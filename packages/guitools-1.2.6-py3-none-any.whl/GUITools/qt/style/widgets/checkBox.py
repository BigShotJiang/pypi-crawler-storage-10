from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from ..utils import Global
from PySide6.QtGui import QColor

def fromRgba(color_str: str, alpha: int) -> str:
    color_str = color_str.strip()

    # Caso seja hexadecimal
    if color_str.startswith('#'):
        color = QColor(color_str)
        return f"rgba({color.red()}, {color.green()}, {color.blue()}, {alpha})"

    # Caso seja rgba
    if color_str.startswith('rgba'):
        parts = color_str[color_str.find('(') + 1 : color_str.find(')')].split(',')
        if len(parts) >= 3:
            r, g, b = [int(p.strip()) for p in parts[:3]]
            return f"rgba({r}, {g}, {b}, {alpha})"

    # Caso seja rgb
    if color_str.startswith('rgb'):
        parts = color_str[color_str.find('(') + 1 : color_str.find(')')].split(',')
        if len(parts) >= 3:
            r, g, b = [int(p.strip()) for p in parts[:3]]
            return f"rgba({r}, {g}, {b}, {alpha})"
        
    return color_str

class indicatorStyleCheet(BaseWidgetStyleSheet):
    def __init__(self, class_name : str, prefix=""):
        super().__init__(f"{prefix} {class_name}")
        self.widget = self.Widget(class_name, prefix)
        self.indicator = self.Indicator(class_name, prefix)
        self.indicator_hover = self.Indicator_hover(class_name, prefix)
        self.indicator_checked = self.Indicator_checked(class_name,prefix)
        self.indicator_checked_hover = self.Indicator_checked_hover(class_name,prefix)

    class Widget(BaseStyleSheet):
        def __init__(self,class_name : str, prefix=""):
            super().__init__(class_name, prefix)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.font = BaseProperty.FontSegoeUI(12)
            self.height = BaseProperty.Height(value=24)

    class Indicator(BaseStyleSheet):
        def __init__(self, class_name : str, prefix=""):
            super().__init__(f'{class_name}::indicator', prefix)
            self.border = BaseProperty.Border(radius=4, color=BaseColor.Widget.hover_border)
            self.width = BaseProperty.Width(value=15)
            self.height = BaseProperty.Height(value=15)
            self.margin = BaseProperty.Margin(top=2)
            self.background = BaseProperty.Background()
            self.add_additional_style('subcontrol-origin: content; subcontrol-position: center left;')
            
    class Indicator_hover(BaseStyleSheet):
        def __init__(self,class_name : str, prefix=""):
            super().__init__(f'{class_name}::indicator:hover', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focus_border)
            self.background = BaseProperty.Background(BaseColor.Widget.background)

    class Indicator_checked_hover(BaseStyleSheet):
        def __init__(self,class_name : str, prefix=""):
            super().__init__(f'{class_name}::indicator:hover:checked', prefix)
            #self.background = BaseProperty.Background(BaseColor.blue.fromRgba(230))
            self.background = BaseProperty.Background(fromRgba(Global.app_color, 230))
            self.add_additional_style(f"background-image: url(:/check_alt_200_200_200.png);") 
           
    class Indicator_checked(BaseStyleSheet):
        def __init__(self,class_name : str, prefix=""):
            super().__init__(f'{class_name}::indicator:checked', prefix)
            #self.background = BaseProperty.Background(BaseColor.blue)
            self.background = BaseProperty.Background(Global.app_color)
            self.add_additional_style(f"background-image: url(:/check_alt_200_200_200.png);")

class CheckBoxStyleCheet(indicatorStyleCheet):
    def __init__(self, prefix=""):
        super().__init__(f"QCheckBox", prefix)
        