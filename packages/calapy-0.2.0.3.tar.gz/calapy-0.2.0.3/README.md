# CalaPy

CalaPy is an undocumented python library that Dr Carmelo Calafiore developed for personal use. It is a collection of
many python functions that Dr Carmelo tends to use in different projects.

In previous versions from 0.0.0 to 0.0.60, the name of this package was ccalafiore.

You can install CalaPy by pip as:

```
pip install calapy
```

## Contacts

Dr Carmelo Calafiore

Newcastle University

Newcastle, UK

[dr.carmelo.calafiore@gmail.com](mailto:dr.carmelo.calafiore@gmail.com)

[LinkedIn](https://www.linkedin.com/in/carmelo-calafiore-a07120269)

[GitHub](https://github.com/ccalafiore)
