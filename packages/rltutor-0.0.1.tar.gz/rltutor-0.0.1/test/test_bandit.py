from rltutor import BanditEnv, EpsilonGreedyAgent, RLTrainer

def test_bandit():
    env = BanditEnv([0.1, 0.5, 0.9])
    agent = EpsilonGreedyAgent(epsilon=0.1, n_arms=3)
    trainer = RLTrainer(env, agent)
    rewards = trainer.train(episodes=100)
    assert len(rewards) == 100
