# rltutor 

A simple, beginner-friendly reinforcement learning toolkit.

## Installation
```bash
pip install rltutor-rohanajay
```
## Usage

from rltutor import BanditEnv, EpsilonGreedyAgent, RLTrainer

env = BanditEnv(arms=[0.1, 0.5, 0.9])
agent = EpsilonGreedyAgent(epsilon=0.1, n_arms=3)
trainer = RLTrainer(env, agent)
trainer.train(episodes=1000)
trainer.plot_results()

## Features

* Features
* Multi-armed bandit environment
* Epsilon-greedy agent
* Visualization of reward progress
* Minimal dependencies