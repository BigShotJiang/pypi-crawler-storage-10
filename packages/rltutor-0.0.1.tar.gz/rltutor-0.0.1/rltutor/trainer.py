import matplotlib.pyplot as plt

class RLTrainer:
    """
    Runs and tracks RL experiments.
    """
    def __init__(self, env, agent):
        self.env = env
        self.agent = agent
        self.rewards = []

    def train(self, episodes=1000):
        """Run training loop."""
        for _ in range(episodes):
            action = self.agent.select_action()
            reward = self.env.step(action)
            self.agent.update(action, reward)
            self.rewards.append(reward)
        return self.rewards

    def plot_results(self):
        """Visualize rewards over episodes."""
        plt.plot(self.rewards)
        plt.xlabel("Episode")
        plt.ylabel("Reward")
        plt.title("Rewards Over Time")
        plt.show()
