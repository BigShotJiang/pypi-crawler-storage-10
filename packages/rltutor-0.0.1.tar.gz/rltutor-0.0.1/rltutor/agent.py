import random

class EpsilonGreedyAgent:
    """
    Epsilon-Greedy Agent for balancing exploration and exploitation.
    """
    def __init__(self, epsilon, n_arms):
        self.epsilon = epsilon
        self.n_arms = n_arms
        self.values = [0.0] * n_arms
        self.counts = [0] * n_arms

    def select_action(self):
        """Select an action using epsilon-greedy strategy."""
        if random.random() < self.epsilon:
            return random.randint(0, self.n_arms - 1)
        return self.values.index(max(self.values))

    def update(self, action, reward):
        """Update action-value estimates."""
        self.counts[action] += 1
        n = self.counts[action]
        value = self.values[action]
        self.values[action] += (reward - value) / n
