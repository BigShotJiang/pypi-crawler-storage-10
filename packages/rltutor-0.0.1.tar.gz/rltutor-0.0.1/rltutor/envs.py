import random

class BanditEnv:
    """
    Simple multi-armed bandit environment for RL learning.
    Each arm has a fixed probability of reward.
    """
    def __init__(self, arms):
        self.arms = arms

    def step(self, action):
        """Take an action (choose an arm) and return a stochastic reward."""
        prob = self.arms[action]
        reward = 1 if random.random() < prob else 0
        return reward

    def n_arms(self):
        """Return number of available actions (arms)."""
        return len(self.arms)
