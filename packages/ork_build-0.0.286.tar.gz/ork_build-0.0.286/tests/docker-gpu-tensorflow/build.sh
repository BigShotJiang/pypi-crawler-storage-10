#!/usr/bin/env sh

docker build -t tflow_gpu:latest .

