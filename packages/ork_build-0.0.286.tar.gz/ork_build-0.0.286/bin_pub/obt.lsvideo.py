#!/usr/bin/env python3

import os

print("please wait...")
os.system("obt.lsusbx.py | grep video")
