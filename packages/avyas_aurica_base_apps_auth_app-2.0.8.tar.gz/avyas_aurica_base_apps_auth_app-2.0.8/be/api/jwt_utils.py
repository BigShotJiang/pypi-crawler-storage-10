"""
JWT token generation and verification utilities for decentralized authentication.
Uses HMAC-based JWT (HS256) with shared secret - no key management needed!
Each host can verify tokens using the shared secret from centralized auth server.
ONLY generates tokens on the centralized auth server (api.oneaurica.com).
Other hosts just verify tokens via JWKS.
"""
import jwt
import json
import os
import secrets
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from pathlib import Path
import sys

# Add the auth-app api directory to path for imports
_api_dir = Path(__file__).parent
if str(_api_dir) not in sys.path:
    sys.path.insert(0, str(_api_dir))

import s3_storage

# Check if we're running on the centralized auth server
def is_auth_server():
    """Check if this instance is the centralized auth server."""
    auth_server_domain = os.getenv("AUTH_SERVER_DOMAIN", "api.oneaurica.com")
    
    # Get current hostname (try multiple methods)
    current_host = None
    
    # Method 1: Check HOSTNAME environment variable (common in containers)
    current_host = os.getenv("HOSTNAME")
    
    # Method 2: Try socket.gethostname()
    if not current_host:
        try:
            import socket
            current_host = socket.gethostname()
        except:
            pass
    
    # Method 3: Check if running in production based on environment
    # If we're in production and AUTH_SERVER_DOMAIN doesn't contain localhost, assume we're the auth server
    if not current_host or "localhost" not in auth_server_domain:
        # In production, if AUTH_SERVER_DOMAIN is api.oneaurica.com, then this IS the auth server
        return "localhost" not in auth_server_domain and "127.0.0.1" not in auth_server_domain
    
    # For localhost testing: AUTH_SERVER_DOMAIN should be localhost:8000
    return "localhost" in auth_server_domain or "127.0.0.1" in auth_server_domain


class JWTManager:
    """Manages JWT token generation and verification with HMAC (HS256) - keyless!"""
    
    def __init__(self):
        """Initialize JWT manager with shared secret."""
        self.is_auth_server = is_auth_server()
        self.storage = s3_storage.S3Storage() if self.is_auth_server else None
        self.secret_key = None
        
        if self.is_auth_server:
            print("🔐 JWTManager: Running as AUTH SERVER - will load/generate JWT secret")
            self._load_or_generate_secret()
        else:
            print("🔓 JWTManager: Running as regular host - JWT secret not needed (tokens verified via JWKS)")
            # Non-auth servers don't need the secret - they verify via JWKS
    
    def _load_or_generate_secret(self):
        """Load existing secret from storage or generate new one (only on auth server)."""
        if not self.is_auth_server:
            return
            
        # First try environment variable (for dynamic secrets)
        env_secret = os.getenv('JWT_SECRET_KEY')
        if env_secret:
            self.secret_key = env_secret
            print("✅ Using JWT secret from environment variable")
            return
        
        try:
            # Try to load existing secret from storage
            print("🔑 Loading JWT secret from storage...")
            secret_data = self.storage.load_json('jwt_secret.json')
            
            if secret_data and 'secret_key' in secret_data:
                self.secret_key = secret_data['secret_key']
                print(f"✅ Loaded existing JWT secret from storage (key length: {len(self.secret_key)})")
            else:
                raise ValueError("Secret data incomplete")
                
        except Exception as e:
            print(f"⚠️  Could not load secret: {e}")
            print(f"⚠️  Attempting to generate and save new secret...")
            
            try:
                # Try to generate and save a new secret
                self._generate_new_secret()
                print(f"✅ Successfully generated and saved new JWT secret")
            except Exception as save_error:
                print(f"❌ Failed to save new secret to storage: {save_error}")
                print("🔑 Using temporary in-memory JWT secret...")
                # Generate temporary secret - won't be persisted if S3 is having issues
                self.secret_key = secrets.token_urlsafe(32)
                print(f"⚠️  Using temporary JWT secret - tokens won't work across restarts!")
                print(f"💡 Set JWT_SECRET_KEY environment variable to use a fixed secret")
    
    def _generate_new_secret(self):
        """Generate a new shared secret and save to storage (only on auth server)."""
        if not self.is_auth_server:
            return
            
        # Generate a secure random secret (256 bits)
        self.secret_key = secrets.token_urlsafe(32)
        
        # Save to storage
        secret_data = {
            'secret_key': self.secret_key,
            'created_at': datetime.utcnow().isoformat(),
            'algorithm': 'HS256'
        }
        
        self.storage.save_json('jwt_secret.json', secret_data)
        print(f"✅ Generated and saved new JWT secret")
        print(f"💡 To use this secret on other hosts, set: JWT_SECRET_KEY={self.secret_key}")
    
    def create_token(
        self,
        user_id: str,
        username: str,
        role: str = "user",
        metadata: Optional[Dict[str, Any]] = None,
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        Create a JWT token for a user.
        
        Args:
            user_id: Unique user identifier
            username: Username
            role: User role (default: "user")
            metadata: Optional additional claims
            expires_delta: Token expiration time (default: 7 days)
        
        Returns:
            JWT token string
        """
        if expires_delta is None:
            expires_delta = timedelta(days=7)
        
        now = datetime.utcnow()
        expire = now + expires_delta
        
        # Build JWT claims
        claims = {
            # Standard claims
            "sub": user_id,  # Subject (user ID)
            "iat": int(now.timestamp()),  # Issued at
            "exp": int(expire.timestamp()),  # Expiration
            "nbf": int(now.timestamp()),  # Not before
            "iss": "api.oneaurica.com",  # Issuer
            "aud": "aurica-apps",  # Audience
            
            # Custom claims
            "username": username,
            "role": role,
        }
        
        # Add any additional metadata
        if metadata:
            claims["metadata"] = metadata
        
        # Sign the token with HMAC
        token = jwt.encode(
            claims,
            self.secret_key,
            algorithm="HS256"
        )
        
        return token
    
    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Verify and decode a JWT token.
        
        Args:
            token: JWT token string
        
        Returns:
            Decoded token claims or None if invalid
        """
        try:
            # Decode and verify the token
            claims = jwt.decode(
                token,
                self.secret_key,
                algorithms=["HS256"],
                audience="aurica-apps",
                issuer="api.oneaurica.com"
            )
            
            return claims
            
        except jwt.ExpiredSignatureError:
            print("⚠️  Token has expired")
            return None
        except jwt.InvalidTokenError as e:
            print(f"⚠️  Invalid token: {e}")
            return None
    
    def get_secret_info(self) -> Dict[str, Any]:
        """
        Get information about the JWT secret (for distribution to other hosts).
        
        Returns:
            Secret information
        """
        return {
            "algorithm": "HS256",
            "issuer": "api.oneaurica.com",
            "audience": "aurica-apps",
            "secret_key": self.secret_key,
            "expires_days": 7
        }
    
    def get_jwks(self) -> Dict[str, Any]:
        """
        Get JSON Web Key Set (JWKS) for token verification.
        
        For HMAC (HS256), this returns the symmetric key.
        Note: In production, consider switching to RSA for better security.
        
        Returns:
            JWKS dictionary
        """
        # For HMAC, the secret_key is already base64url-encoded (from secrets.token_urlsafe)
        # Don't double-encode it!
        return {
            "keys": [
                {
                    "kty": "oct",  # Octet sequence (symmetric key)
                    "use": "sig",
                    "alg": "HS256",
                    "k": self.secret_key  # Already base64url-encoded
                }
            ]
        }
    
    def refresh_token(self, token: str) -> Optional[str]:
        """
        Refresh an existing token (if valid and not expired).
        
        Args:
            token: Existing JWT token
        
        Returns:
            New JWT token or None if invalid
        """
        claims = self.verify_token(token)
        
        if not claims:
            return None
        
        # Create a new token with the same claims but new expiration
        return self.create_token(
            user_id=claims["sub"],
            username=claims["username"],
            role=claims.get("role", "user"),
            metadata=claims.get("metadata")
        )


# Global JWT manager instance
jwt_manager = JWTManager()
