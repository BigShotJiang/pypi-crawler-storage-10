# Log viewer extension
