def test_import() -> None:
    exec("from kraken.core import *")
    exec("from kraken.core import *")
