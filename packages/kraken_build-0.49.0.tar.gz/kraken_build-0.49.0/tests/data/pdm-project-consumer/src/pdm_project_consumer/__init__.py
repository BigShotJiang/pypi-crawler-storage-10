from pdm_project import foo

foo()
