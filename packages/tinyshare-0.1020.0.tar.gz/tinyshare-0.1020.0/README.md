# TinyShare SDK

pip install tinyshare --upgrade