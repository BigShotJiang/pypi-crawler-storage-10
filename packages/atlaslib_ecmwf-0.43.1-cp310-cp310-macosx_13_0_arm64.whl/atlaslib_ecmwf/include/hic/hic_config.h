/*
 * (C) Copyright 2024- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation
 * nor does it submit to any jurisdiction.
 */
#pragma once

#if defined(HIC_BACKEND_DUMMY) && HIC_BACKEND_DUMMY==1
#define HIC_BACKEND_CUDA 0
#define HIC_BACKEND_HIP  0
#else
#define HIC_BACKEND_CUDA 0
#define HIC_BACKEND_HIP 0
#define HIC_BACKEND_DUMMY 1
#endif

#if (defined(__CUDACC__) || defined(__HIPCC__))
#define HIC_COMPILER 1
#define HIC_HOST_DEVICE __host__ __device__
#define HIC_DEVICE      __device__
#define HIC_HOST        __host__
#define HIC_GLOBAL      __global__
#else
#define HIC_COMPILER 0
#define HIC_HOST_DEVICE
#define HIC_DEVICE
#define HIC_HOST
#define HIC_GLOBAL
#endif

#if defined(__CUDA_ARCH__) || defined(__HIP_DEVICE_COMPILE__)
#define HIC_HOST_COMPILE 0
#define HIC_DEVICE_COMPILE 1
#else
#define HIC_HOST_COMPILE 1
#define HIC_DEVICE_COMPILE 0
#endif
