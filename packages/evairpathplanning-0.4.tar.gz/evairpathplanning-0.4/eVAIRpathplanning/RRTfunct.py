import numpy as np
import random as rand


#finding path
def findpath(E, start):
    icntr = 0
    #converts E one for x11 and y11, another for x12, y12
    E = np.array(E)
    VE1 = (E[:,:,0])
    VE2 = (E[:,:,1])

    ipath = -1
    Vpath = [[VE2[ipath,0]], [VE2[ipath,1]]]

    start2 = [start[0], start[1]]

    #matches the x11 and y11 with a x12 and y12
    while 0 != ipath and 0 != ipath and icntr < 1000:
        iplen = range(len(VE2))
        for j in iplen:
            if VE1[ipath][0] == VE2[j][0] and VE1[ipath][1] == VE2[j][1]:
                ipath = j
        Vpath[0].append(int(VE2[ipath,0]))
        Vpath[1].append(int(VE2[ipath,1]))
        icntr += 1
    Vpath[0].append(start2[0])
    Vpath[1].append(start2[0])

    return Vpath



#filter for object points (bounds are exclusive)
def boundfilter(p1, p2, obpts):
    filtered_points = [[],[]]
    if p1[0] > p2[0]:
        if p1[1] > p2[1]:
            #topright = p1
            #bottomleft = p2
            for i in range(len(obpts[0])):
                if p2[0] < obpts[0][i] < p1[0] and p2[1] < obpts[1][i] < p1[1]:
                    filtered_points[0].append(obpts[0][i])
                    filtered_points[1].append(obpts[1][i])

        else:
            #bottomright = p1
            #topleft = p2
            for i in range(len(obpts[0])):
                if p2[0] < obpts[0][i] < p1[0] and p1[1] < obpts[1][i] < p2[1]:
                    filtered_points[0].append(obpts[0][i])
                    filtered_points[1].append(obpts[1][i])

    elif p2[0] > p1[0]:
        if p2[1] > p1[1]:
            #topright = p2
            #bottomleft = p1
            for i in range(len(obpts[0])):
                if p1[0] < obpts[0][i] < p2[0] and p1[1] < obpts[1][i] < p2[1]:
                    filtered_points[0].append(obpts[0][i])
                    filtered_points[1].append(obpts[1][i])

        else:
            #bottomright = p2
            #topleft = p1
            for i in range(len(obpts[0])):
                if p1[0] < obpts[0][i] < p2[0] and p2[1] < obpts[1][i] < p1[1]:
                    filtered_points[0].append(obpts[0][i])
                    filtered_points[1].append(obpts[1][i])
    return filtered_points


# for RRT star
# Euclidean distance between two 2D points (tuples/lists)
def euclid(a, b):
    return ((a[0] - b[0])**2 + (a[1] - b[1])**2)*(1/2)

#computing cost
def compute_cost(new_point, parent_idx, V, costs):
    parent_point = (V[0][parent_idx], V[1][parent_idx])
    dist = euclid(new_point, parent_point)
    return costs[parent_idx] + dist

#choosing parent with the lowest value
def choose_best_parent(new_point, near_indices, V, costs):
    best_parent_idx = None
    best_cost = float("inf")

    for idx in near_indices:
        parent_point = (V[0][idx], V[1][idx])
        dist = euclid(new_point, parent_point)
        candidate_cost = costs[idx] + dist

        if candidate_cost < best_cost:
            best_cost = candidate_cost
            best_parent_idx = idx
    
    return best_parent_idx, best_cost

#rewiring neighbors
def neighborrewiring(newpt, nearidxs, V, E, costs):
    for i in nearidxs:
        nbr_point = [V[0][i], V[1][i]]
        newcost = costs[-1] + euclid(newpt, nbr_point)

        if newcost < costs[i]:

            E[i] = [[nbr_point[0], newpt[0]], [nbr_point[1], newpt[1]]]
            costs[i] = newcost
    
    #optimize
    return E, costs