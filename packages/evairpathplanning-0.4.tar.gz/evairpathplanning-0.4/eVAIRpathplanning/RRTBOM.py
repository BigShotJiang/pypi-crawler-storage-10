import numpy as np
import random as rand
from .RRTfunct import findpath
from .RRTfunct import choose_best_parent
from .RRTfunct import euclid
from .RRTfunct import compute_cost
from .RRTfunct import neighborrewiring

#collision check
def collision_freeBOM(p1, p2, map_matrix):

    x0, y0 = p1
    x1, y1 = p2

    steps = int(max(abs(x1 - x0), abs(y1 - y0)))
    for i in range(steps + 1):
        t = i / steps
        x = x0 + t * (x1 - x0)
        y = y0 + t * (y1 - y0)


        xi = int(round(x))
        yi = int(round(y))


        # Check for obstacle
        if map_matrix[xi, yi] == 1:
            return False

    return True

#RRT 1.3
def RRT13(map, start, goal):
    ### RRT ###
    #starting variables (counter and connect check)
    icntr = 0
    cnct = False
    #separate because it makes it easier to modify the map and RRT
    Qgoal = goal

    #G(V, E)
    #E = [[[x11,x12],[y11,y12]], [[x11,x12],[y11,y12]]]
    E = []
    #V = [[x1, x2...], [y1, y2...]]
    V = [[start[0]], [start[1]]]

    #While counter < lim and path isn't connected
    while icntr < 10000 and cnct == False:
        #Xnew  = RandomPosition()
        #[x1, y1]
        X = (rand.randrange(0, len(map), 1), rand.randrange(0, len(map[0]), 1))

        #if IsInObstacle(Xnew) == True:
            #continue
        Xvalid = True
        shapes1 = []

        xi = int(X[0])
        yi = int(X[1])

        #checks if there's already a point there 
        for i in range(len(V[0])):
            if xi == V[0][i]:
                if yi == V[1][i]:
                    Xvalid = False
        #checks if point is on 1
        if map[xi, yi] == 1:
            Xvalid = False

        if Xvalid == True:
            #Xnearest = Nearest(G(V,E),Xnew) //find nearest vertex
            #setting the nearest vertex as vertex 1
            Vnrst = (V[0][0], V[1][0])
            Vdist1 = ((V[0][0] - X[0])**2 + (V[1][0] - X[1])**2)**(1/2)
            #comparing the vertex distances to determine the closest vertex
            for i in range(len(V[0])):
                Vdist2 = ((V[0][i] - X[0])**2 + (V[1][i] - X[1])**2)**(1/2)
                if Vdist2 < Vdist1:
                    Vnrst = (V[0][i], V[1][i])
                    Vdist1 = Vdist2

            #Link = Chain(Xnew,Xnearest)
            #G.append(Link)
            #[[[x11,x12], [y11,y12]]
            #E.append([[Vnrst[0],X[0]], [Vnrst[1],X[1]]])
            #V[0].append(X[0])
            #V[1].append(X[1])
            if Xvalid and collision_freeBOM(Vnrst, X, map):
                E.append([[Vnrst[1], X[1]], [Vnrst[0], X[0]]])
                V[1].append(X[1])
                V[0].append(X[0])

                #if Xnew in Qgoal:
                    #Return G
                if X[1] >= Qgoal[0][0] and X[0] >= Qgoal[1][0]:
                    if X[1] <= Qgoal[0][1] and X[0] <= Qgoal[1][1]:
                        cnct = True

        #iteration
        icntr += 1

    ### RRT ###


    ### tracing the path ###
    Vpath = findpath(E, start)
    ### tracing the path ###

    return E, V, Vpath, icntr, cnct

#fix
#multiple iteration RRT
def RRT_multi_iter_BOM(map, start, goal, iter):
    Es = []
    Vpaths = []
    slengths = []
    cncts = []
    for i in range(150):
        E, V, Vpath, icntr, cnct = RRT13(map, start, goal)
        Vpaths.append(Vpath)
        cncts.append(cnct)

        slength = 0
        if cnct == True:
            for i in range(len(Vpath[0])-1):
                ds = ((Vpath[0][i] - Vpath[0][i+1])**2 + (Vpath[1][i] - Vpath[1][i+1])**2)**(1/2)
                slength += ds
        slengths.append(slength)
        Es.append(E)

    n = i

    cnct = False
    if len(slengths) > 1:
        minslength = min(slengths)
        idx = slengths.index(minslength)

        cnct = cncts[idx]
        Vpath = Vpaths[idx]
        E = Es[idx]

        return E, Vpath, cnct

    return 0, 0, cnct

