import numpy as np
import random as rand
import RRTfunct
from .RRTfunct import findpath
from .RRTfunct import choose_best_parent
from .RRTfunct import euclid
from .RRTfunct import compute_cost
from .RRTfunct import neighborrewiring

### functions ###
def collision_free(p1, p2, obstacles):
    """
    Check if the line segment between p1 and p2 intersects any rectangular obstacle.
    p1, p2 = (x, y)
    obstacles = list of [[x_min, x_max], [y_min, y_max]]
    """
    for shape in obstacles:
        xmin, xmax = shape[0]
        ymin, ymax = shape[1]

        # If both points are inside obstacle ? Flse
        if (xmin <= p1[0] <= xmax and ymin <= p1[1] <= ymax) or \
           (xmin <= p2[0] <= xmax and ymin <= p2[1] <= ymax):
            return False

        # Divide edge into small steps and check each point
        steps = 20
        for i in range(steps+1):
            t = i / steps
            x = p1[0] + t*(p2[0]-p1[0])
            y = p1[1] + t*(p2[1]-p1[1])
            if xmin <= x <= xmax and ymin <= y <= ymax:
                return False
    return True


def RRT12(maplim, start, goal, shapes1):
    ### RRT ###
    #starting variables (counter and connect check)
    icntr = 0
    cnct = False
    #separate because it makes it easier to modify the map and RRT
    Qgoal = goal

    #G(V, E)
    #E = [[[x11,x12],[y11,y12]], [[x11,x12],[y11,y12]]]
    E = []
    #V = [[x1, x2...], [y1, y2...]]
    V = [[start[0][0]], [start[1][0]]]

    #calling function findpath for vpath variable
    Vpath = findpath(E, start)

    #FUNCTION COLLISION FREE
    #While counter < lim and path isn't connected
    while icntr < 10000 and cnct == False:
        #Xnew  = RandomPosition()
        #[x1, y1]
        X = (rand.randrange(maplim[0][0], maplim[0][1], 1), rand.randrange(maplim[1][0], maplim[1][1], 1))

        Xvalid = True

        for shape in shapes1:
                if X[0] >= shape[0][0] and X[1] >= shape[1][0]:
                    if X[0] <= shape[0][1] and X[1] <= shape[1][1]:
                        Xvalid = False

        if Xvalid == True:
            #Xnearest = Nearest(G(V,E),Xnew) //find nearest vertex
            #setting the nearest vertex as vertex 1
            Vnrst = (V[0][0], V[1][0])
            Vdist1 = ((V[0][0] - X[0])**2 + (V[1][0] - X[1])**2)**(1/2)
            #comparing the vertex distances to determine the closest vertex
        for i in range(len(V[0])):
            Vdist2 = ((V[0][i] - X[0])**2 + (V[1][i] - X[1])**2)**(1/2)
            if Vdist2 < Vdist1:
                Vnrst = (V[0][i], V[1][i])
                Vdist1 = Vdist2


            #Link = Chain(Xnew,Xnearest)
            #G.append(Link)
            #[[[x11,x12], [y11,y12]]
            #E.append([[Vnrst[0],X[0]], [Vnrst[1],X[1]]])
            #V[0].append(X[0])
            #V[1].append(X[1])

            if Xvalid and collision_free(Vnrst, X, shapes1):
                E.append([[Vnrst[0], X[0]], [Vnrst[1], X[1]]])
                V[0].append(X[0])
                V[1].append(X[1])

                #if Xnew in Qgoal:
                    #Return G
            if X[0] > Qgoal[0][0] and X[1] > Qgoal[1][0]:
                if X[0] < Qgoal[0][1] and X[1] < Qgoal[1][1]:
                    cnct = True

        #increment
        icntr += 1

    ###RRT###
    return E, V, icntr, Vpath, cnct

def RRT_multi_iter_O(map, start, goal, iter):
    Es = []
    Vpaths = []
    slengths = []
    cncts = []
    for i in range(150):
        E, V, Vpath, icntr, cnct = RRT12(map, start, goal)
        Vpaths.append(Vpath)
        cncts.append(cnct)

        slength = 0
        if cnct == True:
            for i in range(len(Vpath[0])-1):
                ds = ((Vpath[0][i] - Vpath[0][i+1])**2 + (Vpath[1][i] - Vpath[1][i+1])**2)**(1/2)
                slength += ds
        slengths.append(slength)
        Es.append(E)

    n = i

    cnct = False
    if len(slengths) > 1:
        minslength = min(slengths)
        idx = slengths.index(minslength)

        cnct = cncts[idx]
        Vpath = Vpaths[idx]
        E = Es[idx]

        return E, Vpath, cnct

    return 0, 0, cnct