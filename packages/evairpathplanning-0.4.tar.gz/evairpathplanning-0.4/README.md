idk what to put here lmao
0.1 - had a print(ip on line 43 RRT)
0.2 - new functions
0.3 - RRTO, RRTBOM, and RRTfunct, also cnct
0.4 - fixed find path algorithm