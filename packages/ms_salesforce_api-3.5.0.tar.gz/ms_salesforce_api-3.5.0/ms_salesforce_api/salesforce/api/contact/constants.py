DEFAULT_CONTACT_QUERY = """
SELECT
    Id,
    AccountId,
    Name,
    Email,
    Phone,
    Title,
    Department
FROM
    Contact
"""
