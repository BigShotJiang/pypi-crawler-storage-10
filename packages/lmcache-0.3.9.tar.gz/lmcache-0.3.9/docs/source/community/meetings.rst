Community meetings
====================================================

LMCache hosts regular community meetings to discuss updates, address new feature requests, 
and feedback from the community. If you are interested in contributing to the LMCache projects
(core LMCache or Production Stack), we encourage you to join the meetings.

Meeting schedule
-----------------
The LMCache community meetings held separately for each project: 

- LMCache - `Github <https://github.com/LMCache/LMCache/>`__
- Production Stack - `Github <https://github.com/vllm-project/production-stack>`__

LMCache Project
++++++++++++++++

The LMCache community meeting is held bi-weekly on **Tuesdays** at **9:00-9:30 AM PT**. 

Please find the meeting invite link below:

- **Meeting link**: `Zoom link <https://uchicago.zoom.us/j/6603596916?pwd=Z1E5MDRWUSt2am5XbEt4dTFkNGx6QT09>`_
- **Calendar Invite**: `Google Calendar <https://drive.usercontent.google.com/u/0/uc?id=15Xz8-LtpBQ5QgR7KrorOOyfuohCFQmwn&export=download>`__
- **Slack Channel**: `#lmcache <https://lmcacheworkspace.slack.com/join/shared_invite/zt-3h7ohnf5t-ZZ0JBuYCIh1eUwHPTqSNCQ#/shared-invite/email>`_

vLLM Production Stack Project
+++++++++++++++++++++++++++++++

The Production Stack community meeting is held bi-weekly on **Tuesdays** at **5:30-6:00 PM PT**.
Please find the meeting invite link below:

- **Meeting link**: `Zoom link <https://uchicago.zoom.us/j/6603596916?pwd=Z1E5MDRWUSt2am5XbEt4dTFkNGx6QT09>`_
- **Calendar Invite**: `Google Calendar <https://drive.usercontent.google.com/u/0/uc?id=1I3WuivUVAq1vZ2XSW4rmqgD5c0bQcxE0&export=download>`__
- **Slack Channel**: `#production-stack <https://vllm-dev.slack.com/archives/C089SMEAKRA>`_


.. note:: 
    The Zoom meeting link is the same for both LMCache and Production Stack community meetings. 
    Meeting notes are available here: `Meeting notes <https://docs.google.com/document/d/1vX0g2q3j4x5m7J6z8Q9Gk4Z5l7f3K8h0nqYwW1a2c4o/edit?usp=sharing>`_.
