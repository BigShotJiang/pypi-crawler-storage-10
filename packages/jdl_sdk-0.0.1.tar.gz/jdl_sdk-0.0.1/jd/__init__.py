#!/usr/bin/python3
# @Time    : 2025-10-18
# @Author  : Kevin Kong (kfx2007@163.com)

__version__ = "0.0.1"
__author__ = "Kevin Kong"