"""Entry point for Civic Dev CLI.

File: cli.__main__
"""

from civic_lib_core.cli.cli import app

if __name__ == "__main__":
    app()
