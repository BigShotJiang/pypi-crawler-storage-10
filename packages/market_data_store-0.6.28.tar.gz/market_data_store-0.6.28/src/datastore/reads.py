# Intentionally minimal; add read helpers later (for ops/tests), not bulk APIs.
