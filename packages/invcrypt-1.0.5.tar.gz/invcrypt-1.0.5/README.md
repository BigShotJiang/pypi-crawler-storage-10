InvCrypt CLI – Community Edition v1.0.0
=======================================

Developed by Invicra Technologies AB
------------------------------------

InvCrypt is a quantum-safe command-line encryption tool based on Invicra’s
proprietary DITG/FTG cryptographic framework. It is designed to resist both
classical and quantum-based attacks and offers a fully offline encryption
environment.

This Community Edition is a free, functional version distributed without
exposing the protected cryptographic modules. It is fully compatible with
future commercial editions and intended for research, educational, and
non-commercial use.

------------------------------------------------------------
SECURITY NOTICE
------------------------------------------------------------

This Community Edition is intended for research, testing, and educational use.  
It provides functional, quantum-safe local encryption but is **not certified for
production environments** or for protecting highly sensitive or classified data.

Invicra Technologies AB does not take responsibility for data loss or misuse
resulting from improper seed or file handling. For enterprise or commercial use,
contact Invicra Technologies for a professional license.

------------------------------------------------------------
OVERVIEW
------------------------------------------------------------

- Quantum-safe local file encryption and decryption
- Seed-based key generation (no key files required)
- Built-in hash functions: shake256, shake256x, blake3x
- Extended metrics and integrity verification
- Automated round-trip test (--testrun)
- Cross-platform support (Windows, macOS, Linux)
- Fully functional without exposing source code

------------------------------------------------------------
INSTALLATION
------------------------------------------------------------

From a wheel file:
    pip install dist/invcrypt-1.0.0-py3-none-any.whl

(Future PyPI release)
    pip install invcrypt

------------------------------------------------------------
USAGE EXAMPLES
------------------------------------------------------------

Encrypt a file:
    invcrypt file.txt --seed mypass

Decrypt a file:
    invcrypt file.txt.invx --seed mypass

Prompt for password:
    invcrypt file.txt -p

Run full encrypt/decrypt test:
    invcrypt --testrun file.txt --seed testseed

Display help and options:
    invcrypt --info

------------------------------------------------------------
SEED WARNING
------------------------------------------------------------

Your password (seed) is the **only** key required to encrypt and decrypt files.  
If the seed is lost or forgotten, **your data cannot be recovered**.  
InvCrypt does not store, transmit, or recover seeds under any circumstances.

------------------------------------------------------------
AVAILABLE HASH FUNCTIONS
------------------------------------------------------------

Name        Classical Bits   Quantum Bits   Performance
------------------------------------------------------------
shake256       512               256           Stable
shake256x     1024               512           Stable
blake3x       1024               512           Fast

------------------------------------------------------------
CLI COMMANDS
------------------------------------------------------------

--info                 Show CLI overview and examples
--flags                Display all available flags
--hashlist             List supported hash functions
--mode                 Select "encrypt" or "decrypt"
--seed                 Provide seed or password
--password-prompt      Ask for password interactively
--metrics              Show extended metrics
--avalanchtest         Compare avalanche effect between two files
--testrun              Perform a full encrypt/decrypt test
--overwrite            Allow overwriting existing output files
--delete-original      Delete the original file after successful encryption

------------------------------------------------------------
SECURITY ARCHITECTURE
------------------------------------------------------------

InvCrypt is built upon Invicra’s proprietary mathematical frameworks:

  DITG – Distributed Inverted Transformation Graphs
  FTG  – Field Transformation Geometry

The protected modules (matrix, crypto_core, hashing, utils) are distributed
as compiled .pyc files and cannot be reverse-engineered.

------------------------------------------------------------
SYSTEM REQUIREMENTS
------------------------------------------------------------

Python:    3.12 or later
Platforms: Windows, macOS, Linux
Packages:  tqdm, colorama

------------------------------------------------------------
PROJECT STRUCTURE
------------------------------------------------------------

invcrypt/
    cli_args.py
    config.py
    constants.py
    info.py
    loader.py
    main.py
    metrics.py
    __pycache__/   (contains protected modules)

------------------------------------------------------------
LICENSE
------------------------------------------------------------

Invicra Community License 2025

This version may be used freely for personal, academic, or non-commercial
testing. Redistribution or commercial deployment requires a separate license
from Invicra Technologies AB.

------------------------------------------------------------
ABOUT INVICRA TECHNOLOGIES
------------------------------------------------------------

Invicra Technologies AB develops next-generation quantum-secure cryptographic
systems based on proprietary mathematical frameworks (DITG, FTG, IUHMF).
The company focuses on data security, AI safety, and post-quantum cryptography.

Contact: contact@invicra.com
Website: (to be launched in 2025)

------------------------------------------------------------
RELEASE DETAILS
------------------------------------------------------------

Version: 1.0.0
Date: October 2025
Edition: Community (Public)
