
from setuptools import setup

# 仅通过pyproject.toml读取配置（避免重复定义）
setup()