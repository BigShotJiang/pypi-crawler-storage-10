# -*- coding: utf-8 -*-
"""
kasp_designer.py
Main KASP Primer Designer - Modular version with bin/ structure

Usage examples:
  # Function 1: Genome-wide density-based sampling
  python kasp_designer.py genome --vcf test_data/BSA-test.vcf.gz --ref test_data/msu7_chr1_12.fa --mother PR25 --father RIBENQING --output_prefix results_genome --bowtie_index genome_index/msu7_chr1_12 --threads 12
  
  # Function 2: Region-based SNP analysis
  python kasp_designer.py region --chrom 1 --start 4607899 --end 4627899 --vcf test_data/BSA-test.vcf.gz --ref test_data/msu7_chr1_12.fa --mother PR25 --father RIBENQING --output_prefix results_region --bowtie_index genome_index/msu7_chr1_12 --threads 12
  
  # Function 3: Target SNP primer design
  python kasp_designer.py target --chrom 1 --position 4632557 --vcf test_data/BSA-test.vcf.gz --ref test_data/msu7_chr1_12.fa --mother PR25 --father RIBENQING --output_prefix results_target --bowtie_index genome_index/msu7_chr1_12 --threads 12

  
  # Function 4: Custom sequence-based design
  python kasp_designer.py custom --snp_sequences test_data/test_snp_sequences.txt --ref test_data/msu7_chr1_12.fa --output_prefix results_custom --bowtie_index genome_index/msu7_chr1_12 --threads 12



"""

import os
import sys
import argparse
import time
from multiprocessing import cpu_count

# Add bin directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'bin'))

# Import function modules from bin directory
from kaspioneer.bin.kasp_functions import function_genome_sampling, function_region_analysis, function_target_snp_design, function_custom_sequence_design
from kaspioneer.bin.kasp_utils import check_existing_bowtie_index

def build_common_arguments(subparser):
    """Add common arguments to subparsers"""
    subparser.add_argument("--ref", required=True, help="Reference FASTA")
    subparser.add_argument("--output_prefix", required=True, help="Output file prefix")
    subparser.add_argument("--min_qual", type=float, default=30.0, help="Minimum SNP quality")
    subparser.add_argument("--verbose", action='store_true', help="Enable verbose logging")
    subparser.add_argument("--bowtie_index", help="Bowtie index prefix")
    subparser.add_argument("--min_left_dist", type=int, default=26, help="Filter left SNP closer than this distance (bp)")
    subparser.add_argument("--min_right_dist", type=int, default=80, help="Filter right SNP closer than this distance (bp)")
    subparser.add_argument("--upstream_len", type=int, default=30, help="Upstream sequence length")
    subparser.add_argument("--downstream_len", type=int, default=100, help="Downstream sequence length")
    subparser.add_argument("--min_primer_len", type=int, default=20, help="Minimum primer length")
    subparser.add_argument("--max_primer_len", type=int, default=26, help="Maximum primer length")
    subparser.add_argument("--min_gc", type=float, default=30.0, help="Minimum GC content")
    subparser.add_argument("--max_gc", type=float, default=60.0, help="Maximum GC content")
    subparser.add_argument("--min_tm", type=float, default=55.0, help="Minimum Tm")
    subparser.add_argument("--max_tm", type=float, default=61.0, help="Maximum Tm")
    subparser.add_argument("--max_tm_diff", type=float, default=3.0, help="Maximum Tm difference")
    subparser.add_argument("--max_product_len", type=int, default=100, help="Maximum product length")
    subparser.add_argument("--fam_tail", default="GAAGGTGACCAAGTTCATGCT", help="FAM tail sequence")
    subparser.add_argument("--hex_tail", default="GAAGGTCGGAGTCAACGGATT", help="HEX tail sequence")
    subparser.add_argument("--threads", type=int, default=max(1, cpu_count()-1), help="Number of threads")

def build_genome_arguments(subparser):
    """Add arguments for genome-wide density sampling function"""
    build_common_arguments(subparser)
    subparser.add_argument("--vcf", required=True, help="Input VCF file (can be .gz)")
    subparser.add_argument("--mother", required=True, help="Mother sample name")
    subparser.add_argument("--father", required=True, help="Father sample name")
    subparser.add_argument("--bins_per_chr", type=int, default=20, help="Bins per chromosome")
    subparser.add_argument("--flank_snps", type=int, default=10, help="Number of flanking SNPs on each side of median SNP")

def build_region_arguments(subparser):
    """Add arguments for region-based SNP analysis function"""
    build_common_arguments(subparser)
    subparser.add_argument("--vcf", required=True, help="Input VCF file (can be .gz)")
    subparser.add_argument("--chrom", required=True, help="Chromosome name")
    subparser.add_argument("--start", type=int, required=True, help="Start position of the region")
    subparser.add_argument("--end", type=int, required=True, help="End position of the region")
    subparser.add_argument("--mother", required=True, help="Mother sample name")
    subparser.add_argument("--father", required=True, help="Father sample name")


def build_target_arguments(subparser):
    """Add arguments for target SNP design function"""
    build_common_arguments(subparser)
    subparser.add_argument("--vcf", required=True, help="Input VCF file (can be .gz)")
    subparser.add_argument("--chrom", required=True, help="Chromosome name")
    subparser.add_argument("--position", type=int, required=True, help="Target SNP position")
    subparser.add_argument("--flank_snps", type=int, default=10, help="Number of flanking SNPs on each side of target SNP")
    subparser.add_argument("--mother", required=True, help="Mother sample name")
    subparser.add_argument("--father", required=True, help="Father sample name")

def build_custom_arguments(subparser):
    """Add arguments for custom sequence-based design function"""
    build_common_arguments(subparser)
    subparser.add_argument("--snp_sequences", required=True, help="Input file with SNP sequences (tab-separated: ID and sequence)")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="KASP Primer Designer - Multi-function tool for SNP analysis and primer design",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
        Examples:
        # Genome-wide density-based sampling for primer design
        kasp_designer.py genome --vcf variants.vcf.gz --ref genome.fa --mother PR25 --father RIBENQING --output_prefix results
        
        # Region-based SNP analysis and primer design
        kasp_designer.py region --vcf variants.vcf.gz --chrom chr1 --start 123456 --end 173456 --output_prefix region_design
        
        # Target SNP primer design with flanking analysis
        kasp_designer.py target --vcf variants.vcf.gz --ref genome.fa --chrom chr1 --position 123456 --mother PR25 --father RIBENQING --output_prefix target_design
        
        # Custom sequence-based primer design
        kasp_designer.py custom --snp_sequences snp_list.txt --ref genome.fa --output_prefix custom_design
        """
    )
    
    # Create subparsers for different functions
    subparsers = parser.add_subparsers(dest='function', help='Function to execute', required=True)
    
    # Genome-wide density sampling function
    genome_parser = subparsers.add_parser('genome', help='Genome-wide density-based sampling for primer design')
    build_genome_arguments(genome_parser)
    
    # Region-based SNP analysis function
    region_parser = subparsers.add_parser('region', help='Region-based SNP analysis and primer design')
    build_region_arguments(region_parser)
    
    # Target SNP design function
    target_parser = subparsers.add_parser('target', help='Design primers for target SNP with flanking analysis')
    build_target_arguments(target_parser)
    
    # Custom sequence-based design function
    custom_parser = subparsers.add_parser('custom', help='Design primers from custom SNP sequences')
    build_custom_arguments(custom_parser)
    
    # Parse arguments
    args = parser.parse_args()
    
    # Validate arguments based on function
    if args.function == 'custom':
        # For custom function, validate SNP sequences file
        if not os.path.exists(args.snp_sequences):
            print(f"ERROR: SNP sequences file not found: {args.snp_sequences}", file=sys.stderr)
            sys.exit(1)
    else:
        # For other functions, validate VCF file
        if not os.path.exists(args.vcf):
            print(f"ERROR: VCF file not found: {args.vcf}", file=sys.stderr)
            sys.exit(1)
    
    # Set default bowtie index if not provided
    if not args.bowtie_index:
        print(f"No bowtie index specified, using: {args.bowtie_index}", file=sys.stderr)
    

    
    # Execute the selected function
    start_time = time.time()
    
    try:
        if args.function == 'genome':
            if not os.path.exists(args.ref):
                print(f"ERROR: Reference FASTA not found: {args.ref}", file=sys.stderr)
                sys.exit(1)
            result = function_genome_sampling(args)
            
        elif args.function == 'region':
            result = function_region_analysis(args)
            
        elif args.function == 'target':
            if not os.path.exists(args.ref):
                print(f"ERROR: Reference FASTA not found: {args.ref}", file=sys.stderr)
                sys.exit(1)
            result = function_target_snp_design(args)
            
        elif args.function == 'custom':
            if not os.path.exists(args.ref):
                print(f"ERROR: Reference FASTA not found: {args.ref}", file=sys.stderr)
                sys.exit(1)
            result = function_custom_sequence_design(args)
            
        else:
            print(f"ERROR: Unknown function: {args.function}", file=sys.stderr)
            sys.exit(1)
            
    except Exception as e:
        print(f"ERROR: Function {args.function} failed: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    
    # Calculate and display running time
    end_time = time.time()
    running_time = end_time - start_time
    
    if running_time < 60:
        print(f"\nProgram running time: {running_time:.2f} seconds")
    elif running_time < 3600:
        minutes = running_time // 60
        seconds = running_time % 60
        print(f"\nProgram running time: {int(minutes)} minutes {seconds:.2f} seconds")
    else:
        hours = running_time // 3600
        minutes = (running_time % 3600) // 60
        seconds = running_time % 60
        print(f"\nProgram running time: {int(hours)} hours {int(minutes)} minutes {seconds:.2f} seconds")
    
    return result

if __name__ == "__main__":
    main()