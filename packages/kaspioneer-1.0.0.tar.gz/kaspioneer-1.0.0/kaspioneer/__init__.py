"""
KASPioneer - A comprehensive KASP primer design tool.
"""

__version__ = "1.0.0"
__author__ = "Baoyi Zhang"
__email__ = "zhangbaoyi@ynu.edu.cn"
__description__ = "A comprehensive KASP primer design tool for SNP analysis and primer design"

# Import main functions for easy access
try:
    from .kasp_functions import (
        function_genome_sampling,
        function_region_analysis, 
        function_target_snp_design,
        function_custom_sequence_design
    )
    
    __all__ = [
        "function_genome_sampling",
        "function_region_analysis",
        "function_target_snp_design", 
        "function_custom_sequence_design"
    ]
except ImportError:
    # Handle import errors gracefully
    __all__ = []
