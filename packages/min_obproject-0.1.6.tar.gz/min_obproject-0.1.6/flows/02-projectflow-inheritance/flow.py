from metaflow import step, pypi, kubernetes
from obproject import ProjectFlow
from src.flow_templates import NeuralNetworkFlow
from src.step_decorators import smart_pypi


class CustomizedTrainingFlow(ProjectFlow, NeuralNetworkFlow):

    @smart_pypi
    @step
    def start(self):
        self._resolve_nn_config() # via NeuralNetworkFlow.
        self.next(self.end)

    @smart_pypi(packages={"pandas": "2.2.3"})
    @step
    def end(self):
        import pandas as pd

        print("Pandas version:", pd.__version__)
        print("Resolved config:", self.config)


if __name__ == "__main__":
    CustomizedTrainingFlow()
