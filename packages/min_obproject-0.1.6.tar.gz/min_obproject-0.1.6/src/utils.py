import tomllib
from pathlib import Path
from functools import lru_cache
import urllib.request
import json


def _load_pyproject():
    """
    Load and return the pyproject.toml data.
    
    Returns:
        dict: The parsed pyproject.toml data
    """
    current_dir = Path(__file__).parent
    project_root = current_dir.parent
    pyproject_path = project_root / "pyproject.toml"
    
    if not pyproject_path.exists():
        raise FileNotFoundError(f"Could not find pyproject.toml at {pyproject_path}")
    
    with open(pyproject_path, "rb") as f:
        return tomllib.load(f)


def get_local_pkg_version():
    """
    Get the current version from pyproject.toml.
    
    Returns:
        str: The version string (e.g., "0.1.5")
    """
    pyproject_data = _load_pyproject()
    version = pyproject_data.get("project", {}).get("version")
    
    if not version:
        raise ValueError("Version not found in pyproject.toml")
    
    return version


def get_pkg_name():
    """
    Get the package name from pyproject.toml.
    
    Returns:
        str: The package name (e.g., "min-obproject")
    """
    pyproject_data = _load_pyproject()
    name = pyproject_data.get("project", {}).get("name")
    
    if not name:
        raise ValueError("Package name not found in pyproject.toml")
    
    return name


@lru_cache(maxsize=1)
def get_pkg_version(package_name=None, fallback_to_local=True):
    """
    Get the latest published version of a package from PyPI.
    
    Args:
        package_name: The name of the package on PyPI (default: None, uses name from pyproject.toml)
        fallback_to_local: If True, fall back to local pyproject.toml on error (default: True)
    
    Returns:
        str: The latest version string (e.g., "0.1.5")
    """
    if package_name is None:
        package_name = get_pkg_name()
    
    try:
        url = f"https://pypi.org/pypi/{package_name}/json"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read().decode())
            version = data["info"]["version"]
            return version
    except Exception as e:
        if fallback_to_local:
            # Fall back to local version if PyPI lookup fails
            return get_local_pkg_version()
        else:
            raise RuntimeError(f"Failed to fetch version from PyPI: {e}") from e

