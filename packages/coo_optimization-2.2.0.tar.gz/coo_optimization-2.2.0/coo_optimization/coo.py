"""
Complete Full-Featured COO Package
===================================

Ready for use in both scripts and as a package.
"""

import numpy as np
import math
from typing import Callable, List, Tuple, Optional, Dict
from joblib import Parallel, delayed
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor


# ======================
# Surrogate Ensemble
# ======================
class SurrogateEnsemble:
    """Ensemble surrogate model combining Random Forest and Gradient Boosting."""

    def __init__(self, kind: str = 'ensemble', random_state: int = 42, n_jobs: int = -1):
        self.kind = kind
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.models = []

    def fit(self, X: np.ndarray, y: np.ndarray) -> 'SurrogateEnsemble':
        jobs = []
        if self.kind in ('rf', 'ensemble'):
            jobs.append(('rf', RandomForestRegressor(
                n_estimators=80,
                n_jobs=1,
                random_state=self.random_state,
                max_depth=15
            )))
        if self.kind in ('gb', 'ensemble'):
            jobs.append(('gb', GradientBoostingRegressor(
                n_estimators=150,
                learning_rate=0.1,
                max_depth=5,
                random_state=self.random_state
            )))

        def _fit_one(item):
            name, model = item
            model.fit(X, y)
            return (name, model)

        n_parallel = min(len(jobs), abs(self.n_jobs)
                         if self.n_jobs != -1 else 2)
        self.models = Parallel(n_jobs=n_parallel)(
            delayed(_fit_one)(item) for item in jobs)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not self.models:
            raise RuntimeError("Surrogate not trained. Call fit() first.")
        predictions = [model.predict(X) for _, model in self.models]
        return np.vstack(predictions).mean(axis=0)


# ======================
# Complete COO Algorithm
# ======================
class CanineOlfactoryOptimization:
    """Complete Canine Olfactory Optimization (COO) Algorithm."""

    def __init__(
        self,
        bounds: List[Tuple[float, float]],
        n_packs: int = 2,
        init_pack_size: int = 10,
        min_pack_size: int = 8,
        max_iterations: int = 100,
        surrogate_enabled: bool = True,
        surrogate_kind: str = 'ensemble',
        surrogate_retrain_freq: int = 5,
        surrogate_min_samples: int = 30,
        elitist_exchange_freq: int = 6,
        grad_refinement_pct: float = 0.10,
        use_gradient: bool = True,
        use_elitist: bool = True,
        use_adaptive_pack: bool = True,
        cache_decimals: int = 8,
        random_state: Optional[int] = None,
        verbose: bool = False
    ):
        self.bounds = np.array(bounds)
        self.dim = len(bounds)
        self.lower = self.bounds[:, 0]
        self.upper = self.bounds[:, 1]
        self.n_packs = n_packs
        self.init_pack_size = init_pack_size
        self.min_pack_size = min_pack_size
        self.max_iterations = max_iterations
        self.surrogate_enabled = surrogate_enabled
        self.surrogate_kind = surrogate_kind
        self.surrogate_retrain_freq = surrogate_retrain_freq
        self.surrogate_min_samples = surrogate_min_samples
        self.elitist_exchange_freq = elitist_exchange_freq
        self.grad_refinement_pct = grad_refinement_pct
        self.use_gradient = use_gradient
        self.use_elitist = use_elitist
        self.use_adaptive_pack = use_adaptive_pack
        self.cache_decimals = cache_decimals
        self.verbose = verbose

        # 🔧 FIX 1: Deterministic RNG (replace global seeding)
        self._rng = np.random.default_rng(random_state)

        self.best_position = None
        self.best_fitness = -np.inf
        self.convergence_history = []
        self.evaluation_cache = {}
        self.surrogate = None

        # Hyperparameters
        self.momentum_weight = 0.6
        self.local_attraction = 0.3
        self.sigma1_init = 0.35
        self.sigma2_init = 0.12
        self.zigzag_prob = 0.18
        self.gradient_step = 0.03
        self.gradient_eps = 1e-4

    def _params_to_key(self, params: np.ndarray) -> Tuple:
        return tuple(np.round(params, self.cache_decimals).tolist())

    def _cached_eval(self, params: np.ndarray, func: Callable) -> float:
        key = self._params_to_key(params)
        if key not in self.evaluation_cache:
            result = func(params)
            value = result[0] if isinstance(result, tuple) else result
            self.evaluation_cache[key] = float(value)
        return self.evaluation_cache[key]

    def _batch_eval(self, population: np.ndarray, func: Callable) -> np.ndarray:
        return np.array([self._cached_eval(ind, func) for ind in population])

    def _clip_population(self, population: np.ndarray) -> np.ndarray:
        return np.clip(population, self.lower, self.upper)

    def _compute_numerical_gradient(self, position: np.ndarray, func: Callable) -> np.ndarray:
        gradient = np.zeros(self.dim)
        for j in range(self.dim):
            pos_plus, pos_minus = position.copy(), position.copy()
            pos_plus[j] += self.gradient_eps
            pos_minus[j] -= self.gradient_eps
            f_plus = self._cached_eval(pos_plus, func)
            f_minus = self._cached_eval(pos_minus, func)
            gradient[j] = (f_plus - f_minus) / (2 * self.gradient_eps)
        return gradient

    def _initialize_packs(self) -> List[Dict]:
        packs = []
        for _ in range(self.n_packs):
            positions = self.lower + self._rng.random(
                (self.init_pack_size, self.dim)
            ) * (self.upper - self.lower)
            velocities = np.zeros_like(positions)
            packs.append({'positions': positions, 'velocities': velocities})
        return packs

    def _train_surrogate(self, X_history, y_history):
        if len(X_history) < self.surrogate_min_samples:
            return None
        try:
            X_train = np.vstack(X_history)
            y_train = np.array(y_history)
            surrogate = SurrogateEnsemble(kind=self.surrogate_kind, random_state=int(
                self._rng.bit_generator.random_raw()))
            surrogate.fit(X_train, y_train)
            return surrogate
        except Exception as e:
            if self.verbose:
                print(f"[Warning] Surrogate training failed: {e}")
            return None

    def _adaptive_pack_sizing(self, packs, no_improve_count):
        if not self.use_adaptive_pack:
            return
        if no_improve_count > 10:
            for pack in packs:
                current_size = pack['positions'].shape[0]
                # 🔧 FIX 2: Enforce minimum size
                new_size = max(self.min_pack_size, current_size - 1)
                pack['positions'] = pack['positions'][:new_size]
                pack['velocities'] = pack['velocities'][:new_size]

    def _elitist_exchange(self, packs, pack_bests, func):
        if not self.use_elitist or len(pack_bests) < 2:
            return
        sorted_bests = sorted(pack_bests, key=lambda x: -x[0])
        top_elites = [pos for _,
                      pos in sorted_bests[:min(3, len(sorted_bests))]]
        for pack in packs:
            fitness_values = self._batch_eval(pack['positions'], func)
            worst_idx = int(np.argmin(fitness_values))
            for elite_pos in top_elites:
                perturbed = elite_pos + \
                    self._rng.normal(0, 0.01, size=self.dim)
                perturbed = np.clip(perturbed, self.lower, self.upper)
                pack['positions'][worst_idx] = perturbed

    def _gradient_refinement(self, packs, func):
        if not self.use_gradient:
            return
        all_positions = np.vstack([pack['positions'] for pack in packs])
        all_fitness = self._batch_eval(all_positions, func)
        n_top = max(1, int(len(all_positions) * self.grad_refinement_pct))
        top_indices = np.argsort(-all_fitness)[:n_top]
        for idx in top_indices:
            position = all_positions[idx].copy()
            current_fitness = all_fitness[idx]
            gradient = self._compute_numerical_gradient(position, func)
            grad_norm = np.linalg.norm(gradient) + 1e-12
            step = np.clip(self.gradient_step *
                           (gradient / grad_norm), -0.07, 0.07)
            new_position = np.clip(position + step, self.lower, self.upper)
            new_fitness = self._cached_eval(new_position, func)
            if new_fitness > current_fitness:
                offset = 0
                for pack in packs:
                    pack_size = pack['positions'].shape[0]
                    if idx < offset + pack_size:
                        local_idx = idx - offset
                        pack['positions'][local_idx] = new_position
                        pack['velocities'][local_idx] *= 0.3
                        break
                    offset += pack_size

    def optimize(self, objective_function: Callable[[np.ndarray], float]):
        packs = self._initialize_packs()
        X_history, y_history = [], []
        no_improve_count = 0
        best_prev = -np.inf

        for iteration in range(self.max_iterations):
            sigma1 = self.sigma1_init * math.exp(-0.05 * iteration)
            sigma2 = self.sigma2_init * math.exp(-0.07 * iteration)
            coop_weight = 0.4 + 0.6 * (iteration / max(1, self.max_iterations))
            self._adaptive_pack_sizing(packs, no_improve_count)

            # 🔧 FIX 3: Handle surrogate failure gracefully
            use_surrogate = False
            if (
                self.surrogate_enabled
                and iteration % self.surrogate_retrain_freq == 0
                and len(X_history) >= self.surrogate_min_samples
            ):
                try:
                    self.surrogate = self._train_surrogate(
                        X_history, y_history)
                    use_surrogate = self.surrogate is not None
                except Exception as e:
                    if self.verbose:
                        print(f"[Warning] Surrogate training failed: {e}")
                    self.surrogate = None
                    use_surrogate = False

            pack_bests = []
            for pack in packs:
                positions, velocities = pack['positions'], pack['velocities']
                n_dogs = positions.shape[0]
                if use_surrogate and self.surrogate is not None:
                    try:
                        predicted_fitness = self.surrogate.predict(positions)
                        n_exact = max(1, n_dogs // 2)
                        top_indices = np.argsort(-predicted_fitness)[:n_exact]
                        exact_fitness = self._batch_eval(
                            positions[top_indices], objective_function)
                        predicted_fitness[top_indices] = exact_fitness
                        fitness = predicted_fitness
                    except Exception as e:
                        if self.verbose:
                            print(
                                f"[Warning] Surrogate prediction failed: {e}")
                        fitness = self._batch_eval(
                            positions, objective_function)
                else:
                    fitness = self._batch_eval(positions, objective_function)

                X_history.extend(positions.tolist())
                y_history.extend(fitness.tolist())
                local_best_idx = int(np.argmax(fitness))
                local_best_pos = positions[local_best_idx].copy()
                local_best_fit = float(fitness[local_best_idx])

                if local_best_fit > self.best_fitness:
                    self.best_fitness = local_best_fit
                    self.best_position = local_best_pos.copy()
                    no_improve_count = 0

                pack_bests.append((local_best_fit, local_best_pos))

                for i in range(n_dogs):
                    dir_local = local_best_pos - positions[i]
                    dir_global = (
                        self.best_position - positions[i]) if self.best_position is not None else np.zeros(self.dim)
                    velocities[i] = (
                        self.momentum_weight * velocities[i]
                        + self.local_attraction * dir_local
                        + coop_weight * dir_global / (n_dogs + 1)
                    )
                    positions[i] += velocities[i] + sigma1 * \
                        self._rng.normal(0, 1, size=self.dim)
                    if self._rng.random() < self.zigzag_prob:
                        zigzag_noise = sigma2 * self._rng.normal(0, 1, size=self.dim) * np.sin(
                            2 * math.pi * iteration / max(1, self.max_iterations))
                        positions[i] += zigzag_noise
                    positions[i] = np.clip(
                        positions[i], self.lower, self.upper)
                pack['positions'], pack['velocities'] = positions, velocities

            if iteration % self.elitist_exchange_freq == 0:
                self._elitist_exchange(packs, pack_bests, objective_function)
            self._gradient_refinement(packs, objective_function)

            no_improve_count = no_improve_count + \
                1 if self.best_fitness <= best_prev + 1e-9 else 0
            best_prev = self.best_fitness
            self.convergence_history.append(self.best_fitness)

        diagnostics = {
            "cache_size": len(self.evaluation_cache),
            "iterations": self.max_iterations,
            "final_pack_sizes": [pack["positions"].shape[0] for pack in packs],
            "no_improvement_streak": no_improve_count,
        }
        return self.best_position, self.best_fitness, self.convergence_history, diagnostics


COO = CanineOlfactoryOptimization
