"""
Unit tests for the Complete Canine Olfactory Optimization (COO) algorithm.

Covers:
- Basic optimization on simple functions
- Surrogate-assisted mode
- Gradient refinement
- Adaptive pack sizing and elitist exchange
- Evaluation caching
- Deterministic behavior with random_state
"""

import numpy as np
import pytest
from coo_optim import CanineOlfactoryOptimization, SurrogateEnsemble, COO

# --------------------------
# Fixtures and test helpers
# --------------------------


@pytest.fixture
def sphere_function():
    """Simple convex function with known optimum at x = 0."""
    def func(x):
        return -np.sum(x ** 2)
    return func


@pytest.fixture
def rastrigin_function():
    """Multimodal Rastrigin function (negated for maximization)."""
    def func(x):
        A = 10
        n = len(x)
        result = A * n + np.sum(x ** 2 - A * np.cos(2 * np.pi * x))
        return -result
    return func


@pytest.fixture
def simple_bounds():
    return [(-5, 5), (-5, 5)]


# --------------------------
# Surrogate Model Tests
# --------------------------

def test_surrogate_ensemble_fit_predict(simple_bounds, sphere_function):
    """Ensure surrogate model can fit and predict correctly."""
    X = np.random.uniform(-5, 5, (30, 2))
    y = np.array([sphere_function(x) for x in X])

    surrogate = SurrogateEnsemble(kind='ensemble', random_state=0)
    surrogate.fit(X, y)

    preds = surrogate.predict(X[:5])
    assert preds.shape == (5,)
    assert np.isfinite(preds).all()


# --------------------------
# Core Optimization Tests
# --------------------------

def test_basic_optimization_converges(sphere_function, simple_bounds):
    """COO should converge near the known optimum for a simple function."""
    optimizer = COO(bounds=simple_bounds, max_iterations=30, random_state=123)
    best_pos, best_fit, _, _ = optimizer.optimize(sphere_function)

    # Should be close to the true maximum (0, 0)
    assert np.linalg.norm(best_pos) < 0.5
    assert best_fit <= 0
    assert best_fit > -1.0  # should be near zero


def test_with_surrogate_enabled(rastrigin_function, simple_bounds):
    """Check that surrogate training and prediction occur without failure."""
    optimizer = COO(
        bounds=simple_bounds,
        max_iterations=20,
        surrogate_enabled=True,
        surrogate_kind='ensemble',
        random_state=42,
    )
    best_pos, best_fit, _, diagnostics = optimizer.optimize(rastrigin_function)

    assert np.isfinite(best_fit)
    assert isinstance(diagnostics, dict)
    assert diagnostics["cache_size"] > 0


def test_with_gradient_refinement(sphere_function, simple_bounds):
    """Verify that gradient refinement improves or maintains best fitness."""
    optimizer = COO(
        bounds=simple_bounds,
        max_iterations=25,
        use_gradient=True,
        random_state=1,
    )
    best_pos, best_fit, history, _ = optimizer.optimize(sphere_function)

    assert isinstance(best_pos, np.ndarray)
    assert isinstance(best_fit, float)
    assert len(history) == 25
    assert best_fit >= history[0]  # should not get worse over time


def test_evaluation_cache_reuse(sphere_function, simple_bounds):
    """Check that repeated evaluations use the cache effectively."""
    optimizer = COO(bounds=simple_bounds, max_iterations=10, random_state=0)
    optimizer._cached_eval(np.array([0.0, 0.0]), sphere_function)
    optimizer._cached_eval(np.array([0.0, 0.0]), sphere_function)

    assert len(optimizer.evaluation_cache) == 1


def test_deterministic_with_seed(sphere_function, simple_bounds):
    """Runs with same random_state should produce identical results."""
    opt1 = COO(bounds=simple_bounds, max_iterations=20, random_state=7)
    opt2 = COO(bounds=simple_bounds, max_iterations=20, random_state=7)

    res1 = opt1.optimize(sphere_function)
    res2 = opt2.optimize(sphere_function)

    # Results should match exactly if seeded
    np.testing.assert_allclose(res1[0], res2[0], atol=1e-8)
    assert np.isclose(res1[1], res2[1], atol=1e-8)


def test_adaptive_pack_sizing_and_elitist_exchange(sphere_function, simple_bounds):
    """Verify adaptive pack sizing and elitist exchange logic."""
    optimizer = COO(
        bounds=simple_bounds,
        n_packs=2,
        init_pack_size=6,
        use_elitist=True,
        use_adaptive_pack=True,
        max_iterations=15,
        random_state=2,
    )
    best_pos, best_fit, _, diagnostics = optimizer.optimize(sphere_function)

    assert diagnostics["final_pack_sizes"][0] >= optimizer.min_pack_size
    assert diagnostics["iterations"] == optimizer.max_iterations
    assert diagnostics["cache_size"] > 0


def test_handles_invalid_surrogate_gracefully(sphere_function, simple_bounds, monkeypatch):
    """Ensure optimizer continues even if surrogate fitting fails."""
    optimizer = COO(bounds=simple_bounds,
                    surrogate_enabled=True, random_state=1)

    def mock_train_surrogate(*args, **kwargs):
        raise ValueError("mock failure")

    monkeypatch.setattr(optimizer, "_train_surrogate", mock_train_surrogate)
    best_pos, best_fit, _, diagnostics = optimizer.optimize(sphere_function)

    assert np.isfinite(best_fit)
    assert diagnostics["iterations"] == optimizer.max_iterations
