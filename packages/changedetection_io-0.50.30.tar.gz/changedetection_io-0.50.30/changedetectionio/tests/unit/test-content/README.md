# What is this?
This is test content for the python diff engine, we use the JS interface for the front end, because you can explore 
differences in words etc, but we use (at the moment) the python difflib engine.

This content `before.txt` and `after.txt` is for unit testing
