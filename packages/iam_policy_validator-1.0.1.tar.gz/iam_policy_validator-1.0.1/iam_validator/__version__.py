"""Version information for IAM Validator.

This file is the single source of truth for the package version.
"""

__version__ = "1.0.0"
__version_info__ = tuple(int(part) for part in __version__.split("."))
