import logging

from delta.tables import *
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

from .common import *
from .session import M

_logger = logging.getLogger(__name__)
S, Q, C = M.get_session()
_FMT = "delta"


def NDS_import_data(data):
    return data if hasattr(data, "schema") else S.createDataFrame(data)


def NDS_exist_log(file):
    fs = S._jvm.org.apache.hadoop.fs.FileSystem.get(
        S._jsc.hadoopConfiguration())
    return fs.exists(S._jvm.org.apache.hadoop.fs.Path(f"{file}/{NDS_LOG_NAME}"))


def NDS_describe_table(table: str, fmt=_FMT) -> list[dict]:
    df = S.table(table) if NDS_is_table_or_db(
        table) else S.read.format(fmt).load(table)
    return [{"col_name": f.name,
             "data_type": str(f.dataType),
             "comment": f.metadata.get("comment", "")}
            for f in df.schema.fields
            ]


def NDS_list_tables(db: str) -> list[str]:
    if NDS_is_table_or_db(db):
        return [f"{db}.{t.name}" for t in S.catalog.listTables(db)]

    tables = []
    path = S._jvm.org.apache.hadoop.fs.Path(db)
    fs = path.getFileSystem(S._jsc.hadoopConfiguration())

    for s in fs.listStatus(path):
        if s.isDirectory():
            table_path = str(s.getPath().toString())
            log_path = S._jvm.org.apache.hadoop.fs.Path(
                f"{table_path}/{NDS_LOG_NAME}")
            try:
                if fs.exists(log_path):
                    tables.append(table_path)
            except Exception:
                continue
    return tables


def NDS_query_table(table: str, fields: str, body: dict):
    filters: str = body.get("filters", "")
    page: int = int(body.get("page", 1))
    page_size: int = int(body.get("page_size", 20))

    q = "SELECT {} FROM {}".format(fields, table)
    if filters:
        q += f" WHERE {filters}"

    NDS_check_table(q)
    data = Q(q)

    start = (page - 1) * page_size
    end = start + page_size
    total = data.count()
    rows = data.collect()
    return {"total": total, "rows": [row.asDict() for row in rows[start:end]]}


def NDS_execute(data=None, keys=None, branch: str = "main", file: str = "", db: str = "", fmt: str = _FMT):
    if not data:
        return

    if not file:
        file = C["FILE"].format(branch)

    table = NDS_get_table(file)
    table = f"{db}.{table}"
    data = NDS_import_data(data)
    _logger.debug(data.head())

    try:
        if not S.catalog.databaseExists(db):
            S.catalog.createDatabase(db)
        S.catalog.setCurrentDatabase(db)

        _logger.info(f"save to {file}")
        if not keys or not NDS_exist_log(file):
            Q(f"DROP TABLE IF EXISTS {table}")
            (data.write.mode("overwrite")
             .option("overwriteSchema", "true")
             .option("path", file)
             .format(fmt)
             .saveAsTable(table))
            return table

        _logger.info(f"keys: {keys}")
        condition = " AND ".join([f"d.{k} = s.{k}" for k in keys])
        delta_table = DeltaTable.forPath(S, file)
        (delta_table.alias("d")
         .merge(data.alias("s"), condition)
         .whenMatchedUpdateAll()
         .whenNotMatchedInsertAll()
         .execute())
        S.catalog.refreshTable(table)
        return table
    except Exception as e:
        _logger.exception("error")
