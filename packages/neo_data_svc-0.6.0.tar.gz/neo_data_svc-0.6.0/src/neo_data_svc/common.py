import logging
from functools import wraps

from .cache import NDS_CACHE, NDS_CACHE_INIT
from .job import NDS_Job

_sep = "/"
_path = "://"
_sql_sep = ";"
NDS_LOG_NAME = "_delta_log"


def NDS_get_table(file):
    return file.rstrip(_sep).split(_sep)[-1].lower()


def NDS_is_table_or_db(s: str):
    return _path not in s


def NDS_check_table(statement):
    if _sql_sep in statement:
        raise ValueError("Illegal statement: {}".format(statement))


def NDS_log(f):
    @wraps(f)
    async def wrapper(*args, **kwargs):
        logger = logging.getLogger(f.__module__)
        logger.info(f"{f.__name__} => {args}, {kwargs}")

        try:
            result = await f(*args, **kwargs)
            return result
        except Exception as e:
            logger.exception(f"{f.__name__} => {e}")
            raise

    return wrapper
