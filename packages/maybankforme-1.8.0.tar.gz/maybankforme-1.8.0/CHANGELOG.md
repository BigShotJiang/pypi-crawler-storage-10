# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Full type hints for all modules
- Ruff as primary linter with comprehensive rules
- MyPy strict type checking configuration
- Comprehensive testing infrastructure
- Google-style docstrings for all public functions
- .env.example for environment variables documentation
- CHANGELOG.md following Keep a Changelog format

### Changed
- Updated minimum Python version to 3.11+
- Improved error handling with specific exception types
- Enhanced Dockerfile with non-root user and healthcheck
- Centralized all tool configuration in pyproject.toml
- Updated dependencies with proper type stubs

### Fixed
- Improved error handling in PDF processing
- Better logging practices (no print statements)

## [2.0.0] - Previous Release

### Added
- FastAPI web service for processing PDF statements
- Health check endpoint
- Support for multiple PDF files
- Password-protected PDF support
- CSV output with proper date handling

### Changed
- Migrated from CLI-only to FastAPI service

## [1.0.0] - Initial Release

### Added
- CLI tool for converting Maybank credit card statement PDFs to CSV
- Support for encrypted PDFs
- Date processing across year boundaries
