"""数据模型"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class CallStatus(str, Enum):
    """调用状态"""

    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class StreamEventType(str, Enum):
    """流式事件类型"""

    START = "start"
    CONTENT = "content"
    PROGRESS = "progress"
    DONE = "done"
    ERROR = "error"


@dataclass
class PrefabCall:
    """预制件调用请求"""

    prefab_id: str
    version: str
    function_name: str
    parameters: Dict[str, Any]
    files: Optional[Dict[str, List[str]]] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        inputs: Dict[str, Any] = {"parameters": self.parameters}
        if self.files:
            inputs["files"] = self.files

        return {
            "prefab_id": self.prefab_id,
            "version": self.version,
            "function_name": self.function_name,
            "inputs": inputs,
        }


@dataclass
class PrefabResult:
    """预制件执行结果"""

    status: CallStatus
    output: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    job_id: Optional[str] = None

    def is_success(self) -> bool:
        """判断是否成功"""
        return self.status == CallStatus.SUCCESS

    def get(self, key: str, default: Any = None) -> Any:
        """便捷获取输出字段"""
        if self.output:
            return self.output.get(key, default)
        return default

    def get_result(self) -> Any:
        """获取业务结果"""
        if self.output:
            return self.output.get("result", self.output)
        return None

    def get_files(self) -> Dict[str, List[str]]:
        """获取输出文件"""
        if self.output:
            return self.output.get("files", {})
        return {}


@dataclass
class BatchResult:
    """批量执行结果"""

    job_id: str
    status: str
    results: List[PrefabResult]

    def all_success(self) -> bool:
        """判断是否全部成功"""
        return all(r.is_success() for r in self.results)

    def get_failed(self) -> List[PrefabResult]:
        """获取失败的结果"""
        return [r for r in self.results if not r.is_success()]


@dataclass
class StreamEvent:
    """流式事件"""

    type: StreamEventType
    data: Any

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StreamEvent":
        """从字典创建"""
        event_type = data.get("type", "content")
        try:
            event_type_enum = StreamEventType(event_type)
        except ValueError:
            event_type_enum = StreamEventType.CONTENT

        return cls(type=event_type_enum, data=data.get("data"))


@dataclass
class PrefabInfo:
    """预制件信息"""

    prefab_id: str
    version: str
    name: str
    description: str
    status: str
    is_official: bool = False
    requires_secrets: bool = False

