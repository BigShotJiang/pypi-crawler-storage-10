"""预制件封装"""

from typing import Any, Dict, Iterator, Optional, TYPE_CHECKING
from .models import PrefabResult, StreamEvent

if TYPE_CHECKING:
    from .client import GatewayClient


class Prefab:
    """预制件对象，支持链式调用"""

    def __init__(self, client: "GatewayClient", prefab_id: str, version: str):
        """
        初始化预制件对象

        Args:
            client: Gateway 客户端
            prefab_id: 预制件 ID
            version: 版本号
        """
        self.client = client
        self.prefab_id = prefab_id
        self.version = version
        self._spec: Optional[Dict[str, Any]] = None

    def call(self, function_name: str, **kwargs: Any) -> PrefabResult:
        """
        调用预制件函数

        Args:
            function_name: 函数名
            **kwargs: 函数参数

        Returns:
            PrefabResult

        Example:
            >>> prefab = client.prefab("llm-client", "1.0.0")
            >>> result = prefab.call("chat", messages=[...], model="gpt-4")
        """
        # 分离 files 参数
        files = kwargs.pop("files", None)
        parameters = kwargs

        return self.client.run(
            prefab_id=self.prefab_id,
            version=self.version,
            function_name=function_name,
            parameters=parameters,
            files=files,
            stream=False,
        )

    def stream(self, function_name: str, **kwargs: Any) -> Iterator[StreamEvent]:
        """
        流式调用预制件函数

        Args:
            function_name: 函数名
            **kwargs: 函数参数

        Yields:
            StreamEvent

        Example:
            >>> prefab = client.prefab("llm-client", "1.0.0")
            >>> for event in prefab.stream("chat_stream", messages=[...]):
            ...     if event.type == "content":
            ...         print(event.data, end="")
        """
        # 分离 files 参数
        files = kwargs.pop("files", None)
        parameters = kwargs

        result = self.client.run(
            prefab_id=self.prefab_id,
            version=self.version,
            function_name=function_name,
            parameters=parameters,
            files=files,
            stream=True,
        )

        # result 是 Iterator[StreamEvent]
        if isinstance(result, Iterator):
            yield from result

    def get_spec(self) -> Dict[str, Any]:
        """
        获取预制件规格

        Returns:
            预制件规格字典
        """
        if self._spec is None:
            self._spec = self.client.get_prefab_spec(self.prefab_id, self.version)
        return self._spec

    def __getattr__(self, name: str) -> Any:
        """
        支持动态方法调用

        Example:
            >>> prefab.chat(messages=[...], model="gpt-4")
            等同于
            >>> prefab.call("chat", messages=[...], model="gpt-4")
        """

        def method(**kwargs: Any) -> PrefabResult:
            return self.call(name, **kwargs)

        return method

