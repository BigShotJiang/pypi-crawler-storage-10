"""Tests for Gateway ADK"""

