from django.apps import AppConfig


class DrfCmsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'drf_cms'
    label = 'drf_cms'
