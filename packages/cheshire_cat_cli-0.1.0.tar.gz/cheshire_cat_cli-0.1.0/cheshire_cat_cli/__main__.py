import sys
from cheshire_cat_cli.cli import cli

if __name__ == "__main__":
    sys.exit(cli())
