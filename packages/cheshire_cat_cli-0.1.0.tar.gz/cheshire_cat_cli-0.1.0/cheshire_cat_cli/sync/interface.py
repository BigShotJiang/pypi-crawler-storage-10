"""Base interface for cloud storage providers."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any


class CloudProvider(ABC):
    """Abstract base class for cloud storage providers."""

    @abstractmethod
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the cloud provider with configuration.

        Args:
            config: Provider-specific configuration dictionary
        """
        pass

    @abstractmethod
    def upload(self, local_path: Path, remote_path: str) -> bool:
        """
        Upload a file or directory to the cloud.

        Args:
            local_path: Local file or directory path
            remote_path: Remote path in the cloud storage

        Returns:
            bool: True if upload successful, False otherwise
        """
        pass

    @abstractmethod
    def download(self, remote_path: str, local_path: Path) -> bool:
        """
        Download a file or directory from the cloud.

        Args:
            remote_path: Remote path in the cloud storage
            local_path: Local file or directory path

        Returns:
            bool: True if download successful, False otherwise
        """
        pass

    @abstractmethod
    def sync(self, local_path: Path, remote_path: str) -> bool:
        """
        Synchronize local directory with remote cloud storage.

        Args:
            local_path: Local directory path
            remote_path: Remote directory path in the cloud storage

        Returns:
            bool: True if sync successful, False otherwise
        """
        pass

    @abstractmethod
    def test_connection(self) -> bool:
        """
        Test the connection to the cloud provider.

        Returns:
            bool: True if connection successful, False otherwise
        """
        pass

    @classmethod
    @abstractmethod
    def get_provider_name(cls) -> str:
        """
        Get the name of the cloud provider.

        Returns:
            str: Provider name (e.g., "webdav", "nextcloud")
        """
        pass

    @classmethod
    @abstractmethod
    def get_required_config_fields(cls) -> Dict[str, str]:
        """
        Get the required configuration fields for this provider.

        Returns:
            Dict[str, str]: Dictionary mapping field names to descriptions
        """
        pass
