"""Docker daemon abstraction and validation utilities."""

import subprocess
import shutil
from typing import Tuple


def is_docker_installed() -> bool:
    """
    Check if Docker is installed on the system.

    Returns:
        bool: True if Docker is installed, False otherwise.
    """
    return shutil.which("docker") is not None


def is_docker_daemon_running() -> bool:
    """
    Check if the Docker daemon is running.

    Returns:
        bool: True if the Docker daemon is running, False otherwise.
    """
    if not is_docker_installed():
        return False

    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def check_docker_availability() -> Tuple[bool, str]:
    """
    Check if Docker is available and ready to use.

    Returns:
        Tuple[bool, str]: A tuple containing:
            - bool: True if Docker is available and running, False otherwise.
            - str: An error message if Docker is not available, empty string otherwise.
    """
    if not is_docker_installed():
        return False, (
            "Docker is not installed on your system. "
            "Please install Docker from https://docs.docker.com/get-docker/"
        )

    if not is_docker_daemon_running():
        return False, (
            "Docker daemon is not running. "
            "Please start Docker and try again."
        )

    return True, ""
