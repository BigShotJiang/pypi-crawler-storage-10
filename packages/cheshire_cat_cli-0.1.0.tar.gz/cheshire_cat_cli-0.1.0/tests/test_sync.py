"""Tests for the sync module."""

import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from cheshire_cat_cli.sync.manager import SyncManager
from cheshire_cat_cli.sync.interface import CloudProvider


class TestSyncManager:
    """Tests for SyncManager class."""

    @pytest.fixture
    def temp_config_dir(self, tmp_path):
        """Fixture to create a temporary config directory."""
        return tmp_path / "config"

    @pytest.fixture
    def sync_manager(self, temp_config_dir):
        """Fixture to create a SyncManager instance."""
        return SyncManager(temp_config_dir)

    def test_init_creates_config_dir(self, temp_config_dir):
        """Test that SyncManager initialization works."""
        manager = SyncManager(temp_config_dir)
        assert manager.config_dir == temp_config_dir
        assert isinstance(manager.config, dict)

    def test_load_config_empty(self, sync_manager):
        """Test loading config when file doesn't exist."""
        assert sync_manager.config == {}

    def test_save_and_load_config(self, sync_manager):
        """Test saving and loading configuration."""
        sync_manager.config = {"enabled": True, "provider": "webdav"}
        sync_manager._save_config()

        new_manager = SyncManager(sync_manager.config_dir)
        assert new_manager.config["enabled"] is True
        assert new_manager.config["provider"] == "webdav"

    def test_is_enabled_default_false(self, sync_manager):
        """Test that sync is disabled by default."""
        assert sync_manager.is_enabled() is False

    def test_disable(self, sync_manager):
        """Test disabling sync."""
        sync_manager.config = {"enabled": True}
        sync_manager.disable()
        assert sync_manager.config["enabled"] is False

    def test_configure_invalid_provider(self, sync_manager):
        """Test configuration with invalid provider."""
        result = sync_manager.configure("invalid", {})
        assert result is False

    def test_get_available_providers(self):
        """Test getting available providers."""
        providers = SyncManager.get_available_providers()
        assert "webdav" in providers
        assert len(providers) >= 1

    def test_get_config_info_disabled(self, sync_manager):
        """Test getting config info when disabled."""
        info = sync_manager.get_config_info()
        assert info["enabled"] is False

    def test_get_config_info_enabled(self, sync_manager):
        """Test getting config info when enabled."""
        sync_manager.config = {
            "enabled": True,
            "provider": "webdav",
            "provider_config": {
                "url": "https://example.com",
                "username": "user",
                "password": "secret",
            },
        }

        info = sync_manager.get_config_info()
        assert info["enabled"] is True
        assert info["provider"] == "webdav"
        assert info["config"]["password"] == "***"
        assert info["config"]["username"] == "user"


class TestCloudProvider:
    """Tests for CloudProvider interface."""

    def test_cloud_provider_is_abstract(self):
        """Test that CloudProvider cannot be instantiated directly."""
        with pytest.raises(TypeError):
            CloudProvider({})
