# gdi32-utils

Python package for working with gdi32.dll on Windows systems.

## Installation

```bash
pip install gr-record