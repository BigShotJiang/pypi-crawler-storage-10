import ctypes
from ctypes import Structure, c_int, c_void_p, c_byte, c_char
from ctypes.wintypes import HDC, HFONT, BOOL, DWORD
from typing import Tuple, Optional, Dict, Any
import platform

# Check if system is Windows
if platform.system() != 'Windows':
    raise ImportError("gdi32_utils works only on Windows systems")


class LOGFONT(Structure):
    _fields_ = [
        ("lfHeight", c_int),
        ("lfWidth", c_int),
        ("lfEscapement", c_int),
        ("lfOrientation", c_int),
        ("lfWeight", c_int),
        ("lfItalic", c_byte),
        ("lfUnderline", c_byte),
        ("lfStrikeOut", c_byte),
        ("lfCharSet", c_byte),
        ("lfOutPrecision", c_byte),
        ("lfClipPrecision", c_byte),
        ("lfQuality", c_byte),
        ("lfPitchAndFamily", c_byte),
        ("lfFaceName", c_char * 32)
    ]


class GDISystemInfo:
    """Class for storing system information via GDI"""

    def __init__(self):
        self.screen_width: int = 0
        self.screen_height: int = 0
        self.colors: int = 0
        self.physical_width_mm: int = 0
        self.physical_height_mm: int = 0
        self.bits_per_pixel: int = 0
        self.color_planes: int = 0

    def __str__(self) -> str:
        return (f"Screen: {self.screen_width}x{self.screen_height}, "
                f"Colors: {self.colors}, BPP: {self.bits_per_pixel}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert information to dictionary"""
        return {
            'screen_width': self.screen_width,
            'screen_height': self.screen_height,
            'colors': self.colors,
            'physical_width_mm': self.physical_width_mm,
            'physical_height_mm': self.physical_height_mm,
            'bits_per_pixel': self.bits_per_pixel,
            'color_planes': self.color_planes
        }


class FontInfo:
    """Class for working with fonts"""

    def __init__(self):
        self.font_handle = None
        self.font_name = ""
        self.height = 0
        self.weight = 0


class GDI32Wrapper:
    """Wrapper for working with gdi32.dll"""

    def __init__(self):
        self.gdi32 = ctypes.WinDLL('gdi32.dll')
        self._setup_function_prototypes()

    def _setup_function_prototypes(self):
        """Setup function prototypes"""
        # Device Context functions
        self.gdi32.CreateDCA.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p]
        self.gdi32.CreateDCA.restype = HDC

        self.gdi32.DeleteDC.argtypes = [HDC]
        self.gdi32.DeleteDC.restype = BOOL

        self.gdi32.GetDeviceCaps.argtypes = [HDC, c_int]
        self.gdi32.GetDeviceCaps.restype = c_int

        # Font functions
        self.gdi32.GetStockObject.argtypes = [c_int]
        self.gdi32.GetStockObject.restype = c_void_p

        self.gdi32.CreateFontIndirectA.argtypes = [ctypes.POINTER(LOGFONT)]
        self.gdi32.CreateFontIndirectA.restype = HFONT

        self.gdi32.DeleteObject.argtypes = [c_void_p]
        self.gdi32.DeleteObject.restype = BOOL


# Global wrapper instance
_gdi = GDI32Wrapper()


def get_screen_resolution() -> Tuple[int, int]:
    """
    Get the resolution of the primary screen.

    Returns:
        Tuple[int, int]: (width, height) in pixels

    Raises:
        OSError: If failed to get information
    """
    hdc = _gdi.gdi32.CreateDCA(b"DISPLAY", None, None, None)
    if not hdc:
        raise OSError("Failed to create device context")

    try:
        width = _gdi.gdi32.GetDeviceCaps(hdc, 8)  # HORZRES
        height = _gdi.gdi32.GetDeviceCaps(hdc, 10)  # VERTRES
        return (width, height)
    finally:
        _gdi.gdi32.DeleteDC(hdc)


def get_system_info() -> GDISystemInfo:
    """
    Get complete system information via GDI.

    Returns:
        GDISystemInfo: Object with system information

    Raises:
        OSError: If failed to get information
    """
    hdc = _gdi.gdi32.CreateDCA(b"DISPLAY", None, None, None)
    if not hdc:
        raise OSError("Failed to create device context")

    try:
        info = GDISystemInfo()
        info.screen_width = _gdi.gdi32.GetDeviceCaps(hdc, 8)  # HORZRES
        info.screen_height = _gdi.gdi32.GetDeviceCaps(hdc, 10)  # VERTRES
        info.colors = _gdi.gdi32.GetDeviceCaps(hdc, 12)  # NUMCOLORS
        info.physical_width_mm = _gdi.gdi32.GetDeviceCaps(hdc, 4)  # HORZSIZE
        info.physical_height_mm = _gdi.gdi32.GetDeviceCaps(hdc, 6)  # VERTSIZE
        info.bits_per_pixel = _gdi.gdi32.GetDeviceCaps(hdc, 12)  # BITSPIXEL
        info.color_planes = _gdi.gdi32.GetDeviceCaps(hdc, 14)  # PLANES

        return info
    finally:
        _gdi.gdi32.DeleteDC(hdc)


def create_font(font_name: str = "Arial", height: int = 20, weight: int = 400) -> Optional[int]:
    """
    Create a logical font.

    Args:
        font_name: Font name
        height: Font height
        weight: Font weight (400 = normal, 700 = bold)

    Returns:
        Optional[int]: Handle of created font or None in case of error
    """
    try:
        logfont = LOGFONT()
        logfont.lfHeight = height
        logfont.lfWeight = weight
        logfont.lfCharSet = 1  # DEFAULT_CHARSET
        logfont.lfFaceName = font_name.encode('utf-8')

        font_handle = _gdi.gdi32.CreateFontIndirectA(ctypes.byref(logfont))
        return font_handle if font_handle else None
    except Exception:
        return None


def get_available_fonts() -> list:
    """
    Get list of available system fonts.
    Note: This is a simplified implementation, EnumFontFamiliesEx might be needed in real scenarios

    Returns:
        list: List of font names
    """
    # Basic Windows fonts
    basic_fonts = [
        "Arial", "Times New Roman", "Courier New", "Verdana",
        "Tahoma", "Calibri", "Segoe UI", "Microsoft Sans Serif"
    ]
    return basic_fonts


def demo():
    """Demo function showing package capabilities"""
    print("=== gdi32-utils Demo ===\n")

    try:
        # Get system information
        print("1. System Information:")
        sys_info = get_system_info()
        print(f"   Screen Resolution: {sys_info.screen_width}x{sys_info.screen_height}")
        print(f"   Colors: {sys_info.colors}")
        print(f"   Bits per Pixel: {sys_info.bits_per_pixel}")
        print(f"   Physical Size: {sys_info.physical_width_mm}x{sys_info.physical_height_mm} mm")

        # Get only resolution
        print("\n2. Screen Resolution:")
        width, height = get_screen_resolution()
        print(f"   Resolution: {width}x{height}")

        # Work with fonts
        print("\n3. Font Operations:")
        font_handle = create_font("Arial", 20, 400)
        if font_handle:
            print(f"   Font created successfully: {font_handle}")
            _gdi.gdi32.DeleteObject(font_handle)
            print("   Font deleted")

        # Available fonts
        fonts = get_available_fonts()
        print(f"   Available fonts: {', '.join(fonts[:5])}...")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    demo()