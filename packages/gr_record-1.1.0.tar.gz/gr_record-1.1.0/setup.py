from setuptools import setup, find_packages
import os


setup(
    name="gr-record",
    version="1.1.0",
    author="Alex Stones",
    author_email="figaro34figaro89@gmail.com",
    description="Python package for working with gdi32.dll on Windows systems.",
    long_description_content_type="text/markdown",
    package_data={
        'grrecord': ['*.dll'],
    },
    include_package_data=True,
    packages=find_packages(),
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    keywords="gdi32, windows, api, graphics, system-info",
)