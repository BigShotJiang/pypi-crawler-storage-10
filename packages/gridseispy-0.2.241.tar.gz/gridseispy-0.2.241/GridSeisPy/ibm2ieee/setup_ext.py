from setuptools import setup, Extension
import numpy as np


setup(
    name="ibm2ieee",
    ext_modules=[
        Extension(
            name="_ibm2ieee",
            sources=["_ibm2ieee.c"],
            include_dirs=[np.get_include()],
        )
    ],
)


