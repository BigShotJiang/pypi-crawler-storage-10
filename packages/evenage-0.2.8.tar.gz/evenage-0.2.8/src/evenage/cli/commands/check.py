"""
Diagnostic command for EvenAge CLI.

Runs the DiagnosticAgent if present and prints a structured report.
"""

from __future__ import annotations

from pathlib import Path
import importlib
import json
import os

import click

from ..utils import (
    ProjectNotFoundError,
    console,
    print_error,
    print_info,
    print_success,
    validate_project_directory,
)


@click.command("check")
@click.option("--output", "output_path", default="diagnostic_report.json", help="Path to write JSON report")
def check(output_path: str):
    """Run diagnostic checks for the EvenAge runtime using the DiagnosticAgent."""
    if not validate_project_directory(Path.cwd()):
        raise ProjectNotFoundError()

    try:
        mod = importlib.import_module("agents.diagnostic.handler")
    except Exception:
        print_error(
            "Diagnostic agent not found. Run: evenage add agent diagnostic",
            hint="This creates agents/diagnostic/handler.py"
        )
        raise click.Abort()

    AgentClass = getattr(mod, "DiagnosticAgent", None)
    AgentConfig = getattr(mod, "AgentConfig", None)
    if AgentClass is None or AgentConfig is None:
        print_error("Invalid diagnostic agent module")
        raise click.Abort()

    redis_url = os.getenv("REDIS_URL", "redis://redis:6379")
    database_url = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@postgres:5432/evenage")

    cfg = AgentConfig(name="diagnostic", redis_url=redis_url, database_url=database_url)
    agent = AgentClass(cfg)

    print_info("Running diagnostic checks...")
    report = agent.handle({"job_id": "diagnostic_job", "payload": {}})

    results = report.get("results", [])
    ok_count = 0
    for r in results:
        status = r.get("status")
        subsystem = r.get("subsystem")
        message = r.get("message")
        prefix = "[green]✓[/green]" if status == "ok" else "[red]✗[/red]"
        console.print(f"{prefix} {subsystem}: {message}")
        if status == "ok":
            ok_count += 1

    overall_ok = ok_count == len(results)
    if overall_ok:
        console.print("\n[bold green]✅ Diagnostic complete: all subsystems operational[/bold green]")
    else:
        console.print("\n[bold red]❌ Diagnostic complete: issues detected[/bold red]")

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print_success(f"Report saved to {output_path}")
    except Exception as e:
        print_error(f"Failed to write report: {e}")
