# Weibull Mixture EM - Package Python

Package Python pour l'estimation des parametres d'un melange de deux distributions de Weibull tronquees a gauche par algorithme EM (Expectation-Maximization), avec application a l'analyse de fatigue structurale selon l'Eurocode 3.

## Description

Ce package permet de:
- Estimer les parametres d'un melange de deux lois de Weibull tronquees a partir de donnees binnees (histogramme)
- Generer des donnees synthetiques pour validation
- Calculer l'endommagement selon la regle de Miner (approches discrete et continue)
- Visualiser les resultats avec des graphiques complets
- Utiliser les courbes S-N de l'Eurocode 3 pour l'analyse de fatigue

## Installation

### Prerequis

- Python 3.8 ou superieur
- pip

### Installation depuis PyPI (recommande)

```bash
pip install weibull-mixture-em
```

### Installation depuis GitHub

```bash
pip install git+https://github.com/Pavlishenku/Weibull_Mixture_EM.git
```

### Installation en mode developpement

```bash
git clone https://github.com/Pavlishenku/Weibull_Mixture_EM.git
cd Weibull_Mixture_EM
pip install -e .
```

## Utilisation rapide

### Exemple basique

```python
import numpy as np
from weibull_mixture_em import (
    generate_synthetic_data,
    em_fit,
)

# Generation de donnees synthetiques
binned_data, raw_samples = generate_synthetic_data(
    n=35000,
    beta1=2.0, eta1=50.0, weight1=0.6,
    beta2=2.5, eta2=80.0, weight2=0.4,
    truncation=15.0,
    n_bins=30,
    random_state=42
)

# Estimation par EM
result = em_fit(
    binned_data,
    truncation=15.0,
    max_iterations=200,
    verbose=True,
    compute_ci=True,
    n_bootstrap=100
)

# Affichage des resultats
print(f"beta1 estime: {result.beta1:.4f}")
print(f"eta1 estime: {result.eta1:.4f}")
print(f"Convergence: {result.converged}")
```

### Exemple avec analyse d'endommagement

```python
from weibull_mixture_em import SNCurve, DamageCalculator

# Courbe S-N Eurocode
sn_curve = SNCurve(detail_category=71)

# Melange estime
mixture = result.get_mixture()

# Calcul d'endommagement
damage_calc = DamageCalculator(mixture, sn_curve)

# Approche discrete
D_discrete = damage_calc.damage_discrete(binned_data)
print(f"Endommagement (discret): {D_discrete:.6f}")

# Approche continue
D_continuous = damage_calc.damage_continuous()
print(f"Endommagement (continu): {D_continuous:.6f}")
```

### Exemple avec visualisation

```python
from weibull_mixture_em import (
    plot_log_likelihood,
    plot_density_comparison,
    plot_histogram_and_sn,
)
import matplotlib.pyplot as plt

# Graphique de convergence
plot_log_likelihood(result.log_likelihood_history)
plt.show()

# Comparaison des densites
true_mixture = WeibullMixture(
    beta1=2.0, eta1=50.0, weight1=0.6,
    beta2=2.5, eta2=80.0, weight2=0.4,
    truncation=15.0
)
plot_density_comparison(true_mixture, result.get_mixture())
plt.show()

# Histogramme et courbe S-N
plot_histogram_and_sn(binned_data, sn_curve)
plt.show()
```

## Structure du package

```
weibull_mixture_em/
|-- __init__.py              # Exports principaux
|-- weibull_mixture.py       # Distributions de Weibull tronquees
|-- em_algorithm.py          # Algorithme EM
|-- data_generation.py       # Generation de donnees synthetiques
|-- damage_calculation.py    # Calcul d'endommagement
|-- sn_curves.py             # Courbes S-N Eurocode 3
|-- visualization.py         # Graphiques
|-- utils.py                 # Fonctions utilitaires

tests/
|-- test_weibull.py
|-- test_em.py
|-- test_sn_curves.py
|-- test_damage.py

examples/
|-- example_basic.py                # Exemple simple
|-- example_with_plots.py           # Exemple avec graphiques
|-- example_damage_analysis.py      # Analyse complete d'endommagement
```

## Fonctionnalites principales

### 1. Distributions de Weibull tronquees

Le module `weibull_mixture.py` implemente:
- PDF et CDF de Weibull tronquee a gauche
- Echantillonnage par methode de transformation inverse
- Classe `WeibullMixture` pour un melange de deux composantes

Parametrisation:
- beta: parametre de forme
- eta: parametre d'echelle
- truncation: limite de troncature a gauche (a)

### 2. Algorithme EM

Le module `em_algorithm.py` implemente:
- E-step: calcul des responsabilites pour donnees binnees
- M-step: mise a jour des parametres par optimisation
- Calcul de la log-vraisemblance observee
- Intervalles de confiance par bootstrap

Sortie: objet `EMResult` contenant:
- Parametres estimes (beta1, eta1, weight1, beta2, eta2, weight2)
- Log-vraisemblance finale
- Nombre d'iterations
- Historique de convergence
- Intervalles de confiance (optionnel)

### 3. Courbes S-N Eurocode 3

Le module `sn_curves.py` implemente:
- Courbes S-N selon EN 1993-1-9
- Categories de detail: 160, 140, 125, 112, 100, 90, 80, 71, 63, 56, 50, 45, 40, 36 MPa
- Deux pentes: m=3 (N<=5e6) et m=5 (N>5e6)
- Limite d'endurance (cut-off)

Formule:
```
log(N) = log(C) - m * log(Delta_sigma)
```

### 4. Calcul d'endommagement

Le module `damage_calculation.py` implemente:

Approche discrete (sommation):
```
D = sum(n_i / N_i)
```

Approche continue (integrale):
```
D = integral [f(x) / N(x)] dx
```

avec:
- f(x): densite du melange de Weibull
- N(x): nombre de cycles a rupture selon S-N

### 5. Visualisation

Le module `visualization.py` fournit:
- `plot_log_likelihood`: convergence de l'algorithme EM
- `plot_density_comparison`: comparaison melange vrai vs estime
- `plot_histogram_and_sn`: histogramme des donnees + courbe S-N
- `plot_mixture_components`: decomposition du melange
- `plot_parameter_comparison`: comparaison des parametres

## Exemples d'utilisation

Trois scripts d'exemples complets sont fournis dans le dossier `examples/`:

1. `example_basic.py`: Utilisation de base sans graphiques
2. `example_with_plots.py`: Exemple avec toutes les visualisations
3. `example_damage_analysis.py`: Analyse complete d'endommagement

Execution:

```bash
python examples/example_basic.py
python examples/example_with_plots.py
python examples/example_damage_analysis.py
```

## Tests unitaires

Les tests utilisent pytest:

```bash
# Executer tous les tests
pytest tests/ -v

# Executer un fichier de test specifique
pytest tests/test_weibull.py -v

# Executer avec couverture de code
pytest tests/ --cov=weibull_mixture_em --cov-report=html
```

## Parametres et notation

Le package utilise la notation suivante pour les parametres de Weibull:
- `beta`: parametre de forme (equivalent a k dans certaines notations)
- `eta`: parametre d'echelle (equivalent a lambda dans certaines notations)
- `weight`: poids de la composante dans le melange
- `truncation`: limite de troncature a gauche (a)

Pour un melange de deux Weibull:
- Composante 1: (beta1, eta1, weight1)
- Composante 2: (beta2, eta2, weight2)
- Contrainte: weight1 + weight2 = 1

## Limites et hypotheses

1. Le modele suppose exactement deux composantes de Weibull
2. La troncature a gauche est supposee connue ou estimee a partir du minimum des donnees
3. Les donnees d'entree sont supposees binnees (histogramme)
4. L'algorithme EM peut converger vers un optimum local
5. Le calcul d'intervalles de confiance par bootstrap est couteux

## Conseils d'utilisation

1. Utilisez suffisamment de bins (recommande: 20-50) mais pas trop (eviter le sur-ajustement)
2. Verifiez la convergence en examinant la courbe de log-vraisemblance
3. Comparez toujours les approches discrete et continue pour l'endommagement
4. Utilisez le bootstrap pour les intervalles de confiance (mais attention au temps de calcul)
5. Validez vos resultats sur des donnees synthetiques avant utilisation sur donnees reelles

## References bibliographiques

1. EN 1993-1-9:2005 - Eurocode 3: Design of steel structures - Part 1-9: Fatigue
2. Dempster, A. P., Laird, N. M., & Rubin, D. B. (1977). Maximum likelihood from incomplete data via the EM algorithm. Journal of the Royal Statistical Society, 39(1), 1-38.
3. McLachlan, G., & Peel, D. (2000). Finite Mixture Models. Wiley.
4. Miner, M. A. (1945). Cumulative damage in fatigue. Journal of Applied Mechanics, 12(3), 159-164.

## Auteurs et licence

Package developpe pour l'analyse de fatigue structurale.

Version: 1.0.0

## Contact et support

Pour signaler un bug ou suggerer une amelioration, veuillez ouvrir une issue.

## Fichiers complementaires

Voir aussi:
- `ALGORITHM_EXPLANATION.md`: Explication mathematique detaillee de l'algorithme EM
- `requirements.txt`: Liste des dependances
- `setup.py`: Configuration de l'installation

