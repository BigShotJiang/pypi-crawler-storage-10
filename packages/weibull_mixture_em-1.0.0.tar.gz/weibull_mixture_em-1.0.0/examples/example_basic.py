"""
Exemple basique d'utilisation du package weibull_mixture_em.
"""

import numpy as np
from weibull_mixture_em import (
    generate_synthetic_data,
    em_fit,
    WeibullMixture,
)
from weibull_mixture_em.utils import print_summary, compute_relative_errors


def main():
    """Exemple basique."""
    
    print("=" * 70)
    print("EXEMPLE BASIQUE - ESTIMATION DE MELANGE DE WEIBULL PAR EM")
    print("=" * 70)
    
    # 1. Definition des parametres vrais
    print("\n1. Parametres vrais du melange:")
    print("-" * 70)
    
    true_params = {
        "beta1": 2.0,
        "eta1": 50.0,
        "weight1": 0.6,
        "beta2": 2.5,
        "eta2": 80.0,
        "weight2": 0.4,
        "truncation": 15.0,
    }
    
    for param, value in true_params.items():
        print(f"  {param}: {value}")
    
    # 2. Generation de donnees synthetiques
    print("\n2. Generation de donnees synthetiques:")
    print("-" * 70)
    
    n_cycles = 35000
    n_bins = 30
    
    print(f"  Nombre total de cycles: {n_cycles}")
    print(f"  Nombre d'intervalles: {n_bins}")
    
    np.random.seed(42)
    binned_data, raw_samples = generate_synthetic_data(
        n=n_cycles,
        beta1=true_params["beta1"],
        eta1=true_params["eta1"],
        weight1=true_params["weight1"],
        beta2=true_params["beta2"],
        eta2=true_params["eta2"],
        weight2=true_params["weight2"],
        truncation=true_params["truncation"],
        n_bins=n_bins,
        random_state=42,
    )
    
    print(f"  Donnees generees: {len(binned_data)} intervalles")
    print(f"  Echantillons bruts: {len(raw_samples)} valeurs")
    
    # 3. Estimation par algorithme EM
    print("\n3. Estimation par algorithme EM:")
    print("-" * 70)
    
    result = em_fit(
        binned_data,
        truncation=true_params["truncation"],
        max_iterations=200,
        tolerance=1e-6,
        verbose=True,
        compute_ci=False,  # Pour acceleration
        n_bootstrap=0,
    )
    
    # 4. Affichage des resultats
    print_summary(result, true_params=true_params)
    
    # 5. Calcul des erreurs relatives
    print("\nRecapitulatif des erreurs:")
    print("-" * 70)
    errors = compute_relative_errors(true_params, result.to_dict())
    
    mean_error = np.mean([v for v in errors.values() if not np.isnan(v)])
    print(f"  Erreur relative moyenne: {mean_error:.2f}%")
    
    # 6. Verification du melange estime
    print("\n6. Melange estime:")
    print("-" * 70)
    
    mixture_estimated = result.get_mixture()
    
    # Test PDF
    x_test = np.array([30, 50, 70, 100])
    pdf_values = mixture_estimated.pdf(x_test)
    
    print("  Valeurs de PDF estimee:")
    for x, pdf in zip(x_test, pdf_values):
        print(f"    x={x:.1f} MPa: PDF={pdf:.6f}")
    
    print("\n" + "=" * 70)
    print("EXEMPLE TERMINE")
    print("=" * 70)


if __name__ == "__main__":
    main()

