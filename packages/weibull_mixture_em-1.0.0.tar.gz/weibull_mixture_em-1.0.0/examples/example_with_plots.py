"""
Exemple avec visualisation complete des resultats.
"""

import numpy as np
import matplotlib.pyplot as plt
from weibull_mixture_em import (
    generate_synthetic_data,
    em_fit,
    WeibullMixture,
    plot_log_likelihood,
    plot_density_comparison,
    plot_histogram_and_sn,
    plot_all_results,
    SNCurve,
)
from weibull_mixture_em.utils import print_summary
from weibull_mixture_em.visualization import plot_parameter_comparison


def main():
    """Exemple avec visualisations."""
    
    print("=" * 70)
    print("EXEMPLE AVEC VISUALISATIONS")
    print("=" * 70)
    
    # Parametres vrais
    true_params = {
        "beta1": 2.2,
        "eta1": 45.0,
        "weight1": 0.65,
        "beta2": 2.8,
        "eta2": 75.0,
        "weight2": 0.35,
        "truncation": 12.0,
    }
    
    # Melange vrai
    true_mixture = WeibullMixture(
        beta1=true_params["beta1"],
        eta1=true_params["eta1"],
        weight1=true_params["weight1"],
        beta2=true_params["beta2"],
        eta2=true_params["eta2"],
        weight2=true_params["weight2"],
        truncation=true_params["truncation"],
    )
    
    # Generation de donnees
    print("\nGeneration de donnees...")
    np.random.seed(123)
    binned_data, raw_samples = generate_synthetic_data(
        n=35000,
        beta1=true_params["beta1"],
        eta1=true_params["eta1"],
        weight1=true_params["weight1"],
        beta2=true_params["beta2"],
        eta2=true_params["eta2"],
        weight2=true_params["weight2"],
        truncation=true_params["truncation"],
        n_bins=40,
        random_state=123,
    )
    
    # Estimation EM
    print("Estimation par EM...")
    result = em_fit(
        binned_data,
        truncation=true_params["truncation"],
        max_iterations=300,
        tolerance=1e-6,
        verbose=True,
        compute_ci=True,
        n_bootstrap=50,
    )
    
    # Affichage du resume
    print_summary(result, true_params=true_params)
    
    # Courbe S-N
    sn_curve = SNCurve(detail_category=71)
    
    # Creation des graphiques
    print("\nCreation des graphiques...")
    
    # 1. Log-vraisemblance
    fig1 = plot_log_likelihood(result.log_likelihood_history)
    plt.show(block=False)
    
    # 2. Comparaison des densites
    fig2 = plot_density_comparison(true_mixture, result.get_mixture())
    plt.show(block=False)
    
    # 3. Histogramme + S-N
    fig3 = plot_histogram_and_sn(binned_data, sn_curve)
    plt.show(block=False)
    
    # 4. Comparaison des parametres
    fig4 = plot_parameter_comparison(
        true_params,
        result.to_dict(),
        confidence_intervals=result.confidence_intervals,
    )
    plt.show(block=False)
    
    print("\nGraphiques affiches. Fermez les fenetres pour terminer.")
    plt.show()
    
    print("\n" + "=" * 70)
    print("EXEMPLE TERMINE")
    print("=" * 70)


if __name__ == "__main__":
    main()

