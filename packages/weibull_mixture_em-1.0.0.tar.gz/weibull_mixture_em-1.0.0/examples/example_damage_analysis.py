"""
Exemple complet d'analyse d'endommagement selon la regle de Miner.
"""

import numpy as np
import matplotlib.pyplot as plt
from weibull_mixture_em import (
    generate_synthetic_data,
    em_fit,
    SNCurve,
    DamageCalculator,
)
from weibull_mixture_em.utils import print_summary


def main():
    """Exemple d'analyse d'endommagement."""
    
    print("=" * 70)
    print("EXEMPLE COMPLET - ANALYSE D'ENDOMMAGEMENT")
    print("=" * 70)
    
    # 1. Parametres du melange
    print("\n1. Configuration:")
    print("-" * 70)
    
    true_params = {
        "beta1": 2.0,
        "eta1": 50.0,
        "weight1": 0.7,
        "beta2": 2.5,
        "eta2": 85.0,
        "weight2": 0.3,
        "truncation": 15.0,
    }
    
    n_cycles = 35000
    n_bins = 35
    detail_category = 71
    
    print(f"  Nombre de cycles observes: {n_cycles}")
    print(f"  Categorie de detail Eurocode: {detail_category} MPa")
    print(f"  Nombre d'intervalles: {n_bins}")
    
    # 2. Generation de donnees
    print("\n2. Generation de donnees synthetiques...")
    
    np.random.seed(456)
    binned_data, raw_samples = generate_synthetic_data(
        n=n_cycles,
        beta1=true_params["beta1"],
        eta1=true_params["eta1"],
        weight1=true_params["weight1"],
        beta2=true_params["beta2"],
        eta2=true_params["eta2"],
        weight2=true_params["weight2"],
        truncation=true_params["truncation"],
        n_bins=n_bins,
        random_state=456,
    )
    
    print(f"  Donnees generees: {len(binned_data)} intervalles")
    
    # 3. Estimation EM
    print("\n3. Estimation des parametres par EM...")
    
    result = em_fit(
        binned_data,
        truncation=true_params["truncation"],
        max_iterations=250,
        tolerance=1e-6,
        verbose=True,
        compute_ci=True,
        n_bootstrap=100,
    )
    
    print_summary(result, true_params=true_params)
    
    # 4. Calcul d'endommagement
    print("\n4. Calcul de l'endommagement (regle de Miner):")
    print("-" * 70)
    
    # Courbe S-N
    sn_curve = SNCurve(detail_category=detail_category)
    
    # Melange estime
    mixture_estimated = result.get_mixture()
    
    # Calculateur
    damage_calc = DamageCalculator(mixture_estimated, sn_curve)
    
    # Approche discrete
    print("\n  a) Approche discrete (sommation):")
    damage_discrete = damage_calc.damage_discrete(binned_data)
    print(f"     D_discret = {damage_discrete:.6f}")
    
    # Approche continue
    print("\n  b) Approche continue (integrale):")
    damage_continuous = damage_calc.damage_continuous(
        stress_min=true_params["truncation"],
        stress_max=200.0
    )
    print(f"     D_continu = {damage_continuous:.6f}")
    
    # Comparaison
    print("\n  c) Comparaison:")
    diff_abs = abs(damage_discrete - damage_continuous)
    diff_rel = diff_abs / max(damage_discrete, damage_continuous) * 100
    print(f"     Difference absolue: {diff_abs:.6f}")
    print(f"     Difference relative: {diff_rel:.2f}%")
    
    # 5. Intervalle de confiance sur l'endommagement
    print("\n5. Intervalle de confiance sur l'endommagement:")
    print("-" * 70)
    
    if result.confidence_intervals:
        print("\n  Calcul par Monte Carlo...")
        
        # Discrete
        D_mean_d, D_low_d, D_high_d = damage_calc.damage_with_confidence_interval(
            binned_data,
            method="discrete",
            confidence_intervals=result.confidence_intervals,
            n_samples=500,
        )
        
        print(f"\n  Approche discrete:")
        print(f"    D moyen = {D_mean_d:.6f}")
        print(f"    IC 95%: [{D_low_d:.6f}, {D_high_d:.6f}]")
        
        # Continue
        D_mean_c, D_low_c, D_high_c = damage_calc.damage_with_confidence_interval(
            binned_data,
            method="continuous",
            confidence_intervals=result.confidence_intervals,
            n_samples=500,
        )
        
        print(f"\n  Approche continue:")
        print(f"    D moyen = {D_mean_c:.6f}")
        print(f"    IC 95%: [{D_low_c:.6f}, {D_high_c:.6f}]")
    
    # 6. Interpretation
    print("\n6. Interpretation:")
    print("-" * 70)
    
    if damage_discrete < 1.0:
        print(f"  L'endommagement D = {damage_discrete:.4f} < 1.0")
        print("  => La structure devrait resister aux cycles observes.")
        remaining_life = 1.0 / damage_discrete
        print(f"  => Duree de vie restante: {remaining_life:.2f} fois le spectre observe")
    else:
        print(f"  L'endommagement D = {damage_discrete:.4f} >= 1.0")
        print("  => Rupture prevue selon le critere de Miner.")
    
    # 7. Visualisation
    print("\n7. Creation du graphique d'endommagement...")
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # Graphique 1: Histogramme avec contributions a l'endommagement
    intervals = [interval for interval, _ in binned_data]
    counts = [count for _, count in binned_data]
    bin_centers = [(a + b) / 2 for a, b in intervals]
    bin_widths = [b - a for a, b in intervals]
    
    # Calcul de la contribution de chaque bin
    contributions = []
    for (a, b), n in binned_data:
        delta_sigma = (a + b) / 2
        N = sn_curve.N_at_stress(delta_sigma)
        if N > 0 and not np.isinf(N):
            contrib = n / N
        else:
            contrib = 0
        contributions.append(contrib)
    
    # Normalisation pour visualisation
    colors = plt.cm.YlOrRd(np.array(contributions) / max(contributions))
    
    ax1.bar(bin_centers, counts, width=bin_widths, color=colors, 
            edgecolor="black", alpha=0.8)
    ax1.set_xlabel("Amplitude de contrainte (MPa)", fontsize=12)
    ax1.set_ylabel("Nombre de cycles", fontsize=12)
    ax1.set_title("Histogramme avec contribution a l'endommagement", 
                  fontsize=14, fontweight="bold")
    ax1.grid(True, alpha=0.3, axis="y")
    
    # Colorbar
    sm = plt.cm.ScalarMappable(cmap=plt.cm.YlOrRd, 
                                norm=plt.Normalize(vmin=0, vmax=max(contributions)))
    sm.set_array([])
    plt.colorbar(sm, ax=ax1, label="Contribution a D")
    
    # Graphique 2: Courbe S-N avec donnees
    N_values, delta_sigma_values = sn_curve.get_curve_points()
    ax2.loglog(N_values, delta_sigma_values, "b-", linewidth=2, 
               label=f"S-N Categorie {detail_category}")
    
    # Points des bins
    N_at_bins = sn_curve.N_at_stress(np.array(bin_centers))
    valid_mask = np.isfinite(N_at_bins) & (N_at_bins > 0)
    
    ax2.scatter(N_at_bins[valid_mask], np.array(bin_centers)[valid_mask],
                s=100 + 500 * np.array(counts)[valid_mask] / max(counts),
                alpha=0.6, color="red", edgecolors="black", label="Observations")
    
    ax2.set_xlabel("Nombre de cycles N", fontsize=12)
    ax2.set_ylabel("Amplitude de contrainte (MPa)", fontsize=12)
    ax2.set_title("Courbe S-N et observations", fontsize=14, fontweight="bold")
    ax2.legend()
    ax2.grid(True, alpha=0.3, which="both")
    
    plt.tight_layout()
    plt.show()
    
    print("\n" + "=" * 70)
    print("ANALYSE TERMINEE")
    print("=" * 70)


if __name__ == "__main__":
    main()

