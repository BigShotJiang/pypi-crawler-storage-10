# Changelog

Tous les changements notables de ce projet seront documentes dans ce fichier.

Le format est base sur [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/),
et ce projet respecte [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-10-27

### Ajoute

#### Fonctionnalites principales
- Algorithme EM complet pour estimation de parametres de melange de Weibull tronque
- Support pour donnees binnees (histogramme/rainflow)
- Calcul d'intervalles de confiance par bootstrap
- Generation de donnees synthetiques pour validation

#### Distributions
- Distribution de Weibull tronquee a gauche (PDF, CDF)
- Melange de deux distributions de Weibull
- Echantillonnage par transformation inverse
- Calcul de moments

#### Analyse de fatigue
- Courbes S-N selon Eurocode 3 (EN 1993-1-9)
- 14 categories de detail (160 a 36 MPa)
- Support pour double pente (m=3 et m=5)
- Calcul d'endommagement selon regle de Miner
- Approche discrete (sommation)
- Approche continue (integration)
- Propagation d'incertitude sur l'endommagement

#### Visualisation
- Courbe de convergence de l'algorithme EM
- Comparaison densites vraie vs estimee
- Histogramme des donnees avec courbe S-N
- Decomposition du melange en composantes
- Comparaison des parametres avec intervalles de confiance
- Visualisation des contributions a l'endommagement

#### Tests
- Tests unitaires complets avec pytest
- Tests de convergence de l'algorithme EM
- Tests de validation numerique
- Tests pour toutes les fonctions principales

#### Documentation
- README complet avec exemples d'utilisation
- ALGORITHM_EXPLANATION.md avec derivations mathematiques LaTeX
- Guide de contribution (CONTRIBUTING.md)
- Guide de publication sur GitHub
- Docstrings style NumPy pour toutes les fonctions
- Type hints pour toutes les fonctions

#### Exemples
- example_basic.py: utilisation de base
- example_with_plots.py: exemple avec visualisations
- example_damage_analysis.py: analyse complete d'endommagement

### Dependances
- numpy >= 1.21.0
- scipy >= 1.7.0
- matplotlib >= 3.4.0
- pytest >= 7.0.0

### Notes techniques
- Compatible Python 3.8+
- Stabilite numerique assuree (calculs en log-espace)
- Optimisation numerique robuste (Nelder-Mead)
- Gestion des cas limites et valeurs extremes

### Performance
- Supporte des jeux de donnees de 10,000+ cycles
- Convergence typique en 50-200 iterations
- Bootstrap avec 100 iterations en quelques secondes

[1.0.0]: https://github.com/Pavlishenku/Weibull_Mixture_EM/releases/tag/v1.0.0

