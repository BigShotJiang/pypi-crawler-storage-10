"""
Setup script pour le package weibull_mixture_em.
"""

from setuptools import setup, find_packages
import os


def read_file(filename):
    """Lit le contenu d'un fichier."""
    with open(filename, encoding='utf-8') as f:
        return f.read()


# Lecture du README pour la description longue
long_description = read_file('README.md') if os.path.exists('README.md') else ''

# Lecture des requirements
requirements = []
if os.path.exists('requirements.txt'):
    with open('requirements.txt', encoding='utf-8') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='weibull_mixture_em',
    version='1.0.0',
    author='Weibull EM Package',
    description='Estimation de parametres de melange de Weibull par algorithme EM avec application a la fatigue',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/Pavlishenku/Weibull_Mixture_EM',
    packages=find_packages(exclude=['tests', 'examples']),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Mathematics',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.8',
    install_requires=requirements,
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=3.0.0',
        ],
    },
    include_package_data=True,
    zip_safe=False,
)

