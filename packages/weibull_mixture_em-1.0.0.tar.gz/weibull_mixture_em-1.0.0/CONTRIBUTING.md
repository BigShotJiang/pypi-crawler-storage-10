# Guide de contribution

Merci de votre interet pour contribuer au package Weibull Mixture EM.

## Comment contribuer

### Signaler un bug

Si vous trouvez un bug, veuillez ouvrir une issue avec:
- Une description claire du probleme
- Les etapes pour reproduire le bug
- Le comportement attendu vs le comportement observe
- Votre environnement (version de Python, OS, etc.)

### Proposer une amelioration

Pour proposer une nouvelle fonctionnalite:
1. Ouvrez une issue pour discuter de l'amelioration
2. Attendez les retours avant de commencer le developpement
3. Implementez la fonctionnalite dans une branche separee
4. Soumettez une pull request

### Soumettre une pull request

1. Fork le repository
2. Creez une branche pour votre feature: `git checkout -b feature/ma-fonctionnalite`
3. Faites vos modifications
4. Ajoutez des tests pour votre code
5. Assurez-vous que tous les tests passent: `pytest tests/`
6. Commitez vos changements: `git commit -m "Description de la fonctionnalite"`
7. Pushez vers votre fork: `git push origin feature/ma-fonctionnalite`
8. Ouvrez une pull request

## Standards de code

### Style

- Suivez PEP 8
- Utilisez des docstrings pour toutes les fonctions et classes
- Ajoutez des type hints
- Commentez le code complexe

### Tests

- Tous les nouveaux code doivent avoir des tests
- Les tests doivent passer avant soumission
- Visez une couverture de code > 80%

### Documentation

- Mettez a jour la documentation si necessaire
- Ajoutez des exemples pour les nouvelles fonctionnalites
- Verifiez que le README reste a jour

## Structure des commits

Utilisez des messages de commit clairs et descriptifs:

```
Type: Description courte

Description detaillee si necessaire

- Point 1
- Point 2
```

Types de commits:
- `feat`: Nouvelle fonctionnalite
- `fix`: Correction de bug
- `docs`: Documentation
- `test`: Ajout ou modification de tests
- `refactor`: Refactorisation du code
- `style`: Changements de style (formatage)
- `perf`: Amelioration de performance

## Questions

Pour toute question, n'hesitez pas a ouvrir une issue.

Merci de contribuer au projet.

