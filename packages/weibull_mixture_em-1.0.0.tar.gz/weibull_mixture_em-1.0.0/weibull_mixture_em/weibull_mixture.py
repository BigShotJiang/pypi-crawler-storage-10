"""
Module pour les distributions de Weibull tronquees a gauche.
"""

from typing import Tuple, Optional
import numpy as np
from scipy import stats
from scipy.special import gamma


class WeibullMixture:
    """
    Classe representant un melange de deux distributions de Weibull tronquees a gauche.
    
    Parametres
    ----------
    beta1 : float
        Parametre de forme de la premiere loi de Weibull
    eta1 : float
        Parametre d'echelle de la premiere loi de Weibull
    weight1 : float
        Poids de la premiere composante (entre 0 et 1)
    beta2 : float
        Parametre de forme de la deuxieme loi de Weibull
    eta2 : float
        Parametre d'echelle de la deuxieme loi de Weibull
    weight2 : float
        Poids de la deuxieme composante (entre 0 et 1)
    truncation : float
        Limite de troncature a gauche (a)
    """
    
    def __init__(
        self,
        beta1: float,
        eta1: float,
        weight1: float,
        beta2: float,
        eta2: float,
        weight2: float,
        truncation: float,
    ):
        self.beta1 = beta1
        self.eta1 = eta1
        self.weight1 = weight1
        self.beta2 = beta2
        self.eta2 = eta2
        self.weight2 = weight2
        self.truncation = truncation
        
        # Validation
        if not np.isclose(weight1 + weight2, 1.0):
            raise ValueError("Les poids doivent sommer a 1")
        if weight1 < 0 or weight2 < 0:
            raise ValueError("Les poids doivent etre positifs")
        if beta1 <= 0 or beta2 <= 0:
            raise ValueError("Les parametres beta doivent etre positifs")
        if eta1 <= 0 or eta2 <= 0:
            raise ValueError("Les parametres eta doivent etre positifs")
    
    def pdf(self, x: np.ndarray) -> np.ndarray:
        """
        Densite de probabilite du melange.
        
        Parametres
        ----------
        x : np.ndarray
            Points d'evaluation
            
        Retourne
        --------
        np.ndarray
            Valeurs de densite
        """
        pdf1 = truncated_weibull_pdf(x, self.beta1, self.eta1, self.truncation)
        pdf2 = truncated_weibull_pdf(x, self.beta2, self.eta2, self.truncation)
        return self.weight1 * pdf1 + self.weight2 * pdf2
    
    def cdf(self, x: np.ndarray) -> np.ndarray:
        """
        Fonction de repartition cumulative du melange.
        
        Parametres
        ----------
        x : np.ndarray
            Points d'evaluation
            
        Retourne
        --------
        np.ndarray
            Valeurs de CDF
        """
        cdf1 = truncated_weibull_cdf(x, self.beta1, self.eta1, self.truncation)
        cdf2 = truncated_weibull_cdf(x, self.beta2, self.eta2, self.truncation)
        return self.weight1 * cdf1 + self.weight2 * cdf2
    
    def sample(self, n: int, random_state: Optional[int] = None) -> np.ndarray:
        """
        Genere des echantillons du melange.
        
        Parametres
        ----------
        n : int
            Nombre d'echantillons
        random_state : int, optional
            Graine aleatoire
            
        Retourne
        --------
        np.ndarray
            Echantillons generes
        """
        if random_state is not None:
            np.random.seed(random_state)
        
        # Determine quelle composante pour chaque echantillon
        component = np.random.choice(
            [1, 2], size=n, p=[self.weight1, self.weight2]
        )
        
        samples = np.zeros(n)
        mask1 = component == 1
        mask2 = component == 2
        
        # Genere des echantillons pour chaque composante
        samples[mask1] = sample_truncated_weibull(
            np.sum(mask1), self.beta1, self.eta1, self.truncation
        )
        samples[mask2] = sample_truncated_weibull(
            np.sum(mask2), self.beta2, self.eta2, self.truncation
        )
        
        return samples


def truncated_weibull_pdf(
    x: np.ndarray, beta: float, eta: float, a: float
) -> np.ndarray:
    """
    Densite de probabilite de la loi de Weibull tronquee a gauche.
    
    Pour x >= a:
    f(x|x>=a) = f(x) / (1 - F(a))
    
    ou f(x) = (beta/eta) * (x/eta)^(beta-1) * exp(-(x/eta)^beta)
    
    Parametres
    ----------
    x : np.ndarray
        Points d'evaluation
    beta : float
        Parametre de forme
    eta : float
        Parametre d'echelle
    a : float
        Limite de troncature
        
    Retourne
    --------
    np.ndarray
        Valeurs de densite
    """
    x = np.atleast_1d(x)
    result = np.zeros_like(x, dtype=float)
    
    # Masque pour x >= a
    mask = x >= a
    
    if np.any(mask):
        x_valid = x[mask]
        
        # PDF de Weibull non tronquee
        weibull_pdf = (beta / eta) * (x_valid / eta) ** (beta - 1) * np.exp(
            -((x_valid / eta) ** beta)
        )
        
        # Facteur de normalisation (probabilite de survie a la troncature)
        survival_at_a = np.exp(-((a / eta) ** beta))
        
        result[mask] = weibull_pdf / survival_at_a
    
    return result


def truncated_weibull_cdf(
    x: np.ndarray, beta: float, eta: float, a: float
) -> np.ndarray:
    """
    Fonction de repartition cumulative de la loi de Weibull tronquee a gauche.
    
    Pour x >= a:
    F(x|x>=a) = (F(x) - F(a)) / (1 - F(a))
    
    Parametres
    ----------
    x : np.ndarray
        Points d'evaluation
    beta : float
        Parametre de forme
    eta : float
        Parametre d'echelle
    a : float
        Limite de troncature
        
    Retourne
    --------
    np.ndarray
        Valeurs de CDF
    """
    x = np.atleast_1d(x)
    result = np.zeros_like(x, dtype=float)
    
    # Masque pour x >= a
    mask = x >= a
    
    if np.any(mask):
        x_valid = x[mask]
        
        # CDF de Weibull non tronquee
        cdf_x = 1 - np.exp(-((x_valid / eta) ** beta))
        cdf_a = 1 - np.exp(-((a / eta) ** beta))
        
        result[mask] = (cdf_x - cdf_a) / (1 - cdf_a)
    
    # Pour x < a, CDF = 0
    result[x >= a + 1e10] = 1.0  # Pour les valeurs tres grandes
    
    return result


def sample_truncated_weibull(
    n: int, beta: float, eta: float, a: float
) -> np.ndarray:
    """
    Genere des echantillons d'une loi de Weibull tronquee a gauche.
    
    Utilise la methode de transformation inverse:
    Si U ~ Uniform(0,1), alors X = F^(-1)(U) suit la loi tronquee.
    
    Parametres
    ----------
    n : int
        Nombre d'echantillons
    beta : float
        Parametre de forme
    eta : float
        Parametre d'echelle
    a : float
        Limite de troncature
        
    Retourne
    --------
    np.ndarray
        Echantillons generes
    """
    # Genere des uniformes
    u = np.random.uniform(0, 1, n)
    
    # CDF de Weibull a la limite de troncature
    F_a = 1 - np.exp(-((a / eta) ** beta))
    
    # Transformation inverse
    # F(x|x>=a) = (F(x) - F(a)) / (1 - F(a)) = u
    # => F(x) = u * (1 - F(a)) + F(a)
    # => 1 - exp(-(x/eta)^beta) = u * (1 - F(a)) + F(a)
    # => exp(-(x/eta)^beta) = 1 - u * (1 - F(a)) - F(a)
    # => -(x/eta)^beta = log(1 - u * (1 - F(a)) - F(a))
    # => x = eta * (-log(1 - u * (1 - F(a)) - F(a)))^(1/beta)
    
    F_x = u * (1 - F_a) + F_a
    x = eta * (-np.log(1 - F_x)) ** (1 / beta)
    
    return x


def weibull_mean(beta: float, eta: float) -> float:
    """
    Calcule la moyenne d'une loi de Weibull non tronquee.
    
    E[X] = eta * Gamma(1 + 1/beta)
    
    Parametres
    ----------
    beta : float
        Parametre de forme
    eta : float
        Parametre d'echelle
        
    Retourne
    --------
    float
        Moyenne
    """
    return eta * gamma(1 + 1 / beta)


def weibull_variance(beta: float, eta: float) -> float:
    """
    Calcule la variance d'une loi de Weibull non tronquee.
    
    Var[X] = eta^2 * (Gamma(1 + 2/beta) - Gamma(1 + 1/beta)^2)
    
    Parametres
    ----------
    beta : float
        Parametre de forme
    eta : float
        Parametre d'echelle
        
    Retourne
    --------
    float
        Variance
    """
    return eta**2 * (gamma(1 + 2 / beta) - gamma(1 + 1 / beta) ** 2)

