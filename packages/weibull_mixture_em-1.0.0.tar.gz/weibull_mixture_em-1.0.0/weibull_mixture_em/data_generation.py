"""
Module pour la generation de donnees synthetiques.
"""

from typing import List, Tuple, Optional
import numpy as np
from .weibull_mixture import WeibullMixture


def generate_synthetic_data(
    n: int,
    beta1: float,
    eta1: float,
    weight1: float,
    beta2: float,
    eta2: float,
    weight2: float,
    truncation: float,
    n_bins: int,
    random_state: Optional[int] = None,
    bin_method: str = "equal_width",
) -> Tuple[List[Tuple[Tuple[float, float], int]], np.ndarray]:
    """
    Genere des donnees synthetiques binnees a partir d'un melange de Weibull.
    
    Parametres
    ----------
    n : int
        Nombre total de cycles observes
    beta1, eta1, weight1 : float
        Parametres de la premiere composante
    beta2, eta2, weight2 : float
        Parametres de la deuxieme composante
    truncation : float
        Limite de troncature a gauche
    n_bins : int
        Nombre d'intervalles (bins)
    random_state : int, optional
        Graine aleatoire pour reproductibilite
    bin_method : str
        Methode de creation des bins: 'equal_width' ou 'equal_count'
        
    Retourne
    --------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees: [((min_i, max_i), n_i), ...]
    raw_samples : np.ndarray
        Echantillons bruts generes
    """
    # Creation du melange
    mixture = WeibullMixture(
        beta1, eta1, weight1, beta2, eta2, weight2, truncation
    )
    
    # Generation des echantillons
    samples = mixture.sample(n, random_state=random_state)
    
    # Creation des bins
    if bin_method == "equal_width":
        bins = create_equal_width_bins(samples, n_bins, truncation)
    elif bin_method == "equal_count":
        bins = create_equal_count_bins(samples, n_bins, truncation)
    else:
        raise ValueError(f"Methode de binning inconnue: {bin_method}")
    
    # Comptage dans chaque bin
    binned_data = []
    for i in range(len(bins) - 1):
        bin_min = bins[i]
        bin_max = bins[i + 1]
        
        # Compte les observations dans l'intervalle [bin_min, bin_max)
        # Sauf pour le dernier bin qui inclut la borne superieure
        if i < len(bins) - 2:
            count = np.sum((samples >= bin_min) & (samples < bin_max))
        else:
            count = np.sum((samples >= bin_min) & (samples <= bin_max))
        
        binned_data.append(((bin_min, bin_max), int(count)))
    
    return binned_data, samples


def create_equal_width_bins(
    samples: np.ndarray, n_bins: int, truncation: float
) -> np.ndarray:
    """
    Cree des bins de largeur egale.
    
    Parametres
    ----------
    samples : np.ndarray
        Echantillons
    n_bins : int
        Nombre de bins
    truncation : float
        Limite de troncature
        
    Retourne
    --------
    np.ndarray
        Bornes des bins (n_bins + 1 valeurs)
    """
    min_val = max(np.min(samples), truncation)
    max_val = np.max(samples)
    
    return np.linspace(min_val, max_val, n_bins + 1)


def create_equal_count_bins(
    samples: np.ndarray, n_bins: int, truncation: float
) -> np.ndarray:
    """
    Cree des bins avec approximativement le meme nombre d'observations.
    
    Parametres
    ----------
    samples : np.ndarray
        Echantillons
    n_bins : int
        Nombre de bins
    truncation : float
        Limite de troncature
        
    Retourne
    --------
    np.ndarray
        Bornes des bins (n_bins + 1 valeurs)
    """
    # Filtre les valeurs en dessous de la troncature
    valid_samples = samples[samples >= truncation]
    
    # Calcul des quantiles
    quantiles = np.linspace(0, 100, n_bins + 1)
    bins = np.percentile(valid_samples, quantiles)
    
    # S'assurer que la premiere borne est >= truncation
    bins[0] = max(bins[0], truncation)
    
    return bins


def generate_binned_data_from_histogram(
    bin_edges: np.ndarray, counts: np.ndarray
) -> List[Tuple[Tuple[float, float], int]]:
    """
    Convertit un histogramme (edges + counts) en format binned_data.
    
    Parametres
    ----------
    bin_edges : np.ndarray
        Bornes des bins (n_bins + 1 valeurs)
    counts : np.ndarray
        Comptages dans chaque bin (n_bins valeurs)
        
    Retourne
    --------
    List[Tuple[Tuple[float, float], int]]
        Donnees binnees
    """
    binned_data = []
    for i in range(len(counts)):
        interval = (bin_edges[i], bin_edges[i + 1])
        count = int(counts[i])
        binned_data.append((interval, count))
    
    return binned_data


def add_noise_to_binned_data(
    binned_data: List[Tuple[Tuple[float, float], int]],
    noise_level: float = 0.05,
    random_state: Optional[int] = None,
) -> List[Tuple[Tuple[float, float], int]]:
    """
    Ajoute du bruit aux comptages pour simuler une variabilite d'echantillonnage.
    
    Parametres
    ----------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees originales
    noise_level : float
        Niveau de bruit (ecart-type relatif)
    random_state : int, optional
        Graine aleatoire
        
    Retourne
    --------
    List[Tuple[Tuple[float, float], int]]
        Donnees binnees bruitees
    """
    if random_state is not None:
        np.random.seed(random_state)
    
    noisy_data = []
    for (interval, count) in binned_data:
        # Bruit gaussien
        noise = np.random.normal(0, count * noise_level)
        noisy_count = max(0, int(count + noise))
        noisy_data.append((interval, noisy_count))
    
    return noisy_data

