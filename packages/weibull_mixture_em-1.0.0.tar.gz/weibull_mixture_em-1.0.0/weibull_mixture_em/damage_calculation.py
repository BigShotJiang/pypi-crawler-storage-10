"""
Module pour le calcul de l'endommagement selon la regle de Miner.
"""

from typing import List, Tuple, Optional, Dict
import numpy as np
from scipy import integrate

from .weibull_mixture import WeibullMixture
from .sn_curves import SNCurve


class DamageCalculator:
    """
    Calculateur d'endommagement selon la regle de Miner.
    
    Parametres
    ----------
    mixture : WeibullMixture
        Melange de distributions de Weibull
    sn_curve : SNCurve
        Courbe S-N de reference
    """
    
    def __init__(self, mixture: WeibullMixture, sn_curve: SNCurve):
        self.mixture = mixture
        self.sn_curve = sn_curve
    
    def damage_discrete(
        self, binned_data: List[Tuple[Tuple[float, float], int]]
    ) -> float:
        """
        Calcule l'endommagement par approche discrete (sommation).
        
        D = sum(n_i / N_i)
        
        ou n_i = nombre de cycles a l'amplitude Delta_sigma_i
        et N_i = nombre de cycles a rupture pour Delta_sigma_i
        
        Parametres
        ----------
        binned_data : List[Tuple[Tuple[float, float], int]]
            Donnees binnees: [((min_i, max_i), n_i), ...]
            
        Retourne
        --------
        float
            Endommagement D
        """
        damage = 0.0
        
        for (delta_sigma_min, delta_sigma_max), n_i in binned_data:
            # Utilise le centre de l'intervalle
            delta_sigma_i = (delta_sigma_min + delta_sigma_max) / 2
            
            # Nombre de cycles a rupture
            N_i = self.sn_curve.N_at_stress(delta_sigma_i)
            
            # Evite la division par zero ou infini
            if N_i > 0 and not np.isinf(N_i):
                damage += n_i / N_i
        
        return damage
    
    def damage_continuous(
        self,
        stress_min: Optional[float] = None,
        stress_max: Optional[float] = None,
        n_points: int = 10000,
    ) -> float:
        """
        Calcule l'endommagement par approche continue (integrale).
        
        D = integral [f(x) / N(x)] dx
        
        ou f(x) = densite du melange de Weibull
        et N(x) = nombre de cycles a rupture selon la courbe S-N
        
        Parametres
        ----------
        stress_min : float, optional
            Limite inferieure d'integration (par defaut: troncature)
        stress_max : float, optional
            Limite superieure d'integration (par defaut: calcule automatiquement)
        n_points : int
            Nombre de points pour l'integration numerique
            
        Retourne
        --------
        float
            Endommagement D
        """
        # Limites d'integration
        if stress_min is None:
            stress_min = self.mixture.truncation
        
        if stress_max is None:
            # Utilise le quantile 99.99% du melange
            stress_max = self._estimate_high_quantile(0.9999)
        
        # Integration numerique
        # Methode: integration par la methode des trapezes avec grille adaptative
        
        def integrand(x):
            """Fonction a integrer: f(x) / N(x)"""
            pdf_value = self.mixture.pdf(np.array([x]))[0]
            N_value = self.sn_curve.N_at_stress(x)
            
            # Gestion des cas particuliers
            if N_value == 0 or np.isinf(N_value):
                return 0.0
            
            return pdf_value / N_value
        
        # Integration adaptative
        try:
            damage, error = integrate.quad(
                integrand, stress_min, stress_max, limit=100
            )
        except Exception as e:
            # Fallback: integration par methode des trapezes
            print(f"Integration adaptative echouee: {e}")
            x_values = np.linspace(stress_min, stress_max, n_points)
            y_values = np.array([integrand(x) for x in x_values])
            damage = np.trapz(y_values, x_values)
        
        return damage
    
    def damage_with_confidence_interval(
        self,
        binned_data: List[Tuple[Tuple[float, float], int]],
        method: str = "discrete",
        confidence_intervals: Optional[Dict[str, Tuple[float, float]]] = None,
        n_samples: int = 1000,
    ) -> Tuple[float, float, float]:
        """
        Calcule l'endommagement avec intervalle de confiance.
        
        Strategie: echantillonnage Monte Carlo des parametres
        dans leurs intervalles de confiance.
        
        Parametres
        ----------
        binned_data : List[Tuple[Tuple[float, float], int]]
            Donnees binnees
        method : str
            Methode de calcul: 'discrete' ou 'continuous'
        confidence_intervals : Dict[str, Tuple[float, float]], optional
            Intervalles de confiance sur les parametres
        n_samples : int
            Nombre d'echantillons Monte Carlo
            
        Retourne
        --------
        damage_mean : float
            Endommagement moyen
        damage_ci_low : float
            Limite inferieure IC 95%
        damage_ci_high : float
            Limite superieure IC 95%
        """
        if confidence_intervals is None:
            # Pas d'incertitude: retourne juste la valeur ponctuelle
            if method == "discrete":
                damage = self.damage_discrete(binned_data)
            else:
                damage = self.damage_continuous()
            return damage, damage, damage
        
        # Echantillonnage Monte Carlo
        damage_samples = []
        
        for _ in range(n_samples):
            # Echantillonne les parametres dans leurs IC
            beta1 = np.random.uniform(*confidence_intervals["beta1"])
            eta1 = np.random.uniform(*confidence_intervals["eta1"])
            weight1 = np.random.uniform(*confidence_intervals["weight1"])
            beta2 = np.random.uniform(*confidence_intervals["beta2"])
            eta2 = np.random.uniform(*confidence_intervals["eta2"])
            weight2 = np.random.uniform(*confidence_intervals["weight2"])
            
            # Normalisation des poids
            weight_sum = weight1 + weight2
            weight1 /= weight_sum
            weight2 /= weight_sum
            
            # Cree un nouveau melange
            try:
                mixture_sample = WeibullMixture(
                    beta1,
                    eta1,
                    weight1,
                    beta2,
                    eta2,
                    weight2,
                    self.mixture.truncation,
                )
                
                calc_sample = DamageCalculator(mixture_sample, self.sn_curve)
                
                if method == "discrete":
                    damage = calc_sample.damage_discrete(binned_data)
                else:
                    damage = calc_sample.damage_continuous()
                
                damage_samples.append(damage)
            except Exception:
                # Ignore les parametres invalides
                continue
        
        if len(damage_samples) == 0:
            # Fallback
            if method == "discrete":
                damage = self.damage_discrete(binned_data)
            else:
                damage = self.damage_continuous()
            return damage, damage, damage
        
        # Statistiques
        damage_samples = np.array(damage_samples)
        damage_mean = np.mean(damage_samples)
        damage_ci_low = np.percentile(damage_samples, 2.5)
        damage_ci_high = np.percentile(damage_samples, 97.5)
        
        return damage_mean, damage_ci_low, damage_ci_high
    
    def _estimate_high_quantile(self, quantile: float) -> float:
        """
        Estime un quantile eleve du melange par recherche numerique.
        
        Parametres
        ----------
        quantile : float
            Quantile desire (ex: 0.999)
            
        Retourne
        --------
        float
            Valeur estimee du quantile
        """
        # Recherche dichotomique
        x_low = self.mixture.truncation
        x_high = self.mixture.truncation * 100  # Estimation initiale
        
        # Assure que x_high donne CDF > quantile
        while self.mixture.cdf(np.array([x_high]))[0] < quantile:
            x_high *= 2
        
        # Dichotomie
        for _ in range(50):
            x_mid = (x_low + x_high) / 2
            cdf_mid = self.mixture.cdf(np.array([x_mid]))[0]
            
            if cdf_mid < quantile:
                x_low = x_mid
            else:
                x_high = x_mid
            
            if abs(cdf_mid - quantile) < 1e-6:
                break
        
        return x_mid


def calculate_damage_discrete(
    binned_data: List[Tuple[Tuple[float, float], int]],
    mixture: WeibullMixture,
    sn_curve: SNCurve,
) -> float:
    """
    Fonction utilitaire pour calculer l'endommagement discret.
    
    Parametres
    ----------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees
    mixture : WeibullMixture
        Melange de Weibull
    sn_curve : SNCurve
        Courbe S-N
        
    Retourne
    --------
    float
        Endommagement
    """
    calc = DamageCalculator(mixture, sn_curve)
    return calc.damage_discrete(binned_data)


def calculate_damage_continuous(
    mixture: WeibullMixture,
    sn_curve: SNCurve,
    stress_min: Optional[float] = None,
    stress_max: Optional[float] = None,
) -> float:
    """
    Fonction utilitaire pour calculer l'endommagement continu.
    
    Parametres
    ----------
    mixture : WeibullMixture
        Melange de Weibull
    sn_curve : SNCurve
        Courbe S-N
    stress_min : float, optional
        Limite inferieure
    stress_max : float, optional
        Limite superieure
        
    Retourne
    --------
    float
        Endommagement
    """
    calc = DamageCalculator(mixture, sn_curve)
    return calc.damage_continuous(stress_min, stress_max)

