"""
Module pour la visualisation des resultats.
"""

from typing import List, Tuple, Optional
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure

from .weibull_mixture import WeibullMixture
from .em_algorithm import EMResult
from .sn_curves import SNCurve


def plot_log_likelihood(
    log_likelihood_history: List[float],
    figsize: Tuple[float, float] = (10, 6),
    save_path: Optional[str] = None,
) -> Figure:
    """
    Trace la courbe de log-vraisemblance en fonction des iterations EM.
    
    Parametres
    ----------
    log_likelihood_history : List[float]
        Historique de log-vraisemblance
    figsize : Tuple[float, float]
        Taille de la figure
    save_path : str, optional
        Chemin pour sauvegarder la figure
        
    Retourne
    --------
    Figure
        Figure matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    iterations = range(len(log_likelihood_history))
    ax.plot(iterations, log_likelihood_history, "b-", linewidth=2)
    
    ax.set_xlabel("Iteration", fontsize=12)
    ax.set_ylabel("Log-vraisemblance observee", fontsize=12)
    ax.set_title("Convergence de l'algorithme EM", fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    
    return fig


def plot_density_comparison(
    true_mixture: WeibullMixture,
    estimated_mixture: WeibullMixture,
    x_min: Optional[float] = None,
    x_max: Optional[float] = None,
    n_points: int = 1000,
    figsize: Tuple[float, float] = (10, 6),
    save_path: Optional[str] = None,
) -> Figure:
    """
    Compare les densites du melange vrai et estime.
    
    Parametres
    ----------
    true_mixture : WeibullMixture
        Melange vrai (parametres donnes)
    estimated_mixture : WeibullMixture
        Melange estime (parametres estimes)
    x_min, x_max : float, optional
        Limites de l'axe X
    n_points : int
        Nombre de points pour le trace
    figsize : Tuple[float, float]
        Taille de la figure
    save_path : str, optional
        Chemin pour sauvegarder
        
    Retourne
    --------
    Figure
        Figure matplotlib
    """
    # Limites de trace
    if x_min is None:
        x_min = max(true_mixture.truncation, estimated_mixture.truncation)
    
    if x_max is None:
        # Estime un maximum raisonnable
        x_max = max(
            true_mixture.eta1 * 3,
            true_mixture.eta2 * 3,
            estimated_mixture.eta1 * 3,
            estimated_mixture.eta2 * 3,
        )
    
    x_values = np.linspace(x_min, x_max, n_points)
    
    # Densites
    pdf_true = true_mixture.pdf(x_values)
    pdf_estimated = estimated_mixture.pdf(x_values)
    
    # Trace
    fig, ax = plt.subplots(figsize=figsize)
    
    ax.plot(x_values, pdf_true, "b-", linewidth=2, label="Melange vrai")
    ax.plot(
        x_values,
        pdf_estimated,
        "r--",
        linewidth=2,
        label="Melange estime",
    )
    
    ax.set_xlabel("Amplitude (MPa)", fontsize=12)
    ax.set_ylabel("Densite de probabilite", fontsize=12)
    ax.set_title(
        "Comparaison des densites du melange",
        fontsize=14,
        fontweight="bold",
    )
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    
    return fig


def plot_histogram_and_sn(
    binned_data: List[Tuple[Tuple[float, float], int]],
    sn_curve: SNCurve,
    figsize: Tuple[float, float] = (16, 6),
    save_path: Optional[str] = None,
) -> Figure:
    """
    Graphique double: histogramme des donnees + courbes S-N.
    
    Parametres
    ----------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees
    sn_curve : SNCurve
        Courbe S-N de reference
    figsize : Tuple[float, float]
        Taille de la figure
    save_path : str, optional
        Chemin pour sauvegarder
        
    Retourne
    --------
    Figure
        Figure matplotlib
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
    
    # Graphique 1: Histogramme
    intervals = [interval for interval, _ in binned_data]
    counts = [count for _, count in binned_data]
    
    # Extraction des bornes
    bin_edges = [interval[0] for interval in intervals] + [intervals[-1][1]]
    bin_centers = [(interval[0] + interval[1]) / 2 for interval in intervals]
    bin_widths = [interval[1] - interval[0] for interval in intervals]
    
    ax1.bar(
        bin_centers,
        counts,
        width=bin_widths,
        alpha=0.7,
        edgecolor="black",
        color="steelblue",
    )
    ax1.set_xlabel("Amplitude de contrainte (MPa)", fontsize=12)
    ax1.set_ylabel("Nombre de cycles", fontsize=12)
    ax1.set_title("Histogramme des donnees binnees", fontsize=14, fontweight="bold")
    ax1.grid(True, alpha=0.3, axis="y")
    
    # Graphique 2: Courbe S-N
    N_values, delta_sigma_values = sn_curve.get_curve_points(
        N_min=1e3, N_max=1e9, n_points=1000
    )
    
    ax2.loglog(
        N_values,
        delta_sigma_values,
        "b-",
        linewidth=2,
        label=f"Categorie {sn_curve.detail_category}",
    )
    
    # Ajouter des points correspondant aux comptages
    N_at_bins = sn_curve.N_at_stress(np.array(bin_centers))
    
    # Filtrer les valeurs infinies ou invalides
    valid_mask = np.isfinite(N_at_bins) & (N_at_bins > 0)
    N_at_bins_valid = N_at_bins[valid_mask]
    bin_centers_valid = np.array(bin_centers)[valid_mask]
    counts_valid = np.array(counts)[valid_mask]
    
    # Taille des marqueurs proportionnelle aux comptages
    marker_sizes = 100 + 500 * counts_valid / max(counts_valid)
    
    ax2.scatter(
        N_at_bins_valid,
        bin_centers_valid,
        s=marker_sizes,
        alpha=0.6,
        color="red",
        edgecolors="black",
        label="Observations",
        zorder=5,
    )
    
    # Lignes de transition
    ax2.axvline(
        sn_curve.N_transition,
        color="gray",
        linestyle="--",
        alpha=0.5,
        label="Transition",
    )
    
    ax2.set_xlabel("Nombre de cycles N", fontsize=12)
    ax2.set_ylabel("Amplitude de contrainte (MPa)", fontsize=12)
    ax2.set_title("Courbe S-N Eurocode 3", fontsize=14, fontweight="bold")
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3, which="both")
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    
    return fig


def plot_all_results(
    em_result: EMResult,
    true_mixture: Optional[WeibullMixture],
    binned_data: List[Tuple[Tuple[float, float], int]],
    sn_curve: SNCurve,
    save_dir: Optional[str] = None,
) -> dict:
    """
    Genere tous les graphiques de resultats.
    
    Parametres
    ----------
    em_result : EMResult
        Resultat de l'estimation EM
    true_mixture : WeibullMixture, optional
        Melange vrai (si connu)
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees
    sn_curve : SNCurve
        Courbe S-N
    save_dir : str, optional
        Repertoire pour sauvegarder les figures
        
    Retourne
    --------
    dict
        Dictionnaire des figures
    """
    figures = {}
    
    # 1. Log-vraisemblance
    save_path_ll = f"{save_dir}/log_likelihood.png" if save_dir else None
    figures["log_likelihood"] = plot_log_likelihood(
        em_result.log_likelihood_history, save_path=save_path_ll
    )
    
    # 2. Comparaison des densites (si melange vrai connu)
    if true_mixture is not None:
        save_path_dens = f"{save_dir}/density_comparison.png" if save_dir else None
        figures["density"] = plot_density_comparison(
            true_mixture, em_result.get_mixture(), save_path=save_path_dens
        )
    
    # 3. Histogramme + S-N
    save_path_hist = f"{save_dir}/histogram_sn.png" if save_dir else None
    figures["histogram_sn"] = plot_histogram_and_sn(
        binned_data, sn_curve, save_path=save_path_hist
    )
    
    # 4. Composantes individuelles
    save_path_comp = f"{save_dir}/components.png" if save_dir else None
    figures["components"] = plot_mixture_components(
        em_result.get_mixture(), save_path=save_path_comp
    )
    
    return figures


def plot_mixture_components(
    mixture: WeibullMixture,
    x_min: Optional[float] = None,
    x_max: Optional[float] = None,
    n_points: int = 1000,
    figsize: Tuple[float, float] = (10, 6),
    save_path: Optional[str] = None,
) -> Figure:
    """
    Trace les composantes individuelles du melange.
    
    Parametres
    ----------
    mixture : WeibullMixture
        Melange de Weibull
    x_min, x_max : float, optional
        Limites de l'axe X
    n_points : int
        Nombre de points
    figsize : Tuple[float, float]
        Taille de la figure
    save_path : str, optional
        Chemin pour sauvegarder
        
    Retourne
    --------
    Figure
        Figure matplotlib
    """
    if x_min is None:
        x_min = mixture.truncation
    
    if x_max is None:
        x_max = max(mixture.eta1 * 3, mixture.eta2 * 3)
    
    x_values = np.linspace(x_min, x_max, n_points)
    
    # Import pour eviter les imports circulaires
    from .weibull_mixture import truncated_weibull_pdf
    
    # Densites des composantes
    pdf1 = truncated_weibull_pdf(x_values, mixture.beta1, mixture.eta1, mixture.truncation)
    pdf2 = truncated_weibull_pdf(x_values, mixture.beta2, mixture.eta2, mixture.truncation)
    pdf_mixture = mixture.pdf(x_values)
    
    # Trace
    fig, ax = plt.subplots(figsize=figsize)
    
    ax.plot(
        x_values,
        mixture.weight1 * pdf1,
        "g--",
        linewidth=2,
        alpha=0.7,
        label=f"Composante 1 (poids={mixture.weight1:.3f})",
    )
    ax.plot(
        x_values,
        mixture.weight2 * pdf2,
        "orange",
        linestyle="--",
        linewidth=2,
        alpha=0.7,
        label=f"Composante 2 (poids={mixture.weight2:.3f})",
    )
    ax.plot(
        x_values, pdf_mixture, "b-", linewidth=2.5, label="Melange total"
    )
    
    ax.set_xlabel("Amplitude (MPa)", fontsize=12)
    ax.set_ylabel("Densite de probabilite", fontsize=12)
    ax.set_title(
        "Decomposition du melange de Weibull",
        fontsize=14,
        fontweight="bold",
    )
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Ajouter une ligne verticale a la troncature
    ax.axvline(
        mixture.truncation, color="red", linestyle=":", alpha=0.5, label="Troncature"
    )
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    
    return fig


def plot_parameter_comparison(
    true_params: dict,
    estimated_params: dict,
    confidence_intervals: Optional[dict] = None,
    figsize: Tuple[float, float] = (12, 8),
    save_path: Optional[str] = None,
) -> Figure:
    """
    Compare les parametres vrais et estimes.
    
    Parametres
    ----------
    true_params : dict
        Parametres vrais
    estimated_params : dict
        Parametres estimes
    confidence_intervals : dict, optional
        Intervalles de confiance
    figsize : Tuple[float, float]
        Taille de la figure
    save_path : str, optional
        Chemin pour sauvegarder
        
    Retourne
    --------
    Figure
        Figure matplotlib
    """
    param_names = ["beta1", "eta1", "weight1", "beta2", "eta2", "weight2"]
    
    fig, axes = plt.subplots(2, 3, figsize=figsize)
    axes = axes.flatten()
    
    for i, param_name in enumerate(param_names):
        ax = axes[i]
        
        true_val = true_params.get(param_name, 0)
        est_val = estimated_params.get(param_name, 0)
        
        # Barres
        x_pos = [0, 1]
        values = [true_val, est_val]
        colors = ["steelblue", "coral"]
        
        ax.bar(x_pos, values, color=colors, alpha=0.7, edgecolor="black")
        
        # Intervalle de confiance
        if confidence_intervals and param_name in confidence_intervals:
            ci_low, ci_high = confidence_intervals[param_name]
            ax.errorbar(
                [1],
                [est_val],
                yerr=[[est_val - ci_low], [ci_high - est_val]],
                fmt="none",
                color="black",
                capsize=5,
                linewidth=2,
            )
        
        # Etiquettes
        ax.set_xticks(x_pos)
        ax.set_xticklabels(["Vrai", "Estime"])
        ax.set_ylabel("Valeur", fontsize=10)
        ax.set_title(param_name, fontsize=12, fontweight="bold")
        ax.grid(True, alpha=0.3, axis="y")
        
        # Erreur relative
        if true_val != 0:
            rel_error = abs(est_val - true_val) / abs(true_val) * 100
            ax.text(
                0.5,
                max(values) * 0.9,
                f"Erreur: {rel_error:.1f}%",
                ha="center",
                fontsize=9,
                bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
            )
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    
    return fig

