"""
Module pour l'algorithme EM d'estimation des parametres d'un melange de Weibull.
"""

from typing import Dict, List, Tuple, Optional
import numpy as np
from scipy.optimize import minimize
from scipy.stats import bootstrap
from dataclasses import dataclass

from .weibull_mixture import (
    truncated_weibull_pdf,
    truncated_weibull_cdf,
    WeibullMixture,
)


@dataclass
class EMResult:
    """
    Resultat de l'algorithme EM.
    
    Attributs
    ---------
    beta1, eta1, weight1 : float
        Parametres de la premiere composante
    beta2, eta2, weight2 : float
        Parametres de la deuxieme composante
    truncation : float
        Limite de troncature
    log_likelihood : float
        Log-vraisemblance finale
    n_iterations : int
        Nombre d'iterations
    converged : bool
        Indicateur de convergence
    log_likelihood_history : List[float]
        Historique de log-vraisemblance
    confidence_intervals : Dict[str, Tuple[float, float]]
        Intervalles de confiance a 95%
    """
    
    beta1: float
    eta1: float
    weight1: float
    beta2: float
    eta2: float
    weight2: float
    truncation: float
    log_likelihood: float
    n_iterations: int
    converged: bool
    log_likelihood_history: List[float]
    confidence_intervals: Optional[Dict[str, Tuple[float, float]]] = None
    
    def get_mixture(self) -> WeibullMixture:
        """Retourne l'objet WeibullMixture correspondant."""
        return WeibullMixture(
            self.beta1,
            self.eta1,
            self.weight1,
            self.beta2,
            self.eta2,
            self.weight2,
            self.truncation,
        )
    
    def to_dict(self) -> Dict:
        """Convertit le resultat en dictionnaire."""
        return {
            "beta1": self.beta1,
            "eta1": self.eta1,
            "weight1": self.weight1,
            "beta2": self.beta2,
            "eta2": self.eta2,
            "weight2": self.weight2,
            "truncation": self.truncation,
            "log_likelihood": self.log_likelihood,
            "n_iterations": self.n_iterations,
            "converged": self.converged,
        }


class EMAlgorithm:
    """
    Algorithme EM pour l'estimation des parametres d'un melange de Weibull tronque.
    
    Parametres
    ----------
    max_iterations : int
        Nombre maximum d'iterations
    tolerance : float
        Critere de convergence sur la log-vraisemblance
    verbose : bool
        Affichage des informations de progression
    """
    
    def __init__(
        self,
        max_iterations: int = 1000,
        tolerance: float = 1e-6,
        verbose: bool = False,
    ):
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.verbose = verbose
    
    def fit(
        self,
        binned_data: List[Tuple[Tuple[float, float], int]],
        initial_params: Optional[Dict] = None,
        truncation: Optional[float] = None,
        compute_ci: bool = True,
        n_bootstrap: int = 100,
    ) -> EMResult:
        """
        Estime les parametres du melange par algorithme EM.
        
        Parametres
        ----------
        binned_data : List[Tuple[Tuple[float, float], int]]
            Donnees binnees: [((min_i, max_i), n_i), ...]
        initial_params : Dict, optional
            Parametres initiaux
        truncation : float, optional
            Limite de troncature (si None, utilise le minimum des donnees)
        compute_ci : bool
            Calculer les intervalles de confiance par bootstrap
        n_bootstrap : int
            Nombre d'iterations bootstrap
            
        Retourne
        --------
        EMResult
            Resultat de l'estimation
        """
        # Extraction des bornes et comptages
        intervals = [interval for interval, _ in binned_data]
        counts = np.array([count for _, count in binned_data])
        n_total = np.sum(counts)
        
        # Determination de la troncature
        if truncation is None:
            truncation = min(interval[0] for interval in intervals)
        
        # Initialisation des parametres
        if initial_params is None:
            params = self._initialize_parameters(intervals, counts, truncation)
        else:
            params = initial_params.copy()
            params["truncation"] = truncation
        
        # Historique de log-vraisemblance
        log_likelihood_history = []
        
        # Iterations EM
        for iteration in range(self.max_iterations):
            # E-step: calcul des responsabilites
            responsibilities = self._e_step(intervals, counts, params)
            
            # M-step: mise a jour des parametres
            params = self._m_step(intervals, counts, responsibilities, truncation)
            
            # Calcul de la log-vraisemblance
            log_likelihood = self._compute_log_likelihood(
                intervals, counts, params
            )
            log_likelihood_history.append(log_likelihood)
            
            if self.verbose and iteration % 10 == 0:
                print(f"Iteration {iteration}: Log-likelihood = {log_likelihood:.4f}")
            
            # Test de convergence
            if iteration > 0:
                delta = log_likelihood - log_likelihood_history[-2]
                if abs(delta) < self.tolerance:
                    if self.verbose:
                        print(f"Convergence atteinte a l'iteration {iteration}")
                    converged = True
                    break
        else:
            converged = False
            if self.verbose:
                print("Nombre maximum d'iterations atteint")
        
        # Calcul des intervalles de confiance
        confidence_intervals = None
        if compute_ci:
            confidence_intervals = self._compute_confidence_intervals(
                binned_data, params, n_bootstrap
            )
        
        return EMResult(
            beta1=params["beta1"],
            eta1=params["eta1"],
            weight1=params["weight1"],
            beta2=params["beta2"],
            eta2=params["eta2"],
            weight2=params["weight2"],
            truncation=params["truncation"],
            log_likelihood=log_likelihood_history[-1],
            n_iterations=iteration + 1,
            converged=converged,
            log_likelihood_history=log_likelihood_history,
            confidence_intervals=confidence_intervals,
        )
    
    def _initialize_parameters(
        self,
        intervals: List[Tuple[float, float]],
        counts: np.ndarray,
        truncation: float,
    ) -> Dict:
        """
        Initialise les parametres de l'algorithme EM.
        
        Strategie: utiliser les moments empiriques
        """
        # Calcul des centres des intervalles
        centers = np.array([(a + b) / 2 for a, b in intervals])
        
        # Moyenne et ecart-type ponderes
        n_total = np.sum(counts)
        mean = np.sum(centers * counts) / n_total
        variance = np.sum(((centers - mean) ** 2) * counts) / n_total
        std = np.sqrt(variance)
        
        # Initialisation avec deux composantes separees
        # Composante 1: petites valeurs
        eta1 = mean * 0.7
        beta1 = 2.0
        weight1 = 0.5
        
        # Composante 2: grandes valeurs
        eta2 = mean * 1.3
        beta2 = 2.5
        weight2 = 0.5
        
        return {
            "beta1": beta1,
            "eta1": eta1,
            "weight1": weight1,
            "beta2": beta2,
            "eta2": eta2,
            "weight2": weight2,
            "truncation": truncation,
        }
    
    def _e_step(
        self,
        intervals: List[Tuple[float, float]],
        counts: np.ndarray,
        params: Dict,
    ) -> np.ndarray:
        """
        E-step: calcul des responsabilites (probabilites posterieures).
        
        Pour des donnees binnees, la responsabilite est calculee sur l'integrale:
        gamma_i1 = weight1 * P(x in interval_i | component 1) / P(x in interval_i)
        
        Retourne
        --------
        np.ndarray de forme (n_intervals, 2)
            responsibilities[:, 0] = gamma pour composante 1
            responsibilities[:, 1] = gamma pour composante 2
        """
        n_intervals = len(intervals)
        responsibilities = np.zeros((n_intervals, 2))
        
        for i, (a, b) in enumerate(intervals):
            # Probabilite de l'intervalle pour chaque composante
            # P(a <= X <= b | component k) = CDF(b) - CDF(a)
            prob1 = self._interval_probability(
                a, b, params["beta1"], params["eta1"], params["truncation"]
            )
            prob2 = self._interval_probability(
                a, b, params["beta2"], params["eta2"], params["truncation"]
            )
            
            # Probabilite totale (melange)
            prob_total = (
                params["weight1"] * prob1 + params["weight2"] * prob2
            )
            
            # Responsabilites (stabilite numerique)
            if prob_total > 1e-300:
                responsibilities[i, 0] = params["weight1"] * prob1 / prob_total
                responsibilities[i, 1] = params["weight2"] * prob2 / prob_total
            else:
                # Cas degenere: repartir egalement
                responsibilities[i, 0] = 0.5
                responsibilities[i, 1] = 0.5
        
        return responsibilities
    
    def _interval_probability(
        self, a: float, b: float, beta: float, eta: float, truncation: float
    ) -> float:
        """
        Calcule P(a <= X <= b) pour une Weibull tronquee.
        """
        cdf_b = truncated_weibull_cdf(np.array([b]), beta, eta, truncation)[0]
        cdf_a = truncated_weibull_cdf(np.array([a]), beta, eta, truncation)[0]
        return max(cdf_b - cdf_a, 1e-300)  # Eviter 0
    
    def _m_step(
        self,
        intervals: List[Tuple[float, float]],
        counts: np.ndarray,
        responsibilities: np.ndarray,
        truncation: float,
    ) -> Dict:
        """
        M-step: maximisation de la vraisemblance esperee.
        
        Met a jour:
        - weights: somme ponderee des responsabilites
        - beta, eta: par optimisation numerique pour chaque composante
        """
        n_total = np.sum(counts)
        
        # Mise a jour des poids
        weight1 = np.sum(counts * responsibilities[:, 0]) / n_total
        weight2 = np.sum(counts * responsibilities[:, 1]) / n_total
        
        # Normalisation (securite)
        weight_sum = weight1 + weight2
        weight1 /= weight_sum
        weight2 /= weight_sum
        
        # Mise a jour de beta et eta pour chaque composante
        beta1, eta1 = self._optimize_weibull_params(
            intervals, counts, responsibilities[:, 0], truncation
        )
        beta2, eta2 = self._optimize_weibull_params(
            intervals, counts, responsibilities[:, 1], truncation
        )
        
        return {
            "beta1": beta1,
            "eta1": eta1,
            "weight1": weight1,
            "beta2": beta2,
            "eta2": eta2,
            "weight2": weight2,
            "truncation": truncation,
        }
    
    def _optimize_weibull_params(
        self,
        intervals: List[Tuple[float, float]],
        counts: np.ndarray,
        responsibilities: np.ndarray,
        truncation: float,
    ) -> Tuple[float, float]:
        """
        Optimise beta et eta pour une composante donnee.
        
        Maximise la log-vraisemblance ponderee par les responsabilites.
        """
        
        def neg_log_likelihood(params):
            beta, eta = params
            if beta <= 0 or eta <= 0:
                return 1e10
            
            log_lik = 0
            for i, (a, b) in enumerate(intervals):
                if responsibilities[i] > 1e-10:
                    prob = self._interval_probability(a, b, beta, eta, truncation)
                    if prob > 1e-300:
                        log_lik += counts[i] * responsibilities[i] * np.log(prob)
                    else:
                        log_lik += counts[i] * responsibilities[i] * (-1000)
            
            return -log_lik
        
        # Point initial: moyenne des centres ponderee
        centers = np.array([(a + b) / 2 for a, b in intervals])
        mean_center = np.sum(centers * counts * responsibilities) / np.sum(
            counts * responsibilities
        )
        
        initial_eta = max(mean_center, truncation * 1.1)
        initial_beta = 2.0
        
        # Optimisation
        result = minimize(
            neg_log_likelihood,
            [initial_beta, initial_eta],
            method="Nelder-Mead",
            options={"maxiter": 500},
        )
        
        beta, eta = result.x
        
        # Contraintes
        beta = max(0.1, min(beta, 10.0))
        eta = max(truncation * 1.01, eta)
        
        return beta, eta
    
    def _compute_log_likelihood(
        self, intervals: List[Tuple[float, float]], counts: np.ndarray, params: Dict
    ) -> float:
        """
        Calcule la log-vraisemblance observee.
        
        L = sum_i n_i * log(P(X in interval_i))
        """
        log_lik = 0
        
        for i, (a, b) in enumerate(intervals):
            # Probabilite de l'intervalle pour le melange
            prob1 = self._interval_probability(
                a, b, params["beta1"], params["eta1"], params["truncation"]
            )
            prob2 = self._interval_probability(
                a, b, params["beta2"], params["eta2"], params["truncation"]
            )
            
            prob_total = params["weight1"] * prob1 + params["weight2"] * prob2
            
            if prob_total > 1e-300:
                log_lik += counts[i] * np.log(prob_total)
            else:
                log_lik += counts[i] * (-1000)
        
        return log_lik
    
    def _compute_confidence_intervals(
        self,
        binned_data: List[Tuple[Tuple[float, float], int]],
        params: Dict,
        n_bootstrap: int,
    ) -> Dict[str, Tuple[float, float]]:
        """
        Calcule les intervalles de confiance par bootstrap.
        
        Strategie: reechantillonnage des comptages selon une multinomiale.
        """
        intervals = [interval for interval, _ in binned_data]
        counts_original = np.array([count for _, count in binned_data])
        n_total = np.sum(counts_original)
        
        # Probabilites empiriques
        probs = counts_original / n_total
        
        # Stockage des parametres bootstrappes
        bootstrap_params = {
            "beta1": [],
            "eta1": [],
            "weight1": [],
            "beta2": [],
            "eta2": [],
            "weight2": [],
        }
        
        for _ in range(n_bootstrap):
            # Reechantillonnage multinomial
            counts_boot = np.random.multinomial(n_total, probs)
            
            # Re-estimation
            binned_data_boot = list(zip(intervals, counts_boot))
            try:
                result_boot = self.fit(
                    binned_data_boot,
                    initial_params=params,
                    truncation=params["truncation"],
                    compute_ci=False,
                )
                
                bootstrap_params["beta1"].append(result_boot.beta1)
                bootstrap_params["eta1"].append(result_boot.eta1)
                bootstrap_params["weight1"].append(result_boot.weight1)
                bootstrap_params["beta2"].append(result_boot.beta2)
                bootstrap_params["eta2"].append(result_boot.eta2)
                bootstrap_params["weight2"].append(result_boot.weight2)
            except Exception:
                # En cas d'echec, ignorer cette iteration
                continue
        
        # Calcul des percentiles (intervalle a 95%)
        confidence_intervals = {}
        for param_name in bootstrap_params:
            if len(bootstrap_params[param_name]) > 0:
                values = np.array(bootstrap_params[param_name])
                ci_low = np.percentile(values, 2.5)
                ci_high = np.percentile(values, 97.5)
                confidence_intervals[param_name] = (ci_low, ci_high)
            else:
                confidence_intervals[param_name] = (np.nan, np.nan)
        
        return confidence_intervals


def em_fit(
    binned_data: List[Tuple[Tuple[float, float], int]],
    initial_params: Optional[Dict] = None,
    truncation: Optional[float] = None,
    max_iterations: int = 1000,
    tolerance: float = 1e-6,
    verbose: bool = False,
    compute_ci: bool = True,
    n_bootstrap: int = 100,
) -> EMResult:
    """
    Fonction utilitaire pour ajuster le modele EM.
    
    Parametres
    ----------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees
    initial_params : Dict, optional
        Parametres initiaux
    truncation : float, optional
        Limite de troncature
    max_iterations : int
        Nombre maximum d'iterations
    tolerance : float
        Critere de convergence
    verbose : bool
        Affichage des informations
    compute_ci : bool
        Calculer les intervalles de confiance
    n_bootstrap : int
        Nombre d'iterations bootstrap
        
    Retourne
    --------
    EMResult
        Resultat de l'estimation
    """
    em = EMAlgorithm(
        max_iterations=max_iterations, tolerance=tolerance, verbose=verbose
    )
    return em.fit(
        binned_data,
        initial_params=initial_params,
        truncation=truncation,
        compute_ci=compute_ci,
        n_bootstrap=n_bootstrap,
    )

