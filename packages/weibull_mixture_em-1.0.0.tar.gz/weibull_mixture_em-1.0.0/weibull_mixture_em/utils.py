"""
Fonctions utilitaires pour le package.
"""

from typing import Dict, List, Tuple
import numpy as np
import json


def compute_relative_errors(
    true_params: Dict, estimated_params: Dict
) -> Dict[str, float]:
    """
    Calcule les erreurs relatives entre parametres vrais et estimes.
    
    Parametres
    ----------
    true_params : Dict
        Parametres vrais
    estimated_params : Dict
        Parametres estimes
        
    Retourne
    --------
    Dict[str, float]
        Erreurs relatives en pourcentage
    """
    errors = {}
    
    for param_name in true_params.keys():
        if param_name in estimated_params:
            true_val = true_params[param_name]
            est_val = estimated_params[param_name]
            
            if true_val != 0:
                rel_error = abs(est_val - true_val) / abs(true_val) * 100
                errors[param_name] = rel_error
            else:
                errors[param_name] = np.nan
    
    return errors


def compute_aic(log_likelihood: float, n_params: int) -> float:
    """
    Calcule le critere d'information d'Akaike (AIC).
    
    AIC = 2 * k - 2 * log(L)
    
    Parametres
    ----------
    log_likelihood : float
        Log-vraisemblance
    n_params : int
        Nombre de parametres
        
    Retourne
    --------
    float
        Valeur AIC
    """
    return 2 * n_params - 2 * log_likelihood


def compute_bic(log_likelihood: float, n_params: int, n_samples: int) -> float:
    """
    Calcule le critere d'information Bayesien (BIC).
    
    BIC = log(n) * k - 2 * log(L)
    
    Parametres
    ----------
    log_likelihood : float
        Log-vraisemblance
    n_params : int
        Nombre de parametres
    n_samples : int
        Nombre d'observations
        
    Retourne
    --------
    float
        Valeur BIC
    """
    return np.log(n_samples) * n_params - 2 * log_likelihood


def save_results_to_json(
    results_dict: Dict, filepath: str
) -> None:
    """
    Sauvegarde les resultats dans un fichier JSON.
    
    Parametres
    ----------
    results_dict : Dict
        Dictionnaire de resultats
    filepath : str
        Chemin du fichier
    """
    # Conversion des types numpy en types Python natifs
    def convert_to_serializable(obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        elif isinstance(obj, tuple):
            return tuple(convert_to_serializable(item) for item in obj)
        else:
            return obj
    
    serializable_dict = convert_to_serializable(results_dict)
    
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(serializable_dict, f, indent=2)


def load_results_from_json(filepath: str) -> Dict:
    """
    Charge les resultats depuis un fichier JSON.
    
    Parametres
    ----------
    filepath : str
        Chemin du fichier
        
    Retourne
    --------
    Dict
        Dictionnaire de resultats
    """
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def print_summary(
    em_result,
    true_params: Dict = None,
    damage_discrete: float = None,
    damage_continuous: float = None,
) -> None:
    """
    Affiche un resume des resultats.
    
    Parametres
    ----------
    em_result : EMResult
        Resultat de l'estimation EM
    true_params : Dict, optional
        Parametres vrais
    damage_discrete : float, optional
        Endommagement discret
    damage_continuous : float, optional
        Endommagement continu
    """
    print("\n" + "=" * 60)
    print("RESULTATS DE L'ESTIMATION EM")
    print("=" * 60)
    
    print(f"\nConvergence: {'Oui' if em_result.converged else 'Non'}")
    print(f"Nombre d'iterations: {em_result.n_iterations}")
    print(f"Log-vraisemblance finale: {em_result.log_likelihood:.4f}")
    
    print("\nParametres estimes:")
    print("-" * 60)
    print(f"  Composante 1:")
    print(f"    beta1  = {em_result.beta1:.4f}")
    print(f"    eta1   = {em_result.eta1:.4f}")
    print(f"    poids1 = {em_result.weight1:.4f}")
    print(f"  Composante 2:")
    print(f"    beta2  = {em_result.beta2:.4f}")
    print(f"    eta2   = {em_result.eta2:.4f}")
    print(f"    poids2 = {em_result.weight2:.4f}")
    print(f"  Troncature: a = {em_result.truncation:.4f}")
    
    if true_params:
        print("\nComparaison avec les parametres vrais:")
        print("-" * 60)
        errors = compute_relative_errors(true_params, em_result.to_dict())
        for param_name, error in errors.items():
            if not np.isnan(error):
                print(f"  {param_name}: erreur relative = {error:.2f}%")
    
    if em_result.confidence_intervals:
        print("\nIntervalles de confiance (95%):")
        print("-" * 60)
        for param_name, (ci_low, ci_high) in em_result.confidence_intervals.items():
            if not np.isnan(ci_low):
                print(f"  {param_name}: [{ci_low:.4f}, {ci_high:.4f}]")
    
    if damage_discrete is not None or damage_continuous is not None:
        print("\nEndommagement (regle de Miner):")
        print("-" * 60)
        if damage_discrete is not None:
            print(f"  Approche discrete:  D = {damage_discrete:.6f}")
        if damage_continuous is not None:
            print(f"  Approche continue:  D = {damage_continuous:.6f}")
        if damage_discrete and damage_continuous:
            diff = abs(damage_discrete - damage_continuous)
            rel_diff = diff / max(damage_discrete, damage_continuous) * 100
            print(f"  Difference relative: {rel_diff:.2f}%")
    
    print("\n" + "=" * 60)


def validate_binned_data(
    binned_data: List[Tuple[Tuple[float, float], int]]
) -> bool:
    """
    Valide le format des donnees binnees.
    
    Parametres
    ----------
    binned_data : List[Tuple[Tuple[float, float], int]]
        Donnees binnees
        
    Retourne
    --------
    bool
        True si valide
        
    Raises
    ------
    ValueError
        Si les donnees sont invalides
    """
    if not binned_data:
        raise ValueError("Les donnees binnees sont vides")
    
    for i, item in enumerate(binned_data):
        if not isinstance(item, tuple) or len(item) != 2:
            raise ValueError(f"Bin {i}: format invalide")
        
        interval, count = item
        
        if not isinstance(interval, tuple) or len(interval) != 2:
            raise ValueError(f"Bin {i}: intervalle invalide")
        
        min_val, max_val = interval
        
        if min_val >= max_val:
            raise ValueError(f"Bin {i}: min >= max")
        
        if count < 0:
            raise ValueError(f"Bin {i}: comptage negatif")
    
    return True


def create_parameter_dict(
    beta1: float,
    eta1: float,
    weight1: float,
    beta2: float,
    eta2: float,
    weight2: float,
    truncation: float = None,
) -> Dict:
    """
    Cree un dictionnaire de parametres.
    
    Parametres
    ----------
    beta1, eta1, weight1 : float
        Parametres de la premiere composante
    beta2, eta2, weight2 : float
        Parametres de la deuxieme composante
    truncation : float, optional
        Limite de troncature
        
    Retourne
    --------
    Dict
        Dictionnaire de parametres
    """
    params = {
        "beta1": beta1,
        "eta1": eta1,
        "weight1": weight1,
        "beta2": beta2,
        "eta2": eta2,
        "weight2": weight2,
    }
    
    if truncation is not None:
        params["truncation"] = truncation
    
    return params

