"""
Package pour l'estimation des parametres d'un melange de distributions de Weibull
tronquees a gauche par algorithme EM, avec application a l'analyse de fatigue.
"""

__version__ = "1.0.0"
__author__ = "Weibull EM Package"

from .weibull_mixture import (
    WeibullMixture,
    truncated_weibull_pdf,
    truncated_weibull_cdf,
)
from .em_algorithm import EMAlgorithm, em_fit
from .data_generation import generate_synthetic_data
from .damage_calculation import (
    calculate_damage_discrete,
    calculate_damage_continuous,
    DamageCalculator,
)
from .sn_curves import SNCurve, get_eurocode_sn_curve
from .visualization import (
    plot_log_likelihood,
    plot_density_comparison,
    plot_histogram_and_sn,
    plot_all_results,
)

__all__ = [
    "WeibullMixture",
    "truncated_weibull_pdf",
    "truncated_weibull_cdf",
    "EMAlgorithm",
    "em_fit",
    "generate_synthetic_data",
    "calculate_damage_discrete",
    "calculate_damage_continuous",
    "DamageCalculator",
    "SNCurve",
    "get_eurocode_sn_curve",
    "plot_log_likelihood",
    "plot_density_comparison",
    "plot_histogram_and_sn",
    "plot_all_results",
]

