"""
Module pour les courbes S-N selon l'Eurocode 3 (EN 1993-1-9).
"""

from typing import Optional, Union
import numpy as np


class SNCurve:
    """
    Courbe S-N de fatigue selon l'Eurocode 3.
    
    Equation generale:
    - Pour N <= 5e6: log(N) = log(C) - m * log(Delta_sigma)
    - Pour N > 5e6: log(N) = log(C') - m' * log(Delta_sigma)
    
    Parametres
    ----------
    detail_category : float
        Categorie de detail en MPa (ex: 71, 80, 90, etc.)
    m1 : float
        Pente pour N <= 5e6 (par defaut 3)
    m2 : float
        Pente pour N > 5e6 (par defaut 5)
    N_transition : float
        Nombre de cycles de transition (par defaut 5e6)
    """
    
    # Categories de detail disponibles (MPa)
    DETAIL_CATEGORIES = [160, 140, 125, 112, 100, 90, 80, 71, 63, 56, 50, 45, 40, 36]
    
    def __init__(
        self,
        detail_category: float,
        m1: float = 3.0,
        m2: float = 5.0,
        N_transition: float = 5e6,
    ):
        if detail_category not in self.DETAIL_CATEGORIES:
            print(
                f"Avertissement: categorie {detail_category} non standard. "
                f"Categories standards: {self.DETAIL_CATEGORIES}"
            )
        
        self.detail_category = detail_category
        self.m1 = m1
        self.m2 = m2
        self.N_transition = N_transition
        
        # Calcul de la constante C pour la premiere pente
        # A N=2e6 cycles, Delta_sigma = detail_category (point de reference)
        self.N_ref = 2e6
        self.C1 = self.N_ref * (self.detail_category ** self.m1)
        
        # Contrainte a la transition
        self.delta_sigma_transition = self._stress_at_N(self.N_transition, region=1)
        
        # Constante C pour la deuxieme pente (continuity)
        self.C2 = self.N_transition * (self.delta_sigma_transition ** self.m2)
        
        # Limite d'endurance (cut-off) - asymptote horizontale
        # Generalement a N = 1e8 cycles
        self.N_cutoff = 1e8
        self.delta_sigma_cutoff = self._stress_at_N(self.N_cutoff, region=2)
    
    def stress_at_N(self, N: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        Calcule la contrainte Delta_sigma pour un nombre de cycles N.
        
        Parametres
        ----------
        N : float ou np.ndarray
            Nombre de cycles
            
        Retourne
        --------
        float ou np.ndarray
            Contrainte Delta_sigma en MPa
        """
        N = np.atleast_1d(N)
        delta_sigma = np.zeros_like(N, dtype=float)
        
        # Region 1: N <= N_transition
        mask1 = N <= self.N_transition
        if np.any(mask1):
            delta_sigma[mask1] = self._stress_at_N(N[mask1], region=1)
        
        # Region 2: N_transition < N <= N_cutoff
        mask2 = (N > self.N_transition) & (N <= self.N_cutoff)
        if np.any(mask2):
            delta_sigma[mask2] = self._stress_at_N(N[mask2], region=2)
        
        # Region 3: N > N_cutoff (limite d'endurance)
        mask3 = N > self.N_cutoff
        if np.any(mask3):
            delta_sigma[mask3] = self.delta_sigma_cutoff
        
        if delta_sigma.shape == (1,):
            return float(delta_sigma[0])
        return delta_sigma
    
    def _stress_at_N(
        self, N: Union[float, np.ndarray], region: int
    ) -> Union[float, np.ndarray]:
        """
        Calcule Delta_sigma pour une region donnee.
        
        Parametres
        ----------
        N : float ou np.ndarray
            Nombre de cycles
        region : int
            Region (1 ou 2)
            
        Retourne
        --------
        float ou np.ndarray
            Contrainte Delta_sigma
        """
        if region == 1:
            # log(N) = log(C1) - m1 * log(Delta_sigma)
            # => Delta_sigma = (C1 / N)^(1/m1)
            return (self.C1 / N) ** (1 / self.m1)
        elif region == 2:
            # Delta_sigma = (C2 / N)^(1/m2)
            return (self.C2 / N) ** (1 / self.m2)
        else:
            raise ValueError("Region doit etre 1 ou 2")
    
    def N_at_stress(self, delta_sigma: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        Calcule le nombre de cycles N pour une contrainte Delta_sigma.
        
        Parametres
        ----------
        delta_sigma : float ou np.ndarray
            Contrainte en MPa
            
        Retourne
        --------
        float ou np.ndarray
            Nombre de cycles a rupture
        """
        delta_sigma = np.atleast_1d(delta_sigma)
        N = np.zeros_like(delta_sigma, dtype=float)
        
        # Region 1: Delta_sigma >= delta_sigma_transition
        mask1 = delta_sigma >= self.delta_sigma_transition
        if np.any(mask1):
            N[mask1] = self.C1 / (delta_sigma[mask1] ** self.m1)
        
        # Region 2: delta_sigma_cutoff <= Delta_sigma < delta_sigma_transition
        mask2 = (delta_sigma >= self.delta_sigma_cutoff) & (
            delta_sigma < self.delta_sigma_transition
        )
        if np.any(mask2):
            N[mask2] = self.C2 / (delta_sigma[mask2] ** self.m2)
        
        # Region 3: Delta_sigma < delta_sigma_cutoff (infini)
        mask3 = delta_sigma < self.delta_sigma_cutoff
        if np.any(mask3):
            N[mask3] = np.inf
        
        if N.shape == (1,):
            return float(N[0])
        return N
    
    def get_curve_points(
        self, N_min: float = 1e4, N_max: float = 1e9, n_points: int = 1000
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Genere des points de la courbe S-N pour le trace.
        
        Parametres
        ----------
        N_min, N_max : float
            Limites de nombre de cycles
        n_points : int
            Nombre de points
            
        Retourne
        --------
        N_values : np.ndarray
            Valeurs de N (echelle log)
        delta_sigma_values : np.ndarray
            Valeurs de Delta_sigma correspondantes
        """
        # Echelle logarithmique pour N
        N_values = np.logspace(np.log10(N_min), np.log10(N_max), n_points)
        delta_sigma_values = self.stress_at_N(N_values)
        
        return N_values, delta_sigma_values
    
    def __repr__(self) -> str:
        return (
            f"SNCurve(detail_category={self.detail_category}, "
            f"m1={self.m1}, m2={self.m2})"
        )


def get_eurocode_sn_curve(detail_category: float, **kwargs) -> SNCurve:
    """
    Fonction utilitaire pour obtenir une courbe S-N selon l'Eurocode.
    
    Parametres
    ----------
    detail_category : float
        Categorie de detail en MPa
    **kwargs
        Arguments supplementaires pour SNCurve
        
    Retourne
    --------
    SNCurve
        Objet courbe S-N
    """
    return SNCurve(detail_category, **kwargs)


def get_all_eurocode_curves() -> dict[float, SNCurve]:
    """
    Genere toutes les courbes S-N standards de l'Eurocode.
    
    Retourne
    --------
    dict
        Dictionnaire {detail_category: SNCurve}
    """
    curves = {}
    for category in SNCurve.DETAIL_CATEGORIES:
        curves[category] = SNCurve(category)
    return curves


def compare_categories(
    N: Union[float, np.ndarray], categories: Optional[list] = None
) -> dict:
    """
    Compare les contraintes admissibles pour differentes categories.
    
    Parametres
    ----------
    N : float ou np.ndarray
        Nombre de cycles
    categories : list, optional
        Liste des categories a comparer (sinon toutes)
        
    Retourne
    --------
    dict
        Dictionnaire {category: delta_sigma}
    """
    if categories is None:
        categories = SNCurve.DETAIL_CATEGORIES
    
    results = {}
    for category in categories:
        curve = SNCurve(category)
        results[category] = curve.stress_at_N(N)
    
    return results

