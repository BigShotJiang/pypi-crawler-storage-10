from setuptools import setup, find_packages

setup(
    name="mytest34525",
    version="0.1.0",
    author="qsdf",
    author_email="sathishdhuda25@gmail.com",
    description="dwefg",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
