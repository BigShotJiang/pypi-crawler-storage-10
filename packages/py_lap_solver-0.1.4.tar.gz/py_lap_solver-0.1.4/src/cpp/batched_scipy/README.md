Code credit
https://github.com/scipy/scipy/tree/main/scipy/optimize/rectangular_lsap