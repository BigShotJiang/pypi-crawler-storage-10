Code credit: https://github.com/sguthe/lap-solver/tree/dev
