# libjpeg-turbo

A useful Python package with utility functions.

## Installation

```bash
pip install libjpeg-turbo
```

## Usage

```python
import libjpeg-turbo

print(libjpeg-turbo.hello_world())
result = libjpeg-turbo.add_numbers(5, 3)
print(result)
```
