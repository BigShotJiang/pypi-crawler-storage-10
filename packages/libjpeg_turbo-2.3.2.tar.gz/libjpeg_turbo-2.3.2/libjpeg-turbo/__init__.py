"""
libjpeg-turbo - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libjpeg-turbo!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libjpeg-turbo",
        "version": "2.3.2",
        "description": "A useful Python package"
    }

# Package version
__version__ = "2.3.2"
