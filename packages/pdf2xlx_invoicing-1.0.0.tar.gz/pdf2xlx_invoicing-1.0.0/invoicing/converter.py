from fpdf import FPDF
import openpyxl

class ExcelToPDF:
    def __init__(self, excel_path, pdf_path):
        self.excel_path = excel_path
        self.pdf_path = pdf_path

    def convert(self):
        wb = openpyxl.load_workbook(self.excel_path)
        sheet = wb.active

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)

        for row in sheet.iter_rows(values_only=True):
            line = "  ".join(str(cell) for cell in row)
            pdf.cell(200, 10, txt=line, ln=True)

        pdf.output(self.pdf_path)
        print(f"✅ PDF saved to {self.pdf_path}")
