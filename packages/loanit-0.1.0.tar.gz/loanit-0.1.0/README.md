# loanit

LoanIt — a small Python library to generate loan amortization schedules
(term, equal amortization, interest-only, balloon, bullet) and export to CSV.

Usage:

```python
from loanit import Loan
loan = Loan(principal=100000, annual_rate=0.10, years=5, loan_type="term")
loan.export_to_csv("term.csv")

---

### 2) `LICENSE` (MIT recommended)
```text
MIT License

Copyright (c) 2025 Siddiqa Sajid

Permission is hereby granted, free of charge, to any person obtaining a copy...
(you can paste a full MIT file — I can generate full text if you want)
