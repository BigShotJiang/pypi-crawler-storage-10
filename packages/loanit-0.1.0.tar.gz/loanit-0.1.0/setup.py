from setuptools import setup, find_packages
from pathlib import Path

README = Path("README.md").read_text()

setup(
    name="loanit",
    version="0.1.0",
    author="Siddiqa Sajid",
    author_email="your_email@example.com",
    description="Loan amortization schedules & export utilities",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/loanit",
    packages=find_packages(exclude=("tests", "docs")),
    python_requires=">=3.8",
    include_package_data=True,
    license="MIT",
)