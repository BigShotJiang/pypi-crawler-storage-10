from .core import Loan

__all__ = ["Loan"]
