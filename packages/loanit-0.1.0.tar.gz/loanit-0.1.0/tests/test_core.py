from loanit import Loan

def test_term_schedule_length():
    loan = Loan(100000, 0.1, 5, loan_type="term")
    sched = loan.amortization_schedule()
    assert len(sched) == 5

def test_bullet_final_payment():
    loan = Loan(100000, 0.1, 5, loan_type="bullet")
    sched = loan.amortization_schedule()
    assert sched[-1]["Payment"] > 0
