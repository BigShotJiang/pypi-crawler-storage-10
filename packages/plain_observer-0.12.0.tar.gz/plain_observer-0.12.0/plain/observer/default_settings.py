OBSERVER_IGNORE_URL_PATTERNS: list[str] = [
    "/assets/.*",
    "/observer/.*",
    "/pageviews/.*",
    "/favicon.ico",
    "/.well-known/.*",
]
OBSERVER_TRACE_LIMIT: int = 100
