"""Top-level package for Set_Function."""

__author__ = """Group6 Discrete"""
__email__ = 'letsworkwithinno@gmail.com'

from .set_function import Himpunan

__all__ = ["Himpunan"]