calute.types.tool_calls
=======================

.. automodule:: calute.types.tool_calls
    :members:
    :undoc-members:
    :show-inheritance:
