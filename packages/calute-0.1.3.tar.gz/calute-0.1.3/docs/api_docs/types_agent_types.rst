calute.types.agent_types
========================

.. automodule:: calute.types.agent_types
    :members:
    :undoc-members:
    :show-inheritance:
