calute.cortex.types
===================

.. automodule:: calute.cortex.types
    :members:
    :undoc-members:
    :show-inheritance:
