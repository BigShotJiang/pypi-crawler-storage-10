calute.types.chat_completion_types
==================================

.. automodule:: calute.types.chat_completion_types
    :members:
    :undoc-members:
    :show-inheritance:
