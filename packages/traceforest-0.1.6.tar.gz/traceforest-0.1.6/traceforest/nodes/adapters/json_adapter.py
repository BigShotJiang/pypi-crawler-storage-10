class JSONAdapter:
    pass
