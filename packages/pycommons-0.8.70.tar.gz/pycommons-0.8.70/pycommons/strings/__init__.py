"""Common string handling routines."""
