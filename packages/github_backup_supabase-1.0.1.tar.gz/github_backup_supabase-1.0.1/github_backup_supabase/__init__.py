print("GitHub Backup CLI initialized")
print("Author: Psycho Coder")
print("GitHub: https://github.com/itspsychocoder")
print("Website: https://hussnainahmad.tech/")