"""TOON decoder - converts TOON format to Python data structures."""

from typing import Any, Optional
import re


class ToonDecodeError(Exception):
    """Exception raised when TOON decoding fails."""
    pass


class ToonDecoder:
    """Decodes TOON format to Python data structures."""

    def __init__(self, indent: int = 2, strict: bool = True):
        """
        Initialize decoder.

        Args:
            indent: Expected number of spaces per indentation level (default: 2)
            strict: Enable strict mode validation (default: True)
        """
        if indent < 1:
            raise ValueError("indent must be at least 1")

        self.indent_size = indent
        self.strict = strict

    def decode(self, text: str) -> Any:
        """
        Decode TOON text to Python object.

        Args:
            text: TOON formatted text

        Returns:
            Decoded Python object

        Raises:
            ToonDecodeError: If decoding fails
        """
        if not text:
            if self.strict:
                raise ToonDecodeError("Empty input")
            return {}

        lines = self._parse_lines(text)
        if not lines:
            if self.strict:
                raise ToonDecodeError("Empty input")
            return {}

        # Determine root form
        return self._decode_root(lines)

    def _parse_lines(self, text: str) -> list[tuple[int, str]]:
        """
        Parse text into (depth, content) tuples.

        Args:
            text: Input text

        Returns:
            List of (depth, content) tuples for non-empty lines
        """
        lines = []
        for line_num, line in enumerate(text.split('\n'), 1):
            # Skip completely blank lines outside structures
            if not line.strip():
                continue

            # Check for tabs in indentation BEFORE calculating leading spaces
            # Look at the leading whitespace
            stripped = line.lstrip(' \t')
            leading_ws = line[:len(line) - len(stripped)]

            if '\t' in leading_ws:
                if self.strict:
                    raise ToonDecodeError(f"Line {line_num}: Tabs are not allowed in indentation")

            # Calculate depth from spaces only
            leading_spaces = len(line) - len(line.lstrip(' '))

            # Validate indentation in strict mode
            if self.strict and leading_spaces % self.indent_size != 0:
                raise ToonDecodeError(
                    f"Line {line_num}: Indentation must be an exact multiple of {self.indent_size} spaces"
                )

            depth = leading_spaces // self.indent_size
            content = line.lstrip()

            lines.append((depth, content))

        return lines

    def _decode_root(self, lines: list[tuple[int, str]]) -> Any:
        """Decode root value from lines."""
        if not lines:
            return {}

        first_depth, first_line = lines[0]

        if first_depth != 0:
            raise ToonDecodeError("First line must be at depth 0")

        # Check if it's a root array header (starts with [ , no key before it)
        if self._is_array_header(first_line) and first_line.strip().startswith('['):
            return self._decode_array_at_index(lines, 0)[0]

        # Check if it's a single primitive (exactly one line, not a key:value)
        if len(lines) == 1 and ':' not in self._find_unquoted_char(first_line, ':'):
            return self._decode_primitive(first_line, ",")

        # Otherwise, it's an object
        return self._decode_object_at_index(lines, 0, -1)[0]

    def _decode_object_at_index(
        self,
        lines: list[tuple[int, str]],
        start_idx: int,
        parent_depth: int
    ) -> tuple[dict, int]:
        """
        Decode an object starting at given index.

        Args:
            lines: All lines
            start_idx: Index to start decoding
            parent_depth: Depth of parent structure

        Returns:
            (decoded_object, next_index)
        """
        obj = {}
        current_depth = parent_depth + 1
        idx = start_idx

        while idx < len(lines):
            depth, line = lines[idx]

            # If we're back to parent depth or less, we're done
            if depth <= parent_depth:
                break

            # Skip lines deeper than current depth (they belong to nested structures)
            if depth > current_depth:
                idx += 1
                continue

            # Check if this line contains an array header
            if self._is_array_header(line):
                # Parse the full line as an array with its key
                key, arr, idx = self._parse_keyed_array(lines, idx, depth)
                obj[key] = arr
            else:
                # Parse key-value line
                key, value_part = self._parse_key_value_line(line)

                if value_part is None:
                    # key: alone - nested object or empty
                    # Check if there are nested fields
                    if idx + 1 < len(lines) and lines[idx + 1][0] > depth:
                        obj[key], idx = self._decode_object_at_index(lines, idx + 1, depth)
                    else:
                        obj[key] = {}
                        idx += 1
                else:
                    # It's a primitive
                    obj[key] = self._decode_primitive(value_part, ",")
                    idx += 1

        return obj, idx

    def _decode_array_at_index(
        self,
        lines: list[tuple[int, str]],
        start_idx: int
    ) -> tuple[list, int]:
        """
        Decode a root array starting at given index.

        Args:
            lines: All lines
            start_idx: Index to start decoding

        Returns:
            (decoded_array, next_index)
        """
        depth, line = lines[start_idx]
        # For root arrays, the parent_depth should be the depth of the header itself
        return self._decode_array_with_header(lines, start_idx, depth, line)

    def _decode_array_with_header(
        self,
        lines: list[tuple[int, str]],
        header_idx: int,
        parent_depth: int,
        header_line: str
    ) -> tuple[list, int]:
        """
        Decode an array given its header.

        Args:
            lines: All lines
            header_idx: Index of the header line
            parent_depth: Depth of parent
            header_line: The header line content

        Returns:
            (decoded_array, next_index)
        """
        # Parse header
        length, delimiter, fields, inline_values = self._parse_array_header(header_line)

        # If inline values exist, it's an inline primitive array
        if inline_values is not None:
            arr = self._decode_inline_array(inline_values, delimiter, length)
            return arr, header_idx + 1

        # If fields exist, it's a tabular array
        if fields:
            return self._decode_tabular_array(lines, header_idx, parent_depth, length, delimiter, fields)

        # Otherwise, it's an expanded list array
        return self._decode_expanded_array(lines, header_idx, parent_depth, length, delimiter)

    def _parse_array_header(self, line: str) -> tuple[int, str, Optional[list[str]], Optional[str]]:
        """
        Parse array header line.

        Returns:
            (length, delimiter, fields, inline_values)
        """
        # Remove key if present
        if ':' in line:
            before_colon = line[:line.rindex(':')]
            after_colon = line[line.rindex(':') + 1:].strip()
        else:
            raise ToonDecodeError("Missing colon after key")

        # Extract bracket segment
        bracket_match = re.search(r'\[#?(\d+)([\t|])?\]', before_colon)
        if not bracket_match:
            raise ToonDecodeError(f"Invalid array header: {line}")

        length = int(bracket_match.group(1))
        delim_char = bracket_match.group(2)

        if delim_char == '\t':
            delimiter = '\t'
        elif delim_char == '|':
            delimiter = '|'
        else:
            delimiter = ','

        # Check for fields segment
        fields = None
        fields_match = re.search(r'\{([^}]+)\}', before_colon)
        if fields_match:
            fields_str = fields_match.group(1)
            fields = self._split_by_delimiter(fields_str, delimiter)
            fields = [self._decode_key(f.strip()) for f in fields]

        # Check for inline values
        inline_values = after_colon if after_colon else None

        return length, delimiter, fields, inline_values

    def _decode_inline_array(self, values_str: str, delimiter: str, expected_length: int) -> list:
        """Decode an inline primitive array."""
        if not values_str:
            arr = []
        else:
            parts = self._split_by_delimiter(values_str, delimiter)
            arr = [self._decode_primitive(p.strip(), delimiter) for p in parts]

        if self.strict and len(arr) != expected_length:
            raise ToonDecodeError(
                f"Expected {expected_length} values in inline array, got {len(arr)}"
            )

        return arr

    def _decode_tabular_array(
        self,
        lines: list[tuple[int, str]],
        header_idx: int,
        parent_depth: int,
        expected_length: int,
        delimiter: str,
        fields: list[str]
    ) -> tuple[list, int]:
        """Decode a tabular array."""
        arr = []
        idx = header_idx + 1
        # Rows are at the depth of the header line + 1
        header_depth, _ = lines[header_idx]
        row_depth = header_depth + 1

        while idx < len(lines):
            depth, line = lines[idx]

            # Check if we're still in the array
            if depth < row_depth:
                break
            if depth > row_depth:
                idx += 1
                continue

            # Check if this is a row or a new key-value line
            if self._is_tabular_row(line, delimiter):
                # It's a row
                parts = self._split_by_delimiter(line, delimiter)

                if self.strict and len(parts) != len(fields):
                    raise ToonDecodeError(
                        f"Expected {len(fields)} values in tabular row, got {len(parts)}"
                    )

                obj = {}
                for i, field in enumerate(fields):
                    if i < len(parts):
                        obj[field] = self._decode_primitive(parts[i].strip(), delimiter)

                arr.append(obj)
                idx += 1
            else:
                # It's a key-value line, end of tabular rows
                break

        if self.strict and len(arr) != expected_length:
            raise ToonDecodeError(
                f"Expected {expected_length} rows in tabular array, got {len(arr)}"
            )

        return arr, idx

    def _decode_expanded_array(
        self,
        lines: list[tuple[int, str]],
        header_idx: int,
        parent_depth: int,
        expected_length: int,
        delimiter: str
    ) -> tuple[list, int]:
        """Decode an expanded list array."""
        arr = []
        idx = header_idx + 1
        # Items are at the depth of the header line + 1
        header_depth, _ = lines[header_idx]
        item_depth = header_depth + 1

        while idx < len(lines):
            depth, line = lines[idx]

            if depth < item_depth:
                break
            if depth > item_depth:
                idx += 1
                continue

            # Each item should start with "- "
            if not line.startswith('- '):
                break

            item_content = line[2:]  # Remove "- "

            # Determine item type
            if self._is_array_header(item_content):
                # Inline array item
                _, item_delim, _, inline_vals = self._parse_array_header(item_content)
                item_length = int(re.search(r'\[#?(\d+)', item_content).group(1))
                item = self._decode_inline_array(inline_vals or "", item_delim, item_length)
                arr.append(item)
                idx += 1
            elif ':' in self._find_unquoted_char(item_content, ':'):
                # Object item
                item, idx = self._decode_object_list_item(lines, idx, item_depth, delimiter)
                arr.append(item)
            else:
                # Primitive item
                arr.append(self._decode_primitive(item_content, delimiter))
                idx += 1

        if self.strict and len(arr) != expected_length:
            raise ToonDecodeError(
                f"Expected {expected_length} items in array, got {len(arr)}"
            )

        return arr, idx

    def _decode_object_list_item(
        self,
        lines: list[tuple[int, str]],
        item_idx: int,
        item_depth: int,
        active_delimiter: str
    ) -> tuple[dict, int]:
        """Decode an object that appears as a list item."""
        depth, line = lines[item_idx]
        item_content = line[2:]  # Remove "- "

        obj = {}

        # Parse first field from hyphen line
        key, value_part = self._parse_key_value_line(item_content)

        if value_part is None:
            # Nested object first field
            if item_idx + 1 < len(lines) and lines[item_idx + 1][0] > item_depth + 1:
                obj[key], next_idx = self._decode_object_at_index(lines, item_idx + 1, item_depth + 1)
            else:
                obj[key] = {}
                next_idx = item_idx + 1
        elif self._is_array_header(value_part):
            # Array first field
            arr, next_idx = self._decode_array_with_header(lines, item_idx, item_depth, item_content)
            # Extract key from the line
            key = item_content.split('[')[0].strip()
            if key.startswith('"'):
                key = self._decode_key(key)
            obj[key] = arr
        else:
            # Primitive first field
            obj[key] = self._decode_primitive(value_part, active_delimiter)
            next_idx = item_idx + 1

        # Parse remaining fields at item_depth + 1
        field_depth = item_depth + 1
        idx = next_idx

        while idx < len(lines):
            depth, line = lines[idx]

            if depth < field_depth:
                break
            if depth > field_depth:
                idx += 1
                continue

            # Don't process lines starting with "- " (new list items)
            if line.startswith('- '):
                break

            key, value_part = self._parse_key_value_line(line)

            if value_part is None:
                # Nested object
                if idx + 1 < len(lines) and lines[idx + 1][0] > depth:
                    obj[key], idx = self._decode_object_at_index(lines, idx + 1, depth)
                else:
                    obj[key] = {}
                    idx += 1
            elif self._is_array_header(value_part):
                # Array
                arr, idx = self._decode_array_with_header(lines, idx, depth, line)
                obj[key] = arr
            else:
                # Primitive
                obj[key] = self._decode_primitive(value_part, active_delimiter)
                idx += 1

        return obj, idx

    def _is_array_header(self, line: str) -> bool:
        """Check if a line is an array header."""
        return bool(re.search(r'\[#?\d+[\t|]?\]', line))

    def _is_tabular_row(self, line: str, delimiter: str) -> bool:
        """
        Check if a line is a tabular row vs a key-value line.

        A tabular row either has no unquoted colon, or has an unquoted delimiter
        before the first unquoted colon.
        """
        delim_pos = self._find_first_unquoted(line, delimiter)
        colon_pos = self._find_first_unquoted(line, ':')

        if colon_pos == -1:
            # No colon means it's a row
            return True
        if delim_pos == -1:
            # Colon but no delimiter means it's a key-value line
            return False

        # Both exist: delimiter before colon means row
        return delim_pos < colon_pos

    def _parse_keyed_array(
        self,
        lines: list[tuple[int, str]],
        header_idx: int,
        parent_depth: int
    ) -> tuple[str, list, int]:
        """
        Parse an array that has a key (e.g., "key[N]: ...").

        Returns:
            (key, array, next_index)
        """
        depth, line = lines[header_idx]

        # Extract key from the line
        # Find the bracket position
        bracket_pos = line.find('[')
        if bracket_pos == -1:
            raise ToonDecodeError(f"Invalid array header: {line}")

        key_part = line[:bracket_pos].strip()
        key = self._decode_key(key_part)

        # Parse the array
        arr, next_idx = self._decode_array_with_header(lines, header_idx, parent_depth, line)

        return key, arr, next_idx

    def _parse_key_value_line(self, line: str) -> tuple[str, Optional[str]]:
        """
        Parse a key-value line.

        Returns:
            (key, value_part) where value_part is None if just "key:"
        """
        colon_pos = self._find_first_unquoted(line, ':')
        if colon_pos == -1:
            if self.strict:
                raise ToonDecodeError(f"Missing colon after key: {line}")
            return line, None

        key_part = line[:colon_pos].strip()
        value_part = line[colon_pos + 1:].strip()

        key = self._decode_key(key_part)

        return key, value_part if value_part else None

    def _decode_key(self, key: str) -> str:
        """Decode a key (quoted or unquoted)."""
        if key.startswith('"') and key.endswith('"'):
            return self._unescape_string(key[1:-1])
        return key

    def _decode_primitive(self, token: str, active_delimiter: str) -> Any:
        """Decode a primitive value."""
        token = token.strip()

        # Quoted string
        if token.startswith('"') and token.endswith('"'):
            return self._unescape_string(token[1:-1])

        # Boolean and null
        if token == 'true':
            return True
        if token == 'false':
            return False
        if token == 'null':
            return None

        # Try to parse as number
        try:
            # Check for forbidden leading zeros
            if re.match(r'^0\d+$', token):
                return token  # It's a string

            # Try integer first
            if '.' not in token and 'e' not in token.lower():
                return int(token)

            # Try float
            return float(token)
        except ValueError:
            # It's a string
            return token

    def _unescape_string(self, s: str) -> str:
        """Unescape a string."""
        result = []
        i = 0
        while i < len(s):
            if s[i] == '\\':
                if i + 1 >= len(s):
                    if self.strict:
                        raise ToonDecodeError("Unterminated string: missing closing quote")
                    result.append('\\')
                    i += 1
                    continue

                next_char = s[i + 1]
                if next_char == '\\':
                    result.append('\\')
                elif next_char == '"':
                    result.append('"')
                elif next_char == 'n':
                    result.append('\n')
                elif next_char == 'r':
                    result.append('\r')
                elif next_char == 't':
                    result.append('\t')
                else:
                    if self.strict:
                        raise ToonDecodeError(f"Invalid escape sequence: \\{next_char}")
                    result.append(next_char)
                i += 2
            else:
                result.append(s[i])
                i += 1

        return ''.join(result)

    def _split_by_delimiter(self, text: str, delimiter: str) -> list[str]:
        """Split text by delimiter, respecting quoted strings."""
        parts = []
        current = []
        in_quotes = False
        escaped = False

        for char in text:
            if escaped:
                current.append(char)
                escaped = False
            elif char == '\\':
                current.append(char)
                escaped = True
            elif char == '"':
                current.append(char)
                in_quotes = not in_quotes
            elif char == delimiter and not in_quotes:
                parts.append(''.join(current))
                current = []
            else:
                current.append(char)

        if current or text.endswith(delimiter):
            parts.append(''.join(current))

        return parts

    def _find_first_unquoted(self, text: str, char: str) -> int:
        """Find the first unquoted occurrence of a character."""
        in_quotes = False
        escaped = False

        for i, c in enumerate(text):
            if escaped:
                escaped = False
                continue
            if c == '\\':
                escaped = True
                continue
            if c == '"':
                in_quotes = not in_quotes
                continue
            if c == char and not in_quotes:
                return i

        return -1

    def _find_unquoted_char(self, text: str, char: str) -> str:
        """Return original text if char found unquoted, else empty string."""
        return text if self._find_first_unquoted(text, char) >= 0 else ""

