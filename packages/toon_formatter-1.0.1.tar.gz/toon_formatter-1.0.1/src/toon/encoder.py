"""TOON encoder - converts Python data structures to TOON format."""

from typing import Any, Union
import re


class ToonEncoder:
    """Encodes Python data structures to TOON format."""

    def __init__(self, indent: int = 2, delimiter: str = ",", length_marker: bool = False):
        """
        Initialize encoder.

        Args:
            indent: Number of spaces per indentation level (default: 2)
            delimiter: Document delimiter - ",", "\t", or "|" (default: ",")
            length_marker: Whether to include # length marker (default: False)
        """
        if delimiter not in [",", "\t", "|"]:
            raise ValueError("delimiter must be ',', '\\t', or '|'")
        if indent < 1:
            raise ValueError("indent must be at least 1")

        self.indent_size = indent
        self.delimiter = delimiter
        self.length_marker = length_marker

    def encode(self, obj: Any) -> str:
        """
        Encode Python object to TOON string.

        Args:
            obj: The object to encode

        Returns:
            TOON formatted string
        """
        normalized = self._normalize(obj)
        lines = self._encode_value(normalized, depth=0, is_root=True)
        return "\n".join(lines) if lines else ""

    def _normalize(self, value: Any) -> Any:
        """Normalize value to JSON-compatible types."""
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            if isinstance(value, float):
                if value != value:  # NaN
                    return None
                if value == float('inf') or value == float('-inf'):
                    return None
                if value == -0.0:
                    return 0
            return value
        if isinstance(value, str):
            return value
        if isinstance(value, (list, tuple)):
            return [self._normalize(v) for v in value]
        if isinstance(value, dict):
            return {str(k): self._normalize(v) for k, v in value.items()}
        if isinstance(value, set):
            return [self._normalize(v) for v in value]
        # Unsupported types become null
        return None

    def _encode_value(
        self,
        value: Any,
        depth: int = 0,
        key: str = None,
        is_root: bool = False,
        active_delimiter: str = None
    ) -> list[str]:
        """
        Encode a value recursively.

        Args:
            value: Value to encode
            depth: Current indentation depth
            key: Optional key for this value
            is_root: Whether this is the root value
            active_delimiter: Active delimiter in current array scope

        Returns:
            List of lines
        """
        # Use document delimiter if no active delimiter
        if active_delimiter is None:
            active_delimiter = self.delimiter

        indent = " " * (depth * self.indent_size)

        if value is None or isinstance(value, bool):
            primitive = self._encode_primitive(value, active_delimiter)
            if key:
                return [f"{indent}{self._encode_key(key)}: {primitive}"]
            return [f"{indent}{primitive}"] if is_root else [primitive]

        if isinstance(value, (int, float)):
            primitive = self._encode_number(value)
            if key:
                return [f"{indent}{self._encode_key(key)}: {primitive}"]
            return [f"{indent}{primitive}"] if is_root else [primitive]

        if isinstance(value, str):
            primitive = self._encode_string(value, active_delimiter)
            if key:
                return [f"{indent}{self._encode_key(key)}: {primitive}"]
            return [f"{indent}{primitive}"] if is_root else [primitive]

        if isinstance(value, list):
            return self._encode_array(value, depth, key, is_root, active_delimiter)

        if isinstance(value, dict):
            return self._encode_object(value, depth, key, is_root, active_delimiter)

        return []

    def _encode_primitive(self, value: Any, active_delimiter: str) -> str:
        """Encode a primitive value."""
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return self._encode_number(value)
        return self._encode_string(str(value), active_delimiter)

    def _encode_number(self, num: Union[int, float]) -> str:
        """Encode a number without scientific notation."""
        if isinstance(num, float):
            # Handle special cases
            if num == -0.0:
                return "0"
            # Use Python's default string conversion which provides good precision
            s = str(num)
            # If it contains 'e' or 'E', it's in scientific notation - convert it
            if 'e' in s.lower():
                # For very large or very small numbers, use formatted output
                if abs(num) < 1e-6 or abs(num) > 1e15:
                    s = f"{num:.17f}".rstrip('0').rstrip('.')
                else:
                    s = str(num)
            return s
        return str(num)

    def _encode_string(self, s: str, active_delimiter: str) -> str:
        """Encode a string with proper quoting and escaping."""
        if self._needs_quoting(s, active_delimiter):
            return '"' + self._escape_string(s) + '"'
        return s

    def _needs_quoting(self, s: str, active_delimiter: str) -> bool:
        """Check if a string needs quoting."""
        if not s:
            return True
        if s[0].isspace() or s[-1].isspace():
            return True
        if s in ("true", "false", "null"):
            return True
        if s.startswith("-"):
            return True
        # Check if numeric-like
        if re.match(r'^-?\d+(?:\.\d+)?(?:e[+-]?\d+)?$', s, re.IGNORECASE):
            return True
        if re.match(r'^0\d+$', s):
            return True
        if any(c in s for c in [':', '"', '\\', '[', ']', '{', '}', '\n', '\r', '\t']):
            return True
        if active_delimiter in s:
            return True
        return False

    def _escape_string(self, s: str) -> str:
        """Escape special characters in a string."""
        s = s.replace('\\', '\\\\')
        s = s.replace('"', '\\"')
        s = s.replace('\n', '\\n')
        s = s.replace('\r', '\\r')
        s = s.replace('\t', '\\t')
        return s

    def _encode_key(self, key: str) -> str:
        """Encode an object key."""
        if re.match(r'^[A-Za-z_][\w.]*$', key):
            return key
        return '"' + self._escape_string(key) + '"'

    def _encode_object(
        self,
        obj: dict,
        depth: int,
        key: str = None,
        is_root: bool = False,
        active_delimiter: str = None
    ) -> list[str]:
        """Encode an object."""
        indent = " " * (depth * self.indent_size)

        if not obj:
            # Empty object
            if is_root:
                return []
            if key:
                return [f"{indent}{self._encode_key(key)}:"]
            return []

        lines = []

        # If this object has a key, add the key line first
        if key:
            lines.append(f"{indent}{self._encode_key(key)}:")
            depth += 1
            indent = " " * (depth * self.indent_size)

        # Encode each field
        for k, v in obj.items():
            field_lines = self._encode_value(v, depth, k, False, active_delimiter)
            lines.extend(field_lines)

        return lines

    def _encode_array(
        self,
        arr: list,
        depth: int,
        key: str = None,
        is_root: bool = False,
        parent_delimiter: str = None
    ) -> list[str]:
        """Encode an array."""
        if parent_delimiter is None:
            parent_delimiter = self.delimiter

        indent = " " * (depth * self.indent_size)

        # Determine array type and encoding strategy
        if not arr:
            # Empty array
            header = self._make_header(0, key, parent_delimiter)
            return [f"{indent}{header}"]

        if self._is_primitive_array(arr):
            # Inline primitive array
            return self._encode_inline_array(arr, depth, key, parent_delimiter)

        if self._is_tabular_array(arr):
            # Tabular array
            return self._encode_tabular_array(arr, depth, key, parent_delimiter)

        if self._is_array_of_primitive_arrays(arr):
            # Expanded list of arrays
            return self._encode_array_of_arrays(arr, depth, key, parent_delimiter)

        # Mixed/non-uniform array - expanded list
        return self._encode_expanded_array(arr, depth, key, parent_delimiter)

    def _is_primitive_array(self, arr: list) -> bool:
        """Check if array contains only primitives."""
        return all(
            v is None or isinstance(v, (bool, int, float, str))
            for v in arr
        )

    def _is_tabular_array(self, arr: list) -> bool:
        """Check if array is suitable for tabular encoding."""
        if not arr:
            return False
        if not all(isinstance(item, dict) for item in arr):
            return False
        if not arr[0]:  # First object is empty
            return False

        # Get keys from first object
        first_keys = set(arr[0].keys())

        # Check all objects have same keys and all values are primitives
        for item in arr:
            if set(item.keys()) != first_keys:
                return False
            if not all(
                v is None or isinstance(v, (bool, int, float, str))
                for v in item.values()
            ):
                return False
        return True

    def _is_array_of_primitive_arrays(self, arr: list) -> bool:
        """Check if array contains only primitive arrays."""
        return all(
            isinstance(item, list) and self._is_primitive_array(item)
            for item in arr
        )

    def _make_header(
        self,
        length: int,
        key: str = None,
        delimiter: str = None,
        fields: list[str] = None
    ) -> str:
        """Create an array header."""
        if delimiter is None:
            delimiter = self.delimiter

        # Build bracket segment
        marker = "#" if self.length_marker else ""
        if delimiter == "\t":
            delim_char = "\t"
        elif delimiter == "|":
            delim_char = "|"
        else:
            delim_char = ""

        bracket = f"[{marker}{length}{delim_char}]"

        # Add fields if provided
        if fields:
            encoded_fields = [self._encode_key(f) for f in fields]
            fields_seg = "{" + delimiter.join(encoded_fields) + "}"
            bracket = bracket + fields_seg

        # Add key if provided
        if key:
            return f"{self._encode_key(key)}{bracket}:"
        return f"{bracket}:"

    def _encode_inline_array(
        self,
        arr: list,
        depth: int,
        key: str = None,
        parent_delimiter: str = None
    ) -> list[str]:
        """Encode an inline primitive array."""
        indent = " " * (depth * self.indent_size)
        header = self._make_header(len(arr), key, parent_delimiter)

        if not arr:
            return [f"{indent}{header}"]

        # Encode values with active delimiter
        values = [self._encode_primitive(v, parent_delimiter) for v in arr]
        values_str = parent_delimiter.join(values)

        return [f"{indent}{header} {values_str}"]

    def _encode_tabular_array(
        self,
        arr: list,
        depth: int,
        key: str = None,
        parent_delimiter: str = None
    ) -> list[str]:
        """Encode a tabular array."""
        indent = " " * (depth * self.indent_size)
        row_indent = " " * ((depth + 1) * self.indent_size)

        # Get field names from first object
        fields = list(arr[0].keys())
        header = self._make_header(len(arr), key, parent_delimiter, fields)

        lines = [f"{indent}{header}"]

        # Encode each row
        for item in arr:
            values = [self._encode_primitive(item[f], parent_delimiter) for f in fields]
            row = parent_delimiter.join(values)
            lines.append(f"{row_indent}{row}")

        return lines

    def _encode_array_of_arrays(
        self,
        arr: list,
        depth: int,
        key: str = None,
        parent_delimiter: str = None
    ) -> list[str]:
        """Encode an array of primitive arrays."""
        indent = " " * (depth * self.indent_size)
        item_indent = " " * ((depth + 1) * self.indent_size)

        header = self._make_header(len(arr), key, parent_delimiter)
        lines = [f"{indent}{header}"]

        for item in arr:
            item_header = self._make_header(len(item), None, parent_delimiter)
            if item:
                values = [self._encode_primitive(v, parent_delimiter) for v in item]
                values_str = parent_delimiter.join(values)
                lines.append(f"{item_indent}- {item_header} {values_str}")
            else:
                lines.append(f"{item_indent}- {item_header}")

        return lines

    def _encode_expanded_array(
        self,
        arr: list,
        depth: int,
        key: str = None,
        parent_delimiter: str = None
    ) -> list[str]:
        """Encode a mixed/non-uniform array as expanded list."""
        indent = " " * (depth * self.indent_size)
        item_indent = " " * ((depth + 1) * self.indent_size)

        header = self._make_header(len(arr), key, parent_delimiter)
        lines = [f"{indent}{header}"]

        for item in arr:
            if item is None or isinstance(item, (bool, int, float, str)):
                # Primitive item
                primitive = self._encode_primitive(item, parent_delimiter)
                lines.append(f"{item_indent}- {primitive}")
            elif isinstance(item, list) and self._is_primitive_array(item):
                # Inline array item
                item_header = self._make_header(len(item), None, parent_delimiter)
                if item:
                    values = [self._encode_primitive(v, parent_delimiter) for v in item]
                    values_str = parent_delimiter.join(values)
                    lines.append(f"{item_indent}- {item_header} {values_str}")
                else:
                    lines.append(f"{item_indent}- {item_header}")
            elif isinstance(item, dict):
                # Object item
                lines.extend(self._encode_object_as_list_item(item, depth + 1, parent_delimiter))
            else:
                # Complex nested structures
                lines.append(f"{item_indent}- null")

        return lines

    def _encode_object_as_list_item(
        self,
        obj: dict,
        depth: int,
        active_delimiter: str
    ) -> list[str]:
        """Encode an object as a list item."""
        item_indent = " " * (depth * self.indent_size)
        field_indent = " " * ((depth + 1) * self.indent_size)

        if not obj:
            return [f"{item_indent}-"]

        lines = []
        keys = list(obj.keys())

        # First field on hyphen line
        first_key = keys[0]
        first_value = obj[first_key]

        if first_value is None or isinstance(first_value, (bool, int, float, str)):
            # Primitive first field
            primitive = self._encode_primitive(first_value, active_delimiter)
            lines.append(f"{item_indent}- {self._encode_key(first_key)}: {primitive}")
        elif isinstance(first_value, list):
            # Array first field
            if self._is_primitive_array(first_value):
                header = self._make_header(len(first_value), first_key, active_delimiter)
                if first_value:
                    values = [self._encode_primitive(v, active_delimiter) for v in first_value]
                    values_str = active_delimiter.join(values)
                    lines.append(f"{item_indent}- {header} {values_str}")
                else:
                    lines.append(f"{item_indent}- {header}")
            elif self._is_tabular_array(first_value):
                # Tabular array on hyphen line
                fields = list(first_value[0].keys())
                header = self._make_header(len(first_value), first_key, active_delimiter, fields)
                lines.append(f"{item_indent}- {header}")

                # Rows at depth + 1
                row_indent = " " * ((depth + 1) * self.indent_size)
                for row_obj in first_value:
                    values = [self._encode_primitive(row_obj[f], active_delimiter) for f in fields]
                    row = active_delimiter.join(values)
                    lines.append(f"{row_indent}{row}")
            else:
                # Non-uniform array on hyphen line
                header = self._make_header(len(first_value), first_key, active_delimiter)
                lines.append(f"{item_indent}- {header}")
                # Items at depth + 1 would go here, but simplified for now
        else:
            # Object first field
            lines.append(f"{item_indent}- {self._encode_key(first_key)}:")
            # Nested fields at depth + 2
            nested_lines = self._encode_value(first_value, depth + 2, None, False, active_delimiter)
            lines.extend(nested_lines)

        # Remaining fields at depth + 1
        for key in keys[1:]:
            value = obj[key]
            field_lines = self._encode_value(value, depth + 1, key, False, active_delimiter)
            lines.extend(field_lines)

        return lines
