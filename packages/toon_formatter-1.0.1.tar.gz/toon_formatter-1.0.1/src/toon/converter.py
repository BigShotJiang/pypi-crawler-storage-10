"""Converters between TOON and other formats (JSON, CSV, XML)."""

import json
import csv
from io import StringIO
from typing import Any, Union
from xml.etree import ElementTree as ET
from xml.dom import minidom

from .encoder import ToonEncoder
from .decoder import ToonDecoder


class ToonConverter:
    """Converts between TOON and other data formats."""

    def __init__(
            self,
            indent: int = 2,
            delimiter: str = ",",
            length_marker: bool = False,
            strict: bool = True
    ):
        """
        Initialize converter.

        Args:
            indent: Indentation size (default: 2)
            delimiter: TOON delimiter - ",", "\t", or "|" (default: ",")
            length_marker: Whether to include # length marker (default: False)
            strict: Enable strict mode for decoding (default: True)
        """
        self.encoder = ToonEncoder(indent, delimiter, length_marker)
        self.decoder = ToonDecoder(indent, strict)

    # JSON conversions
    def json_to_toon(self, json_str: str) -> str:
        """
        Convert JSON string to TOON format.

        Args:
            json_str: JSON string

        Returns:
            TOON formatted string
        """
        data = json.loads(json_str)
        return self.encoder.encode(data)

    def toon_to_json(self, toon_str: str, indent: int = 2) -> str:
        """
        Convert TOON string to JSON format.

        Args:
            toon_str: TOON string
            indent: JSON indentation (default: 2)

        Returns:
            JSON formatted string
        """
        data = self.decoder.decode(toon_str)
        return json.dumps(data, indent=indent, ensure_ascii=False)

    # CSV conversions
    def csv_to_toon(
            self,
            csv_str: str,
            has_header: bool = True,
            csv_delimiter: str = ","
    ) -> str:
        """
        Convert CSV string to TOON format.

        Args:
            csv_str: CSV string
            has_header: Whether CSV has a header row (default: True)
            csv_delimiter: CSV delimiter character (default: ",")

        Returns:
            TOON formatted string (tabular array)
        """
        reader = csv.reader(StringIO(csv_str), delimiter=csv_delimiter)
        rows = list(reader)

        if not rows:
            return self.encoder.encode([])

        if has_header:
            headers = rows[0]
            data_rows = rows[1:]
        else:
            # Generate column names
            headers = [f"col{i}" for i in range(len(rows[0]))]
            data_rows = rows

        # Convert to list of dicts
        data = []
        for row in data_rows:
            obj = {}
            for i, header in enumerate(headers):
                if i < len(row):
                    # Try to infer type
                    value = self._infer_type(row[i])
                    obj[header] = value
            data.append(obj)

        return self.encoder.encode(data)

    def toon_to_csv(
            self,
            toon_str: str,
            csv_delimiter: str = ","
    ) -> str:
        """
        Convert TOON string to CSV format.

        Args:
            toon_str: TOON string
            csv_delimiter: CSV delimiter character (default: ",")

        Returns:
            CSV formatted string

        Raises:
            ValueError: If TOON data is not a list of objects
        """
        data = self.decoder.decode(toon_str)

        if not isinstance(data, list):
            raise ValueError("TOON data must be a list for CSV conversion")

        if not data:
            return ""

        # Ensure all items are objects
        if not all(isinstance(item, dict) for item in data):
            raise ValueError("All list items must be objects for CSV conversion")

        # Get all unique keys preserving order
        headers = []
        seen = set()
        for item in data:
            for key in item.keys():
                if key not in seen:
                    headers.append(key)
                    seen.add(key)

        # Write CSV
        output = StringIO()
        writer = csv.writer(output, delimiter=csv_delimiter)
        writer.writerow(headers)

        for item in data:
            row = [self._serialize_value(item.get(h)) for h in headers]
            writer.writerow(row)

        return output.getvalue().rstrip('\n')

    # XML conversions
    def xml_to_toon(self, xml_str: str) -> str:
        """
        Convert XML string to TOON format.

        Args:
            xml_str: XML string

        Returns:
            TOON formatted string
        """
        root = ET.fromstring(xml_str)
        data = self._xml_element_to_dict(root)
        return self.encoder.encode(data)

    def toon_to_xml(
            self,
            toon_str: str,
            root_name: str = "root",
            item_name: str = "item"
    ) -> str:
        """
        Convert TOON string to XML format.

        Args:
            toon_str: TOON string
            root_name: Name for root element (default: "root")
            item_name: Name for list items (default: "item")

        Returns:
            XML formatted string
        """
        data = self.decoder.decode(toon_str)
        root = self._dict_to_xml_element(data, root_name, item_name)

        # Pretty print
        rough_string = ET.tostring(root, encoding='unicode')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ").split('\n', 1)[1]  # Skip XML declaration

    # Helper methods
    @staticmethod
    def _infer_type(value: str) -> Union[str, int, float, bool, None]:
        """Infer the type of string value."""
        value = value.strip()

        if not value:
            return ""

        # Boolean
        if value.lower() == 'true':
            return True
        if value.lower() == 'false':
            return False

        # Null
        if value.lower() in ('null', 'none', ''):
            return None

        # Number
        try:
            if '.' in value or 'e' in value.lower():
                return float(value)
            return int(value)
        except ValueError:
            pass

        return value

    @staticmethod
    def _serialize_value(value: Any) -> str:
        """Serialize a value for CSV output."""
        if value is None:
            return ""
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (list, dict)):
            return json.dumps(value)
        return str(value)

    def _xml_element_to_dict(self, element: ET.Element) -> Any:
        """Convert XML element to Python dict/list."""
        # Get attributes
        result = {}

        if element.attrib:
            result['@attributes'] = dict(element.attrib)

        # Get text content
        text = (element.text or "").strip()

        # Get children
        children = list(element)

        if not children:
            # Leaf node
            if text:
                if result:
                    result['@text'] = self._infer_type(text)
                    return result
                return self._infer_type(text)
            return result if result else None

        # Group children by tag
        child_groups = {}
        for child in children:
            tag = child.tag
            if tag not in child_groups:
                child_groups[tag] = []
            child_groups[tag].append(child)

        # Convert children
        for tag, elements in child_groups.items():
            if len(elements) == 1:
                result[tag] = self._xml_element_to_dict(elements[0])
            else:
                result[tag] = [self._xml_element_to_dict(e) for e in elements]

        # Add text if present
        if text:
            result['@text'] = text

        return result

    def _dict_to_xml_element(
            self,
            data: Any,
            tag: str,
            item_name: str = "item"
    ) -> ET.Element:
        """Convert Python dict/list to XML element."""
        element = ET.Element(tag)

        if data is None:
            return element

        if isinstance(data, (str, int, float, bool)):
            element.text = str(data)
            return element

        if isinstance(data, list):
            # Create wrapper element with children
            for i, item in enumerate(data):
                child = self._dict_to_xml_element(item, item_name, item_name)
                element.append(child)
            return element

        if isinstance(data, dict):
            # Handle attributes
            if '@attributes' in data:
                for key, value in data['@attributes'].items():
                    element.set(key, str(value))

            # Handle text
            if '@text' in data:
                element.text = str(data['@text'])

            # Handle other fields
            for key, value in data.items():
                if key.startswith('@'):
                    continue

                if isinstance(value, list):
                    for item in value:
                        child = self._dict_to_xml_element(item, key, item_name)
                        element.append(child)
                else:
                    child = self._dict_to_xml_element(value, key, item_name)
                    element.append(child)

        return element
