"""TOON CLI - Command line interface for TOON format operations."""

import argparse
import sys
import json
import re
from pathlib import Path
from typing import Optional

from .encoder import ToonEncoder
from .decoder import ToonDecoder, ToonDecodeError
from .converter import ToonConverter


class ToonCLI:
    """Command-line interface for TOON operations."""

    def __init__(self):
        self.parser = self._create_parser()

    def _create_parser(self) -> argparse.ArgumentParser:
        """Create the argument parser."""
        parser = argparse.ArgumentParser(
            prog='toon',
            description='TOON (Token-Oriented Object Notation) CLI tool',
            epilog='For more information, see https://github.com/johannschopplich/toon'
        )

        subparsers = parser.add_subparsers(dest='command', help='Available commands')

        # Convert command
        convert_parser = subparsers.add_parser(
            'convert',
            help='Convert between formats (JSON/CSV/XML ↔ TOON)'
        )
        convert_parser.add_argument('input', help='Input file path')
        convert_parser.add_argument('output', help='Output file path')
        convert_parser.add_argument(
            '--from',
            dest='from_format',
            choices=['json', 'csv', 'xml', 'toon'],
            required=True,
            help='Input format'
        )
        convert_parser.add_argument(
            '--to',
            dest='to_format',
            choices=['json', 'csv', 'xml', 'toon'],
            required=True,
            help='Output format'
        )
        convert_parser.add_argument(
            '--indent',
            type=int,
            default=2,
            help='Indentation size (default: 2)'
        )
        convert_parser.add_argument(
            '--delimiter',
            choices=[',', '|', 'tab'],
            default=',',
            help='TOON delimiter (default: comma)'
        )
        convert_parser.add_argument(
            '--length-marker',
            action='store_true',
            help='Include # length marker in TOON'
        )
        convert_parser.add_argument(
            '--csv-delimiter',
            default=',',
            help='CSV delimiter character (default: comma)'
        )
        convert_parser.add_argument(
            '--no-csv-header',
            action='store_true',
            help='CSV has no header row'
        )

        # Validate command
        validate_parser = subparsers.add_parser(
            'validate',
            help='Validate TOON file'
        )
        validate_parser.add_argument('file', help='TOON file to validate')
        validate_parser.add_argument(
            '--indent',
            type=int,
            default=2,
            help='Expected indentation size (default: 2)'
        )
        validate_parser.add_argument(
            '--permissive',
            action='store_true',
            help='Use permissive mode (non-strict)'
        )

        # Format command
        format_parser = subparsers.add_parser(
            'format',
            help='Format/pretty-print TOON file'
        )
        format_parser.add_argument('input', help='Input TOON file')
        format_parser.add_argument(
            '--output',
            help='Output file (default: overwrite input)'
        )
        format_parser.add_argument(
            '--indent',
            type=int,
            default=2,
            help='Indentation size (default: 2)'
        )
        format_parser.add_argument(
            '--delimiter',
            choices=[',', '|', 'tab'],
            default=',',
            help='Delimiter (default: comma)'
        )
        format_parser.add_argument(
            '--check',
            action='store_true',
            help='Only check if formatting is needed (exit 1 if yes)'
        )

        # Minify command
        minify_parser = subparsers.add_parser(
            'minify',
            help='Optimize TOON for minimum token count'
        )
        minify_parser.add_argument('input', help='Input TOON file')
        minify_parser.add_argument(
            '--output',
            help='Output file (default: overwrite input)'
        )

        # Info command
        info_parser = subparsers.add_parser(
            'info',
            help='Show information about TOON file'
        )
        info_parser.add_argument('file', help='TOON file to analyze')
        info_parser.add_argument(
            '--verbose',
            '-v',
            action='store_true',
            help='Show detailed information'
        )

        # Diff command
        diff_parser = subparsers.add_parser(
            'diff',
            help='Compare two TOON files'
        )
        diff_parser.add_argument('file1', help='First TOON file')
        diff_parser.add_argument('file2', help='Second TOON file')
        diff_parser.add_argument(
            '--semantic',
            action='store_true',
            help='Compare decoded values (ignore formatting)'
        )

        return parser

    def run(self, args: Optional[list[str]] = None) -> int:
        """Run the CLI with given arguments."""
        parsed_args = self.parser.parse_args(args)

        if not parsed_args.command:
            self.parser.print_help()
            return 1

        try:
            command_method = getattr(self, f'_cmd_{parsed_args.command}')
            return command_method(parsed_args)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    def _cmd_convert(self, args) -> int:
        """Handle convert command."""
        # Read input file
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"Error: Input file '{args.input}' not found", file=sys.stderr)
            return 1

        input_data = input_path.read_text(encoding='utf-8')

        # Setup converter
        delimiter = '\t' if args.delimiter == 'tab' else args.delimiter
        converter = ToonConverter(
            indent=args.indent,
            delimiter=delimiter,
            length_marker=args.length_marker,
            strict=True
        )

        # Convert
        output_data = self._convert_data(
            input_data,
            args.from_format,
            args.to_format,
            converter,
            args
        )

        # Write output
        output_path = Path(args.output)
        output_path.write_text(output_data, encoding='utf-8')

        print(f"✓ Converted {args.from_format.upper()} → {args.to_format.upper()}")
        print(f"  Input:  {args.input}")
        print(f"  Output: {args.output}")

        return 0

    def _convert_data(self, data: str, from_fmt: str, to_fmt: str, converter: ToonConverter, args) -> str:
        """Convert data between formats."""
        # First, get data into Python
        if from_fmt == 'json':
            python_data = json.loads(data)
        elif from_fmt == 'csv':
            decoder = ToonDecoder()
            toon = converter.csv_to_toon(
                data,
                has_header=not args.no_csv_header,
                csv_delimiter=args.csv_delimiter
            )
            python_data = decoder.decode(toon)
        elif from_fmt == 'xml':
            decoder = ToonDecoder()
            toon = converter.xml_to_toon(data)
            python_data = decoder.decode(toon)
        elif from_fmt == 'toon':
            decoder = ToonDecoder(indent=args.indent)
            python_data = decoder.decode(data)
        else:
            raise ValueError(f"Unsupported input format: {from_fmt}")

        # Then, convert to output format
        if to_fmt == 'json':
            return json.dumps(python_data, indent=args.indent, ensure_ascii=False)
        elif to_fmt == 'csv':
            encoder = ToonEncoder()
            toon = encoder.encode(python_data)
            return converter.toon_to_csv(toon, csv_delimiter=args.csv_delimiter)
        elif to_fmt == 'xml':
            encoder = ToonEncoder()
            toon = encoder.encode(python_data)
            return converter.toon_to_xml(toon)
        elif to_fmt == 'toon':
            encoder = ToonEncoder(
                indent=args.indent,
                delimiter='\t' if args.delimiter == 'tab' else args.delimiter,
                length_marker=args.length_marker
            )
            return encoder.encode(python_data)
        else:
            raise ValueError(f"Unsupported output format: {to_fmt}")

    def _cmd_validate(self, args) -> int:
        """Handle validate command."""
        file_path = Path(args.file)
        if not file_path.exists():
            print(f"Error: File '{args.file}' not found", file=sys.stderr)
            return 1

        content = file_path.read_text(encoding='utf-8')
        decoder = ToonDecoder(indent=args.indent, strict=not args.permissive)

        try:
            data = decoder.decode(content)
            print(f"✓ Valid TOON file: {args.file}")
            print(f"  Mode: {'permissive' if args.permissive else 'strict'}")
            print(f"  Type: {type(data).__name__}")
            if isinstance(data, list):
                print(f"  Items: {len(data)}")
            elif isinstance(data, dict):
                print(f"  Keys: {len(data)}")
            return 0
        except ToonDecodeError as e:
            print(f"✗ Invalid TOON file: {args.file}", file=sys.stderr)
            print(f"  Error: {e}", file=sys.stderr)
            return 1

    def _cmd_format(self, args) -> int:
        """Handle format command."""
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"Error: File '{args.input}' not found", file=sys.stderr)
            return 1

        content = input_path.read_text(encoding='utf-8')

        # Decode and re-encode
        decoder = ToonDecoder(indent=args.indent)
        delimiter = '\t' if args.delimiter == 'tab' else args.delimiter
        encoder = ToonEncoder(indent=args.indent, delimiter=delimiter)

        try:
            data = decoder.decode(content)
            formatted = encoder.encode(data)

            if args.check:
                if content.strip() == formatted.strip():
                    print(f"✓ File is already formatted: {args.input}")
                    return 0
                else:
                    print(f"✗ File needs formatting: {args.input}")
                    return 1

            output_path = Path(args.output) if args.output else input_path
            output_path.write_text(formatted, encoding='utf-8')

            if args.output:
                print(f"✓ Formatted TOON written to: {args.output}")
            else:
                print(f"✓ Formatted TOON file: {args.input}")

            return 0
        except ToonDecodeError as e:
            print(f"Error: Invalid TOON file: {e}", file=sys.stderr)
            return 1

    def _cmd_minify(self, args) -> int:
        """Handle minify command."""
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"Error: File '{args.input}' not found", file=sys.stderr)
            return 1

        content = input_path.read_text(encoding='utf-8')

        # Decode
        decoder = ToonDecoder()
        data = decoder.decode(content)

        # Find best delimiter (most compact)
        best_output = None
        best_size = float('inf')
        best_delim = ','

        for delim in [',', '\t', '|']:
            encoder = ToonEncoder(indent=2, delimiter=delim, length_marker=False)
            output = encoder.encode(data)
            size = len(output)
            if size < best_size:
                best_size = size
                best_output = output
                best_delim = delim

        output_path = Path(args.output) if args.output else input_path
        output_path.write_text(best_output, encoding='utf-8')

        original_size = len(content)
        reduction = ((original_size - best_size) / original_size * 100) if original_size > 0 else 0

        delim_name = {',' : 'comma', '\t': 'tab', '|': 'pipe'}[best_delim]
        print(f"✓ Minified TOON file")
        print(f"  Original: {original_size} chars")
        print(f"  Minified: {best_size} chars")
        print(f"  Saved: {reduction:.1f}%")
        print(f"  Best delimiter: {delim_name}")
        if args.output:
            print(f"  Output: {args.output}")

        return 0

    def _cmd_info(self, args) -> int:
        """Handle info command."""
        file_path = Path(args.file)
        if not file_path.exists():
            print(f"Error: File '{args.file}' not found", file=sys.stderr)
            return 1

        content = file_path.read_text(encoding='utf-8')

        try:
            decoder = ToonDecoder()
            data = decoder.decode(content)

            print(f"📄 TOON File Information: {args.file}")
            print(f"{'=' * 60}")
            print(f"Size: {len(content)} characters")
            print(f"Lines: {len(content.splitlines())}")
            print(f"Root type: {type(data).__name__}")

            if isinstance(data, list):
                print(f"Array length: {len(data)}")
                if data:
                    first_type = type(data[0]).__name__
                    all_same = all(type(item).__name__ == first_type for item in data)
                    print(f"Item types: {first_type}" + (" (uniform)" if all_same else " (mixed)"))

                    if all(isinstance(item, dict) for item in data):
                        all_keys = set()
                        for item in data:
                            all_keys.update(item.keys())
                        print(f"Unique keys: {len(all_keys)}")
                        if args.verbose:
                            print(f"Keys: {', '.join(sorted(all_keys))}")

            elif isinstance(data, dict):
                print(f"Object keys: {len(data)}")
                if args.verbose:
                    print(f"Keys: {', '.join(data.keys())}")

                # Count nested structures
                arrays = sum(1 for v in data.values() if isinstance(v, list))
                objects = sum(1 for v in data.values() if isinstance(v, dict))
                primitives = sum(1 for v in data.values() if not isinstance(v, (list, dict)))

                print(f"  Primitives: {primitives}")
                print(f"  Arrays: {arrays}")
                print(f"  Objects: {objects}")

            # Detect delimiter used
            if '	' in content:  # tab
                print(f"Delimiter: tab")
            elif '|' in content and re.search(r'\[\d+\|?\]', content):
                print(f"Delimiter: pipe")
            else:
                print(f"Delimiter: comma")

            # Detect indentation
            lines = content.splitlines()
            indents = []
            for line in lines:
                if line and line[0] == ' ':
                    spaces = len(line) - len(line.lstrip(' '))
                    if spaces > 0:
                        indents.append(spaces)
            if indents:
                min_indent = min(indents)
                print(f"Indentation: {min_indent} spaces")

            return 0
        except ToonDecodeError as e:
            print(f"Error: Invalid TOON file: {e}", file=sys.stderr)
            return 1

    def _cmd_diff(self, args) -> int:
        """Handle diff command."""
        file1_path = Path(args.file1)
        file2_path = Path(args.file2)

        if not file1_path.exists():
            print(f"Error: File '{args.file1}' not found", file=sys.stderr)
            return 1
        if not file2_path.exists():
            print(f"Error: File '{args.file2}' not found", file=sys.stderr)
            return 1

        content1 = file1_path.read_text(encoding='utf-8')
        content2 = file2_path.read_text(encoding='utf-8')

        if args.semantic:
            # Compare decoded values
            decoder = ToonDecoder()
            try:
                data1 = decoder.decode(content1)
                data2 = decoder.decode(content2)

                if data1 == data2:
                    print("✓ Files are semantically identical")
                    return 0
                else:
                    print("✗ Files are semantically different")
                    print(f"\nFile 1 type: {type(data1).__name__}")
                    print(f"File 2 type: {type(data2).__name__}")

                    if isinstance(data1, list) and isinstance(data2, list):
                        print(f"\nFile 1 length: {len(data1)}")
                        print(f"File 2 length: {len(data2)}")
                    elif isinstance(data1, dict) and isinstance(data2, dict):
                        keys1 = set(data1.keys())
                        keys2 = set(data2.keys())
                        only1 = keys1 - keys2
                        only2 = keys2 - keys1
                        if only1:
                            print(f"\nKeys only in file 1: {', '.join(only1)}")
                        if only2:
                            print(f"Keys only in file 2: {', '.join(only2)}")

                    return 1
            except ToonDecodeError as e:
                print(f"Error decoding: {e}", file=sys.stderr)
                return 1
        else:
            # Compare text
            if content1 == content2:
                print("✓ Files are textually identical")
                return 0
            else:
                print("✗ Files are textually different")

                lines1 = content1.splitlines()
                lines2 = content2.splitlines()

                print(f"\nFile 1 lines: {len(lines1)}")
                print(f"File 2 lines: {len(lines2)}")

                # Show first difference
                for i, (line1, line2) in enumerate(zip(lines1, lines2), 1):
                    if line1 != line2:
                        print(f"\nFirst difference at line {i}:")
                        print(f"  File 1: {line1}")
                        print(f"  File 2: {line2}")
                        break

                return 1


def main():
    """Entry point for CLI."""
    cli = ToonCLI()
    sys.exit(cli.run())


if __name__ == '__main__':
    main()
