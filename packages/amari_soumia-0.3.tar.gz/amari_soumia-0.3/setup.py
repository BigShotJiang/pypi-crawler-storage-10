from setuptools import setup, find_packages

setup(
    name="amari_soumia",
    version="0.3",
    author="anari soumia",
    author_email="s.amari@esi-sba.dz",
    description="A simple linear regression model from scratch",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
)
