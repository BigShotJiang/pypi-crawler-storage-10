def hello_world(msg: str) -> str:
    return f"Hello, {msg}!"


def calculate_floor(x: float, y: float) -> float:
    return x // y