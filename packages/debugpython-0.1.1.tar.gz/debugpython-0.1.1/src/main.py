#from helloworld.main import hello_world, calculate_floor
from debugpython import hello_world, calculate_floor

def main():
    print("Hello from debugpython!")
    print(hello_world("World"))
    print(calculate_floor(10, 3))


if __name__ == "__main__":
    main()
