# debugPython

Example of posting a module to PyPI.

## How to Build

```bash
uv build --no-sources
```

## How to Publish

### Publish to PyPI

```bash
uv publish --token <your_token_from_pypi>
```

### Publish to Test PyPI

```bash
uv publish --publish-url https://test.pypi.org/legacy/ --token <your_token>
```

## Getting API Tokens

- **PyPI**: https://pypi.org/manage/account/token/
- **Test PyPI**: https://test.pypi.org/manage/account/token/

