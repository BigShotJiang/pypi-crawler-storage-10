# AutoLearnX

**AutoLearnX** is a simple and powerful AutoML library that automatically:
- detects classification/regression tasks,
- trains multiple models,
- evaluates them,
- and generates performance reports.

## 📦 Installation
```bash
pip install autolearnx
