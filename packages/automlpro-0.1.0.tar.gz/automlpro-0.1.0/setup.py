from setuptools import setup, find_packages

setup(
    name="automlpro",
    version="0.1.0",
    author="Aamir Jamil",
    author_email="engr.aamir@example.com",
    description="A lightweight AutoML library for automation and ML workflows.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/digiart-aamir/automlpro",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
