import pandas as pd
from sklearn.datasets import load_iris
from automlpro import run_all_models

data = load_iris(as_frame=True)
df = data.frame
# sklearn's iris has target column named 'target'
results, best_name, best_model, report_paths = run_all_models(df, target_col="target", task="classification")

print(results)
print("Best:", best_name)
print(report_paths)
