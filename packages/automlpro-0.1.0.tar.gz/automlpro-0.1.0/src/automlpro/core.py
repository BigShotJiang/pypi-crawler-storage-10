from .models import get_models
from .evaluator import train_and_evaluate
from .reporter import generate_report
import pandas as pd

def run_all_models(df, target_col, task="classification", sample_frac=None, verbose=True):
    """
    df: pandas DataFrame (contains target_col)
    target_col: str
    task: "classification" or "regression"
    Returns: (results_df, best_model_name, best_model, report_paths)
    """
    if task not in ("classification", "regression"):
        raise ValueError("task must be 'classification' or 'regression'")

    if sample_frac is not None:
        df = df.sample(frac=sample_frac, random_state=42).reset_index(drop=True)

    if target_col not in df.columns:
        raise ValueError(f"target_col {target_col} not in dataframe")

    X = df.drop(columns=[target_col])
    y = df[target_col]

    # Basic: drop non-numeric columns for now (later add encoders)
    X_numeric = X.select_dtypes(include=["number"]).fillna(0)

    models = get_models(task=task)
    if verbose:
        print(f"> Found {len(models)} models for task={task}")

    results_df, fitted_models, splits = train_and_evaluate(models, X_numeric, y, task=task)

    # best model selection
    if task == "classification":
        primary = "Accuracy"
        best_row = results_df.dropna(subset=[primary]).iloc[0]
    else:
        primary = "RMSE"
        best_row = results_df.dropna(subset=[primary]).iloc[0]

    best_name = best_row["Model"]
    best_model = fitted_models.get(best_name)

    report = generate_report(results_df)

    if verbose:
        print("Results saved:", report)
    return results_df, best_name, best_model, report
