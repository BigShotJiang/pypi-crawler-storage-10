# model factory: returns dict of name->estimator for given task
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor

def get_models(task="classification"):
    if task == "classification":
        return {
            "LogisticRegression": LogisticRegression(max_iter=1000),
            "RandomForest": RandomForestClassifier(),
            "GradientBoosting": GradientBoostingClassifier(),
            "SVM": SVC(probability=True),
            "KNN": KNeighborsClassifier()
        }
    elif task == "regression":
        return {
            "LinearRegression": LinearRegression(),
            "RandomForest": RandomForestRegressor(),
            "GradientBoosting": GradientBoostingRegressor(),
            "KNN": KNeighborsRegressor()
        }
    else:
        raise ValueError("task must be 'classification' or 'regression'")
