import matplotlib.pyplot as plt
import pandas as pd
import os

def generate_report(results_df, out_path="automl_report.png", title="Auto ML Pro - Model Comparison"):
    # results_df: DataFrame
    # Create a simple bar plot for main metric
    if "Accuracy" in results_df.columns:
        metric = "Accuracy"
    elif "RMSE" in results_df.columns:
        metric = "RMSE"
    else:
        # pick first numeric col
        numeric = results_df.select_dtypes("number").columns
        metric = numeric[0] if len(numeric)>0 else None

    if metric is None:
        # save table only
        results_df.to_csv("automl_results.csv", index=False)
        return {"report_image": None, "table_csv": os.path.abspath("automl_results.csv")}

    plt.figure(figsize=(8,5))
    # if lower is better (RMSE), invert color or sort accordingly
    results_df_plot = results_df.dropna(subset=[metric]).copy()
    results_df_plot = results_df_plot.set_index("Model")
    results_df_plot[metric].plot.bar()
    plt.title(f"{title} ({metric})")
    plt.ylabel(metric)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()
    # also save full table
    table_path = "automl_results.csv"
    results_df.to_csv(table_path, index=False)
    return {"report_image": os.path.abspath(out_path), "table_csv": os.path.abspath(table_path)}
