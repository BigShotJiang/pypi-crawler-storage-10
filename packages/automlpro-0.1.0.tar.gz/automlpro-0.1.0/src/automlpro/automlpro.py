"""
Main entry point for AutoMLPro
"""
import pandas as pd
from .models import get_models
from .evaluator import train_and_evaluate
from .reporter import generate_report


def run_all_models(df, target_col, task="classification", sample_frac=None, verbose=True):
    """
    Run all relevant models for given task and generate report.
    """
    if target_col not in df.columns:
        raise ValueError(f"Target column '{target_col}' not found in DataFrame")

    if sample_frac:
        df = df.sample(frac=sample_frac, random_state=42).reset_index(drop=True)

    X = df.drop(columns=[target_col])
    y = df[target_col]

    # numeric only (simple version)
    X = X.select_dtypes(include=["number"]).fillna(0)

    models = get_models(task)
    if verbose:
        print(f"Running {len(models)} models for {task} task...")

    results, fitted_models, splits = train_and_evaluate(models, X, y, task)

    if task == "classification":
        best_model_name = results.iloc[0]["Model"]
        metric = "Accuracy"
    else:
        best_model_name = results.iloc[0]["Model"]
        metric = "RMSE"

    best_model = fitted_models.get(best_model_name)
    report_paths = generate_report(results)

    if verbose:
        print(f"Best model: {best_model_name}")
        print("Report saved at:", report_paths)

    return results, best_model_name, best_model, report_paths
