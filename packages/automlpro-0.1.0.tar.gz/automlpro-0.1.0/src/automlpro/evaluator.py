import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, mean_squared_error, r2_score
import numpy as np

def train_and_evaluate(models, X, y, task="classification", test_size=0.2, random_state=42):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=(y if task=="classification" else None))
    rows = []
    fitted_models = {}

    for name, model in models.items():
        try:
            model.fit(X_train, y_train)
            fitted_models[name] = model
            y_pred = model.predict(X_test)
            if task == "classification":
                # prefer metrics: accuracy, f1, roc_auc (if possible)
                acc = accuracy_score(y_test, y_pred)
                f1 = f1_score(y_test, y_pred, average="weighted")
                # try roc_auc for binary or if predict_proba exists and labels are binary
                try:
                    if hasattr(model, "predict_proba") and len(np.unique(y_test)) == 2:
                        proba = model.predict_proba(X_test)[:, 1]
                        roc = roc_auc_score(y_test, proba)
                    else:
                        roc = None
                except Exception:
                    roc = None
                rows.append({"Model": name, "Accuracy": acc, "F1": f1, "ROC_AUC": roc})
            else:
                mse = mean_squared_error(y_test, y_pred)
                rmse = mse ** 0.5
                r2 = r2_score(y_test, y_pred)
                rows.append({"Model": name, "RMSE": rmse, "R2": r2})
        except Exception as e:
            # record failure
            rows.append({"Model": name, "Error": str(e)})
    df = pd.DataFrame(rows)
    # sort by primary metric
    if task == "classification":
        df_sorted = df.sort_values(by="Accuracy", ascending=False).reset_index(drop=True)
    else:
        df_sorted = df.sort_values(by="RMSE").reset_index(drop=True)
    return df_sorted, fitted_models, (X_train, X_test, y_train, y_test)
