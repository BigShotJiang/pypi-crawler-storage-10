"""
Simple hyperparameter tuner using RandomizedSearchCV
"""
from sklearn.model_selection import RandomizedSearchCV


def tune_model(model, param_distributions, X, y, cv=3, n_iter=10, scoring=None, random_state=42):
    """Perform random search hyperparameter tuning."""
    search = RandomizedSearchCV(
        model,
        param_distributions=param_distributions,
        n_iter=n_iter,
        cv=cv,
        scoring=scoring,
        random_state=random_state,
        n_jobs=-1
    )
    search.fit(X, y)
    return search.best_estimator_, search.best_params_, search.best_score_
