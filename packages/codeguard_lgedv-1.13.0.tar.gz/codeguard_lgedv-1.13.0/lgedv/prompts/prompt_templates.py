"""
Prompt templates for different types of code analysis
Các template cho prompts phân tích code khác nhau
"""

class PromptTemplates:
    """Class chứa các template cho prompts"""
    
    @staticmethod
    def get_lgedv_analysis_prompt() -> str:
        """Template cho LGEDV analysis"""
        return (
            "You are a C++ static analysis expert. Analyze the current file for violations of LGEDV rules for automotive code compliance.\n"
            "If the rule file is not existed, please call fetch_lgedv_rule from MCP server.\n"
            "Always use the latest LGEDV rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the rules above\n"
            "- Focus specifically on LGEDV rule violations\n"
            "- Cite EXACT rule numbers (e.g., LGEDV_CRCL_0001, MISRA Rule 8-4-3, DCL50-CPP, RS-001)\n"
            "- Check every line thoroughly, including:\n"
            "  - All code paths, even unreachable code, dead code, early return, and magic numbers.\n"
            "  - All resource acquisition and release points.\n"
            "  - All exit points (return, break, continue, goto, throw, etc.).\n"
            "  - All function and method boundaries.\n"
            "- Provide concrete fixes for each violation\n"
            "- Use the original file's line numbers in all reports\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each violation found:\n\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [EXACT_RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global scope/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how fix works]\n\n"
            # "## 🔧 Complete Fixed Code\n"
            # "```cpp\n[entire corrected file with all fixes applied]\n```\n\n"            
            "**Note:** If you need the complete fixed code file after all fixes, please request it explicitly."
        )

    @staticmethod
    def get_lge_static_analysis_prompt() -> str:
        """Template cho LGE Static Analysis"""
        return (
            "You are a C++ static analysis expert. Analyze the current file for violations of LGE Static Analysis rules for automotive code compliance.\n"
            "If the rule file is not existed, please call fetch_static_analysis_rule from MCP server.\n"
            "Always use the latest LGE Static Analysis rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the rules above\n"
            "- Focus specifically on LGE Static Analysis rule violations\n"
            "- Cite EXACT rule numbers (e.g., LGE-SA-001, LGE-MEM-002, LGE-PERF-003, MISRA Rule 8-4-3, DCL50-CPP, RS-001)\n"
            "- Check every line thoroughly, including:\n"
            "  - All code paths, even unreachable code, dead code, early return, and magic numbers.\n"
            "  - All resource acquisition and release points.\n"
            "  - All exit points (return, break, continue, goto, throw, etc.).\n"
            "  - All function and method boundaries.\n"
            "- Provide concrete fixes for each violation\n"
            "- Use the original file's line numbers in all reports\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each violation found:\n\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [EXACT_RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global scope/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how fix works]\n\n"
            "**Note:** If you need the complete fixed code file after all fixes, please request it explicitly."
        )
   
    @staticmethod
    def get_misra_analysis_prompt() -> str:
        """Template cho MISRA analysis"""
        return (
            "You are a C++ static analysis expert. Analyze the current file for violations of MISRA C++ 2008 rules for safety-critical software.\n"
            "If the rule file is not existed, please call fetch_misra_cpp_rule from MCP server.\n"
            "Always use the latest MISRA C++ 2008 rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the rules above\n"
            "- Focus specifically on MISRA rule violations\n"
            "- Cite EXACT rule numbers (e.g., MISRA Rule 8-4-3, LGEDV_CRCL_0001, DCL50-CPP, RS-001)\n"
            "- Check every line thoroughly, including:\n"
            "  - All code paths, even unreachable code, dead code, early return, and magic numbers.\n"
            "  - All resource acquisition and release points.\n"
            "  - All exit points (return, break, continue, goto, throw, etc.).\n"
            "  - All function and method boundaries.\n"
            "- Provide concrete fixes for each violation\n"
            "- Use the original file's line numbers in all reports\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each violation found:\n\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [EXACT_RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global scope/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how fix works]\n\n"            
            # "## 🔧 Complete Fixed Code\n"
            # "```cpp\n[entire corrected file with all fixes applied]\n```\n\n"
            # "**Important:** If no MISRA rule violations are found, clearly state \"No MISRA rule violations detected in this code.\"\n"
            "**Note:** If you need the complete fixed code file after all fixes, please request it explicitly."
        )
    
    def get_autosar_analysis_prompt(self) -> str:
        """Get AUTOSAR C++ 14 analysis prompt"""
        return (
            "You are an expert C++ static analysis specialist. Analyze the current file for AUTOSAR C++ 14 coding standard violations.\n"
            "If rule file is not available, please call fetch_autosar_rule from MCP server.\n"
            "Always use the latest AUTOSAR C++ 14 rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the above rules\n"
            "- Focus on AUTOSAR C++ 14 violations\n"
            "- Clearly state rule numbers (e.g., Rule M0-1-1, Rule A0-1-1, MISRA Rule 8-4-3, DCL50-CPP)\n"
            "- Check every line of code, including unreachable, dead code, early returns, magic numbers\n"
            "- Check every acquire/release resource point, every exit point, every function/method\n"
            "- Provide specific code fixes for each error\n"
            "- Include original line numbers in the report\n\n"
            "**RESULT FORMAT:**\n"
            "For each error:\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how the fix works]\n\n"
            "**Note:** If you need the complete fixed code file, please ask explicitly."
        )

    def get_misra_c_analysis_prompt(self) -> str:
        """Get MISRA C 2023 analysis prompt"""
        return (
            "You are an expert C static analysis specialist. Analyze the current file for MISRA C 2023 coding standard violations.\n"
            "If rule file is not available, please call fetch_misra_c_rule from MCP server.\n"
            "Always use the latest MISRA C 2023 rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the above rules\n"
            "- Focus on MISRA C 2023 violations (C LANGUAGE, NOT C++)\n"
            "- Clearly state rule numbers (e.g., Rule 1.1, Dir 4.1, MISRA Rule 8-4-3, DCL50-CPP)\n"
            "- Check every line of code, including unreachable, dead code, early returns, magic numbers\n"
            "- Check every acquire/release resource point, every exit point, every function\n"
            "- Provide specific code fixes for each error\n"
            "- Include original line numbers in the report\n\n"
            "**RESULT FORMAT:**\n"
            "For each error:\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```c\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```c\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how the fix works]\n\n"
            "**IMPORTANT NOTE:** This analysis is for C language (not C++). Focus on MISRA C 2023 directives and rules."
        )

    @staticmethod
    def get_certcpp_analysis_prompt() -> str:
        """Template cho CERT C++ analysis"""
        return (
            "You are a C++ static analysis expert. Analyze the current file for violations of CERT C++ Secure Coding Standard rules.\n"
            "If the rule file is not existed, please call fetch_certcpp_rule from MCP server.\n"
            "Always use the latest CERT C++ rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the rules above\n"
            "- Focus specifically on CERT rule violations\n"
            "- Cite EXACT rule numbers (e.g., DCL50-CPP, MISRA Rule 8-4-3, LGEDV_CRCL_0001, RS-001)\n"
            "- Check every line thoroughly, including:\n"
            "  - All code paths, even unreachable code, dead code, early return, and magic numbers.\n"
            "  - All resource acquisition and release points.\n"
            "  - All exit points (return, break, continue, goto, throw, etc.).\n"
            "  - All function and method boundaries.\n"
            "- Provide concrete fixes for each violation\n"
            "- Use the original file's line numbers in all reports\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each violation found:\n\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [EXACT_RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global scope/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how fix works]\n\n"          
            # "## 🔧 Complete Fixed Code\n"
            # "```cpp\n[entire corrected file with all fixes applied]\n```\n\n"
            # "**Important:** If no CERT rule violations are found, clearly state \"No CERT rule violations detected in this code.\"\n"
            "**Note:** If you need the complete fixed code file after all fixes, please request it explicitly."
        )
    
    @staticmethod
    def get_custom_analysis_prompt() -> str:
        """Template cho Custom rule analysis"""
        return (
            "You are a C++ static analysis expert. Analyze the current file for violations of the following custom rules.\n"
            "If the rule file is not existed, please call fetch_custom_rule from MCP server.\n"
            "Always use the latest custom rules just fetched for analysis, not any cached or built-in rules.\n"
            "Explicitly state which rule set is being used for the analysis in your report.\n\n"
            "**ANALYSIS REQUIREMENTS:**\n"
            "- Find ALL violations of the rules above\n"
            "- Focus specifically on custom rule violations\n"
            "- Cite EXACT rule numbers (e.g., CUSTOM-001, MISRA Rule 8-4-3, LGEDV_CRCL_0001, RS-001)\n"
            "- Check every line thoroughly, including:\n"
            "  - All code paths, even unreachable code, dead code, early return, and magic numbers.\n"
            "  - All resource acquisition and release points.\n"
            "  - All exit points (return, break, continue, goto, throw, etc.).\n"
            "  - All function and method boundaries.\n"
            "- Provide concrete fixes for each violation\n"
            "- Use the original file's line numbers in all reports\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each violation found:\n\n"
            "## 🚨 Issue [#]: [Brief Description]\n\n"
            "**Rule Violated:** [EXACT_RULE_NUMBER] - [Rule Description]\n\n"
            "**Location:** [file name, function name or global scope/unknown]\n\n"
            "**Severity:** [Critical/High/Medium/Low]\n\n"
            "**Current Code:**\n"
            "```cpp\n[problematic code]\n```\n"
            "**Fixed Code:**\n"
            "```cpp\n[corrected code]\n```\n"
            "**Explanation:** [Why this violates the rule and how fix works]\n\n"         
            # "## 🔧 Complete Fixed Code\n"
            # "```cpp\n[entire corrected file with all fixes applied]\n```\n\n"
            # "**Important:** If no custom rule violations are found, clearly state \"No custom rule violations detected in this code.\"\n"
            "**Note:** If you need the complete fixed code file after all fixes, please request it explicitly."
        )
    
    @staticmethod
    def get_context_prompt() -> str:
        """Template cho việc lấy và ghi nhớ context code cho mọi loại file source"""
        return (
            "You are a code context assistant. Your task is to read and remember the full content and structure of all source files (C++, Python, etc.) in the current project directory.\n"
            "If file contents are not yet loaded, call the tool 'get_src_context' from the MCP server to retrieve all relevant source files in the directory specified by SRC_DIR.\n"
            "For each file, extract and summarize:\n"
            "- File name and relative path\n"
            "- All class, struct, enum, and function definitions (for C++, Python, etc.)\n"
            "- Key relationships (inheritance, composition, usage)\n"
            "- Any global variables, constants, macros, or configuration\n"
            "- Any important comments or documentation\n"
            "Do not perform static analysis or rule checking in this step.\n"
            "Store this context for use in subsequent analysis or code-related queries in the same session.\n\n"
            "**OUTPUT FORMAT:**\n"
            "For each file:\n"
            "### [File Name]\n"
            "```[language]\n[Summary of structure, definitions, and key elements]\n```\n"
            "Repeat for all files provided.\n"
            "Confirm when context is fully loaded and ready for future queries."
        )
    
    @staticmethod
    def get_design_verification_prompt(feature: str = None) -> str:
        """
        Template for Design Verification analysis - English version matching Vietnamese structure
        """
        prompt = (
            "You are an expert automotive embedded system design analyst.\n"
            "Your task: Evaluate the sequence diagram in the attached design (image file) for requirements compliance"
        )
        
        # Add feature if provided
        if feature:
            prompt += f" for feature {feature}"
        
        prompt += ", API validation, and robustness.\n"
        
        # Add feature section if provided
        if feature:
            prompt += f"\n**Focus Feature:** {feature}\n"
        
        prompt += (
            "\n\n**ANALYSIS PROCESS:**\n"
            f"1. Thoroughly analyze requirements for feature"
        )
        
        if feature:
            prompt += f" {feature}"
        
        prompt += (
            " in the requirement document (attached markdown file).\n"
            "2. Extract all components, API calls, and interaction flows from the sequence diagram.\n"
            "3. Cross-reference each API call with application context, framework, interface to validate legitimacy.\n"
            "4. Compare each design step with requirements, check for missing/coverage gaps or unclear points. Most importantly, verify if design meets input requirements\n"
            "5. Evaluate error handling capability, timeout, fallback logic, and system state management.\n"
            "6. Propose improvements and build enhanced PlantUML sequence diagram if needed.\n\n"
            
            "**RESULT FORMAT:**\n"
            "## 📋 Context Validation\n"
            "- Main application context (src_dir): ✅/❌\n"
            "- Framework context (framework_dir): ✅/❌\n"
            "- Interface context (module_api): ✅/❌\n"
            "- Requirements context (req_dir): ✅/❌\n\n"
            
            "## 🔍 Current Design Analysis\n"
            "### Sequence Flow Evaluation\n"
            "- Components: [list]\n"
            "- Message Flow: [analysis]\n"
            "- State Transitions: [analysis]\n\n"
            
            "### API Validation Results\n"
            "**✅ Valid APIs:**\n"
            "- `ClassName::method()` - Found in [context]\n"
            "**❌ Missing APIs:**\n"
            "- `UnknownClass::method()` - Not found, needs implementation\n"
            "**⚠️ Ambiguous APIs:**\n"
            "- `CommonName::method()` - Found in multiple contexts, needs clarification\n\n"
            
            "### Requirements Compliance\n"
            "| Requirement ID | Description | Status | Notes |\n"
            "|----------------|-------------|--------|-------|\n"
            "| REQ-001 | [content] | ✅/❌/⚠️ | [notes] |\n\n"
            
            "## ❌ Critical Issues\n"
            "- Missing requirements coverage\n"
            "- Invalid or missing APIs\n"
            "- Missing robustness (error handling, timeout, fallback, state)\n"
            
            "## 🚀 Advanced Design Solution\n"
            "### API Integration Strategy\n"
            "- Use existing APIs from all contexts where possible\n"
            "- Modify existing APIs if needed\n"
            "- Only propose new APIs when absolutely necessary, must justify clearly\n\n"
            
            "### Requirements Implementation Plan\n"
            "- For each missing requirement, specify design changes needed\n\n"
            
            "### Enhanced Design Proposal\n"
            "Please present enhanced design for current design using standard PlantUML sequence diagram.\n"
            "```plantuml\n"
            "@startuml\n"
            "!theme blueprint\n"
            "title Enhanced Design"
        )
        
        if feature:
            prompt += f" - {feature}"
        
        prompt += (
            "\n\n"
            "' Add enhanced design here\n"
            "' Include error handling and robustness\n"
            "@enduml\n"
            "```\n"
        )
        
        return prompt
    
    @staticmethod
    def get_single_requirement_verification_prompt(requirement_text: str) -> str:
        """
        Prompt to verify if current source code implements a specific user-provided requirement.
        Auto-instructs tool usage if requirement or source context not yet loaded.
        
        Args:
            requirement_text: Raw requirement provided by user (plain sentence or multi-line).
        """
        requirement_text = (requirement_text or "").strip()
        if not requirement_text:
            requirement_text = "<NO REQUIREMENT PROVIDED>"

        return (
            "You are a senior C++ requirements compliance analyst.\n"
            "Task: Determine whether the current codebase implements the following requirement.\n"
            f"**Target Requirement (User Input):**\n{requirement_text}\n\n"
            "If requirement context is not loaded yet, call the tool `analyze_requirement` (with dir pointing to configured req_dir if needed).\n"
            "If source code context is not loaded yet, call the tool `get_src_context` (with dir pointing to configured src_dir if needed).\n"
            "Do NOT assume implementation exists; verify using actual code constructs only.\n\n"
            "## ANALYSIS OBJECTIVES\n"
            "1. Locate ALL functions, methods, classes, modules that implement, partially implement, or relate to the requirement.\n"
            "2. Extract exact code snippets (with line numbers) evidencing implementation.\n"
            "3. Distinguish: Fully Implemented / Partially Implemented / Not Implemented / Unclear.\n"
            "4. Identify missing behaviors, edge cases, error handling, concurrency, performance, and safety aspects tied to the requirement.\n"
            "5. Recommend precise implementation steps if gaps exist.\n\n"
            "## METHOD\n"
            "- Parse function, class, and file names for semantic correlation (keywords, verbs, domain nouns).\n"
            "- Check comments, TODOs, public APIs, state variables, and condition branches.\n"
            "- Confirm logic (input validation, state transitions, side effects, output generation).\n"
            "- Avoid speculative matches: only list items with concrete textual or logical evidence.\n"
            "- If no matches found, clearly state so and propose a minimal design.\n\n"
            "## OUTPUT FORMAT\n"
            "### 🧾 Requirement Summary\n"
            f"- Text: {requirement_text}\n"
            "- Key Tokens: [list extracted domain keywords]\n"
            "- Interpretation: [your concise operational breakdown]\n\n"
            "### 🔍 Implementation Mapping\n"
            "| Location | Type | Lines | Status | Evidence |\n"
            "|----------|------|-------|--------|----------|\n"
            "| file.cpp::Class::method | function | 120-148 | Full/Partial/Related | condition X, updates Y |\n"
            "Add one row per match. Use relative paths. Merge contiguous line spans.\n\n"
            "### ✅ Coverage Assessment\n"
            "- Overall Status: [Fully Implemented | Partially Implemented | Not Implemented | Unclear]\n"
            "- Implemented Aspects: [list]\n"
            "- Missing Aspects: [list]\n"
            "- Edge Cases Missing: [list]\n"
            "- Error Handling Gaps: [list]\n"
            "- Concurrency/Safety Notes: [list if relevant]\n\n"
            "### 🛠 Recommendations\n"
            "- Implementation Steps / Refactors:\n"
            "  1. [Add function ...]\n"
            "  2. [Inject validation ...]\n"
            "  3. [Improve error path ...]\n"
            "- Proposed New/Updated API Signatures (if needed):\n"
            "```cpp\n// example\nbool FeatureController::activateMode(const ModeConfig& cfg);\n```\n"
            "- Suggested Comments / Documentation additions.\n\n"
            "### 📦 Minimal Stub (If Not Implemented)\n"
            "```cpp\n// Provide a concise skeleton meeting core requirement behavior\n```\n\n"
            "### 🧪 Suggested Tests\n"
            "- Unit: [case name → expected]\n"
            "- Integration: [scenario]\n"
            "- Negative / Boundary: [invalid input, timeouts]\n\n"
            "### ⚠️ Traceability Notes\n"
            "- Link this assessment to requirement ID or tag if available.\n"
            "- If requirement should be split (too broad), propose atomic sub-requirements.\n\n"
            "**Important:** Only reference real code. If source or requirement context is missing, first invoke the appropriate tools (`analyze_requirement`, `get_src_context`) before concluding."
        )
    
    @staticmethod
    def get_single_requirement_verification_prompt_vi(requirement_text: str) -> str:
        """
        Prompt tiếng Việt để xác minh mã nguồn có triển khai yêu cầu đơn lẻ hay không.
        Giữ nguyên cấu trúc và các section như bản tiếng Anh.
        
        Args:
            requirement_text: Yêu cầu thô do người dùng cung cấp (1 câu hoặc nhiều dòng).
        """
        requirement_text = (requirement_text or "").strip()
        if not requirement_text:
            requirement_text = "<CHƯA CUNG CẤP YÊU CẦU>"
        
        return (
            "Bạn là chuyên gia phân tích tuân thủ yêu cầu phần mềm C++ nhúng ô tô cấp cao.\n"
            "Nhiệm vụ: Xác định mã nguồn hiện tại có triển khai yêu cầu sau hay không.\n"
            f"**Yêu cầu mục tiêu (Người dùng cung cấp):**\n{requirement_text}\n\n"
            "Nếu ngữ cảnh yêu cầu (requirements) chưa được nạp, hãy gọi tool `analyze_requirement` (tham số dir trỏ tới req_dir cấu hình).\n"
            "Nếu ngữ cảnh mã nguồn chưa được nạp, hãy gọi tool `get_src_context` (tham số dir trỏ tới src_dir cấu hình).\n"
            "KHÔNG giả định đã có triển khai; phải xác minh bằng cấu trúc mã cụ thể.\n\n"
            "## MỤC TIÊU PHÂN TÍCH\n"
            "1. Tìm TẤT CẢ function, method, class, module liên quan hoặc thể hiện một phần yêu cầu.\n"
            "2. Trích xuất đoạn mã chính xác (kèm số dòng) làm bằng chứng.\n"
            "3. Phân loại: Đã triển khai / Triển khai một phần / Chưa triển khai / Không rõ.\n"
            "4. Chỉ ra logic/thao tác/nhánh/edge case/error/concurrency/performance/safety còn thiếu.\n"
            "5. Đề xuất các bước triển khai cụ thể nếu có gap.\n\n"
            "## PHƯƠNG PHÁP\n"
            "- Phân tích tên function, class, file (từ khóa nghiệp vụ, động từ, danh từ).\n"
            "- Kiểm tra comment, TODO, public API, biến trạng thái, điều kiện chuyển trạng thái.\n"
            "- Xác thực logic: kiểm tra đầu vào, cập nhật state, tác dụng phụ, đầu ra.\n"
            "- Tránh suy đoán: chỉ liệt kê phần tử có bằng chứng văn bản hoặc logic rõ ràng.\n"
            "- Nếu không tìm thấy gì: nêu rõ và đề xuất thiết kế tối thiểu.\n\n"
            "## ĐỊNH DẠNG KẾT QUẢ\n"
            "### 🧾 Tóm tắt yêu cầu\n"
            f"- Văn bản: {requirement_text}\n"
            "- Từ khóa chính: [liệt kê từ khóa miền nghiệp vụ]\n"
            "- Diễn giải: [phân rã thao tác ngắn gọn]\n\n"
            "### 🔍 Ánh xạ triển khai\n"
            "| Vị trí | Kiểu | Dòng | Trạng thái | Bằng chứng |\n"
            "|--------|------|------|------------|------------|\n"
            "| file.cpp::Class::method | function | 120-148 | Full/Partial/Related | điều kiện X, cập nhật Y |\n"
            "Thêm một hàng cho mỗi khớp. Dùng đường dẫn tương đối. Gộp các đoạn dòng liên tiếp.\n\n"
            "### ✅ Đánh giá mức độ phủ\n"
            "- Trạng thái tổng thể: [Đã triển khai | Một phần | Chưa triển khai | Không rõ]\n"
            "- Phần đã có: [liệt kê]\n"
            "- Phần thiếu: [liệt kê]\n"
            "- Edge cases thiếu: [liệt kê]\n"
            "- Thiếu xử lý lỗi: [liệt kê]\n"
            "- Ghi chú concurrency/an toàn: [nếu có]\n\n"
            "### 🛠 Khuyến nghị\n"
            "- Bước triển khai / Refactor:\n"
            "  1. [Thêm function ...]\n"
            "  2. [Chèn kiểm tra ...]\n"
            "  3. [Bổ sung luồng lỗi ...]\n"
            "- API mới / cập nhật (nếu cần):\n"
            "```cpp\n// ví dụ\nbool FeatureController::activateMode(const ModeConfig& cfg);\n```\n"
            "- Gợi ý comment / tài liệu.\n\n"
            "### 📦 Stub tối thiểu (Nếu Chưa triển khai)\n"
            "```cpp\n// Khung skeleton đáp ứng hành vi cốt lõi\n```\n\n"
            "### 🧪 Test gợi ý\n"
            "- Unit: [tên case → kỳ vọng]\n"
            "- Integration: [kịch bản]\n"
            "- Negative / Boundary: [input không hợp lệ, timeout]\n\n"
            "### ⚠️ Traceability / Truy xuất\n"
            "- Liên kết đánh giá với ID yêu cầu (nếu có).\n"
            "- Nếu yêu cầu quá rộng: đề xuất tách thành các yêu cầu nguyên tử.\n\n"
            "**Quan trọng:** Chỉ tham chiếu mã thật. Nếu thiếu ngữ cảnh requirement hoặc source, trước tiên gọi đúng tool (`analyze_requirement`, `get_src_context`) rồi mới kết luận."
        )
            