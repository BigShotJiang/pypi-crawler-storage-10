from enum import Enum


class httpMethodEnum(str, Enum):
    POST = "POST"
    GET = "GET"
    DELETE = "DELETE"
    PUT = "PUT"

