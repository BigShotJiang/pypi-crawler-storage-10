import base64
import hashlib
import os


# 文件辅助类
class fileHelp:
    def __init__(self, fileUrl):
        """
        为文件类定义初始化公共参数
        :param fileUrl:
        """
        self.fileOs = os.path.abspath(os.path.join(os.getcwd(), fileUrl))
        self.contentMd5 = self.__content_encoding()  # 初始化文件MD5
        self.fileName = os.path.basename(self.fileOs)  # 初始化文件名
        self.fileSize = os.path.getsize(self.fileOs)  # 初始化文件大小

    def __content_encoding(self):
        """
        文件转 bytes 加密并使用 base64 编码
        :param fileOs: 文件路径
        :return: 返回加密编码后的字符串
        """

        with open(self.fileOs, 'rb') as f:
            content = f.read()
        content_md5 = hashlib.md5()
        content_md5.update(content)
        content_base64 = base64.b64encode(content_md5.digest())
        return content_base64.decode("utf-8")

    def getBinFile(self):
        """
        获取文件流
        :param fileOs:
        :return:
        """
        with open(self.fileOs, 'rb') as f:
            binfile = f.read()
        return binfile

