# 公共参数配置类
class config:
    def __init__(self):
        """
        项目配置类，在此配置公共参数
        """
        # 沙箱appid获取路径：https://open.esign.cn/doc/opendoc/saas_api/vwtg6m
        # 沙箱appid获取路径：https://open.esign.cn/doc/opendoc/saas_api/zag8bm
        self.appId = "7439044092"  # 项目appid
        self.scert = "7b1c435a78bee504190b4463aa50a7f0"  # 项目密钥
        self.host = "https://smlopenapi.esign.cn"  # 沙箱请求地址，正式环境地址：https://openapi.esign.cn

