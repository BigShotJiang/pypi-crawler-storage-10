"""
带骑缝章的单方企业合同签署演示
使用 xl_sign.SignClient 进行带骑缝章的单方企业自动签署
骑缝章是指跨页面的印章，通常在多页合同的边缘位置添加，用于证明文档的连续性和完整性
"""

from xl_sign import SignClient


def demo_cross_page_seal_auto_sign():
    """
    演示：单方企业自动签署 - 添加骑缝章
    """
    print("=== 单方企业自动签署（骑缝章）演示 ===")
    
    # 初始化签署客户端
    # 可以使用默认配置，或传入自定义配置：
    # client = SignClient(app_id="your_app_id", secret="your_secret", host="https://openapi.esign.cn")
    client = SignClient()
    
    # 配置参数
    file_path = "C:\\Users\\heinz97\\Desktop\\报表报告.pdf"  # 本地合同文件路径（需要多页PDF文件）
    org_name = "杭州希隆信息技术服务有限公司"  # 企业名称
    seal_name = "检测专用章"  # 要使用的印章名称（可选）
    
    # 骑缝章配置参数
    start_page = 1  # 骑缝章起始页码（从第1页开始，仅在 end_page 不为 None 时使用）
    end_page = None  # 骑缝章结束页码（None表示所有页都盖骑缝章，也可以指定具体页码如 9）
    # 注意：骑缝章的 positionX 不生效，只需设置 positionY
    position_y = None  # 骑缝章Y坐标位置（None表示使用默认值400，即垂直居中位置）
    
    print(f"\n骑缝章配置:")
    print(f"  - 页码范围: {'所有页' if end_page is None else f'第{start_page}页到第{end_page}页'}")
    print(f"  - 垂直位置: Y={position_y if position_y is not None else 400}")
    print(f"  - 注意：骑缝章会自动放置在页面边缘，positionX 不生效")
    
    try:
        # 调用带骑缝章的签署方法
        # 该方法会自动完成以下步骤：
        # 1. 查询企业信息
        # 2. 查询印章ID（如果指定了印章名称）
        # 3. 上传文件
        # 4. 创建带骑缝章的签署流程
        # 5. 等待签署完成（如果 auto_sign=True 且 wait_complete=True）
        sign_flow_id = client.cross_page_seal_sign(
            file_path=file_path,
            org_name=org_name,
            seal_name=seal_name,  # 可选
            auto_sign=True,
            start_page=start_page,  # 骑缝章起始页码（仅在 end_page 不为 None 时使用）
            end_page=end_page,  # None表示所有页都盖骑缝章，也可以指定具体页码如 9
            position_y=position_y,  # None表示使用默认值400，即垂直居中位置
            wait_complete=True,  # 是否等待签署完成
            max_wait_time=30  # 最大等待时间（秒）
        )
        
        print(f"\n签署流程ID: {sign_flow_id}")
        print("签署流程已完成！")
        
        # 获取已签署文件的下载地址
        download_url = client.get_file_download_url(sign_flow_id)
        print(f"\n已签署文件下载地址（包含骑缝章）: {download_url}")
        
    except ValueError as e:
        print(f"参数错误: {e}")
    except Exception as e:
        print(f"签署失败: {e}")


if __name__ == '__main__':
    # 运行单方企业自动签署（骑缝章）演示
    demo_cross_page_seal_auto_sign()
