# 分布式锁

提供跨进程/实例的互斥控制，保证缓存一致性与并发安全。

::: symphra_cache.locks.DistributedLock
