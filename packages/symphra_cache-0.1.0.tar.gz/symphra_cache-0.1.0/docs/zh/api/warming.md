# 预热

预加载与智能预热工具。

::: symphra_cache.warming.CacheWarmer

::: symphra_cache.warming.SmartCacheWarmer

::: symphra_cache.warming.create_warmer
