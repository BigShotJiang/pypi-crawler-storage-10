# 类型与枚举

序列化模式、淘汰策略与后端类型枚举。

::: symphra_cache.types.SerializationMode

::: symphra_cache.types.EvictionPolicy

::: symphra_cache.types.BackendType
