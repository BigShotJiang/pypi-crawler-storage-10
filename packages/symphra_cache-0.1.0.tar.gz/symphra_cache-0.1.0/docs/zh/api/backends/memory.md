# 内存后端

进程内内存缓存，速度最快，适合单实例使用。

::: symphra_cache.backends.memory.MemoryBackend
