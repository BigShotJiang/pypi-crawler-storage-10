# Redis 后端

共享、持久化的分布式缓存，适合多实例与水平扩展。

::: symphra_cache.backends.redis.RedisBackend
