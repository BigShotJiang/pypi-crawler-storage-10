# 文件后端

基于文件系统的缓存，支持热重载，适合开发与简单持久化场景。

::: symphra_cache.backends.file.FileBackend
