# 配置

统一的缓存配置，支持从字典、YAML/TOML/JSON 文件与环境变量加载。

::: symphra_cache.config.CacheConfig
