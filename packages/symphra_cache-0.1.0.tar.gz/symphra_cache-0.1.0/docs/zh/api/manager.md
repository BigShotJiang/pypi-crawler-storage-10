# 管理器

缓存管理器负责统一调度后端、监控与策略。

::: symphra_cache.manager.CacheManager
