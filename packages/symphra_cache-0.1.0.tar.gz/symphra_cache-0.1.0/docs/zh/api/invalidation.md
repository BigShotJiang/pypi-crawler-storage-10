# 失效

缓存失效工具与分组失效。

::: symphra_cache.invalidation.CacheInvalidator

::: symphra_cache.invalidation.CacheGroupInvalidator

::: symphra_cache.invalidation.create_invalidator
