# 装饰器

同步与异步缓存装饰器，以及缓存失效装饰器与属性缓存。

::: symphra_cache.decorators.cache

::: symphra_cache.decorators.acache

::: symphra_cache.decorators.cache_invalidate

::: symphra_cache.decorators.CachedProperty
