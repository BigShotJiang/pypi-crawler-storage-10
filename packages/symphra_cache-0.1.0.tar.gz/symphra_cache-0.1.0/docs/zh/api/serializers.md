# 序列化

内置 JSON / Pickle / MessagePack 序列化器，支持自定义。

::: symphra_cache.serializers.BaseSerializer

::: symphra_cache.serializers.JSONSerializer

::: symphra_cache.serializers.PickleSerializer

::: symphra_cache.serializers.MessagePackSerializer

::: symphra_cache.serializers.get_serializer
