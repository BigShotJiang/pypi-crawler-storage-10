# Serializers

Built-in serializer implementations and helper to select serializer.

::: symphra_cache.serializers.BaseSerializer

::: symphra_cache.serializers.JSONSerializer

::: symphra_cache.serializers.PickleSerializer

::: symphra_cache.serializers.MessagePackSerializer

::: symphra_cache.serializers.get_serializer
