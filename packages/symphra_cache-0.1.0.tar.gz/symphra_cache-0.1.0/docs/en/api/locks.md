# DistributedLock

Helper for distributed locking using the configured backend.

::: symphra_cache.locks.DistributedLock
