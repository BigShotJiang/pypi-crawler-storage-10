# CacheConfig

Typed configuration powered by Pydantic for backend selection and options.

::: symphra_cache.config.CacheConfig
