# Types and Enums

Core enums and type aliases used across the library.

::: symphra_cache.types.SerializationMode

::: symphra_cache.types.EvictionPolicy

::: symphra_cache.types.BackendType
