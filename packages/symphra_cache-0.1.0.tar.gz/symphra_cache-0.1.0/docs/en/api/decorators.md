# Decorators

Synchronous and asynchronous caching decorators, plus cache invalidation and cached property.

::: symphra_cache.decorators.cache

::: symphra_cache.decorators.acache

::: symphra_cache.decorators.cache_invalidate

::: symphra_cache.decorators.CachedProperty
