# FileBackend

SQLite-based persistent cache backend with hot-reload support.

::: symphra_cache.backends.file.FileBackend
