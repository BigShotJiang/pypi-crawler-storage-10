# RedisBackend

Distributed cache backend powered by `redis-py`, supporting cluster/sentinel and pipeline optimizations.

::: symphra_cache.backends.redis.RedisBackend
