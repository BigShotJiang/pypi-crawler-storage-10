import os

os.environ["DJANGO_ALLOW_ASYNC_UNSAFE"] = "1"
