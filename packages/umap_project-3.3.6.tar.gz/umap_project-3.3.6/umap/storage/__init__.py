# Retrocompat

from .staticfiles import UmapManifestStaticFilesStorage  # noqa: F401
