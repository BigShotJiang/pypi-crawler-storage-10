from django.apps import AppConfig


class UmapConfig(AppConfig):
    name = "umap"
    verbose_name = "uMap"
