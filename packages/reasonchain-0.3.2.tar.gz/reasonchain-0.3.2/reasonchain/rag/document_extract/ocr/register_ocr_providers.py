"""
Auto-register built-in OCR providers.

This module automatically registers all built-in OCR providers when imported.
"""

from .ocr_registry import OCRProviderRegistry


def register_builtin_providers():
    """Register all built-in OCR providers."""
    try:
        # Traditional OCR
        from .providers.tesseract_provider import TesseractProvider
        OCRProviderRegistry.register('tesseract', TesseractProvider)
        
        from .providers.easyocr_provider import EasyOCRProvider
        OCRProviderRegistry.register('easyocr', EasyOCRProvider)
        
        from .providers.paddleocr_provider import PaddleOCRProvider
        OCRProviderRegistry.register('paddleocr', PaddleOCRProvider)
        
        # LLM-based OCR
        from .providers.lightonocr_provider import LightOnOCRProvider
        OCRProviderRegistry.register('lightonocr', LightOnOCRProvider)
        
        from .providers.vllm_ocr_provider import VLLMOCRProvider
        OCRProviderRegistry.register('vllm_ocr', VLLMOCRProvider)
        
        print("Built-in OCR providers registered successfully")
        
    except Exception as e:
        print(f"Warning: Error registering OCR providers: {e}")


# Auto-register on import
register_builtin_providers()

