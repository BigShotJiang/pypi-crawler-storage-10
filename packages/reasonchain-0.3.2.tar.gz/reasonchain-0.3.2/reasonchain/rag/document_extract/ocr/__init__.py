"""
OCR Provider System for ReasonChain

Extensible OCR system supporting multiple engines:
- Traditional OCR: Tesseract, EasyOCR, PaddleOCR
- LLM-based OCR: LightOnOCR, Qwen2-VL, GPT-4V, Claude, etc.
"""

from .base_ocr_provider import BaseOCRProvider
from .ocr_registry import OCRProviderRegistry

# Auto-register built-in providers
try:
    from . import register_ocr_providers
except Exception as e:
    print(f"Warning: Could not auto-register OCR providers: {e}")

__all__ = [
    'BaseOCRProvider',
    'OCRProviderRegistry',
]

