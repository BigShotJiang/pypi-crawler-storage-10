"""
Base OCR Provider Interface

Abstract base class for all OCR providers in ReasonChain.
Supports both traditional OCR and modern LLM-based OCR.
"""

from abc import ABC, abstractmethod
from typing import Union, List, Dict, Any, Optional
from PIL import Image
import numpy as np


class BaseOCRProvider(ABC):
    """
    Abstract base class for OCR providers.
    
    All OCR providers must inherit from this class and implement the required methods.
    Supports images, PDFs, and various document types.
    """
    
    def __init__(self, model_name: str = None, **kwargs):
        """
        Initialize the OCR provider.
        
        Args:
            model_name: Name/path of the OCR model
            **kwargs: Additional provider-specific parameters
        """
        self.model_name = model_name
        self.config = kwargs
        self._initialize(**kwargs)
    
    @abstractmethod
    def _initialize(self, **kwargs):
        """
        Initialize the OCR engine/model.
        
        This method should load the model, set up configurations, etc.
        """
        pass
    
    @abstractmethod
    def extract_text(
        self, 
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text from a single image.
        
        Args:
            image: PIL Image, numpy array, file path, or bytes
            **kwargs: Additional extraction parameters (language, confidence threshold, etc.)
            
        Returns:
            str: Extracted text
        """
        pass
    
    def extract_text_batch(
        self,
        images: List[Union[Image.Image, np.ndarray, str, bytes]],
        **kwargs
    ) -> List[str]:
        """
        Extract text from multiple images (batch processing).
        
        Default implementation processes images sequentially.
        Override for parallel/optimized batch processing.
        
        Args:
            images: List of images in various formats
            **kwargs: Additional extraction parameters
            
        Returns:
            List[str]: List of extracted texts
        """
        return [self.extract_text(img, **kwargs) for img in images]
    
    def extract_text_with_confidence(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Extract text with confidence scores and bounding boxes.
        
        Args:
            image: Image to process
            **kwargs: Additional parameters
            
        Returns:
            dict: {
                'text': str,
                'confidence': float (0-1),
                'words': List[Dict] (optional, word-level details),
                'boxes': List[tuple] (optional, bounding boxes)
            }
        """
        # Default implementation returns just text
        # Override for providers that support confidence/bbox
        text = self.extract_text(image, **kwargs)
        return {
            'text': text,
            'confidence': 1.0,
            'words': [],
            'boxes': []
        }
    
    def extract_from_pdf(
        self,
        pdf_path: str,
        page_numbers: Optional[List[int]] = None,
        **kwargs
    ) -> List[str]:
        """
        Extract text from PDF pages.
        
        Args:
            pdf_path: Path to PDF file
            page_numbers: Specific pages to process (None = all pages)
            **kwargs: Additional parameters
            
        Returns:
            List[str]: Text from each page
        """
        from reasonchain.utils.lazy_imports import pdf2image
        
        # Convert PDF pages to images
        if page_numbers:
            images = pdf2image.convert_from_path(
                pdf_path, 
                first_page=min(page_numbers), 
                last_page=max(page_numbers)
            )
        else:
            images = pdf2image.convert_from_path(pdf_path)
        
        # Extract text from images
        return self.extract_text_batch(images, **kwargs)
    
    def supports_language(self, language: str) -> bool:
        """
        Check if the provider supports a specific language.
        
        Args:
            language: Language code (e.g., 'eng', 'fra', 'chi_sim')
            
        Returns:
            bool: True if supported
        """
        # Default: assume all languages supported
        # Override for providers with language limitations
        return True
    
    def get_supported_languages(self) -> List[str]:
        """
        Get list of supported languages.
        
        Returns:
            List[str]: Language codes
        """
        return ['eng']  # Default, override in subclasses
    
    def set_language(self, language: str):
        """
        Set the OCR language.
        
        Args:
            language: Language code
        """
        if hasattr(self, 'language'):
            self.language = language
    
    def get_provider_info(self) -> Dict[str, Any]:
        """
        Get information about the OCR provider.
        
        Returns:
            dict: Provider metadata
        """
        return {
            'name': self.__class__.__name__,
            'model': self.model_name,
            'type': self._get_provider_type(),
            'languages': self.get_supported_languages(),
            'config': self.config
        }
    
    def _get_provider_type(self) -> str:
        """
        Get the provider type (traditional_ocr or llm_ocr).
        
        Returns:
            str: Provider type
        """
        return 'traditional_ocr'
    
    def _preprocess_image(
        self, 
        image: Union[Image.Image, np.ndarray, str, bytes]
    ) -> Image.Image:
        """
        Preprocess image to PIL Image format.
        
        Args:
            image: Image in various formats
            
        Returns:
            PIL.Image: Standardized image
        """
        import io
        from PIL import Image
        
        if isinstance(image, Image.Image):
            return image
        elif isinstance(image, np.ndarray):
            return Image.fromarray(image)
        elif isinstance(image, str):
            return Image.open(image)
        elif isinstance(image, bytes):
            return Image.open(io.BytesIO(image))
        else:
            raise ValueError(f"Unsupported image type: {type(image)}")
    
    def __repr__(self):
        return f"{self.__class__.__name__}(model='{self.model_name}')"

