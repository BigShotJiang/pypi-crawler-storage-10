"""
OCR Provider Registry

Central registry for managing OCR providers in ReasonChain.
"""

from typing import Dict, Type, Optional, List
from .base_ocr_provider import BaseOCRProvider


class OCRProviderRegistry:
    """
    Registry for OCR providers.
    
    Manages registration, retrieval, and instantiation of OCR providers.
    """
    
    _providers: Dict[str, Type[BaseOCRProvider]] = {}
    _instances: Dict[str, BaseOCRProvider] = {}
    
    @classmethod
    def register(cls, name: str, provider_class: Type[BaseOCRProvider]):
        """
        Register an OCR provider.
        
        Args:
            name: Provider name (e.g., 'tesseract', 'lightonocr')
            provider_class: Provider class inheriting from BaseOCRProvider
            
        Example:
            OCRProviderRegistry.register('tesseract', TesseractProvider)
        """
        if not issubclass(provider_class, BaseOCRProvider):
            raise TypeError(
                f"Provider class must inherit from BaseOCRProvider, "
                f"got {provider_class}"
            )
        
        cls._providers[name.lower()] = provider_class
        print(f"Registered OCR provider: {name}")
    
    @classmethod
    def get_provider(
        cls,
        name: str,
        model_name: Optional[str] = None,
        use_cache: bool = True,
        **kwargs
    ) -> BaseOCRProvider:
        """
        Get an OCR provider instance.
        
        Args:
            name: Provider name
            model_name: Model name/path (optional)
            use_cache: Use cached instance if available
            **kwargs: Provider-specific parameters
            
        Returns:
            BaseOCRProvider: OCR provider instance
            
        Example:
            ocr = OCRProviderRegistry.get_provider(
                'lightonocr',
                model_name='lightonai/LightOnOCR-1B-1025'
            )
        """
        name_lower = name.lower()
        
        if name_lower not in cls._providers:
            available = ', '.join(cls._providers.keys())
            raise ValueError(
                f"OCR provider '{name}' not found. "
                f"Available providers: {available}"
            )
        
        # Check cache
        cache_key = f"{name_lower}_{model_name}"
        if use_cache and cache_key in cls._instances:
            return cls._instances[cache_key]
        
        # Create new instance
        provider_class = cls._providers[name_lower]
        instance = provider_class(model_name=model_name, **kwargs)
        
        # Cache instance
        if use_cache:
            cls._instances[cache_key] = instance
        
        return instance
    
    @classmethod
    def list_providers(cls) -> List[str]:
        """
        List all registered OCR providers.
        
        Returns:
            List[str]: Provider names
        """
        return list(cls._providers.keys())
    
    @classmethod
    def unregister(cls, name: str):
        """
        Unregister an OCR provider.
        
        Args:
            name: Provider name
        """
        name_lower = name.lower()
        if name_lower in cls._providers:
            del cls._providers[name_lower]
            # Clear cached instances
            cls._instances = {
                k: v for k, v in cls._instances.items() 
                if not k.startswith(name_lower)
            }
            print(f"Unregistered OCR provider: {name}")
    
    @classmethod
    def clear_cache(cls):
        """Clear all cached provider instances."""
        cls._instances.clear()
    
    @classmethod
    def get_provider_info(cls, name: str) -> Dict:
        """
        Get information about a registered provider.
        
        Args:
            name: Provider name
            
        Returns:
            dict: Provider information
        """
        name_lower = name.lower()
        if name_lower not in cls._providers:
            return {'error': f'Provider {name} not found'}
        
        provider_class = cls._providers[name_lower]
        return {
            'name': name,
            'class': provider_class.__name__,
            'module': provider_class.__module__,
            'doc': provider_class.__doc__
        }

