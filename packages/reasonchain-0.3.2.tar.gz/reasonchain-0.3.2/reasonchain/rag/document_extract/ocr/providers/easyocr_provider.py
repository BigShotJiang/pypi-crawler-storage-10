"""
EasyOCR Provider

Deep learning-based OCR with GPU acceleration.
Supports 80+ languages with high accuracy.
"""

from typing import Union, List, Dict, Any
from PIL import Image
import numpy as np

from ..base_ocr_provider import BaseOCRProvider


class EasyOCRProvider(BaseOCRProvider):
    """
    EasyOCR provider.
    
    Uses deep learning models for accurate text extraction.
    Supports GPU acceleration for faster processing.
    
    Example:
        ocr = EasyOCRProvider(languages=['en'], use_gpu=True)
        text = ocr.extract_text('document.png')
    """
    
    def _initialize(self, **kwargs):
        """Initialize EasyOCR reader."""
        try:
            import easyocr
        except ImportError:
            raise ImportError(
                "EasyOCR not installed. Install with: pip install easyocr"
            )
        
        self.languages = kwargs.get('languages', ['en'])
        self.use_gpu = kwargs.get('use_gpu', True)
        
        print(f"Initializing EasyOCR for languages: {self.languages}")
        self.reader = easyocr.Reader(
            self.languages,
            gpu=self.use_gpu,
            verbose=False
        )
    
    def extract_text(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text using EasyOCR.
        
        Args:
            image: Input image
            **kwargs:
                - detail: Return detailed results (default: 0)
                - paragraph: Group text by paragraph (default: False)
                
        Returns:
            str: Extracted text
        """
        try:
            # EasyOCR works best with numpy arrays or file paths
            if isinstance(image, Image.Image):
                image = np.array(image)
            elif isinstance(image, bytes):
                import io
                image = np.array(Image.open(io.BytesIO(image)))
            
            # Extract text
            results = self.reader.readtext(
                image,
                detail=0,  # Return only text, no boxes
                paragraph=kwargs.get('paragraph', False)
            )
            
            # Join text results
            if isinstance(results, list):
                return '\n'.join(results)
            return str(results)
            
        except Exception as e:
            print(f"EasyOCR error: {e}")
            return ""
    
    def extract_text_with_confidence(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Extract text with confidence scores and bounding boxes.
        
        Returns:
            dict: Text, confidence, words, and bounding boxes
        """
        try:
            # Convert to format EasyOCR expects
            if isinstance(image, Image.Image):
                image = np.array(image)
            elif isinstance(image, bytes):
                import io
                image = np.array(Image.open(io.BytesIO(image)))
            
            # Get detailed results
            results = self.reader.readtext(image, detail=1)
            
            # Extract information
            words = []
            boxes = []
            text_parts = []
            confidences = []
            
            for (bbox, text, confidence) in results:
                text_parts.append(text)
                confidences.append(confidence)
                
                # Convert bbox to simple format
                x_coords = [point[0] for point in bbox]
                y_coords = [point[1] for point in bbox]
                box = (min(x_coords), min(y_coords), 
                      max(x_coords) - min(x_coords), 
                      max(y_coords) - min(y_coords))
                
                words.append({
                    'text': text,
                    'confidence': confidence,
                    'box': box
                })
                boxes.append(box)
            
            # Calculate average confidence
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
            
            return {
                'text': '\n'.join(text_parts),
                'confidence': avg_confidence,
                'words': words,
                'boxes': boxes
            }
            
        except Exception as e:
            print(f"EasyOCR detailed extraction error: {e}")
            return {
                'text': self.extract_text(image, **kwargs),
                'confidence': 0.0,
                'words': [],
                'boxes': []
            }
    
    def extract_text_batch(
        self,
        images: List[Union[Image.Image, np.ndarray, str, bytes]],
        **kwargs
    ) -> List[str]:
        """
        Batch process multiple images.
        
        EasyOCR supports batch processing for better GPU utilization.
        """
        try:
            # Convert all images to numpy arrays
            processed_images = []
            for img in images:
                if isinstance(img, Image.Image):
                    processed_images.append(np.array(img))
                elif isinstance(img, bytes):
                    import io
                    processed_images.append(np.array(Image.open(io.BytesIO(img))))
                else:
                    processed_images.append(img)
            
            # Process batch
            results = []
            for img in processed_images:
                text = self.extract_text(img, **kwargs)
                results.append(text)
            
            return results
            
        except Exception as e:
            print(f"EasyOCR batch processing error: {e}")
            return [self.extract_text(img, **kwargs) for img in images]
    
    def get_supported_languages(self) -> List[str]:
        """Get list of supported languages."""
        return [
            'en', 'ch_sim', 'ch_tra', 'ja', 'ko', 'th', 'vi', 'ar', 'hi', 'bn',
            'ta', 'te', 'kn', 'ml', 'mr', 'ne', 'pa', 'sa', 'ur', 'fa', 'ru',
            'uk', 'be', 'bg', 'mk', 'sr', 'mn', 'abq', 'ady', 'kbd', 'ava', 'dar',
            'inh', 'che', 'lbe', 'lez', 'tab', 'de', 'fr', 'it', 'es', 'pt', 'nl',
            'pl', 'cs', 'sk', 'sl', 'hr', 'ro', 'hu', 'et', 'lv', 'lt', 'no', 'da',
            'sv', 'fi', 'is', 'ga', 'cy', 'mt', 'sq', 'az', 'tr', 'kk', 'uz', 'ky'
        ]
    
    def _get_provider_type(self) -> str:
        """Provider type."""
        return 'deep_learning_ocr'

