"""
Generic VLLM OCR Provider

Supports any vision-language model served via vLLM:
- LightOnOCR-1B-1025
- Qwen2-VL
- InternVL
- CogVLM
- Any custom VLM
"""

from typing import Union, List, Dict, Any
from PIL import Image
import numpy as np
import base64
import io

from ..base_ocr_provider import BaseOCRProvider


class VLLMOCRProvider(BaseOCRProvider):
    """
    Generic VLLM OCR provider for any vision-language model.
    
    Works with any VLM served through vLLM, including:
    - LightOnOCR models
    - Qwen2-VL models  
    - InternVL models
    - Custom vision-language models
    
    Example:
        # LightOnOCR
        ocr = VLLMOCRProvider(
            model_name='lightonai/LightOnOCR-1B-1025',
            endpoint='http://localhost:8000'
        )
        
        # Qwen2-VL
        ocr = VLLMOCRProvider(
            model_name='Qwen/Qwen2-VL-7B-Instruct',
            endpoint='http://localhost:8000',
            prompt_template='Extract all text from this image:'
        )
        
        # Custom model
        ocr = VLLMOCRProvider(
            model_name='your-org/your-vlm-model',
            endpoint='http://your-server:8000',
            prompt_template='OCR this document:'
        )
    """
    
    def _initialize(self, **kwargs):
        """Initialize VLLM OCR provider."""
        self.endpoint = kwargs.get('endpoint', 'http://localhost:8177')
        self.max_tokens = kwargs.get('max_tokens', 4096)
        self.temperature = kwargs.get('temperature', 0.2)
        self.top_p = kwargs.get('top_p', 0.9)
        
        # Prompt template for OCR task
        self.prompt_template = kwargs.get('prompt_template', '')
        
        # Image preprocessing
        self.target_size = kwargs.get('target_size', 1280)
        self.image_format = kwargs.get('image_format', 'PNG')
        
        # API configuration
        self.api_version = kwargs.get('api_version', 'v1')
        self.timeout = kwargs.get('timeout', 120)
        
        if not self.model_name:
            raise ValueError("model_name is required for VLLMOCRProvider")
        
        print(f"VLLM OCR Provider initialized")
        print(f"  Model: {self.model_name}")
        print(f"  Endpoint: {self.endpoint}")
        print(f"  Prompt: '{self.prompt_template}'")
    
    def extract_text(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text using VLLM-served vision-language model.
        
        Args:
            image: Input image
            **kwargs:
                - prompt: Custom prompt (overrides default)
                - max_tokens: Maximum tokens to generate
                - temperature: Sampling temperature
                - top_p: Top-p sampling
                
        Returns:
            str: Extracted text
        """
        try:
            import requests
            
            pil_image = self._preprocess_image(image)
            
            # Resize image if needed
            if self.target_size:
                pil_image = self._resize_image(pil_image)
            
            # Convert to base64
            buffer = io.BytesIO()
            pil_image.save(buffer, format=self.image_format)
            image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
            
            # Prepare prompt
            prompt = kwargs.get('prompt', self.prompt_template)
            
            # Build message content
            content = []
            if prompt:
                content.append({"type": "text", "text": prompt})
            content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/{self.image_format.lower()};base64,{image_base64}"
                }
            })
            
            # Prepare request payload
            payload = {
                "model": self.model_name,
                "messages": [{
                    "role": "user",
                    "content": content
                }],
                "max_tokens": kwargs.get('max_tokens', self.max_tokens),
                "temperature": kwargs.get('temperature', self.temperature),
                "top_p": kwargs.get('top_p', self.top_p),
            }
            
            # Make request
            response = requests.post(
                f"{self.endpoint}/{self.api_version}/chat/completions",
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            text = result['choices'][0]['message']['content']
            return text.strip()
            
        except Exception as e:
            print(f"VLLM OCR error: {e}")
            return ""
    
    def _resize_image(self, image: Image.Image) -> Image.Image:
        """Resize image to target size while maintaining aspect ratio."""
        width, height = image.size
        max_dim = max(width, height)
        
        if max_dim > self.target_size:
            scale = self.target_size / max_dim
            new_width = int(width * scale)
            new_height = int(height * scale)
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        return image
    
    def extract_text_batch(
        self,
        images: List[Union[Image.Image, np.ndarray, str, bytes]],
        **kwargs
    ) -> List[str]:
        """
        Batch process multiple images in parallel.
        """
        import concurrent.futures
        
        max_workers = kwargs.get('max_workers', 4)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(self.extract_text, img, **kwargs) 
                for img in images
            ]
            results = [f.result() for f in futures]
        
        return results
    
    def extract_from_pdf(
        self,
        pdf_path: str,
        page_numbers: Union[List[int], None] = None,
        dpi: int = 300,
        **kwargs
    ) -> List[str]:
        """
        Extract text from PDF with optimal rendering.
        
        Args:
            pdf_path: Path to PDF file
            page_numbers: Specific pages to process
            dpi: DPI for rendering (default: 300)
            **kwargs: Additional parameters
            
        Returns:
            List[str]: Text from each page
        """
        try:
            # Try pypdfium2 first (faster, better quality)
            import pypdfium2 as pdfium
            
            with open(pdf_path, 'rb') as f:
                pdf_data = f.read()
            
            pdf = pdfium.PdfDocument(pdf_data)
            
            if page_numbers is None:
                pages = range(len(pdf))
            else:
                pages = page_numbers
            
            results = []
            scale = dpi / 72.0  # Convert DPI to scale factor
            
            for page_idx in pages:
                page = pdf[page_idx]
                pil_image = page.render(scale=scale).to_pil()
                text = self.extract_text(pil_image, **kwargs)
                results.append(text)
            
            return results
            
        except ImportError:
            # Fallback to pdf2image
            from reasonchain.utils.lazy_imports import pdf2image
            
            if page_numbers:
                images = pdf2image.convert_from_path(
                    pdf_path,
                    dpi=dpi,
                    first_page=min(page_numbers),
                    last_page=max(page_numbers)
                )
            else:
                images = pdf2image.convert_from_path(pdf_path, dpi=dpi)
            
            return self.extract_text_batch(images, **kwargs)
    
    def _get_provider_type(self) -> str:
        """Provider type."""
        return 'llm_ocr'
    
    def get_supported_languages(self) -> List[str]:
        """
        Supported languages depend on the specific VLM model.
        Most modern VLMs support multilingual text.
        """
        return ['multilingual']
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check if the VLLM server is running and accessible.
        
        Returns:
            dict: Health status
        """
        try:
            import requests
            
            response = requests.get(
                f"{self.endpoint}/health",
                timeout=5
            )
            
            if response.status_code == 200:
                return {
                    'status': 'healthy',
                    'endpoint': self.endpoint,
                    'model': self.model_name
                }
            else:
                return {
                    'status': 'unhealthy',
                    'error': f'Status code: {response.status_code}'
                }
                
        except Exception as e:
            return {
                'status': 'unreachable',
                'error': str(e),
                'hint': f'Start server: vllm serve {self.model_name}'
            }

