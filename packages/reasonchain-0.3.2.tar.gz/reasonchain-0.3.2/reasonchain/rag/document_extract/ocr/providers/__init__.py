"""
Built-in OCR Providers

Traditional OCR and LLM-based OCR implementations.
"""

from .tesseract_provider import TesseractProvider
from .easyocr_provider import EasyOCRProvider
from .paddleocr_provider import PaddleOCRProvider
from .lightonocr_provider import LightOnOCRProvider
from .vllm_ocr_provider import VLLMOCRProvider

__all__ = [
    'TesseractProvider',
    'EasyOCRProvider',
    'PaddleOCRProvider',
    'LightOnOCRProvider',
    'VLLMOCRProvider',
]

