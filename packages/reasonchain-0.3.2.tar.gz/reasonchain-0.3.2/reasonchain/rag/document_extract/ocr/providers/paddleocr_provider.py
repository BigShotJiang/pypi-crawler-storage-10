"""
PaddleOCR Provider

High-performance OCR supporting 80+ languages.
Industrial-grade OCR from Baidu PaddlePaddle.
"""

from typing import Union, List, Dict, Any
from PIL import Image
import numpy as np

from ..base_ocr_provider import BaseOCRProvider


class PaddleOCRProvider(BaseOCRProvider):
    """
    PaddleOCR provider.
    
    Fast, accurate OCR supporting 80+ languages.
    Supports text detection, recognition, and layout analysis.
    
    Example:
        ocr = PaddleOCRProvider(lang='en', use_gpu=True)
        text = ocr.extract_text('document.png')
    """
    
    def _initialize(self, **kwargs):
        """Initialize PaddleOCR."""
        try:
            from paddleocr import PaddleOCR
        except ImportError:
            raise ImportError(
                "PaddleOCR not installed. Install with: "
                "pip install paddleocr paddlepaddle-gpu"
            )
        
        self.lang = kwargs.get('lang', 'en')
        self.use_gpu = kwargs.get('use_gpu', True)
        self.use_angle_cls = kwargs.get('use_angle_cls', True)  # Text direction classification
        self.show_log = kwargs.get('show_log', False)
        
        print(f"Initializing PaddleOCR (lang={self.lang}, gpu={self.use_gpu})")
        self.ocr = PaddleOCR(
            use_angle_cls=self.use_angle_cls,
            lang=self.lang,
            use_gpu=self.use_gpu,
            show_log=self.show_log
        )
    
    def extract_text(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text using PaddleOCR.
        
        Args:
            image: Input image
            **kwargs:
                - cls: Use angle classification (default: True)
                - det: Use text detection (default: True)
                - rec: Use text recognition (default: True)
                
        Returns:
            str: Extracted text
        """
        try:
            # Convert to format PaddleOCR expects
            if isinstance(image, Image.Image):
                image = np.array(image)
            elif isinstance(image, bytes):
                import io
                image = np.array(Image.open(io.BytesIO(image)))
            elif isinstance(image, str):
                # File path - PaddleOCR can handle this directly
                pass
            
            # Run OCR
            cls = kwargs.get('cls', True)
            det = kwargs.get('det', True)
            rec = kwargs.get('rec', True)
            
            result = self.ocr.ocr(image, cls=cls, det=det, rec=rec)
            
            # Extract text from results
            if result and result[0]:
                texts = [line[1][0] for line in result[0]]
                return '\n'.join(texts)
            return ""
            
        except Exception as e:
            print(f"PaddleOCR error: {e}")
            return ""
    
    def extract_text_with_confidence(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Extract text with confidence scores and bounding boxes.
        
        Returns:
            dict: Text, confidence, words, and bounding boxes
        """
        try:
            # Convert image
            if isinstance(image, Image.Image):
                image = np.array(image)
            elif isinstance(image, bytes):
                import io
                image = np.array(Image.open(io.BytesIO(image)))
            
            # Run OCR
            result = self.ocr.ocr(image, cls=True)
            
            if not result or not result[0]:
                return {
                    'text': '',
                    'confidence': 0.0,
                    'words': [],
                    'boxes': []
                }
            
            # Extract information
            words = []
            boxes = []
            text_parts = []
            confidences = []
            
            for line in result[0]:
                bbox = line[0]  # [top-left, top-right, bottom-right, bottom-left]
                text, confidence = line[1]
                
                text_parts.append(text)
                confidences.append(confidence)
                
                # Convert bbox to simple format (x, y, width, height)
                x_coords = [point[0] for point in bbox]
                y_coords = [point[1] for point in bbox]
                box = (
                    min(x_coords), 
                    min(y_coords),
                    max(x_coords) - min(x_coords),
                    max(y_coords) - min(y_coords)
                )
                
                words.append({
                    'text': text,
                    'confidence': confidence,
                    'box': box
                })
                boxes.append(box)
            
            # Calculate average confidence
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
            
            return {
                'text': '\n'.join(text_parts),
                'confidence': avg_confidence,
                'words': words,
                'boxes': boxes
            }
            
        except Exception as e:
            print(f"PaddleOCR detailed extraction error: {e}")
            return {
                'text': self.extract_text(image, **kwargs),
                'confidence': 0.0,
                'words': [],
                'boxes': []
            }
    
    def extract_text_batch(
        self,
        images: List[Union[Image.Image, np.ndarray, str, bytes]],
        **kwargs
    ) -> List[str]:
        """
        Batch process multiple images.
        
        PaddleOCR supports efficient batch processing.
        """
        try:
            # Convert images to numpy arrays
            processed_images = []
            for img in images:
                if isinstance(img, Image.Image):
                    processed_images.append(np.array(img))
                elif isinstance(img, bytes):
                    import io
                    processed_images.append(np.array(Image.open(io.BytesIO(img))))
                else:
                    processed_images.append(img)
            
            # Process batch
            results = []
            for img in processed_images:
                text = self.extract_text(img, **kwargs)
                results.append(text)
            
            return results
            
        except Exception as e:
            print(f"PaddleOCR batch error: {e}")
            return [self.extract_text(img, **kwargs) for img in images]
    
    def get_supported_languages(self) -> List[str]:
        """Get list of supported languages."""
        return [
            'en', 'ch', 'ta', 'te', 'ka', 'kn', 'ml', 'pa', 'sa', 'mr', 'ne',
            'hi', 'fa', 'ur', 'ar', 'oc', 'rua', 'rs_cyrillic', 'rs_latin',
            'be', 'uk', 'el', 'la', 'it', 'xi', 'pu', 'ru', 'pt', 'nl', 'et',
            'be', 'bg', 'uk', 'rs_latin', 'ug', 'fa', 'ur', 'arabic', 'korean',
            'japan', 'chinese_cht', 'french', 'german', 'korean', 'japan'
        ]
    
    def _get_provider_type(self) -> str:
        """Provider type."""
        return 'deep_learning_ocr'

