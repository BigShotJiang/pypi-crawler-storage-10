"""
Tesseract OCR Provider

Traditional OCR using Tesseract engine.
Fast, reliable, supports 100+ languages.
"""

from typing import Union, List, Dict, Any
from PIL import Image
import numpy as np

from ..base_ocr_provider import BaseOCRProvider


class TesseractProvider(BaseOCRProvider):
    """
    Tesseract OCR provider.
    
    Uses pytesseract (Python wrapper for Tesseract OCR).
    
    Example:
        ocr = TesseractProvider(language='eng')
        text = ocr.extract_text('document.png')
    """
    
    def _initialize(self, **kwargs):
        """Initialize Tesseract OCR."""
        from reasonchain.utils.lazy_imports import pytesseract
        
        self.pytesseract = pytesseract
        self.language = kwargs.get('language', 'eng')
        self.config = kwargs.get('config', '--psm 3')  # Page segmentation mode
        
        # Custom Tesseract path if provided
        tesseract_cmd = kwargs.get('tesseract_cmd')
        if tesseract_cmd:
            self.pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
    
    def extract_text(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text using Tesseract.
        
        Args:
            image: Input image
            **kwargs: 
                - language: Language code (default: self.language)
                - config: Tesseract config (default: self.config)
                
        Returns:
            str: Extracted text
        """
        try:
            pil_image = self._preprocess_image(image)
            
            language = kwargs.get('language', self.language)
            config = kwargs.get('config', self.config)
            
            text = self.pytesseract.image_to_string(
                pil_image,
                lang=language,
                config=config
            )
            
            return text.strip()
            
        except Exception as e:
            print(f"Tesseract OCR error: {e}")
            return ""
    
    def extract_text_with_confidence(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Extract text with confidence scores and bounding boxes.
        
        Returns:
            dict: Text, confidence, words, and bounding boxes
        """
        try:
            pil_image = self._preprocess_image(image)
            
            language = kwargs.get('language', self.language)
            
            # Get detailed data
            data = self.pytesseract.image_to_data(
                pil_image,
                lang=language,
                output_type=self.pytesseract.Output.DICT
            )
            
            # Extract full text
            text = self.pytesseract.image_to_string(pil_image, lang=language).strip()
            
            # Calculate average confidence
            confidences = [int(conf) for conf in data['conf'] if conf != '-1']
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
            
            # Extract words with details
            words = []
            boxes = []
            n_boxes = len(data['text'])
            for i in range(n_boxes):
                if int(data['conf'][i]) > 0:
                    word_info = {
                        'text': data['text'][i],
                        'confidence': int(data['conf'][i]) / 100.0,
                        'box': (data['left'][i], data['top'][i], 
                               data['width'][i], data['height'][i])
                    }
                    words.append(word_info)
                    boxes.append(word_info['box'])
            
            return {
                'text': text,
                'confidence': avg_confidence / 100.0,
                'words': words,
                'boxes': boxes
            }
            
        except Exception as e:
            print(f"Tesseract detailed extraction error: {e}")
            return {
                'text': self.extract_text(image, **kwargs),
                'confidence': 0.0,
                'words': [],
                'boxes': []
            }
    
    def get_supported_languages(self) -> List[str]:
        """Get list of installed Tesseract languages."""
        try:
            langs = self.pytesseract.get_languages()
            return langs
        except Exception:
            return ['eng']  # Default fallback
    
    def supports_language(self, language: str) -> bool:
        """Check if language is supported."""
        return language in self.get_supported_languages()

