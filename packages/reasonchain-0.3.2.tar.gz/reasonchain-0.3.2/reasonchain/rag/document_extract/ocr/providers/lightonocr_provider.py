"""
LightOnOCR Provider

State-of-the-art LLM-based OCR for documents.
https://huggingface.co/lightonai/LightOnOCR-1B-1025

Fast, accurate, end-to-end vision-language model for OCR and document understanding.
"""

from typing import Union, List, Dict, Any
from PIL import Image
import numpy as np
import base64
import io

from ..base_ocr_provider import BaseOCRProvider


class LightOnOCRProvider(BaseOCRProvider):
    """
    LightOnOCR provider - Modern LLM-based OCR.
    
    Uses LightOnOCR-1B vision-language model for accurate document understanding.
    Handles tables, receipts, forms, multi-column layouts, and math notation.
    
    Reference: https://huggingface.co/lightonai/LightOnOCR-1B-1025
    
    Performance:
    - 5× faster than traditional VLM-based OCR
    - Processes 5.71 pages/s on H100 (~493k pages/day)
    - Cost: <$0.01 per 1,000 pages
    
    Example:
        # Using vLLM server
        ocr = LightOnOCRProvider(
            model_name='lightonai/LightOnOCR-1B-1025',
            endpoint='http://localhost:8000'
        )
        text = ocr.extract_text('document.png')
        
        # Or use HuggingFace Transformers (slower, for local inference)
        ocr = LightOnOCRProvider(
            model_name='lightonai/LightOnOCR-1B-1025',
            use_transformers=True
        )
    """
    
    def _initialize(self, **kwargs):
        """Initialize LightOnOCR model."""
        self.endpoint = kwargs.get('endpoint', 'http://localhost:8177')
        self.use_transformers = kwargs.get('use_transformers', False)
        self.max_tokens = kwargs.get('max_tokens', 6500)
        self.temperature = kwargs.get('temperature', 0.2)
        self.top_p = kwargs.get('top_p', 0.9)
        
        if not self.model_name:
            self.model_name = 'lightonai/LightOnOCR-1B-1025'
        
        if self.use_transformers:
            self._initialize_transformers()
        else:
            # Using vLLM server (recommended for production)
            print(f"LightOnOCR configured to use vLLM server at {self.endpoint}")
            print(f"Model: {self.model_name}")
            print(f"To start server: vllm serve {self.model_name} --limit-mm-per-prompt '{{\"image\": 1}}'")
    
    def _initialize_transformers(self):
        """Initialize using HuggingFace Transformers (for local inference)."""
        try:
            from transformers import AutoProcessor, AutoModelForVision2Seq
            import torch
            
            print(f"Loading LightOnOCR model: {self.model_name}")
            self.processor = AutoProcessor.from_pretrained(self.model_name)
            self.model = AutoModelForVision2Seq.from_pretrained(
                self.model_name,
                torch_dtype=torch.bfloat16,
                device_map="auto"
            )
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            print(f"Model loaded on {self.device}")
            
        except ImportError:
            raise ImportError(
                "Transformers not installed. Install with: "
                "pip install transformers torch"
            )
        except Exception as e:
            raise RuntimeError(f"Failed to load LightOnOCR model: {e}")
    
    def extract_text(
        self,
        image: Union[Image.Image, np.ndarray, str, bytes],
        **kwargs
    ) -> str:
        """
        Extract text using LightOnOCR.
        
        Args:
            image: Input image
            **kwargs:
                - max_tokens: Maximum tokens to generate
                - temperature: Sampling temperature
                - top_p: Top-p sampling
                
        Returns:
            str: Extracted text
        """
        try:
            pil_image = self._preprocess_image(image)
            
            # Resize to optimal dimensions (longest edge = 1280-1300px)
            pil_image = self._resize_for_ocr(pil_image)
            
            if self.use_transformers:
                return self._extract_with_transformers(pil_image, **kwargs)
            else:
                return self._extract_with_vllm(pil_image, **kwargs)
                
        except Exception as e:
            print(f"LightOnOCR error: {e}")
            return ""
    
    def _resize_for_ocr(self, image: Image.Image, target_size: int = 1280) -> Image.Image:
        """
        Resize image to optimal size for LightOnOCR.
        
        Target: longest dimension = 1280-1300px while maintaining aspect ratio.
        """
        width, height = image.size
        max_dim = max(width, height)
        
        if max_dim > target_size:
            scale = target_size / max_dim
            new_width = int(width * scale)
            new_height = int(height * scale)
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        return image
    
    def _extract_with_vllm(self, image: Image.Image, **kwargs) -> str:
        """Extract text using vLLM server."""
        import requests
        
        # Convert image to base64
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        
        # Prepare request
        payload = {
            "model": self.model_name,
            "messages": [{
                "role": "user",
                "content": [{
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{image_base64}"}
                }]
            }],
            "max_tokens": kwargs.get('max_tokens', self.max_tokens),
            "temperature": kwargs.get('temperature', self.temperature),
            "top_p": kwargs.get('top_p', self.top_p),
        }
        
        # Make request
        try:
            response = requests.post(
                f"{self.endpoint}/v1/chat/completions",
                json=payload,
                timeout=60
            )
            
            # Check for error responses
            if response.status_code != 200:
                error_detail = ""
                try:
                    error_json = response.json()
                    error_detail = f"\nServer error: {error_json}"
                except:
                    error_detail = f"\nResponse: {response.text[:500]}"
                
                raise RuntimeError(
                    f"vLLM server returned {response.status_code}: {response.reason}"
                    f"{error_detail}\n"
                    f"Make sure the server is running correctly: "
                    f"./start_lightonocr_server.sh"
                )
            
            result = response.json()
            text = result['choices'][0]['message']['content']
            return text.strip()
            
        except requests.exceptions.RequestException as e:
            raise RuntimeError(
                f"vLLM server request failed: {e}\n"
                f"Make sure the server is running: "
                f"./start_lightonocr_server.sh"
            )
    
    def _extract_with_transformers(self, image: Image.Image, **kwargs) -> str:
        """Extract text using HuggingFace Transformers."""
        import torch
        
        # Process image
        inputs = self.processor(images=image, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            generated_ids = self.model.generate(
                **inputs,
                max_new_tokens=kwargs.get('max_tokens', self.max_tokens),
                temperature=kwargs.get('temperature', self.temperature),
                top_p=kwargs.get('top_p', self.top_p),
            )
        
        # Decode
        text = self.processor.batch_decode(
            generated_ids,
            skip_special_tokens=True
        )[0]
        
        return text.strip()
    
    def extract_text_batch(
        self,
        images: List[Union[Image.Image, np.ndarray, str, bytes]],
        **kwargs
    ) -> List[str]:
        """
        Batch process multiple images.
        
        LightOnOCR with vLLM supports efficient batch processing.
        """
        if self.use_transformers:
            # Transformers: process sequentially
            return [self.extract_text(img, **kwargs) for img in images]
        
        # vLLM: can process in parallel
        import concurrent.futures
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = [
                executor.submit(self.extract_text, img, **kwargs) 
                for img in images
            ]
            results = [f.result() for f in futures]
        
        return results
    
    def extract_from_pdf(
        self,
        pdf_path: str,
        page_numbers: Union[List[int], None] = None,
        **kwargs
    ) -> List[str]:
        """
        Extract text from PDF using LightOnOCR.
        
        Optimized for PDF rendering at correct DPI.
        """
        try:
            import pypdfium2 as pdfium
        except ImportError:
            # Fallback to pdf2image
            return super().extract_from_pdf(pdf_path, page_numbers, **kwargs)
        
        # Open PDF
        with open(pdf_path, 'rb') as f:
            pdf_data = f.read()
        
        pdf = pdfium.PdfDocument(pdf_data)
        
        # Determine pages to process
        if page_numbers is None:
            pages = range(len(pdf))
        else:
            pages = page_numbers
        
        # Convert pages to images and extract text
        results = []
        for page_idx in pages:
            page = pdf[page_idx]
            # Render at 300 DPI (scale factor = 300/72 ≈ 4.17)
            pil_image = page.render(scale=4.17).to_pil()
            text = self.extract_text(pil_image, **kwargs)
            results.append(text)
        
        return results
    
    def _get_provider_type(self) -> str:
        """Provider type."""
        return 'llm_ocr'
    
    def get_supported_languages(self) -> List[str]:
        """
        LightOnOCR supports multiple languages with focus on Latin alphabet.
        
        Variants:
        - LightOnOCR-1B-1025: Full multilingual (151k vocab)
        - LightOnOCR-1B-32k: European languages optimized (32k vocab)
        - LightOnOCR-1B-16k: Most compact (16k vocab)
        """
        return [
            'en', 'fr', 'de', 'es', 'it', 'pt', 'nl', 'pl', 'cs', 'sk',
            'ro', 'hu', 'fi', 'sv', 'no', 'da', 'multilingual'
        ]

