import argparse
import inspect
import importlib.util
import sys
import pathlib

from configs.config_manager import ConfigManager
from services.files_service import FilesService
from services.todo_service import TodoService
from src.apps.base_app import BaseApp


class CLI:
    """Main command-line interface providing the user experience."""

    def __init__(self):
        self.config_manager = ConfigManager()
        self.todo_service = TodoService()
        self.parser = self._build_parser()

    # -----------------------------
    # CLI Setup
    # -----------------------------

    def _build_parser(self) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            description="TODO-to-Task CLI — manage and sync TODOs with task apps",
            add_help=False
        )

        subparsers = parser.add_subparsers(dest="command", required=True)
        parser.add_argument("-h", "--help", "-?", action="help", help="Show help message and exit")

        # configure
        configure_parser = subparsers.add_parser("configure", help="Set up a specific app")
        configure_parser.add_argument("app", help="App name to configure")

        # apps
        subparsers.add_parser("apps", help="List all active and available apps")

        # remove
        remove_parser = subparsers.add_parser("remove", help="Remove app")
        remove_parser.add_argument("app", help="App name to remove")

        # run
        run_parser = subparsers.add_parser("run", help="Scan codebase and export TODOs")
        run_parser.add_argument("--apps", type=str, help="Comma-separated list of apps to write to")
        run_parser.add_argument("-n", "--noignore", action="store_true", help="Include git-ignored files")
        run_parser.add_argument("--ignore", type=str, help="Path to custom ignore file or directory")
        run_parser.add_argument("-dir", type=str, help="Directory to scan")
        run_parser.add_argument("-r", action="store_true", help="Recursively scan directory")

        return parser

    # -----------------------------
    # Command Runner
    # -----------------------------

    def run(self, argv: list[str]):
        args = self.parser.parse_args(argv)
        command = args.command

        command_map = {
            "configure": lambda: self._configure_app(args.app),
            "apps": lambda: self._list_apps(),
            "remove": lambda: self._remove(args.app),
            "run": lambda: self._run_scan(args),
        }

        handler = command_map.get(command)
        if handler:
            handler()
        else:
            print(f"❌ Unknown command: {command}")

    # -----------------------------
    # Command Implementations
    # -----------------------------

    def _remove(self, app: str):
        config = self.config_manager.load()
        if app in config["connected_apps"]:
            del config["connected_apps"][app]
        if app in config.get("apps_config", {}):
            del config["apps_config"][app]
        self.config_manager.save(config)
        print(f"🗑️  Removed credentials for {app}.")

    def _configure_app(self, app_name: str):
        config = self.config_manager.load()
        app_meta = next((a for a in config["available_apps"] if a["name"].lower() == app_name.lower()), None)
        if not app_meta:
            print(f"❌ App '{app_name}' not found.")
            return

        app_class = self._load_app_class(app_meta)
        if not app_class:
            print(f"❌ Failed to load app '{app_name}'.")
            return

        current_config = self.config_manager.load_app_config(app_meta["name"])
        app_instance = app_class(current_config)
        new_config = app_instance.configure()
        self.config_manager.save_app_config(app_meta["name"], new_config)
        print(f"✅ Configuration for '{app_meta['name']}' saved successfully.")

    def _run_scan(self, args):
        config = self.config_manager.load()

        files_service = FilesService(
            include_ignored=args.noignore,
            ignore_file=args.ignore,
            directory=args.dir,
            recursive=args.r or True,
        )

        files = files_service.get_files()
        todos = self.todo_service.get_todos(files)

        print(f"📁 Scanned {len(files)} files and found {len(todos)} TODOs.")

        if not args.apps:
            print("⚠️  No apps specified. Use --apps to define export targets.")
            return

        target_apps = [a.strip() for a in args.apps.split(",")]
        for app_name in target_apps:
            app_meta = next((a for a in config["available_apps"] if a["name"].lower() == app_name.lower()), None)
            if not app_meta:
                print(f"❌ Unknown app '{app_name}', skipping.")
                continue

            connected = config["connected_apps"].get(app_meta["name"], {}).get("status") == "connected"
            if not connected:
                print(f"⚠️  App '{app_meta['name']}' is not connected. Skipping.")
                continue

            app_class = self._load_app_class(app_meta)
            if not app_class:
                print(f"❌ Failed to load app '{app_meta['name']}'.")
                continue

            app_config = self.config_manager.load_app_config(app_meta["name"])
            app_instance = app_class(app_config)

            print(f"🚀 Exporting TODOs to {app_meta['name']}...")
            app_instance.write_todos(todos)
            print(f"✅ Exported {len(todos)} TODOs to {app_meta['name']}")

        print("🎉 All done!")

    def _list_apps(self):
        config = self.config_manager.load()
        connected = config.get("connected_apps", {})
        available = config.get("available_apps", [])

        print("\nAvailable Apps:")
        for app in available:
            status = connected.get(app["name"], {}).get("status", "not connected")
            print(f"  • {app['name']} [{status}] — {app['description']}")
        print()

    # -----------------------------
    # Dynamic App Loading
    # -----------------------------

    def _load_app_class(self, app_meta: dict):
        """Dynamically load an app class inheriting from BaseApp."""
        try:
            path = pathlib.Path(app_meta["path"])
            spec = importlib.util.spec_from_file_location(app_meta["name"], str(path))
            module = importlib.util.module_from_spec(spec)
            sys.modules[app_meta["name"]] = module
            spec.loader.exec_module(module)
        except Exception as e:
            print(f"❌ Failed to import {app_meta['name']}: {e}")
            return None

        for _, cls in inspect.getmembers(module, inspect.isclass):
            if issubclass(cls, BaseApp) and cls is not BaseApp:
                return cls
        return None
