from typing import Any, Optional
from apps.asana.api.asana_api import AsanaApi
from models.todo import Todo


class TasksApi:
    def __init__(self, asana_api):
        self.asana: AsanaApi = asana_api
    
    def create_tasks_in_batch(self, todos: list[Todo], project: Optional[str], parent: Optional[str]):
        batches = []
        actions = []

        for todo in todos:
            actions.append(self._create_batch_action(
                relative_path='/tasks',
                method='post',
                data={
                    'name': todo.summary,
                    'notes': f"f{todo.body}\n\nf{todo.file_path}:{todo.line}",
                    'parent': parent if parent else None,
                    'projects': [project] if project else []
                }
            ))

            if actions.__len__() > 9:
                batches.append(actions)
                actions.clear()

        for actions in batches:
            self.asana.post('/batch', {
                'actions': actions
            })

    def _create_batch_action(self, relative_path: str, method: str, data: dict[str, Any]):
        return {
            'relative_path': relative_path,
            'method': method,
            'data': data
        }
