class Certificate(object):

    def __init__(self, service_account_json):
        self.service_account_json = service_account_json
