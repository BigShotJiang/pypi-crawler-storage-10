import random
import numpy as np
from ase import Atoms
from icet.core.sublattices import Sublattices
from icet.tools.geometry import atomic_number_to_chemical_symbol


class SwapNotPossibleError(Exception):
    pass


class ConfigurationManager(object):
    """
    The ConfigurationManager owns and handles information pertaining to a
    configuration being sampled in a Monte Carlo simulation.

    Note
    ----
    As a user you will usually not interact directly with objects of this type.

    Parameters
    ----------
    structure : Atoms
        Configuration to be handled.
    sublattices : :class:`Sublattices <icet.core.sublattices.Sublattices>`
        Sublattices used to define allowed occupations and handle related information.
    """

    def __init__(self, structure: Atoms, sublattices: Sublattices) -> None:
        self._structure = structure.copy()
        self._occupations = self._structure.numbers
        self._sublattices = sublattices
        self._sites_by_species = self._get_sites_by_species()

    def _get_sites_by_species(self) -> list[dict[int, list[int]]]:
        """Returns the sites that are occupied for each species.  Each
        dictionary represents one sublattice where the key is the
        species (by atomic number) and the value is the list of sites
        occupied by said species in the respective sublattice.
        """
        sites_by_species = []
        for sl in self._sublattices:
            species_dict = {key: [] for key in sl.atomic_numbers}
            for site in sl.indices:
                species_dict[self._occupations[site]].append(site)
            sites_by_species.append(species_dict)
        return sites_by_species

    @property
    def occupations(self) -> np.ndarray:
        """ Occupation vector of the configuration (copy). """
        return self._occupations.copy()

    @property
    def sublattices(self) -> Sublattices:
        """ Sublattices of the configuration. """
        return self._sublattices

    @property
    def structure(self) -> Atoms:
        """ Atomic structure associated with configuration (copy). """
        structure = self._structure.copy()
        structure.set_atomic_numbers(self.occupations)
        return structure

    def get_occupations_on_sublattice(self, sublattice_index: int) -> list[int]:
        """
        Returns the occupations on one sublattice.

        Parameters
        ---------
        sublattice_index
            Sublattice by index for which the occupations should be returned.
        """
        sl = self.sublattices[sublattice_index]
        return list(self.occupations[sl.indices])

    def is_swap_possible(self, sublattice_index: int,
                         allowed_species: list[int] = None) -> bool:
        """ Checks if a swap trial move is possible on a specific sublattice.

        Parameters
        ----------
        sublattice_index
            Index of sublattice to be checked.
        allowed_species
            List of atomic numbers for allowed species.
         """
        sl = self.sublattices[sublattice_index]
        if allowed_species is None:
            swap_symbols = set(self.occupations[sl.indices])
        else:
            swap_symbols = set([o for o in self.occupations[sl.indices] if o in
                                allowed_species])
        return len(swap_symbols) > 1

    def get_swapped_state(self, sublattice_index: int,
                          allowed_species: list[int] = None,
                          allowed_sites: list[int] = None
                          ) -> tuple[list[int], list[int]]:
        """Returns two random sites (first element of tuple) and their
        occupation after a swap (second element of tuple).  The new
        configuration will obey the occupation constraints associated
        with the :class:`ConfigurationManager` object.

        Parameters
        ----------
        sublattice_index
            Sublattice by index from which to pick sites.
        allowed_species
            List of atomic numbers for allowed species.
        allowed_sites
            List of indices for allowed sites.
        """
        # pick the first site
        if allowed_species is None:
            available_sites = self.sublattices[sublattice_index].indices
        else:
            available_sites = [
                s for Z in allowed_species for s in
                self._get_sites_by_species()[sublattice_index][Z]]

        # only include allowed sites
        if allowed_sites is not None:
            available_sites = list(set(available_sites).intersection(allowed_sites))

        try:
            site1 = random.choice(available_sites)
        except IndexError:
            raise SwapNotPossibleError(f'Sublattice {sublattice_index} is empty.')

        # pick the second site
        if allowed_species is None:
            possible_swap_species = \
                set(self._sublattices.get_allowed_numbers_on_site(site1)) - \
                set([self._occupations[site1]])
        else:
            possible_swap_species = \
                set(allowed_species) - set([self._occupations[site1]])
        possible_swap_sites = []
        for Z in possible_swap_species:
            possible_swap_sites.extend(self._sites_by_species[sublattice_index][Z])

        # only include allowed sites
        if allowed_sites is not None:
            possible_swap_sites = list(set(possible_swap_sites).intersection(allowed_sites))

        possible_swap_sites = np.array(possible_swap_sites)

        try:
            site2 = random.choice(possible_swap_sites)
        except IndexError:
            raise SwapNotPossibleError(
                'Cannot swap on sublattice {} since it is full of {} species .'
                .format(sublattice_index,
                        atomic_number_to_chemical_symbol([self._occupations[site1]])[0]))

        return ([site1, site2], [self._occupations[site2], self._occupations[site1]])

    def get_flip_state(
            self,
            sublattice_index: int,
            allowed_species: list[int] = None,
            allowed_sites: list[int] = None
            ) -> tuple[int, int]:
        """
        Returns a site index and a new species for the site.

        Parameters
        ----------
        sublattice_index
            Index of sublattice from which to pick a site.
        allowed_species
            List of atomic numbers for allowed species.
        allowed_sites
            List of indices for allowed sites.
        """
        if allowed_species is None:
            available_sites = self._sublattices[sublattice_index].indices
        else:
            available_sites = [s for Z in allowed_species for s in
                               self._get_sites_by_species()[sublattice_index][Z]]

        # only include allowed sites
        if allowed_sites is not None:
            available_sites = list(set(available_sites).intersection(allowed_sites))

        site = random.choice(available_sites)
        if allowed_species is not None:
            species = random.choice(list(
                set(allowed_species) - set([self._occupations[site]])))
        else:
            species = random.choice(list(
                set(self._sublattices[sublattice_index].atomic_numbers) -
                set([self._occupations[site]])))
        return site, species

    def update_occupations(self, sites: list[int], species: list[int]) -> None:
        """
        Updates the occupation vector of the configuration being sampled.
        This will change the state in both the configuration in the calculator
        and the configuration manager.

        Parameters
        ----------
        sites
            Indices of sites of the configuration to change.
        species
            New occupations by atomic number.
        """

        # Update sublattices
        for site, new_Z in zip(sites, species):
            if 0 > new_Z > 118:
                raise ValueError('Invalid new species {} on site {}'.format(new_Z, site))
            if len(self._occupations) >= site < 0:
                raise ValueError('Site {} is not a valid site index'.format(site))
            old_Z = self._occupations[site]
            sublattice_index = self.sublattices.get_sublattice_index_from_site_index(site)

            if new_Z not in self.sublattices[sublattice_index].atomic_numbers:
                raise ValueError('Invalid new species {} on site {}'.format(new_Z, site))

            # Remove site from list of sites for old species
            self._sites_by_species[sublattice_index][old_Z].remove(site)
            # Add site to list of sites for new species
            try:
                self._sites_by_species[sublattice_index][new_Z].append(site)
            except KeyError:
                raise ValueError('Invalid new species {} on site {}'.format(new_Z, site))

        # Update occupation vector itself
        self._occupations[sites] = species
