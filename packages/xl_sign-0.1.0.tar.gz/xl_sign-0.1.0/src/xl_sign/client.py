"""
xl_sign 主类 - 提供单方签署功能
"""
from xl_sign import esigntool
from xl_sign.esigntool.esign_file import fileHelp
import requests
import time


class SignClient:
    """
    签署客户端，提供单方企业合同签署功能
    """
    
    def __init__(self, app_id=None, secret=None, host=None):
        """
        初始化签署客户端
        :param app_id: 应用AppId（可选，如果未提供则使用默认配置）
        :param secret: 应用密钥（可选，如果未提供则使用默认配置）
        :param host: API地址（可选，如果未提供则使用默认配置）
        """
        self.config = esigntool.config()
        if app_id:
            self.config.appId = app_id
        if secret:
            self.config.scert = secret
        if host:
            self.config.host = host
    
    def _find_org_identity_info(self, org_name):
        """
        查询机构认证信息（私有方法）
        :param org_name: 企业名称
        :return: 企业ID
        """
        if not org_name:
            raise ValueError("请设置实名企业名称")
        
        api_path = "/v3/organizations/identity-info?orgName={}".format(org_name)
        method = esigntool.httpMethodEnum.GET
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            esigntool.apiPathSort(api_path)
        )
        resp = requests.request(method, self.config.host + api_path, json=None, headers=json_headers)
        resp_json = resp.json()
        if resp_json.get('code') != 0:
            raise Exception(f"查询企业信息失败: {resp_json.get('message', '未知错误')}")
        return resp_json['data']['orgId']
    
    def _get_org_seal_list(self, org_id, seal_name=None):
        """
        查询企业内部印章列表（私有方法）
        :param org_id: 企业ID
        :param seal_name: 印章名称（可选），如果指定则查找匹配的印章
        :return: 印章列表或指定印章ID
        """
        page_num = 1
        page_size = 20
        api_path = "/v3/seals/org-own-seal-list?orgId={}&pageNum={}&pageSize={}".format(
            org_id, page_num, page_size
        )
        method = esigntool.httpMethodEnum.GET
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path
        )
        resp = requests.request(method, self.config.host + api_path, json=None, headers=json_headers)
        resp_json = resp.json()
        
        if resp_json.get('code') != 0:
            error_msg = resp_json.get('message', '未知错误')
            raise Exception(f"查询印章列表失败: {error_msg}")
        
        data = resp_json.get('data')
        if data is None:
            raise Exception("响应数据为空")
        
        seal_list = data.get('seals', [])
        
        if seal_name:
            for seal in seal_list:
                if seal.get('sealName') == seal_name:
                    return seal.get('sealId')
            available_seals = [seal.get('sealName') for seal in seal_list]
            raise ValueError(
                f"未找到名称为 '{seal_name}' 的印章。可用印章列表: {available_seals}"
            )
        
        return seal_list
    
    def _get_file_upload_url(self, file):
        """
        获取文件上传地址（私有方法）
        :param file: 文件对象
        :return: (fileUploadUrl, fileId)
        """
        content_type = "application/pdf"
        body = {
            "contentMd5": file.contentMd5,
            "contentType": content_type,
            "convert2Pdf": False,
            "fileName": file.fileName,
            "fileSize": file.fileSize
        }
        api_path = "/v3/files/file-upload-url"
        method = esigntool.httpMethodEnum.POST
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path, 
            body
        )
        resp = requests.request(method, self.config.host + api_path, json=body, headers=json_headers)
        resp_json = resp.json()
        if resp_json.get('code') != 0:
            raise Exception(f"获取文件上传地址失败: {resp_json.get('message', '未知错误')}")
        return resp_json['data']['fileUploadUrl'], resp_json['data']['fileId']
    
    def _file_stream_upload(self, file, binfile, file_upload_url):
        """
        文件流上传服务器（私有方法）
        :param file: 文件对象
        :param binfile: 文件二进制数据
        :param file_upload_url: 上传地址
        :return: 响应对象
        """
        content_md5 = file.contentMd5
        content_type = "application/pdf"
        method = esigntool.httpMethodEnum.PUT
        json_headers = esigntool.buildFileUploadHeader(content_type, content_md5)
        resp = requests.request(method, file_upload_url, data=binfile, headers=json_headers)
        return resp
    
    def _sign_flow_detail(self, sign_flow_id):
        """
        查询签署流程详情（私有方法）
        :param sign_flow_id: 签署流程ID
        :return: 流程详情
        """
        api_path = "/v3/sign-flow/{}/detail".format(sign_flow_id)
        method = esigntool.httpMethodEnum.GET
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path
        )
        resp = requests.request(method, self.config.host + api_path, json=None, headers=json_headers)
        return resp.json()
    
    def _wait_for_sign_complete(self, sign_flow_id, max_wait_time=30):
        """
        等待签署流程完成（私有方法）
        :param sign_flow_id: 签署流程ID
        :param max_wait_time: 最大等待时间（秒）
        :return: True表示签署完成，False表示超时
        """
        start_time = time.time()
        while time.time() - start_time < max_wait_time:
            try:
                detail = self._sign_flow_detail(sign_flow_id)
                sign_flow_status = detail.get('data', {}).get('signFlowStatus')
                # 签署流程状态：0-草稿，1-签署中，2-签署完成，3-签署失败，4-已撤销，5-已过期，6-已拒签，7-已撤回
                if sign_flow_status == 2:  # 签署完成
                    return True
                elif sign_flow_status in [3, 4, 5, 6, 7]:  # 签署失败、已撤销、已过期、已拒签、已撤回
                    raise Exception(f"签署流程状态异常: {sign_flow_status}")
                time.sleep(2)
            except Exception as e:
                if "签署流程状态异常" in str(e):
                    raise
                time.sleep(2)
        
        raise TimeoutError("等待签署完成超时")
    
    def _create_single_sign_flow(self, file_id, org_id, seal_id=None, auto_sign=True):
        """
        创建单方企业签署流程（私有方法）
        :param file_id: 文件ID
        :param org_id: 企业ID
        :param seal_id: 印章ID（可选）
        :param auto_sign: 是否自动签署
        :return: 签署流程ID
        """
        sign_field_config = {
            "autoSign": auto_sign,
            "signFieldPosition": {
                "positionPage": "1",
                "positionX": 200,
                "positionY": 400
            },
            "signFieldStyle": 1
        }
        
        if seal_id:
            sign_field_config["assignedSealId"] = seal_id
        
        signer = {
            "orgSignerInfo": {
                "orgId": org_id
            },
            "signConfig": {
                "signOrder": 1
            },
            "signFields": [{
                "customBizNum": "single_org_sign_field",
                "fileId": file_id,
                "normalSignFieldConfig": sign_field_config
            }],
            "signerType": 1
        }
        
        body = {
            "docs": [{
                "fileId": file_id,
                "fileName": "单方合同.pdf"
            }],
            "signers": [signer],
            "signFlowConfig": {
                "autoFinish": auto_sign,
                "autoStart": True,
                "noticeConfig": {
                    "noticeTypes": "1"
                },
                "signFlowTitle": "单方合同签署",
                "signConfig": {
                    "availableSignClientTypes": "1",
                    "showBatchDropSealButton": True
                }
            }
        }
        
        api_path = "/v3/sign-flow/create-by-file"
        method = esigntool.httpMethodEnum.POST
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path, 
            body
        )
        resp = requests.request(method, self.config.host + api_path, json=body, headers=json_headers)
        resp_json = resp.json()
        if resp_json.get('code') != 0:
            raise Exception(f"创建签署流程失败: {resp_json.get('message', '未知错误')}")
        return resp_json['data']['signFlowId']
    
    def _create_cross_page_seal_sign_flow(self, file_id, org_id, seal_id=None, auto_sign=True,
                                          start_page=1, end_page=None, position_y=None):
        """
        创建带骑缝章的单方企业签署流程（私有方法）
        :param file_id: 文件ID
        :param org_id: 企业ID
        :param seal_id: 印章ID（可选）
        :param auto_sign: 是否自动签署
        :param start_page: 骑缝章起始页码（从1开始，仅在 end_page 不为 None 时使用）
        :param end_page: 骑缝章结束页码（None表示所有页都盖骑缝章）
        :param position_y: 骑缝章Y坐标位置（None表示使用默认值400）
        :return: 签署流程ID
        """
        sign_field_position = {
            "positionY": position_y if position_y is not None else 400,
            "acrossPageMode": "ALL" if end_page is None else "AssignedPages"
        }
        
        if end_page is not None:
            sign_field_position["positionPage"] = "{}-{}".format(start_page, end_page)
        
        normal_sign_field_config = {
            "autoSign": auto_sign,
            "signFieldPosition": sign_field_position,
            "signFieldStyle": 2  # 2表示骑缝签章
        }
        
        if seal_id:
            normal_sign_field_config["assignedSealId"] = seal_id
        
        signer = {
            "orgSignerInfo": {
                "orgId": org_id
            },
            "signConfig": {
                "signOrder": 1
            },
            "signFields": [{
                "customBizNum": "cross_page_seal_field",
                "fileId": file_id,
                "normalSignFieldConfig": normal_sign_field_config
            }],
            "signerType": 1
        }
        
        body = {
            "docs": [{
                "fileId": file_id,
                "fileName": "带骑缝章的合同.pdf"
            }],
            "signers": [signer],
            "signFlowConfig": {
                "autoFinish": auto_sign,
                "autoStart": True,
                "noticeConfig": {
                    "noticeTypes": "1"
                },
                "signFlowTitle": "带骑缝章的单方合同签署",
                "signConfig": {
                    "availableSignClientTypes": "1",
                    "showBatchDropSealButton": True
                }
            }
        }
        
        api_path = "/v3/sign-flow/create-by-file"
        method = esigntool.httpMethodEnum.POST
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path, 
            body
        )
        resp = requests.request(method, self.config.host + api_path, json=body, headers=json_headers)
        resp_json = resp.json()
        if resp_json.get('code') != 0:
            raise Exception(f"创建签署流程失败: {resp_json.get('message', '未知错误')}")
        return resp_json['data']['signFlowId']
    
    def single_sign(self, file_path, org_name, seal_name=None, auto_sign=True, wait_complete=True, max_wait_time=30):
        """
        单方企业合同签署
        
        :param file_path: 本地合同文件路径
        :param org_name: 企业名称
        :param seal_name: 印章名称（可选），如果指定则使用该印章，否则使用默认印章
        :param auto_sign: 是否自动签署（默认True）
        :param wait_complete: 是否等待签署完成（默认True）
        :param max_wait_time: 最大等待时间（秒，默认30）
        :return: 签署流程ID，如果wait_complete=True且签署成功，返回流程ID；否则返回None
        """
        # 1. 查询企业信息
        org_id = self._find_org_identity_info(org_name)
        
        # 2. 查询印章ID（如果指定了印章名称）
        seal_id = None
        if seal_name:
            seal_id = self._get_org_seal_list(org_id, seal_name=seal_name)
        
        # 3. 初始化文件并上传
        file = fileHelp(file_path)
        file_upload_url, file_id = self._get_file_upload_url(file)
        self._file_stream_upload(file, file.getBinFile(), file_upload_url)
        
        # 4. 创建单方签署流程
        sign_flow_id = self._create_single_sign_flow(file_id, org_id, seal_id=seal_id, auto_sign=auto_sign)
        
        # 5. 等待自动签署完成（如果需要）
        if wait_complete and auto_sign:
            self._wait_for_sign_complete(sign_flow_id, max_wait_time=max_wait_time)
        
        return sign_flow_id
    
    def cross_page_seal_sign(self, file_path, org_name, seal_name=None, auto_sign=True,
                            start_page=1, end_page=None, position_y=None,
                            wait_complete=True, max_wait_time=30):
        """
        带骑缝章的单方企业合同签署
        
        :param file_path: 本地合同文件路径（需要多页PDF文件）
        :param org_name: 企业名称
        :param seal_name: 印章名称（可选），如果指定则使用该印章，否则使用默认印章
        :param auto_sign: 是否自动签署（默认True）
        :param start_page: 骑缝章起始页码（从1开始，仅在 end_page 不为 None 时使用）
        :param end_page: 骑缝章结束页码（None表示所有页都盖骑缝章，也可以指定具体页码如 9）
        :param position_y: 骑缝章Y坐标位置（None表示使用默认值400，即垂直居中位置）
        :param wait_complete: 是否等待签署完成（默认True）
        :param max_wait_time: 最大等待时间（秒，默认30）
        :return: 签署流程ID，如果wait_complete=True且签署成功，返回流程ID；否则返回None
        """
        # 1. 查询企业信息
        org_id = self._find_org_identity_info(org_name)
        
        # 2. 查询印章ID（如果指定了印章名称）
        seal_id = None
        if seal_name:
            seal_id = self._get_org_seal_list(org_id, seal_name=seal_name)
        
        # 3. 初始化文件并上传
        file = fileHelp(file_path)
        file_upload_url, file_id = self._get_file_upload_url(file)
        self._file_stream_upload(file, file.getBinFile(), file_upload_url)
        
        # 4. 创建带骑缝章的签署流程
        sign_flow_id = self._create_cross_page_seal_sign_flow(
            file_id, 
            org_id, 
            seal_id=seal_id, 
            auto_sign=auto_sign,
            start_page=start_page,
            end_page=end_page,
            position_y=position_y
        )
        
        # 5. 等待自动签署完成（如果需要）
        if wait_complete and auto_sign:
            self._wait_for_sign_complete(sign_flow_id, max_wait_time=max_wait_time)
        
        return sign_flow_id
    
    def get_file_download_url(self, sign_flow_id):
        """
        获取已签署文件的下载地址
        :param sign_flow_id: 签署流程ID
        :return: 文件下载地址
        """
        api_path = "/v3/sign-flow/{}/file-download-url".format(sign_flow_id)
        method = esigntool.httpMethodEnum.GET
        json_headers = esigntool.buildSignJsonHeader(
            self.config.appId, 
            self.config.scert, 
            method, 
            api_path
        )
        resp = requests.request(method, self.config.host + api_path, json=None, headers=json_headers)
        resp_json = resp.json()
        if resp_json.get('code') != 0:
            raise Exception(f"获取文件下载地址失败: {resp_json.get('message', '未知错误')}")
        return resp_json['data']['fileDownloadUrl']

