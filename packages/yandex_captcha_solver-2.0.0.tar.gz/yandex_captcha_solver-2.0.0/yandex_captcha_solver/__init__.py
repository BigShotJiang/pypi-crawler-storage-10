from .solver import YandexCaptchaSolver

__version__ = "2.0.0"
__all__ = ["YandexCaptchaSolver"]
