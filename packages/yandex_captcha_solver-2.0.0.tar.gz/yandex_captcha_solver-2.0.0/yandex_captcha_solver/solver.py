import asyncio
import base64
import json
import re
from typing import Optional, Tuple, Dict, Any
import httpx
from playwright.async_api import Page, Response


class YandexCaptchaSolver:
    def __init__(self, api_token: str):
        self.api_token = api_token
        self.api_base_url = "https://api.sctg.xyz"
        self._cached_silhouette_body_1 = None
        self._cached_silhouette_body_2 = None

    async def solve(self, page: Page) -> bool:
        if not (page.url.startswith("https://yandex.ru/showcaptcha") or page.url.startswith("https://yandex.by/showcaptcha")):
            return True

        for main_attempt in range(3):
            captcha_type, task_data, captcha_image = await self._detect_captcha_type(page)

            result = False
            if captcha_type == "kaleidoscope":
                result, new_captcha_type = await self._solve_kaleidoscope_captcha(page, task_data, captcha_image)

                if new_captcha_type == "silhouette":
                    result = await self._solve_silhouette_captcha(page)
            else:
                result = await self._solve_silhouette_captcha(page)

            if result:
                return True

            if not (page.url.startswith("https://yandex.ru/showcaptcha") or page.url.startswith("https://yandex.by/showcaptcha")):
                return True

            await asyncio.sleep(1)

        return False

    async def _solve_captcha_once(self, page: Page, is_retry: bool = False, cached_body_1: Optional[str] = None, cached_body_2: Optional[str] = None, button_already_clicked: bool = False) -> Tuple[bool, Optional[str], Optional[str]]:
        checkbox_appeared = False
        if is_retry:
            button = page.locator('input[id="js-button"]')
            if await button.count() > 0:
                checkbox_appeared = True

        if cached_body_1 and cached_body_2 and not checkbox_appeared:
            body_1, body_2 = cached_body_1, cached_body_2
            auto_solved = False
        else:
            body_1, body_2, auto_solved = await self._capture_captcha_images(page, is_retry, button_already_clicked)

        if auto_solved:
            return True, None, None

        if not body_1 or not body_2:
            return False, None, None

        task_id = await self._submit_captcha(body_1, body_2)

        if not task_id:
            return False, None, None

        coordinates = await self._get_captcha_solution(task_id)

        if not coordinates:
            return False, None, None

        is_solved, new_body_1, new_body_2 = await self._click_coordinates(page, coordinates)

        return is_solved, new_body_1, new_body_2

    async def _solve_kaleidoscope_captcha(self, page: Page, task_data: str, captcha_image: Optional[str]) -> Tuple[bool, Optional[str]]:
        if not captcha_image:
            return (False, None)

        task_id = await self._submit_captcha(captcha_image, body_2=None, textinstructions=task_data)

        if not task_id:
            return (False, None)

        solution = await self._get_captcha_solution(task_id)

        if solution is None:
            return (False, None)

        if not isinstance(solution, int):
            return (False, None)

        success, new_captcha_type, new_html = await self._move_slider_to_position(page, solution, task_data)

        if new_captcha_type:
            return (False, new_captcha_type)

        return (success, None)

    async def _solve_silhouette_captcha(self, page: Page) -> bool:
        checkbox_clicked = False
        for i in range(6):
            button = page.locator('input[id="js-button"]')
            if await button.count() > 0:
                await button.click()
                checkbox_clicked = True
                await asyncio.sleep(1)
                break
            await asyncio.sleep(0.5)

        cached_body_1 = self._cached_silhouette_body_1
        cached_body_2 = self._cached_silhouette_body_2

        if cached_body_1 and cached_body_2:
            self._cached_silhouette_body_1 = None
            self._cached_silhouette_body_2 = None
        else:
            cached_body_1 = None
            cached_body_2 = None

        for attempt in range(3):
            try:
                is_retry = attempt > 0
                button_already_clicked = checkbox_clicked if attempt == 0 else False
                success, new_body_1, new_body_2 = await self._solve_captcha_once(page, is_retry, cached_body_1, cached_body_2, button_already_clicked)

                if success:
                    return True

                cached_body_1 = new_body_1
                cached_body_2 = new_body_2

                await asyncio.sleep(1)

            except Exception as e:
                pass

        return False

    async def _capture_captcha_images(self, page: Page, is_retry: bool = False, button_already_clicked: bool = False) -> Tuple[Optional[str], Optional[str], bool]:
        body_1 = None
        body_2 = None
        auto_solved = False

        async def handle_response(response: Response):
            nonlocal body_1, body_2

            url = response.url

            if "ext.captcha.yandex.net/image" in url and "data=img" in url:
                body = await response.body()
                body_1 = base64.b64encode(body).decode('utf-8')

            elif "ext.captcha.yandex.net/image" in url and "data=task" in url:
                body = await response.body()
                body_2 = base64.b64encode(body).decode('utf-8')

        page.on("response", handle_response)

        button = page.locator('input[id="js-button"]')
        button_count = await button.count()

        if button_count > 0 and not button_already_clicked:
            await button.click()
            max_wait = 40
        elif not is_retry and not button_already_clicked:
            max_wait = 40
        else:
            max_wait = 5 if button_already_clicked else 40

        for _ in range(max_wait):
            await asyncio.sleep(1)

            if not (page.url.startswith("https://yandex.ru/showcaptcha") or page.url.startswith("https://yandex.by/showcaptcha")):
                page.remove_listener("response", handle_response)
                auto_solved = True
                return None, None, auto_solved

            if body_1 and body_2:
                break

        page.remove_listener("response", handle_response)

        return body_1, body_2, auto_solved

    async def _submit_captcha(self, body_1: str, body_2: str = None, textinstructions: str = None) -> Optional[str]:
        url = f"{self.api_base_url}/in.php"

        payload = {
            "key": self.api_token,
            "method": "yandeximg",
            "body_1": body_1
        }

        if body_2:
            payload["body_2"] = body_2
        else:
            payload["body_2"] = "NONE"

        if textinstructions:
            payload["textinstructions"] = textinstructions

        headers = {"content-type": "application/x-www-form-urlencoded"}

        async with httpx.AsyncClient() as client:
            response = await client.post(url, data=payload, headers=headers, timeout=30)
            result = response.text

            if result.startswith("OK|"):
                task_id = result.split("|")[1]
                return task_id
            else:
                return None

    async def _get_captcha_solution(self, task_id: str):
        url = f"{self.api_base_url}/res.php"
        params = {
            "key": self.api_token,
            "id": task_id
        }

        for attempt in range(15):
            await asyncio.sleep(1)

            async with httpx.AsyncClient() as client:
                response = await client.get(url, params=params, timeout=30)
                result = response.text

                if result.startswith("OK|"):
                    solution_str = result.split("|")[1]

                    if "x=" in solution_str and "y=" in solution_str:
                        coordinates = self._parse_coordinates(solution_str)
                        return coordinates
                    else:
                        try:
                            slider_value = int(solution_str)
                            return slider_value
                        except ValueError:
                            return solution_str

                elif result == "CAPCHA_NOT_READY":
                    continue

                else:
                    return None

        return None

    def _parse_coordinates(self, coords_str: str) -> list:
        pattern = r'x=(\d+),y=(\d+)'
        matches = re.findall(pattern, coords_str)

        coordinates = []
        for x, y in matches:
            coordinates.append({"x": int(x), "y": int(y)})

        return coordinates

    def _parse_ssr_data(self, html: str) -> Optional[Dict[str, Any]]:
        pattern = r'window\.__SSR_DATA__\s*=\s*({.+?})\s*</script>'
        match = re.search(pattern, html, re.DOTALL)

        if not match:
            return None

        try:
            ssr_data_str = match.group(1)

            url_match = re.search(r'url:"([^"]+)"', ssr_data_str)
            if not url_match:
                return None

            url = url_match.group(1)

            task_match = re.search(r'task:"([^"]+)"', ssr_data_str)
            task = task_match.group(1) if task_match else None

            return {
                "url": url,
                "task": task
            }
        except Exception as e:
            return None

    async def _detect_captcha_type(self, page: Page) -> Tuple[str, Optional[str], Optional[str]]:
        showcaptcha_html = None
        captcha_image = None
        silhouette_body_1 = None
        silhouette_body_2 = None

        async def handle_response(response: Response):
            nonlocal showcaptcha_html, captcha_image, silhouette_body_1, silhouette_body_2

            if "/showcaptcha" in response.url:
                showcaptcha_html = await response.text()

            elif "ext.captcha.yandex.net/image?key=" in response.url:
                if "data=img" in response.url:
                    body = await response.body()
                    silhouette_body_1 = base64.b64encode(body).decode('utf-8')
                elif "data=task" in response.url:
                    body = await response.body()
                    silhouette_body_2 = base64.b64encode(body).decode('utf-8')
                else:
                    body = await response.body()
                    captcha_image = base64.b64encode(body).decode('utf-8')

        page.on("response", handle_response)

        button = page.locator('input[id="js-button"]')
        button_count = await button.count()
        checkbox_clicked = False
        if button_count > 0:
            await button.click()
            checkbox_clicked = True
        else:
            pass

        max_iterations = 200 if checkbox_clicked else 20
        captcha_type_detected = None
        for i in range(max_iterations):
            await asyncio.sleep(0.5)

            if showcaptcha_html and not captcha_type_detected:
                ssr_data = self._parse_ssr_data(showcaptcha_html)
                if ssr_data:
                    url = ssr_data.get("url", "")
                    if "kaleidoscope" in url:
                        captcha_type_detected = "kaleidoscope"
                    else:
                        captcha_type_detected = "silhouette"

            if captcha_type_detected == "kaleidoscope" and captcha_image:
                break

            if captcha_type_detected == "silhouette" and silhouette_body_1 and silhouette_body_2:
                break

        page.remove_listener("response", handle_response)

        if not showcaptcha_html:
            return "silhouette", None, None

        ssr_data = self._parse_ssr_data(showcaptcha_html)

        if not ssr_data:
            if silhouette_body_1 and silhouette_body_2:
                self._cached_silhouette_body_1 = silhouette_body_1
                self._cached_silhouette_body_2 = silhouette_body_2
            return "silhouette", None, None

        url = ssr_data.get("url", "")

        if "kaleidoscope" in url:
            task = ssr_data.get("task", None)
            return "kaleidoscope", task, captcha_image
        else:
            if silhouette_body_1 and silhouette_body_2:
                self._cached_silhouette_body_1 = silhouette_body_1
                self._cached_silhouette_body_2 = silhouette_body_2
            return "silhouette", None, None

    async def _move_slider_to_position(self, page: Page, target_position: int, current_task: str) -> Tuple[bool, Optional[str], Optional[str]]:
        slider = page.locator('div[id="captcha-slider"]')

        box = await slider.bounding_box()
        if not box:
            return (False, None, None)

        start_x = box['x'] + box['width'] / 2
        start_y = box['y'] + box['height'] / 2

        await page.mouse.move(start_x, start_y)
        await page.mouse.down()
        await asyncio.sleep(0.2)

        max_attempts = 300
        for i in range(max_attempts):
            current_value = await slider.get_attribute("aria-valuenow")
            current_int = int(current_value) if current_value else 0

            if current_int == target_position:
                break
            elif current_int > target_position:
                break

            distance = target_position - current_int
            step = 1 if distance < 5 else 2

            start_x += step
            await page.mouse.move(start_x, start_y)
            await asyncio.sleep(0.05)

        final_value = await slider.get_attribute("aria-valuenow")

        await page.mouse.up()

        new_showcaptcha_html = None
        new_image_detected = False
        silhouette_body_1 = None
        silhouette_body_2 = None
        silhouette_detected = False
        silhouette_wait_iterations = 0

        async def handle_response(response: Response):
            nonlocal new_showcaptcha_html, new_image_detected, silhouette_body_1, silhouette_body_2, silhouette_detected, silhouette_wait_iterations
            url = response.url

            if "/showcaptcha" in url:
                new_showcaptcha_html = await response.text()
            elif "ext.captcha.yandex.net/image?key=" in url:
                if "data=img" in url:
                    body = await response.body()
                    silhouette_body_1 = base64.b64encode(body).decode('utf-8')
                    new_image_detected = True
                elif "data=task" in url:
                    body = await response.body()
                    silhouette_body_2 = base64.b64encode(body).decode('utf-8')
                else:
                    new_image_detected = True

        page.on("response", handle_response)

        for i in range(140):
            await asyncio.sleep(0.5)

            if silhouette_detected:
                silhouette_wait_iterations += 1

            if not (page.url.startswith("https://yandex.ru/showcaptcha") or page.url.startswith("https://yandex.by/showcaptcha")):
                page.remove_listener("response", handle_response)
                return (True, None, None)

            if silhouette_detected and silhouette_body_1 and silhouette_body_2:
                page.remove_listener("response", handle_response)
                self._cached_silhouette_body_1 = silhouette_body_1
                self._cached_silhouette_body_2 = silhouette_body_2
                return (False, "silhouette", None)

            if silhouette_detected and silhouette_wait_iterations > 20:
                page.remove_listener("response", handle_response)
                if silhouette_body_1 and silhouette_body_2:
                    self._cached_silhouette_body_1 = silhouette_body_1
                    self._cached_silhouette_body_2 = silhouette_body_2
                return (False, "silhouette", None)

            if new_image_detected and not silhouette_detected:
                page.remove_listener("response", handle_response)

                try:
                    button = page.locator('input[id="js-button"]')
                    if await button.count() > 0:
                        await button.click(timeout=3000)
                        await asyncio.sleep(1)
                except Exception as e:
                    pass

                return (False, None, None)

            if new_showcaptcha_html:
                ssr_data = self._parse_ssr_data(new_showcaptcha_html)
                if ssr_data:
                    new_url = ssr_data.get("url", "")

                    if "checkbox" in new_url:
                        try:
                            button = page.locator('input[id="js-button"]')
                            if await button.count() > 0:
                                await button.click(timeout=3000)
                                new_showcaptcha_html = None
                                await asyncio.sleep(2)
                                continue
                        except Exception as e:
                            page.remove_listener("response", handle_response)
                            return (False, None, None)

                    if "silhouette" in new_url:
                        silhouette_detected = True
                        new_showcaptcha_html = None
                        continue

                    new_task = ssr_data.get("task")
                    if new_task and new_task != current_task:
                        page.remove_listener("response", handle_response)

                        try:
                            button = page.locator('input[id="js-button"]')
                            if await button.count() > 0:
                                await button.click(timeout=3000)
                                await asyncio.sleep(1)
                        except Exception as e:
                            pass

                        return (False, None, None)

        page.remove_listener("response", handle_response)

        if silhouette_detected:
            if silhouette_body_1 and silhouette_body_2:
                self._cached_silhouette_body_1 = silhouette_body_1
                self._cached_silhouette_body_2 = silhouette_body_2
            return (False, "silhouette", None)

        try:
            button = page.locator('input[id="js-button"]')
            if await button.count() > 0:
                await button.click(timeout=3000)
                await asyncio.sleep(1)
        except Exception as e:
            pass

        return (False, None, None)

    async def _click_coordinates(self, page: Page, coordinates: list) -> Tuple[bool, Optional[str], Optional[str]]:
        captcha_element = page.locator('div[class="AdvancedCaptcha-View"]')

        box = await captcha_element.bounding_box()
        if not box:
            return False, None, None

        for coord in coordinates:
            x = box['x'] + coord['x']
            y = box['y'] + coord['y']

            await page.mouse.click(x, y)
            await asyncio.sleep(0.5)

        captcha_solved = False
        new_body_1 = None
        new_body_2 = None

        async def handle_response(response: Response):
            nonlocal new_body_1, new_body_2
            url = response.url

            if "ext.captcha.yandex.net/image" in url and "data=img" in url:
                body = await response.body()
                new_body_1 = base64.b64encode(body).decode('utf-8')

            elif "ext.captcha.yandex.net/image" in url and "data=task" in url:
                body = await response.body()
                new_body_2 = base64.b64encode(body).decode('utf-8')

        page.on("response", handle_response)

        submit_button = page.locator('div[class="CaptchaButton-ProgressWrapper"]')
        await submit_button.click()

        for _ in range(50):
            await asyncio.sleep(0.1)

            if not (page.url.startswith("https://yandex.ru/showcaptcha") or page.url.startswith("https://yandex.by/showcaptcha")):
                captcha_solved = True
                break

            if new_body_1 and new_body_2:
                break

        page.remove_listener("response", handle_response)

        return captcha_solved, new_body_1, new_body_2
