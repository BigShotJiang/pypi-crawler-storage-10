from fastmcp import FastMCP
import argparse




mcp = FastMCP("My MCP Server")


@mcp.tool
def greet(name: str) -> str:
    """Greet someone by name with a custom greeting.

    Args:
        name: The name of the person to greet
    """
    return f"hello, {name}!"  # 使用传入的greeting参数

@mcp.tool
def add_numbers(a: float, b: float) -> float:
    """Add two numbers together.

    Args:
        a: First number
        b: Second number
    """
    return a + b


def main() -> None:
    mcp.run(transport="stdio")
