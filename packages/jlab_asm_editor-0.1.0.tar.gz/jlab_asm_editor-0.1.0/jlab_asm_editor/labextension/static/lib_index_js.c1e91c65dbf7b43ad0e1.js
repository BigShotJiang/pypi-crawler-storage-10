"use strict";
(self["webpackChunkjlab_asm_editor"] = self["webpackChunkjlab_asm_editor"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__);



/**
 * Initialization data for the jlab_asm_editor extension.
 */
const plugin = {
    id: 'jlab_asm_editor:plugin',
    description: 'A plugin to add an assembly editor to the launcher in tljh',
    autoStart: true,
    requires: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette], // Ensure dependencies are listed
    activate: (app, launcher, palette) => {
        console.log('JupyterLab extension jlab_asm_editor is activated!');
        const new_asm_file = 'jlab_asm_editor:create-asm';
        app.commands.addCommand(new_asm_file, {
            label: 'ASM File',
            caption: 'Create a new ASM file',
            iconClass: 'jp-FileIcon',
            execute: () => {
                const model = new _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_2__.TextModelFactory().createNew();
                model.sharedModel.setSource('');
                const widget = app.serviceManager.contents.newUntitled({
                    type: 'file',
                    ext: '.asm',
                });
                widget.then(file => {
                    //app.commands.execute('docmanager:open', { path: file.path });
                    app.commands.execute('docmanager:open', { path: file.path, factory: 'Editor' });
                });
            }
        });
        const category = 'File Operations';
        launcher.add({ command: new_asm_file });
        palette.addItem({ command: new_asm_file, category });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.c1e91c65dbf7b43ad0e1.js.map