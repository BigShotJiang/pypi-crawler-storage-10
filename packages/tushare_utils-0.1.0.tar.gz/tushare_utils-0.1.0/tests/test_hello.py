from tushare_utils import hello

def test_hello():
    assert hello()=="Hello Python!"