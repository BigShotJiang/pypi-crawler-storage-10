"""
Winston - Self-voicing IDE and personal productivity environment

A Python framework for creating interactive command interfaces with
dialog management, Claude Code integration, and productivity applets.
Designed primarily for blind users on Windows.
"""

__version__ = "0.1.2"
__author__ = "Chris"
__description__ = "Self-voicing IDE and productivity environment"

# Import framework first to avoid circular imports
from . import framework

# Make key functions available at package level
from .framework import beep

__all__ = [
    'framework',
    'beep'
]