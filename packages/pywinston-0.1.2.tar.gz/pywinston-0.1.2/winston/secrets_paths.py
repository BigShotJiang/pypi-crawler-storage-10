"""Simple path helper for Winston secrets and data.

Uses Windows %LOCALAPPDATA% for secrets storage.
This is a Windows-only solution since Winston has many Windows dependencies.
"""
import os
from pathlib import Path

def get_winston_dir() -> Path:
    """Get Winston data directory in %LOCALAPPDATA%.

    Returns:
        Path to Winston data directory (e.g., C:\\Users\\Chris\\AppData\\Local\\Winston)
    """
    local_appdata = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
    winston_dir = Path(local_appdata) / 'Winston'
    winston_dir.mkdir(exist_ok=True)
    return winston_dir

def get_google_credentials_path() -> str:
    """Path to google_credentials.json in secrets directory.

    Returns:
        Full path to Google OAuth credentials file.
    """
    secrets_dir = get_winston_dir() / 'secrets'
    secrets_dir.mkdir(exist_ok=True)
    return str(secrets_dir / 'google_credentials.json')

def get_google_token_path() -> str:
    """Path to google_token.json in secrets directory.

    Returns:
        Full path to Google OAuth token file.
    """
    secrets_dir = get_winston_dir() / 'secrets'
    secrets_dir.mkdir(exist_ok=True)
    return str(secrets_dir / 'google_token.json')

def get_openai_key_path() -> str:
    """Path to openai_key.txt in secrets directory.

    Returns:
        Full path to OpenAI API key file.
    """
    secrets_dir = get_winston_dir() / 'secrets'
    secrets_dir.mkdir(exist_ok=True)
    return str(secrets_dir / 'openai_key.txt')

def get_contacts_cache_path() -> str:
    """Path to contacts.json in cache directory.

    Returns:
        Full path to contacts cache file.
    """
    cache_dir = get_winston_dir() / 'cache'
    cache_dir.mkdir(exist_ok=True)
    return str(cache_dir / 'contacts.json')

def get_recent_contacts_path() -> str:
    """Path to recent_contacts.json in cache directory.

    Returns:
        Full path to recent contacts cache file.
    """
    cache_dir = get_winston_dir() / 'cache'
    cache_dir.mkdir(exist_ok=True)
    return str(cache_dir / 'recent_contacts.json')

# Backward compatibility: check old locations first

def get_google_credentials_path_with_fallback() -> str:
    """Get Google credentials path, checking old location first.

    Returns:
        Path to credentials file. Checks working directory first for
        backward compatibility, then returns new location.
    """
    # Check old location (working directory)
    old_path = 'winston_google_credentials.json'
    if os.path.exists(old_path):
        return old_path
    # Use new location
    return get_google_credentials_path()

def get_google_token_path_with_fallback() -> str:
    """Get Google token path, checking old location first.

    Returns:
        Path to token file. Checks working directory first for
        backward compatibility, then returns new location.
    """
    old_path = 'winston_google_token.json'
    if os.path.exists(old_path):
        return old_path
    return get_google_token_path()

def get_openai_key_path_with_fallback() -> str:
    """Get OpenAI key path, checking old locations first.

    Returns:
        Path to API key file. Checks hardcoded location first,
        then working directory, then new location.
    """
    # Check old hardcoded location
    old_path_hardcoded = r'C:\mypy\openai_key.txt'
    if os.path.exists(old_path_hardcoded):
        return old_path_hardcoded
    # Check working directory
    old_path_local = 'openai_key.txt'
    if os.path.exists(old_path_local):
        return old_path_local
    # Use new location
    return get_openai_key_path()

def get_contacts_cache_path_with_fallback() -> str:
    """Get contacts cache path, checking old location first.

    Returns:
        Path to contacts cache. Checks resource_cache directory first
        for backward compatibility, then returns new location.
    """
    old_path = r'resource_cache\contacts.json'
    if os.path.exists(old_path):
        return old_path
    return get_contacts_cache_path()

def get_recent_contacts_path_with_fallback() -> str:
    """Get recent contacts path, checking old location first.

    Returns:
        Path to recent contacts cache. Checks resource_cache directory
        first for backward compatibility, then returns new location.
    """
    old_path = r'resource_cache\recent_contacts.json'
    if os.path.exists(old_path):
        return old_path
    return get_recent_contacts_path()

def get_diary_cache_path() -> str:
    """Path to diary.json in cache directory.

    Returns:
        Full path to diary cache file.
    """
    cache_dir = get_winston_dir() / 'cache'
    cache_dir.mkdir(exist_ok=True)
    return str(cache_dir / 'diary.json')

def get_diary_cache_path_with_fallback() -> str:
    """Get diary cache path, checking old location first.

    Returns:
        Path to diary cache. Checks resource_cache directory first
        for backward compatibility, then returns new location.
    """
    old_path = r'resource_cache\diary.json'
    if os.path.exists(old_path):
        return old_path
    return get_diary_cache_path()

def get_gmail_labels_cache_path() -> str:
    """Path to labels.json in cache directory.

    Returns:
        Full path to Gmail labels cache file.
    """
    cache_dir = get_winston_dir() / 'cache'
    cache_dir.mkdir(exist_ok=True)
    return str(cache_dir / 'labels.json')

def get_gmail_labels_cache_path_with_fallback() -> str:
    """Get Gmail labels cache path, checking old location first.

    Returns:
        Path to labels cache. Checks resource_cache directory first
        for backward compatibility, then returns new location.
    """
    old_path = r'resource_cache\labels.json'
    if os.path.exists(old_path):
        return old_path
    return get_gmail_labels_cache_path()

def get_gmail_folder_cache_path(folder: str) -> str:
    """Path to folder summary cache in cache directory.

    Args:
        folder: Gmail folder name (e.g., 'INBOX', 'Sent')

    Returns:
        Full path to folder cache file.
    """
    cache_dir = get_winston_dir() / 'cache'
    cache_dir.mkdir(exist_ok=True)
    safe_folder = folder.replace('/', '_')
    return str(cache_dir / f'{safe_folder}.json')

def get_gmail_folder_cache_path_with_fallback(folder: str) -> str:
    """Get Gmail folder cache path, checking old location first.

    Args:
        folder: Gmail folder name (e.g., 'INBOX', 'Sent')

    Returns:
        Path to folder cache. Checks resource_cache directory first
        for backward compatibility, then returns new location.
    """
    safe_folder = folder.replace('/', '_')
    old_path = f'resource_cache\{safe_folder}.json'
    if os.path.exists(old_path):
        return old_path
    return get_gmail_folder_cache_path(folder)

def get_gmail_message_cache_dir(message_id: str) -> str:
    """Path to message cache directory.

    Args:
        message_id: Gmail message ID

    Returns:
        Full path to message cache directory.
    """
    cache_dir = get_winston_dir() / 'cache' / message_id
    cache_dir.mkdir(parents=True, exist_ok=True)
    return str(cache_dir)

def get_gmail_message_cache_path(message_id: str, filename: str | None = None) -> str:
    """Path to cached message file (metadata or attachment).

    Args:
        message_id: Gmail message ID
        filename: Attachment filename (None for message metadata)

    Returns:
        Full path to message cache file.
    """
    if filename:
        return os.path.join(get_gmail_message_cache_dir(message_id), filename)
    else:
        cache_dir = get_winston_dir() / 'cache'
        cache_dir.mkdir(exist_ok=True)
        return str(cache_dir / f'{message_id}.json')

def get_gmail_message_cache_path_with_fallback(message_id: str, filename: str | None = None) -> str:
    """Get Gmail message cache path, checking old location first.

    Args:
        message_id: Gmail message ID
        filename: Attachment filename (None for message metadata)

    Returns:
        Path to message cache. Checks resource_cache directory first
        for backward compatibility, then returns new location.
    """
    if filename:
        old_path = os.path.join('resource_cache', message_id, filename)
    else:
        old_path = os.path.join('resource_cache', f'{message_id}.json')

    if os.path.exists(old_path):
        return old_path
    return get_gmail_message_cache_path(message_id, filename)