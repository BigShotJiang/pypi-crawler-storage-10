# click.py

import winsound

import time

import os

import wave

import struct

import math



CLICK_FILE = "click.wav"



def generate_click(filename=CLICK_FILE):

    """Generate a short click sound as a WAV file."""

    framerate = 44100

    duration = 0.05  # 50 ms

    amplitude = 32767

    freq = 300  # Hz



    with wave.open(filename, 'w') as w:

        w.setnchannels(1)

        w.setsampwidth(2)

        w.setframerate(framerate)

        samples = []

        for i in range(int(duration * framerate)):

            # Decaying sine wave for a percussive click

            val = int(amplitude * math.sin(2 * math.pi * freq * i / framerate) * math.exp(-40 * i / framerate))

            samples.append(struct.pack('<h', val))

        w.writeframes(b''.join(samples))



def play_click():

    """Play the click sound once."""

    winsound.PlaySound(CLICK_FILE, winsound.SND_FILENAME)



def main():

    if not os.path.exists(CLICK_FILE):

        print("Creating click.wav...")

        generate_click()



    for _ in range(10):

        play_click()

        time.sleep(1)



if __name__ == "__main__":

    main()
