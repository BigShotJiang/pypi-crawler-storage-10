"""JSON editor applet for Winston."""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from collections.abc import Generator
import json
from ..key_handler import KeyHandler
from ..elements import Element
from .editor import EditorDialog

if TYPE_CHECKING:
    from typing import TextIO

class JsonicDialog(EditorDialog):
    """JSON file editor with pretty-printing."""

    def contents_from_file(  # type: ignore[override]
        self,
        open_file: TextIO | None,
        element_type: type[Element]
    ) -> Generator[Element, None, None]:
        """Load and pretty-print JSON file contents.

        Args:
            open_file: File object or None for empty.
            element_type: Element type for lines.

        Yields:
            Elements for each line of pretty-printed JSON.
        """
        if not open_file:
            yield element_type(self,'blank line',"")
        else:
            data = json.load(open_file)
            # Convert the JSON object into a pretty-printed JSON string
            pretty_json_string = json.dumps(data, indent=4)
            json_lines = pretty_json_string.splitlines()
            for l in json_lines:
                yield element_type(self,'blank line',l.rstrip('\n'))

    @classmethod
    def new_template(cls) -> str:
        """Get default filename for new JSON files.

        Returns:
            Template filename.
        """
        return 'new json file.json'

    #@KeyHandler.hotkey("Control+M")
    def command_speech_status(self, modified_name: str) -> None:
        """Check speech status (disabled)."""
        j=self.app.tts.engine
        silent_status=j.RunFunction("SayCheck")
        self.say_strings('this is quite a lot of bollocky speaking to see if status is different')
        speaking_status=        j.RunFunction("SayCheck")
        print(f"silent status: {silent_status}, speaking status: {speaking_status}")

    # @KeyHandler.hotkey("Control+Up")
    def command_increase_rate(self, modified_name: str) -> None:
        """Increase speech rate (disabled)."""
        self.app.sapi_tts.set_rate(+1)  # type: ignore[attr-defined]

    # @KeyHandler.hotkey("Control+Down")
    def command_decrease_rate(self, modified_name: str) -> None:
        """Decrease speech rate (disabled)."""
        self.app.sapi_tts.set_rate(-1)  # type: ignore[attr-defined]

    #@KeyHandler.hotkey("Alt+V")
    def command_cycle_voices(self, modified_name: str) -> None:
        """Cycle through TTS voices (disabled)."""
        self.app.sapi_tts.cycle_voices()  # type: ignore[attr-defined]

    def zzzsay(self, s: str, interrupt: bool, substitutions: Any, wait: bool = False) -> None:
        """Disabled say method."""
        #need to also do whatever substitution processing is normally done in dialog.say()
        self.app.sapi_tts.speak(s,interrupt,wait)  # type: ignore[attr-defined]

    @KeyHandler.hotkey("Control+N")
    def command_get_name(self, modified_name: str) -> None:
        """Get name from user (test command)."""
        first = input('what is your first name')
        second=input('and your surname')
        self.say_strings([first,second],interrupt=False)

    @KeyHandler.hotkey("Control+S")
    def command_save(self, modified_name: str = '') -> None:
        """Save JSON file."""
        self.say_strings('implement dumping of json to file')
