import openai
import os
from ..secrets_paths import get_openai_key_path_with_fallback

# set OpenAI API key
#openai.api_key = os.environ["OPENAI_API_KEY"]
#openai.api_key = os.getenv('OPENAI_API_KEY')
openai.api_key_path = get_openai_key_path_with_fallback()  # type: ignore[attr-defined]  # Old OpenAI API
# set up the prompt for ChatGPT
prompt = "Hello, I am ChatGPT. What can I help you with today?"

# set up the API parameters
model_engine = "text-davinci-002"
temperature = 0.5
max_tokens = 100

# interact with ChatGPT
while True:
    user_input = input("You: ")
    prompt += f"\nUser: {user_input}\nChatGPT:"
    response = openai.Completion.create(  # type: ignore[attr-defined]  # Old OpenAI API
        engine=model_engine,
        prompt=prompt,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    message = response.choices[0].text.strip()
    print(f"ChatGPT: {message}")
    prompt += message
