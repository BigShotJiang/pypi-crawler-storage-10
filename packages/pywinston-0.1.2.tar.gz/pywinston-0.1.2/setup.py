"""Setup script for Winston (backward compatibility shim).

Modern configuration is in pyproject.toml.
This file exists for backward compatibility with older tools.
"""
from setuptools import setup

# All configuration is in pyproject.toml
setup()
