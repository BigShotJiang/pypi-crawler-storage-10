class ProtocolError(Exception):
    pass