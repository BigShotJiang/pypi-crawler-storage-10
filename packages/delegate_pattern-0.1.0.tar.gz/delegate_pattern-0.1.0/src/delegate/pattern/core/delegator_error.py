
class DelegatorError(Exception):
    pass