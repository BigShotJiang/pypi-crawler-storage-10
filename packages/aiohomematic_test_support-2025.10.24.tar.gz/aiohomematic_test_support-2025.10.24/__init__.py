__version__ = "2025.10.24"
"""Module to support aiohomematic testing with a local client."""
