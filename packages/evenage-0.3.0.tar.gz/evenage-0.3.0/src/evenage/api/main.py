"""
FastAPI server for EvenAge.

Provides REST API for job submission, status queries, and agent management.
"""

from __future__ import annotations

import logging
import json
from datetime import datetime
from contextlib import asynccontextmanager
from typing import Any
import pkgutil
import importlib

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from evenage.core.config import EvenAgeConfig, PipelineConfig, load_pipeline_config
from evenage.core.message_bus_base import MessageBusBase as MessageBus
from evenage.core.database_base import DatabaseService
from evenage.database.models import Job
from importlib import import_module
from evenage import __version__ as pkg_version
from core.runtime_entry import AgentRunner  # type: ignore
from evenage.observability.metrics import init_metrics
from evenage.observability.tracing import init_tracing

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Request/Response models
class SubmitJobRequest(BaseModel):
    """Request to submit a new job."""

    pipeline_name: str
    inputs: dict[str, Any] | None = None


class JobStatusResponse(BaseModel):
    """Response for job status query."""

    job_id: str
    status: str
    pipeline: str
    tasks: dict[str, Any]
    results: dict[str, Any]


class AgentInfo(BaseModel):
    """Agent information."""

    name: str
    role: str
    goal: str
    status: str
    tools: list[str]


# Global services
config: EvenAgeConfig
message_bus: MessageBus
database: DatabaseService


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup services."""
    global config, message_bus, database

    # Load configuration
    config = EvenAgeConfig()

    # Initialize services
    message_bus = MessageBus(config.redis_url)
    database = DatabaseService(config.database_url)

    # Create database tables
    database.create_tables()

    # Initialize observability
    if config.enable_tracing:
        init_tracing(
            service_name="evenage-api",
            otlp_endpoint=config.otel_exporter_otlp_endpoint,
        )

    if config.enable_metrics:
        init_metrics(port=config.prometheus_metrics_port)

    logger.info("EvenAge API server started")

    yield

    logger.info("EvenAge API server shutting down")


# Create FastAPI app
app = FastAPI(
    title="EvenAge API",
    description="API for EvenAge distributed agent framework",
    version=pkg_version,
    lifespan=lifespan,
)

# Add CORS middleware - allow dashboard origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Local development
        "http://dashboard:5173",  # Docker internal
        "*",  # TODO: Configure appropriately for production
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Root endpoint - API information."""
    return {
        "service": "EvenAge API",
        "version": pkg_version,
        "status": "running",
        "dashboard": "http://localhost:5173",
        "docs": "/docs",
    }


@app.get("/api")
async def api_root():
    """API root endpoint."""
    return {
        "service": "EvenAge API",
        "version": pkg_version,
        "status": "running",
    }


@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    # Check Redis connection
    redis_healthy = message_bus.health_check()

    if not redis_healthy:
        raise HTTPException(status_code=503, detail="Redis connection failed")

    return {
        "status": "healthy",
        "redis": redis_healthy,
    }


@app.post("/api/jobs", response_model=dict)
async def submit_job(request: SubmitJobRequest):
    """
    Submit a new job for execution.

    Args:
        request: Job submission request

    Returns:
        Job ID
    """
    try:
        pipeline_path = f"pipelines/{request.pipeline_name}.yml"
        pipeline = load_pipeline_config(pipeline_path)

        if not pipeline.tasks:
            raise HTTPException(status_code=400, detail="Pipeline has no tasks")

        results: dict[str, Any] = {}
        first_job_id: str | None = None
        for task in pipeline.tasks:
            agent_name = task.agent
            mod = import_module(f"agents.{agent_name}.handler")
            AgentClass = getattr(mod, f"{agent_name.capitalize()}Agent")
            AgentConfig = getattr(mod, "AgentConfig")
            cfg = AgentConfig(
                name=agent_name,
                redis_url=config.redis_url,
                database_url=config.database_url,
            )
            runner = AgentRunner(AgentClass(cfg))
            res = runner.run(request.inputs or {})
            if not first_job_id:
                first_job_id = res.get("result", {}).get("job_id") or res.get("job_id")
            results[agent_name] = res

        response = {
            "job_id": first_job_id or "",
            "status": "completed",
            "pipeline_name": request.pipeline_name,
            "results": results,
        }
        # Emit a DB/job event for observability/UI if we have a job id
        try:
            if first_job_id:
                message_bus.redis_client.xadd(
                    "events:stream",
                    {
                        "data": json.dumps(
                            {
                                "event_type": "job_submitted",
                                "job_id": first_job_id,
                                "pipeline": request.pipeline_name,
                                "timestamp": datetime.utcnow().isoformat(),
                            }
                        )
                    },
                )
        except Exception:
            pass
        return response

    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error submitting job: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/jobs/{job_id}", response_model=dict)
async def get_job_status(job_id: str):
    """
    Get the status of a job.

    Args:
        job_id: Job identifier

    Returns:
        Job status information
    """
    # Fetch from DB
    try:
        with database.get_session() as session:
            rec = session.query(Job).filter_by(job_id=job_id).first()
            if not rec:
                raise HTTPException(status_code=404, detail="Job not found")
            outputs = rec.outputs or {}
            trace_id = None
            if isinstance(outputs, dict):
                # If single agent result, may be nested; otherwise check fields
                trace_id = outputs.get("trace_id") or outputs.get("result", {}).get("trace_id")
            return {
                "job_id": job_id,
                "status": rec.status,
                "pipeline": rec.pipeline_name,
                "results": outputs,
                "trace_id": trace_id,
                "created_at": rec.created_at.isoformat() if rec.created_at else None,
                "completed_at": rec.completed_at.isoformat() if rec.completed_at else None,
            }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to fetch job status")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/jobs/{job_id}")
async def cancel_job(job_id: str):
    """
    Cancel a running job.

    Args:
        job_id: Job identifier

    Returns:
        Cancellation status
    """
    try:
        with database.get_session() as session:
            rec = session.query(Job).filter_by(job_id=job_id).first()
            if not rec:
                raise HTTPException(status_code=404, detail="Job not found")
            rec.status = "cancelled"
            session.add(rec)
            session.commit()
            # Emit job cancellation event
            try:
                message_bus.redis_client.xadd(
                    "events:stream",
                    {
                        "data": json.dumps(
                            {
                                "event_type": "job_cancelled",
                                "job_id": job_id,
                                "timestamp": datetime.utcnow().isoformat(),
                            }
                        )
                    },
                )
            except Exception:
                pass
            return {"job_id": job_id, "status": "cancelled"}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to cancel job")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/jobs", response_model=list[dict[str, Any]])
async def list_jobs():
    """List recent jobs from database."""
    try:
        with database.get_session() as session:
            rows = (
                session.query(Job)
                .order_by(Job.created_at.desc())
                .limit(200)
                .all()
            )
            items = []
            for rec in rows:
                trace_id = None
                outputs = rec.outputs or {}
                if isinstance(outputs, dict):
                    trace_id = outputs.get("trace_id") or outputs.get("result", {}).get("trace_id")
                items.append(
                    {
                        "job_id": rec.job_id,
                        "pipeline_name": rec.pipeline_name,
                        "status": rec.status,
                        "created_at": rec.created_at.isoformat() if rec.created_at else None,
                        "completed_at": rec.completed_at.isoformat() if rec.completed_at else None,
                        "trace_id": trace_id,
                    }
                )
            return items
    except Exception as e:
        logger.exception("Failed to list jobs")
        raise HTTPException(status_code=500, detail=str(e))


class PipelineRunRequest(BaseModel):
    definition: dict | None = None
    yaml: str | None = None


@app.post("/api/pipelines/run", response_model=dict)
async def run_pipeline(request: PipelineRunRequest):
    """Run a pipeline from YAML or JSON definition."""
    try:
        if request.definition is None and request.yaml is None:
            raise HTTPException(status_code=400, detail="Provide 'definition' or 'yaml'")
        import yaml  # type: ignore
        data = request.definition or yaml.safe_load(request.yaml or "{}")
        stages = data.get("pipeline") or data.get("stages") or data.get("tasks")
        if not isinstance(stages, list):
            raise HTTPException(status_code=400, detail="Pipeline definition must include a list of stages")

        results: dict[str, Any] = {}
        first_job_id: str | None = None
        for stage in stages:
            agent_name = stage.get("agent")
            if not agent_name:
                raise HTTPException(status_code=400, detail="Each stage must include 'agent'")
            inputs = stage.get("inputs", {k: v for k, v in stage.items() if k != "agent"})
            mod = import_module(f"agents.{agent_name}.handler")
            AgentClass = getattr(mod, f"{agent_name.capitalize()}Agent")
            AgentConfig = getattr(mod, "AgentConfig")
            cfg = AgentConfig(
                name=agent_name,
                redis_url=config.redis_url,
                database_url=config.database_url,
            )
            runner = AgentRunner(AgentClass(cfg))
            res = runner.run(inputs)
            if not first_job_id:
                first_job_id = res.get("result", {}).get("job_id") or res.get("job_id")
            results[agent_name] = res
        return {
            "job_id": first_job_id or "",
            "status": "completed",
            "results": results,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Pipeline run failed")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/jobs/replay/{job_id}", response_model=dict)
async def replay_job(job_id: str):
    """Replay a job by fetching stored results."""
    try:
        with database.get_session() as session:
            rec = session.query(Job).filter_by(job_id=job_id).first()
            if not rec:
                raise HTTPException(status_code=404, detail="Job not found")
            return rec.outputs or {}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Job replay failed")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/agents", response_model=list[AgentInfo])
async def list_agents():
    """
    List all registered agents.

    Returns:
        List of agent information
    """
    live = message_bus.get_registered_agents()
    merged: dict[str, dict[str, Any]] = {k: dict(v) for k, v in live.items()}
    try:
        agents_pkg = importlib.import_module("agents")
        for modinfo in pkgutil.iter_modules(getattr(agents_pkg, "__path__", [])):
            name = modinfo.name
            if name in merged:
                continue
            try:
                handler = importlib.import_module(f"agents.{name}.handler")
            except Exception:
                continue
            role = getattr(handler, "ROLE", "Unknown")
            goal = getattr(handler, "GOAL", "N/A")
            tools_loader = getattr(handler, "load_tools", None)
            tools = []
            try:
                if callable(tools_loader):
                    tools = list((tools_loader() or {}).keys())
            except Exception:
                tools = []
            merged[name] = {"role": role, "goal": goal, "status": "inactive", "tools": tools}
    except Exception:
        pass
    out: list[AgentInfo] = []
    for name, metadata in merged.items():
        out.append(
            AgentInfo(
                name=name,
                role=str(metadata.get("role", "")),
                goal=str(metadata.get("goal", "")),
                status=str(metadata.get("status", "unknown")),
                tools=list(metadata.get("tools", [])),
            )
        )
    return out


@app.get("/api/agents/{agent_name}")
async def get_agent_details(agent_name: str):
    """
    Get detailed information about an agent.

    Args:
        agent_name: Agent name

    Returns:
        Agent details including recent tasks
    """
    agents = message_bus.get_registered_agents()
    
    if agent_name not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    metadata = agents[agent_name]
    queue_depth = message_bus.get_queue_depth(agent_name)
    
    return {
        "name": agent_name,
        "role": metadata.get("role", ""),
        "goal": metadata.get("goal", ""),
        "status": metadata.get("status", "unknown"),
        "tools": metadata.get("tools", []),
        "queue_depth": queue_depth,
        "last_heartbeat": metadata.get("last_heartbeat"),
    }


@app.get("/api/agents/{agent_name}/queue")
async def get_agent_queue_depth(agent_name: str):
    """
    Get the queue depth for an agent.

    Args:
        agent_name: Agent name

    Returns:
        Queue depth information
    """
    depth = message_bus.get_queue_depth(agent_name)

    return {
        "agent_name": agent_name,
        "queue_depth": depth,
    }


@app.post("/api/agents/{agent_name}/chat")
async def chat_with_agent(agent_name: str, message: dict[str, str]):
    """
    Chat with a specific agent.

    Args:
        agent_name: Agent to chat with
        message: Chat message containing 'content'

    Returns:
        Agent response
    """
    from evenage.core.message_bus_base import TaskMessage
    import uuid
    
    # Create a chat task
    task = TaskMessage(
        job_id=f"chat-{uuid.uuid4()}",
        source_agent="user",
        target_agent=agent_name,
        payload={
            "description": message.get("content", ""),
            "type": "chat",
        }
    )
    
    # Publish task
    message_bus.publish_task(task)
    
    return {
        "task_id": task.task_id,
        "status": "submitted",
        "message": "Chat message sent to agent",
    }


@app.get("/api/traces")
async def get_traces(limit: int = 100, agent_name: str | None = None):
    """
    Get recent traces from database.

    Args:
        limit: Maximum number of traces to return
        agent_name: Filter by agent name (optional)

    Returns:
        List of traces
    """
    # Query database for traces
    # This is a simplified version - full implementation would use SQLAlchemy
    return {
        "traces": [],
        "total": 0,
        "message": "Trace query would return results from PostgreSQL",
    }


@app.get("/api/metrics")
async def get_metrics_summary():
    """
    Get metrics summary for the dashboard.

    Returns:
        Metrics summary including task counts, token usage, etc.
    """
    agents = message_bus.get_registered_agents()
    
    try:
        with database.get_session() as session:
            active_jobs = session.query(Job).filter_by(status="running").count()
    except Exception:
        active_jobs = 0
    return {
        "active_agents": len([a for a in agents.values() if a.get("status") == "active"]),
        "total_agents": len(agents),
        "active_jobs": active_jobs,
        "total_queue_depth": sum(
            message_bus.get_queue_depth(name) for name in agents.keys()
        ),
    }


@app.websocket("/ws/logs/{agent_name}")
async def agent_logs_websocket(websocket: WebSocket, agent_name: str):
    """
    WebSocket endpoint for streaming agent logs.

    Args:
        websocket: WebSocket connection
        agent_name: Agent to stream logs for
    """
    await websocket.accept()

    try:
        import asyncio
        
        # Send initial connection message
        await websocket.send_json({
            "type": "connected",
            "agent": agent_name,
            "message": f"Connected to {agent_name} logs",
        })
        
        # In production, this would tail Docker logs
        # For now, send periodic status updates
        while True:
            # Check if agent is active
            agents = message_bus.get_registered_agents()
            if agent_name in agents:
                status = agents[agent_name].get("status", "unknown")
                queue_depth = message_bus.get_queue_depth(agent_name)
                
                await websocket.send_json({
                    "type": "status",
                    "agent": agent_name,
                    "status": status,
                    "queue_depth": queue_depth,
                    "timestamp": __import__('time').time(),
                })
            
            await asyncio.sleep(2)

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for agent: {agent_name}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")


@app.websocket("/ws/events")
async def system_events_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for system-wide events.
    
    Streams:
    - New jobs
    - Task completions
    - Agent status changes
    """
    await websocket.accept()

    try:
        import asyncio

        # Initial connection acknowledgement
        await websocket.send_json({
            "type": "connected",
            "message": "Connected to system events",
        })

        events_stream = "events:stream"
        # Start from the latest ID to avoid backfilling old events
        last_id = "$"

        while True:
            # Block up to 10s waiting for new events; no periodic spam
            result = await asyncio.to_thread(
                message_bus.redis_client.xread,
                {events_stream: last_id},
                None,
                10000,
            )

            if not result:
                # Timeout without events; continue waiting
                continue

            for _stream, messages in result:
                for msg_id, fields in messages:
                    last_id = msg_id
                    try:
                        raw = fields.get("data") if isinstance(fields, dict) else None
                        payload = json.loads(raw) if isinstance(raw, str) else fields
                    except Exception:
                        payload = {"event_type": "unknown", "raw": fields}

                    event_type = payload.get("event_type") or payload.get("type") or "event"
                    timestamp = payload.get("timestamp") or datetime.utcnow().isoformat()
                    await websocket.send_json(
                        {
                            "event_type": event_type,
                            "timestamp": timestamp,
                            "data": payload,
                        }
                    )

    except WebSocketDisconnect:
        logger.info("System events WebSocket disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")


def main():
    """Run the API server."""
    import uvicorn

    config = EvenAgeConfig()

    uvicorn.run(
        "evenage.api.main:app",
        host=config.api_host,
        port=config.api_port,
        reload=False,
    )


if __name__ == "__main__":
    main()
