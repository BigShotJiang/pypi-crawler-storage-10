"""
BAPAO - Developer Environment Sync Engine

Make your entire development environment portable.
"""

__version__ = "0.0.8"
__author__ = "BAPAO Team"
__email__ = "team@bapao.dev"