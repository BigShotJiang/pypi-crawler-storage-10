# mcp-python-sandbox

MCP server providing a restricted Python exec tool.

## Run

```bash
python -m src.python_sandbox.server
```
