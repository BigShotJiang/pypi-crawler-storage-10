#!/usr/bin/env python3
"""
MCP Server: mcp-python-sandbox

Restricted Python execution (blacklist model) with stdout capture.
"""

from io import StringIO
import sys

from mcp.server.fastmcp import FastMCP


def create_server() -> FastMCP:
    mcp = FastMCP("mcp-python-sandbox")

    @mcp.tool()
    def python_exec(command: str) -> str:
        """Execute Python code in a restricted sandbox (blacklist-based)."""
        try:
            BLOCKED_MODULES = {
                'subprocess', 'shutil', 'os', 'pathlib', 'tempfile',
                'pty', 'multiprocessing', 'signal', 'gc',
                'importlib', 'ctypes', 'cffi',
            }
            BLOCKED_BUILTINS = {'exec', 'compile', 'open', 'breakpoint'}

            def safe_import(name, *args, **kwargs):
                base = name.split('.')[0]
                if base in BLOCKED_MODULES:
                    raise ImportError(
                        f"Import of '{base}' is blocked for security reasons. "
                        f"Blocked modules: {', '.join(sorted(BLOCKED_MODULES))}"
                    )
                return __import__(name, *args, **kwargs)

            import builtins as _builtins
            sandbox_builtins = {k: getattr(_builtins, k) for k in dir(_builtins) if not k.startswith('_')}
            for b in BLOCKED_BUILTINS:
                sandbox_builtins.pop(b, None)
            sandbox_builtins['__import__'] = safe_import

            sandbox_globals = {'__builtins__': sandbox_builtins}

            output_buffer = StringIO()
            original_stdout = sys.stdout
            sys.stdout = output_buffer
            try:
                exec(command, sandbox_globals, {})
                out = output_buffer.getvalue()
                return out if out.strip() else "Code executed successfully with no output."
            finally:
                sys.stdout = original_stdout
        except Exception as e:
            return f"Error executing Python code: {str(e)}"

    return mcp


if __name__ == "__main__":
    create_server().run()

def main():
    create_server().run()

