def hello():
    return "Hello from Deepfence!"
