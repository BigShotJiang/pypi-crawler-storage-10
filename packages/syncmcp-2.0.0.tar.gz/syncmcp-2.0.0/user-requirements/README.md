# user-requirements/ 目錄說明

這個目錄存放**您的原始需求和參考資料**。

## 📁 目錄結構

```
user-requirements/
├── initial-requirements.md  # 您用自然語言寫的需求
├── references/              # 參考文件（PDF、文章連結等）
├── mockups/                 # UI/UX 設計稿、wireframes
└── docs/                    # 其他相關文件
```

## 🔄 與 rfp/ 的關係

- **user-requirements/** = 您寫的內容（輸入）
- **rfp/** = Claude 產生的規格文件（輸出）

## 💡 使用方式

1. 在 `initial-requirements.md` 用自然語言描述需求
2. 將參考資料放到對應的子目錄
3. 執行 `/vibe-coding` 讓 Claude 產生正式規格
4. Claude 會將結果寫入 `rfp/` 目錄

## ⚠️ 重要

- 這個目錄的內容**不會被 Claude 覆蓋**
- 您可以隨時修改和新增內容
- Claude 只會讀取，不會修改這裡的檔案
