# SyncMCP 作為 MCP Server 使用指南

**日期**: 2025-10-28
**狀態**: ✅ 已完成安裝和配置

---

## 🎉 完成的工作

### 1. ✅ Google Sheets MCP 修復
- 診斷問題：`uvx mcp-google-sheets@latest` 缺少 `packaging` 依賴
- 解決方案：改用虛擬環境安裝
- 安裝位置：`/Users/youlinhsieh/Documents/mcps/mcp-google-sheets/.venv`
- 配置已更新：使用虛擬環境的執行檔
- 詳細報告：[docs/GOOGLE-SHEETS-MCP-FIX.md](docs/GOOGLE-SHEETS-MCP-FIX.md)

### 2. ✅ SyncMCP MCP Server 安裝
- 已安裝到 Claude Code 全域配置
- 位置：`~/.claude.json`
- 命令：`/opt/homebrew/bin/syncmcp`
- 參數：`['mcp']`

### 3. ✅ 撰寫完整的 MCP 設置指南
- 檔案：[docs/MCP-SETUP-GUIDE.md](docs/MCP-SETUP-GUIDE.md)
- 內容涵蓋：
  - 全域 MCP vs 專案 MCP
  - 各種安裝方式（npx, uvx, python, http, sse）
  - 常見錯誤與修復
  - 使用 SyncMCP 同步
  - 測試與驗證

### 4. ✅ 新增 MCP 查詢功能
- 新工具：`get_setup_guide` - 查詢設置指南
- 新工具：`troubleshoot_mcp` - 診斷 MCP 問題
- 類似 Context7 的知識庫查詢功能

---

## 🚀 如何使用 SyncMCP MCP

### 重啟 Claude Code 後可用

```bash
# 重啟 Claude Code
osascript -e 'quit app "Claude Code"'
# 然後重新開啟
```

### MCP 工具列表

現在 SyncMCP 提供 **6 個工具**：

#### 1. sync_mcp_configs
**用途**: 同步所有客戶端的 MCP 配置

**使用範例**:
```
請使用 syncmcp 同步我的 MCP 配置
```

#### 2. check_sync_status
**用途**: 檢查所有客戶端的 MCP 配置狀態

**使用範例**:
```
查看我的 MCP 配置狀態
```

#### 3. show_config_diff
**用途**: 顯示各客戶端之間的配置差異

**使用範例**:
```
顯示我的 MCP 配置差異
```

#### 4. suggest_conflict_resolution
**用途**: 提供配置衝突的解決建議

**使用範例**:
```
我的 MCP 配置有衝突，請給建議
```

#### 5. get_setup_guide ⭐ 新功能
**用途**: 獲取 MCP 設置完整指南

**使用範例**:
```
# 查看完整指南
請顯示 MCP 設置指南

# 查看特定章節
請顯示全域 MCP 設置指南
請顯示 uvx 安裝指南
請顯示常見錯誤解決方案
```

**可用章節**:
- 全部（預設）
- 全域MCP
- 專案MCP
- npx安裝
- uvx安裝
- python安裝
- 常見錯誤
- 測試驗證

#### 6. troubleshoot_mcp ⭐ 新功能
**用途**: 診斷並提供 MCP 問題的解決方案

**使用範例**:
```
# 診斷一般錯誤
我的 google-sheets MCP 無法連接，錯誤是：ModuleNotFoundError: No module named 'packaging'

# 診斷專案 MCP 問題
我的專案 MCP 沒有載入，錯誤訊息：找不到 .claude/mcp.json
```

**支援的錯誤類型**:
- Python 模組依賴缺失 (`ModuleNotFoundError`)
- 命令找不到 (`command not found`, `ENOENT`)
- JSON 格式錯誤
- 認證問題 (`auth`, `token`, `credential`)
- 專案 MCP 配置問題

---

## 💡 使用場景

### 場景 1: 設置新的 MCP

**之前**（容易出錯）:
```
我：請幫我設置一個新的 notion MCP
Claude：好的，我將在 ~/.claude.json 中添加...
[可能設置錯誤：類型錯誤、路徑錯誤、格式錯誤]
```

**現在**（有指南參考）:
```
我：請幫我設置一個新的 notion MCP
Claude：讓我先查詢設置指南... [調用 get_setup_guide]
[Claude 參考指南後正確設置]
```

### 場景 2: MCP 無法連接

**之前**（需要手動排查）:
```
我：google-sheets MCP 無法連接
Claude：讓我檢查配置...
[需要多次嘗試和測試]
```

**現在**（智能診斷）:
```
我：google-sheets MCP 無法連接，錯誤：ModuleNotFoundError: No module named 'packaging'
[Claude 調用 troubleshoot_mcp]
Claude：診斷結果：Python 模組依賴缺失
解決方案：
1. 改用虛擬環境安裝
2. 更新配置使用虛擬環境路徑
[提供具體的命令]
```

### 場景 3: 專案 MCP 設置

**之前**（常見錯誤）:
```
我：幫我設置專案級 MCP
Claude：好的，我將建立 mcp.json...
[建立在錯誤位置：專案根目錄而非 .claude/]
```

**現在**（參考指南）:
```
我：幫我設置專案級 MCP
[Claude 調用 get_setup_guide section="專案MCP"]
Claude：根據指南，專案 MCP 必須放在 .claude/mcp.json...
[正確建立在 .claude/ 目錄中]
```

---

## 🔧 配置詳情

### Claude Code 全域配置

**檔案位置**: `~/.claude.json`

**SyncMCP MCP 配置**:
```json
{
  "mcpServers": {
    "syncmcp": {
      "type": "stdio",
      "command": "/opt/homebrew/bin/syncmcp",
      "args": ["mcp"],
      "env": {}
    }
  }
}
```

### 驗證安裝

```bash
# 檢查配置
syncmcp list claude-code | grep syncmcp

# 應該看到
# • syncmcp
#   command: /opt/homebrew/bin/syncmcp
#   args: ['mcp']
```

---

## 📊 MCP 工具對比

### SyncMCP vs Context7

| 特性 | SyncMCP | Context7 |
|-----|---------|----------|
| **主要功能** | MCP 配置管理 | 程式碼搜尋 |
| **知識庫** | MCP 設置指南 | 程式碼資料庫 |
| **查詢方式** | `get_setup_guide` | HTTP API |
| **診斷功能** | `troubleshoot_mcp` | N/A |
| **自動修復** | ✅ 同步配置 | ❌ |
| **本地/遠端** | 本地（stdio） | 遠端（HTTP） |

### 何時使用 SyncMCP MCP？

| 任務 | 使用 SyncMCP MCP | 使用 syncmcp CLI |
|-----|-----------------|------------------|
| 查詢設置指南 | ✅ 更方便（在對話中） | ⚠️ 需要離開對話 |
| 診斷 MCP 問題 | ✅ 智能分析 | ⚠️ 手動判斷 |
| 同步配置 | ✅ 可以 | ✅ 推薦（更快） |
| 查看差異 | ✅ 可以 | ✅ 推薦（Rich UI） |
| 系統診斷 | ❌ | ✅ `syncmcp doctor` |

**建議**:
- 📖 **查詢文檔** → 使用 MCP 工具
- 🔧 **診斷問題** → 使用 MCP 工具
- ⚙️ **執行操作** → 使用 CLI（更快更直接）

---

## 🎓 給未來 Claude Code 的提示

當您（未來的 Claude Code）需要設置 MCP 時：

### ✅ 正確做法

```
步驟 1: 查詢指南
[調用 get_setup_guide 獲取相關章節]

步驟 2: 根據指南設置
[按照指南中的正確格式和位置設置]

步驟 3: 驗證設置
[檢查 JSON 格式、檔案存在性、路徑正確性]

步驟 4: 測試 MCP
[建議用戶重啟 Claude Code 並測試]
```

### ❌ 錯誤做法

```
直接憑記憶設置
→ 可能使用錯誤的類型（如 streamable-http）
→ 可能放錯位置（專案 MCP 在根目錄）
→ 可能缺少必要的配置項
```

### 🔍 遇到問題時

```
步驟 1: 分析錯誤訊息
[調用 troubleshoot_mcp 診斷問題]

步驟 2: 檢查相關章節
[調用 get_setup_guide 查看相關指南]

步驟 3: 執行修復
[根據診斷結果修復問題]

步驟 4: 驗證修復
[確認問題已解決]
```

---

## 📚 相關文檔

### 主要文檔
- **MCP 設置指南**: [docs/MCP-SETUP-GUIDE.md](docs/MCP-SETUP-GUIDE.md)
- **Google Sheets 修復報告**: [docs/GOOGLE-SHEETS-MCP-FIX.md](docs/GOOGLE-SHEETS-MCP-FIX.md)
- **MCP 整合指南**: [MCP_INTEGRATION.md](MCP_INTEGRATION.md)
- **使用者指南**: [docs/USER-GUIDE.md](docs/USER-GUIDE.md)

### 快速參考
- **README**: [README.md](README.md)
- **變更日誌**: [CHANGELOG.md](CHANGELOG.md)
- **發布指南**: [PUBLISHING.md](PUBLISHING.md)

---

## 🎯 下一步

### 1. 重啟 Claude Code
讓新的 MCP 配置生效：
```bash
osascript -e 'quit app "Claude Code"'
```

### 2. 測試 SyncMCP MCP
```
/mcp list
# 應該看到 syncmcp

# 測試查詢功能
請顯示 MCP 設置指南

# 測試診斷功能（使用之前修復的 google-sheets 案例）
請診斷這個錯誤：ModuleNotFoundError: No module named 'packaging'
```

### 3. 測試 Google Sheets MCP
```
請列出我 Google Drive 中的所有 spreadsheet
```

### 4. 未來設置 MCP 時
記得使用 SyncMCP MCP 的查詢功能：
```
# 設置前先查詢
請顯示 [相關章節] 的 MCP 設置指南

# 遇到問題時診斷
請診斷這個 MCP 問題：[錯誤訊息]
```

---

## ✨ 總結

### 完成的功能

1. ✅ **Google Sheets MCP 修復** - 從 uvx 改為虛擬環境
2. ✅ **SyncMCP MCP 安裝** - 可在對話中使用
3. ✅ **完整設置指南** - 涵蓋所有安裝方式和錯誤處理
4. ✅ **智能查詢功能** - 類似 Context7 的知識庫
5. ✅ **智能診斷功能** - 自動分析錯誤並提供解決方案

### 核心優勢

- �� **有文檔參考** - 不再憑記憶設置 MCP
- 🔍 **智能診斷** - 自動分析常見錯誤
- 🔧 **自動修復** - 提供具體的修復步驟
- 🚀 **提升效率** - 減少設置錯誤和排查時間

### 未來改進方向

- [ ] 增加更多錯誤模式匹配
- [ ] 支援自動執行修復命令
- [ ] 整合更多 MCP 範例
- [ ] 提供互動式設置嚮導

---

**建立者**: Claude
**日期**: 2025-10-28
**版本**: 1.0
