# Claude Code MCP 設置完整指南

**目標讀者**: Claude Code AI Assistant（未來的我）
**用途**: 正確設置 MCP Server，避免常見錯誤
**版本**: 2.0
**更新日期**: 2025-10-28

---

## 🚨 重要提醒

**在設置任何 MCP 之前，請先執行以下命令獲取最新指南**:

```bash
# 使用 SyncMCP MCP 獲取指南
@syncmcp get-setup-guide
```

如果 SyncMCP MCP 尚未安裝，請先完成本文檔。

---

## 📚 目錄

1. [MCP 基礎概念](#mcp-基礎概念)
2. [全域 MCP 設置](#全域-mcp-設置)
3. [專案級 MCP 設置](#專案級-mcp-設置)
4. [常見錯誤與修復](#常見錯誤與修復)
5. [使用 SyncMCP 同步](#使用-syncmcp-同步)
6. [測試與驗證](#測試與驗證)

---

## MCP 基礎概念

### 什麼是 MCP？

**MCP** (Model Context Protocol) 是一個標準協議，讓 AI 助手能夠：
- 🔌 連接外部工具和服務
- 📊 存取資料來源（資料庫、API、檔案系統）
- 🤖 執行自動化任務

### MCP 的兩個層級

| 層級 | 配置檔位置 | 作用範圍 | 適用場景 |
|-----|-----------|---------|---------|
| **全域 MCP** | `~/.claude.json` | 所有專案 | 通用工具（如 filesystem, notion, sheets） |
| **專案 MCP** | `專案/.claude/mcp.json` | 當前專案 | 專案特定工具（如專案 API、本地資料庫） |

### MCP 類型

Claude Code 支援 4 種 MCP 類型：

#### 1. stdio (標準輸入輸出) ⭐ 最常用

**適用**: Node.js、Python、任何命令列程式

```json
{
  "your-mcp-name": {
    "type": "stdio",
    "command": "執行檔路徑",
    "args": ["參數1", "參數2"],
    "env": {
      "環境變數": "值"
    }
  }
}
```

#### 2. http (HTTP API)

**適用**: 遠端 HTTP MCP 服務（需要 headers）

```json
{
  "your-mcp-name": {
    "type": "http",
    "url": "https://api.example.com/mcp",
    "headers": {
      "Authorization": "Bearer YOUR_TOKEN"
    }
  }
}
```

#### 3. sse (Server-Sent Events)

**適用**: 遠端 SSE MCP 服務（無需 headers）

```json
{
  "your-mcp-name": {
    "type": "sse",
    "url": "https://api.example.com/mcp"
  }
}
```

#### 4. streamable-http (Roo Code 專用)

⚠️ **Claude Code 不支援！** 這是 Roo Code 特有的類型。

---

## 全域 MCP 設置

### 配置檔位置

```bash
~/.claude.json
```

### 設置步驟

#### 步驟 1: 備份現有配置

```bash
cp ~/.claude.json ~/.claude.json.backup-$(date +%Y%m%d-%H%M%S)
```

#### 步驟 2: 編輯配置

```bash
# 使用編輯器打開
vim ~/.claude.json

# 或使用 Claude Code 的指令
/open ~/.claude.json
```

#### 步驟 3: 添加 MCP

在 `mcpServers` 區塊中添加：

```json
{
  "mcpServers": {
    "existing-mcp": { ... },

    "your-new-mcp": {
      "type": "stdio",
      "command": "/path/to/executable",
      "args": ["arg1", "arg2"],
      "env": {
        "VAR_NAME": "value"
      }
    }
  }
}
```

### 常見安裝方式

#### 方式 A: npx (Node.js 套件) ⭐ 推薦

**優點**: 簡單、自動更新、無需安裝

```json
{
  "your-mcp-name": {
    "type": "stdio",
    "command": "npx",
    "args": ["-y", "package-name@latest"],
    "env": {}
  }
}
```

**範例**:
```json
{
  "notion": {
    "type": "stdio",
    "command": "npx",
    "args": ["-y", "notion-mcp-server"],
    "env": {
      "NOTION_API_TOKEN": "your_token_here"
    }
  }
}
```

#### 方式 B: uvx (Python 套件)

**優點**: 快速、自動隔離

```json
{
  "your-mcp-name": {
    "type": "stdio",
    "command": "uvx",
    "args": ["package-name@latest"],
    "env": {}
  }
}
```

**⚠️ 常見問題**: macOS 可能需要完整路徑

```json
{
  "your-mcp-name": {
    "type": "stdio",
    "command": "/Users/username/.cargo/bin/uvx",  // 完整路徑
    "args": ["package-name@latest"],
    "env": {}
  }
}
```

**如何找到 uvx 路徑**:
```bash
which uvx
```

#### 方式 C: Python 虛擬環境

**優點**: 完全控制依賴、可修復套件問題

**何時使用**: uvx 安裝失敗時（如缺少依賴）

```json
{
  "your-mcp-name": {
    "type": "stdio",
    "command": "/path/to/project/.venv/bin/mcp-executable",
    "args": [],
    "env": {}
  }
}
```

**設置步驟**:
```bash
# 1. 建立虛擬環境
mkdir -p ~/Documents/mcps/your-mcp-name
cd ~/Documents/mcps/your-mcp-name
python3.12 -m venv .venv

# 2. 安裝套件
.venv/bin/pip install your-mcp-package

# 3. 找到執行檔
ls -la .venv/bin/ | grep mcp

# 4. 在 .claude.json 中使用完整路徑
```

**範例**（google-sheets 的實際案例）:
```json
{
  "google-sheets": {
    "type": "stdio",
    "command": "/Users/username/Documents/mcps/mcp-google-sheets/.venv/bin/mcp-google-sheets",
    "args": [],
    "env": {
      "SERVICE_ACCOUNT_PATH": "/path/to/credentials.json",
      "DRIVE_FOLDER_ID": "your_folder_id"
    }
  }
}
```

#### 方式 D: 本地開發中的 MCP

**適用**: 您正在開發的 MCP

```json
{
  "your-dev-mcp": {
    "type": "stdio",
    "command": "/path/to/project/node_modules/.bin/your-mcp",
    "args": [],
    "cwd": "/path/to/project",
    "env": {}
  }
}
```

#### 方式 E: HTTP/SSE 遠端 MCP

**HTTP** (需要認證):
```json
{
  "context7": {
    "type": "http",
    "url": "https://mcp.context7.com/mcp",
    "headers": {
      "CONTEXT7_API_KEY": "your_api_key"
    }
  }
}
```

**SSE** (無需認證或使用 OAuth):
```json
{
  "canva": {
    "type": "sse",
    "url": "https://mcp.canva.com/mcp"
  }
}
```

### 🔍 設置檢查清單

設置完成後，**必須檢查**以下項目：

- [ ] ✅ JSON 格式正確（無語法錯誤）
- [ ] ✅ `command` 路徑存在且可執行
- [ ] ✅ 環境變數 (`env`) 正確設置
- [ ] ✅ 認證資訊（API keys, tokens）有效
- [ ] ✅ 必要的檔案（如 credentials.json）存在

**檢查指令**:

```bash
# 1. 驗證 JSON 格式
python3 -m json.tool ~/.claude.json > /dev/null && echo "✅ JSON 格式正確" || echo "❌ JSON 格式錯誤"

# 2. 檢查命令是否存在
which npx uvx  # 檢查 npx/uvx 是否在 PATH 中
test -f /path/to/command && echo "✅ 命令存在" || echo "❌ 命令不存在"

# 3. 使用 SyncMCP 診斷
syncmcp doctor

# 4. 查看配置
syncmcp list claude-code
```

---

## 專案級 MCP 設置

### ⚠️ 重要：正確的檔案位置

**❌ 錯誤** (無效！):
```
專案根目錄/
├── mcp.json          ❌ 不會被讀取
├── .mcp.json         ❌ 不會被讀取
├── src/
└── README.md
```

**✅ 正確**:
```
專案根目錄/
├── .claude/
│   └── mcp.json      ✅ 正確位置！
├── src/
└── README.md
```

### 設置步驟

#### 步驟 1: 建立 .claude 目錄

```bash
cd /path/to/your/project
mkdir -p .claude
```

#### 步驟 2: 建立 mcp.json

```bash
touch .claude/mcp.json
```

#### 步驟 3: 編輯配置

```json
{
  "mcpServers": {
    "project-specific-mcp": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "your-project-mcp"],
      "env": {
        "PROJECT_VAR": "value"
      }
    }
  }
}
```

### 專案 MCP vs 全域 MCP

| 特性 | 全域 MCP | 專案 MCP |
|-----|---------|---------|
| **適用場景** | 通用工具 | 專案特定 |
| **範例** | notion, sheets, filesystem | 專案 API, 本地資料庫 |
| **配置檔** | `~/.claude.json` | `.claude/mcp.json` |
| **版本控制** | ❌ 不要提交 | ✅ 可以提交（移除密鑰） |
| **團隊共享** | ❌ 個人配置 | ✅ 團隊共用 |

### 專案 MCP 最佳實踐

#### 1. 環境變數管理

**❌ 不要直接寫密鑰**:
```json
{
  "env": {
    "API_KEY": "sk-1234567890"  // ❌ 不安全
  }
}
```

**✅ 使用環境變數**:
```json
{
  "env": {
    "API_KEY": "${PROJECT_API_KEY}"  // ✅ 從系統環境讀取
  }
}
```

設置環境變數:
```bash
# ~/.zshrc 或 ~/.bashrc
export PROJECT_API_KEY="sk-1234567890"
```

#### 2. .gitignore 設置

```bash
# .gitignore
.claude/mcp.json.local    # 本地覆蓋配置
.claude/*.secret.json     # 密鑰檔案
```

#### 3. 提供範例配置

```bash
# .claude/mcp.json.example
{
  "mcpServers": {
    "project-api": {
      "type": "http",
      "url": "http://localhost:3000/mcp",
      "headers": {
        "Authorization": "Bearer ${PROJECT_API_KEY}"
      }
    }
  }
}
```

團隊成員可以複製並修改:
```bash
cp .claude/mcp.json.example .claude/mcp.json
# 然後編輯填入實際的密鑰
```

---

## 常見錯誤與修復

### 錯誤 1: MCP 無法連接

**症狀**: Claude Code 無法載入 MCP

**可能原因**:

#### A. 命令路徑錯誤

**檢查**:
```bash
# 檢查命令是否存在
which npx uvx python3
test -f /path/to/command && echo "存在" || echo "不存在"
```

**修復**: 使用完整路徑或確保命令在 PATH 中

#### B. 依賴缺失

**症狀**: 看到 `ModuleNotFoundError` 或類似錯誤

**修復**: 改用虛擬環境安裝（參見方式 C）

```bash
# 建立虛擬環境
mkdir -p ~/Documents/mcps/your-mcp
cd ~/Documents/mcps/your-mcp
python3.12 -m venv .venv

# 安裝套件及缺失的依賴
.venv/bin/pip install your-mcp-package missing-dependency

# 更新配置使用虛擬環境路徑
```

#### C. 環境變數錯誤

**檢查**: 確認所有必要的環境變數都已設置

```json
{
  "env": {
    "REQUIRED_VAR": "value",      // ✅ 正確
    "OPTIONAL_VAR": ""            // ⚠️ 空值可能導致問題
  }
}
```

#### D. 認證檔案不存在

**檢查**:
```bash
test -f /path/to/credentials.json && echo "✅ 檔案存在" || echo "❌ 檔案不存在"
```

### 錯誤 2: JSON 格式錯誤

**症狀**: 配置檔無法解析

**常見問題**:

```json
{
  "mcpServers": {
    "mcp1": { ... },    // ✅ 正確：逗號分隔
    "mcp2": { ... }     // ✅ 正確：最後一個不要逗號
  }
}
```

**檢查工具**:
```bash
# 驗證 JSON
python3 -m json.tool ~/.claude.json

# 或使用 jq
jq . ~/.claude.json
```

### 錯誤 3: 專案 MCP 無效

**症狀**: 專案級 MCP 沒有載入

**原因**: 檔案位置錯誤

**檢查**:
```bash
# 正確位置
test -f .claude/mcp.json && echo "✅ 位置正確" || echo "❌ 位置錯誤"

# 錯誤位置
test -f mcp.json && echo "⚠️ 應該在 .claude/ 目錄中" || true
```

**修復**:
```bash
mkdir -p .claude
mv mcp.json .claude/
```

### 錯誤 4: 類型轉換錯誤

**症狀**: Roo Code 或其他客戶端的配置在 Claude Code 中無效

**原因**: 類型不相容

| 原始類型 | Claude Code 轉換 |
|---------|-----------------|
| `streamable-http` | `http` (有 headers) 或 `sse` (無 headers) |
| `http` (Roo) | `streamable-http` (Roo) |

**修復**: 使用 SyncMCP 自動轉換（參見下一節）

---

## 使用 SyncMCP 同步

### 什麼時候使用 SyncMCP？

- ✅ 在多個 AI 客戶端之間同步 MCP（Claude Code, Roo Code, Claude Desktop, Gemini）
- ✅ 自動轉換不相容的 MCP 類型
- ✅ 備份和恢復 MCP 配置
- ✅ 檢查配置衝突

### 基本用法

#### 1. 檢查當前狀態

```bash
syncmcp status
```

輸出:
```
┏━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ 客戶端         ┃ 配置路徑      ┃ MCP 數量 ┃ 最後修改     ┃
┡━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ claude-code    │ ~/.claude.js… │ 11       │ 2025-10-28   │
│ roo-code       │ ...           │ 11       │ 2025-10-28   │
│ claude-desktop │ ...           │ 9        │ 2025-10-28   │
└────────────────┴───────────────┴──────────┴──────────────┘
```

#### 2. 檢查差異

```bash
syncmcp diff
```

顯示各客戶端之間的 MCP 差異。

#### 3. 執行同步

```bash
# 預覽同步（不實際執行）
syncmcp sync --dry-run

# 實際同步
syncmcp sync

# 自動選擇最新配置
syncmcp sync --auto
```

#### 4. 備份配置

```bash
# 自動備份（同步前自動執行）
syncmcp sync  # 會先備份

# 手動備份
cp ~/.claude.json ~/.claude.json.backup-$(date +%Y%m%d)
```

#### 5. 恢復配置

```bash
# 查看備份歷史
syncmcp history

# 恢復特定備份
syncmcp restore <backup-id>
```

### SyncMCP 自動類型轉換

SyncMCP 會自動處理不同客戶端的類型差異：

**從 Roo Code 同步到 Claude Code**:
```json
// Roo Code 配置
{
  "type": "streamable-http",
  "url": "https://api.example.com/mcp"
}

// ↓ SyncMCP 自動轉換為 ↓

// Claude Code 配置
{
  "type": "sse",  // 或 "http"（如果有 headers）
  "url": "https://api.example.com/mcp"
}
```

**從 Claude Code 同步到 Claude Desktop**:
```json
// Claude Code 配置（http MCP）
{
  "type": "http",
  "url": "https://api.example.com/mcp"
}

// ↓ SyncMCP 自動過濾（Desktop 只支援 stdio）↓

// 不會同步到 Claude Desktop
```

### SyncMCP 診斷

```bash
# 完整系統診斷
syncmcp doctor
```

檢查項目:
- ✅ Python 版本
- ✅ 依賴套件
- ✅ 配置檔存在性
- ✅ 配置檔格式
- ✅ MCP Server 可用性

---

## 測試與驗證

### 步驟 1: 驗證配置格式

```bash
# JSON 格式檢查
python3 -m json.tool ~/.claude.json > /dev/null && \
  echo "✅ 全域配置格式正確" || \
  echo "❌ 全域配置格式錯誤"

python3 -m json.tool .claude/mcp.json > /dev/null && \
  echo "✅ 專案配置格式正確" || \
  echo "❌ 專案配置格式錯誤"
```

### 步驟 2: 檢查命令可用性

```bash
# 檢查 npx
which npx && npx --version

# 檢查 uvx
which uvx && uvx --version

# 檢查自定義命令
test -f /path/to/command && echo "✅ 命令存在"
```

### 步驟 3: 測試 MCP 連接

```bash
# 使用 SyncMCP
syncmcp list claude-code

# 查看特定 MCP
syncmcp list claude-code | grep "your-mcp-name"
```

### 步驟 4: 重啟 Claude Code

配置更改後，**必須重啟** Claude Code 才會生效。

```bash
# macOS
osascript -e 'quit app "Claude Code"'

# 或使用快捷鍵
Cmd + Q
```

### 步驟 5: 驗證 MCP 載入

重啟後，執行:

```
/mcp list
```

應該看到您新增的 MCP。

### 步驟 6: 測試 MCP 功能

嘗試使用 MCP 提供的工具:

```
請使用 [您的 MCP 名稱] 執行一個簡單的測試任務
```

---

## 📋 快速參考

### MCP 設置檢查清單

設置新 MCP 時，按順序檢查：

1. [ ] 確認 MCP 類型（stdio/http/sse）
2. [ ] 準備認證資訊（API keys, tokens, credentials）
3. [ ] 備份現有配置
4. [ ] 編輯配置檔（全域或專案）
5. [ ] 驗證 JSON 格式
6. [ ] 檢查命令/檔案存在性
7. [ ] 使用 syncmcp doctor 診斷
8. [ ] 重啟 Claude Code
9. [ ] 執行 /mcp list 驗證
10. [ ] 測試 MCP 功能

### 常用指令速查

```bash
# 配置檔位置
~/.claude.json              # 全域配置
.claude/mcp.json            # 專案配置

# SyncMCP 指令
syncmcp status              # 查看狀態
syncmcp list claude-code    # 列出 MCP
syncmcp diff                # 查看差異
syncmcp sync                # 同步配置
syncmcp doctor              # 診斷問題

# 配置檢查
python3 -m json.tool ~/.claude.json  # 驗證 JSON
which npx uvx                        # 檢查命令
test -f /path/to/file                # 檢查檔案
```

### 獲取更多幫助

```bash
# SyncMCP 文檔
syncmcp --help
syncmcp sync --help

# 或使用 MCP 查詢
@syncmcp get-setup-guide
@syncmcp troubleshoot "your error message"
```

---

## 🔗 相關資源

- **SyncMCP 文檔**: [README.md](../README.md)
- **MCP 整合指南**: [MCP_INTEGRATION.md](../MCP_INTEGRATION.md)
- **故障排除**: [TROUBLESHOOTING.md](../docs/TROUBLESHOOTING.md)
- **Claude Code 文檔**: https://docs.claude.com/en/docs/claude-code

---

**版本歷史**:
- v2.0 (2025-10-28): 完整重寫，新增專案 MCP、SyncMCP 整合
- v1.0 (2025-10-20): 初始版本

**維護者**: Claude + SyncMCP Team
