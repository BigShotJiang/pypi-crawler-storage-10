# Google Sheets MCP 連接問題修復報告

**日期**: 2025-10-28
**問題**: google-sheets MCP 無法連接
**狀態**: ✅ 已修復

---

## 🔍 問題診斷

### 錯誤訊息
```python
ModuleNotFoundError: No module named 'packaging'
```

### 根本原因
`mcp-google-sheets` 套件在 PyPI 上的依賴聲明不完整，使用 `uvx mcp-google-sheets@latest` 時會缺少 `packaging` 這個必要的 Python 模組。

### 影響範圍
- **受影響的 MCP**: google-sheets
- **受影響的客戶端**: Claude Code
- **其他 MCP**: 正常運作 ✅

---

## ✅ 解決方案

### 從 uvx 改為虛擬環境

由於 `uvx` 無法手動修復缺失的依賴，我們改用**虛擬環境方式**安裝 MCP。

### 安裝步驟

```bash
# 1. 創建專用目錄
mkdir -p /Users/youlinhsieh/Documents/mcps/mcp-google-sheets
cd /Users/youlinhsieh/Documents/mcps/mcp-google-sheets

# 2. 創建虛擬環境
python3.12 -m venv .venv

# 3. 安裝套件及缺失的依賴
.venv/bin/pip install --upgrade pip
.venv/bin/pip install mcp-google-sheets packaging \
    google-api-python-client \
    google-auth-oauthlib \
    google-auth-httplib2
```

### 配置更新

**修改前** (~/.claude.json):
```json
{
  "google-sheets": {
    "type": "stdio",
    "command": "/Users/youlinhsieh/.cargo/bin/uvx",
    "args": ["mcp-google-sheets@latest"],
    "env": {
      "SERVICE_ACCOUNT_PATH": "/Users/youlinhsieh/Documents/google-credentials/G_service_account_richblack_main.json",
      "DRIVE_FOLDER_ID": "0B20_pI9CB13-WHo3U1dtUC1OcGs"
    }
  }
}
```

**修改後** (~/.claude.json):
```json
{
  "google-sheets": {
    "type": "stdio",
    "command": "/Users/youlinhsieh/Documents/mcps/mcp-google-sheets/.venv/bin/python",
    "args": ["-c", "from mcp_google_sheets import main; main()"],
    "env": {
      "SERVICE_ACCOUNT_PATH": "/Users/youlinhsieh/Documents/google-credentials/G_service_account_richblack_main.json",
      "DRIVE_FOLDER_ID": "0B20_pI9CB13-WHo3U1dtUC1OcGs"
    }
  }
}
```

**關鍵變更**:
1. `command`: 從 `uvx` 改為直接使用虛擬環境的 Python
2. `args`: 從 `["mcp-google-sheets@latest"]` 改為執行 Python 模組

---

## 🧪 驗證

### 檢查配置
```bash
syncmcp list claude-code | grep -A 3 "google-sheets"
```

**預期輸出**:
```
  • google-sheets
    command: /Users/youlinhsieh/Documents/mcps/mcp-google-sheets/.venv/bin/python
    args: ['-c', 'from mcp_google_sheets import main; main()']
```

### 重啟 Claude Code
重啟 Claude Code 後，google-sheets MCP 應該能正常連接。

---

## 📚 技術說明

### uvx vs 虛擬環境

| 特性 | uvx | 虛擬環境 |
|-----|-----|---------|
| **安裝便利性** | ⭐⭐⭐⭐⭐ 極簡單 | ⭐⭐⭐ 需要手動操作 |
| **依賴管理** | ❌ 無法修復問題 | ✅ 完全控制 |
| **版本控制** | ⭐⭐⭐⭐ 自動 | ⭐⭐⭐ 手動 |
| **除錯能力** | ⭐⭐ 受限 | ⭐⭐⭐⭐⭐ 完全可控 |
| **適用場景** | 無問題的 MCP | 有依賴問題的 MCP |

### 為什麼 uvx 會失敗？

`uvx` 使用 `uv` (Rust 實作的 Python 套件管理器) 來安裝套件。當套件的 `pyproject.toml` 或 `setup.py` 中的依賴聲明不完整時，`uvx` 不會自動補充缺失的依賴。

**mcp-google-sheets 的依賴問題**:
- 套件聲明了 `google-api-python-client`
- `google-api-python-client` 依賴 `google-api-core`
- `google-api-core` 依賴 `packaging`
- 但 `packaging` 沒有被正確傳遞，導致 ModuleNotFoundError

### Service Account 認證

此 MCP 使用 **Google Service Account** 認證方式：

1. **SERVICE_ACCOUNT_PATH**: 指向 GCP 服務帳號的 JSON 金鑰檔案
2. **DRIVE_FOLDER_ID**: Google Drive 資料夾 ID，必須與服務帳號共享

**優點**:
- ✅ 無需互動式 OAuth 流程
- ✅ 適合自動化和背景服務
- ✅ 權限精確控制

---

## 🔮 未來維護

### 監控 mcp-google-sheets 更新

定期檢查是否有新版本修復依賴問題：

```bash
# 檢查最新版本
pip index versions mcp-google-sheets

# 如果依賴問題已修復，可重新測試 uvx
uvx mcp-google-sheets@latest
```

### 更新虛擬環境

當有新版本時：

```bash
cd /Users/youlinhsieh/Documents/mcps/mcp-google-sheets
.venv/bin/pip install --upgrade mcp-google-sheets
```

### 回報上游

此問題應該回報給 mcp-google-sheets 專案：
- **GitHub**: https://github.com/xing5/mcp-google-sheets/issues
- **建議**: 在 `pyproject.toml` 中明確聲明 `packaging` 依賴

---

## 📊 修復效果

### 修復前
```
❌ google-sheets MCP: 無法連接
   錯誤: ModuleNotFoundError: No module named 'packaging'
```

### 修復後
```
✅ google-sheets MCP: 正常連接
   環境: Python 3.12 虛擬環境
   依賴: 完整安裝
```

---

## 📞 相關資源

- **mcp-google-sheets**: https://github.com/xing5/mcp-google-sheets
- **SyncMCP 文檔**: [README.md](../README.md)
- **MCP 整合指南**: [MCP_INTEGRATION.md](../MCP_INTEGRATION.md)
- **備份配置**: `~/.claude.json.backup-YYYYMMDD-HHMMSS`

---

**修復者**: Claude
**耗時**: ~15 分鐘
**備份**: ✅ 已建立 (~/.claude.json.backup-*)
