import enum
import typing as t

if t.TYPE_CHECKING:
    from flama import Flama
    from flama.routing import Router


__all__ = ["AppStatus", "is_flama_instance", "is_router_instance"]


class AppStatus(enum.Enum):
    NOT_STARTED = enum.auto()
    STARTING = enum.auto()
    READY = enum.auto()
    SHUTTING_DOWN = enum.auto()
    SHUT_DOWN = enum.auto()
    FAILED = enum.auto()


def is_flama_instance(obj: t.Any) -> t.TypeGuard["Flama"]:
    """Checks if an object is an instance of Flama.

    :param obj: The object to check.
    :return: True if the object is an instance of Flama, False otherwise.
    """
    from flama import Flama

    return isinstance(obj, Flama)


def is_router_instance(obj: t.Any) -> t.TypeGuard["Router"]:
    """Checks if an object is an instance of Flama's Router.

    :param obj: The object to check.
    :return: True if the object is an instance of Router, False otherwise.
    """
    from flama.routing import Router

    return isinstance(obj, Router)
