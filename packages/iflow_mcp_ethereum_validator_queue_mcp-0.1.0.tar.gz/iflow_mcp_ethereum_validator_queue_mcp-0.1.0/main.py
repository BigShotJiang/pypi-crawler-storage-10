import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "ETH Validator Queue",
    dependencies=["httpx"]
)


@mcp.tool()
async def get_activation_queue() -> str:
    """Get current Ethereum validator activation queue statistics.
    
    Returns:
        A string containing:
        - Current activation queue length (number of validators waiting to activate)
        - Total active validators
        - Total balance of entering validators in ETH
        - Estimated wait time (based on ~900 activations per day)
    """
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get("https://beaconcha.in/api/v1/validators/queue")
            response.raise_for_status()
            data = response.json()["data"]
            entering = data.get("beaconchain_entering", 0)
            validators_count = data.get("validatorscount", 0)
            entering_balance = data.get("beaconchain_entering_balance", 0) / 1e9 if data.get("beaconchain_entering_balance") else 0
            return (
                f"Current activation queue length: {entering} validators\n"
                f"Total active validators: {validators_count}\n"
                f"Entering validators balance: {entering_balance:.2f} ETH\n"
                f"Estimated wait time: Approximately {entering / 900:.1f} days "
                f"(assuming ~900 activations per day)"
            )
        except Exception as e:
            return f"Error fetching activation queue data: {str(e)}"


@mcp.tool()
async def get_exit_queue() -> str:
    """Get current Ethereum validator exit queue statistics.
    
    Returns:
        A string containing:
        - Current exit queue length (number of validators waiting to exit)
        - Total active validators
        - Total balance of exiting validators in ETH
        - Estimated wait time (based on ~900 exits per day)
    """
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get("https://beaconcha.in/api/v1/validators/queue")
            response.raise_for_status()
            data = response.json()["data"]
            exiting = data.get("beaconchain_exiting", 0)
            validators_count = data.get("validatorscount", 0)
            exiting_balance = data.get("beaconchain_exiting_balance", 0) / 1e9 if data.get("beaconchain_exiting_balance") else 0
            return (
                f"Current exit queue length: {exiting} validators\n"
                f"Total active validators: {validators_count}\n"
                f"Exiting validators balance: {exiting_balance:.2f} ETH\n"
                f"Estimated wait time: Approximately {exiting / 900:.1f} days "
                f"(assuming ~900 exits per day)"
            )
        except Exception as e:
            return f"Error fetching exit queue data: {str(e)}"


@mcp.tool()
async def get_validator_status(pubkey: str) -> str:
    """Get status for a specific Ethereum validator by public key.
    
    Args:
        pubkey (str): The public key of the validator (48-byte hex string starting with '0x')
    
    Returns:
        A string containing:
        - Validator public key
        - Current status (e.g., active_online, pending, exited)
        - Effective balance in ETH
        - Activation epoch (if applicable)
        - Exit epoch (if applicable)
    """
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"https://beaconcha.in/api/v1/validator/{pubkey}")
            response.raise_for_status()
            data = response.json()["data"]
            status = data.get("status", "unknown")
            balance = data.get("balance", 0) / 1e9 if data.get("balance") else 0
            return (
                f"Validator {pubkey}:\n"
                f"Status: {status}\n"
                f"Effective Balance: {balance:.2f} ETH\n"
                f"Activation Epoch: {data.get('activationepoch', 'N/A')}\n"
                f"Exit Epoch: {data.get('exitepoch', 'N/A')}"
            )
        except Exception as e:
            return f"Error fetching validator status: {str(e)}"


@mcp.prompt()
def analyze_queue() -> str:
    """Prompt to analyze current validator queue trends.
    
    Returns:
        A string prompt for LLM analysis of queue trends, including:
        - Queue length implications
        - Impact on ETH price and network security
        - Request for historical context
    """
    return (
        "Analyze the current Ethereum validator queues:\n"
        "- What do the current queue lengths indicate about staking demand?\n"
        "- How might this impact ETH price and network security?\n"
        "- Provide historical context if possible."
    )


if __name__ == "__main__":
    mcp.run()
