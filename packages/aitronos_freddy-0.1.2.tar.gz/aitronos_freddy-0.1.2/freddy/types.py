"""Type definitions for Freddy SDK"""

from typing import Any, Dict, List, Literal, Optional, Union
from typing_extensions import TypedDict


# Response types
class TextContent(TypedDict, total=False):
    """Text content in a message"""

    text: str


class ImageContent(TypedDict, total=False):
    """Image content in a message - supports URL, base64 data, or file ID"""

    url: Optional[str]  # Direct URL to image
    data: Optional[str]  # Base64 encoded image data (data:image/jpeg;base64,...)


class FileContent(TypedDict, total=False):
    """File content reference in a message"""

    fileId: str  # ID of file uploaded to Freddy


MessageContent = Union[str, TextContent, ImageContent]


class Message(TypedDict, total=False):
    """Message structure"""

    role: Literal["user", "assistant", "system"]
    content: Union[str, List[MessageContent]]
    texts: Optional[List[TextContent]]
    images: Optional[List[ImageContent]]
    files: Optional[List[FileContent]]


# Image types
ImageSize = Literal["256x256", "512x512", "1024x1024", "1024x1792", "1792x1024"]
ImageFormat = Literal["url", "b64_json"]


# File purposes
FilePurpose = Literal["vector_store", "user_upload", "assistant"]


# Vector store access modes
AccessMode = Literal["public", "organization", "department", "private"]

