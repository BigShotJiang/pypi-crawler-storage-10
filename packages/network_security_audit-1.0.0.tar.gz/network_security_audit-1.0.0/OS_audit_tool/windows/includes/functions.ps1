# Windows Security Functions
# Encoding: UTF-8

# 화면에 출력한 내용 그대로 log 파일로 저장
function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] $Message"
    Write-Host $output
    Add-Content -Path $script:LOGFILE -Value $output
}

# 표준 에러로 출력 후 log 파일에 저장
function Write-ErrorLog {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [ERROR] $Message"
    Write-Host $output -ForegroundColor Red
    Add-Content -Path $script:LOGFILE -Value $output
}

# 백업 파일 생성 EX: C:\file.inf -> C:\file.inf.bak.20250829-000000
function Backup-File {
    param([string]$SourcePath)

    if (Test-Path $SourcePath) {
        $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $backupPath = "$SourcePath.bak.$timestamp"
        Copy-Item -Path $SourcePath -Destination $backupPath -Force
        Write-Log "[BACKUP] $SourcePath -> $backupPath"
        return $backupPath
    } else {
        Write-Log "[BACKUP] $SourcePath no backup (file not found)"
        return $null
    }
}

# W-30: 원격 시스템에서 강제로 시스템 종료 권한 제한 (SeRemoteShutdownPrivilege)
function Invoke-W30 {
    $TS = Get-Date -Format "yyyy-MM-ddTHH:mm:sszzz"
    $DIR = Split-Path -Parent $PSScriptRoot
    $script:LOGFILE = Join-Path $DIR "logs\W-30.log"
    $JSON = Join-Path $DIR "reports\W-30.json"

    # 로그 및 리포트 디렉터리 생성
    $logsDir = Join-Path $DIR "logs"
    $reportsDir = Join-Path $DIR "reports"
    if (-not (Test-Path $logsDir)) { New-Item -ItemType Directory -Path $logsDir -Force | Out-Null }
    if (-not (Test-Path $reportsDir)) { New-Item -ItemType Directory -Path $reportsDir -Force | Out-Null }

    # 임시 파일 경로
    $tempSecPol = Join-Path $env:TEMP "secpol_export.inf"
    $tempSecPolClean = Join-Path $env:TEMP "secpol_clean.inf"
    $tempSecDb = Join-Path $env:TEMP "secedit.sdb"

    # 상태 플래그
    $DETECT_STATUS = "FAIL"
    $REMEDIATE_STATUS = "FAIL"
    $REMOTE_SHUTDOWN_USERS = @()
    $BF_REMOTE_SHUTDOWN_USERS = @()
    $AUTHORIZED_ONLY = "no"
    $BF_AUTHORIZED_ONLY = "no"

    Write-Log "============= [W-30] Remote Shutdown Privilege Assessment ============="
    Write-Log "[INFO] Checking SeRemoteShutdownPrivilege policy"

    try {
        # Step 1: 현재 보안 정책 내보내기
        Write-Log "[INFO] Exporting current security policy..."
        $exportResult = secedit /export /cfg $tempSecPol /quiet

        if ($LASTEXITCODE -ne 0) {
            Write-ErrorLog "Failed to export security policy"
            throw "secedit export failed"
        }

        # Step 2: SeRemoteShutdownPrivilege 설정 확인
        Write-Log "[INFO] Parsing security policy for SeRemoteShutdownPrivilege..."

        $policyContent = Get-Content $tempSecPol -Encoding Unicode
        $remoteShutdownLine = $policyContent | Where-Object { $_ -match '^\s*SeRemoteShutdownPrivilege\s*=\s*(.*)$' }

        if ($remoteShutdownLine) {
            $privilegeValue = $Matches[1].Trim()
            Write-Log "[INFO] Current SeRemoteShutdownPrivilege = $privilegeValue"

            # SID 또는 계정명을 배열로 분리
            if ($privilegeValue -ne "" -and $privilegeValue -ne "*S-1-5-32-544") {
                $REMOTE_SHUTDOWN_USERS = $privilegeValue -split ',' | ForEach-Object { $_.Trim() }
            } elseif ($privilegeValue -eq "*S-1-5-32-544") {
                $REMOTE_SHUTDOWN_USERS = @("*S-1-5-32-544")
            } else {
                $REMOTE_SHUTDOWN_USERS = @()
            }

            $BF_REMOTE_SHUTDOWN_USERS = $REMOTE_SHUTDOWN_USERS

            # Administrator 외 다른 계정이 있는지 확인
            $nonAdminUsers = $REMOTE_SHUTDOWN_USERS | Where-Object {
                $_ -ne "*S-1-5-32-544" -and $_ -ne ""
            }

            if ($nonAdminUsers.Count -eq 0 -and $REMOTE_SHUTDOWN_USERS -contains "*S-1-5-32-544") {
                $AUTHORIZED_ONLY = "yes"
                $DETECT_STATUS = "PASS"
            } elseif ($REMOTE_SHUTDOWN_USERS.Count -eq 0) {
                $AUTHORIZED_ONLY = "no"
                $DETECT_STATUS = "FAIL"
            } else {
                $AUTHORIZED_ONLY = "no"
                $DETECT_STATUS = "FAIL"
            }

            $BF_AUTHORIZED_ONLY = $AUTHORIZED_ONLY
        } else {
            Write-Log "[INFO] SeRemoteShutdownPrivilege not found in policy (using default)"
            $DETECT_STATUS = "PASS"
            $AUTHORIZED_ONLY = "yes"
            $BF_AUTHORIZED_ONLY = "yes"
        }

        Write-Log "------------- Detect Result -------------"
        Write-Log "[RESULT] SeRemoteShutdownPrivilege users: $($REMOTE_SHUTDOWN_USERS -join ', ')"
        Write-Log "[RESULT] Authorized only (Administrators): $AUTHORIZED_ONLY"
        Write-Log "[RESULT] Detection status: $DETECT_STATUS"
        Write-Log "------------------------------------"

        # Step 3: 조치 (Administrators 그룹만 남기고 제거)
        if ($DETECT_STATUS -eq "FAIL") {
            Write-Log "[INFO] Remediating: Setting SeRemoteShutdownPrivilege to Administrators only..."

            Backup-File -SourcePath $tempSecPol

            # 새로운 보안 정책 파일 생성
            $newPolicyContent = $policyContent | ForEach-Object {
                if ($_ -match '^\s*SeRemoteShutdownPrivilege\s*=') {
                    "SeRemoteShutdownPrivilege = *S-1-5-32-544"
                } else {
                    $_
                }
            }

            # 정책 파일에 SeRemoteShutdownPrivilege가 없으면 추가
            if (-not ($policyContent | Where-Object { $_ -match '^\s*SeRemoteShutdownPrivilege\s*=' })) {
                Write-Log "[INFO] SeRemoteShutdownPrivilege not found, adding to policy..."
                $privilegeRightsSection = $false
                $newPolicyContent = $policyContent | ForEach-Object {
                    if ($_ -match '^\s*\[Privilege Rights\]') {
                        $privilegeRightsSection = $true
                        $_
                        "SeRemoteShutdownPrivilege = *S-1-5-32-544"
                    } else {
                        $_
                    }
                }

                # [Privilege Rights] 섹션이 없으면 생성
                if (-not $privilegeRightsSection) {
                    $newPolicyContent += "`r`n[Privilege Rights]`r`nSeRemoteShutdownPrivilege = *S-1-5-32-544"
                }
            }

            # UTF-16 LE 인코딩으로 저장
            $newPolicyContent | Out-File -FilePath $tempSecPolClean -Encoding Unicode -Force

            # 정책 적용
            Write-Log "[INFO] Applying new security policy..."
            $importResult = secedit /configure /db $tempSecDb /cfg $tempSecPolClean /quiet

            if ($LASTEXITCODE -ne 0) {
                Write-ErrorLog "Failed to apply security policy"
                $REMEDIATE_STATUS = "FAIL"
            } else {
                Write-Log "[SUCCESS] Security policy applied successfully"

                # gpupdate로 정책 갱신
                Write-Log "[INFO] Refreshing group policy..."
                gpupdate /force /target:computer | Out-Null

                # Step 4: 재확인
                Start-Sleep -Seconds 2
                $verifyResult = secedit /export /cfg $tempSecPol /quiet
                $verifyContent = Get-Content $tempSecPol -Encoding Unicode
                $verifyLine = $verifyContent | Where-Object { $_ -match '^\s*SeRemoteShutdownPrivilege\s*=\s*(.*)$' }

                if ($verifyLine) {
                    $verifyValue = $Matches[1].Trim()
                    $REMOTE_SHUTDOWN_USERS = @($verifyValue)

                    if ($verifyValue -eq "*S-1-5-32-544") {
                        $AUTHORIZED_ONLY = "yes"
                        $REMEDIATE_STATUS = "PASS"
                        Write-Log "[SUCCESS] Verification passed: Only Administrators have remote shutdown privilege"
                    } else {
                        $AUTHORIZED_ONLY = "no"
                        $REMEDIATE_STATUS = "FAIL"
                        Write-ErrorLog "Verification failed: Policy not applied correctly"
                    }
                } else {
                    Write-ErrorLog "Verification failed: Cannot read policy after remediation"
                    $REMEDIATE_STATUS = "FAIL"
                }
            }
        } else {
            Write-Log "[RESULT] Already compliant: Only Administrators have remote shutdown privilege"
            $REMEDIATE_STATUS = "PASS"
        }

    } catch {
        Write-ErrorLog "Exception occurred: $_"
        $DETECT_STATUS = "FAIL"
        $REMEDIATE_STATUS = "FAIL"
    } finally {
        # 임시 파일 정리
        if (Test-Path $tempSecPol) { Remove-Item $tempSecPol -Force -ErrorAction SilentlyContinue }
        if (Test-Path $tempSecPolClean) { Remove-Item $tempSecPolClean -Force -ErrorAction SilentlyContinue }
        if (Test-Path $tempSecDb) { Remove-Item $tempSecDb -Force -ErrorAction SilentlyContinue }
    }

    # Step 5: JSON 리포트 생성
    $jsonContent = @{
        date = $TS
        control_family = "1. Account Management > 1.15 User Rights Assignment"
        check_target = "Restrict remote shutdown privilege to Administrators only"
        discussion = "Good: When only Administrators group has the SeRemoteShutdownPrivilege, preventing unauthorized remote system shutdown.`nVulnerable: When unauthorized users or groups have remote shutdown privilege, they may disrupt system availability or cause denial of service."
        check_content = "Confirm that only Administrators group has 'Force shutdown from a remote system' privilege in Local Security Policy`n1. Run > secpol.msc`n2. Security Settings > Local Policies > User Rights Assignment`n3. Check 'Force shutdown from a remote system' policy`n4. Verify only Administrators group is listed"
        fix_text = "[Windows Server 2012/2016/2019]`nStep 1) Run > secpol.msc`nStep 2) Navigate to Security Settings > Local Policies > User Rights Assignment`nStep 3) Open 'Force shutdown from a remote system' policy`nStep 4) Remove all accounts and groups except Administrators`nStep 5) Apply and run 'gpupdate /force'"
        payload = @{
            severity = "medium"
            port = @(135, 445, 3389)
            service = @("RPC", "SMB", "RDP")
            protocol = "TCP"
            threat = @("Denial of Service", "Unauthorized System Shutdown", "Service Disruption")
            TTP = @("T1489", "T1529")
            policy_checked = @("SeRemoteShutdownPrivilege")
        }
        results = @(
            @{
                phase = "detect"
                status = $DETECT_STATUS
                authorized_only = $BF_AUTHORIZED_ONLY
                users_with_privilege = $BF_REMOTE_SHUTDOWN_USERS
            },
            @{
                phase = "remediate"
                status = $REMEDIATE_STATUS
                authorized_only = $AUTHORIZED_ONLY
                users_with_privilege = $REMOTE_SHUTDOWN_USERS
            }
        )
    }

    $jsonContent | ConvertTo-Json -Depth 10 | Out-File -FilePath $JSON -Encoding UTF8 -Force
    Write-Log "[INFO] Report saved to $JSON"
    Write-Log "============= [W-30] Assessment Complete ============="
}
