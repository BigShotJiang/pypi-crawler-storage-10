from .DecoStar import patch_starlette_app

__version__ = "1.1"

patch_starlette_app()