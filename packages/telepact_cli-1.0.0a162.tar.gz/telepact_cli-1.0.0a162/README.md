# Telepact CLI

The CLI is a tool for various development jobs, such as fetching API schemas,
generating code, and starting up mock servers for testing purposes.

## Installation

```
pipx install telepact-cli
```

## Usage

```
telepact --help
```

