"""Some queuing theory results"""
