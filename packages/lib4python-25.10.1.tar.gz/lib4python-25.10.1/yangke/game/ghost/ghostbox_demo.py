# 导入幽灵键鼠python库
import ghostbox as gb
import time

print(gb.opendevice(0))
# 根据设备ID打开设备
# print(gb.opendevicebyid(1, 1))
# 判断当前是否已打开设备
# print(gb.isconnected())
# 关闭当前打开的设备
# print(gb.closedevice())

# 获取当前连接设备的型号
# print(gb.getmodel())
# 获取当前连接设备的序列号
print(gb.getserialnumber())
# 获取当前连接设备的生产日期
# print(gb.getproductiondate())
# 获取当前连接设备的固件版本号
# print(gb.getfirmwareversion())

gb.presskeybyname("Enter")
gb.releasekeybyname("Enter")

# print(gb.setclientscreenresolution(1920, 1080))
# time.sleep(5)
# 移动鼠标到指定坐标
# gb.releaseallmousebutton()
gb.setmouseposition(int(1920 / 2), int(1080 / 2))
# print(gb.movemouseto(1200, 1000))
# print(gb.movemouseto(-192, -108))
# time.sleep(1)
# print(gb.movemouseto(-192, -108))
# time.sleep(1)

print(gb.movemouseto(192, 108))
print(gb.movemouseto(192, 108))
print(gb.movemouseto(192, 108))
print(gb.movemouseto(192, 108))
print(gb.movemouseto(192, 108))
# print(gb.movemouseto(192, 108))
# time.sleep(1)
# print(gb.movemouseto(192, 108))
# time.sleep(1)
# print(gb.movemouseto(192, 108))
# time.sleep(1)
# print(gb.movemouseto(192, 108))
# time.sleep(1)

# gb.movemouserelative(-100,-100)
# print(gb.movemouseto(500, 200))
