class SystemLib:
    def __init__(self):
        ...


class MathLib:
    def __init__(self):
        ...


class PointLib:
    def __init__(self):
        ...

    def GetFloatPoint(self, kks) -> float | None:
        return None


class ExecutionLib:
    def __init__(self):
        ...


class MemoryLib:
    def __init__(self):
        ...
