"""
Create a planning scene.

COMPAS FAB v1.1.2
"""

from compas_ghpython import create_id
from ghpythonlib.componentbase import executingcomponent as component
from scriptcontext import sticky as st

from compas_fab.robots import PlanningScene


class PlanningSceneComponent(component):
    def RunScript(self, robot):
        key = create_id(self, "planning_scene")
        if robot:
            st[key] = PlanningScene(robot)
        return st.get(key, None)
