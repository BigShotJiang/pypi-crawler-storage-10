# Gestionnaire de paquets

Cette librairie contient la présentation sur les gestionnaires de paquets.

## Installation de Baudream

### Pre-requisites
Python 3.9+

### Run
Pour lancer la présentation, exécutez les commandes suivantes dans votre terminal:
```bash
mkdir presentation && cd presentation && python3 -m venv venv && source venv/bin/activate
pip install baudream
baudream
