from setuptools import setup, find_packages

VERSION = '0.0.0.2'
DESCRIPTION = 'A Python tool for traffic surrogate safety analysis'
LONG_DESCRIPTION = ''

setup(
    name="tssa",
    version=VERSION,
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    author="Zhenyu Wang",
    author_email="wonstran@hotmail.com",
    license='MIT',
    packages=find_packages(include=("*.yaml")),
    keywords=('traffic', 'vehicle', 'trajectory', 'surrogate', 'safety'),
    url = 'https://its.cutr.usf.edu/dnt/',
    classifiers= [
        "Development Status :: 3 - Alpha",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    install_requires = [
        'cython',
        'cython_bbox',
        'easydict',
        'geopandas',
        'matplotlib',
        'numpy',
        'numpy_indexed',
        'pandas',
        'pyyaml',
        'scipy',
        'shapely',
        'tabulate',
        'tqdm'
    ],
    python_requires='>=3.9',
    include_package_data=True,
)