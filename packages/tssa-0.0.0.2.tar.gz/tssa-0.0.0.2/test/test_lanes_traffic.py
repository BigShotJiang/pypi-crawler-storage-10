import os
import sys
import numpy as np
from shapely.geometry import Polygon, LineString
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from tssa.core.lane import LaneDetector
from dnt.label.labeler2 import Labeler
from label_zone import label_track_lane

count_lines = [
    LineString(np.array([[265, 298], [671, 304]])),
    LineString(np.array([[930, 465], [1139, 570]]))
]
lanes = [
    Polygon(np.array([[393, 36], [407, 157], [407, 217], [388, 274], [355, 343],
                      [193, 628], [15, 597], [195, 390], [329, 194], [352, 39], [352, 37]])),
    Polygon(np.array([[356, 342], [388, 274], [408, 219], [407, 160], [394, 35],
                      [429, 31], [457, 94], [490, 200], [505, 239], [508, 287], [495, 425], [433, 657], [193, 628]])),
    Polygon(np.array([[523, 664], [553, 442], [554, 286], [527, 202], [527, 202],
                      [459, 91], [429, 29], [469, 30], [563, 143], [615, 207], [649, 248], [696, 389], [729, 530], [738, 663]])),
    Polygon(np.array([[1274, 393], [1255, 408], [1192, 465], [1125, 590], [1095, 711],
                      [788, 665], [863, 537], [966, 435], [1075, 366], [1195, 309]]))
]

track_file = '/mnt/d/videos/sample/tracks/traffic_track.txt'
out_file = '/mnt/d/videos/sample/lanes/traffic_track_zones.csv'

lane_detector = LaneDetector(lanes=lanes, ref_point='bc', ref_offset=(0,0))
tracks = lane_detector.detect(track_file=track_file, out_file=out_file, mask_unmatched=True)

input_video = '/mnt/d/videos/sample/traffic.mp4'
out_video = '/mnt/d/videos/sample/labels/traffic_zones.mp4'
colors = [[255, 0, 0], [0, 255, 0], [130, 0, 75], [0, 127, 255], [128, 0, 128]]
label_track_lane(input_video, out_file, lanes, colors, out_video)

print('ok')