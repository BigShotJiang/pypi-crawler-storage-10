import os
import sys
import pandas as pd
import numpy as np
from tqdm import tqdm
from shapely.geometry import LineString, Polygon
import cv2
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from tssa.core.count import Count
from tssa.io.definition import track_fields
from label_zone import draw

input_video = '/mnt/d/videos/sample/traffic.mp4'
track_file = '/mnt/d/videos/sample/tracks/traffic_track.txt'
lane_track_file ='/mnt/d/videos/sample/lanes/traffic_track_zones.csv'
count_file = '/mnt/d/videos/sample/count/traffic_count.csv'
output_video = '/mnt/d/videos/sample/labels/traffic_zones_count.mp4'

count_line = LineString(np.array([[265, 298], [671, 304], [930, 465], [1139, 570]]))
lanes = [
    Polygon(np.array([[393, 36], [407, 157], [407, 217], [388, 274], [355, 343],
                      [193, 628], [15, 597], [195, 390], [329, 194], [352, 39], [352, 37]])),
    Polygon(np.array([[356, 342], [388, 274], [408, 219], [407, 160], [394, 35],
                      [429, 31], [457, 94], [490, 200], [505, 239], [508, 287], [495, 425], [433, 657], [193, 628]])),
    Polygon(np.array([[523, 664], [553, 442], [554, 286], [527, 202], [527, 202],
                      [459, 91], [429, 29], [469, 30], [563, 143], [615, 207], [649, 248], [696, 389], [729, 530], [738, 663]])),
    Polygon(np.array([[1274, 393], [1255, 408], [1192, 465], [1125, 590], [1095, 711],
                      [788, 665], [863, 537], [966, 435], [1075, 366], [1195, 309]]))
]

counter = Count(line=count_line)
veh_count = counter.count_tracks_by_line(track_file=track_file, with_header=False)

lane_tracks = pd.read_csv(lane_track_file)
count_track_ids = veh_count['track_id'].unique()
lane_track_ids = lane_tracks['track_id'].unique()
final_ids = [int(id) for id in count_track_ids if id in lane_track_ids]

results = []
for id in final_ids:
    cnt_frame = veh_count.loc[veh_count['track_id']==id]['frame'].values[0]
    cnt = veh_count.loc[veh_count['track_id']==id]['count'].values[0]
    direction = veh_count.loc[veh_count['track_id']==id]['direction'].values[0]
    selected_lane_tracks = lane_tracks.loc[lane_tracks['track_id']==id].copy()
    selected_lane_tracks['diff'] = selected_lane_tracks['frame'].apply(lambda x: abs(x-cnt_frame))
    selected_lane_tracks.sort_values(by='diff', inplace=True)
    lane = selected_lane_tracks.iloc[0]['lane']
    lane_frame = selected_lane_tracks.iloc[0]['frame']
    ref_x = selected_lane_tracks.iloc[0]['ref_x'] 
    ref_y = selected_lane_tracks.iloc[0]['ref_y']
    results.append([id, cnt_frame, cnt, direction, lane, lane_frame, ref_x, ref_y])
df = pd.DataFrame(results, columns=['track_id', 'frame', 'count', 'direction', 'lane', 'lane_frame', 'ref_x', 'ref_y'])
df.to_csv(count_file, index=False)
veh_count = pd.read_csv(count_file)

tracks = pd.read_csv('/mnt/d/videos/sample/tracks/traffic_track.txt', header=None)
tracks.columns = track_fields
tracks = tracks.loc[tracks['track_id'].isin(count_track_ids)].copy()

colors = [[255, 0, 0],
          [0, 255, 0],
          [128, 0, 128],
          [0, 127, 255],
          [255, 255, 0]
        ]
points = [(217, 453),
          (396, 462),
          (627, 472),
          (1031, 514)]

cap = cv2.VideoCapture(input_video)
if not cap.isOpened():
    raise IOError("Couldn't open webcam or video")
tot_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
cap.release()

pbar = tqdm(total=tot_frames, unit=" frames", desc="Generating labels ...")
results = []
cnt = 0
cnts = [0, 0, 0, 0, 0]
for i in range(tot_frames):
    tracks_at_frame_i = lane_tracks.loc[lane_tracks['frame']==i]
    if len(tracks_at_frame_i) > 0:
        for index, track in tracks_at_frame_i.iterrows():
            final_color = colors[int(track['lane'])]
            label_str = '#'+str(int(track['track_id']))
            results.append([track['frame'],
                        'bbox',
                        [(track['x'], track['y']),
                         (track['x'] + track['w'], 
                          track['y'] + track['h'])],
                        final_color, 
                        0.5,
                        1,
                        1.0,
                        label_str])
            results.append([track['frame'],
                        'circle',
                        [(track['ref_x'], track['ref_y'])],
                        [0, 0, 255], 
                        3,
                        -1,
                        1.0,
                        ""])
    for j in range(len(lanes)):
        lane = lanes[j]
        results.append([i, 
                        'text',
                        [(points[j][0], points[j][1])], 
                        colors[j],
                        1,
                        2,
                        1,
                        "L"+str(j+1)])
        results.append([i, 
                        'polygon',
                        np.array(list(lane.exterior.coords), np.int32).reshape((-1, 1, 2)),
                        [0, 0, 0],
                        1,
                        1,
                        1,
                        ""])
        results.append([i, 
                        'filled_polygon',
                        np.array(list(lane.exterior.coords), np.int32).reshape((-1, 1, 2)),
                        [218, 177, 218],
                        1,
                        1,
                        0.2, 
                        ""])
    veh_count_at_frame_i = veh_count.loc[veh_count['frame']==i]
    if len(veh_count_at_frame_i) > 0:
        cnt = veh_count_at_frame_i.iloc[-1]['count']
        for index, t in veh_count_at_frame_i.iterrows():
            if t['lane'] == 0:
                cnts[0] = cnts[0] + 1
            elif t['lane'] == 1:
                cnts[1] = cnts[1] + 1
            elif t['lane'] == 2:
                cnts[2] = cnts[2] + 1
            elif t['lane'] == 3:
                cnts[3] = cnts[3] + 1
            elif t['lane'] == 4:
                cnts[4] = cnts[4] + 1
 
    results.append([i,
                    'text',
                    [(640, 100)],
                    [0, 0, 0],
                    1.3,
                    2,
                    1,
                    "Total:"+str(int(cnt))])
    '''results.append([i,
                    'polylines',
                    np.array(list(count_line.coords), np.int32),
                    [0, 0, 255],
                    1,
                    1,
                    1,
                    ""])'''
    for j in range(len(lanes)):
        lane = lanes[j]
        results.append([i, 
                        'text',
                        [(points[j][0], points[j][1] + 50)], 
                        [0, 0, 0],
                        1,
                        2,
                        1,
                        str(cnts[j])])      
    pbar.update()
pbar.close()

df = pd.DataFrame(results, columns=['frame','type','coords','color','size','thick','alpha','desc'])
df.sort_values(by='frame', inplace=True)
df.to_csv(output_video.replace('.mp4', '.csv'), index=False)

draw(input_video = input_video,
         output_video = output_video,
         draws = df)
