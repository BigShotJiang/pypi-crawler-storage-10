import cv2
import numpy as np

# Create a blank black image
image = np.zeros((500, 500, 3), dtype="uint8")

# Define the start and end coordinates
start_point = (50, 50)
end_point = (450, 450)

# Color for the halo line (e.g., white)
halo_color = (255, 255, 255)
# Color for the main line (e.g., red)
line_color = (0, 0, 255)

# Thickness of the halo line
halo_thickness = 10
# Thickness of the main line
line_thickness = 8

# Draw the halo line
cv2.line(image, start_point, end_point, halo_color, halo_thickness)
# Draw the main line
cv2.line(image, start_point, end_point, line_color, line_thickness)

# Display the image
cv2.imshow("Halo Line Effect", image)
cv2.waitKey(0)
cv2.destroyAllWindows()