import sys, os
sys.path.append(os.path.dirname(__file__))

__version__='0.0.0.2'