import os
import sys

# Add the path to the tssa/engine directory to the system path
sys.path.append(os.path.dirname(os.path.realpath(__file__)))

# Import the modules
from view_transform import ViewTransform