# -*- coding: utf-8 -*-
# Copyright 2021 Cardiff University

"""Test suite for `pyRing.waveform`
"""

import pytest

from .. import waveform


class TestTEOBPM:
    WAVEFORM = waveform.TEOBPM

    # Try and catch to accommodate python 3.9 and lower:
    # pytest.fixture should be first [ https://github.com/pytest-dev/pytest/issues/13479#issuecomment-2959890896 ].
    # This is required for python 3.13 and pytest 8.4, while for python 3.9 the order of decorators has to be reversed.
    try:
        @pytest.fixture
        @classmethod
        def smwaveform(cls):
            return cls.WAVEFORM(
                0.,             # t0
                10.,            # m1
                10.,            # m2
                0.,             # chi1
                0.,             # chi2
                {},             # phases
                1000,           # distance
                0.,             # iota
                0.,             # phi
                [(2,2), (3,3)], # modes
                {},             # TGR params
            )
    except AttributeError:
        @classmethod
        @pytest.fixture
        def smwaveform(cls):
            return cls.WAVEFORM(
                0.,             # t0
                10.,            # m1
                10.,            # m2
                0.,             # chi1
                0.,             # chi2
                {},             # phases
                1000,           # distance
                0.,             # iota
                0.,             # phi
                [(2,2), (3,3)], # modes
                {},             # TGR params
            )


    @pytest.mark.parametrize(("l", "m", "a1"), (
        (2, 2, pytest.approx(1.7666767219721071)),
    ))
    def test_EOBPM_SetupFitCoefficients(self, smwaveform, l, m, a1):
        coeffs = smwaveform.EOBPM_SetupFitCoefficients(l, m, None) # NR fit coefficients, not used in inference
        assert coeffs["a1"] == a1
