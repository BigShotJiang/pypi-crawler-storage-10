References
================

.. [IFS-CY47R3-PhysicalProcesses]

IFS Documentation CY47R3 - Part IV Physical processes, (2021). URL: https://www.ecmwf.int/en/elibrary/20198-ifs-documentation-cy47r3-part-iv-physical-processes



.. [ECEF]

Earth-centred, Earth-fixed coordinate system. URL: https://en.wikipedia.org/wiki/Earth-centered,_Earth-fixed_coordinate_system


.. [From_ECEF_to_geodetic_coordinates]

URL: https://en.wikipedia.org/wiki/Geographic_coordinate_conversion#From_ECEF_to_geodetic_coordinates


.. [From_geodetic_to_ECEF_coordinates]

URL: https://en.wikipedia.org/wiki/Geographic_coordinate_conversion#From_geodetic_to_ECEF_coordinates
