Version 0.1 Updates
/////////////////////////

Version 0.1.0
===============

New features
++++++++++++++++

- implemented figures: :py:attr:`earthkit.geo.figure.IFS_SPHERE` and :py:attr:`earthkit.geo.figure.UNIT_SPHERE`
- allowed specifying the figure for public methods
- optimised nearest methods by using UNIT_SPHERE internally
