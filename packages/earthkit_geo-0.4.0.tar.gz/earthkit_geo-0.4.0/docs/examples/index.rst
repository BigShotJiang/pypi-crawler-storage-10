.. _examples:

Examples
============

Here is a list of example notebooks to illustrate how to use earthkit-geo.

.. toctree::
    :maxdepth: 1

    rotate.ipynb
    country_polygons.ipynb
