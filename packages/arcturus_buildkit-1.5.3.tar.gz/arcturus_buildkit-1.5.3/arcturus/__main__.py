import argparse
import random
from .arcturus_buildkit import arcturusNLP, arcturusSUPERVISED_INTENT, arcturusSEARCH_ENGINE

# -------------------------
# Build Supervised Intent Bot
# -------------------------
def build_bot():
    nlp = arcturusNLP()

    training_data = [
        ("hi", "greeting"),
        ("hello", "greeting"),
        ("hey", "greeting"),
        ("how are you", "greeting"),
        ("bye", "goodbye"),
        ("see you later", "goodbye"),
        ("tell me a joke", "joke"),
        ("make me laugh", "joke"),
        ("thanks", "thanks"),
        ("thank you", "thanks"),
        ("what's your name", "identity")
    ]

    intent_responses = {
        "greeting": ["Hello!", "Hey there!", "Hi! How can I help you?"],
        "goodbye": ["Goodbye!", "See you later!", "Bye!"],
        "joke": ["Why do programmers prefer dark mode? Because light attracts bugs!"],
        "thanks": ["You're welcome!", "No problem!", "Anytime!"],
        "identity": ["I'm Arcturus, your AI assistant."]
    }

    bot = arcturusSUPERVISED_INTENT(nlp, intent_responses)
    bot.train(training_data)
    return bot

# -------------------------
# Build Search Engine
# -------------------------
def build_search_engine():
    nlp = arcturusNLP()
    search_data = {
        "what is python": "Python is a high-level programming language used for many applications.",
        "who created python": "Python was created by Guido van Rossum in 1991.",
        "what is ai": "AI stands for Artificial Intelligence — machines that can think and learn.",
        "what is abu dhabi university": "Abu Dhabi University is a leading private university in the UAE known for STEM and innovation.",
        "what is arcturus": "Arcturus is a custom AI/NLP framework built for intent recognition and smart search."
    }
    return arcturusSEARCH_ENGINE(nlp, search_data)

# -------------------------
# CLI Entry Point
# -------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Arcturus NLP CLI — combines intent recognition and smart search"
    )

    parser.add_argument("-s", "--sentence", type=str, help="Send a single sentence and get a response")
    parser.add_argument("-i", "--interactive", action="store_true", help="Run interactive chat mode")
    parser.add_argument("--search", action="store_true", help="Force search engine mode")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show debug info")

    args = parser.parse_args()

    nlp = arcturusNLP()
    bot = build_bot()
    search_engine = build_search_engine()

    def respond(sentence):
        if args.search:
            # Explicitly use search engine
            result = search_engine.search_response(sentence, show_scores=args.verbose)
            return result or "No relevant results found."
        else:
            # Try supervised bot first
            intent = bot.predict_intent(sentence)
            if intent == "unknown":
                result = search_engine.search_response(sentence, show_scores=args.verbose)
                return result or "I don't understand."
            else:
                return bot.get_response(sentence)

    # Single-sentence mode
    if args.sentence:
        print("→", respond(args.sentence))

    # Interactive chat
    elif args.interactive:
        print("🤖 Arcturus CLI v1.0 | Type 'exit' to quit.")
        while True:
            user_input = input("You: ").strip()
            if user_input.lower() in ["exit", "quit"]:
                print("Bot: Goodbye!")
                break
            response = respond(user_input)
            print("Bot:", response)

    else:
        print("No input provided. Use --sentence <text> or --interactive")
        parser.print_help()


if __name__ == "__main__":
    main()
