LEMMATIZER = {
    "walk": ["walker", "walking", "walks", "walked"],
    "sit": ["sit", "sat", "sitting"],
    "use": ["use", "uses", "using", "used"],
    "pakistan": ["pakistani"]
}

FORMS_WORDS = {
    "VERB": [["walk", "walking", "walked", "walks"], ["sit", "sat", "sitting"], ["use", "uses", "using", "used"]],
    "NOUN": [["walk", "walks"], ["dollar", "dollars"]]
}
SYNONYM = {
    "fast": ["speedy", "quick"]
}

SYNONYM_NGRAM = {
    ("the", "car"): [("the", "vehicle")],
}
