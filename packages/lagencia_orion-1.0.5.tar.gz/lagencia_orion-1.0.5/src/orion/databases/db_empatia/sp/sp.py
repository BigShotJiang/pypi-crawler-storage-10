from typing import Literal

from sqlalchemy import text

from orion.databases.config_db_empatia import get_session_empatia


def create_sp(tablename: Literal["municipios", "veredas", "corregimientos", "comunas", "barrios", "lugares"]):
    # PASO 1: Eliminar procedimiento si existe
    drop_sql = "DROP PROCEDURE IF EXISTS sp_update_{tablename}_shows_in_sectors_table".format(tablename=tablename)

    # PASO 2: Crear procedimiento
    create_procedure_sql = """CREATE PROCEDURE sp_update_{tablename}_shows_in_sectors_table()
    BEGIN
        START TRANSACTION;

        UPDATE sectors s
        JOIN (
            SELECT
                s.id AS sector_id,
                MAX(p.show_villacruz) AS show_villacruz,
                MAX(p.show_rent_villacruz) AS show_rent_villacruz,
                MAX(p.show_sale_villacruz) AS show_sale_villacruz,
                MAX(p.show_furnished_villacruz) AS show_furnished_villacruz,
                MAX(p.show_castillo) AS show_castillo,
                MAX(p.show_rent_castillo) AS show_rent_castillo,
                MAX(p.show_sale_castillo) AS show_sale_castillo,
                MAX(p.show_furnished_castillo) AS show_furnished_castillo,
                MAX(p.show_estrella) AS show_estrella,
                MAX(p.show_rent_estrella) AS show_rent_estrella,
                MAX(p.show_sale_estrella) AS show_sale_estrella,
                MAX(p.show_furnished_estrella) AS show_furnished_estrella,
                MAX(p.show_livin) AS show_livin,
                MAX(p.show_rent_livin) AS show_rent_livin,
                MAX(p.show_sale_livin) AS show_sale_livin,
                MAX(p.show_furnished_livin) AS show_furnished_livin
            FROM properties p
            JOIN {tablename} s ON ST_Contains(s.geometry, p.geometry)
            WHERE s.active = 1
            GROUP BY s.id
            LIMIT 1000
        ) AS subquery ON s.id = subquery.sector_id
        SET
            s.show_villacruz = subquery.show_villacruz,
            s.show_rent_villacruz = subquery.show_rent_villacruz,
            s.show_sale_villacruz = subquery.show_sale_villacruz,
            s.show_furnished_villacruz = subquery.show_furnished_villacruz,
            s.show_castillo = subquery.show_castillo,
            s.show_rent_castillo = subquery.show_rent_castillo,
            s.show_sale_castillo = subquery.show_sale_castillo,
            s.show_furnished_castillo = subquery.show_furnished_castillo,
            s.show_estrella = subquery.show_estrella,
            s.show_rent_estrella = subquery.show_rent_estrella,
            s.show_sale_estrella = subquery.show_sale_estrella,
            s.show_furnished_estrella = subquery.show_furnished_estrella,
            s.show_livin = subquery.show_livin,
            s.show_rent_livin = subquery.show_rent_livin,
            s.show_sale_livin = subquery.show_sale_livin,
            s.show_furnished_livin = subquery.show_furnished_livin;

        COMMIT;
    END""".format(tablename=tablename)

    # Ejecutar por separado
    with get_session_empatia() as session:
        try:
            # Eliminar procedimiento
            session.execute(text(drop_sql))
            session.commit()

            # Crear procedimiento
            session.execute(text(create_procedure_sql))
            session.commit()

            print("Procedimiento almacenado creado exitosamente")

        except Exception as e:
            session.rollback()
            print(f"Error creando procedimiento: {e}")
            raise


def create_trigger(tablename: Literal["municipios", "veredas", "corregimientos", "comunas", "barrios", "lugares"]) -> bool:
    """
    Crea un triger sobre una tabla fuente que actualiza los campos <name> y <geometry> de la tabla properties

    Args:
        tablename (str): Nombre de la tabla sobre la que se desea aplicar el trigger.

    Returns:
        bool: True si el trigger se creo exitosamente, False en caso contrario.
    """

    # PASO 1: Eliminar el trigger si existe
    drop_sql = "DROP TRIGGER IF EXISTS after_{tablename}_update;".format(tablename=tablename)

    # Crear el trigger
    create_trigger_sql = """
        CREATE TRIGGER after_{tablename}_update
        AFTER UPDATE ON {tablename}
        FOR EACH ROW
        BEGIN
            IF NEW.active = 0 THEN
                DELETE FROM sectors WHERE id = NEW.id;

            ELSE
                UPDATE sectors
                SET name = NEW.name,
                    geometry = NEW.geometry
                WHERE id = NEW.id;
            END IF;
        END
        """.format(tablename=tablename)

    # Ejecutar por separado
    with get_session_empatia() as session:
        try:
            # Eliminar trigger
            session.execute(text(drop_sql))
            session.commit()

            # Crear trigger
            session.execute(text(create_trigger_sql))
            session.commit()

            print("trigger creado exitosamente")
            return True

        except Exception as e:
            session.rollback()
            print(f"Error creando trigger: {e}")
            return False


def create_sp_and_trigers_from_sectors_control():
    # + Falta agregar la eliminacion en cascade
    # + Falta calcular distancia entre propiedades y lugares
    # + Falta agregar table alias
    # + Falta agregar barrios relacionados
    # ? requiero actualizar los show= 0?

    # Base.metadata.drop_all(engine)
    # Base.metadata.create_all(engine)

    # with engine.connect() as c:
    #     print("DB:", c.execute(text("SELECT DATABASE()")).scalar())
    #     print("Version:", c.execute(text("SELECT VERSION()")).scalar())

    tables = ["municipios", "veredas", "corregimientos", "comunas", "barrios", "lugares"]

    for table in tables:
        if table != "lugares":
            create_sp(tablename=table)
            # sql_call_sp= """CALL sp_update_municipio_shows_in_sectors_table();"""

        create_trigger(tablename=table)

    # for table in tables:
    #     alter_sql = """
    #     ALTER TABLE {tablename}
    #     MODIFY updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
    #     """.format(tablename=table)

    #     try:
    #         with engine.connect() as connection:
    #             connection.execute(text(alter_sql))
    #     except Exception as e:
    #         print(f"Error al ejecutar el ALTER TABLE para {table}: {e}")

    # # Crear los triggers para las tablas
    # trigger_sqls = [
    #     """
    #     DROP TRIGGER IF EXISTS after_municipios_update;
    #     CREATE TRIGGER after_municipios_update
    #     AFTER UPDATE ON municipios
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;

    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """,
    #     """
    #     DROP TRIGGER IF EXISTS after_veredas_update;
    #     CREATE TRIGGER after_veredas_update
    #     AFTER UPDATE ON veredas
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;
    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """,
    #     """
    #     DROP TRIGGER IF EXISTS after_corregimientos_update;
    #     CREATE TRIGGER after_corregimientos_update
    #     AFTER UPDATE ON corregimientos
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;
    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """,
    #     """
    #     DROP TRIGGER IF EXISTS after_comunas_update;
    #     CREATE TRIGGER after_comunas_update
    #     AFTER UPDATE ON comunas
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;
    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """,
    #     """
    #     DROP TRIGGER IF EXISTS after_barrios_update;
    #     CREATE TRIGGER after_barrios_update
    #     AFTER UPDATE ON barrios
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;
    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """,
    #     """
    #     DROP TRIGGER IF EXISTS after_lugares_update;
    #     CREATE TRIGGER after_lugares_update
    #     AFTER UPDATE ON lugares
    #     FOR EACH ROW
    #     BEGIN
    #         IF NEW.active = 0 THEN
    #             DELETE FROM sectors WHERE id = NEW.id;
    #         ELSE
    #             UPDATE sectors
    #             SET name = NEW.name,
    #                 geometry = NEW.geometry
    #             WHERE id = NEW.id;
    #         END IF;
    #     END
    #     """
    #     # Agregar otros triggers para las demás tablas aquí...
    # ]

    # # with engine.connect() as connection:
    #     for trigger_sql in trigger_sqls:
    #         connection.execute(text(trigger_sql))
