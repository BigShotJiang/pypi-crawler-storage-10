import ast

import numpy as np
import pandas as pd
from loguru import logger

from orion.acrecer.permitted_neighborhoods import BARRIOS
from orion.definition_ids import ID_BASE_MLS_ACRECER
from orion.tools import generate_slug

map_id_inmobiliaria = {
    "786": 10_000_000,
    "B": 20_000_000,
    "743": 30_000_000,
    "473": 40_000_000,
    "AC": 50_000_000,
    "AA": 60_000_000,
    np.nan: 70_000_000,
}


filds_properties_acrecer = [
    "code",
    "generalDescription",
    "rentValue",
    "propertyType",
    "builtArea",
    "numberOfRooms",
    "rooms",
    "propertyImages",
    "propertyVideoUrl",
    # "managementQuota",
    "constructionYears",
    "stratum",
    "address",
    "lat",
    "lng",
    "lastUpdate",
    "addedOn",
    "inCondominiumFeatures",
    "householdFeatures",
    "locationData",
]


map_name_fields_properties_acrecer = {
    "code": "code",
    "generalDescription": "description",
    "rentValue": "price",
    "propertyType": "property_type",
    "builtArea": "area",
    "numberOfRooms": "bedrooms",
    "rooms": "bathrooms",
    "propertyImages": "image",
    "propertyVideoUrl": "video",
    # "managementQuota": "",
    "constructionYears": "age",
    "stratum": "stratum",
    "address": "address",
    # "locationData": "neighborhood",
    "lat": "latitude",
    "lng": "longitude",
    "lastUpdate": "modified_date",
    "addedOn": "create_at",
}


def parse_elevator(x):
    """Determina si una propiedad tiene ascensor.

    Parámetros
    ----------
    x : Any
        Valor que representa las características del condominio. Puede ser
        None, una cadena con representación de dict o un dict ya parseado.

    Retorna
    -------
    bool
        True si existe el indicador de ascensor, False en caso contrario.
    """
    if pd.isna(x):
        return False
    try:
        value = ast.literal_eval(x)
        return value.get("servedByElevator") == "T"
    except Exception:
        logger.debug("parse_elevator: fallo al parsear valor: %s", x)
        return False


def parse_garage(x):
    """Determina si una propiedad tiene parqueadero.

    Maneja entradas nulas, dicts o strings con literal dict.
    """
    if pd.isna(x):
        return False
    try:
        value = ast.literal_eval(x)
        return value.get("garages") == 1
    except Exception:
        logger.debug("parse_garage: fallo al parsear valor: %s", x)
        return False


def parse_bathrooms(x):
    """Extrae el número de baños desde distintos formatos.

    Acepta:
    - NaN -> 0
    - dict -> toma la clave 'baths'
    - str -> intenta literal_eval y luego toma 'baths'
    """
    if pd.isna(x):
        return 0
    if isinstance(x, dict):  # ya es dict
        return int(x.get("baths", 0))
    if isinstance(x, str):
        try:
            val = ast.literal_eval(x)
            if isinstance(val, dict):
                return int(val.get("baths", 0))
        except Exception:
            logger.debug("parse_bathrooms: fallo al parsear valor: %s", x)
            return 0
        # Baño social
    return 0


def parse_neighborhood(x):
    """Normaliza y extrae el barrio (neighborhood) desde distintos formatos.

    Devuelve cadena vacía si no encuentra información válida.
    """
    if pd.isna(x):
        return ""

    if isinstance(x, dict):
        return x.get("neighborhood", "")

    if isinstance(x, str):
        try:
            val = ast.literal_eval(x)
            if isinstance(val, dict):
                return val.get("neighborhood", "")
        except Exception:
            logger.debug("parse_neighborhood: fallo al parsear valor: %s", x)
            return ""
    return ""


def transform_data(data: pd.DataFrame) -> pd.DataFrame:
    """Transforma el DataFrame crudo de la API a la estructura interna.

    Realiza:
    - Selección y renombrado de columnas
    - Filtrado por precio mínimo
    - Normalización de identificadores y creación de campos derivados

    No modifica la lógica original, sólo añade trazabilidad.
    """
    logger.info("transform_data: inicio transformacion, filas antes=%s", len(data))
    data = data.copy()
    #data = data[filds_properties_acrecer]
    data.rename(columns=map_name_fields_properties_acrecer, inplace=True)
    data = data[data["price"] >= 2_000_000]

    #data["idinmobiliaria"] = data["code"].apply(lambda x: str(x).split("-")[0] if "-" in str(x) else np.nan)
    data = data[data["prefix_code"] != "494"]

    #data["code"] = data["code"].apply(lambda x: str(x).split("-")[1] if "-" in str(x) else x)

    # data["id"] = data["code"].astype(int).copy()
    # data["id"] = data["id"] + ID_BASE_MLS_ACRECER
    # data["id"] = data.apply(lambda x: x["id"] + map_id_inmobiliaria.get(x["idinmobiliaria"], 0), axis=1)

    data["property_type_searcher"] = data["property_type"].copy()
    data["management"] = "Arriendo"
    data["show_livin"] = True
    data["show_rent_livin"] = True
    data["slug"] = ""
    data["price_admon"] = ""
    data["active"] = True
    data["featured"] = ""

    data["bedrooms"] = data["bedrooms"].apply(lambda x: int(x) if pd.notna(x) else 0)
    data["bathrooms"] = data["bathrooms"].apply(lambda x: parse_bathrooms(x))

    data["elevator"] = data["inCondominiumFeatures"].apply(lambda x: parse_elevator(x))
    data["garage"] = data["householdFeatures"].apply(lambda x: parse_garage(x))
    data["neighborhood"] = data["locationData"].apply(lambda x: parse_neighborhood(x))
    data = data[data["neighborhood"].isin(BARRIOS)]
    data["slug"] = data["property_type"] + "-en" + data["management"] + "-en " + data["neighborhood"] + "-" + data["code"].astype(str)
    data["slug"] = data["slug"].apply(generate_slug)
    data["image"] = data["image"].astype(str)
    #data["source"] = "mls_acrecer"

    data = data[
        [
            "id",
            "code",
            "description",
            "slug",
            "price",
            "property_type",
            "property_type_searcher",
            "management",
            "area",
            "bedrooms",
            "bathrooms",
            "garage",
            "elevator",
            "image",
            "video",
            "price_admon",
            "show_livin",
            "show_rent_livin",
            "featured",
            "age",
            # "urbanization",
            "stratum",
            "address",
            "neighborhood",
            # "keys_inmodified_date",
            "latitude",
            "longitude",
            "modified_date",
            "create_at",
            "prefix_code",
            "source",
        ]
    ]
    data.drop_duplicates(subset=["id"], inplace=True)
    logger.info("transform_data: fin transformacion, filas despues=%s", len(data))
    return data


def transform_mls_acrecer_for_properties(mls_acrecer: pd.DataFrame) -> pd.DataFrame:

    mls_acrecer = transform_data(mls_acrecer)

    mls_acrecer["show_mls_lagencia"] = False
    mls_acrecer["image"] = mls_acrecer["image"].apply(lambda x: ast.literal_eval(x)[0] if ast.literal_eval(x) else None)
    mls_acrecer.rename(columns={"idinmobiliaria": "prefix_code"}, inplace=True)
    return mls_acrecer
