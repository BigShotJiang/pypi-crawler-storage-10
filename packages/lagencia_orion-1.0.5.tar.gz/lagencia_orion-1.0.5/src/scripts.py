from datetime import datetime  # noqa: F401

from orion.acrecer.acrecer import get_all_properties_acrecer_by_city_sync
from orion.acrecer.etl_acrecer import load_data_for_table_acrecer
from orion.mls.mls import filter_mls_for_castillo, filter_mls_for_estrella, filter_mls_for_livin, filter_mls_for_villacruz, get_all_mls, get_full_data_mls  # noqa: F401

# + mls
# date = datetime.now().strftime("%Y%m%d")
# mls_full = get_full_data_mls(date=date)


# mls_villacruz = filter_mls_for_villacruz(full_data=mls_full)
# mls_estrella = filter_mls_for_estrella(full_data=mls_full)
# mls_livin = filter_mls_for_livin(full_data=mls_full)
# mls_castillo = filter_mls_for_castillo(full_data=mls_full)

# mls_full.to_excel("mls_full.xlsx", index=False)
# mls_villacruz.to_excel("mls_villacruz.xlsx", index=False)
# mls_estrella.to_excel("mls_estrella.xlsx", index=False)
# mls_livin.to_excel("mls_livin.xlsx", index=False)
# mls_castillo.to_excel("mls_castillo.xlsx", index=False)


# all_mls = get_all_mls()
# all_mls.to_excel("all_mls.xlsx", index=False)


# + Acrecer
# result = get_all_properties_acrecer_by_city_sync()
# print(result)

load_data_for_table_acrecer()
