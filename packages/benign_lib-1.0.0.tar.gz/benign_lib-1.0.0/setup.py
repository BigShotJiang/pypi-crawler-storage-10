from setuptools import setup, find_packages

setup(
  name='benign_lib',
  version='1.0.0',
  author='FixerHack',
  author_email='craftfixer@gmail.com',
  description='This is my first module',
  url='https://github.com/FixerHack',
  packages=find_packages(),
  classifiers=[
    'Programming Language :: Python :: 3.11',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='example python',
  project_urls={
    'Documentation': 'https://github.com/FixerHack'
  },
  python_requires='>=3.14'
)