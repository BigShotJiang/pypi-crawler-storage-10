"""FastAPI backend for admin panel"""

from pyhybriddb.api.server import app

__all__ = ["app"]
