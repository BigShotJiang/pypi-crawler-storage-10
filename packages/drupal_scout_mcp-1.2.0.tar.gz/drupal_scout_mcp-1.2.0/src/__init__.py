"""Drupal Scout MCP - Discover functionality in Drupal sites."""

__version__ = "0.1.0"
