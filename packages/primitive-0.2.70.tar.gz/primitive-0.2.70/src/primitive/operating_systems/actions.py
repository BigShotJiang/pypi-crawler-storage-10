from enum import Enum

from gql import gql
import requests

from primitive.operating_systems.graphql.mutations import (
    operating_system_create_mutation,
)
from primitive.operating_systems.graphql.queries import operating_system_list_query
from primitive.utils.actions import BaseAction
from primitive.utils.auth import guard

from primitive.utils.cache import get_operating_systems_cache
from pathlib import Path
from urllib.request import urlopen
import os
from loguru import logger

from primitive.utils.checksums import get_checksum_from_file, calculate_sha256


class OperatingSystems(BaseAction):
    def __init__(self, primitive):
        super().__init__(primitive)
        self.remote_operating_systems = {
            "ubuntu-24-04-3": {
                "iso": "https://releases.ubuntu.com/24.04.3/ubuntu-24.04.3-desktop-amd64.iso",
                "checksum": "https://releases.ubuntu.com/24.04.3/SHA256SUMS",
                "checksum_file_type": self.OperatingSystemChecksumFileType.SHA256SUMS,
            },
        }

    class OperatingSystemChecksumFileType(Enum):
        SHA256SUMS = "SHA256SUMS"

    def get_remote_operating_system_names(self):
        return list(self.remote_operating_systems.keys())

    def _download_remote_operating_system_iso(self, remote_operating_system_name):
        operating_system_dir = Path(
            get_operating_systems_cache() / remote_operating_system_name
        )
        iso_dir = Path(operating_system_dir / "iso")
        os.makedirs(iso_dir, exist_ok=True)

        operating_system_info = self.remote_operating_systems[
            remote_operating_system_name
        ]
        iso_remote_url = operating_system_info["iso"]
        iso_filename = iso_remote_url.split("/")[-1]
        iso_file_path = Path(iso_dir / iso_filename)

        if iso_file_path.exists() and iso_file_path.is_file():
            logger.info("Operating system iso already downloaded.")
            return iso_file_path

        logger.info(
            f"Downloading operating system '{remote_operating_system_name}' iso. This may take a few minutes..."
        )

        session = requests.Session()
        with session.get(iso_remote_url, stream=True) as response:
            response.raise_for_status()
            with open(iso_file_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        f.flush()

        logger.info(
            f"Successfully downloaded operating system iso to '{iso_file_path}'."
        )

        return iso_file_path

    def _download_remote_operating_system_checksum(self, remote_operating_system_name):
        operating_system_dir = Path(
            get_operating_systems_cache() / remote_operating_system_name
        )
        checksum_dir = Path(operating_system_dir / "checksum")
        os.makedirs(checksum_dir, exist_ok=True)

        operating_system_info = self.remote_operating_systems[
            remote_operating_system_name
        ]
        checksum_filename = operating_system_info["checksum"].split("/")[-1]

        checksum_file_path = Path(checksum_dir / checksum_filename)
        if checksum_file_path.exists() and checksum_file_path.is_file():
            logger.info("Operating system checksum already downloaded.")
            return checksum_file_path

        logger.info(
            f"Downloading operating system '{remote_operating_system_name}' checksum."
        )

        checksum_response = urlopen(operating_system_info["checksum"])
        checksum_file_content = checksum_response.read()
        with open(checksum_file_path, "wb") as f:
            f.write(checksum_file_content)

        logger.info(f"Successfully downloaded checksum to '{checksum_file_path}'.")

        return checksum_file_path

    def download_from_remote(self, remote_operating_system_name: str):
        remote_operating_system_names = self.get_remote_operating_system_names()

        if remote_operating_system_name not in remote_operating_system_names:
            logger.error(
                f"No such operating system '{remote_operating_system_name}'. Run 'primitive operating-systems list' for available operating systems."
            )
            raise ValueError(
                f"No such operating system '{remote_operating_system_name}'."
            )

        iso_file_path = self._download_remote_operating_system_iso(
            remote_operating_system_name
        )
        checksum_file_path = self._download_remote_operating_system_checksum(
            remote_operating_system_name
        )

        return iso_file_path, checksum_file_path

    def get_checksum_file_type(self, operating_system_name: str):
        return self.remote_operating_systems[operating_system_name][
            "checksum_file_type"
        ]

    def validate_checksum(
        self,
        operating_system_name: str,
        iso_file_path: str,
        checksum_file_path: str,
        checksum_file_type: OperatingSystemChecksumFileType | None = None,
    ):
        checksum_file_type = (
            checksum_file_type
            if checksum_file_type
            else self.get_checksum_file_type(operating_system_name)
        )

        match checksum_file_type:
            case self.OperatingSystemChecksumFileType.SHA256SUMS:
                return self._validate_sha256_sums_checksum(
                    iso_file_path, checksum_file_path
                )
            case _:
                logger.error(f"Invalid checksum file type: {checksum_file_type}")
                raise ValueError(f"Invalid checksum file type: {checksum_file_type}")

    def _validate_sha256_sums_checksum(self, iso_file_path, checksum_file_path):
        iso_file_name = Path(iso_file_path).name

        remote_checksum = get_checksum_from_file(checksum_file_path, iso_file_name)
        local_checksum = calculate_sha256(iso_file_path)
        return remote_checksum == local_checksum

    @guard
    def create_operating_system(
        self,
        slug: str,
        organization_id: str,
        checksum_file_id: str,
        checksum_file_type: str,
        iso_file_id: str,
    ):
        mutation = gql(operating_system_create_mutation)
        input = {
            "slug": slug,
            "organization": organization_id,
            "checksumFile": checksum_file_id,
            "checksumFileType": checksum_file_type,
            "isoFile": iso_file_id,
        }
        variables = {"input": input}
        result = self.primitive.session.execute(
            mutation, variable_values=variables, get_execution_result=True
        )
        return result.data.get("operatingSystemCreate")

    @guard
    def get_operating_system_list(
        self,
        organization_id: str,
        slug: str | None = None,
        id: str | None = None,
    ):
        query = gql(operating_system_list_query)

        variables = {
            "filters": {
                "organization": {"id": organization_id},
            }
        }

        if slug:
            variables["filters"]["slug"] = {"exact": slug}

        if id:
            variables["filters"]["id"] = id

        result = self.primitive.session.execute(
            query, variable_values=variables, get_execution_result=True
        )

        return result

    @guard
    def get_operating_system(
        self, organization_id: str, slug: str | None = None, id: str | None = None
    ):
        if not (slug or id):
            raise Exception("Slug or id must be provided.")
        if slug and id:
            raise Exception("Only one of slug or id must be provided.")

        operating_system_list_result = self.get_operating_system_list(
            organization_id=organization_id, slug=slug, id=id
        )

        edges = operating_system_list_result.data.get("operatingSystemList").get(
            "edges", []
        )

        if len(edges) == 0:
            if slug:
                logger.error(f"No operating system found for slug '{slug}'.")
                raise Exception(f"No operating system  found for slug {slug}.")
            else:
                logger.error(f"No operating system found for ID {id}.")
                raise Exception(f"No operating system  found for ID {id}.")

        return edges[0].get("node")

    @guard
    def is_slug_available(self, slug: str, organization_id: str):
        query = gql(operating_system_list_query)

        variables = {
            "filters": {
                "slug": {"exact": slug},
                "organization": {"id": organization_id},
            }
        }

        result = self.primitive.session.execute(
            query, variable_values=variables, get_execution_result=True
        )

        count = result.data.get("operatingSystemList").get("totalCount")

        return count == 0

    def is_operating_system_cached(self, slug: str, directory: str | None = None):
        cache_dir = Path(directory) if directory else get_operating_systems_cache()
        cache_path = cache_dir / slug

        return cache_path.exists()
