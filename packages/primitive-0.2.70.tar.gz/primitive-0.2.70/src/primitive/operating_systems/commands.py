from pathlib import Path

import click
import typing
from loguru import logger

from ..utils.cache import get_operating_systems_cache
from ..utils.text import slugify

if typing.TYPE_CHECKING:
    from ..client import Primitive


@click.group("operating-systems")
@click.pass_context
def cli(context):
    "Operating Systems"
    pass


@cli.command("download")
@click.option("--id", help="Operating system ID", required=False)
@click.option("--slug", help="Operating system slug", required=False)
@click.option("--organization-slug", help="Organization slug", required=False)
@click.option(
    "--directory",
    help="Directory to download the operating system files to",
    required=False,
)
@click.pass_context
def download(context, id, slug, organization_slug, directory):
    if not (id or slug):
        raise click.UsageError("You must provide either --id or --slug.")
    if id and slug:
        raise click.UsageError("You can only specify one of --id or --slug.")

    primitive: Primitive = context.obj.get("PRIMITIVE")

    organization = (
        primitive.organizations.get_organization(slug=organization_slug)
        if organization_slug
        else primitive.organizations.get_default_organization()
    )

    if not organization:
        if organization_slug:
            logger.error(f"No organization found with slug {slug}")
        else:
            logger.error("Failed to fetch default organization")

    try:
        operating_system = primitive.operating_systems.get_operating_system(
            organization_id=organization["id"], slug=slug, id=id
        )
    except Exception:
        logger.error("Unable to fetch operating system")
        return

    is_cached = primitive.operating_systems.is_operating_system_cached(
        slug=operating_system["slug"],
        directory=directory,
    )

    if is_cached:
        logger.info("Operating system already exists in cache, aborting download.")
        return

    operating_system_directory = (
        Path(directory) / operating_system["slug"]
        if directory
        else (get_operating_systems_cache() / operating_system["slug"])
    )
    checksum_directory = operating_system_directory / "checksum"
    checksum_file_path = (
        checksum_directory / operating_system["checksumFile"]["fileName"]
    )
    iso_directory = operating_system_directory / "iso"
    iso_file_path = iso_directory / operating_system["isoFile"]["fileName"]

    if not iso_directory.exists():
        iso_directory.mkdir(parents=True)

    if not checksum_directory.exists():
        checksum_directory.mkdir(parents=True)

    logger.info("Downloading operating system iso")
    primitive.files.download_file(
        file_id=operating_system["isoFile"]["id"],
        output_path=iso_directory,
        organization_id=organization["id"],
    )

    logger.info("Downloading operating system checksum")
    primitive.files.download_file(
        file_id=operating_system["checksumFile"]["id"],
        output_path=checksum_directory,
        organization_id=organization["id"],
    )

    logger.info("Validating iso checksum")
    try:
        checksum_file_type = (
            primitive.operating_systems.OperatingSystemChecksumFileType[
                operating_system["checksumFileType"]
            ]
        )
        checksum_valid = primitive.operating_systems.validate_checksum(
            operating_system["slug"],
            iso_file_path,
            checksum_file_path,
            checksum_file_type=checksum_file_type,
        )
    except Exception:
        logger.error("Failed to validate checksum.")
        return

    if not checksum_valid:
        logger.error(
            "Checksums did not match:  file may have been corrupted during download."
            + f"\nTry deleting the directory {get_operating_systems_cache()}/{operating_system['slug']} and running this command again."
        )
        return

    logger.success(
        f"Successfully downloaded operating system to {operating_system_directory}"
    )


@cli.group("remotes")
@click.pass_context
def remotes(context):
    "Remotes"
    pass


@remotes.command("mirror")
@click.pass_context
@click.argument("operating-system")
@click.option("--slug", help="Slug of the operating system", required=False)
@click.option(
    "--organization-slug",
    help="Slug of the organization to upload the operating system to",
    required=False,
)
def operating_system_mirror_command(
    context, operating_system, slug=None, organization_slug=None
):
    primitive: Primitive = context.obj.get("PRIMITIVE")

    operating_system_slug = slugify(slug) if slug else slugify(operating_system)

    organization = (
        primitive.organizations.get_organization(slug=organization_slug)
        if organization_slug
        else primitive.organizations.get_default_organization()
    )

    if not organization:
        if organization_slug:
            logger.error(f"No organization found with slug {slug}.")
        else:
            logger.error("Failed to fetch default organization.")

    is_slug_available = primitive.operating_systems.is_slug_available(
        slug=operating_system_slug,
        organization_id=organization["id"],
    )

    if not is_slug_available:
        logger.error(
            f"Operating system slug {operating_system_slug} already exists."
            + " Please specify the --slug parameter to mirror the operating system with a different slug."
        )
        return

    try:
        iso_file_path, checksum_file_path = (
            primitive.operating_systems.download_from_remote(operating_system)
        )
    except Exception:
        logger.error("Unable to download operating system")
        return

    logger.info("Validating iso checksum")
    try:
        checksum_valid = primitive.operating_systems.validate_checksum(
            operating_system, iso_file_path, checksum_file_path
        )
    except Exception:
        logger.error("Failed to validate checksum.")
        return

    if not checksum_valid:
        logger.error(
            "Checksums did not match:  file may have been corrupted during download."
            + f"\nTry deleting the directory {get_operating_systems_cache()}/{operating_system} and running this command again."
        )
        return

    logger.info("Checksum valid")

    logger.info("Uploading operating system files to primitive.")
    file_key_prefix = "operating-systems"

    iso_upload_result = primitive.files.upload_file_direct(
        path=iso_file_path,
        organization_id=organization["id"],
        key_prefix=file_key_prefix,
    )

    if iso_upload_result and iso_upload_result.data is not None:
        iso_upload_data = iso_upload_result.data
        iso_file_id = iso_upload_data.get("fileUpdate", {}).get("id")

        if not iso_file_id:
            logger.error("Unable to upload iso file")
            return

    checksum_upload_response = primitive.files.upload_file_via_api(
        path=checksum_file_path,
        organization_id=organization["id"],
        key_prefix=file_key_prefix,
    )

    if not checksum_upload_response.ok:
        logger.error("Unable to upload checksum file")
        return

    checksum_file_id = (
        checksum_upload_response.json()
        .get("data", {})
        .get("fileUpload", {})
        .get("id", {})
    )

    if not checksum_file_id:
        logger.error("Unable to upload checksum file")
        return

    logger.info("Creating operating system in primitive.")
    operating_system_create_response = (
        primitive.operating_systems.create_operating_system(
            slug=operating_system_slug,
            checksum_file_id=checksum_file_id,
            checksum_file_type=primitive.operating_systems.get_checksum_file_type(
                operating_system
            ).value,
            organization_id=organization["id"],
            iso_file_id=iso_file_id,
        )
    )

    if "id" not in operating_system_create_response:
        logger.error("Failed to create operating system")
        return

    logger.success("Operating system created in primitive.")


@remotes.command("list")
@click.pass_context
def operating_system_list_command(context):
    primitive: Primitive = context.obj.get("PRIMITIVE")
    remote_operating_system_names = (
        primitive.operating_systems.get_remote_operating_system_names()
    )
    logger.info("Remote operating systems available for download:")
    logger.info("\n".join(remote_operating_system_names))
