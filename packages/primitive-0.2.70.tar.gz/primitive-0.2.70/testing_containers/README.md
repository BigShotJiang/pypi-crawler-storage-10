Run the following commands, at the root of the project, to test **ubuntu** and/or **fedora** systeminfo.

```sh
make build && \
podman build -t ubuntu-with-primitive:latest -f ./testing_containers/ubuntu.Containerfile . && \
podman run -it --rm ubuntu-with-primitive:latest primitive --json hardware systeminfo
```

```sh
make build && \
podman build -t fedora-with-primitive:latest -f ./testing_containers/fedora.Containerfile . && \
podman run -it --rm fedora-with-primitive:latest primitive --json hardware systeminfo
```