from ._lrparse import lr, lrr
__all__ = ["lr", "lrr"]
__version__ = "0.1.7"
