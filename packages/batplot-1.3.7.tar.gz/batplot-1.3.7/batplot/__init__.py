"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.3.7"

__all__ = ["__version__"]
