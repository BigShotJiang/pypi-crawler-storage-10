# flake8: noqa

# import apis into api package
from wink_sdk_affiliate_winklinks.api.syndicated_item_api import SyndicatedItemApi
from wink_sdk_affiliate_winklinks.api.syndication_category_api import SyndicationCategoryApi
from wink_sdk_affiliate_winklinks.api.syndication_settings_api import SyndicationSettingsApi

