# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reactive): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant reactive widget for all other entities.   - [TripPay](/reactive): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # WinkLinks API The WinkLinks API exposes endpoints to manage WinkLink entries, categories and settings. This API lets you:  1. Entries: Manage WinkLinks entries. 2. Categories: Manage WinkLinks tags. 2. Settings: Configure WinkLinks account.  Browse the endpoints in the left navigation bar to get started.  

    The version of the OpenAPI document: 30.17.5
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


import unittest

from wink_sdk_affiliate_winklinks.models.redirect_view import RedirectView

class TestRedirectView(unittest.TestCase):
    """RedirectView unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def make_instance(self, include_optional) -> RedirectView:
        """Test RedirectView
            include_optional is a boolean, when False only required
            params are included, when True both required and
            optional params are included """
        # uncomment below to create an instance of `RedirectView`
        """
        model = RedirectView()
        if include_optional:
            return RedirectView(
                application_context = wink_sdk_affiliate_winklinks.models.application_context.ApplicationContext(
                    parent = null, 
                    id = '', 
                    display_name = '', 
                    autowire_capable_bean_factory = null, 
                    application_name = '', 
                    startup_date = 56, 
                    environment = wink_sdk_affiliate_winklinks.models.environment.Environment(
                        active_profiles = [
                            ''
                            ], 
                        default_profiles = [
                            ''
                            ], ), 
                    bean_definition_count = 56, 
                    bean_definition_names = [
                        ''
                        ], 
                    parent_bean_factory = null, 
                    class_loader = wink_sdk_affiliate_winklinks.models.application_context_class_loader.ApplicationContext_classLoader(
                        name = '', 
                        registered_as_parallel_capable = True, 
                        parent = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent.ApplicationContext_classLoader_parent(
                            name = '', 
                            registered_as_parallel_capable = True, 
                            unnamed_module = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_unnamed_module.ApplicationContext_classLoader_parent_unnamedModule(
                                name = '', 
                                descriptor = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_unnamed_module_descriptor.ApplicationContext_classLoader_parent_unnamedModule_descriptor(
                                    open = True, 
                                    automatic = True, ), 
                                named = True, 
                                annotations = [
                                    null
                                    ], 
                                declared_annotations = [
                                    null
                                    ], 
                                packages = [
                                    ''
                                    ], 
                                native_access_enabled = True, 
                                layer = null, ), 
                            defined_packages = [
                                wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_defined_packages_inner.ApplicationContext_classLoader_parent_definedPackages_inner(
                                    name = '', 
                                    sealed = True, 
                                    specification_title = '', 
                                    specification_version = '', 
                                    specification_vendor = '', 
                                    implementation_title = '', 
                                    implementation_version = '', 
                                    implementation_vendor = '', )
                                ], 
                            default_assertion_status = True, ), 
                        unnamed_module = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_unnamed_module.ApplicationContext_classLoader_parent_unnamedModule(
                            name = '', 
                            named = True, 
                            native_access_enabled = True, 
                            layer = null, ), 
                        defined_packages = [
                            wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_defined_packages_inner.ApplicationContext_classLoader_parent_definedPackages_inner(
                                name = '', 
                                sealed = True, 
                                specification_title = '', 
                                specification_version = '', 
                                specification_vendor = '', 
                                implementation_title = '', 
                                implementation_version = '', 
                                implementation_vendor = '', )
                            ], 
                        default_assertion_status = True, ), ),
                servlet_context = wink_sdk_affiliate_winklinks.models.servlet_context.ServletContext(
                    class_loader = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent.ApplicationContext_classLoader_parent(
                        name = '', 
                        registered_as_parallel_capable = True, 
                        unnamed_module = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_unnamed_module.ApplicationContext_classLoader_parent_unnamedModule(
                            name = '', 
                            descriptor = wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_unnamed_module_descriptor.ApplicationContext_classLoader_parent_unnamedModule_descriptor(
                                open = True, 
                                automatic = True, ), 
                            named = True, 
                            annotations = [
                                null
                                ], 
                            declared_annotations = [
                                null
                                ], 
                            packages = [
                                ''
                                ], 
                            native_access_enabled = True, 
                            layer = null, ), 
                        defined_packages = [
                            wink_sdk_affiliate_winklinks.models.application_context_class_loader_parent_defined_packages_inner.ApplicationContext_classLoader_parent_definedPackages_inner(
                                name = '', 
                                sealed = True, 
                                specification_title = '', 
                                specification_version = '', 
                                specification_vendor = '', 
                                implementation_title = '', 
                                implementation_version = '', 
                                implementation_vendor = '', )
                            ], 
                        default_assertion_status = True, ), 
                    major_version = 56, 
                    minor_version = 56, 
                    session_tracking_modes = [
                        'COOKIE'
                        ], 
                    init_parameter_names = null, 
                    attribute_names = null, 
                    context_path = '', 
                    servlet_context_name = '', 
                    effective_major_version = 56, 
                    effective_minor_version = 56, 
                    server_info = '', 
                    session_cookie_config = wink_sdk_affiliate_winklinks.models.session_cookie_config.SessionCookieConfig(
                        path = '', 
                        domain = '', 
                        name = '', 
                        attributes = {
                            'key' : ''
                            }, 
                        comment = '', 
                        secure = True, 
                        max_age = 56, 
                        http_only = True, ), 
                    session_timeout = 56, 
                    servlet_registrations = {
                        'key' : wink_sdk_affiliate_winklinks.models.servlet_registration.ServletRegistration(
                            run_as_role = '', 
                            mappings = [
                                ''
                                ], 
                            name = '', 
                            class_name = '', 
                            init_parameters = {
                                'key' : ''
                                }, )
                        }, 
                    default_session_tracking_modes = [
                        'COOKIE'
                        ], 
                    filter_registrations = {
                        'key' : wink_sdk_affiliate_winklinks.models.filter_registration.FilterRegistration(
                            servlet_name_mappings = [
                                ''
                                ], 
                            url_pattern_mappings = [
                                ''
                                ], 
                            name = '', 
                            class_name = '', )
                        }, 
                    effective_session_tracking_modes = [
                        'COOKIE'
                        ], 
                    jsp_config_descriptor = wink_sdk_affiliate_winklinks.models.jsp_config_descriptor.JspConfigDescriptor(
                        taglibs = [
                            wink_sdk_affiliate_winklinks.models.taglib_descriptor.TaglibDescriptor(
                                taglib_location = '', 
                                taglib_uri = '', )
                            ], 
                        jsp_property_groups = [
                            wink_sdk_affiliate_winklinks.models.jsp_property_group_descriptor.JspPropertyGroupDescriptor(
                                deferred_syntax_allowed_as_literal = '', 
                                error_on_el_not_found = '', 
                                page_encoding = '', 
                                scripting_invalid = '', 
                                is_xml = '', 
                                include_preludes = [
                                    ''
                                    ], 
                                include_codas = [
                                    ''
                                    ], 
                                trim_directive_whitespaces = '', 
                                error_on_undeclared_namespace = '', 
                                el_ignored = '', 
                                buffer = '', 
                                default_content_type = '', 
                                url_patterns = [
                                    ''
                                    ], )
                            ], ), 
                    virtual_server_name = '', 
                    request_character_encoding = '', 
                    response_character_encoding = '', ),
                content_type = '',
                request_context_attribute = '',
                static_attributes = {
                    'key' : null
                    },
                expose_path_variables = True,
                expose_context_beans_as_attributes = True,
                exposed_context_bean_names = [
                    ''
                    ],
                bean_name = '',
                url = '',
                context_relative = True,
                http10_compatible = True,
                expose_model_attributes = True,
                encoding_scheme = '',
                status_code = None,
                expand_uri_template_variables = True,
                propagate_query_params = True,
                hosts = [
                    ''
                    ],
                redirect_view = True,
                propagate_query_properties = True,
                attributes = {
                    'key' : ''
                    },
                attributes_map = {
                    'key' : null
                    },
                attributes_csv = ''
            )
        else:
            return RedirectView(
        )
        """

    def testRedirectView(self):
        """Test RedirectView"""
        # inst_req_only = self.make_instance(include_optional=False)
        # inst_req_and_optional = self.make_instance(include_optional=True)

if __name__ == '__main__':
    unittest.main()
