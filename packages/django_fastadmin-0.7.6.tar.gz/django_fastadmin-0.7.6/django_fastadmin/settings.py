from django.conf import settings

ENABLE_WIDGET_API_TITLE_TO_CODE = getattr(settings, "ENABLE_WIDGET_API_TITLE_TO_CODE", True)
