
default_app_config = "django_fastadmin.apps.DjangoFastadminConfig"

app_requires = [
    "django_static_jquery3",
    "django_static_ace_builds",
    "django_static_fontawesome",
    "django_apiview",
]
