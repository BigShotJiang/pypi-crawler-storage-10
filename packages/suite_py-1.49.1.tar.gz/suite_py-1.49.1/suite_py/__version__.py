# -*- encoding: utf-8 -*-
__version__ = "1.49.1"
