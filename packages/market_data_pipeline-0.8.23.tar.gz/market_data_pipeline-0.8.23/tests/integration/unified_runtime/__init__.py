"""Integration tests for unified runtime."""

