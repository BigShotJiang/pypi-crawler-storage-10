"""Integration tests for market data pipeline."""
