"""CLI for market data pipeline unified runtime."""

