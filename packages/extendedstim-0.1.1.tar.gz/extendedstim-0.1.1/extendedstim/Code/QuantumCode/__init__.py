import QuantumCode
import QuantumCSSCode
import MajoranaCode
import MajoranaCSSCode
import PauliCode
import PauliCSSCode
import LatticeSurgery

QuantumCode=QuantumCode.QuantumCode
QuantumCSSCode=QuantumCSSCode.QuantumCSSCode
MajoranaCode=MajoranaCode.MajoranaCode
MajoranaCSSCode=MajoranaCSSCode.MajoranaCSSCode
PauliCode=PauliCode.PauliCode
PauliCSSCode=PauliCSSCode.PauliCSSCode
