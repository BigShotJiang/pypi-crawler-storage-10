from LinearCode import *
from QuantumCode import *


