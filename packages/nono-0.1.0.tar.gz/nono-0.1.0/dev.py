from nono.models import CallingFrame

x = CallingFrame(
    calling_entity_id="entity-123",
    data = {"key": "value"},
    value_stack=[],
    handler_stack=[],
    op_stack=[]
)