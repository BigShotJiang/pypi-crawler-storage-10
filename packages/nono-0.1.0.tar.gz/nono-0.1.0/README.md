# nono Python SDK

A type-safe async Python SDK for the nono orchestrator server.

## Features

- **Fully async** - Built on `httpx` for async HTTP requests
- **Type-safe** - Full Pydantic models with type hints
- **Kebab-case compatible** - Handles both `snake_case` and `kebab-case` field names
- **Auto-configuration** - Reads `NONO_HOST` and `NONO_PORT` from environment variables
- **Comprehensive** - Covers all nono API endpoints

## Installation

```bash
# From the sdks/python directory
pip install -e .

# Or with uv
uv pip install -e .
```

## Quick Start

```python
import asyncio
from nono import NonoClient, CallingFrame, OperationPushValue

async def main():
    # Client reads NONO_HOST and NONO_PORT from environment
    async with NonoClient() as client:
        # Read configuration
        config = await client.config_read()
        print(f"Config: {config.config}")

        # Create a session
        frame = CallingFrame(
            calling_entity_id="my-entity",
            data={"frame_data": "initial"},
            value_stack=[],
            op_stack=[],
            handler_stack=[],
        )

        session_id = await client.session_create(
            name="my-session",
            data={"counter": 0},
            frame=frame,
        )
        print(f"Created session: {session_id}")

        # Execute operations
        await client.frame_push_value(session_id, 42)
        
        # Read session data
        data = await client.session_get_data(session_id)
        print(f"Session data: {data}")

        # Clean up
        await client.session_delete(session_id)

asyncio.run(main())
```

## License

MIT
