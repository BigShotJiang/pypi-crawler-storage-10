# This file is auto-generated. Do not edit manually.
SDK_VERSION = "0.2.0"
