"""
Download endpoint - Download apps from S3 repository
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from pathlib import Path
import sys
import json
from datetime import datetime

# Add the backend source to path
backend_path = Path(__file__).parent.parent.parent.parent.parent / "aurica-base-be" / "src"
sys.path.insert(0, str(backend_path.parent))

try:
    from src.s3_version_manager import S3VersionManager
    from src.auth_decorators import require_auth
except ImportError as e:
    print(f"Warning: Import error: {e}")
    def require_auth(func):
        return func

router = APIRouter()


class DownloadRequest(BaseModel):
    """Request model for download endpoint."""
    app_name: str
    version: Optional[str] = None  # For future version support
    force: bool = False  # Force download even if app exists locally


class DownloadResponse(BaseModel):
    """Response model for download endpoint."""
    success: bool
    message: str
    app_name: str
    version: Optional[str]
    files_downloaded: int


@router.post("/", response_model=DownloadResponse, summary="Download app from S3 repository", tags=['app-sync'])
@require_auth
async def download_app(request: DownloadRequest):
    """
    Download an app from S3 repository to local filesystem.
    
    Args:
        request: DownloadRequest with app_name and optional version
        
    Returns:
        DownloadResponse with download status
    """
    try:
        # Initialize version manager
        version_manager = S3VersionManager()
        
        # Get apps directory
        apps_dir = Path(__file__).parent.parent.parent.parent
        app_path = apps_dir / request.app_name
        
        # Check if app already exists
        if app_path.exists() and not request.force:
            raise HTTPException(
                status_code=409,
                detail=f"App '{request.app_name}' already exists locally. Use force=true to overwrite."
            )
        
        # Download the app
        success = version_manager.download_app(request.app_name, apps_dir, request.version)
        
        if not success:
            raise HTTPException(
                status_code=404,
                detail=f"App '{request.app_name}' not found in repository or download failed"
            )
        
        # Count downloaded files
        files_count = sum(1 for f in app_path.rglob('*') if f.is_file() 
                         and '__pycache__' not in str(f) 
                         and not f.name.startswith('.'))
        
        # Get version from downloaded app.json
        downloaded_version = None
        app_json_path = app_path / "app.json"
        if app_json_path.exists():
            try:
                with open(app_json_path, 'r') as f:
                    app_data = json.load(f)
                    downloaded_version = app_data.get('version', 'unknown')
                    
                    # Update last_synced timestamp
                    app_data['last_synced'] = datetime.now().isoformat()
                    
                    with open(app_json_path, 'w') as f:
                        json.dump(app_data, f, indent=2)
            except Exception as e:
                print(f"Warning: Could not update app.json: {e}")
        
        return DownloadResponse(
            success=True,
            message=f"Successfully downloaded app '{request.app_name}' from repository",
            app_name=request.app_name,
            version=downloaded_version,
            files_downloaded=files_count
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error downloading app: {str(e)}"
        )
