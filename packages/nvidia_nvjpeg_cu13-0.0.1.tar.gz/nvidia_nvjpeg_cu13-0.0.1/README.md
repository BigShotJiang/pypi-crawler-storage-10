⚠️ THIS PROJECT 'nvidia-nvjpeg-cu13' IS DEPRECATED.
Please use 'nvidia-nvjpeg' instead.

To install the correct package, use:

    pip install nvidia-nvjpeg

For more information, visit: https://pypi.org/project/nvidia-nvjpeg/
