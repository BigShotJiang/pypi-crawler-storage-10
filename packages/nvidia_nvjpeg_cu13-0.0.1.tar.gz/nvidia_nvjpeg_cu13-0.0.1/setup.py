import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-nvjpeg-cu13' IS DEPRECATED.
Please use 'nvidia-nvjpeg' instead.

To install the correct package, use:

    pip install nvidia-nvjpeg

For more information, visit: https://pypi.org/project/nvidia-nvjpeg/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
