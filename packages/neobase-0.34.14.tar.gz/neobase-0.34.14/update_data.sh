#!/usr/bin/env sh

wget --no-check-certificate 'https://raw.githubusercontent.com/opentraveldata/opentraveldata/master/opentraveldata/optd_por_public.csv' -O neobase/optd_por_public.csv
