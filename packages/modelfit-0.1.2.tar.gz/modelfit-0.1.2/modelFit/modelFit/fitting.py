"""High-level orchestration for Gaussian-oriented (M)LE fitting."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional, Tuple, Union

import numpy as np
from scipy.optimize import OptimizeResult, minimize

from .data import (
    ArrayLike,
    Bounds,
    coerce_float_array,
    ensure_1d_response,
    ensure_2d_features,
    ensure_theta,
    validate_bounds,
)
from .display import ObjectiveTracker, OptimisationMonitor, evaluate_likelihood_surface_grid
from .likelihoods import ObservationModelEvaluator
from .metrics import compute_metrics
from .priors import build_prior
from .structures import EvaluationState, FitResult, FitUncertainty, LikelihoodSurface
from .uncertainty import (
    compute_bootstrap_uncertainty,
    compute_hessian_uncertainty,
)


ModelFunction = Callable[[np.ndarray, np.ndarray], np.ndarray]
SigmaFunction = Callable[[np.ndarray], float]


@dataclass
class _VerboseLogger:
    enabled: bool

    def __post_init__(self) -> None:
        self.messages: List[str] = []

    def log(self, message: str) -> None:
        formatted = str(message)
        self.messages.append(formatted)
        if self.enabled:
            print(formatted)


def _normalise_distribution(name: str, allowed: Iterable[str]) -> str:
    normalised = str(name).lower()
    if normalised not in allowed:
        allowed_str = ", ".join(sorted(allowed))
        raise ValueError(f"`{name}` must be one of {{{allowed_str}}}.")
    return normalised


def _resolve_trials(trials: Optional[ArrayLike], y: np.ndarray) -> np.ndarray:
    if trials is None:
        trials_arr = np.ones_like(y, dtype=float)
    else:
        trials_arr = coerce_float_array("binomial_trials", trials).reshape(-1)
        if trials_arr.shape[0] != y.shape[0]:
            raise ValueError("`binomial_trials` must align with the number of observations in `y`.")
        trials_arr = trials_arr.astype(float)

    if np.any(trials_arr <= 0):
        raise ValueError("`binomial_trials` entries must be positive.")
    if np.any((y < 0) | (y > trials_arr)):
        raise ValueError("Binomial responses must satisfy 0 <= y <= number of trials.")
    return trials_arr


def fit_gaussian(
    model_fn: ModelFunction,
    x: ArrayLike,
    y: ArrayLike,
    initial_params: ArrayLike,
    *,
    method: str = "L-BFGS-B",
    bounds: Bounds = None,
    options: Optional[Dict[str, Union[int, float]]] = None,
    estimate_uncertainty: bool = False,
    uncertainty_method: str = "none",
    n_bootstrap: int = 500,
    bootstrap_seed: Optional[int] = None,
    hessian_eps: float = 1e-5,
    sigma_fn: Optional[SigmaFunction] = None,
    profile_sigma: bool = False,
    mode: str = "mle",
    prior_mean: Optional[ArrayLike] = None,
    prior_variance: Optional[ArrayLike] = None,
    prior_distribution: str = "gaussian",
    prior_prob: Optional[ArrayLike] = None,
    prior_rate: Optional[ArrayLike] = None,
    prior_alpha: Optional[ArrayLike] = None,
    prior_beta_shape: Optional[ArrayLike] = None,
    output_distribution: str = "gaussian",
    binomial_trials: Optional[ArrayLike] = None,
    verbose: bool = False,
    display: bool = False,
    display_identifier: Optional[str] = None,
    display_backend_fallback: bool = False,
    compute_likelihood_surface: bool = False,
    surface_param_indices: Tuple[int, int] = (0, 1),
    surface_points: int = 50,
    bootstrap_parallel: bool = True,
    bootstrap_max_workers: Optional[int] = None,
) -> FitResult:
    """Fit a Gaussian-style observation model via (M)LE optimisation.

    The refactored pipeline validates inputs, evaluates the likelihood via
    :class:`ObservationModelEvaluator`, minimises the negative log-posterior, and
    augments the solution with uncertainty diagnostics and fit metrics.
    """

    if not callable(model_fn):
        raise TypeError("`model_fn` must be callable.")
    if sigma_fn is not None and not callable(sigma_fn):
        raise TypeError("`sigma_fn` must be callable when provided.")

    mode_normalised = _normalise_distribution(mode, {"mle", "map"})
    distribution = _normalise_distribution(output_distribution, {"gaussian", "binomial", "poisson"})
    uncertainty = _normalise_distribution(uncertainty_method, {"bootstrap", "hessian", "none"})

    logger = _VerboseLogger(verbose)

    x_arr = ensure_2d_features(coerce_float_array("x", x))
    y_arr = ensure_1d_response(coerce_float_array("y", y))
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError("`x` and `y` must contain the same number of observations.")

    if distribution == "binomial":
        trials_arr = _resolve_trials(binomial_trials, y_arr)
    else:
        trials_arr = None

    if distribution == "poisson" and np.any(y_arr < 0):
        raise ValueError("Poisson observations must be non-negative.")

    if distribution != "gaussian" and (sigma_fn is not None or profile_sigma):
        raise ValueError("`sigma_fn` and `profile_sigma` are only valid for Gaussian likelihoods.")

    if distribution == "gaussian" and (sigma_fn is None and not profile_sigma):
        raise ValueError("Provide `sigma_fn` or set `profile_sigma=True` for Gaussian likelihoods.")

    theta0 = ensure_theta(initial_params)
    bounds_list = validate_bounds(bounds, theta0.size)

    if options is not None and not isinstance(options, dict):
        raise TypeError("`options` must be a dictionary of optimiser settings.")

    prior_info = build_prior(
        mode_normalised,
        theta0,
        prior_distribution,
        prior_mean=prior_mean,
        prior_variance=prior_variance,
        prior_prob=prior_prob,
        prior_rate=prior_rate,
        prior_alpha=prior_alpha,
        prior_beta=prior_beta_shape,
    )

    if distribution != "gaussian" and estimate_uncertainty and uncertainty != "none":
        logger.log(
            "Uncertainty estimation is currently only implemented for Gaussian outputs; skipping for distribution="
            f"{distribution}."
        )
        estimate_uncertainty = False
        uncertainty = "none"
    evaluator = ObservationModelEvaluator(
        model_fn,
        x_arr,
        y_arr,
        sigma_fn,
        profile_sigma,
        distribution,
        trials_arr,
    )

    surface_display_enabled = (
        compute_likelihood_surface and bounds_list is not None and theta0.size == 2
    )
    monitor = OptimisationMonitor(
        y=y_arr,
        evaluator=evaluator,
        prior_info=prior_info,
        bounds=bounds_list,
        mode=mode_normalised,
        n_params=theta0.size,
        display=bool(display),
        surface_enabled=surface_display_enabled,
        surface_indices=surface_param_indices if surface_display_enabled else None,
        surface_points=surface_points,
        display_label=display_identifier,
        allow_backend_switch=display_backend_fallback,
    )

    initial_eval = evaluator.evaluate(theta0)
    initial_log_prior = prior_info.evaluate(theta0)
    initial_state = EvaluationState(
        theta=theta0.copy(),
        evaluation=initial_eval,
        log_prior=initial_log_prior,
        log_posterior=initial_eval.log_likelihood + initial_log_prior,
        objective=-(initial_eval.log_likelihood + initial_log_prior),
    )
    monitor.record(initial_state)
    monitor.seed_initial_state(initial_state)

    sigma_msg = (
        f", sigma_start={initial_eval.sigma:.6f}" if initial_eval.sigma is not None else ""
    )
    logger.log(
        "Validated inputs: n_obs={n_obs}, n_params={n_params}{sigma}".format(
            n_obs=y_arr.size,
            n_params=theta0.size,
            sigma=sigma_msg,
        )
    )
    logger.log(f"Initial objective value: {initial_state.objective:.6f}")

    tracker = ObjectiveTracker(
        evaluator=evaluator,
        prior_info=prior_info,
        monitor=monitor,
    )

    def _callback(theta: np.ndarray) -> None:
        monitor.on_iteration(theta)

    optimisation_result: OptimizeResult = minimize(
        tracker,
        theta0,
        method=method,
        bounds=bounds_list,
        options=options,
        callback=_callback,
    )

    monitor.finalize(optimisation_result.x)
    final_state = monitor.latest_iteration_state
    if final_state is None or not np.allclose(final_state.theta, optimisation_result.x, rtol=1e-7, atol=1e-9):
        tracker.evaluate(optimisation_result.x, record=True)
        monitor.finalize(optimisation_result.x)
        final_state = monitor.latest_iteration_state

    if final_state is None:
        raise RuntimeError("Optimisation finished without producing a valid evaluation state.")

    final_params = final_state.theta.copy()
    final_evaluation = final_state.evaluation
    final_log_likelihood = final_evaluation.log_likelihood
    final_log_prior_value = final_state.log_prior if prior_info.enabled else None
    final_log_posterior = final_state.log_posterior

    sigma_suffix = "" if final_evaluation.sigma is None else f", sigma={final_evaluation.sigma:.6f}"
    logger.log(
        "Optimisation complete: success={success}, objective={objective:.6f}{sigma}".format(
            success=bool(optimisation_result.success),
            objective=float(optimisation_result.fun),
            sigma=sigma_suffix,
        )
    )

    if uncertainty == "bootstrap":
        uncertainty_info = compute_bootstrap_uncertainty(
            estimate_uncertainty=estimate_uncertainty,
            model_fn=model_fn,
            x=x_arr,
            y=y_arr,
            theta_start=final_params,
            method=method,
            bounds=bounds_list,
            options=options,
            prior_info=prior_info,
            sigma_fn=sigma_fn,
            profile_sigma=profile_sigma,
            distribution=distribution,
            trials=trials_arr,
            n_bootstrap=n_bootstrap,
            bootstrap_seed=bootstrap_seed,
            bootstrap_parallel=bootstrap_parallel,
            bootstrap_max_workers=bootstrap_max_workers,
            logger=logger.log,
        )
    elif uncertainty == "hessian":
        uncertainty_info = compute_hessian_uncertainty(
            estimate_uncertainty=estimate_uncertainty,
            objective=lambda theta: tracker.evaluate(theta, record=False),
            theta=final_params,
            hessian_eps=hessian_eps,
            likelihood_distribution=distribution,
            prior_distribution=prior_info.distribution,
            logger=logger.log,
        )
    else:
        logger.log("Uncertainty estimation disabled by user request.")
        uncertainty_info = FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="none",
        )

    metrics = compute_metrics(
        y_arr,
        final_evaluation,
        final_log_likelihood,
        theta0.size,
        distribution,
    )

    surface: Optional[LikelihoodSurface] = None
    if compute_likelihood_surface:
        if bounds_list is None:
            raise ValueError("`compute_likelihood_surface=True` requires finite bounds for all parameters.")
        if theta0.size < 2:
            raise ValueError("Likelihood surface requires at least two parameters.")
        idx0, idx1 = surface_param_indices
        if not (0 <= idx0 < theta0.size and 0 <= idx1 < theta0.size):
            raise ValueError("`surface_param_indices` must reference valid parameter indices.")
        if idx0 == idx1:
            raise ValueError("`surface_param_indices` must reference two distinct parameters.")

        def _finite_pair(bound: Tuple[Optional[float], Optional[float]]) -> bool:
            lower, upper = bound
            return (
                lower is not None
                and upper is not None
                and math.isfinite(lower)
                and math.isfinite(upper)
            )

        if not _finite_pair(bounds_list[idx0]) or not _finite_pair(bounds_list[idx1]):
            raise ValueError("Likelihood surface evaluation requires finite bounds for the selected parameters.")
        if surface_points <= 1:
            raise ValueError("`surface_points` must be greater than 1 to form a grid.")

        snapshot = monitor.surface_snapshot
        if snapshot is not None and snapshot.param_indices == (idx0, idx1):
            surface = snapshot
        else:
            surface = evaluate_likelihood_surface_grid(
                evaluator=evaluator,
                theta_reference=final_params,
                bounds=bounds_list,
                indices=(idx0, idx1),
                surface_points=surface_points,
            )
        logger.log(
            "Computed likelihood surface on a {size}x{size} grid for parameters {indices}.".format(
                size=surface.axis0.size,
                indices=(idx0, idx1),
            )
        )

    return FitResult(
        success=bool(optimisation_result.success),
        mode=mode_normalised,
        params=final_params,
        fun=float(optimisation_result.fun),
        log_likelihood=float(final_log_likelihood),
        log_prior=None if final_log_prior_value is None else float(final_log_prior_value),
        log_posterior=float(final_log_posterior),
        fitted=final_evaluation.fitted,
        residuals=final_evaluation.residuals,
        uncertainty=uncertainty_info,
        metrics=metrics,
        optimizer_result=optimisation_result,
        history=list(logger.messages),
        likelihood_surface=surface,
    )


__all__ = ["fit_gaussian"]
