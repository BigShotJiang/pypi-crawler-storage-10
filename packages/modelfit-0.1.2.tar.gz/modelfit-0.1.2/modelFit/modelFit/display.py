"""Interactive display utilities for the refactored modelFit toolbox."""

from __future__ import annotations

import math
import platform
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

try:  # pragma: no cover - optional dependency for interactive dashboard
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes  # type: ignore
except Exception:  # pragma: no cover - defer hard failure until display is requested
    inset_axes = None  # type: ignore

from .likelihoods import ObservationModelEvaluator
from .priors import PriorInfo
from .structures import EvaluationState, LikelihoodSurface, ParameterProfile


@dataclass
class ObjectiveTracker:
    """Wrap the scalar objective while keeping the monitor in sync."""

    evaluator: ObservationModelEvaluator
    prior_info: PriorInfo
    monitor: "OptimisationMonitor"

    def __call__(self, theta: np.ndarray) -> float:
        return self.evaluate(theta, record=True)

    def evaluate(self, theta: np.ndarray, *, record: bool = True) -> float:
        theta_arr = np.asarray(theta, dtype=float).reshape(-1)
        evaluation = self.evaluator.evaluate(theta_arr)
        log_prior = self.prior_info.evaluate(theta_arr)
        log_posterior = evaluation.log_likelihood + log_prior
        state = EvaluationState(
            theta=theta_arr.copy(),
            evaluation=evaluation,
            log_prior=log_prior,
            log_posterior=log_posterior,
            objective=-log_posterior,
        )
        if record:
            self.monitor.record(state)
        else:
            self.monitor.set_last_state(state)
        return state.objective

    @property
    def last_state(self) -> Optional[EvaluationState]:
        return self.monitor.last_state


class _QtTabContext:
    """Handle for a Qt tab embedding a Matplotlib canvas."""

    def __init__(
        self,
        app: Any,
        tabs: Any,
        tab_widget: Any,
        canvas: Any,
        original_window: Any,
    ) -> None:
        self._app = app
        self._tabs = tabs
        self._tab_widget = tab_widget
        self._canvas = canvas
        self._original_window = original_window

    def process_events(self) -> None:
        if self._app is not None:
            self._app.processEvents()

    def close(self) -> None:
        if self._tabs is not None and self._tab_widget is not None:
            index = self._tabs.indexOf(self._tab_widget)
            if index != -1:
                self._tabs.removeTab(index)
        if self._canvas is not None:
            try:
                self._canvas.setParent(None)
                self._canvas.close()
                delete_later = getattr(self._canvas, "deleteLater", None)
                if callable(delete_later):
                    delete_later()
            except Exception:
                pass
        if self._original_window is not None:
            self._original_window.close()
        self._tab_widget = None
        self._canvas = None
        self._original_window = None


class _QtTabManager:
    """Shared Qt tab host that stacks multiple optimisation dashboards."""

    def __init__(self, matplotlib_module: Any) -> None:
        self.available = False
        self._app: Optional[Any] = None
        self._window: Any = None
        self._tabs: Any = None
        self._figure_context: Dict[Any, _QtTabContext] = {}
        self._run_counter = 0

        backend = str(matplotlib_module.get_backend()).lower()
        if "qt" not in backend:
            return

        try:
            from matplotlib.backends import qt_compat  # type: ignore
            from matplotlib.backends.backend_qtagg import NavigationToolbar2QT  # type: ignore
        except Exception:
            return

        QtWidgets = getattr(qt_compat, "QtWidgets", None)
        if QtWidgets is None:
            return

        self.available = True
        self._QtWidgets = QtWidgets
        self._NavigationToolbar = NavigationToolbar2QT
        try:
            self._app = qt_compat._create_qApp()  # type: ignore[attr-defined]
        except AttributeError:
            self._app = QtWidgets.QApplication.instance()
            if self._app is None:
                self._app = QtWidgets.QApplication(sys.argv or [""])

    def attach(self, figure_or_canvas: Any, label: Optional[str]) -> Optional[_QtTabContext]:
        if not self.available:
            return None

        if hasattr(figure_or_canvas, "figure") and hasattr(figure_or_canvas, "mpl_connect"):
            canvas = figure_or_canvas
            figure = getattr(canvas, "figure", None)
        else:
            figure = figure_or_canvas
            canvas = getattr(figure, "canvas", None)
        if canvas is None:
            return None
        manager = getattr(canvas, "manager", None)
        window = getattr(manager, "window", None)

        QtWidgets = self._QtWidgets
        if self._window is None:
            self._window = QtWidgets.QMainWindow()
            self._window.setWindowTitle("Gaussian Fit Dashboard")
            self._tabs = QtWidgets.QTabWidget()
            self._tabs.setTabsClosable(False)
            self._window.setCentralWidget(self._tabs)
            self._window.resize(1280, 720)

        tab_container = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab_container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        toolbar = self._NavigationToolbar(canvas, tab_container)
        layout.addWidget(toolbar)
        layout.addWidget(canvas)
        if hasattr(canvas, "setParent"):
            canvas.setParent(tab_container)

        display_label = label or f"Run {self._run_counter + 1}"
        index = self._tabs.addTab(tab_container, display_label)
        self._tabs.setCurrentIndex(index)
        self._window.show()
        if window is not None:
            window.hide()

        key = figure if figure is not None else canvas
        context = _QtTabContext(self._app, self._tabs, tab_container, canvas, window)
        self._figure_context[key] = context
        self._run_counter += 1

        def _close_handler(_: Any) -> None:
            self.detach(key)

        target = canvas
        if hasattr(target, "mpl_connect"):
            target.mpl_connect("close_event", _close_handler)
        self.process_events()
        return context

    def detach(self, key: Any) -> None:
        context = self._figure_context.pop(key, None)
        if context is not None:
            context.close()
        if self._tabs is not None and self._tabs.count() == 0 and self._window is not None:
            self._window.hide()

    def process_events(self) -> None:
        if self._app is not None:
            self._app.processEvents()

    def close_all(self) -> None:
        for fig in list(self._figure_context.keys()):
            self.detach(fig)
        if self._window is not None:
            self._window.close()
            self._window = None
            self._tabs = None


_TAB_MANAGER: Optional[_QtTabManager] = None


def _get_tab_manager(matplotlib_module: Any) -> Optional[_QtTabManager]:
    global _TAB_MANAGER
    if _TAB_MANAGER is None:
        _TAB_MANAGER = _QtTabManager(matplotlib_module)
    if _TAB_MANAGER.available:
        return _TAB_MANAGER
    return None


class DynamicDisplay:
    """Matplotlib-powered dashboard to follow optimisation progress in real time."""

    def __init__(
        self,
        n_params: int,
        *,
        surface_enabled: bool,
        surface_indices: Optional[Tuple[int, int]],
        map_enabled: bool,
        display_label: Optional[str] = None,
        prior_payload: Optional[Dict[str, Any]] = None,
        allow_backend_switch: bool = False,
    ) -> None:
        try:
            import matplotlib
            import matplotlib.pyplot as plt
            from matplotlib import gridspec
        except ImportError as exc:  # pragma: no cover - defer failure until needed
            raise RuntimeError(
                "Dynamic display requires matplotlib to be installed. Install it or set display=False."
            ) from exc

        if inset_axes is None:
            try:
                from mpl_toolkits.axes_grid1.inset_locator import inset_axes as _inset_axes  # type: ignore
            except ImportError as exc:  # pragma: no cover - GUI dependency missing
                raise RuntimeError(
                    "Dynamic display requires mpl_toolkits.axes_grid1; install matplotlib with GUI extras."
                ) from exc
            else:
                globals()["inset_axes"] = _inset_axes

        backend_name = matplotlib.get_backend().lower()
        self._allow_backend_switch = bool(allow_backend_switch)

        def _backend_supports_gui(name: str) -> bool:
            from matplotlib import rcsetup

            lowered = name.lower()

            if lowered.startswith("module://"):
                if "matplotlib_inline" in lowered or "ipympl" in lowered:
                    return False

            non_gui_exact = {
                "agg",
                "pdf",
                "ps",
                "svg",
                "cairo",
                "pgf",
                "template",
                "nbagg",
                "webagg",
                "inline",
            }
            if lowered in non_gui_exact:
                return False

            interactive_backends = {bk.lower() for bk in rcsetup.interactive_bk}
            interactive_backends.update({"qtagg", "qt6agg"})

            return lowered in interactive_backends or lowered.startswith("qt") or lowered == "macosx"

        attempted = backend_name

        def _try_switch(candidates: Sequence[str]) -> Optional[str]:
            nonlocal plt
            for candidate in candidates:
                try:
                    plt.switch_backend(candidate)
                except Exception:
                    continue
                candidate_backend = matplotlib.get_backend().lower()
                if _backend_supports_gui(candidate_backend):
                    return candidate_backend
            return None

        gui_backend = _backend_supports_gui(backend_name)

        if not gui_backend and self._allow_backend_switch:
            if "qt" not in backend_name:
                qt_candidates = ["QtAgg", "Qt6Agg", "Qt5Agg", "Qt4Agg"]
                new_backend = _try_switch(qt_candidates)
                if new_backend is not None and "qt" in new_backend:
                    backend_name = new_backend
                    gui_backend = _backend_supports_gui(backend_name)

            if not gui_backend:
                system_name = platform.system()
                if system_name == "Darwin":
                    fallback_candidates: List[str] = ["macosx", "QtAgg", "Qt5Agg", "TkAgg"]
                elif system_name == "Windows":
                    fallback_candidates = ["QtAgg", "Qt5Agg", "TkAgg"]
                else:
                    fallback_candidates = ["QtAgg", "Qt5Agg", "TkAgg"]

                new_backend = _try_switch(fallback_candidates)
                if new_backend is not None:
                    backend_name = new_backend
                    gui_backend = _backend_supports_gui(backend_name)

        if not gui_backend:
            raise RuntimeError(
                "Dynamic display requires a GUI matplotlib backend. "
                f"Current backend '{attempted}' cannot open pop-up windows. "
                "Either activate one manually (for example `%matplotlib qt`) or pass "
                "`display_backend_fallback=True` to `fit_gaussian` to enable automatic switching."
            )

        self._plt = plt
        self._surface_enabled = surface_enabled
        self._surface_indices = surface_indices
        self.map_enabled = map_enabled
        plt.ion()
        self._tab_context: Optional[_QtTabContext] = None
        self._canvas: Any
        self._prior_payload = prior_payload if map_enabled else None
        self._prior_text_artist: Optional[Any] = None
        self._prior_mean_lines: List[Any] = []
        self._prior_band_patches: List[Any] = []
        tab_manager = _get_tab_manager(matplotlib)

        figure_created = False
        if tab_manager is not None:
            try:
                from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
                from matplotlib.figure import Figure
            except Exception:
                FigureCanvasQTAgg = None
                Figure = None  # type: ignore[assignment]
            if FigureCanvasQTAgg is not None and Figure is not None:
                self.fig = Figure(figsize=(13.0, 8.0), constrained_layout=True)
                self._canvas = FigureCanvasQTAgg(self.fig)
                self._tab_context = tab_manager.attach(self._canvas, display_label)
                figure_created = True

        if not figure_created:
            self.fig = plt.figure(figsize=(13.0, 8.0), constrained_layout=True)
            self._canvas = self.fig.canvas

        if self._tab_context is None and tab_manager is not None:
            self._tab_context = tab_manager.attach(self._canvas, display_label)
        if hasattr(self.fig, "set_constrained_layout_pads"):
            self.fig.set_constrained_layout_pads(w_pad=0.18, h_pad=0.18, wspace=0.18, hspace=0.18)

        if map_enabled:
            primary_spec = gridspec.GridSpec(
                1,
                2,
                figure=self.fig,
                width_ratios=[1.0, 0.42],
                wspace=0.82,
            )
            grid = gridspec.GridSpecFromSubplotSpec(
                2,
                2,
                subplot_spec=primary_spec[0, 0],
                height_ratios=[1.05, 1.3],
                width_ratios=[1.0, 1.85],
                hspace=0.1,
                wspace=0.12,
            )
            profiles_parent = primary_spec[0, 1]
        else:
            grid = gridspec.GridSpec(
                2,
                2,
                figure=self.fig,
                height_ratios=[1.05, 1.3],
                width_ratios=[1.0, 1.85],
                hspace=0.1,
                wspace=0.12,
            )
            profiles_parent = None

        self.fig.subplots_adjust(left=0.055, right=0.975, top=0.97, bottom=0.075)

        self.ax_objective = self.fig.add_subplot(grid[0, 0])
        self.ax_objective.set_title("Objective Value")
        self.ax_objective.set_xlabel("Iteration")
        self.ax_objective.set_ylabel("-log posterior" if self.map_enabled else "-log likelihood")
        self.ax_objective.grid(True, alpha=0.25)
        (self._objective_line,) = self.ax_objective.plot([], [], color="#1f77b4")
        self._objective_text = self.ax_objective.text(
            0.02,
            -0.18,
            "",
            transform=self.ax_objective.transAxes,
            va="top",
            ha="left",
            clip_on=False,
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
        )

        self.ax_scatter = self.fig.add_subplot(grid[0, 1])
        self.ax_scatter.set_title("Observed vs predicted")
        self.ax_scatter.set_xlabel("Observed")
        self.ax_scatter.set_ylabel("Predicted")
        self.ax_scatter.grid(True, alpha=0.25)
        self.ax_scatter.set_aspect("equal", adjustable="box")
        (self._scatter_points,) = self.ax_scatter.plot(
            [],
            [],
            linestyle="",
            marker="o",
            markersize=4.5,
            color="#ff7f0e",
            alpha=0.6,
        )
        (self._identity_line,) = self.ax_scatter.plot([], [], linestyle="--", color="#666666", linewidth=1.0)
        self._scatter_text = self.ax_scatter.text(
            0.02,
            -0.18,
            "",
            transform=self.ax_scatter.transAxes,
            va="top",
            ha="left",
            clip_on=False,
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
        )

        if surface_enabled:
            self.ax_parameters = self.fig.add_subplot(grid[1, 0])
            self.ax_surface = self.fig.add_subplot(grid[1, 1])
            self.ax_surface.set_title("Log-likelihood surface")
            if surface_indices is not None:
                self.ax_surface.set_xlabel(f"theta[{surface_indices[0]}]")
                self.ax_surface.set_ylabel(f"theta[{surface_indices[1]}]")
            self.ax_surface.grid(False)
            if hasattr(self.ax_surface, "set_box_aspect"):
                self.ax_surface.set_box_aspect(1)
            else:
                self.ax_surface.set_aspect("equal", adjustable="box")
            self._surface_cbar_ax = inset_axes(
                self.ax_surface,
                width="3%",
                height="100%",
                loc="lower left",
                bbox_to_anchor=(1.02, 0.0, 1.0, 1.0),
                bbox_transform=self.ax_surface.transAxes,
                borderpad=0.0,
            )
            self._surface_cbar_ax.yaxis.set_ticks_position("right")
            self._surface_cbar_ax.yaxis.set_label_position("right")
            self._surface_cbar_ax.tick_params(
                left=False,
                right=True,
                labelleft=False,
                labelright=True,
                pad=2,
            )
            self._surface_image = None
            self._surface_point = None
            self._surface_path = None
            self._surface_colorbar = None
        else:
            self.ax_parameters = self.fig.add_subplot(grid[1, 0:2])
            self.ax_surface = None
            self._surface_image = None
            self._surface_point = None
            self._surface_path = None
            self._surface_cbar_ax = None
            self._surface_colorbar = None

        self.ax_parameters.set_title("Parameter trajectories")
        self.ax_parameters.set_xlabel("Iteration")
        self.ax_parameters.set_ylabel("Value")
        self.ax_parameters.grid(True, alpha=0.25)

        cmap = plt.cm.get_cmap("tab10", max(n_params, 10))
        self._param_lines: List[Any] = []
        for idx in range(n_params):
            color = cmap(idx % cmap.N)
            (line,) = self.ax_parameters.plot([], [], label=f"theta{idx}", color=color)
            self._param_lines.append(line)
        self._legend_shown = False

        if hasattr(self._canvas, "draw_idle"):
            self._canvas.draw_idle()
        if hasattr(self._canvas, "flush_events"):
            self._canvas.flush_events()

        if self.map_enabled and self._prior_payload is not None:
            self._initialise_prior_annotations()

        self._profile_axes: List[Any] = []
        self._profile_lines: List[Dict[str, Any]] = []
        if map_enabled and profiles_parent is not None:
            rows = n_params
            profiles_spec = gridspec.GridSpecFromSubplotSpec(
                rows,
                1,
                subplot_spec=profiles_parent,
                hspace=0.16,
            )
            for idx in range(rows):
                ax = self.fig.add_subplot(profiles_spec[idx, 0])
                ax.set_title(f"theta{idx} profile")
                ax.set_xlabel("Value")
                ax.set_ylabel("Log density (normalised)")
                ax.grid(True, alpha=0.25)
                (line_prior,) = ax.plot([], [], linestyle="--", color="#2ca02c", label="log prior")
                (line_like,) = ax.plot([], [], linestyle="-.", color="#9467bd", label="log likelihood")
                (line_post,) = ax.plot([], [], linestyle="-", color="#d62728", label="log posterior")
                if idx == rows - 1:
                    legend = ax.legend(
                        loc="lower center",
                        bbox_to_anchor=(0.5, -0.32),
                        borderaxespad=0.0,
                        frameon=False,
                        ncol=3,
                    )
                    legend.set_draggable(False)
                self._profile_axes.append(ax)
                self._profile_lines.append(
                    {
                        "prior": line_prior,
                        "likelihood": line_like,
                        "posterior": line_post,
                    }
                )

    def _initialise_prior_annotations(self) -> None:
        prior = self._prior_payload
        if prior is None:
            return
        if self._prior_text_artist is None:
            self._prior_text_artist = self.ax_parameters.text(
                0.02,
                -0.18,
                "",
                transform=self.ax_parameters.transAxes,
                va="top",
                ha="left",
                fontsize=9,
                clip_on=False,
                bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
            )
        else:
            self._prior_text_artist.set_position((0.02, 0.02))
            self._prior_text_artist.set_verticalalignment("bottom")
            self._prior_text_artist.set_text("")

        for artist in self._prior_mean_lines:
            artist.remove()
        for patch in self._prior_band_patches:
            patch.remove()
        self._prior_mean_lines = []
        self._prior_band_patches = []

        if prior.get("distribution") != "gaussian":
            return

        mean = np.asarray(prior.get("mean", []), dtype=float).ravel()
        variance = np.asarray(prior.get("variance", []), dtype=float).ravel()
        if mean.size != len(self._param_lines) or variance.size != len(self._param_lines):
            return

        for idx, line in enumerate(self._param_lines):
            mu = float(mean[idx])
            color = line.get_color()
            h_line = self.ax_parameters.axhline(
                mu,
                color=color,
                linestyle=":",
                linewidth=1.1,
                alpha=0.8,
            )
            self._prior_mean_lines.append(h_line)
            var_val = float(variance[idx]) if np.isfinite(variance[idx]) else 0.0
            if var_val <= 0.0:
                continue
            sigma = float(np.sqrt(var_val))
            band = self.ax_parameters.axhspan(
                mu - sigma,
                mu + sigma,
                color=color,
                alpha=0.12,
            )
            self._prior_band_patches.append(band)

    @staticmethod
    def _format_float(value: float) -> str:
        if not np.isfinite(value):
            return "nan"
        magnitude = abs(value)
        if magnitude != 0.0 and (magnitude < 1e-3 or magnitude >= 1e3):
            return f"{value:.3e}"
        return f"{value:.3f}"

    def _build_prior_text(self, latest_theta: Optional[np.ndarray]) -> str:
        if self._prior_payload is None:
            return ""

        distribution = str(self._prior_payload.get("distribution", "")).capitalize()
        lines = [f"Prior: {distribution}"]
        latest = np.asarray(latest_theta, dtype=float) if latest_theta is not None else None

        if self._prior_payload.get("distribution") == "gaussian":
            mean = np.asarray(self._prior_payload.get("mean", []), dtype=float).ravel()
            variance = np.asarray(self._prior_payload.get("variance", []), dtype=float).ravel()
            for idx, mu in enumerate(mean):
                variance_val = variance[idx] if idx < variance.size else 0.0
                sigma = float(np.sqrt(max(variance_val, 0.0))) if np.isfinite(variance_val) else float("nan")
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    "theta{idx}: mu={mu}, sigma={sigma}, theta={theta}".format(
                        idx=idx,
                        mu=self._format_float(mu),
                        sigma=self._format_float(sigma),
                        theta=self._format_float(theta_val),
                    )
                )
        elif self._prior_payload.get("distribution") == "bernoulli":
            probs = np.asarray(self._prior_payload.get("prob", []), dtype=float).ravel()
            for idx, prob in enumerate(probs):
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    "theta{idx}: p={prob}, theta={theta}".format(
                        idx=idx,
                        prob=self._format_float(prob),
                        theta=self._format_float(theta_val),
                    )
                )
        elif self._prior_payload.get("distribution") == "poisson":
            rates = np.asarray(self._prior_payload.get("rate", []), dtype=float).ravel()
            for idx, rate in enumerate(rates):
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    "theta{idx}: lambda={rate}, theta={theta}".format(
                        idx=idx,
                        rate=self._format_float(rate),
                        theta=self._format_float(theta_val),
                    )
                )
        elif self._prior_payload.get("distribution") == "beta":
            alpha_params = np.asarray(self._prior_payload.get("alpha", []), dtype=float).ravel()
            beta_params = np.asarray(self._prior_payload.get("beta", []), dtype=float).ravel()
            for idx, alpha_val in enumerate(alpha_params):
                beta_val = beta_params[idx] if idx < beta_params.size else float("nan")
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    "theta{idx}: alpha={alpha}, beta={beta}, theta={theta}".format(
                        idx=idx,
                        alpha=self._format_float(alpha_val),
                        beta=self._format_float(beta_val),
                        theta=self._format_float(theta_val),
                    )
                )

        return "\n".join(lines)

    def _update_prior_annotations(self, thetas: np.ndarray) -> None:
        if self._prior_payload is None:
            return

        latest = thetas[-1] if thetas.size != 0 else None
        if self._prior_text_artist is not None:
            self._prior_text_artist.set_text(self._build_prior_text(latest))

    def update(
        self,
        *,
        objectives: np.ndarray,
        thetas: np.ndarray,
        correlations: np.ndarray,
        log_likelihoods: np.ndarray,
        log_priors: np.ndarray,
        log_posteriors: np.ndarray,
        current_theta: np.ndarray,
        surface: Optional[Dict[str, np.ndarray]],
        map_profiles: Optional[List[ParameterProfile]],
        observed: np.ndarray,
        fitted: np.ndarray,
        r_squared: np.ndarray,
        prior_summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        if objectives.size == 0:
            return

        prior_changed = prior_summary is not None and prior_summary is not self._prior_payload
        if prior_summary is not None:
            self._prior_payload = prior_summary
        if self.map_enabled and (self._prior_text_artist is None or prior_changed):
            self._initialise_prior_annotations()

        iterations = np.arange(objectives.size)
        self._objective_line.set_data(iterations, objectives)
        self.ax_objective.relim()
        self.ax_objective.autoscale_view()
        last_ll = log_likelihoods[-1] if log_likelihoods.size else float("nan")
        if self.map_enabled:
            last_lp = log_priors[-1] if log_priors.size else float("nan")
            self._objective_text.set_text(f"LL={last_ll:.3f}\nlog prior={last_lp:.3f}")
        else:
            self._objective_text.set_text(f"LL={last_ll:.3f}")

        observed_arr = np.asarray(observed, dtype=float).reshape(-1)
        fitted_arr = np.asarray(fitted, dtype=float).reshape(-1)
        valid_mask = np.isfinite(observed_arr) & np.isfinite(fitted_arr)
        if np.any(valid_mask):
            x_vals = observed_arr[valid_mask]
            y_vals = fitted_arr[valid_mask]
            self._scatter_points.set_data(x_vals, y_vals)
            data_min = float(np.nanmin(np.concatenate((x_vals, y_vals))))
            data_max = float(np.nanmax(np.concatenate((x_vals, y_vals))))
            if not np.isfinite(data_min) or not np.isfinite(data_max):
                data_min, data_max = -1.0, 1.0
            if data_min == data_max:
                span = 1.0 if data_min == 0.0 else abs(data_min) * 0.1
                data_min -= span
                data_max += span
            pad = 0.05 * (data_max - data_min)
            lower = data_min - pad
            upper = data_max + pad
            self.ax_scatter.set_xlim(lower, upper)
            self.ax_scatter.set_ylim(lower, upper)
            self._identity_line.set_data([lower, upper], [lower, upper])
        else:
            self._scatter_points.set_data([], [])
            self._identity_line.set_data([], [])

        r_display = correlations[-1] if correlations.size else float("nan")
        r2_display = r_squared[-1] if r_squared.size else float("nan")
        text_lines: List[str] = []
        if np.isfinite(r2_display):
            text_lines.append(f"R^2={r2_display:.3f}")
        else:
            text_lines.append("R^2=nan")
        if np.isfinite(r_display):
            text_lines.append(f"r={r_display:.3f}")
        else:
            text_lines.append("r=nan")
        self._scatter_text.set_text("\n".join(text_lines))

        if thetas.size != 0:
            for idx, line in enumerate(self._param_lines):
                line.set_data(iterations, thetas[:, idx])
            self.ax_parameters.relim()
            self.ax_parameters.autoscale_view()
            if not self._legend_shown:
                legend = self.ax_parameters.legend(
                    loc="upper left",
                    bbox_to_anchor=(1.02, 1.0),
                    borderaxespad=0.0,
                    frameon=False,
                    ncol=1,
                )
                if legend is not None:
                    legend.set_draggable(False)
                self._legend_shown = True

        if self.map_enabled:
            self._update_prior_annotations(thetas)

        if self._surface_enabled and surface is not None and self.ax_surface is not None:
            axis0 = surface["axis0"]
            axis1 = surface["axis1"]
            grid = surface["grid"]
            extent = [axis0.min(), axis0.max(), axis1.min(), axis1.max()]
            if self._surface_image is None:
                self._surface_image = self.ax_surface.imshow(
                    grid,
                    origin="lower",
                    aspect="auto",
                    extent=extent,
                    cmap="viridis",
                )
                if self._surface_cbar_ax is not None:
                    self._surface_colorbar = self.fig.colorbar(
                        self._surface_image,
                        cax=self._surface_cbar_ax,
                    )
                    self._surface_cbar_ax.yaxis.set_ticks_position("right")
                    self._surface_cbar_ax.yaxis.set_label_position("right")
            else:
                self._surface_image.set_data(grid)
                self._surface_image.set_extent(extent)
                if self._surface_colorbar is not None:
                    self._surface_colorbar.update_normal(self._surface_image)
            if thetas.size != 0 and thetas.ndim == 2 and self._surface_indices is not None:
                idx0, idx1 = self._surface_indices
                path_x = thetas[:, idx0]
                path_y = thetas[:, idx1]
                mask = np.isfinite(path_x) & np.isfinite(path_y)
                if np.any(mask):
                    path_x = path_x[mask]
                    path_y = path_y[mask]
                    if self._surface_path is None:
                        self._surface_path = self.ax_surface.plot(
                            path_x,
                            path_y,
                            color="#ff9896",
                            linewidth=1.2,
                            alpha=0.6,
                            marker="o",
                            markersize=3.0,
                        )[0]
                    else:
                        self._surface_path.set_data(path_x, path_y)
                elif self._surface_path is not None:
                    self._surface_path.set_data([], [])
            if self._surface_point is None and self._surface_indices is not None:
                x_val = float(current_theta[self._surface_indices[0]])
                y_val = float(current_theta[self._surface_indices[1]])
                self._surface_point = self.ax_surface.plot(
                    [x_val],
                    [y_val],
                    marker="o",
                    color="#d62728",
                )[0]
            elif self._surface_indices is not None:
                x_val = float(current_theta[self._surface_indices[0]])
                y_val = float(current_theta[self._surface_indices[1]])
                self._surface_point.set_data([x_val], [y_val])

        if self.map_enabled and map_profiles is not None and self._profile_lines:
            for idx, profile in enumerate(map_profiles):
                if idx >= len(self._profile_lines):
                    break
                lines = self._profile_lines[idx]
                x_vals = profile.grid
                prior_vals = self._normalise(profile.log_prior)
                like_vals = self._normalise(profile.log_likelihood)
                post_vals = self._normalise(profile.log_posterior)
                lines["prior"].set_data(x_vals, prior_vals)
                lines["likelihood"].set_data(x_vals, like_vals)
                lines["posterior"].set_data(x_vals, post_vals)
                axis = self._profile_axes[idx]
                axis.relim()
                axis.autoscale_view()

        if hasattr(self._canvas, "draw_idle"):
            self._canvas.draw_idle()
        if hasattr(self._canvas, "flush_events"):
            self._canvas.flush_events()

        if self._tab_context is not None:
            self._tab_context.process_events()
        else:
            self._plt.pause(0.01)

    @staticmethod
    def _normalise(values: np.ndarray) -> np.ndarray:
        result = np.asarray(values, dtype=float)
        if result.size == 0 or not np.isfinite(result).any():
            return result
        max_val = np.nanmax(result)
        if not np.isfinite(max_val):
            return result
        return result - max_val


class OptimisationMonitor:
    """Track optimisation state, drive the live dashboard, and expose summaries."""

    def __init__(
        self,
        *,
        y: np.ndarray,
        evaluator: ObservationModelEvaluator,
        prior_info: PriorInfo,
        bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
        mode: str,
        n_params: int,
        display: bool,
        surface_enabled: bool,
        surface_indices: Optional[Tuple[int, int]],
        surface_points: int,
        display_label: Optional[str],
        allow_backend_switch: bool,
        profile_points: int = 80,
        profile_every: int = 3,
        surface_refresh: int = 2,
    ) -> None:
        self.y = np.asarray(y, dtype=float)
        self._y_std = float(np.std(self.y))
        self._y_mean = float(np.mean(self.y))
        self._ss_tot = float(np.sum((self.y - self._y_mean) ** 2))
        self._evaluator = evaluator
        self._prior_info = prior_info
        self._bounds = bounds
        self.mode = mode
        self._surface_indices = surface_indices if surface_enabled else None
        self._surface_points = surface_points
        self._profile_points = profile_points
        self._profile_every = profile_every
        self._surface_refresh = surface_refresh

        self._evaluation_states: List[EvaluationState] = []
        self._iteration_states: List[EvaluationState] = []
        self._last_state: Optional[EvaluationState] = None

        self.theta_history: List[np.ndarray] = []
        self.objective_history: List[float] = []
        self.log_likelihood_history: List[float] = []
        self.log_prior_history: List[float] = []
        self.log_posterior_history: List[float] = []
        self.correlation_history: List[float] = []
        self.r2_history: List[float] = []

        self.surface_snapshot: Optional[LikelihoodSurface] = None

        self.map_enabled = display and mode == "map" and prior_info.enabled
        self.surface_enabled = display and surface_enabled and self._bounds is not None
        self._prior_payload = self._build_prior_payload(prior_info) if self.map_enabled else None
        self.display = (
            DynamicDisplay(
                n_params=int(n_params),
                surface_enabled=self.surface_enabled,
                surface_indices=self._surface_indices,
                map_enabled=self.map_enabled,
                display_label=display_label,
                prior_payload=self._prior_payload,
                allow_backend_switch=allow_backend_switch,
            )
            if display
            else None
        )

    @property
    def last_state(self) -> Optional[EvaluationState]:
        return self._last_state

    @property
    def latest_iteration_state(self) -> Optional[EvaluationState]:
        if self._iteration_states:
            return self._iteration_states[-1]
        return self._last_state

    def record(self, state: EvaluationState) -> None:
        self._evaluation_states.append(state)
        self._last_state = state

    def set_last_state(self, state: EvaluationState) -> None:
        self._last_state = state

    def seed_initial_state(self, state: EvaluationState) -> None:
        if state not in self._evaluation_states:
            self._evaluation_states.append(state)
        self.register_iteration(state, is_initial=True, force=True)

    def on_iteration(self, theta: np.ndarray) -> None:
        state = self._match_state(theta)
        if state is None:
            return
        self.register_iteration(state)

    def finalize(self, theta: np.ndarray) -> None:
        state = self._match_state(theta)
        if state is None:
            state = self._last_state
        if state is not None:
            self.register_iteration(state, force=True)

    def register_iteration(self, state: EvaluationState, *, is_initial: bool = False, force: bool = False) -> None:
        if state.assigned and not force:
            return
        state.assigned = True
        if self._iteration_states and np.allclose(self._iteration_states[-1].theta, state.theta) and not force:
            return

        self._iteration_states.append(state)
        self.theta_history.append(state.theta.copy())
        self.objective_history.append(state.objective)
        self.log_likelihood_history.append(state.evaluation.log_likelihood)
        self.log_prior_history.append(state.log_prior)
        self.log_posterior_history.append(state.log_posterior)
        fitted_values = state.evaluation.fitted
        self.correlation_history.append(self._compute_correlation(fitted_values))
        self.r2_history.append(self._compute_r_squared(fitted_values))

        if self.display is not None:
            profiles: Optional[List[ParameterProfile]] = None
            iteration_count = len(self._iteration_states)
            refresh_profiles = (
                self.map_enabled
                and (is_initial or force or iteration_count == 1 or iteration_count % self._profile_every == 0)
            )
            if refresh_profiles:
                profiles = self._compute_profiles(state.theta)

            surface_payload: Optional[Dict[str, np.ndarray]] = None
            if self.surface_enabled:
                need_surface = (
                    self.surface_snapshot is None
                    or force
                    or iteration_count % self._surface_refresh == 0
                )
                if need_surface:
                    self.surface_snapshot = self._compute_surface_snapshot(state.theta)
                if self.surface_snapshot is not None:
                    surface_payload = {
                        "axis0": self.surface_snapshot.axis0,
                        "axis1": self.surface_snapshot.axis1,
                        "grid": self.surface_snapshot.log_likelihood,
                    }

            objectives = np.asarray(self.objective_history, dtype=float)
            thetas = np.vstack(self.theta_history) if self.theta_history else np.empty((0,))
            correlations = np.asarray(self.correlation_history, dtype=float)
            log_likelihoods = np.asarray(self.log_likelihood_history, dtype=float)
            log_priors = np.asarray(self.log_prior_history, dtype=float)
            log_posteriors = np.asarray(self.log_posterior_history, dtype=float)
            r_squareds = np.asarray(self.r2_history, dtype=float)

            self.display.update(
                objectives=objectives,
                thetas=thetas,
                correlations=correlations,
                log_likelihoods=log_likelihoods,
                log_priors=log_priors,
                log_posteriors=log_posteriors,
                current_theta=state.theta,
                surface=surface_payload,
                map_profiles=profiles,
                observed=self.y,
                fitted=fitted_values,
                r_squared=r_squareds,
                prior_summary=self._prior_payload,
            )

    def _match_state(self, theta: np.ndarray) -> Optional[EvaluationState]:
        theta_arr = np.asarray(theta, dtype=float)
        for state in reversed(self._evaluation_states):
            if state.assigned:
                continue
            if np.allclose(state.theta, theta_arr, rtol=1e-7, atol=1e-9):
                return state
        return None

    def _compute_correlation(self, fitted: np.ndarray) -> float:
        fitted_arr = np.asarray(fitted, dtype=float)
        if fitted_arr.size != self.y.size:
            return float("nan")
        fitted_std = float(np.std(fitted_arr))
        if self._y_std == 0.0 or fitted_std == 0.0:
            return float("nan")
        corr = float(np.corrcoef(self.y, fitted_arr)[0, 1])
        return float(np.clip(corr, -1.0, 1.0))

    def _compute_r_squared(self, fitted: np.ndarray) -> float:
        fitted_arr = np.asarray(fitted, dtype=float)
        if fitted_arr.size != self.y.size or self._ss_tot == 0.0:
            return float("nan")
        residuals = self.y - fitted_arr
        ss_res = float(np.sum(residuals**2))
        r2 = 1.0 - ss_res / self._ss_tot
        return float(np.clip(r2, -10.0, 1.0))

    def _build_prior_payload(self, prior_info: PriorInfo) -> Optional[Dict[str, Any]]:
        if not prior_info.enabled or not prior_info.distribution:
            return None

        payload: Dict[str, Any] = {"distribution": str(prior_info.distribution).lower()}
        parameters = prior_info.parameters or {}
        for key, value in parameters.items():
            if value is None:
                continue
            arr = np.asarray(value, dtype=float)
            payload[key] = np.atleast_1d(arr).astype(float, copy=True)
        return payload

    def _compute_profiles(self, theta: np.ndarray) -> Optional[List[ParameterProfile]]:
        if not self.map_enabled:
            return None

        theta_arr = np.asarray(theta, dtype=float)
        n_params = theta_arr.size
        profiles: List[ParameterProfile] = []

        for idx in range(n_params):
            grid = self._parameter_grid(idx, theta_arr)
            log_likelihood_curve = np.full(grid.size, np.nan, dtype=float)
            log_prior_curve = np.full(grid.size, np.nan, dtype=float)
            log_posterior_curve = np.full(grid.size, np.nan, dtype=float)

            for pos, value in enumerate(grid):
                theta_candidate = theta_arr.copy()
                theta_candidate[idx] = value
                try:
                    evaluation = self._evaluator.evaluate(theta_candidate)
                    log_prior_val = self._prior_info.evaluate(theta_candidate)
                    log_likelihood_curve[pos] = evaluation.log_likelihood
                    log_prior_curve[pos] = log_prior_val
                    log_posterior_curve[pos] = evaluation.log_likelihood + log_prior_val
                except Exception:  # pragma: no cover - keep interactive plotting resilient
                    continue

            profiles.append(
                ParameterProfile(
                    grid=grid,
                    log_likelihood=log_likelihood_curve,
                    log_prior=log_prior_curve,
                    log_posterior=log_posterior_curve,
                )
            )

        return profiles

    def _parameter_grid(self, index: int, theta: np.ndarray) -> np.ndarray:
        lower_bound: Optional[float] = None
        upper_bound: Optional[float] = None
        if self._bounds is not None:
            lower, upper = self._bounds[index]
            if (
                lower is not None
                and upper is not None
                and math.isfinite(lower)
                and math.isfinite(upper)
            ):
                return np.linspace(lower, upper, self._profile_points)
            if lower is not None and math.isfinite(lower):
                lower_bound = lower
            if upper is not None and math.isfinite(upper):
                upper_bound = upper

        if self._prior_info.enabled:
            distribution = self._prior_info.distribution
            params = self._prior_info.parameters
            if distribution == "gaussian" and "mean" in params and "variance" in params:
                mean = params["mean"][index]
                std = math.sqrt(params["variance"][index])
                return np.linspace(mean - 4.0 * std, mean + 4.0 * std, self._profile_points)
            if distribution in {"bernoulli", "beta"}:
                return np.linspace(1e-6, 1.0 - 1e-6, self._profile_points)
            if distribution == "poisson" and "rate" in params:
                upper = max(theta[index] * 3.0, params["rate"][index] * 5.0, 1.0)
                return np.linspace(0.0, upper, self._profile_points)

        span = max(abs(theta[index]) * 2.0, 1.0)
        lower_default = theta[index] - span if lower_bound is None else lower_bound
        upper_default = theta[index] + span if upper_bound is None else upper_bound
        return np.linspace(lower_default, upper_default, self._profile_points)

    def _compute_surface_snapshot(self, theta: np.ndarray) -> Optional[LikelihoodSurface]:
        if not self.surface_enabled or self._bounds is None or self._surface_indices is None:
            return None
        try:
            return evaluate_likelihood_surface_grid(
                evaluator=self._evaluator,
                theta_reference=theta,
                bounds=self._bounds,
                indices=self._surface_indices,
                surface_points=self._surface_points,
            )
        except Exception:  # pragma: no cover - keep plotting resilient
            return None


def evaluate_likelihood_surface_grid(
    *,
    evaluator: ObservationModelEvaluator,
    theta_reference: np.ndarray,
    bounds: Sequence[Tuple[Optional[float], Optional[float]]],
    indices: Tuple[int, int],
    surface_points: int,
) -> LikelihoodSurface:
    """Evaluate the log-likelihood on a grid for diagnostics."""

    if surface_points <= 1:
        raise ValueError("`surface_points` must be greater than 1 to compute a grid.")

    idx0, idx1 = indices
    lower0, upper0 = bounds[idx0]
    lower1, upper1 = bounds[idx1]

    def _resolve_axis(center: float, lower: Optional[float], upper: Optional[float]) -> Tuple[float, float]:
        span = max(abs(center), 1.0)
        lo = lower if lower is not None else center - 3.0 * span
        hi = upper if upper is not None else center + 3.0 * span
        if hi <= lo:
            hi = lo + np.finfo(float).eps
        return lo, hi

    lower0, upper0 = _resolve_axis(theta_reference[idx0], lower0, upper0)
    lower1, upper1 = _resolve_axis(theta_reference[idx1], lower1, upper1)

    axis0 = np.linspace(lower0, upper0, surface_points)
    axis1 = np.linspace(lower1, upper1, surface_points)
    # grid rows correspond to axis1 (y-axis), columns to axis0 (x-axis) to match matplotlib.imshow
    grid = np.empty((axis1.size, axis0.size), dtype=float)

    base_theta = np.asarray(theta_reference, dtype=float)
    for i, value0 in enumerate(axis0):
        for j, value1 in enumerate(axis1):
            theta = base_theta.copy()
            theta[idx0] = value0
            theta[idx1] = value1
            try:
                evaluation = evaluator.evaluate(theta)
                grid[j, i] = evaluation.log_likelihood
            except Exception:  # pragma: no cover - diagnostics only
                grid[j, i] = np.nan

    return LikelihoodSurface(
        param_indices=indices,
        axis0=axis0,
        axis1=axis1,
        log_likelihood=grid,
    )


__all__ = [
    "ObjectiveTracker",
    "DynamicDisplay",
    "OptimisationMonitor",
    "evaluate_likelihood_surface_grid",
]
