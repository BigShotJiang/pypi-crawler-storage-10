"""Refactored modelFit toolbox public API."""

from .display import DynamicDisplay, evaluate_likelihood_surface_grid
from .fitting import fit_gaussian
from .priors import build_prior, PriorInfo
from .structures import (
    FitResult,
    FitMetrics,
    FitUncertainty,
    LikelihoodSurface,
    ParameterProfile,
)
from .uncertainty import approximate_hessian

__all__ = [
    "fit_gaussian",
    "DynamicDisplay",
    "build_prior",
    "PriorInfo",
    "FitResult",
    "FitMetrics",
    "FitUncertainty",
    "LikelihoodSurface",
    "ParameterProfile",
    "approximate_hessian",
    "evaluate_likelihood_surface_grid",
]
