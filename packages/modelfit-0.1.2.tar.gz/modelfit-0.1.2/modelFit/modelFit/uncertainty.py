"""Uncertainty quantification helpers for Gaussian model fitting."""

from __future__ import annotations

import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
from scipy.optimize import minimize

from .likelihoods import ObservationModelEvaluator
from .priors import PriorInfo
from .structures import FitUncertainty

LogSink = Optional[Callable[[str], None]]


def _log(logger: LogSink, message: str) -> None:
	if logger is None:
		return
	logger(message)


def approximate_hessian(
	func: Callable[[np.ndarray], float],
	theta: np.ndarray,
	eps: float = 1e-5,
) -> Optional[np.ndarray]:
	"""Numerically approximate the Hessian matrix via central differences."""

	theta = np.asarray(theta, dtype=float)
	n = theta.size
	eye = np.eye(n)
	hessian = np.zeros((n, n), dtype=float)

	f0 = func(theta)
	if not np.isfinite(f0):
		return None

	for i in range(n):
		step = eps * eye[i]
		f_plus = func(theta + step)
		f_minus = func(theta - step)
		if not (np.isfinite(f_plus) and np.isfinite(f_minus)):
			return None
		hessian[i, i] = (f_plus - 2.0 * f0 + f_minus) / (eps**2)

	for i in range(n):
		for j in range(i + 1, n):
			step_i = eps * eye[i]
			step_j = eps * eye[j]
			f_pp = func(theta + step_i + step_j)
			f_pm = func(theta + step_i - step_j)
			f_mp = func(theta - step_i + step_j)
			f_mm = func(theta - step_i - step_j)
			if not (np.isfinite(f_pp) and np.isfinite(f_pm) and np.isfinite(f_mp) and np.isfinite(f_mm)):
				return None
			value = (f_pp - f_pm - f_mp + f_mm) / (4.0 * eps**2)
			hessian[i, j] = value
			hessian[j, i] = value

	return hessian


def compute_hessian_uncertainty(
	estimate_uncertainty: bool,
	objective: Callable[[np.ndarray], float],
	theta: np.ndarray,
	hessian_eps: float,
	likelihood_distribution: str,
	prior_distribution: str,
	logger: LogSink,
) -> FitUncertainty:
	"""Approximate covariance and standard errors from the observed Hessian."""

	if not estimate_uncertainty:
		_log(logger, "Skipped covariance estimation at user request.")
		return FitUncertainty(covariance=None, standard_errors=None, method="none")

	_log(logger, "Estimating uncertainty via observed Hessian (workers=1).")

	if likelihood_distribution != "gaussian":
		_log(
			logger,
			"Warning: Hessian-based uncertainty with non-Gaussian likelihoods is an approximation; validate via simulation.",
		)
	if prior_distribution != "gaussian":
		_log(
			logger,
			"Warning: Non-Gaussian priors change posterior curvature; treat covariance estimates with caution.",
		)

	hessian = approximate_hessian(objective, theta, eps=hessian_eps)
	if hessian is None:
		_log(logger, "Failed to approximate Hessian; uncertainty estimates unavailable.")
		return FitUncertainty(covariance=None, standard_errors=None, method="hessian")

	try:
		covariance = np.linalg.inv(hessian)
	except np.linalg.LinAlgError:
		_log(logger, "Observed Hessian is singular; uncertainty estimates unavailable.")
		return FitUncertainty(covariance=None, standard_errors=None, method="hessian")

	standard_errors = np.sqrt(np.diag(covariance))
	_log(logger, "Computed covariance matrix and standard errors from the Hessian.")
	return FitUncertainty(covariance=covariance, standard_errors=standard_errors, method="hessian")


def _project_to_bounds(theta: np.ndarray, bounds: Optional[List[Tuple[Optional[float], Optional[float]]]]) -> np.ndarray:
	if bounds is None:
		return np.asarray(theta, dtype=float)

	projected = np.asarray(theta, dtype=float).copy()
	for idx, (lower, upper) in enumerate(bounds):
		if lower is not None and not math.isinf(lower):
			projected[idx] = max(projected[idx], lower)
		if upper is not None and not math.isinf(upper):
			projected[idx] = min(projected[idx], upper)
	return projected


def _prepare_initial_guesses(
	theta_start: np.ndarray,
	n_bootstrap: int,
	bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
	rng: np.random.Generator,
) -> np.ndarray:
	theta_start = np.asarray(theta_start, dtype=float).reshape(-1)
	jitter_scale = np.maximum(np.abs(theta_start), 1.0) * 0.05
	guesses = np.empty((n_bootstrap, theta_start.size), dtype=float)
	for iteration in range(n_bootstrap):
		jitter = rng.normal(scale=jitter_scale)
		candidate = theta_start + jitter
		guesses[iteration] = _project_to_bounds(candidate, bounds)
	return guesses


def _run_bootstrap_iteration(
	iteration: int,
	sample_indices: np.ndarray,
	theta_initial: np.ndarray,
	*,
	model_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
	x: np.ndarray,
	y: np.ndarray,
	bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
	options: Optional[Dict[str, Union[int, float]]],
	method: str,
	prior_info: PriorInfo,
	sigma_fn: Optional[Callable[[np.ndarray], float]],
	profile_sigma: bool,
	distribution: str,
	trials: Optional[np.ndarray],
) -> Tuple[bool, Optional[np.ndarray], Optional[str]]:
	x_sample = x[sample_indices]
	y_sample = y[sample_indices]
	trials_sample = trials[sample_indices] if trials is not None else None

	evaluator = ObservationModelEvaluator(
		model_fn,
		x_sample,
		y_sample,
		sigma_fn,
		profile_sigma,
		distribution,
		trials_sample,
	)

	def _objective(theta: np.ndarray) -> float:
		evaluation = evaluator.evaluate(theta)
		log_prior = prior_info.evaluate(theta)
		return -(evaluation.log_likelihood + log_prior)

	try:
		result = minimize(
			_objective,
			np.asarray(theta_initial, dtype=float),
			method=method,
			bounds=bounds,
			options=options,
		)
	except Exception as exc:  # pragma: no cover - defensive guard
		return False, None, f"Bootstrap iteration {iteration + 1} failed with error: {exc}"

	if not result.success or not np.all(np.isfinite(result.x)):
		message = result.message if isinstance(result.message, str) else str(result.message)
		return False, None, f"Bootstrap iteration {iteration + 1} failed to converge: {message}"

	estimate = _project_to_bounds(result.x, bounds)
	try:
		evaluator.evaluate(estimate)
	except Exception as exc:  # pragma: no cover - defensive guard
		return False, None, f"Bootstrap iteration {iteration + 1} produced invalid estimate: {exc}"

	return True, estimate, None


def _summarise_bootstrap(
	samples: np.ndarray,
	n_bootstrap: int,
	n_failures: int,
	*,
	parallel: bool,
	worker_count: int,
	requested_max_workers: Optional[int],
) -> FitUncertainty:
	n_success = samples.shape[0]
	covariance = np.cov(samples, rowvar=False) if n_success > 1 else None
	standard_errors = np.std(samples, axis=0, ddof=1) if n_success > 1 else None
	confidence_intervals = np.percentile(samples, [2.5, 97.5], axis=0).T if n_success > 0 else None
	return FitUncertainty(
		covariance=covariance,
		standard_errors=standard_errors,
		method="bootstrap",
		bootstrap_estimates=samples if n_success > 0 else None,
		confidence_intervals=confidence_intervals,
		extras={
			"n_bootstrap": n_bootstrap,
			"n_success": n_success,
			"n_failures": n_failures,
			"parallel": bool(parallel),
			"worker_count": worker_count,
			"requested_max_workers": requested_max_workers,
		},
	)


def compute_bootstrap_uncertainty(
	*,
	estimate_uncertainty: bool,
	model_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
	x: np.ndarray,
	y: np.ndarray,
	theta_start: np.ndarray,
	method: str,
	bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
	options: Optional[Dict[str, Union[int, float]]],
	prior_info: PriorInfo,
	sigma_fn: Optional[Callable[[np.ndarray], float]],
	profile_sigma: bool,
	distribution: str,
	trials: Optional[np.ndarray],
	n_bootstrap: int,
	bootstrap_seed: Optional[int],
	bootstrap_parallel: bool,
	bootstrap_max_workers: Optional[int],
	logger: LogSink,
) -> FitUncertainty:
	"""Estimate parameter uncertainty via nonparametric bootstrapping."""

	if not estimate_uncertainty:
		_log(logger, "Skipped uncertainty estimation at user request.")
		return FitUncertainty(covariance=None, standard_errors=None, method="none")

	if n_bootstrap <= 0:
		raise ValueError("`n_bootstrap` must be a positive integer when using bootstrap uncertainty.")

	x_arr = np.asarray(x, dtype=float)
	y_arr = np.asarray(y, dtype=float).reshape(-1)
	if x_arr.shape[0] != y_arr.shape[0]:
		raise ValueError("`x` and `y` must contain the same number of observations.")

	trials_arr: Optional[np.ndarray] = None
	if trials is not None:
		trials_arr = np.asarray(trials, dtype=float).reshape(-1)
		if trials_arr.shape[0] != y_arr.shape[0]:
			raise ValueError("`binomial_trials` must align with the number of observations in `y`.")

	theta_start = np.asarray(theta_start, dtype=float).reshape(-1)
	rng = np.random.default_rng(bootstrap_seed)
	index_matrix = rng.integers(0, y_arr.shape[0], size=(n_bootstrap, y_arr.shape[0]), dtype=int)
	initial_guesses = _prepare_initial_guesses(theta_start, n_bootstrap, bounds, rng)

	bootstrap_params: List[np.ndarray] = []
	failure_messages: List[str] = []
	n_failures = 0
	worker_count = 1

	def _collect_outcome(outcome: Tuple[bool, Optional[np.ndarray], Optional[str]]) -> None:
		nonlocal n_failures
		success, params, message = outcome
		if success and params is not None:
			bootstrap_params.append(params)
		else:
			n_failures += 1
			if message and len(failure_messages) < 5:
				failure_messages.append(message)

	if bootstrap_parallel and n_bootstrap > 1:
		max_workers = bootstrap_max_workers or min(n_bootstrap, os.cpu_count() or 1)
		worker_count = max_workers
		_log(
			logger,
			"Estimating uncertainty via bootstrap with {workers} worker(s) over {n} resamples.".format(
				workers=worker_count,
				n=n_bootstrap,
			),
		)
		try:
			with ThreadPoolExecutor(max_workers=max_workers) as executor:
				futures = {
					executor.submit(
						_run_bootstrap_iteration,
						iteration,
						index_matrix[iteration],
						initial_guesses[iteration],
						model_fn=model_fn,
						x=x_arr,
						y=y_arr,
						bounds=bounds,
						options=options,
						method=method,
						prior_info=prior_info,
						sigma_fn=sigma_fn,
						profile_sigma=profile_sigma,
						distribution=distribution,
						trials=trials_arr,
					): iteration
					for iteration in range(n_bootstrap)
				}
				for future in as_completed(futures):
					try:
						_collect_outcome(future.result())
					except Exception as exc:  # pragma: no cover - defensive guard
						_collect_outcome((False, None, str(exc)))
		except Exception as exc:  # pragma: no cover - defensive guard
			_log(logger, f"Bootstrap parallel execution failed, reverting to sequential mode: {exc}")
			bootstrap_params.clear()
			failure_messages.clear()
			n_failures = 0
			worker_count = 1
			bootstrap_parallel = False

	if not bootstrap_parallel or n_bootstrap == 1:
		_log(
			logger,
			"Estimating uncertainty via bootstrap with 1 worker over {n} resamples.".format(
				n=n_bootstrap,
			),
		)
		for iteration in range(n_bootstrap):
			outcome = _run_bootstrap_iteration(
				iteration,
				index_matrix[iteration],
				initial_guesses[iteration],
				model_fn=model_fn,
				x=x_arr,
				y=y_arr,
				bounds=bounds,
				options=options,
				method=method,
				prior_info=prior_info,
				sigma_fn=sigma_fn,
				profile_sigma=profile_sigma,
				distribution=distribution,
				trials=trials_arr,
			)
			_collect_outcome(outcome)

	if failure_messages:
		for message in failure_messages:
			_log(logger, f"Bootstrap warning: {message}")
		suppressed = n_failures - len(failure_messages)
		if suppressed > 0:
			_log(logger, f"Additional {suppressed} bootstrap iterations failed; details suppressed.")

	if not bootstrap_params:
		_log(logger, "Bootstrap failed to produce any successful resamples.")
		return FitUncertainty(
			covariance=None,
			standard_errors=None,
			method="bootstrap",
			extras={
				"n_bootstrap": n_bootstrap,
				"n_success": 0,
				"n_failures": n_bootstrap,
				"parallel": bool(bootstrap_parallel),
				"worker_count": worker_count,
				"requested_max_workers": bootstrap_max_workers,
			},
		)

	samples = np.vstack(bootstrap_params)
	_log(
		logger,
		"Computed bootstrap uncertainty with {success} successful resamples out of {total}.".format(
			success=samples.shape[0],
			total=n_bootstrap,
		),
	)
	return _summarise_bootstrap(
		samples,
		n_bootstrap,
		n_failures,
		parallel=bootstrap_parallel,
		worker_count=worker_count,
		requested_max_workers=bootstrap_max_workers,
	)


__all__ = [
	"approximate_hessian",
	"compute_bootstrap_uncertainty",
	"compute_hessian_uncertainty",
]

