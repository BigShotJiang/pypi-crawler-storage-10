"""Shim module exposing the refactored package at modelFit.modelFit."""

from .modelFit import *  # noqa: F401,F403 - re-export public API

try:
    from .modelFit import __all__ as _inner_all
except ImportError:  # pragma: no cover - safeguard during installation
    _inner_all = [name for name in globals() if not name.startswith("_")]

__all__ = list(_inner_all)
