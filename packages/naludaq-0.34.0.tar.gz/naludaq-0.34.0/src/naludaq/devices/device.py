class Device:
    """Base class for peripheral devices on the board."""
