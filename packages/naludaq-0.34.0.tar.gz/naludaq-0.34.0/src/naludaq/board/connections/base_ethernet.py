from naludaq.board.connections.base_connection import BaseConnection


class EthernetBaseConnection(BaseConnection):
    pass
