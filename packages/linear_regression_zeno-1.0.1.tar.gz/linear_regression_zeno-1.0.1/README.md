# package_name

`linear-regression-zeno` is a Python library for rockets

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket-zeno`.

```bash
pip install linear-regression-zeno
```

## Usage

```python
import package_name

# returns 'words'
package_name.module_name('word')

# returns 'geese'
package_name.module_name('goose')

# returns 'phenomenon'
package_name.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)