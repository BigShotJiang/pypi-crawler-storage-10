from setuptools import setup

setup(
   name='linear_regression_zeno', 
   version='1.0.1',
   author='Abderrahim Zineddine',
   author_email='z.abderrahim@esi-sba.dz',
   packages=['linear_regression'],               
   url='https://pypi.org/project/linear_regression_zeno/',
   license='LICENSE.txt',
   description='testing linear regression from scratch',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=[]               
)