# TigerODM (placeholder, setup.py)

This is a **placeholder** to reserve the `tigerodm` project name on PyPI.
Official releases with documentation and code will follow.

- Status: Planning
- Branding: **TigerODM** (PyPI normalizes to lowercase: project name is `tigerodm`)
- Contact: (add later)

> Please do not depend on this pre-release (`0.0.0a1`).
