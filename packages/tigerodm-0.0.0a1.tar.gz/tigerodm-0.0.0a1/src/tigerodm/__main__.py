def main():
    print("TigerODM placeholder (0.0.0a1) — official releases coming soon.")

if __name__ == "__main__":
    main()
