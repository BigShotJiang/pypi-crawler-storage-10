"""Configuration loader for Switch."""

from pathlib import Path

import yaml
from databricks.sdk import WorkspaceClient

from ..utils.common_utils import setup_logger
from ..utils.databricks_credentials import DatabricksCredentials
from .models import LakebridgeConfig, SwitchConfig

logger = setup_logger(__name__)


class SwitchConfigLoader:
    """Load Switch config from YAML file."""

    _DEFAULT_CONFIG_PATH = Path(__file__).parent.parent.parent.parent / "resources" / "switch_config.yml"

    @classmethod
    def load(cls, config_path: str | None = None) -> SwitchConfig:
        """Load Switch config from switch_config.yml or specified path.

        Args:
            config_path: Optional custom config file path. If None, uses default path.

        Returns:
            SwitchConfig instance. Returns empty instance if file not found or invalid.
        """
        path = Path(config_path) if config_path else cls._DEFAULT_CONFIG_PATH

        if not path.exists():
            logger.warning(f"Switch config file not found: {path}")
            return SwitchConfig()

        try:
            with open(path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
            config = config if config is not None else {}
            switch_config = SwitchConfig.from_dict(config)
            logger.info(f"Loaded Switch config from {path}:\n{switch_config}")
            return switch_config
        except (OSError, yaml.YAMLError) as e:
            logger.warning(f"Failed to load Switch config: {e}")
            return SwitchConfig()


class LakebridgeConfigLoader:
    """Load Lakebridge workspace configuration."""

    _DEFAULT_CONFIG_PATH_TEMPLATE = "/Workspace/Users/{user}/.lakebridge/config.yml"

    @classmethod
    def load(cls, config_path: str | None = None) -> LakebridgeConfig:
        """Load transpiler options from Lakebridge config.yml or specified path.

        Args:
            config_path: Optional custom config file path. If None, uses default user-specific path.

        Returns:
            LakebridgeConfig instance. Returns empty instance if file not found or invalid.
        """
        path = Path(config_path) if config_path else cls._get_default_config_path()

        if not path.exists():
            logger.warning(f"Lakebridge config file not found: {path}")
            return LakebridgeConfig()

        try:
            with open(path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
            config = config if config is not None else {}
            transpiler_options = config.get("transpiler_options", {})
            lakebridge_config = LakebridgeConfig.from_dict(transpiler_options)
            logger.info(f"Loaded Lakebridge config from {path}:\n{lakebridge_config}")
            return lakebridge_config
        except (OSError, yaml.YAMLError) as e:
            logger.warning(f"Failed to read Lakebridge config: {e}")
            return LakebridgeConfig()

    @classmethod
    def _get_default_config_path(cls) -> Path:
        """Get default Lakebridge config file path for current user."""
        creds = DatabricksCredentials()
        credentials = creds.get_host_and_token()
        w = WorkspaceClient(host=credentials["host"], token=credentials["token"])
        current_user = w.current_user.me().user_name
        return Path(cls._DEFAULT_CONFIG_PATH_TEMPLATE.format(user=current_user))
