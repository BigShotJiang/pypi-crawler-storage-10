from setuptools import setup, find_packages

setup(
    name="rocket-vuln3rator",
    version='1.0.0',
    author='Moha',
    description='Rocket module with circleRocket class and utility methods',
    packages=find_packages(),
    license='MIT',
)
