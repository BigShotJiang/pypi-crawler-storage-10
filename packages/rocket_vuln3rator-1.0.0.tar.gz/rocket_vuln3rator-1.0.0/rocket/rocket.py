import math

class Rocket:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def move_up(self, x_increment=0, y_increment=1):
        self.x += x_increment
        self.y += y_increment

    def __str__(self):
        return f"A Rocket positioned at ({self.x},{self.y})"
    
    def __repr__(self):
        return f"Rocket({self.x},{self.y})"

        
    
    def __eq__(self, other):
        return self.x == other.x and self.y == other.y
    
    def get_distance(self, other):
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
