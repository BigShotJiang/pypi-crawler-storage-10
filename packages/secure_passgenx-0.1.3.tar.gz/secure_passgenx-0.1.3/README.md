# secure_passgen

Basit bir Python şifre üretici ve hash hesaplayıcı kütüphanedir

## Kullanım
```python
from secure_passgenx import password_generator
password, hash_value = password_generator(12, "sha256", True, True, True, True)
print(password)
print(hash_value)
