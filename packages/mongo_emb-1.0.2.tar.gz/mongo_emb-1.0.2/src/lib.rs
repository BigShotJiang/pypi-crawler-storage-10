use pyo3::prelude::*;

mod helper_type_translator;
mod py_database;
mod py_rdb;
mod rdb;
mod tool;

use py_rdb::PyRdb;

use py_database::PyCollection;
use py_database::PyDatabase;

#[pymodule]
fn mongo_emb(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // m.add_function(wrap_pyfunction!(sum_as_string, m)?);
    m.add_class::<PyDatabase>()?;

    m.add_class::<PyCollection>()?;
    m.add_class::<PyRdb>()?;

    Ok(())
}
