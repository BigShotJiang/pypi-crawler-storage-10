Command-Line Interface
======================

.. click:: epiccli.main:cli
   :prog: epic
   :show-nested:
