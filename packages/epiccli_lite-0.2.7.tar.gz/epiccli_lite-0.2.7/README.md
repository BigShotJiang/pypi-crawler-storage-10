# EPIC CLI

This repository contains the command-line interface for the EPIC platform.

For full documentation, please see https://epiccli-lite.readthedocs.io/
