"""
Job
"""
import os
import time

from . import core
from . import task
from .scheduler import Scheduler, ThreadScheduler, JobScheduler
from .helpers import mkdir, serialize_kwargs, rmd

# We put these global variables here instead of core
# They are used as defaults
# This cannot be pickled and prevents pantarei to be imported!
# thread_scheduler = ThreadScheduler()
# job_scheduler = JobScheduler()
# if 'pantarei_jobs_limit' in os.environ:
#     job_scheduler.jobs_limit = int(os.environ['pantarei_jobs_limit'])
# if 'pantarei_verbose' in os.environ:
#     job_scheduler.verbose = True

class JobFailure(Exception):
    """Exception raised when a failed job is found in the session"""
    pass

def _load_yaml(path):
    with open(path) as fh:
        db = {}
        for line in fh:
            if len(line.strip()) == 0:
                print(f'warning: empty line in {fh}')
                continue
            key, value = line.split(':')
            db[key] = value
    return db


class Parallel:
    """
    Batch execution on distibuted memory environment (ex. scheduler)
    """
    # TODO: perhaps add backend argument to be passed to Scheduler?
    # This would make a more direct setup than via Schedulers
    #   job = Parallel(task, backend='process')
    # The only issue is that we must create a single scheduler
    # so we must use core singletons for this...
    # Another issue is that this will mix with task arguments.
    #
    # TODO: this interface is too complex, arguments are dispatched here and there.
    # We cannot think of wrapping each and single argument of Task.
    def __init__(self, task_or_func, tag="", clear_first=False,
                 scheduler=None, cores=1, wall_time=None, memory=None,
                 output=None, error=None, mode=None,
                 **kwargs):
        """

        :param task_or_func: the `Task` or function to execute
        :param tag: string to tag the task, relevant if `task_or_func` is a function
        :param clear_first: clear task cache and artifacts before execution, relevant if `task_or_func` is a function
        :param scheduler: the scheduler to use if `None` it will be auto-detected
        :param cores: number of cores to use
        :param wall_time: the maximum wall time
        :param output: output file
        :param error: error file
        :param memory: requested memory (RAM)

        """
        if not isinstance(task_or_func, task.Task):
            task_or_func = task.Task(task_or_func, tag=tag, clear_first=clear_first)
        else:
            assert len(tag) == 0, 'will not pass tag to Task'
            assert not clear_first, 'will not pass clear_first to Task'
        self.task = task_or_func
        self.scheduler = scheduler
        self.cores = cores
        self.wall_time = wall_time
        self.memory = memory
        self.output = output
        self.error = error
        self.mode = core.mode if mode is None else mode
        # Arguments for task (as keyword arguments only)
        self.kwargs = kwargs
        if self.scheduler is None:
            self.scheduler = core.scheduler

    @property
    def path(self):
        """Path to the cache of the job"""
        return os.path.join(self.task.cache.path, self.qualified_name())

    def name(self):
        """General name of job (independent of arguments)"""
        return self.task.name(**self.kwargs)

    def qualified_name(self):
        """Unique name of job"""
        return self.task.qualified_name(**self.kwargs)

    def pretty_name(self):
        """Pretty printed name of job (with args)"""
        args = []
        for key in self.kwargs:
            if self.task.ignore is not None:
                if key in self.task.ignore:
                    continue
            if isinstance(self.kwargs[key], str):
                args.append(f'{key}="{self.kwargs[key]}"')
            else:
                args.append(f'{key}={self.kwargs[key]}')
        kwargs = ','.join(args)
        return f'{self.task.name()}({kwargs})'

    def clear(self, **kwargs):
        """Clear undelrying task and its artifacts"""
        self.task.clear(self.task, **kwargs)
        # Clear job artifacts too
        rmd(self.path)

    # TODO: drop?
    def done(self, **kwargs):
        """Return True is Job is done"""
        # TODO: add condition on job execution
        if hasattr(self.task, 'done'):
            return self.task.done(**kwargs)
        return False

    @property
    def artifacts(self):
        """Job artifacts, possibly as a sequence"""
        return self.task.artifacts(**self.kwargs)

    @property
    def duration(self):
        """Current duration of job. If job is ended, return the elapsed duration"""
        import datetime
        job_file = os.path.join(self.path, 'job.yaml')
        if not os.path.exists(job_file):
            return datetime.timedelta(seconds=0)

        db = _load_yaml(job_file)
        if 'job_start' in db and 'job_end' in db:
            delta = float(db['job_end']) - float(db['job_start'])
        elif 'job_start' in db and 'job_fail' in db:
            delta = float(db['job_fail']) - float(db['job_start'])
        elif 'job_start' in db:
            delta = time.time() - float(db['job_start'])
        else:
            delta = 0
        return datetime.timedelta(seconds=int(delta))

    @property
    def state(self):
        """
        State of job.

        Possible values:
        - failed
        - ended
        - running
        - queued
        - unknown
        """
        job_file = os.path.join(self.path, 'job.yaml')
        if not os.path.exists(job_file):
            return ''
        else:
            db = _load_yaml(job_file)
            if 'job_fail' in db:
                return 'failed'
            elif 'job_end' in db:
                return 'ended'
            elif 'job_start' in db:
                # return 'started'
                return 'running'
            elif 'job_queue' in db:
                return 'queued'
            elif len(db) == 0:
                return 'unknown'
            else:
                raise ValueError(f'wrong state {list(db.keys())} in {self.path}')

    def __call__(self, **kwargs):
        # If no arguments are passed than we assume they were passed
        # to the constructor
        # TODO: not good, we should stick to one pattern
        if len(kwargs) > 0:
            self.kwargs = kwargs

        # Add this job qname to global list
        # TODO: this should be the Scheduler's responsibility? Revise.
        from pantarei import core
        core.jobs.append(self.qualified_name())

        # This is not properly done atm, but it should work. The
        # point is that without the line below, when the task is not
        # done, the wrapped job will not store its path anywhere, and
        # will be missing. Jobs that are not ended would be phantom
        from . import core
        # This looks duplicated in job and task...
        if self.task.cache._storage(self.qualified_name()) not in core._tasks:
            core._tasks.append(self.task.cache._storage(self.qualified_name()))
        # Check again
        assert self.mode in ['safe', 'brave', 'dry']

        # This was at the end, matching safe + ended
        # elif self.task.done(**self.kwargs):
        #     return self.task(**self.kwargs)

        # The execution modes are mutually exclusive, we check each
        # one independent of the others. This leads to some
        # redundance, but the switch will be more robust.
        results = None

        if self.mode == 'dry':
            # Get the results right away if done, but do not submit.
            # We do not do anything with failed jobs.
            if self.task.done(**self.kwargs):
                results = self.task(**self.kwargs)
            else:
                # Make sure that cache is setup anyway
                # This way the report will point to an existing path in cache
                # and rei ls can show even jobs that are not submitted yet.
                self.task._setup(**self.kwargs)

        elif self.mode == 'safe':
            # Get the results right away if done, else submit,
            # but stop at the first failure
            if self.task.done(**self.kwargs):
                results = self.task(**self.kwargs)
            elif self.state == 'failed':
                raise JobFailure(f'stop because of previous job failure {self.qualified_name()}')
            elif self.state in ['running', 'queued'] or self.scheduler.queued(self.qualified_name()):
                # If job is running or queued (ex. on a remote cluster), do nothing
                pass
            else:
                self.scheduler.submit(self.task, self.kwargs, self.wall_time, self.memory)

        elif self.mode == 'brave':
            # In brave mode we skip failed jobs
            if self.task.done(**self.kwargs):
                results = self.task(**self.kwargs)
            elif self.state == 'failed':
                # TODO: this should only be done if there are no deps
                print(f'WARNING: skipping failed job {self.qualified_name()}')
            elif self.state in ['running', 'queued'] or self.scheduler.queued(self.qualified_name()):
                # If job is running or queued (ex. on a remote cluster), do nothing
                pass
            else:
                self.scheduler.submit(self.task, self.kwargs, self.wall_time, self.memory)

        # We reset the arguments if they were passed to __call__
        if len(kwargs) > 0:
            self.kwargs = {}

        return results


class Job(Parallel):

    def __init__(self, task_or_func, tag="", clear_first=False, scheduler=None,
                 cores=1, wall_time=None, output=None, error=None, memory=None,
                 **kwargs):
        if scheduler is None:
            scheduler = core.scheduler
        assert isinstance(scheduler, JobScheduler)
        # TODO: what about jobs_limit?
        super().__init__(task_or_func, tag=tag, clear_first=clear_first,
                         scheduler=scheduler, cores=cores, wall_time=wall_time,
                         output=output, error=error, memory=memory, **kwargs)


class Thread(Parallel):

    def __init__(self, task_or_func, tag="", clear_first=False, scheduler=None, **kwargs):
        if scheduler is None:
            scheduler = core.scheduler
        assert isinstance(scheduler, ThreadScheduler), f'{scheduler}'
        super().__init__(task_or_func, tag=tag, clear_first=clear_first,
                         scheduler=scheduler, **kwargs)

