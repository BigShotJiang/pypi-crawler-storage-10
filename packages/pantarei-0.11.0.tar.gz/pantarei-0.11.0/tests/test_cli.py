import unittest
import os

import pantarei.cli as cli

class Test(unittest.TestCase):

    def setUp(self):
        self.script = ['script.py']
        with open('script.py', 'w') as fh:
            fh.write("""
import time
import pantarei as rei
def f(x):
   print('called')
   time.sleep(1)
   return x
job = rei.Parallel(f)
job(x=1.0)
job(x=2.0)
""")
        
    def test(self):
        cli.run(self.script)
        import time
        time.sleep(2)
        cli.ls(self.script, stats=True)
        cli.rm(self.script, recursive=True, force=True)
        cli.ls(self.script, stats=True)
        cli.cat(self.script)

    def tearDown(self):
        from pantarei.helpers import rmd
        import pantarei.core
        pantarei.core.scheduler.wait()
        rmd(pantarei.core.cache.path)

if __name__ == '__main__':
    unittest.main()
