"""Version file for deepnote-toolkit."""

__version__ = "1.0.0rc3"
