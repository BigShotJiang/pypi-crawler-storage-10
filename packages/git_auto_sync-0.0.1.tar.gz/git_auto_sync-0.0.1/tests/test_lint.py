import compileall
import subprocess
import sys
from pathlib import Path
import unittest


class TestLint(unittest.TestCase):
    def test_syntax_compile(self):
        # Ensure all python files compile
        root = Path(__file__).resolve().parents[1]
        ok = compileall.compile_dir(str(root), force=False, quiet=1)
        self.assertTrue(ok, "Some python files failed to compile")

    def test_ruff_if_available(self):
        # If ruff is installed in the environment, run it and expect no errors.
        try:
            res = subprocess.run([sys.executable, "-m", "ruff", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if res.returncode != 0:
                self.skipTest("ruff not available")
        except FileNotFoundError:
            self.skipTest("ruff not available")

        # Run ruff on the repo
        root = Path(__file__).resolve().parents[1]
        res = subprocess.run([sys.executable, "-m", "ruff", str(root)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.assertEqual(res.returncode, 0, f"ruff reported issues:\n{res.stdout}\n{res.stderr}")


if __name__ == "__main__":
    unittest.main()
