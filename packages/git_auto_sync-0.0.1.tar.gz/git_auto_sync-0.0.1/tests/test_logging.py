import unittest
import tempfile
from pathlib import Path
import subprocess
import sys


class TestLogging(unittest.TestCase):
    def test_log_file_created(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d) / "repos"
            base.mkdir()
            repo = base / "r1"
            repo.mkdir()
            (repo / ".git").mkdir()

            logf = Path(d) / "out.log"

            # Run the script with dry-run and log-file
            cmd = [sys.executable, "sync_repos.py", "--base", str(base), "--dry-run", "--log-file", str(logf)]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            # Process should exit normally
            self.assertEqual(res.returncode, 0)
            # Log file should exist and contain DRY RUN lines
            self.assertTrue(logf.exists())
            content = logf.read_text(encoding="utf-8")
            self.assertIn("DRY RUN", content)


if __name__ == "__main__":
    unittest.main()
