import unittest
from pathlib import Path
import tempfile

from sync_repos import is_git_repo, sync_repo, read_config, list_repos


class TestSyncRepos(unittest.TestCase):
    def test_is_git_repo_false(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "notrepo"
            p.mkdir()
            self.assertFalse(is_git_repo(p))

    def test_is_git_repo_true_by_dotgit(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "repo"
            p.mkdir()
            (p / ".git").mkdir()
            self.assertTrue(is_git_repo(p))

    def test_sync_repo_dry_run(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "repo"
            p.mkdir()
            (p / ".git").mkdir()
            r = sync_repo(p, dry_run=True)
            self.assertTrue(r.get("dry_run"))
            self.assertIn("commands", r)

    def test_list_repos(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            for name in ("a", "b", "file.txt"):
                p = base / name
                if name.endswith(".txt"):
                    p.write_text("x")
                else:
                    p.mkdir()
            items = list_repos(base)
            self.assertEqual(len([x for x in items if x.is_dir()]), 2)

    def test_read_config(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = Path(d) / "cfg.json"
            cfg.write_text('{"base_path": "./repos"}')
            loaded = read_config(cfg)
            self.assertIn("base_path", loaded)


if __name__ == "__main__":
    unittest.main()
