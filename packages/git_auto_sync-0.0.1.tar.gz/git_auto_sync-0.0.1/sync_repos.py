"""git-auto-sync: pull latest changes for git repositories under a folder.

Functions:
 - read_config(path) -> dict
 - list_repos(base_path) -> list[Path]
 - is_git_repo(path) -> bool
 - sync_repo(path, dry_run=False) -> CompletedProcess-like dict

Also provides a small CLI.
"""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List


def read_config(path: Path) -> Dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def list_repos(base_path: Path) -> List[Path]:
    base = Path(base_path)
    if not base.exists() or not base.is_dir():
        raise NotADirectoryError(f"Base path is not a directory: {base}")
    return [p for p in base.iterdir() if p.is_dir()]


def is_git_repo(path: Path) -> bool:
    # Quick check: presence of .git directory or file
    p = Path(path)
    git_dir = p / ".git"
    if git_dir.exists():
        return True
    # Fallback: try git rev-parse
    try:
        subprocess.run(["git", "-C", str(p), "rev-parse", "--is-inside-work-tree"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except Exception:
        return False


def _run_git_command(cmd: List[str]):
    # Wrap subprocess.run to return a dict-like result for easier mocking/testing
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return {"returncode": res.returncode, "stdout": res.stdout, "stderr": res.stderr}


def sync_repo(path: Path, dry_run: bool = False) -> Dict:
    p = Path(path)
    if not is_git_repo(p):
        return {"path": str(p), "skipped": True, "reason": "not a git repository"}

    commands = [
        ["git", "-C", str(p), "fetch", "--all"],
        ["git", "-C", str(p), "pull"],
    ]

    if dry_run:
        return {"path": str(p), "dry_run": True, "commands": commands}

    results = []
    for cmd in commands:
        results.append({"cmd": cmd, **_run_git_command(cmd)})

    return {"path": str(p), "dry_run": False, "results": results}


def main(argv=None):
    parser = argparse.ArgumentParser(description="Pull latest changes for git repos under a folder")
    parser.add_argument("--config", "-c", default="config.json", help="Path to JSON config file")
    parser.add_argument("--base", "-b", help="Override base path from config")
    parser.add_argument("--dry-run", action="store_true", help="Do not run git commands, only show what would run")
    parser.add_argument("--log-file", help="Optional path to a log file to write logs to")
    parser.add_argument("--workers", "-j", type=int, default=4, help="Parallel workers")
    args = parser.parse_args(argv)

    # Configure logging
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root_logger.handlers = [sh]
    if args.log_file:
        fh = logging.FileHandler(args.log_file, encoding="utf-8")
        fh.setFormatter(fmt)
        root_logger.addHandler(fh)

    cfg = read_config(Path(args.config))
    base = Path(args.base) if args.base else Path(cfg.get("base_path"))

    repos = list_repos(base)

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = {ex.submit(sync_repo, repo, args.dry_run): repo for repo in repos}
        for fut in as_completed(futures):
            try:
                results.append(fut.result())
            except Exception as e:
                results.append({"path": str(futures[fut]), "error": str(e)})

    # Log output
    logger = logging.getLogger(__name__)
    for r in results:
        if r.get("skipped"):
            logger.info("SKIP: %s (%s)", r['path'], r.get('reason'))
        elif r.get("dry_run"):
            logger.info("DRY RUN: %s", r['path'])
            for cmd in r.get("commands", []):
                logger.info("   %s", " ".join(cmd))
        elif r.get("results"):
            logger.info("UPDATED: %s", r['path'])
            for item in r["results"]:
                rc = item.get("returncode", 1)
                if rc == 0:
                    logger.info("   OK: %s", " ".join(item['cmd']))
                else:
                    logger.error("   FAIL: %s\n     stderr: %s", " ".join(item['cmd']), item.get('stderr'))
        else:
            logger.info("INFO: %s", r)


if __name__ == "__main__":
    main()
