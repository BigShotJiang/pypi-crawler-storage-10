# git-auto-sync

Small Python tool to pull the latest changes for all git repositories under a configured folder.

Quick start

1. Edit `config.json` and set `base_path` to the folder that contains your repositories.
2. Run:

```powershell
python sync_repos.py --config config.json
```

Options:
- `--base` override the `base_path` in the config
- `--dry-run` show commands without executing
- `--workers N` run up to N repos in parallel (default 4)
 - `--log-file PATH` optionally write logs to a file as well as the console
