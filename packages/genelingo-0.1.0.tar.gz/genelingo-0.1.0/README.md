 GeneLingo 🧬

GeneLingo is a Python library developed by Sarah for visualizing genetic mutations in an intuitive way. It allows you to compare reference and mutated sequences, detect SNPs, insertions, deletions, and display them as colored boxes for easy interpretation.

1- Features


- Compare reference and mutated DNA sequences  
- Detect SNPs, insertions, and deletions  
- Manual mutation entry  
- Visualize sequences with colored boxes:

| Base / Mutation | Color   |
|-----------------|---------|
| A               | Green   |
| T               | Blue    |
| G               | Red     |
| C               | Yellow  |
| SNP             | Orange  |
| Deletion (DEL)  | Black   |
| Insertion (INS) | Purple  |


2- Installation

Install GeneLingo directly via pip:

```bash
pip install genelingo
Make sure you have the dependencies installed (Biopython and Matplotlib):

pip install biopython matplotlib

3- Usage:

Here's a simple example:

from genelingo import load_fasta, compare_sequences, apply_manual_mutations, draw_sequence

# Load sequences
ref_seq = load_fasta("reference.fasta")
mut_seq = load_fasta("mutated.fasta")

# Compare sequences
displayed_seq, report = compare_sequences(ref_seq, mut_seq)

# Apply manual mutations
manual_mutations = ["A5G", "Δ10", "+12"]
displayed_seq, manual_report = apply_manual_mutations(displayed_seq, manual_mutations)

# Visualize
draw_sequence(displayed_seq)

# Print mutation report
for line in report + manual_report:
    print(line)

4- Example Visualization

Here's an example of how GeneLingo displays mutations:

![GeneLingo Example](images/gen.png)



5- Contributing

Contributions are welcome! Feel free to open issues or submit pull requests to improve GeneLingo.

6- License

This project is licensed under the MIT License.