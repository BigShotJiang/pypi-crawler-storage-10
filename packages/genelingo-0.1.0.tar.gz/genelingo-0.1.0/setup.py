from setuptools import setup, find_packages

setup(
    name="genelingo",
    version="0.1.0",
    author="Sarah Ali",
    author_email="alsayedsarah01@gmail.com",
    description="Visualize DNA mutations with colored boxes",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/genelingo",
    packages=find_packages(),
    install_requires=[
        "biopython",
        "matplotlib"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)

