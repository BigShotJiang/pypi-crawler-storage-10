from Bio import SeqIO
import matplotlib.pyplot as plt

BASE_COLORS = {
    "A": "green", "T": "blue", "G": "red", "C": "yellow",
    "SNP": "orange", "DEL": "black", "INS": "purple"
}

def load_fasta(file_path):
    for record in SeqIO.parse(file_path, "fasta"):
        return list(str(record.seq).upper())
    return []

def compare_sequences(ref_seq, mut_seq):
    max_len = max(len(ref_seq), len(mut_seq))
    ref_seq_extended = ref_seq + ["-"] * (max_len - len(ref_seq))
    mut_seq_extended = mut_seq + ["-"] * (max_len - len(mut_seq))

    displayed_seq = []
    mutation_report = []

    for i, (r, m) in enumerate(zip(ref_seq_extended, mut_seq_extended)):
        if r == m:
            displayed_seq.append(m)
        elif m == "-":
            displayed_seq.append("DEL")
            mutation_report.append(f"Deletion at position {i+1}")
        elif r == "-":
            displayed_seq.append("INS")
            mutation_report.append(f"Insertion at position {i+1}")
        else:
            displayed_seq.append("SNP")
            mutation_report.append(f"SNP {r}→{m} at position {i+1}")

    return displayed_seq, mutation_report

def apply_manual_mutations(seq, mutations):
    report = []
    for mut in mutations:
        try:
            if mut.startswith("Δ"):
                pos = int(mut[1:]) - 1
                seq[pos] = "DEL"
                report.append(f"Deletion at position {pos+1}")
            elif mut.startswith("+"):
                pos = int(mut[1:]) - 1
                seq.insert(pos, "INS")
                report.append(f"Insertion at position {pos+1}")
            else:
                base_from = mut[0]
                pos = int(mut[1:-1]) - 1
                base_to = mut[-1]
                seq[pos] = "SNP"
                report.append(f"SNP {base_from}→{base_to} at position {pos+1}")
        except Exception as e:
            report.append(f"Error applying mutation {mut}: {e}")
    return seq, report

def draw_sequence(seq, blocks_per_row=50):
    fig, ax = plt.subplots(figsize=(20, 5))
    block_size = 1
    padding = 0.1

    for i, base in enumerate(seq):
        color = BASE_COLORS.get(base, "gray")
        row = i // blocks_per_row
        col = i % blocks_per_row
        rect = plt.Rectangle(
            (col * (block_size + padding), -row * (block_size + padding)),
            block_size, block_size, facecolor=color, edgecolor="black"
        )
        ax.add_patch(rect)
        ax.text(
            col * (block_size + padding) + block_size/2,
            -row * (block_size + padding) + block_size/2,
            base, ha='center', va='center', fontsize=8, color='white'
        )

    ax.set_xlim(0, blocks_per_row * (block_size + padding))
    ax.set_ylim(-((len(seq) // blocks_per_row + 1) * (block_size + padding)), 1)
    ax.axis('off')
    plt.show()
