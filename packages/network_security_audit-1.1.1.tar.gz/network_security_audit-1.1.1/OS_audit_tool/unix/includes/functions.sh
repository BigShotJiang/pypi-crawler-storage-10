### Functions ###

## ANSI 코드
RED=$'\e[1;31m'         # BOLD + RED
GREEN=$'\e[1;32m'       # BOLD + GREEN
BOLD=$'\e[1m'           # BOLD
RESET=$'\e[0m'          # 원래 글씨로 전환

## 화면에 출력한 내용 그대로 log 파일로 저장
log() {
    printf '%s\n' "$*" | tee -a "$LOGFILE"
}

## 표준 에러로 출력 후 log 파일에 저장
err() {
    printf "${RED}[ERROR] %s${RESET}\n" "$*" | tee -a "$LOGFILE" >&2
}

## 백업 파일 생성 EX: /etc/securetty -> /etc/securetty.bak.20250829-000000
backup() {
    local src="$1"
    local ts
    ts=$(date '+%Y%m%d-%H%M%S')
    local name="${src}.bak.${ts}"

    if [ -f "$src" ]; then
        cp -p "$src" "$name"
        log "$BOLD[BACKUP]$RESET $src -> $name"
    else
        log "$BOLD[BACKUP]$RESET $src no backup"        # 파일이 아니면 백업 없음
    fi
}

## U-37: Apache AllowOverride AuthConfig 보안 점검 및 조치
U-37() {
    local TS="$(date '+%Y-%m-%dT%H:%M:%S%z')"         # 점검 실행 날짜(KST) EX: 2025-08-29T00:00:00+0900
    local DIR="$(cd "$(dirname "$0")" && pwd)"        # 점검 스크립트가 위치한 경로
    local LOGFILE="$DIR/logs/U-37.log"             # 로그 파일 저장 경로 및 파일명
    local JSON="$DIR/reports/U-37.json"            # 결과 파일 저장 경로 및 파일명(json형식)

    mkdir -p "$(dirname "$LOGFILE")" "$(dirname "$JSON")"       # 로그, 결과 파일의 상위 디렉터리가 없으면 생성

    ## 점검 할 파일 명
    local APACHE_CONFIG="/etc/apache2/apache2.conf"

    ## 서비스 활성화 여부 및 AuthConfig 설정 여부 플래그
    local APACHE_ACTIVE="no"
    local ALLOWOVERRIDE_AUTHCONFIG="no"

    ## 보안 점검 시 탐색 후, 수정 후 PASS/FAIL 기록
    local DETECT_STATUS="FAIL"
    local REMEDIATE_STATUS="FAIL"

    log "$BOLD============= [U-37] Apache Security Assessment =============$RESET"
    log "$BOLD[INFO]$RESET Apache assessment files: $APACHE_CONFIG"

    ## TCP/80번 또는 443번 포트 LISTENING이면 Apache 서비스 활성화로 판단
    if ss -ltn '( sport = :80 or sport = :443 )' 2>/dev/null | grep -q .; then
        APACHE_ACTIVE="yes"
    fi

    if [ "$APACHE_ACTIVE" = "yes" ]; then
        ## AllowOverride 지시자에서 AuthConfig 옵션이 설정되어 있는지 확인
        ## 주석이 아닌 AllowOverride 설정 중 AuthConfig를 포함하는 경우 취약으로 판단
        if [ -r "$APACHE_CONFIG" ] && \
            grep -Eq '^[[:space:]]*AllowOverride[[:space:]]+' "$APACHE_CONFIG" | \
            grep -v '^[[:space:]]*#' | \
            grep -iq 'AuthConfig'; then
            ALLOWOVERRIDE_AUTHCONFIG="yes"
        else
            ALLOWOVERRIDE_AUTHCONFIG="no"
        fi
    fi

    ## Apache가 비활성화 상태이거나 AuthConfig가 비활성화 상태면 PASS
    if [ "$APACHE_ACTIVE" = "no" ] || [ "$ALLOWOVERRIDE_AUTHCONFIG" = "no" ]; then
        DETECT_STATUS="PASS"
    fi

    log "------------- Detect Result -------------"
    log "$BOLD[RESULT]$RESET Apache activation: $APACHE_ACTIVE"
    log "$BOLD[RESULT]$RESET AllowOverride AuthConfig enabled: $ALLOWOVERRIDE_AUTHCONFIG"
    log "------------------------------------"

    ## 탐지 결과 임시 저장
    local BF_ALLOWOVERRIDE_AUTHCONFIG=$ALLOWOVERRIDE_AUTHCONFIG

    if [ "$DETECT_STATUS" = "FAIL" ]; then
        if [ "$ALLOWOVERRIDE_AUTHCONFIG" = "yes" ]; then
            backup "$APACHE_CONFIG"

            ## AllowOverride 지시자에서 AuthConfig를 제거하고 None으로 설정
            ## Directory 블록 내의 AllowOverride 설정을 찾아서 None으로 변경
            sed -i 's/^\([[:space:]]*AllowOverride[[:space:]]\+\).*AuthConfig.*/\1None/' "$APACHE_CONFIG"
            log "$GREEN[RESULT] $APACHE_CONFIG: Changed AllowOverride to None$RESET"
            ALLOWOVERRIDE_AUTHCONFIG="no"

            ## 수정 후 재확인
            local ALLOW_OVERRIDE_CHECK=$(grep -E '^\s*AllowOverride\s+' "$APACHE_CONFIG" | grep -v '^\s*#' | grep -i 'AuthConfig')

            if [ -z "$ALLOW_OVERRIDE_CHECK" ]; then
                REMEDIATE_STATUS="PASS"
            fi
        fi
    else
        log "$BOLD[RESULT] AllowOverride is already set to None.$RESET"
        REMEDIATE_STATUS="PASS"
    fi

    cat > "$JSON" <<EOF
{
  "date": "$TS",
  "control_family": "3. Service Management > 3.19 Web Service",
  "check_target": "Restrict directory access control using \".\" notation",
  "discussion": "Good: When moving using the upper path is not permitted to anyone.\\nVulnerable: When moving using the upper path is permitted, unauthorized users with access may be able to bypass restrictions and access important files or data with malicious intent.",
  "check_content": "Confirm that the AllowOverride directive's AuthConfig option is set in httpd.conf file located in each directory\\n#vi /[Apache_home]/conf/httpd.conf\\nAllowOverride None",
  "fix_text": "[SOLARIS, LINUX, AIX, HP-UX]\\nStep 1) Open /[Apache_home]/conf/httpd.conf with vi editor\\nStep 2) Set AuthConfig option in AllowOverride directive for all set directories\\n(Remediation before) AllowOverride None directive is set for AuthConfig option\\n<Directory \\\"/usr/local/apache2/htdocs\\\">\\n    AllowOverride None\\n    Allow from all\\n</Directory>",
  "payload": {
    "severity": "medium",
    "port": [80, 443],
    "service": ["apache", "httpd"],
    "protocol": "TCP",
    "threat": ["Directory Traversal", "Unauthorized Access", "Information Disclosure"],
    "TTP": ["T1190", "T1083", "T1078"],
    "files_checked": ["$APACHE_CONFIG"]
  },
  "results": [
    {
      "phase": "detect",
      "status": "$DETECT_STATUS",
      "apache_active": "$APACHE_ACTIVE",
      "allowoverride_authconfig": "$BF_ALLOWOVERRIDE_AUTHCONFIG"
    },
    {
      "phase": "remediate",
      "status": "$REMEDIATE_STATUS",
      "apache_active": "$APACHE_ACTIVE",
      "allowoverride_authconfig": "$ALLOWOVERRIDE_AUTHCONFIG"
    }
  ]
}
EOF

    log "$BOLD============= [U-37] Assessment Complete =============$RESET"
}

## U-39: Apache FollowSymLinks 보안 점검 및 조치
U-39() {
    local TS="$(date '+%Y-%m-%dT%H:%M:%S%z')"         # 점검 실행 날짜(KST) EX: 2025-08-29T00:00:00+0900
    local DIR="$(cd "$(dirname "$0")" && pwd)"        # 점검 스크립트가 위치한 경로
    local LOGFILE="$DIR/logs/U-39.log"             # 로그 파일 저장 경로 및 파일명
    local JSON="$DIR/reports/U-39.json"            # 결과 파일 저장 경로 및 파일명(json형식)

    mkdir -p "$(dirname "$LOGFILE")" "$(dirname "$JSON")"       # 로그, 결과 파일의 상위 디렉터리가 없으면 생성

    ## 점검 할 파일 명
    local APACHE_CONFIG="/etc/apache2/apache2.conf"

    ## 서비스 활성화 여부 및 FollowSymLinks 설정 여부 플래그
    local APACHE_ACTIVE="no"
    local FOLLOWSYMLINKS_ENABLED="no"

    ## 보안 점검 시 탐색 후, 수정 후 PASS/FAIL 기록
    local DETECT_STATUS="FAIL"
    local REMEDIATE_STATUS="FAIL"

    log "$BOLD============= [U-39] Apache Security Assessment =============$RESET"
    log "$BOLD[INFO]$RESET Apache assessment files: $APACHE_CONFIG"

    ## TCP/80번 또는 443번 포트 LISTENING이면 Apache 서비스 활성화로 판단
    if ss -ltn '( sport = :80 or sport = :443 )' 2>/dev/null | grep -q .; then
        APACHE_ACTIVE="yes"
    fi

    if [ "$APACHE_ACTIVE" = "yes" ]; then
        ## Options 지시자에서 FollowSymLinks 옵션이 설정되어 있는지 확인
        ## 주석이 아닌 Options 설정 중 FollowSymLinks를 포함하는 경우 취약으로 판단
        if [ -r "$APACHE_CONFIG" ] && \
            grep -Ev '^[[:space:]]*#' "$APACHE_CONFIG" | \
            grep -Eq '^[[:space:]]*Options[[:space:]]+.*FollowSymLinks'; then
            FOLLOWSYMLINKS_ENABLED="yes"
        else
            FOLLOWSYMLINKS_ENABLED="no"
        fi
    fi

    ## Apache가 비활성화 상태이거나 FollowSymLinks가 비활성화 상태면 PASS
    if [ "$APACHE_ACTIVE" = "no" ] || [ "$FOLLOWSYMLINKS_ENABLED" = "no" ]; then
        DETECT_STATUS="PASS"
    fi

    log "------------- Detect Result -------------"
    log "$BOLD[RESULT]$RESET Apache activation: $APACHE_ACTIVE"
    log "$BOLD[RESULT]$RESET FollowSymLinks enabled: $FOLLOWSYMLINKS_ENABLED"
    log "------------------------------------"

    ## 탐지 결과 임시 저장
    local BF_FOLLOWSYMLINKS_ENABLED=$FOLLOWSYMLINKS_ENABLED

    if [ "$DETECT_STATUS" = "FAIL" ]; then
        if [ "$FOLLOWSYMLINKS_ENABLED" = "yes" ]; then
            backup "$APACHE_CONFIG"

            ## Options 지시자에서 FollowSymLinks를 제거
            ## Directory 블록 내의 Options 설정을 찾아서 FollowSymLinks 제거
            sed -i 's/^\([[:space:]]*Options[[:space:]]\+\)\(.*\)FollowSymLinks\(.*\)/\1\2\3/' "$APACHE_CONFIG"
            log "$GREEN[RESULT] $APACHE_CONFIG: Removed FollowSymLinks from Options$RESET"
            FOLLOWSYMLINKS_ENABLED="no"

            ## 수정 후 재확인
            local FOLLOWSYMLINKS_CHECK=$(grep -Ev '^[[:space:]]*#' "$APACHE_CONFIG" | grep -E '^[[:space:]]*Options[[:space:]]+.*FollowSymLinks')

            if [ -z "$FOLLOWSYMLINKS_CHECK" ]; then
                REMEDIATE_STATUS="PASS"
            fi
        fi
    else
        log "$BOLD[RESULT] FollowSymLinks is not enabled or Apache is not active.$RESET"
        REMEDIATE_STATUS="PASS"
    fi

    cat > "$JSON" <<EOF
{
  "date": "$TS",
  "control_family": "3. Service Management > 3.21 Web Service Symbolic Link Restriction",
  "check_target": "Restrict symbolic link and aliases usage",
  "discussion": "Good: When symbolic link and aliases usage is restricted to prevent unauthorized file access.\\nVulnerable: When unnecessary symbolic link and aliases usage is permitted, unauthorized users can discover and access important system files or data with malicious intent.",
  "check_content": "Confirm that FollowSymLinks option is NOT set in Options directive of httpd.conf file located in each directory\\n#vi /[Apache_home]/conf/httpd.conf\\nOptions Indexes FollowSymLinks",
  "fix_text": "[SOLARIS, LINUX, AIX, HP-UX]\\nStep 1) Open /[Apache_home]/conf/httpd.conf with vi editor\\nStep 2) Remove FollowSymLinks option from Options directive for all set directories\\n(Before) Options Indexes FollowSymLinks\\n(After) Options Indexes",
  "payload": {
    "severity": "medium",
    "port": [80, 443],
    "service": ["apache", "httpd"],
    "protocol": "TCP",
    "threat": ["Directory Traversal", "Unauthorized Access", "Information Disclosure"],
    "TTP": ["T1190", "T1083", "T1078"],
    "files_checked": ["$APACHE_CONFIG"]
  },
  "results": [
    {
      "phase": "detect",
      "status": "$DETECT_STATUS",
      "apache_active": "$APACHE_ACTIVE",
      "followsymlinks_enabled": "$BF_FOLLOWSYMLINKS_ENABLED"
    },
    {
      "phase": "remediate",
      "status": "$REMEDIATE_STATUS",
      "apache_active": "$APACHE_ACTIVE",
      "followsymlinks_enabled": "$FOLLOWSYMLINKS_ENABLED"
    }
  ]
}
EOF

    log "$BOLD============= [U-39] Assessment Complete =============$RESET"
}