# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a cross-platform security auditing framework that performs automated security assessments on Unix/Linux and Windows systems. The framework detects security vulnerabilities, automatically remediates them, and generates structured JSON reports with detailed findings.

## Running the Auditor

### Execute Full Audit
```bash
python3 run.py
```

The launcher (`run.py`) detects the operating system and shell type, then dispatches to the appropriate audit script:
- **Unix/Linux**: Executes `unix/audit.sh` (supports bash/zsh/sh)
- **Windows**: Executes `windows/audit.ps1` (PowerShell only)

### Run Specific Security Checks

**Unix/Linux:**
```bash
cd unix
source ./includes/functions.sh
U-37  # Apache AllowOverride AuthConfig check
U-39  # Apache FollowSymLinks check
```

Each check function can be invoked independently after sourcing `functions.sh`.

## Architecture

### Cross-Platform Design
The codebase uses a dispatching architecture where `run.py` acts as a platform-agnostic entry point that:
1. Detects OS type (Windows/Linux)
2. Identifies the parent shell process
3. Routes to platform-specific audit scripts with appropriate shell interpreters

### Unix/Linux Architecture

**Entry Point**: `unix/audit.sh`
- Sources shared functions from `unix/includes/functions.sh`
- Calls individual security check functions (e.g., `U-37`, `U-39`)

**Shared Functions** (`unix/includes/functions.sh`):
- `log()`: Outputs to stdout and writes to `$LOGFILE` simultaneously
- `err()`: Writes error messages to stderr and log file (red formatting)
- `backup()`: Creates timestamped backups of files before modification (format: `filename.bak.YYYYMMDD-HHMMSS`)
- `U-XX()`: Individual security check functions that follow a standardized pattern

**Security Check Pattern**:
Each check function (e.g., `U-37`, `U-39`) follows this workflow:
1. **Setup**: Initialize variables (timestamp, log path, JSON report path, config file paths)
2. **Detect**: Check if service is active (via `ss` port listening) and identify vulnerability
3. **Remediate**: If vulnerable, backup config file and apply fix using `sed`
4. **Verify**: Re-check configuration after remediation
5. **Report**: Generate structured JSON report with detect/remediate results

**Output Structure**:
- Logs: `unix/logs/U-XX.log` (human-readable audit trail)
- Reports: `unix/reports/U-XX.json` (structured findings with MITRE ATT&CK TTPs)

### Windows Architecture

**Entry Point**: `windows/audit.ps1`
- PowerShell-based auditing framework (structure mirrors Unix design)
- Output: `windows/reports/` directory

### Report Schema

JSON reports follow a standardized structure:
```json
{
  "date": "ISO 8601 timestamp",
  "control_family": "Security control category",
  "check_target": "Brief description of what is being checked",
  "discussion": "Good vs Vulnerable state explanation",
  "check_content": "Manual verification steps",
  "fix_text": "Detailed remediation instructions",
  "payload": {
    "severity": "low|medium|high|critical",
    "port": [array of affected ports],
    "service": [array of service names],
    "protocol": "TCP|UDP",
    "threat": [array of threat types],
    "TTP": [array of MITRE ATT&CK technique IDs],
    "files_checked": [array of configuration file paths]
  },
  "results": [
    {
      "phase": "detect|remediate",
      "status": "PASS|FAIL",
      "...": "check-specific state flags"
    }
  ]
}
```

## Adding New Security Checks

### Unix/Linux Checks

1. **Add function to `unix/includes/functions.sh`**:
   - Follow the naming convention `U-XX()` where XX is the check number
   - Use the existing pattern: setup → detect → remediate → verify → report
   - Define these local variables:
     - `TS`: Timestamp in ISO 8601 format
     - `DIR`: Script directory path
     - `LOGFILE`: `$DIR/logs/U-XX.log`
     - `JSON`: `$DIR/reports/U-XX.json`
   - Use `log()` for informational output and `err()` for errors
   - Call `backup()` before modifying any configuration files

2. **Register in `unix/audit.sh`**:
   - Add function call `U-XX` to the audit sequence

3. **Key implementation details**:
   - Service detection typically uses `ss -ltn` for port listening checks
   - Configuration parsing uses `grep -E` with proper escaping for regex patterns
   - Always filter out commented lines with `grep -v '^[[:space:]]*#'`
   - Remediation uses `sed -i` for in-place file editing
   - Verify remediation by re-running detection logic after changes

### Windows Checks

Add checks to `windows/audit.ps1` following the same detect-remediate-report pattern.

## Important Conventions

- **Shell Compatibility**: Unix scripts use `/bin/zsh` shebang but are compatible with bash/sh
- **Korean Comments**: Code includes Korean language comments (코드, 화면, 파일 등)
- **ANSI Colors**: Defined at top of `functions.sh` (RED, GREEN, BOLD, RESET)
- **Backup Safety**: All file modifications must be preceded by `backup()` call
- **Log Atomicity**: Use `log()` instead of `echo` to ensure console and file sync
- **Status Values**: Always use "PASS"/"FAIL" for status, "yes"/"no" for boolean flags

## Current Security Checks

- **U-37**: Apache `AllowOverride AuthConfig` restriction (prevents directory traversal via `.htaccess`)
- **U-39**: Apache `FollowSymLinks` restriction (prevents symbolic link exploitation)

Both checks target Apache web server configurations (`/etc/apache2/apache2.conf`) and only activate when ports 80/443 are listening.
