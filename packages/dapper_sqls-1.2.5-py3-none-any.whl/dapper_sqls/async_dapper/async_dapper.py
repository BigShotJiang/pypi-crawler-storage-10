# coding: utf-8
from .._types import  T
from ..config import Config
from ..models import Result, LoadJoin
from typing import Type, overload
from .async_executors import AsyncQuery, AsyncStored

class AsyncDapper(object):

    def __init__(self,  server: str , database : str , username : str, password : str, sql_version : int = None, api_environment = False, default_attempts = 1, default_wait_timeout = 2):
        self._config = Config(server, database, username, password, sql_version, api_environment, default_attempts, default_wait_timeout)
        
    async def query(self, attempts : int = None, wait_timeout : int = None):
        attempts = attempts if attempts else self.config.default_attempts
        wait_timeout = wait_timeout if wait_timeout else self.config.default_wait_timeout
        return AsyncQuery(self.config.connectionStringDataQuery.get(), attempts, wait_timeout, self._config.sql_version, self._config.api_environment)

    async def stored(self, attempts : int = None, wait_timeout : int = None):
        attempts = attempts if attempts else self.config.default_attempts
        wait_timeout = wait_timeout if wait_timeout else self.config.default_wait_timeout
        return AsyncStored(self.config.connectionStringDataStored.get() , attempts, wait_timeout, self._config.sql_version, self._config.api_environment)

    @property
    def config(self):
        return self._config
    
    @overload
    @staticmethod
    def load(model : Type[T], dict_data : dict, joins : list[LoadJoin] = []) -> T:
        pass

    @overload
    @staticmethod
    def load(model : Type[T], list_dict_data : list[dict], joins : list[LoadJoin] = []) -> list[T]:
        pass

    @overload
    @staticmethod
    def load(model : Type[T], fetchone : Result.Fetchone, joins : list[LoadJoin] = []) -> T:
        pass

    @overload
    @staticmethod
    def load(model : Type[T], fetchall : Result.Fetchall, joins : list[LoadJoin] = []) -> list[T]:
        pass

    @staticmethod
    def load(*args) -> object | list[object]:
        model = args[0] 
        data = args[1]
        joins : list[LoadJoin] = args[2] if len(args) > 2 else []

        if isinstance(data, dict) or isinstance(data, Result.Fetchone):
            if isinstance(data, Result.Fetchone):
                data = data.dict
            if all(value is None for value in data.values()):
                return model()

            joined_tables : dict = data.get('joined_tables')
            for join in joins:
                join_value = joined_tables.get(join.table)
                if join_value:
                    data[join.field] = join_value

            return model(**data)

        if isinstance(data, list) or isinstance(data, Result.Fetchall):
            if isinstance(data, Result.Fetchall):
                data = data.list_dict

            for d in data:
                joined_tables : dict = d.get('joined_tables')
                for join in joins:
                    join_value = joined_tables.get(join.table)
                    if join_value:
                        d[join.field] = join_value

        return [model(**d) for d in data]





