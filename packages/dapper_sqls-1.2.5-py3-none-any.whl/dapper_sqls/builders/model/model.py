# coding: utf-8
import os
from .utils import (create_content_orm , create_field, create_content_async_orm,
                    create_params_routine, get_parameters_with_defaults, create_queue_update, create_arg,
                    SqlTable, SqlColumn, SqlStored)
from ...models import TableBaseModel

class TableBuilderData:
    def __init__(self, table_schema : str, table_name : str, class_name : str, model : str, orm : str | None, async_orm : str | None):
        self.table_schema = table_schema
        self.table_name = table_name
        self.class_name = class_name
        self.model = model
        self.orm = orm
        self.async_orm = async_orm

class RoutineBuilderData:
    def __init__(self, table_schema : str, stp_name : str, content_stp : str, content_async_stp : str):
        self.table_schema = table_schema
        self.stp_name = stp_name
        self.content_stp = content_stp
        self.content_async_stp = content_async_stp

class BuilderData(object):
    def __init__(self, table_catalog : str):
        self.table_catalog = table_catalog
        self.talbes : list[TableBuilderData] = []
        self.routines : list[RoutineBuilderData] = []

class ModelBuilder(object):

    class TableOptions(object):
        def __init__(self, table_name : str, *, create_orm=True, ignore_table=False):
            self.table_name = table_name
            self.create_orm = create_orm
            self.ignore_table = ignore_table

    class RoutineOptions(object):
        def __init__(self, routine_name : str, ignore_routine=False):
            self.routine_name = routine_name
            self.ignore_routine = ignore_routine

    def __init__(self, dapper):
        self._dapper = dapper
        
        self.query_tables = """
            WITH BaseTables AS (
                SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_TYPE = 'BASE TABLE'
            ),
            FKData AS (
                SELECT 
                    fkc.parent_object_id,
                    fkc.parent_column_id,
                    JSON_QUERY(CONCAT(
                        '{',
                            '"table": "', s2.name, '.', t2.name, '", ',
                            '"column": "', c2.name, '"',
                        '}'
                    )) AS fk_json
                FROM sys.foreign_keys fk
                JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
                JOIN sys.tables t2 ON t2.object_id = fkc.referenced_object_id
                JOIN sys.schemas s2 ON s2.schema_id = t2.schema_id
                JOIN sys.columns c2 ON c2.object_id = t2.object_id AND c2.column_id = fkc.referenced_column_id
            ),
            IndexData AS (
                SELECT
                    ic.object_id,
                    ic.column_id,
                    MAX(CASE WHEN i.is_primary_key = 1 THEN 1 ELSE 0 END) AS IS_PRIMARY_KEY,
                    MAX(CASE WHEN i.is_unique = 1 THEN 1 ELSE 0 END) AS IS_UNIQUE
                FROM sys.indexes i
                JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
                GROUP BY ic.object_id, ic.column_id
            ),
            ColumnInfo AS (
                SELECT 
                    c.TABLE_CATALOG,
                    c.TABLE_SCHEMA,
                    c.TABLE_NAME,
                    c.COLUMN_NAME,
                    c.DATA_TYPE,
                    c.CHARACTER_MAXIMUM_LENGTH,
                    CAST(sc.is_nullable AS BIT) AS IS_NULLABLE,
                    CAST(sc.is_identity AS BIT) AS IS_IDENTITY,
                    ISNULL(idx.IS_PRIMARY_KEY, 0) AS IS_PRIMARY_KEY,
                    ISNULL(idx.IS_UNIQUE, 0) AS IS_UNIQUE,
                    ISNULL(ep.value,'') AS COLUMN_DESCRIPTION,
                    dc.definition AS DEFAULT_VALUE,
                    fk.fk_json AS FOREIGN_KEY,
                    ROW_NUMBER() OVER (PARTITION BY c.TABLE_SCHEMA, c.TABLE_NAME ORDER BY c.ORDINAL_POSITION) AS rn
                FROM INFORMATION_SCHEMA.COLUMNS c
                JOIN BaseTables t ON c.TABLE_NAME = t.TABLE_NAME AND c.TABLE_SCHEMA = t.TABLE_SCHEMA
                LEFT JOIN sys.tables st ON st.name = c.TABLE_NAME AND SCHEMA_NAME(st.schema_id) = c.TABLE_SCHEMA
                LEFT JOIN sys.columns sc ON sc.object_id = st.object_id AND sc.name = c.COLUMN_NAME
                LEFT JOIN sys.default_constraints dc ON dc.parent_object_id = sc.object_id AND dc.parent_column_id = sc.column_id
                LEFT JOIN sys.extended_properties ep ON ep.major_id = sc.object_id AND ep.minor_id = sc.column_id AND ep.name='MS_Description'
                LEFT JOIN IndexData idx ON idx.object_id = sc.object_id AND idx.column_id = sc.column_id
                LEFT JOIN FKData fk ON fk.parent_object_id = sc.object_id AND fk.parent_column_id = sc.column_id
            )
            SELECT
                TABLE_CATALOG,
                TABLE_SCHEMA,
                TABLE_NAME,
                CASE WHEN rn = 1 THEN '' ELSE NULL END AS TABLE_DESCRIPTION,
                COLUMN_NAME,
                DATA_TYPE,
                CHARACTER_MAXIMUM_LENGTH,
                IS_NULLABLE,
                IS_IDENTITY,
                IS_PRIMARY_KEY,
                IS_UNIQUE,
                COLUMN_DESCRIPTION,
                FOREIGN_KEY
            FROM ColumnInfo
            ORDER BY TABLE_SCHEMA, TABLE_NAME, rn;
        """

        self.query_routines = f"""
            SELECT  
                r.SPECIFIC_CATALOG,
                r.SPECIFIC_SCHEMA,
                r.SPECIFIC_NAME,
                sm.definition AS PROCEDURE_DEFINITION,
                (
                    SELECT 
                        p.ORDINAL_POSITION,
                        p.PARAMETER_NAME,
                        p.DATA_TYPE
                    FROM INFORMATION_SCHEMA.PARAMETERS p
                    WHERE p.SPECIFIC_NAME = r.SPECIFIC_NAME
                    ORDER BY p.ORDINAL_POSITION
                    FOR JSON PATH
                ) AS PARAMETERS
            FROM INFORMATION_SCHEMA.ROUTINES r
            JOIN sys.sql_modules sm 
                ON OBJECT_NAME(sm.object_id) = r.SPECIFIC_NAME
            WHERE r.ROUTINE_TYPE = 'PROCEDURE'
            ORDER BY r.SPECIFIC_NAME;
        """

    @property
    def dapper(self):
        return self._dapper
    
    def get_tables_data(self):
        with self.dapper.query() as db:
            result = db.fetchall(self.query_tables)
            if not result.success:
                return []

        tables: dict[str, SqlTable] = {}

        for row in result.list_dict:
            if row['TABLE_SCHEMA'] in {'sys', 'INFORMATION_SCHEMA'} or row['TABLE_NAME'].startswith('__'):
                continue

            table_key = f"{row['TABLE_SCHEMA']}.{row['TABLE_NAME']}"

            if table_key not in tables:
                tables[table_key] = SqlTable(
                    TABLE_CATALOG=row.get('TABLE_CATALOG', ''),
                    TABLE_SCHEMA=row.get('TABLE_SCHEMA', ''),
                    TABLE_NAME=row['TABLE_NAME'],
                    TABLE_DESCRIPTION=row.get('TABLE_DESCRIPTION', ''),
                    COLUMNS=[]
                )

            column = SqlColumn(
                TABLE_NAME=row['TABLE_NAME'],
                COLUMN_NAME=row['COLUMN_NAME'],
                DATA_TYPE=row['DATA_TYPE'],
                CHARACTER_MAXIMUM_LENGTH=row.get('CHARACTER_MAXIMUM_LENGTH'),
                IS_NULLABLE=row['IS_NULLABLE'],
                IS_IDENTITY=row['IS_IDENTITY'],
                IS_PRIMARY_KEY=row['IS_PRIMARY_KEY'],
                IS_UNIQUE=row['IS_UNIQUE'],
                COLUMN_DESCRIPTION=row.get('COLUMN_DESCRIPTION', ''),
                FOREIGN_KEY=row.get('FOREIGN_KEY')
            )

            tables[table_key].COLUMNS.append(column)

        return list(tables.values())

    def get_routines_data(self) -> list[SqlStored]:
        with self.dapper.query() as db:
            rows = db.fetchall(self.query_routines)
            if not rows.success:
                return []
        return self.dapper.load(SqlStored, rows)
    
    def get_models_db(self, tables : dict[str, SqlTable]):
        models : list[TableBaseModel] = []
        for table in tables.values():
            if not table.available:
                continue
            models.append(self.get_model_db(table))
        return models

    def get_model_db(self, table : SqlTable):
            
        from datetime import datetime
        from pydantic import Field
        from typing import Union, Optional, ClassVar, Set
        from dapper_sqls import (TableBaseModel, StringQueryField, NumericQueryField, BoolQueryField, DateQueryField, BytesQueryField,
                            JoinNumericCondition, JoinStringCondition, JoinBooleanCondition, JoinDateCondition, JoinBytesCondition)

        table_description = table.auto_description()

        table_name = table.TABLE_NAME
        class_name = table_name 
        schema = table.TABLE_SCHEMA

        fields = [create_field(row) for row in table.COLUMNS if row.available]
        fields_str = "\n    ".join(fields)

        identities = {d.COLUMN_NAME for d in table.COLUMNS if d.IS_IDENTITY  and d.available}

        primary_keys = {d.COLUMN_NAME for d in table.COLUMNS if d.IS_PRIMARY_KEY and d.available}

        optional_fields = {d.COLUMN_NAME for d in table.COLUMNS if d.IS_NULLABLE and d.available}

        max_length_fields = {
            d.COLUMN_NAME: d.CHARACTER_MAXIMUM_LENGTH
            for d in table.COLUMNS
            if d.CHARACTER_MAXIMUM_LENGTH is not None and d.CHARACTER_MAXIMUM_LENGTH > 0 and d.available
        }

        table_alias = table_name.lower()

        content_model = f'''# coding: utf-8
class {class_name}(TableBaseModel):
    TABLE_NAME: ClassVar[str] = '[{schema}].[{table_name}]'

    TABLE_ALIAS: ClassVar[str] = '{table_alias}'

    JSON_ALIAS: ClassVar[str] = '{table_name}'
    
    DESCRIPTION : ClassVar[str] = """{table_description}"""
    
    IDENTITIES : ClassVar[Set[str]] = {identities}

    PRIMARY_KEYs : ClassVar[Set[str]] = {primary_keys}

    OPTIONAL_FIELDS : ClassVar[Set[str]] = {optional_fields}   

    MAX_LENGTH_FIELDS: ClassVar[dict[str, int]] = {max_length_fields}
    
    {fields_str}
            '''
        local_vars = {}
        exec(content_model, {
            "TableBaseModel": TableBaseModel,
            "StringQueryField": StringQueryField,
            "NumericQueryField": NumericQueryField,
            "BoolQueryField": BoolQueryField,
            "DateQueryField": DateQueryField,
            "BytesQueryField": BytesQueryField,
            "JoinNumericCondition": JoinNumericCondition,
            "JoinStringCondition": JoinStringCondition,
            "JoinBooleanCondition": JoinBooleanCondition,
            "JoinDateCondition": JoinDateCondition,
            "JoinBytesCondition": JoinBytesCondition,
            "datetime": datetime,
            "Field": Field,
            "Union": Union,
            "Optional": Optional,
            "ClassVar": ClassVar,
            "Set": Set
        }, local_vars)
        return local_vars[class_name]

    def create_model_db(self, dir_path : str, create_orm = True, create_stp = True, *, table_catalog : str | list[str] | tuple[str] = "all",
                          table_schema : str | list[str] | tuple[str] = "all",
                          tables_options : list[TableOptions] = [], routines_oprions : list[RoutineOptions] = []):

        dict_tables_options = {}
        if tables_options:
            dict_tables_options = {options.table_name : options for options in tables_options}
            create_orm = False
            for options in tables_options:
                if options.create_orm:
                    create_orm = True
                    break

        dict_routines_options = {options.routine_name : options for options in routines_oprions}
        if routines_oprions:
            create_stp = False
            for options in routines_oprions:
                if not options.ignore_routine:
                    create_stp = True
                    break

        information_routines = []
        if create_stp:
            information_routines = self.get_routines_data()
    
        table_data = self.get_tables_data()
        if not table_data:
            return False

        table_catalog = [table_catalog] if isinstance(table_catalog, str) and table_catalog != "all" else table_catalog
        table_schema = [table_schema] if isinstance(table_schema, str) and table_schema != "all" else table_schema
       
        builder_data : dict[str, BuilderData] = {}
        import_init_db = ""
        for data in table_data:

            if table_catalog != "all":
                if data.TABLE_CATALOG not in table_catalog :
                    continue

            if table_schema != "all":
                if data.TABLE_SCHEMA not in table_schema :
                    continue

            table_options = dict_tables_options.get(data.TABLE_NAME)
            if table_options:
                if table_options.ignore_table:
                    continue
            
            table_description = data.auto_description()
           
            table_name = data.TABLE_NAME
            class_name = table_name #table_name.replace("TBL_", "")
            schema = data.TABLE_SCHEMA

            fields = [create_field(column) for column in data.COLUMNS]
            fields_str = "\n    ".join(fields)

            # original_fields = [create_field(column, False) for column in data.COLUMNS]
            # original_fields_str = "\n        ".join(original_fields)

            fields_args = [create_arg(column) for column in data.COLUMNS]
            fields_args_str = ", ".join(fields_args)

            identities = {d.COLUMN_NAME for d in data.COLUMNS if d.IS_IDENTITY}

            primary_keys = {d.COLUMN_NAME for d in data.COLUMNS if d.IS_PRIMARY_KEY}

            optional_fields = {d.COLUMN_NAME for d in data.COLUMNS if d.IS_NULLABLE}

            max_length_fields = {
                d.COLUMN_NAME: d.CHARACTER_MAXIMUM_LENGTH
                for d in data.COLUMNS
                if d.CHARACTER_MAXIMUM_LENGTH is not None and d.CHARACTER_MAXIMUM_LENGTH > 0
            }

            table_alias = table_name.lower()
            
            content_model = f'''# coding: utf-8

from dapper_sqls import (TableBaseModel, StringQueryField, NumericQueryField, BoolQueryField, DateQueryField, BytesQueryField,
                        JoinNumericCondition, JoinStringCondition, JoinBooleanCondition, JoinDateCondition, JoinBytesCondition)
from datetime import datetime
from pydantic import Field
from typing import Union, Optional, ClassVar, Set

class {class_name}(TableBaseModel):
    TABLE_NAME: ClassVar[str] = '[{schema}].[{table_name}]'

    TABLE_ALIAS: ClassVar[str] = '{table_alias}'

    JSON_ALIAS: ClassVar[str] = '{table_name}'
    
    DESCRIPTION : ClassVar[str] = '{table_description}'
    
    IDENTITIES : ClassVar[Set[str]] = {identities}

    PRIMARY_KEYs : ClassVar[Set[str]] = {primary_keys}

    OPTIONAL_FIELDS : ClassVar[Set[str]] = {optional_fields}   

    MAX_LENGTH_FIELDS: ClassVar[dict[str, int]] = {max_length_fields}
    
    {fields_str}
    
    {create_queue_update(fields_args_str)}
\n
            '''
            
            table_create_orm = create_orm
            if table_options:
                    table_create_orm = table_options.create_orm

            content_orm = create_content_orm(class_name, fields_args_str) if table_create_orm else None
            content_async_orm = create_content_async_orm(class_name, fields_args_str) if table_create_orm else None

            catalog = data.TABLE_CATALOG
            if catalog not in builder_data:
                builder_data[catalog] = BuilderData(catalog)

            table_builder_data = TableBuilderData(schema, table_name, class_name, content_model, content_orm, content_async_orm)
            builder_data[catalog].talbes.append(table_builder_data)
      
        for data in information_routines:

            if table_catalog != "all":
                if data.SPECIFIC_CATALOG not in table_catalog :
                    continue

            if table_schema != "all":
                if data.SPECIFIC_SCHEMA not in table_schema :
                    continue

            routine_oprions = dict_routines_options.get(data.SPECIFIC_NAME)
            if routine_oprions:
                if routine_oprions.ignore_routine:
                    continue
            
            defaults_values = get_parameters_with_defaults(data.PROCEDURE_DEFINITION)
            params_routine = [create_params_routine(row, defaults_values) for row in data]
            params_routine_str = ", ".join(params_routine)

            stp_name = data.SPECIFIC_NAME.replace('STP_', '')
            content_routine = f'''
    def {stp_name}(self, *, {params_routine_str}):
        return StpBuilder(self.dapper, '[{data.SPECIFIC_SCHEMA}].[{data.SPECIFIC_NAME}]',locals())'''

            content_async_routine = f'''
    def {stp_name}(self, *, {params_routine_str}):
        return AsyncStpBuilder(self.async_dapper, '[{data.SPECIFIC_SCHEMA}].[{data.SPECIFIC_NAME}]', locals())'''
            
            catalog = data.SPECIFIC_CATALOG
            if catalog not in builder_data:
                builder_data[catalog] = BuilderData(catalog)

            builder_data[catalog].routines.append(RoutineBuilderData(data.SPECIFIC_SCHEMA, data.SPECIFIC_NAME, content_routine, content_async_routine))

        for catalog, data in builder_data.items():
            import_init_db += f"from .{catalog} import {catalog}\n"
  
            dir_catalog = os.path.join(dir_path, catalog)
            schema_data_tables : dict[str, list[TableBuilderData]] = {}
            for table in data.talbes:
                if table.table_schema not in schema_data_tables:
                    schema_data_tables[table.table_schema] = []

                dir_schema = os.path.join(dir_catalog, table.table_schema)
                dir_table = os.path.join(dir_schema, table.table_name)

                if not os.path.exists(dir_table):
                    os.makedirs(dir_table)

                table_options = dict_tables_options.get(table.table_name)

                table_create_orm = create_orm
                if table_options:
                    table_create_orm = table_options.create_orm

                if table_create_orm:
                    with open(os.path.join(dir_table ,'orm.py'), 'w', encoding='utf-8') as file:
                        file.write(''.join(table.orm))

                    with open(os.path.join(dir_table ,'async_orm.py'), 'w', encoding='utf-8') as file:
                        file.write(''.join(table.async_orm))

                with open(os.path.join(dir_table ,f'__init__.py'), 'w', encoding='utf-8') as file:
                    if table_create_orm:
                        file.write(f'from .orm import {table.class_name}ORM\nfrom .async_orm import Async{table.class_name}ORM\nfrom .model import {table.class_name}')
                    else:
                        file.write(f'from .model import {table.class_name}')

                with open(os.path.join(dir_table ,'model.py'), 'w', encoding='utf-8') as file:
                    file.write(''.join(table.model))

                
                schema_data_tables[table.table_schema].append(table)

            schema_data_routine : dict[str, list[RoutineBuilderData]] = {}
            content_file_routine = '''# coding: utf-8
from dapper_sqls import StpBuilder
from dapper_sqls import Dapper
from datetime import datetime
from typing import Union

class stp(object):

    def __init__(self, dapper : Dapper):
        self._dapper = dapper

    @property
    def dapper(self):
        return self._dapper
            '''

            content_file_async_rounine = '''# coding: utf-8
from dapper_sqls import AsyncStpBuilder
from dapper_sqls import AsyncDapper
from datetime import datetime
from typing import Union

class async_stp(object):

    def __init__(self, async_dapper : AsyncDapper):
        self._async_dapper = async_dapper

    @property
    def async_dapper(self):
        return self._async_dapper
            '''

            for routine in data.routines:
                if routine.table_schema not in schema_data_routine:
                    schema_data_routine[routine.table_schema] = []

                dir_schema = os.path.join(dir_catalog, routine.table_schema)
                if not os.path.exists(dir_schema):
                    os.makedirs(dir_schema)

                content_file_routine += f'{routine.content_stp}\n' 
                content_file_async_rounine += f'{routine.content_async_stp}\n' 

            if data.routines:
                dir_schema = os.path.join(dir_catalog, data.routines[0].table_schema)
                with open(os.path.join(dir_schema ,'routines.py'), 'w', encoding='utf-8') as file:
                     file.write(''.join(content_file_routine))
                with open(os.path.join(dir_schema ,'async_routines.py'), 'w', encoding='utf-8') as file:
                     file.write(''.join(content_file_async_rounine))

            import_init_catalog = ""
            class_init_catalog = f'''class {catalog}(object):\n'''
         
            for schema, data in schema_data_tables.items():
                import_init_catalog += f"from .{schema} import schema_{schema}\n"
                class_init_catalog += f"\n    class {schema}(schema_{schema}):\n        ...\n"
                import_init_schema = ""
                class_init_schema = ""
                class_models_schema = "    class models(object):\n"
                class_orm_schema = "    class orm(object):\n        def __init__(self, dapper : Dapper):\n"
                class_async_orm_schema = "    class async_orm(object):\n        def __init__(self, async_dapper : AsyncDapper):\n"
                for table in data:

                    table_options = dict_tables_options.get(table.table_name)
                    table_create_orm = create_orm
                    if table_options:
                        table_create_orm = table_options.create_orm

                    dir_schema = os.path.join(dir_catalog, schema)
                    class_models_schema += f"\n        class {table.class_name}({table.class_name}):\n            ...\n"
                    if table_create_orm:
                        class_orm_schema += f"            self.{table.class_name} = {table.class_name}ORM(dapper)\n"
                        class_async_orm_schema += f"            self.{table.class_name} = Async{table.class_name}ORM(async_dapper)\n"
                        import_init_schema += f"from .{table.table_name} import {table.class_name}, {table.class_name}ORM, Async{table.class_name}ORM\n"
                        class_init_schema += f"\n    class {table.class_name}ORM({table.class_name}ORM):\n        ...\n"
                        class_init_schema += f"\n    class Async{table.class_name}ORM(Async{table.class_name}ORM):\n        ...\n"
                    else:
                        import_init_schema += f"from .{table.table_name} import {table.class_name}\n"

                if information_routines :
                    import_init_schema += "from .routines import stp\nfrom .async_routines import async_stp\n"

                class_stp = "\n    class stp(stp):\n        ...\n" if information_routines else ""
                class_async_stp = "\n    class async_stp(async_stp):\n        ...\n" if information_routines else ""
                
                class_schema = f"class schema_{schema}(object):\n"
                if create_orm:
                    class_init_schema = f"{class_schema}{class_stp}{class_async_stp}\n{class_models_schema}\n{class_orm_schema}\n{class_async_orm_schema}\n{class_init_schema}"
                    content_init_schema = f"{import_init_schema}\nfrom dapper_sqls import Dapper, AsyncDapper\n\n{class_init_schema}"
                else:
                    class_init_schema = f"{class_schema}{class_stp}{class_async_stp}\n{class_models_schema}"
                    content_init_schema = f"{import_init_schema}\n\n{class_init_schema}"

                with open(os.path.join(dir_schema ,f'__init__.py'), 'w', encoding='utf-8') as file:
                    file.write(''.join(content_init_schema))

            content_init_catalog = f"{import_init_catalog}\n\n{class_init_catalog}"
            with open(os.path.join(dir_catalog ,f'__init__.py'), 'w', encoding='utf-8') as file:
                    file.write(''.join(content_init_catalog))

        if builder_data:
            #with open(os.path.join(dir_path ,f'__init__.py'), 'w', encoding='utf-8') as file:
            #        file.write(''.join(import_init_db))

            return True