# myregression/__init__.py

import numpy as np

# -------------------------
# Helper functions
# -------------------------
def train_test_split(X, y, test_size=0.2, random_state=None):
    """Split arrays X and y into training and test sets."""
    if random_state:
        np.random.seed(random_state)
    n_samples = len(X)
    indices = np.arange(n_samples)
    np.random.shuffle(indices)
    test_size = int(n_samples * test_size)
    test_idx = indices[:test_size]
    train_idx = indices[test_size:]
    return X[train_idx], X[test_idx], y[train_idx], y[test_idx]

def mean_squared_error(y_true, y_pred):
    """Calculate the Mean Squared Error between true and predicted values."""
    return np.mean((y_true - y_pred) ** 2)

# -------------------------
# Linear Regression class
# -------------------------
class LinearRegression:
    def __init__(self):
        self.coef_ = None
        self.intercept_ = None

    def fit(self, X, y):
        X_b = np.c_[np.ones((len(X), 1)), X]  # add bias term
        theta = np.linalg.pinv(X_b.T @ X_b) @ X_b.T @ y
        self.intercept_ = theta[0]
        self.coef_ = theta[1:]
    
    def predict(self, X):
        return X @ self.coef_ + self.intercept_

# -------------------------
# Ridge Regression class
# -------------------------
class RidgeRegression:
    def __init__(self, alpha=1.0):
        self.alpha = alpha
        self.coef_ = None
        self.intercept_ = None

    def fit(self, X, y):
        X_b = np.c_[np.ones((len(X), 1)), X]  # add bias term
        n_features = X_b.shape[1]
        I = np.eye(n_features)
        I[0,0] = 0  # don't regularize the bias
        theta = np.linalg.pinv(X_b.T @ X_b + self.alpha * I) @ X_b.T @ y
        self.intercept_ = theta[0]
        self.coef_ = theta[1:]

    def predict(self, X):
        return X @ self.coef_ + self.intercept_
