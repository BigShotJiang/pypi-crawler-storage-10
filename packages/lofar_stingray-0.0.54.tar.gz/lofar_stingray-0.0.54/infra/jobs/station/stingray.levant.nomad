# Receives station statistics and meta data,
# publishes them on ZMQ, and records them as JSON on S3.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/station/stingray.levant.nomad

job "statistics" {
  region      = "[[ $.region ]]"
  datacenters = ["stat"]

  reschedule {
    unlimited = true
    delay = "30s"
    delay_function = "constant"
  }

  group "stingray-metadata" {
    count = 1

    network {
      mode = "bridge"
    }

    task "initialise-buckets" {
      lifecycle {
        hook = "prestart"
      }

      driver = "docker"
      config {
        # source: minio/mc
        image = "[[ $.registry.astron.url ]]/mc:[[.object_storage.mc.version]]"
        entrypoint = ["bash", "-c", "mc ping -x local && mc mb --ignore-existing local/statistics"]

        mount {
          type   = "bind"
          source = "local/mc"
          target = "/root/.mc"
        }
      }

      env {
        MINIO_ROOT_USER     = "[[.object_storage.user.name]]"
        MINIO_ROOT_PASSWORD = "[[.object_storage.user.pass]]"
      }

      resources {
        cpu    = 10
        memory = 512
      }

      template {
        destination     = "local/mc/config.json"
        change_mode     = "noop"
        data = <<EOF
{
  "aliases": {
    "local": {
      "url": "http://s3.service.consul:9000",
      "accessKey": "[[$.object_storage.user.name]]",
      "secretKey": "[[$.object_storage.user.name]]",
      "api": "s3v4",
      "path": "on"
    }
  }
}
EOF
      }
    }

    task "stingray-record-metadata" {
      driver = "docker"

      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"

        entrypoint = [
          "l2ss-stingray-forward",
          "--datatype=json",
          "zmq+tcp://device-metadata.service.consul:6001/metadata?content-type=application%2Fjson",
          "s3://statistics/[[$.station]]/metadata"
        ]
      }

      env {
        MINIO_ROOT_USER     = "[[$.object_storage.user.name]]"
        MINIO_ROOT_PASSWORD = "[[$.object_storage.user.pass]]"
      }


      resources {
        cpu    = 10
        memory = 512
      }
    }
  }

  [[ range $af, $fields := $.stingray ]]
  [[   range $st, $ip := $fields ]]
  group "stingray-[[ $af ]]-[[ $st ]]" {
    count = 1

    network {
      mode = "cni/statistics"

      cni {
        args = {
          IP = "[[ $ip ]]"
          GATEWAY = "10.99.250.250"
        }
      }
    }

    service {
      name = "statistics-[[ $af ]]-[[ $st ]]-zmq"
      port = 6001
      address_mode = "alloc"

      check {
        type = "tcp"
        interval = "20s"
        timeout = "5s"
        address_mode = "alloc"
      }
    }

    service {
      name = "statistics-[[ $af ]]-[[ $st ]]-udp"
      port = 5001
      address_mode = "alloc"
    }

    service {
      name = "stingray-[[ $af ]]-[[ $st ]]-publish-metrics"
      tags = ["scrape"]
      port = 8000
      address_mode = "alloc"
    }

    service {
      name = "stingray-[[ $af ]]-[[ $st ]]-record-metrics"
      tags = ["scrape"]
      port = 8001
      address_mode = "alloc"
    }

    task "wait-for-s3" {
      lifecycle {
        hook    = "prestart"
        sidecar = false
      }
      driver = "docker"

      config {
        image   = "[[ $.registry.astron.url ]]/busybox:latest"
        command = "sh"
        args    = ["-c", "while ! nc -z s3.service.consul 9000; do sleep 1; done"]
      }
    }

    task "stingray-publish-[[ $af ]]-[[ $st ]]" {
      driver = "docker"

      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[ $.image_tag ]]"

        entrypoint = [
          "l2ss-stingray-publish",
          "[[ $.station ]]",
          "[[ $af ]]",
          "[[ $st ]]",
          "udp://0.0.0.0:5001",
          "--port=6001"
        ]
      }

      resources {
        cpu    = 10
        memory = 512
      }
    }

    task "stingray-record-[[ $af ]]-[[ $st ]]" {
      driver = "docker"

      config {
          image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"

          entrypoint = [
            "l2ss-stingray-forward",
            "--datatype=json",
            "zmq+tcp://localhost:6001/[[ $st ]]/[[ $af ]]/",
            "s3://statistics/[[$.station]]/[[ $st ]]/[[ $af ]]",
            "--metrics-port=8001"
          ]
      }

      env {
        MINIO_ROOT_USER = "[[$.object_storage.user.name]]"
        MINIO_ROOT_PASSWORD = "[[$.object_storage.user.pass]]"
      }

      resources {
        cpu    = 10
        memory = 512
      }
    }
  }
  [[   end ]]
  [[ end ]]
}
