# Replicates statistics JSONs from station to central S3.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/station/stingray-bucket-replication.levant.nomad

job "statistics-bucket-replication" {
  region      = "[[ $.region ]]"
  datacenters = ["stat"]
  type        = "batch"

  periodic {
    crons            = ["*/5 * * * * *"]
    prohibit_overlap = true
  }

  group "batch" {
    count = 1

    network {
      mode = "bridge"
    }

    task "wait-for-s3" {
      lifecycle {
        hook    = "prestart"
        sidecar = false
      }
      driver = "docker"

      config {
        image   = "[[ $.registry.astron.url ]]/busybox:latest"
        command = "sh"
        args    = ["-c", "while ! nc -z s3.service.consul 9000; do sleep 1; done"]
      }
    }

    task "mc" {
      driver = "docker"
      config {
        # source: minio/mc
        image = "[[ $.registry.astron.url ]]/mc:[[.object_storage.mc.version]]"

        entrypoint = ["mc", "batch", "start", "local", "/secrets/statistics.yaml" ]

        mount {
          type   = "bind"
          source = "local/mc"
          target = "/root/.mc"
        }
      }

      env {
        MINIO_ROOT_USER     = "[[.object_storage.user.name]]"
        MINIO_ROOT_PASSWORD = "[[.object_storage.user.pass]]"
      }

      resources {
        cpu    = 10
        memory = 512
      }

      template {
        destination     = "local/mc/config.json"
        change_mode     = "noop"
        data = <<EOF
{
  "aliases": {
    "local": {
      "url": "http://s3.service.consul:9000",
      "accessKey": "[[.object_storage.user.name]]",
      "secretKey": "[[.object_storage.user.name]]",
      "api": "s3v4",
      "path": "on"
    }
  }
}
EOF
      }
      template {
        destination     = "secrets/statistics.yaml"
        change_mode     = "noop"
        data = <<EOF
replicate:
  apiVersion: v1
  source:
    type: minio
    bucket: statistics
    prefix: ""
  target:
    type: minio
    bucket: central-statistics
    {{ range service "s3@lofar-central" }}
    endpoint: "{{ index .ServiceMeta "protocol" }}://{{ .Address }}:{{ .Port }}"
    {{   break }}
    {{ end }} 
    credentials:
      {{ with nomadVar "nomad/jobs" }}
      accessKey: "{{.minio_remote_accessKey}}"
      secretKey: "{{.minio_remote_secretKey}}"
      {{ end }}
  flags:
    filter:
      newerThan: "10m"
      EOF
      }
    }
  }
}
