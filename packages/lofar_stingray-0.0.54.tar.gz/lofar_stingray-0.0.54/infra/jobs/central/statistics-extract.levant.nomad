# Extracts station statistics JSON files and generates an HDF5 file
# containing their data and associated meta data.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/central/extract.levant.nomad

job "statistics-extract" {
  region      = "lofar-central"
  datacenters = ["nl-cit"]
  type        = "batch"
  namespace   = "statistics"

  parameterized {
    payload       = "forbidden"
    meta_required = ["observation_id", "station", "antenna_field", "begin", "end", "source", "destination"]
    meta_optional = ["metadata_bst", "metadata_sst", "metadata_xst"]
  }

  vault {
  }

  [[ range $type := "bst xst sst" | split " " ]]
  group "aggregate-[[ $type ]]" {
    count = 1

    network {
      mode = "bridge"
    }

    ephemeral_disk {
      size = 110 # nomad wants 100 MiB for log storage, so provide at least that
    }

    task "stingray" {
      driver = "docker"
      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"
        entrypoint = ["local/extract.sh"]
      }

      template {
        destination  = "local/extract.sh"
        perms        = "755"
        data = <<EOF
#!/bin/bash -v

{{ range service "s3" }}
l2ss-stingray-extract \
     --endpoint {{ .Address }}:{{ .Port }} \
{{-  if (eq (index .ServiceMeta "protocol") "https") }}
     --secure \
{{-  end }}
    "${NOMAD_META_station}" \
    "${NOMAD_META_antenna_field}" \
    "[[ $type ]]" \
    "${NOMAD_META_begin}" \
    "${NOMAD_META_end}" \
    "${NOMAD_META_source}" \
    "${NOMAD_META_destination}/L${NOMAD_META_observation_id}/[[ $type ]]/L${NOMAD_META_observation_id}_${NOMAD_META_station}_${NOMAD_META_antenna_field}_[[ $type ]].h5" \
    --user-metadata "${NOMAD_META_metadata_[[ $type ]]}"
{{   break }}
{{ end }}
EOF
      }

      template {
        destination = "secrets/env.txt"
        env         = true

        data = <<EOH
        {{- with secret "kv-v2/minio/statistics-extract" -}}
        MINIO_ROOT_USER      = "{{ .Data.data.username }}"
        MINIO_ROOT_PASSWORD  = "{{ .Data.data.password }}"
        {{- end -}}
        EOH
      }

      resources {
        cpu    = 10
        memory = 512
        memory_max = 4096
      }
    }
  }
  [[ end ]]
}
