#  Copyright (C) 2024 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Class to aggregate BST statistics"""

from datetime import datetime
from typing import Iterable

import numpy

from lofar_stingray.statistics_data import (
    BstStatisticsSet,
    StatisticsDataFile,
)

from ._base import BaseAnnotator


class BstAnnotator(BaseAnnotator):
    """Class to aggregate BST statistics"""

    def __init__(
        self,
        station: str,
        antenna_field: str,
        start_time: datetime,
        metadata_packets: Iterable,
        matrices: Iterable,
    ):
        super().__init__(station, antenna_field, start_time, metadata_packets)
        self.matrices = matrices

    @property
    def mode(self):
        return "BST"

    def set_statisticsset_metadata(
        self, statisticsset: BstStatisticsSet, timestamp: datetime, matrix: dict
    ):
        super().set_statisticsset_metadata(statisticsset, timestamp, matrix)

        metadata = self.metadata.get_metadata(timestamp)
        sdp_metadata = metadata.get(self.sdp_device, {})
        digitalbeam_metadata = metadata.get(self.digitalbeam_device, {})

        subbands = digitalbeam_metadata.get("subband_select_RW", [])
        frequencies = sdp_metadata.get("subband_frequency_R", [[]])[0]
        statisticsset.subbands = subbands
        statisticsset.frequencies = [
            frequencies[sb] if sb < len(frequencies) else 0.0 for sb in subbands
        ]

        statisticsset.digital_beam_pointing_directions = digitalbeam_metadata.get(
            "Pointing_direction_str_R", []
        )
        statisticsset.digital_beam_tracking_enabled = digitalbeam_metadata.get(
            "Tracking_enabled_R", True
        )
        statisticsset.digital_beam_subbands = digitalbeam_metadata.get(
            "subband_select_RW", []
        )

    def write(self, statistics: StatisticsDataFile):
        self.set_file_header(statistics)

        for matrix in self.matrices:
            timestamp = datetime.fromisoformat(matrix["timestamp"])

            values = numpy.array(matrix["bst_data"], dtype=numpy.float32).view(
                BstStatisticsSet
            )

            self.set_statisticsset_metadata(values, timestamp, matrix)

            statistics[f"BST_{self.timestamp_dataset_name(timestamp)}"] = values
