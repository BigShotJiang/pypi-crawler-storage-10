import socket

def get_primary_ip() -> str:
    # doesn't send any packets; safe and fast
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    finally:
        s.close()