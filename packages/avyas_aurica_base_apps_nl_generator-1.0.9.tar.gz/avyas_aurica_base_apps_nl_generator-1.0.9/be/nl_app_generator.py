"""
Natural Language App Generator.

Generates FastAPI apps from natural language descriptions.
"""
import json
from pathlib import Path
from typing import Dict, Optional, List
import os


class NLAppGenerator:
    """Generates apps from natural language descriptions."""
    
    def __init__(self, apps_dir: Path):
        """
        Initialize the NL app generator.
        
        Args:
            apps_dir: Path to the apps directory
        """
        self.apps_dir = Path(apps_dir)
        self.nl_config_file = "app.nl.json"
        
    async def discover_nl_apps(self) -> List[str]:
        """
        Discover all apps with natural language definitions.
        
        Returns:
            List of app names that have NL definitions
        """
        nl_apps = []
        
        if not self.apps_dir.exists():
            return nl_apps
        
        for app_path in self.apps_dir.iterdir():
            if app_path.is_dir() and not app_path.name.startswith('.'):
                nl_config_path = app_path / self.nl_config_file
                if nl_config_path.exists():
                    nl_apps.append(app_path.name)
        
        return nl_apps
    
    async def load_nl_config(self, app_name: str) -> Optional[Dict]:
        """
        Load natural language configuration for an app.
        
        Args:
            app_name: Name of the app
            
        Returns:
            Dictionary with NL configuration, or None if not found
        """
        app_path = self.apps_dir / app_name
        nl_config_path = app_path / self.nl_config_file
        
        if not nl_config_path.exists():
            return None
        
        try:
            with open(nl_config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"❌ Error loading NL config for {app_name}: {e}")
            return None
    
    async def generate_app_from_nl(self, app_name: str, nl_config: Dict) -> bool:
        """
        Generate app code from natural language configuration.
        
        Args:
            app_name: Name of the app
            nl_config: Natural language configuration
            
        Returns:
            True if generation was successful, False otherwise
        """
        try:
            app_path = self.apps_dir / app_name
            
            # Create directories if they don't exist
            api_dir = app_path / "api"
            api_dir.mkdir(parents=True, exist_ok=True)
            
            static_dir = app_path / "static"
            static_dir.mkdir(parents=True, exist_ok=True)
            
            # Get app description
            app_description = nl_config.get("description", "")
            endpoints = nl_config.get("endpoints", [])
            
            print(f"\n🤖 Generating app: {app_name}")
            print(f"   Description: {app_description}")
            print(f"   Endpoints to generate: {len(endpoints)}")
            
            # Generate each endpoint
            for endpoint in endpoints:
                await self._generate_endpoint(app_name, api_dir, endpoint)
            
            # Generate static index.html if needed
            if nl_config.get("generate_ui", False):
                await self._generate_static_ui(app_name, static_dir, nl_config)
            
            print(f"✅ Successfully generated {app_name}")
            return True
            
        except Exception as e:
            print(f"❌ Error generating app {app_name}: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def _generate_endpoint(self, app_name: str, api_dir: Path, endpoint_config: Dict):
        """
        Generate a single API endpoint from configuration.
        
        Args:
            app_name: Name of the app
            api_dir: Path to the API directory
            endpoint_config: Endpoint configuration
        """
        endpoint_name = endpoint_config.get("name", "handler")
        description = endpoint_config.get("description", "")
        method = endpoint_config.get("method", "GET").upper()
        response_type = endpoint_config.get("response_type", "json")
        
        # Create the endpoint file
        endpoint_file = api_dir / f"{endpoint_name}.py"
        
        # Generate code based on configuration
        code = self._generate_endpoint_code(endpoint_name, description, method, response_type, endpoint_config)
        
        # Write the file
        with open(endpoint_file, 'w', encoding='utf-8') as f:
            f.write(code)
        
        print(f"   ✓ Generated endpoint: {endpoint_name}.py")
    
    def _generate_endpoint_code(
        self, 
        name: str, 
        description: str, 
        method: str, 
        response_type: str,
        config: Dict
    ) -> str:
        """
        Generate Python code for an endpoint.
        
        Args:
            name: Endpoint name
            description: Endpoint description
            method: HTTP method
            response_type: Type of response
            config: Full endpoint configuration
            
        Returns:
            Generated Python code
        """
        # Extract configuration
        tags = config.get("tags", [name])
        fields = config.get("fields", {})
        
        # Build the code
        code = f'''"""
{description}

Auto-generated from natural language description.
"""
from fastapi import APIRouter, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

router = APIRouter()

'''
        
        # Generate response model if fields are specified
        if fields:
            code += f'''
class {name.title().replace("_", "")}Response(BaseModel):
    """Response model for {name} endpoint."""
'''
            for field_name, field_type in fields.items():
                # Map string types to Python types
                py_type = self._map_type(field_type)
                code += f'    {field_name}: {py_type}\n'
            
            response_model_name = f'{name.title().replace("_", "")}Response'
        else:
            # Generic response
            code += f'''
class {name.title().replace("_", "")}Response(BaseModel):
    """Response model for {name} endpoint."""
    success: bool
    message: str
    data: Dict[str, Any]

'''
            response_model_name = f'{name.title().replace("_", "")}Response'
        
        # Generate endpoint
        method_lower = method.lower()
        tags_str = str(tags)
        
        code += f'''
@router.{method_lower}("/", response_model={response_model_name}, summary="{description}", tags={tags_str})
async def {name}():
    """
    {description}
    
    Returns:
        {response_model_name} with the requested data
    """
    # TODO: Implement actual logic here
    # Replace the placeholder return values below with your implementation
'''
        
        # Generate placeholder return based on fields
        if fields:
            code += f'    return {response_model_name}(\n'
            for field_name, field_type in fields.items():
                sample_value = self._get_sample_value(field_type)
                code += f'        {field_name}={sample_value},\n'
            code += '    )\n'
        else:
            code += f'''    return {response_model_name}(
        success=True,
        message="Operation completed successfully",
        data={{}}
    )
'''
        
        return code
    
    def _map_type(self, type_str: str) -> str:
        """Map string type to Python type annotation."""
        type_map = {
            "string": "str",
            "str": "str",
            "integer": "int",
            "int": "int",
            "number": "float",
            "float": "float",
            "boolean": "bool",
            "bool": "bool",
            "array": "List[Any]",
            "list": "List[Any]",
            "object": "Dict[str, Any]",
            "dict": "Dict[str, Any]",
        }
        return type_map.get(type_str.lower(), "Any")
    
    def _get_sample_value(self, type_str: str) -> str:
        """
        Get placeholder value for a type in generated code.
        These are temporary values that should be replaced with actual implementation.
        """
        samples = {
            "string": '"TODO: Replace with actual value"',
            "str": '"TODO: Replace with actual value"',
            "integer": '0',
            "int": '0',
            "number": '0.0',
            "float": '0.0',
            "boolean": 'False',
            "bool": 'False',
            "array": '[]',
            "list": '[]',
            "object": '{}',
            "dict": '{}',
        }
        return samples.get(type_str.lower(), 'None')
    
    async def _generate_static_ui(self, app_name: str, static_dir: Path, nl_config: Dict):
        """
        Generate a simple static UI for the app.
        
        Args:
            app_name: Name of the app
            static_dir: Path to static directory
            nl_config: Natural language configuration
        """
        index_file = static_dir / "index.html"
        
        app_title = nl_config.get("title", app_name.title())
        app_description = nl_config.get("description", "")
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{app_title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        h1 {{
            margin: 0 0 10px 0;
            color: #333;
        }}
        .description {{
            color: #666;
            font-size: 16px;
        }}
        .links {{
            margin-top: 20px;
        }}
        .link {{
            display: inline-block;
            margin-right: 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }}
        .link:hover {{
            background: #0056b3;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{app_title}</h1>
        <p class="description">{app_description}</p>
        <div class="links">
            <a href="/{app_name}/docs" class="link">📚 API Documentation</a>
            <a href="/{app_name}/redoc" class="link">📖 ReDoc</a>
        </div>
    </div>
    
    <div class="header">
        <h2>About this app</h2>
        <p>This app was auto-generated from a natural language description.</p>
        <p>Visit the API documentation to see available endpoints and try them out.</p>
    </div>
</body>
</html>
'''
        
        with open(index_file, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"   ✓ Generated static UI: index.html")
