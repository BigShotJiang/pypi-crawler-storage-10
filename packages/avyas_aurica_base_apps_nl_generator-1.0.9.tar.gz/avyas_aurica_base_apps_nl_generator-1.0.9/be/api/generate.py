"""
Generate API endpoint - generates apps from natural language definitions.
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from pathlib import Path
from typing import List
import sys

# Add parent directory to path to import the generator
sys.path.insert(0, str(Path(__file__).parent.parent))
from nl_app_generator import NLAppGenerator

# Import authentication decorators from base
try:
    from src.auth_decorators import require_auth
except ImportError:
    # Fallback if running in different context
    def require_auth(func):
        return func

router = APIRouter()


class GenerateRequest(BaseModel):
    """Request model for app generation."""
    nl_file_path: str


class GenerateResponse(BaseModel):
    """Response model for app generation."""
    success: bool
    app_name: str
    message: str
    generated_files: List[str]
    restart_required: bool


@router.post("/", response_model=GenerateResponse, summary="Generate app from NL definition", tags=["generator"])
@require_auth
async def generate_app(request: GenerateRequest):
    """
    Generate FastAPI app code from a natural language JSON file.
    
    This endpoint accepts a path to an `app.nl.json` file and generates
    FastAPI code based on the natural language definition.
    
    Args:
        request: Contains nl_file_path (path to app.nl.json file)
        
    Returns:
        GenerateResponse with generation status and details
        
    Example:
        POST /nl-generator/api/generate/
        {
            "nl_file_path": "apps/my-app/app.nl.json"
        }
    """
    # Import app_loader from src.main
    from src.main import app_loader
    
    try:
        # Convert to Path object
        nl_path = Path(request.nl_file_path)
        
        # If relative path, make it relative to project root
        if not nl_path.is_absolute():
            project_root = Path(__file__).parent.parent.parent.parent
            nl_path = project_root / nl_path
        
        # Check if file exists
        if not nl_path.exists():
            raise HTTPException(status_code=404, detail=f"File not found: {request.nl_file_path}")
        
        if nl_path.name != "app.nl.json":
            raise HTTPException(status_code=400, detail="File must be named 'app.nl.json'")
        
        # Get app name from parent directory
        app_name = nl_path.parent.name
        
        # Initialize the NL generator
        apps_dir = Path(__file__).parent.parent.parent.parent / "apps"
        nl_generator = NLAppGenerator(apps_dir)
        
        # Load NL configuration
        nl_config = await nl_generator.load_nl_config(app_name)
        if not nl_config:
            raise HTTPException(status_code=400, detail=f"Failed to load configuration from {request.nl_file_path}")
        
        # Generate the app
        success = await nl_generator.generate_app_from_nl(app_name, nl_config)
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to generate app")
        
        # Get list of generated files
        generated_files = await _get_generated_files(app_name)
        
        # Check if app already exists
        app_info = app_loader.apps.get(app_name)
        if app_info:
            message = f"App '{app_name}' regenerated successfully. Please restart the server to load the updated endpoints."
        else:
            message = f"New app '{app_name}' generated successfully. Please restart the server to load it."
            # Update apps.json with new app
            await app_loader._save_apps_json()
        
        return GenerateResponse(
            success=True,
            app_name=app_name,
            message=message,
            generated_files=generated_files,
            restart_required=True
        )
            
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error generating app: {str(e)}")


async def _get_generated_files(app_name: str) -> list:
    """Get list of generated files for an app."""
    apps_dir = Path(__file__).parent.parent.parent.parent / "apps"
    app_path = apps_dir / app_name
    
    generated_files = []
    
    # Check api directory
    api_dir = app_path / "api"
    if api_dir.exists():
        for file in api_dir.rglob("*.py"):
            if not file.name.startswith("_"):
                generated_files.append(str(file.relative_to(app_path)))
    
    # Check static directory
    static_dir = app_path / "static"
    if static_dir.exists():
        for file in static_dir.rglob("*"):
            if file.is_file():
                generated_files.append(str(file.relative_to(app_path)))
    
    return generated_files
