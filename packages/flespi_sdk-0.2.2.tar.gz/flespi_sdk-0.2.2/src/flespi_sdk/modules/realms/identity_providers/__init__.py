import aiohttp
from flespi_sdk.base.items import Items
from flespi_sdk.modules.realms.identity_providers.identity_provider import (
    RealmIdentityProvider,
)


class IdentityProviders(Items):
    TOP_ITEMS = False
    ID_FIELD_NAME = "identity_provider_id"
    DEFAULT_FIELDS = RealmIdentityProvider.FIELDS

    def __init__(self, realm_id: int, session: aiohttp.ClientSession, operate_as: int):
        self.realm_id = realm_id
        super().__init__(
            items_path=f"/platform/realms/{realm_id}/identity-providers",
            session=session,
            operate_as=operate_as,
        )

    def construct_item(self, item: dict):
        return RealmIdentityProvider(
            realm_id=self.realm_id,
            item=item,
            session=self.session,
            operate_as=self.operate_as,
        )
