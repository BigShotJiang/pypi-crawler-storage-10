import aiohttp
from flespi_sdk.base.items import Items
from flespi_sdk.modules.identity_providers.identity_provider import (
    IdentityProvider,
)


class IdentityProviders(Items):
    TOP_ITEMS = True
    DEFAULT_FIELDS = IdentityProvider.FIELDS

    def __init__(self, session: aiohttp.ClientSession, operate_as: int):
        super().__init__(
            items_path="/platform/identity-providers",
            session=session,
            operate_as=operate_as,
        )

    def construct_item(self, item: dict):
        return IdentityProvider(
            item=item,
            session=self.session,
            operate_as=self.operate_as,
        )
