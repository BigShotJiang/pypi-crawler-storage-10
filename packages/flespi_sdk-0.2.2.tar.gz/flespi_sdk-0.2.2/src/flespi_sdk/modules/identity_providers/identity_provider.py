from aiohttp import ClientSession

from flespi_sdk.base.item import Item


class IdentityProvider(Item):
    FIELDS = [
        "blocked",
        "type",
        "configuration",
        "public_info",
    ]

    def __init__(
        self,
        item: dict,
        session: ClientSession,
        operate_as: int,
    ):
        provider_id = item["id"]
        super().__init__(
            id=provider_id,
            item_path=f"platform/identity-providers/{provider_id}",
            session=session,
            operate_as=operate_as,
        )
        self.enabled = None
        self.allow_registration = None
        self.blocked = None
        self.type = None
        self.configuration = None
        self.public_info = None
        self._update_fields(item=item)

    def __str__(self):
        return f"IdentityProvider(id={self.id}, name={self.name}, type={self.type}, enabled={self.enabled})"
