from dataclasses import dataclass


@dataclass
class FlespiError:
    code: int
    reason: str
    id: int | None = None
    selector: str | None = None
    field: str | None = None


class FlespiException(Exception):
    def __init__(self, status_code: int, errors: list[dict]):
        self.status_code = status_code
        self.errors = [FlespiError(**error) for error in errors]

    def __str__(self):
        error_messages = [
            f"[{error.code}] {error.reason} (id: {error.id}, selector: {error.selector}, field: {error.field})"
            for error in self.errors
        ]
        return f"FlespiException: status_code={self.status_code}, errors=[{', '.join(error_messages)}]"
