#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Base Backend
"""

import sys
import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, Optional, Union

logger = logging.getLogger(__name__)

# Type aliases
ParamValue = Optional[Union[bool, int, float, str]]
NodeId = Optional[int]

class BackendInitializationError(Exception):
    """Raised when a backend cannot be initialized (e.g., missing device or driver)."""
    pass

class BaseBackend(ABC):
    """Abstract base class defining the backend communication interface."""

    def __init__(self) -> None:
        """Initialize the base backend."""
        logger.info("Hello from base backend")

    @abstractmethod
    def tick(self, dt: float) -> None:
        """Perform backend-specific periodic tasks."""

    #
    # Topics API: subscribe and publish
    #
    @abstractmethod
    def subscribe(self, topic: str, callback: Callable, node_id: NodeId = None) -> None:
        """Subscribe to messages from a given topic."""
        logger.warning("Not implemented in %s: subscribe(%s, cb, %s)",
                       self.__class__.__name__, topic, node_id)

    @abstractmethod
    def advertise(self, topic: str, field: str, frequency: float = 10.0) -> None:
        """Register a periodic message publisher."""
        logger.warning("Not implemented in %s: advertise(%s, %s, %s)",
                       self.__class__.__name__, topic, field, frequency)

    @abstractmethod
    def set_publisher_field(self, topic: str, field: str, value: Any) -> None:
        """Update value for an existing publisher."""
        logger.warning("Not implemented in %s: set_publisher_field(%s, %s, %s)",
                       self.__class__.__name__, topic, field, value)

    #
    # Parameters API: read and write
    #
    @abstractmethod
    def subscribe_param(self, node_id: int, param_name: str, setText: Callable) -> None:
        """Read a parameter from the node."""
        logger.warning("Not implemented in %s: subscribe_param(%s, %s, cb)",
                       self.__class__.__name__, node_id, param_name)

    @abstractmethod
    def set_param(self, node_id: NodeId, param_name: str, value: Any) -> ParamValue:
        """Write a parameter value to the node."""
        logger.warning("Not implemented in %s: set_param(%s, %s, %s)",
                       self.__class__.__name__, node_id, param_name, value)

    #
    # GetInfo API: subscribe
    #
    @abstractmethod
    def subscribe_get_info(self, node_id: int, field: str, callback: Callable) -> None:
        """Write a parameter value to the node."""
        logger.warning("Not implemented in %s: subscribe_get_info(%s, %s, cb)",
                       self.__class__.__name__, node_id, field)

    #
    # Commands API
    #
    def execute_command(self, node_id: int, command: str) -> None:
        """Execute command"""
        logger.warning("Not implemented in %s: execute_command(%s, %s)",
                       self.__class__.__name__, node_id, command)

def instanciate_backend(backend: str, iface: str, node_id: Optional[int]) -> BaseBackend:
    logger.info("Start backend: %s / id=%s / iface=%s", backend, node_id, iface)

    if backend == "dummy":
        from tsugite.backend.dummy_backend import DummyBackend
        communicator = DummyBackend()
    elif backend == "dronecan":
        # Supress dronecan internal logging
        logging.getLogger("dronecan").setLevel(logging.WARNING)

        from tsugite.backend.dronecan_backend import DronecanBackend
        communicator = DronecanBackend(iface=iface, node_id=node_id)
    elif backend == "cyphal":
        raise BackendInitializationError(f"Cyphal is not supported at the moment")
    else:
        raise BackendInitializationError("Unknown backend")

    return communicator
