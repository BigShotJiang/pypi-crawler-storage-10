import argparse
import os
import subprocess

from simple_slurm import Slurm


def setup_args(subparsers: "argparse._SubParsersAction") -> None:
    subformat = subparsers.add_parser(
        "gctb-impute", formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    group_exec = subformat.add_argument_group("execution options")

    subformat.add_argument(
        metavar="trait_name",
        dest="trait_name",
        help="name of the trait",
        type=str,
    )
    subformat.add_argument(
        metavar="root",
        dest="root",
        help="path to the summaries root directory",
        type=str,
    )
    subformat.add_argument(
        metavar="mldm",
        dest="matrix",
        help="path to the matrix of LD scores",
        type=str,
    )

    action = subformat.add_mutually_exclusive_group(required=True)

    # option to impute blocks through slurm
    action.add_argument(
        "--slurm-impute-blocks",
        "-b",
        dest="impute_blocks",
        help="impute the blocks through slurm jobs",
        action="store_true",
    )

    # option to merge imputed blocks
    action.add_argument(
        "--merge-blocks",
        "-m",
        dest="merge_blocks",
        help="merge the imputed blocks",
        action="store_true",
    )

    # option to run the complete imputation
    action.add_argument(
        "--local-impute",
        "-l",
        dest="local_impute",
        help="run the complete imputation locally",
        action="store_true",
    )

    group_exec.add_argument(
        "--threads",
        "-t",
        dest="threads",
        help="number of threads to use (only for the local imputation)",
        type=int,
        default=1,
    )
    group_exec.add_argument(
        "--gctb-executable",
        dest="gctb_executable",
        help="path to the gctb executable",
        type=str,
        default="gctb",
    )
    group_exec.add_argument(
        "--print-only",
        dest="print_only",
        help="print the command only",
        action="store_true",
    )


def run(args):
    gctb_impute(
        root=args.root,
        trait_name=args.trait_name,
        matrix=args.matrix,
        impute_blocks=args.impute_blocks,
        merge_blocks=args.merge_blocks,
        local_impute=args.local_impute,
        threads=args.threads,
        gctb_executable=args.gctb_executable,
        print_only=args.print_only,
    )


def gctb_impute(
    root,
    trait_name,
    matrix,
    impute_blocks=False,
    merge_blocks=False,
    local_impute=True,
    threads=1,
    gctb_executable="gctb",
    print_only=False,
    **kwargs,
):
    if impute_blocks:
        command = f"{gctb_executable} --impute-summary --ldm-eigen {matrix} --gwas-summary {root}/{trait_name}/summary.cojo.tsv --out {root}/{trait_name}/summary.cojo"
        if print_only:
            print(f"{command} --block [1,591]")
        else:
            os.makedirs(f"{root}/{trait_name}/logs", exist_ok=True)
            slurm_block = Slurm(
                partition="ghfc",
                qos="ghfc",
                cpus_per_task=1,
                mem="5G",
                array=range(1, 592),
                job_name=f"gctb_impute_{trait_name.split('/')[0]}",
                output=f"{root}/{trait_name}/logs/gctb_impute_block%a.txt",
            )
            slurm_block.sbatch(f"{command} --block {Slurm.SLURM_ARRAY_TASK_ID}")
        return

    if merge_blocks:
        command = f"cd {root}/{trait_name} ; {gctb_executable} --gwas-summary summary.cojo --merge-block-gwas-summary --out summary.cojo.imputed"
        if print_only:
            print(command)
        else:
            os.makedirs(f"{root}/{trait_name}/logs", exist_ok=True)
            subprocess.run(
                f"{command} > {root}/{trait_name}/logs/gctb_impute_merge.txt",
                shell=True,
            )
        return

    if local_impute:
        command = f"{gctb_executable} --impute-summary --ldm-eigen {matrix} --thread {threads} --gwas-summary {root}/{trait_name}/summary.cojo.tsv --out {root}/{trait_name}/summary.cojo"
        if print_only:
            print(command)
        else:
            os.makedirs(f"{root}/{trait_name}/logs", exist_ok=True)
            subprocess.run(
                f"{command} > {root}/{trait_name}/logs/gctb_local_impute.txt",
                shell=True,
            )
        return
