import argparse
import os

import pandas as pd
from tqdm import tqdm


def setup_args(subparsers: "argparse._SubParsersAction") -> None:
    """register arguments for this submodule of the argparse

    Args:
        subparsers (argparse._SubParsersAction): the subparsers to register into
    """
    subformat = subparsers.add_parser("create-catalog")
    subformat.add_argument(
        metavar="root",
        dest="root",
        help="collection of summaries to put in the catalog",
        type=str,
    )
    subformat.add_argument(
        "--tool",
        "-t",
        dest="tool",
        help="tool used to generate the summary",
        type=str,
        default="sbayesrc",
    )
    subformat.add_argument(
        "--force", "-f", help="force the processing", action="store_true"
    )


def run(args):
    list_pgs = []
    # loop over all entity.yaml file in the args.root directory
    for root, _, files in os.walk(args.root):
        if ("entity.yaml" in files) and (f"summary.{args.tool}.snpRes" in files):
            pgs_name = root[len(args.root) :]
            if pgs_name.startswith("/"):
                pgs_name = pgs_name[1:]
            list_pgs.append(pgs_name)
    list_pgs.sort()

    first_p = True

    for p in (pbar := tqdm(list_pgs, desc="cataloging summaries")):
        pbar.set_description("processing " + p)
        df_p = pd.read_table(
            f"{args.root}/{p}/summary.{args.tool}.snpRes",
            sep="\\s+",
            usecols=["Name", "Chrom", "Position", "A1", "A2", "A1Effect"],
        )
        df_p.columns = ["Name", "Chrom", "Position", "A1", "A2", p]
        if first_p:
            df = df_p
            first_p = False
        else:
            df = pd.merge(
                df, df_p, how="outer", on=["Name", "Chrom", "Position", "A1", "A2"]
            )
    df.fillna(0, inplace=True)
    df.to_csv(f"{args.root}/catalog.tsv", sep="\t", index=False)
    print(
        f"catalog saved in {args.root}/catalog.tsv.",
        f"Length: {len(df)}.",
        f"Nb duplicated names: {len(df[df.duplicated('Name')])}",
        sep="\n",
    )
    return 0
