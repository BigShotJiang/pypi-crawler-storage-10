import argparse
import glob
import os

from tqdm import tqdm

from . import gctb_impute
from .status import get_nb_imputed_blocks, get_nb_merged_blocks


def setup_args(subparsers: "argparse._SubParsersAction") -> None:
    """register arguments for this submodule of the argparse

    Args:
        subparsers (argparse._SubParsersAction): the subparsers to register into
    """
    subformat = subparsers.add_parser("gctb-impute-all")
    subformat.add_argument(
        metavar="root",
        dest="root",
        help="absolute path to the collection of summaries to impute with GCTB",
        type=str,
    )
    subformat.add_argument(
        metavar="mldm",
        dest="matrix",
        help="absolute path to the matrix of LD scores",
        type=str,
    )

    action = subformat.add_mutually_exclusive_group(required=True)

    # option to impute blocks through slurm
    action.add_argument(
        "--slurm-impute-blocks",
        "-b",
        dest="impute_blocks",
        help="impute the blocks through slurm jobs",
        action="store_true",
    )

    # option to merge imputed blocks
    action.add_argument(
        "--merge-blocks",
        "-m",
        dest="merge_blocks",
        help="merge the imputed blocks",
        action="store_true",
    )

    # option to run the complete imputation
    action.add_argument(
        "--local-impute",
        "-l",
        dest="local_impute",
        help="run the complete imputation locally",
        action="store_true",
    )

    group_exec = subformat.add_argument_group("execution options")

    group_exec.add_argument(
        "--threads",
        dest="threads",
        help="number of threads to use",
        type=int,
        default=1,
    )
    group_exec.add_argument(
        "--gctb-executable",
        dest="gctb_executable",
        help="path to the gctb executable",
        type=str,
        default="gctb",
    )
    group_exec.add_argument(
        "--print-only",
        dest="print_only",
        help="print the command only",
        action="store_true",
    )
    group_exec.add_argument(
        "--force",
        "-f",
        help="force the processing even if file already exists",
        action="store_true",
    )


def run(args):
    list_pgs = []
    for root, _, files in os.walk(args.root):
        if "summary.cojo.tsv" in files:
            pgs_name = root[len(args.root) :]
            if pgs_name.startswith("/"):
                pgs_name = pgs_name[1:]

            if not args.force:
                if "summary.cojo.imputed.ma" in files:
                    if (
                        args.merge_blocks
                        and (
                            len(glob.glob(f"{root}/summary.cojo.block*.imputed.ma"))
                            >= 1
                        )
                        and (
                            get_nb_imputed_blocks(root, pgs_name)
                            > get_nb_merged_blocks(root, pgs_name)
                        )
                    ):
                        print(
                            f"{pgs_name} has imputed blocks to merge but not all are merged"
                        )
                    else:
                        continue
                else:
                    if args.merge_blocks and (
                        len(glob.glob(f"{root}/summary.cojo.block*.imputed.ma")) < 1
                    ):
                        print(f"{pgs_name} has no imputed blocks to merge")
                        continue
            else:
                if args.merge_blocks and (
                    len(glob.glob(f"{root}/summary.cojo.block*.imputed.ma")) < 1
                ):
                    print(f"{pgs_name} has no imputed blocks to merge")
                    continue

            list_pgs.append(pgs_name)
    list_pgs.sort()

    for p in (pbar := tqdm(list_pgs, desc="running GCTB", disable=(args.print_only))):
        pbar.set_description("running GCTB imputation on " + p)
        gctb_impute.gctb_impute(trait_name=p, **vars(args))
