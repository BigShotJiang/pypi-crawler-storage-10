import argparse
import glob
import os

import pandas as pd
from termcolor import colored

DONE_STR = colored("done", "green")
NOT_DONE_STR = colored("not done", "red")
PB_STR = colored("PB", "red")


def setup_args(subparsers: "argparse._SubParsersAction") -> None:
    """register arguments for this submodule of the argparse

    Args:
        subparsers (argparse._SubParsersAction): the subparsers to register into
    """
    subformat = subparsers.add_parser("status")
    subformat.add_argument(
        "--root",
        dest="root",
        help="collection of summaries to get the status on",
        type=str,
        default=".",
    )
    subformat.add_argument(
        "--details",
        "-d",
        dest="details",
        help="show details",
        action="store_true",
    )
    subformat.add_argument(
        "--hide-ok",
        "-H",
        dest="hide_ok",
        help="hide OK status",
        action="store_true",
    )


def is_processed_sbayesrc(root, pgs_name):
    if os.path.isfile(f"{root}/{pgs_name}/summary.sbayesrc.snpRes"):
        return f"{colored('done', 'green')}"
    return f"{colored('not done', 'red')}"


def get_hsq_sbayesrc(root, pgs_name):
    if os.path.isfile(f"{root}/{pgs_name}/logs/sbayesrc.txt"):
        with open(f"{root}/{pgs_name}/logs/sbayesrc.txt") as f:
            for line in f:
                line = line.strip()
                if line.startswith("hsq"):
                    return float(line.split()[1])
    return -1


def is_formated(root, pgs_name):
    if os.path.isfile(f"{root}/{pgs_name}/summary.cojo.tsv"):
        with open(f"{root}/{pgs_name}/summary.cojo.tsv") as f:
            header = f.readline().strip()
            if header == "SNP\tA1\tA2\tfreq\tb\tse\tp\tN":
                line = f.readline().strip()
                if line.split("\t")[-1] != "0":
                    # check if one of the frist 10 rows starts with "rs"
                    for _ in range(20):
                        line = f.readline().strip()
                        if line.split("\t")[0].startswith("rs"):
                            return f"{DONE_STR}"
                    return f"{PB_STR}: SNP are not rsIDs"
                else:
                    return f"{PB_STR}: N column is 0"
            else:
                return f"{PB_STR}: header problem"
    else:
        return f"{NOT_DONE_STR}"
    return f"{colored('unknown problem', 'red')}"


def get_nb_imputed_blocks(root, pgs_name):
    return len(glob.glob(f"{root}/{pgs_name}/summary.cojo.block*.imputed.ma"))


def get_nb_merged_blocks(root, pgs_name):
    # if f"{root}/{pgs_name}/logs/gctb_impute_merge.txt") does not exist, return -1
    if not os.path.isfile(f"{root}/{pgs_name}/logs/gctb_impute_merge.txt"):
        return -1
    # grep "Merging GWAS summary statistics files across" from the gctb_impute_merge.txt log file
    with open(f"{root}/{pgs_name}/logs/gctb_impute_merge.txt") as f:
        for line in f:
            if "Merging GWAS summary statistics files across" in line:
                return int(line.split()[6])


def is_imputed(root, pgs_name):
    if os.path.isfile(f"{root}/{pgs_name}/summary.cojo.imputed.ma"):
        # need to check if all the blocks were merged together
        nb_imputed_blocks = get_nb_imputed_blocks(root, pgs_name)
        nb_merged_blocks = get_nb_merged_blocks(root, pgs_name)
        if nb_merged_blocks == -1:
            return f"{PB_STR}: missing log file"
        if nb_imputed_blocks == nb_merged_blocks:
            return f"{DONE_STR}"
        return f"{PB_STR}: missing {nb_imputed_blocks - nb_merged_blocks} blocks"
    return f"{NOT_DONE_STR}"


def run(args):
    """
    Executes the main logic for processing PGS (Polygenic Scores) modules.

    Args:
        args: An object containing the following attributes:
            - root (str): The root directory to start the search.
            - hide_ok (bool): A flag to hide entries that are marked as done.

    Returns:
        None

    The function performs the following steps:
        1. Walks through the directory tree starting from `args.root`.
        2. Collects directories containing "entity.yaml" files, excluding "logs" directories.
        3. Sorts the collected directories.
        4. For each collected directory, checks the formatting, imputation, and SBayesRC processing status.
        5. Generates a report containing the status of each directory.
        6. Optionally filters out entries that are marked as done if `args.hide_ok` is True.
        7. Prints the report as a markdown table.
    """
    list_pgs = []
    for root, dirs, files in os.walk(args.root):
        if "logs" in dirs:
            dirs.remove("logs")
        if "entity.yaml" in files:
            pgs_name = root[len(args.root) :]
            if pgs_name.startswith("/"):
                pgs_name = pgs_name[1:]
            list_pgs.append(pgs_name)
    list_pgs.sort()

    t_report = []

    for p in list_pgs:
        t_report.append(
            [
                p,
                is_formated(args.root, p),
                is_imputed(args.root, p),
                get_nb_merged_blocks(args.root, p),
                is_processed_sbayesrc(args.root, p),
                get_hsq_sbayesrc(args.root, p),
            ]
        )

    if args.hide_ok:
        t_report = [r for r in t_report if ((r[4] != DONE_STR) or (r[1] != DONE_STR))]

    print(
        pd.DataFrame(
            t_report,
            columns=[
                "PGS",
                "formating",
                "imputation",
                "blocks",
                "SBayesRC",
                "SBayesRC hsq",
            ],
        ).to_markdown(index=False)
    )
