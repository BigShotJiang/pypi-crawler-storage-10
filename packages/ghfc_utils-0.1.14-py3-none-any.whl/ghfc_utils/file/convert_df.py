import argparse

from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument(
        "-g",
        "--ghfc-file",
        dest="ghfc_file",
        help="name of the GhfcFile to extract the dataframe to",
        required=True,
        type=str,
    )
    subparser.add_argument(
        "--key",
        "-k",
        dest="key",
        help="access key for the dataframe in the GhfcFile",
        type=str,
        required=True,
    )
    subparser.add_argument(
        "--format",
        "-f",
        dest="format",
        help="format of the dataframe (default: tsv)",
        type=str,
        default="tsv",
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode (default: False)",
        default=False,
        action="store_true",
    )


def run(args):
    convert_df(
        args.ghfc_file,
        args.key,
        args.format,
        args.verbose,
    )


def convert_df(
    ghfc_file: str,
    key: str,
    format: str = "tsv",
    verbose: bool = False,
) -> None:
    if not verbose:
        logger.remove()
    with GhfcFile(ghfc_file, mode="a") as gf:
        if key not in gf.keys():
            logger.error(f"{key} does not exist in {ghfc_file}")
            raise ValueError(f"{key} does not exist in {ghfc_file}")
        if gf.summary[key]["format"] == format:
            logger.info(f"{key} is already in {format} format")
            return
        df = gf.getDataFrame(key)
        gf.addDataFrame(df, key, format=format)
        logger.info(f"Converted dataframe {key} to {format} format")
