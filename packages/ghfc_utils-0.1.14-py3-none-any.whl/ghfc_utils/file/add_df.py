import argparse

import pandas as pd
from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument(
        "-g",
        "--ghfc-file",
        dest="ghfc_file",
        help="name of the GhfcFile to add the dataframe to",
        required=True,
        type=str,
    )
    subparser.add_argument(
        "--dataframe",
        "-d",
        dest="dataframe",
        help="add a dataframe to the GhfcFile",
        default=False,
        type=str,
        required=True,
    )
    subparser.add_argument(
        "--key",
        "-k",
        dest="key",
        help="access key for the dataframe in the GhfcFile",
        type=str,
        required=True,
    )
    subparser.add_argument(
        "--format",
        "-f",
        dest="format",
        help="format of the dataframe (default: tsv)",
        type=str,
        default="tsv",
    )
    subparser.add_argument(
        "--description",
        "-D",
        dest="description",
        help="description of the dataframe (default: '')",
        type=str,
        default="",
    )
    subparser.add_argument(
        "--overwrite",
        "-o",
        dest="overwrite",
        help="overwrite the dataframe if it already exists (default: False)",
        default=False,
        action="store_true",
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode (default: False)",
        default=False,
        action="store_true",
    )


def run(args):
    add_df(
        args.ghfc_file,
        args.dataframe,
        args.key,
        args.format,
        args.description,
        args.overwrite,
        args.verbose,
    )


def add_df(
    ghfc_file: str,
    dataframe: str,
    key: str,
    format: str = "tsv",
    description: str = "",
    overwrite: bool = False,
    verbose: bool = False,
) -> None:
    if not verbose:
        logger.remove()
    if not overwrite:
        with GhfcFile(ghfc_file) as gf:
            if key in gf.keys():
                raise ValueError(
                    f"{key} already exists in {ghfc_file}, Set overwrite to True or change key."
                )
    with GhfcFile(ghfc_file, mode="a") as gf:
        if dataframe.endswith(".tsv"):
            df = pd.read_table(dataframe)
        elif dataframe.endswith(".csv"):
            df = pd.read_csv(dataframe)
        elif dataframe.endswith(".feather"):
            df = pd.read_feather(dataframe)
        else:
            raise ValueError(f"Unsupported format: {dataframe}")
        gf.addDataFrame(df, key, format)
        logger.info(f"Added {key} to {ghfc_file}")
        logger.info(f"Description: {description}")
