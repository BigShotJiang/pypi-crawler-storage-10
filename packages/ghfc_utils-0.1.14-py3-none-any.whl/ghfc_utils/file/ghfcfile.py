import os
from tempfile import TemporaryDirectory
from typing import List
from zipfile import ZIP_DEFLATED, ZipFile

import pandas as pd
from loguru import logger

from ghfc_utils.utils.timer import Timer


class GhfcFile:
    def __init__(self, name: str, mode: str = "r", overwrite: bool = False):
        valid_mode = {"r", "w", "a"}
        if mode not in valid_mode:
            raise ValueError("GhfcFile: mode must be one of %r." % valid_mode)
        self.dir = os.path.dirname(name)
        self.name = os.path.basename(name)
        self.mode = mode
        self.overwrite = overwrite

    def __str__(self):
        return f"GhfcFile({self.name}, {self.dir}, {self.mode}, {self.overwrite}, {self.get_fullpath()})"

    @Timer(name="__enter__", logger=logger.info)
    def __enter__(self):
        logger.info(f"Opening {self.name}")
        self.__read_summary()
        if self.mode == "r":
            return self

        if self.mode in {"w", "a"}:
            if os.path.exists(self.get_fullpath()):
                if self.mode == "w":
                    if not self.overwrite:
                        logger.error(
                            f"{self.get_fullpath()} already exists, Set overwrite to True or change name."
                        )
                        raise ValueError(
                            f"{self.get_fullpath()} already exists, Set overwrite to True or change name."
                        )
                    else:
                        self.summary = {}
                        logger.info(f"Overwriting {self.name}")
                if self.mode == "a":
                    logger.info(f"Appending to {self.name}")
            else:
                logger.info(f"Creating {self.name}")
            self.shortname = os.path.splitext(self.name)[0]
            self.tempdir = TemporaryDirectory(
                dir=self.dir, prefix=f"temp_{self.shortname}_"
            )
            logger.debug(f"tempdir: {self.tempdir.name}")
            if self.mode == "a":
                with ZipFile(self.get_fullpath(), "r") as z:
                    z.extractall(self.tempdir.name)
                pass
            logger.add(os.path.join(self.tempdir.name, "log.txt"), level="DEBUG")
            return self
        return None

    @Timer(name="__exit__", logger=logger.info)
    def __exit__(self, exc_type, exc_value, traceback):
        logger.info(f"Closing {self.name}...")
        if self.mode == "w" or self.mode == "a":
            self.__write_summary()
            with ZipFile(self.get_fullpath(), "w", compression=ZIP_DEFLATED) as z:
                for root, dirs, files in os.walk(self.tempdir.name):
                    for file in files:
                        relpath = os.path.relpath(
                            os.path.join(root, file), self.tempdir.name
                        )
                        logger.info(f"Writing {relpath} into {self.name}")
                        z.write(os.path.join(root, file), relpath)
            self.tempdir.cleanup()

    def get_fullpath(self) -> str:
        return os.path.join(self.dir, self.name)

    def list(self) -> list[str]:
        if self.mode == "r":
            with ZipFile(self.get_fullpath(), "r") as z:
                return z.namelist()
        if self.mode in {"w", "a"}:
            l_content = []
            for root, dirs, files in os.walk(self.tempdir.name):
                for file in files:
                    l_content.append(
                        os.path.relpath(
                            os.path.join(root, file),
                            self.tempdir.name,
                        )
                    )
            return l_content
        return []

    @Timer(name="addDataFrame", logger=logger.info)
    def addDataFrame(self, df: pd.DataFrame, key: str, format: str = "tsv"):
        valid_format = {"tsv", "feather"}
        if format not in valid_format:
            logger.error("addDataFrame: format must be one of %r." % valid_format)
            raise ValueError("addDataFrame: format must be one of %r." % valid_format)
        if self.mode not in {"w", "a"}:
            logger.error("addDataFrame: read only, change mode to 'w' or 'a'.")
            raise ValueError("addDataFrame: mode must be 'w' or 'a'.")
        logger.info(f"Adding DataFrame {key} with format {format}")
        temp_file = os.path.join(self.tempdir.name, key)
        logger.debug(f"writing to {temp_file}")
        os.makedirs(os.path.dirname(temp_file), exist_ok=True)
        if format == "tsv":
            df.to_csv(f"{temp_file}.{format}", sep="\t", index=False)
        if format == "feather":
            df.to_feather(f"{temp_file}.{format}")
        if not hasattr(self, "summary"):
            self.summary = {}
        self.summary[key] = {
            "key": key,
            "format": format,
            "filesize": sizeof_fmt(os.path.getsize(f"{temp_file}.{format}")),
            "nb_rows": df.shape[0],
            "nb_cols": df.shape[1],
        }

    def getDataFrame(self, key: str) -> pd.DataFrame:
        logger.trace(f"Getting DataFrame {key}")
        logger.trace(f"keys: {self.keys()}")
        if key not in self.keys():
            logger.error(f"Key {key} not found in {self.name}")
            raise ValueError(f"Key {key} not found in {self.name}")
        if self.mode == "r":
            logger.info(f"Reading DataFrame {key} from zip")
            return self.__readDataFrameFromZip(key, self.summary[key]["format"])
        if self.mode in {"w", "a"}:
            logger.info(f"Reading DataFrame {key} from tempdir")
            return self.__readDataFrameFromTempdir(key, self.summary[key]["format"])
        return pd.DataFrame()

    def removeDataFrame(self, key: str) -> None:
        if self.mode not in {"w", "a"}:
            logger.error("removeDataFrame: read only, change mode to 'w' or 'a'.")
            raise ValueError("removeDataFrame: mode must be 'w' or 'a'.")
        logger.info(f"Removing DataFrame {key}")
        if key not in self.keys():
            logger.error(f"Key {key} not found in {self.name}")
            raise ValueError(f"Key {key} not found in {self.name}")
        temp_file = os.path.join(self.tempdir.name, key)
        os.remove(f"{temp_file}.{self.summary[key]['format']}")
        del self.summary[key]

    @Timer(name="__readDataFrameFromZip", logger=logger.info)
    def __readDataFrameFromZip(self, key: str, format: str) -> pd.DataFrame:
        valid_format = {"tsv", "feather"}
        if format not in valid_format:
            logger.error(
                "__readDataFrameFromZip: format must be one of %r." % valid_format
            )
            raise ValueError(
                "__readDataFrameFromZip: format must be one of %r." % valid_format
            )
        with ZipFile(self.get_fullpath(), "r") as z:
            with z.open(f"{key}.{format}", mode="r") as f:
                if format == "tsv":
                    return pd.read_table(f, sep="\t")
                if format == "feather":
                    return pd.read_feather(f)

    @Timer(name="__readDataFrameFromTempdir", logger=logger.info)
    def __readDataFrameFromTempdir(self, key: str, format: str) -> pd.DataFrame:
        valid_format = {"tsv", "feather"}
        if format not in valid_format:
            logger.error(
                "__readDataFrameFromTempdir: format must be one of %r." % valid_format
            )
            raise ValueError(
                "__readDataFrameFromTempdir: format must be one of %r." % valid_format
            )
        temp_file = os.path.join(self.tempdir.name, f"{key}.{format}")
        if format == "tsv":
            return pd.read_table(temp_file, sep="\t")
        if format == "feather":
            return pd.read_feather(temp_file)

    def addConfig(self, config: dict, key: str):
        if self.mode not in {"w", "a"}:
            logger.error("addConfig: read only, change mode to 'w' or 'a'.")
            raise ValueError("addConfig: mode must be 'w' or 'a.")
        logger.info(f"Adding config {key}")
        logger.warning("Not implemented yet")

    def addFile(
        self, file: str, key: str, format: str, nb_rows: int = -1, nb_cols: int = -1
    ):
        if self.mode not in {"w", "a"}:
            logger.error("addFile: read only, change mode to 'w' or 'a'.")
            raise ValueError("addFile: mode must be 'w' or 'a.")
        logger.info(f"Adding file {key}")
        logger.warning("Not implemented yet")

    def keys(self) -> List:
        if hasattr(self, "summary"):
            return list(self.summary.keys())
        return []

    def getSummary(self):
        if hasattr(self, "summary"):
            return pd.DataFrame(self.summary).T
        return pd.DataFrame()

    def getLog(self):
        if self.mode == "r":
            with ZipFile(self.get_fullpath(), "r") as z:
                with z.open("log.txt", mode="r") as f:
                    return f.read().decode("utf-8")
        if self.mode in {"w", "a"}:
            with open(os.path.join(self.tempdir.name, "log.txt"), "r") as f:
                return f.read()
        return ""

    def __write_summary(self) -> None:
        if hasattr(self, "summary") and self.mode in {"w", "a"}:
            with open(os.path.join(self.tempdir.name, "summary.tsv"), "w") as f:
                f.write(self.getSummary().to_csv(index=False, sep="\t"))

    def __read_summary(self) -> None:
        if os.path.exists(self.get_fullpath()):
            with ZipFile(self.get_fullpath(), "r") as z:
                if "summary.tsv" in z.namelist():
                    with z.open("summary.tsv", mode="r") as f:
                        self.summary = (
                            pd.read_table(f, sep="\t")
                            .set_index("key", drop=False)
                            .T.to_dict()
                        )
                        return
        self.summary = {}


def sizeof_fmt(num, suffix="B"):
    for unit in ("", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi"):
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Yi{suffix}"
