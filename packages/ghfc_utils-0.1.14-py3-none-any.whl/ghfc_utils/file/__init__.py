import argparse

from . import add_df, convert_df, export_df, log, remove_df, summary


def parse_app_args(args=None):
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(
        dest="cmd",
        help="GhfcFile manipulation tool. for additional help, run `ghfc-file <subcommand> -h`",
    )
    subparsers.required = True
    summary.setup_args(subparsers, "summary")
    log.setup_args(subparsers, "log")
    add_df.setup_args(subparsers, "addDF")
    remove_df.setup_args(subparsers, "removeDF")
    export_df.setup_args(subparsers, "exportDF")
    convert_df.setup_args(subparsers, "convertDF")

    return parser.parse_args(args)


def main() -> None:
    parsed_args = parse_app_args()
    command_map = {
        "summary": summary.run,
        "log": log.run,
        "addDF": add_df.run,
        "removeDF": remove_df.run,
        "exportDF": export_df.run,
        "convertDF": convert_df.run,
    }
    command_map[parsed_args.cmd](parsed_args)


if __name__ == "__main__":
    main()
