# submodule ghfc-file

Management of variout data use on our every day analysis, mostly tsv files such as the one produce by slivar, or the ones with PGS or ancestry informations. This could also work for clinic data and more. This is designed to keep multiple files together, keep track of what is done through an integrated log file, and also by keeping all config files used as a way to remember parameters used.

## File format: GhfcFile

Created as a zip file. This contains in a strucutred way multiple other files and can easily evolve. Due to the nature of zip file, when it is open for writing (`'w'` or `'a'`) it will work in a temporary directory and redo the compression at the end.

For the internal storage of dataframes, `tsv` and `feather` are both supported, each with pros and cons.

**TODO:** explain which one to use in which case

## CLI tools

```text
usage: ghfc-file [-h] {summary,log,addDF,removeDF,exportDF,convertDF} ...

positional arguments:
  {summary,log,addDF,removeDF,exportDF,convertDF}
                        GhfcFile manipulation tool. for additional help, run `ghfc-file <subcommand> -h`

options:
  -h, --help            show this help message and exit
```

### 1. summary

```text
usage: ghfc-file summary [-h] [-v] file

positional arguments:
  file           name of the GhfcFile to summarize

options:
  -h, --help     show this help message and exit
  -v, --verbose  activate verbose mode
```

Display the matrix from the file containing the content summary (list of tables and files in the archive).

### 2. log

```text
usage: ghfc-file log [-h] [-v] file

positional arguments:
  file           name of the GhfcFile to print log of

options:
  -h, --help     show this help message and exit
  -v, --verbose  activate verbose mode
```

To display or export the internal logfile.

### 3. addDF

```text
usage: ghfc-file addDF [-h] -g GHFC_FILE --dataframe DATAFRAME --key KEY [--format FORMAT] [--description DESCRIPTION] [--overwrite] [-v]

options:
  -h, --help            show this help message and exit
  -g GHFC_FILE, --ghfc-file GHFC_FILE
                        name of the GhfcFile to add the dataframe to
  --dataframe DATAFRAME, -d DATAFRAME
                        add a dataframe to the GhfcFile
  --key KEY, -k KEY     access key for the dataframe in the GhfcFile
  --format FORMAT, -f FORMAT
                        format of the dataframe (default: tsv)
  --description DESCRIPTION, -D DESCRIPTION
                        description of the dataframe (default: '')
  --overwrite, -o       overwrite the dataframe if it already exists (default: False)
  -v, --verbose         activate verbose mode (default: False)
```

Add a dataframe to the archive at a specific key, specifying the format.

### 4. removeDF

```text
usage: ghfc-file removeDF [-h] -g GHFC_FILE --key KEY [-v]

options:
  -h, --help            show this help message and exit
  -g GHFC_FILE, --ghfc-file GHFC_FILE
                        name of the GhfcFile to add the dataframe to
  --key KEY, -k KEY     access key for the dataframe in the GhfcFile
  -v, --verbose         activate verbose mode (default: False)
```

Remove a dataframe from the archive using its key

### 5. exportDF

```text
usage: ghfc-file exportDF [-h] -g GHFC_FILE --key KEY --output OUTPUT [--format FORMAT] [-v]

options:
  -h, --help            show this help message and exit
  -g GHFC_FILE, --ghfc-file GHFC_FILE
                        name of the GhfcFile to extract the dataframe to
  --key KEY, -k KEY     access key for the dataframe in the GhfcFile
  --output OUTPUT, -o OUTPUT
                        export the dataframe from the GhfcFile
  --format FORMAT, -f FORMAT
                        format of the dataframe (default: tsv)
  -v, --verbose         activate verbose mode (default: False)
```

Export the dataframe from the archive using its key to the given destination in the given format

### 6. convertDF

```text
usage: ghfc-file convertDF [-h] -g GHFC_FILE --key KEY [--format FORMAT] [-v]

options:
  -h, --help            show this help message and exit
  -g GHFC_FILE, --ghfc-file GHFC_FILE
                        name of the GhfcFile to extract the dataframe to
  --key KEY, -k KEY     access key for the dataframe in the GhfcFile
  --format FORMAT, -f FORMAT
                        format of the dataframe (default: tsv)
  -v, --verbose         activate verbose mode (default: False)
```

Convert the dataframe from inside the archive from one format to another (`tsv -> feather` or `feather -> tsv`)

### 7. addFile

Add a file to the archive at a key without changing anything about it, shoudl be avoided for dataframes

### 8. removeFile

Remove a file from the archive using its key

### 9. exportFile

Export file from the archive using its key and without changing its format
