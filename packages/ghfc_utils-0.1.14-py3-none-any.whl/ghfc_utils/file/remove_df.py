import argparse

from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument(
        "-g",
        "--ghfc-file",
        dest="ghfc_file",
        help="name of the GhfcFile to add the dataframe to",
        required=True,
        type=str,
    )
    subparser.add_argument(
        "--key",
        "-k",
        dest="key",
        help="access key for the dataframe in the GhfcFile",
        type=str,
        required=True,
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode (default: False)",
        default=False,
        action="store_true",
    )


def run(args):
    remove_df(
        args.ghfc_file,
        args.key,
        args.verbose,
    )


def remove_df(
    ghfc_file: str,
    key: str,
    verbose: bool = False,
) -> None:
    if not verbose:
        logger.remove()
    with GhfcFile(ghfc_file, mode="a") as gf:
        gf.removeDataFrame(key)
