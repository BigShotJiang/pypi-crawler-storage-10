import argparse

from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument("file", help="name of the GhfcFile to print log of")
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode",
        default=False,
        action="store_true",
    )


def run(args):
    log(args.file, args.verbose)


def log(file: str, verbose: bool = False) -> None:
    if not verbose:
        logger.remove()
    with GhfcFile(file) as gf:
        print(gf.getLog())
