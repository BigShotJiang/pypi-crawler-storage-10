import argparse

from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument("file", help="name of the GhfcFile to summarize")
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode",
        default=False,
        action="store_true",
    )


def run(args):
    summary(args.file, args.verbose)


def summary(file: str, verbose: bool = False) -> None:
    if not verbose:
        logger.remove()
    with GhfcFile(file) as gf:
        print(gf.getSummary().to_markdown())
