import argparse

from loguru import logger

from .ghfcfile import GhfcFile


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(parsername)
    subparser.add_argument(
        "-g",
        "--ghfc-file",
        dest="ghfc_file",
        help="name of the GhfcFile to extract the dataframe to",
        required=True,
        type=str,
    )
    subparser.add_argument(
        "--key",
        "-k",
        dest="key",
        help="access key for the dataframe in the GhfcFile",
        type=str,
        required=True,
    )
    subparser.add_argument(
        "--output",
        "-o",
        dest="output",
        help="export the dataframe from the GhfcFile",
        default=False,
        type=str,
        required=True,
    )
    subparser.add_argument(
        "--format",
        "-f",
        dest="format",
        help="format of the dataframe (default: tsv)",
        type=str,
        default="tsv",
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode (default: False)",
        default=False,
        action="store_true",
    )


def run(args):
    export_df(
        args.ghfc_file,
        args.key,
        args.output,
        args.format,
        args.verbose,
    )


def export_df(
    ghfc_file: str,
    key: str,
    output: str,
    format: str = "tsv",
    verbose: bool = False,
) -> None:
    if not verbose:
        logger.remove()
    with GhfcFile(ghfc_file, mode="r") as gf:
        if key not in gf.keys():
            logger.error(f"{key} does not exist in {ghfc_file}")
            raise ValueError(f"{key} does not exist in {ghfc_file}")
        df = gf.getDataFrame(key)
        if format == "tsv":
            df.to_csv(output, sep="\t", index=False)
        elif format == "csv":
            df.to_csv(output, index=False)
        elif format == "feather":
            df.to_feather(output, index=False)
        else:
            raise ValueError(f"Unknown format: {format}")
        logger.info(f"Exported dataframe {key} to {output} in {format} format")
