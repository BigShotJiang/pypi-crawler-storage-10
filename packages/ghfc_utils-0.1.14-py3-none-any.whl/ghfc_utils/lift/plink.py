import argparse

import pandas as pd
from liftover import get_lifter
from tqdm.auto import tqdm


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(
        parsername,
        description="Lift over a bim file from one genome version to another. This tool will output 2 files next to the bim file: (1.) a file with the SNPs that could not be lifted (*.toExclude.txt) and (2.) a file with the lifted SNPs (*.update-map-{source}-{dest}.txt)",
    )
    subparser.add_argument("bim", help="name of the bim file to lift")
    subparser.add_argument(
        "--source",
        "-s",
        dest="source",
        default="hg38",
        help="source genome version (hg19 or hg38)",
        type=str,
    )
    subparser.add_argument(
        "--dest",
        "-d",
        dest="dest",
        default="hg19",
        help="destination genome version (hg19 or hg38)",
        type=str,
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode",
        default=False,
        action="store_true",
    )


def run(args):
    liftover_plink(args.bim, args.source, args.dest, args.verbose)


def liftover_plink(bim, source, dest, verbose=False):
    valid_versions = ["hg19", "hg38"]
    if source not in valid_versions:
        raise ValueError(f"source version must be one of {valid_versions}")
    if dest not in valid_versions:
        raise ValueError(f"destination version must be one of {valid_versions}")
    if source == dest:
        raise ValueError("source and destination versions must be different")
    tqdm.pandas()
    df = pd.read_csv(bim, sep="\t", header=None)
    df.columns = ["chrom", "snp", "cm", "pos", "a1", "a2"]

    converter = get_lifter(source, dest)

    def convert(chr, p):
        chrom = str(chr)
        if chrom == "23":
            chrom = "X"
        pos = int(p)
        new_pos = converter[chrom][pos]
        if len(new_pos) == 0:
            return None
        new_pos = new_pos[0]
        if (new_pos[0] != chrom) and (new_pos[0][3:] != chrom):
            return None
        return str(new_pos[1])

    df["lifted_pos"] = df.progress_apply(
        lambda x: convert(x["chrom"], x["pos"]), axis=1
    )

    df[df["lifted_pos"].isna()][["snp"]].to_csv(
        f"{bim[:-4]}.toExclude.txt", index=False, header=None
    )

    df[df["lifted_pos"].notna()][["snp", "lifted_pos"]].to_csv(
        f"{bim[:-4]}.update-map-{source}-{dest}.txt", index=False, header=None, sep="\t"
    )

    return
