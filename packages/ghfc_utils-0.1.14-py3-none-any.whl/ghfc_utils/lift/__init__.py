import argparse

from . import bed, plink


def parse_app_args(args=None):
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(
        dest="cmd",
        help="Tool to perform liftover on various genomic file formats. for additional help, run `ghfc-lift <subcommand> -h`",
    )
    subparsers.required = True
    plink.setup_args(subparsers, "plink")
    bed.setup_args(subparsers, "bed")

    return parser.parse_args(args)


def main() -> None:
    parsed_args = parse_app_args()
    command_map = {
        "plink": plink.run,
        "bed": bed.run,
    }
    command_map[parsed_args.cmd](parsed_args)


if __name__ == "__main__":
    main()
