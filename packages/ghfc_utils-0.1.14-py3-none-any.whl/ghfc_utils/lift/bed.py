import argparse

import pandas as pd
from liftover import get_lifter
from tqdm.auto import tqdm


def setup_args(subparsers: "argparse._SubParsersAction", parsername: str) -> None:
    subparser = subparsers.add_parser(
        parsername,
        description="Lift over a bed file.",
    )
    subparser.add_argument("bed", help="name of the bed file to lift")
    subparser.add_argument("output", help="name of the output file")
    subparser.add_argument(
        "--source",
        "-s",
        dest="source",
        default="hg38",
        help="source genome version (hg19 or hg38)",
        type=str,
    )
    subparser.add_argument(
        "--dest",
        "-d",
        dest="dest",
        default="hg19",
        help="destination genome version (hg19 or hg38)",
        type=str,
    )
    subparser.add_argument(
        "--separator",
        "-sep",
        dest="separator",
        default="\t",
        help="separator used in the bed file (default: tab)",
        type=str,
    )
    subparser.add_argument(
        "--chr-col",
        dest="chr_col",
        default=0,
        help="column number containing of the chromosome (0-based, default: 0)",
        type=int,
    )
    subparser.add_argument(
        "--start-col",
        dest="start_col",
        default=1,
        help="column number containing of the start position (0-based, default: 1)",
        type=int,
    )
    subparser.add_argument(
        "--end-col",
        dest="end_col",
        default=2,
        help="column number containing of the end position (0-based, -1 to ignore, default: 2)",
        type=int,
    )
    subparser.add_argument(
        "--comment",
        dest="comment",
        default="#",
        help="comment character (default: #)",
        type=str,
    )
    subparser.add_argument(
        "--header",
        dest="header",
        default=False,
        help="header is present in the bed file (default: False)",
        action="store_true",
    )
    subparser.add_argument(
        "-v",
        "--verbose",
        dest="verbose",
        help="activate verbose mode",
        default=False,
        action="store_true",
    )


def run(args):
    liftover_bed(
        args.bed,
        args.output,
        args.source,
        args.dest,
        args.separator,
        args.chr_col,
        args.start_col,
        args.end_col,
        args.comment,
        args.header,
        args.verbose,
    )


def liftover_bed(
    bed,
    output,
    source="hg38",
    dest="hg19",
    separator="\t",
    chr_col=0,
    start_col=1,
    end_col=2,
    comment="#",
    header=False,
    verbose=False,
):
    valid_versions = ["hg19", "hg38"]
    if source not in valid_versions:
        raise ValueError(f"source version must be one of {valid_versions}")
    if dest not in valid_versions:
        raise ValueError(f"destination version must be one of {valid_versions}")
    if source == dest:
        raise ValueError("source and destination versions must be different")
    tqdm.pandas()
    if header:
        myheader = "infer"
    else:
        myheader = None
    df = pd.read_csv(bed, sep=separator, header=myheader, comment=comment)

    converter = get_lifter(source, dest)

    def convert(chr, p):
        chrom = str(chr)
        if chrom == "23":
            chrom = "X"
        pos = int(p)
        new_pos = converter[chrom][pos]
        if len(new_pos) == 0:
            return None
        new_pos = new_pos[0]
        if (new_pos[0] != chrom) and (new_pos[0][3:] != chrom):
            return None
        return str(new_pos[1])

    df["lifted_start"] = df.progress_apply(
        lambda x: convert(x[chr_col], x[start_col]), axis=1
    )
    df[start_col] = df["lifted_start"]
    df.drop(columns=["lifted_start"], inplace=True)
    if end_col != -1:
        df["lifted_end"] = df.progress_apply(
            lambda x: convert(x[chr_col], x[end_col]), axis=1
        )
        df[end_col] = df["lifted_end"]
        df.drop(columns=["lifted_end"], inplace=True)
    else:
        end_col = start_col

    if header:
        df[df[start_col].notna() & df[end_col].notna()].to_csv(
            output, index=False, sep=separator
        )
    else:
        df[df[start_col].notna() & df[end_col].notna()].to_csv(
            output, index=False, header=None, sep=separator
        )
    return
