import argparse
import re

from cyvcf2 import VCF


def parse_app_args(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--vcf",
        "-v",
        dest="vcf",
        help="name of the vcf file to query",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--sample",
        "-s",
        dest="sample",
        help="name of the sample to query",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--locus",
        "-l",
        dest="locus",
        help="locus to query (e.g. chr1:1000-2000)",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--header",
        "-H",
        dest="header",
        help="print header",
        default=False,
        action="store_true",
    )
    parser.add_argument(
        "--nohomref",
        "-n",
        dest="nohomref",
        help="do not print homozygous reference variants",
        default=False,
        action="store_true",
    )
    parser.add_argument(
        "--consequence",
        "-c",
        dest="consequence",
        help="print consequence annotations from Ensembl VEP",
        default=False,
        action="store_true",
    )
    parser.add_argument(
        "--filter_genes",
        "-f",
        dest="filter_genes",
        help="comma-separated list of genes to filter by (e.g. BRCA1,BRCA2)",
        type=str,
        default=None,
    )
    parser.add_argument(
        "--filter_impacts",
        "-i",
        dest="filter_impacts",
        help="comma-separated list of impacts to filter by (e.g. HIGH,MODERATE)",
        type=str,
        default=None,
    )

    return parser.parse_args(args)


def reformat_gt(genotype):
    return f"{genotype[0]}/{genotype[1]}"


def reformat_locus(locus):
    pattern = re.compile(r"^(chr)?([0-9XYMT]+):(\d+)-(\d+)$")
    if pattern.match(locus):
        return locus

    pattern = re.compile(r"^(chr)?([0-9XYMT]+):(\d+)$")
    if pattern.match(locus):
        return f"{locus}-" + str(int(locus.split(":")[1]))

    pattern = re.compile(r"^(chr)?([0-9XYMT]+):(\d+):([ATGC]+):([ATGC]+)$")
    if pattern.match(locus):
        return f"{locus.split(':')[0]}:{locus.split(':')[1]}-{locus.split(':')[1]}"

    raise ValueError(
        f"locus {locus} is not in the correct format. expected format: chr1:1000-2000 or chr1:1000 or chr1:1000:ATGC:ATGC"
    )


def reformat_vep(vep, filter_genes=None, filter_impacts=None):
    # ##INFO=<ID=CSQ,Number=.,Type=String,Description="Consequence annotations from Ensembl VEP. Format:
    # 0Allele|1Consequence|2IMPACT|3SYMBOL|4Gene|5Feature_type|6Feature|7BIOTYPE|8EXON|9INTRON|10HGVSc|11HGVSp|12cDNA_position|
    # 13CDS_position|14Protein_position|15Amino_acids|16Codons|17Existing_variation|18DISTANCE|19STRAND|20FLAGS|21SYMBOL_SOURCE|
    # 22HGNC_ID|23CANONICAL|24CCDS|25SIFT|26PolyPhen|27HGVS_OFFSET|28LoF|29LoF_filter|30LoF_flags|31LoF_info|32am_class|33am_pathogenicity">

    txs = vep.split(",")
    ret = []
    for tx in txs:
        annots = tx.split("|")
        if annots[23] == "YES":
            if filter_genes:
                if annots[3] in filter_genes.split(","):
                    if filter_impacts:
                        if annots[2] in filter_impacts.split(","):
                            ret.append(f"{annots[3]} ({annots[2]} - {annots[1]})")
                    else:
                        ret.append(f"{annots[3]} ({annots[2]} - {annots[1]})")

            else:
                ret.append(f"{annots[3]} ({annots[2]} - {annots[1]})")
    return ret


def query_vcf(
    vcf,
    sample,
    locus,
    header=False,
    nohomref=False,
    consequence=False,
    filter_genes=None,
    filter_impacts=None,
):
    """
    Query a VCF file for a specific sample and locus.

    Args:
        vcf (str): Path to the VCF file.
        sample (str): Name of the sample to query.
        locus (str): Locus to query (e.g. chr1:1000-2000).

    Returns:
        None
    """

    vcf = VCF(vcf)
    if sample not in vcf.samples:
        print(f"Sample {sample} not found in VCF file")
        return
    sample_index = vcf.samples.index(sample)

    if header:
        print("variant_id\tGT\tDP\tAD\tGQ\tAC\tAN\tsample")

    locus = reformat_locus(locus)

    for variant in vcf(locus):
        if nohomref:
            if (variant.genotypes[sample_index][0] in [-1, 1, 2]) or (
                variant.genotypes[sample_index][1] in [-1, 1, 2]
            ):
                if consequence:
                    vep_annots = reformat_vep(
                        variant.INFO.get("CSQ", ""),
                        filter_genes=filter_genes,
                        filter_impacts=filter_impacts,
                    )
                    if vep_annots:
                        print(
                            f"{variant.CHROM}:{variant.start + 1}:{variant.REF}:{variant.ALT[0]}\t{reformat_gt(variant.genotypes[sample_index])}\t{variant.gt_ref_depths[sample_index] + variant.gt_alt_depths[sample_index]}\t{variant.gt_alt_depths[sample_index]}\t{variant.gt_quals[sample_index]}\t{variant.INFO.get('AC')}\t{variant.INFO.get('AN')}\t{sample}\t{','.join(vep_annots)}"
                        )
                else:
                    print(
                        f"{variant.CHROM}:{variant.start + 1}:{variant.REF}:{variant.ALT[0]}\t{reformat_gt(variant.genotypes[sample_index])}\t{variant.gt_ref_depths[sample_index] + variant.gt_alt_depths[sample_index]}\t{variant.gt_alt_depths[sample_index]}\t{variant.gt_quals[sample_index]}\t{variant.INFO.get('AC')}\t{variant.INFO.get('AN')}\t{sample}"
                    )
        else:
            if consequence:
                vep_annots = reformat_vep(
                    variant.INFO.get("CSQ", ""),
                    filter_genes=filter_genes,
                    filter_impacts=filter_impacts,
                )
                if vep_annots:
                    print(
                        f"{variant.CHROM}:{variant.start + 1}:{variant.REF}:{variant.ALT[0]}\t{reformat_gt(variant.genotypes[sample_index])}\t{variant.gt_ref_depths[sample_index] + variant.gt_alt_depths[sample_index]}\t{variant.gt_alt_depths[sample_index]}\t{variant.gt_quals[sample_index]}\t{variant.INFO.get('AC')}\t{variant.INFO.get('AN')}\t{sample}\t{','.join(vep_annots)}"
                    )
            else:
                print(
                    f"{variant.CHROM}:{variant.start + 1}:{variant.REF}:{variant.ALT[0]}\t{reformat_gt(variant.genotypes[sample_index])}\t{variant.gt_ref_depths[sample_index] + variant.gt_alt_depths[sample_index]}\t{variant.gt_alt_depths[sample_index]}\t{variant.gt_quals[sample_index]}\t{variant.INFO.get('AC')}\t{variant.INFO.get('AN')}\t{sample}"
                )
    pass


def main() -> None:
    parsed_args = parse_app_args()
    query_vcf(
        vcf=parsed_args.vcf,
        sample=parsed_args.sample,
        locus=parsed_args.locus,
        header=parsed_args.header,
        nohomref=parsed_args.nohomref,
        consequence=parsed_args.consequence,
        filter_genes=parsed_args.filter_genes,
        filter_impacts=parsed_args.filter_impacts,
    )


if __name__ == "__main__":
    main()
