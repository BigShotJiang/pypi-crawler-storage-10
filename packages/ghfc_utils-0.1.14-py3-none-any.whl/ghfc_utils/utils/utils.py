# TODO
# function to split a given column (chr:pos:ref:alt) in a dataframe into 4 columns

# function to liftover a given column (chr:pos:ref:alt) in a dataframe that flag the rows that were not lifted

# function to liftover a pair of columns (chr:pos) in a dataframe that flag the rows that were not lifted

# function to quickly optimize the memory usage of a dataframe by changing the data type of the columns to Categoricals when possible
# involves ordered Categories for chromosomes
# multiple functions, some dedicated to specific clumns (especially ordered ones) with matching config files

# function to optimize a slivar dataframe

# read_yaml
