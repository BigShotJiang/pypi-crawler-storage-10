import argparse

from . import dnm, reannotate


def parse_app_args(args=None):
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(
        dest="cmd",
        help="pgs subcommand to run. for additional help, run `pgs <subcommand> -h`",
    )
    subparsers.required = True
    reannotate.setup_args(subparsers, "reannotate")
    dnm.setup_args(subparsers, "dnm")

    return parser.parse_args(args)


def main() -> None:
    parsed_args = parse_app_args()
    command_map = {
        "reannotate": reannotate.run,
        "dnm": dnm.run,
    }
    command_map[parsed_args.cmd](parsed_args)


if __name__ == "__main__":
    main()
