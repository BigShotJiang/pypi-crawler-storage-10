# decision tree bricks

> [!NOTE]
> We need to see if we maintain the CADD when no MPC_v2

```mermaid
flowchart TD
    loftee["Loftee in ['HC']"]
    mpc["*MPC_v2>=2.6*"]
    miss_cadd["*missense* and *MPC_v2<0* and *CADD>=28.3*"]
    cadd["*CADD>=10*"]
    spliceai["*spliceAI>=0.8*"]
    high
    moderate
    low

    loftee --true--> high
    loftee --false--> mpc
    mpc --true--> high
    mpc --false--> miss_cadd
    miss_cadd --true--> high
    miss_cadd --false--> cadd
    cadd --true--> moderate
    cadd --false--> spliceai
    spliceai --true--> moderate
    spliceai --false--> low
```
