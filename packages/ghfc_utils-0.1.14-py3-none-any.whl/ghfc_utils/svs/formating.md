# formating

```mermaid
flowchart TD
    raw["*project*.{sample}.tsv"]
    raw_cohort["*project*.tsv"]
    raw --concatenate using **project sample list**--> raw_cohort
    split_type["*project*.{del|dup|inv|bnd}.tsv"]
    raw_cohort --split by type--> split_type
    split_chr["*project*.{del|dup|inv|bnd}.{chr}.tsv"]
    split_type --split by chromosome--> split_chr
    split_freq["*project*.{del|dup|inv|bnd}.{chr}.freq.tsv"]
    split_chr --annotate freq (family?)--> split_freq
    split_annot["*project*.{del|dup|inv|bnd}.{chr}.freq.annotsv.tsv"]
    split_freq --AnnotSV--> split_annot
    
    split_file_1["*project*.{del|dup|inv|bnd}.{chr}.split.tsv"]
    split_annot --separate **split**--> split_file_1
    split_file_2["*project*.{del|dup|inv|bnd}.{chr}.split.{high|pass|low}.tsv"]
    split_file_1 --split on FT--> split_file_2
    split_file_3["*project*.{del|dup|inv|bnd}.split.{high|pass|low}.tsv"]
    split_file_2 --concatenate chromosomes--> split_file_3

    full_file_1["*project*.{del|dup|inv|bnd}.{chr}.full.tsv"]
    split_annot --separate **full**--> full_file_1
    full_file_2["*project*.{del|dup|inv|bnd}.{chr}.full.{high|pass|low}.tsv"]
    full_file_1 --split on FT--> full_file_2
    full_file_3["*project*.{del|dup}.{chr}.full.{high|pass|low}.ML.tsv"]
    full_file_2 --apply ML (inheritance + veracity)--> full_file_3
    full_file_4["*project*.{inv|bnd}.{chr}.full.{high|pass|low}.ML.tsv"]
    full_file_2 --> full_file_4
    full_file_5["*project*.{del|dup|inv|bnd}.full.{high|pass|low}.tsv"]
    full_file_3 --concatenate chromosomes--> full_file_5
    full_file_4 --concatenate chromosomes--> full_file_5

```