"""MoFA CLI commands module"""
