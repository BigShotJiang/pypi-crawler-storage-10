# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the Custom Service Manager."""

__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .create_no_sql_cluster_v2 import CreateNoSQLClusterV2
from .create_no_sql_database__189b02 import CreateNoSQLDatabaseCredentialV2
from .create_no_sql_database_v2 import CreateNoSQLDatabaseV2
from .delete_no_sql_cluster_v2 import DeleteNoSQLClusterV2
from .delete_no_sql_database_v2 import DeleteNoSQLDatabaseV2
from .get_no_sql_access_tunnel_v2 import GetNoSQLAccessTunnelV2
from .get_no_sql_cluster_v2 import GetNoSQLClusterV2
from .get_no_sql_database_v2 import GetNoSQLDatabaseV2
from .update_no_sql_cluster_v2 import UpdateNoSQLClusterV2
