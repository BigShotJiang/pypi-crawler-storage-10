from pathlib import Path

import tinkerforge2mqtt


CLI_EPILOG = 'Project Homepage: https://github.com/jedie/tinkerforge2mqtt'

BASE_PATH = Path(tinkerforge2mqtt.__file__).parent
