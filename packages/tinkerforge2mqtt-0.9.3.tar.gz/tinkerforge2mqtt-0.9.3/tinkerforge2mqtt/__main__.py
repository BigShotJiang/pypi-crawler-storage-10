"""
    Allow tinkerforge2mqtt to be executable
    through `python -m tinkerforge2mqtt`.
"""


from tinkerforge2mqtt.cli_app import main


if __name__ == '__main__':
    main()
