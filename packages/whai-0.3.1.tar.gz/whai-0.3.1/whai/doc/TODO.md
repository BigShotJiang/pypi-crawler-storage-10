# TODO
Features:
- [x] No quotes typing
- [x] Timeout delay flag
- [x] Config commands
- [x] Role commands
- [x] Prettier outputs
    - [x] Spinning loading icon
    - [x] Shell commands formatting
- [x] Faster shell executions ?
- [x] Test mutliple models
- [x] Improve dev documentation
- [x] Improve Readme.md
- [?] Console output instant streaming
    - Powershell subprocess.run fix prevents it. Maybe for linux once I get to it.
- [x] Graceful exit?
- [x] Start message: model, role
- [x] default model in config
- [x] Debug levels
- [x] Add "real world" unit tests
- [x] Find new name
- [x] Pip installable


Issues:
- [x] Timeout issue
    - Note: UGH
- [x] Linux background
