VERSION = "0.3.6"

# this will be templated during the build
GIT_COMMIT = "3db2fc16ad04fc0bb32a41a9ecd013f9f5fa5c36"
