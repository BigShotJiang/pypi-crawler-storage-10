Para usar este módulo:

1.  Crie uma fatura com o tipo de documento fiscal 'SE'.
2.  Preencha os detalhes necessários, como o código tributário da
    cidade, impostos e informações correlatas.
3.  Valide o documento.
4.  Envie o Documento Fiscal.
5.  Acompanhe o status de processamento do documento.
