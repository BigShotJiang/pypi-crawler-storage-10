# -*- mode: python; coding: utf-8 -*-
#
# Copyright (C) 2025 Benjamin Thomas Schwertfeger
# All rights reserved.
# https://github.com/btschwertfeger
#

from infinity_grid.services.notification_service import NotificationService

__all__ = [
    "NotificationService",
]
