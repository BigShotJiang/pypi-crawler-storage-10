"""Interacciones básicas para Holobits."""
try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución directa
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

import numpy as np
from typing import Iterable

from holobit_sdk.core.holobit import Holobit


def confinar_quarks(holobit: Holobit, limite: float = 1.0) -> Holobit:
    """Limita la posición de cada quark dentro de un cubo de lado ``2*limite``.

    Args:
        holobit: Holobit a modificar.
        limite: Valor absoluto máximo permitido para cada coordenada.
    """
    for quark in holobit.quarks + holobit.antiquarks:
        quark.posicion = np.clip(quark.posicion, -limite, limite)
    return holobit


def cambiar_spin(holobit: Holobit, nuevo_spin: float) -> Holobit:
    """Modifica el valor del *spin* del Holobit."""
    holobit.spin = nuevo_spin
    return holobit


def sincronizar_spin(holobits: Iterable[Holobit]) -> Iterable[Holobit]:
    """Iguala el *spin* de todos los Holobits al promedio del grupo.

    Args:
        holobits: Conjunto de Holobits a sincronizar.
    """
    holobits = list(holobits)
    if not holobits:
        return holobits
    promedio = float(np.mean([hb.spin for hb in holobits]))
    for hb in holobits:
        hb.spin = promedio
    return holobits

