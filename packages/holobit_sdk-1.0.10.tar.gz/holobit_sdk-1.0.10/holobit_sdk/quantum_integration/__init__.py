from holobit_sdk.quantum_integration.base import QuantumAdapter

try:
    from holobit_sdk.quantum_integration.qiskit_adapter import QiskitAdapter
except Exception:  # pragma: no cover - dependencias opcionales
    QiskitAdapter = None

try:
    from holobit_sdk.quantum_integration.pennylane_adapter import PennyLaneAdapter
except Exception:  # pragma: no cover - dependencias opcionales
    PennyLaneAdapter = None

try:
    from holobit_sdk.quantum_integration.cirq_adapter import CirqAdapter
except Exception:  # pragma: no cover - dependencias opcionales
    CirqAdapter = None

try:
    from holobit_sdk.quantum_integration.braket_adapter import BraketAdapter
except Exception:  # pragma: no cover - dependencias opcionales
    BraketAdapter = None

try:
    from holobit_sdk.quantum_integration.qutip_adapter import QutipAdapter
except Exception:  # pragma: no cover - dependencias opcionales
    QutipAdapter = None

__all__ = [
    "QuantumAdapter",
    "QiskitAdapter",
    "PennyLaneAdapter",
    "CirqAdapter",
    "BraketAdapter",
    "QutipAdapter",
]
