"""Utilidades para ejecutar módulos del paquete como scripts independientes."""

from __future__ import annotations

import importlib
import importlib.util
import sys
from pathlib import Path
from typing import MutableMapping


def fix_relative_imports(globals_dict: MutableMapping[str, object]) -> None:
    """Garantiza que un módulo del paquete pueda ejecutarse como script.

    La función se centra en tres tareas:

    * Añadir al ``sys.path`` la carpeta que contiene al paquete raíz.
    * Establecer ``__package__`` para que las importaciones relativas funcionen.
    * Crear un ``__spec__`` coherente cuando el módulo se ejecuta como ``__main__``.

    Parameters
    ----------
    globals_dict:
        El diccionario global del módulo que invoca la función (típicamente
        ``globals()``).
    """

    package = globals_dict.get("__package__")
    if package:  # Ya está correctamente inicializado.
        return

    file_value = globals_dict.get("__file__")
    if not file_value:
        return

    file_path = Path(file_value).resolve()
    package_parts: list[str] = []
    current = file_path.parent

    # Recorremos los padres que forman parte del paquete (tienen ``__init__.py``).
    while (current / "__init__.py").is_file():
        package_parts.append(current.name)
        current = current.parent

    package_parts.reverse()
    parent_dir = current
    parent_str = str(parent_dir)

    if parent_str not in sys.path:
        sys.path.insert(0, parent_str)

    if package_parts:
        top_package = package_parts[0]
        package_root = Path(parent_dir / top_package)
        existing = sys.modules.get(top_package)
        module_path = getattr(existing, "__file__", None) if existing else None
        different_origin = False
        if module_path:
            try:
                different_origin = not Path(module_path).resolve().is_relative_to(package_root.resolve())
            except AttributeError:  # pragma: no cover - Python < 3.9
                module_real = Path(module_path).resolve()
                different_origin = not str(module_real).startswith(str(package_root.resolve()))
        if different_origin:
            sys.modules.pop(top_package, None)

    if package_parts:
        package_name = ".".join(package_parts)
        globals_dict["__package__"] = package_name
        try:
            importlib.import_module(package_name)
        except ModuleNotFoundError:  # pragma: no cover - se gestionará en la importación real
            pass

    module_name = globals_dict.get("__name__")
    if module_name == "__main__" and package_parts:
        full_name = ".".join(package_parts + [file_path.stem])
        sys.modules.setdefault(full_name, sys.modules["__main__"])
        if globals_dict.get("__spec__") is None:
            spec = importlib.util.spec_from_file_location(full_name, file_path)
            globals_dict["__spec__"] = spec


__all__ = ["fix_relative_imports"]
