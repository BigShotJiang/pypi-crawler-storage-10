"""Backends de computación en la nube para Holobit SDK."""

from holobit_sdk.cloud.aws import AWSBackend
from holobit_sdk.cloud.azure import AzureBackend
from holobit_sdk.cloud.base import BaseCloudBackend
from holobit_sdk.cloud.credentials import CredentialsProvider
from holobit_sdk.cloud.gcp import GCPBackend
from holobit_sdk.cloud.universal import UniversalBackend

__all__ = [
    "BaseCloudBackend",
    "AWSBackend",
    "AzureBackend",
    "CredentialsProvider",
    "GCPBackend",
    "UniversalBackend",
]
