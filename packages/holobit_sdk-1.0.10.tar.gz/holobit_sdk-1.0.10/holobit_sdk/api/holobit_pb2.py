"""Mensajes ligeros equivalentes a los generados por ``protoc``."""

from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any, Dict

__all__ = [
    "CodeRequest",
    "JobReply",
    "JobRequest",
    "ResultReply",
]


def _to_bytes(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, ensure_ascii=False).encode("utf-8")


def _from_bytes(data: bytes) -> Dict[str, Any]:
    if not data:
        return {}
    return json.loads(data.decode("utf-8"))


@dataclass
class CodeRequest:
    code: str = ""

    def SerializeToString(self) -> bytes:
        return _to_bytes({"code": self.code})

    @classmethod
    def FromString(cls, data: bytes) -> "CodeRequest":
        payload = _from_bytes(data)
        return cls(code=str(payload.get("code", "")))


@dataclass
class JobReply:
    job_id: str = ""

    def SerializeToString(self) -> bytes:
        return _to_bytes({"job_id": self.job_id})

    @classmethod
    def FromString(cls, data: bytes) -> "JobReply":
        payload = _from_bytes(data)
        return cls(job_id=str(payload.get("job_id", "")))


@dataclass
class JobRequest:
    job_id: str = ""

    def SerializeToString(self) -> bytes:
        return _to_bytes({"job_id": self.job_id})

    @classmethod
    def FromString(cls, data: bytes) -> "JobRequest":
        payload = _from_bytes(data)
        return cls(job_id=str(payload.get("job_id", "")))


@dataclass
class ResultReply:
    result: str = ""

    def SerializeToString(self) -> bytes:
        return _to_bytes({"result": self.result})

    @classmethod
    def FromString(cls, data: bytes) -> "ResultReply":
        payload = _from_bytes(data)
        return cls(result=str(payload.get("result", "")))
