try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución como script
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from holobit_sdk.multi_level.low_level.memory_manager import MemoryManager
from holobit_sdk.multi_level.low_level.structure import HoloStructure


class LowLevelAPI:
    """
    API de Bajo Nivel para interactuar con el Ensamblador Cuántico Holográfico.
    """

    def __init__(self):
        self.memory = MemoryManager()
        self.structures = {}

    def ejecutar_comando(self, comando, *args):
        """
        Ejecuta un comando ensamblador de bajo nivel.

        Args:
            comando (str): Nombre del comando a ejecutar.
            *args: Argumentos adicionales según el comando.

        Returns:
            str: Resultado de la ejecución del comando.
        """
        if comando == "ALLOCATE":
            holobit_id, x, y, z = args
            self.memory.allocate(holobit_id, (float(x), float(y), float(z)))
            return f"Holobit {holobit_id} asignado en ({x}, {y}, {z})."

        elif comando == "DEALLOCATE":
            holobit_id = args[0]
            self.memory.deallocate(holobit_id)
            return f"Holobit {holobit_id} liberado."

        elif comando == "GET_POSITION":
            holobit_id = args[0]
            position = self.memory.get_position(holobit_id)
            return f"Posición de {holobit_id}: {position}"

        elif comando == "CREATE_STRUCT":
            struct_id = args[0]
            holobit_ids = args[1:]
            self.structures[struct_id] = HoloStructure(holobit_ids, self.memory)
            return f"Estructura {struct_id} creada con {len(holobit_ids)} holobits."

        elif comando == "TRANSFORM_STRUCT":
            struct_id = args[0]
            operacion = args[1]
            if struct_id not in self.structures:
                return f"Estructura {struct_id} no existe."
            estructura = self.structures[struct_id]
            if operacion == "ROTATE":
                eje = args[2]
                angulo = args[3]
                estructura.rotate(eje, float(angulo))
            elif operacion == "TRANSLATE":
                dx, dy, dz = map(float, args[2:5])
                estructura.translate((dx, dy, dz))
            elif operacion == "SCALE":
                factor = args[2]
                estructura.scale(float(factor))
            else:
                return "Operación desconocida."
            return f"Estructura {struct_id} transformada."

        else:
            return "Comando desconocido."


# Ejemplo de uso
if __name__ == "__main__":
    api = LowLevelAPI()
    print(api.ejecutar_comando("ALLOCATE", "H1", 0.1, 0.2, 0.3))
    print(api.ejecutar_comando("GET_POSITION", "H1"))
    print(api.ejecutar_comando("DEALLOCATE", "H1"))

