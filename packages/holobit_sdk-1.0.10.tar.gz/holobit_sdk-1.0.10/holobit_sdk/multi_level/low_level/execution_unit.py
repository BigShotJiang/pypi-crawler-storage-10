try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución como script
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from holobit_sdk.multi_level.low_level.low_level_api import LowLevelAPI


class ExecutionUnit:
    """
    Módulo de ejecución de instrucciones ensamblador-holográficas.
    """

    def __init__(self):
        self.api = LowLevelAPI()

    def ejecutar_instruccion(self, instruccion):
        """
        Ejecuta una instrucción en el ensamblador cuántico holográfico.

        Args:
            instruccion (str): Instrucción ensamblador a ejecutar.

        Returns:
            str: Resultado de la ejecución de la instrucción.
        """
        partes = instruccion.split()
        if not partes:
            return "Instrucción vacía."

        comando = partes[0]
        argumentos = partes[1:]

        try:
            return self.api.ejecutar_comando(comando, *argumentos)
        except Exception as e:
            return f"Error en la ejecución: {str(e)}"


# Ejemplo de uso
if __name__ == "__main__":
    executor = ExecutionUnit()
    print(executor.ejecutar_instruccion("ALLOCATE H1 0.1 0.2 0.3"))
    print(executor.ejecutar_instruccion("GET_POSITION H1"))
    print(executor.ejecutar_instruccion("DEALLOCATE H1"))

