try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución como script
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from holobit_sdk.multi_level.low_level.low_level_api import LowLevelAPI
from holobit_sdk.multi_level.medium_level.vector_processor import VectorProcessor


class HolographicAPI:
    """API de Nivel Medio para la manipulación de Holobits.

    Esta capa ofrece un conjunto de operaciones que abstraen la lógica de
    bajo nivel. Además de gestionar la memoria holográfica, incluye
    utilidades para operaciones vectoriales mediante :class:`VectorProcessor`,
    como ``producto_vectorial``, ``normalizar_vector`` y ``proyeccion_vector``.
    """

    def __init__(self):
        self.low_level_api = LowLevelAPI()

    def crear_holobit(self, holobit_id, x, y, z):
        """
        Crea un nuevo Holobit en la memoria holográfica.

        Args:
            holobit_id (str): Identificador único del Holobit.
            x (float): Coordenada X.
            y (float): Coordenada Y.
            z (float): Coordenada Z.

        Returns:
            str: Mensaje de confirmación.
        """
        return self.low_level_api.ejecutar_comando("ALLOCATE", holobit_id, x, y, z)

    def obtener_posicion(self, holobit_id):
        """
        Obtiene la posición de un Holobit en el espacio holográfico.

        Args:
            holobit_id (str): Identificador del Holobit.

        Returns:
            str: Coordenadas del Holobit.
        """
        return self.low_level_api.ejecutar_comando("GET_POSITION", holobit_id)

    def eliminar_holobit(self, holobit_id):
        """
        Elimina un Holobit de la memoria holográfica.

        Args:
            holobit_id (str): Identificador del Holobit.

        Returns:
            str: Mensaje de confirmación.
        """
        return self.low_level_api.ejecutar_comando("DEALLOCATE", holobit_id)

    # --- Operaciones vectoriales de nivel medio ---

    def producto_vectorial(self, v1, v2):
        """Wrapper del :func:`VectorProcessor.producto_vectorial`."""
        return VectorProcessor.producto_vectorial(v1, v2)

    def normalizar_vector(self, v):
        """Wrapper del :func:`VectorProcessor.normalizar_vector`."""
        return VectorProcessor.normalizar_vector(v)

    def proyeccion_vector(self, v1, v2):
        """Wrapper del :func:`VectorProcessor.proyeccion_vector`."""
        return VectorProcessor.proyeccion_vector(v1, v2)


# Ejemplo de uso
if __name__ == "__main__":
    api = HolographicAPI()
    print(api.crear_holobit("H1", 0.1, 0.2, 0.3))
    print(api.obtener_posicion("H1"))
    print(api.eliminar_holobit("H1"))

