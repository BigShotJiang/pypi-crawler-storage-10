try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución como script
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from holobit_sdk.multi_level.high_level.compiler import HoloLangCompiler


class HoloLangDebugger:
    """
    Depurador para el lenguaje de programación holográfico.
    """

    def __init__(self):
        self.compiler = HoloLangCompiler()
        self.break_points = set()

    def agregar_punto_de_ruptura(self, linea):
        """
        Agrega un punto de ruptura en una línea específica.

        Args:
            linea (int): Número de línea donde se coloca el punto de ruptura.
        """
        self.break_points.add(linea)

    def depurar(self, codigo):
        """
        Ejecuta el código línea por línea permitiendo detenerse en los puntos de ruptura.

        Args:
            codigo (list): Lista de líneas de código en HoloLang.
        """
        for i, linea in enumerate(codigo, start=1):
            if i in self.break_points:
                input(f"[DEBUG] Pausado en la línea {i}: {linea}. Presiona Enter para continuar...")
            resultado = self.compiler.compilar_y_ejecutar(linea)
            print(f"Línea {i}: {resultado}")


# Ejemplo de uso
if __name__ == "__main__":
    debugger = HoloLangDebugger()
    debugger.agregar_punto_de_ruptura(2)
    codigo = [
        "CREAR H1 (0.1, 0.2, 0.3)",
        "IMPRIMIR H1",
        "EJECUTAR ALLOCATE H2 0.4 0.5 0.6"
    ]
    debugger.depurar(codigo)

