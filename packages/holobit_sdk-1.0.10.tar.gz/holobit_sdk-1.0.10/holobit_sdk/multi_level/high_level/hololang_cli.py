try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución como script
    import importlib.util
    import sys as _sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = _sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        _sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

import argparse
import sys
from pathlib import Path

from holobit_sdk.multi_level.high_level.compiler import HoloLangCompiler


def main() -> int:
    """Punto de entrada del CLI para ejecutar código HoloLang."""
    parser = argparse.ArgumentParser(
        description="Ejecuta código HoloLang utilizando el compilador integrado"
    )
    parser.add_argument(
        "-f",
        "--file",
        help="Ruta de un archivo con instrucciones HoloLang",
    )
    parser.add_argument(
        "-c",
        "--code",
        action="append",
        help="Línea de código HoloLang; usa varias veces para múltiples líneas",
    )
    parser.add_argument(
        "--arch",
        default="x86",
        help="Arquitectura de destino (x86, ARM, RISC-V, c, cpp, rust, go)",
    )
    args = parser.parse_args()

    compiler = HoloLangCompiler(args.arch)
    lines = []

    if args.file:
        file_path = Path(args.file)
        if not file_path.is_file():
            print(f"Archivo no encontrado: {file_path}", file=sys.stderr)
            return 1
        content = file_path.read_text(encoding="utf-8")
        lines.extend(line.strip() for line in content.splitlines() if line.strip())

    if args.code:
        lines.extend(line.strip() for line in args.code if line.strip())

    if not lines:
        print("Debes proporcionar --file o --code", file=sys.stderr)
        return 1

    for line in lines:
        result = compiler.compilar_y_ejecutar(line)
        print(result)

    return 0


if __name__ == "__main__":
    sys.exit(main())
