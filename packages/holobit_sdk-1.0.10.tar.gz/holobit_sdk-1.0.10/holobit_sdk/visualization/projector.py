"""Herramientas de visualización basadas en Matplotlib."""

from __future__ import annotations

try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución directa
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from collections.abc import Iterable
from typing import Sequence

import matplotlib.pyplot as plt
import numpy as np

from holobit_sdk.core.holobit import Holobit


def _asegurar_secuencia(holobits: Holobit | Iterable[Holobit]) -> Sequence[Holobit]:
    """Normaliza la entrada para trabajar siempre con una secuencia.

    Args:
        holobits: Un único ``Holobit`` o cualquier iterable de ellos.

    Returns:
        Una secuencia con los holobits recibidos.

    Raises:
        TypeError: Si el parámetro no es un ``Holobit`` ni un iterable válido.
    """

    if isinstance(holobits, Holobit):
        return [holobits]

    if isinstance(holobits, Iterable) and not isinstance(holobits, (str, bytes)):
        return list(holobits)

    raise TypeError(
        "'holobits' debe ser un Holobit individual o un iterable de Holobits."
    )


def proyectar_holograma(holobits: Holobit | Iterable[Holobit]):
    """
    Proyecta las posiciones de los quarks y antiquarks de una lista de
    holobits en una figura 3D. Cada holobit muestra su valor de spin en el
    centro geométrico calculado a partir de todas sus partículas.

    Args:
        holobits: Un ``Holobit`` individual o una secuencia de ``Holobit``.
    """
    holobits_normalizados = _asegurar_secuencia(holobits)

    if not holobits_normalizados:
        raise ValueError("Se requiere al menos un Holobit para proyectar el holograma.")

    fig = plt.figure()
    ax = fig.add_subplot(111, projection="3d")

    for holobit in holobits_normalizados:
        for quark in holobit.quarks:
            ax.scatter(
                quark.posicion[0],
                quark.posicion[1],
                quark.posicion[2],
                color="blue",
            )
        for antiquark in holobit.antiquarks:
            ax.scatter(
                antiquark.posicion[0],
                antiquark.posicion[1],
                antiquark.posicion[2],
                color="red",
            )

        todas = holobit.quarks + holobit.antiquarks
        posiciones = np.array([p.posicion for p in todas], dtype=float)
        centro = posiciones.mean(axis=0)
        ax.text(centro[0], centro[1], centro[2], f"spin={holobit.spin}")

    ax.set_title("Proyección Holográfica de Holobits")
    return fig, ax


def visualizar_familia_3d(holobits: Holobit | Iterable[Holobit]):
    """
    Genera una visualización 3D para una familia de holobits.

    Args:
        holobits: Un ``Holobit`` individual o una secuencia de ``Holobit``.
    """
    fig, ax = proyectar_holograma(holobits)
    plt.show()
    return fig, ax

