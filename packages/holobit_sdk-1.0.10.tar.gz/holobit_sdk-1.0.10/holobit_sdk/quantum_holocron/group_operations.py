"""Operaciones de gestión de grupos para el Holocron."""

from __future__ import annotations

try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución directa
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from typing import Iterable

from holobit_sdk.quantum_holocron.core.holocron import Holocron


def fusionar_grupo(holocron: Holocron, nuevo_grupo: str, grupos: Iterable[str]):
    """Fusiona varios grupos existentes en uno nuevo.

    Parameters
    ----------
    holocron:
        Instancia sobre la que se aplicará la operación.
    nuevo_grupo:
        Identificador para el grupo resultante.
    grupos:
        Colección con los identificadores de los grupos a fusionar.
    """
    holocron.merge_groups(nuevo_grupo, grupos)
    return holocron.groups[nuevo_grupo]


def dividir_grupo(
    holocron: Holocron,
    grupo_origen: str,
    nuevo_grupo: str,
    holobits: Iterable[str],
):
    """Divide un grupo moviendo Holobits a un nuevo grupo."""
    holocron.split_group(grupo_origen, nuevo_grupo, holobits)
    return holocron.groups[nuevo_grupo]


FUSIONAR_GRUPO = fusionar_grupo
DIVIDIR_GRUPO = dividir_grupo

__all__ = ["fusionar_grupo", "dividir_grupo", "FUSIONAR_GRUPO", "DIVIDIR_GRUPO"]
