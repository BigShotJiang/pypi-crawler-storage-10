try:
    from holobit_sdk._bootstrap import fix_relative_imports
except ModuleNotFoundError:  # pragma: no cover - soporte para ejecución directa
    import importlib.util
    import sys
    from pathlib import Path

    _FILE = Path(__file__).resolve()
    _top_level = None
    _current = _FILE.parent
    while (_current / "__init__.py").is_file():
        _top_level = _current
        _current = _current.parent
    if _top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
        raise
    _helper_path = _top_level / "_bootstrap.py"
    _spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", _helper_path)
    _module = sys.modules.get("holobit_sdk._bootstrap")
    if _module is None:
        if _spec is None or _spec.loader is None:  # pragma: no cover - errores de carga
            raise
        _module = importlib.util.module_from_spec(_spec)
        sys.modules["holobit_sdk._bootstrap"] = _module
        _spec.loader.exec_module(_module)  # type: ignore[arg-type]
    fix_relative_imports = _module.fix_relative_imports  # type: ignore[attr-defined]
fix_relative_imports(globals())

from holobit_sdk.asiic_holographic.translator import ASIICTranslator
from holobit_sdk.assembler.virtual_machine import AssemblerVM


class ASIICInterpreter:
    """Intérprete del ASIIC Holográfico."""

    def __init__(self, vm: AssemblerVM | None = None):
        """Inicializa el intérprete con una VM opcional."""
        self.vm = vm if vm is not None else AssemblerVM()
        self.translator = ASIICTranslator()

    def interpretar(self, comando):
        """Traduce y ejecuta un comando ASIIC."""

        asm_command = self.translator.traducir(comando)
        if (
            asm_command.startswith("Instrucción desconocida")
            or asm_command == "Comando vacío"
        ):
            return asm_command

        parts = asm_command.split()
        instr = parts[0]
        args = parts[1:]

        try:
            self.vm.execute_instruction(instr, *args)
        except (ValueError, KeyError) as e:
            return str(e)

        return asm_command


# Ejemplo de uso
if __name__ == "__main__":
    interprete = ASIICInterpreter()

    # Preparar quarks y holobits necesarios para las demostraciones
    coordenadas = [
        (0.1, 0.2, 0.3),
        (0.4, 0.5, 0.6),
        (0.7, 0.8, 0.9),
        (-0.1, -0.2, -0.3),
        (-0.4, -0.5, -0.6),
        (-0.7, -0.8, -0.9),
        (0.15, 0.25, 0.35),
        (0.45, 0.55, 0.65),
        (0.75, 0.85, 0.95),
        (-0.15, -0.25, -0.35),
        (-0.45, -0.55, -0.65),
        (-0.75, -0.85, -0.95),
    ]
    for idx, (x, y, z) in enumerate(coordenadas, start=1):
        interprete.vm.execute_instruction(
            "CREAR",
            f"Q{idx}",
            *(str(valor) for valor in (x, y, z)),
        )

    referencias_h1 = ", ".join(f"Q{i}" for i in range(1, 7))
    referencias_h2 = ", ".join(f"Q{i}" for i in range(7, 13))
    interprete.vm.execute_instruction("CREAR_HOLOBIT", "H1", referencias_h1)
    interprete.vm.execute_instruction("CREAR_HOLOBIT", "H2", referencias_h2)

    # Ejecutar comandos de prueba
    print(interprete.interpretar("ROTAR H1 z 90"))
    print(interprete.interpretar("ENTRELAZAR H1 H2"))
