from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_function_demo_executes_as_script(tmp_path):
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "examples" / "function_demo.py"

    result = subprocess.run(
        [sys.executable, str(script)],
        check=True,
        cwd=tmp_path,
        capture_output=True,
        text=True,
    )

    assert "Variable H1" in result.stdout
