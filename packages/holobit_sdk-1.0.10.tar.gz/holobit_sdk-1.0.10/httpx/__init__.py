"""Implementación mínima de :mod:`httpx` para las pruebas locales."""

from __future__ import annotations

import base64
import json
import urllib.parse
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Dict, Iterable, Iterator, List, Mapping, MutableMapping, Optional, Sequence, Tuple

__all__ = [
    "BaseTransport",
    "ByteStream",
    "Client",
    "Headers",
    "Request",
    "Response",
    "URL",
    "USE_CLIENT_DEFAULT",
]


USE_CLIENT_DEFAULT = object()
_client = SimpleNamespace(USE_CLIENT_DEFAULT=USE_CLIENT_DEFAULT)
_types = SimpleNamespace(
    URLTypes=object,
    RequestContent=object,
    RequestFiles=object,
    QueryParamTypes=object,
    HeaderTypes=object,
    CookieTypes=object,
    AuthTypes=object,
    TimeoutTypes=object,
)


class ByteStream:
    def __init__(self, data: bytes) -> None:
        self._data = data

    def read(self) -> bytes:
        return self._data


class Headers(MutableMapping[str, str]):
    def __init__(self, items: Optional[Iterable[Tuple[str, str]]] = None) -> None:
        self._store: Dict[str, str] = {}
        if items:
            for key, value in items:
                self[key] = value

    def __getitem__(self, key: str) -> str:
        return self._store[key.lower()]

    def __setitem__(self, key: str, value: str) -> None:
        self._store[key.lower()] = value

    def __delitem__(self, key: str) -> None:
        del self._store[key.lower()]

    def __iter__(self) -> Iterator[str]:
        return iter(self._store)

    def __len__(self) -> int:
        return len(self._store)

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:  # type: ignore[override]
        return self._store.get(key.lower(), default)

    def multi_items(self) -> List[Tuple[str, str]]:
        return [(key, value) for key, value in self._store.items()]


@dataclass
class URL:
    _raw: str

    def __post_init__(self) -> None:
        parsed = urllib.parse.urlsplit(self._raw)
        self.scheme = parsed.scheme or "http"
        self.path = parsed.path or "/"
        self.raw_path = self.path.encode("ascii", errors="ignore")
        self.netloc = parsed.netloc.encode("ascii", errors="ignore")
        self.query = parsed.query.encode("ascii", errors="ignore")
        self.fragment = parsed.fragment.encode("ascii", errors="ignore")

    def join(self, url: str) -> "URL":
        return URL(urllib.parse.urljoin(self._raw, url))

    def __str__(self) -> str:
        return self._raw


class Request:
    def __init__(
        self,
        method: str,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        json_data: Any = None,
        params: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if params:
            query = urllib.parse.urlencode(params, doseq=True)
            sep = "&" if urllib.parse.urlsplit(url).query else "?"
            url = f"{url}{sep}{query}"
        self.method = method.upper()
        self.url = URL(url)
        self.headers = Headers(headers.items() if isinstance(headers, Headers) else headers.items() if headers else None)
        if json_data is not None:
            content = json.dumps(json_data, ensure_ascii=False).encode("utf-8")
            self.headers.setdefault("content-type", "application/json")
        elif data is not None and content is None:
            content = urllib.parse.urlencode(data, doseq=True).encode("utf-8")
        self._body = content or b""
        self.stream = ByteStream(self._body)
        self.extensions: Dict[str, Any] = {}

    def read(self) -> bytes:
        return self._body


class Response:
    def __init__(
        self,
        status_code: int = 200,
        headers: Optional[Iterable[Tuple[str, str]]] = None,
        stream: Optional[ByteStream] = None,
        content: Optional[bytes] = None,
        request: Optional[Request] = None,
    ) -> None:
        self.status_code = status_code
        self.headers = Headers(headers)
        body = content if content is not None else (stream.read() if stream else b"")
        self._content = body
        self.stream = ByteStream(body)
        self.request = request

    @property
    def content(self) -> bytes:
        return self._content

    @property
    def text(self) -> str:
        return self._content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        if not self._content:
            return None
        return json.loads(self._content.decode("utf-8"))


class BaseTransport:
    def handle_request(self, request: Request) -> Response:  # pragma: no cover - implementado por subclases
        raise NotImplementedError

    def close(self) -> None:  # pragma: no cover - compatibilidad con la API real
        """Permite que los clientes cierren transportes sin requerir implementación."""
        return None


class Client:
    def __init__(
        self,
        *,
        base_url: str = "http://testserver",
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        transport: Optional[BaseTransport] = None,
        follow_redirects: bool = True,
        auth: Any = None,
    ) -> None:
        self.base_url = URL(base_url)
        self.headers = Headers(headers.items() if isinstance(headers, Headers) else headers.items() if headers else None)
        self.cookies = dict(cookies or {})
        self._transport = transport or BaseTransport()
        self.follow_redirects = follow_redirects
        self._auth = auth

    def _merge_url(self, url: str) -> str:
        url_str = str(url)
        if urllib.parse.urlsplit(url_str).scheme:
            return url_str
        return str(self.base_url.join(url_str))

    def request(
        self,
        method: str,
        url: str,
        *,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Optional[Any] = None,
        json: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        auth: Any = USE_CLIENT_DEFAULT,
        follow_redirects: Any = USE_CLIENT_DEFAULT,
        timeout: Any = USE_CLIENT_DEFAULT,
        extensions: Optional[Dict[str, Any]] = None,
    ) -> Response:
        merged_headers = Headers(self.headers.multi_items())
        if headers:
            for key, value in headers.items():
                merged_headers[key] = value
        auth_value = self._auth if auth is USE_CLIENT_DEFAULT else auth
        if isinstance(auth_value, tuple) and len(auth_value) == 2:
            user, password = auth_value
            token = base64.b64encode(f"{user}:{password}".encode()).decode()
            merged_headers["authorization"] = f"Basic {token}"
        final_url = self._merge_url(url)
        request = Request(
            method,
            final_url,
            headers=merged_headers,
            content=content,
            data=data,
            json_data=json,
            params=params,
        )
        request.extensions.update(extensions or {})
        response = self._transport.handle_request(request)
        response.request = request
        return response

    def get(self, url: str, **kwargs: Any) -> Response:
        return self.request("GET", url, **kwargs)

    def options(self, url: str, **kwargs: Any) -> Response:
        return self.request("OPTIONS", url, **kwargs)

    def head(self, url: str, **kwargs: Any) -> Response:
        return self.request("HEAD", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> Response:
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs: Any) -> Response:
        return self.request("PUT", url, **kwargs)

    def patch(self, url: str, **kwargs: Any) -> Response:
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs: Any) -> Response:
        return self.request("DELETE", url, **kwargs)

    def close(self) -> None:
        close = getattr(self._transport, "close", None)
        if callable(close):
            close()

    def __enter__(self) -> "Client":  # pragma: no cover - compatibilidad
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # pragma: no cover - compatibilidad
        self.close()
