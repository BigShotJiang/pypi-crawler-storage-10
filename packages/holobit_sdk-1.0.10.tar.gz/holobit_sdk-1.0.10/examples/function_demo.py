from __future__ import annotations

if __package__ in {None, ""}:
    import _bootstrap

    _bootstrap.bootstrap_examples(globals())

from examples import ensure_repo_root_on_path

ensure_repo_root_on_path()

from holobit_sdk.multi_level.high_level.compiler import HoloLangCompiler

programa = """
CREAR H1 (0.1, 0.2, 0.3)
CREAR_ESTRUCTURA G1 {H1}

FUNCION medir_superposicion(h) {
    SUPERPOSICION h
    MEDIR h
}

LLAMAR medir_superposicion(G1)
"""

if __name__ == "__main__":
    compilador = HoloLangCompiler()
    resultados = compilador.compilar_y_ejecutar(programa)
    for r in resultados:
        print(r)
