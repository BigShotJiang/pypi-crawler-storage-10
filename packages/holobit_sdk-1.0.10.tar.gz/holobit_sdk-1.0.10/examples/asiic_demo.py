from __future__ import annotations

if __package__ in {None, ""}:
    import _bootstrap

    _bootstrap.bootstrap_examples(globals())

from examples import ensure_repo_root_on_path

ensure_repo_root_on_path()

from holobit_sdk.asiic_holographic.instructions import ASIICInstructions
from holobit_sdk.asiic_holographic.translator import ASIICTranslator
from holobit_sdk.asiic_holographic.interpreter import ASIICInterpreter
from holobit_sdk.core.quark import Quark
from holobit_sdk.core.holobit import Holobit


def main():
    """Demostración de uso del conjunto ASIIC."""
    asiic = ASIICInstructions()

    def rotar_holobit(holobit, eje, angulo):
        return f"Rotando Holobit en el eje {eje} con ángulo {angulo} grados"

    asiic.agregar_instruccion("ROTAR", rotar_holobit)
    print(asiic.ejecutar_instruccion("ROTAR", "H1", "z", 90))

    traductor = ASIICTranslator()
    print(traductor.traducir("ROTAR H1 z 90"))
    print(traductor.traducir("ENTRELAZAR H1 H2"))

    interprete = ASIICInterpreter()
    h1 = Holobit(
        [
            Quark(0.1, 0.2, 0.3),
            Quark(0.2, 0.3, 0.4),
            Quark(0.3, 0.4, 0.5),
            Quark(0.4, 0.5, 0.6),
            Quark(0.5, 0.6, 0.7),
            Quark(0.6, 0.7, 0.8),
        ],
        [
            Quark(-0.1, -0.2, -0.3),
            Quark(-0.2, -0.3, -0.4),
            Quark(-0.3, -0.4, -0.5),
            Quark(-0.4, -0.5, -0.6),
            Quark(-0.5, -0.6, -0.7),
            Quark(-0.6, -0.7, -0.8),
        ],
    )
    h2 = Holobit(
        [
            Quark(0.2, 0.1, 0.0),
            Quark(0.3, 0.2, 0.1),
            Quark(0.4, 0.3, 0.2),
            Quark(0.5, 0.4, 0.3),
            Quark(0.6, 0.5, 0.4),
            Quark(0.7, 0.6, 0.5),
        ],
        [
            Quark(-0.2, -0.1, 0.0),
            Quark(-0.3, -0.2, -0.1),
            Quark(-0.4, -0.3, -0.2),
            Quark(-0.5, -0.4, -0.3),
            Quark(-0.6, -0.5, -0.4),
            Quark(-0.7, -0.6, -0.5),
        ],
    )
    interprete.vm.parser.holobits["H1"] = h1
    interprete.vm.parser.holobits["H2"] = h2
    print(interprete.interpretar("ROTAR H1 z 90"))
    print(interprete.interpretar("ENTRELAZAR H1 H2"))


if __name__ == "__main__":
    main()
