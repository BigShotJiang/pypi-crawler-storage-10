"""Demostración de nuevas instrucciones y macros de Hololang."""

from __future__ import annotations

if __package__ in {None, ""}:
    import _bootstrap

    _bootstrap.bootstrap_examples(globals())

from examples import ensure_repo_root_on_path

ensure_repo_root_on_path()

from holobit_sdk.assembler.virtual_machine import AssemblerVM


def build_program():
    return [
        "#macro PREPARAR_PAR a b",
        "CREAR Q_{a}_1 (0.1, 0.2, 0.3)",
        "CREAR Q_{a}_2 (0.4, 0.5, 0.6)",
        "CREAR Q_{a}_3 (0.7, 0.8, 0.9)",
        "CREAR Q_{a}_4 (0.2, 0.3, 0.4)",
        "CREAR Q_{a}_5 (0.5, 0.6, 0.7)",
        "CREAR Q_{a}_6 (0.8, 0.9, 1.0)",
        "CREAR HOLOBIT {a} {{Q_{a}_1, Q_{a}_2, Q_{a}_3, Q_{a}_4, Q_{a}_5, Q_{a}_6}}",
        "SUPERPOSICION {a}",
        "CREAR Q_{b}_1 (-0.1, -0.2, -0.3)",
        "CREAR Q_{b}_2 (-0.4, -0.5, -0.6)",
        "CREAR Q_{b}_3 (-0.7, -0.8, -0.9)",
        "CREAR Q_{b}_4 (-0.2, -0.3, -0.4)",
        "CREAR Q_{b}_5 (-0.5, -0.6, -0.7)",
        "CREAR Q_{b}_6 (-0.8, -0.9, -1.0)",
        "CREAR HOLOBIT {b} {{Q_{b}_1, Q_{b}_2, Q_{b}_3, Q_{b}_4, Q_{b}_5, Q_{b}_6}}",
        "SUPERPOSICION {b}",
        "ENTRELAZAR {a} {b}",
        "#endmacro",
        "PREPARAR_PAR H1 H2",
        "GRUPO G1 = {H1, H2}",
        "MEASURE H1 H2",
        "SI H1",
        "    ROT H2 z 45",
        "SINO",
        "    ROT H2 z 180",
        "FIN",
    ]


def main():
    vm = AssemblerVM()
    vm.run_program(build_program())
    print("Mediciones registradas:", vm.parser.measurements)


if __name__ == "__main__":
    main()
