"""Demostración de creación, simulación y graficado de un fractal multidimensional.

El flujo básico consiste en:

1. Generar un fractal ``N``-dimensional de forma aleatoria.
2. Simular su dinámica aplicando pequeñas perturbaciones.
3. (Opcional) Optimizar genéticamente los parámetros de un fractal
   morfométrico utilizando :meth:`holobit_sdk.quantum_holocron.fractal.Fractal.optimizar_geneticamente`.
"""

from __future__ import annotations

if __package__ in {None, ""}:
    import _bootstrap

    _bootstrap.bootstrap_examples(globals())

from examples import ensure_repo_root_on_path

ensure_repo_root_on_path()
