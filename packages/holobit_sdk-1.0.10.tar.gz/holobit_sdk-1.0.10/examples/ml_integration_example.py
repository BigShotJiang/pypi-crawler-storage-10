"""Ejemplo de integración del Holobit SDK con bibliotecas de ML.

Este script muestra cómo convertir datos de ``numpy``/``pandas`` en Holobits y
Holocrones, cómo integrarlo en un pipeline de scikit-learn y cómo iterar con un
``DataLoader`` de PyTorch.
"""

from __future__ import annotations

if __package__ in {None, ""}:
    import _bootstrap

    _bootstrap.bootstrap_examples(globals())

from examples import ensure_repo_root_on_path

ensure_repo_root_on_path()

import numpy as np
import pandas as pd

try:  # pragma: no cover - dependencia opcional
    from sklearn.pipeline import Pipeline
except ModuleNotFoundError:  # pragma: no cover
    Pipeline = None  # type: ignore[assignment]

from holobit_sdk.api import (
    HolobitTransformer,
    holobit_dataloader,
    holocron_from_dataframe,
)

# ---------------------------------------------------------------------------
# Datos de ejemplo
# ---------------------------------------------------------------------------

df = pd.DataFrame(np.arange(24).reshape(2, 12))
data = df.to_numpy()

# Conversión directa a Holocron
holocron = holocron_from_dataframe(df)
print("Holocron con", len(holocron.holobits), "holobits")

# Uso en un pipeline de scikit-learn
transformer = HolobitTransformer()
if Pipeline is None:
    print("scikit-learn no está instalado; se aplica la transformación directamente.")
    resultado = transformer.fit_transform(data)
else:
    pipeline = Pipeline([("holobits", transformer)])
    resultado = pipeline.fit_transform(data)
print("Transformación produjo", len(resultado), "holobits")

# Iteración con PyTorch
loader = holobit_dataloader(data, batch_size=1, shuffle=False)
for batch in loader:
    print("Batch con", len(batch), "elementos")
