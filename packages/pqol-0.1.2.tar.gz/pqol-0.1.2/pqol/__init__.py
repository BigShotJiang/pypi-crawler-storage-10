from .logic import logic

AND = logic.AND
OR = logic.OR
NOT = logic.NOT
NAND = logic.NAND
NOR = logic.NOR
XOR = logic.XOR
XNOR = logic.XNOR

__all__ = ["logic", "AND", "OR", "NOT", "NAND", "NOR", "XOR", "XNOR"]

__version__ = "0.1.2"