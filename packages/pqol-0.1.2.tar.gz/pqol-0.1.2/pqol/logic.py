class logic:
    @staticmethod
    def AND(a, b):
        return bool(a and b)
        
    @staticmethod
    def OR(a, b):
        return bool(a or b)

    @staticmethod
    def NOT(a):
        return not bool(a)
    @staticmethod
    def NAND(a, b):
        return not (a and b)

    @staticmethod
    def NOR(a, b):
        return not (a or b)

    @staticmethod
    def XOR(a, b):
        return bool(a) != bool(b)

    @staticmethod
    def XNOR(a, b):
        return bool(a) == bool(b)