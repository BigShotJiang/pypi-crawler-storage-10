from setuptools import setup, find_packages

setup(
    name="specrypto",
    version="1.0.0",
    author="S P Ecialise Srinivasan",
    author_email="specialise.ceg@gmail.com",
    description="A powerful mathematical toolkit including number theory, modular arithmetic, matrix operations, and crypto utilities",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/SP-ecialise/specrypto",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["numpy","pycryptodome"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    python_requires=">=3.7",
)
