from render_engine_sitemap.plugin import SiteMap

__all__ = ["SiteMap"]
