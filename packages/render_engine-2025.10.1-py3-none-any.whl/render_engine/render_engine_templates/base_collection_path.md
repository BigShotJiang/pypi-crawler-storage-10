---
title: Example Page
---

# This is a test page

This page was built using the `create_app` command.

You may notice this is [markdown](https://www.markdownguide.org) format.

You can add the markdown parser to this collection.

```python

from render_engine.parsers.markdown import MarkdownPageParser

...

```

For more information check out the [Render Engine Documentation](https://render-engine.readthedocs.io/en/latest/)
