from setuptools import setup, find_packages

setup(
    name='chem_spectra',
    version='0.0.20',
    url='',
    author='Yannick Zander',
    author_email='yannick.zander@gmail.com',
    description='Processing chemical spectra',
    packages=find_packages(),
    install_requires=['numpy', 'matplotlib', 'pandas', 'tqdm'],
)
