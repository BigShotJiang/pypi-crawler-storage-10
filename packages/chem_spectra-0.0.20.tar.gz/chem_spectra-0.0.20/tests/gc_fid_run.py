import pandas as pd

from chem_spectra.base import SpectrumBaseClass

path_file = r"\\hlabstorage.dmz.marum.de\scratch\Yannick\Lennart_FID_data\FAME_MUC08_282_sq_50_118_FrontDetector.txt"

df = pd.read_csv(
    path_file, skiprows=42, sep='\t', decimal=',', thousands='.'
).drop(columns='Step (s)')

spec = SpectrumBaseClass.from_dataframe(df)

