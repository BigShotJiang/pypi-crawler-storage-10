from chem_spectra.base import SpectrumBaseClass


class Spectrum(SpectrumBaseClass):
    pass
