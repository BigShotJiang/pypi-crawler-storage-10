import numpy as np

from chem_spectra.base import SpectrumBaseClass


class Spectra(SpectrumBaseClass):
    spectra_indices: np.ndarray[int] = None

    # (x and) y are/is two-dimension instead
    ...
