from typing import Literal, Any

import numpy as np
from matplotlib import pyplot as plt
from scipy.signal import find_peaks

from chem_spectra.peaks.main import Peak, PEAK_PROPERTIES_SCIPY, PeakList

PEAK_SEARCH_METHODS = ['prominence']
PeakSearchMethod: type = Literal[*PEAK_SEARCH_METHODS]


class PeakFinder:
    """Find peaks in a profile spectrum."""
    x: np.ndarray[int | float] = None
    y: np.ndarray[int | float] = None

    peak_indices: np.ndarray[int] = None
    peak_properties: dict[PEAK_PROPERTIES_SCIPY, Any] = None

    parameters: dict[str, Any] = None

    def __init__(self, x, y, search_on_init: bool = True, **kwargs):
        self.x = x
        self.y = y

        self.parameters = {}

        if search_on_init:
            self.search(**kwargs)

    @classmethod
    def from_spectrum(cls, spec, **kwargs):
        new = cls(x=spec.x, y=spec.y, **kwargs)
        return new

    def search(self, method: PeakSearchMethod = 'prominence', **kwargs):
        if method == 'prominence':
            self.search_prominence(**kwargs)
        else:
            raise NotImplementedError()

    def search_prominence(
            self,
            abs_prominence=None,
            rel_prominence=None,
            rel_to: Literal['median', 'max'] = 'median', width=3,
            **kwargs_find_peaks
    ):
        """if neither abs nor rel are provided, rel_prominence will be set to 0.1"""
        assert width is not None, 'width required for downstream processing'
        assert 'rel_height' not in kwargs_find_peaks, 'rel_height of 0.5 required for further processing'

        if (abs_prominence is None) and (rel_prominence is None):
            rel_prominence = .1

        if rel_prominence is not None:
            if rel_to == 'max':
                abs_p = rel_prominence * self.y.max()
            elif rel_to == 'median':
                abs_p = rel_prominence * np.median(self.y)
            else:
                KeyError(f'rel_to should be median or max')
            # if abs is also provided, take stricter (higher) one
            if abs_prominence is not None:
                abs_prominence = max([abs_prominence, abs_p])
            else:
                abs_prominence = abs_p

        self.parameters['prominence_threshold'] = abs_prominence

        self.peak_indices, self.peak_properties = find_peaks(
            self.y, prominence=abs_prominence, width=width,
            rel_height=.5,  # do not allow this argument to be overwritten
            **kwargs_find_peaks
        )

    def to_peak_list(self) -> PeakList:
        peaks = []
        for i in range(self.peak_indices.shape[0]):
            x_idx = self.peak_indices[i]
            props = {}
            for k, v in self.peak_properties.items():
                props[k] = v[i]
            # noinspection PyTypeChecker
            p = Peak(x_idx=x_idx, x=self.x[x_idx], y=self.y[x_idx], properties=props)
            peaks.append(p)
        return PeakList(peaks)

    def plot(self, ax: plt.Axes = None):
        if ax is None:
            _, ax = plt.subplots()
        ax.plot(self.x, self.y)

        if self.peak_indices is None:
            return ax

        ax.vlines(
            x=self.x[self.peak_indices],
            ymin=self.y[self.peak_indices] - self.peak_properties["prominences"],
            ymax=self.y[self.peak_indices], color="C1"
        )
        ax.hlines(
            y=self.peak_properties["width_heights"],
            xmin=self.x[self.peak_properties["left_ips"].astype(int)],
            xmax=self.x[self.peak_properties["right_ips"].astype(int)],
            color="C1"
        )
        return ax
