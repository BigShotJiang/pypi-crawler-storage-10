from typing import Callable

import numpy as np
from scipy.optimize import curve_fit

from chem_spectra.peaks.main import Peak
from chem_spectra.peaks.peak_shapes import PeakShape, PEAK_SHAPE_TO_FUNC, PEAK_SHAPES
from chem_spectra.util import convert_fwhm_to_sigma

import logging

logger = logging.getLogger(__name__)

DEFAULT_RELATIVE_SEARCH_RANGES_PARAMETERS: dict[str, float] = {
    'x_c': 0.2,
    'sigma': 0.2,
    'sigma_l': 0.2,
    'sigma_r': 0.2,
    'H': 0.2
}


def get_absolute_bounds(params0, bound_deviation_factors) -> tuple[list, list]:
    bounds_l = []
    bounds_r = []
    for param_name, param_value in params0.items():
        if param_value == 0:
            logger.warning(
                'encountered parameter with initial value of 0. This may cause '
                'issues because absolute bounds are not well defined. Consider '
                'providing absolute bounds instead.'
            )
            bounds_l.append(-1e-32)
            bounds_l.append(1e-32)
            continue
        # need to swap upper and lower for negative values
        sign = np.sign(param_value)
        bounds_l.append(param_value * (1 - bound_deviation_factors[param_name] * sign))
        bounds_r.append(param_value * (1 + bound_deviation_factors[param_name] * sign))
    return bounds_l, bounds_r


def get_params_from_peak(peak: Peak, x) -> tuple[Callable, dict]:
    """get the right peak shape function and the right parameters for the fitting function from a peak object"""
    f_name: PeakShape = peak.shape
    if f_name == 'gaussian':
        # left and right are locations of indices (but floats)
        fwhm = x[round(peak.properties['right_ips'])] - x[round(peak.properties['left_ips'])]
        params0 = {
            'x_c': peak.x,
            'H': peak.y,
            'sigma': convert_fwhm_to_sigma(fwhm)
        }
    elif f_name == 'bigaussian':
        x_c = peak.x
        fwhm_l = (x_c - x[round(peak.properties['left_ips'])]) * 2
        fwhm_r = (x[round(peak.properties['right_ips'])] - x_c) * 2
        params0 = {
            'x_c': x_c,
            'H': peak.y,
            'sigma_l': convert_fwhm_to_sigma(fwhm_l),
            'sigma_r': convert_fwhm_to_sigma(fwhm_r),
        }
    else:
        raise NotImplementedError(f'{f_name} is not a valid peak shape, choose one of {PEAK_SHAPES}')
    f = PEAK_SHAPE_TO_FUNC[f_name]

    return f, params0


def peak_curve_fit(
        func: Callable,
        params0: dict,
        x: np.ndarray,
        y: np.ndarray,
        bound_deviation_factors: dict[str, float] = None
) -> dict:
    """
    Utilize scipy's curve fit function to adjust parameters from find_peaks to
    fine-tune fit

    :param func:
    :param params0:
    :param x:
    :param y:
    :return:
    """
    if bound_deviation_factors is None:
        bound_deviation_factors = DEFAULT_RELATIVE_SEARCH_RANGES_PARAMETERS
    bounds = get_absolute_bounds(params0, bound_deviation_factors)

    params = curve_fit(
        f=func,
        xdata=np.asarray(x).astype(np.float64),  # doc says float64 is required
        ydata=np.asarray(y).astype(np.float64),  # doc says float64 is required
        p0=list(params0.values()),
        bounds=bounds
    )[0]
    return {name: fitted_value for name, fitted_value in zip(params0.keys(), params)}


def coeluting_peak_curve_fit(func, params_a0, params_b0, x, y):
    ...


def fit_peak(peak: Peak, spectrum: "SpectrumBaseClass", **kwargs) -> dict:
    func, params0 = get_params_from_peak(peak, spectrum.x)
    return peak_curve_fit(func=func, params0=params0, x=spectrum.x, y=spectrum.y, **kwargs)
