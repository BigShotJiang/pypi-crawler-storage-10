import warnings
from dataclasses import dataclass
from typing import Any, Literal

import numpy as np
from matplotlib import pyplot as plt
from scipy.signal import find_peaks

from chem_spectra.peaks.peak_shapes import PeakShape, PEAK_SHAPE_TO_FUNC

# noinspection PyTypeHints
PEAK_PROPERTIES_SCIPY = Literal[
    'peak_heights',
    'left_thresholds', 'right_thresholds',
    'prominences', 'right_bases', 'left_bases',
    'widths', 'width_heights', 'left_ips', 'right_ips',
    'plateau_size', 'left_edges', 'right_edges'
]


@dataclass
class Peak:
    """Acts as a container for various peak processing steps, not intended to be used on its own."""
    x: int | float = None
    y: int | float = None
    x_idx: int = None

    # todo: use compound from msIO
    annotation: str = None

    # populated by the scipy.signal.find_peaks function
    properties: dict[PEAK_PROPERTIES_SCIPY, Any] = None
    shape: PeakShape = None

    # populated by the fit_peak function
    parameters: dict[str, int | float] = None

    quantified: float | int = None
    quantification_parameters: dict = None

    def _get_intersection_at_height(self, height: float, xs, ys, is_left: bool) -> float:
        """
        Determine the intersection of a horizontal line at the specified
        height either left or right of the peak
        """
        # draw vertical line at height and find intersection with ys
        if is_left:
            # last value where peak values are below the height
            ys_ = (ys < height) & (xs < self.x)
            assert np.any(ys_), f'no value found below the specified level of {height} for peak {id(self)} on the left'
            idx_below = np.argwhere(ys_)[-1][0]
        else:
            # first value where peak values are below the height
            ys_ = (ys < height) & (xs > self.x)
            assert np.any(ys_), f'no value found below the specified level of {height} for peak {id(self)} on the right'
            idx_below = np.argwhere(ys_)[0][0] - 1
        idx_above = idx_below + 1
        # interpolate intersection value
        v = np.interp(x=height, xp=ys[[idx_below, idx_above]], fp=xs[[idx_below, idx_above]])
        return v

    def get_widths_at_rel_height(self, reL_height: float, xs, ys) -> tuple[float, float]:
        assert 0 < reL_height < 1
        height = self.y * reL_height
        a = self.x - self._get_intersection_at_height(height, xs, ys, True)
        b = self._get_intersection_at_height(height, xs, ys, False) - self.x
        return a, b

    def get_tailing_factor(self, xs, ys):
        """Defined as the ratio of the width at 5 % and 2x left width at 5 %

        from https://lcms.cz/labrulez-bucket-strapi-h3hsga3/peak_shape_august102023_72c0549acf/peak-shape-august102023.pdf
        """
        a, b = self.get_widths_at_rel_height(.05, xs, ys)
        return (a + b) / (2 * a)

    def get_asymmetry_factor(self, xs, ys):
        # from https://lcms.cz/labrulez-bucket-strapi-h3hsga3/peak_shape_august102023_72c0549acf/peak-shape-august102023.pdf
        a, b = self.get_widths_at_rel_height(.1, xs, ys)
        return b / a

    def get_fwhm(self, xs):
        """In units of xs"""
        a = xs[round(self.properties['left_ips'])]
        b = xs[round(self.properties['right_ips'])]
        return b - a

    @property
    def kernel_func(self):
        if self.shape is None:
            raise AttributeError('Peak shape not defined')
        return PEAK_SHAPE_TO_FUNC[self.shape]

    def _get_boundaries_from_relative_height(self, rel_height, xs, ys):
        """For peak integration, proper boundaries have to be found. This is a tread-off between avoiding noise/ running out of bounds
        and including as much information from the peak as possible
        """
        a, b = self.get_widths_at_rel_height(rel_height, xs, ys)
        return self.x - a, self.x + b

    def _get_boundaries_from_std(self, factor) -> tuple[float, float]:
        # find parameter resembling std
        _func_to_std_names: dict[PeakShape, tuple[str, str]] = {
            'gaussian': ('sigma', 'sigma'),
            'bigaussian': ('sigma_l', 'sigma_r'),
        }
        assert self.shape in _func_to_std_names, \
            f'internal error: do not know which parameter should be used for std for peak shape {self.shape}'
        param_names: tuple[str, str] = _func_to_std_names[self.shape]
        # fetch values
        assert self.parameters is not None, \
            'can only use this function after peak parameters were determined'

        # left and right side
        std_l, std_r = [self.parameters[n] for n in param_names]
        return self.x - std_l * factor, self.x + std_r * factor

    def get_bounds(
            self,
            xs=None,
            ys=None,
            relative_height_level: float = None,
            max_standard_deviations: float = None,
            if_both_use: Literal['biggest', 'smallest'] = 'biggest'
    ) -> tuple[float, float]:
        """Get the boundaries for peak integration using either the relative height or the width of the peak (or both)"""
        use_height = relative_height_level is not None
        use_widths = max_standard_deviations is not None
        assert use_widths or use_height

        if use_height:
            assert (xs is not None) and (ys is not None), 'xs and ys required for relative height'
            bounds_height = self._get_boundaries_from_relative_height(relative_height_level, xs, ys)
            if not use_widths:
                return bounds_height
        if use_widths:
            bounds_width = self._get_boundaries_from_std(max_standard_deviations)
            if not use_height:
                return bounds_width

        if if_both_use == 'biggest':
            bounds = min([bounds_height[0], bounds_width[0]]), max([bounds_height[1], bounds_width[1]])
        elif if_both_use == 'smallest':
            bounds = max([bounds_height[0], bounds_width[0]]), min([bounds_height[1], bounds_width[1]])
        else:
            raise KeyError()
        return bounds

    def _quantify_from_signal_area(self, xs, ys, **kwargs) -> float:
        # use peak parameters to determine integration boundaries
        bounds = self.get_bounds(xs, ys, **kwargs)
        self.quantification_parameters['bounds'] = bounds
        mask = (xs >= bounds[0]) & (xs <= bounds[1])
        return np.trapezoid(y=ys[mask], x=xs[mask])

    def _quantify_from_height(
            self,
            method_height: Literal['height', 'max'],
            xs, ys,
            is_original_xs: bool = False,
            check_at_interval_boundary: bool = False,
            **kwargs
    ) -> float:
        bounds = self.get_bounds(xs, ys, **kwargs)
        self.quantification_parameters['bounds'] = bounds

        mask = (xs >= bounds[0]) & (xs <= bounds[1])
        if method_height == 'max':
            if not check_at_interval_boundary:
                return ys[mask].max()
            ys_peak = ys[mask]
            xs_peak = xs[mask]
            idx_candidates, *_ = find_peaks(ys_peak)
            y_peak = ys_peak[idx_candidates].max()
            x_peak = xs_peak[np.argmax(ys_peak[idx_candidates])]

            x_idx = np.argwhere((y_peak == ys) & (x_peak == xs))[0][0]
            self.quantification_parameters['x_value_for_height'] = xs[x_idx]
            return y_peak
        elif method_height == 'height':
            if check_at_interval_boundary:
                warnings.warn('will not check for height method_height')
            if is_original_xs:
                x_idx = self.x_idx
            else:
                x_idx = np.argmin(np.abs(xs - self.x))
            self.quantification_parameters['x_value_for_height'] = xs[x_idx]
            return ys[x_idx]

    def quantify(self, use_fitted: bool, integrate: bool, xs = None, ys = None, **kwargs):
        """
        Quantify by integrating either the area or the height.

        Can use the fitted parameters (for noisy/ biased data) or the raw/processed data.
        If the latter is used, peak parameters are used to determine integration
        boundaries
        """
        self.quantification_parameters = dict(
            use_fitted=use_fitted,
            integrate=integrate
        ) | kwargs

        assert xs is not None
        assert ys is not None

        if use_fitted:
            if ys is not None:
                warnings.warn('y values not needed if integrating the fit')
            # TODO: use analytical results
            ys = self.kernel_func(xs, **self.parameters)

        max_standard_deviations = kwargs.pop('max_standard_deviations', 2)
        self.quantification_parameters['max_standard_deviations'] = max_standard_deviations

        if integrate:
            self.quantified = self._quantify_from_signal_area(
                xs=xs, ys=ys,
                max_standard_deviations=max_standard_deviations,
                **kwargs
            )
        else:  # use fitted
            assert 'method_height' in kwargs
            self.quantified = self._quantify_from_height(
                method_height=kwargs.pop('method_height'),
                xs=xs, ys=ys,
                is_original_xs=True,
                max_standard_deviations=max_standard_deviations,
                **kwargs
            )

    def get_halfwidth_idcs(self) -> tuple[float, str]:
        if (self.properties is not None) and ('left_ips' in self.properties):
            half_width = (self.properties['right_ips'] - self.properties['left_ips'])
            return half_width, 'properties_ips'
        elif (self.properties is not None) and ('widths' in self.properties):
            half_width = self.properties['widths'] / 2
            return half_width, 'properties_width'
        # elif self.parameters is not None:
        #     half_width = np.mean([convert_sigma_to_fwhm(v) / 2 for k, v in self.parameters.items() if 'sigma' in k])
        #     return half_width, 'sigma_fit'
        else:
            half_width = 0
            return half_width, 'none'

    def get_masked(self, xs: np.ndarray, half_width, n_widths=3):
        return (xs > (self.x - half_width * n_widths)) & (xs < (self.x + half_width * n_widths))

    def plot(self, xs: np.ndarray = None, ax: plt.Axes = None, add_labels=None) -> plt.Axes:
        if add_labels is None:  # only add labels if new axes object is created
            add_labels = ax is None
        if ax is None:
            _, ax = plt.subplots()

        if use_indices := (xs is None):
            half_width_idcs = self.get_halfwidth_idcs()[0]
            idcs_per_side = 3 * half_width_idcs
            # draw using indices
            xs = np.arange(self.x_idx - idcs_per_side, self.x_idx + idcs_per_side + 1)

        if use_indices:
            mask = np.ones_like(xs, dtype=bool)
        else:
            mask = self.get_masked(xs, half_width=self.get_fwhm(xs) / 2)

        # draw properties, if defined
        ax.vlines(
            x=self.x,
            ymin=0,
            ymax=self.y,
            color="C1",
            label='height' if add_labels else None
        )
        if not use_indices:
            ax.hlines(
                y=self.properties["width_heights"],
                xmin=xs[self.properties["left_ips"].astype(int)],
                xmax=xs[self.properties["right_ips"].astype(int)],
                color="C1", label='FWHM' if add_labels else None
            )

        # draw peak shape, if defined from parameters
        if self.parameters is not None:
            xs_plot = xs[mask]
            ys_plot = self.kernel_func(xs_plot, **self.parameters)
            ax.plot(xs_plot, ys_plot, label='fit' if add_labels else None)

        # draw integrated, selected quantification
        if self.quantified is not None:
            ax.vlines(self.quantification_parameters['bounds'],
                      0,
                      ys_plot.max(),
                      label='integration bounds',
                      color='C2')
            if not self.quantification_parameters['integrate']:  # height
                ax.scatter(
                    self.quantification_parameters['x_value_for_height'],
                    self.quantified,
                    label='quantified height' if add_labels else None,
                    color='red'
                )
        return ax


class PeakList:
    # TODO: is this class really necessary?
    peaks: list[Peak] = None

    def __init__(self, peaks: list[Peak]):
        self.peaks = peaks

    def get_closest_peak(self, x) -> tuple[Peak, float]:
        dists = [p.x - x for p in self.peaks]
        idx = np.argmin(np.abs(dists))
        return self.peaks[idx], dists[idx]

    def filter_on_abs_height(self, thr: int | float):
        self.peaks = [p for p in self.peaks if p.y > thr]

    def filter_on_rel_height(self, thr: int | float):
        max_height = max([p.y for p in self.peaks])
        self.peaks = [p for p in self.peaks if p.y / max_height > thr]

    def filter_on_param(
            self,
            param_name: str,
            param_lower=None,
            param_upper=None,
            keep_if_param_missing: bool = False
    ):
        is_param_lower_active = (param_lower is not None)
        is_param_upper_active = (param_upper is not None)
        peaks = []
        for p in self.peaks:
            if param_name not in p.parameters:
                if keep_if_param_missing:
                    peaks.append(p)
                else:
                    continue
            val = p.parameters[param_name]
            if is_param_lower_active and (val < param_lower):
                continue
            if is_param_upper_active and (val > param_upper):
                continue
            peaks.append(p)
        self.peaks = peaks
