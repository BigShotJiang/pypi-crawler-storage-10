from typing import Literal, Callable

import numpy as np


def gaussian(x: np.ndarray, x_c: float, H: float, sigma: float) -> np.ndarray:
    """
    Gaussian kernel function.

    Parameters
    ----------
    x : np.ndarray
        The values at which to evaluate the function
    x_c : np.ndarray
        Center of the kernel in same units as x.
    H : int | float
        Amplitude of the kernel.
    sigma : int | float
        Standard deviation defining the width of the kernel.

    Returns
    -------
    y: np.ndarray
        The function values at the provided x values.
    """
    return H * np.exp(-1 / 2 * ((x - x_c) / sigma) ** 2)


def bigaussian(
        x: np.ndarray, x_c: float, H: float, sigma_l: float, sigma_r: float
) -> np.ndarray:
    """
    Evaluate bigaussian for mass vector based on parameters.

    Parameters
    ----------
    x : np.ndarray
        mass vector.
    x_c : float
        mass at center of peak
    H : float
        Amplitude of peak.
    sigma_l : float
        left-side standard deviation.
    sigma_r : float
        right-side standard deviation.

    Returns
    -------
    y: np.ndarray
        Intensities of bigaussian at given x.

    """
    x_l = x[x <= x_c]
    x_r = x[x > x_c]
    y_l = H * np.exp(-1 / 2 * ((x_l - x_c) / sigma_l) ** 2)
    y_r = H * np.exp(-1 / 2 * ((x_r - x_c) / sigma_r) ** 2)
    return np.hstack([y_l, y_r])


PEAK_SHAPES = ['gaussian', 'bigaussian']
PEAK_FUNCTIONS = [gaussian, bigaussian]
# noinspection PyTypeHints
PeakShape: type = Literal[*PEAK_SHAPES]

PEAK_SHAPE_TO_FUNC: dict[PeakShape, Callable] = {f_name: f for f_name, f in zip(PEAK_SHAPES, PEAK_FUNCTIONS)}


if __name__ == '__main__':
    pass
