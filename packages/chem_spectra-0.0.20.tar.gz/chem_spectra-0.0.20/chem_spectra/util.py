import numpy as np

"""
FWHM = 2 * sqrt(2 * ln(2)) * sigma
FWHM = 2 * k * sigma
sigma = FWHM / 2 / k
"""
Y_AT_HALF = np.sqrt(2 * np.log(2))


def convert_fwhm_to_sigma(fwhm: float) -> float:
    """Assumes peak is gaussian"""
    return (fwhm / 2) / Y_AT_HALF


def convert_sigma_to_fwhm(sigma: float) -> float:
    return sigma * Y_AT_HALF * 2


if __name__ == '__main__':
    import matplotlib.pyplot as plt

    sigma = 5
    mu = 0
    x_min = -3 * sigma + mu
    x_max = 3 * sigma + mu
    xs = np.linspace(x_min, x_max, 100)
    ys = np.exp(-1/2 * (xs - mu) ** 2 / sigma ** 2)

    fwhm = convert_sigma_to_fwhm(sigma)
    sigma_re = convert_fwhm_to_sigma(fwhm)

    plt.figure()
    plt.plot(xs, ys)
    plt.vlines([mu - fwhm / 2, mu + fwhm / 2], 0, 1, colors='r')
    plt.hlines(1/2, x_min, x_max, colors='r')
    plt.savefig('temp.pdf')
    plt.close()
