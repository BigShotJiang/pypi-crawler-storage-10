from typing import Callable, Self, Literal

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from chem_spectra.baseline_finder.main import Baseline
from chem_spectra.peaks.main import Peak, PeakList

import logging

from chem_spectra.peaks.peak_finder.main import PeakFinder
from chem_spectra.peaks.peak_fitter.main import fit_peak
from chem_spectra.peaks.peak_shapes import PeakShape

logger = logging.getLogger(__name__)

SPECTRUM_TYPES: list[str] = ['LC', 'GC', 'MS', 'mob']
# noinspection PyTypeHints
SpectrumType: type = Literal[*SPECTRUM_TYPES]

DEFAULT_PEAK_SHAPES: dict[SpectrumType, PeakShape] = {
    'LC': 'bigaussian',
    'GC': 'bigaussian',
    'MS': 'gaussian',
    'mob': 'bigaussian'
}


class SpectrumBaseClass:
    spectrum_type: SpectrumType = None

    is_standard_run: bool = None

    # mass, retention time or mobility
    x: np.ndarray[int | float] = None
    x_unit: str = None
    x_name: str = None

    # counts, voltage, ...
    y: np.ndarray[int | float] = None
    y_unit: str = None
    y_name: str = None

    is_resampled_at_interval: int | float = None

    baseline: Baseline = None
    has_baseline_subtracted = False
    # output from scipy find_peaks
    peak_finder: PeakFinder = None
    peak_list: PeakList = None

    # remaining intensity after peak parameters have been used to deconvolute
    # and quantify peaks
    y_post_quantify: np.ndarray = None

    # takes the x values and returns shifted values
    calibration_function: Callable[[np.ndarray[int | float]], np.ndarray[float]] = None

    # as fraction of total area
    reconstruction_loss: float = None

    @classmethod
    def from_dataframe(cls, df):
        """assuming first column corresponds to x and second to y"""

        def _split_unit(name: str) -> tuple[str, str]:
            if ('(' not in name) or (')' not in name):
                return name, ''
            ts = name.split('(', 1)
            name, unit = ts[0].strip(), ts[1].strip(') \n')
            return name, unit

        x_col, y_col = df.columns

        new = cls()
        # attempt to split of unit name in brackets
        new.x_name, new.x_unit = _split_unit(x_col)
        new.x_name, new.x_unit = _split_unit(x_col)
        new.x = df.loc[:, x_col].to_numpy()
        new.y = df.loc[:, y_col].to_numpy()
        return new

    def resample(self, dx=None, x_new=None, enforce_even_sampling: bool = True):
        assert (dx is not None) or (x_new is not None), \
            'provide either sampling interval (dx) or sample positions (x_new)'

        # determine sample positions
        if dx is not None:
            # create mzs spaced apart with specified precision
            # round to next smallest multiple of delta_mz
            smallest_x = int(self.x.min() / dx) * dx
            # round to next biggest multiple of delta_mz
            biggest_x = (int(self.x.max() / dx) + 1) * dx
            # equally spaced
            xs_ip = np.arange(smallest_x, biggest_x + dx, dx)
        else:
            dxs = np.diff(x_new)
            if enforce_even_sampling:
                assert np.allclose(dxs[1:], dxs[0]), \
                    'passed dx must either be float or list of equally spaced mzs'
            xs_ip = x_new
            dx = dxs[0]

        if self.is_resampled_at_interval == dx:
            return
        if enforce_even_sampling:
            self.is_resampled_at_interval = dx

        # interpolate to regular spaced mz values
        ints_ip = np.interp(xs_ip, self.x, self.y)
        # overwrite objects mz vals and intensities
        self.x = xs_ip
        self.y = ints_ip

    def set_window(self, window: tuple[int | float, int | float]):
        lower, upper = window
        mask = (self.x >= lower) & (self.x <= upper)
        self.x = self.x[mask]
        self.y = self.y[mask]

    def plot(self, ax: plt.Axes = None, **kwargs):
        if ax is None:
            _, ax = plt.subplots()

        ax.plot(self.x, self.y)
        return ax

    def plot_peaks(self, ax: plt.Axes = None) -> plt.Axes:
        if ax is None:
            _, ax = plt.subplots()
        for idx, peak in enumerate(self.peak_list.peaks):
            peak.plot(xs=self.x, ax=ax)
            if peak.annotation is not None:
                ax.text(peak.x, peak.y, f'{idx}: {peak.annotation}', rotation='vertical')
        return ax

    def plot_integrated_peak(self, x_roughly: float = None, x_lim = None, ax: plt.Axes = None) -> plt.Axes:
        if ax is None:
            _, ax = plt.subplots()

        if x_roughly is None:
            # plot all of them
            for p in self.peak_list.peaks:
                self.plot_integrated_peak(x_roughly=p.x, x_lim=x_lim, ax=ax)
            return ax

        p: Peak = self.peak_list.get_closest_peak(x_roughly)[0]
        if x_lim is None:
            x_lim = p.get_bounds(
                xs=self.x,
                ys=self.y,
                max_standard_deviations=5,
                relative_height_level=.05,
                if_both_use='smallest'
            )

        if p.quantification_parameters['use_fitted']:
            ys_peak = p.kernel_func(self.x, **p.parameters)
        else:
            ys_peak = self.y.copy()
        ys_peak += self.baseline.y_baseline

        # raw between bounds
        mask_plot = (self.x > x_lim[0]) & (self.x < x_lim[1])
        ax.plot(
            self.x[mask_plot],
            self.y[mask_plot] + self.baseline.y_baseline[mask_plot],
            color='C0',
            label='raw'
        )
        ax.plot(self.x[mask_plot], self.baseline.y_baseline[mask_plot], label='baseline', color='C1')

        if p.quantification_parameters['integrate']:
            lower_int_b, upper_int_b = p.quantification_parameters['bounds']
            mask_int = (self.x > lower_int_b) & (self.x < upper_int_b)
            ax.fill_between(
                self.x[mask_int],
                self.baseline.y_baseline[mask_int],
                ys_peak[mask_int],
                label='integrated area', color='C2'
            )
        # TODO: plots for quantification from height
        ...

        return ax

    def find_baseline(self, suppress_warnings: bool = False, **kwargs):
        if not suppress_warnings and self.is_resampled_at_interval is None:
            logger.warning(
                'Spectrum is not resampled. It is recommended to ensure even '
                'sampling before finding the baseline'
            )
        self.baseline = Baseline.from_spectrum(self, **kwargs)

    def subtract_baseline(self, suppress_warnings: bool = False):
        assert (self.baseline is not None) and (self.baseline.y_baseline is not None), \
            'need to call find_baseline first'
        if not suppress_warnings and self.has_baseline_subtracted:
            logger.warning('Baseline subtraction has been called before')
        self.y = self.baseline.get_y_corrected(self.y)
        self.has_baseline_subtracted = True

    def find_peak_positions(self, **kwargs):
        self.peak_finder = PeakFinder.from_spectrum(self, **kwargs)
        self.peak_list: PeakList = self.peak_finder.to_peak_list()

    def find_targets(self, *args, **kwargs):
        ...

    def filter_peaks_on_heights(self, *args, **kwargs):
        ...

    def find_calibration(self, *args, **kwargs):
        ...

    def apply_calibration(self, *args, **kwargs):
        ...

    def find_peak_parameters(self, peak_shape: PeakShape = None, **kwargs):
        if peak_shape is None:
            peak_shape: PeakShape = DEFAULT_PEAK_SHAPES[self.spectrum_type]

        for p in self.peak_list.peaks:
            p.shape = peak_shape
            params_fit = fit_peak(p, self, **kwargs)
            p.parameters = params_fit

    def annotatate_peaks_manually(self, mapper: dict[int, str | None]):
        """Mapper: peak index to label"""
        for idx, lbl in mapper.items():
            self.peak_list.peaks[idx].annotation = lbl

    def filter_peaks_on_parameters(self, *args, **kwargs):
        ...

    def set_peak_abundances(self, use_fitted: bool, integrate: bool, try_deconvolute: bool = True, **kwargs):
        # start with highest prominence peak and subtract peak contribution
        # TODO: better model for coeluting peaks
        y_remainder = self.y.copy()
        ordering = np.argsort([p.y for p in self.peak_list.peaks])[::-1]

        for idx in ordering:
            p = self.peak_list.peaks[idx]
            p.quantify(
                xs=self.x,
                ys=y_remainder,
                use_fitted=use_fitted,
                integrate=integrate,
                **kwargs
            )
            if not try_deconvolute:
                continue

            q_bounds = p.quantification_parameters['bounds']
            mask_peak = (self.x > q_bounds[0]) & (self.x < q_bounds[1])
            if use_fitted:
                y_remainder -= p.kernel_func(self.x, **p.parameters)
            else:
                y_remainder[mask_peak] = 0

        if try_deconvolute:
            self.y_post_quantify = y_remainder

    def to_dataframe(self):
        # flatten properties of peaks
        xs_peak = [p.x for p in self.peak_list.peaks]
        qs_peak = [p.quantified for p in self.peak_list.peaks]
        lbls_peak = [p.annotation for p in self.peak_list.peaks]
        df = pd.DataFrame({
            'x': xs_peak,
            'q': qs_peak,
            'annotation': lbls_peak
        })
        return df

    def to_sql(self):
        ...

    def find_reconstruction_loss(self, *args, **kwargs):
        ...

    def norm(self, *args, **kwargs):
        ...

    def __add__(self, other: Self) -> Self:
        ...
