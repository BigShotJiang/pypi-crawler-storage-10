from typing import Self, Any

from scipy.ndimage import minimum_filter, median_filter
from scipy.signal import find_peaks, peak_widths

import numpy as np
import matplotlib.pyplot as plt


class Baseline:
    y_baseline: np.ndarray[int | float] = None
    parameters: dict[str, Any] = None

    def __init__(self, x, y, method: str = 'min|median', fit_on_init: bool = True, **kwargs):
        self.parameters = {}

        if fit_on_init:
            self.fit(x, y, method=method, **kwargs)

    @classmethod
    def from_spectrum(cls, spec, **kwargs) -> Self:
        new = cls(x=spec.x, y=spec.y, **kwargs)
        return new

    def fit(self, x, y, method, **kwargs):
        if method == 'min|median':
            self.fit_min_median(x, y, **kwargs)
        else:
            raise NotImplementedError()

    def fit_min_median(
            self,
            x, y,
            window_size: int = None,
            required_prominence: float = None,
            window_size_from_rel_height=.8
    ):
        """Use global window size determined from peak parameters and tweaked to minimize peak collapse fraction"""

        def estimate_peaks_width(prominence, rel_height) -> int:
            """Estimate the minimum filter size from the peak widths."""
            if prominence is None:
                prominence = .1 * np.median(y)
            peaks, peak_props = find_peaks(y, prominence=prominence, width=3)
            widths, *_ = peak_widths(y, peaks=peaks, rel_height=rel_height)
            return int(np.max(widths))

        if window_size is None:
            window_size = estimate_peaks_width(required_prominence, window_size_from_rel_height)
        self.parameters['window_size_samples'] = window_size
        self.parameters['window_size_abs'] = window_size * np.median(np.diff(x))

        ys_min: np.ndarray[float] = minimum_filter(y, size=window_size)
        # run median filter on that
        self.y_baseline: np.ndarray[float] = median_filter(ys_min, size=window_size)

    def check_peak_collapse(self) -> bool:
        """inside of peaks the slope of the baseline should not have a peak. check this for a specific peak"""
        # TODO
        ...

    def get_score(self):
        """Good baseline fit can be quantified by how peaks look before and after: should not collapse"""
        # TODO
        ...

    def get_y_corrected(self, y) -> np.ndarray[int | float]:
        assert self.y_baseline is not None
        corrected = y - self.y_baseline
        corrected[corrected < 0] = 0
        return corrected

    def plot(
            self,
            x, y,
            x_lim: tuple[int | float, int | float] = None,
            y_lim: tuple[int | float, int | float] = None,
            ax: plt.Axes = None
    ):
        if ax is None:
            _, ax = plt.subplots()

        if x_lim is not None:
            lower, upper = x_lim
            mask = (x >= lower) & (x <= upper)
        else:
            mask = np.ones_like(x, dtype=bool)
        x_plot = x[mask]
        y_plot = y[mask]

        ax.plot(x_plot, y_plot, label='original')
        if self.y_baseline is not None:
            ax.plot(x_plot, self.y_baseline[mask])
        if (ws := self.parameters.get('window_size_samples')) is not None and ws < x_plot.shape[0]:
            # anchor at left
            y = y_plot[:ws].min()
            ax.hlines(y, x_plot[0], x_plot[ws], colors='r', label='filter size')
        if y_lim is not None:
            ax.set_ylim(y_lim)
        ax.legend()
        return ax

