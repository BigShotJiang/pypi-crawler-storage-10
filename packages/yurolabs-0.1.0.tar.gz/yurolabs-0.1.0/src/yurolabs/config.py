
import os
from appdirs import user_config_dir

CONFIG_DIR = user_config_dir("yurolabs")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config")

def save_key(key: str):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        f.write(key)

def load_key():
    with open(CONFIG_FILE) as f:
        return f.read().strip()
