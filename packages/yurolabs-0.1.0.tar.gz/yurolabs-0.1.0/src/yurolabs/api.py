
import requests
from yurolabs.config import load_key

BASE = "https://your-modal-backend.example.com"

def deploy_model(model_path: str):
    key = load_key()
    files = {"file": open(model_path, "rb")}
    r = requests.post(f"{BASE}/deploy", files=files, headers={"Authorization": key})
    return r.json()

def run_inference(data):
    key = load_key()
    r = requests.post(f"{BASE}/infer", json={"data": data}, headers={"Authorization": key})
    return r.json()
