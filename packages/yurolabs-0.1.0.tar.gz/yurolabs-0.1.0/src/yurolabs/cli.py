import typer
from rich import print

from yurolabs.config import save_key
from yurolabs.api import deploy_model, run_inference

app = typer.Typer(help="Yuro model management CLI.")

@app.command()
def login(key: str):
    save_key(key)
    print("[green]API key saved![/green]")

@app.command()
def deploy(model: str):
    print("[cyan]Deploying model...[/cyan]")
    out = deploy_model(model)
    print(out)

@app.command()
def test(input: str):
    print("[cyan]Running inference...[/cyan]")
    out = run_inference(input)
    print(out)
