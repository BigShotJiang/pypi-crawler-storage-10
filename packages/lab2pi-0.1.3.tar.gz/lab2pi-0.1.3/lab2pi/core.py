import os
import json

class Lab:
    def __init__(self):
        self.tasks = self._load_tasks()

    def _load_tasks(self):
        data_path = os.path.join(os.path.dirname(__file__), 'data', 'tasks.json')
        with open(data_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def getlab(self, n):
        return self.tasks.get(str(n), "Задание не найдено")