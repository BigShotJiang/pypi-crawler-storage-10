# Lab Package

Пакет для доступа к заданиям лабораторных работ.

## Установка

```bash
pip install lab-package