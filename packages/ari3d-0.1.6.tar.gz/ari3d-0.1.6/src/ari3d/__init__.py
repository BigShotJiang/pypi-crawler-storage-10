"""Initialization file for the ari3d package."""
__version__ = "0.1.6"
__author__ = "Jan Philipp Albrecht, Jose Ricardo Assuncao Godinho"
