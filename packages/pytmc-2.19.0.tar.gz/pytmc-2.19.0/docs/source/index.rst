.. pytmc documentation master file, created by
   sphinx-quickstart on Thu Dec  7 12:54:14 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pytmc's documentation!
=================================
.. image:: https://travis-ci.org/pcdshub/pytmc.svg?branch=master
       :target: https://travis-ci.org/pcdshub/pytmc

Pytmc helps developers automatically generate ADS based Epics records files
from Beckhoff's TwinCAT3 projects.

Pytmc is developed with these `guidelines
<https://pcdshub.github.io/development.html>`_ in mind.

The source code is hosted on `github <https://github.com/pcdshub/pytmc>`_.

Issues and requests can be posted on the `github issue tracker
<https://github.com/pcdshub/pytmc/issues>`_. Use the ``bug`` tag for issues
with intended features and the ``enhancement`` tag can be used for feature
requests. The ``question`` tag will be treated like an 'enhancements' tag for
the documentation but regular questions can be posted there as well.

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   user_guide.rst
   source_code.rst
   release_notes.rst
