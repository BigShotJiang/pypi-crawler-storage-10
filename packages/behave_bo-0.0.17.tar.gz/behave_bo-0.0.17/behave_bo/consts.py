scenario_group_prefix = 'scenario_group_'
scenario_tag_cookie_key = 'scenario_tag'
