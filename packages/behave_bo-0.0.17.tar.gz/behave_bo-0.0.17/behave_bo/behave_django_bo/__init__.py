"""Behave BDD integration for Django"""

__version__ = '1.1.0'
__license__ = 'MIT License'
