import logging


tests_logger = logging.getLogger('console')
