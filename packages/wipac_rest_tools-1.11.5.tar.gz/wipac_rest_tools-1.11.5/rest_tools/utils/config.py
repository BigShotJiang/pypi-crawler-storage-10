# config.py
"""Module to provide configuration support."""

import wipac_dev_tools

from_environment = wipac_dev_tools.from_environment
