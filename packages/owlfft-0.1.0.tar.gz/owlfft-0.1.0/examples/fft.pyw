import owlfft
owlfft.main()
