from .core import CEvent

__all__ = ['CEvent']
__version__ = '1.0.0'
