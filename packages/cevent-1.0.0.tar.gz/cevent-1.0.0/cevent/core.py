class CEvent:
    """
        Class for event creating like a C# events.
    """
    def __init__(self):
        """
            Aks about func params types.
        """
        self._event_pool: list[callable] = []
        
    def __iadd__(self, elem: callable):
        """
            Subscribes callable element by adding to the pool.
        """
        if not callable(elem):
            raise TypeError(f'{elem} is not callable!')
        
        if elem not in self._event_pool:
            self._event_pool.append(elem)
        
        return self


    def __isub__(self, sub_elem: callable):
        """
            Unsubscribes callable element by removing from the pool.
        """
        if sub_elem in self._event_pool:
            self._event_pool.remove(sub_elem)

        return self

    def invoke(self, *args, **kwargs) -> list[tuple[callable, str]]:
        """
            Calls all callable items from the pool.

        Returns:
            List of errors
        """
        errors = []
        for f in self._event_pool:
            try:
                f(*args, **kwargs)
            except TypeError as e:
                errors.append((f, str(e)))
        if errors:
            print("[CEvent] Warning: some handlers failed to invoke:")
            for func, msg in errors:
                print(f" - {func}: {msg}")

        return errors

    def clear(self):
        """
            Clears all subscribers in the pool.
        """
        self._event_pool.clear()

    def __iter__(self):
        """
            Iterate over all subscribed handlers.
        """
        return iter(self._event_pool)
    
    def __repr__(self):
        names = [getattr(f, '__name__', repr(f)) for f in self._event_pool]
        return f'<CEvent subscribers={names}>'
