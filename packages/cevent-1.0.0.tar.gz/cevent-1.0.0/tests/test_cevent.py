import pytest
from cevent import CEvent


def test_subscribe_and_invoke(capsys):
    event = CEvent()

    def handler():
        print("called")

    event += handler
    event.invoke()

    captured = capsys.readouterr()
    assert "called" in captured.out


def test_multiple_handlers(capsys):
    event = CEvent()

    def a(): print("A")
    def b(): print("B")

    event += a
    event += b
    event.invoke()

    captured = capsys.readouterr()
    assert "A" in captured.out
    assert "B" in captured.out


def test_unsubscribe_handler(capsys):
    event = CEvent()

    def handler():
        print("called")

    event += handler
    event -= handler
    event.invoke()

    captured = capsys.readouterr()
    assert "called" not in captured.out


def test_clear_subscribers():
    event = CEvent()
    event += lambda: None
    event += lambda: None
    event.clear()
    assert list(event) == []


def test_no_duplicate_subscriptions():
    event = CEvent()

    def handler():
        pass

    event += handler
    event += handler  # duplicate should be ignored
    assert len(list(event)) == 1


def test_invoke_with_arguments(capsys):
    event = CEvent()

    def handler(x, y):
        print(x + y)

    event += handler
    event.invoke(2, 3)

    captured = capsys.readouterr()
    assert "5" in captured.out


def test_invoke_with_incompatible_signature(capsys):
    event = CEvent()

    def handler_no_args():
        print("no args")

    def handler_with_args(x):
        print(f"x={x}")

    event += handler_no_args
    event += handler_with_args

    event.invoke(42)

    captured = capsys.readouterr()
    # one handler should work, the other should warn
    assert "x=42" in captured.out
    assert "Warning: some handlers failed" in captured.out


def test_iter_and_repr():
    event = CEvent()

    def handler(): pass
    event += handler

    items = list(iter(event))
    assert handler in items
    assert "subscribers" in repr(event)
