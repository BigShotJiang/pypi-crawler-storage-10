import pwndck

pwndck.main()
