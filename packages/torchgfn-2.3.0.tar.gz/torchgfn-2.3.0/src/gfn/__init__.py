import importlib.metadata as met

__version__ = met.version("torchgfn")
