from ccxt.base.types import Entry


class ImplicitAPI:
    public_get_api_client_v1_currencies_prices_digital = publicGetApiClientV1CurrenciesPricesDigital = Entry('/api/client/v1/currencies/prices/digital', 'public', 'GET', {'cost': 1})
