#include <stdio.h>
int bin(int a[],int l,int h,int key){
    if(l>h) return 0;
    int m=(l+h)/2;
    if(a[m]==key) return 1;
    if(a[m]>key) return bin(a,l,m-1,key);
    return bin(a,m+1,h,key);
}
int main(){
    int a[10],n,i,key;
    scanf("%d",&n);
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&key);
    if(bin(a,0,n-1,key)) printf("Found"); else printf("Not Found");
}
