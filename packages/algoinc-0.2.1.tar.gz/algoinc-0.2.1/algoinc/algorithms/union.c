#include <stdio.h>
int parent[10];
int find(int x){ return parent[x]==x?x:(parent[x]=find(parent[x])); }
void uni(int x,int y){ parent[find(x)]=find(y); }
int main(){
    int n,i; scanf("%d",&n);
    for(i=0;i<n;i++) parent[i]=i;
    uni(0,1); uni(1,2);
    if(find(0)==find(2)) printf("Connected"); else printf("Not Connected");
}
