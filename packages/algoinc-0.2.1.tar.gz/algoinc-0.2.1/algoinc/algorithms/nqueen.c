#include <stdio.h>
int n,x[10];
int place(int k,int i){
    for(int j=1;j<k;j++)
        if(x[j]==i||abs(x[j]-i)==abs(j-k)) return 0;
    return 1;
}
void print(){
    for(int i=1;i<=n;i++){ for(int j=1;j<=n;j++) printf(x[i]==j?"Q ":"- "); printf("\n"); }
    printf("\n");
}
void nqueen(int k){
    for(int i=1;i<=n;i++)
        if(place(k,i)){
            x[k]=i;
            if(k==n) print(); else nqueen(k+1);
        }
}
int main(){
    scanf("%d",&n);
    nqueen(1);
}
