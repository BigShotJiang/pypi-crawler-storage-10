#include <stdio.h>
#include <string.h>
int main(){
    char t[100],p[20]; int i,j,lt,lp;
    scanf("%s%s",t,p);
    lt=strlen(t); lp=strlen(p);
    for(i=0;i<=lt-lp;i++){
        for(j=0;j<lp;j++) if(t[i+j]!=p[j]) break;
        if(j==lp){ printf("Found"); return 0; }
    }
    printf("Not Found");
}
