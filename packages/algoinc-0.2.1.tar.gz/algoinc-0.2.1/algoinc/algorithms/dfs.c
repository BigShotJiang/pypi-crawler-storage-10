#include <stdio.h>
int n,a[10][10],v[10];
void dfs(int s){
    int i; v[s]=1; printf("%d ",s);
    for(i=0;i<n;i++) if(a[s][i]&&!v[i]) dfs(i);
}
int main(){
    int i,j,s;
    scanf("%d",&n);
    for(i=0;i<n;i++) for(j=0;j<n;j++) scanf("%d",&a[i][j]);
    scanf("%d",&s);
    dfs(s);
}
