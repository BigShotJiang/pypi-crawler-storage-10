#include <stdio.h>

int find(int parent[], int i){
    while(parent[i]!=i) i=parent[i];
    return i;
}

void uni(int parent[], int i, int j){
    int a=find(parent,i);
    int b=find(parent,j);
    parent[a]=b;
}

int main(){
    int n,i,j,u,v,a,b,min,cost=0,e=0;
    int agraph[10][10],parent[10];
    scanf("%d",&n);
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            scanf("%d",&agraph[i][j]);
    for(i=0;i<n;i++) parent[i]=i;

    while(e<n-1){
        min=999;
        for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                if(agraph[i][j]<min && i!=j){
                    min=agraph[i][j];
                    a=u=i;
                    b=v=j;
                }
        u=find(parent,u);
        v=find(parent,v);
        if(u!=v){
            printf("%d-%d ",a,b);
            uni(parent,u,v);
            cost+=min;
            e++;
        }
        agraph[a][b]=agraph[b][a]=999;
    }
    printf("\nCost=%d",cost);
}
