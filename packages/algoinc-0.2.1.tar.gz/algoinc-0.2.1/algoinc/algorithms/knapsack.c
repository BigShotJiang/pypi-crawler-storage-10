#include <stdio.h>
int max(int a,int b){return a>b?a:b;}
int main(){
    int n,W,w[10],v[10],i,j,k[10][10];
    scanf("%d%d",&n,&W);
    for(i=1;i<=n;i++) scanf("%d%d",&w[i],&v[i]);
    for(i=0;i<=n;i++)
        for(j=0;j<=W;j++)
            if(i==0||j==0) k[i][j]=0;
            else if(w[i]<=j) k[i][j]=max(v[i]+k[i-1][j-w[i]],k[i-1][j]);
            else k[i][j]=k[i-1][j];
    printf("%d",k[n][W]);
}

