#include <stdio.h>
int main(){
    int n,i,j,a[10][10],v[10]={0},e=0,min,cost=0,x,y;
    scanf("%d",&n);
    for(i=0;i<n;i++) for(j=0;j<n;j++) scanf("%d",&a[i][j]);
    v[0]=1;
    while(e<n-1){
        min=999;
        for(i=0;i<n;i++)
            if(v[i])
                for(j=0;j<n;j++)
                    if(!v[j]&&a[i][j]<min){min=a[i][j];x=i;y=j;}
        printf("%d-%d ",x,y);
        v[y]=1; cost+=min; e++;
    }
    printf("\nCost=%d",cost);
}
