#include <stdio.h>
int search(int a[],int n,int key){
    if(n==0) return 0;
    if(a[n-1]==key) return 1;
    return search(a,n-1,key);
}
int main(){
    int a[10],n,i,key;
    scanf("%d",&n);
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    scanf("%d",&key);
    if(search(a,n,key)) printf("Found"); else printf("Not Found");
}
