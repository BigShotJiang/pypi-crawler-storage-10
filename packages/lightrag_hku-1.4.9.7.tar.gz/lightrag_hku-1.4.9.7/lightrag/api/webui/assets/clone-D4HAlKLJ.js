import{b as r}from"./_baseUniq-KaFXGb1T.js";var e=4;function a(o){return r(o,e)}export{a as c};
