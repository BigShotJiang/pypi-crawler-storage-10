# Demo Global Hotkeys for PySide6 Applications

An example application for the PySide6-GlobalHotkeys library https://github.com/develOseven/PySide6-GlobalHotkeys

Shows hotkey presses/releases in a text box.
Has a button to show the hotkey configuration user interface.

Install the `data/demo-PySide6-GlobalHotkeys.desktop` file for it to work:

```sh
cp data/demo-PySide6-GlobalHotkeys.desktop ~/.local/share/applications/
```
