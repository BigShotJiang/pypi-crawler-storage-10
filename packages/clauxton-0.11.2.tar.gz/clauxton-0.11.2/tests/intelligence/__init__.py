"""Tests for clauxton.intelligence module."""
