"""Security tests for Clauxton."""
