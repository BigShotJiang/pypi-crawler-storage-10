using System;

namespace テストアプリ
{
    public class ユーザー
    {
        private string 名前;

        public string 名前を取得()
        {
            return 名前;
        }
    }

    public class 😀Emoji
    {
        public void 😊メソッド()
        {
            // Unicode method
        }
    }
}
