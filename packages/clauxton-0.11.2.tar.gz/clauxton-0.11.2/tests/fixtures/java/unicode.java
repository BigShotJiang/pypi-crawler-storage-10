// Unicode names test file

/**
 * Japanese class name.
 */
public class 使用者 {
    private String name;

    public void こんにちは() {
        System.out.println("Hello");
    }
}
