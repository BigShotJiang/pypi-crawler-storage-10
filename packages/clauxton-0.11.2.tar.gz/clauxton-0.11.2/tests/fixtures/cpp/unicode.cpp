// Unicode names test file

/// Japanese function
void こんにちは() {
    // Hello
}

/// Unicode class
class 使用者 {
public:
    void greet() {
        // Greeting
    }
};
