// Empty C++ file for testing
