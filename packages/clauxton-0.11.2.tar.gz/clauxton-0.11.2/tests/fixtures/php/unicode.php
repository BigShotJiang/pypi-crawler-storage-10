<?php

namespace アプリ;

class ユーザー
{
    public function 名前取得(): string
    {
        return "テスト";
    }
}

function 計算(int $数値): int
{
    return $数値 * 2;
}
