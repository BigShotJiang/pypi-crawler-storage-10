"""MCP Server for Clauxton Knowledge Base."""

from clauxton.mcp.server import main, mcp

__all__ = ["mcp", "main"]
