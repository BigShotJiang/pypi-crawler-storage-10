"""Version information for Clauxton."""

__version__ = "0.11.2"
