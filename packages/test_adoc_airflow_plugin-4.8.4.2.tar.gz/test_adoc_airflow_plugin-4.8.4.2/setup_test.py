#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import find_namespace_packages, setup

with open("README.md", encoding="utf-8") as readme_file:
    readme = readme_file.read()

__version__ = "4.8.4.2"

requirements = [
    "test-acceldata-sdk>=4.8.4",
]

setup(
    name="test_adoc_airflow_plugin",
    version=__version__,
    description="Acceldata Airflow Listener Plugin",
    long_description=readme,
    long_description_content_type="text/markdown",
    author="acceldata",
    author_email="support@acceldata.io",  # optional but recommended
    packages=find_namespace_packages(include=["acceldata.*"]),
    include_package_data=True,
    install_requires=requirements,
    python_requires=">=3.8",
    zip_safe=False,
    keywords=["acceldata", "airflow", "plugin"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Framework :: Apache Airflow",
    ],
    entry_points={
        "airflow.plugins": [
            "AcceldataListenerPlugin = acceldata.airflow.plugin:AcceldataListenerPlugin",
        ],
    },
)
