# examples/example_usage.py
from fpsboost3d import PerformanceMonitor, Booster, TextureOptimizer

# Monitor 10s
m = PerformanceMonitor(interval=1.0)
m.run(duration=10)
print(m.summary())

# Boost: ustaw priorytet dla procesu gry (przykładowy PID)
b = Booster(dry_run=True)
# b.set_process_priority(12345, high=True)

# Optymalizacja tekstury
opt = TextureOptimizer(quality=80, max_size=2048)
# out = opt.optimize_image('path/to/texture.png')
