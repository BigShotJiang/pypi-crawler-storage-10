# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

__signature__ = "MGQCMG5Y2b3MSvbKO/6VdrrO5FhQc1ZrPYLjYbmKO4x7ZYzglByML1PtU3jEQfN7oigw7gIwVtblNTCgQ32RC+ujSetCIibbZOC8BVYk2oV99uV2GtsIwhtp+lqUhP4WtG83tRy4"
