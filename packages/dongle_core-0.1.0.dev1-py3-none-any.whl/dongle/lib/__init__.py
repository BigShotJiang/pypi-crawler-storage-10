# SPDX-FileCopyrightText: 2025 led-inc.eu
# SPDX-FileContributor: Michael Meinel <led02@me.com>
#
# SPDX-License-Identifier: Apache-2.0

__signature__ = "MGYCMQCFvJ+7DJNFo7/RRrDj5aEvuy78iXVmIV1MgynlkkA0EdWyiCSQ8k3xj6/aSc+HgSECMQDymIwKJNaewfOiXkR4OIkjab1AM8hxgzIjqJyfQZLzVqocjTlIbMzSpkrOvbh6Yzg="
