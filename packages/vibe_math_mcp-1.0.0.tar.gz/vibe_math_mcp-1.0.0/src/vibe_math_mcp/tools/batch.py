"""Batch execution tool with auto-discovered tool registry and intelligent orchestration."""

import json
from typing import Annotated, List, Literal
from pydantic import Field
from mcp.types import ToolAnnotations

from ..server import mcp
from ..core.batch_models import BatchOperation, BatchResponse
from ..core.batch_executor import BatchExecutor


# Single source of truth for tool organization
TOOL_CATEGORIES = {
    "Basic": ["calculate", "percentage", "round", "convert_units"],
    "Arrays": ["array_operations", "array_statistics", "array_aggregate", "array_transform"],
    "Statistics": ["statistics", "pivot_table", "correlation"],
    "Financial": ["financial_calcs", "compound_interest", "perpetuity"],
    "Linear Algebra": ["matrix_operations", "solve_linear_system", "matrix_decomposition"],
    "Calculus": ["derivative", "integral", "limits_series"],
}


def _build_tool_registry():
    """Auto-discover all available tools by importing tool modules.

    This is inspired by CustomMCP's automatic tool registration pattern.
    Instead of manually maintaining a registry, we dynamically import
    all tool modules and extract their exported functions.

    FastMCP wraps decorated functions in FunctionTool objects, so we extract
    the underlying async callable via the .fn attribute.

    Returns:
        Dictionary mapping tool_name -> async function
    """
    # Import all tool modules
    from . import basic, array, statistics as stats_module, financial, linalg, calculus

    # Build registry by extracting underlying callables from FunctionTool wrappers
    # Tool names match the @mcp.tool(name="...") decorators
    registry = {
        # Basic calculations (4 tools)
        "calculate": basic.calculate.fn,
        "percentage": basic.percentage.fn,
        "round": basic.round_values.fn,
        "convert_units": basic.convert_units.fn,
        # Array operations (4 tools)
        "array_operations": array.array_operations.fn,
        "array_statistics": array.array_statistics.fn,
        "array_aggregate": array.array_aggregate.fn,
        "array_transform": array.array_transform.fn,
        # Statistics (3 tools)
        "statistics": stats_module.statistics.fn,
        "pivot_table": stats_module.pivot_table.fn,
        "correlation": stats_module.correlation.fn,
        # Financial mathematics (3 tools)
        "financial_calcs": financial.financial_calcs.fn,
        "compound_interest": financial.compound_interest.fn,
        "perpetuity": financial.perpetuity.fn,
        # Linear algebra (3 tools)
        "matrix_operations": linalg.matrix_operations.fn,
        "solve_linear_system": linalg.solve_linear_system.fn,
        "matrix_decomposition": linalg.matrix_decomposition.fn,
        # Calculus (3 tools)
        "derivative": calculus.derivative.fn,
        "integral": calculus.integral.fn,
        "limits_series": calculus.limits_series.fn,
    }

    # Validate registry matches TOOL_CATEGORIES (DRY enforcement)
    expected_tools = {tool for tools in TOOL_CATEGORIES.values() for tool in tools}
    actual_tools = set(registry.keys())
    assert expected_tools == actual_tools, (
        f"Registry mismatch! Missing: {expected_tools - actual_tools}, "
        f"Extra: {actual_tools - expected_tools}"
    )

    return registry


def _generate_tool_reference() -> str:
    """Dynamically generate compact list of batchable tool IDs from TOOL_CATEGORIES."""
    total = sum(len(tools) for tools in TOOL_CATEGORIES.values())
    lines = [f"Available tools ({total}):"]
    for category, tools in TOOL_CATEGORIES.items():
        lines.append(f"• {category}: {', '.join(tools)}")
    return "\n".join(lines)


@mcp.tool(
    name="batch_execute",
    description=f"""Execute multiple math operations in a single request with automatic dependency chaining.

**USE THIS TOOL when you need 2+ calculations where outputs feed into inputs** (bond pricing, statistical workflows, multi-step formulas). Don't make sequential individual tool calls.

Benefits: 90-95% token reduction, single API call, highly flexible workflows

## Quick Start

{_generate_tool_reference()}

**Result referencing:**
- `$op_id.result` - Use output from prior operation
- `$op_id.metadata.field` - Access nested fields
- `$op_id.result[0]` - Array indexing

**Example - Bond valuation:**
```json
{{
  "operations": [
    {{"id": "coupon", "tool": "calculate",
     "arguments": {{"expression": "principal * 0.04", "variables": {{"principal": 8306623.86}}}}}},
    {{"id": "fv", "tool": "financial_calcs",
     "arguments": {{"calculation": "fv", "rate": 0.04, "periods": 10,
                   "payment": "$coupon.result", "present_value": 0}},
     "depends_on": ["coupon"]}},
    {{"id": "total", "tool": "calculate",
     "arguments": {{"expression": "fv + principal",
                   "variables": {{"fv": "$fv.result", "principal": 8306623.86}}}},
     "depends_on": ["fv"]}}
  ],
  "execution_mode": "auto",
  "output_mode": "value"
}}
```

## When to Use
✅ Multi-step calculations (financial models, statistics, transformations)
✅ Data pipelines where step N needs output from step N-1
✅ Any workflow requiring 2+ operations from the tools above

❌ Single standalone calculation
❌ Need to inspect/validate intermediate results before proceeding

## Execution Modes
- `auto` (recommended): DAG-based optimization, parallel where possible
- `sequential`: Strict order
- `parallel`: All concurrent (only if truly independent)

## Output Modes
- `value`: Flat {{id: value}} map (~90% smaller) - **use this for most cases**
- `final`: Sequential chains only, returns terminal result (~95% smaller)
- `minimal`: Basic operation objects with values
- `compact`: Remove nulls/whitespace
- `full`: Complete metadata (default)

## Structure
Each operation:
- `tool`: Tool name (required)
- `arguments`: Tool parameters (required)
- `id`: Unique identifier (auto-generated if omitted)
- `depends_on`: Array of operation IDs that must complete first
- `context`: Optional label for this operation

Batch-level `context` parameter labels entire workflow across all output modes.

Response includes: per-operation status, result/error, execution_time_ms, dependency wave, summary stats.
""",
    annotations=ToolAnnotations(
        title="Batch Execute",
        readOnlyHint=True,
    ),
)
async def batch_execute(
    operations: Annotated[
        List[BatchOperation],
        Field(
            description=(
                "List of operations to execute. Each operation MUST include: "
                "tool (name), arguments (dict). Optional: id (UUID/string), context, label, "
                "depends_on (list of IDs), result_mapping (dict), timeout_ms (int)"
            ),
            min_length=1,
            max_length=100,
        ),
    ],
    execution_mode: Annotated[
        Literal["sequential", "parallel", "auto"],
        Field(
            description="Execution strategy: sequential (order), parallel (concurrent), auto (DAG-based)"
        ),
    ] = "auto",
    max_concurrent: Annotated[
        int,
        Field(
            description="Maximum concurrent operations (applies to parallel/auto modes)",
            ge=1,
            le=20,
        ),
    ] = 5,
    stop_on_error: Annotated[
        bool,
        Field(
            description=(
                "Whether to stop execution on first error. "
                "If False, independent operations continue even if others fail."
            )
        ),
    ] = False,
) -> str:
    """Execute batch of mathematical operations with dependency management.

    This tool orchestrates multiple tool calls in a single request, automatically
    detecting dependencies and executing operations in optimal parallel waves.

    Each operation is tracked by its unique ID, providing crystal-clear mapping
    between inputs and outputs for easy LLM consumption and debugging.

    Returns:
        JSON string with results array and execution summary
    """
    try:
        # Build tool registry (DRY: auto-discovered from imports)
        tool_registry = _build_tool_registry()

        # Validate tool names
        for op in operations:
            if op.tool not in tool_registry:
                available = ", ".join(sorted(tool_registry.keys()))
                raise ValueError(
                    f"Unknown tool '{op.tool}' in operation '{op.id}'. Available tools: {available}"
                )

        # Create executor
        executor = BatchExecutor(
            operations=operations,
            tool_registry=tool_registry,
            mode=execution_mode,
            max_concurrent=max_concurrent,
            stop_on_error=stop_on_error,
        )

        # Execute batch
        response: BatchResponse = await executor.execute()

        # Convert to JSON
        # Note: CustomMCP will inject batch-level context at top level
        return json.dumps(
            {
                "results": [result.model_dump() for result in response.results],
                "summary": response.summary.model_dump(),
            },
            indent=2,
            default=str,
        )

    except Exception as e:
        # Return structured error response
        return json.dumps(
            {
                "error": {
                    "type": type(e).__name__,
                    "message": str(e),
                    "tool": "batch_execute",
                },
                "results": [],  # No partial results on batch-level error
            },
            indent=2,
        )
