def convert_to_date(df, cols:list):
    """Convert specified columns from a Pandas dataframe into datetime

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    cols : list
        List of columns to be converted

    Returns
    -------
    pd.DataFrame
        Pandas dataframe with converted columns
    """
    import pandas as pd

    for col in cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col])
    return df

# Datetime conversion
def convert_datetime_columns(df, datetime_cols, utc=True):
    """
    Converts specified columns in a DataFrame to datetime.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame whose columns you want to convert.
    datetime_cols : list
        List of column names to convert to datetime.
    utc : bool, default True
        Whether to convert to UTC timezone.

    Returns
    -------
    pd.DataFrame
        The same DataFrame with converted datetime columns.
    """
    for col in datetime_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], utc=utc, errors="coerce")
        else:
            print(f"Warning: '{col}' not found in DataFrame columns.")
    return df
