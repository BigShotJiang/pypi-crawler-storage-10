"""Weather symbols for meteogram."""
