"""PNG weather symbols for meteogram."""
