from __future__ import annotations

from typing import List, Dict
from dataclasses import asdict

# 框架依赖
from ..framework.command import Command
from ..framework.context import Context
from ..framework.command_registry import CommandRegistry

# 解析工具方法（仅保留元数据解析）
from ..common.word.docx_file_parse_util import (
    extract_docx_content_with_metadata,
)

# 为拼接多行标题引入 docx 读取
from docx import Document
import re


class DocxFileParseCommand(Command):
    """
    框架命令子类：按“标题-表格-脚注/段落”分块（仅元数据）。
    仅使用 `extract_docx_content_with_metadata` 进行解析。
    """

    def is_satisfied(self, context: Context) -> bool:
        return context.has_document()

    def execute(self, context: Context) -> Context:
        # 解析输入路径（支持文件或文件夹），仅处理 .docx
        paths = context.resolve_document_paths(patterns=["*.docx"])
        if not paths:
            context.add_error("No DOCX files resolved from context")
            return context

        def _clean_text(s: str) -> str:
            s = (s or "")
            s = s.replace("\u200b", "").replace("\xa0", " ")
            s = re.sub(r"\s+", " ", s).strip()
            return s

        def _assemble_title_and_extra_footnotes(docx_path: str, indices: List[int]):
            """
            组装多行标题：
            - 直接将 indices 对应的非空段落按顺序用换行连接；
            - 首次遇到空段落后停止收集（避免把正文/脚注拼入标题）。
            - 返回 (multi_line_title, extra_footnote_text, extra_footnote_indices)。
            """
            try:
                doc = Document(docx_path)
            except Exception:
                return "", "", []
            title_parts: List[str] = []
            started_title = False
            separated = False
            for i in sorted(set(int(x) for x in (indices or []))):
                if i < 0 or i >= len(doc.paragraphs):
                    continue
                para = doc.paragraphs[i]
                text = _clean_text(para.text)
                if not text:
                    if started_title:
                        separated = True
                    continue
                if separated:
                    # 空行之后的内容不再纳入标题（不做额外脚注处理，交由解析阶段）
                    continue
                title_parts.append(text)
                started_title = True

            title = "\n".join(title_parts).strip()
            # 这里不再识别“额外脚注”，解析阶段已有精细脚注归类
            return title, "", []

        # 将解析得到的 TableItem 列表转为结构化字典，并写入 Context.sections
        parsed_sections: List[Dict] = []
        for p in paths:
            sections = extract_docx_content_with_metadata(str(p))
            for sec in sections:
                d = asdict(sec)
                # 组装标题并识别额外脚注（标题下方、不同字体/字号或空行后的内容）
                full_title, extra_foot, extra_indices = _assemble_title_and_extra_footnotes(str(p), sec.title_indices)
                if full_title:
                    d["title"] = full_title
                if extra_foot:
                    prev = (d.get("footnote") or "").strip()
                    d["footnote"] = f"{prev}\n{extra_foot}".strip() if prev else extra_foot
                    d["footnote_indices"] = (d.get("footnote_indices") or []) + extra_indices
                    # 从标题索引中移除这些被判定为脚注的段落，避免拆分时复制到标题里
                    if d.get("title_indices"):
                        rm = set(extra_indices)
                        d["title_indices"] = [i for i in d["title_indices"] if i not in rm]
                d["source_file"] = str(p)
                parsed_sections.append(d)

        # 特殊规则：当同一文档中出现多个相同的 Table/Listing/Figure 标签时，
        # 认为其标题前存在“数字.”或“字母.”形式的枚举，按出现顺序为其添加 ".序号" 后缀。
        # 例如："Table 4" -> "Table 4.1"、"Table 4.2"。
        by_file: Dict[str, List[Dict]] = {}
        for d in parsed_sections:
            by_file.setdefault(d.get("source_file") or "", []).append(d)
        for src, items in by_file.items():
            # 统计重复标签
            counts: Dict[str, int] = {}
            for d in items:
                label = (d.get("label") or "").strip()
                if not label:
                    continue
                if re.match(r"(?i)^(table|listing|figure)\s+", label):
                    counts[label] = counts.get(label, 0) + 1
            # 仅对重复项追加序号
            seq: Dict[str, int] = {}
            for d in items:
                label = (d.get("label") or "").strip()
                if not label or counts.get(label, 0) <= 1:
                    continue
                n = seq.get(label, 0) + 1
                seq[label] = n
                new_label = f"{label}.{n}"
                d["label"] = new_label
                # 更新 section 使其与新标签一致（如 4 -> 4.1）
                parts = new_label.split(None, 1)
                d["section"] = (parts[1] if len(parts) == 2 else parts[0]).strip()
                # 将标题开头的“Table/Listing/Figure + 编号”替换为新标签，保持其余标题文本不变
                title_text = (d.get("title") or "")
                if title_text:
                    d["title"] = re.sub(r"(?i)^(table|listing|figure)\s+\S+", new_label, title_text)

        # 更新上下文
        context.doc_type = "docx"
        context.sections = parsed_sections
        context.processing_summary["title_table_footnote_partition"] = {
            "files_processed": len(paths),
            "sections_extracted": len(parsed_sections),
            "mode": "metadata_only",
        }
        return context


# 注册到命令注册表，便于 Pipeline 通过 YAML 创建
CommandRegistry.register("DocxFileParseCommand", DocxFileParseCommand)