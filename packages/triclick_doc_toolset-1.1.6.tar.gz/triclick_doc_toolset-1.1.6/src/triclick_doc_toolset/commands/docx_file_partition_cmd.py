from __future__ import annotations

from pathlib import Path
from typing import List, Dict
from dataclasses import asdict

# 框架依赖
from ..framework.command import Command
from ..framework.context import Context
from ..framework.command_registry import CommandRegistry

# 仅对接拆分工具方法
from ..common.word.docx_file_partition_util import (
    split_docx_into_tables_with_copy,
)
from ..common.models import TableItem
from docx import Document
import re


class DocxFilePartitionCommand(Command):
    """
    基于“标题-表格-脚注”元数据拆分 DOCX，保留原样式。
    只对接 `split_docx_into_tables_with_copy`，从 Context.sections 读取解析结果，
    处理完后覆盖写回 Context.sections。
    输出目录仅从 Context.metadata['output_dir'] 读取。
    """

    def is_satisfied(self, context: Context) -> bool:
        return context.has_document()

    def _clean_text(self, s: str) -> str:
        s = (s or "")
        s = s.replace("\u200b", "").replace("\xa0", " ")
        s = re.sub(r"\s+", " ", s).strip()
        return s

    def _para_font_signature(self, para) -> tuple:
        name = None
        size_pt = None
        try:
            for r in para.runs:
                if not (r.text or "").strip():
                    continue
                if r.font.name and not name:
                    name = r.font.name
                if r.font.size and not size_pt:
                    try:
                        size_pt = float(r.font.size.pt)
                    except Exception:
                        size_pt = None
                if name and size_pt:
                    break
            if not name:
                try:
                    name = para.style.font.name
                except Exception:
                    name = None
            if not size_pt:
                try:
                    st_size = para.style.font.size
                    size_pt = float(st_size.pt) if st_size else None
                except Exception:
                    size_pt = None
        except Exception:
            pass
        name = (name or "").strip().lower() or None
        return (name, size_pt)

    def _same_font(self, a: tuple, b: tuple) -> bool:
        if not a or not b:
            return False
        an, asz = a
        bn, bsz = b
        if an != bn:
            return False
        if asz is None or bsz is None:
            return False
        return abs(asz - bsz) <= 0.5

    def _assemble_full_title(self, docx_path: str, indices: List[int]) -> str:
        """兜底组装标题：按索引顺序拼接非空段落，遇空行后停止。"""
        try:
            doc = Document(docx_path)
        except Exception:
            return ""
        parts: List[str] = []
        started = False
        separated = False
        for i in sorted(set(int(x) for x in (indices or []))):
            if i < 0 or i >= len(doc.paragraphs):
                continue
            para = doc.paragraphs[i]
            text = self._clean_text(para.text)
            if not text:
                if started:
                    separated = True
                continue
            if separated:
                break
            parts.append(text)
            started = True
        return "\n".join(parts).strip()

    def _to_table_item(self, d: Dict, src_doc_path: str) -> TableItem:
        ti = TableItem(
            level=int(d.get("level", 0) or 0),
            table_index=d.get("table_index"),
            label=d.get("label"),
            section=d.get("section"),
            title=d.get("title"),
        )
        # 安全过滤 None
        ti.title_indices = [int(i) for i in (d.get("title_indices") or []) if isinstance(i, int)]
        ti.footnote = d.get("footnote")
        ti.footnote_indices = [int(i) for i in (d.get("footnote_indices") or []) if isinstance(i, int)]
        ti.local_path = d.get("local_path")
        # 兜底：若存在多行索引而 title 仍为单行，则组装完整标题
        if ti.title_indices and ("\n" not in (ti.title or "")) and len(ti.title_indices) > 1:
            full_title = self._assemble_full_title(src_doc_path, ti.title_indices)
            if full_title:
                ti.title = full_title
        return ti

    def execute(self, context: Context) -> Context:
        # 从 Context.sections 读取解析结果
        sections_in = context.sections or []
        if not sections_in:
            context.add_error("No parsed sections found in context; run partition first")
            return context

        # 按 source_file 分组
        grouped: Dict[str, List[TableItem]] = {}
        for d in sections_in:
            src = d.get("source_file")
            if not src:
                # 无来源则跳过
                continue
            grouped.setdefault(src, []).append(self._to_table_item(d, src))

        out_dirs: List[str] = []
        generated_files: List[str] = []
        sections_out: List[dict] = []

        for src_str, items in grouped.items():
            src = Path(src_str)
            base_out = context.metadata.get("output_dir")
            if not base_out:
                context.add_error("DocxFilePartitionCommand requires context.metadata['output_dir']")
                return context
            out_dir_str = str(base_out)

            updated_items = split_docx_into_tables_with_copy(str(src), items, output_dir=out_dir_str)
            out_dirs.append(out_dir_str)

            # 写入 Context.sections（结构化 dict），附带 source_file
            for sec in updated_items:
                d = asdict(sec)
                d["source_file"] = src_str
                sections_out.append(d)
                if d.get("local_path"):
                    generated_files.append(d["local_path"])

        context.doc_type = "docx"
        # 覆盖写回拆分后的分段到 Context
        context.sections = sections_out
        # 记录输出摘要
        tables_processed = sum(1 for d in sections_out if d.get("local_path"))
        context.processing_summary["title_table_footnote_split"] = {
            "files_processed": len(grouped),
            "tables_processed": tables_processed,
            "generated_files_count": len(generated_files),
            "output_dirs": out_dirs,
            "mode": "copy_elements",
        }
        # 附加生成文件（可用于后续输出或验证）
        context.generated_files.extend(generated_files)
        return context


# 注册到命令注册表，便于 Pipeline 通过 YAML 创建
CommandRegistry.register("DocxFilePartitionCommand", DocxFilePartitionCommand)