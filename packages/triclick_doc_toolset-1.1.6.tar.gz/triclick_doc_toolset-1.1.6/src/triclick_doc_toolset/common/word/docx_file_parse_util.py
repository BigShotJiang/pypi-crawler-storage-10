from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, cast, Dict
from docx import Document
from docx.document import Document as DocxDocument
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl
from docx.text.paragraph import Paragraph
from docx.table import Table

from ..models import TableItem
from ..utils.title_table_footnote_patterns_loader import (
    load_title_patterns, load_label_patterns, load_footnote_patterns
)

TITLE_PATTERNS: List[re.Pattern] = load_title_patterns()
LABEL_PATTERNS: List[re.Pattern] = load_label_patterns()
FOOTNOTE_PATTERNS: List[re.Pattern] = load_footnote_patterns()


def extract_title_label(text: str) -> Optional[str]:
    """
    从标题文本中提取简洁标签（例如："Table 2.3" 或 "Listing 1"）。
    仅返回前缀 + 编号，不包含后续描述。
    支持从配置的多个正则中按序匹配，取首个命中。
    """
    text = (text or "").strip()
    for pat in LABEL_PATTERNS:
        # 允许在任意位置提取（用于脚注中的 "same as table 2.2.1" 等）
        m = pat.search(text)
        if m:
            label = m.group(0).strip()
            label = re.sub(r'\s+', ' ', label)
            # 统一大小写（前缀首字母大写，大小写不敏感）
            label = re.sub(r'(?i)^(table|listing|figure)', lambda m: m.group(1).capitalize(), label)
            return label
    return None


def _extract_leading_enumerator(text: str) -> Optional[str]:
    """提取标题行首的枚举标记（支持“数字.”或“字母.”）。例如："1. Table 4 ..." -> "1"；"A. Table 4 ..." -> "A"。
    返回去掉句点的枚举字符；未命中返回 None。
    """
    s = (text or "").strip()
    m = re.match(r"^\s*([0-9]+|[A-Za-z])\.", s)
    if m:
        return m.group(1)
    return None


def _iter_block_items(doc: DocxDocument):
    """
    迭代文档正文的块级元素（段落与表格），保持与文档中出现的真实顺序。

    返回值:
    - 当遇到段落时，产出 ('paragraph', Paragraph)
    - 当遇到表格时，产出 ('table', Table)

    说明:
    - 直接遍历底层 body.iterchildren()，避免仅用 doc.paragraphs 或 doc.tables 导致顺序错乱。
    - 该生成器用于在标题、表格、脚注之间建立基于相邻关系的解析。
    """
    body = doc._element.body
    for child in body.iterchildren():
        if isinstance(child, CT_P):
            yield 'paragraph', Paragraph(child, doc)
        elif isinstance(child, CT_Tbl):
            yield 'table', Table(child, doc)


def _is_probable_footnote(text: str, style_name: str) -> bool:
    """判断段落是否很可能是脚注文本。
    规则：匹配 FOOTNOTE_PATTERNS；或以项目符号/破折号开头；排除 Heading。
    """
    if not text:
        return False
    if style_name and style_name.startswith('Heading'):
        return False
    if any(p.search(text) for p in FOOTNOTE_PATTERNS):
        return True
    if re.match(r"^[\-•·–]\s+", text):
        return True
    return False


def _get_paragraph_font_info(para) -> tuple:
    """获取段落的字体信息 (font_name, font_size_pt, is_bold, is_italic, style_name)"""
    font_name = None
    font_size = None
    is_bold = False
    is_italic = False
    style_name = None
    
    try:
        # 获取样式名称
        if para.style and para.style.name:
            style_name = para.style.name
        
        # 优先从runs获取字体信息
        for run in para.runs:
            if run.text.strip():  # 只考虑有内容的run
                if run.font.name and not font_name:
                    font_name = run.font.name.lower()
                if run.font.size and not font_size:
                    font_size = run.font.size.pt
                if run.font.bold:
                    is_bold = True
                if run.font.italic:
                    is_italic = True
                break
        
        # 如果runs没有信息，从样式获取
        if not font_name or not font_size:
            try:
                if not font_name and para.style.font.name:
                    font_name = para.style.font.name.lower()
                if not font_size and para.style.font.size:
                    font_size = para.style.font.size.pt
            except:
                pass
    except:
        pass
    
    return (font_name, font_size, is_bold, is_italic, style_name)


def _is_structure_separator(para, base_font_info, para_index=None, title_start_index=None) -> bool:
    """判断段落是否为结构分隔符（空行、字体变化、或基于位置的启发式规则）"""
    text = para.text.strip()
    
    # 空段落是明确的分隔符
    if not text:
        return True
    
    # 获取当前段落信息
    current_font_info = _get_paragraph_font_info(para)
    base_name, base_size, base_bold, base_italic, base_style = base_font_info
    curr_name, curr_size, curr_bold, curr_italic, curr_style = current_font_info
    
    # 字体信息变化检测
    font_changed = False
    
    # 字体名称不同
    if base_name and curr_name and base_name != curr_name:
        font_changed = True
    
    # 字体大小差异超过1pt
    if base_size and curr_size and abs(base_size - curr_size) > 1.0:
        font_changed = True
    
    # 粗体/斜体状态不同
    if base_bold != curr_bold or base_italic != curr_italic:
        font_changed = True
    
    # 样式名称不同
    if base_style and curr_style and base_style != curr_style:
        font_changed = True
    
    if font_changed:
        # 近标题容错：标题开始后前4行内，若不是典型脚注且文本不超长，则视为标题续行
        if para_index is not None and title_start_index is not None:
            if para_index - title_start_index <= 4:
                if not _is_probable_footnote(text, curr_style) and len(text) <= 150:
                    return False
        return True
    
    # 当字体信息都为空时，使用启发式规则
    if not any([base_name, base_size, curr_name, curr_size]):
        # 基于段落位置的启发式判断
        if para_index is not None and title_start_index is not None:
            # 如果当前段落距离标题开始位置超过4行，很可能是脚注
            if para_index - title_start_index > 4:
                return True
        
        # 基于内容的启发式判断
        # 如果段落包含典型的脚注标识符
        if _is_probable_footnote(text, curr_style):
            return True
        
        # 如果段落很长（超过100字符），很可能是脚注
        if len(text) > 100:
            return True
    
    return False


def extract_docx_content_with_metadata(docx_path: str) -> List[TableItem]:
    """
    基于文档结构模式解析文档：
    模式1: title + table + footnote
    模式2: title + footnote (无表格)
    
    使用结构化方法而非枚举式匹配：
    1. 识别标题段落
    2. 收集连续的同字体标题段落
    3. 遇到表格则标记为模式1，否则为模式2
    4. 表格后或标题后遇到字体变化/空行则开始收集脚注
    """
    doc = Document(docx_path)
    content: List[TableItem] = []
    # 记录同一文档内、按列表样式编号出现的同名标签的序号（.1/.2/...）
    label_seq_counter: Dict[str, int] = {}

    # 建立索引映射
    para_index_map = {para._p: idx for idx, para in enumerate(doc.paragraphs)}
    tbl_index_map = {tbl._tbl: idx for idx, tbl in enumerate(doc.tables)}

    current_section: Optional[TableItem] = None
    title_font_info = None  # 标题的字体信息
    title_start_index = None  # 标题开始的段落索引
    section_state = "seeking_title"  # seeking_title, collecting_title, after_table, collecting_footnote

    def compute_title_level(label: Optional[str]) -> int:
        if not label:
            return 0
        parts = label.split(None, 1)
        number_part = parts[1] if len(parts) == 2 else parts[0]
        return number_part.count('.')

    for kind, item in _iter_block_items(doc):
        if kind == 'paragraph':
            par = cast(Paragraph, item)
            text = par.text.strip()
            
            # 跳过空段落，但在收集标题时可能作为分隔符
            if not text:
                if section_state == "collecting_title" and current_section:
                    section_state = "collecting_footnote"
                continue
                
            p_idx = para_index_map.get(par._p)
            if p_idx is None:
                continue

            # 检查是否为新标题：支持行首枚举（数字./字母.）后接 Table/Listing/Figure
            is_title = any(pat.match(text) for pat in TITLE_PATTERNS)
            if not is_title:
                enum = _extract_leading_enumerator(text)
                if enum:
                    stripped = re.sub(r"^\s*([0-9]+|[A-Za-z])\.?\s*", "", text)
                    is_title = any(pat.match(stripped) for pat in TITLE_PATTERNS)
            
            if is_title:
                # 保存前一个section
                if current_section:
                    content.append(current_section)
                
                # 创建新section
                label = extract_title_label(text)
                # 若行首存在“数字.”或“字母.”，并且标签为 Table，则将枚举并入 label：Table 4 -> Table 4.X
                enum = _extract_leading_enumerator(text)
                if enum and label and re.match(r"(?i)^table\s+", label):
                    label = f"{label}.{enum}"
                # 若段落是列表编号样式（Word 的 List Number/字母编号），而枚举不在纯文本中，则为重复 label 添加递增序号后缀
                try:
                    pPr = par._p.pPr  # type: ignore[attr-defined]
                    has_num = bool(pPr is not None and getattr(pPr, 'numPr', None) is not None)
                except Exception:
                    has_num = False
                style_name = (par.style.name or "") if par.style is not None else ""
                is_list_style = ('List' in style_name) or has_num
                if label and re.match(r"(?i)^table\s+", label) and is_list_style and not enum:
                    cnt = label_seq_counter.get(label, 0) + 1
                    label_seq_counter[label] = cnt
                    label = f"{label}.{cnt}"
                section = None
                if label:
                    parts = label.split(None, 1)
                    section = (parts[1] if len(parts) == 2 else parts[0]).strip()
                
                current_section = TableItem(
                    label=label,
                    section=section,
                    title=text,
                    level=compute_title_level(label),
                    title_indices=[p_idx]
                )
                
                # 记录标题字体信息和开始位置
                title_font_info = _get_paragraph_font_info(par)
                title_start_index = p_idx
                section_state = "collecting_title"
                continue

            # 处理非标题段落
            if current_section:
                if section_state == "collecting_title":
                    # 检查是否应该继续收集标题还是转为脚注
                    if title_font_info and not _is_structure_separator(par, title_font_info, p_idx, title_start_index):
                        # 继续收集标题
                        current_section.title_indices.append(p_idx)
                        # 更新标题文本，将新行追加到现有标题
                        if current_section.title and text:
                            current_section.title += " " + text
                        elif text:
                            current_section.title = text
                    else:
                        # 转为脚注收集
                        section_state = "collecting_footnote"
                        current_section.add_footnote_index(p_idx)
                        current_section.append_footnote_text(text)
                
                elif section_state == "after_table":
                    # 表格后的段落都是脚注
                    current_section.add_footnote_index(p_idx)
                    current_section.append_footnote_text(text)
                
                elif section_state == "collecting_footnote":
                    # 继续收集脚注
                    current_section.add_footnote_index(p_idx)
                    current_section.append_footnote_text(text)

        elif kind == 'table':
            tbl = cast(Table, item)
            tbl_idx = tbl_index_map.get(tbl._tbl)
            if tbl_idx is None:
                continue
                
            if current_section:
                current_section.set_table(tbl_idx)
                section_state = "after_table"  # 表格后的内容都是脚注

    # 保存最后一个section
    if current_section:
        content.append(current_section)

    return content