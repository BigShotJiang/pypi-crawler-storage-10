######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.408220                                                            #
######################################################################################################

from __future__ import annotations


from ......_vendor import click as metaflow_click
from ......_vendor import click as click

