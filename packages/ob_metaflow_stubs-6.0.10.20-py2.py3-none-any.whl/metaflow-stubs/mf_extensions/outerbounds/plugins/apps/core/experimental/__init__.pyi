######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.409771                                                            #
######################################################################################################

from __future__ import annotations



TYPE_CHECKING: bool

DEFAULT_BRANCH: str

def capsule_input_overrides(app_config: "AppConfig", capsule_input: dict):
    ...

