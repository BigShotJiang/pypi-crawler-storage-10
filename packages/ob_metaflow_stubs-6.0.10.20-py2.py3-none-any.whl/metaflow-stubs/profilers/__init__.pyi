######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.334993                                                            #
######################################################################################################

from __future__ import annotations


from ..mf_extensions.outerbounds.profilers import gpu as gpu
from ..mf_extensions.outerbounds.profilers.gpu import gpu_profile as gpu_profile

