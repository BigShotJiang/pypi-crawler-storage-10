######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.391724                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

