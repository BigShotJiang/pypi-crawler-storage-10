######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.393332                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

