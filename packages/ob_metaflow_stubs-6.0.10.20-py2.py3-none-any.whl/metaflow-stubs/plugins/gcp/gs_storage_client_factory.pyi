######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.424906                                                            #
######################################################################################################

from __future__ import annotations



class GcpDefaultClientProvider(object, metaclass=type):
    @staticmethod
    def get_gs_storage_client(*args, **kwargs):
        ...
    @staticmethod
    def get_credentials(scopes, *args, **kwargs):
        ...
    ...

cached_provider_class: None

def get_gs_storage_client():
    ...

def get_credentials(scopes, *args, **kwargs):
    ...

