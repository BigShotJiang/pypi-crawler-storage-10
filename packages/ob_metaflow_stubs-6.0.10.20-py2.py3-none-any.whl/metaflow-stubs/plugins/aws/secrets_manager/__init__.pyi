######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.418804                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

