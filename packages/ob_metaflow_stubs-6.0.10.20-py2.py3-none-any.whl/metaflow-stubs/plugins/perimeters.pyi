######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.3.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-10-28T11:23:52.334763                                                            #
######################################################################################################

from __future__ import annotations

import typing

from ..exception import MetaflowException as MetaflowException

CURRENT_PERIMETER_KEY: str

CURRENT_PERIMETER_URL: str

CURRENT_PERIMETER_URL_LEGACY_KEY: str

def get_perimeter_config_url_if_set_in_ob_config() -> typing.Optional[str]:
    ...

