"""Code analysis and generation functions"""
