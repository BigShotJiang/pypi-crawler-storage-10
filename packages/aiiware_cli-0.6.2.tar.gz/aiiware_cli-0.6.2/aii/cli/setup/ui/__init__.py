"""
UI components for setup wizard.
"""

from aii.cli.setup.ui.browser import BrowserHelper

__all__ = ["BrowserHelper"]
