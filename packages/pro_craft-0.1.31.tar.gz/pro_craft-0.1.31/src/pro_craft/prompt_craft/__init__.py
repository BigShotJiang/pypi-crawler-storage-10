from .async_ import AsyncIntel
from .sync import Intel
from .new import IntelNew