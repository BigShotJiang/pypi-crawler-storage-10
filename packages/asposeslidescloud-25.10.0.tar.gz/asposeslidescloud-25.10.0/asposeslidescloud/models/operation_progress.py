# coding: utf-8

# -----------------------------------------------------------------------------------
# <copyright company="Aspose">
#   Copyright (c) 2018 Aspose.Slides for Cloud
# </copyright>
# <summary>
#   Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in all
#  copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#  SOFTWARE.
# </summary>
# -----------------------------------------------------------------------------------

import pprint
import re  # noqa: F401

import six


class OperationProgress(object):


    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'description': 'str',
        'step_index': 'int',
        'step_count': 'int'
    }

    attribute_map = {
        'description': 'description',
        'step_index': 'stepIndex',
        'step_count': 'stepCount'
    }

    type_determiners = {
    }

    def __init__(self, description=None, step_index=None, step_count=None):  # noqa: E501
        """OperationProgress - a model defined in Swagger"""  # noqa: E501

        self._description = None
        self._step_index = None
        self._step_count = None

        if description is not None:
            self.description = description
        self.step_index = step_index
        self.step_count = step_count

    @property
    def description(self):
        """Gets the description of this OperationProgress.  # noqa: E501

        Description.  # noqa: E501

        :return: The description of this OperationProgress.  # noqa: E501
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this OperationProgress.

        Description.  # noqa: E501

        :param description: The description of this OperationProgress.  # noqa: E501
        :type: str
        """
        self._description = description

    @property
    def step_index(self):
        """Gets the step_index of this OperationProgress.  # noqa: E501

        Current Step Index.  # noqa: E501

        :return: The step_index of this OperationProgress.  # noqa: E501
        :rtype: int
        """
        return self._step_index

    @step_index.setter
    def step_index(self, step_index):
        """Sets the step_index of this OperationProgress.

        Current Step Index.  # noqa: E501

        :param step_index: The step_index of this OperationProgress.  # noqa: E501
        :type: int
        """
        self._step_index = step_index

    @property
    def step_count(self):
        """Gets the step_count of this OperationProgress.  # noqa: E501

        Current Step Index.  # noqa: E501

        :return: The step_count of this OperationProgress.  # noqa: E501
        :rtype: int
        """
        return self._step_count

    @step_count.setter
    def step_count(self, step_count):
        """Sets the step_count of this OperationProgress.

        Current Step Index.  # noqa: E501

        :param step_count: The step_count of this OperationProgress.  # noqa: E501
        :type: int
        """
        self._step_count = step_count

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, OperationProgress):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
