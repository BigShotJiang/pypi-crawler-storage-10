# Gradient Leakage in Production Federated Learning

Research on gradient leakage attack and defense using the Plato framework.

Refer to the [Plato documentation](https://platodocs.netlify.app/examples/algorithms/14.%20gradient%20leakage%20attacks%20and%20defences/) for more details.
