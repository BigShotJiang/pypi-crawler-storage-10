from .config_module import ConfigModule

__all__ = ["ConfigModule"]
