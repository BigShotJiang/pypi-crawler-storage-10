from clean_frames import CleanFrame

cleaner = CleanFrame(device='mps')

# Extract embeddings using Swin Transformer

# Run the cleaning pipeline
cleaner.cleanframes(
    path="/Users/abdallhal-mutiri/Desktop/ComputerVison/genAI/Hajjv2/train/images",
    embeddings=True)