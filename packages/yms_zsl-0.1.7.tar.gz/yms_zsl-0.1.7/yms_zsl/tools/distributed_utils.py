import logging
from collections import defaultdict, deque
import datetime
import pickle
import time
import errno
import os

import torch
import torch.distributed as dist

from yms_zsl.tools.tools import log_or_print

logger = logging.getLogger('yms')

class SmoothedValue(object):
    """Track a series of values and provide access to smoothed values over a
    window or the global series average.
    """
    def __init__(self, window_size=20, fmt=None):
        if fmt is None:
            fmt = "{value:.4f} ({global_avg:.4f})"
        self.deque = deque(maxlen=window_size)  # deque简单理解成加强版list
        self.total = 0.0
        self.count = 0
        self.fmt = fmt

    def update(self, value, n=1):
        self.deque.append(value)
        self.count += n
        self.total += value * n

    def synchronize_between_processes(self):
        """
        Warning: does not synchronize the deque!
        """
        if not is_dist_avail_and_initialized():
            return
        t = torch.tensor([self.count, self.total], dtype=torch.float64, device="cuda")
        dist.barrier()
        dist.all_reduce(t)
        t = t.tolist()
        self.count = int(t[0])
        self.total = t[1]

    @property
    def median(self):  # @property 是装饰器，这里可简单理解为增加median属性(只读)
        d = torch.tensor(list(self.deque))
        return d.median().item()

    @property
    def avg(self):
        d = torch.tensor(list(self.deque), dtype=torch.float32)
        return d.mean().item()

    @property
    def global_avg(self):
        return self.total / self.count

    @property
    def max(self):
        return max(self.deque)

    @property
    def value(self):
        return self.deque[-1]

    def __str__(self):
        return self.fmt.format(
            median=self.median,
            avg=self.avg,
            global_avg=self.global_avg,
            max=self.max,
            value=self.value)


def all_gather(data):
    """
    Run all_gather on arbitrary picklable data (not necessarily tensors)
    Args:
        data: any picklable object
    Returns:
        list[data]: list of data gathered from each rank
    """
    world_size = get_world_size()
    if world_size == 1:
        return [data]

    # serialized to a Tensor
    buffer = pickle.dumps(data)
    storage = torch.ByteStorage.from_buffer(buffer)
    tensor = torch.ByteTensor(storage).to("cuda")

    # obtain Tensor size of each rank
    local_size = torch.tensor([tensor.numel()], device="cuda")
    size_list = [torch.tensor([0], device="cuda") for _ in range(world_size)]
    dist.all_gather(size_list, local_size)
    size_list = [int(size.item()) for size in size_list]
    max_size = max(size_list)

    # receiving Tensor from all ranks
    # we pad the tensor because torch all_gather does not support
    # gathering tensors of different shapes
    tensor_list = []
    for _ in size_list:
        tensor_list.append(torch.empty((max_size,), dtype=torch.uint8, device="cuda"))
    if local_size != max_size:
        padding = torch.empty(size=(max_size - local_size,), dtype=torch.uint8, device="cuda")
        tensor = torch.cat((tensor, padding), dim=0)
    dist.all_gather(tensor_list, tensor)

    data_list = []
    for size, tensor in zip(size_list, tensor_list):
        buffer = tensor.cpu().numpy().tobytes()[:size]
        data_list.append(pickle.loads(buffer))

    return data_list


def reduce_dict(input_dict, average=True):
    """
    Args:
        input_dict (dict): all the values will be reduced
        average (bool): whether to do average or sum
    Reduce the values in the dictionary from all processes so that all processes
    have the averaged results. Returns a dict with the same fields as
    input_dict, after reduction.
    """
    world_size = get_world_size()
    if world_size < 2:  # 单GPU的情况
        return input_dict
    with torch.no_grad():  # 多GPU的情况
        names = []
        values = []
        # sort the keys so that they are consistent across processes
        for k in sorted(input_dict.keys()):
            names.append(k)
            values.append(input_dict[k])
        values = torch.stack(values, dim=0)
        dist.all_reduce(values)
        if average:
            values /= world_size

        reduced_dict = {k: v for k, v in zip(names, values)}
        return reduced_dict


class MetricLogger(object):
    def __init__(self, delimiter="\t"):
        self.meters = defaultdict(SmoothedValue)
        self.delimiter = delimiter

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if isinstance(v, torch.Tensor):
                v = v.item()
            assert isinstance(v, (float, int))
            self.meters[k].update(v)

    def __getattr__(self, attr):
        if attr in self.meters:
            return self.meters[attr]
        if attr in self.__dict__:
            return self.__dict__[attr]
        raise AttributeError("'{}' object has no attribute '{}'".format(
            type(self).__name__, attr))

    def __str__(self):
        loss_str = []
        for name, meter in self.meters.items():
            loss_str.append(
                "{}: {}".format(name, str(meter))
            )
        return self.delimiter.join(loss_str)

    def synchronize_between_processes(self):
        for meter in self.meters.values():
            meter.synchronize_between_processes()

    def add_meter(self, name, meter):
        self.meters[name] = meter

    def log_every(self, iterable, print_freq, header=None):
        i = 0
        if not header:
            header = ""
        start_time = time.time()
        end = time.time()
        iter_time = SmoothedValue(fmt='{avg:.4f}')  # 总迭代时间（数据加载+模型计算）
        data_time = SmoothedValue(fmt='{avg:.4f}')  # 数据加载时间
        model_time = SmoothedValue(fmt='{avg:.4f}')  # 新增：模型计算时间（总迭代时间 - 数据加载时间）
        space_fmt = ":" + str(len(str(len(iterable)))) + "d"

        # 更新日志格式，增加模型时间和占比
        if torch.cuda.is_available():
            log_msg = self.delimiter.join([header,
                                           '[{0' + space_fmt + '}/{1}]',
                                           'eta: {eta}',
                                           '{meters}',
                                           'time: {time}',  # 总迭代时间
                                           'data: {data}',  # 数据加载时间
                                           'model: {model}',  # 新增：模型计算时间
                                           'model_ratio: {model_ratio:.1f}%',  # 新增：模型时间占比
                                           'max mem: {memory:.0f} MB'])
        else:
            log_msg = self.delimiter.join([header,
                                           '[{0' + space_fmt + '}/{1}]',
                                           'eta: {eta}',
                                           '{meters}',
                                           'time: {time}',
                                           'data: {data}',
                                           'model: {model}',
                                           'model_ratio: {model_ratio:.1f}%'])

        MB = 1024.0 * 1024.0
        for obj in iterable:
            # 计算数据加载时间（当前迭代中，从上次结束到数据准备完成的时间）
            delta_data = time.time() - end
            data_time.update(delta_data)

            yield obj  # 此处yield的obj会被用于模型计算，因此yield之后的时间主要是模型计算

            # 计算总迭代时间（从上次结束到本次迭代完成的时间）
            delta_iter = time.time() - end
            iter_time.update(delta_iter)

            # 计算模型计算时间（总迭代时间 - 数据加载时间）
            delta_model = delta_iter - delta_data
            model_time.update(delta_model)

            # 打印日志（按print_freq频率）
            if i % print_freq == 0 or i == len(iterable) - 1:
                eta_second = iter_time.global_avg * (len(iterable) - i)
                eta_string = str(datetime.timedelta(seconds=eta_second))

                # 计算模型时间占比（避免除零错误）
                if delta_iter == 0:
                    model_ratio = 0.0
                else:
                    model_ratio = (delta_model / delta_iter) * 100

                if torch.cuda.is_available():
                    msg = log_msg.format(i, len(iterable),
                                         eta=eta_string,
                                         meters=str(self),
                                         time=str(iter_time),
                                         data=str(data_time),
                                         model=str(model_time),  # 模型计算时间（平滑后）
                                         model_ratio=model_ratio,  # 本次迭代的模型时间占比
                                         memory=torch.cuda.max_memory_allocated() / MB)
                    # logger.info()
                else:
                    msg = log_msg.format(i, len(iterable),
                                         eta=eta_string,
                                         meters=str(self),
                                         time=str(iter_time),
                                         data=str(data_time),
                                         model=str(model_time),
                                         model_ratio=model_ratio)
                    # logger.info()
                log_or_print(msg)
            i += 1
            end = time.time()

        # 最终总时间统计（保持不变）
        total_time = time.time() - start_time
        total_time_str = str(datetime.timedelta(seconds=int(total_time)))
        msgs = '{} Total time: {} ({:.4f} s / it)'.format(header,
                                                         total_time_str,
                                                         total_time / len(iterable))
        log_or_print(msgs)
        # logger.info()
    # def log_every(self, iterable, print_freq, header=None):
    #     i = 0
    #     if not header:
    #         header = ""
    #     start_time = time.time()
    #     end = time.time()
    #     iter_time = SmoothedValue(fmt='{avg:.4f}')
    #     data_time = SmoothedValue(fmt='{avg:.4f}')
    #     space_fmt = ":" + str(len(str(len(iterable)))) + "d"
    #     if torch.cuda.is_available():
    #         log_msg = self.delimiter.join([header,
    #                                        '[{0' + space_fmt + '}/{1}]',
    #                                        'eta: {eta}',
    #                                        '{meters}',
    #                                        'time: {time}',
    #                                        'data: {data}',
    #                                        'max mem: {memory:.0f} MB'])
    #     else:
    #         log_msg = self.delimiter.join([header,
    #                                        '[{0' + space_fmt + '}/{1}]',
    #                                        'eta: {eta}',
    #                                        '{meters}',
    #                                        'time: {time}',
    #                                        'data: {data}'])
    #     MB = 1024.0 * 1024.0
    #     for obj in iterable:
    #         data_time.update(time.time() - end)
    #         yield obj
    #         iter_time.update(time.time() - end)
    #         if i % print_freq == 0 or i == len(iterable) - 1:
    #             eta_second = iter_time.global_avg * (len(iterable) - i)
    #             eta_string = str(datetime.timedelta(seconds=eta_second))
    #             if torch.cuda.is_available():
    #                 print(log_msg.format(i, len(iterable),
    #                                      eta=eta_string,
    #                                      meters=str(self),
    #                                      time=str(iter_time),
    #                                      data=str(data_time),
    #                                      memory=torch.cuda.max_memory_allocated() / MB))
    #             else:
    #                 print(log_msg.format(i, len(iterable),
    #                                      eta=eta_string,
    #                                      meters=str(self),
    #                                      time=str(iter_time),
    #                                      data=str(data_time)))
    #         i += 1
    #         end = time.time()
    #     total_time = time.time() - start_time
    #     total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    #     print('{} Total time: {} ({:.4f} s / it)'.format(header,
    #                                                      total_time_str,
    #
    #                                                      total_time / len(iterable)))


def warmup_lr_scheduler(optimizer, warmup_iters, warmup_factor):

    def f(x):
        """根据step数返回一个学习率倍率因子"""
        if x >= warmup_iters:  # 当迭代数大于给定的warmup_iters时，倍率因子为1
            return 1
        alpha = float(x) / warmup_iters
        # 迭代过程中倍率因子从warmup_factor -> 1
        return warmup_factor * (1 - alpha) + alpha

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=f)


def mkdir(path):
    try:
        os.makedirs(path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


def setup_for_distributed(is_master):
    """
    This function disables when not in master process
    """
    import builtins as __builtin__
    builtin_print = __builtin__.print

    def print(*args, **kwargs):
        force = kwargs.pop('force', False)
        if is_master or force:
            builtin_print(*args, **kwargs)

    __builtin__.print = print


def is_dist_avail_and_initialized():
    """检查是否支持分布式环境"""
    if not dist.is_available():
        return False
    if not dist.is_initialized():
        return False
    return True


def get_world_size():
    if not is_dist_avail_and_initialized():
        return 1
    return dist.get_world_size()


def get_rank():
    if not is_dist_avail_and_initialized():
        return 0
    return dist.get_rank()


def is_main_process():
    return get_rank() == 0


def save_on_master(*args, **kwargs):
    if is_main_process():
        torch.save(*args, **kwargs)


def init_distributed_mode(args):
    if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
        args.rank = int(os.environ["RANK"])
        args.world_size = int(os.environ['WORLD_SIZE'])
        args.gpu = int(os.environ['LOCAL_RANK'])
    elif 'SLURM_PROCID' in os.environ:
        args.rank = int(os.environ['SLURM_PROCID'])
        args.gpu = args.rank % torch.cuda.device_count()
    else:
        print('Not using distributed mode')
        args.distributed = False
        return

    args.distributed = True

    torch.cuda.set_device(args.gpu)
    args.dist_backend = 'nccl'
    print('| distributed init (rank {}): {}'.format(
        args.rank, args.dist_url), flush=True)
    torch.distributed.init_process_group(backend=args.dist_backend, init_method=args.dist_url,
                                         world_size=args.world_size, rank=args.rank)
    # 使用torch1.9或以上时建议加上device_ids=[args.rank]
    torch.distributed.barrier()
    setup_for_distributed(args.rank == 0)

