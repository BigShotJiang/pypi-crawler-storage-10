# inspectML

inspectML is a Python library designed to help ML engineers and researchers evaluate, monitor, and visualize machine learning models effortlessly.

## Features
- Regression and classification evaluation
- Generative model metrics (FID, Inception Score)
- Drift detection and monitoring
- GPU and CPU utilization tracking
- Visualization tools for confusion matrix, learning curves, etc.
- Simple integration with existing ML pipelines

## Installation
```bash
pip install inspectML

## Usage Example

from inspectML.core.evaluation import regression, classification
from inspectML.visualization import plots

# Evaluate a regression model
regression.evaluate(y_true, y_pred)

# Visualize performance
plots.learning_curve(history)
