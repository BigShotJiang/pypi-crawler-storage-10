"""
FastAPI wrapper for Spanish Vehicle Tax Valuation MCP Server.

This module provides an ASGI application wrapper around the MCP server
for deployment to Azure App Service. It exposes the MCP server via
HTTP/SSE (Server-Sent Events) at the /sse endpoint.

Usage for Azure deployment:
    gunicorn -w 2 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 src.app:app

Usage for local testing:
    uvicorn src.app:app --reload --port 8000
"""

import os
from fastapi import FastAPI, Request
from fastapi.responses import Response
from contextlib import asynccontextmanager
from starlette.routing import Mount

from .config import settings
from .server import server as mcp_server

# Import SSE transport from MCP
from mcp.server.sse import SseServerTransport


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifespan events."""
    # Startup
    print("Starting Spanish Vehicle Tax Valuation MCP Server", flush=True)
    print(f"API Base URL: {settings.api_base_url}", flush=True)
    print("SSE Endpoint: /sse", flush=True)
    yield
    # Shutdown
    print("Shutting down MCP Server", flush=True)


# Create FastAPI application
app = FastAPI(
    title="Spanish Vehicle Tax Valuation MCP",
    description="MCP server for Spanish vehicle tax calculations via HTTP/SSE",
    version="0.1.2",
    lifespan=lifespan
)


@app.get("/")
async def root():
    """Root endpoint with service information."""
    return {
        "service": "Spanish Vehicle Tax Valuation MCP Server",
        "version": "0.1.2",
        "mcp_endpoint": "/sse",
        "protocol": "MCP over HTTP/SSE",
        "status": "running",
        "api_base": settings.api_base_url,
        "tools": [
            "get_vehicle_categories",
            "search_vehicle_models",
            "get_vehicle_model_details",
            "get_vehicle_prices",
            "get_depreciation_rates",
            "calculate_vehicle_tax_valuation",
            "get_stored_valuations",
            "check_api_health"
        ]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint for Azure App Service."""
    return {
        "status": "healthy",
        "service": "spanish-vehicle-tax-mcp",
        "mcp_protocol": "sse",
        "api_connected": True
    }


# Initialize SSE transport for MCP
sse_transport = SseServerTransport("/messages/")


@app.get("/sse")
async def handle_sse(request: Request):
    """
    MCP Server-Sent Events endpoint.
    
    This endpoint provides MCP protocol access via HTTP/SSE transport.
    Clients connect here to interact with the MCP tools.
    """
    async with sse_transport.connect_sse(
        request.scope, request.receive, request._send
    ) as streams:
        await mcp_server._mcp_server.run(
            streams[0],
            streams[1],
            mcp_server._mcp_server.create_initialization_options(),
        )
    return Response()


# Mount the SSE post message handler
app.mount("/messages/", sse_transport.handle_post_message)


@app.get("/tools")
async def list_tools():
    """List all available MCP tools."""
    return {
        "tools": [
            {
                "name": "get_vehicle_categories",
                "description": "Get all available vehicle categories"
            },
            {
                "name": "search_vehicle_models",
                "description": "Search for vehicle models with filters"
            },
            {
                "name": "get_vehicle_model_details",
                "description": "Get detailed information about a vehicle model"
            },
            {
                "name": "get_vehicle_prices",
                "description": "Get vehicle price information"
            },
            {
                "name": "get_depreciation_rates",
                "description": "Get official depreciation rates"
            },
            {
                "name": "calculate_vehicle_tax_valuation",
                "description": "Calculate official tax valuation"
            },
            {
                "name": "get_stored_valuations",
                "description": "Get previously calculated valuations"
            },
            {
                "name": "check_api_health",
                "description": "Check API health status"
            }
        ]
    }


# For local development testing
if __name__ == "__main__":
    import uvicorn
    
    port = int(os.environ.get("PORT", 8000))
    host = os.environ.get("HOST", "0.0.0.0")

    print("\nStarting FastAPI wrapper for MCP Server")
    print(f"Server: http://{host}:{port}")
    print(f"MCP SSE Endpoint: http://{host}:{port}/sse")
    print(f"Health Check: http://{host}:{port}/health")
    print("\nPress CTRL+C to stop\n")
    
    uvicorn.run(
        "src.app:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )
