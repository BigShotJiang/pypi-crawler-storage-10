"""
Tests for the API client module.
"""

import pytest
from src.api_client import APIClient


@pytest.fixture
def api_client():
    """Create an API client instance for testing."""
    return APIClient(base_url="http://localhost:5000")


@pytest.mark.asyncio
async def test_client_initialization():
    """Test that the API client initializes correctly."""
    client = APIClient(base_url="http://test.example.com", timeout=60)
    assert client.base_url == "http://test.example.com"
    assert client.timeout == 60
    await client.close()


@pytest.mark.asyncio
async def test_get_categories(api_client):
    """Test getting vehicle categories."""
    # This test requires the API to be running
    try:
        response = await api_client.get_categories()
        assert "success" in response or "data" in response
    except Exception:
        pytest.skip("API not available for integration testing")
    finally:
        await api_client.close()


@pytest.mark.asyncio
async def test_get_models_with_filters(api_client):
    """Test getting models with filters."""
    try:
        response = await api_client.get_models(
            make="Toyota",
            year=2023,
            page=1,
            per_page=10
        )
        assert "success" in response or "data" in response
    except Exception:
        pytest.skip("API not available for integration testing")
    finally:
        await api_client.close()


@pytest.mark.asyncio
async def test_calculate_valuation(api_client):
    """Test calculating a vehicle valuation."""
    try:
        # This assumes model_id 1 exists in the database
        response = await api_client.calculate_valuation(
            model_id=1,
            vehicle_age=3
        )
        assert "success" in response or "data" in response
    except Exception:
        pytest.skip("API not available for integration testing")
    finally:
        await api_client.close()
