"""
Quick test script for the FastAPI MCP server.
Run this to verify the server works before deploying to Azure.
"""

import sys
import asyncio
import httpx

async def test_endpoints():
    """Test all FastAPI endpoints."""
    port = sys.argv[1] if len(sys.argv) > 1 else "8000"
    base_url = f"http://localhost:{port}"
    
    print("🧪 Testing Spanish Vehicle Tax MCP Server...\n")
    
    async with httpx.AsyncClient(timeout=5.0) as client:
        # Test 1: Root endpoint
        try:
            response = await client.get(f"{base_url}/")
            print(f"✅ Root endpoint: {response.status_code}")
            print(f"   {response.json()}\n")
        except Exception as e:
            print(f"❌ Root endpoint failed: {e}\n")
            return False
        
        # Test 2: Health check
        try:
            response = await client.get(f"{base_url}/health")
            print(f"✅ Health check: {response.status_code}")
            print(f"   {response.json()}\n")
        except Exception as e:
            print(f"❌ Health check failed: {e}\n")
            return False
        
        # Test 3: List tools
        try:
            response = await client.get(f"{base_url}/tools")
            print(f"✅ Tools list: {response.status_code}")
            tools = response.json()
            print(f"   Found {len(tools['tools'])} tools\n")
        except Exception as e:
            print(f"❌ Tools list failed: {e}\n")
            return False
        
        # Test 4: SSE endpoint (GET)
        try:
            response = await client.get(f"{base_url}/sse", timeout=2.0)
            print(f"✅ SSE endpoint (GET): {response.status_code}")
            print(f"   Content-Type: {response.headers.get('content-type')}\n")
        except httpx.TimeoutException:
            msg = "Connected (timed out as expected for streaming)"
            print(f"✅ SSE endpoint (GET): {msg}\n")
        except Exception as e:
            print(f"❌ SSE endpoint failed: {e}\n")
            return False
    
    print("=" * 60)
    print("✅ All tests passed! Server is ready for deployment.")
    print("=" * 60)
    return True

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("Spanish Vehicle Tax MCP Server - Quick Test")
    print("=" * 60 + "\n")
    print("Make sure the server is running:")
    print("  py -m uvicorn src.app:app --reload --port 8000\n")
    
    try:
        result = asyncio.run(test_endpoints())
        sys.exit(0 if result else 1)
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user.")
        sys.exit(1)
