from seaart import AsyncClient, APIError
import asyncio


async def async_demo() -> None:
    try:
        async with AsyncClient() as client:
            # High-level helper: simple ping check
            status = await client.ping()
            print(f"Ping OK: {status.msg}")

            # Log in and authenticate the client
            login = await client.login("email@example.com", "password")
            print(f"Logged in as {login.email}")

            # High-level helper: fetch account details
            account = await client.get_my_account()
            print(f"Hello, {account.name}!")

            # --- Low-level example ---
            # If the library doesn't provide a helper for some endpoint,
            # you can call it directly using `client.request()`.
            resp = await client.request("POST", "ping")
            print(f"Manual request: {resp.status.msg}")

    except APIError as e:
        print(f"APIError: {e.msg} (code={e.code}, status={e.http_status})")


if __name__ == "__main__":
    asyncio.run(async_demo())
