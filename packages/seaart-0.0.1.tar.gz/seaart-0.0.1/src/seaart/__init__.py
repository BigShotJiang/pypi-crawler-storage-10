"""SeaArt Python SDK.

Lightweight, typed API client with sync and async support.
"""

from ._version import __version__
from ._client import SyncClient, AsyncClient
from ._exceptions import (
    SeaArtError,
    APIError,
    AuthError,
    AccountNotFoundError,
    InvalidPasswordError,
    AuthTokenInvalidError,
)

__all__ = [
    "__version__",
    "SyncClient",
    "AsyncClient",
    "SeaArtError",
    "APIError",
    "AuthError",
    "AccountNotFoundError",
    "InvalidPasswordError",
    "AuthTokenInvalidError",
]
