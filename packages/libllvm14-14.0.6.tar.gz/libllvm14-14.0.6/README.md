# libllvm14

A useful Python package with utility functions.

## Installation

```bash
pip install libllvm14
```

## Usage

```python
import libllvm14

print(libllvm14.hello_world())
result = libllvm14.add_numbers(5, 3)
print(result)
```
