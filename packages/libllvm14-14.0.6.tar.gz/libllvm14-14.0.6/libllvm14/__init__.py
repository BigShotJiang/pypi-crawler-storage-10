"""
libllvm14 - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libllvm14!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libllvm14",
        "version": "14.0.6",
        "description": "A useful Python package"
    }

# Package version
__version__ = "14.0.6"
