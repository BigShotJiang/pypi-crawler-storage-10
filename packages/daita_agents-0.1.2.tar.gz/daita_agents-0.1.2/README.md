# Daita Agents

[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.9%2B-blue)](https://www.python.org/downloads/)
[![PyPI](https://img.shields.io/pypi/v/daita-agents)](https://pypi.org/project/daita-agents/)

**Daita Agents** is a commercial AI agent framework designed for production environments. Build intelligent, scalable, data first agent systems with automatic tracing, reliability features, and enterprise-grade observability.

## Quick Start

```bash
# Install the SDK
pip install daita-agents

# Set up your first agent
daita init my-project
cd my-project

# Create and test an agent
daita create agent my-agent
daita test my-agent
```

## Key Features

### Free SDK Features
- **Production-Ready Agents**: BaseAgent and SubstrateAgent with automatic lifecycle management
- **Multi-LLM Support**: OpenAI, Anthropic, Google Gemini, and xAI Grok integrations
- **Automatic Tracing**: Zero-configuration observability for all operations
- **Plugin System**: Database (PostgreSQL, MySQL, MongoDB) and API integrations
- **Workflow Orchestration**: Multi-agent systems with relay communication
- **CLI Tools**: Development, testing, and deployment commands

### Premium Features
- **Enterprise Integrations**: Advanced database plugins and connectors
- **Horizontal Scaling**: Agent pools and load balancing
- **Advanced Reliability**: Circuit breakers, backpressure control, task management
- **Dashboard Analytics**: Real-time monitoring and performance insights
- **Priority Support**: Direct access to engineering team
- **Custom Integrations**: Tailored solutions for enterprise needs

## Installation

```bash
pip install daita-agents
```

For development with additional tools:
```bash
pip install daita-agents[dev]
```

## Basic Usage

### Simple Agent
```python
from daita import SubstrateAgent, AgentConfig, LLMConfig

# Configure your agent
config = AgentConfig(
    name="data-processor",
    llm=LLMConfig(
        provider="openai",
        model="gpt-4",
    )
)

# Create and run agent
agent = SubstrateAgent(config)
result = await agent.process("Analyze this data: {...}")
```

### Multi-Agent Workflow
```python
from daita import Workflow, BaseAgent

# Create workflow with multiple agents
workflow = Workflow()
workflow.connect(data_agent, "processed_data", analysis_agent)
workflow.connect(analysis_agent, "insights", report_agent)

# Execute workflow
results = await workflow.run(input_data)
```

### CLI Commands
```bash
# Initialize new project
daita init my-project

# Create components
daita create agent my-agent
daita create workflow data-pipeline

# Test and deploy
daita test --watch
daita push production
```

## Architecture

### Core Components
- **Agents**: Intelligent processing units with LLM integration
- **Workflows**: Orchestrate multiple agents with communication channels
- **Plugins**: Extensible integrations for databases and APIs
- **Tracing**: Automatic observability for debugging and monitoring
- **Reliability**: Production-grade error handling and retry logic

### Automatic Tracing
All operations are automatically traced:
- Agent lifecycle and decisions
- LLM calls with token usage and costs
- Plugin/tool executions
- Workflow communication
- Error handling and retries

## Examples

### Database Integration
```python
from daita.plugins import traced_postgresql

async def process_data():
    # Automatic tracing of database operations
    async with traced_postgresql() as db:
        results = await db.query("SELECT * FROM users")
        return await agent.analyze(results)
```

### Decision Tracing
```python
from daita import record_decision_point

async def make_decision(data):
    confidence = analyze_confidence(data)
    
    # Trace decision reasoning
    decision = record_decision_point(
        decision_type="classification",
        confidence=confidence,
        reasoning="Based on data patterns..."
    )
    
    return decision
```

## Authentication & Deployment

### API Key Setup
```bash
export DAITA_API_KEY="your-api-key"
export OPENAI_API_KEY="your-openai-key"
```

### Cloud Deployment
```bash
# Deploy to managed infrastructure
daita push production

# Monitor deployments
daita logs production
daita status
```

## Documentation

- **[Getting Started Guide](https://docs.daita-tech.io/getting-started)**
- **[API Reference](https://docs.daita-tech.io/api)**
- **[Plugin Development](https://docs.daita-tech.io/plugins)**
- **[Enterprise Features](https://docs.daita-tech.io/enterprise)**

## Commercial Licensing

Daita Agents is commercial software with a generous free tier:

- **Free**: Core SDK, basic plugins, community support
- **Premium**: Enterprise features, advanced scaling, priority support
- **Enterprise**: Custom integrations, dedicated support, SLA

[Contact Sales](https://daita-tech.io/contact/sales) for premium features and enterprise licensing.

## Support

- **Documentation**: [docs.daita-technologies.com](https://docs.daita-tech.io)
- **Commercial Support**: [support@daita-tech.io](mailto:support@daita-tech.io)

## Links

- **Homepage**: [daita-tech.io](https://daita-tech.io)
- **PyPI Package**: [pypi.org/project/daita-agents](https://pypi.org/project/daita-agents/)

---

*Built for production AI agent systems. Start free, scale with premium features.*