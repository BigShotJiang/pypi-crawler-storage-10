"""
Anthropic LLM provider implementation with integrated tracing.
"""
import os
import logging
from typing import Dict, Any, Optional

from ..core.exceptions import LLMError
from .base import BaseLLMProvider

logger = logging.getLogger(__name__)

class AnthropicProvider(BaseLLMProvider):
    """Anthropic LLM provider implementation with automatic call tracing."""
    
    def __init__(
        self,
        model: str = "claude-3-sonnet-20240229",
        api_key: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize Anthropic provider.
        
        Args:
            model: Anthropic model name
            api_key: Anthropic API key
            **kwargs: Additional Anthropic-specific parameters
        """
        # Get API key from parameter or environment
        api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        
        super().__init__(model=model, api_key=api_key, **kwargs)
        
        # Anthropic-specific default parameters
        self.default_params.update({
            'timeout': kwargs.get('timeout', 60)
        })
        
        # Lazy-load Anthropic client
        self._client = None
    
    @property
    def client(self):
        """Lazy-load Anthropic client."""
        if self._client is None:
            try:
                import anthropic
                self._validate_api_key()
                self._client = anthropic.AsyncAnthropic(api_key=self.api_key)
                logger.debug("Anthropic client initialized")
            except ImportError:
                raise LLMError(
                    "Anthropic package not installed. Install with: pip install anthropic"
                )
        return self._client
    
    async def _generate_impl(self, prompt: str, **kwargs) -> str:
        """
        Provider-specific implementation of text generation for Anthropic.
        
        This method contains the actual Anthropic API call logic and is automatically
        wrapped with tracing by the base class generate() method.
        
        Args:
            prompt: Input prompt
            **kwargs: Optional parameters
            
        Returns:
            Generated text response
        """
        try:
            # Merge parameters
            params = self._merge_params(kwargs)
            
            # Make API call
            response = await self.client.messages.create(
                model=self.model,
                max_tokens=params.get('max_tokens'),
                temperature=params.get('temperature'),
                messages=[
                    {"role": "user", "content": prompt}
                ],
                timeout=params.get('timeout')
            )
            
            # Store usage for base class token extraction
            self._last_usage = response.usage
            
            return response.content[0].text
            
        except Exception as e:
            logger.error(f"Anthropic generation failed: {str(e)}")
            raise LLMError(f"Anthropic generation failed: {str(e)}")
    
    async def generate_with_system(self, prompt: str, system_message: str, **kwargs) -> str:
        """
        Generate text with a system message using Anthropic's system parameter.
        
        Note: This method bypasses automatic tracing since it's not part of the 
        base interface. If you want tracing for system messages, call the base
        generate() method with a formatted prompt instead.
        
        Args:
            prompt: User prompt
            system_message: System message to set context
            **kwargs: Optional parameters
            
        Returns:
            Generated text
        """
        try:
            # Merge parameters
            params = self._merge_params(kwargs)
            
            # Make API call with system parameter
            response = await self.client.messages.create(
                model=self.model,
                max_tokens=params.get('max_tokens'),
                temperature=params.get('temperature'),
                system=system_message,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                timeout=params.get('timeout')
            )
            
            # Store usage for potential token extraction
            self._last_usage = response.usage
            
            return response.content[0].text
            
        except Exception as e:
            logger.error(f"Anthropic generation with system message failed: {str(e)}")
            raise LLMError(f"Anthropic generation failed: {str(e)}")
    
    def _get_last_token_usage(self) -> Dict[str, int]:
        """
        Override base class method to handle Anthropic's token format.
        
        Anthropic uses input_tokens and output_tokens format, different from OpenAI.
        """
        if self._last_usage:
            # Anthropic format: input_tokens + output_tokens
            input_tokens = getattr(self._last_usage, 'input_tokens', 0)
            output_tokens = getattr(self._last_usage, 'output_tokens', 0)
            total_tokens = input_tokens + output_tokens
            
            return {
                'total_tokens': total_tokens,
                'prompt_tokens': input_tokens,  # Map input_tokens to prompt_tokens
                'completion_tokens': output_tokens  # Map output_tokens to completion_tokens
            }
        
        # Fallback to base class estimation
        return super()._get_last_token_usage()
    
    @property
    def info(self) -> Dict[str, Any]:
        """Get information about the Anthropic provider."""
        base_info = super().info
        base_info.update({
            'provider_name': 'Anthropic',
            'api_compatible': 'Anthropic'
        })
        return base_info