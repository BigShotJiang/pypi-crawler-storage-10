"""
Grok (xAI) LLM provider implementation with integrated tracing.
"""
import os
import logging
from typing import Dict, Any, Optional

from ..core.exceptions import LLMError
from .base import BaseLLMProvider

logger = logging.getLogger(__name__)

class GrokProvider(BaseLLMProvider):
    """Grok (xAI) LLM provider implementation with automatic call tracing."""
    
    def __init__(
        self,
        model: str = "grok-beta",
        api_key: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize Grok provider.
        
        Args:
            model: Grok model name (e.g., "grok-beta", "grok-vision-beta")
            api_key: xAI API key
            **kwargs: Additional Grok-specific parameters
        """
        # Get API key from parameter or environment
        api_key = api_key or os.getenv("XAI_API_KEY") or os.getenv("GROK_API_KEY")
        
        super().__init__(model=model, api_key=api_key, **kwargs)
        
        # Grok-specific default parameters
        self.default_params.update({
            'stream': kwargs.get('stream', False),
            'timeout': kwargs.get('timeout', 60)
        })
        
        # Base URL for xAI API
        self.base_url = kwargs.get('base_url', 'https://api.x.ai/v1')
        
        # Lazy-load OpenAI client (Grok uses OpenAI-compatible API)
        self._client = None
    
    @property
    def client(self):
        """Lazy-load OpenAI client configured for xAI."""
        if self._client is None:
            try:
                import openai
                self._validate_api_key()
                self._client = openai.AsyncOpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url
                )
                logger.debug("Grok client initialized")
            except ImportError:
                raise LLMError(
                    "OpenAI package not installed. Install with: pip install openai"
                )
        return self._client
    
    async def _generate_impl(self, prompt: str, **kwargs) -> str:
        """
        Provider-specific implementation of text generation for Grok.
        
        This method contains the actual Grok API call logic and is automatically
        wrapped with tracing by the base class generate() method.
        
        Args:
            prompt: Input prompt
            **kwargs: Optional parameters
            
        Returns:
            Generated text response
        """
        try:
            # Merge parameters
            params = self._merge_params(kwargs)
            
            # Make API call using OpenAI-compatible interface
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_tokens=params.get('max_tokens'),
                temperature=params.get('temperature'),
                top_p=params.get('top_p'),
                stream=params.get('stream'),
                timeout=params.get('timeout')
            )
            
            # Store usage for base class token extraction
            self._last_usage = response.usage
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Grok generation failed: {str(e)}")
            raise LLMError(f"Grok generation failed: {str(e)}")
    
    @property
    def info(self) -> Dict[str, Any]:
        """Get information about the Grok provider."""
        base_info = super().info
        base_info.update({
            'base_url': self.base_url,
            'provider_name': 'Grok (xAI)',
            'api_compatible': 'OpenAI'
        })
        return base_info