"""MCP server implementation for ticket management."""

from .server import MCPTicketServer

__all__ = ["MCPTicketServer"]
