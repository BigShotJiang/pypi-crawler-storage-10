"""Validation functionality for SVG and G-code files."""
