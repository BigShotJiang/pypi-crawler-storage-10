# Threat Model

## Security Assumptions

1. **Computational Hardness**: LWE problem is computationally hard even for quantum computers
2. **Hash Function Security**: SHA-256 is collision-resistant
3. **Randomness**: CSPRNG provides cryptographically secure randomness
4. **Key Secrecy**: Private keys remain secret

## Threat Categories

### Quantum Attacks

- **Shor's Algorithm**: Protected by lattice-based cryptography (not based on factoring/discrete log)
- **Grover's Algorithm**: Protected by large key spaces and dual-key system

### Classical Attacks

- **Brute Force**: Protected by high-dimensional key spaces
- **Known Plaintext**: Protected by per-byte unique encoding parameters
- **Side-Channel Attacks**: Protected by constant-time operations

### Implementation Attacks

- **Timing Attacks**: Prevented by constant-time implementations
- **Memory Attacks**: Protected by secure memory wiping
- **Fault Injection**: Requires additional hardware protection (not in scope)

## Security Levels

- **Kyber512/Dilithium2**: 128-bit security (NIST Level 1)
- **Kyber768/Dilithium3**: 192-bit security (NIST Level 3)
- **Kyber1024/Dilithium5**: 256-bit security (NIST Level 5)

