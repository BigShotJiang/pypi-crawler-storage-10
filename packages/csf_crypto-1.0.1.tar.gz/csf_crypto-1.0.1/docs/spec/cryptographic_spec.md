# Cryptographic Specification

## Overview

CSF implements a hybrid post-quantum cryptographic system combining:

1. **NIST PQC Standards**: CRYSTALS-Kyber (FIPS 203), CRYSTALS-Dilithium (FIPS 204), SPHINCS+ (FIPS 205)
2. **Fractal Encoding**: Messages encoded into Julia set parameter space
3. **Semantic Keys**: Text-derived numerical vectors
4. **Dual Security**: Mathematical + semantic key layers

## Cryptographic Primitives

### Key Encapsulation Mechanism (KEM)

- **Primary**: CRYSTALS-Kyber (ML-KEM per FIPS 203)
  - Variants: Kyber512 (128-bit), Kyber768 (192-bit), Kyber1024 (256-bit)
  - Fallback: Lattice-based LWE implementation

### Digital Signatures

- **Primary**: CRYSTALS-Dilithium (ML-DSA per FIPS 204)
  - Variants: Dilithium2 (128-bit), Dilithium3 (192-bit), Dilithium5 (256-bit)
- **Backup**: SPHINCS+ (SLH-DSA per FIPS 205)
- **Additional**: Fractal-based signatures for authentication

### Fractal Encoding

Messages are encoded into Julia set parameters:

```
z_{n+1} = z_n^2 + c

where:
  c = f(message_byte, math_key, semantic_key)
  z_0 = g(position, math_key, semantic_key)
```

## Security Properties

- **Post-Quantum Security**: All cryptographic operations use NIST-approved PQC standards
- **Constant-Time Operations**: All operations execute in constant time to prevent side-channel attacks
- **Dual-Key Security**: Requires both mathematical and semantic keys for decryption
- **Quantum Resistance**: Protection against Shor's and Grover's algorithms

## Key Sizes

- **Public Keys**: Varies by scheme (Kyber768: ~1184 bytes, Dilithium3: ~1952 bytes)
- **Private Keys**: Varies by scheme (Kyber768: ~2400 bytes, Dilithium3: ~4000 bytes)
- **Shared Secrets**: 32 bytes (256 bits)

