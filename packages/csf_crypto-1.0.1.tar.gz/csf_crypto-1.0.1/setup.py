"""Setup script for CSF package.

CSF - Cryptographic Security Framework
Inventor: Jeremy Noverraz (1988 - 2025)
"""

from setuptools import setup, find_packages

# Read README for long description
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "Military-grade post-quantum cryptographic system with fractal encoding"

setup(
    name="csf-crypto",
    version="1.0.1",
    author="Jeremy Noverraz",
    maintainer="Jeremy Noverraz",
    author_email="",
    description="Military-grade post-quantum cryptographic system with fractal encoding",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/iyotee/csf",
    packages=find_packages(exclude=["tests", "tests.*", "venv", "venv.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "matplotlib>=3.7.0",
    ],
    extras_require={
        "pqc": [
            "pykyber>=0.1.0",  # Optional: CRYSTALS-Kyber
            "python-pqc>=0.1.0",  # Optional: Additional PQC schemes
            "pysphincs>=0.1.0",  # Optional: SPHINCS+
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "mypy>=1.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "csf-keygen=csf.tools.keygen:main",
            "csf-benchmark=csf.tools.benchmark:main",
        ],
    },
    keywords="cryptography, post-quantum, fractal, encryption, security, NIST PQC",
    project_urls={
        "Documentation": "https://github.com/iyotee/csf",
        "Source": "https://github.com/iyotee/csf",
        "GitHub": "https://github.com/iyotee/csf",
    },
    include_package_data=True,
    zip_safe=False,
)

