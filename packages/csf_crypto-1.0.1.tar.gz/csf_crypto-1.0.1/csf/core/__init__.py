"""Core cryptographic primitives."""

