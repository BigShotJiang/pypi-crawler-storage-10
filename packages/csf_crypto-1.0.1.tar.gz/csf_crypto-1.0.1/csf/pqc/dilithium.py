"""
CRYSTALS-Dilithium integration (NIST PQC Standard FIPS 204 / ML-DSA).

Provides digital signatures using lattice-based cryptography.
"""

from typing import Tuple
import numpy as np
from csf.pqc.base import SignatureScheme, PQCScheme
from csf.core.randomness import CSPRNG
from csf.security.validation import validate_bytes
from csf.utils.exceptions import CryptographicError


class DilithiumSignature(SignatureScheme, PQCScheme):
    """
    CRYSTALS-Dilithium Digital Signature Algorithm.
    
    Implements ML-DSA (FIPS 204) standard.
    """
    
    def __init__(self, variant: str = "Dilithium3"):
        """
        Initialize Dilithium signature scheme.
        
        Args:
            variant: Dilithium variant ("Dilithium2", "Dilithium3", "Dilithium5")
        """
        self.variant = variant
        
        # Parameters based on variant
        if variant == "Dilithium2":
            self._n = 256
            self._q = 8380417
            self._k = 4
            self._l = 4
            self._eta = 2
            self._tau = 39
            self._gamma1 = 2**17
            self._gamma2 = (self._q - 1) // 88
            self._sec_level = 128
        elif variant == "Dilithium3":
            self._n = 256
            self._q = 8380417
            self._k = 6
            self._l = 5
            self._eta = 4
            self._tau = 49
            self._gamma1 = 2**19
            self._gamma2 = (self._q - 1) // 32
            self._sec_level = 192
        elif variant == "Dilithium5":
            self._n = 256
            self._q = 8380417
            self._k = 8
            self._l = 7
            self._eta = 2
            self._tau = 60
            self._gamma1 = 2**19
            self._gamma2 = (self._q - 1) // 32
            self._sec_level = 256
        else:
            raise ValueError(f"Unknown Dilithium variant: {variant}")
        
        self.csprng = CSPRNG()
    
    def generate_key_pair(self) -> Tuple[bytes, bytes]:
        """
        Generate a signing/verification key pair.
        
        Returns:
            Tuple of (public_key, private_key) as bytes
        """
        try:
            return self._generate_key_pair_external()
        except (ImportError, AttributeError):
            return self._generate_key_pair_internal()
    
    def _generate_key_pair_external(self) -> Tuple[bytes, bytes]:
        """Generate keys using external library."""
        try:
            from pqc.crystals_dilithium import Dilithium as PQCDilithium
            
            if self.variant == "Dilithium2":
                dil = PQCDilithium("dilithium2")
            elif self.variant == "Dilithium3":
                dil = PQCDilithium("dilithium3")
            else:
                dil = PQCDilithium("dilithium5")
            
            pk, sk = dil.keygen()
            return bytes(pk), bytes(sk)
        except ImportError:
            raise ImportError("No Dilithium library available. Install python-pqc.")
    
    def _generate_key_pair_internal(self) -> Tuple[bytes, bytes]:
        """Internal key generation."""
        # Generate matrix A (public parameter)
        A = self._generate_matrix_A()
        
        # Private key: small polynomial vectors
        s1 = self._sample_poly_vector(self._l)
        s2 = self._sample_poly_vector(self._k)
        
        # Public key: t = A @ s1 + s2
        t = (A @ s1 + s2) % self._q
        t1 = self._highbits(t)
        
        # Serialize keys
        pk_bytes = self._serialize_public_key(A, t1)
        sk_bytes = self._serialize_private_key(A, s1, s2, t1)
        
        return pk_bytes, sk_bytes
    
    def sign(self, message: bytes, private_key: bytes) -> bytes:
        """
        Sign a message.
        
        Args:
            message: Message to sign
            private_key: Signing key
            
        Returns:
            Signature as bytes
        """
        validate_bytes(message, "message", min_length=0)
        validate_bytes(private_key, "private_key", min_length=1)
        
        try:
            return self._sign_external(message, private_key)
        except (ImportError, AttributeError):
            return self._sign_internal(message, private_key)
    
    def _sign_external(self, message: bytes, private_key: bytes) -> bytes:
        """Sign using external library."""
        try:
            from pqc.crystals_dilithium import Dilithium as PQCDilithium
            
            if self.variant == "Dilithium3":
                dil = PQCDilithium("dilithium3")
            elif self.variant == "Dilithium2":
                dil = PQCDilithium("dilithium2")
            else:
                dil = PQCDilithium("dilithium5")
            
            sig = dil.sign(message, private_key)
            return bytes(sig)
        except ImportError:
            raise ImportError("No Dilithium library available.")
    
    def _sign_internal(self, message: bytes, private_key: bytes) -> bytes:
        """Internal signing implementation."""
        # Parse private key
        A, s1, s2, t1 = self._deserialize_private_key(private_key)
        
        # Compute message hash
        mu = self._hash_message(message, t1)
        
        # Generate nonce
        rho = self.csprng.random_bytes(32)
        
        # Signing loop
        kappa = 0
        while True:
            # Generate challenge polynomial
            c_tilde = self._hash_poly(mu + rho)
            c = self._sample_challenge(c_tilde)
            
            # Compute signature
            y = self._sample_y()
            w1 = self._highbits(A @ y, self._gamma2)
            
            # Check if signature is valid
            if np.linalg.norm(w1) > self._gamma1 - self._beta:
                kappa += 1
                if kappa > 100:
                    raise CryptographicError("Signing failed after too many iterations")
                continue
            
            z = y + c @ s1
            if np.linalg.norm(z) >= self._gamma1 - self._beta:
                kappa += 1
                if kappa > 100:
                    raise CryptographicError("Signing failed after too many iterations")
                continue
            
            h = self._make_hint(z, w1, c @ s2)
            if h.size > self._omega:
                kappa += 1
                if kappa > 100:
                    raise CryptographicError("Signing failed after too many iterations")
                continue
            
            # Serialize signature
            return self._serialize_signature(c, z, h)
    
    def verify(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        """
        Verify a signature.
        
        Args:
            message: Original message
            signature: Signature to verify
            public_key: Verification key
            
        Returns:
            True if signature is valid
        """
        validate_bytes(message, "message", min_length=0)
        validate_bytes(signature, "signature", min_length=1)
        validate_bytes(public_key, "public_key", min_length=1)
        
        try:
            return self._verify_external(message, signature, public_key)
        except (ImportError, AttributeError):
            return self._verify_internal(message, signature, public_key)
    
    def _verify_external(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verify using external library."""
        try:
            from pqc.crystals_dilithium import Dilithium as PQCDilithium
            
            if self.variant == "Dilithium3":
                dil = PQCDilithium("dilithium3")
            elif self.variant == "Dilithium2":
                dil = PQCDilithium("dilithium2")
            else:
                dil = PQCDilithium("dilithium5")
            
            return dil.verify(message, signature, public_key)
        except ImportError:
            raise ImportError("No Dilithium library available.")
    
    def _verify_internal(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        """Internal verification implementation."""
        try:
            # Parse signature
            c, z, h = self._deserialize_signature(signature)
            
            # Parse public key
            A, t1 = self._deserialize_public_key(public_key)
            
            # Verify signature bounds
            if np.linalg.norm(z) >= self._gamma1 - self._beta:
                return False
            
            # Compute message hash
            mu = self._hash_message(message, t1)
            
            # Verify challenge
            c_tilde = self._hash_poly(mu + h)
            c_prime = self._sample_challenge(c_tilde)
            
            if not np.array_equal(c, c_prime):
                return False
            
            # Verify signature equation
            w1_prime = self._highbits(A @ z - c @ t1, self._gamma2)
            return self._use_hint(w1_prime, h) == self._lowbits(A @ z - c @ t1, self._gamma2)
        except Exception:
            return False
    
    # Helper methods (simplified implementations)
    def _generate_matrix_A(self) -> np.ndarray:
        """Generate public matrix A."""
        return self.csprng.random_matrix(self._k, self._l, dtype=np.int32) % self._q
    
    def _sample_poly_vector(self, k: int) -> np.ndarray:
        """Sample polynomial vector."""
        return self.csprng.random_array((k, self._n), dtype=np.int16) % (2 * self._eta + 1) - self._eta
    
    def _highbits(self, x: np.ndarray, gamma: int) -> np.ndarray:
        """Extract high bits."""
        return (x + gamma // 2) // gamma
    
    def _lowbits(self, x: np.ndarray, gamma: int) -> np.ndarray:
        """Extract low bits."""
        return x - self._highbits(x, gamma) * gamma
    
    def _hash_message(self, message: bytes, t1: np.ndarray) -> bytes:
        """Hash message."""
        import hashlib
        return hashlib.sha256(message + t1.tobytes()).digest()
    
    def _hash_poly(self, data: bytes) -> np.ndarray:
        """Hash to polynomial."""
        import hashlib
        hash_bytes = hashlib.sha256(data).digest()
        return np.frombuffer(hash_bytes, dtype=np.uint8)[:self._n]
    
    def _sample_challenge(self, c_tilde: np.ndarray) -> np.ndarray:
        """Sample challenge polynomial."""
        return c_tilde[:self._tau]
    
    def _sample_y(self) -> np.ndarray:
        """Sample y vector."""
        return self.csprng.random_array((self._l, self._n), dtype=np.int32) % (2 * self._gamma1)
    
    def _make_hint(self, z: np.ndarray, w1: np.ndarray, r: np.ndarray) -> np.ndarray:
        """Make hint."""
        # Simplified hint generation
        return np.concatenate([z.flatten(), w1.flatten()])[:self._omega]
    
    def _use_hint(self, w1: np.ndarray, h: np.ndarray) -> np.ndarray:
        """Use hint."""
        # Simplified hint usage
        return w1
    
    def _serialize_public_key(self, A: np.ndarray, t1: np.ndarray) -> bytes:
        """Serialize public key."""
        return A.tobytes() + t1.tobytes()
    
    def _deserialize_public_key(self, data: bytes) -> Tuple[np.ndarray, np.ndarray]:
        """Deserialize public key."""
        A_size = self._k * self._l * self._n * 4
        A = np.frombuffer(data[:A_size], dtype=np.int32).reshape(self._k, self._l, self._n)
        t1 = np.frombuffer(data[A_size:], dtype=np.int32)
        return A, t1
    
    def _serialize_private_key(self, A: np.ndarray, s1: np.ndarray, 
                              s2: np.ndarray, t1: np.ndarray) -> bytes:
        """Serialize private key."""
        return A.tobytes() + s1.tobytes() + s2.tobytes() + t1.tobytes()
    
    def _deserialize_private_key(self, data: bytes) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Deserialize private key."""
        # Simplified deserialization
        A_size = self._k * self._l * self._n * 4
        s1_size = self._l * self._n * 4
        s2_size = self._k * self._n * 4
        t1_size = self._k * self._n * 4
        
        offset = 0
        A = np.frombuffer(data[offset:offset+A_size], dtype=np.int32).reshape(self._k, self._l, self._n)
        offset += A_size
        s1 = np.frombuffer(data[offset:offset+s1_size], dtype=np.int32).reshape(self._l, self._n)
        offset += s1_size
        s2 = np.frombuffer(data[offset:offset+s2_size], dtype=np.int32).reshape(self._k, self._n)
        offset += s2_size
        t1 = np.frombuffer(data[offset:offset+t1_size], dtype=np.int32)
        
        return A, s1, s2, t1
    
    def _serialize_signature(self, c: np.ndarray, z: np.ndarray, h: np.ndarray) -> bytes:
        """Serialize signature."""
        return c.tobytes() + z.tobytes() + h.tobytes()
    
    def _deserialize_signature(self, data: bytes) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Deserialize signature."""
        c_size = self._tau * 4
        z_size = self._l * self._n * 4
        h_size = self._omega * 4
        
        c = np.frombuffer(data[:c_size], dtype=np.int32)
        z = np.frombuffer(data[c_size:c_size+z_size], dtype=np.int32).reshape(self._l, self._n)
        h = np.frombuffer(data[c_size+z_size:c_size+z_size+h_size], dtype=np.int32)
        
        return c, z, h
    
    @property
    def public_key_size(self) -> int:
        """Size of public key in bytes."""
        return self._k * self._l * self._n * 4 + self._k * self._n * 4
    
    @property
    def private_key_size(self) -> int:
        """Size of private key in bytes."""
        return self._k * self._l * self._n * 4 + self._l * self._n * 4 + self._k * self._n * 4 * 2
    
    @property
    def signature_size(self) -> int:
        """Size of signature in bytes."""
        return self._tau * 4 + self._l * self._n * 4 + self._omega * 4
    
    @property
    def security_level(self) -> int:
        """Security level in bits."""
        return self._sec_level
    
    @property
    def name(self) -> str:
        """Name of the scheme."""
        return f"CRYSTALS-Dilithium ({self.variant})"
    
    @property
    def version(self) -> str:
        """Version of the scheme."""
        return "1.0"


    @property
    def _beta(self):
        """Beta parameter."""
        return self._gamma1 - self._gamma2
    
    @property
    def _omega(self):
        """Omega parameter."""
        return self._tau * 64


def create_dilithium(variant: str = "Dilithium3") -> DilithiumSignature:
    """
    Create a Dilithium signature instance.
    
    Args:
        variant: Dilithium variant
        
    Returns:
        DilithiumSignature instance
    """
    return DilithiumSignature(variant)

