# Academic Whitepaper  
## CSF: Fractal Semantic Encryption  
### A post-quantum approach integrating fractal geometry and semantic keys

**Inventor**: Jeremy Noverraz (1988 - 2025)  
**Intellectual Property**: CSF Protocol - Fractal Semantic Encryption

---

## 1. Introduction
Modern cryptography faces a dual threat:  
- **The advent of quantum computing**, which weakens RSA, ECC and other classical schemes.  
- **Post-quantum standardization** (NIST PQC) which remains dominated by arithmetic approaches (lattices, error-correcting codes).  

We propose a new class of protocols: **Fractal Semantic Encryption (CSF)**.  
This protocol rests on three pillars:  
1. **Post-quantum primitives** (lattices, error-correcting codes).  
2. **Fractal encoding** (deterministic chaos, unique visual signatures).  
3. **Semantic keys** (conceptual vectors, adding a contextual layer).  

---

## 2. State of the Art
- Some work already explores **fractal or chaotic encryption**, e.g.:  
  - Iovane et al., *A Quantum‑Secure Cryptographic Algorithm Integrating Fractals and Prime Numbers* (2024).  
  - Algorithms based on Sierpinski or Mandelbrot.  
- However, no protocol combines **fractals + semantics + post-quantum**.  
CSF positions itself as a **new cryptographic family**.

---

## 3. Formal Definition
### 3.1 Key Spaces
- **Mathematical key** \(K_{math}\): generated via a PQC scheme (e.g., Kyber).  
- **Semantic key** \(K_{sem}\): vector derived from semantic embedding (Word2Vec, BERT, or symbolic hash).  

### 3.2 Fractal Function
We define an iteration function:  

\[
z_{n+1} = z_n^2 + F(m, K_{math}, K_{sem})
\]

where:  
- \(m\) is the plaintext message,  
- \(F\) is a mixing function (hash + vector projection),  
- \(z_0\) is an initial condition depending on the key.  

### 3.3 Encryption
- The message is mapped into fractal space.  
- The ciphertext is represented by a sequence of fractal parameters \(\{z_n\}\).  

### 3.4 Decryption
- Replay the function with both keys.  
- Extract the plaintext message by inverting \(F\).  

### 3.5 Fractal Signature
- Generation of a **unique fractal fingerprint** (image + hash).  
- Any modification of the message destroys geometric coherence.  

---

## 4. Security Properties
- **Quantum resistance**: inherited from PQC primitives.  
- **Non-reproducibility**: the semantic key adds a quasi-infinite contextual space.  
- **Built-in authenticity**: the fractal signature acts as an integrity proof.  
- **Complexity**: brute force search requires exploring both mathematical and semantic spaces.  

---

## 5. Use Cases
- **Semantic blockchain**: blocks validated by fractal signatures.  
- **Secure messaging**: flow indistinguishable from noise without the semantic key.  
- **IoT**: lightweight but robust encryption.  
- **Digital identity**: fractal fingerprints as visual certificates.  

---

## 6. Perspectives
- Complete mathematical formalization (complexity analysis, entropy).  
- Open-source implementation (Python, PQC + fractal libraries).  
- Community cryptanalysis.  
- Patent filing and academic publication.  

---

## 7. Conclusion
**CSF** inaugurates a new era of cryptography: **post-quantum, geometric and semantic**.  
It is not just a technical protocol, but a **symbolic manifesto**: uniting mathematics, language and fractals to transcend the limits of brute-force computation.  

---

## References
1. G. Iovane, E. Benedetto, A. Di Lauro, *A Quantum‑Secure Cryptographic Algorithm Integrating Fractals and Prime Numbers*, Applied Sciences, 2024.  
2. Springer, *Symmetric Encryption Using Sierpinski Fractal Geometry*.  
3. MECS Press, *Symmetric Key Encryption using Iterated Fractal Functions*.
