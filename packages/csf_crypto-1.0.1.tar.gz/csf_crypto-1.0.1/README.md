# CSF - Cryptographic Security Framework

**Military-grade post-quantum cryptographic system with fractal encoding**

---

## Installation

### Standard Installation (Recommended)

Just like installing any Python package:

```bash
# From PyPI (installs version 1.0.0)
pip install csf-crypto

# Or explicitly install version 1.0.0
pip install csf-crypto==1.0.0

# Or from Git repository
pip install git+https://github.com/iyotee/csf.git

# Or from local source (for development)
pip install .
```

**No setup.sh needed!** Just `pip install csf` and you're ready to go.

### Optional Extras

```bash
# With NIST PQC libraries (optional)
pip install csf[pqc]

# With development tools (optional, for contributors)
pip install csf[dev]
```

---

## Quick Start

```python
from csf import FractalCryptoSystem
from csf.core.keys import KeyManager

# Initialize
crypto = FractalCryptoSystem()
key_manager = KeyManager()

# Generate keys
public_key, private_key = key_manager.generate_key_pair()

# Encrypt
message = "Secret message"
encrypted = crypto.encrypt(message, "my_secret_key", public_key, private_key)

# Decrypt
decrypted = crypto.decrypt(encrypted, "my_secret_key", private_key)
print(decrypted)  # "Secret message"
```

That's it! CSF works exactly like `cryptography` or `pycryptodome`.

**Note**: The package is published as `csf-crypto` on PyPI (because `csf` was already taken).

See [QUICKSTART.md](QUICKSTART.md) for more examples.

---

## Features

- **Post-Quantum Secure**: NIST PQC standards (FIPS 203, 204, 205)
- **Dual-Key System**: Mathematical + Semantic keys
- **Fractal Encoding**: Messages in Julia set parameter space
- **Constant-Time**: Side-channel attack protection
- **Simple API**: Use like any standard cryptographic library

---

## Usage

### Basic Encryption

```python
from csf import FractalCryptoSystem
from csf.core.keys import KeyManager

crypto = FractalCryptoSystem()
key_manager = KeyManager()

pk, sk = key_manager.generate_key_pair()
encrypted = crypto.encrypt("Hello", "key", pk, sk)
decrypted = crypto.decrypt(encrypted, "key", sk)
```

### Signing

```python
hash, sig = crypto.sign("Message", "key", sk)
is_valid = crypto.verify("Message", hash, "key", sk, pk)
```

### Command-Line Tools

After installation:

```bash
# Generate keys
python -m csf.tools.keygen --scheme Kyber768

# Benchmark
python -m csf.tools.benchmark --message-size 1000
```

---

## Documentation

- **Quick Start**: [QUICKSTART.md](QUICKSTART.md)
- **Full Usage**: [USAGE.md](USAGE.md)
- **Installation Details**: [INSTALL.md](INSTALL.md)
- **Distribution**: [DISTRIBUTION.md](DISTRIBUTION.md) (for maintainers)
- **Technical Specs**: [docs/spec/cryptographic_spec.md](docs/spec/cryptographic_spec.md)
- **Whitepaper**: [whitepaper.md](whitepaper.md)

---

## Requirements

- Python >= 3.9
- numpy >= 1.24.0
- scipy >= 1.10.0
- matplotlib >= 3.7.0

---

## Development

For contributors who want to modify CSF:

```bash
# Clone repository
git clone https://github.com/iyotee/csf.git
cd csf

# Create virtual environment (optional helper)
./setup.sh  # OR manually: python -m venv venv && source venv/bin/activate

# Install in development mode
pip install -e .[dev]

# Run tests
pytest tests/
```

**Note**: `setup.sh` is only a convenience script for local development. End users don't need it - they just use `pip install csf`.

---

## License

This project is provided for private/government use.

---

## Inventor

**Jeremy Noverraz (1988 - 2025)**
