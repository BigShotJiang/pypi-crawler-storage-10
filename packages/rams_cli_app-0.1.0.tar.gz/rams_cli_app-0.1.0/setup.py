from setuptools import setup, find_packages

setup(
    name="rams-cli-app",
    version="0.1.0",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'mycli=my_cli_app.__main__:main',
        ],
    },
    description="A sample CLI app",
    author="Ram",
)
