"""Inductance."""

import importlib.metadata

__version__ = importlib.metadata.version("inductance")

# from . import elliptics, filaments, inductance
