import os
from typing import Optional

from .common import mkdir, create_file, extract_names, str_format, add_docker_compose_script, \
    unwrapper_dir_name, add_uv_script


def generate_cli(project_dir: str, package_dir: str, override: bool = False,
                 command: str = None,
                 extra_import: Optional[str] = '',
                 extra_run: Optional[str] = '',
                 docker: Optional[bool] = True,
                 docker_compose: Optional[bool] = True,
                 **kwargs):
    """生成uv cli命令

    Args:
        project_dir: 项目目录
        package_dir: 包目录
        override: 是否覆盖文件
        command: 命令名称, 生成的cli命令可使用 uv run {command} 运行
        extra_import: 生成的cli需要额外执行的导入
        extra_run: 生成的cli需要额外执行的逻辑
        docker: 是否生成docker相关文件
        docker_compose: 是否生成docker-compose相关文件
        app: 指定应用
    """
    project_name = unwrapper_dir_name(project_dir)
    package_name = unwrapper_dir_name(package_dir)
    cli_dir = package_dir + os.sep + 'cli'
    cli_init_py = cli_dir + os.sep + '__init__.py'
    mkdir(cli_dir)
    # 该文件不覆盖, 防止影响其他逻辑
    create_file(cli_init_py)
    names = extract_names(command)
    cli_name = '_'.join(names)
    names.append('main')
    cli_main_name = '_'.join(names)
    cli_py = cli_dir + os.sep + cli_main_name + '.py'
    create_file(cli_py, str_format('''import os
import click
from typing import Optional

from ${package_name}.boot import start
${extra_import}

@click.command()
@click.option('--project_dir', default=None, help='项目目录, 未打包无需传该参数, 自动基于项目树检索')
@click.option('--env', default='dev', help='运行环境, dev=测试环境, test=测试环境, pro=正式环境, 默认: dev')
@click.version_option(version="1.0.0", help='查看命令版本')
@click.help_option('-h', '--help', help='查看命令帮助')
def main(project_dir: Optional[str] = None,
         env: Optional[str] = 'dev') -> None:
    """${command} cli."""
    if project_dir:
        os.environ['PROJECT_DIR'] = project_dir
    if env:
        os.environ['ENV'] = env

    # start ioc
    start()

    ${extra_run}

if __name__ == "__main__":
    main()
''', package_name=package_name, command=command, extra_import=extra_import, extra_run=extra_run), override=override)
    add_uv_script(project_dir, str_format('${command} = "${package_name}.cli.${cli_main_name}:main"',
                                              package_name=package_name,
                                              command=command,
                                              cli_main_name=cli_main_name))
    bin_dir = project_dir + os.sep + 'bin'
    mkdir(bin_dir)
    bin_file = bin_dir + os.sep + cli_name + '.sh'
    create_file(bin_file, str_format('''USER=$(whoami)
echo "当前用户: $USER"
# 更新UV缓存目录, 解决非root用户使用uv访问root目录问题
export UV_CACHE_DIR=/home/$USER/.cache/uv
export HOME=/home/$USER
export XDG_DATA_HOME=/home/$USER/.local/share

# 默认环境和进程数
ENV="test"
NUM_PROCESSES=1  # 默认进程数

# 解析命令行参数
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --env) ENV="$2"; shift ;;
        --workers) NUM_PROCESSES="$2"; shift ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
    shift
done
echo "使用环境: $ENV, 进程数: $NUM_PROCESSES"

# 获取脚本文件目录
BIN_DIR=$(dirname "$(readlink -f "$0")")
# 获取项目目录
PROJECT_DIR=$(dirname "$BIN_DIR")
echo "当前项目路径: $PROJECT_DIR"
# 进入目录
cd "$PROJECT_DIR"
echo "切换到项目目录: $PROJECT_DIR"
echo "拉取最新项目代码"
git pull
echo "切换虚拟环境"
source venv/bin/activate
echo "开始安装生产环境依赖"
uv sync --no-dev
echo "安装生产环境依赖完成"
echo "开始检查是否已存在运行中的进程"
pids=$(pgrep -f 'uv run --no-dev ${command} --env ${ENV}}$')
if [ -z "$pids" ]; then
  echo "无正在运行中的进程, 忽略"
else
  # 通过for循环遍历所有进程ID
  for pid in $pids; do
    echo "存在正在运行中的进程: $pid, 即将终止进程..."
    kill "$pid" # 使用引号以确保ID作为参数正确传递
    if [ $? -eq 0 ]; then
      echo "进程: $pid 已被成功终止"
    else
      echo "进程: $pid 终止失败"
    fi
  done
fi
# 执行命令
echo "开始执行命令"
for ((i=1; i<=NUM_PROCESSES; i++)); do
  nohup uv run --no-dev ${command} --env $ENV >> /dev/null 2>&1 &
done
echo "执行成功, 命令: uv run --no-dev ${command} --env $ENV"
''', project_name=project_name, command=command), override=override)

    if docker or docker_compose:
        dockerfile_file = project_dir + os.sep + cli_name + '.Dockerfile'
        create_file(dockerfile_file, str_format('''FROM python:3.9

# Install uv.
COPY --from=ghcr.nju.edu.cn/astral-sh/uv:latest /uv /uvx /bin/

COPY . /app

# 系统时区改为上海
RUN ln -snf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime && echo "Asia/Shanghai" > /etc/timezone

WORKDIR /app

RUN uv sync --no-dev

CMD uv run ${command} --env pro
''', command=command), override=override)

    if docker_compose:
        add_docker_compose_script(project_dir, str_format('''  ${cli_name}:
    container_name: ${project_name}_${cli_name}
    build:
      context: .
      dockerfile: ${cli_name}.Dockerfile
    image: ${project_name}_${cli_name}:latest
    volumes:
      - "./config:/app/config"
''', project_name=project_name, cli_name=cli_name))
