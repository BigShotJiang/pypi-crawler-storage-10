"""Coordinator tests."""
