# 🧙‍♂️ Sage: the senior dev in your terminal
![Sage welcome page.](./sage/public/sage_start_page.jpg "Sage welcome page snapshot.")
## 🤔 Why Sage?

- Claude Code, Codex CLI, and Cursor are **hella expensive**.  
- Most open-source “alternatives” are too complicated and cluttered doing too much for mid context engineering and agentic features they are have.  
- I wanted a CLI that could switch between **any model I want** at any moment (500+ models, 50+ free ones).
## ⚙️ What It Does

- Reads your project, **understands your codebase**, and helps you **write, refactor, and debug**  all without switching tabs or selling your kidney for a subscription.  
- And yeah, it’s not just for coding. You can even ask it **how to get a girlfriend?** and sage will help (no agentic actions for that   though, you gotta do that part yourself).
## ⬇️ How to Install

 ```
pip install sage-code
```

-	and then type 
```
sage
```
 in the terminal of the directory you created for your project (not in your downloads or desktop folder ).
- then you will see
``` Welcome! Setting up and analyzing your project now...```
- After that, just follow the terminal instructions.
- Grab your API key from  [OpenRouter](https://openrouter.ai/settings/keys), paste it in.
- select your favorite model,  and start building your next project.

## 🧩 How It Works
- The fundamental protocol is inspired by the hardest-working gatekeepers we all know.
- If you’re into papers and minimal math, the technique’s on [arXiv](https://arxiv.org/abs/2510.14881)
- The code is minimalist by design.
- Inside the sage folder, you’ll find:
```text
sage/
├── Starters/   : sets up the project, initializes the protocol, and provides context  
└── Core/       : handles the main agent orchestration and LLM communication 
```

- Programming ideology? **Procedural spaghetti.**
- **Trust me bro**  you can figure it out and customize it.
Just ask Sage itself (no ChatGPT though).
## 🤝 Oh btw,
- if you’re unemployed and got some time **to contribute** to this project:        
 - fork the repo,and make it cooler
 - or just add up to my spaghetti.I’ll be around to merge your PRs.
## 📢 Final Words
- Just the first version, built after work — so don’t be harsh on  babe.   
- Made with ❤️ by a brokie named Fikre.