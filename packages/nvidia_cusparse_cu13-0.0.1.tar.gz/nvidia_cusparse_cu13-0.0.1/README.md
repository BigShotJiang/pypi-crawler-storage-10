⚠️ THIS PROJECT 'nvidia-cusparse-cu13' IS DEPRECATED.
Please use 'nvidia-cusparse' instead.

To install the correct package, use:

    pip install nvidia-cusparse

For more information, visit: https://pypi.org/project/nvidia-cusparse/
