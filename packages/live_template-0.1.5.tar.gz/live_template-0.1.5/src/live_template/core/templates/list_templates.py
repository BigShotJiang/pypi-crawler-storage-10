text = """
📂 Templates list:
"""

parse_mode = "HTML"
buttons = []
