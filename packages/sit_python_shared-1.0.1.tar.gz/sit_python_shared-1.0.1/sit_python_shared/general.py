MESSAGE_TO_USER = ("You used 'import sit', but this is not a real SIT library. "
                   "Delete this library, check your JFRog settings and install it again")


def hello():
    print(MESSAGE_TO_USER)


print(MESSAGE_TO_USER)
