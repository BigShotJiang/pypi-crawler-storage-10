import httpx
from enum import Enum
from .retry import retry
from base64 import b64encode
from typing import Iterable



class APIClient:

    _DEFAULT_LIMITS = httpx.Limits(max_connections=10, max_keepalive_connections=5, keepalive_expiry=30.0)
    def __init__(
            self, timeout: float=15.0,
            limits: httpx.Limits=_DEFAULT_LIMITS):
        
        self.__client = httpx.AsyncClient(
            limits=limits,
            timeout=timeout,
            headers={"Accept-Encoding": "gzip"},
            follow_redirects=True
            )



    
    def _get_headers(self, api_key: str)->dict:
        if ":" in api_key:
            return {"Authorization": f"Basic {b64encode(api_key.encode()).decode()}"}
        return {"Authorization": f"Bearer {api_key}"}

    
    @retry
    async def _request(
            self,
            method: str, 
            api_key: str,
            url: str,
            params: dict | None=None,
            payload: dict | None=None)-> httpx.Response:

        headers = self._get_headers(api_key)
        
        request = self.__client.request(
            method=method,
            url=url,
            headers=headers,
            params=params,
            json=payload


        )

        response = await request
        return response
        


    
    async def get(
                self,
                api_key: str,
                url: str,
                params: dict | None = None)-> httpx.Response:
        response = await self._request(
            method='GET', 
            api_key=api_key,
            url=url,
            params=params
            )
        return response
        
    async def post(
            self,
            api_key: str,
            url: str,
            payload: dict | None=None,
            params: dict | None = None)-> httpx.Response:
        
        response = await self._request(
            method="POST", 
            api_key=api_key,
            url=url,
            payload=payload,
            params=params
            )
        return response
    
    async def put(
            self,
            api_key: str,
            url: str,
            payload: dict | None=None,
            params: dict | None = None)-> httpx.Response:
        
        response = await self._request(
            method="PUT", 
            api_key=api_key, 
            url=url,
            payload=payload,
            params=params
            )
        return response
    
    async def delete(
            self,
            api_key: str,
            url: str,
            params: dict | None = None)-> httpx.Response:
        
        response = await self._request(
            method="DELETE", 
            api_key=api_key,
            url=url,
            params=params
            )
        return response


    def __str__(self)->str:
        return f"{self.__class__.__name__}"

    async def aclose(self):
        await self.__client.aclose()

    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc, tb):
        await self.__client.aclose()
    

