from __future__ import annotations
from .objects_enum import MSObject
from .errors.errs import SingleParamError, ExpandDephError, SingleTargetError, SingleIdError
from urllib.parse import quote


class _URLExpression:
    """
    Helper class for building filter expressions in URL.
    """
    def __init__(
            self, 
            builder: URLbuilder,
            key: str,
            field: str,
            sep: str):
        
        self.__key = key
        self.__field = field
        self.__builder = builder
        self.__sep = sep
        

    def __add(self, value: str, sign: str):
        self.__builder._set_param(
            key=self.__key,
            subkey=self.__field,
            value=value,
            sep=self.__sep,
            sign=sign
        )
        return self.__builder
    
    def eq(self, value: str): return self.__add(value, '=')
    def ne(self, value: str): return self.__add(value, '!=')
    def gt(self, value: str): return self.__add(value, '>')
    def lt(self, value): return self.__add(value, '<')
    def gte(self, value): return self.__add(value, ">=")
    def lte(self, value): return self.__add(value, "<=")


class URLbuilder:
    """
    Universal URL builder for MoySklad API.
    """
    __BASE_URL = "https://api.moysklad.ru/api/remap/1.2"

    def __init__(
            self,
            ms_object_type: MSObject=None,
            document_id: str|None=None,
            base_url: str=__BASE_URL):
        
        """
        Initialize the URL builder.
        Args:
            ms_object_type (MSObject | None): MoySklad object type (e.g. product, customerorder).
            document_id (str | None): Document ID (optional).
            base_url (str): Base API URL.

        """
        
        self.__request_params = {}
        self.__base_url = base_url
        self.__target = None
        self.__document_id = document_id
        if(ms_object_type):
            self._set_target(ms_object_type)

    
    def _set_target(self, target: MSObject)->URLbuilder:
        if(self.__target):
            raise SingleTargetError(f"Can be only one type of target!")
        if isinstance(target, MSObject):
            self.__target = target.value
        else:
            raise TypeError(f'Target can be only MSObject type, {type(target)} given')
        return self  
    
    def document(self, ms_object_type: MSObject)->URLbuilder:
        """Select MoySklad object type (e.g. product, customerorder), can be only one type in instance"""
        return self._set_target(ms_object_type)
    
    def document_id(self, value: str)->URLbuilder:
        """Set document ID. can be only one id in instance"""
        if self.__document_id:
            raise SingleIdError(
                f"Can be only one ID for document, given two, {self.__document_id}")
        self.__document_id = value
        return self


    def _set_param(
            self,
            key: str,
            subkey: str,
            value: str,
            sep: str,
            sign: str)->URLbuilder:
        
        if self.get_param(key):
            self.add_param(key, f"{sep}{subkey}{sign}{value}") 
        else:
            self.set_param(key, f"{subkey}{sign}{value}")
        return self

    def _set_uniq_param(self, key: str, value: str)->URLbuilder:
        if self.get_param(key):
            raise SingleParamError(
            f"Only one instance of parameter '{key}' is allowed, "
            f"already set to '{self.get_param(key)}'.")
        self.set_param(key, value)
        return self

    def filter(self, field: str)->_URLExpression:
        """Start building filter expression. filter(field_name).eq(field_value)"""
        return _URLExpression(
            builder=self,
            key='filter',
            field=field,
            sep=','
        )

    def expand(self, *fields: str)->URLbuilder:
        """Add 'expand' parameter for nested entities. 
        Expand depth limited to three by MS example (demands.customerorders.salesChannel)
        """
        for field in fields:
            depth = len(field.split('.'))
            if depth > 3:
                raise ExpandDephError(
                f'Expand depth can be <= 3 {field} depth {depth}')
            if self.get_param('expand'):
                self.add_param(key='expand', value=f';{field}')
            elif not self.get_param('expand'):
                self.set_param(key='expand', value=f"{field}")
        return self

    def search(self, value: str, strictly=True)->URLbuilder:
        """Add search parameter
        It can be strictly=True, that means full entry (field=value)
        strictly=False with partical entry (field~=value)
        """
        self._set_uniq_param(
            key='search',
            value=f"{value}" if strictly else f"~{value}" 
        )
        return self
    

    def limit(self, value: int)->URLbuilder:
        """Set result limit. Limit must be set if expand used, expand max limit = 100"""
        self.set_param('limit', value)
        return self
    
    def offset(self, value: int)->URLbuilder:
        """Set pagination offset"""
        self.set_param('offset', value)
        return self
    

    
    def get_param(self, key: str)->str:
        """Get specific param"""
        return self.__request_params.get(str(key))
    
    def set_param(self, key: str, value: str)->URLbuilder:
        """Set specific param in params dict"""
        self.__request_params[str(key)] = value
        return self

    def add_param(self, key: str, value: str)->URLbuilder:
        """Append specific param for param in param dict"""
        if self.get_param(key):
            self.__request_params[key] += str(value)
        else:
            self.set_param(key, value)
        return self

    def encode_url(self, include_params=False)->str:
        """Return encoded URL."""
        if include_params:
            return quote(self.url_with_params, safe="/:?=&")
        return quote(self.url, safe="/:?=&")

    @property
    def params(self)->dict:
        """Return all params dict"""
        return self.__request_params
    

    @property
    def url(self)->str:
        """Return <base_url>/<document_type>/<document_id>"""

        return (
            f"{self.__base_url}"
            f"{f'/{self.__target}' if self.__target else ''}"
            f"{f'/{self.__document_id}' if self.__document_id else ''}"
            )

    @property
    def url_with_params(self)->str:
        """Return url with all params filter/expand/limit.."""
        query = "&".join(f"{k}={v}" for k, v in self.__request_params.items())
        return self.url + f"{'?' + query if query else ''}"

    
    
    @property
    def available_documents(self)->str:
        """Return all available MSObject types."""
        return MSObject.available_list()

    def __str__(self):
        return self.url

        


