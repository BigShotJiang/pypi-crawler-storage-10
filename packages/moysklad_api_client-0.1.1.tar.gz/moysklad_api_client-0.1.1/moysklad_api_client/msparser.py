import httpx
from functools import cached_property


class BaseEntityParser:
    def __init__(self, response: httpx.Response):
        self._json = response.json()

    def _get_required(self, key):
        try:
            return self.data[key]
        except KeyError:
            raise KeyError(f"Response does not contain required field '{key}'")
    
    def get_value(self, *keys):
        curr_val = self.data
        for key in keys:
            try:
                curr_val = curr_val[key]
            except (KeyError, TypeError):
                return None
        return curr_val

    @cached_property
    def data(self):
        return self._json
    
    @cached_property
    def meta(self):return self._get_required('meta')
    
    @cached_property
    def type(self):return self.meta.get('type')
    
    @cached_property
    def id(self): return self._get_required('id')
    
    @cached_property
    def name(self): return self._get_required('name')

    @cached_property
    def external_code(self): return self._get_required('externalCode')

    @cached_property
    def rows(self): return self.get_value('rows')





    



    