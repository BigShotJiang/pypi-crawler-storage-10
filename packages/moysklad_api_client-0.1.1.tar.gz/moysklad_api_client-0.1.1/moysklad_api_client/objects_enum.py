from enum import Enum

class MSObject(Enum):
    """
    Сущности (entity) из API МойСклад.

    Доступные значения:
    - counterparty
    - product
    - variant
    - bundle
    - supplier
    - demand
    - supply
    - invoicein
    - invoiceout
    - paymentin
    - paymentout
    - purchaseorder
    - customerorder
    - purchasereturn
    - salesreturn
    - loss
    - inventory
    - move
    - retaildemand
    - retailsalesreturn
    - retailshift
    - retailstore
    - project
    - store
    - consignment
    - task
    - productfolder
    - cashin
    - cashout
    - cashintake
    - processing
    - processingorder
    - processingplan

    Отчеты (report) из API МойСклад.

    # Остатки
    STOCK_ALL = "stock/all"                       # отчет «Остатки (полный)» :contentReference[oaicite:1]{index=1}
    STOCK_ALL_CURRENT = "stock/all/current"       # краткий вариант
    STOCK_BY_STORE = "stock/bystore"              # остатки по складам
    STOCK_BY_SLOT = "stock/byslot"                # остатки по ячейкам/слотам

    # Документы-номенклатура
    DOCUMENTS_ASSORTMENT_STOCK = "documents/assortment/stock"     # отчет «по документам: отображающий остатки» :contentReference[oaicite:2]{index=2}
    DOCUMENTS_ASSORTMENT_RESERVE = "documents/assortment/reserve" # отображающий резервы
    DOCUMENTS_ASSORTMENT_WAITING = "documents/assortment/waiting" # отображающий ожидания

    # Финансы / деньги
    MONEY_FLOW = "money/flow"                     # движение денежных средств
    MONEY_BALANCE = "money/balance"               # остатки денежных средств
    MONEY_CASHFLOW = "money/cashflow"             # возможно вариант «cashflow»

    # Продажи / заказы / показатели
    SALES_INDICATORS = "sales/indicators"         # показатели продаж
    ORDER_INDICATORS = "orders/indicators"        # показатели заказов
    COUNTERPARTY_INDICATORS = "counterparty/indicators"  # показатели контрагентов

    # Прибыльность / рентабельность
    PROFITABILITY = "profitability"               # отчёт прибыльности

    # Товарооборот
    TURNOVER_GOODS = "turnover/goods"             # товарооборот по товарам

    # Прочие отчёты (примерные)
    INVENTORY_TURNOVER = "inventory/turnover"     # смена/оборачиваемость запасов
    SALES_BY_PRODUCT = "sales/byproduct"           # продажи по товарам
    SALES_BY_STORE = "sales/bystore"               # продажи по складам/точкам
    COST_BY_PRODUCT = "cost/byproduct"             # себестоимость по товарам
    """
    counterparty = "entity/counterparty"
    product = "entity/product"
    variant = "entity/variant"
    bundle = "entity/bundle"
    supplier = "entity/supplier"
    demand = "entity/demand"
    supply = "entity/supply"
    invoicein = "entity/invoicein"
    invoiceout = "entity/invoiceout"
    paymentin = "entity/paymentin"
    paymentout = "entity/paymentout"
    purchaseorder = "entity/purchaseorder"
    customerorder = "entity/customerorder"
    purchasereturn = "entity/purchasereturn"
    salesreturn = "entity/salesreturn"
    loss = "entity/loss"
    inventory = "entity/inventory"
    move = "entity/move"
    retaildemand = "entity/retaildemand"
    retailsalesreturn = "entity/retailsalesreturn"
    retailshift = "entity/retailshift"
    retailstore = "entity/retailstore"
    project = "entity/project"
    store = "entity/store"
    consignment = "entity/consignment"
    task = "entity/task"
    productfolder = "entity/productfolder"
    cashin = "entity/cashin"
    cashout = "entity/cashout"
    cashintake = "entity/cashintake"
    processing = "entity/processing"
    processingorder = "entity/processingorder"
    processingplan = "entity/processingplan"
    STOCK_ALL = "stock/all"                       
    STOCK_ALL_CURRENT = "stock/all/current"      
    STOCK_BY_STORE = "stock/bystore"              
    STOCK_BY_SLOT = "stock/byslot"                
    DOCUMENTS_ASSORTMENT_STOCK = "documents/assortment/stock"     
    DOCUMENTS_ASSORTMENT_RESERVE = "documents/assortment/reserve" 
    DOCUMENTS_ASSORTMENT_WAITING = "documents/assortment/waiting" 
    MONEY_FLOW = "money/flow"                     
    MONEY_BALANCE = "money/balance"              
    MONEY_CASHFLOW = "money/cashflow"             
    SALES_INDICATORS = "sales/indicators"         
    ORDER_INDICATORS = "orders/indicators"        
    COUNTERPARTY_INDICATORS = "counterparty/indicators"  
    PROFITABILITY = "profitability"              
    TURNOVER_GOODS = "turnover/goods"             
    INVENTORY_TURNOVER = "inventory/turnover"     
    SALES_BY_PRODUCT = "sales/byproduct"           
    SALES_BY_STORE = "sales/bystore"               
    COST_BY_PRODUCT = "cost/byproduct"             

    @classmethod
    def available_list(cls):
        return '\n'.join([f"{i}: {i.value}" for i in cls])
