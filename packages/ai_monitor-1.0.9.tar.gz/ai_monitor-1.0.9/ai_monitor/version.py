"""Version information for ai-monitor package."""

__version__ = "1.0.9"
__version_info__ = (1, 0, 9)
