"""MCP Prompts for Halo blog management."""

from .blog_prompts import BLOG_PROMPTS

__all__ = ["BLOG_PROMPTS"]
