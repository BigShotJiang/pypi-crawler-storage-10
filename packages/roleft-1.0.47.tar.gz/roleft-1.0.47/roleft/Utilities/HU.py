import requests


def get_html_content(url: str = "http://www.baidu.com") -> str:
    return requests.get(url).text
