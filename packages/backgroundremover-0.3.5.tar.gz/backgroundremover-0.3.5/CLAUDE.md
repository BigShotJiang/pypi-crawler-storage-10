# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

BackgroundRemover is a command-line tool and Python library that removes backgrounds from images and videos using AI-based U-Net models. It supports multiple output formats including transparent videos (.mov), GIFs, and matte keys for video editing software.

## Development Commands

### Installation and Setup

```bash
# Install in development mode
pip install --upgrade pip
pip install -e .

# Install dependencies
pip install -r requirements.txt

# Run without installing (development)
python -m backgroundremover.cmd.cli -i "input.jpg" -o "output.png"
```

### Testing the CLI

```bash
# Test image background removal
backgroundremover -i "path/to/image.jpg" -o "output.png"

# Test video with matte key
backgroundremover -i "path/to/video.mp4" -mk -o "output.mov"

# Test with alpha matting (better quality)
backgroundremover -i "path/to/image.jpg" -a -ae 15 -o "output.png"

# Test different models
backgroundremover -i "path/to/image.jpg" -m "u2net_human_seg" -o "output.png"

# Test folder processing
backgroundremover -if "input_folder" -of "output_folder"
```

### Building and Distribution

```bash
# Build distribution packages
python setup.py sdist bdist_wheel

# Docker build
docker build -t bgremover .
docker run -it --rm -v "$(pwd):/tmp" bgremover:latest -i "input.jpg" -o "output.png"
```

## Architecture

### Core Components

**Entry Point**: `backgroundremover/cmd/cli.py`
- Main command-line interface with argparse
- Handles both single file and folder batch processing
- Routes to appropriate processing function based on file type and flags

**Background Removal**: `backgroundremover/bg.py`
- `remove()`: Core function for image background removal
- `Net`: PyTorch model wrapper that handles model loading and inference
- `alpha_matting_cutout()`: Advanced alpha matting for better edge quality
- `naive_cutout()`: Fast cutout without alpha matting
- Device detection logic (CUDA/MPS/CPU) for optimal performance

**Video Processing**: `backgroundremover/utilities.py`
- `matte_key()`: Generates matte key files (green screen) for video editors
- `transparentvideo()`: Creates transparent .mov files
- `transparentgif()`: Creates transparent GIFs
- `transparentvideoovervideo()`: Overlays transparent video over another video
- `transparentvideooverimage()`: Overlays transparent video over static image
- Multiprocessing architecture with worker pools for parallel frame processing

**Model Management**: `backgroundremover/u2net/`
- `detect.py`: Model loading and prediction logic
- `u2net.py`: U-Net neural network architecture definitions
- `data_loader.py`: Image preprocessing and data transformations

**Model Download**: `backgroundremover/github.py`
- Downloads U2Net models from GitHub repository on first run
- Models stored in `~/.u2net/` directory
- Supports three models: u2net, u2net_human_seg, u2netp

### Model Types

1. **u2net**: General purpose background removal (default)
2. **u2net_human_seg**: Optimized for human segmentation
3. **u2netp**: Lightweight version for faster processing

### Video Processing Architecture

The video processing system uses a multi-worker architecture:

1. **Frame Ripper Worker**: Extracts frames from video using moviepy
2. **Processing Workers**: Multiple GPU/CPU workers process frames in parallel batches
3. **Frame Buffer**: Shared dictionary managing frame data between workers
4. **Result Aggregation**: Collects processed frames and pipes to ffmpeg

Key parameters:
- `worker_nodes`: Number of parallel workers (default: 1)
- `gpu_batchsize`: Batch size for GPU processing (default: 2)
- `framerate`: Override detected framerate
- `framelimit`: Limit frames for testing

### Device Detection

The codebase automatically detects and uses the best available device:
1. CUDA (NVIDIA GPU) if available
2. MPS (Apple Silicon GPU) if available
3. CPU as fallback

This is set in `backgroundremover/bg.py` via the `DEVICE` global variable.

### Alpha Matting

Alpha matting improves edge quality by:
1. Creating a trimap (foreground/background/unknown regions)
2. Using binary erosion to refine boundaries
3. Estimating alpha channel with closed-form matting
4. Estimating foreground colors

Parameters:
- `-af`: Foreground threshold (default: 240)
- `-ab`: Background threshold (default: 10)
- `-ae`: Erosion structure size (default: 10)
- `-az`: Base size for processing (default: 1000)

## Key Implementation Details

### Model Loading

Models are downloaded on first use and cached in `~/.u2net/`. Large models (u2net, u2net_human_seg) are split into multiple parts and concatenated during download.

### Video Frame Processing

Videos are resized to 320px height for processing to balance speed and quality. The multiprocessing architecture ensures efficient GPU utilization by processing frames in batches while the frame ripper continues extracting frames.

### FFmpeg Integration

The tool heavily relies on ffmpeg for:
- Video frame extraction (via moviepy wrapper)
- Alpha channel merging (`alphamerge` filter)
- Format conversion and encoding
- Overlay composition

### Library Usage

The `remove()` function in `backgroundremover/bg.py` can be imported and used programmatically:

```python
from backgroundremover.bg import remove

with open("input.jpg", "rb") as f:
    data = f.read()

result = remove(data, model_name="u2net", alpha_matting=True)

with open("output.png", "wb") as f:
    f.write(result)
```

## Dependencies

Critical dependencies:
- **torch/torchvision**: Neural network inference
- **moviepy**: Video frame extraction
- **ffmpeg-python**: FFmpeg command generation
- **pymatting**: Alpha matting algorithms
- **PIL/Pillow**: Image processing
- **scikit-image**: Image manipulation utilities

## Common Issues

1. **Python version**: Supports Python 3.6+ (recently updated for Python 3.12 compatibility)
2. **FFmpeg requirement**: Must have ffmpeg 4.4+ installed and in PATH
3. **Model download**: First run requires internet connection to download models
4. **Memory usage**: Video processing can be memory-intensive; adjust `gpu_batchsize` and `worker_nodes` accordingly
5. **Multiprocessing**: Uses 'spawn' method for cross-platform compatibility
