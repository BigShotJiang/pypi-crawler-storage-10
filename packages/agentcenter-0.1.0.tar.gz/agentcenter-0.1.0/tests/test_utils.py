"""Tests for utility functions."""

import logging

from agentcenter.utils import format_response, setup_logging, validate_input


def test_validate_input_valid():
    """Test input validation with valid input."""
    assert validate_input("Hello") is True
    assert validate_input("A" * 100) is True


def test_validate_input_invalid():
    """Test input validation with invalid input."""
    assert validate_input("") is False
    assert validate_input("A" * 1001) is False
    assert validate_input(123) is False


def test_validate_input_edge_cases():
    """Test input validation edge cases."""
    # Exact min length
    assert validate_input("A", min_length=1) is True

    # Exact max length
    assert validate_input("A" * 1000, max_length=1000) is True

    # Just under min (empty after strip)
    assert validate_input("   ", min_length=1) is False

    # Just over max
    assert validate_input("A" * 1001, max_length=1000) is False

    # Custom min/max
    assert validate_input("Hello", min_length=3, max_length=10) is True
    assert validate_input("Hi", min_length=3, max_length=10) is False
    assert validate_input("Hello World!", min_length=3, max_length=10) is False


def test_validate_input_whitespace_handling():
    """Test that validate_input strips whitespace."""
    # Leading/trailing whitespace should be stripped
    assert validate_input("  Hello  ", min_length=5, max_length=5) is True
    assert validate_input("  Hello  ", min_length=7, max_length=10) is False


def test_validate_input_non_string_types():
    """Test validate_input with non-string types."""
    assert validate_input(None) is False
    assert validate_input(123) is False
    assert validate_input(12.34) is False
    assert validate_input([]) is False
    assert validate_input({}) is False
    assert validate_input(True) is False


def test_format_response():
    """Test response formatting."""
    data = {"key1": "value1", "key2": "value2"}
    result = format_response(data)
    assert "key1: value1" in result
    assert "key2: value2" in result


def test_format_response_empty_dict():
    """Test format_response with empty dict."""
    data = {}
    result = format_response(data)
    assert result == ""


def test_format_response_single_item():
    """Test format_response with single item."""
    data = {"name": "Agent"}
    result = format_response(data)
    assert result == "name: Agent"


def test_format_response_multiple_items():
    """Test format_response with multiple items."""
    data = {"name": "Agent", "version": "1.0", "status": "active"}
    result = format_response(data)

    lines = result.split("\n")
    assert len(lines) == 3
    assert "name: Agent" in result
    assert "version: 1.0" in result
    assert "status: active" in result


def test_format_response_with_different_value_types():
    """Test format_response with different value types."""
    data = {"string": "text", "number": 42, "float": 3.14, "bool": True, "none": None}
    result = format_response(data)

    assert "string: text" in result
    assert "number: 42" in result
    assert "float: 3.14" in result
    assert "bool: True" in result
    assert "none: None" in result


def test_setup_logging_default_level(caplog):
    """Test setup_logging with default level."""
    # Use caplog to verify logging is configured
    with caplog.at_level(logging.INFO):
        setup_logging()
        logger = logging.getLogger("test")
        logger.info("Test message")
        assert "Test message" in caplog.text


def test_setup_logging_debug_level(caplog):
    """Test setup_logging with DEBUG level."""
    with caplog.at_level(logging.DEBUG):
        setup_logging("DEBUG")
        logger = logging.getLogger("test_debug")
        logger.debug("Debug message")
        assert "Debug message" in caplog.text


def test_setup_logging_warning_level(caplog):
    """Test setup_logging with WARNING level."""
    with caplog.at_level(logging.WARNING):
        setup_logging("WARNING")
        logger = logging.getLogger("test_warning")
        logger.warning("Warning message")
        assert "Warning message" in caplog.text


def test_setup_logging_error_level(caplog):
    """Test setup_logging with ERROR level."""
    with caplog.at_level(logging.ERROR):
        setup_logging("ERROR")
        logger = logging.getLogger("test_error")
        logger.error("Error message")
        assert "Error message" in caplog.text


def test_setup_logging_critical_level(caplog):
    """Test setup_logging with CRITICAL level."""
    with caplog.at_level(logging.CRITICAL):
        setup_logging("CRITICAL")
        logger = logging.getLogger("test_critical")
        logger.critical("Critical message")
        assert "Critical message" in caplog.text


def test_setup_logging_case_insensitive():
    """Test setup_logging is case insensitive."""
    # Test that it doesn't raise an error with lowercase
    setup_logging("debug")
    setup_logging("info")
    setup_logging("warning")
    # If no exception raised, test passes


def test_setup_logging_info_level(caplog):
    """Test setup_logging with INFO level."""
    with caplog.at_level(logging.INFO):
        setup_logging("INFO")
        logger = logging.getLogger("test_info")
        logger.info("Info message")
        assert "Info message" in caplog.text
