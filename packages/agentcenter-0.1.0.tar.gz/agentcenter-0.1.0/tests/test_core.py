"""Tests for core functionality."""

from agentcenter.core import AgentCenter


def test_agent_center_init():
    """Test AgentCenter initialization."""
    agent = AgentCenter(name="TestAgent")
    assert agent.name == "TestAgent"
    assert len(agent.messages) == 0


def test_add_message():
    """Test adding messages."""
    agent = AgentCenter()
    agent.add_message("Hello", is_user=True)
    assert len(agent.messages) == 1


def test_process():
    """Test processing input."""
    agent = AgentCenter()
    response = agent.process("Test input")
    assert "Processed" in response
    assert len(agent.messages) == 2  # User message + AI response


def test_clear_messages():
    """Test clearing messages."""
    agent = AgentCenter()
    agent.add_message("Test", is_user=True)
    agent.clear_messages()
    assert len(agent.messages) == 0


def test_get_messages():
    """Test getting messages."""
    agent = AgentCenter()
    agent.add_message("Message 1", is_user=True)
    agent.add_message("Message 2", is_user=False)
    messages = agent.get_messages()
    assert len(messages) == 2
