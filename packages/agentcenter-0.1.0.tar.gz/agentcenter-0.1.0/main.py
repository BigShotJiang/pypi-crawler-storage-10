def main():
    print("Hello from agentcenter!")


if __name__ == "__main__":
    main()
