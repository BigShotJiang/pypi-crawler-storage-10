# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project structure
- Core AgentCenter class with basic functionality
- Configuration management with Pydantic
- Utility functions for logging and validation
- Comprehensive test suite
- CLI interface for interactive and single-message modes
- Documentation (Getting Started, API docs)
- Development scripts for testing and code formatting

## [0.1.0] - 2025-10-27

### Added
- Initial release
- Basic project setup with uv
- LangChain integration
