"""Core functionality for Agent Center."""

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage


class AgentCenter:
    """Main agent center class for managing LangChain agents."""

    def __init__(self, name: str = "AgentCenter"):
        """Initialize the AgentCenter.

        Args:
            name: Name of the agent center
        """
        self.name = name
        self.messages: list[BaseMessage] = []

    def add_message(self, content: str, is_user: bool = True) -> None:
        """Add a message to the conversation history.

        Args:
            content: Message content
            is_user: Whether the message is from the user
        """
        message = HumanMessage(content=content) if is_user else AIMessage(content=content)
        self.messages.append(message)

    def get_messages(self) -> list[BaseMessage]:
        """Get all messages in the conversation.

        Returns:
            List of messages
        """
        return self.messages

    def clear_messages(self) -> None:
        """Clear all messages from the conversation history."""
        self.messages.clear()

    def process(self, input_text: str) -> str:
        """Process input text and return a response.

        Args:
            input_text: Input text to process

        Returns:
            Processed response
        """
        self.add_message(input_text, is_user=True)

        # TODO: Implement actual LangChain agent logic here
        response = f"Processed: {input_text}"

        self.add_message(response, is_user=False)
        return response
