"""Command-line interface for Agent Center."""

import argparse
import sys

from agentcenter import AgentCenter
from agentcenter.config import get_settings
from agentcenter.utils import setup_logging


def main(args: list | None = None) -> int:
    """Main CLI entry point.

    Args:
        args: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Exit code
    """
    parser = argparse.ArgumentParser(
        description="Agent Center - LangChain Agent Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )

    parser.add_argument(
        "-n",
        "--name",
        type=str,
        default="AgentCenter",
        help="Name of the agent (default: AgentCenter)",
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode",
    )

    parser.add_argument(
        "message",
        nargs="?",
        type=str,
        help="Message to process",
    )

    parsed_args = parser.parse_args(args)

    # Setup logging
    settings = get_settings()
    log_level = "DEBUG" if parsed_args.debug else settings.log_level
    setup_logging(log_level)

    # Create agent
    agent = AgentCenter(name=parsed_args.name)

    # Interactive mode if no message provided
    if not parsed_args.message:
        print(f"Welcome to {agent.name}!")
        print("Type your messages (or 'quit' to exit):\n")

        while True:
            try:
                user_input = input("> ")
                if user_input.lower() in ["quit", "exit", "q"]:
                    print("Goodbye!")
                    break

                response = agent.process(user_input)
                print(f"\n{response}\n")

            except KeyboardInterrupt:
                print("\nGoodbye!")
                break
            except Exception as e:
                print(f"Error: {e}")
                return 1

    else:
        # Process single message
        response = agent.process(parsed_args.message)
        print(response)

    return 0


if __name__ == "__main__":
    sys.exit(main())
