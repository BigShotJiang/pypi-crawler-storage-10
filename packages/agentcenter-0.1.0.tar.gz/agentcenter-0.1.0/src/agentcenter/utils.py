"""Utility functions for Agent Center."""

import logging
from typing import Any


def setup_logging(log_level: str = "INFO") -> None:
    """Setup logging configuration.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def format_response(data: dict[str, Any]) -> str:
    """Format response data as a string.

    Args:
        data: Data to format

    Returns:
        Formatted string
    """
    lines = []
    for key, value in data.items():
        lines.append(f"{key}: {value}")
    return "\n".join(lines)


def validate_input(text: str, min_length: int = 1, max_length: int = 1000) -> bool:
    """Validate input text.

    Args:
        text: Text to validate
        min_length: Minimum length
        max_length: Maximum length

    Returns:
        True if valid, False otherwise
    """
    if not isinstance(text, str):
        return False
    return min_length <= len(text.strip()) <= max_length
