#!/bin/bash
# Format and lint code

set -e

echo "Formatting code with Black..."
uv run black src/ tests/

echo ""
echo "Linting with Ruff..."
uv run ruff check src/ tests/ --fix

echo ""
echo "Type checking with Mypy..."
uv run mypy src/

echo ""
echo "All checks passed!"
