#!/bin/bash
# Run tests with coverage report

set -e

echo "Running tests with coverage..."
uv run pytest --cov=agentcenter --cov-report=term-missing --cov-report=html

echo ""
echo "Coverage report generated in htmlcov/index.html"
