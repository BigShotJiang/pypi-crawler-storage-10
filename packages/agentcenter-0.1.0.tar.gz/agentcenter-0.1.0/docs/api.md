# API Documentation

## Core Classes

### AgentCenter

Main class for managing LangChain agents.

#### Constructor

```python
AgentCenter(name: str = "AgentCenter")
```

**Parameters:**
- `name` (str): Name of the agent center. Default: "AgentCenter"

#### Methods

##### process

```python
def process(input_text: str) -> str
```

Process input text and return a response.

**Parameters:**
- `input_text` (str): Input text to process

**Returns:**
- str: Processed response

**Example:**
```python
agent = AgentCenter()
response = agent.process("Hello!")
```

##### add_message

```python
def add_message(content: str, is_user: bool = True) -> None
```

Add a message to the conversation history.

**Parameters:**
- `content` (str): Message content
- `is_user` (bool): Whether the message is from the user. Default: True

##### get_messages

```python
def get_messages() -> List[BaseMessage]
```

Get all messages in the conversation.

**Returns:**
- List[BaseMessage]: List of messages

##### clear_messages

```python
def clear_messages() -> None
```

Clear all messages from the conversation history.

## Configuration

### Settings

Configuration class using Pydantic.

**Attributes:**
- `app_name` (str): Application name
- `debug` (bool): Debug mode
- `log_level` (str): Logging level
- `api_key` (Optional[str]): API key for external services

**Example:**
```python
from agentcenter.config import get_settings

settings = get_settings()
print(settings.app_name)
```

## Utilities

### setup_logging

```python
def setup_logging(log_level: str = "INFO") -> None
```

Setup logging configuration.

### validate_input

```python
def validate_input(text: str, min_length: int = 1, max_length: int = 1000) -> bool
```

Validate input text.

### format_response

```python
def format_response(data: Dict[str, Any]) -> str
```

Format response data as a string.
