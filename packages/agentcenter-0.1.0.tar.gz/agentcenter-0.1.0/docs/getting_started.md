# Getting Started with Agent Center

This guide will help you get started with Agent Center.

## Installation

First, ensure you have Python 3.12+ and [uv](https://docs.astral.sh/uv/) installed.

Install the project dependencies:

```bash
uv sync
```

## Basic Usage

### Using the Python API

```python
from agentcenter import AgentCenter

# Create an agent instance
agent = AgentCenter(name="MyAgent")

# Process a message
response = agent.process("Hello, how are you?")
print(response)

# View conversation history
for message in agent.get_messages():
    print(f"{message.__class__.__name__}: {message.content}")
```

### Using the CLI

Interactive mode:
```bash
uv run agentcenter
```

Single message mode:
```bash
uv run agentcenter "Your message here"
```

With custom agent name:
```bash
uv run agentcenter --name "CustomAgent" "Your message"
```

## Configuration

Create a `.env` file in the project root:

```env
APP_NAME=Agent Center
DEBUG=false
LOG_LEVEL=INFO
API_KEY=your-api-key-here
```

## Next Steps

- Check out the [API documentation](api.md)
- Learn about [advanced features](advanced.md)
- See [examples](examples.md) for common use cases
