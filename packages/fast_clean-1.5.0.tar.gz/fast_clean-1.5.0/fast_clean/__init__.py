"""
FastAPI clean architecture implementation.
"""
