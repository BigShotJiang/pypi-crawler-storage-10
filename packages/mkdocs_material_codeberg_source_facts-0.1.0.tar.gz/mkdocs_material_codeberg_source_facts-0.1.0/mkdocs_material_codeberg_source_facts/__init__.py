import os

from mkdocs.plugins import BasePlugin
from mkdocs.structure.files import Files, File

from mkdocs.config import base

file_base_path = os.path.dirname(os.path.abspath(__file__))


class PluginConfig(base.Config): ...


class Plugin(BasePlugin[PluginConfig]):
    def on_config(self, config):
        config.extra_javascript.append(
            "assets/javascript/add_source_facts_from_codeberg.js"
        )

    def on_files(self, files: Files, /, *, config) -> Files | None:
        file = File(
            "add_source_facts_from_codeberg.js",
            file_base_path,
            os.path.join(config["site_dir"], "assets/javascript"),
            config["use_directory_urls"],
        )

        files.append(file)

        return files
