//
// code adapted from
// https://github.com/squidfunk/mkdocs-material/issues/5942
//

document$.subscribe(async () => {
  const repo_stats = document.querySelector(
    '[data-md-component="source"] .md-source__repository',
  );

  const repo_url = repo_stats.parentElement.href;

  const match = repo_url.match(/^.+codeberg\.org\/([^/]+)\/?([^/]+)?/i);

  if (!match) {
    console.error("Not a codeberg repo");
    return;
  }

  const [_, owner, repo] = match;
  const url = `https://codeberg.org/api/v1/repos/${owner}/${repo}`;

  function displayInfo(data) {
    const facts = document.createElement("ul");
    facts.className = "md-source__facts";

    for (const type of ["version", "stars", "forks"]) {
      const el = document.createElement("li");
      el.className = `md-source__fact md-source__fact--${type}`;
      el.innerText = data[type];
      facts.appendChild(el);
    }

    repo_stats.appendChild(facts);
  }

  async function determineReleaseName(result) {
    const data = await result.json();
    if (data?.message || data.length == 0) {
      return "---";
    }
    return data[0].name;
  }

  async function fetchInfo() {
    const [releaseName, repo] = await Promise.all([
      fetch(`${url}/releases?limit=1`).then(determineReleaseName),
      fetch(`${url}`).then((_) => _.json()),
    ]);

    const data = {
      version: releaseName,
      stars: repo.stars_count,
      forks: repo.forks_count,
    };

    __md_set("__git_repo", data, sessionStorage);
    displayInfo(data);
  }

  if (!repo_stats.querySelector(".md-source__facts")) {
    // const cached = __md_get("__git_repo", sessionStorage);
    const cached = null;
    if (cached != null && cached["version"]) {
      displayInfo(cached);
    } else {
      fetchInfo();
    }
  }
});
