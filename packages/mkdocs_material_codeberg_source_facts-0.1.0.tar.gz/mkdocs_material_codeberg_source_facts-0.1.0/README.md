# mkdocs-material-codeberg-source-facts

Adds support to mkdocs-material to parse codeberg source facts
following [https://github.com/squidfunk/mkdocs-material/issues/5942](https://github.com/squidfunk/mkdocs-material/issues/5942).

