# mkdocs-material-codeberg-source-facts

This plugin allows you to display the source facts from codeberg.
For example without this plugin one has

![Just a single line](./assets/no_plugin.png)

and afterwards

![Stars and Forks are displayed on second line](./assets/with_plugin.png)

## Installation

Install via

```bash
pip install mkdocs-material-codeberg-source-facts
```

## Configuration

Add to your `plugins` in `mkdocs.yml`

```yaml title="mkdocs.yml"
plugins:
  - codeberg-source-facts
  - search

```

## Development

The heavy lifting is done in [mkdocs_material_codeberg_source_facts/add_source_facts_from_codeberg.js](https://codeberg.org/helge/mkdocs-material-codeberg-source-facts/src/branch/main/mkdocs_material_codeberg_source_facts/add_source_facts_from_codeberg.js).
This file is currently test free and manually maintained, so __please take care__ when modifying.

In addition to better code quality and tests, a change that would be appreciated is support
for general forgejo, gitea instances. This might be simple, but as I would be unable to test
it, I refrained from trying.
