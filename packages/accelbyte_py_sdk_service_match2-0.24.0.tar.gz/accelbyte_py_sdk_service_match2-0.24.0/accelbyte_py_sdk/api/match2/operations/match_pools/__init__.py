# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Match Service V2."""

__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .admin_get_match_pool_tickets import AdminGetMatchPoolTickets
from .create_match_pool import CreateMatchPool
from .delete_match_pool import DeleteMatchPool
from .get_player_metric import GetPlayerMetric
from .match_pool_details import MatchPoolDetails
from .match_pool_list import MatchPoolList
from .match_pool_metric import MatchPoolMetric
from .post_match_error_metric import PostMatchErrorMetric
from .public_get_player_metric import PublicGetPlayerMetric
from .update_match_pool import UpdateMatchPool
