from __future__ import annotations

import threading
from typing import Any, Dict, List
import queue
from enum import Enum

from appdynamics.agent.core.logs import setup_logger
from appdynamics.agent.services.event_service_client import EventServiceClient


class EventServiceSink(threading.Thread):
    """
    Sink thread per event type that drains the EventProcessor queue, ensures schema
    registration, publishes batches with retry semantics, and applies an optional
    long pause on persistent failures.
    """

    class PublishOutcome(Enum):
        SUCCESS = 'SUCCESS'
        DROP = 'DROP'
        RETRY_NORMAL = 'RETRY_NORMAL'
        RETRY_LONG = 'RETRY_LONG'

    def __init__(self, *, agent: Any, event_type: str, config: Any, signal: Any, 
        event_queue: queue.Queue[Dict[str, Any]]):
        super(EventServiceSink, self).__init__(
            name=f"EventServiceSink[{event_type}]"
        )
        self.agent = agent
        self.event_type = event_type
        self.config = config
        self.signal = signal
        self.event_queue = event_queue
        self.running = True
        self.client = EventServiceClient(agent)
        self.pause_event = threading.Event()
        self.schema_registered = False
        self.schema_registration_attempted = False

    def stop(self) -> None:
        self.running = False
        self.signal.set()
        self.pause_event.set()

    def run(self) -> None:
        try:
            while self.running:
                # Wait for either signal or timeout to form a batch
                self.signal.wait(self.config.max_wait_seconds)

                batch = self._pop_batch(self.config.chunk_size)
                # Clear the signal after draining attempt
                self.signal.clear()
                if not batch:
                    continue
                self._process_batch(batch)
        except Exception:
            self.agent.logger.error('EventServiceSink stopped due to unhandled error for %s', self.event_type)

    def _ensure_schema_registered(self) -> bool:
        if self.schema_registered:
            return True

        # If registration has been attempted as CONFLICT(#409) was seen, try update_schema
        if self.schema_registration_attempted:
            self._update_schema_flow()
            return self.schema_registered

        self._register_schema_flow()
        return self.schema_registered

    def _register_schema_flow(self):
        url = self.config.register_url
        headers = self.config.request_headers
        payload = self.config.schema_payload
        status, _ = self.client.post_json(url, payload, headers, method='POST')
        if status in (200, 202):  # OK/ACCEPTED
            self.schema_registered = True
            self.agent.logger.debug('Schema registered for %s', self.event_type)
            return
        if status == 409:  # CONFLICT
            self.schema_registration_attempted = True
            self.agent.logger.warn('Schema registration conflict for %s; will attempt update_schema on next cycle', self.event_type)
            self._open_normal_pause()
            return
        if status == 406:  # NOT_ACCEPTABLE (license/limit)
            # License limit: long pause
            self.agent.logger.error('Schema registration returned 406 (license limit). Long pause requested for %s', self.event_type)
            self._open_long_pause()
            return
        # Other non-2xx: normal pause
        self._open_normal_pause()
        return

    def _update_schema_flow(self):
        url = self.config.register_url
        headers = self.config.request_headers
        payload = self.config.schema_payload
        status, _ = self.client.post_json(url, payload, headers, method='PUT')
        if status in (200, 202):  # OK/ACCEPTED
            self.schema_registered = True
            self.agent.logger.debug('Schema updated for %s', self.event_type)
            return
        # Other non-2xx: normal pause
        self._open_normal_pause()
        return

    def _publish_batch(self, batch: List[Dict[str, Any]]) -> "EventServiceSink.PublishOutcome":
        url = self.config.publish_url
        headers = self.config.request_headers
        status, response_data = self.client.post_json(url, batch, headers, method='POST')

        if status in (200, 202):  # OK/ACCEPTED
            self.agent.logger.debug('Published %d events for %s', len(batch), self.event_type)
            return EventServiceSink.PublishOutcome.SUCCESS

        if status == 400:  # BAD_REQUEST
            # Permanent failure: drop, no backoff
            self.agent.logger.error('Publish returned 400 (permanent). Dropping %d events for %s, reason: %s',
                              len(batch), self.event_type, response_data)
            return EventServiceSink.PublishOutcome.DROP

        if status == 406:  # NOT_ACCEPTABLE (license/limit)
            # License limit: long pause requested
            self.agent.logger.error('Publish returned 406 (license limit). Long pause requested for %s, reason: %s', self.event_type, response_data)
            return EventServiceSink.PublishOutcome.RETRY_LONG

        # Other non-2xx
        self.agent.logger.warn('Publish failed (status=%s) for %s, reason: %s',
                            status, self.event_type, response_data)
        return EventServiceSink.PublishOutcome.RETRY_NORMAL


    def _process_batch(self, batch: List[Dict[str, Any]]) -> None:
        """Retry loop : keep the current batch in-memory and 
        retry registration/publish with appropriate pauses
        until success or a permanent drop condition occurs."""
        send_attempt_max = self.config.send_attempt_max
        try:
            while self.running:
                send_attempt_max -= 1
                # open long pause if send_attempt_max gets to 0 and reset to max value
                if send_attempt_max < 0:
                    self.agent.logger.warn('Send attempt max reached for %s. Long pause requested. Resetting send attempt max to %d', self.event_type, self.config.send_attempt_max)
                    self._open_long_pause()
                    send_attempt_max = self.config.send_attempt_max
                    continue
                # Ensure schema is registered
                if not self._ensure_schema_registered():
                    continue

                outcome = self._publish_batch(batch)
                self.agent.logger.debug(f'Publish batch outcome for {self.event_type}: Outcome: {outcome}')
                if outcome == EventServiceSink.PublishOutcome.SUCCESS:
                    return
                if outcome == EventServiceSink.PublishOutcome.DROP:
                    return
                if outcome == EventServiceSink.PublishOutcome.RETRY_LONG:
                    self._open_long_pause()
                else:
                    self._open_normal_pause()
        except Exception as exc:
            self.agent.logger.error('Error while processing batch for %s: %s, dropping batch', self.event_type, str(exc))
            return

    def _open_long_pause(self) -> None:
        pause_sec = int(self.config.long_pause_pause_seconds)
        self.pause_event.clear()
        self.agent.logger.debug('Opening long pause for event type %s for %s seconds', self.event_type, pause_sec)
        self.pause_event.wait(pause_sec)

    def _open_normal_pause(self) -> None:
        self.pause_event.clear()
        self.agent.logger.debug('Opening normal pause for event type %s for %s seconds', self.event_type, self.config.normal_pause_seconds)
        self.pause_event.wait(float(self.config.normal_pause_seconds))


    def _pop_batch(self, max_items: int) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []

        if self.event_queue.empty():
            return items
        for _ in range(max_items):
            try:
                items.append(self.event_queue.get_nowait())
            except Exception:
                break
        return items

