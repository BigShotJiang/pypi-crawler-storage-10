from __future__ import annotations

import json
from typing import Any, Dict, Optional, Tuple
import time
import ssl
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from appdynamics.agent.core.logs import setup_logger
from appdynamics import config


class EventServiceClient:
    """
    Thin HTTP client to send JSON POST requests for event schema registration
    and batch publishing. Keeps networking concerns out of the sink logic.
    """

    def __init__(self, agent: Any) -> None:
        self.agent = agent

    def post_json(self, url: str, payload_obj: Any, headers: Dict[str, str], method: str = 'POST') -> Tuple[int, Optional[str]]:
        try:
            body_str = json.dumps(payload_obj)
            body = body_str.encode('utf-8')
            start_time = time.time()

            ssl_context = ssl.create_default_context(cafile=config.EVENTS_CAFILE)
            # Assume headers are complete and correctly cased
            request_headers = dict(headers or {})
            request_headers['Content-Length'] = len(body)

            req = Request(url, body, request_headers, method=method)
            resp = urlopen(req, context=ssl_context, timeout=config.EVENTS_CLIENT_TIMEOUT_SECONDS)
            status = int(getattr(resp, 'status', None) or resp.getcode())
            data_bytes = None
            try:
                data_bytes = resp.read()
            except Exception:
                data_bytes = None
            data = data_bytes.decode('utf-8') if data_bytes else None

            end_time = time.time()
            duration_ms = round((end_time - start_time) * 1000, 2)
            self.agent.logger.debug('HTTP %s completed - URL: %s, Status: %s, Duration: %sms, PayloadLength: %s', 
                             method, url, status, duration_ms, len(body_str))
            return status, data
        except HTTPError as exc:
            status_code = exc.code
            self.agent.logger.warn('HTTP %s failed for %s: HTTP %s - %s, Will be retried', method, url, status_code, exc)
            return status_code, str(exc)
        except Exception as exc:
            self.agent.logger.warn('HTTP %s failed for %s: %s, Will be retried', method, url, exc)
            return 599, str(exc)

