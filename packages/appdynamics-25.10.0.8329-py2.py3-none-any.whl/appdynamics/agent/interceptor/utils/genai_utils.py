from uuid import uuid4
import appdynamics.agent.models.custom_metrics as custom_metrics_mod
from appdynamics.lang import items, urlparse
from collections import defaultdict
from datetime import datetime, timezone
import time
from appdynamics import config
from appdynamics.agent.interceptor.utils.genai_event import GenAIEvent


class GenaiConstants():
    MODERATION_MODULE_STRING = "moderation"
    EMBEDDING_MODULE_STRING = "embedding"
    CHAT_COMPLETIONS_MODULE_STRING = "chat.completions"
    TOKENS_METRIC_NAME = "Tokens"
    CALLS_METRIC_NAME = "Calls per minute"
    ERROR_METRIC_NAME = "Errors per minute"
    LATENCY_METRIC_NAME = "Latency"
    ALL_MODELS_STRING = "All Models"
    METRIC_NAME_SEGREGATOR = " - "
    APPLICATION_METRIC_PATH = "BTM|Application Summary"
    METRIC_PATH_SEGREGATOR = "|"
    INPUT_TOKENS_METRIC_NAME = "Input Tokens"
    COMPLETION_TOKENS_METRIC_NAME = "Completion Tokens"
    GENAI_CHAT_OPERATION = "chat"
    GENAI_TEXT_OPERATION = "text"
    GENAI_EMBEDDING_OPERATION = "embeddings"
    GENAI_MODERATION_OPERATION = "moderation"

class OpenaiConstants():
    FLAGGED_QUERIES_METRIC_NAME = "Flagged queries"
    TOTAL_QUERIES_METRIC_NAME = "Total queries"
    FLAGGED_EVENT_ATTRIBUTE = "flagged"
    CATEGORIES_EVENT_ATTRIBUTE = "categories"
    OPENAI = "OpenAI"
    OPENAI_PREFIX = OPENAI + GenaiConstants.METRIC_NAME_SEGREGATOR
    TIER_METRIC_PATH = "Agent|OpenAI"
    PROMPT_TOKENS_STRING = "prompt_tokens"
    COMPLETION_TOKENS_STRING = "completion_tokens"
    TOTAL_TOKENS_STRING = "total_tokens"
    TIME_ROLLUP_STRING = "time_rollup_type"
    CLUSTER_ROLLUP_STRING = "cluster_rollup_type"
    HOLE_HANDLING_STRING = "hole_handling_type"
    DEFAULT_HOST = "api.openai.com"
    DEFAULT_OPENAI_ENDPOINT = "https://api.openai.com/v1"
    MODERATION = "moderations"
    MODERATION_METRIC_PATH = TIER_METRIC_PATH + GenaiConstants.METRIC_PATH_SEGREGATOR + MODERATION
    MODERATION_CATERGORY_FOLDER_NAME = "Flagged Calls by category"
    MODERATION_APPLICATION_LEVEL_PREFIX = OPENAI_PREFIX + \
        MODERATION_CATERGORY_FOLDER_NAME + GenaiConstants.METRIC_NAME_SEGREGATOR
    MODERATION_TIER_LEVEL_PREFIX = TIER_METRIC_PATH + GenaiConstants.METRIC_PATH_SEGREGATOR + MODERATION + \
        GenaiConstants.METRIC_PATH_SEGREGATOR + MODERATION_CATERGORY_FOLDER_NAME
    MODERATION_QUERY_KEY = "Moderation input query"
    CATEGORIES_STRING = "categories"
    CATEGORY_SCORES_STRING = "category_scores"
    MODERATION_RESPONSE_STRING = "Moderation response"
    OPENAI_EXIT_CREATED_HEADER = "appd_openai_exit_created"
    BASE_ENCODING_TYPE_STRING = "cl100k_base"
    SUPPORTED_OPENAI_APIS_URISUFFIX_LIST = ["moderation", "chat/completion", "completion", "embedding"]
    CHOICES_FIELD = "choices"
    DELTA_FIELD = "delta"
    ROLE_FIELD = "role"
    NAME_FIELD = "name"
    CONTENT_FIELD = "content"
    MODEL_FIELD = "model"
    USAGE_FIELD = "usage"
    INPUT_QUERY_KEY = "Input query"
    MODEL_OUTPUT_KEY = "Output"


class BedrockConstants():
    BEDROCK_PROMPT_TOKENS_STRING = "inputTokens"
    BEDROCK_COMPLETION_TOKENS_STRING = "outputTokens"
    BEDROCK_TOTAL_TOKENS_STRING = "totalTokens"
    BEDROCK_TIER_METRIC_PATH = "Agent|Bedrock"
    BEDROCK = "Bedrock"
    BEDROCK_PREFIX = BEDROCK + GenaiConstants.METRIC_NAME_SEGREGATOR


METRICS_DICT = {
    GenaiConstants.CALLS_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_AVERAGE,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.RATE_COUNTER
    },
    GenaiConstants.ERROR_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_AVERAGE,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.RATE_COUNTER
    },
    GenaiConstants.TOKENS_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_SUM,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.REGULAR_COUNTER
    },
    GenaiConstants.LATENCY_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_AVERAGE,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.RATE_COUNTER
    },
    GenaiConstants.INPUT_TOKENS_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_SUM,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.REGULAR_COUNTER
    },
    GenaiConstants.COMPLETION_TOKENS_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_SUM,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.REGULAR_COUNTER
    },
}

MODERATION_CATEGORY_LIST = set()

MODERATION_METRIC_DICT = {
    GenaiConstants.CALLS_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_AVERAGE,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.RATE_COUNTER
    },
    OpenaiConstants.FLAGGED_QUERIES_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_SUM,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.REGULAR_COUNTER
    },
    OpenaiConstants.TOTAL_QUERIES_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_SUM,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.REGULAR_COUNTER
    },
    GenaiConstants.ERROR_METRIC_NAME: {
        OpenaiConstants.TIME_ROLLUP_STRING: custom_metrics_mod.TIME_AVERAGE,
        OpenaiConstants.CLUSTER_ROLLUP_STRING: None,
        OpenaiConstants.HOLE_HANDLING_STRING: custom_metrics_mod.RATE_COUNTER
    },
}

MODERATION_CATEGORY_METRICS = {
    value: MODERATION_METRIC_DICT[OpenaiConstants.FLAGGED_QUERIES_METRIC_NAME]
    for value in MODERATION_CATEGORY_LIST
}


def get_tokens_per_request(method_response, token_type=OpenaiConstants.PROMPT_TOKENS_STRING):
    try:
        return method_response['usage'][token_type]
    except Exception as exec:
        if token_type == OpenaiConstants.COMPLETION_TOKENS_STRING:
            return None
        raise UnsupportedResponseException(f"""UnsupportedResponseException: create method response struct changed.
                    Please contact admin or use the latest agent for updates \n [Error]:
                    {str(exec)}""")


def calculate_token_usage_from_string(model_name, messages, agent=None):
    try:
        # pylint: disable=import-error
        import tiktoken
        encoding = tiktoken.encoding_for_model(model_name)
    except KeyError as ex:
        # no such model_name in tiktoken
        if agent:
            agent.logger.error(f"Failed to get tiktoken encoding for model_name {model_name},\
                                error: {str(ex)}, defaulting to {OpenaiConstants.BASE_ENCODING_TYPE_STRING}")
        encoding = tiktoken.get_encoding(OpenaiConstants.BASE_ENCODING_TYPE_STRING)
    except ImportError:
        return None
    # ref:https://github.com/openai/openai-cookbook/blob/main/examples/How_to_count_tokens_with_tiktoken.ipynb
    if model_name == "gpt-3.5-turbo-0301":
        # every message follows <|start|>{role/name}\n{content}<|end|>\n
        # if there's a name, the role is omitted
        tokens_per_message = 4
        tokens_per_name = -1
    else:
        tokens_per_message = 3
        tokens_per_name = 1

    total_tokens = 0
    for message in messages:
        if isinstance(message, dict):
            total_tokens += tokens_per_message
            for key, value in message.items():
                total_tokens += len(encoding.encode(value))
                if key == "name":
                    total_tokens += tokens_per_name
        else:
            total_tokens += len(encoding.encode(message))
    # every reply is primed with <|start|>assistant<|message|>
    if len(messages) > 0 and isinstance(messages[0], dict):
        total_tokens += 3
    return total_tokens


def initialize_metrics(metric_prefix_path="", metric_prefix="", metric_suffix="", metric_dict=dict()):
    model_metrics_dict = dict()
    for metric_name, metric_attr in items(metric_dict):
        model_metrics_dict[metric_name] = custom_metrics_mod.CustomMetric(
            name=metric_prefix_path + GenaiConstants.METRIC_PATH_SEGREGATOR +
            metric_prefix + metric_name + metric_suffix,
            time_rollup_type=metric_attr[OpenaiConstants.TIME_ROLLUP_STRING],
            hole_handling_type=metric_attr[OpenaiConstants.HOLE_HANDLING_STRING])
    return model_metrics_dict


def get_backend_details(base_url=None) -> tuple:
    backend_details = None
    try:
        # importing openai package since api's hostname
        # change will different api's getting hostname
        # on every exitcall
        if base_url and hasattr(base_url, 'host') and hasattr(base_url, 'port') and hasattr(base_url, 'scheme'):
            port = base_url.port or ('443' if base_url.scheme == 'https' else '80')
            backend_details = (base_url.host, port, base_url.scheme, base_url.host)
        else:
            from openai import api_base
            parsed_url = urlparse(api_base)
            port = parsed_url.port or ('443' if parsed_url.scheme == 'https' else '80')
            backend_details = (parsed_url.hostname, port, parsed_url.scheme, api_base)
    except Exception:
        backend_details = (
            OpenaiConstants.DEFAULT_HOST,
            '443', 'https',
            OpenaiConstants.DEFAULT_OPENAI_ENDPOINT
        )
    return backend_details


def prompt_flagged_counter(agent=None, response=None) -> int:
    flagged_calls = 0
    try:
        if not response:
            response = list()
        flagged_calls = sum([int(moderation_data.get("flagged", False)) for moderation_data in response])
    except Exception as e:
        agent.logger.error(f"Moderation API response changed. {str(e)} \n. Please raise a bug")
    return flagged_calls


def convert_category_to_camel_case(category):
    """
    Convert moderation category names to camelCase format.
    Handles various formats: underscores, hyphens, slashes.
    Examples:
        'harassment_threatening' -> 'harassmentThreatening'
        'self-harm' -> 'selfHarm'
        'sexual/minors' -> 'sexualMinors'
    """
    # Replace underscores, hyphens, and slashes with spaces
    category = category.replace('_', ' ').replace('-', ' ').replace('/', ' ')
    words = category.split()
    if not words:
        return category
    # First word lowercase, rest title case
    return words[0].lower() + ''.join(word.capitalize() for word in words[1:])


def get_moderation_category_values(input_response=None, agent=None, moderation_model_metrics_mapping=None, moderation_app_level_metrics_mapping=None) -> dict:
    global MODERATION_CATEGORY_METRICS
    output_response = defaultdict(int)
    try:
        update_metrics_list = False
        for prompts in input_response.get('results'):
            for category, is_flagged in items(prompts.get("categories", {})):
                if is_flagged:
                    # Convert category to camelCase format dynamically
                    category_name = convert_category_to_camel_case(category)
                    MODERATION_CATEGORY_LIST.add(category_name)
                    
                    if category_name not in MODERATION_CATEGORY_METRICS:
                        MODERATION_CATEGORY_METRICS[category_name] = MODERATION_METRIC_DICT[OpenaiConstants.FLAGGED_QUERIES_METRIC_NAME]
                    
                    output_response[category_name] += 1
                    if category_name not in moderation_model_metrics_mapping:
                        update_metrics_list = True
                    if category_name not in moderation_app_level_metrics_mapping:
                        update_metrics_list = True
        if update_metrics_list:
            moderation_model_metrics_mapping.update(
                initialize_metrics(
                    metric_prefix_path=OpenaiConstants.MODERATION_TIER_LEVEL_PREFIX,
                    metric_dict=MODERATION_CATEGORY_METRICS,
                )
            )
            moderation_app_level_metrics_mapping.update(
                initialize_metrics(
                    metric_prefix_path=GenaiConstants.APPLICATION_METRIC_PATH,
                    metric_prefix=OpenaiConstants.MODERATION_APPLICATION_LEVEL_PREFIX,
                    metric_suffix=GenaiConstants.METRIC_NAME_SEGREGATOR + OpenaiConstants.MODERATION,
                    metric_dict=MODERATION_CATEGORY_METRICS,
                )
            )
    except Exception as e:
        agent.logger.error("Moderation API response changed. Please raise a bug" + str(e))
    return output_response


def report_metrics(metrics_dict=None, reporting_values=None, agent=None):
    if not metrics_dict or not reporting_values:
        raise MissingReportingValuesExcepion(" Metric Reporting\
           values not found .Please provide proper method arguments\
        ")
    try:
        for metric_name, metric_value in items(reporting_values):
            if metric_name in metrics_dict:
                agent.report_custom_metric(
                    metrics_dict[metric_name],
                    metric_value
                )
    except Exception as ex:
        log_metric_reporting_error(agent, ex)


def convert_to_dict(agent=None, response=None):
    modified_response = response
    try:
        if hasattr(response, 'model_dump') and not isinstance(response, dict):
            modified_response = response.model_dump(exclude_unset=True)
    except Exception as exc:
        agent.logger.error("Cannot convert api class to dict " + str(exc))
    return modified_response


def get_reporting_values_per_request(model_name=None, agent=None, endpoint_response=None):
    reporting_values = dict()
    # Calculating current request tokens
    try:
        reporting_values[GenaiConstants.TOKENS_METRIC_NAME] = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=OpenaiConstants.TOTAL_TOKENS_STRING
        )
        input_tokens = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=OpenaiConstants.PROMPT_TOKENS_STRING
        )
        if input_tokens:
            reporting_values[GenaiConstants.INPUT_TOKENS_METRIC_NAME] = input_tokens
        completion_tokens = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=OpenaiConstants.COMPLETION_TOKENS_STRING
        )
        if completion_tokens:
            reporting_values[GenaiConstants.COMPLETION_TOKENS_METRIC_NAME] = completion_tokens
    except UnsupportedResponseException as exec:
        agent.logger.error(str(exec))
        raise
    return reporting_values


def get_reporting_bedrock_values_per_request(agent=None,
                                             endpoint_response=None, region_name=None):
    reporting_values = dict()
    # Calculating current request tokens
    try:
        reporting_values[GenaiConstants.TOKENS_METRIC_NAME] = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=BedrockConstants.BEDROCK_TOTAL_TOKENS_STRING
        )
        prompt_tokens = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=BedrockConstants.BEDROCK_PROMPT_TOKENS_STRING
        )
        reporting_values[GenaiConstants.INPUT_TOKENS_METRIC_NAME] = prompt_tokens
        completion_tokens = get_tokens_per_request(
            method_response=endpoint_response,
            token_type=BedrockConstants.BEDROCK_COMPLETION_TOKENS_STRING
        )
        reporting_values[GenaiConstants.COMPLETION_TOKENS_METRIC_NAME] = completion_tokens
    except UnsupportedResponseException as exec:
        agent.logger.error(str(exec))
    return reporting_values


def get_reporting_values_streaming_type(model_name=None, token_usage=None, agent=None):
    reporting_values = dict()
    try:
        prompt_tokens = token_usage.get(OpenaiConstants.PROMPT_TOKENS_STRING, None) if token_usage else None
        completion_tokens = token_usage.get(OpenaiConstants.COMPLETION_TOKENS_STRING, None) if token_usage else None
        if prompt_tokens and completion_tokens:
            reporting_values[GenaiConstants.TOKENS_METRIC_NAME] = prompt_tokens + completion_tokens
            reporting_values[GenaiConstants.INPUT_TOKENS_METRIC_NAME] = prompt_tokens
            reporting_values[GenaiConstants.COMPLETION_TOKENS_METRIC_NAME] = completion_tokens
    except UnsupportedModelException as exec:
        agent.logger.error(str(exec))
    return reporting_values


def parse_completion_response(completion_response=None, openai_major_version=0, agent=None):
    completion_res_list = None
    try:
        if openai_major_version < 1:
            completion_res_list = completion_response.to_dict_recursive().get('choices')
        else:
            if hasattr(completion_response, 'to_dict'):
                completion_res_list = completion_response.to_dict().get('choices')
            else:
                # Use model_dump() for newer OpenAI SDK versions (pydantic v2)
                completion_dict = convert_to_dict(agent=agent, response=completion_response)
                completion_res_list = completion_dict.get('choices')
        return str(completion_res_list)
    except Exception as exc:
        agent.logger.error(f"Error occured while parsing resp: {str(exc)}")
        return None


def parse_moderation_response(moderation_response=None, openai_major_version=0, agent=None):
    moderation_res_list = None
    try:
        if openai_major_version < 1:
            moderation_res_list = moderation_response.to_dict_recursive().get('results')
        else:
            if hasattr(moderation_response, 'to_dict'):
                moderation_res_list = moderation_response.to_dict().get('results')
            else:
                # Use model_dump() for newer OpenAI SDK versions (pydantic v2)
                moderation_dict = convert_to_dict(agent=agent, response=moderation_response)
                moderation_res_list = moderation_dict.get('results')
        return get_parsed_moderation_results(moderation_res_list, agent)
    except Exception as exc:
        agent.logger.error(f"Error occured while parsing moderation resp: {str(exc)}")
        return None


def get_parsed_moderation_results(moderation_res_list=None, agent=None):
    try:
        moderation_response_parsed = []
        if moderation_res_list:
            for dict_response in moderation_res_list:
                dict_categories = dict_response[OpenaiConstants.CATEGORIES_STRING]
                dict_category_scores = dict_response[OpenaiConstants.CATEGORY_SCORES_STRING]
                moderation_response = "{"

                for index, category in enumerate(dict_categories):
                    score = str(dict_category_scores[category])
                    modified_score = format(float(score), '.9f')
                    moderation_response += f"\"{category}\" : [{dict_categories[category]}, {modified_score}]"
                    if index < len(dict_categories) - 1:
                        moderation_response += ", "
                moderation_response += "}"
                moderation_response_parsed.append(moderation_response)
        return moderation_response_parsed
    except Exception as exc:
        agent.logger.error(f"Error occured while parsing moderation dict: {str(exc)}")
        return None


def get_token_usage_data(usage_data=None, model_name=None, input_messages=None, response_messages=None, agent=None):
    token_usage = dict()
    try:
        if usage_data:
            token_usage[OpenaiConstants.PROMPT_TOKENS_STRING] = usage_data.prompt_tokens \
                if hasattr(usage_data, OpenaiConstants.PROMPT_TOKENS_STRING) \
                else usage_data.get(OpenaiConstants.PROMPT_TOKENS_STRING)
            token_usage[OpenaiConstants.COMPLETION_TOKENS_STRING] = usage_data.completion_tokens \
                if hasattr(usage_data, OpenaiConstants.COMPLETION_TOKENS_STRING) \
                else usage_data.get(OpenaiConstants.COMPLETION_TOKENS_STRING)
        elif model_name and response_messages:
            # if tiktoken is not added as import, then this returns none
            token_usage[OpenaiConstants.PROMPT_TOKENS_STRING] = \
                calculate_token_usage_from_string(model_name, input_messages, agent)
            token_usage[OpenaiConstants.COMPLETION_TOKENS_STRING] = \
                calculate_token_usage_from_string(model_name, response_messages, agent)
    except Exception as exc:
        agent.logger.error(f"Error occured while streaming token calculation, error={str(exc)}.")
    return token_usage





def derive_token_usage_from_generation_info(llm_result=None, existing_model_name=None):
    # Derive token usage and model from LLMResult.generations[*].generation_info.
    model_name = existing_model_name
    if llm_result is None:
        return None, model_name
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_tokens = 0
    usage_present = False
    gens = getattr(llm_result, 'generations', None) # generations=[[geninfo], ...]
    if gens and len(gens) > 0:
        for gen in gens:
            gi = getattr(gen[0], 'generation_info', None)
            if gi:
                gi_model = gi.get('model')
                if gi_model and not model_name:
                    model_name = gi_model
                if gi.get('usage_metadata'):
                    p_val = gi.get('usage_metadata').get('input_tokens')
                    c_val = gi.get('usage_metadata').get('output_tokens')
                    t_raw = gi.get('usage_metadata').get('total_tokens')
                else:
                    p_val = gi.get('prompt_eval_count') or gi.get('input_tokens') or 0
                    c_val = gi.get('eval_count') or gi.get('output_tokens') or 0
                    t_raw = gi.get('total_tokens')
                t_val = t_raw if t_raw is not None else (p_val + c_val)
                if p_val is not None and c_val is not None:
                    total_prompt_tokens += p_val
                    total_completion_tokens += c_val
                    total_tokens += t_val
                    usage_present = True
    if not usage_present:
        return None, model_name
    token_usage = {
        'prompt_tokens': total_prompt_tokens,
        'completion_tokens': total_completion_tokens,
        'total_tokens': total_tokens,
    }
    return token_usage, model_name


def get_moderation_input_query(args, kwargs):
    input_query = None
    if kwargs and "input" in kwargs:
        input_query = kwargs.get('input')
    elif args and len(args) > 0:
        input_query = args[0]
    return input_query


def get_completion_opr_string(module_name=""):
    return GenaiConstants.CHAT_COMPLETIONS_MODULE_STRING if "chat_completion" in module_name \
        or "chat.completions" in module_name else "completions"


def get_streaming_message_obj(delta, agent=None):
    message_obj = dict()
    try:
        if isinstance(delta, dict):
            message_role = delta.get(OpenaiConstants.ROLE_FIELD)
            message_name = delta.get(OpenaiConstants.NAME_FIELD)
            message_content = delta.get(OpenaiConstants.CONTENT_FIELD)
        else:
            message_role = delta.role if hasattr(delta, OpenaiConstants.ROLE_FIELD) else None
            message_name = delta.name if hasattr(delta, OpenaiConstants.NAME_FIELD) else None
            message_content = delta.content if hasattr(delta, OpenaiConstants.CONTENT_FIELD) else None
    except KeyError as ex:
        agent.logger.error(str(ex))
    if message_role:
        message_obj[OpenaiConstants.ROLE_FIELD] = message_role
    if message_name:
        message_obj[OpenaiConstants.NAME_FIELD] = message_name
    if message_content:
        message_obj[OpenaiConstants.CONTENT_FIELD] = message_content
    return message_obj


def set_complete_response_obj(choices, complete_response, response_content, agent):
    for choice in choices:
        delta = choice.delta if hasattr(choice, OpenaiConstants.DELTA_FIELD) \
            else (choice.get(OpenaiConstants.DELTA_FIELD) if isinstance(choice, dict) else None)
        if delta:
            message_obj = get_streaming_message_obj(delta, agent)
            if OpenaiConstants.CONTENT_FIELD in message_obj:
                response_content += message_obj[OpenaiConstants.CONTENT_FIELD]
        elif hasattr(choice, "text"):
            response_content += choice.text
    return response_content


def set_parsed_chunk_values(chunk, response_content, complete_response, usage_data, agent=None):
    try:
        choices = chunk.choices if hasattr(chunk, OpenaiConstants.CHOICES_FIELD) \
            else chunk.get(OpenaiConstants.CHOICES_FIELD)
        
        response_content = set_complete_response_obj(choices, complete_response, response_content, agent)

        if not complete_response["model"]:
            complete_response["model"] = chunk.model if hasattr(chunk, OpenaiConstants.MODEL_FIELD) \
                else chunk.get(OpenaiConstants.MODEL_FIELD)
        # when stream_options: {"include_usage": true}, usage data is returned in one of the chunks
        if not usage_data:
            if isinstance(chunk, dict):
                usage_data = chunk.get(OpenaiConstants.USAGE_FIELD, None)
            elif hasattr(chunk, OpenaiConstants.USAGE_FIELD):
                usage_data = chunk.usage
    except Exception as ex:
        agent.logger.error(f"Error occured while parsing streaming response, error = {str(ex)}")
        response_content = ""
        complete_response = {"response": [], "model": ""}
        usage_data = None
    return response_content, complete_response, usage_data


def add_multiple_exit_suppression_header(url_string, headers):
    add_suppression_header = False
    for openai_api_type in OpenaiConstants.SUPPORTED_OPENAI_APIS_URISUFFIX_LIST:
        if openai_api_type in url_string:
            add_suppression_header = True
    # Below check to add suppression header(appd_exit_created) only if we are already intercepting the call
    if url_string and add_suppression_header:
        headers[OpenaiConstants.OPENAI_EXIT_CREATED_HEADER] = "True"


def get_metric_complaint_string(name):
    name = name.replace(":", "-")
    name = name.replace("|", "-")
    return name


# for testing purpose
def get_latency_ms_from_start_time(call_start_time):
    return int((time.time() - call_start_time) * 1000)


def calculate_streaming_timing_metrics(call_start_time, first_token_time, total_latency_ms, output_tokens):
    """
    Calculate time_to_first_token_ms and time_per_output_token_ms for streaming responses.
    """
    
    time_to_first_token_ms = None
    time_per_output_token_ms = None
    
    if call_start_time and first_token_time:
        time_to_first_token_ms = round((first_token_time - call_start_time) * 1000)
    
    if total_latency_ms and output_tokens and time_to_first_token_ms and \
            output_tokens > 0 and total_latency_ms > time_to_first_token_ms:
        time_per_output_token_ms = round((total_latency_ms - time_to_first_token_ms) / output_tokens)
        
    return time_to_first_token_ms, time_per_output_token_ms


def emit_llm_event(
  agent,
  bt,
  err_detail,
  gen_ai_system,
  gen_ai_operation_name,
  model,
  reporting_values,
  latency_ms,
  time_to_first_token_ms=None,
  time_per_output_token_ms=None,
  streaming=False,
  event_start_time=None,
  openai_moderations=None,
):
  # Respect global toggle for GenAI event publishing
  if not config.ENABLE_GENAI_EVENTS or not agent.event_svc:
    return

  input_tokens = reporting_values.get(GenaiConstants.INPUT_TOKENS_METRIC_NAME, None)
  output_tokens = reporting_values.get(GenaiConstants.COMPLETION_TOKENS_METRIC_NAME, None)
  total_tokens = reporting_values.get(GenaiConstants.TOKENS_METRIC_NAME, None)

  llm_fields = {
    "gen_ai_system": gen_ai_system.lower() if gen_ai_system else None,
    "gen_ai_operation_name": gen_ai_operation_name.lower() if gen_ai_operation_name else None,
    "model_used": model.lower() if model else None,
    "streaming": bool(streaming),
    "input_tokens": input_tokens,
    "output_tokens": output_tokens,
    "total_tokens": total_tokens,
    "time_to_first_token_ms": time_to_first_token_ms,
    "time_per_output_token_ms": time_per_output_token_ms,
    "latency_ms": latency_ms,
  }

  emit_genai_event(
    event_start_time=event_start_time,
    agent=agent,
    bt=bt,
    err_detail=err_detail,
    call_type="llm",
    llm=llm_fields,
    openai_moderations=openai_moderations,
  )


def get_vectordb_operation_name(method_name):
    """
    Extract operation name from method name.
    Maps common vectordb operations to standardized names.
    """
    if not method_name:
        return 'unknown'
    if 'search' in method_name:
        return 'query'
    elif 'add_texts' in method_name:
        return 'add'
    elif 'delete' in method_name:
        return 'delete'
    return method_name


def emit_vectordb_event(
  agent,
  bt,
  err_detail,
  system,
  operation,
  reporting_values,
  latency_ms,
  documents_count=None,
  event_start_time=None,
):
  """
  Create a vectordb event for langchain vectorstore operations.
  """
  if not config.ENABLE_GENAI_EVENTS or not agent.event_svc:
    return
    
  # Calculate average search score
  from appdynamics.agent.interceptor.utils.langchain_utils import LangchainConstants
  search_scores = reporting_values.get(LangchainConstants.SEARCH_SCORE_METRIC_NAME, [])
  average_search_score = round(sum(search_scores) / len(search_scores)) if len(search_scores) > 0 else None
  vector_count = (
    reporting_values.get(LangchainConstants.INSERTIONCOUNT_METRIC_NAME, 0)
    + reporting_values.get(LangchainConstants.DELETIONCOUNT_METRIC_NAME, 0)
  )

  vectordb_fields = {
    "system": system.lower() if system else None,
    "operation": operation.lower() if operation else None,  # list of operations: query, add, delete
    "search_score": average_search_score,
    "latency_ms": latency_ms,
    "vector_count": vector_count,
    "documents_count": documents_count,
  }
  
  emit_genai_event(
    event_start_time=event_start_time,
    agent=agent,
    bt=bt,
    err_detail=err_detail,
    call_type="vectordb",
    vectordb=vectordb_fields,
  )


def emit_genai_event(
  event_start_time,
  agent,
  bt,
  err_detail,
  call_type,
  llm=None,
  vectordb=None,
  openai_moderations=None,
  additional_attributes=None
):
  """
  Centralized function to emit a GenAI event.
  Used by both emit_llm_event and emit_vectordb_event.
  """
  timestamp = (
    datetime.fromtimestamp(event_start_time, timezone.utc)
    .isoformat()
    .replace("+00:00", "Z")
    if event_start_time
    else datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
  )
  event_obj = GenAIEvent().set_event_fields(
    timestamp=timestamp,
    req_guid=_get_request_guid(bt),
    status=("SUCCESS" if err_detail is None else "FAILED"),
    error_message=err_detail,
    application_id=str(agent.app_id) if agent.app_id else None,
    application_name=config.AGENT_APPLICATION_NAME,
    tier=config.AGENT_TIER_NAME,
    tier_id=str(agent.tier_id) if agent.tier_id else None,
    node=config.AGENT_NODE_NAME,
    node_id=str(agent.node_id) if agent.node_id else None,
    bt_id=(int(bt.registered_id) if bt and bt.registered_id else None),
    bt_name=(bt.name if bt else None),
    call_type=call_type,
    llm=llm or {},
    vectordb=vectordb or {},
    openai_moderations=openai_moderations or {},
    additional_attributes=additional_attributes or {},
  )
  agent.event_svc.add_event(event_obj.EVENT_TYPE, event_obj.to_dict())


def _get_request_guid(bt):
    if bt is None:
        return None
    if bt.snapshot_guid is not None:
        return str(bt.snapshot_guid)
    if bt.correlation_hdr_snapshot_guid is not None:
        return str(bt.correlation_hdr_snapshot_guid)
    return str(uuid4())


def log_metric_reporting_error(agent, error):
    name = error.__class__.__name__
    if name == 'AgentNotStartedException':
        agent.logger.debug("Cannot report genai metrics because the agent hasn't been started.")
    elif name == 'AgentNotReadyException':
        agent.logger.debug("Cannot report genai metrics because the agent is not ready.")
    else:
        agent.logger.error(f"Error occurred while reporting genai metrics, error = {str(error)}")


class UnsupportedModelException(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return f"UnsupportedModelException: {self.message}"


class UnsupportedResponseException(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return f"UnsupportedResponseException: {self.message}"


class MissingReportingValuesExcepion(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return f"MissingReportingValuesExcepion: {self.message}"


def report_moderation_metrics_and_event(
    agent,
    bt,
    moderation_response,
    reporting_values,
    moderationApiModelInstance,
    err_detail,
    call_start_time
):
    """Helper to report moderation metrics and emit event after exit call ends."""
    moderationApiModelInstance.report_metrics(
        response=moderation_response,
        reporting_values=reporting_values,
        model_name=OpenaiConstants.MODERATION
    )
    openai_moderations = {
        OpenaiConstants.FLAGGED_EVENT_ATTRIBUTE: False
    }
    is_flagged = reporting_values.get(OpenaiConstants.FLAGGED_QUERIES_METRIC_NAME, 0)
    if is_flagged > 0:
        openai_moderations[OpenaiConstants.FLAGGED_EVENT_ATTRIBUTE] = True
    if len(MODERATION_CATEGORY_LIST) > 0:
        openai_moderations[OpenaiConstants.CATEGORIES_EVENT_ATTRIBUTE] = dict()
        for category_name in MODERATION_CATEGORY_LIST:
            openai_moderations[OpenaiConstants.CATEGORIES_EVENT_ATTRIBUTE][category_name] = reporting_values.get(category_name, 0) > 0
    actual_model = getattr(moderation_response, 'model', None) or OpenaiConstants.MODERATION
    if config.ENABLE_GENAI_EVENTS and agent.event_svc:
        emit_llm_event(
            agent=agent,
            bt=bt,
            err_detail=err_detail,
            gen_ai_system="OpenAI", 
            gen_ai_operation_name=GenaiConstants.GENAI_MODERATION_OPERATION,
            model=actual_model,
            reporting_values=reporting_values,
            latency_ms=int((time.time() - call_start_time) * 1000) if call_start_time else None,
            event_start_time=call_start_time,
            openai_moderations=openai_moderations,
        )


def report_embedding_metrics_and_event(
    agent,
    bt,
    embedding_response,
    reporting_values,
    completionApiModelInstance,
    err_detail,
    call_start_time,
    model
):
    """Helper to report embedding metrics and emit event after exit call ends."""
    completionApiModelInstance.report_metrics(
        response=embedding_response,
        reporting_values=reporting_values,
        model_name=model
    )
    
    if config.ENABLE_GENAI_EVENTS and agent.event_svc:
        emit_llm_event(
            agent=agent,
            bt=bt,
            err_detail=err_detail,
            gen_ai_system="OpenAI",
            gen_ai_operation_name=GenaiConstants.GENAI_EMBEDDING_OPERATION,
            model=model,
            reporting_values=reporting_values,
            latency_ms=int((time.time() - call_start_time) * 1000) if call_start_time else None,
            event_start_time=call_start_time
        )


def report_completion_metrics_and_event(
    agent,
    bt,
    create_response,
    reporting_values,
    completionApiModelInstance,
    err_detail,
    call_start_time,
    model,
    module_name
):
    """Helper to report completion metrics and emit event after exit call ends."""
    completionApiModelInstance.report_metrics(
        response=create_response,
        reporting_values=reporting_values,
        model_name=model
    )
    
    operation_name = GenaiConstants.GENAI_CHAT_OPERATION if GenaiConstants.CHAT_COMPLETIONS_MODULE_STRING in module_name \
            else GenaiConstants.GENAI_TEXT_OPERATION
    
    if config.ENABLE_GENAI_EVENTS and agent.event_svc:
        emit_llm_event(
            agent=agent,
            bt=bt,
            err_detail=err_detail,
            gen_ai_system="OpenAI", 
            gen_ai_operation_name=operation_name,
            model=model,
            reporting_values=reporting_values,
            latency_ms=int((time.time() - call_start_time) * 1000) if call_start_time else None,
            streaming=False,
            event_start_time=call_start_time
        )


def report_streaming_metrics_and_event(
    agent,
    bt,
    complete_response,
    usage_data,
    input_messages,
    model_used,
    reporting_values,
    completionApiModelInstance,
    err_detail,
    call_start_time,
    first_token_time
):
    """Helper to report streaming metrics and emit event after exit call ends."""
    token_usage = get_token_usage_data(usage_data, complete_response["model"], input_messages,
                                      complete_response["response"], agent)
    completionApiModelInstance.report_streaming_metrics(
        reporting_values=reporting_values,
        model_name=model_used,
        token_usage=token_usage
    )
    
    latency_ms = int((time.time() - call_start_time) * 1000)
    time_to_first_token_ms, time_per_output_token_ms = calculate_streaming_timing_metrics(
        call_start_time, first_token_time, latency_ms, reporting_values.get(GenaiConstants.COMPLETION_TOKENS_METRIC_NAME, None)
    )

    if config.ENABLE_GENAI_EVENTS and agent.event_svc:
        emit_llm_event(
            agent=agent,
            bt=bt,
            err_detail=err_detail,
            gen_ai_system="OpenAI", 
            gen_ai_operation_name=GenaiConstants.GENAI_CHAT_OPERATION,
            model=model_used,
            reporting_values=reporting_values,
            latency_ms=latency_ms,
            time_to_first_token_ms=time_to_first_token_ms,
            time_per_output_token_ms=time_per_output_token_ms,
            streaming=True,
            event_start_time=call_start_time
        )
