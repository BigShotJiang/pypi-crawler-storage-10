from __future__ import annotations

from typing import Any, Dict, Optional
from dataclasses import dataclass, field
import base64
from appdynamics import config
from appdynamics.agent.services.event_processor import EventProcessorConfig


@dataclass
class GenAIEvent:

    EVENT_TYPE: str = "gen_ai_event_v1"

    # Common fields
    timestamp: Optional[str] = None
    req_guid: Optional[str] = None
    status: str = "SUCCESS"  # SUCCESS | FAILED
    error_message: Optional[str] = None
    application_id: Optional[str] = None
    application_name: Optional[str] = None
    tier: Optional[str] = None
    tier_id: Optional[str] = None
    node: Optional[str] = None
    node_id: Optional[str] = None
    bt_id: Optional[int] = None
    bt_name: Optional[str] = None
    call_type: str = ""  # "llm" or "vectordb"

    # Nested sections
    llm: Dict[str, Any] = field(default_factory=dict)
    vectordb: Dict[str, Any] = field(default_factory=dict)
    openai_moderations: Dict[str, Any] = field(default_factory=dict)
    additional_attributes: Dict[str, Any] = field(default_factory=dict)

    def set_event_fields(
        self,
        *,
        timestamp: str,
        req_guid: Optional[str],
        status: str,
        error_message: Optional[str],
        application_id: Optional[str],
        application_name: Optional[str],
        tier: Optional[str],
        tier_id: Optional[str],
        node: Optional[str],
        node_id: Optional[str],
        bt_id: Optional[int],
        bt_name: Optional[str],
        call_type: str,
        llm: Dict[str, Any],
        vectordb: Dict[str, Any],
        openai_moderations: Dict[str, Any],
        additional_attributes: Dict[str, Any],
    ) -> "GenAIEvent":
        self.timestamp = timestamp
        self.req_guid = req_guid
        self.status = status
        self.error_message = error_message
        self.application_id = application_id
        self.application_name = application_name
        self.tier = tier
        self.tier_id = tier_id
        self.node = node
        self.node_id = node_id
        self.bt_id = bt_id
        self.bt_name = bt_name
        self.call_type = call_type
        self.llm = llm
        self.vectordb = vectordb
        self.openai_moderations = openai_moderations
        self.additional_attributes = additional_attributes
        return self

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "timestamp": self.timestamp,
            "req_guid": self.req_guid,
            "status": self.status,
            "error_message": self.error_message,
            "applicationId": self.application_id,
            "application_name": self.application_name,
            "tier": self.tier,
            "tierId": self.tier_id,
            "node": self.node,
            "nodeId": self.node_id,
            "bt_id": self.bt_id,
            "bt_name": self.bt_name,
            "call_type": self.call_type,
        }
        
        # Only add nested objects if they have values (not None or empty dict)
        llm_filtered = {k: v for k, v in (self.llm or {}).items() if v is not None}
        if llm_filtered:
            result["llm"] = llm_filtered
        
        vectordb_filtered = {k: v for k, v in (self.vectordb or {}).items() if v is not None}
        if vectordb_filtered:
            result["vectordb"] = vectordb_filtered
        
        openai_moderations_filtered = {k: v for k, v in (self.openai_moderations or {}).items() if v is not None}
        if openai_moderations_filtered:
            result["openai_moderations"] = openai_moderations_filtered
        
        additional_attributes_filtered = {k: v for k, v in (self.additional_attributes or {}).items() if v is not None}
        if additional_attributes_filtered:
            result["additional_attributes"] = additional_attributes_filtered
        
        return result


class GenAIEventConfig(EventProcessorConfig):

    def __init__(self) -> None:
        headers: Dict[str, Any] = {}
        headers['Accept'] = 'application/json'
        headers['Content-Type'] = 'application/json'
        if config.EVENT_SERVICE_ACCOUNT_NAME and config.EVENT_SERVICE_ACCESS_KEY:
            token = f"{config.EVENT_SERVICE_ACCOUNT_NAME}:{config.EVENT_SERVICE_ACCESS_KEY}".encode('utf-8')
            auth_header = 'Basic ' + base64.b64encode(token).decode('utf-8')
            headers['Authorization'] = auth_header
        # Defaults for queue/timing and URLs
        event_type = GenAIEvent.EVENT_TYPE
        max_queue_size = int(config.GENAI_EVENTS_MAX_QUEUE_SIZE)
        chunk_size = int(config.GENAI_EVENTS_CHUNK_SIZE)
        max_wait_seconds = int(config.GENAI_EVENTS_MAX_WAIT_SECONDS)
        normal_pause_seconds = float(config.GENAI_EVENTS_NORMAL_PAUSE_MILLIS) / 1000.0
        long_pause_pause_seconds = float(config.GENAI_EVENTS_LONG_PAUSE_MILLIS) / 1000.0

        send_attempt_max = int(config.GENAI_EVENTS_SEND_ATTEMPT_MAX)
        register_url = ""
        publish_url = ""
        # Compose URLs from base EVENT_SERVICE_URL if provided
        base_url = (config.EVENT_SERVICE_URL or '').rstrip('/') 
        if base_url:
            register_url = f"{base_url}/gen_ai_event_v1"
            publish_url = f"{register_url}/event"

        super(GenAIEventConfig, self).__init__(
            event_type=event_type,
            publish_url=publish_url,
            register_url=register_url,
            request_headers=headers,
            max_queue_size=max_queue_size,
            chunk_size=chunk_size,
            max_wait_seconds=max_wait_seconds,
            normal_pause_seconds=normal_pause_seconds,
            long_pause_pause_seconds=long_pause_pause_seconds,
            send_attempt_max=send_attempt_max,
            schema_payload=GENAI_EVENT_SCHEMA,
        )


# Static schema payload used for register/update
GENAI_EVENT_SCHEMA: Dict[str, Any] = {
    "properties": {
        "timestamp": {"type": "date"},
        "req_guid": {"type": "keyword"},
        "status": {"type": "keyword"},
        "error_message": {"type": "string"},
        "applicationId": {"type": "string"},
        "application_name": {"type": "string"},
        "tier": {"type": "string"},
        "tierId": {"type": "string"},
        "node": {"type": "string"},
        "nodeId": {"type": "string"},
        "bt_id": {"type": "long"},
        "bt_name": {"type": "string"},
        "call_type": {"type": "keyword"},
        "llm": {
            "type": "object",
            "properties": {
                "gen_ai_system": {"type": "string"},
                "gen_ai_operation_name": {"type": "string"},
                "model_used": {"type": "string"},
                "input_tokens": {"type": "long"},
                "output_tokens": {"type": "long"},
                "total_tokens": {"type": "long"},
                "time_to_first_token_ms": {"type": "integer"},
                "time_per_output_token_ms": {"type": "integer"},
                "latency_ms": {"type": "integer"},
                "streaming": {"type": "boolean"},
            },
        },
        "vectordb": {
            "type": "object",
            "properties": {
                "system": {"type": "string"},
                "operation": {"type": "string"},
                "search_score": {"type": "integer"},
                "latency_ms": {"type": "integer"},
                "vector_count": {"type": "integer"},
                "documents_count": {"type": "integer"},
            },
        },
        "openai_moderations": {
            "type": "object",
            "properties": {
                "flagged": {"type": "boolean"},
                "categories": {
                    "type": "object"
                },
            },
        },
        "additional_attributes": {"type": "object"},
    }
}


