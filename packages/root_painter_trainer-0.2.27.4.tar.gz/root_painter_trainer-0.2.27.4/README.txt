PyTorch is required but Installing torch is not that easy to automate from a script.

Please see instructions available here: https://pytorch.org/

If the 'Stable' option does not work for you then I recommend trying Preview (Nightly).

