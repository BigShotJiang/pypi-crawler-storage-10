"""Nodes module for Salt Docs."""
