"""
Salt Docs - Wiki for your codebase
"""

from .metadata import __version__, AUTHOR_NAME

__author__ = AUTHOR_NAME
