import logging

from delta.tables import DeltaTable
from pyspark.sql import DataFrame

from .session import M

logger = logging.getLogger(__name__)


def neo_write(self, path, mode="overwrite", keys=None, **options):
    writer = self.write.format("delta")

    for key, value in options.items():
        writer = writer.option(key, value)

    try:
        if mode == "overwrite":
            writer.mode("overwrite").save(path)

        elif mode == "append":
            writer.mode("append").save(path)

        elif mode == "merge":
            if not keys:
                raise ValueError("keys required for merge mode")

            delta_table = DeltaTable.forPath(self.sparkSession, path)
            condition = " AND ".join(
                [f"target.{k} = source.{k}" for k in keys])

            (delta_table.alias("target")
                .merge(self.alias("source"), condition)
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute())

        else:
            raise ValueError(f"Unsupported mode: {mode}")

        logger.info(f"Successfully wrote to {path} using {mode}")

    except Exception as e:
        if "Path does not exist" in str(e) and mode == "merge":
            writer.mode("overwrite").save(path)
            logger.info(f"Created new Delta table at {path}")
        else:
            raise


def install():
    if not hasattr(DataFrame, 'neo_write'):
        setattr(DataFrame, "neo_write", neo_write)

    logger.info("Neo Data Service installed")


def get_session():
    return M.get_session()
