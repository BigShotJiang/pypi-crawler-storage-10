__version__ = "0.1.0"

from .core import get_session, install

install()

S, Q = get_session()
__all__ = ["S", "Q"]