# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RollbackSnapshotRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'snapshot_id': 'str',
        'body': 'RollbackSnapshotRequestBody'
    }

    attribute_map = {
        'snapshot_id': 'snapshot_id',
        'body': 'body'
    }

    def __init__(self, snapshot_id=None, body=None):
        r"""RollbackSnapshotRequest

        The model defined in huaweicloud sdk

        :param snapshot_id: 快照ID
        :type snapshot_id: str
        :param body: Body of the RollbackSnapshotRequest
        :type body: :class:`huaweicloudsdkevs.v2.RollbackSnapshotRequestBody`
        """
        
        

        self._snapshot_id = None
        self._body = None
        self.discriminator = None

        self.snapshot_id = snapshot_id
        if body is not None:
            self.body = body

    @property
    def snapshot_id(self):
        r"""Gets the snapshot_id of this RollbackSnapshotRequest.

        快照ID

        :return: The snapshot_id of this RollbackSnapshotRequest.
        :rtype: str
        """
        return self._snapshot_id

    @snapshot_id.setter
    def snapshot_id(self, snapshot_id):
        r"""Sets the snapshot_id of this RollbackSnapshotRequest.

        快照ID

        :param snapshot_id: The snapshot_id of this RollbackSnapshotRequest.
        :type snapshot_id: str
        """
        self._snapshot_id = snapshot_id

    @property
    def body(self):
        r"""Gets the body of this RollbackSnapshotRequest.

        :return: The body of this RollbackSnapshotRequest.
        :rtype: :class:`huaweicloudsdkevs.v2.RollbackSnapshotRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this RollbackSnapshotRequest.

        :param body: The body of this RollbackSnapshotRequest.
        :type body: :class:`huaweicloudsdkevs.v2.RollbackSnapshotRequestBody`
        """
        self._body = body

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RollbackSnapshotRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
