"""
QtDraw
"""

from pathlib import Path

__version__ = "2.3.9"
__date__ = "2021 - 2025"
__author__ = "Hiroaki Kusunose"
__top_dir__ = Path(__file__).parent / ".."
