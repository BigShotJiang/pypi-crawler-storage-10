# bluekit

[![Release](https://img.shields.io/github/v/release/evgnomon/bluekit)](https://img.shields.io/github/v/release/evgnomon/bluekit)
[![Build status](https://img.shields.io/github/actions/workflow/status/evgnomon/bluekit/main.yml?branch=main)](https://github.com/evgnomon/bluekit/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/evgnomon/bluekit)](https://img.shields.io/github/commit-activity/m/evgnomon/bluekit)
[![License](https://img.shields.io/github/license/evgnomon/bluekit)](https://img.shields.io/github/license/evgnomon/bluekit)

Blueprint development kit for Python
