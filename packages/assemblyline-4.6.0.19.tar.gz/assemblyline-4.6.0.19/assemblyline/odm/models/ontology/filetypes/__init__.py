from assemblyline.odm.models.ontology.filetypes.pe import PE
