from pathlib import Path

ICON_PATH = Path(__file__).parent / "resources"
