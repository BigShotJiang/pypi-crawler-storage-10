"""Tests for INTEGRIUM. Author: Juste Elysée MALANDILA"""
import pytest
from integrium import Validator, sanitize

def test_validator_import():
    """Test can import Validator."""
    assert Validator is not None

def test_sanitize():
    """Test sanitize function."""
    result = sanitize("  HELLO  ")
    assert result == "hello"
