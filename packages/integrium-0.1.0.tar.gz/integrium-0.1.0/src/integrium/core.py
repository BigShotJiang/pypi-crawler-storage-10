"""
Core functionality for your package
"""

def main_function(message: str = "Hello from your package!") -> str:
    """
    Main function of your package.
    
    Args:
        message (str): Message to return
        
    Returns:
        str: The formatted message
    """
    return f"🚀 {message}"


def example_utility(data: list) -> dict:
    """
    Example utility function.
    
    Args:
        data (list): Input data to process
        
    Returns:
        dict: Processed data with statistics
    """
    return {
        "count": len(data),
        "data": data,
        "processed": True
    }
