"""INTEGRIUM Schema decorator. Author: Juste Elysée MALANDILA"""

def schema(cls):
    """Decorator for validation schemas."""
    return cls
