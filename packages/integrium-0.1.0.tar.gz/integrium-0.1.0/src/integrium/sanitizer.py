"""INTEGRIUM Sanitizer. Author: Juste Elysée MALANDILA"""

def sanitize(data: str) -> str:
    """Sanitize data."""
    return data.strip().lower()
