"""
INTEGRIUM - Advanced Data Validation Framework
The Integrity Element
Created by Juste Elysée MALANDILA
LinkedIn: https://linkedin.com/in/juste-elysee-malandila
"""

__version__ = "0.1.0"
__author__ = "Juste Elysée MALANDILA"
__email__ = "justech4dev@gmail.com"
__linkedin__ = "https://linkedin.com/in/juste-elysee-malandila"

from .validator import Validator, Field
from .schema import schema
from .sanitizer import sanitize
from .exceptions import ValidationError, IntegriumError

__all__ = [
    "Validator",
    "Field", 
    "schema",
    "sanitize",
    "ValidationError",
    "IntegriumError",
    "__version__",
]
