"""INTEGRIUM Exceptions. Author: Juste Elysée MALANDILA"""

class IntegriumError(Exception):
    """Base exception for INTEGRIUM."""
    pass

class ValidationError(IntegriumError):
    """Validation failed."""
    pass
