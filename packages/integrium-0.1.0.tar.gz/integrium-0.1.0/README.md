# integrium

A modern Python package created by Juste Elysée MALANDILA.

## Installation

```bash
pip install integrium
```

## Usage

```python
from integrium import main_function

result = main_function("Hello World!")
print(result)
```

## Development

```bash
# Install in development mode
pip install -e .[dev]

# Run tests
pytest

# Format code
black .
isort .

# Type checking
mypy .
```

## License

MIT License - see LICENSE file for details.

## Author

**Juste Elysée MALANDILA**  
Email: justech4dev@gmail.com  
GitHub: @jdevsky
