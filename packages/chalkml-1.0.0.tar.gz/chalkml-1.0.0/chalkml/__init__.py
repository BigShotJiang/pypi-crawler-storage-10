"""
ChalkML - Terminal-Based ML Data Engineering
=============================================

A production-grade data manipulation engine with:
- Intuitive position notation (01N, N01)
- 40+ ML operations
- Design patterns (MAP, REDUCE, STENCIL, SCAN, FARM)
- Control flow (IF/ELSE, WHILE)
- Auto-versioning and undo
- Knowledge graph integration

Usage:
    chalkml -rm col 01N data.csv
    chalkml -fillsmart col 03N mean data.csv
    chalkml -map col 05N "x*2" data.csv

Version: 1.0.0
Author: Mankind Research Labs
"""

__version__ = "1.0.0"
__author__ = "Mankind Research Labs"

from .engine import ChalkMLEngine, get_chalkml_engine
from .knowledge_graph import KnowledgeGraph, get_knowledge_graph

__all__ = [
    'ChalkMLEngine',
    'get_chalkml_engine',
    'KnowledgeGraph',
    'get_knowledge_graph',
]
