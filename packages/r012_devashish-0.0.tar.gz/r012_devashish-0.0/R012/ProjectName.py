#Code goes here
import numpy as np
import time

# Define the environment grid (a simplified 2x2 Frozen Lake)
# 0: Start, 1: Frozen (safe), 2: Hole (bad), 3: Goal (good)
ENVIRONMENT = np.array([
    [0, 1],
    [2, 3]
])

# Map actions to changes in (row, col)
ACTIONS = {
    0: (0, 1),   # Right
    1: (0, -1),  # Left
    2: (1, 0),   # Down
    3: (-1, 0)   # Up
}

def q_learning_agent(episodes=1000):
    """
    Implements a Q-Learning agent to solve the 2x2 environment.
    """
    # Parameters
    gamma = 0.9      # Discount factor
    learning_rate = 0.1
    epsilon = 1.0    # Exploration-exploitation trade-off
    epsilon_decay = 0.999

    # Initialize Q-table (4 states x 4 actions)
    # States: (0,0), (0,1), (1,0), (1,1) -> 0 to 3
    # Actions: Right, Left, Down, Up -> 0 to 3
    Q_table = np.zeros((4, 4))
    
    # State mapping function (row, col) to a single index
    def get_state_index(row, col):
        return row * 2 + col

    # Training loop
    for episode in range(episodes):
        row, col = 0, 0 # Start state (0, 0)
        current_state = get_state_index(row, col)

        while ENVIRONMENT[row, col] != 3: # While not at the Goal
            # 1. Choose action (Epsilon-greedy strategy)
            if np.random.random() < epsilon:
                action_index = np.random.randint(4) # Explore
            else:
                action_index = np.argmax(Q_table[current_state, :]) # Exploit

            # 2. Determine new state and reward
            dr, dc = ACTIONS.get(action_index)
            
            # Boundary check
            new_row = np.clip(row + dr, 0, 1)
            new_col = np.clip(col + dc, 0, 1)
            
            # Check for wall/boundary (No movement if hitting wall)
            if new_row == row and new_col == col and (dr != 0 or dc != 0):
                reward = -0.1 # Small penalty for hitting a wall
            else:
                row, col = new_row, new_col

                # Determine reward based on new cell type
                cell_type = ENVIRONMENT[row, col]
                if cell_type == 3:
                    reward = 100 # Goal
                elif cell_type == 2:
                    reward = -100 # Hole (Episode should end here, but Q-table updates)
                    row, col = 0, 0 # Reset to start after falling in hole
                else:
                    reward = -1 # Step cost

            next_state = get_state_index(row, col)
            
            # 3. Update Q-table (Q-Learning formula)
            old_value = Q_table[current_state, action_index]
            next_max = np.max(Q_table[next_state, :])
            
            new_value = (1 - learning_rate) * old_value + learning_rate * (reward + gamma * next_max)
            Q_table[current_state, action_index] = new_value
            
            # Update current state
            current_state = next_state
        
        # Decay epsilon (less exploration over time)
        epsilon = max(0.01, epsilon * epsilon_decay)

    print(f"Training completed after {episodes} episodes.")
    print("\nFinal Q-Table:")
    print("Columns: [Right, Left, Down, Up]")
    print(Q_table)
    
    # Show the learned path
    print("\nOptimal Path Test (S: Start, G: Goal):")
    test_path(Q_table)

def test_path(Q_table):
    """Tests the learned optimal policy."""
    row, col = 0, 0
    path = [(row, col)]
    
    while ENVIRONMENT[row, col] != 3:
        current_state = row * 2 + col
        # Choose the action with the highest Q-value
        action_index = np.argmax(Q_table[current_state, :])
        dr, dc = ACTIONS.get(action_index)
        
        new_row = np.clip(row + dr, 0, 1)
        new_col = np.clip(col + dc, 0, 1)
        
        # Stop if no movement is possible (stuck)
        if new_row == row and new_col == col:
            break

        row, col = new_row, new_col
        path.append((row, col))
        
        # Prevent infinite loop if the policy is bad
        if len(path) > 10:
            print("Path stuck or too long.")
            break
            
    # Visualize the path
    grid = np.array([['S', '1'], ['2', 'G']])
    for r, c in path:
        if grid[r, c] not in ('S', 'G'):
            grid[r, c] = 'P' # Path marker
            
    print(grid)

if __name__ == '__main__':
    q_learning_agent()