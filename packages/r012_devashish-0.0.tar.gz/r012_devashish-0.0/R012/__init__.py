#Everthing you want to run when the module is initialized goes here
# __init__.py
from .ProjectName import q_learning_agent

# Optional: Define what happens when 'from R012 import *' is used
__all__ = ["q_learning_agent"] 

# To run the agent directly if R012 is the top-level script:
# if __name__ == '__main__':
#     q_learning_agent()