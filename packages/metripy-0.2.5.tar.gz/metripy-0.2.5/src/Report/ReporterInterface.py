from abc import ABC, abstractmethod

from Metric.ProjectMetrics import ProjectMetrics
from Application.Config.ReportConfig import ReportConfig
from Component.Output.CliOutput import CliOutput


class ReporterInterface(ABC):
    def __init__(
        self, config: ReportConfig, output: CliOutput, project_name: str = "foobar"
    ):
        self.config: ReportConfig = config
        self.output = output

    @abstractmethod
    def generate(self, metrics: ProjectMetrics) -> None:
        raise NotImplementedError()
