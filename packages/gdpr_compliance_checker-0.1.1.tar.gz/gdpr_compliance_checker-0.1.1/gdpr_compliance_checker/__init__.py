"""
GDPR Compliance Checker

A Python package for analyzing websites for GDPR compliance indicators.
"""

from .checker import GDPRChecker
from .models import ComplianceResult, CheckerConfig, ComplianceRule
from .batch import BatchChecker
from .exceptions import GDPRCheckerException, InvalidURLException, AnalysisException

__version__ = "0.1.1"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    "GDPRChecker",
    "ComplianceResult",
    "CheckerConfig",
    "ComplianceRule",
    "BatchChecker",
    "GDPRCheckerException",
    "InvalidURLException",
    "AnalysisException",
]
