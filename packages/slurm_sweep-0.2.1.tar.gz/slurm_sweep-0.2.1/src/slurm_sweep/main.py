from .cli import app  # noqa F401
