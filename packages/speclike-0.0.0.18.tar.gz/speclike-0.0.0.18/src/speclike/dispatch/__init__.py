
from speclike.dispatch.mod import Spec, Check

__all__ = ("Spec", "Check")
