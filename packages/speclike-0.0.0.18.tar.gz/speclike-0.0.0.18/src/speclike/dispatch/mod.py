from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Callable

import pytest
import inspect

_MARK_FOR_FEATURE_METHOD = "_speclike_feature_method"
_MARK_FOR_CHECK_METHOD = "_speclike_check_method"

_TEST_PREFIX = "test_"
_ACT_PREFIX = "act_"

_PYTESTMARK = "pytestmark"

class DispatcherMeta(type):

    _SPEC_ACT_CACHE: dict[type[Check], set[Callable]] = {}

    def __new__(mcls, name, bases, namespace: dict[str, Any]):
        tests = {}
        for k, v in namespace.items():
            if callable(v):
                if hasattr(v, _MARK_FOR_FEATURE_METHOD):
                    # class specific test name
                    cstname = _TEST_PREFIX + k
                    if not inspect.iscoroutinefunction(v):
                        tests[cstname] = mcls._make_feature_test(k, v)
                    else:
                        async_test = mcls._make_async_feature_test(k, v)
                        tests[cstname] = async_test
        
        for spec, acts in mcls._SPEC_ACT_CACHE.items():
            for act in acts:
                templatename, template, pytestmark = spec.get_details()
                actname = _ACT_PREFIX + templatename
                # common test name
                cmtname = _TEST_PREFIX + templatename
                tests[actname] = act
                tests[cmtname] = mcls._make_check_test(
                    cmtname, template, actname, pytestmark
                )

        mcls._SPEC_ACT_CACHE.clear()

        namespace.update(tests)

        return super().__new__(mcls, name, bases, namespace)

    @classmethod
    def register_spec(mcls, spec: type[Check], act: Callable):
        if not issubclass(spec, Check):
            raise TypeError(
                f"spec must be a subclass of \"{Check.__name__}\". " +
                f"but recieves -> \"{type(spec)}\"."
            )
        if spec not in mcls._SPEC_ACT_CACHE:
            mcls._SPEC_ACT_CACHE[spec] = set()
        mcls._SPEC_ACT_CACHE[spec].add(act)

    @staticmethod
    def _arrange_test_function(test_fn, test_name, src):
        """Set the name, signature, and line number for the generated test function.

        The line number corresponds to the src (template or native) defined in the user's code.
        """
        test_fn.__name__ = test_name
        test_fn.__signature__ = inspect.signature(src)
        test_fn.__code__ = test_fn.__code__.replace(
            co_firstlineno = src.__code__.co_firstlineno)
        return test_fn
    
    @staticmethod
    def _make_feature_test(name, unbound_method):
        def bridge(self, *args, **kwargs):
            bound_method = getattr(self, name)
            self.dispatch(name, bound_method, *args, **kwargs)
        DispatcherMeta._copy_pytestmark(src = unbound_method, dst = bridge)
        return DispatcherMeta._arrange_test_function(bridge, name, unbound_method)

    @staticmethod
    def _make_async_feature_test(name, unbound_method):
        async def bridge(self, *args, **kwargs):
            bound_method = getattr(self, name)
            await self.dispatch_async(name, bound_method, *args, **kwargs)
        DispatcherMeta._copy_pytestmark(src = unbound_method, dst = bridge)
        if not any(m.name == "asyncio" for m in getattr(bridge, _PYTESTMARK)):
            asyncio_mark = _create_pytestmark(pytest.mark.asyncio)
            getattr(bridge, _PYTESTMARK).append(asyncio_mark)
        return DispatcherMeta._arrange_test_function(bridge, name, unbound_method)
    
    @staticmethod
    def _copy_pytestmark(src, dst):
        if hasattr(src, _PYTESTMARK):
            tmp_pytestmark = getattr(src, _PYTESTMARK)
            setattr(dst, _PYTESTMARK, tmp_pytestmark)
    
    @staticmethod
    def _make_check_test(name, template, actname, pytestmark):
        def bridge(self, *args, **kwargs):
            bound_act = getattr(self, actname)
            template(bound_act, *args, **kwargs)
        if pytestmark:
            setattr(bridge, _PYTESTMARK, pytestmark)
        return DispatcherMeta._arrange_test_function(bridge, name, template)

def _create_pytestmark(decorator):
    def test_dummy(*_args, **_kwargs):
        pass
    return getattr(decorator(test_dummy), _PYTESTMARK)

def _normalize_pytestmark_to_list(pytestmark) -> list[Any]:
    """Normalize pytestmark to a list."""
    if pytestmark is None:
        return []
    if not isinstance(pytestmark, Iterable):
        return [pytestmark]
    else:
        return list(pytestmark)

def _synth_parametrize_mark(fn: Callable, *args, **kwargs):
    """Generate a parametrize mark based on the parameters and signature of the given function."""
    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())[1:]
    return _create_pytestmark(
        pytest.mark.parametrize(",".join(params), *args, **kwargs)
    )

def _place_pytestmark(src: Any, dst: Any, pytestmark):
    """Combine the pytestmark of `src` with the specified pytestmark and set it on `dst`.
    
    The pytestmark of `src` will be removed.
    """
    all_marks = _normalize_pytestmark_to_list(pytestmark)
    if hasattr(src, _PYTESTMARK):
        tmp_pytestmark = getattr(src, _PYTESTMARK)
        tmp_pytestmark = _normalize_pytestmark_to_list(tmp_pytestmark)
        all_marks.extend(tmp_pytestmark)
    setattr(dst, _PYTESTMARK, all_marks)


class FeatureMethodSpecifierChain:
    def __call__(self, method: Callable) -> Callable:
        return self._process(method, None)
    
    def follows(self, *args, **kwargs) -> Callable[[Callable], Callable]:
        def decorator(method) -> Callable:
            param_mark = _synth_parametrize_mark(method, *args, **kwargs)
            return self._process(method, param_mark)
        return decorator
    
    def _process(self, method: Callable, pytestmark) -> Callable:
        method_name = str(method.__name__)
        if not method_name.isidentifier():
            raise TypeError(
                f"Method name must be valid python identifier." +
                f"but recieves -> {method_name}"
            )
        if method_name.startswith("test") or method_name.startswith("_test"):
            raise TypeError(
                f"Method name must not start \"test\" or \"_test\"." +
                f"but recieves -> {method_name}"
            )
        _place_pytestmark(src = method, dst = method, pytestmark = pytestmark)
        setattr(method, _MARK_FOR_FEATURE_METHOD, 0)
        return method

class Spec(metaclass = DispatcherMeta):

    feature = FeatureMethodSpecifierChain()

    def dispatch(self, method_name: str, method: Callable, *args, **kwargs) -> None:
        method(*args, **kwargs)
    
    async def dispatch_async(
            self, method_name: str, method: Callable, *args, **kwargs
    ) -> None:
        await method(*args, **kwargs)



class CheckMethodSpecifierChain:
    def __call__(self, template: Callable) -> staticmethod:
        return self._process(template, None)
    
    def follows(self, *args, **kwargs) -> Callable[[Callable], staticmethod]:
        def decorator(template) -> staticmethod:
            param_mark = _synth_parametrize_mark(template, *args, **kwargs)
            return self._process(template, param_mark)
        return decorator
    
    def _process(self, template: Callable, pytestmark):
        if not callable(template):
            raise TypeError(
                "template must be a callable." +
                f"but recieved a not callable '{type(template)}' object."
            )
        sm = staticmethod(template)
        _place_pytestmark(src = template, dst = sm, pytestmark = pytestmark)
        setattr(sm, _MARK_FOR_CHECK_METHOD, 0)
        return sm

class CheckMeta(type):
    def __new__(mcls, name, bases, namespace: dict[str, Any]):
        if bases != (object,):
            def __new__(cls, act):
                if not callable(act):
                    raise TypeError(
                        "act must be a callable." +
                        f"but received a non-callable object of type '{type(act)}'."
                    )
                DispatcherMeta.register_spec(cls, act)

            namespace["__new__"] = __new__

        return super().__new__(mcls, name, bases, namespace)

class Check(metaclass = CheckMeta):

    of = CheckMethodSpecifierChain()

    @classmethod
    def get_details(cls) -> tuple[str, Callable, list[pytest.Mark] | None]:
        already_found = False
        for k, v in cls.__dict__.items():
            if hasattr(v, _MARK_FOR_CHECK_METHOD):
                if already_found:
                    raise TypeError(
                        f"Multiple template methods found. such as '{k}'."
                    )
                already_found = True
                if not isinstance(v, staticmethod):
                    raise TypeError(
                        f"template method must be a staticmethod. " +
                        f"but '{type(v)}' was found."
                    )
                template = v.__func__
                append_name = template.__name__ if template.__name__ != "_" else ""
                name = cls.__name__ + ("_" + append_name if append_name else "")
                pytestmark = None
                if hasattr(v, _PYTESTMARK):
                    pytestmark = list(getattr(v, _PYTESTMARK))
                return name, template, pytestmark
        raise TypeError(
            f"Missing a template method."
        )
    
    def __init__(self):
        raise RuntimeError(
            "Unexpected call. __new__ may have returned a non-None value."
        )

