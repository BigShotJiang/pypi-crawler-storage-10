'''Framework for Structuring Tests Based on pytest

Usage:

    import pytest
    from speclike import Spec, Check, setup, after


    # === Target of Testing =====================================================

    class Calculator:
        """A simple calculator class"""
        def add(self, a, b):
            if not all(isinstance(x, (int, float)) for x in (a, b)):
                raise TypeError("operands must be numeric")
            return a + b

        def subtract(self, a, b):
            if not all(isinstance(x, (int, float)) for x in (a, b)):
                raise TypeError("operands must be numeric")
            return a - b

        def divide(self, a, b):
            if not all(isinstance(x, (int, float)) for x in (a, b)):
                raise TypeError("operands must be numeric")
            if b == 0:
                raise ZeroDivisionError("cannot divide by zero")
            return a / b


    # === Common Validations (Check) =============================================

    class TypeError_when_not_number(Check):
        """Raises TypeError when non-numeric values are passed"""
        @Check.of.follows(("a", None), (1, "b"), (object(), 3))
        def _(act, a, b):
            obj = setup(lambda: Calculator())
            with pytest.raises(TypeError):
                act(obj, a, b)


    class ZeroDivision_not_allowed(Check):
        """Validates that division by zero is not allowed"""
        @Check.of.follows((10, 0), (0, 0), (-5, 0))
        def _(act, a, b):
            obj = setup(lambda: Calculator())
            with pytest.raises(ZeroDivisionError):
                act(obj, a, b)


    # === Functional Specifications (Spec) ==============================================

    class TestAddSpec(Spec):
        """Specifications for Calculator.add"""

        @Spec.feature.follows((1, 2), (-1, 1), (0, 0), (1.5, 2.5))
        def returns_sum(self, a, b):
            obj = setup(lambda: Calculator())
            result = obj.add(a, b)
            after(lambda: result == a + b)

        @TypeError_when_not_number
        def _(obj: Calculator, a, b):
            obj.add(a, b)


    class TestSubtractSpec(Spec):
        """Specifications for Calculator.subtract"""

        @Spec.feature.follows((1, 2), (-1, 1), (3.5, 2.5))
        def returns_difference(self, a, b):
            obj = setup(lambda: Calculator())
            result = obj.subtract(a, b)
            after(lambda: result == a - b)

        @TypeError_when_not_number
        def _(obj: Calculator, a, b):
            obj.subtract(a, b)


    class TestDivideSpec(Spec):
        """Specifications for Calculator.divide"""

        @Spec.feature.follows((10, 2), (-6, 3), (5.0, 2.0))
        def returns_quotient(self, a, b):
            obj = setup(lambda: Calculator())
            result = obj.divide(a, b)
            after(lambda: result == a / b)

        @TypeError_when_not_number
        def _(obj: Calculator, a, b):
            obj.divide(a, b)

        @ZeroDivision_not_allowed
        def _(obj: Calculator, a, b):
            obj.divide(a, b)


Examples of tests generated during pytest execution:

- test_returns_sum[1-2]
- test_returns_difference[3.5-2.5]
- test_returns_quotient[10-2]
- test_TypeError_when_not_number_add[a-None]
- test_ZeroDivision_not_allowed[10-0]
...and so on.

In other words, for each Spec (specification), "normal feature tests" and
"common Check-based abnormal tests" are automatically structured.

By following pytest's auto-discovery conventions, starting class names with `Test`
allows for natural execution of individual tests from IDEs or the CLI.
'''
from speclike.mark import setup, invariant, before, after
from speclike.dispatch import Spec, Check

__all__ = [
    "setup", "invariant", "before", "after",
    "Spec", "Check"
]

