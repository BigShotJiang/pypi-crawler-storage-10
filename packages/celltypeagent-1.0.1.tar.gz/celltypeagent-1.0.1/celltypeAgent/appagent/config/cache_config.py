#!/usr/bin/env python3
"""
celltypeAgent - 缓存配置管理模块（兼容性层）
Author: cuilei
Version: 1.0
"""

import os
import json
import sys
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

# 导入统一配置系统
try:
    # 优先尝试从包内导入统一配置
    from celltypeAgent.config import get_global_config, get_cache_dir as global_get_cache_dir
    UNIFIED_CONFIG_AVAILABLE = True
except ImportError:
    try:
        # 回退到根目录config
        current_dir = Path(__file__).resolve().parent.parent.parent  # 回到根目录
        sys.path.insert(0, str(current_dir))
        from config import get_global_config, get_cache_dir as global_get_cache_dir
        UNIFIED_CONFIG_AVAILABLE = True
    except ImportError:
        print("警告：统一配置系统不可用，回退到原有系统")
        UNIFIED_CONFIG_AVAILABLE = False

# 全局缓存配置（仅在回退模式下使用）
_CACHE_DIR = None
_CACHE_CONFIG = {}

def init_cache(cache_dir: Optional[str] = None) -> Path:
    """
    初始化缓存目录
    
    Args:
        cache_dir: 可选的缓存目录路径，如果为None则使用默认路径
        
    Returns:
        缓存目录的Path对象
    """
    global _CACHE_DIR, _CACHE_CONFIG

    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        config = get_global_config()
        cache_dir = config.get_cache_dir("celltypeAppAgent")

        # 注释：子目录现在按需创建，不再预先创建
        # 原来的子目录（celldex, sctype, celltypist, temp, logs）现在不使用
        # 因为各工具已改用统一配置，直接保存到 cache_dir 根目录

        _CACHE_DIR = cache_dir
        _CACHE_CONFIG = {
            "cache_dir": str(cache_dir),
            "initialized_at": datetime.now().isoformat(),
            "unified_config": True
        }

        return cache_dir
    else:
        # 回退到原有系统
        if cache_dir is None:
            # 使用默认缓存目录
            cache_dir = Path.cwd() / ".celltype_cache"
        else:
            cache_dir = Path(cache_dir)

        # 展开用户目录
        cache_dir = cache_dir.expanduser().resolve()

        # 创建目录
        cache_dir.mkdir(parents=True, exist_ok=True)

        # 注释：子目录现在按需创建，不再预先创建
        # 原来的子目录（celldex, sctype, celltypist, temp, logs）现在不使用

        _CACHE_DIR = cache_dir
        _CACHE_CONFIG = {
            "cache_dir": str(cache_dir),
            "initialized_at": datetime.now().isoformat()
        }

        # 缓存目录初始化完成（静默模式，避免污染 MCP stdout）
        return cache_dir

def set_cache_dir(cache_dir: str) -> Path:
    """
    设置缓存目录

    Args:
        cache_dir: 缓存目录路径

    Returns:
        缓存目录的Path对象
    """
    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统，忽略传入的cache_dir
        config = get_global_config()
        return config.get_cache_dir("celltypeAppAgent")
    else:
        # 回退到原有系统
        return init_cache(cache_dir)

def get_cache_dir(subdir: str = "") -> Path:
    """
    获取当前缓存目录

    Args:
        subdir: 子目录名称（与其他Agent保持兼容）

    Returns:
        缓存目录的Path对象
    """
    global _CACHE_DIR

    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        if subdir:
            return global_get_cache_dir(f"celltypeAppAgent/{subdir}")
        else:
            return global_get_cache_dir("celltypeAppAgent")
    else:
        # 回退到原有系统
        if _CACHE_DIR is None:
            _CACHE_DIR = init_cache()

        if subdir:
            subdir_path = _CACHE_DIR / subdir
            subdir_path.mkdir(exist_ok=True)
            return subdir_path
        return _CACHE_DIR

def get_cache_subdir(subdir: str) -> Path:
    """
    获取缓存子目录（兼容性函数）
    
    Args:
        subdir: 子目录名称

    Returns:
        子目录的Path对象
    """
    return get_cache_dir(subdir)

def get_cache_info() -> Dict[str, Any]:
    """
    获取缓存目录信息
    
    Returns:
        缓存信息字典
    """
    cache_dir = get_cache_dir()
    
    info = {
        "cache_dir": str(cache_dir),
        "exists": cache_dir.exists(),
        "size_mb": 0,
        "subdirs": {},
        "config": _CACHE_CONFIG
    }
    
    if cache_dir.exists():
        # 计算目录大小
        total_size = 0
        for file_path in cache_dir.rglob('*'):
            if file_path.is_file():
                total_size += file_path.stat().st_size
        
        info["size_mb"] = round(total_size / (1024 * 1024), 2)
        
        # 统计子目录信息
        for item in cache_dir.iterdir():
            if item.is_dir():
                file_count = len(list(item.rglob('*')))
                info["subdirs"][item.name] = {
                    "file_count": file_count,
                    "path": str(item)
                }
    
    return info

def clear_cache(subdir: Optional[str] = None) -> Dict[str, Any]:
    """
    清理缓存
    
    Args:
        subdir: 可选的子目录名，如果提供则只清理指定子目录
        
    Returns:
        清理结果信息
    """
    import shutil
    
    cache_dir = get_cache_dir()
    result = {
        "cleared": False,
        "message": "",
        "deleted_files": 0,
        "freed_mb": 0
    }
    
    try:
        if subdir:
            # 清理指定子目录
            target_dir = cache_dir / subdir
            if target_dir.exists():
                # 计算要删除的文件大小
                total_size = 0
                file_count = 0
                for file_path in target_dir.rglob('*'):
                    if file_path.is_file():
                        total_size += file_path.stat().st_size
                        file_count += 1
                
                shutil.rmtree(target_dir)
                target_dir.mkdir(exist_ok=True)
                
                result.update({
                    "cleared": True,
                    "message": f"已清理子目录: {subdir}",
                    "deleted_files": file_count,
                    "freed_mb": round(total_size / (1024 * 1024), 2)
                })
            else:
                result["message"] = f"子目录不存在: {subdir}"
        else:
            # 清理整个缓存目录
            if cache_dir.exists():
                # 计算要删除的文件大小
                total_size = 0
                file_count = 0
                for file_path in cache_dir.rglob('*'):
                    if file_path.is_file() and file_path.name != "cache_config.json":
                        total_size += file_path.stat().st_size
                        file_count += 1
                
                # 删除除配置文件外的所有内容
                for item in cache_dir.iterdir():
                    if item.name != "cache_config.json":
                        if item.is_dir():
                            shutil.rmtree(item)
                        else:
                            item.unlink()
                
                # 重新创建子目录
                init_cache(str(cache_dir))
                
                result.update({
                    "cleared": True,
                    "message": "已清理整个缓存目录",
                    "deleted_files": file_count,
                    "freed_mb": round(total_size / (1024 * 1024), 2)
                })
            else:
                result["message"] = "缓存目录不存在"
                
    except Exception as e:
        result.update({
            "cleared": False,
            "message": f"清理失败: {str(e)}"
        })
    
    return result

# 自动初始化默认缓存目录
if _CACHE_DIR is None:
    init_cache()