#!/usr/bin/env python3
"""
celltypeAgent - MainAgent MCP Server
Author: cuilei
Version: 1.0
"""

from __future__ import annotations

import os
import json
import asyncio
from pathlib import Path
from typing import Any, Dict, Optional, Union

# 导入项目模块
import sys

# 依赖导入
try:
    from mcp.server.fastmcp import FastMCP
except Exception as e:
    print(f"导入FastMCP失败: {e}\n请先安装依赖：pip install mcp")
    sys.exit(1)

# 本项目内部依赖
from celltypeAgent.mainagent.config.settings import ConfigManager
from celltypeAgent.mainagent.config.cache_config import CacheManager, init_cache

# 国际化占位（与DataAgent风格保持一致）
try:
    from celltypeAgent.mainagent.utils.i18n import _  # 若存在 _(key, **kwargs)
except Exception:
    def _(key: str, **kwargs):
        return key.format(**kwargs) if kwargs else key

# 导入工具函数
from celltypeAgent.mainagent.tools.subagent_tools import process_data, run_annotation_pipeline, analyze_gene_list
from celltypeAgent.mainagent.tools.file_paths_tools import (
    save_file_paths_bundle as _save_file_paths_bundle,
    load_file_paths_bundle as _load_file_paths_bundle,
    load_and_validate_bundle as _load_and_validate_bundle,
    list_saved_bundles as _list_saved_bundles,
    clear_expired_bundles as _clear_expired_bundles,
    delete_bundle as _delete_bundle
)

# 导入会话配置
from celltypeAgent.mainagent.config.session_config import (
    create_session_id,
    set_session_id,
    get_session_id,
    get_session_info
)

# 为避免启动时硬依赖不可用模块，改为在对应工具内惰性导入。
# 如模块缺失，工具将返回结构化的错误信息，而不影响服务器启动。


# ========== 全局对象 ==========
mcp = FastMCP("celltype-main-agent", log_level="INFO")

# ========== 会话管理 ==========
# 🌟 生成并设置当前进程的会话ID（每个进程独立）
SESSION_ID = create_session_id()
set_session_id(SESSION_ID)

# 🗑️ 启动时清理旧的路径包文件
def cleanup_old_path_bundles():
    """在MCP Server启动时清理cache目录中的所有旧路径包文件"""
    try:
        from celltypeAgent.mainagent.tools.file_paths_tools import FilePathsManager

        manager = FilePathsManager()
        bundle_dir = manager.bundle_dir

        if bundle_dir.exists():
            deleted_count = 0
            for old_file in bundle_dir.glob("celltype_file_paths_*.json"):
                try:
                    old_file.unlink()
                    deleted_count += 1
                except Exception as e:
                    print(f"⚠️ 删除失败 {old_file.name}: {e}", file=sys.stderr)

            if deleted_count > 0:
                print(f"🗑️ 已清理 {deleted_count} 个旧路径包", file=sys.stderr)
            else:
                print("✅ 无需清理，cache目录中没有旧路径包", file=sys.stderr)
        else:
            print(f"✅ 路径包目录尚未创建: {bundle_dir}", file=sys.stderr)

        print("✅ 路径包清理完成，开始新会话", file=sys.stderr)
    except Exception as e:
        print(f"⚠️ 路径包清理失败: {e}", file=sys.stderr)

# 执行清理
# cleanup_old_path_bundles()  # ❌ 已禁用：保留测试数据，不再自动清理 cache 目录

# 尝试从 JSON 文件加载配置，如果失败则使用环境变量
try:
    from celltypeAgent.mainagent.tools.subagent_tools import load_config_from_json

    json_config = load_config_from_json()
    if json_config:
        # 设置环境变量，让子Agent能够找到正确的配置文件
        # 获取实际使用的配置文件路径
        config_file_path = None
        env_config_path = os.getenv("CELLTYPE_CONFIG_PATH")
        if env_config_path and Path(env_config_path).exists():
            config_file_path = env_config_path
        else:
            # 搜索当前工作目录下的配置文件
            current_config = Path.cwd() / "celltypeAgent_config.json"
            if current_config.exists():
                config_file_path = str(current_config.resolve())

        # 设置环境变量供子Agent使用
        if config_file_path:
            os.environ["CELLTYPE_CONFIG_PATH"] = config_file_path

            # 优先从配置文件读取 project_root 作为工作目录
            paths_config = json_config.get('paths', {})
            project_root = paths_config.get('project_root')

            if project_root and Path(project_root).exists():
                # 使用配置文件中的 project_root
                os.environ["CELLTYPE_WORK_DIR"] = str(project_root)
                print(f"🔧 设置子Agent工作目录（来自配置）: {project_root}", file=sys.stderr)
            else:
                # 回退使用当前工作目录
                work_dir = str(Path.cwd())
                os.environ["CELLTYPE_WORK_DIR"] = work_dir
                print(f"🔧 设置子Agent工作目录（当前目录）: {work_dir}", file=sys.stderr)

            print(f"🔧 设置子Agent配置文件路径: {config_file_path}", file=sys.stderr)

        llm_config = json_config.get('llm', {})
        project_config = json_config.get('project', {})

        resolved_model = (
            llm_config.get('model')
            or llm_config.get('openai_model')
            or 'gpt-4o'
        )

        config = ConfigManager(
            openai_api_base=llm_config.get('api_base') or llm_config.get('openai_api_base'),
            openai_api_key=llm_config.get('api_key') or llm_config.get('openai_api_key'),
            openai_model=resolved_model,
            language=project_config.get('language', 'zh'),
            enable_streaming=project_config.get('enable_streaming', True),
            cache_dir=project_config.get('cache_dir', '.celltype_cache'),
            log_dir=project_config.get('log_dir', 'logs')
        )
        print(f"✅ MCP服务器使用JSON配置: {resolved_model}", file=sys.stderr)
    else:
        config = ConfigManager.from_env()
        print("⚠️ MCP服务器使用环境变量配置", file=sys.stderr)
except Exception as e:
    config = ConfigManager.from_env()
    print(f"⚠️ 加载JSON配置失败，使用环境变量配置: {e}", file=sys.stderr)

cache = init_cache(config.cache_dir)
cache_manager = CacheManager(config.cache_dir)

# 缓存目录（与DataAgent风格一致）
CACHE_DIR = str(cache_manager.cache_dir)

def ensure_cache_dir() -> str:
    os.makedirs(CACHE_DIR, exist_ok=True)
    return CACHE_DIR

def _ensure_abs(path: Optional[str]) -> Optional[str]:
    return str(Path(path).resolve()) if path else None



# ========== 数据预处理 ==========
@mcp.tool()
async def enhanced_data_processing(input_data: str, species: Optional[str] = None) -> str:
    """根据输入数据类型自动选择 DataAgent 的合适工具完成预处理与标准输出。

    支持 .rds / .h5ad / .h5 / .csv / .json

    Args:
        input_data: 输入数据路径
        species: 可选的物种参数 (如 "Human", "Mouse")，如果不提供则自动检测
    """
    try:
        ensure_cache_dir()
        abs_input = _ensure_abs(input_data)
        if not abs_input:
            return json.dumps({"success": False, "error": "缺少必要的输入数据参数"}, ensure_ascii=False, indent=2)
        # 直接调用子Agent封装函数，传递species参数
        result = process_data(abs_input, species=species, config=config)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"数据预处理异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 细胞注释 ==========
@mcp.tool()
async def enhanced_cell_annotation(
    rds_path: Optional[str] = None,
    h5ad_path: Optional[str] = None,
    h5_path: Optional[str] = None,
    marker_json_path: Optional[str] = None,
    tissue_description: Optional[str] = None,
    species: Optional[str] = None,
    cluster_column: Optional[str] = None,
) -> str:
    """调用 AppAgent 的多种注释工具（SingleR / scType / CellTypist）。

    目标：尽量根据可用输入运行更多方法，返回汇总结构。
    """
    try:
        ensure_cache_dir()
        result = run_annotation_pipeline(
            rds_path=_ensure_abs(rds_path) if rds_path else None,
            h5ad_path=_ensure_abs(h5ad_path) if h5ad_path else None,
            tissue_description=tissue_description,
            marker_json_path=_ensure_abs(marker_json_path) if marker_json_path else None,
            species=species,
            h5_path=_ensure_abs(h5_path) if h5_path else None,
            cluster_column=cluster_column,
            config=config,
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"细胞注释异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 基因分析 ==========
@mcp.tool()
async def enhanced_gene_analysis(
    gene_list: str,
    tissue_type: Optional[str] = None,
    species: str = "HUMAN"
) -> str:
    """调用 Subagent 的基因相关工具（基因信息、CellMarker/PanglaoDB富集、GO/KEGG）。

    🔄 自动路径echo机制：
    在第四阶段循环处理cluster时，此函数会自动从最新保存的路径包中读取路径信息：
    - marker_genes_json: 用于 extract_cluster_genes 提取基因
    - singler_result, sctype_result, celltypist_result: 用于 read_cluster_results 读取注释

    这些路径会在返回值的 remember_paths 中自动echo回来，防止长循环（30+次）中路径丢失。
    无需手动传递路径参数，函数内部会自动加载！

    Args:
        gene_list: 基因列表（逗号分隔）
        tissue_type: 组织类型
        species: 物种，默认HUMAN
    """
    try:
        ensure_cache_dir()
        # 注意：species 参数目前在 analyze_gene_list 中未使用，但保留以便兼容
        if not gene_list:
            return json.dumps({"success": False, "error": "缺少基因列表参数"}, ensure_ascii=False, indent=2)

        # 导入 analyze_gene_list_via_subagent（自动从路径包读取路径）
        from celltypeAgent.mainagent.tools.subagent_tools import analyze_gene_list_via_subagent

        result = analyze_gene_list_via_subagent(
            gene_list=gene_list,
            tissue_type=tissue_type,
            config=config
        )

        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"基因分析异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 簇级结果读写 ==========
@mcp.tool()
async def read_cluster_results(
    cluster: str,
    singler_result: Optional[str] = None,
    sctype_result: Optional[str] = None,
    celltypist_result: Optional[str] = None
) -> str:
    """从常用方法的结果 JSON 中读取指定簇的合并结果。

    Args:
        cluster: 簇ID，例如 "cluster0" 或 "0"
        singler_result: SingleR 结果 JSON 路径（可选，默认自动读取当前 session 的结果文件）
        sctype_result: scType 结果 JSON 路径（可选，默认自动读取当前 session 的结果文件）
        celltypist_result: CellTypist 结果 JSON 路径（可选，默认自动读取当前 session 的结果文件）

    Returns:
        包含各方法结果的合并字典的 JSON 字符串
    """
    try:
        try:
            from celltypeAgent.mainagent.tools.cluster_tools import read_cluster_results as _read_cluster_results  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.read_cluster_results: {e}"}, ensure_ascii=False, indent=2)

        # 直接传递参数，让底层函数处理 None 值和自动加载
        out = _read_cluster_results(
            cluster=cluster,
            singler_result=_ensure_abs(singler_result) if singler_result else None,
            sctype_result=_ensure_abs(sctype_result) if sctype_result else None,
            celltypist_result=_ensure_abs(celltypist_result) if celltypist_result else None
        )
        return json.dumps(out, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"读取簇结果异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def save_cluster_type(cluster_id: str, cell_type: str, dir_path: str = None) -> str:
    """保存单个簇的注释类型到缓存目录。"""
    try:
        try:
            from celltypeAgent.mainagent.tools.cluster_tools import save_cluster_type as _save_cluster_type  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.save_cluster_type: {e}"}, ensure_ascii=False, indent=2)
        if dir_path:
            path = _save_cluster_type(cluster_id, cell_type, dir_path=dir_path)
        else:
            path = _save_cluster_type(cluster_id, cell_type)
        return json.dumps({"success": True, "path": path}, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"保存异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def load_cluster_types(dir_path: str = None) -> str:
    """读取所有已保存的簇→类型映射。"""
    try:
        try:
            from celltypeAgent.mainagent.tools.cluster_tools import load_cluster_types as _load_cluster_types  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.load_cluster_types: {e}"}, ensure_ascii=False, indent=2)
        if dir_path:
            mapping = _load_cluster_types(dir_path=dir_path)
        else:
            mapping = _load_cluster_types()
        return json.dumps({"success": True, "mapping": mapping}, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"读取异常: {e}"}, ensure_ascii=False, indent=2)


# @mcp.tool()
# async def unify_cell_type_names(cluster_mapping_data: Union[str, Dict], output_json_path: str) -> str:
#     """将细胞类型映射保存为JSON文件。

#     Args:
#         cluster_mapping_data: 映射数据，可以是JSON字符串或字典
#         output_json_path: 输出json文件路径

#     Returns:
#         包含成功状态的JSON字符串，失败时包含错误信息
#     """
#     try:
#         try:
#             from celltypeAgent.mainagent.tools.cluster_tools import unify_cell_type_names as _unify_cell_type_names  # type: ignore
#         except Exception as e:
#             return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.unify_cell_type_names: {e}"}, ensure_ascii=False, indent=2)

#         abs_output_path = _ensure_abs(output_json_path)
#         if not abs_output_path:
#             return json.dumps({"success": False, "error": "无效的输出文件路径"}, ensure_ascii=False, indent=2)

#         # 处理cluster_mapping_data参数 - 支持字典和字符串格式
#         if isinstance(cluster_mapping_data, dict):
#             # 如果传入的是字典，转换为JSON字符串
#             json_string = json.dumps(cluster_mapping_data, ensure_ascii=False)
#         elif isinstance(cluster_mapping_data, str):
#             # 如果传入的是字符串，直接使用
#             json_string = cluster_mapping_data
#         else:
#             return json.dumps({"success": False, "error": f"不支持的cluster_mapping_data类型: {type(cluster_mapping_data)}"}, ensure_ascii=False, indent=2)

#         result = _unify_cell_type_names(json_string, abs_output_path)
#         return json.dumps(result, ensure_ascii=False, indent=2)
#     except Exception as e:
#         return json.dumps({"success": False, "error": f"统一化处理异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 基因提取工具 ==========
@mcp.tool()
async def get_all_cluster_ids(marker_genes_json_path: Optional[str] = None) -> str:
    """获取 JSON 文件中所有簇的编号。

    Args:
        marker_genes_json_path: 包含簇基因信息的 JSON 文件路径（可选，默认自动读取当前 session 的 marker genes 文件）

    Returns:
        包含所有簇编号列表的 JSON 字符串
    """
    try:
        from celltypeAgent.mainagent.tools.cluster_tools import get_all_cluster_ids as _get_all_cluster_ids

        # 直接传递参数，让底层函数处理 None 值和自动加载
        abs_path = _ensure_abs(marker_genes_json_path) if marker_genes_json_path else None
        cluster_ids = _get_all_cluster_ids(marker_genes_json_path=abs_path)

        return json.dumps({
            "success": True,
            "cluster_ids": cluster_ids,
            "total_clusters": len(cluster_ids)
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"获取簇编号异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def extract_cluster_genes(cluster_name: str, gene_count: int = 50, marker_genes_json_path: Optional[str] = None) -> str:
    """从 JSON 文件中提取指定簇的基因。

    Args:
        cluster_name: 簇名称（支持 "cluster0", "0" 等格式）
        gene_count: 要提取的基因数量，默认50
        marker_genes_json_path: 包含簇基因信息的 JSON 文件路径（可选，默认自动读取当前 session 的 marker genes 文件）

    Returns:
        包含基因列表的 JSON 字符串
    """
    try:
        from celltypeAgent.mainagent.tools.cluster_tools import extract_cluster_genes as _extract_cluster_genes

        # 参数验证
        if gene_count <= 0:
            return json.dumps({"success": False, "error": "基因数量必须大于 0"}, ensure_ascii=False, indent=2)

        # 直接传递参数，让底层函数处理 None 值和自动加载
        abs_path = _ensure_abs(marker_genes_json_path) if marker_genes_json_path else None
        result = _extract_cluster_genes(
            cluster_name=cluster_name,
            gene_count=gene_count,
            marker_genes_json_path=abs_path
        )

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({"success": False, "error": f"提取基因异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 写回 Seurat/AnnData ==========
@mcp.tool()
async def map_cluster_types(seurat_path: str, mapping_json_or_path: Union[str, Dict[str, str]], cluster_col: str = "seurat_clusters", output_col: str = "celltypeAgent", output_rds: Optional[str] = None) -> str:
    """将映射写回 Seurat 对象（RDS/H5），返回 R 侧的摘要信息。

    Args:
        seurat_path: Seurat对象文件路径
        mapping_json_or_path: JSON文件路径、JSON字符串，或字典对象
        cluster_col: 簇列名，默认"seurat_clusters"
        output_col: 输出列名，默认"celltypeAgent"
        output_rds: 输出文件路径，可选
    """
    try:
        ensure_cache_dir()
        try:
            from celltypeAgent.mainagent.tools.mapping_tools import map_cluster_types as _map_cluster_types  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: mapping_tools.map_cluster_types: {e}"}, ensure_ascii=False, indent=2)
        summary = await asyncio.get_event_loop().run_in_executor(
            None,
            _map_cluster_types,
            _ensure_abs(seurat_path),
            mapping_json_or_path,
            cluster_col,
            output_col,
            output_rds,
        )
        return json.dumps({"success": True, **summary}, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"写回Seurat异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def apply_cluster_mapping_to_adata(h5ad_path: str, mapping_json_or_path: Union[str, Dict[str, str]], cluster_col: str = "seurat_clusters", output_file: Optional[str] = None, output_col: str = "celltypeAgent") -> str:
    """将映射写入 AnnData.obs 并保存新的 H5AD 文件。"""
    try:
        ensure_cache_dir()
        try:
            from celltypeAgent.mainagent.tools.adata_mapping import map_cluster_types_to_adata  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: adata_mapping.map_cluster_types_to_adata: {e}"}, ensure_ascii=False, indent=2)

        in_path = _ensure_abs(h5ad_path)
        out_path = _ensure_abs(output_file) if output_file else None

        # 使用新的主函数，在 executor 中运行以避免阻塞
        def _process():
            return map_cluster_types_to_adata(
                h5ad_path=in_path,
                mapping_json_or_path=mapping_json_or_path,
                cluster_col=cluster_col,
                output_col=output_col,
                output_h5ad=out_path
            )

        summary = await asyncio.get_event_loop().run_in_executor(None, _process)
        return json.dumps(summary, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"写回AnnData异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def map_cluster_types_from_saved(
    cluster_col: str = "seurat_clusters",
    output_col: str = "celltypeAgent",
    output_rds: Optional[str] = None,
    seurat_path: Optional[str] = None
) -> str:
    """从已保存的簇映射写回Seurat对象（自动从缓存读取映射和数据文件路径）

    此工具直接从 load_cluster_types() 读取映射，无需传入JSON参数。
    自动从当前 session 路径包中读取数据文件（优先 rds_file，降级到 h5_file）。
    适用于第七阶段，避免JSON转义问题。

    Args:
        cluster_col: 簇列名，默认"seurat_clusters"
        output_col: 输出列名，默认"celltypeAgent"
        output_rds: 输出文件路径，可选
        seurat_path: Seurat对象文件路径，可选（不传则自动从路径包读取）

    Returns:
        JSON格式的写回结果
    """
    try:
        ensure_cache_dir()

        # 1. 加载已保存的映射
        try:
            from celltypeAgent.mainagent.tools.cluster_tools import load_cluster_types as _load_cluster_types  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.load_cluster_types: {e}"}, ensure_ascii=False, indent=2)

        mapping = _load_cluster_types()

        if not mapping:
            return json.dumps({
                "success": False,
                "error": "未找到已保存的簇映射，请确保第四阶段已完成并保存了所有簇的注释"
            }, ensure_ascii=False, indent=2)

        # 2. 🌟 自动识别 Seurat 数据文件路径（优先 rds，降级 h5）
        if seurat_path is None:
            try:
                from celltypeAgent.mainagent.tools.file_paths_tools import load_file_paths_bundle
                bundle = load_file_paths_bundle()

                if bundle.get("success"):
                    # 优先尝试 rds_file
                    rds_file = bundle.get("rds_file")
                    if rds_file and os.path.exists(rds_file):
                        seurat_path = rds_file
                        print(f"✅ 自动识别到 RDS 文件: {rds_file}")
                    else:
                        # 降级到 h5_file
                        h5_file = bundle.get("h5_file")
                        if h5_file and os.path.exists(h5_file):
                            seurat_path = h5_file
                            print(f"⚠️ 未找到 RDS 文件，降级使用 H5 文件: {h5_file}")

                if seurat_path is None:
                    return json.dumps({
                        "success": False,
                        "error": "未找到 Seurat 数据文件。请确保路径包中包含 rds_file 或 h5_file，或手动传入 seurat_path 参数。"
                    }, ensure_ascii=False, indent=2)

            except Exception as e:
                return json.dumps({
                    "success": False,
                    "error": f"自动加载 Seurat 路径失败: {e}。请手动传入 seurat_path 参数。"
                }, ensure_ascii=False, indent=2)

        # 3. 调用原始map_cluster_types函数
        try:
            from celltypeAgent.mainagent.tools.mapping_tools import map_cluster_types as _map_cluster_types  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: mapping_tools.map_cluster_types: {e}"}, ensure_ascii=False, indent=2)

        summary = await asyncio.get_event_loop().run_in_executor(
            None,
            _map_cluster_types,
            _ensure_abs(seurat_path),
            mapping,  # 直接传入字典，避免JSON转义问题
            cluster_col,
            output_col,
            output_rds
        )

        return json.dumps({"success": True, **summary}, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"从已保存映射写回Seurat异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def apply_cluster_mapping_to_adata_from_saved(
    cluster_col: str = "seurat_clusters",
    output_col: str = "celltypeAgent",
    output_file: Optional[str] = None,
    h5ad_path: Optional[str] = None
) -> str:
    """从已保存的簇映射写回AnnData对象（自动从缓存读取映射和数据文件路径）

    此工具直接从 load_cluster_types() 读取映射，无需传入JSON参数。
    自动从当前 session 路径包中读取数据文件（优先 h5ad_file，降级到 h5_file）。
    适用于第八阶段，避免JSON转义问题。

    Args:
        cluster_col: 簇列名，默认"seurat_clusters"
        output_col: 输出列名，默认"celltypeAgent"
        output_file: 输出文件路径，可选
        h5ad_path: H5AD文件路径，可选（不传则自动从路径包读取）

    Returns:
        JSON格式的写回结果
    """
    try:
        ensure_cache_dir()

        # 1. 加载已保存的映射
        try:
            from celltypeAgent.mainagent.tools.cluster_tools import load_cluster_types as _load_cluster_types  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.load_cluster_types: {e}"}, ensure_ascii=False, indent=2)

        mapping = _load_cluster_types()

        if not mapping:
            return json.dumps({
                "success": False,
                "error": "未找到已保存的簇映射，请确保第四阶段已完成并保存了所有簇的注释"
            }, ensure_ascii=False, indent=2)

        # 2. 🌟 自动识别 AnnData 数据文件路径（优先 h5ad，降级 h5）
        if h5ad_path is None:
            try:
                from celltypeAgent.mainagent.tools.file_paths_tools import load_file_paths_bundle
                bundle = load_file_paths_bundle()

                if bundle.get("success"):
                    # 优先尝试 h5ad_file
                    h5ad_file = bundle.get("h5ad_file")
                    if h5ad_file and os.path.exists(h5ad_file):
                        h5ad_path = h5ad_file
                        print(f"✅ 自动识别到 H5AD 文件: {h5ad_file}")
                    else:
                        # 降级到 h5_file
                        h5_file = bundle.get("h5_file")
                        if h5_file and os.path.exists(h5_file):
                            h5ad_path = h5_file
                            print(f"⚠️ 未找到 H5AD 文件，降级使用 H5 文件: {h5_file}")

                if h5ad_path is None:
                    return json.dumps({
                        "success": False,
                        "error": "未找到 AnnData 数据文件。请确保路径包中包含 h5ad_file 或 h5_file，或手动传入 h5ad_path 参数。"
                    }, ensure_ascii=False, indent=2)

            except Exception as e:
                return json.dumps({
                    "success": False,
                    "error": f"自动加载 AnnData 路径失败: {e}。请手动传入 h5ad_path 参数。"
                }, ensure_ascii=False, indent=2)

        # 3. 调用原始apply函数
        try:
            from celltypeAgent.mainagent.tools.adata_mapping import map_cluster_types_to_adata  # type: ignore
        except Exception as e:
            return json.dumps({"success": False, "error": f"依赖缺失: adata_mapping.map_cluster_types_to_adata: {e}"}, ensure_ascii=False, indent=2)

        in_path = _ensure_abs(h5ad_path)
        out_path = _ensure_abs(output_file) if output_file else None

        # 使用新的主函数，在 executor 中运行以避免阻塞
        def _process():
            return map_cluster_types_to_adata(
                h5ad_path=in_path,
                mapping_json_or_path=mapping,  # 直接传入字典，避免JSON转义问题
                cluster_col=cluster_col,
                output_col=output_col,
                output_h5ad=out_path
            )

        summary = await asyncio.get_event_loop().run_in_executor(None, _process)
        return json.dumps(summary, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"从已保存映射写回AnnData异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 文件路径管理工具 ==========
@mcp.tool()
async def save_file_paths_bundle(
    rds_file: Optional[str] = None,
    h5ad_file: Optional[str] = None,
    h5_file: Optional[str] = None,
    marker_genes_json: Optional[str] = None,
    singler_result: Optional[str] = None,
    sctype_result: Optional[str] = None,
    celltypist_result: Optional[str] = None,
    metadata: Optional[str] = None,  # JSON字符串格式（非必须）
    session_id: Optional[str] = None,
    expiry_hours: Optional[int] = None
) -> str:
    """保存文件路径信息包到系统临时目录。

    将包含7个核心文件路径的信息保存到跨平台兼容的临时目录中，
    支持自动过期清理和会话管理。适用于保存分析流程中的文件路径组合。

    Args:
        rds_file: RDS文件路径
        h5ad_file: H5AD文件路径
        h5_file: H5文件路径
        marker_genes_json: Marker基因JSON文件路径
        singler_result: SingleR结果文件路径
        sctype_result: scType结果文件路径
        celltypist_result: CellTypist结果文件路径
        metadata: 额外元数据(JSON字符串格式,非必须)
        session_id: 会话ID(如果不提供则自动生成)
        expiry_hours: 过期时间(小时,默认24小时)

    Returns:
        JSON格式的保存结果
    """
    try:
        # 处理metadata JSON字符串参数
        metadata_dict = None
        if metadata:
            try:
                metadata_dict = json.loads(metadata)
            except json.JSONDecodeError:
                return json.dumps({"success": False, "error": "metadata 不是有效的JSON格式"}, ensure_ascii=False, indent=2)

        # 调用核心函数
        result = _save_file_paths_bundle(
            rds_file=rds_file,
            h5ad_file=h5ad_file,
            h5_file=h5_file,
            marker_genes_json=marker_genes_json,
            singler_result=singler_result,
            sctype_result=sctype_result,
            celltypist_result=celltypist_result,
            metadata=metadata_dict,
            session_id=session_id,
            expiry_hours=expiry_hours
        )

        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"保存文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def load_file_paths_bundle() -> str:
    """从临时目录加载当前会话的文件路径信息包。

    自动使用当前会话ID从临时目录加载文件路径信息,
    自动检查过期时间并清理过期文件。

    Returns:
        JSON格式的文件路径信息
    """
    try:
        result = _load_file_paths_bundle()
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"加载文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def load_and_validate_file_paths_bundle() -> str:
    """加载当前会话的文件路径包并验证关键文件是否存在。

    这是一个安全的加载方法，会在加载后验证marker_genes_json等关键文件是否存在。
    推荐使用此方法而非 load_file_paths_bundle，可以避免使用指向已删除文件的过时路径包。

    Returns:
        JSON格式的文件路径信息及验证结果：
        - validated: 是否完成验证
        - missing_files: 缺失的文件列表
        - existing_files: 存在的文件列表
        - all_files_exist: 是否所有文件都存在
        - validation_failed: 如果关键文件不存在则为True
    """
    try:
        result = _load_and_validate_bundle()
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"加载并验证文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def list_saved_file_paths_bundles(include_expired: bool = False, validate_files: bool = True) -> str:
    """列出所有已保存的文件路径包。

    查看临时目录中所有已保存的文件路径包信息,
    包括会话ID、创建时间、文件数量等。

    **重要**：默认会验证文件存在性，过滤掉指向已删除文件的路径包。

    Args:
        include_expired: 是否包含已过期的包
        validate_files: 是否验证文件存在性（默认True，强烈推荐保持开启）

    Returns:
        JSON格式的文件路径包列表，每个包含marker_genes_json路径和files_exist状态
    """
    try:
        result = _list_saved_bundles(include_expired, validate_files)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"列出文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def clear_expired_file_paths_bundles() -> str:
    """清理过期的文件路径包。

    扫描临时目录并删除所有已过期的文件路径包文件，
    释放磁盘空间。

    Returns:
        JSON格式的清理结果
    """
    try:
        result = _clear_expired_bundles()
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"清理过期文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def delete_file_paths_bundle(session_id: str) -> str:
    """删除指定的文件路径包。

    根据会话ID删除对应的文件路径包文件。

    Args:
        session_id: 会话ID

    Returns:
        JSON格式的删除结果
    """
    try:
        result = _delete_bundle(session_id)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"删除文件路径包异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 会话管理工具 ==========

@mcp.tool()
async def get_current_session() -> str:
    """获取当前进程的会话ID和详细信息。

    每个MainAgent进程都有唯一的会话ID，用于隔离不同进程的数据。

    Returns:
        JSON格式的会话信息
    """
    try:
        session_info = get_session_info()
        return json.dumps(session_info, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"获取会话信息异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def list_all_sessions() -> str:
    """列出所有历史会话。

    返回所有已保存的会话ID列表，按时间倒序排列（最新的在前）。

    Returns:
        JSON格式的会话列表
    """
    try:
        from celltypeAgent.mainagent.tools.cluster_tools import list_all_sessions as _list_all_sessions  # type: ignore
    except Exception as e:
        return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.list_all_sessions: {e}"}, ensure_ascii=False, indent=2)

    try:
        sessions = _list_all_sessions()
        current = get_session_id()
        return json.dumps({
            "success": True,
            "current_session": current,
            "total_sessions": len(sessions),
            "sessions": sessions
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"列出会话异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_session_summary() -> str:
    """获取所有会话的摘要信息。

    返回每个会话的详细信息，包括创建时间、簇数量等。

    Returns:
        JSON格式的会话摘要
    """
    try:
        from celltypeAgent.mainagent.tools.cluster_tools import get_session_summary as _get_session_summary  # type: ignore
    except Exception as e:
        return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.get_session_summary: {e}"}, ensure_ascii=False, indent=2)

    try:
        summary = _get_session_summary()
        return json.dumps(summary, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"获取会话摘要异常: {e}"}, ensure_ascii=False, indent=2)


@mcp.tool()
async def load_session_cluster_types(session_id: str) -> str:
    """加载指定会话的簇注释结果。

    用于查看历史会话的注释结果。

    Args:
        session_id: 会话ID

    Returns:
        JSON格式的簇映射
    """
    try:
        from celltypeAgent.mainagent.tools.cluster_tools import load_cluster_types_by_session as _load_by_session  # type: ignore
    except Exception as e:
        return json.dumps({"success": False, "error": f"依赖缺失: cluster_tools.load_cluster_types_by_session: {e}"}, ensure_ascii=False, indent=2)

    try:
        mapping = _load_by_session(session_id)
        if not mapping:
            return json.dumps({
                "success": False,
                "error": f"会话 {session_id} 不存在或无注释数据"
            }, ensure_ascii=False, indent=2)

        return json.dumps({
            "success": True,
            "session_id": session_id,
            "mapping": mapping
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"success": False, "error": f"加载会话注释异常: {e}"}, ensure_ascii=False, indent=2)


# ========== 服务器启动 ==========
if __name__ == "__main__":
    """
    启动 MCP 服务器，等待客户端连接并处理工具调用请求
    """
    # 解析命令行参数
    import argparse
    from celltypeAgent.mainagent.config.session_config import set_session_id

    parser = argparse.ArgumentParser(description='CellType MainAgent MCP Server')
    parser.add_argument('--session-id', type=str, help='Session ID for file naming')
    args = parser.parse_args()

    # 如果提供了session_id，设置到全局配置
    if args.session_id:
        set_session_id(args.session_id)
        print(f"✅ MCP Server 使用传入的 session_id: {args.session_id}")

    try:
        # 运行 FastMCP 服务器（stdio 模式）
        mcp.run()
    except KeyboardInterrupt:
        print("\n🛑 MCP 服务器已停止")
    except Exception as e:
        print(f"❌ MCP 服务器启动失败: {e}")
        sys.exit(1)
