#!/usr/bin/env python3
"""
celltypeAgent - MainAgent缓存配置管理（兼容性层）
Author: cuilei
Version: 1.0
"""

import sys
from pathlib import Path
from typing import Optional

# 添加根目录config到路径
current_dir = Path(__file__).resolve().parent.parent.parent  # 回到根目录
sys.path.insert(0, str(current_dir))

# 导入统一配置系统
from celltypeAgent.config import get_global_config, get_cache_dir as global_get_cache_dir


class CacheManager:
    """MainAgent缓存管理器"""

    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化缓存管理器（简化版，移除冗余的配置文件管理）

        Args:
            cache_dir: 缓存目录路径，如果不指定则使用默认目录

        Note:
            所有配置统一由 celltypeAgent_config.json 管理
        """
        # 使用统一配置系统
        config = get_global_config()
        self.cache_dir = config.get_cache_dir("celltypeMainagent")
        self.results_cache_dir = config.get_results_dir("celltypeMainagent")
        self.logs_cache_dir = config.get_logs_dir("celltypeMainagent")


def init_cache(cache_dir: Optional[str] = None) -> CacheManager:
    """
    初始化缓存管理器

    Args:
        cache_dir: 缓存目录路径

    Returns:
        CacheManager: 缓存管理器实例
    """
    return CacheManager(cache_dir)


# 兼容性函数，与其他Agent保持一致的接口
def get_cache_dir(subdir: str = "") -> Path:
    """获取缓存目录路径

    Args:
        subdir: 子目录名称

    Returns:
        缓存目录路径
    """
    # 使用统一配置系统
    if subdir:
        return global_get_cache_dir(f"celltypeMainagent/{subdir}")
    else:
        return global_get_cache_dir("celltypeMainagent")