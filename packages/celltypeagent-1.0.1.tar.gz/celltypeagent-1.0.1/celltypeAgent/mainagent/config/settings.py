#!/usr/bin/env python3
"""
celltypeAgent - 配置管理
Author: cuilei
Version: 1.0
"""

from __future__ import annotations

import os
from dataclasses import dataclass, asdict, field
from typing import Dict, Optional, List
from pathlib import Path


@dataclass
class SubAgentConfig:
    """子Agent连接配置"""
    name: str
    server_script: str
    enabled: bool = True
    max_retries: int = 3


@dataclass
class ConfigManager:
    """MainAgent配置管理器

    负责管理MainAgent及其与子Agent的连接配置
    """

    # LLM配置
    openai_api_base: Optional[str] = None
    openai_api_key: Optional[str] = None
    openai_model: Optional[str] = "gpt-4o"

    # MainAgent配置
    language: str = "zh"
    enable_streaming: bool = True
    max_parallel_tasks: int = 3

    # 缓存和日志配置
    cache_dir: Optional[str] = None
    log_dir: Optional[str] = None
    enable_logging: bool = True

    # 子Agent连接配置
    subagents: Dict[str, SubAgentConfig] = field(default_factory=dict)

    def __post_init__(self):
        """初始化后处理"""
        if not self.subagents:
            self._setup_default_subagents()

        # 设置默认路径
        if not self.cache_dir:
            self.cache_dir = str(Path.cwd() / ".celltype_cache")
        if not self.log_dir:
            self.log_dir = str(Path.cwd() / "logs")

    def _setup_default_subagents(self):
        """设置默认的子Agent配置"""
        current_dir = Path(__file__).resolve().parent.parent.parent

        self.subagents = {
            "celltypeSubagent": SubAgentConfig(
                name="celltypeSubagent",
                server_script=str(current_dir / "celltypeSubagent" / "services" / "mcp_server.py")
            ),
            "celltypeDataAgent": SubAgentConfig(
                name="celltypeDataAgent",
                server_script=str(current_dir / "celltypeDataAgent" / "services" / "mcp_server.py")
            ),
            "celltypeAppAgent": SubAgentConfig(
                name="celltypeAppAgent",
                server_script=str(current_dir / "celltypeAppAgent" / "services" / "mcp_server.py")
            )
        }

    def get_subagent_config(self, name: str) -> Optional[SubAgentConfig]:
        """获取指定子Agent的配置"""
        return self.subagents.get(name)

    def get_enabled_subagents(self) -> Dict[str, SubAgentConfig]:
        """获取启用的子Agent配置字典"""
        return {name: config for name, config in self.subagents.items() if config.enabled}

    def validate(self) -> bool:
        """验证配置有效性"""
        # 验证子Agent服务器脚本存在
        for name, subagent in self.subagents.items():
            if subagent.enabled:
                server_path = Path(subagent.server_script)
                if not server_path.exists():
                    print(f"警告: 子Agent服务器脚本不存在: {server_path}")
                    return False

        # 验证目录权限
        try:
            Path(self.cache_dir).mkdir(parents=True, exist_ok=True)
            Path(self.log_dir).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"警告: 无法创建缓存或日志目录: {e}")
            return False

        return True

    def to_dict(self) -> Dict:
        """转换为字典格式"""
        result = asdict(self)
        # 转换SubAgentConfig对象
        result['subagents'] = [asdict(config) for config in self.subagents]
        return result

    @classmethod
    def from_env(cls) -> "ConfigManager":
        """从环境变量创建配置"""
        return cls(
            openai_api_base=os.getenv("OPENAI_API_BASE"),
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            language=os.getenv("CELLTYPE_LANGUAGE", "zh"),
            enable_streaming=os.getenv("CELLTYPE_ENABLE_STREAMING", "true").lower() == "true",
            enable_logging=os.getenv("CELLTYPE_ENABLE_LOGGING", "true").lower() == "true"
        )

