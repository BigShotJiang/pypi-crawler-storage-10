#!/usr/bin/env python3
"""
celltypeAgent - MainAgent 主工作流处理接口
Author: cuilei
Version: 1.0
"""

import asyncio
import gc
import sys
from pathlib import Path
from typing import Optional, Dict, Any, Union

# 导入依赖模块
try:
    from celltypeAgent.config import get_global_config, check_and_update_config
    from celltypeAgent.mainagent.config.cache_config import init_cache
    from celltypeAgent.mainagent.config.settings import ConfigManager
    from celltypeAgent.mainagent.agent.main_react_agent import MainReactAgent
except ImportError as e:
    raise ImportError(f"无法导入 MainAgent 依赖: {e}")


async def process_workflow(
    input_data: Union[str, Path],
    tissue_type: str = "骨髓",
    cluster_column: str = "seurat_clusters",
    species: Optional[str] = None,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    model: Optional[str] = None,
    language: str = "zh",
    enable_streaming: bool = True,
    **kwargs
) -> Dict[str, Any]:
    """
    执行主工作流处理

    这是 MainAgent 的核心接口，负责统一工作流编排和多Agent协调。

    Args:
        input_data: 输入数据文件路径 (RDS/H5AD等格式)
        tissue_type: 目标组织类型，默认为"骨髓"
        cluster_column: 聚类列名，用于细胞类型注释，默认为"seurat_clusters"
        species: 可选的物种参数 (如 "Human", "Mouse")，如果不提供则自动检测
        api_key: OpenAI API密钥，默认从环境变量读取
        api_base: API基础URL，默认使用配置文件设置
        model: 使用的模型，默认使用配置文件设置
        language: 语言设置，默认为中文
        enable_streaming: 是否启用流式输出
        **kwargs: 其他参数

    Returns:
        Dict[str, Any]: 处理结果，包含：
            - success: 是否成功
            - total_iterations: 总迭代次数
            - output_file_paths: 输出文件路径
            - analysis_log: 分析日志

    Raises:
        ImportError: 当无法导入必要依赖时
        Exception: 当处理过程中发生错误时
    """

    agent = None
    try:
        # 获取全局配置
        global_config = get_global_config()

        # 检查并更新配置（如果参数与配置文件不同）
        check_and_update_config(
            global_config,
            api_key=api_key,
            api_base=api_base,
            model=model,
            language=language,
            enable_streaming=enable_streaming,
        )

        # 初始化缓存
        init_cache()

        # 创建配置管理器
        config = ConfigManager(
            openai_api_base=api_base or global_config.llm.api_base or "https://api.siliconflow.cn/v1",
            openai_api_key=api_key or global_config.llm.api_key,
            openai_model=model or global_config.llm.model,
            language=language,
            enable_streaming=enable_streaming,
            cache_dir=str(global_config.get_cache_dir('celltypeMainagent')),
            log_dir=str(global_config.get_logs_dir('celltypeMainagent'))
        )

        # 创建 MainReactAgent 实例
        agent = MainReactAgent(
            config=config,
            language=language,
            enable_streaming=enable_streaming,
        )

        # 初始化 Agent
        if not await agent.initialize():
            return {
                "success": False,
                "error": "MainAgent 初始化失败",
                "total_iterations": 0,
                "output_file_paths": {},
                "analysis_log": []
            }

        # 执行主工作流
        result = await agent.process_with_llm_react(
            input_data=str(input_data),
            tissue_type=tissue_type,
            cluster_column=cluster_column,
            species=species
        )

        # 确保返回标准格式
        return {
            "session_id": result.get('session_id', 'unknown'),  # 会话ID
            "api_base": result.get('api_base', 'unknown'),  # API URL
            "model": result.get('model', 'unknown'),  # 使用的模型
            "result_file": result.get('result_file'),  # 保存的文件路径
            "result_saved_at": result.get('result_saved_at'),  # 保存时间
            "success": result.get('success', False),
            "total_iterations": result.get('total_iterations', 0),
            "output_file_paths": result.get('output_file_paths', {}),
            "analysis_log": result.get('analysis_log', []),
            "final_result": result.get('final_result', ''),  # LLM生成的最终分析结果
            "token_stats": result.get('token_stats', {}),  # Token统计信息
            "tissue_type": tissue_type,
            "input_data": str(input_data)
        }

    except Exception as e:
        # 即使异常也尝试获取 session_id
        try:
            from celltypeAgent.mainagent.config.session_config import get_session_id
            session_id = get_session_id()
        except:
            session_id = 'unknown'

        return {
            "session_id": session_id,
            "success": False,
            "error": str(e),
            "total_iterations": 0,
            "output_file_paths": {},
            "analysis_log": [],
            "tissue_type": tissue_type,
            "input_data": str(input_data)
        }

    finally:
        # 清理资源
        if agent:
            try:
                await agent.cleanup()
                await asyncio.sleep(0.3)
                gc.collect()
                await asyncio.sleep(0.1)
            except Exception:
                pass  # 静默处理清理错误


def process_workflow_sync(
    input_data: Union[str, Path],
    tissue_type: str = "骨髓",
    cluster_column: str = "seurat_clusters",
    species: Optional[str] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    同步版本的工作流处理函数

    为不使用 async/await 的用户提供的便利接口。

    Args:
        input_data: 输入数据文件路径
        tissue_type: 目标组织类型
        cluster_column: 聚类列名，用于细胞类型注释，默认为"seurat_clusters"
        species: 可选的物种参数 (如 "Human", "Mouse")，如果不提供则自动检测
        **kwargs: 其他参数，传递给 process_workflow

    Returns:
        Dict[str, Any]: 处理结果
    """
    return asyncio.run(process_workflow(input_data, tissue_type, cluster_column, species, **kwargs))


# 为向后兼容保留的别名
main_workflow = process_workflow
main_workflow_sync = process_workflow_sync