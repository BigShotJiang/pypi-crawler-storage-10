#!/usr/bin/env python3
"""
celltypeAgent - 数据转换工具模块
Author: cuilei
Version: 1.0
"""

import json
import subprocess
import os
import sys
from pathlib import Path
from anndata import AnnData
import pandas as pd
from typing import Dict, Any, Optional

# 导入项目模块

# 导入统一配置系统
from celltypeAgent.config import get_results_dir, get_temp_dir, get_session_id_for_filename

def run_r_sce_to_h5(seurat_file: str) -> Optional[str]:
    """
    将Seurat RDS文件转换为easySCF H5格式

    参数:
    seurat_file: Seurat RDS文件路径

    返回:
    成功时返回输出信息，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    h5_file = str(results_dir / f'sce_{session_id}.h5')
    
    try:
        subprocess.run(['R', '--version'], capture_output=True, check=True)
    except:
        error_msg = "错误：未找到R环境，请安装R语言环境"
        print(error_msg)
        return error_msg
    
    # 转换为绝对路径
    seurat_file = os.path.abspath(seurat_file)
    if not os.path.exists(seurat_file):
        error_msg = f"错误：文件不存在: {seurat_file}"
        print(error_msg)
        return error_msg
    
    # 如果指定了输出路径，确保输出目录存在
    h5_file = os.path.abspath(h5_file)
    output_dir = os.path.dirname(h5_file)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
        print(f"✓ 创建输出目录: {output_dir}")
    
    # 使用绝对路径的R脚本
    r_script = f'''
    library(Seurat)
    library(easySCFr)
    
    # 设置详细输出
    cat("正在读取RDS文件:", "{seurat_file}", "\\n")
    sce <- readRDS("{seurat_file}")
    cat("RDS文件读取成功\\n")
    
    cat("正在保存为H5格式:", "{h5_file}", "\\n")
    saveH5(sce, "{h5_file}")
    cat("RDS文件已成功转换为H5格式:", "{h5_file}", "\\n")
    '''
    
    try:
        print(f"正在将 {seurat_file} 转换为H5格式...")
        print(f"输出文件: {h5_file}")
        
        result = subprocess.run(['R', '--slave', '--no-restore', '--no-save'], 
                              input=r_script, text=True, capture_output=True, encoding='utf-8')
        
        print("R执行完成，返回代码:", result.returncode)
        
        if result.stdout:
            print("R输出:")
            print(result.stdout)
        
        if result.stderr:
            print("R错误输出:")
            print(result.stderr)
            
        if result.returncode == 0:
            # 验证输出文件是否存在
            if os.path.exists(h5_file):
                success_msg = f"✓ RDS转H5转换成功完成: {h5_file}"
                print(success_msg)
                return success_msg
            else:
                error_msg = f"✗ R脚本执行成功但未找到输出文件: {h5_file}"
                print(error_msg)
                return error_msg
        else:
            error_msg = f"✗ R脚本执行失败，返回代码: {result.returncode}, 错误信息: {result.stderr}"
            print(error_msg)
            return error_msg
            
    except Exception as e:
        error_msg = f"✗ 转换过程中发生异常: {e}"
        print(error_msg)
        return error_msg

def run_r_findallmarkers(seurat_file: str, pval_threshold: float = 0.05, cluster_column: str = "seurat_clusters") -> Optional[Dict]:
    """
    运行R语言FindAllMarkers分析并直接输出JSON格式

    参数:
    seurat_file: Seurat RDS文件路径
    pval_threshold: p值阈值
    cluster_column: 聚类列名，默认"seurat_clusters"

    返回:
    成功时返回marker基因字典，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    output_file = str(results_dir / f'cluster_markers_{session_id}.json')
    
    try:
        subprocess.run(['R', '--version'], capture_output=True, check=True)
    except:
        print("错误：未找到R环境，请安装R语言环境")
        return None
    
    if not os.path.exists(seurat_file):
        print(f"错误：文件不存在: {seurat_file}")
        return None
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_file)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    # R脚本（包含完整的结果验证，防止生成空JSON文件）
    r_script = f'''
library(Seurat)
library(jsonlite)
sce <- readRDS("{seurat_file}")
print("Seurat对象已加载")

# 设置聚类列
Idents(sce) <- "{cluster_column}"
cat("使用聚类列:", "{cluster_column}", "\\n")

# 数据标准化
if ("RNA" %in% names(sce@assays)) {{
  if("layers" %in% names(attributes(sce[["RNA"]]))){{
    if (!("data" %in% names(sce@assays$RNA@layers))) {{
        sce <- NormalizeData(sce)
    }}
  }} else {{
    if(!("data" %in% names(attributes(sce[["RNA"]])))){{
        sce <- NormalizeData(sce)
    }}
  }}
}}

# 运行 FindAllMarkers
cat("开始运行 FindAllMarkers 分析...\\n")
alm <- FindAllMarkers(sce, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)

# ========== 验证步骤 1: 检查 FindAllMarkers 结果 ==========
if (is.null(alm) || nrow(alm) == 0) {{
  cat("诊断信息：\\n")
  cat("  细胞数:", ncol(sce), "\\n")
  cat("  基因数:", nrow(sce), "\\n")
  cat("  Cluster数:", length(unique(Idents(sce))), "\\n")
  cat("  Cluster分布:", table(Idents(sce)), "\\n")
  stop("FindAllMarkers 未找到任何差异基因。可能原因：数据质量问题、cluster之间差异太小、或阈值设置过严格。")
}}

cat("FindAllMarkers 找到", nrow(alm), "个差异基因\\n")
significant_alm <- alm[alm$p_val_adj < {pval_threshold}, ]
cluster_to_genes <- split(as.character(significant_alm$gene), significant_alm$cluster)
names(cluster_to_genes) <- paste0("cluster", names(cluster_to_genes))

# ========== 验证通过，保存结果 ==========
cat("✓ 所有验证通过，保存结果到 JSON 文件...\\n")
write_json(cluster_to_genes, "{output_file}", pretty = TRUE, auto_unbox = FALSE)
cat("✓ 结果已保存到", "{output_file}", "\\n")
cat("✓ 总计", length(cluster_to_genes), "个 cluster，", nrow(significant_alm), "个显著 marker 基因\\n")
'''

    try:
        print(f"正在对 {seurat_file} 运行FindAllMarkers分析...")
        result = subprocess.run(['R', '--slave', '--no-restore'],
                              input=r_script, text=True, capture_output=True, encoding='utf-8')

        # 显示R的标准输出（包括诊断信息）
        if result.stdout:
            print("R输出:")
            print(result.stdout)

        # 检查R脚本执行状态
        if result.returncode == 0:
            print("✓ R脚本执行成功")

            # 检查JSON文件是否生成
            if not os.path.exists(output_file):
                print("✗ R未能创建JSON文件")
                return None

            # 加载JSON文件
            with open(output_file, 'r', encoding='utf-8') as f:
                marker_genes = json.load(f)

            # ========== 额外验证：防止空JSON文件 ==========
            # 虽然R脚本已经验证，但并行处理时可能出现竞态条件
            if not marker_genes:
                print("✗ JSON文件为空（没有任何cluster）")
                print(f"   问题文件: {output_file}")
                return None

            # 检查是否所有cluster都是空列表
            total_genes = sum(len(genes) for genes in marker_genes.values())
            if total_genes == 0:
                print("✗ JSON文件包含cluster，但所有cluster的marker基因列表都为空")
                print(f"   Cluster数量: {len(marker_genes)}")
                print(f"   Cluster列表: {list(marker_genes.keys())}")
                print(f"   问题文件: {output_file}")
                print("   这不应该发生，因为R脚本已包含验证逻辑")
                print("   可能原因：并行处理时文件被覆盖或损坏")
                return None

            # 统计信息
            print(f"✓ FindAllMarkers分析成功完成")
            print(f"  Cluster数量: {len(marker_genes)}")
            print(f"  总marker基因数: {total_genes}")
            for cluster, genes in marker_genes.items():
                print(f"    {cluster}: {len(genes)} 个基因")

            return marker_genes

        else:
            # R脚本执行失败
            print(f"✗ R脚本执行失败 (返回码: {result.returncode})")

            # 解析stderr中的错误信息
            if result.stderr:
                print("R错误输出:")
                error_lines = result.stderr.strip().split('\n')

                # 查找关键错误信息
                for line in error_lines:
                    if 'Error' in line or 'stop' in line or '错误' in line:
                        print(f"  ❌ {line}")
                    elif 'Warning' in line or '警告' in line:
                        print(f"  ⚠️  {line}")
                    else:
                        print(f"     {line}")

                # 提取诊断建议
                if "未找到任何显著的 marker 基因" in result.stderr:
                    print("\n💡 建议：")
                    print("   1. 尝试放宽p值阈值（当前: {pval_threshold}）")
                    print("   2. 调整FindAllMarkers参数：min.pct, logfc.threshold")
                    print("   3. 检查数据质量和cluster定义")
                elif "未找到任何差异基因" in result.stderr:
                    print("\n💡 建议：")
                    print("   1. 检查cluster之间是否有足够的差异")
                    print("   2. 降低FindAllMarkers的阈值")
                    print("   3. 确认数据已正确标准化")
                elif "没有足够的 marker 基因" in result.stderr:
                    print("\n💡 建议：")
                    print("   1. 放宽p值阈值或降低min_genes_per_cluster要求")
                    print("   2. 某些cluster可能确实缺乏特异性marker")

            return None

    except Exception as e:
        print(f"✗ Python执行错误: {e}")
        import traceback
        traceback.print_exc()
        return None

def load_scanpy_data(file_path: str) -> Optional[Any]:
    """
    使用scanpy加载数据文件
    
    参数:
    file_path: 数据文件路径（支持.h5ad等格式）
    
    返回:
    成功时返回AnnData对象，失败时返回None
    """
    try:
        import scanpy as sc
        
        if not os.path.exists(file_path):
            print(f"错误：文件不存在: {file_path}")
            return None
        
        print(f"正在使用scanpy加载 {file_path}...")
        
        if file_path.endswith('.h5ad'):
            sce = sc.read_h5ad(file_path)
        elif file_path.endswith('.h5'):
            sce = sc.read_10x_h5(file_path)
        elif file_path.endswith('.csv'):
            sce = sc.read_csv(file_path)
        else:
            print("警告：未知文件格式，尝试使用read_h5ad加载")
            sce = sc.read_h5ad(file_path)
        
        print(f"✓ 成功加载，包含 {sce.n_obs} 个细胞，{sce.n_vars} 个基因")
        return sce
        
    except ImportError:
        print("错误：未找到scanpy包，请安装: pip install scanpy")
        return None
    except Exception as e:
        print(f"✗ 加载文件失败: {e}")
        return None

def load_h5_with_easyscfpy(h5_file: str) -> Optional[Any]:
    """
    使用easySCFpy加载h5文件
    """
    try:
        from easySCFpy import loadH5
        return loadH5(h5_file)
    except ImportError:
        print("错误：未找到easySCFpy包，请安装: pip install easySCFpy")
        return None

def easyscfpy_h5_to_json(h5_file: str, pval_threshold: float = 0.05, cluster_column: str = None) -> Optional[Any]:
    """
    使用easySCFpy加载h5文件，并转换为JSON格式

    参数:
    h5_file: H5文件路径
    pval_threshold: p值阈值
    cluster_column: 聚类列名，为None时自动搜索 ['seurat_clusters', 'leiden', 'louvain']

    返回:
    成功时返回marker基因字典，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    try:
        sce = load_h5_with_easyscfpy(h5_file)
        return process_scanpy_data(sce, pval_threshold, cluster_column)
    except Exception as e:
        print(f"✗ 转换过程中出现错误: {e}")
        return None

def scanpy_path_to_json(scanpy_path: str, pval_threshold: float = 0.05, cluster_column: str = None) -> Optional[Dict]:
    """
    处理scanpy数据，运行差异分析，从路径中加载数据

    参数:
    scanpy_path: scanpy文件路径
    pval_threshold: p值阈值
    cluster_column: 聚类列名，为None时自动搜索 ['seurat_clusters', 'leiden', 'louvain']

    返回:
    成功时返回marker基因字典，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    try:
        sce = load_scanpy_data(scanpy_path)
        return process_scanpy_data(sce, pval_threshold, cluster_column)
    except Exception as e:
        print(f"✗ 转换过程中出现错误: {e}")
        return None


def convert_scanpy_file_to_h5(input_file: str) -> Optional[str]:
    """
    从文件加载scanpy数据并保存为easySCF H5格式

    参数:
    input_file: 输入数据文件路径（支持.h5ad等格式）

    返回:
    成功时返回成功信息，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    h5_file = str(results_dir / f'data_{session_id}.h5')
    
    try:
        # 加载scanpy数据
        sce = load_scanpy_data(input_file)
        if sce is None:
            return None
        
        # 保存为H5格式
        return save_scanpy_to_h5(sce, h5_file)
        
    except Exception as e:
        error_msg = f"✗ 文件转换过程中发生异常: {e}"
        print(error_msg)
        return error_msg

def process_scanpy_data(sce: AnnData, pval_threshold: float = 0.05, cluster_column: str = None) -> Optional[Dict]:
    """
    处理scanpy数据，运行差异分析

    参数:
    sce: AnnData对象
    pval_threshold: p值阈值
    cluster_column: 聚类列名，为None时自动搜索 ['seurat_clusters', 'leiden', 'louvain']

    返回:
    成功时返回marker基因字典，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    output_file = str(results_dir / f'cluster_marker_genes_{session_id}.json')
    
    try:
        import scanpy as sc
                
        # 数据预处理
        if sce.X.max() > 20:  # 原始计数数据
            print("⚠️ 进行对数化处理...")
            sc.pp.normalize_total(sce)
            sc.pp.log1p(sce)
            print("✓ 数据对数化处理完成")
        
        # 查找聚类信息
        cluster_key = None
        if cluster_column:
            # 用户指定了聚类列
            if cluster_column in sce.obs.columns:
                cluster_key = cluster_column
                print(f"✓ 使用指定的聚类列: {cluster_column}")
            else:
                print(f"⚠️ 指定的聚类列 '{cluster_column}' 不存在，尝试自动搜索")

        if cluster_key is None:
            # 自动搜索聚类列
            for key in ['seurat_clusters', 'leiden', 'louvain']:
                if key in sce.obs.columns:
                    cluster_key = key
                    print(f"✓ 使用 {cluster_key} 聚类信息")
                    break

        if cluster_key is None:
            print("✗ 错误：未找到聚类信息，自动使用分辨率1进行leiden聚类分析")
            sc.pp.scale(sce)
            sc.pp.pca(sce)
            sc.pp.neighbors(sce, n_neighbors=20, n_pcs=15)
            sc.tl.leiden(sce, resolution=1.0)
            cluster_key = 'leiden'
            print(f"✓ 使用自动生成的 leiden 聚类信息")
        
        # 运行差异基因分析
        print(f"🔬 正在运行差异基因分析...")
        sc.tl.rank_genes_groups(sce, cluster_key, method='wilcoxon')
        
        # 调用保存函数
        from .save_marker_genes import save_marker_genes_to_json
        marker_genes = save_marker_genes_to_json(sce, output_file, pval_threshold)
        
        return marker_genes
        
    except ImportError:
        print("错误：未找到scanpy包，请安装: pip install scanpy")
        return None
    except Exception as e:
        print(f"✗ 处理scanpy数据失败: {e}")
        return None


def convert_r_markers_csv_to_json(csv_file: str, pval_threshold: float = 0.05) -> Optional[Dict]:
    """
    将FindAllMarkers的CSV结果转换为JSON格式

    参数:
    csv_file: CSV文件路径
    pval_threshold: p值阈值

    返回:
    成功时返回marker基因字典，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    output_file = str(results_dir / f'cluster_marker_genes_{session_id}.json')
    
    try:
        # 确保输出目录存在
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        
        print(f"正在读取 {csv_file}...")
        markers_df = pd.read_csv(csv_file)
        
        # 检查必要的列
        required_cols = ['cluster', 'gene', 'p_val_adj']
        for col in required_cols:
            if col not in markers_df.columns:
                print(f"错误：未找到必要的列: {col}")
                return None
        
        # 筛选显著的基因
        significant_markers = markers_df[markers_df['p_val_adj'] < pval_threshold]
        print(f"筛选出 {len(significant_markers)} 个显著的marker基因")
        
        # 生成marker基因字典
        marker_genes = {}
        clusters = significant_markers['cluster'].unique()
        
        for cluster in sorted(clusters):
            cluster_markers = significant_markers[
                significant_markers['cluster'] == cluster
            ]['gene'].tolist()
            
            marker_genes[f'cluster{cluster}'] = cluster_markers
        
        # 保存为JSON文件
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(marker_genes, f, ensure_ascii=False, indent=2)
        
        print(f"✓ 成功提取 {len(marker_genes)} 个分簇的marker基因")
        print(f"结果已保存到 {output_file}")
        
        return marker_genes
        
    except FileNotFoundError:
        print(f"错误：找不到文件 {csv_file}")
        return None
    except Exception as e:
        print(f"✗ 转换过程中出现错误: {e}")
        return None

def save_scanpy_to_h5(sce: AnnData) -> Optional[str]:
    """
    将scanpy AnnData对象保存为easySCF H5格式

    参数:
    sce: AnnData对象

    返回:
    成功时返回成功信息，失败时返回None

    注意:
    输出文件会自动保存到配置的结果目录，使用 session_id 命名
    """
    # 使用 session_id 作为文件名
    session_id = get_session_id_for_filename()
    # 使用统一配置系统的结果目录
    results_dir = get_results_dir("celltypeDataAgent")
    h5_file = str(results_dir / f'data_{session_id}.h5')

    try:
        from easySCFpy import saveH5

        # 确保输出目录存在
        h5_file = os.path.abspath(h5_file)
        output_dir = os.path.dirname(h5_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
            print(f"✓ 创建输出目录: {output_dir}")
        
        print(f"正在保存scanpy数据为H5格式: {h5_file}")
        saveH5(sce, h5_file)
        
        # 验证输出文件是否存在
        if os.path.exists(h5_file):
            success_msg = f"✓ scanpy数据已成功保存为H5格式: {h5_file}"
            print(success_msg)
            return success_msg
        else:
            error_msg = f"✗ 保存失败，未找到输出文件: {h5_file}"
            print(error_msg)
            return error_msg
            
    except ImportError:
        error_msg = "错误：未找到easySCFpy包，请安装: pip install easySCFpy"
        print(error_msg)
        return error_msg
    except Exception as e:
        error_msg = f"✗ 保存过程中发生异常: {e}"
        print(error_msg)
        return error_msg
