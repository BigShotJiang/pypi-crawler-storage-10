#!/usr/bin/env python3
"""
celltypeAgent - 配置管理
Author: cuilei
Version: 1.0
"""

import os
from pathlib import Path
import sys

# 导入全局配置

# 导入统一配置系统
from celltypeAgent.config import get_cache_dir

class ConfigManager:
    """配置管理类"""
    
    def __init__(self, 
                 openai_api_base: str = None,
                 openai_api_key: str = None,
                 openai_model: str = "gpt-4o",
                 proxy: str = None):
        self.openai_api_base = openai_api_base
        self.openai_api_key = openai_api_key
        self.openai_model = openai_model
        self.proxy = proxy
        
        # 数据处理相关的必需配置
        self.pval_threshold = 0.05
        self.max_retries = 3

        # 使用统一配置系统
        self.cache_dir = str(get_cache_dir("celltypeDataAgent"))
        self.log_dir = "logs"
        
        # 设置代理环境变量
        if self.proxy:
            os.environ['HTTP_PROXY'] = self.proxy
            os.environ['HTTPS_PROXY'] = self.proxy