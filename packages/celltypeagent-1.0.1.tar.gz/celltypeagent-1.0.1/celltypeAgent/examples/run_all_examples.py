#!/usr/bin/env python3
"""
celltypeAgent - 运行所有Agent示例的统一入口脚本
Author: cuilei
Version: 1.0
"""

import sys
import os
import subprocess
from pathlib import Path


def print_header():
    """打印欢迎头部"""
    print("=" * 70)
    print("   🧬 CellType MCP Server - 统一配置示例演示")
    print("=" * 70)
    print()


def print_menu():
    """打印菜单选项"""
    print("请选择要运行的Agent示例:")
    print()
    print("  1️⃣  MainAgent    - 主调度器 (统一工作流编排)")
    print("  2️⃣  SubAgent     - 基础数据服务 (基因查询、富集分析)")
    print("  3️⃣  DataAgent    - 数据处理 (格式转换、预处理)")
    print("  4️⃣  AppAgent     - 应用级注释 (SingleR/scType/CellTypist)")
    print()
    print("  5️⃣  查看配置     - 显示当前项目配置")
    print("  6️⃣  清理输出     - 清理outputs目录")
    print("  0️⃣  退出")
    print()


def show_current_config():
    """显示当前配置"""
    try:
        project_root = Path(__file__).resolve().parent.parent
        sys.path.insert(0, str(project_root))

        from config import get_global_config

        config = get_global_config()

        print("\n" + "=" * 50)
        print("🔧 当前项目配置")
        print("=" * 50)

        print(f"📂 项目根目录: {config.paths.project_root}")
        print(f"📂 输出目录: {config.paths.outputs_dir}")
        print(f"📂 缓存目录: {config.paths.cache_dir}")
        print(f"📂 日志目录: {config.paths.logs_dir}")
        print(f"📂 结果目录: {config.paths.results_dir}")
        print(f"📂 下载目录: {config.paths.downloads_dir}")

        print(f"\n🤖 LLM配置:")
        print(f"   模型: {config.llm.model}")
        print(f"   API Base: {config.llm.api_base or '未设置(使用默认)'}")
        print(f"   API Key: {'已设置' if config.llm.api_key else '未设置'}")

        print(f"\n📋 项目设置:")
        print(f"   语言: {config.project.language}")
        print(f"   流式输出: {config.project.enable_streaming}")
        print(f"   日志记录: {config.project.enable_logging}")
        print(f"   缓存过期天数: {config.project.cache_expiry_days}")

        print(f"\n🎯 启用的Agents:")
        enabled_agents = [name for name, cfg in config._agents_config.items() if cfg.enabled]
        for agent in enabled_agents:
            print(f"   ✅ {agent}")

        print("\n💡 提示: API密钥可以通过环境变量 OPENAI_API_KEY 设置")

    except Exception as e:
        print(f"❌ 无法读取配置: {e}")


def cleanup_outputs():
    """清理输出目录"""
    try:
        project_root = Path(__file__).resolve().parent.parent
        outputs_dir = project_root / "outputs"

        if not outputs_dir.exists():
            print("📂 outputs目录不存在，无需清理")
            return

        print(f"🧹 准备清理输出目录: {outputs_dir}")

        # 统计当前文件
        total_files = sum(1 for _ in outputs_dir.rglob("*") if _.is_file())
        total_size = sum(_.stat().st_size for _ in outputs_dir.rglob("*") if _.is_file())
        size_mb = total_size / (1024 * 1024)

        print(f"📊 当前状态: {total_files} 个文件，总大小 {size_mb:.2f} MB")

        if total_files == 0:
            print("✅ 目录已经是空的")
            return

        confirm = input("\n⚠️  确定要清理所有输出文件吗? (y/N): ").strip().lower()

        if confirm in ['y', 'yes']:
            import shutil

            # 删除所有子目录内容，但保留目录结构
            for subdir in ['cache', 'logs', 'results', 'downloads']:
                subdir_path = outputs_dir / subdir
                if subdir_path.exists():
                    shutil.rmtree(subdir_path)
                    subdir_path.mkdir(exist_ok=True)
                    print(f"🗑️  已清理: {subdir}/")

            print("✅ 清理完成!")
        else:
            print("❌ 取消清理")

    except Exception as e:
        print(f"❌ 清理失败: {e}")


def run_example(example_name: str):
    """运行指定的示例"""
    project_root = Path(__file__).resolve().parent.parent
    examples_dir = project_root / "examples"

    example_files = {
        "main": "main_example.py",
        "sub": "subagent_example.py",
        "data": "data_example.py",
        "app": "app_example.py"
    }

    if example_name not in example_files:
        print(f"❌ 未知的示例类型: {example_name}")
        return False

    example_file = examples_dir / example_files[example_name]

    if not example_file.exists():
        print(f"❌ 示例文件不存在: {example_file}")
        return False

    print(f"🚀 正在运行: {example_files[example_name]}")
    print("=" * 50)

    try:
        # 设置工作目录为项目根目录
        result = subprocess.run(
            [sys.executable, str(example_file)],
            cwd=str(project_root),
            check=True
        )
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"❌ 示例运行失败，退出码: {e.returncode}")
        return False
    except KeyboardInterrupt:
        print("\n⚠️  用户中断执行")
        return False
    except Exception as e:
        print(f"❌ 运行示例时发生错误: {e}")
        return False


def main():
    """主函数"""
    print_header()

    # 检查环境
    project_root = Path(__file__).resolve().parent.parent
    if not (project_root / "config").exists():
        print("❌ 配置目录不存在，请确保在正确的项目根目录下运行")
        sys.exit(1)

    # 显示环境信息
    print("🌍 运行环境:")
    print(f"   Python: {sys.version.split()[0]}")
    print(f"   工作目录: {project_root}")
    print(f"   API密钥: {'已设置' if os.environ.get('OPENAI_API_KEY') else '未设置'}")
    print()

    while True:
        print_menu()
        choice = input("请选择 (0-6): ").strip()

        if choice == "0":
            print("\n👋 再见！")
            break
        elif choice == "1":
            print("\n🎯 选择: MainAgent 示例")
            run_example("main")
        elif choice == "2":
            print("\n🎯 选择: SubAgent 示例")
            run_example("sub")
        elif choice == "3":
            print("\n🎯 选择: DataAgent 示例")
            run_example("data")
        elif choice == "4":
            print("\n🎯 选择: AppAgent 示例")
            run_example("app")
        elif choice == "5":
            show_current_config()
        elif choice == "6":
            cleanup_outputs()
        else:
            print("❌ 无效的选择，请重新输入")

        print("\n" + "=" * 50)
        input("按 Enter 键继续...")
        print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 程序被用户中断，再见！")
    except Exception as e:
        print(f"\n❌ 程序执行失败: {e}")
        sys.exit(1)