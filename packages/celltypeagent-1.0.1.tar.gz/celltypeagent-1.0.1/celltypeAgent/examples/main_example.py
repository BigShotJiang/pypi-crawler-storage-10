#!/usr/bin/env python3
"""
celltypeAgent - MainAgent 统一使用示例
Author: cuilei
Version: 1.0
"""

import asyncio
import gc
import sys
from pathlib import Path

# 项目根目录
project_root = Path(__file__).resolve().parent.parent

# 导入统一配置系统
from celltypeAgent.config import get_global_config, get_logs_dir, get_results_dir

# 导入MainAgent依赖
from celltypeAgent.mainagent.config.cache_config import init_cache
from celltypeAgent.mainagent.config.settings import ConfigManager
from celltypeAgent.mainagent.agent.main_react_agent import MainReactAgent


async def example_usage():
    """使用示例"""
    print("🧬 CellType MainAgent 统一配置示例")
    print("=" * 50)

    # 使用统一配置系统
    global_config = get_global_config()
    print(f"📂 项目根目录: {global_config.paths.project_root}")
    print(f"📂 输出目录: {global_config.paths.outputs_dir}")
    print(f"📂 缓存目录: {global_config.get_cache_dir('celltypeMainagent')}")
    print(f"📂 日志目录: {global_config.get_logs_dir('celltypeMainagent')}")
    print(f"📂 结果目录: {global_config.get_results_dir('celltypeMainagent')}")

    # 初始化MainAgent缓存系统
    cache = init_cache()
    print(f"📂 MainAgent缓存已初始化: {cache.cache_dir}")

    # 使用统一配置创建ConfigManager
    # API密钥从环境变量或统一配置中读取
    config = ConfigManager(
        openai_api_base=global_config.llm.api_base or "https://api.siliconflow.cn/v1",
        openai_api_key=global_config.llm.api_key or "sk-your-key-here",
        openai_model=global_config.llm.model,
        language=global_config.project.language,
        enable_streaming=global_config.project.enable_streaming,
        cache_dir=str(global_config.get_cache_dir('celltypeMainagent')),
        log_dir=str(global_config.get_logs_dir('celltypeMainagent'))
    )

    # 创建MainReactAgent实例
    agent = MainReactAgent(
        config=config,
        language=global_config.project.language,
        enable_streaming=global_config.project.enable_streaming,
    )

    # 使用示例数据文件（请根据实际情况调整路径）
    test_data_file = project_root / "test_data" / "sce.rds"
    test_tissue = "骨髓"

    # 如果测试文件不存在，使用mock路径
    if not test_data_file.exists():
        test_data_file = "/root/code/gitpackage/celltypeAgent/utils/sce.rds"
        print(f"📄 使用测试文件: {test_data_file}")

    try:
        print("\n🚀 初始化 MainReactAgent...")
        if not await agent.initialize():
            print("❌ 初始化失败")
            return

        print(f"🧬 开始分析 - 组织类型: {test_tissue}")
        print(f"📁 数据文件: {test_data_file}")

        # 调用主工作流（传入RDS路径与组织类型）
        result = await agent.process_with_llm_react(
            input_data=str(test_data_file),
            tissue_type=test_tissue
        )

        # 输出摘要
        print("\n" + "=" * 50)
        print("✅ 分析完成!")
        print(f"📊 执行结果: {result.get('success', False)}")
        print(f"🧬 目标组织: {test_tissue}")
        print(f"📏 总迭代次数: {result.get('total_iterations', 0)}")

        # 输出文件路径
        if result.get("output_file_paths"):
            print("\n📁 生成的文件:")
            for key, path in result["output_file_paths"].items():
                if path:
                    print(f"   - {key}: {path}")

        print(f"\n💾 所有输出文件都保存在: {global_config.paths.outputs_dir}")

    except Exception as e:
        print(f"❌ 执行过程中发生错误: {e}")

    finally:
        # 清理资源
        print("\n🧹 清理资源...")
        await agent.cleanup()
        await asyncio.sleep(0.5)
        gc.collect()
        await asyncio.sleep(0.2)

        print("🎉 示例运行完成！")
        print(f"📄 查看详细日志: {global_config.get_logs_dir('celltypeMainagent')}")
        print(f"📊 查看分析结果: {global_config.get_results_dir('celltypeMainagent')}")


def main():
    """主函数"""
    print("=" * 60)
    print(" CellType MCP Server - MainAgent 统一配置示例")
    print("=" * 60)
    print()
    print("💡 提示:")
    print("   - 所有输出文件都保存在统一的 outputs/ 目录下")
    print("   - API密钥可以通过环境变量 OPENAI_API_KEY 设置")
    print("   - 更多配置选项请查看 config/celltypeAgent_config.json")
    print()

    try:
        asyncio.run(example_usage())
    except KeyboardInterrupt:
        print("\n⚠️  用户中断执行")
    except Exception as e:
        print(f"❌ 程序执行失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()