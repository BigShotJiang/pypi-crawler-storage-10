#!/usr/bin/env python3
"""
celltypeAgent - 缓存配置模块（兼容性层）
Author: cuilei
Version: 1.0
"""

import os
import sys
from pathlib import Path
from typing import Optional

# 导入统一配置系统
try:
    # 优先尝试从包内导入统一配置
    from celltypeAgent.config import get_global_config, get_cache_dir as global_get_cache_dir
    UNIFIED_CONFIG_AVAILABLE = True
except ImportError:
    try:
        # 回退到根目录config
        current_dir = Path(__file__).resolve().parent.parent.parent  # 回到根目录
        sys.path.insert(0, str(current_dir))
        from config import get_global_config, get_cache_dir as global_get_cache_dir
        UNIFIED_CONFIG_AVAILABLE = True
    except ImportError:
        print("警告：统一配置系统不可用，回退到原有系统")
        UNIFIED_CONFIG_AVAILABLE = False
        from ..utils.common import GlobalCacheManager


def set_cache_dir(cache_dir: str) -> Path:
    """设置全局缓存目录

    Args:
        cache_dir: 缓存目录路径

    Returns:
        设置后的缓存目录路径
    """
    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        config = get_global_config()
        return config.get_cache_dir()
    else:
        # 回退到原有系统
        GlobalCacheManager.set_global_cache_dir(cache_dir)
        return GlobalCacheManager.get_base_cache_dir()


def init_cache(cache_dir: Optional[str] = None) -> Path:
    """初始化缓存目录

    Args:
        cache_dir: 缓存目录路径，None表示使用默认配置

    Returns:
        初始化后的缓存目录路径

    优先级：
    1. 统一配置系统（如果可用）
    2. 传入的 cache_dir 参数
    3. 环境变量 CELLTYPE_CACHE_DIR
    4. 当前工作目录下的 .celltype_cache
    """
    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        config = get_global_config()
        # 为celltypeSubagent创建专门的缓存目录
        return config.get_cache_dir("celltypeSubagent")
    else:
        # 回退到原有系统
        if cache_dir is None:
            # 检查环境变量
            cache_dir = os.environ.get('CELLTYPE_CACHE_DIR')

        if cache_dir is None:
            # 使用默认目录
            cache_dir = os.path.join(os.getcwd(), ".celltype_cache")

        return set_cache_dir(cache_dir)


def get_cache_dir(subdir: str = "") -> Path:
    """获取缓存目录路径

    Args:
        subdir: 子目录名称

    Returns:
        缓存目录路径
    """
    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        if subdir:
            return global_get_cache_dir(f"celltypeSubagent/{subdir}")
        else:
            return global_get_cache_dir("celltypeSubagent")
    else:
        # 回退到原有系统
        return GlobalCacheManager.get_cache_dir(subdir)


def get_cache_info() -> dict:
    """获取当前缓存配置信息

    Returns:
        缓存配置信息字典
    """
    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        config = get_global_config()
        base_dir = config.get_cache_dir("celltypeSubagent")

        if not base_dir.exists():
            return {
                "base_dir": str(base_dir),
                "exists": False,
                "subdirs": [],
                "agent": "celltypeSubagent"
            }

        # 扫描子目录
        subdirs = [d.name for d in base_dir.iterdir() if d.is_dir()]

        # 计算总大小
        total_size = 0
        file_count = 0
        for root, dirs, files in os.walk(base_dir):
            for file in files:
                file_path = os.path.join(root, file)
                if os.path.exists(file_path):
                    total_size += os.path.getsize(file_path)
                    file_count += 1

        return {
            "base_dir": str(base_dir),
            "exists": True,
            "subdirs": sorted(subdirs),
            "total_size_mb": total_size / (1024 * 1024),
            "file_count": file_count,
            "agent": "celltypeSubagent"
        }
    else:
        # 回退到原有系统
        base_dir = GlobalCacheManager.get_base_cache_dir()

        if not base_dir.exists():
            return {
                "base_dir": str(base_dir),
                "exists": False,
                "subdirs": []
            }

        # 扫描子目录
        subdirs = [d.name for d in base_dir.iterdir() if d.is_dir()]

        # 计算总大小
        total_size = 0
        file_count = 0
        for root, dirs, files in os.walk(base_dir):
            for file in files:
                file_path = os.path.join(root, file)
                if os.path.exists(file_path):
                    total_size += os.path.getsize(file_path)
                    file_count += 1

        return {
            "base_dir": str(base_dir),
            "exists": True,
            "subdirs": sorted(subdirs),
            "total_size_mb": total_size / (1024 * 1024),
            "file_count": file_count
        }


def clear_cache(subdir: Optional[str] = None) -> int:
    """清理缓存

    Args:
        subdir: 子目录名称，None表示清理所有缓存

    Returns:
        清理的文件数量
    """
    import shutil

    if UNIFIED_CONFIG_AVAILABLE:
        # 使用统一配置系统
        if subdir:
            cache_dir = get_cache_dir(subdir)
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
                cache_dir.mkdir(parents=True, exist_ok=True)
                return 1
            return 0
        else:
            # 清理整个celltypeSubagent缓存目录
            config = get_global_config()
            base_dir = config.get_cache_dir("celltypeSubagent")
            if base_dir.exists():
                file_count = sum(1 for _, _, files in os.walk(base_dir) for _ in files)
                shutil.rmtree(base_dir)
                base_dir.mkdir(parents=True, exist_ok=True)
                return file_count
            return 0
    else:
        # 回退到原有系统
        if subdir:
            cache_dir = get_cache_dir(subdir)
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
                cache_dir.mkdir(parents=True, exist_ok=True)
                return 1
            return 0
        else:
            # 清理整个缓存目录
            base_dir = GlobalCacheManager.get_base_cache_dir()
            if base_dir.exists():
                file_count = sum(1 for _, _, files in os.walk(base_dir) for _ in files)
                shutil.rmtree(base_dir)
                base_dir.mkdir(parents=True, exist_ok=True)
                return file_count
            return 0


# 自动初始化（如果还没有设置）
def auto_init():
    """自动初始化缓存目录（仅在必要时）"""
    try:
        if UNIFIED_CONFIG_AVAILABLE:
            # 使用统一配置系统，确保celltypeSubagent目录存在
            # 这里只是确保路径存在，不需要额外的初始化
            from config import get_cache_dir as global_get_cache_dir
            cache_dir = global_get_cache_dir("celltypeSubagent")
            # 目录会在get_cache_dir中自动创建，无需额外操作
        else:
            # 回退到原有系统：尝试获取缓存目录，如果失败则初始化
            try:
                GlobalCacheManager.get_base_cache_dir()
            except Exception:
                # 只有在真正失败时才初始化
                init_cache()
    except ImportError:
        # 统一配置系统不可用时的回退
        try:
            GlobalCacheManager.get_base_cache_dir()
        except Exception:
            init_cache()
    except Exception:
        # 其他异常，使用最基本的初始化
        pass  # 不强制初始化，避免创建不必要的目录


# 模块导入时自动初始化
auto_init()