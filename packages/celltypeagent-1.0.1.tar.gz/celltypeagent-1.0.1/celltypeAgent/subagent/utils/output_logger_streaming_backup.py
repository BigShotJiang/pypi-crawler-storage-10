#!/usr/bin/env python3
"""
celltypeAgent - 输出日志工具模块
Author: cuilei
Version: 1.0
"""

import os
import sys
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, Any
from contextlib import contextmanager
from io import StringIO

# 尝试导入colorama，如果没有安装则使用空的颜色代码
try:
    import colorama
    from colorama import Fore, Style
    colorama.init()
    COLORAMA_AVAILABLE = True
except ImportError:
    # 如果colorama不可用，定义空的颜色代码
    class Fore:
        GREEN = ""
        YELLOW = ""
        RED = ""
        BLUE = ""
        
    class Style:
        RESET_ALL = ""
        BRIGHT = ""
    
    COLORAMA_AVAILABLE = False


class OutputLogger:
    """输出日志工具类
    
    支持同时输出到控制台和文件，保持格式一致性
    """
    
    def __init__(self, 
                 log_dir: str = "./logs",
                 log_prefix: str = "celltype_analysis",
                 console_output: bool = True,
                 file_output: bool = True):
        """初始化输出日志器
        
        Args:
            log_dir: 日志文件保存目录
            log_prefix: 日志文件名前缀
            console_output: 是否输出到控制台
            file_output: 是否输出到文件
        """
        self.log_dir = Path(log_dir)
        self.log_prefix = log_prefix
        self.console_output = console_output
        self.file_output = file_output
        
        # 创建日志目录
        if self.file_output:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            
            # 生成带时间戳的日志文件名
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            self.log_file = self.log_dir / f"{self.log_prefix}_{timestamp}.log"
            
            # 初始化日志文件
            with open(self.log_file, 'w', encoding='utf-8') as f:
                f.write(f"# {self.log_prefix} 日志文件\n")
                f.write(f"# 创建时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("# " + "="*60 + "\n\n")
        else:
            self.log_file = None
    
    def _write_to_file(self, message: str) -> None:
        """写入日志文件
        
        Args:
            message: 要写入的消息
        """
        if self.file_output and self.log_file:
            timestamp = datetime.now().strftime("%H:%M:%S")
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(f"[{timestamp}] {message}\n")
                f.flush()  # 确保立即写入磁盘
    
    def _write_streaming_update(self, content: str, is_final: bool = False) -> None:
        """写入流式输出更新
        
        Args:
            content: 当前的流式内容
            is_final: 是否是最终内容
        """
        if self.file_output and self.log_file:
            timestamp = datetime.now().strftime("%H:%M:%S")
            # 简化版本：直接追加流式更新，用特殊标记区分
            status = "✅ 完成" if is_final else "⏳ 更新中"
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(f"[{timestamp}] 🌊 流式更新 ({status}): {content}\n")
                f.flush()
    
    def _write_to_console(self, message: str, color: str = None) -> None:
        """写入控制台
        
        Args:
            message: 要输出的消息
            color: 颜色代码
        """
        if self.console_output:
            if color:
                print(f"{color}{message}{Style.RESET_ALL}")
            else:
                print(message)
    
    def info(self, message: str, color: str = None) -> None:
        """输出信息级别的日志
        
        Args:
            message: 消息内容
            color: 控制台颜色（可选）
        """
        self._write_to_console(message, color)
        self._write_to_file(message)
    
    def success(self, message: str) -> None:
        """输出成功信息（绿色）
        
        Args:
            message: 消息内容
        """
        self.info(message, Fore.GREEN)
    
    def warning(self, message: str) -> None:
        """输出警告信息（黄色）
        
        Args:
            message: 消息内容
        """
        self.info(message, Fore.YELLOW)
    
    def error(self, message: str) -> None:
        """输出错误信息（红色）
        
        Args:
            message: 消息内容
        """
        self.info(message, Fore.RED)
    
    def header(self, message: str) -> None:
        """输出标题信息（蓝色加粗）
        
        Args:
            message: 消息内容
        """
        self.info(message, Fore.BLUE + Style.BRIGHT)
    
    def separator(self, char: str = "=", length: int = 60) -> None:
        """输出分隔线
        
        Args:
            char: 分隔符字符
            length: 分隔线长度
        """
        line = char * length
        self.info(line)
    
    def print(self, *args, sep: str = " ", end: str = "\n", **kwargs) -> None:
        """兼容原生print函数的接口
        
        Args:
            *args: 要打印的参数
            sep: 参数之间的分隔符
            end: 结尾字符
            **kwargs: 其他参数（为了兼容性，实际不使用）
        """
        message = sep.join(str(arg) for arg in args) + end.rstrip('\n')
        self.info(message)
    
    def get_log_file_path(self) -> Optional[Path]:
        """获取日志文件路径
        
        Returns:
            日志文件路径，如果未启用文件输出则返回None
        """
        return self.log_file
    
    @contextmanager
    def capture_stdout(self):
        """上下文管理器，用于捕获stdout输出到日志文件
        
        使用方式:
        with logger.capture_stdout():
            # 在这里的所有print()输出都会被捕获到日志文件
            print("这会被记录到日志文件")
            some_function_that_prints()
        """
        if not self.file_output:
            # 如果没有启用文件输出，直接执行原始代码
            yield
            return
            
        # 创建一个自定义的输出类来同时处理控制台和文件输出
        class TeeOutput:
            def __init__(self, original_stdout, logger_instance):
                self.original_stdout = original_stdout
                self.logger = logger_instance
                self.buffer = ""
                self.is_streaming = False
                self.streaming_content = ""
                self.last_update_length = 0  # 记录上次更新的长度，用于控制更新频率
                
            def write(self, text):
                # 输出到控制台
                self.original_stdout.write(text)
                self.original_stdout.flush()
                
                # 处理日志文件写入
                if text:
                    self.buffer += text
                    
                    # 如果在流式输出中，收集内容
                    if self.is_streaming and text.strip():
                        if text.strip() not in ["", "============================================================", "\n"]:
                            self.streaming_content += text
                            
                            # 每收集一定长度的内容才更新一次（减少频繁更新）
                            content_length = len(self.streaming_content.strip())
                            if content_length - self.last_update_length >= 50:  # 每50个字符更新一次
                                self.logger._write_streaming_update(self.streaming_content.strip())
                                self.last_update_length = content_length
                    
                    # 处理换行符分割的内容
                    while '\n' in self.buffer:
                        line, self.buffer = self.buffer.split('\n', 1)
                        line_stripped = line.strip()
                        
                        if line_stripped:
                            # 检查流式输出开始
                            if "🌊 开始流式输出:" in line_stripped:
                                self.logger._write_to_file(line_stripped)
                                self.is_streaming = True
                                self.streaming_content = ""
                                self.last_update_length = 0
                                continue
                            
                            # 检查流式输出结束
                            if "✅ 流式输出完成" in line_stripped:
                                if self.streaming_content.strip():
                                    # 最终更新，清理内容
                                    final_content = self.streaming_content.strip()
                                    if "✅ 流式输出完成" in final_content:
                                        final_content = final_content.split("✅ 流式输出完成")[0].strip()
                                    self.logger._write_streaming_update(final_content, is_final=True)
                                
                                self.logger._write_to_file(line_stripped)
                                self.is_streaming = False
                                self.streaming_content = ""
                                self.last_update_length = 0
                                continue
                            
                            # 非流式输出正常记录
                            if not self.is_streaming:
                                self.logger._write_to_file(line_stripped)
                        
            def flush(self):
                self.original_stdout.flush()
                # 刷新时如果有流式内容，更新一次
                if self.is_streaming and self.streaming_content.strip():
                    self.logger._write_streaming_update(self.streaming_content.strip())
                    self.last_update_length = len(self.streaming_content.strip())
                elif self.buffer.strip() and not self.is_streaming:
                    self.logger._write_to_file(self.buffer.rstrip())
                self.buffer = ""
                
            def __getattr__(self, name):
                return getattr(self.original_stdout, name)
        
        # 保存原始stdout
        original_stdout = sys.stdout
        
        try:
            # 替换stdout为我们的TeeOutput
            tee_output = TeeOutput(original_stdout, self)
            sys.stdout = tee_output
            yield
        finally:
            # 刷新缓冲区
            if hasattr(sys.stdout, 'flush'):
                sys.stdout.flush()
            # 恢复原始stdout
            sys.stdout = original_stdout
    
    def close(self) -> None:
        """关闭日志器（添加结束标记）"""
        if self.file_output and self.log_file:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(f"\n# 日志结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("# " + "="*60 + "\n")


# 创建默认的输出日志器实例
default_output_logger = None


def create_logger(log_dir: str = "./logs", 
                 log_prefix: str = "celltype_analysis",
                 console_output: bool = True,
                 file_output: bool = True) -> OutputLogger:
    """创建输出日志器实例
    
    Args:
        log_dir: 日志文件保存目录
        log_prefix: 日志文件名前缀
        console_output: 是否输出到控制台
        file_output: 是否输出到文件
        
    Returns:
        OutputLogger实例
    """
    global default_output_logger
    default_output_logger = OutputLogger(log_dir, log_prefix, console_output, file_output)
    return default_output_logger


def get_default_logger() -> OutputLogger:
    """获取默认的输出日志器
    
    Returns:
        默认的OutputLogger实例
    """
    global default_output_logger
    if default_output_logger is None:
        default_output_logger = create_logger()
    return default_output_logger


# 提供便捷的全局函数
def log_info(message: str, color: str = None) -> None:
    """便捷的信息输出函数"""
    get_default_logger().info(message, color)


def log_success(message: str) -> None:
    """便捷的成功信息输出函数"""
    get_default_logger().success(message)


def log_warning(message: str) -> None:
    """便捷的警告信息输出函数"""
    get_default_logger().warning(message)


def log_error(message: str) -> None:
    """便捷的错误信息输出函数"""
    get_default_logger().error(message)


def log_header(message: str) -> None:
    """便捷的标题输出函数"""
    get_default_logger().header(message)


def log_separator(char: str = "=", length: int = 60) -> None:
    """便捷的分隔线输出函数"""
    get_default_logger().separator(char, length)