#!/usr/bin/env python3
"""
celltypeAgent - 全局配置管理器
Author: cuilei
Version: 1.0
"""

import inspect
import os
import json
import sys
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime


class ConfigurationIncompleteError(Exception):
    """配置文件不完整，需要用户手动填写 API 信息"""
    pass


@dataclass
class PathConfig:
    """路径配置"""
    project_root: Path
    outputs_dir: Path
    cache_dir: Path
    logs_dir: Path
    results_dir: Path
    downloads_dir: Path
    temp_dir: Path

    def __post_init__(self):
        """确保所有路径都是Path对象"""
        for field in ['project_root', 'outputs_dir', 'cache_dir', 'logs_dir', 'results_dir', 'downloads_dir', 'temp_dir']:
            value = getattr(self, field)
            if isinstance(value, str):
                setattr(self, field, Path(value))


@dataclass
class LLMConfig:
    """LLM API配置"""
    api_base: Optional[str] = None
    api_key: Optional[str] = None
    model: str = "gpt-4"
    max_tokens: int = 4000
    temperature: float = 0.3


@dataclass
class AgentConfig:
    """单个Agent配置"""
    enabled: bool = True
    max_retries: int = 3
    log_level: str = "INFO"


@dataclass
class ProjectConfig:
    """项目配置"""
    language: str = "zh"
    enable_streaming: bool = True
    enable_logging: bool = True
    max_parallel_tasks: int = 3
    cache_expiry_days: int = 30
    auto_cleanup: bool = True


class GlobalConfigManager:
    """全局配置管理器"""

    _instance = None
    _config_file = None
    _paths = None
    _llm_config = None
    _project_config = None
    _agents_config = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_initialized'):
            self._initialize()
            self._initialized = True

    def _initialize(self):
        """初始化配置管理器"""
        env_root = os.getenv("CELLTYPE_PROJECT_ROOT")
        env_config = os.getenv("CELLTYPE_CONFIG_FILE")

        external_config = _detect_external_config() if '_detect_external_config' in globals() else None

        if env_root:
            project_root = Path(env_root).expanduser()
        elif external_config:
            project_root = external_config.parent
        else:
            project_root = Path.cwd()

        try:
            project_root = project_root.resolve()
        except Exception:
            project_root = project_root.expanduser()

        self.project_root = project_root

        if env_config:
            config_file = Path(env_config).expanduser()
        elif external_config:
            config_file = external_config
        else:
            config_file = self.project_root / "celltypeAgent_config.json"

        try:
            config_file = config_file.resolve()
        except Exception:
            config_file = config_file.expanduser()

        self._config_file = config_file

        # 如果找到了配置文件，设置环境变量供子 Agent 使用
        if config_file.exists() and not os.getenv("CELLTYPE_CONFIG_PATH"):
            os.environ["CELLTYPE_CONFIG_PATH"] = str(config_file)

        # 初始化路径配置
        self._init_paths()

        # 加载或创建配置文件
        self._load_or_create_config()

    def _init_paths(self):
        """初始化路径配置"""
        outputs_dir = self.project_root / "outputs"

        self._paths = PathConfig(
            project_root=self.project_root,
            outputs_dir=outputs_dir,
            cache_dir=outputs_dir / "cache",
            logs_dir=outputs_dir / "logs",
            results_dir=outputs_dir / "results",
            downloads_dir=outputs_dir / "downloads",
            temp_dir=outputs_dir / "temp"
        )

        # 创建必要的目录
        for path in [self._paths.outputs_dir, self._paths.cache_dir,
                     self._paths.logs_dir, self._paths.results_dir,
                     self._paths.downloads_dir, self._paths.temp_dir]:
            path.mkdir(parents=True, exist_ok=True)

        # 为每个Agent创建专门的缓存目录
        for agent_name in ["celltypeMainagent", "celltypeSubagent", "celltypeDataAgent", "celltypeAppAgent"]:
            agent_cache_dir = self._paths.cache_dir / agent_name
            agent_cache_dir.mkdir(parents=True, exist_ok=True)

    def _load_or_create_config(self):
        """加载或创建配置文件

        策略：
        - 配置文件存在 → 仅读取，绝不写入
        - 配置文件不存在 → 创建默认配置并写入一次
        """
        config_file_existed = self._config_file.exists()

        if config_file_existed:
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
                self._load_from_dict(config_data)
                # 检查环境变量冲突
                self._check_env_conflicts()
            except Exception as e:
                print(f"加载配置文件失败: {e}，使用默认配置")
                self._create_default_config()
        else:
            self._create_default_config()
            self.save_config()

        # 验证配置完整性
        self._validate_config(is_newly_created=not config_file_existed)

    def _validate_config(self, is_newly_created: bool = False):
        """
        验证配置文件是否完整

        Args:
            is_newly_created: 是否为新创建的配置文件
        """
        # 尝试导入彩色输出库
        try:
            from colorama import Fore, Style
            RED = Fore.RED
            YELLOW = Fore.YELLOW
            BLUE = Fore.BLUE
            GREEN = Fore.GREEN
            RESET = Style.RESET_ALL
        except ImportError:
            RED = YELLOW = BLUE = GREEN = RESET = ""

        # 检查 API 配置是否为空
        api_key_empty = not self._llm_config.api_key or str(self._llm_config.api_key).strip() == ""
        api_base_empty = not self._llm_config.api_base or str(self._llm_config.api_base).strip() == ""

        if api_key_empty and api_base_empty:
            # 显示友好的错误提示
            status_text = "已生成" if is_newly_created else "不完整"
            print(f"\n{RED}{'='*60}{RESET}")
            print(f"{RED}❌ 配置文件{status_text}，无法继续执行{RESET}")
            print(f"{RED}{'='*60}{RESET}\n")

            print(f"{BLUE}配置文件位置:{RESET}")
            print(f"  {YELLOW}{self._config_file}{RESET}\n")

            print(f"{BLUE}请填写以下必填项:{RESET}")
            print(f"  {GREEN}1. llm.api_base{RESET} - API 基础 URL")
            print(f"     示例: https://api.openai.com/v1")
            print(f"     示例: https://api.siliconflow.cn/v1\n")

            print(f"  {GREEN}2. llm.api_key{RESET} - API 密钥")
            print(f"     从您的 API 提供商获取\n")

            print(f"  {GREEN}3. llm.model{RESET} - 模型名称（可选，默认为 gpt-4）")
            print(f"     示例: gpt-4")
            print(f"     示例: Pro/deepseek-ai/DeepSeek-V3\n")

            print(f"{YELLOW}填写完成后，重新运行程序。{RESET}")
            print(f"{RED}{'='*60}{RESET}\n")

            raise ConfigurationIncompleteError(
                f"配置文件{status_text}: {self._config_file}\n"
                f"请填写 llm.api_base 和 llm.api_key 后重新运行。"
            )

    def _create_default_config(self):
        """创建默认配置（生成模板，不从环境变量读取 API 信息）"""
        # LLM配置（生成模板，API 信息为空，需用户手动填写）
        self._llm_config = LLMConfig(
            api_base=None,
            api_key=None,
            model="gpt-4"
        )

        # 项目配置（可从环境变量读取）
        self._project_config = ProjectConfig(
            language=os.getenv("CELLTYPE_LANGUAGE", "zh"),
            enable_streaming=os.getenv("CELLTYPE_ENABLE_STREAMING", "true").lower() == "true",
            enable_logging=os.getenv("CELLTYPE_ENABLE_LOGGING", "true").lower() == "true"
        )

        # Agent配置
        self._agents_config = {
            "celltypeMainagent": AgentConfig(),
            "celltypeSubagent": AgentConfig(),
            "celltypeDataAgent": AgentConfig(),
            "celltypeAppAgent": AgentConfig()
        }

        # 标记为新创建的配置
        self._is_newly_created = True

    def _load_from_dict(self, config_data: Dict[str, Any]):
        """从字典加载配置"""
        # 加载LLM配置
        llm_data = config_data.get("llm", {})
        self._llm_config = LLMConfig(**llm_data)

        # 加载项目配置
        project_data = config_data.get("project", {})
        self._project_config = ProjectConfig(**project_data)

        # 加载Agent配置
        agents_data = config_data.get("agents", {})
        self._agents_config = {}
        for agent_name, agent_data in agents_data.items():
            self._agents_config[agent_name] = AgentConfig(**agent_data)

        # 确保所有必要的Agent都有配置
        for agent_name in ["celltypeMainagent", "celltypeSubagent", "celltypeDataAgent", "celltypeAppAgent"]:
            if agent_name not in self._agents_config:
                self._agents_config[agent_name] = AgentConfig()

    def _check_env_conflicts(self):
        """检查环境变量与配置文件的冲突（仅提示，不自动填充）"""
        # 尝试导入colorama用于彩色输出
        try:
            from colorama import Fore, Style
            RED = Fore.RED
            YELLOW = Fore.YELLOW
            GREEN = Fore.GREEN
            RESET = Style.RESET_ALL
        except ImportError:
            RED = YELLOW = GREEN = RESET = ""

        conflicts = []

        # 检查API Base
        env_api_base = os.getenv("OPENAI_API_BASE")
        if env_api_base and self._llm_config.api_base and env_api_base != self._llm_config.api_base:
            conflicts.append({
                'field': 'API Base',
                'env_value': env_api_base,
                'config_value': self._llm_config.api_base
            })

        # 检查API Key
        env_api_key = os.getenv("OPENAI_API_KEY")
        if env_api_key and self._llm_config.api_key and env_api_key != self._llm_config.api_key:
            display_env_key = f"{env_api_key[:10]}...{env_api_key[-4:]}" if len(env_api_key) > 14 else env_api_key
            display_config_key = f"{self._llm_config.api_key[:10]}...{self._llm_config.api_key[-4:]}" if len(self._llm_config.api_key) > 14 else self._llm_config.api_key
            conflicts.append({
                'field': 'API Key',
                'env_value': display_env_key,
                'config_value': display_config_key
            })

        # 检查Model
        env_model = os.getenv("OPENAI_MODEL")
        if env_model and self._llm_config.model and env_model != self._llm_config.model:
            conflicts.append({
                'field': 'Model',
                'env_value': env_model,
                'config_value': self._llm_config.model
            })

        # 输出冲突信息
        if conflicts:
            print(f"\n{YELLOW}⚠️  环境变量与配置文件存在不一致:{RESET}")
            print(f"{YELLOW}优先使用配置文件的值，如需修改请直接编辑配置文件。{RESET}")
            for conflict in conflicts:
                print(f"{RED}  - {conflict['field']}:{RESET}")
                print(f"    环境变量: {GREEN}{conflict['env_value']}{RESET}")
                print(f"    配置文件: {YELLOW}{conflict['config_value']}{RESET} {GREEN}← 实际使用{RESET}")
            print()

    def save_config(self):
        """保存配置到文件

        ⚠️ 警告：此方法仅用于创建初始配置文件。
        在多进程环境中，配置文件应保持只读状态。

        使用场景：
        - 首次运行，配置文件不存在时创建
        - 不应在配置文件已存在时调用

        如需修改配置：
        - 请手动编辑 celltypeAgent_config.json 文件
        - 不要使用 update_*_config() 方法进行持久化
        """
        config_data = {
            "version": "1.0.0",
            "updated_at": datetime.now().isoformat(),
            "paths": {
                "project_root": str(self._paths.project_root),
                "outputs_dir": str(self._paths.outputs_dir),
                "cache_dir": str(self._paths.cache_dir),
                "logs_dir": str(self._paths.logs_dir),
                "results_dir": str(self._paths.results_dir),
                "downloads_dir": str(self._paths.downloads_dir),
                "temp_dir": str(self._paths.temp_dir)
            },
            "llm": asdict(self._llm_config),
            "project": asdict(self._project_config),
            "agents": {name: asdict(config) for name, config in self._agents_config.items()}
        }

        # 确保config目录存在
        self._config_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self._config_file, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, ensure_ascii=False, indent=2)

    # 公共接口方法
    @property
    def paths(self) -> PathConfig:
        """获取路径配置"""
        return self._paths

    @property
    def llm(self) -> LLMConfig:
        """获取LLM配置"""
        return self._llm_config

    @property
    def project(self) -> ProjectConfig:
        """获取项目配置"""
        return self._project_config

    def get_agent_config(self, agent_name: str) -> AgentConfig:
        """获取指定Agent的配置"""
        return self._agents_config.get(agent_name, AgentConfig())

    def update_llm_config(self, **kwargs):
        """更新LLM配置（仅内存，不写入文件）

        ⚠️ 注意：此方法仅更新内存中的配置对象。
        如需持久化配置，请手动编辑 celltypeAgent_config.json 文件。
        """
        for key, value in kwargs.items():
            if hasattr(self._llm_config, key):
                setattr(self._llm_config, key, value)

    def update_project_config(self, **kwargs):
        """更新项目配置（仅内存，不写入文件）

        ⚠️ 注意：此方法仅更新内存中的配置对象。
        如需持久化配置，请手动编辑 celltypeAgent_config.json 文件。
        """
        for key, value in kwargs.items():
            if hasattr(self._project_config, key):
                setattr(self._project_config, key, value)
        # ✅ 移除 save_config()，保持配置文件只读

    def update_agent_config(self, agent_name: str, **kwargs):
        """更新Agent配置（仅内存，不写入文件）

        ⚠️ 注意：此方法仅更新内存中的配置对象。
        如需持久化配置，请手动编辑 celltypeAgent_config.json 文件。
        """
        if agent_name not in self._agents_config:
            self._agents_config[agent_name] = AgentConfig()

        agent_config = self._agents_config[agent_name]
        for key, value in kwargs.items():
            if hasattr(agent_config, key):
                setattr(agent_config, key, value)
        # ✅ 移除 save_config()，保持配置文件只读

    def get_cache_dir(self, subdir: str = "") -> Path:
        """获取缓存目录路径"""
        if subdir:
            cache_path = self._paths.cache_dir / subdir
            cache_path.mkdir(parents=True, exist_ok=True)
            return cache_path
        return self._paths.cache_dir

    def get_logs_dir(self, subdir: str = "") -> Path:
        """获取日志目录路径"""
        if subdir:
            logs_path = self._paths.logs_dir / subdir
            logs_path.mkdir(parents=True, exist_ok=True)
            return logs_path
        return self._paths.logs_dir

    def get_results_dir(self, subdir: str = "") -> Path:
        """获取结果目录路径"""
        if subdir:
            results_path = self._paths.results_dir / subdir
            results_path.mkdir(parents=True, exist_ok=True)
            return results_path
        return self._paths.results_dir

    def get_downloads_dir(self, subdir: str = "") -> Path:
        """获取下载目录路径"""
        if subdir:
            downloads_path = self._paths.downloads_dir / subdir
            downloads_path.mkdir(parents=True, exist_ok=True)
            return downloads_path
        return self._paths.downloads_dir

    def get_temp_dir(self, subdir: str = "") -> Path:
        """获取临时目录路径"""
        if subdir:
            temp_path = self._paths.temp_dir / subdir
            temp_path.mkdir(parents=True, exist_ok=True)
            return temp_path
        return self._paths.temp_dir

    def cleanup_old_files(self, days: int = None):
        """清理过期文件"""
        if days is None:
            days = self._project_config.cache_expiry_days

        from datetime import timedelta
        cutoff_date = datetime.now() - timedelta(days=days)

        # 清理日志文件
        for log_file in self._paths.logs_dir.rglob("*.log"):
            if log_file.stat().st_mtime < cutoff_date.timestamp():
                log_file.unlink()

        # 清理缓存文件
        for cache_file in self._paths.cache_dir.rglob("*"):
            if cache_file.is_file() and cache_file.stat().st_mtime < cutoff_date.timestamp():
                cache_file.unlink()

        print(f"已清理{days}天前的文件")

    def apply_external_config(self, config_path: Path) -> bool:
        """尝试从外部配置文件加载设置"""
        if not config_path:
            return False

        config_path = Path(config_path).expanduser().resolve()

        if not config_path.exists():
            return False

        current_config = None
        if self._config_file is not None:
            try:
                current_config = Path(self._config_file).resolve()
            except Exception:
                current_config = None

        if current_config == config_path:
            return True

        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
        except Exception as exc:
            print(f"加载外部配置失败: {exc}")
            return False

        paths_data = config_data.get('paths') or {}
        required_keys = ['project_root', 'outputs_dir', 'cache_dir',
                         'logs_dir', 'results_dir', 'downloads_dir', 'temp_dir']

        if all(key in paths_data for key in required_keys):
            try:
                path_config = PathConfig(**{key: Path(paths_data[key]) for key in required_keys})
                self._paths = path_config
                self.project_root = path_config.project_root
                for path in [path_config.outputs_dir, path_config.cache_dir,
                             path_config.logs_dir, path_config.results_dir,
                             path_config.downloads_dir, path_config.temp_dir]:
                    path.mkdir(parents=True, exist_ok=True)
            except Exception as exc:
                print(f"应用路径配置失败: {exc}")

        self._config_file = config_path
        self._load_from_dict(config_data)
        self._check_env_conflicts()
        # ✅ 移除 save_config()，因为外部配置文件已存在，不需要再次写入
        return True

    def get_config_info(self) -> Dict[str, Any]:
        """获取配置信息摘要"""
        return {
            "project_root": str(self._paths.project_root),
            "outputs_dir": str(self._paths.outputs_dir),
            "llm_model": self._llm_config.model,
            "language": self._project_config.language,
            "agents_count": len(self._agents_config),
            "enabled_agents": [name for name, config in self._agents_config.items() if config.enabled]
        }


# 工具函数
def _detect_external_config() -> Optional[Path]:
    """
    检测配置文件，仅搜索两个位置：
    1. 环境变量 CELLTYPE_CONFIG_PATH（最高优先级）
    2. 当前工作目录下的 celltypeAgent_config.json
    """
    # 首先检查环境变量（最高优先级，用于子Agent）
    env_config_path = os.getenv("CELLTYPE_CONFIG_PATH")
    if env_config_path:
        env_config_file = Path(env_config_path).expanduser()
        if env_config_file.exists():
            try:
                # 验证是否为有效的 JSON 文件
                with open(env_config_file, 'r', encoding='utf-8') as f:
                    json.load(f)
                return env_config_file
            except (json.JSONDecodeError, IOError):
                pass

    # 检查当前工作目录
    current_config = Path.cwd() / "celltypeAgent_config.json"
    if current_config.exists():
        try:
            # 验证是否为有效的 JSON 文件
            with open(current_config, 'r', encoding='utf-8') as f:
                json.load(f)
            return current_config
        except (json.JSONDecodeError, IOError):
            pass

    return None


# 全局实例
global_config = GlobalConfigManager()


# 便捷函数
def get_global_config() -> GlobalConfigManager:
    """获取全局配置管理器实例"""
    external_config = _detect_external_config()
    if external_config:
        global_config.apply_external_config(external_config)
    return global_config


def get_paths() -> PathConfig:
    """获取路径配置"""
    return global_config.paths


def get_cache_dir(subdir: str = "") -> Path:
    """获取缓存目录"""
    return global_config.get_cache_dir(subdir)


def get_logs_dir(subdir: str = "") -> Path:
    """获取日志目录"""
    return global_config.get_logs_dir(subdir)


def get_results_dir(subdir: str = "") -> Path:
    """获取结果目录"""
    return global_config.get_results_dir(subdir)


def get_downloads_dir(subdir: str = "") -> Path:
    """获取下载目录"""
    return global_config.get_downloads_dir(subdir)


def get_temp_dir(subdir: str = "") -> Path:
    """获取临时目录"""
    return global_config.get_temp_dir(subdir)


def check_and_update_config(
    global_config: GlobalConfigManager,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    model: Optional[str] = None,
    language: Optional[str] = None,
    enable_streaming: Optional[bool] = None,
) -> None:
    """
    检查并更新配置文件

    如果传入的参数与配置文件中的值不同，自动更新配置文件并提醒用户。

    Args:
        global_config: 全局配置对象
        api_key: API 密钥
        api_base: API 基础 URL
        model: 模型名称
        language: 语言设置
        enable_streaming: 是否启用流式输出
    """
    # 尝试导入彩色输出库
    try:
        from colorama import Fore, Style
        GREEN = Fore.GREEN
        YELLOW = Fore.YELLOW
        RESET = Style.RESET_ALL
    except ImportError:
        GREEN = YELLOW = RESET = ""

    updates = []

    # 检查 LLM 配置
    if api_key is not None and api_key != global_config.llm.api_key:
        global_config.update_llm_config(api_key=api_key)
        updates.append("api_key")

    if api_base is not None and api_base != global_config.llm.api_base:
        global_config.update_llm_config(api_base=api_base)
        updates.append("api_base")

    if model is not None and model != global_config.llm.model:
        global_config.update_llm_config(model=model)
        updates.append("model")

    # 检查项目配置
    if language is not None and language != global_config.project.language:
        global_config.update_project_config(language=language)
        updates.append("language")

    if enable_streaming is not None and enable_streaming != global_config.project.enable_streaming:
        global_config.update_project_config(enable_streaming=enable_streaming)
        updates.append("enable_streaming")

    # 打印提醒信息
    if updates:
        print(f"\n{YELLOW}⚠️  配置已更新并保存到配置文件:{RESET}")
        for param in updates:
            print(f"{GREEN}   ✓ {param}{RESET}")
        print()
