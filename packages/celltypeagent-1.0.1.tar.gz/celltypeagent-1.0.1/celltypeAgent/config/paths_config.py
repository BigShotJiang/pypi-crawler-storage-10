#!/usr/bin/env python3
"""
celltypeAgent - 路径管理器
Author: cuilei
Version: 1.0
"""

from pathlib import Path
from typing import Optional, Dict
from .global_config import get_global_config


class PathManager:
    """路径管理器，提供统一的路径管理接口"""

    def __init__(self):
        self.config = get_global_config()

    def get_project_root(self) -> Path:
        """获取项目根目录"""
        return self.config.paths.project_root

    def get_outputs_dir(self) -> Path:
        """获取输出目录"""
        return self.config.paths.outputs_dir

    def get_cache_dir(self, subdir: str = "") -> Path:
        """获取缓存目录"""
        return self.config.get_cache_dir(subdir)

    def get_logs_dir(self, subdir: str = "") -> Path:
        """获取日志目录"""
        return self.config.get_logs_dir(subdir)

    def get_results_dir(self, subdir: str = "") -> Path:
        """获取结果目录"""
        return self.config.get_results_dir(subdir)

    def get_downloads_dir(self, subdir: str = "") -> Path:
        """获取下载目录"""
        return self.config.get_downloads_dir(subdir)

    def get_temp_dir(self, subdir: str = "") -> Path:
        """获取临时目录"""
        return self.config.get_temp_dir(subdir)

    def get_agent_cache_dir(self, agent_name: str) -> Path:
        """获取特定Agent的缓存目录"""
        return self.get_cache_dir(agent_name)

    def get_agent_logs_dir(self, agent_name: str) -> Path:
        """获取特定Agent的日志目录"""
        return self.get_logs_dir(agent_name)

    def get_agent_results_dir(self, agent_name: str) -> Path:
        """获取特定Agent的结果目录"""
        return self.get_results_dir(agent_name)

    def get_database_cache_dir(self, database_name: str) -> Path:
        """获取数据库缓存目录"""
        return self.get_downloads_dir(database_name)

    def create_session_dir(self, agent_name: str, session_id: str) -> Path:
        """为特定会话创建目录"""
        session_dir = self.get_results_dir(f"{agent_name}/{session_id}")
        session_dir.mkdir(parents=True, exist_ok=True)
        return session_dir

    def get_log_file_path(self, agent_name: str, session_id: Optional[str] = None) -> Path:
        """获取日志文件路径"""
        if session_id is None:
            # 使用 get_session_id() 获取当前会话ID（完整格式）
            from ..mainagent.config.session_config import get_session_id
            session_id = get_session_id()

        log_dir = self.get_agent_logs_dir(agent_name)
        log_file = log_dir / f"{agent_name}_{session_id}.log"
        return log_file

    def cleanup_empty_dirs(self):
        """清理空目录"""
        def remove_empty_dirs(path: Path):
            if not path.exists():
                return

            for child in path.iterdir():
                if child.is_dir():
                    remove_empty_dirs(child)

            # 如果目录为空，删除它（除了顶层目录）
            if path != self.get_outputs_dir() and not any(path.iterdir()):
                path.rmdir()

        remove_empty_dirs(self.get_outputs_dir())

    def get_path_info(self) -> Dict[str, str]:
        """获取路径信息摘要"""
        return {
            "project_root": str(self.get_project_root()),
            "outputs_dir": str(self.get_outputs_dir()),
            "cache_dir": str(self.get_cache_dir()),
            "logs_dir": str(self.get_logs_dir()),
            "results_dir": str(self.get_results_dir()),
            "downloads_dir": str(self.get_downloads_dir()),
            "temp_dir": str(self.get_temp_dir())
        }


# 全局路径管理器实例
path_manager = PathManager()


# 便捷函数
def get_path_manager() -> PathManager:
    """获取路径管理器实例"""
    return path_manager


# 兼容性函数 - 为现有代码提供兼容接口
def get_cache_dir(subdir: str = "") -> Path:
    """获取缓存目录（兼容性函数）"""
    return path_manager.get_cache_dir(subdir)


def get_logs_dir(subdir: str = "") -> Path:
    """获取日志目录（兼容性函数）"""
    return path_manager.get_logs_dir(subdir)


def get_results_dir(subdir: str = "") -> Path:
    """获取结果目录（兼容性函数）"""
    return path_manager.get_results_dir(subdir)


def get_downloads_dir(subdir: str = "") -> Path:
    """获取下载目录（兼容性函数）"""
    return path_manager.get_downloads_dir(subdir)


def get_temp_dir(subdir: str = "") -> Path:
    """获取临时目录（兼容性函数）"""
    return path_manager.get_temp_dir(subdir)