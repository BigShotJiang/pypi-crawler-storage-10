"""
celltypeAgent - MCP Server 统一配置模块
Author: cuilei
Version: 1.0
"""

from .global_config import (
    GlobalConfigManager,
    PathConfig,
    LLMConfig,
    AgentConfig,
    ProjectConfig,
    global_config,
    get_global_config,
    get_paths,
    get_cache_dir,
    get_logs_dir,
    get_results_dir,
    get_downloads_dir,
    get_temp_dir,
    check_and_update_config
)

from .paths_config import (
    PathManager,
    path_manager,
    get_path_manager
)

from ..mainagent.config.session_config import (
    get_session_id,
    get_session_id_for_filename,
    set_session_id,
    create_session_id,
    reset_session_id,
    get_session_info
)

__all__ = [
    # 主要类
    'GlobalConfigManager',
    'PathConfig',
    'LLMConfig',
    'AgentConfig',
    'ProjectConfig',
    'PathManager',

    # 实例
    'global_config',
    'path_manager',

    # 便捷函数
    'get_global_config',
    'get_path_manager',
    'get_paths',
    'get_cache_dir',
    'get_logs_dir',
    'get_results_dir',
    'get_downloads_dir',
    'get_temp_dir',
    'check_and_update_config',

    # Session 管理函数
    'get_session_id',
    'get_session_id_for_filename',
    'set_session_id',
    'create_session_id',
    'reset_session_id',
    'get_session_info',
]