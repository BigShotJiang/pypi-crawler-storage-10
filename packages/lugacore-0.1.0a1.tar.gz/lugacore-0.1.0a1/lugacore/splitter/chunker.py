from lugacore.logger import logger
import re
import numpy as np
from fastembed import TextEmbedding


class GenerateChunks:
    def __init__(self,
                 text: dict,
                 mod_name: str = 'BAAI/bge-small-en-v1.5'
                 ):
        """Initialize chunker instance.
        Args:
            text: Data to be split.
            mod_name: Model name for fastembed TextEmbedding instance.
        """
        self.text = text
        self.emb_model = TextEmbedding(model_name=mod_name)
        logger.info("Chunker initialised")

    @staticmethod
    def _cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
        """
        Compute cosine similarity between two vectors
        Args:
            vec_a: List of floats
            vec_b: List of floats
        Returns:
            Float
        """
        vec_a, vec_b = np.array(vec_a), np.array(vec_b)
        sim = np.dot(vec_a, vec_b) / (np.linalg.norm(vec_a) * np.linalg.norm(vec_b))
        return sim

    @staticmethod
    def _approx_tokens(text: str) -> int:
        """
        Estimate number of tokens in a text
        Args:
             text: Text you want to know number of tokens.
        Returns:
            Number of tokens.
        """
        return len(text) // 4

    def get_chunks(self, chunk_size: int, chunk_overlap=0) -> list:
        """
        Generate chunks from input text.
        Args:
            chunk_size: Number of tokens each chunk should contain.
            chunk_overlap: Estimate number of tokens that are cut from the sentence.
        Returns:
            List of chunks with their source.
        """
        chunks = []
        if self.text.get('text'):
            words = self.text['text'].split()

            start_index = 0
            if chunk_size <= chunk_overlap:
                raise ValueError("Chunk_size must be greater than chunk_overlap")
            while start_index < len(words):
                end_index = start_index + chunk_size
                chunk = {'chunk': ' '.join(words[start_index:end_index]), 'metadata': self.text.get('metadata')}
                chunks.append(chunk)
                start_index += (chunk_size - chunk_overlap)
        else:

            return []
        logger.info(f'Generated {len(chunks)} chunks from text')
        return chunks

    def _recursive_splitter(self, max_tokens: int = 1000, level=0, chunk: str = '') -> list:
        """
        Recursively split chunks based on maximum token size.
        Args:
            max_tokens: Maximum tokens for each chunk. Defaults to 1000.
            level: level of recursion. Defaults to 0.
            chunk: text from the input data
        Returns:
            List of chunks.
        """
        splits = []
        texts = self.text.get('text') if not chunk else chunk
        separators = [r'(?<!\d)(?<=\.|!|\?)(?!\d|\s*\d\.)\s*', r'\s+']

        if GenerateChunks._approx_tokens(texts) <= max_tokens:
            splits.append(texts)
            return splits
        separator = separators[min(level, len(separators) - 1)]
        chunks = re.split(separator, texts)

        if any(GenerateChunks._approx_tokens(text=chunk) >= max_tokens for chunk in chunks):
            new_chunks = []
            for chunk in chunks:
                if GenerateChunks._approx_tokens(chunk) > max_tokens:
                    new_chunks.extend(self._recursive_splitter(max_tokens=max_tokens, level=level + 1, chunk=chunk))
                else:
                    new_chunks.append(chunk)
            return new_chunks
        else:
            return chunks

    def _semantic_chunking(self, chunks: list[str], max_tokens: int = 1000, sim_threshold: float = 0.70) -> list[dict]:
        """Merge chunks with semantic similarity.
        Args:
            chunks: List of strings to be merged.
            max_tokens: Maximum tokens for each chunk. Defaults to 1000.
            sim_threshold: Desired cosine similarity threshold. Defaults to 0.70.
        Returns:
            List of merged chunks with their source.
        """
        merge = []
        curr = chunks[0]

        for nxt_chunk in chunks[1:]:
            emb_a = list(self.emb_model.embed(curr))[0]  #<- list of vectors from the TextEmbedding model
            emb_b = list(self.emb_model.embed(nxt_chunk))[0]  #<- list of vectors from the TextEmbedding model

            sim = GenerateChunks._cosine_similarity(vec_a=emb_a, vec_b=emb_b)

            combined_tkns = GenerateChunks._approx_tokens(curr) + GenerateChunks._approx_tokens(nxt_chunk)
            if combined_tkns <= max_tokens:
                combined = f'{curr.strip()} {nxt_chunk.strip()}'
                # merge only if the condition is met
                if sim >= sim_threshold:
                    curr = combined
                else:
                    merge.append({'chunk': curr, 'metadata': self.text.get('metadata')})
                    curr = nxt_chunk
            else:
                merge.append({'chunk': curr, 'metadata': self.text.get('metadata')})
                curr = nxt_chunk
        merge.append({'chunk': curr, 'metadata': self.text.get('metadata')})
        return merge

    def recursive_semantic_chunking(self, max_tokens: int = 1000, sim_threshold: float = 0.70) -> list[dict]:
        """
        Split text using recursive and semantic algorithms.
        Args:
            max_tokens: Maximum number of tokens for each chunk. Defaults to 1000.
            sim_threshold: Desired cosine similarity threshold. Defaults to 0.70.
        Returns:
            List of chunks with their source.
        """
        recursed = self._recursive_splitter(max_tokens=max_tokens)
        chunks = self._semantic_chunking(chunks=recursed, sim_threshold=sim_threshold, max_tokens=max_tokens)
        return chunks
