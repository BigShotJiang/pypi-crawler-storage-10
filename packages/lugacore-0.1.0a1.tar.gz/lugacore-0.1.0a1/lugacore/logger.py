import logging

# create logger
logger = logging.getLogger(name="LugaCore")

logger.setLevel(level=logging.DEBUG)

if not logger.handlers:
    # set the log format
    formatter = logging.Formatter(
        fmt='%(asctime)s | %(name)s - %(levelname)s:\t\t%(message)s'
    )
    #load to console
    console = logging.StreamHandler()
    console.setFormatter(fmt=formatter)
    console.setLevel(level=logging.DEBUG)
    logger.addHandler(hdlr=console)