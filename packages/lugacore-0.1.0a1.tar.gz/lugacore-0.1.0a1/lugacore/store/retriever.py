from qdrant_client import QdrantClient,models
from qdrant_client.http.models import PayloadSchemaType, Filter, FieldCondition, MatchValue
import uuid
from typing import Optional
from lugacore.logger import logger
from fastembed import SparseEmbedding,SparseTextEmbedding


class Retriever:
    def __init__(self,
                 *args:str,
                 url: str,
                 api_key: str,
                 collection_name: str,
                 sparse_model:str = 'prithivida/Splade_PP_en_v1'
                 ):
        """
        Initialises Retriever class.
        Args:
            args: arguments to act as metadata.
            url: URL to your qdrant account.
            api_key: API key for qdrant authentication.
            collection_name: Collection where the vectors are stored.
            sparse_model: Model name for generating sparse vectors.
        """
        try:
            self.client = QdrantClient(
                url=url,
                api_key=api_key,
                prefer_grpc=False,
                timeout=120,
            )
        except Exception as error:
            logger.error(f'{str(error)} - Connection failed', exc_info=True)

        self.collection_name = collection_name
        self.filters = args
        self._init_collection()
        try:
            self.sparse_model  = SparseTextEmbedding(model_name=sparse_model)
        except Exception as error:
            logger.error(f'{str(error)}', exc_info=True)

    def _init_collection(self):
        """
        Creates a Qdrant collection if it does not exist.
        """
        existing_collections = [col.name for col in self.client.get_collections().collections]
        try:
            if self.collection_name not in existing_collections:
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config={
                        'dense':models.VectorParams(size=768, distance=models.Distance.COSINE)}, # <-- configuration for dense vectors.
                    sparse_vectors_config={
                        "sparse":models.SparseVectorParams(), # <-- configuration for sparse vectors.
                    }
                )
        except Exception as error:
            logger.error(f'{str(error)} - Creating Collection of name-{self.collection_name} failed', exc_info=True)
        try:
            for field in self.filters:
                self.client.create_payload_index(
                    collection_name=self.collection_name,
                    field_name=field,
                    field_schema=PayloadSchemaType.KEYWORD
                )
        except Exception as error:
            logger.error(f'{str(error)} - Payloads need to unique', exc_info=True)

    def upsert_vectors(self, vectors: list[list[float]], chunks: list[dict], batch_size: Optional[int] = None,
                       sparse_vectors:list[SparseEmbedding]=None,**kwargs:str) -> None:
        """
        Store vector embeddings to the Qdrant collection.
        Args:
            vectors:Dense vector embeddings to be stored.
            chunks: Chunks of the dense vectors.
            batch_size: Number of dense vectors to be stored in each call. Defaults to None.
            sparse_vectors: Sparse vector embeddings to be stored along with dense vectors.
            kwargs: keyword arguments for metadata
        Returns:
            None
        """
        batch = [[split.get('chunk') for split in chunks[i:i + batch_size]] for i in range(0, len(chunks), batch_size)]

        points = [models.PointStruct(
            id=uuid.uuid4().hex,
            vector={
                "dense":vectors[i], # dense vector to be stored
                "sparse":models.SparseVector( # declaration of sparse vectors to be stored(indices and values of non-zero dimensions
                    indices=list(sparse_vectors[i].indices),
                    values=list(sparse_vectors[i].values),
                )
            },
            payload={"text": ' '.join(batch[i]), **kwargs}
        ) for i in range(len(batch))]
        try:
            self.client.upsert(
                collection_name=self.collection_name,
                wait=True,
                points=points
            )
            logger.info(f'Stored {len(vectors)} embeddings into vector database')
        except Exception as error:
            logger.error(f'{str(error)} - Storing Vectors Failed', exc_info=True)

    def search(self, query_vector: list[list[float]], limit: Optional[int] = 20, **kwargs:str) -> list[models.ScoredPoint]:
        """
        Retrieve stored embeddings with a query.
        Args:
            query_vector:dense embeddings of the query.
            limit: Maximum embeddings to be retrieved.
            kwargs: keyword arguments for metadata.
        Returns:
            list of embeddings.
        """
        scored_points = []
        logger.info('Querying vector database...')
        try:
            must_conditions = []
            for key, value in kwargs.items():
                must_conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))
            query_filter = Filter(must=must_conditions) if must_conditions else None
            result = self.client.query_points(
                collection_name=self.collection_name,
                query=query_vector[0],
                query_filter=query_filter,
                with_payload=True,
                using="dense",
                limit=limit
            ).points
            scored_points.extend(result)
        except Exception as error:
            logger.error(f'{str(error)} - Querying database Failed', exc_info=True)
        return scored_points

    def hybrid_search(self,query_vector:list[list[float]],query:str,limit:Optional[int]=20,**kwargs:str)->list[models.ScoredPoint]:
        """
        Hybrid Retrieval of stored embeddings.
        Args:
            query_vector: Dense embeddings of the query.
            query: String format of the query.
            limit: maximum embeddings to be retrieved.
            kwargs: keyword arguments for metadata.
        Returns:
            List of embeddings.
        """
        scored_points = []
        query_sparse = list(self.sparse_model.query_embed(query=query))[0]
        try:
            must_conditions = []
            for key, value in kwargs.items():
                must_conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))
            query_filter = Filter(must=must_conditions) if must_conditions else None
            hybrid_result = self.client.query_points(
                collection_name=self.collection_name,
                prefetch=[
                    models.Prefetch(
                        query=models.SparseVector(
                            indices=list(query_sparse.indices),
                            values=list(query_sparse.values)), # <-- sparse vectors
                        using="sparse",
                        limit=limit,
                        filter=query_filter
                    ),
                    models.Prefetch(
                        query=query_vector[0], # <-- dense vectors
                        using="dense",
                        limit=limit,
                        filter=query_filter,
                        )
                ],
                with_payload=True,
                query=models.FusionQuery(fusion=models.Fusion.RRF), # reciprocal rank fusion is used.
            ).points
            scored_points.extend(hybrid_result)
        except Exception as error:
            logger.error(f'{str(error)} - Querying database Failed', exc_info=True)
        return scored_points