from google import genai
from lugacore.logger import logger



class AskGemini:
    """
    Handles interaction with Gemini LLM for generating context-based answers.
    """
    def __init__(self,api_key:str, model: str = 'gemini-2.5-flash'):
        """
        Initialize the AskGemini Chat interface
        Args:
             model: Them Gemini model to use for generating responses. Defaults to 'gemini-2.5-flash'.
        """
        try:
            self.client = genai.Client(api_key=api_key)
            self.chat = self.client.chats.create(model=model)
            logger.info('AskGemini initialized')
        except Exception as error:
            logger.error(f'{str(error)} - Connection failed',exc_info=True)

    def generate_answer(self, context: str, question: str) -> str:
        """
        Generate an answer from LLM using provided context and question.
        Args:
            context: Background or document text to ground the response.
            question: The user query to answer.
        Returns:
            The generated answer text
        """
        answer = ''
        prompt = (f"Generate answers using. "
                  f"The following context to answer:\n\n {context} \n\nQuestion:{question}")
        logger.info(f'Generating response for query - {question}')
        try:
            response = self.chat.send_message(message=prompt)
            answer += response.text.strip()
        except Exception as error:
            logger.error(f'{str(error)} - Message sending failed')
        return answer


