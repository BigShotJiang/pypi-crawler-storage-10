from typing import Optional
from google import genai
from google.genai import types
from lugacore.logger import logger
from fastembed import SparseTextEmbedding, SparseEmbedding


class GeminiEmbedder:

    def __init__(self,
                 embedding_model: str,
                 gemini_api_key: str,
                 vector_size: int = 768,
                 sprs_embedding_md: str = 'prithivida/Splade_PP_en_v1',
                 ):
        """
        Initialize the Embedder instance.
        Args:
            embedding_model: Name of the Gemini embedding model.
            gemini_api_key: API key for Gemini authentication.
            vector_size: Dimensionality of the generated embeddings. Defaults to 768.
            sprs_embedding_md: Name of sparse embedding model from fastembed models.
        """

        self.model = embedding_model
        self.vector_size = vector_size
        self.gemini_api_key = gemini_api_key
        try:
            self.sparse_model = SparseTextEmbedding(model_name=sprs_embedding_md) # <-- download sparse embedding model.
        except Exception as error:
            logger.error(f'{str(error)}', exc_info=True)

        try:
            self.client = genai.Client(api_key=self.gemini_api_key)
        except Exception as error:
            logger.error(f'{str(error)}', exc_info=True)

    def get_embeddings(self, chunks: list[dict], batch_size: int = None, task_type: Optional[str] = None) -> list[
        list[float]]:

        """
        Generate embeddings for multiple text chunks.
        Args:
            chunks: A list of text chunks to embed.
            batch_size: Number of chunks per batch. Defaults to None.
            task_type: Type of task (e.g., 'RETRIEVAL_DOCUMENT'). Defaults to None.
        Returns:
            A list of embedding vectors.
        """

        batch = [[split.get('chunk') for split in chunks[i:i + batch_size]] for i in range(0, len(chunks), batch_size)]
        embeddings = []
        for index, chunk in enumerate(batch):
            try:
                result = self.client.models.embed_content(
                    model=self.model,
                    contents=chunk,
                    config=types.EmbedContentConfig(
                        task_type=task_type,
                        output_dimensionality=self.vector_size)
                )
                embedding = result.embeddings[0].values
                if len(embedding) != self.vector_size:
                    logger.error(f"Embedding size mismatch for batch {index}. "
                                 f"Expected {self.vector_size}, got {len(embedding)}")
                embeddings.append(embedding)
            except Exception as error:
                logger.error(f'{str(error)} - Embedding failed', exc_info=True)
        logger.info(f'Generated {len(embeddings)} Embedding successful')
        return embeddings

    def get_query_vector(self, question: str | list[str], task_type: Optional[str] = None) -> list[list[float]]:
        """
        Generate embedding for a query or list of queries.
        Args:
             question: Question(s) to embed.
             task_type: Embedding task type (e.g., 'QUESTION_ANSWERING'). Defaults to None.
        Returns:
            Embedding vectors for the question(s).
        """
        embeddings = []
        try:

            result = self.client.models.embed_content(
                model=self.model,
                contents=question,
                config=types.EmbedContentConfig(
                    task_type=task_type,
                    output_dimensionality=self.vector_size)
            )
            embedding = result.embeddings[0].values
            embeddings.append(embedding)
            logger.info('Embedding successful')

        except Exception as e:
            logger.error(f'{str(e)} - Embedding of {question} failed', exc_info=True)
        return embeddings

    def get_sparse_embeddings(self, chunks: list[dict], batch_size: int = None) -> list[SparseEmbedding]:
        """
        Encode a list of chunks into a list of sparse embeddings.
        Args:
            chunks: List of strings to embed
            batch_size: An integer for batching chunks.
        Returns:
            List of embeddings of type SparseEmbedding


        """
        batch = [[split.get('chunk') for split in chunks[i:i + batch_size]] for i in range(0, len(chunks), batch_size)]
        sparse_embeddings_list = []
        for doc in batch:
            sparse = list(self.sparse_model.embed(documents=doc))
            sparse_embeddings_list.extend(sparse)
        return sparse_embeddings_list


