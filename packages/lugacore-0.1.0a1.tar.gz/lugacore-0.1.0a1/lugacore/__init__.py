from lugacore.loaders import DocumentLoader
from lugacore.splitter import GenerateChunks
from lugacore.embedings import GeminiEmbedder
from lugacore.store import Retriever
from lugacore.chat import AskGemini


class LugaCore:
    """
    A class designed for Retrieval-Augmented Generation (RAG) operations.
    """
    def __init__(self,
                 qdrant_url: str,
                 qdrant_api_key: str,
                 gemini_api_key: str,
                 embedding_model: str = 'gemini-embedding-001',
                 vector_size: int = 768,
                 llm_model: str = 'gemini-2.5-flash',
                 collection: str = 'sparse',
                 hybrid:bool = False
                 ) -> None:
        """
        Initializes a LugaCore instance with model and Qdrant settings.
        Args:
            embedding_model: Model used to generate embeddings. Defaults to 'gemini-embedding-001'.
            vector_size: Dimensionality of the embeddings. Defaults to 768.
            gemini_api_key: API key for the Gemini service.
            llm_model: Large Language Model for text generation. Defaults to 'gemini-2.5-flash'.
            qdrant_url: URL of the Qdrant vector database.
            qdrant_api_key: API key for Qdrant authentication.
            collection: Name of the Qdrant collection to use. Defaults to 'test_collection'.
            hybrid: Boolean to enforce hybrid search and sparse embedding
        """

        self.embedder = GeminiEmbedder(
            embedding_model=embedding_model,
            gemini_api_key=gemini_api_key,
            vector_size=vector_size)

        self.chat = AskGemini(model=llm_model,api_key=gemini_api_key)

        self.store = Retriever(
            url=qdrant_url,
            api_key=qdrant_api_key,
            collection_name=collection)
        self.hybrid_search = hybrid

    def load_document(self,filepath_or_buffer:str,chunk_size:int=200,overlap:int=20,batch:int=5,**kwargs:str) -> None:
        """
        Load document, split into chunks, embed into dense and sparse vectors and upsert them into Qdrant collection.
        Args:
            filepath_or_buffer: Path to the file loaded.
            chunk_size: Size of chunks
            overlap:
            batch: Number of chunks stored per call.
            kwargs: Metadata of documents for accuracy.
        Returns:
            None.
        """
        doc = DocumentLoader(filepath_or_buffer=filepath_or_buffer)
        texts = doc.extract_text_from_document()
        instance = GenerateChunks(text=texts)
        splits = instance.get_chunks(chunk_size=chunk_size, chunk_overlap=overlap)
        embedding = self.embedder.get_embeddings(chunks=splits,batch_size=batch)

        if self.hybrid_search: # <- enable sparse embedding
            sparse_vectors = self.embedder.get_sparse_embeddings(chunks=splits,batch_size=batch)
            self.store.upsert_vectors(vectors=embedding,chunks=splits,sparse_vectors=sparse_vectors,batch_size=batch,**kwargs)
        else:
            self.store.upsert_vectors(vectors=embedding, chunks=splits)

    def ask(self, question:str,**kwargs:str) -> str:
        """
        Generate an answer from LLM using provided question.
        Args:
            question: The user query to answer.
            kwargs: Metadata of documents for accuracy.
        Returns:
            The generated answer text
        """
        context = ''
        points = self.embedder.get_query_vector(question=question)

        if self.hybrid_search: # <- enable hybrid search

            result = self.store.hybrid_search(query_vector=points, limit=20,query=question,**kwargs)
            context += '\n'.join(hit.payload['text'] for hit in result)
        else:
            result = self.store.search(query_vector=points,limit=20,**kwargs)
            context += '\n'.join(hit.payload['text'] for hit in result)
        answer = self.chat.generate_answer(context=context, question=question)
        return answer

