from docx import Document
from typing import BinaryIO, Optional
import os
from lugacore.logger import logger


class DocumentLoader:
    def __init__(self, filepath_or_buffer: str | BinaryIO, delimiter: Optional[str] = None):
        self.document = filepath_or_buffer
        self.delimiter = delimiter
        logger.info(f'Initialized DocumentLoader with file: {filepath_or_buffer}')

    def extract_text_from_document(self) -> dict:
        """
        Extract texts from the document.
        Returns:
            Dictionary with keys; 'text', 'metadata'.
        """
        text = ''
        output = {}
        _, filename = os.path.split(self.document)
        _, extension = os.path.splitext(filename)
        try:
            if extension == '.docx':
                doc = Document(self.document)
                paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
                text += "\n".join(paragraphs)
                output.update({'text': text, 'metadata': {'source': self.document}})
        except Exception as error:
            logger.error(f'{str(error)}', exc_info=True)
        return output