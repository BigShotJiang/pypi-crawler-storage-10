<h1 align="center" >LugaCore</h1>

[![License:MIT](https://img.shields.io/badge/license-MIT-green.svg?style=flat-default)](LICENSE) 
![Release Status](https://img.shields.io/badge/Release_Status-3--alpha-orange?style=flat-default)
![LLM](https://img.shields.io/badge/LLM-Gemini-8E75B2?style=flat-defaultc&logo=google&logoColor=white)
![VectorDB](https://img.shields.io/badge/VectorDB-Qdrant-4515B3?style=flat-default&logo=qdrant&logoColor=white)

A lightweight, modular Retrieval-Augmented-Generation (RAG) system built from fundamental python libraries for efficient, verifiable Q&A.

## **📘 Overview**
This project is a RAG framework built without reliance on high-level orchestration libraries. it demonstrates a ground-up implementation of the key RAG components.

## **✨  Features**
**Custom Document Processing**:
* **Self-implemented Text Splitter**: Recursive,semantic text splitting with token awareness logic for optimal chunk boundaries.
* **Custom Document Loader**: Direct .docx parsing via python-docx, preserving paragraphs.

**Intelligent Retrieval**:
* **Hybrid Search Engine**: combines dense semantic and sparse keyword retrieval within Qdrant for flexible query resolution.
* **Qdrant Integration**: Native support for:
  * Vector indexing and collection management
  * Batch upserts and attribute-based payload filtering
  * Hybrid retrieval experimentation (dense + sparse)

**Gemini LLM Integration** 
* **LLM-Driven Generation**: Uses **Gemini** exclusively for answer synthesis, summarization, and context-aware responses.
* **Context injection**: Dynamically augments user queries with retrieved context chunks.
* **Conversation Flow**: Uses [Gemini chat SDK](https://ai.google.dev/gemini-api/docs/text-generation) for multi-turn conversations keeping track of user queries and RAG responses to improve relevance.

**Modular & Transparent**
* 100% open and debuggable - designed for **learning**, **research**, and **low-level RAG experimentation**.


## **🚀  Installation & Quick Start**
Follow these steps to install **LangCore** from PyPI and start using your RAG powered by Gemini.
### 1. Create project directory (if not already created)
```bash
# setup
mkdir my_project
cd my_project
```
### 2. Create and activate Virtual environment

````bash
# create a virtual environment
python -m venv virt

#Activate it (windows)
source virt/scripts/activate
````
### 3. Install LugaCore from PyPI


````bash
 pip install lugacore
````
### 4. Verify Installation

````bash
pip list | grep lugacore
````
### 5. Quick Start Example

````python
from lugacore import LugaCore

#Initialize RAG pipeline
rag = LugaCore(
  qdrant_api_key="YOUR_QDRANT_API_KEY",
  gemini_api_key="YOUR_GEMINI_API_KEY",
  qdrant_url="YOUR_QDRANT_URL"
)

# Ingest documents
rag.load_document(filepath_or_buffer="path/to/your/file.docx")

#Query your knowledge base
response = rag.ask("What is physics?")
print(response)
````
## **🧩  Planed Features**

* Re-ranking.
* Knowledge Graph
* Caching layer
* Multimodal support (images,audio, video).
* Agentic pipelines
* Async & Sync support

