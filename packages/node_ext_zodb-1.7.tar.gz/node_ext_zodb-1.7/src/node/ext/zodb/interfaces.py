from node.interfaces import INode


class IZODBNode(INode):
    """Marker for ZODB nodes."""
