"""APIs related to Nextcloud Providers."""
