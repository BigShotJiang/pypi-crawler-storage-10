"""Version of nc_py_api."""

__version__ = "0.22.0"
