"""SFR Box API."""
