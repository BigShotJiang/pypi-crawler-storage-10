"""SFR Box CLI."""
