# triton_python_backend_mock_utils

This is a mock library for the triton_python_backend_utils python package that is available inside a [triton server](https://github.com/triton-inference-server/server) python backend runtime.
This mock library is intended to be used for local development and unit testing of triton python backend models outside the triton server container environment.
This library attempts to replicate the interface of the triton_python_backend_utils package, but may not have full functionality or behavior of the original package.
PRs are welcome to improve the mock library to better match the real package.

The need for this mock library was brought up in the following GitHub issue: https://github.com/triton-inference-server/server/issues/5813

## Installation

You can install the mock library via pip:

```bash
pip install triton_python_backend_mock_utils
```

## Usage

You can now import and use the `triton_python_backend_utils` module in your local python environment for type hints and unit testing.
Please see the [python backend](https://github.com/triton-inference-server/python_backend) documentation for more details on available functionality and usage.

You can reference our [example model](./examples/model.py) to see the usage which includes a `__main__` block for local testing.
You can run this model in your local python environment by running:

```bash
python examples/model.py
```
