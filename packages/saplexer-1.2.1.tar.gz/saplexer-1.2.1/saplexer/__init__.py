from .display import display

__all__ = ["display"]
