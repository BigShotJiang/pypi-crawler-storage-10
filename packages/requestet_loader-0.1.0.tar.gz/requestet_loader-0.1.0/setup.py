from setuptools import setup, find_packages

setup(
    name="requestet-loader",
    version="0.1.0",
    description="Load and run code from Pastebin using base64 ID",
    author="Zver",
    packages=find_packages(),
    install_requires=["requests"],
    python_requires=">=3.6",
)