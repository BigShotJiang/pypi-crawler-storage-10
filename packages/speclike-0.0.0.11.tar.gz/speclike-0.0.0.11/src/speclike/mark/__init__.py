
from speclike.mark.mod import setup, invariant, before, after

__all__ = ("setup", "invariant", "before", "after")
