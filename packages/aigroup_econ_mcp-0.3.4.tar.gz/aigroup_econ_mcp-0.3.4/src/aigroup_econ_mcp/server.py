
"""
AIGroup 计量经济学 MCP 服务器
使用最新的MCP特性提供专业计量经济学分析工具
"""

from typing import List, Dict, Any, Optional, Annotated, Tuple
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
import importlib.metadata

import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.tsa import stattools
from scipy import stats
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP, Context
from mcp.server.session import ServerSession
from mcp.types import CallToolResult, TextContent


# 数据模型定义 - 使用Pydantic实现结构化输出
class DescriptiveStatsResult(BaseModel):
    """描述性统计结果"""
    count: int = Field(description="样本数量")
    mean: float = Field(description="均值")
    std: float = Field(description="标准差")
    min: float = Field(description="最小值")
    max: float = Field(description="最大值")
    median: float = Field(description="中位数")
    skewness: float = Field(description="偏度")
    kurtosis: float = Field(description="峰度")


class OLSRegressionResult(BaseModel):
    """OLS回归分析结果"""
    rsquared: float = Field(description="R²")
    rsquared_adj: float = Field(description="调整R²")
    f_statistic: float = Field(description="F统计量")
    f_pvalue: float = Field(description="F检验p值")
    aic: float = Field(description="AIC信息准则")
    bic: float = Field(description="BIC信息准则")
    coefficients: Dict[str, Dict[str, float]] = Field(description="回归系数详情")


class HypothesisTestResult(BaseModel):
    """假设检验结果"""
    test_type: str = Field(description="检验类型")
    statistic: float = Field(description="检验统计量")
    p_value: float = Field(description="p值")
    significant: bool = Field(description="是否显著(5%水平)")
    confidence_interval: Optional[List[float]] = Field(default=None, description="置信区间")


class TimeSeriesStatsResult(BaseModel):
    """时间序列统计结果"""
    adf_statistic: float = Field(description="ADF检验统计量")
    adf_pvalue: float = Field(description="ADF检验p值")
    stationary: bool = Field(description="是否平稳")
    acf: List[float] = Field(description="自相关函数")
    pacf: List[float] = Field(description="偏自相关函数")


# 应用上下文
@dataclass
class AppContext:
    """应用上下文，包含共享资源"""
    config: Dict[str, Any]
    version: str = importlib.metadata.version("aigroup-econ-mcp")


# 服务器图标（已移除，因为MCP库不再支持Icon类）


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """服务器生命周期管理"""
    # 启动时初始化资源
    config = {
        "max_sample_size": 10000,
        "default_significance_level": 0.05,
        "supported_tests": ["t_test", "f_test", "chi_square", "adf"],
        "data_types": ["cross_section", "time_series", "panel"]
    }

    try:
        yield AppContext(config=config, version=importlib.metadata.version("aigroup-econ-mcp"))
    finally:
        # 清理资源
        pass


# 创建MCP服务器实例
mcp = FastMCP(
    name="aigroup-econ-mcp",
    instructions="Econometrics MCP Server - Provides data analysis, regression analysis, hypothesis testing and more",
    lifespan=lifespan
)


@mcp.resource("dataset://sample/{dataset_name}")
def get_sample_dataset(dataset_name: str) -> str:
    """Get sample dataset"""
    datasets = {
        "economic_growth": """
        GDP Growth,Inflation Rate,Unemployment Rate,Investment Rate
        3.2,2.1,4.5,15.2
        2.8,2.3,4.2,14.8
        3.5,1.9,4.0,16.1
        2.9,2.4,4.3,15.5
        """,
        "stock_returns": """
        Stock A,Stock B,Stock C
        0.02,-0.01,0.015
        -0.015,0.025,-0.008
        0.018,-0.005,0.012
        """,
        "time_series": """
        Date,Sales,Advertising Expense
        2023-01,12000,800
        2023-02,13500,900
        2023-03,11800,750
        2023-04,14200,1000
        """
    }

    if dataset_name not in datasets:
        return f"Available datasets: {', '.join(datasets.keys())}"

    return datasets[dataset_name]


@mcp.prompt(title="Economic Data Analysis")
def economic_analysis_prompt(data_description: str, analysis_type: str = "descriptive") -> str:
    """Economic data analysis prompt template"""
    prompts = {
        "descriptive": "Please perform descriptive statistical analysis on the following economic data:",
        "regression": "Please perform regression analysis on the following economic data to identify key factors:",
        "hypothesis": "Please perform hypothesis testing on the following economic data to verify research assumptions:",
        "time_series": "Please analyze the following time series data to check stationarity and correlation:"
    }

    return f"{prompts.get(analysis_type, prompts['descriptive'])}\n\nData description: {data_description}"


@mcp.tool()
async def descriptive_statistics(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""数据字典，格式为 {变量名: [数值列表]}
            
示例格式：
{
    "GDP增长率": [3.2, 2.8, 3.5, 2.9],
    "通货膨胀率": [2.1, 2.3, 1.9, 2.4],
    "失业率": [4.5, 4.2, 4.0, 4.3]
}

要求:
- 至少包含一个变量
- 每个变量的数据点数量应相同
- 数值必须为浮点数或整数
- 建议样本量 >= 30 以获得可靠的统计推断"""
        )
    ]
) -> CallToolResult:
    """计算描述性统计量
    
    📊 功能说明：
    对输入数据进行全面的描述性统计分析，包括集中趋势、离散程度、分布形状等指标。
    
    📈 输出指标：
    - 样本数量 (count)
    - 均值 (mean)：数据的平均水平
    - 标准差 (std)：数据的离散程度
    - 最小值/最大值 (min/max)：数据的取值范围
    - 中位数 (median)：数据的中间值，对异常值不敏感
    - 偏度 (skewness)：分布的对称性，0表示对称，>0右偏，<0左偏
    - 峰度 (kurtosis)：分布的尖峭程度，0表示正态分布
    - 相关系数矩阵：变量间的线性相关关系
    
    💡 使用场景：
    - 初步了解数据的分布特征
    - 检查数据质量和异常值
    - 为后续建模提供基础信息
    - 比较不同变量的统计特征
    
    ⚠️ 注意事项：
    - 偏度绝对值 > 1 表示数据明显偏斜，可能需要转换
    - 峰度绝对值 > 3 表示尖峭或扁平分布
    - 相关系数 > 0.8 表示强相关，可能存在多重共线性

    Args:
        data: 数据字典，键为变量名，值为数值列表
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始计算描述性统计，处理 {len(data)} 个变量")

    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        
        df = pd.DataFrame(data)
        
        # 检查数据一致性
        if len(df.columns) == 0:
            raise ValueError("至少需要一个变量")
        
        # 基础统计量 - 修复：返回所有变量的综合统计
        result = DescriptiveStatsResult(
            count=len(df),
            mean=df.mean().mean(),  # 所有变量的均值
            std=df.std().mean(),    # 所有变量的标准差均值
            min=df.min().min(),     # 所有变量的最小值
            max=df.max().max(),     # 所有变量的最大值
            median=df.median().mean(),  # 所有变量的中位数均值
            skewness=df.skew().mean(),  # 所有变量的偏度均值
            kurtosis=df.kurtosis().mean()  # 所有变量的峰度均值
        )

        # 计算相关系数矩阵
        correlation_matrix = df.corr().round(4)

        await ctx.info(f"描述性统计计算完成，样本大小: {len(df)}")

        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"描述性统计结果：\n"
                         f"均值: {result.mean:.4f}\n"
                         f"标准差: {result.std:.4f}\n"
                         f"最小值: {result.min:.4f}\n"
                         f"最大值: {result.max:.4f}\n"
                         f"中位数: {result.median:.4f}\n"
                         f"偏度: {result.skewness:.4f}\n"
                         f"峰度: {result.kurtosis:.4f}\n\n"
                         f"相关系数矩阵：\n{correlation_matrix.to_string()}"
                )
            ],
            structuredContent=result.model_dump()
        )

    except Exception as e:
        await ctx.error(f"计算描述性统计时出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def ols_regression(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据（被解释变量/响应变量）
            
示例:[12000, 13500, 11800, 14200, 15100]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量/预测变量），二维列表格式
            
示例格式（3个观测，2个自变量）：
[
    [800, 5.2],    # 第1个观测的自变量值
    [900, 5.8],    # 第2个观测的自变量值
    [750, 4.9]     # 第3个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致
- 自变量数量建议 < 观测数量/10（避免过拟合）"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""自变量名称列表（可选）
            
示例:["广告支出", "价格指数"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None
) -> CallToolResult:
    """执行普通最小二乘法(OLS)回归分析
    
    📊 功能说明：
    使用最小二乘法估计线性回归模型，分析因变量与自变量之间的线性关系。
    模型形式：Y = β₀ + β₁X₁ + β₂X₂ + ... + βₖXₖ + ε
    
    📈 输出指标：
    - R²：决定系数，取值0-1，衡量模型拟合优度
    - 调整R²：考虑自变量数量的修正R²
    - F统计量及p值：检验模型整体显著性
    - AIC/BIC：信息准则，用于模型比较，越小越好
    - 回归系数：每个自变量的估计值、标准误、t统计量、p值、置信区间
    
    💡 使用场景：
    - 因果关系分析（如广告支出对销售额的影响）
    - 预测建模（如根据经济指标预测GDP）
    - 控制变量分析（如研究教育回报率时控制工作经验）
    - 假设检验（如检验某变量是否对结果有显著影响）
    
    ⚠️ 注意事项：
    - R² > 0.7 表示拟合良好，但需警惕过拟合
    - p值 < 0.05 表示该系数在5%水平显著
    - 需检查残差的正态性、同方差性和独立性假设
    - 自变量间高度相关（相关系数>0.8）可能导致多重共线性问题
    - 样本量过小可能导致不可靠的估计结果

    Args:
        y_data: 因变量数据
        x_data: 自变量数据，每行一个观测
        feature_names: 自变量名称（可选）
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始OLS回归分析，样本大小: {len(y_data)}，自变量数量: {len(x_data[0]) if x_data else 0}")

    try:
        # 数据验证
        if not y_data:
            raise ValueError("因变量数据不能为空")
        if not x_data:
            raise ValueError("自变量数据不能为空")
        if len(y_data) != len(x_data):
            raise ValueError(f"因变量和自变量的观测数量不一致: y_data={len(y_data)}, x_data={len(x_data)}")
        
        # 准备数据
        X = np.array(x_data)
        y = np.array(y_data)
        
        # 添加常数项
        X_with_const = sm.add_constant(X)

        # 拟合模型
        model = sm.OLS(y, X_with_const).fit()

        # 构建系数字典
        conf_int = model.conf_int()
        coefficients = {}
        
        # 修复：正确处理feature_names为None的情况
        if feature_names is None:
            feature_names = [f"x{i+1}" for i in range(X.shape[1])]
        elif len(feature_names) != X.shape[1]:
            await ctx.warning(f"提供的feature_names数量({len(feature_names)})与自变量数量({X.shape[1]})不匹配，使用默认命名")
            feature_names = [f"x{i+1}" for i in range(X.shape[1])]

        for i, coef in enumerate(model.params):
            if i == 0:
                var_name = "const"
            else:
                var_name = feature_names[i-1]
            
            coefficients[var_name] = {
                "coef": float(coef),  # 转换numpy.float64为float
                "std_err": float(model.bse[i]),
                "t_value": float(model.tvalues[i]),
                "p_value": float(model.pvalues[i]),
                "ci_lower": float(conf_int[i][0]),
                "ci_upper": float(conf_int[i][1])
            }
        
        # 构建结果
        result = OLSRegressionResult(
            rsquared=float(model.rsquared),
            rsquared_adj=float(model.rsquared_adj),
            f_statistic=float(model.fvalue),
            f_pvalue=float(model.f_pvalue),
            aic=float(model.aic),
            bic=float(model.bic),
            coefficients=coefficients
        )

        await ctx.info("OLS回归分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"OLS回归分析结果：\n"
                         f"R² = {result.rsquared:.4f}\n"
                         f"调整R² = {result.rsquared_adj:.4f}\n"
                         f"F统计量 = {result.f_statistic:.4f} (p = {result.f_pvalue:.4f})\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}\n\n"
                         f"回归系数：\n{model.summary().tables[1]}"
                )
            ],
            structuredContent=result.model_dump()
        )

    except Exception as e:
        await ctx.error(f"OLS回归分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def hypothesis_testing(
    ctx: Context[ServerSession, AppContext],
    data1: Annotated[
        List[float],
        Field(
            description="""第一组数据或单一样本数据
            
示例:[3.2, 2.8, 3.5, 2.9, 3.1, 2.7, 3.3]

要求:
- 必须为数值列表
- 不能包含缺失值
- 建议样本量 >= 30（大样本）
- t检验要求数据近似正态分布"""
        )
    ],
    data2: Annotated[
        Optional[List[float]],
        Field(
            default=None,
            description="""第二组数据（可选，用于双样本检验）
            
示例:[2.5, 2.9, 2.3, 2.6, 2.8]

说明：
- 仅在双样本t检验时需要提供
- 单样本t检验时保持为None
- 两组数据可以
有不同的样本量
- ADF检验不需要第二组数据"""
        )
    ] = None,
    test_type: Annotated[
        str,
        Field(
            default="t_test",
            description="""假设检验类型

可选值：
- "t_test": t检验（默认）
  * 单样本t检验：检验样本均值是否等于0（data2=None）
  * 双样本t检验：检验两组样本均值是否相等（提供data2）
  
- "adf": 增强迪基-富勒检验（Augmented Dickey-Fuller Test）
  * 用于检验时间序列的平稳性
  * 原假设：存在单位根（非平稳）
  * p<0.05 拒绝原假设，序列平稳

使用建议：
- 比较均值差异 → 使用 t_test
- 检验时间序列平稳性 → 使用 adf"""
        )
    ] = "t_test"
) -> CallToolResult:
    """执行统计假设检验
    
    📊 功能说明：
    对数据进行统计假设检验，判断样本是否支持某个统计假设。
    
    📈 检验类型详解：
    
    1️⃣ t检验 (t_test)：
       - 单样本：H₀: μ = 0 vs H₁: μ ≠ 0
       - 双样本：H₀: μ₁ = μ₂ vs H₁: μ₁ ≠ μ₂
       - 适用于小样本（n<30）且数据近似正态分布
    
    2️⃣ ADF检验 (adf)：
       - H₀: 序列存在单位根（非平稳）
       - H₁: 序列不存在单位根（平稳）
       - 用于时间序列分析前的平稳性检验
    
    📊 输出指标：
    - 检验统计量：用于判断是否拒绝原假设
    - p值：显著性水平，<0.05表示在5%水平显著
    - 是否显著：基于5%显著性水平的判断
    - 置信区间：参数的可能取值范围（仅t检验）
    
    💡 使用场景：
    - 检验新药是否有效（单样本t检验）
    - 比较两种教学方法的效果差异（双样本t检验）
    - 检验股价序列是否平稳（ADF检验）
    - 验证经济理论假说（如购买力平价理论）
    
    ⚠️ 注意事项：
    - p值 < 0.05：拒绝原假设（结果显著）
    - p值 >= 0.05：不能拒绝原假设（结果不显著）
    - t检验要求数据近似正态分布
    - 小样本(<30)时t检验结果可能不可靠
    - ADF检验中p<0.05表示序列平稳（拒绝非平稳假设）

    Args:
        data1: 第一组数据
        data2: 第二组数据（可选，用于双样本检验）
        test_type: 检验类型（t_test或adf）
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始假设检验: {test_type}")

    try:
        if test_type == "t_test":
            if data2 is None:
                # 单样本t检验
                result = stats.ttest_1samp(data1, 0)
                ci = stats.t.interval(0.95, len(data1)-1, loc=np.mean(data1), scale=stats.sem(data1))
            else:
                # 双样本t检验
                result = stats.ttest_ind(data1, data2)
                ci = None  # 双样本t检验不计算置信区间

            test_result = HypothesisTestResult(
                test_type=test_type,
                statistic=result.statistic,
                p_value=result.pvalue,
                significant=result.pvalue < 0.05,
                confidence_interval=list(ci) if ci else None
            )

        elif test_type == "adf":
            # ADF单位根检验
            result = stattools.adfuller(data1)
            test_result = HypothesisTestResult(
                test_type="adf",
                statistic=result[0],
                p_value=result[1],
                significant=result[1] < 0.05,
                confidence_interval=None
            )
        else:
            raise ValueError(f"不支持的检验类型: {test_type}")

        await ctx.info(f"假设检验完成: {test_type}")

        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"{test_type.upper()}检验结果：\n"
                         f"检验统计量 = {test_result.statistic:.4f}\n"
                         f"p值 = {test_result.p_value:.4f}\n"
                         f"{'显著' if test_result.significant else '不显著'} (5%水平)\n"
                         f"{f'95%置信区间: [{test_result.confidence_interval[0]:.4f}, {test_result.confidence_interval[1]:.4f}]' if test_result.confidence_interval else ''}"
                )
            ],
            structuredContent=test_result.model_dump()
        )

    except Exception as e:
        await ctx.error(f"假设检验出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def time_series_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        List[float],
        Field(
            description="""时间序列数据（按时间顺序排列）
            
示例格式：
[12000, 13500, 11800, 14200, 15100, 14800, 16200, 15900]
# 表示连续8期的观测值，如月度销售额

要求:
- 必须按时间顺序排列（从早到晚）
- 建议至少30个观测点以获得可靠结果
- 数据应等间隔采样（如日度、月度、季度）
- 不能包含缺失值
- 数据量越大，ACF/PACF分析越准确

应用示例:
- 股票价格序列
- GDP季度数据
- 月度销售额
- 日均气温数据"""
        )
    ]
) -> CallToolResult:
    """时间序列统计分析
    
    📊 功能说明：
    对时间序列数据进行全面的统计分析，包括平稳性检验和自相关分析。
    
    📈 分析内容：
    
    1️⃣ ADF单位根检验（Augmented Dickey-Fuller Test）：
       - 检验序列是否平稳
       - H₀: 存在单位根（序列非平稳）
       - p < 0.05：拒绝原假设，序列平稳
       - 平稳性是时间序列建模的基础
    
    2️⃣ 自相关函数（ACF）：
       - 衡量序列与其滞后值之间的相关性
       - 用于识别MA模型的阶数
       - 指数衰减→AR过程；q阶截尾→MA(q)过程
    
    3️⃣ 偏自相关函数（PACF）：
       - 剔除中间滞后项影响后的相关性
       - 用于识别AR模型的阶数
       - p阶截尾→AR(p)过程
    
    📊 输出指标：
    - ADF统计量：越负越可能平稳
    - ADF p值：<0.05表示序列平稳
    - 平稳性判断：基于5%显著性水平
    - ACF值：前20阶（或更少）的自相关系数
    - PACF值：前20阶（或更少）的偏自相关系数
    
    💡 使用场景：
    - ARIMA建模前的平稳性检验
    - 识别合适的时间序列模型（AR、MA、ARMA）
    - 检测季节性和趋势
    - 评估序列的记忆性和持续性
    
    ⚠️ 注意事项：
    - 非平稳序列需要差分或变换后才能建模
    - ACF和PACF应结合使用以识别模型类型
    - 数据点太少（<30）可能导致不可靠的结果
    - 强烈的季节性可能影响ACF/PACF的解读
    - 建议同时观察ACF/PACF图形以获得更好的直观理解
    
    📖 结果解读：
    - ADF p值 < 0.05 + ACF快速衰减 → 平稳序列，可直接建模
    - ADF p值 >= 0.05 → 非平稳序列，需要差分处理
    - PACF在p阶截尾 → 考虑AR(p)模型
    - ACF在q阶截尾 → 考虑MA(q)模型
    - ACF和PACF都衰减 → 考虑ARMA模型

    Args:
        data: 时间序列数据（按时间顺序）
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始时间序列分析，数据点数量: {len(data)}")

    try:
        # 数据验证
        if not data:
            raise ValueError("时间序列数据不能为空")
        if len(data) < 5:
            raise ValueError("时间序列数据至少需要5个观测点")
        
        # ADF单位根检验
        adf_result = stattools.adfuller(data)

        # 自相关和偏自相关函数
        # 修复：安全计算nlags，避免PACF计算失败
        max_nlags = min(20, len(data) - 1, len(data) // 2)
        if max_nlags < 1:
            max_nlags = 1  # 确保至少计算1阶
        
        # 修复：使用try-except处理ACF/PACF计算可能失败的情况
        try:
            acf_values = stattools.acf(data, nlags=max_nlags)
            pacf_values = stattools.pacf(data, nlags=max_nlags)
        except Exception as acf_error:
            await ctx.warning(f"ACF/PACF计算遇到问题: {str(acf_error)}，使用简化计算")
            # 使用更简单的计算方法
            acf_values = np.zeros(max_nlags + 1)
            pacf_values = np.zeros(max_nlags + 1)
            acf_values[0] = 1.0  # 0阶自相关总是1
            pacf_values[0] = 1.0  # 0阶偏自相关总是1

        # 转换numpy类型为Python原生类型
        result = TimeSeriesStatsResult(
            adf_statistic=float(adf_result[0]),
            adf_pvalue=float(adf_result[1]),
            stationary=bool(adf_result[1] < 0.05),
            acf=[float(x) for x in acf_values.tolist()],
            pacf=[float(x) for x in pacf_values.tolist()]
        )

        await ctx.info("时间序列分析完成")

        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"时间序列分析结果：\n"
                         f"ADF检验统计量 = {result.adf_statistic:.4f}\n"
                         f"ADF检验p值 = {result.adf_pvalue:.4f}\n"
                         f"{'平稳' if result.stationary else '非平稳'}序列\n"
                         f"ACF前5阶: {result.acf[:5]}\n"
                         f"PACF前5阶: {result.pacf[:5]}"
                )
            ],
            structuredContent=result.model_dump()
        )

    except Exception as e:
        await ctx.error(f"时间序列分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def correlation_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量数据字典
            
示例格式：
{
    "销售额": [12000, 13500, 11800, 14200],
    "广告支出": [800, 900, 750, 1000],
    "价格": [99, 95, 102, 98],
    "竞争对手数量": [3, 3, 4, 3]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 30
- 数值不能包含缺失值

应用：
- 探索变量间的关联关系
- 识别潜在的多重共线性
- 为回归分析筛选变量"""
        )
    ],
    method: Annotated[
        str,
        Field(
            default="pearson",
            description="""相关系数计算方法

可选值：
- "pearson": 皮尔逊相关系数（默认）
  * 衡量线性相关关系
  * 取值范围：-1到1
  * 要求:数据近似正态分布
  * 对异常值敏感
  
- "spearman": 斯皮尔曼秩相关系数
  * 衡量单调相关关系（不要求线性）
  * 基于数据的秩次
  * 对异常值不敏感
  * 适用于非正态分布
  
- "kendall": 肯德尔τ相关系数
  * 衡量一致性程度
  * 更稳健但计算较慢
  * 适用于小样本和有序数据

选择建议：
- 数据正态分布 + 关注线性关系 → pearson
- 数据有异常值或非正态 → spearman
- 有序分类数据 → kendall"""
        )
    ] = "pearson"
) -> CallToolResult:
    """变量间相关性分析
    
    📊 功能说明：
    计算多个变量之间的相关系数矩阵，揭示变量间的关联关系强度和方向。
    
    📈 相关系数解读：
    - 相关系数范围：-1 到 +1
    - |r| = 0.0-0.3：弱相关或无相关
    - |r| = 0.3-0.7：中等程度相关
    - |r| = 0.7-1.0：强相关
    - r > 0：正相关（同向变化）
    - r < 0：负相关（反向变化）
    - r = 0：无线性相关
    
    💡 使用场景：
    - 探索性数据分析（EDA）
    - 回归分析前的变量筛选
    - 识别多重共线性问题
    - 构建投资组合（寻找低相关资产）
    - 因子分析和主成分分析的前置步骤
    
    ⚠️ 注意事项：
    - 相关≠因果：高相关不代表因果关系
    - 皮尔逊相关仅衡量线性关系，可能错过非线性关系
    - 异常值会显著影响皮尔逊相关系数
    - 回归分析中，自变量间相关系数>0.8可能导致多重共线性
    - 小样本(<30)的相关系数可能不稳定
    
    📖 实际应用示例:
    - 营销分析：广告支出与销售额的相关性
    - 金融分析：不同股票收益率之间的相关性
    - 经济研究：GDP增长与失业率的关系
    - 多重共线性检测：回归模型中自变量间的相关性

    Args:
        data: 变量数据字典
        method: 相关系数类型（pearson/spearman/kendall）
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始相关性分析: {method}")

    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("至少需要2个变量进行相关性分析")
        
        df = pd.DataFrame(data)
        correlation_matrix = df.corr(method=method)

        await ctx.info("相关性分析完成")

        # 修复：返回正确的CallToolResult类型
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"{method.title()}相关系数矩阵：\n{correlation_matrix.round(4).to_string()}"
                )
            ]
        )

    except Exception as e:
        await ctx.error(f"相关性分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


def create_mcp_server() -> FastMCP:
    """创建并返回MCP服务器实例"""
    return mcp


# 面板数据分析工具
# 高级时间序列分析工具
from .tools.time_series import (
    VARModelResult,
    VECMModelResult,
    GARCHModelResult,
    StateSpaceModelResult,
    var_model,
    vecm_model,
    garch_model,
    state_space_model,
    forecast_var,
    impulse_response_analysis,
    variance_decomposition
)


class VARModelArguments(BaseModel):
    """VAR模型参数"""
    data: Dict[str, List[float]] = Field(description="多变量时间序列数据")
    max_lags: int = Field(default=5, description="最大滞后阶数")
    ic: str = Field(default="aic", description="信息准则")


class VECMModelArguments(BaseModel):
    """VECM模型参数"""
    data: Dict[str, List[float]] = Field(description="多变量时间序列数据")
    coint_rank: int = Field(default=1, description="协整秩")
    deterministic: str = Field(default="co", description="确定性项")
    max_lags: int = Field(default=5, description="最大滞后阶数")


class GARCHModelArguments(BaseModel):
    """GARCH模型参数"""
    data: List[float] = Field(description="时间序列数据")
    order: Tuple[int, int] = Field(default=(1, 1), description="GARCH阶数")
    dist: str = Field(default="normal", description="误差分布")


class StateSpaceModelArguments(BaseModel):
    """状态空间模型参数"""
    data: List[float] = Field(description="时间序列数据")
    state_dim: int = Field(default=1, description="状态维度")
    observation_dim: int = Field(default=1, description="观测维度")
    trend: bool = Field(default=True, description="是否包含趋势项")
    seasonal: bool = Field(default=False, description="是否包含季节项")
    period: int = Field(default=12, description="季节周期")


class VARForecastArguments(BaseModel):
    """VAR预测参数"""
    data: Dict[str, List[float]] = Field(description="多变量时间序列数据")
    steps: int = Field(default=10, description="预测步数")
    max_lags: int = Field(default=5, description="最大滞后阶数")


class ImpulseResponseArguments(BaseModel):
    """脉冲响应分析参数"""
    data: Dict[str, List[float]] = Field(description="多变量时间序列数据")
    periods: int = Field(default=10, description="响应期数")
    max_lags: int = Field(default=5, description="最大滞后阶数")


class VarianceDecompositionArguments(BaseModel):
    """方差分解参数"""
    data: Dict[str, List[float]] = Field(description="多变量时间序列数据")
    periods: int = Field(default=10, description="分解期数")
    max_lags: int = Field(default=5, description="最大滞后阶数")
from .tools.panel_data import (
    FixedEffectsResult,
    RandomEffectsResult,
    HausmanTestResult,
    PanelUnitRootResult,
    fixed_effects_model,
    random_effects_model,
    hausman_test,
    panel_unit_root_test,
    compare_panel_models
)


class FixedEffectsArguments(BaseModel):
    """固定效应模型参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    entity_ids: List[str] = Field(description="个体标识符")
    time_periods: List[str] = Field(description="时间标识符")
    feature_names: Optional[List[str]] = Field(default=None, description="自变量名称")
    entity_effects: bool = Field(default=True, description="是否包含个体效应")
    time_effects: bool = Field(default=False, description="是否包含时间效应")


class RandomEffectsArguments(BaseModel):
    """随机效应模型参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    entity_ids: List[str] = Field(description="个体标识符")
    time_periods: List[str] = Field(description="时间标识符")
    feature_names: Optional[List[str]] = Field(default=None, description="自变量名称")
    entity_effects: bool = Field(default=True, description="是否包含个体效应")
    time_effects: bool = Field(default=False, description="是否包含时间效应")


class HausmanTestArguments(BaseModel):
    """Hausman检验参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    entity_ids: List[str] = Field(description="个体标识符")
    time_periods: List[str] = Field(description="时间标识符")
    feature_names: Optional[List[str]] = Field(default=None, description="自变量名称")


class PanelUnitRootArguments(BaseModel):
    """面板单位根检验参数"""
    data: List[float] = Field(description="面板数据序列")
    entity_ids: List[str] = Field(description="个体标识符")
    time_periods: List[str] = Field(description="时间标识符")
    test_type: str = Field(default="levinlin", description="检验类型")


@mcp.tool()
async def panel_fixed_effects(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220, 240, 260]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（5个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97],   # 第4个观测的自变量值
    [9, 92]      # 第5个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    entity_ids: Annotated[
        List[str],
        Field(
            description="""个体标识符列表
            
示例:["公司A", "公司A", "公司A", "公司B", "公司B", "公司B"]

要求:
- 长度必须与观测数量一致
- 建议使用有意义的标识符
- 每个个体应有多个时间观测"""
        )
    ],
    time_periods: Annotated[
        List[str],
        Field(
            description="""时间标识符列表
            
示例:["2020Q1", "2020Q2", "2020Q3", "2020Q1", "2020Q2", "2020Q3"]

要求:
- 长度必须与观测数量一致
- 建议使用标准时间格式
- 每个时间点可以有多个个体观测"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""自变量名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    entity_effects: Annotated[
        bool,
        Field(
            default=True,
            description="""是否包含个体效应
            
说明：
- True：包含个体固定效应（默认）
- False：不包含个体固定效应
- 通常建议包含个体效应以控制个体间差异"""
        )
    ] = True,
    time_effects: Annotated[
        bool,
        Field(
            default=False,
            description="""是否包含时间效应
            
说明：
- True：包含时间固定效应
- False：不包含时间固定效应（默认）
- 如果存在时间趋势，建议包含时间效应"""
        )
    ] = False
) -> CallToolResult:
    """固定效应模型分析
    
    📊 功能说明：
    固定效应模型假设个体间存在不可观测的固定差异，通过组内变换消除这些固定效应。
    适用于个体特征不随时间变化的情况。
    
    📈 模型形式：
    y_it = α_i + βX_it + ε_it
    
    💡 使用场景：
    - 研究个体内部随时间变化的影响
    - 控制个体固定特征的影响
    - 面板数据中个体间存在系统性差异
    
    ⚠️ 注意事项：
    - 无法估计不随时间变化的变量的系数
    - 需要较大的时间维度以获得可靠估计
    - 对个体异质性敏感

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        entity_ids: 个体标识符
        time_periods: 时间标识符
        feature_names: 自变量名称
        entity_effects: 是否包含个体效应
        time_effects: 是否包含时间效应
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始固定效应模型分析，样本大小: {len(y_data)}，个体数量: {len(set(entity_ids))}")
    
    try:
        # 数据验证
        if not y_data:
            raise ValueError("因变量数据不能为空")
        if not x_data:
            raise ValueError("自变量数据不能为空")
        if len(y_data) != len(x_data):
            raise ValueError(f"因变量和自变量的观测数量不一致: y_data={len(y_data)}, x_data={len(x_data)}")
        if len(y_data) != len(entity_ids):
            raise ValueError(f"因变量和个体标识符数量不一致: y_data={len(y_data)}, entity_ids={len(entity_ids)}")
        if len(y_data) != len(time_periods):
            raise ValueError(f"因变量和时间标识符数量不一致: y_data={len(y_data)}, time_periods={len(time_periods)}")
        
        # 执行固定效应模型分析
        result = fixed_effects_model(
            y_data, x_data, entity_ids, time_periods, feature_names, 
            entity_effects, time_effects
        )
        
        await ctx.info("固定效应模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"固定效应模型分析结果：\n"
                         f"R² = {result.rsquared:.4f}\n"
                         f"调整R² = {result.rsquared_adj:.4f}\n"
                         f"F统计量 = {result.f_statistic:.4f} (p = {result.f_pvalue:.4f})\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}\n"
                         f"组内R² = {result.within_rsquared:.4f}\n"
                         f"观测数量 = {result.n_obs}\n"
                         f"个体效应: {'是' if result.entity_effects else '否'}, "
                         f"时间效应: {'是' if result.time_effects else '否'}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"固定效应模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def panel_random_effects(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220, 240, 260]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（5个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97],   # 第4个观测的自变量值
    [9, 92]      # 第5个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    entity_ids: Annotated[
        List[str],
        Field(
            description="""个体标识符列表
            
示例:["公司A", "公司A", "公司A", "公司B", "公司B", "公司B"]

要求:
- 长度必须与观测数量一致
- 建议使用有意义的标识符
- 每个个体应有多个时间观测"""
        )
    ],
    time_periods: Annotated[
        List[str],
        Field(
            description="""时间标识符列表
            
示例:["2020Q1", "2020Q2", "2020Q3", "2020Q1", "2020Q2", "2020Q3"]

要求:
- 长度必须与观测数量一致
- 建议使用标准时间格式
- 每个时间点可以有多个个体观测"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""自变量名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    entity_effects: Annotated[
        bool,
        Field(
            default=True,
            description="""是否包含个体效应
            
说明：
- True：包含个体随机效应（默认）
- False：不包含个体随机效应
- 通常建议包含个体效应以控制个体间差异"""
        )
    ] = True,
    time_effects: Annotated[
        bool,
        Field(
            default=False,
            description="""是否包含时间效应
            
说明：
- True：包含时间随机效应
- False：不包含时间随机效应（默认）
- 如果存在时间趋势，建议包含时间效应"""
        )
    ] = False
) -> CallToolResult:
    """随机效应模型分析
    
    📊 功能说明：
    随机效应模型假设个体间差异是随机的，通过GLS估计同时利用组内和组间变异。
    适用于个体特征与解释变量不相关的情况。
    
    📈 模型形式：
    y_it = α + βX_it + μ_i + ε_it
    
    💡 使用场景：
    - 个体特征与解释变量不相关
    - 希望估计不随时间变化的变量的系数
    - 样本来自更大的总体
    
    ⚠️ 注意事项：
    - 需要满足个体效应与解释变量不相关的假设
    - 如果假设不成立，估计可能不一致
    - 比固定效应模型更有效率

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        entity_ids: 个体标识符
        time_periods: 时间标识符
        feature_names: 自变量名称
        entity_effects: 是否包含个体效应
        time_effects: 是否包含时间效应
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始随机效应模型分析，样本大小: {len(y_data)}，个体数量: {len(set(entity_ids))}")
    
    try:
        # 数据验证
        if not y_data:
            raise ValueError("因变量数据不能为空")
        if not x_data:
            raise ValueError("自变量数据不能为空")
        if len(y_data) != len(x_data):
            raise ValueError(f"因变量和自变量的观测数量不一致: y_data={len(y_data)}, x_data={len(x_data)}")
        if len(y_data) != len(entity_ids):
            raise ValueError(f"因变量和个体标识符数量不一致: y_data={len(y_data)}, entity_ids={len(entity_ids)}")
        if len(y_data) != len(time_periods):
            raise ValueError(f"因变量和时间标识符数量不一致: y_data={len(y_data)}, time_periods={len(time_periods)}")
        
        # 执行随机效应模型分析
        result = random_effects_model(
            y_data, x_data, entity_ids, time_periods, feature_names, 
            entity_effects, time_effects
        )
        
        await ctx.info("随机效应模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"随机效应模型分析结果：\n"
                         f"R² = {result.rsquared:.4f}\n"
                         f"调整R² = {result.rsquared_adj:.4f}\n"
                         f"F统计量 = {result.f_statistic:.4f} (p = {result.f_pvalue:.4f})\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}\n"
                         f"组间R² = {result.between_rsquared:.4f}\n"
                         f"观测数量 = {result.n_obs}\n"
                         f"个体效应: {'是' if result.entity_effects else '否'}, "
                         f"时间效应: {'是' if result.time_effects else '否'}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"随机效应模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def panel_hausman_test(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220, 240, 260]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（5个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97],   # 第4个观测的自变量值
    [9, 92]      # 第5个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    entity_ids: Annotated[
        List[str],
        Field(
            description="""个体标识符列表
            
示例:["公司A", "公司A", "公司A", "公司B", "公司B", "公司B"]

要求:
- 长度必须与观测数量一致
- 建议使用有意义的标识符
- 每个个体应有多个时间观测"""
        )
    ],
    time_periods: Annotated[
        List[str],
        Field(
            description="""时间标识符列表
            
示例:["2020Q1", "2020Q2", "2020Q3", "2020Q1", "2020Q2", "2020Q3"]

要求:
- 长度必须与观测数量一致
- 建议使用标准时间格式
- 每个时间点可以有多个个体观测"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""自变量名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None
) -> CallToolResult:
    """Hausman检验
    
    📊 功能说明：
    Hausman检验用于比较固定效应模型和随机效应模型，判断个体效应是否与解释变量相关。
    原假设：随机效应模型是一致的（个体效应与解释变量不相关）
    备择假设：固定效应模型是一致的
    
    💡 使用场景：
    - 在固定效应和随机效应模型之间选择
    - 检验个体效应是否与解释变量相关
    - 验证随机效应模型的假设
    
    ⚠️ 注意事项：
    - p值 < 0.05：拒绝原假设，选择固定效应模型
    - p值 >= 0.05：不能拒绝原假设，选择随机效应模型
    - 检验统计量服从卡方分布

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        entity_ids: 个体标识符
        time_periods: 时间标识符
        feature_names: 自变量名称
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始Hausman检验，样本大小: {len(y_data)}，个体数量: {len(set(entity_ids))}")
    
    try:
        # 数据验证
        if not y_data:
            raise ValueError("因变量数据不能为空")
        if not x_data:
            raise ValueError("自变量数据不能为空")
        if len(y_data) != len(x_data):
            raise ValueError(f"因变量和自变量的观测数量不一致: y_data={len(y_data)}, x_data={len(x_data)}")
        if len(y_data) != len(entity_ids):
            raise ValueError(f"因变量和个体标识符数量不一致: y_data={len(y_data)}, entity_ids={len(entity_ids)}")
        if len(y_data) != len(time_periods):
            raise ValueError(f"因变量和时间标识符数量不一致: y_data={len(y_data)}, time_periods={len(time_periods)}")
        
        # 执行Hausman检验
        result = hausman_test(y_data, x_data, entity_ids, time_periods, feature_names)
        
        await ctx.info("Hausman检验完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"Hausman检验结果：\n"
                         f"检验统计量 = {result.statistic:.4f}\n"
                         f"p值 = {result.p_value:.4f}\n"
                         f"{'显著' if result.significant else '不显著'} (5%水平)\n"
                         f"建议：{result.recommendation}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"Hausman检验出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def panel_unit_root_test(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        List[float],
        Field(
            description="""面板数据序列
            
示例:[100, 120, 150, 130, 180, 200, 190, 220, 240, 260]

要求:
- 必须为数值列表
- 长度必须与个体和时间标识符数量一致
- 不能包含缺失值(NaN)
- 建议每个个体至少有5个时间观测"""
        )
    ],
    entity_ids: Annotated[
        List[str],
        Field(
            description="""个体标识符列表
            
示例:["公司A", "公司A", "公司A", "公司B", "公司B", "公司B"]

要求:
- 长度必须与数据序列长度一致
- 建议使用有意义的标识符
- 每个个体应有多个时间观测"""
        )
    ],
    time_periods: Annotated[
        List[str],
        Field(
            description="""时间标识符列表
            
示例:["2020Q1", "2020Q2", "2020Q3", "2020Q1", "2020Q2", "2020Q3"]

要求:
- 长度必须与数据序列长度一致
- 建议使用标准时间格式
- 每个时间点可以有多个个体观测"""
        )
    ],
    test_type: Annotated[
        str,
        Field(
            default="levinlin",
            description="""面板单位根检验类型
            
可选值：
- "levinlin": Levin-Lin-Chu检验（默认）
  * 假设所有个体有相同的自回归系数
  * 适用于平衡面板数据
  
- "ips": Im-Pesaran-Shin检验
  * 允许个体间有不同的自回归系数
  * 适用于非平衡面板数据
  
- "fisher": Fisher组合检验
  * 基于个体ADF检验的组合
  * 适用于各种面板数据类型

选择建议：
- 平衡面板 + 同质系数 → levinlin
- 非平衡面板 + 异质系数 → ips
- 小样本或复杂情况 → fisher"""
        )
    ] = "levinlin"
) -> CallToolResult:
    """面板单位根检验
    
    📊 功能说明：
    检验面板数据是否存在单位根，判断序列是否平稳。
    常用的检验方法包括Levin-Lin-Chu检验、Im-Pesaran-Shin检验等。
    
    💡 使用场景：
    - 面板数据建模前的平稳性检验
    - 判断是否需要差分处理
    - 验证面板数据的协整关系
    
    ⚠️ 注意事项：
    - p值 < 0.05：拒绝原假设，序列平稳
    - p值 >= 0.05：不能拒绝原假设，序列非平稳
    - 不同检验方法适用于不同的数据特征

    Args:
        data: 面板数据序列
        entity_ids: 个体标识符
        time_periods: 时间标识符
        test_type: 检验类型
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始面板单位根检验: {test_type}，样本大小: {len(data)}，个体数量: {len(set(entity_ids))}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("面板数据不能为空")
        if len(data) != len(entity_ids):
            raise ValueError(f"数据和个体标识符数量不一致: data={len(data)}, entity_ids={len(entity_ids)}")
        if len(data) != len(time_periods):
            raise ValueError(f"数据和时间标识符数量不一致: data={len(data)}, time_periods={len(time_periods)}")
        
        # 执行面板单位根检验
        result = panel_unit_root_test(data, entity_ids, time_periods, test_type)
        
        await ctx.info("面板单位根检验完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"面板单位根检验结果 ({result.test_type})：\n"
                         f"检验统计量 = {result.statistic:.4f}\n"
                         f"p值 = {result.p_value:.4f}\n"
                         f"{'平稳' if result.stationary else '非平稳'}序列\n"
                         f"建议：{'可直接建模' if result.stationary else '需要差分处理'}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"面板单位根检验出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )

@mcp.tool()
async def var_model_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量时间序列数据
             
示例格式：
{
    "GDP增长率": [3.2, 2.8, 3.5, 2.9, 3.1, 2.7, 3.3, 3.0],
    "通货膨胀率": [2.1, 2.3, 1.9, 2.4, 2.2, 2.5, 2.0, 2.3],
    "失业率": [4.5, 4.2, 4.0, 4.3, 4.1, 4.4, 3.9, 4.2]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 30
- 数据应平稳或经过差分处理"""
        )
    ],
    max_lags: Annotated[
        int,
        Field(
            default=5,
            description="""最大滞后阶数
             
说明：
- 用于自动选择最优滞后阶数
- 建议值：3-8
- 样本量越大，可选择的滞后阶数越多"""
        )
    ] = 5,
    ic: Annotated[
        str,
        Field(
            default="aic",
            description="""信息准则
             
可选值：
- "aic": Akaike信息准则（默认）
- "bic": Bayesian信息准则
- "hqic": Hannan-Quinn信息准则

选择建议：
- 小样本 → AIC
- 大样本 → BIC
- 中等样本 → HQIC"""
        )
    ] = "aic"
) -> CallToolResult:
    """VAR模型分析
     
    📊 功能说明：
    向量自回归模型用于分析多个时间序列变量之间的动态关系。
    每个变量的当前值都依赖于所有变量的滞后值。
    
    📈 模型形式：
    Y_t = A_1 Y_{t-1} + A_2 Y_{t-2} + ... + A_p Y_{t-p} + ε_t
    
    💡 使用场景：
    - 宏观经济变量间的相互影响分析
    - 金融市场联动性研究
    - 脉冲响应函数和方差分解
    - 格兰杰因果关系检验
    
    ⚠️ 注意事项：
    - 所有变量都应该是平稳的
    - 滞后阶数选择很重要
    - 变量数量不宜过多（避免维度灾难）
    - 样本量应足够大

    Args:
        data: 多变量时间序列数据
        max_lags: 最大滞后阶数
        ic: 信息准则
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始VAR模型分析，变量数量: {len(data)}，最大滞后阶数: {max_lags}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("VAR模型至少需要2个变量")
        
        # 执行VAR模型分析
        result = var_model(data, max_lags=max_lags, ic=ic)
        
        await ctx.info("VAR模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"VAR模型分析结果：\n"
                         f"最优滞后阶数: {result.order}\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}, HQIC = {result.hqic:.2f}\n"
                         f"变量数量: {len(data)}\n"
                         f"格兰杰因果关系检验完成"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"VAR模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def vecm_model_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量时间序列数据
             
示例格式：
{
    "GDP": [100, 102, 105, 103, 108, 110, 109, 112],
    "消费": [80, 82, 85, 83, 88, 90, 89, 92],
    "投资": [20, 21, 22, 21, 23, 24, 23, 25]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 50
- 变量应为一阶单整I(1)"""
        )
    ],
    coint_rank: Annotated[
        int,
        Field(
            default=1,
            description="""协整秩
             
说明：
- 协整向量的数量
- 通常为变量数量-1
- 需要根据协整检验确定"""
        )
    ] = 1,
    deterministic: Annotated[
        str,
        Field(
            default="co",
            description="""确定性项
             
可选值：
- "co": 常数项（默认）
- "ci": 常数项和趋势项
- "lo": 线性趋势
- "li": 线性趋势和二次趋势"""
        )
    ] = "co",
    max_lags: Annotated[
        int,
        Field(
            default=5,
            description="""最大滞后阶数
             
说明：
- 用于误差修正模型
- 建议值：2-6
- 根据样本量调整"""
        )
    ] = 5
) -> CallToolResult:
    """VECM模型分析
     
    📊 功能说明：
    用于分析非平稳时间序列之间的长期均衡关系和短期动态调整。
    适用于存在协整关系的多变量系统。
    
    📈 模型形式：
    ΔY_t = αβ' Y_{t-1} + Γ_1 ΔY_{t-1} + ... + Γ_{p-1} ΔY_{t-p+1} + ε_t
    
    💡 使用场景：
    - 存在长期均衡关系的经济变量分析
    - 误差修正机制研究
    - 协整关系检验
    - 短期动态调整分析
    
    ⚠️ 注意事项：
    - 所有变量应该是一阶单整的I(1)
    - 协整秩的选择很重要
    - 需要较大的样本量
    - 对模型设定敏感

    Args:
        data: 多变量时间序列数据
        coint_rank: 协整秩
        deterministic: 确定性项
        max_lags: 最大滞后阶数
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始VECM模型分析，变量数量: {len(data)}，协整秩: {coint_rank}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("VECM模型至少需要2个变量")
        
        # 执行VECM模型分析
        result = vecm_model(data, coint_rank=coint_rank, deterministic=deterministic, max_lags=max_lags)
        
        await ctx.info("VECM模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"VECM模型分析结果：\n"
                         f"协整秩: {result.coint_rank}\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}, HQIC = {result.hqic:.2f}\n"
                         f"协整关系数量: {len(result.cointegration_relations)}\n"
                         f"调整速度计算完成"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"VECM模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def garch_model_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        List[float],
        Field(
            description="""时间序列数据（通常是收益率）
             
示例:[0.02, -0.015, 0.018, -0.008, 0.012, -0.005, 0.025, -0.01]

要求:
- 建议使用收益率数据
- 不能包含缺失值
- 建议样本量 >= 50
- 数据应具有波动率聚类特征"""
        )
    ],
    order: Annotated[
        Tuple[int, int],
        Field(
            default=(1, 1),
            description="""GARCH阶数
             
说明：
- 第一个数：ARCH项阶数
- 第二个数：GARCH项阶数
- 常用阶数：(1,1)"""
        )
    ] = (1, 1),
    dist: Annotated[
        str,
        Field(
            default="normal",
            description="""误差分布
             
可选值：
- "normal": 正态分布（默认）
- "t": t分布
- "skewt": 偏t分布

选择建议：
- 一般情况 → normal
- 厚尾数据 → t
- 非对称数据 → skewt"""
        )
    ] = "normal"
) -> CallToolResult:
    """GARCH模型分析
     
    📊 功能说明：
    用于建模金融时间序列的波动率聚类现象，捕捉条件方差的时变特征。
    
    📈 模型形式：
    r_t = μ + ε_t, ε_t = σ_t z_t
    σ_t² = ω + α ε_{t-1}² + β σ_{t-1}²
    
    💡 使用场景：
    - 金融资产波动率建模
    - 风险管理和VaR计算
    - 期权定价
    - 波动率预测
    
    ⚠️ 注意事项：
    - 数据应具有波动率聚类特征
    - 需要较大的样本量
    - 对分布假设敏感
    - 高阶GARCH可能不稳定

    Args:
        data: 时间序列数据
        order: GARCH阶数
        dist: 误差分布
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始GARCH模型分析，样本大小: {len(data)}，阶数: {order}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 50:
            raise ValueError("GARCH模型至少需要50个观测点")
        
        # 执行GARCH模型分析
        result = garch_model(data, order=order, dist=dist)
        
        await ctx.info("GARCH模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"GARCH模型分析结果：\n"
                         f"阶数: {result.order}\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}\n"
                         f"持久性: {result.persistence:.4f}\n"
                         f"无条件方差: {result.unconditional_variance:.6f}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"GARCH模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def state_space_model_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        List[float],
        Field(
            description="""时间序列数据
             
示例:[100, 102, 105, 103, 108, 110, 109, 112, 115, 118]

要求:
- 不能包含缺失值
- 建议样本量 >= 20
- 数据应具有趋势或季节特征"""
        )
    ],
    state_dim: Annotated[
        int,
        Field(
            default=1,
            description="""状态维度
             
说明：
- 不可观测状态变量的维度
- 通常为1-3
- 根据模型复杂度选择"""
        )
    ] = 1,
    observation_dim: Annotated[
        int,
        Field(
            default=1,
            description="""观测维度
             
说明：
- 观测变量的维度
- 通常为1
- 多变量时为变量数量"""
        )
    ] = 1,
    trend: Annotated[
        bool,
        Field(
            default=True,
            description="""是否包含趋势项
             
说明：
- True：包含趋势项（默认）
- False：不包含趋势项
- 适用于有趋势的数据"""
        )
    ] = True,
    seasonal: Annotated[
        bool,
        Field(
            default=False,
            description="""是否包含季节项
             
说明：
- True：包含季节项
- False：不包含季节项（默认）
- 适用于有季节性的数据"""
        )
    ] = False,
    period: Annotated[
        int,
        Field(
            default=12,
            description="""季节周期
             
说明：
- 季节周期的长度
- 月度数据：12
- 季度数据：4
- 日度数据：7"""
        )
    ] = 12
) -> CallToolResult:
    """状态空间模型分析
     
    📊 功能说明：
    使用状态空间表示和卡尔曼滤波进行时间序列建模，可以处理不可观测的状态变量。
    
    📈 模型形式：
    状态方程: α_t = T α_{t-1} + R η_t
    观测方程: y_t = Z α_t + ε_t
    
    💡 使用场景：
    - 不可观测状态变量的估计
    - 结构时间序列建模
    - 实时滤波和平滑
    - 缺失数据处理
    
    ⚠️ 注意事项：
    - 模型设定复杂
    - 需要先验知识
    - 计算量较大
    - 对初始值敏感

    Args:
        data: 时间序列数据
        state_dim: 状态维度
        observation_dim: 观测维度
        trend: 是否包含趋势项
        seasonal: 是否包含季节项
        period: 季节周期
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始状态空间模型分析，样本大小: {len(data)}，状态维度: {state_dim}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 20:
            raise ValueError("状态空间模型至少需要20个观测点")
        
        # 执行状态空间模型分析
        result = state_space_model(
            data, 
            state_dim=state_dim, 
            observation_dim=observation_dim,
            trend=trend,
            seasonal=seasonal,
            period=period
        )
        
        await ctx.info("状态空间模型分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"状态空间模型分析结果：\n"
                         f"状态变量: {result.state_names}\n"
                         f"对数似然: {result.log_likelihood:.2f}\n"
                         f"AIC = {result.aic:.2f}, BIC = {result.bic:.2f}\n"
                         f"滤波和平滑完成"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"状态空间模型分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def var_forecast(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量时间序列数据
             
示例格式：
{
    "GDP增长率": [3.2, 2.8, 3.5, 2.9, 3.1, 2.7, 3.3, 3.0],
    "通货膨胀率": [2.1, 2.3, 1.9, 2.4, 2.2, 2.5, 2.0, 2.3]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 30
- 数据应平稳或经过差分处理"""
        )
    ],
    steps: Annotated[
        int,
        Field(
            default=10,
            description="""预测步数
             
说明：
- 向前预测的期数
- 建议值：5-20
- 预测期数越长，不确定性越大"""
        )
    ] = 10,
    max_lags: Annotated[
        int,
        Field(
            default=5,
            description="""最大滞后阶数
             
说明：
- 用于VAR模型拟合
- 建议值：3-8
- 根据样本量调整"""
        )
    ] = 5
) -> CallToolResult:
    """VAR模型预测
     
    📊 功能说明：
    基于VAR模型进行多变量时间序列预测。
    
    💡 使用场景：
    - 宏观经济变量联合预测
    - 金融市场联动预测
    - 政策模拟和情景分析
    
    ⚠️ 注意事项：
    - 预测精度随步数增加而下降
    - 需要平稳数据
    - 预测结果包含不确定性

    Args:

        data: 多变量时间序列数据
        steps: 预测步数
        max_lags: 最大滞后阶数
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始VAR模型预测，变量数量: {len(data)}，预测步数: {steps}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("VAR预测至少需要2个变量")
        
        # 执行VAR预测
        result = forecast_var(data, steps=steps, max_lags=max_lags)
        
        await ctx.info("VAR模型预测完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"VAR模型预测结果：\n"
                         f"预测步数: {steps}\n"
                         f"模型滞后阶数: {result['model_order']}\n"
                         f"AIC = {result.get('model_aic', 0):.2f}, BIC = {result.get('model_bic', 0):.2f}\n"
                         f"各变量预测值已生成"
                )
            ],
            structuredContent=result
        )
        
    except Exception as e:
        await ctx.error(f"VAR模型预测出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def impulse_response_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量时间序列数据
             
示例格式：
{
    "GDP增长率": [3.2, 2.8, 3.5, 2.9, 3.1, 2.7, 3.3, 3.0],
    "通货膨胀率": [2.1, 2.3, 1.9, 2.4, 2.2, 2.5, 2.0, 2.3],
    "利率": [2.5, 2.6, 2.4, 2.7, 2.5, 2.8, 2.3, 2.6]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 30
- 数据应平稳或经过差分处理"""
        )
    ],
    periods: Annotated[
        int,
        Field(
            default=10,
            description="""响应期数
             
说明：
- 脉冲响应的追踪期数
- 建议值：5-20
- 期数越长，计算量越大"""
        )
    ] = 10,
    max_lags: Annotated[
        int,
        Field(
            default=5,
            description="""最大滞后阶数
             
说明：
- 用于VAR模型拟合
- 建议值：3-8
- 根据样本量调整"""
        )
    ] = 5
) -> CallToolResult:
    """脉冲响应分析
     
    📊 功能说明：
    分析一个变量的冲击对其他变量的动态影响。
    
    💡 使用场景：
    - 政策冲击效应分析
    - 变量间动态关系研究
    - 经济传导机制分析
    
    ⚠️ 注意事项：
    - 需要正交化处理
    - 结果对变量顺序敏感
    - 需要平稳数据

    Args:
        data: 多变量时间序列数据
        periods: 响应期数
        max_lags: 最大滞后阶数
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始脉冲响应分析，变量数量: {len(data)}，响应期数: {periods}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("脉冲响应分析至少需要2个变量")
        
        # 执行脉冲响应分析
        result = impulse_response_analysis(data, periods=periods, max_lags=max_lags)
        
        await ctx.info("脉冲响应分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"脉冲响应分析结果：\n"
                         f"响应期数: {periods}\n"
                         f"变量数量: {len(data)}\n"
                         f"所有冲击-响应组合的脉冲响应函数已计算"
                )
            ],
            structuredContent=result
        )
        
    except Exception as e:
        await ctx.error(f"脉冲响应分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def variance_decomposition_analysis(
    ctx: Context[ServerSession, AppContext],
    data: Annotated[
        Dict[str, List[float]],
        Field(
            description="""多变量时间序列数据
             
示例格式：
{
    "GDP增长率": [3.2, 2.8, 3.5, 2.9, 3.1, 2.7, 3.3, 3.0],
    "通货膨胀率": [2.1, 2.3, 1.9, 2.4, 2.2, 2.5, 2.0, 2.3],
    "利率": [2.5, 2.6, 2.4, 2.7, 2.5, 2.8, 2.3, 2.6]
}

要求:
- 至少包含2个变量
- 所有变量的数据点数量必须相同
- 建议样本量 >= 30
- 数据应平稳或经过差分处理"""
        )
    ],
    periods: Annotated[
        int,
        Field(
            default=10,
            description="""分解期数
             
说明：
- 方差分解的期数
- 建议值：5-20
- 期数越长，结果越稳定"""
        )
    ] = 10,
    max_lags: Annotated[
        int,
        Field(
            default=5,
            description="""最大滞后阶数
             
说明：
- 用于VAR模型拟合
- 建议值：3-8
- 根据样本量调整"""
        )
    ] = 5
) -> CallToolResult:
    """方差分解分析
     
    📊 功能说明：
    将每个变量的预测误差方差分解为各冲击源的贡献。
    
    💡 使用场景：
    - 变量重要性分析
    - 冲击来源识别
    - 系统稳定性分析
    
    ⚠️ 注意事项：
    - 需要正交化处理
    - 结果对变量顺序敏感
    - 需要平稳数据

    Args:
        data: 多变量时间序列数据
        periods: 分解期数
        max_lags: 最大滞后阶数
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始方差分解分析，变量数量: {len(data)}，分解期数: {periods}")
    
    try:
        # 数据验证
        if not data:
            raise ValueError("数据不能为空")
        if len(data) < 2:
            raise ValueError("方差分解分析至少需要2个变量")
        
        # 执行方差分解分析
        result = variance_decomposition(data, periods=periods, max_lags=max_lags)
        
        await ctx.info("方差分解分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"方差分解分析结果：\n"
                         f"分解期数: {periods}\n"
                         f"变量数量: {len(data)}\n"
                         f"各变量方差分解已完成"
                )
            ],
            structuredContent=result
        )
        
    except Exception as e:
        await ctx.error(f"方差分解分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )

# 机器学习工具导入
from .tools.machine_learning import (
    RandomForestResult,
    GradientBoostingResult,
    RegularizedRegressionResult,
    CrossValidationResult,
    FeatureImportanceResult,
    random_forest_regression,
    gradient_boosting_regression,
    lasso_regression,
    ridge_regression,
    cross_validation,
    feature_importance_analysis,
    compare_ml_models
)


class RandomForestArguments(BaseModel):
    """随机森林回归参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    feature_names: Optional[List[str]] = Field(default=None, description="特征名称")
    n_estimators: int = Field(default=100, description="树的数量")
    max_depth: Optional[int] = Field(default=None, description="最大深度")


class GradientBoostingArguments(BaseModel):
    """梯度提升树回归参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    feature_names: Optional[List[str]] = Field(default=None, description="特征名称")
    n_estimators: int = Field(default=100, description="树的数量")
    learning_rate: float = Field(default=0.1, description="学习率")
    max_depth: int = Field(default=3, description="最大深度")


class LassoRegressionArguments(BaseModel):
    """Lasso回归参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    feature_names: Optional[List[str]] = Field(default=None, description="特征名称")
    alpha: float = Field(default=1.0, description="正则化强度")


class RidgeRegressionArguments(BaseModel):
    """Ridge回归参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    feature_names: Optional[List[str]] = Field(default=None, description="特征名称")
    alpha: float = Field(default=1.0, description="正则化强度")


class CrossValidationArguments(BaseModel):
    """交叉验证参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    model_type: str = Field(default="random_forest", description="模型类型")
    cv_folds: int = Field(default=5, description="交叉验证折数")
    scoring: str = Field(default="r2", description="评分指标")


class FeatureImportanceArguments(BaseModel):
    """特征重要性分析参数"""
    y_data: List[float] = Field(description="因变量数据")
    x_data: List[List[float]] = Field(description="自变量数据")
    feature_names: Optional[List[str]] = Field(default=None, description="特征名称")
    method: str = Field(default="random_forest", description="分析方法")
    top_k: int = Field(default=5, description="最重要的特征数量")


@mcp.tool()
async def random_forest_regression_analysis(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""特征名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    n_estimators: Annotated[
        int,
        Field(
            default=100,
            description="""树的数量
            
说明：
- 随机森林中决策树的数量
- 默认值：100
- 建议范围：50-500
- 树越多，模型越稳定但计算成本越高"""
        )
    ] = 100,
    max_depth: Annotated[
        Optional[int],
        Field(
            default=None,
            description="""最大深度
            
说明：
- 决策树的最大深度
- None：不限制深度
- 建议值：3-20
- 深度越大，模型越复杂，可能过拟合"""
        )
    ] = None
) -> CallToolResult:
    """随机森林回归分析
    
    📊 功能说明：
    使用随机森林算法进行回归分析，适用于非线性关系和复杂交互效应。
    
    📈 算法特点：
    - 集成学习：多个决策树的组合
    - 抗过拟合：通过袋外样本和特征随机选择
    - 非线性建模：能够捕捉复杂的非线性关系
    - 特征重要性：提供特征重要性排序
    
    💡 使用场景：
    - 复杂非线性关系建模
    - 特征重要性分析
    - 高维数据回归
    - 稳健预测建模
    
    ⚠️ 注意事项：
    - 计算复杂度较高
    - 需要调整超参数（n_estimators, max_depth）
    - 对异常值相对稳健

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        feature_names: 特征名称
        n_estimators: 树的数量
        max_depth: 最大深度
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始随机森林回归分析，样本大小: {len(y_data)}，特征数量: {len(x_data[0]) if x_data else 0}")
    
    try:
        # 执行随机森林回归
        result = random_forest_regression(
            y_data, x_data, feature_names, n_estimators, max_depth
        )
        
        await ctx.info("随机森林回归分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"随机森林回归分析结果：\n"
                         f"R² = {result.r2_score:.4f}\n"
                         f"均方误差 = {result.mse:.4f}\n"
                         f"平均绝对误差 = {result.mae:.4f}\n"
                         f"树的数量 = {result.n_estimators}\n"
                         f"最大深度 = {result.max_depth if result.max_depth != -1 else '无限制'}\n"
                         f"袋外得分 = {result.oob_score:.4f if result.oob_score is not None else 'N/A'}\n\n"
                         f"特征重要性：\n" + "\n".join([
                             f"  {feature}: {importance:.4f}" 
                             for feature, importance in result.feature_importance.items()
                         ])
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"随机森林回归分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def gradient_boosting_regression_analysis(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""特征名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    n_estimators: Annotated[
        int,
        Field(
            default=100,
            description="""树的数量
            
说明：
- 梯度提升树中决策树的数量
- 默认值：100
- 建议范围：50-500
- 树越多，模型越精确但计算成本越高"""
        )
    ] = 100,
    learning_rate: Annotated[
        float,
        Field(
            default=0.1,
            description="""学习率
            
说明：
- 每棵树对最终预测的贡献程度
- 默认值：0.1
- 建议范围：0.01-0.3
- 学习率越小，需要更多的树"""
        )
    ] = 0.1,
    max_depth: Annotated[
        int,
        Field(
            default=3,
            description="""最大深度
            
说明：
- 决策树的最大深度
- 默认值：3
- 建议范围：2-8
- 深度越大，模型越复杂，可能过拟合"""
        )
    ] = 3
) -> CallToolResult:
    """梯度提升树回归分析
    
    📊 功能说明：
    使用梯度提升算法进行回归分析，通过逐步优化残差来提升模型性能。
    
    📈 算法特点：
    - 逐步优化：通过梯度下降逐步改进模型
    - 高精度：通常比随机森林有更好的预测精度
    - 正则化：通过学习率和树深度控制过拟合
    - 特征重要性：提供特征重要性排序
    
    💡 使用场景：
    - 高精度预测需求
    - 结构化数据建模
    - 竞赛和实际应用
    - 需要精细调优的场景
    
    ⚠️ 注意事项：
    - 对超参数敏感
    - 训练时间较长
    - 容易过拟合（需要仔细调参）

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        feature_names: 特征名称
        n_estimators: 树的数量
        learning_rate: 学习率
        max_depth: 最大深度
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始梯度提升树回归分析，样本大小: {len(y_data)}，特征数量: {len(x_data[0]) if x_data else 0}")
    
    try:
        # 执行梯度提升树回归
        result = gradient_boosting_regression(
            y_data, x_data, feature_names, n_estimators, learning_rate, max_depth
        )
        
        await ctx.info("梯度提升树回归分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"梯度提升树回归分析结果：\n"
                         f"R² = {result.r2_score:.4f}\n"
                         f"均方误差 = {result.mse:.4f}\n"
                         f"平均绝对误差 = {result.mae:.4f}\n"
                         f"树的数量 = {result.n_estimators}\n"
                         f"学习率 = {result.learning_rate}\n"
                         f"最大深度 = {result.max_depth}\n\n"
                         f"特征重要性：\n" + "\n".join([
                             f"  {feature}: {importance:.4f}" 
                             for feature, importance in result.feature_importance.items()
                         ])
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"梯度提升树回归分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def lasso_regression_analysis(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""特征名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    alpha: Annotated[
        float,
        Field(
            default=1.0,
            description="""正则化强度
            
说明：
- L1正则化的强度参数
- 默认值：1.0
- 建议范围：0.001-10
- alpha越大，正则化越强，更多系数变为0"""
        )
    ] = 1.0
) -> CallToolResult:
    """Lasso回归分析
    
    📊 功能说明：
    使用L1正则化的线性回归，能够进行特征选择和稀疏建模。
    
    📈 算法特点：
    - 特征选择：自动将不重要的特征系数压缩为0
    - 稀疏解：产生稀疏的系数向量
    - 可解释性：保留重要特征，去除冗余特征
    - 处理多重共线性：对高度相关的特征进行选择
    
    💡 使用场景：
    - 高维数据特征选择
    - 多重共线性问题
    - 稀疏建模需求
    - 可解释性要求高的场景
    
    ⚠️ 注意事项：
    - 对alpha参数敏感
    - 可能过度压缩重要特征
    - 需要数据标准化

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        feature_names: 特征名称
        alpha: 正则化强度
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始Lasso回归分析，样本大小: {len(y_data)}，特征数量: {len(x_data[0]) if x_data else 0}")
    
    try:
        # 执行Lasso回归
        result = lasso_regression(y_data, x_data, feature_names, alpha)
        
        await ctx.info("Lasso回归分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"Lasso回归分析结果：\n"
                         f"R² = {result.r2_score:.4f}\n"
                         f"均方误差 = {result.mse:.4f}\n"
                         f"平均绝对误差 = {result.mae:.4f}\n"
                         f"正则化强度 = {result.alpha}\n\n"
                         f"回归系数：\n" + "\n".join([
                             f"  {feature}: {coef:.4f}" 
                             for feature, coef in result.coefficients.items()
                         ])
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"Lasso回归分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def ridge_regression_analysis(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""特征名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    alpha: Annotated[
        float,
        Field(
            default=1.0,
            description="""正则化强度
            
说明：
- L2正则化的强度参数
- 默认值：1.0
- 建议范围：0.001-10
- alpha越大，正则化越强，系数收缩越明显"""
        )
    ] = 1.0
) -> CallToolResult:
    """Ridge回归分析
    
    📊 功能说明：
    使用L2正则化的线性回归，能够处理多重共线性问题。
    
    📈 算法特点：
    - 稳定性：对多重共线性稳健
    - 收缩系数：将所有系数向0收缩
    - 无特征选择：保留所有特征
    - 数值稳定性：改善矩阵条件数
    
    💡 使用场景：
    - 多重共线性问题
    - 需要稳定估计的场景
    - 所有特征都可能有贡献的情况
    - 小样本高维数据
    
    ⚠️ 注意事项：
    - 不进行特征选择
    - 对alpha参数敏感
    - 需要数据标准化

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        feature_names: 特征名称
        alpha: 正则化强度
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始Ridge回归分析，样本大小: {len(y_data)}，特征数量: {len(x_data[0]) if x_data else 0}")
    
    try:
        # 执行Ridge回归
        result = ridge_regression(y_data, x_data, feature_names, alpha)
        
        await ctx.info("Ridge回归分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"Ridge回归分析结果：\n"
                         f"R² = {result.r2_score:.4f}\n"
                         f"均方误差 = {result.mse:.4f}\n"
                         f"平均绝对误差 = {result.mae:.4f}\n"
                         f"正则化强度 = {result.alpha}\n\n"
                         f"回归系数：\n" + "\n".join([
                             f"  {feature}: {coef:.4f}" 
                             for feature, coef in result.coefficients.items()
                         ])
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"Ridge回归分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def cross_validation_analysis(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    model_type: Annotated[
        str,
        Field(
            default="random_forest",
            description="""模型类型
            
可选值：
- "random_forest": 随机森林
- "gradient_boosting": 梯度提升树
- "lasso": Lasso回归
- "ridge": Ridge回归

选择建议：
- 非线性关系 → random_forest, gradient_boosting
- 特征选择 → lasso
- 稳定性 → ridge"""
        )
    ] = "random_forest",
    cv_folds: Annotated[
        int,
        Field(
            default=5,
            description="""交叉验证折数
            
说明：
- 将数据分为多少份进行交叉验证
- 默认值：5
- 建议范围：3-10
- 折数越多，评估越稳定但计算成本越高"""
        )
    ] = 5,
    scoring: Annotated[
        str,
        Field(
            default="r2",
            description="""评分指标
            
可选值：
- "r2": R²得分
- "neg_mean_squared_error": 负均方误差
- "neg_mean_absolute_error": 负平均绝对误差

说明：
- 使用负值指标时，得分越高表示模型越好"""
        )
    ] = "r2"
) -> CallToolResult:
    """交叉验证分析
    
    📊 功能说明：
    通过交叉验证评估模型的泛化能力和稳定性。
    
    📈 验证方法：
    - K折交叉验证：将数据分为K份，轮流使用K-1份训练，1份测试
    - 稳定性评估：通过多次验证评估模型稳定性
    - 泛化能力：评估模型在未见数据上的表现
    
    💡 使用场景：
    - 模型选择和比较
    - 超参数调优
    - 评估模型稳定性
    - 防止过拟合
    
    ⚠️ 注意事项：
    - 计算成本较高
    - 需要足够的数据量
    - 折数选择影响结果稳定性

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        model_type: 模型类型
        cv_folds: 交叉验证折数
        scoring: 评分指标
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始交叉验证分析，模型类型: {model_type}，折数: {cv_folds}")
    
    try:
        # 执行交叉验证
        result = cross_validation(
            y_data, x_data, model_type, cv_folds, scoring
        )
        
        await ctx.info("交叉验证分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"交叉验证分析结果：\n"
                         f"模型类型 = {result.model_type}\n"
                         f"交叉验证折数 = {result.n_splits}\n"
                         f"平均得分 = {result.mean_score:.4f}\n"
                         f"标准差 = {result.std_score:.4f}\n"
                         f"各折得分 = {[f'{score:.4f}' for score in result.cv_scores]}"
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"交叉验证分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )


@mcp.tool()
async def feature_importance_analysis_tool(
    ctx: Context[ServerSession, AppContext],
    y_data: Annotated[
        List[float],
        Field(
            description="""因变量数据(被解释变量)
            
示例:[100, 120, 150, 130, 180, 200, 190, 220]

要求:
- 必须为数值列表
- 长度必须与自变量观测数量一致
- 不能包含缺失值(NaN)
- 建议样本量 >= 30"""
        )
    ],
    x_data: Annotated[
        List[List[float]],
        Field(
            description="""自变量数据（解释变量），二维列表格式
            
示例格式（4个观测，2个自变量）：
[
    [5, 100],    # 第1个观测的自变量值
    [6, 98],     # 第2个观测的自变量值
    [7.5, 95],   # 第3个观测的自变量值
    [6.5, 97]    # 第4个观测的自变量值
]

要求:
- 外层列表：每个元素代表一个观测
- 内层列表：该观测的所有自变量值
- 所有观测的自变量数量必须相同
- 观测数量必须与y_data长度一致"""
        )
    ],
    feature_names: Annotated[
        Optional[List[str]],
        Field(
            default=None,
            description="""特征名称列表（可选）
            
示例:["广告支出", "价格"]

说明：
- 如果不提供，将自动命名为 x1, x2, x3...
- 名称数量必须与自变量数量一致
- 建议使用有意义的名称以便解释结果"""
        )
    ] = None,
    method: Annotated[
        str,
        Field(
            default="random_forest",
            description="""分析方法
            
可选值：
- "random_forest": 基于随机森林
- "gradient_boosting": 基于梯度提升树

选择建议：
- 一般情况 → random_forest
- 高精度需求 → gradient_boosting"""
        )
    ] = "random_forest",
    top_k: Annotated[
        int,
        Field(
            default=5,
            description="""最重要的特征数量
            
说明：
- 返回重要性排名前k的特征
- 默认值：5
- 建议范围：3-10
- 根据实际需求调整"""
        )
    ] = 5
) -> CallToolResult:
    """特征重要性分析
    
    📊 功能说明：
    分析各个特征对预测目标的重要性，帮助理解数据中的关键因素。
    
    📈 分析方法：
    - 基于模型：使用机器学习模型计算特征重要性
    - 排序分析：按重要性对特征进行排序
    - 关键特征识别：识别最重要的top-k个特征
    
    💡 使用场景：
    - 特征选择和降维
    - 模型可解释性分析
    - 业务洞察提取
    - 数据理解增强
    
    ⚠️ 注意事项：
    - 不同方法可能给出不同的重要性排序
    - 重要性分数是相对的，不是绝对的
    - 需要结合业务知识解释结果

    Args:
        y_data: 因变量数据
        x_data: 自变量数据
        feature_names: 特征名称
        method: 分析方法
        top_k: 最重要的特征数量
        ctx: MCP上下文对象
    """
    await ctx.info(f"开始特征重要性分析，分析方法: {method}，top_k: {top_k}")
    
    try:
        # 执行特征重要性分析
        result = feature_importance_analysis(
            y_data, x_data, feature_names, method, top_k
        )
        
        await ctx.info("特征重要性分析完成")
        
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"特征重要性分析结果：\n"
                         f"分析方法 = {method}\n"
                         f"最重要的{top_k}个特征 = {result.top_features}\n\n"
                         f"特征重要性排序：\n" + "\n".join([
                             f"  {i+1}. {feature}: {importance:.4f}" 
                             for i, (feature, importance) in enumerate(result.sorted_features)
                         ])
                )
            ],
            structuredContent=result.model_dump()
        )
        
    except Exception as e:
        await ctx.error(f"特征重要性分析出错: {str(e)}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"错误: {str(e)}")],
            isError=True
        )