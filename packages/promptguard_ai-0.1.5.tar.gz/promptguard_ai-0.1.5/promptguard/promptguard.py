import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from flashtext import KeywordProcessor

from .data import rules
from .keyword_matcher import KeywordMatcher
from .llm_intent_classifier import LLMIntentClassifier
from .utils import (
    normalize_text,
    smart_split_sentences,
    contains_sensitive_action,
    translate_to_english,
)



RULES = rules


class PromptGuardLite:
    """
    Multilingual, layered prompt injection detection:
      1️⃣ Keyword + regex heuristics
      2️⃣ Sensitive action detection
      3️⃣ Multilingual semantic similarity (MiniLM)
      4️⃣ Fuzzy fallback
    """
    def __init__(self, semantic=True, threshold=0.78, multilingual=True, fuzzy=False, translate_fallback=True):
        self.keyword_matcher = KeywordMatcher()
        self.semantic = semantic
        self.threshold = threshold
        self.multilingual = multilingual
        self.fuzzy = fuzzy
        self.translate_fallback = translate_fallback

        if semantic:
            model_name = "paraphrase-multilingual-MiniLM-L12-v2" if multilingual else "all-MiniLM-L6-v2"
            self.model = SentenceTransformer(model_name)
            self._prepare_pattern_vectors()

    def _prepare_pattern_vectors(self):
        """Pre-encode all known bad patterns."""
        self.patterns = []
        self.pattern_cats = []
        for cat, pats in RULES.items():
            for p in pats:
                self.patterns.append(p)
                self.pattern_cats.append(cat)
        self.pattern_vecs = self.model.encode(self.patterns, normalize_embeddings=True, show_progress_bar=False)

    def analyze(self, text: str) -> dict:
        if not text or not text.strip():
            return {"safe": True, "matches": []}

        # Keep both normalized and raw text
        text_raw = text.strip()
        text_norm = normalize_text(text_raw)
        sentences = smart_split_sentences(text_norm)
        matches = []

        # 1️⃣ Keyword heuristic
        kw_hits = self.keyword_matcher.search(text_norm)
        if kw_hits:
            return {"safe": False, "risk": "HIGH", "reason": "keyword_match", "matches": kw_hits}

        # 2️⃣ Sensitive-action detector
        for s in sentences:
            if contains_sensitive_action(s):
                matches.append({"category": "heuristic", "sentence": s, "reason": "sensitive_action"})
                return {"safe": False, "risk": "HIGH", "matches": matches}

        # 3️⃣ Multilingual Semantic Similarity
        if self.semantic:
            multilingual_sentences = smart_split_sentences(text_raw)
            # Optional translation fallback for non-English
            if self.translate_fallback:
                multilingual_sentences = [translate_to_english(s) for s in multilingual_sentences]

            sent_vecs = self.model.encode(multilingual_sentences, normalize_embeddings=True, show_progress_bar=False)
            sims = cosine_similarity(sent_vecs, self.pattern_vecs)
            max_sim = float(np.max(sims))

            if max_sim > self.threshold:
                i, j = np.unravel_index(np.argmax(sims), sims.shape)
                cat = self.pattern_cats[j]
                sentence = multilingual_sentences[i]
                matches.append({"category": cat, "sentence": sentence, "similarity": round(max_sim, 3)})
                risk = "HIGH" if max_sim > 0.9 else "MEDIUM"
                return {"safe": False, "risk": risk, "reason": "semantic_match", "matches": matches}

        # 4️⃣ Fuzzy fallback
        if self.fuzzy:
            fuzzy_hits = self.keyword_matcher.fuzzy_search(text_norm)
            if fuzzy_hits:
                return {"safe": False, "risk": "HIGH", "reason": "fuzzy_match", "matches": fuzzy_hits}

        return {"safe": True, "matches": []}


class PromptGuard:
    """
    Optimized LLM-enhanced prompt injection detector:
      1️Keyword / regex heuristics
      2️ Sensitive-action detection
      3️ Quantized LLM-based intent classification (multilingual)
      4️ Optional fuzzy fallback
    """
    def __init__(self, llm_model="Qwen/Qwen2.5-0.5B-Instruct", fuzzy=False):
        self.keyword_matcher = KeywordMatcher()
        self.intent_model = LLMIntentClassifier(model_name=llm_model)
        self.fuzzy = fuzzy

    def analyze(self, text: str) -> dict:
        if not text or not text.strip():
            return {"safe": True, "matches": []}

        text_raw = text.strip()
        text_norm = normalize_text(text_raw)
        sentences = smart_split_sentences(text_norm)
        matches = []


        kw_hits = self.keyword_matcher.search(text_norm)
        if kw_hits:
            return {"safe": False, "risk": "HIGH", "reason": "keyword_match", "matches": kw_hits}


        for s in sentences:
            if contains_sensitive_action(s):
                matches.append({
                    "category": "heuristic",
                    "sentence": s,
                    "reason": "Sensitive action detected"
                })
                return {"safe": False, "risk": "HIGH", "matches": matches}


        malicious_found = False
        for s in sentences:
            label = self.intent_model.classify(s)
            if label == "MALICIOUS":
                malicious_found = True
                matches.append({
                    "category": "semantic_llm",
                    "sentence": s,
                    "reason": "LLM intent classification = MALICIOUS"
                })

        if malicious_found:
            return {"safe": False, "risk": "HIGH", "reason": "llm_intent", "matches": matches}


        if self.fuzzy:
            fuzzy_hits = self.keyword_matcher.fuzzy_search(text_norm)
            if fuzzy_hits:
                return {"safe": False, "risk": "MEDIUM", "reason": "fuzzy_match", "matches": fuzzy_hits}

        return {"safe": True, "matches": []}

