ChannelId = str
ContactPointId = str