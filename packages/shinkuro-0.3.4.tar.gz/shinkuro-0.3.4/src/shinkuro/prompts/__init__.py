"""Prompt implementations for shinkuro."""
