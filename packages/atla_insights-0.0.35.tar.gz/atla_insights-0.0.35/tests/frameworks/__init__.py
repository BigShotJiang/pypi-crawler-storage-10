"""Test the frameworks."""
