"""MCP prompts for Katana Manufacturing ERP.

This module contains reusable prompt templates for common manufacturing
workflow scenarios.
"""

__all__ = []
