# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity and
orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment for our
community include:

- Demonstrating empathy and kindness toward other people.
- Being respectful of differing opinions, viewpoints, and experiences.
- Giving and gracefully accepting constructive feedback.
- Taking responsibility and apologizing to those affected by our mistakes.
- Focusing on what is best not just for us as individuals, but for the overall community.

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances of any kind.
- Trolling, insulting or derogatory comments, and personal or political attacks.
- Public or private harassment.
- Publishing others’ private information, such as a physical or email address, without their explicit permission.
- Other conduct which could reasonably be considered inappropriate in a professional setting.

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of acceptable behavior and will take appropriate and fair corrective action in response to any behavior they deem inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all community spaces and also applies when
an individual is officially representing the community in public spaces (e.g.,
using an official project email, posting via an official social media account, or
acting as an appointed representative at an online or offline event).

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to the community leaders at **hello@cogentlabs.co**.
All complaints will be reviewed and investigated promptly and fairly.

All community leaders are obligated to respect the privacy and security of the reporter of any incident.

## Enforcement Guidelines

Community leaders will follow these guidelines in determining the consequences for any action they deem in violation of this Code of Conduct:

1. **Correction**

   - Community impact: Use of inappropriate language or other behavior deemed unprofessional.
   - Consequence: A private, written warning from community leaders, providing clarity around the nature of the violation.

2. **Warning**

   - Community impact: A violation through a single incident or series of actions.
   - Consequence: A warning with consequences for continued behavior.

3. **Temporary Ban**

   - Community impact: Serious violation of community standards.
   - Consequence: A temporary ban from interaction or public communication with the community.

4. **Permanent Ban**
   - Community impact: Demonstrating a pattern of violation or harassment.
   - Consequence: Permanent removal from community spaces.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org),
version 2.1, available at
https://www.contributor-covenant.org/version/2/1/code_of_conduct.html

For answers to common questions, see
https://www.contributor-covenant.org/faq
