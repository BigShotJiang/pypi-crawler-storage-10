from typing import Any

from fastapi_constance.clients.redis import RedisClient
from fastapi_constance.exceptions import TypeMismatchError


class ConstanceConfigCacheManager:
    """
    Redis-backed cache without local memory.
    All reads/writes go directly to Redis.
    """

    def __init__(self):
        self.redis_client = RedisClient.get_client()

    async def get(self, key: str) -> Any:
        """Get value directly from Redis."""

        value = await self.redis_client.get(key)
        return value

    async def set(self, key: str, value: Any):
        """Set value in Redis."""

        if value is None:
            redis_value = "None"
        elif isinstance(value, bool):
            redis_value = "True" if value else "False"
        else:
            redis_value = str(value)

        await self.redis_client.set(key, redis_value)

    async def remove(self, key: str):
        """Remove value from Redis."""

        await self.redis_client.delete(key)

    async def populate(self, config: dict):
        """Populate Redis with default config values."""

        for key, data in config.items():
            value_type = data.get("type", str)
            value = data["value"]
            await self.set(key, self.type_cast_value(value, value_type))

    def type_cast_value(self, value: Any, value_type: type):
        """
        Strictly handle type casting, especially for bools.
        """

        try:
            return None if value is None else self._cast_to_bool(value) if value_type is bool else value_type(value)
        except (ValueError, TypeError):
            raise TypeMismatchError(f"Cannot type cast value '{value}' to {value_type.__name__}")

    def _cast_to_bool(self, value: Any):
        """
        Handle strict boolean type casting.
        Accepts True/False (bool) or "True"/"False" (str).
        """

        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value in ("True", "False"):
            return value == "True"
        raise TypeMismatchError(f"Cannot type cast '{value}' to bool. Must be 'True' or 'False'.")
