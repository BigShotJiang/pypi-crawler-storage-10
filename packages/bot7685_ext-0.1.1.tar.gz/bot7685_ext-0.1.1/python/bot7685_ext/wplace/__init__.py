from .compare import ColorEntry, compare

__all__ = ["ColorEntry", "compare"]
