__version__ = "1.3.0"  # This is overwritten by Hatch in CI/CD, don't change it.
