# fastapi-maker

> 🚧 **Work in Progress** – This is a placeholder release to reserve the package name.  
> Full CLI functionality (e.g., `fam init`, `fam create <module>`) coming soon!

A command-line tool to scaffold FastAPI applications with modules, DTOs, routes, models, and more.

## Installation (future)

```bash
pip install fastapi-maker
