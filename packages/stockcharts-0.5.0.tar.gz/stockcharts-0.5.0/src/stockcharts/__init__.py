"""StockCharts package: initial minimal scaffold for Heiken Ashi chart generation."""
"""StockCharts package initialization.

Provides public version constant for CLI and user introspection.
"""

__all__ = ["__version__"]
__version__ = "0.5.0"
