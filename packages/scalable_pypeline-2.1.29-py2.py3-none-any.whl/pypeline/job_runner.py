import os
import sys
import signal
import logging
import argparse
import threading
import multiprocessing as mp

# Prefer spawn for user code using multiprocessing
if mp.get_start_method(allow_none=True) != "spawn":
    mp.set_start_method("spawn", force=True)

# Avoid staging more than one message; must be set before Dramatiq import path runs
os.environ.setdefault("dramatiq_queue_prefetch", "1")

from dramatiq import Worker, get_broker, set_broker  # noqa: E402
try:
    from pypeline.dramatiq import configure_default_broker  # adjust path/name if needed
    broker = configure_default_broker() or get_broker()
    set_broker(broker)
except Exception:
    import pypeline.dramatiq  # noqa: F401
    broker = get_broker()

from dramatiq.middleware import Middleware  # noqa: E402


class OneAndDone(Middleware):
    """Flip an event after the first successful message in THIS process."""
    def __init__(self, done_event: threading.Event):
        self.done = done_event

    def after_process_message(self, broker, message, *, result=None, exception=None):
        if exception is None and not self.done.is_set():
            self.done.set()


def job_runner(queues, idle_timeout_ms: int = 0):
    """
    Start a single-thread Dramatiq worker, process exactly one successful message, then exit.
    - queues: list[str]
    - idle_timeout_ms: 0 or <0 => wait forever; >0 => exit if nothing processed in time
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
    log = logging.getLogger("oneshot")

    # Normalize timeout
    timeout_ms = int(idle_timeout_ms) if idle_timeout_ms and int(idle_timeout_ms) > 0 else 0
    log.info("Launching worker with queues=%s, idle_timeout_ms=%s", queues, timeout_ms or "∞")

    done = threading.Event()
    broker.add_middleware(OneAndDone(done))

    worker = Worker(
        broker,
        worker_threads=1,
        queues=queues,
        worker_timeout=1000,  # ms; how often the worker checks for stop
    )

    worker.start()

    def controller():
        try:
            if timeout_ms > 0:
                finished = done.wait(timeout=timeout_ms / 1000.0)
                if not finished:
                    log.info("Idle timeout reached (%d ms); stopping worker.", timeout_ms)
            else:
                done.wait()

            log.info("Stopping worker now.")
            worker.stop()    # halts consumers; no new message will start
            worker.join()
        finally:
            # Exit cleanly so K8s Job is marked Succeeded
            sys.exit(0)

    t = threading.Thread(target=controller, name="oneshot-controller", daemon=False)
    t.start()

    # Block main thread until controller finishes (which joins the worker)
    t.join()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run a one-shot Dramatiq worker.")
    parser.add_argument(
        "-q", "--queue",
        action="append",
        default=None,
        help="Queue to listen to (repeatable). You can also pass a comma-separated list."
    )
    parser.add_argument(
        "--idle-timeout-ms",
        type=int,
        default=int(os.getenv("IDLE_TIMEOUT_MS", "0")),
        help="Exit if no job arrives within this time (0 or negative = wait forever)."
    )
    args = parser.parse_args(argv)

    # Build the queue list from flags or env, splitting on commas for each entry.
    raw_entries = args.queue if args.queue else [os.getenv("JOB_QUEUE", "pipeline-queue")]
    queues = []
    for entry in raw_entries:
        queues.extend([q.strip() for q in str(entry).split(",") if q and q.strip()])

    if not queues:
        raise SystemExit("No queues provided. Use -q ... or set JOB_QUEUE.")

    logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
    log = logging.getLogger("oneshot")

    pid = os.getpid()
    ppid = os.getppid()
    log.info("Starting one-shot worker PID=%s, Parent PID=%s, queues=%s, idle_timeout_ms=%s",
             pid, ppid, queues, args.idle_timeout_ms if args.idle_timeout_ms > 0 else "∞")

    job_runner(queues, idle_timeout_ms=args.idle_timeout_ms)


if __name__ == "__main__":
    main()
