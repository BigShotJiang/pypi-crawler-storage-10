module.exports = {
    // eslint parser options
    // - enable eslint to understand typescript grammer
    parser: '@typescript-eslint/parser',
    // parser options:
    parserOptions: {
        project: 'tsconfig.eslint.json',
        sourceType: 'module',
    },
    // follow typescript eslint rules
    plugins: ["@typescript-eslint"],
    // extends eslint:recommended and typescript-eslint recommended rules (usually defaults)
    extends: [
        'eslint:recommended',
        'plugin:@typescript-eslint/eslint-recommended',
        'plugin:@typescript-eslint/recommended',
        'plugin:prettier/recommended',
    ],
    rules: {
        '@typescript-eslint/no-unused-vars': ['warn', { args: 'none' }],
        '@typescript-eslint/no-explicit-any': 'off',
        '@typescript-eslint/no-namespace': 'off',
        '@typescript-eslint/no-use-before-define': 'off',
        '@typescript-eslint/quotes': [
            'error',
            'single',
            { avoidEscape: true, allowTemplateLiterals: false }
        ],
        curly: ['error', 'all'],
        eqeqeq: 'error',
        'prefer-arrow-callback': 'error'
    }
}