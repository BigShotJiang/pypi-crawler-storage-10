import glViewer from './glviewer';
import glResource from './glresource';

type Impl = {
  initialize?: (args: { model: any }) => void;
  render: (args: { model: any; el: HTMLElement }) => void;
};

const registry: Record<'glviewer' | 'glresource', Impl> = {
  glviewer: glViewer,
  glresource: glResource,
};

function getFromRegistry(model: any): Impl | undefined {
  const kind = model.get('kind') as keyof typeof registry;
  return registry[kind];
}

export default () => {
  return {
    initialize({ model }: { model: any }) {
      try {
        const impl = getFromRegistry(model);
        if (!impl) {
          console.warn('[ext] no impl found for kind');
          return;
        }
        impl.initialize?.({ model });
      } catch (err) {
        console.error('[ext] initialize error', err);
        throw err;
      }
    },
    render({ model, el }: { model: any; el: HTMLElement }) {
      try {
        const impl = getFromRegistry(model);
        if (!impl) {
          el.textContent = '[ext] no impl for given kind';
          return;
        }
        impl.render({ model, el });
      } catch (err) {
        console.error('[ext] render error', err);
        throw err;
      }
    },
  };
};
