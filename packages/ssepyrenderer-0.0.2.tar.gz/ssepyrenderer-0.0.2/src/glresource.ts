import type { AnyModel } from '@anywidget/types';
import { glContext } from './webglcontext';

function displayJson(json: any, parent: any): void {
  for (const key in json) {
    const jsonKey = document.createElement('div');
    jsonKey.classList.add('ssepywidget-json-key');
    jsonKey.textContent = `${key}:`;

    const jsonValue = document.createElement('div');
    jsonValue.classList.add('ssepywidget-json-value');

    if (typeof json[key] === 'object') {
      const nestedJsonDisplay = document.createElement('div');
      nestedJsonDisplay.classList.add('ssepywidget-json-display');

      displayJson(json[key], nestedJsonDisplay);
      jsonValue.appendChild(nestedJsonDisplay);
    } else {
      jsonValue.textContent = json[key];
    }

    parent.appendChild(jsonKey);
    parent.appendChild(jsonValue);
  }
}

function initialize({ model }: { model: AnyModel }) {}
function render({ model, el }: { model: AnyModel; el: HTMLElement }) {
  const root = el;
  const jsonDisplay = document.createElement('div');
  jsonDisplay.classList.add('ssepywidget-json-display');

  const jsonKey = document.createElement('div');
  jsonKey.classList.add('ssepywidget-json-key');
  jsonKey.textContent = 'uid:';

  const jsonValue = document.createElement('div');
  jsonValue.classList.add('ssepywidget-json-value');
  jsonValue.textContent = model.get('uid');

  jsonDisplay.appendChild(jsonKey);
  jsonDisplay.appendChild(jsonValue);

  const info = glContext.getResourceInfo(model.get('uid'));
  if (info !== null) {
    displayJson(info, jsonDisplay);
  }

  root.appendChild(jsonDisplay);
}

export default { initialize, render };
