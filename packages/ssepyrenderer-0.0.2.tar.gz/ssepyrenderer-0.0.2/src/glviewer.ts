import type { AnyModel } from '@anywidget/types';
import { glContext } from './webglcontext';

function initialize({ model }: { model: AnyModel }) {
  glContext.initialize(model);
}

function render({ model, el }: { model: AnyModel; el: HTMLElement }) {
  glContext.render(model, el);
}

export default { initialize, render };
