import type { AnyModel } from '@anywidget/types';

declare global {
  interface Window {
    SPECTOR?: any;
  }
}

// spector bundle lazy loading:
async function ensureSpector(): Promise<any> {
  if (window.SPECTOR) {
    return window.SPECTOR;
  }

  await new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/spectorjs/dist/spector.bundle.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('Failed to load SpectorJS'));
    document.head.appendChild(s);
  });
  return window.SPECTOR;
}

function bufferToArray(dtype: string, buffer: any) {
  let array: any = null;
  switch (dtype) {
    case 'int8':
      array = new Int8Array(buffer);
      break;
    case 'uint8':
      array = new Uint8Array(buffer);
      break;
    case 'int16':
      array = new Int16Array(buffer);
      break;
    case 'uint16':
      array = new Uint16Array(buffer);
      break;
    case 'int32':
      array = new Int32Array(buffer);
      break;
    case 'uint32':
      array = new Uint32Array(buffer);
      break;
    case 'float32':
      array = new Float32Array(buffer);
      break;
    case 'float64':
      array = new Float64Array(buffer);
      break;
    default:
      throw new Error(`Unsupported dtype: ${dtype}`);
  }
  return array;
}

function m4Frustum(
  left: number,
  right: number,
  bottom: number,
  top: number,
  near: number,
  far: number,
) {
  const a = (right + left) / (right - left);
  const b = (top + bottom) / (top - bottom);
  const c = -(far + near) / (far - near);
  const d = (-2 * far * near) / (far - near);
  const e = (2 * near) / (right - left);
  const f = (2 * near) / (top - bottom);

  return [e, 0, a, 0, 0, f, b, 0, 0, 0, c, d, 0, 0, -1, 0];
}

function m4ProjectionMatrix(
  fovY: number,
  aspectRatio: number,
  near: number,
  far: number,
) {
  const ymax = near * Math.tan((fovY * Math.PI) / 360.0);
  const xmax = ymax * aspectRatio;
  return m4Frustum(-xmax, xmax, -ymax, ymax, near, far);
}

function m4OrthoProjectionMatrix(
  width: number,
  height: number,
  near: number,
  far: number,
) {
  const a = 1 / width;
  const b = 1 / height;
  const c = -(far + near) / (far - near);
  const d = -2 / (far - near);

  return [a, 0, 0, 0, 0, b, 0, 0, 0, 0, c, d, 0, 0, 0, 1];
}

function m4Transpose(m: number[]) {
  return [
    m[0],
    m[4],
    m[8],
    m[12],
    m[1],
    m[5],
    m[9],
    m[13],
    m[2],
    m[6],
    m[10],
    m[14],
    m[3],
    m[7],
    m[11],
    m[15],
  ];
}

function m4GetTranslation(m: number[]) {
  return [m[3], m[7], m[11]];
}

function m4GetColumnI(m: number[]) {
  return [m[0], m[4], m[8]];
}

function m4GetColumnJ(m: number[]) {
  return [m[1], m[5], m[9]];
}

function m4GetColumnK(m: number[]) {
  return [m[2], m[6], m[10]];
}

function m4GetColumnL(m: number[]) {
  return [m[3], m[7], m[11]];
}

function v3Add(a: number[], b: number[]) {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}

function v3Scale(a: number[], scale: number) {
  return [a[0] * scale, a[1] * scale, a[2] * scale];
}

function m4Translation(tx: number, ty: number, tz: number) {
  return [1, 0, 0, tx, 0, 1, 0, ty, 0, 0, 1, tz, 0, 0, 0, 1];
}

function m4XRotation(angleInRadians: number) {
  var c = Math.cos(angleInRadians);
  var s = Math.sin(angleInRadians);
  return [1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1];
}

function m4YRotation(angleInRadians: number) {
  var c = Math.cos(angleInRadians);
  var s = Math.sin(angleInRadians);
  return [c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1];
}

function m4ZRotation(angleInRadians: number) {
  var c = Math.cos(angleInRadians);
  var s = Math.sin(angleInRadians);
  return [c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0];
}

function m4Scale(sx: number, sy: number, sz: number) {
  return [sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1];
}

function m4Dot(b: number[], a: number[]) {
  return [
    b[0] * a[0] + b[1] * a[4] + b[2] * a[8] + b[3] * a[12],
    b[0] * a[1] + b[1] * a[5] + b[2] * a[9] + b[3] * a[13],
    b[0] * a[2] + b[1] * a[6] + b[2] * a[10] + b[3] * a[14],
    b[0] * a[3] + b[1] * a[7] + b[2] * a[11] + b[3] * a[15],
    b[4] * a[0] + b[5] * a[4] + b[6] * a[8] + b[7] * a[12],
    b[4] * a[1] + b[5] * a[5] + b[6] * a[9] + b[7] * a[13],
    b[4] * a[2] + b[5] * a[6] + b[6] * a[10] + b[7] * a[14],
    b[4] * a[3] + b[5] * a[7] + b[6] * a[11] + b[7] * a[15],
    b[8] * a[0] + b[9] * a[4] + b[10] * a[8] + b[11] * a[12],
    b[8] * a[1] + b[9] * a[5] + b[10] * a[9] + b[11] * a[13],
    b[8] * a[2] + b[9] * a[6] + b[10] * a[10] + b[11] * a[14],
    b[8] * a[3] + b[9] * a[7] + b[10] * a[11] + b[11] * a[15],
    b[12] * a[0] + b[13] * a[4] + b[14] * a[8] + b[15] * a[12],
    b[12] * a[1] + b[13] * a[5] + b[14] * a[9] + b[15] * a[13],
    b[12] * a[2] + b[13] * a[6] + b[14] * a[10] + b[15] * a[14],
    b[12] * a[3] + b[13] * a[7] + b[14] * a[11] + b[15] * a[15],
  ];
}

function m4Inverse(m: number[]) {
  var tmp_0 = m[10] * m[15];
  var tmp_1 = m[14] * m[11];
  var tmp_2 = m[6] * m[15];
  var tmp_3 = m[14] * m[7];
  var tmp_4 = m[6] * m[11];
  var tmp_5 = m[10] * m[7];
  var tmp_6 = m[2] * m[15];
  var tmp_7 = m[14] * m[3];
  var tmp_8 = m[2] * m[11];
  var tmp_9 = m[10] * m[3];
  var tmp_10 = m[2] * m[7];
  var tmp_11 = m[6] * m[3];
  var tmp_12 = m[8] * m[13];
  var tmp_13 = m[12] * m[9];
  var tmp_14 = m[4] * m[13];
  var tmp_15 = m[12] * m[5];
  var tmp_16 = m[4] * m[9];
  var tmp_17 = m[8] * m[5];
  var tmp_18 = m[0] * m[13];
  var tmp_19 = m[12] * m[1];
  var tmp_20 = m[0] * m[9];
  var tmp_21 = m[8] * m[1];
  var tmp_22 = m[0] * m[5];
  var tmp_23 = m[4] * m[1];

  var t0 =
    tmp_0 * m[5] +
    tmp_3 * m[9] +
    tmp_4 * m[13] -
    (tmp_1 * m[5] + tmp_2 * m[9] + tmp_5 * m[13]);
  var t1 =
    tmp_1 * m[1] +
    tmp_6 * m[9] +
    tmp_9 * m[13] -
    (tmp_0 * m[1] + tmp_7 * m[9] + tmp_8 * m[13]);
  var t2 =
    tmp_2 * m[1] +
    tmp_7 * m[5] +
    tmp_10 * m[13] -
    (tmp_3 * m[1] + tmp_6 * m[5] + tmp_11 * m[13]);
  var t3 =
    tmp_5 * m[1] +
    tmp_8 * m[5] +
    tmp_11 * m[9] -
    (tmp_4 * m[1] + tmp_9 * m[5] + tmp_10 * m[9]);

  var d = 1.0 / (m[0] * t0 + m[4] * t1 + m[8] * t2 + m[12] * t3);

  return [
    d * t0,
    d * t1,
    d * t2,
    d * t3,
    d *
      (tmp_1 * m[4] +
        tmp_2 * m[8] +
        tmp_5 * m[12] -
        (tmp_0 * m[4] + tmp_3 * m[8] + tmp_4 * m[12])),
    d *
      (tmp_0 * m[0] +
        tmp_7 * m[8] +
        tmp_8 * m[12] -
        (tmp_1 * m[0] + tmp_6 * m[8] + tmp_9 * m[12])),
    d *
      (tmp_3 * m[0] +
        tmp_6 * m[4] +
        tmp_11 * m[12] -
        (tmp_2 * m[0] + tmp_7 * m[4] + tmp_10 * m[12])),
    d *
      (tmp_4 * m[0] +
        tmp_9 * m[4] +
        tmp_10 * m[8] -
        (tmp_5 * m[0] + tmp_8 * m[4] + tmp_11 * m[8])),
    d *
      (tmp_12 * m[7] +
        tmp_15 * m[11] +
        tmp_16 * m[15] -
        (tmp_13 * m[7] + tmp_14 * m[11] + tmp_17 * m[15])),
    d *
      (tmp_13 * m[3] +
        tmp_18 * m[11] +
        tmp_21 * m[15] -
        (tmp_12 * m[3] + tmp_19 * m[11] + tmp_20 * m[15])),
    d *
      (tmp_14 * m[3] +
        tmp_19 * m[7] +
        tmp_22 * m[15] -
        (tmp_15 * m[3] + tmp_18 * m[7] + tmp_23 * m[15])),
    d *
      (tmp_17 * m[3] +
        tmp_20 * m[7] +
        tmp_23 * m[11] -
        (tmp_16 * m[3] + tmp_21 * m[7] + tmp_22 * m[11])),
    d *
      (tmp_14 * m[10] +
        tmp_17 * m[14] +
        tmp_13 * m[6] -
        (tmp_16 * m[14] + tmp_12 * m[6] + tmp_15 * m[10])),
    d *
      (tmp_20 * m[14] +
        tmp_12 * m[2] +
        tmp_19 * m[10] -
        (tmp_18 * m[10] + tmp_21 * m[14] + tmp_13 * m[2])),
    d *
      (tmp_18 * m[6] +
        tmp_23 * m[14] +
        tmp_15 * m[2] -
        (tmp_22 * m[14] + tmp_14 * m[2] + tmp_19 * m[6])),
    d *
      (tmp_22 * m[10] +
        tmp_16 * m[2] +
        tmp_21 * m[6] -
        (tmp_20 * m[6] + tmp_23 * m[10] + tmp_17 * m[2])),
  ];
}

/** generic singleton class (my preferrable version of using singleton pattern regardless of languages) */
abstract class Singleton<T> {
  private static instances: Map<any, any> = new Map();

  constructor() {
    const constructor = this.constructor;
    if (Singleton.instances.has(constructor)) {
      return Singleton.instances.get(constructor);
    }
    Singleton.instances.set(constructor, this);
  }

  static getInstance<T extends Singleton<any>>(this: new () => T): T {
    const globalKey = Symbol.for(`__singleton__:${this.name}`);
    const g = globalThis as any;
    g.__registry ??= new Map();

    const reg: Map<any, any> = g.__registry;

    if (reg.has(globalKey)) {
      return reg.get(globalKey);
    }

    if (!Singleton.instances.has(this)) {
      new this();
    }

    const inst = Singleton.instances.get(this) as T;
    reg.set(globalKey, inst);
    return inst;
  }
}

class GLResource {
  public uid: number;

  /**
   * internal state
   * - _gl_ptr: the pointer to WebGL2 resource object
   * - _info: the type of WebGL2 resource object
   */
  public _gl_ptr:
    | WebGLShader
    | WebGLTexture
    | WebGLBuffer
    | WebGLFramebuffer
    | WebGLRenderbuffer
    | null = null;

  public _info: {
    type: any;
  } = { type: 'not set' };

  constructor() {
    this.uid = -1;
  }
}

/** independent gl-context instance manages canvas and webgl in JS side */
class GLContext extends Singleton<GLContext> {
  /** canvas element that will be used to render the scene */
  public canvas: HTMLCanvasElement;

  /** WebGL2 context */
  public ctx: WebGL2RenderingContext | null;

  /** uniform buffer binded slot-0 */
  public viewBlock: WebGLBuffer | null;

  /** resources managed by this context */
  resources: GLResource[] = [];

  /** bound program state (e.g. PSO: pipeline state object) */
  boundProgram: GLResource | null;
  boundVao: GLResource | null;
  boundBuffers = {};
  commands: any[] = [];
  buffers: any[] = [];

  /** matrix state */
  projectionMatrix: number[] = [];
  cameraMatrix: number[] = [];
  viewMatrix: number[] = [];
  viewProjMatrix: number[] = [];

  /** viewer properties */
  isMouseDown: boolean = false;
  moveDirection: boolean[] = [false, false, false, false];
  willRedraw: boolean = false;

  /** webgl2 spectorJS (for graphics frame debugger) */
  private spector: any | null = null;
  private spectorAutoOnce: boolean = false;
  private spectorActive: boolean = false;
  private spectorSpied = false;

  constructor() {
    // we inherit from singleton class, so need to call super()
    super();

    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('webgl2', {
      preserveDrawingBuffer: true,
    });

    this.viewBlock = null;
    if (this.ctx === null) {
      console.error(
        'could not create WebGL2 context, this is not supported by your browser',
      );
    } else {
      const gl: WebGL2RenderingContext = this.ctx;
      this.viewBlock = gl.createBuffer();
      gl.bindBuffer(gl.UNIFORM_BUFFER, this.viewBlock);
      gl.bufferData(gl.UNIFORM_BUFFER, 256, gl.DYNAMIC_DRAW);
      gl.bindBuffer(gl.UNIFORM_BUFFER, null);
      gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, this.viewBlock);

      // extensions to activate
      gl.getExtension('EXT_color_buffer_float');

      console.log('WebGL2 context is successfully created');
    }

    // clear bound program state
    this.boundProgram = null;
    this.boundVao = null;
  }

  public initialize(model: AnyModel): void {
    // resize canvas with model's info
    this.resizeCanvas(model);

    // listen to model's changes
    ['width', 'height', 'camera_fov', 'camera_near', 'camera_far'].forEach(
      (p) => model.on(`change:${p}`, () => this.resizeCanvas(model)),
    );

    // listen json-type message events
    // - see python code: GLViewer.execute_commands()
    model.on('msg:custom', (msg: any, buffers: DataView[]) => {
      this.handleCustomMessages(model, msg, buffers);
    });

    ['camera_pos', 'camera_yaw', 'camera_pitch'].forEach((p) =>
      model.on(`change:${p}`, () => this.runCommands(model)),
    );

    this.cameraMatrix = m4Translation(0, 50, 200);
    this.viewMatrix = m4Inverse(this.cameraMatrix);

    console.log('GLContext.initialize() is called successfully');
  }

  private resizeCanvas(model: AnyModel): void {
    const width: number = model.get('width');
    const height: number = model.get('height');
    this.canvas.setAttribute('width', width.toString());
    this.canvas.setAttribute('height', height.toString());

    if (this.ctx !== null) {
      this.ctx.viewport(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
    }

    this.projectionMatrix = m4ProjectionMatrix(
      model.get('camera_fov'),
      width / height,
      model.get('camera_near'),
      model.get('camera_far'),
    );
  }

  private updateCamera(model: AnyModel): void {
    let pos = model.get('camera_pos');
    let yaw = model.get('camera_yaw');
    let pitch = model.get('camera_pitch');

    this.cameraMatrix = m4Translation(pos[0], pos[1], pos[2]);
    this.cameraMatrix = m4Dot(this.cameraMatrix, m4YRotation(yaw));
    this.cameraMatrix = m4Dot(this.cameraMatrix, m4XRotation(pitch));
    this.viewMatrix = m4Inverse(this.cameraMatrix);
    this.viewProjMatrix = m4Dot(this.projectionMatrix, this.viewMatrix);
  }

  private glEnumToString(gl: WebGL2RenderingContext, value: any) {
    const keys = [];
    for (const key in gl) {
      if ((gl as any)[key] === value) {
        keys.push(key);
      }
    }
    return keys.length ? keys.join(' | ') : `0x${value.toString(16)}`;
  }

  private executeCommand(
    model: AnyModel,
    gl: WebGL2RenderingContext,
    command: any,
    convertedBuffers: any[],
  ): void {
    if (model.get('verbose') > 0) {
      console.log(command);
      if (command.hasOwnProperty('buffer_metadata')) {
        console.log('data');
        console.log(convertedBuffers[command.buffer_metadata.index]);
      }
    }

    switch (command.cmd) {
      case 'viewport':
        gl.viewport(command.x, command.y, command.width, command.height);
        break;
      case 'enable':
      case 'disable':
        {
          let cap = 0;
          if (command.blend) cap |= gl.BLEND;
          if (command.depth_test) cap |= gl.DEPTH_TEST;
          if (command.dither) cap |= gl.DITHER;
          if (command.polygon_offset_fill) cap |= gl.POLYGON_OFFSET_FILL;
          if (command.sample_alpha_to_coverage)
            cap |= gl.SAMPLE_ALPHA_TO_COVERAGE;
          if (command.sample_coverage) cap |= gl.SAMPLE_COVERAGE;
          if (command.scissor_test) cap |= gl.SCISSOR_TEST;
          if (command.stencil_test) cap |= gl.STENCIL_TEST;
          if (command.rasterizer_discard) cap |= gl.RASTERIZER_DISCARD;
          if (command.cull_face) cap |= gl.CULL_FACE;

          if (command.cmd == 'enable') {
            gl.enable(cap);
          } else {
            gl.disable(cap);
          }
        }
        break;
      case 'clearColor':
        gl.clearColor(command.r, command.g, command.b, command.a);
        break;
      case 'clear':
        {
          let bits = 0;
          if (command.depth) bits |= gl.DEPTH_BUFFER_BIT;
          if (command.color) bits |= gl.COLOR_BUFFER_BIT;
          if (command.stencil) bits |= gl.STENCIL_BUFFER_BIT;
          gl.clear(bits);
        }
        break;
      case 'frontFace':
        {
          gl.frontFace((gl as any)[command.mode]);
        }
        break;
      case 'cullFace':
        {
          gl.cullFace((gl as any)[command.mode]);
        }
        break;

      //------------------------------- DEPTH --------------------------------------
      case 'depthFunc':
        {
          gl.depthFunc((gl as any)[command.func]);
        }
        break;
      case 'depthMask':
        {
          gl.depthMask(command.flag);
        }
        break;
      case 'depthRange':
        {
          gl.depthRange(command.z_near, command.z_far);
        }
        break;

      //------------------------------- COLOR --------------------------------------
      case 'createTexture':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createTexture();
          res._gl_ptr = ptr;
          res._info = { type: 'texture' };
        }
        break;
      case 'bindTexture':
        {
          if (command.texture > -1) {
            const texture = this.getResource(command.texture)._gl_ptr;
            gl.bindTexture((gl as any)[command.target], texture);
          } else {
            gl.bindTexture((gl as any)[command.target], null);
          }
        }
        break;
      case 'activeTexture':
        gl.activeTexture(gl.TEXTURE0 + command.texture);
        break;
      case 'generateMipmap':
        gl.generateMipmap((gl as any)[command.target]);
        break;
      case 'texImage2D':
        {
          if (command.hasOwnProperty('buffer_metadata')) {
            gl.texImage2D(
              (gl as any)[command.target],
              command.level,
              (gl as any)[command.internal_format],
              command.width,
              command.height,
              command.border,
              (gl as any)[command.format],
              (gl as any)[command.data_type],
              convertedBuffers[command.buffer_metadata.index],
            );
          } else {
            gl.texImage2D(
              (gl as any)[command.target],
              command.level,
              (gl as any)[command.internal_format],
              command.width,
              command.height,
              command.border,
              (gl as any)[command.format],
              (gl as any)[command.data_type],
              null,
            );
          }
        }
        break;
      case 'texStorage2D':
        {
          gl.texStorage2D(
            (gl as any)[command.target],
            command.levels,
            (gl as any)[command.internal_format],
            command.width,
            command.height,
          );
        }
        break;
      case 'texImage3D':
        {
          if (command.hasOwnProperty('buffer_metadata')) {
            gl.texImage3D(
              (gl as any)[command.target],
              command.level,
              (gl as any)[command.internal_format],
              command.width,
              command.height,
              command.depth,
              command.border,
              (gl as any)[command.format],
              (gl as any)[command.data_type],
              convertedBuffers[command.buffer_metadata.index],
            );
          } else {
            gl.texImage3D(
              (gl as any)[command.target],
              command.level,
              (gl as any)[command.internal_format],
              command.width,
              command.height,
              command.depth,
              command.border,
              (gl as any)[command.format],
              (gl as any)[command.data_type],
              null,
            );
          }
        }
        break;
      case 'texStorage3D':
        {
          gl.texStorage3D(
            (gl as any)[command.target],
            command.levels,
            (gl as any)[command.internal_format],
            command.width,
            command.height,
            command.depth,
          );
        }
        break;
      case 'texParameteri':
        gl.texParameteri(
          (gl as any)[command.target],
          (gl as any)[command.pname],
          command.param,
        );
        break;
      case 'texParameterf':
        gl.texParameterf(
          (gl as any)[command.target],
          (gl as any)[command.pname],
          command.param,
        );
        break;
      case 'texParameter_str':
        gl.texParameteri(
          (gl as any)[command.target],
          (gl as any)[command.pname],
          (gl as any)[command.param],
        );
        break;
      case 'pixelStorei':
        {
          if (command.pname == 'UNPACK_COLORSPACE_CONVERSION_WEBGL') {
            gl.pixelStorei(
              (gl as any)[command.pname],
              (gl as any)[command.param],
            );
          } else {
            gl.pixelStorei((gl as any)[command.pname], command.param);
          }
        }
        break;
      // ------------------------------- SHADERS --------------------------------------
      case 'createShader':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createShader((gl as any)[command.type]);
          res._gl_ptr = ptr;
          res._info = { type: 'shader' };
        }
        break;
      case 'shaderSource':
        {
          const res = this.getResource(command.shader);
          const ptr = res._gl_ptr as WebGLShader;
          gl.shaderSource(ptr, command.source);
        }
        break;
      case 'compileShader':
        {
          const res = this.getResource(command.shader);
          const ptr = res._gl_ptr as WebGLShader;
          gl.compileShader(ptr);

          let resInfo = res._info as { type: any; message?: string };
          if (!gl.getShaderParameter(ptr, gl.COMPILE_STATUS)) {
            let info = gl.getShaderInfoLog(ptr);
            resInfo.message = info || '';
            // leave error log:
            console.log(resInfo);
          } else {
            resInfo.message = 'compiled';
          }
          res._info = resInfo;
        }
        break;
      // ------------------------------- PROGRAMS --------------------------------------
      case 'createProgram':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createProgram();
          res._gl_ptr = ptr;
          res._info = { type: 'program' };
        }
        break;
      case 'attachShader':
        {
          const prog = this.getResource(command.program)
            ._gl_ptr as WebGLProgram;
          const shader = this.getResource(command.shader)
            ._gl_ptr as WebGLShader;
          gl.attachShader(prog, shader);
        }
        break;
      case 'bindAttribLocation':
        {
          let res = this.getResource(command.program);
          const ptr = res._gl_ptr as WebGLProgram;
          gl.bindAttribLocation(ptr, command.index, command.name);
        }
        break;
      case 'linkProgram':
        {
          let res = this.getResource(command.program);
          const ptr = res._gl_ptr as WebGLProgram;
          gl.linkProgram(ptr);
          gl.validateProgram(ptr);

          let resInfo = res._info as {
            type: any;
            message?: string;
            uniformBlocks?: any[];
            uniforms?: any[];
            attributes?: any[];
          };
          if (!gl.getProgramParameter(ptr, gl.LINK_STATUS)) {
            let info = gl.getShaderInfoLog(ptr);
            resInfo.message = info || '';
          } else {
            // bind our view-block:
            let viewBlockIndex = gl.getUniformBlockIndex(ptr, 'ViewBlock');
            if (viewBlockIndex < 4294967295) {
              gl.uniformBlockBinding(ptr, viewBlockIndex, 0);
            }
            resInfo.message = 'linked';
            resInfo.uniformBlocks = [];
            resInfo.uniforms = [];

            const numUniforms = gl.getProgramParameter(ptr, gl.ACTIVE_UNIFORMS);
            const indices = [...Array(numUniforms).keys()];
            const blockIndices = gl.getActiveUniforms(
              ptr,
              indices,
              gl.UNIFORM_BLOCK_INDEX,
            );
            const offsets = gl.getActiveUniforms(
              ptr,
              indices,
              gl.UNIFORM_OFFSET,
            );
            for (let i = 0; i < numUniforms; ++i) {
              const info = gl.getActiveUniform(ptr, i);
              if (info) {
                // regroup the blocks:
                if (blockIndices[i] > -1) {
                  let uniformBlock = resInfo.uniformBlocks.find(
                    (element: any) => {
                      return element.index == blockIndices[i];
                    },
                  );
                  if (uniformBlock == undefined) {
                    uniformBlock = {
                      index: blockIndices[i],
                      name: gl.getActiveUniformBlockName(ptr, blockIndices[i]),
                      size: gl.getActiveUniformBlockParameter(
                        ptr,
                        blockIndices[i],
                        gl.UNIFORM_BLOCK_DATA_SIZE,
                      ),
                      uniforms: [],
                    };
                    resInfo.uniformBlocks.push(uniformBlock);
                  }
                  uniformBlock.uniforms.push({
                    name: info.name,
                    type: this.glEnumToString(gl, info.type),
                    size: info.size,
                    offset: offsets[i],
                  });
                } else {
                  resInfo.uniforms.push({
                    name: info.name,
                    type: this.glEnumToString(gl, info.type),
                    size: info.size,
                    location: gl.getUniformLocation(ptr, info.name),
                  });
                }
              }
            }

            resInfo.attributes = [];
            const numAttributes = gl.getProgramParameter(
              ptr,
              gl.ACTIVE_ATTRIBUTES,
            );
            for (let i = 0; i < numAttributes; ++i) {
              const info = gl.getActiveAttrib(ptr, i);
              if (info) {
                resInfo.attributes.push({
                  name: info.name,
                  type: this.glEnumToString(gl, info.type),
                  size: info.size,
                  location: gl.getAttribLocation(ptr, info.name),
                });
              }
            }
          }

          res._info = resInfo;
        }
        break;
      case 'useProgram':
        {
          if (command.program >= 0) {
            const res = this.getResource(command.program);
            const ptr = res._gl_ptr as WebGLProgram;
            gl.useProgram(ptr);
            this.boundProgram = res;
          } else {
            gl.useProgram(null);
            this.boundProgram = null;
          }
        }
        break;
      case 'uniform':
      case 'uniformMatrix':
        {
          if (this.boundProgram !== null) {
            let resInfo = this.boundProgram._info as {
              type: any;
              uniforms: any[];
            };
            const uniform = resInfo.uniforms.find((element: any) => {
              return element.name == command.name;
            });
            if (uniform !== undefined) {
              const location = uniform.location;
              if (command.cmd == 'uniform') {
                let shape =
                  command.buffer_metadata.shape[
                    command.buffer_metadata.shape.length - 1
                  ];
                if (command.buffer_metadata.dtype == 'int32') {
                  let bufArray: Int32Array = convertedBuffers[
                    command.buffer_metadata.index
                  ] as Int32Array;
                  if (shape === 1) {
                    gl.uniform1iv(location, bufArray);
                  } else if (shape === 2) {
                    gl.uniform2iv(location, bufArray);
                  } else if (shape === 3) {
                    gl.uniform3iv(location, bufArray);
                  } else if (shape === 4) {
                    gl.uniform4iv(location, bufArray);
                  }
                }
                if (command.buffer_metadata.dtype == 'uint32') {
                  let bufArray: Uint32Array = convertedBuffers[
                    command.buffer_metadata.index
                  ] as Uint32Array;
                  if (shape === 1) {
                    gl.uniform1uiv(location, bufArray);
                  } else if (shape === 2) {
                    gl.uniform2uiv(location, bufArray);
                  } else if (shape === 3) {
                    gl.uniform3uiv(location, bufArray);
                  } else if (shape === 4) {
                    gl.uniform4uiv(location, bufArray);
                  }
                }
                if (command.buffer_metadata.dtype == 'float32') {
                  let bufArray: Float32Array = convertedBuffers[
                    command.buffer_metadata.index
                  ] as Float32Array;
                  if (shape === 1) {
                    gl.uniform1fv(location, bufArray);
                  } else if (shape === 2) {
                    gl.uniform2fv(location, bufArray);
                  } else if (shape === 3) {
                    gl.uniform3fv(location, bufArray);
                  } else if (shape === 4) {
                    gl.uniform4fv(location, bufArray);
                  }
                }
              } else {
                let a =
                  command.buffer_metadata.shape[
                    command.buffer_metadata.shape.length - 2
                  ];
                let b =
                  command.buffer_metadata.shape[
                    command.buffer_metadata.shape.length - 1
                  ];
                let bufArray: Float32Array = convertedBuffers[
                  command.buffer_metadata.index
                ] as Float32Array;
                if (a == 2) {
                  if (b == 2) {
                    gl.uniformMatrix2fv(location, false, bufArray);
                  } else if (b == 3) {
                    gl.uniformMatrix2x3fv(location, false, bufArray);
                  } else if (b == 4) {
                    gl.uniformMatrix2x4fv(location, false, bufArray);
                  }
                } else if (a == 3) {
                  if (b == 2) {
                    gl.uniformMatrix3x2fv(location, false, bufArray);
                  } else if (b == 3) {
                    gl.uniformMatrix3fv(location, false, bufArray);
                  } else if (b == 4) {
                    gl.uniformMatrix3x4fv(location, false, bufArray);
                  }
                } else if (a == 4) {
                  if (b == 2) {
                    gl.uniformMatrix4x2fv(location, false, bufArray);
                  } else if (b == 3) {
                    gl.uniformMatrix4x3fv(location, false, bufArray);
                  } else if (b == 4) {
                    gl.uniformMatrix4fv(location, false, bufArray);
                  }
                }
              }
            }
          }
        }
        break;
      case 'uniformBlockBinding':
        {
          let res = this.getResource(command.program);
          const ptr = res._gl_ptr as WebGLProgram;
          const uniformBlock = (
            res._info as { type: any; uniformBlocks: any[] }
          ).uniformBlocks.find((element: any) => {
            return element.name == command.uniform_block_name;
          });

          if (uniformBlock !== undefined) {
            gl.uniformBlockBinding(
              ptr,
              uniformBlock.index,
              command.uniform_block_binding,
            );
          }
        }
        break;
      // ------------------------------- BUFFERS --------------------------------------
      case 'createBuffer':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createBuffer();
          res._gl_ptr = ptr;
          res._info = { type: 'Buffer' };
        }
        break;
      case 'bindBuffer':
        {
          const target: string = command.target;
          if (command.buffer >= 0) {
            const res = this.getResource(command.buffer);
            const ptr = res._gl_ptr as WebGLBuffer;
            gl.bindBuffer((gl as any)[target], ptr);
            (this.boundBuffers as any)[target] = res;
          } else {
            gl.bindBuffer((gl as any)[target], null);
            (this.boundBuffers as any)[target] = null;
          }
        }
        break;
      case 'bindBufferBase':
        {
          const target: string = command.target;
          if (command.buffer >= 0) {
            const res = this.getResource(command.buffer);
            const ptr = res._gl_ptr as WebGLBuffer;
            gl.bindBufferBase((gl as any)[target], command.index, ptr);
          } else {
            gl.bindBufferBase((gl as any)[target], command.index, null);
          }
        }
        break;
      case 'bufferData':
        {
          const target: string = command.target;
          const usage: string = command.usage;

          if (command.hasOwnProperty('buffer_metadata')) {
            gl.bufferData(
              (gl as any)[target],
              convertedBuffers[command.buffer_metadata.index],
              (gl as any)[usage],
            );

            let buf = (this.boundBuffers as any)[target];
            if (command.update_info && buf != null) {
              const size = gl.getBufferParameter(
                (gl as any)[target],
                gl.BUFFER_SIZE,
              );
              buf._info = { type: 'Buffer', size: size, target: target };
            }
          } else {
            let buf = (this.boundBuffers as any)[target];
            gl.bufferData((gl as any)[target], null, (gl as any)[usage]);
            if (command.update_info && buf != null) {
              buf._info = { type: 'Buffer', size: 'undefined', target: target };
            }
          }
        }
        break;
      case 'createUniformBuffer':
        {
          const newResource = new GLResource();
          newResource.uid = command.buffer;
          this.registerResource(newResource);

          let res = this.getResource(command.buffer);
          const ptr = gl.createBuffer();

          let info = { type: 'Buffer' };
          const prog = this.getResource(command.program);
          const uniformBlock = (
            prog._info as { type: any; uniformBlocks: any[] }
          ).uniformBlocks.find((element: any) => {
            return element.name == command.block_name;
          });

          if (uniformBlock != undefined) {
            gl.bindBuffer(gl.UNIFORM_BUFFER, ptr);
            gl.bufferData(
              gl.UNIFORM_BUFFER,
              uniformBlock.size,
              (gl as any)[command.usage],
            );
            gl.bindBuffer(gl.UNIFORM_BUFFER, null);
            (this.boundBuffers as any)['UNIFORM_BUFFER'] = null;
            (info as any)['size'] = uniformBlock.size;
            (info as any)['target'] = 'UNIFORM_BUFFER';
            (info as any)['uniformBlock'] = uniformBlock;
          }
          res._gl_ptr = ptr;
          res._info = info;
        }
        break;
      case 'bufferSubData':
      case 'bufferSubDataStr':
        {
          const target: string = command.target;
          let offset = command.dst_byte_offset;
          if (command.cmd == 'bufferSubDataStr') {
            offset = 0;
            let buf = (this.boundBuffers as any)[target];
            if (buf != null) {
              const uniformBlock = (
                buf._info as { type: any; uniformBlock: any }
              ).uniformBlock as { uniforms: any[] };
              const uniform = uniformBlock.uniforms.find((element: any) => {
                return element.name == command.dst_byte_offset;
              });
              if (uniform != undefined) {
                offset = uniform.offset;
              }
            }
          }
          if (command.hasOwnProperty('buffer_metadata')) {
            gl.bufferSubData(
              (gl as any)[target],
              offset,
              convertedBuffers[command.buffer_metadata.index],
              command.src_offset,
            );
          } else {
            gl.bufferSubData((gl as any)[target], offset, command.src_offset);
          }
        }
        break;
      // ------------------------------- VERTEX ARRAYS --------------------------------------
      case 'createVertexArray':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createVertexArray();
          res._gl_ptr = ptr;
          res._info = { type: 'VertexArrayObject', bindings: [] } as any;
        }
        break;
      case 'bindVertexArray':
        {
          if (command.vertex_array >= 0) {
            const res = this.getResource(command.vertex_array);
            const ptr = res._gl_ptr as WebGLVertexArrayObject;
            gl.bindVertexArray(ptr);
            this.boundVao = res;
          } else {
            gl.bindVertexArray(null);
            this.boundVao = null;
          }
        }
        break;
      case 'vertexAttribPointer':
      case 'vertexAttribIPointer':
      case 'enableVertexAttribArray':
      case 'disableVertexAttribArray':
      case 'vertexAttrib[1234]fv':
      case 'vertexAttribI4[u]iv':
      case 'vertexAttribDivisor':
        {
          let index = -1;
          if (typeof command.index === 'number') {
            index = command.index;
          } else {
            if (this.boundProgram != null) {
              const attr = (
                this.boundProgram._info as { type: any; attributes: any[] }
              ).attributes.find((element: any) => {
                return element.name == command.index;
              });

              if (attr != undefined) {
                index = attr.location;
              }
            } else {
              console.error('a program must be bound to find the attribute');
            }
          }

          let buf = (this.boundBuffers as any)['ARRAY_BUFFER'];
          if (index >= 0) {
            index += command.index_offset;
            if (command.cmd == 'vertexAttribIPointer') {
              gl.vertexAttribIPointer(
                index,
                command.size,
                (gl as any)[command.type],
                command.stride,
                command.offset,
              );
              if (this.boundVao != null && buf != null) {
                let vaoInfo = this.boundVao._info as {
                  type: any;
                  bindings: any[];
                };
                const bufferUid = buf.uid;
                let bindingInfo = vaoInfo.bindings.find((element: any) => {
                  return element.buffer_uid == bufferUid;
                });
                if (bindingInfo == undefined) {
                  bindingInfo = { buffer_uid: bufferUid, attributes: [] };
                  vaoInfo.bindings.push(bindingInfo);
                }
                bindingInfo.attributes.push({
                  pointer: 'vertexAttribIPointer',
                  index: index,
                  size: command.size,
                  type: command.type,
                  stride: command.stride,
                  offset: command.offset,
                });
                this.boundVao._info = vaoInfo;
              }
            } else if (command.cmd == 'vertexAttribPointer') {
              gl.vertexAttribPointer(
                index,
                command.size,
                (gl as any)[command.type],
                command.normalized,
                command.stride,
                command.offset,
              );
              if (this.boundVao != null && buf != null) {
                let vaoInfo = this.boundVao._info as {
                  type: any;
                  bindings: any[];
                };
                const bufferUid = buf.uid;
                let bindingInfo = vaoInfo.bindings.find((element: any) => {
                  return element.buffer_uid == bufferUid;
                });
                if (bindingInfo == undefined) {
                  bindingInfo = { buffer_uid: bufferUid, attributes: [] };
                  vaoInfo.bindings.push(bindingInfo);
                }
                bindingInfo.attributes.push({
                  pointer: 'vertexAttribPointer',
                  index: index,
                  size: command.size,
                  type: command.type,
                  normalized: command.normalized,
                  stride: command.stride,
                  offset: command.offset,
                });
                this.boundVao._info = vaoInfo;
              }
            } else if (command.cmd == 'enableVertexAttribArray') {
              gl.enableVertexAttribArray(index);
            } else if (command.cmd == 'disableVertexAttribArray') {
              gl.disableVertexAttribArray(index);
            } else if (command.cmd == 'vertexAttrib[1234]fv') {
              if (command.buffer_metadata.shape[0] == 1) {
                gl.vertexAttrib1fv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              } else if (command.buffer_metadata.shape[0] == 2) {
                gl.vertexAttrib2fv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              } else if (command.buffer_metadata.shape[0] == 3) {
                gl.vertexAttrib3fv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              } else if (command.buffer_metadata.shape[0] == 4) {
                gl.vertexAttrib4fv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              }
            } else if (command.cmd == 'vertexAttribI4[u]iv') {
              if (command.buffer_metadata.dtype == 'uint32') {
                gl.vertexAttribI4uiv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              } else if (command.buffer_metadata.dtype == 'int32') {
                gl.vertexAttribI4iv(
                  index,
                  convertedBuffers[command.buffer_metadata.index],
                );
              }
            } else if (command.cmd == 'vertexAttribDivisor') {
              gl.vertexAttribDivisor(index, command.divisor);
            }
          } else {
            console.error(`attribute ${command.index} location not found`);
          }
        }
        break;

      // ------------------------------- RENDER --------------------------------------
      case 'drawArrays':
        {
          gl.drawArrays(
            (gl as any)[command.mode],
            command.first,
            command.count,
          );
        }
        break;
      case 'drawArraysInstanced':
        {
          gl.drawArraysInstanced(
            (gl as any)[command.mode],
            command.first,
            command.count,
            command.instance_count,
          );
        }
        break;
      case 'drawElements':
        {
          gl.drawElements(
            (gl as any)[command.mode],
            command.count,
            (gl as any)[command.byte_type],
            command.offset,
          );
        }
        break;
      case 'drawElementsInstanced':
        {
          gl.drawElementsInstanced(
            (gl as any)[command.mode],
            command.count,
            (gl as any)[command.byte_type],
            command.offset,
            command.instance_count,
          );
        }
        break;
      // ------------------------------- FRAMEBUFFER --------------------------------------
      case 'createFramebuffer':
        {
          const newResource = new GLResource();
          newResource.uid = command.resource;
          this.registerResource(newResource);

          let res = this.getResource(command.resource);
          const ptr = gl.createFramebuffer();
          res._gl_ptr = ptr;
          res._info = { type: 'Framebuffer' };
        }
        break;
      case 'bindFramebuffer':
        {
          if (command.framebuffer >= 0) {
            let res = this.getResource(command.framebuffer);
            gl.bindFramebuffer(
              (gl as any)[command.target],
              res._gl_ptr as WebGLFramebuffer,
            );
          } else {
            gl.bindFramebuffer((gl as any)[command.target], null);
          }
        }
        break;
      case 'framebufferTexture2D':
        {
          let res = this.getResource(command.texture);
          gl.framebufferTexture2D(
            (gl as any)[command.target],
            (gl as any)[command.attachment],
            (gl as any)[command.textarget],
            res._gl_ptr as WebGLTexture,
            command.level,
          );
        }
        break;
      case 'drawBuffers':
        {
          const buffers = command.buffers.map((element: any) => {
            return (gl as any)[element];
          });
          gl.drawBuffers(buffers);
        }
        break;
    }
  }

  private executeCommands(
    model: AnyModel,
    commands: any[],
    convertedBuffers: any[],
  ): void {
    if (this.ctx === null) {
      return;
    }

    const gl: WebGL2RenderingContext = this.ctx;

    this.captureFrame();

    // update camera
    this.updateCamera(model);

    // update the uniform block:
    const isRowMajor: boolean = model.get('shader_matrix_major') == 'row_major';
    let cm = isRowMajor ? m4Transpose(this.cameraMatrix) : this.cameraMatrix;
    const cm_f32 = new Float32Array(cm);
    let vm = isRowMajor ? m4Transpose(this.viewMatrix) : this.viewMatrix;
    const vm_f32 = new Float32Array(vm);
    let pm = isRowMajor
      ? m4Transpose(this.projectionMatrix)
      : this.projectionMatrix;
    const pm_f32 = new Float32Array(pm);
    let vpm = isRowMajor
      ? m4Transpose(this.viewProjMatrix)
      : this.viewProjMatrix;
    const vpm_f32 = new Float32Array(vpm);

    gl.bindBuffer(gl.UNIFORM_BUFFER, this.viewBlock);
    gl.bufferSubData(gl.UNIFORM_BUFFER, 0, cm_f32, 0);
    gl.bufferSubData(gl.UNIFORM_BUFFER, 64, vm_f32, 0);
    gl.bufferSubData(gl.UNIFORM_BUFFER, 128, pm_f32, 0);
    gl.bufferSubData(gl.UNIFORM_BUFFER, 192, vpm_f32, 0);
    gl.bindBuffer(gl.UNIFORM_BUFFER, null);

    commands.forEach((command: any) => {
      this.executeCommand(model, gl, command, convertedBuffers);
    });

    if (model.get('sync_image_data')) {
      const width = model.get('width');
      const height = model.get('height');
      const pixels = new Uint8ClampedArray(width * height * 4);
      gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      model.set('image_data', pixels);
      model.save_changes();
    }
  }

  private handleCustomMessages(
    model: AnyModel,
    command: any,
    buffers: any,
  ): void {
    if (command.clear == true) {
      this.commands = [];
      this.buffers = [];
    }

    let commands = command.commands;
    let convertedBuffers: any[] = [];
    commands.forEach((element: any) => {
      if (element.hasOwnProperty('buffer_metadata')) {
        const converted = bufferToArray(
          element.buffer_metadata.dtype,
          buffers[element.buffer_metadata.index].buffer,
        );
        convertedBuffers.push(converted);
      }
    });

    // only execute once
    if (command.only_once == true) {
      this.executeCommands(model, commands, convertedBuffers);
      return;
    }

    // persistent execution by accmulating separate buffers
    let bufferIdOffset = this.buffers.length;
    this.buffers = this.buffers.concat(convertedBuffers);
    commands.forEach((element: any) => {
      if (element.hasOwnProperty('buffer_metadata')) {
        element.buffer_metadata.index += bufferIdOffset;
      }
    });

    this.commands = this.commands.concat(commands);
    this.runCommands(model);
  }

  private runCommands(model: AnyModel) {
    this.executeCommands(model, this.commands, this.buffers);
  }

  private registerResource(resource: GLResource): void {
    if (resource.uid !== this.resources.length) {
      console.error('uid not matching what we have internally');
    }
    this.resources.push(resource);
  }

  private getResource(index: number) {
    return this.resources[index];
  }

  public getResourceInfo(index: number): any {
    if (index < 0 || index >= this.resources.length) {
      return null;
    }
    return this.resources[index]._info;
  }

  private renderResizeCanvas(model: AnyModel): void {
    this.canvas.setAttribute('width', model.get('width'));
    this.canvas.setAttribute('height', model.get('height'));
    this.resizeCanvas(model);
  }

  private requestRedraw(model: AnyModel): void {
    if (this.willRedraw == false) {
      this.willRedraw = true;
      requestAnimationFrame(() => this.redraw(model));
    }
  }

  private redraw(model: AnyModel): void {
    this.willRedraw = false;

    // update movement if needed
    if (
      this.moveDirection[0] ||
      this.moveDirection[1] ||
      this.moveDirection[2] ||
      this.moveDirection[3]
    ) {
      let speed = model.get('move_speed');
      let forwardAxis = m4GetColumnK(this.cameraMatrix);
      let sideAxis = m4GetColumnI(this.cameraMatrix);
      let cameraPos = model.get('camera_pos');
      if (this.moveDirection[0]) {
        cameraPos = v3Add(cameraPos, v3Scale(forwardAxis, -speed));
      }
      if (this.moveDirection[2]) {
        cameraPos = v3Add(cameraPos, v3Scale(forwardAxis, speed));
      }
      if (this.moveDirection[1]) {
        cameraPos = v3Add(cameraPos, v3Scale(sideAxis, -speed));
      }
      if (this.moveDirection[3]) {
        cameraPos = v3Add(cameraPos, v3Scale(sideAxis, speed));
      }
      model.set('camera_pos', cameraPos);
      model.save_changes();

      // request a new frame if we are moving:
      this.requestRedraw(model);
    }
  }

  private onMouseMove(model: AnyModel, event: MouseEvent): void {
    if (this.isMouseDown) {
      let speed = model.get('mouse_speed');
      model.set(
        'camera_yaw',
        model.get('camera_yaw') - event.movementX * 0.1 * speed,
      );
      model.set(
        'camera_pitch',
        model.get('camera_pitch') - event.movementY * 0.1 * speed,
      );
      model.save_changes();
      this.requestRedraw(model);
    }
  }

  private onMouseDown(event: MouseEvent): void {
    this.isMouseDown = true;
    this.canvas.focus();
  }

  private onMouseUp(event: MouseEvent): void {
    this.isMouseDown = false;
  }

  private onMouseOut(event: MouseEvent): void {
    this.isMouseDown = false;
    this.moveDirection = [false, false, false, false];
  }

  private async onKeyDown(
    model: AnyModel,
    event: KeyboardEvent,
  ): Promise<void> {
    event.preventDefault();
    event.stopPropagation();

    let keys = model.get('move_keys');
    let captureKey = model.get('capture_frame_key');

    if (event.repeat == false) {
      if (event.key == keys[0]) {
        this.moveDirection[0] = true;
        this.requestRedraw(model);
      } else if (event.key == keys[1]) {
        this.moveDirection[1] = true;
        this.requestRedraw(model);
      } else if (event.key == keys[2]) {
        this.moveDirection[2] = true;
        this.requestRedraw(model);
      } else if (event.key == keys[3]) {
        this.moveDirection[3] = true;
        this.requestRedraw(model);
      } else if (event.key == captureKey) {
        await this.requestSpectorStart();
        this.runCommands(model);
        requestAnimationFrame(() => {
          this.requestSpectorStop();
        });
      }
    }
  }

  private onKeyUp(model: AnyModel, event: KeyboardEvent): void {
    event.preventDefault();
    event.stopPropagation();

    let keys = model.get('move_keys');
    if (event.key == keys[0]) {
      this.moveDirection[0] = false;
    } else if (event.key == keys[1]) {
      this.moveDirection[1] = false;
    } else if (event.key == keys[2]) {
      this.moveDirection[2] = false;
    } else if (event.key == keys[3]) {
      this.moveDirection[3] = false;
    }
  }

  public render(model: AnyModel, el: HTMLElement): void {
    el.appendChild(this.canvas);

    this.renderResizeCanvas(model);

    ['width', 'height'].forEach((p) =>
      model.on(`change:${p}`, () => this.renderResizeCanvas(model)),
    );

    el.addEventListener('mousemove', (event) => this.onMouseMove(model, event));
    el.addEventListener('mousedown', (event) => this.onMouseDown(event));
    el.addEventListener('mouseup', (event) => this.onMouseUp(event));
    el.addEventListener('mouseout', (event) => this.onMouseOut(event));
    el.addEventListener('keydown', (event) => this.onKeyDown(model, event));
    el.addEventListener('keyup', (event) => this.onKeyUp(model, event));

    el.setAttribute('tabindex', '0');
  }

  private async getSpectorInstance() {
    if (this.spector) {
      return this.spector;
    }

    const S = await ensureSpector();
    this.spector = new S.Spector();

    this.spector.onCaptureStarted.add((info: any) => {
      console.log('[spector] capture started', info);
    });

    this.spector.onError.add((error: any) => {
      console.error('[spector] error', error);
    });

    if (!this.spectorSpied) {
      try {
        this.spector.spyCanvas();
      } catch (e) {
        /* if the canvas is already spied, skip it */
      }
      this.spectorSpied = true;
    }

    this.spector.onCapture.add((capture: any) => {
      try {
        const blob = new Blob([JSON.stringify(capture, null, 2)], {
          type: 'application/json',
        });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'spector_capture.json';
        a.click();
      } catch (e) {
        console.warn('spector capture download failed: ', e);
      }
    });
    return this.spector;
  }

  public async requestSpectorCaptureNext(quick = false) {
    // wait until spector is initialized
    await this.getSpectorInstance();
    this.spectorAutoOnce = true;
  }

  public async requestSpectorStart(commandCount = 50000, quick = false) {
    // wait until spector is initialized
    const S = await this.getSpectorInstance();
    S.startCapture(this.ctx, commandCount, quick);
    this.spectorActive = true;
  }

  public async requestSpectorStop() {
    // wait until spector is initialized
    const S = await this.getSpectorInstance();
    if (this.spectorActive) {
      S.stopCapture();
      this.spectorActive = false;
    }
  }

  private captureFrame() {
    if (!this.spector || !this.ctx) {
      return;
    }
    if (this.spectorAutoOnce) {
      this.spectorAutoOnce = false;
      this.spector.captureNextFrame(this.ctx);
    }
  }
}

// export the singleton instance
export const glContext = GLContext.getInstance();
