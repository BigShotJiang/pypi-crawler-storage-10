/******/ var __webpack_modules__ = ({

/***/ 350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   glContext: () => (/* binding */ glContext)
/* harmony export */ });
// spector bundle lazy loading:
async function ensureSpector() {
    if (window.SPECTOR) {
        return window.SPECTOR;
    }
    await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://unpkg.com/spectorjs/dist/spector.bundle.js';
        s.onload = () => resolve();
        s.onerror = () => reject(new Error('Failed to load SpectorJS'));
        document.head.appendChild(s);
    });
    return window.SPECTOR;
}
function bufferToArray(dtype, buffer) {
    let array = null;
    switch (dtype) {
        case 'int8':
            array = new Int8Array(buffer);
            break;
        case 'uint8':
            array = new Uint8Array(buffer);
            break;
        case 'int16':
            array = new Int16Array(buffer);
            break;
        case 'uint16':
            array = new Uint16Array(buffer);
            break;
        case 'int32':
            array = new Int32Array(buffer);
            break;
        case 'uint32':
            array = new Uint32Array(buffer);
            break;
        case 'float32':
            array = new Float32Array(buffer);
            break;
        case 'float64':
            array = new Float64Array(buffer);
            break;
        default:
            throw new Error(`Unsupported dtype: ${dtype}`);
    }
    return array;
}
function m4Frustum(left, right, bottom, top, near, far) {
    const a = (right + left) / (right - left);
    const b = (top + bottom) / (top - bottom);
    const c = -(far + near) / (far - near);
    const d = (-2 * far * near) / (far - near);
    const e = (2 * near) / (right - left);
    const f = (2 * near) / (top - bottom);
    return [e, 0, a, 0, 0, f, b, 0, 0, 0, c, d, 0, 0, -1, 0];
}
function m4ProjectionMatrix(fovY, aspectRatio, near, far) {
    const ymax = near * Math.tan((fovY * Math.PI) / 360.0);
    const xmax = ymax * aspectRatio;
    return m4Frustum(-xmax, xmax, -ymax, ymax, near, far);
}
function m4OrthoProjectionMatrix(width, height, near, far) {
    const a = 1 / width;
    const b = 1 / height;
    const c = -(far + near) / (far - near);
    const d = -2 / (far - near);
    return [a, 0, 0, 0, 0, b, 0, 0, 0, 0, c, d, 0, 0, 0, 1];
}
function m4Transpose(m) {
    return [
        m[0],
        m[4],
        m[8],
        m[12],
        m[1],
        m[5],
        m[9],
        m[13],
        m[2],
        m[6],
        m[10],
        m[14],
        m[3],
        m[7],
        m[11],
        m[15],
    ];
}
function m4GetTranslation(m) {
    return [m[3], m[7], m[11]];
}
function m4GetColumnI(m) {
    return [m[0], m[4], m[8]];
}
function m4GetColumnJ(m) {
    return [m[1], m[5], m[9]];
}
function m4GetColumnK(m) {
    return [m[2], m[6], m[10]];
}
function m4GetColumnL(m) {
    return [m[3], m[7], m[11]];
}
function v3Add(a, b) {
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
function v3Scale(a, scale) {
    return [a[0] * scale, a[1] * scale, a[2] * scale];
}
function m4Translation(tx, ty, tz) {
    return [1, 0, 0, tx, 0, 1, 0, ty, 0, 0, 1, tz, 0, 0, 0, 1];
}
function m4XRotation(angleInRadians) {
    var c = Math.cos(angleInRadians);
    var s = Math.sin(angleInRadians);
    return [1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1];
}
function m4YRotation(angleInRadians) {
    var c = Math.cos(angleInRadians);
    var s = Math.sin(angleInRadians);
    return [c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1];
}
function m4ZRotation(angleInRadians) {
    var c = Math.cos(angleInRadians);
    var s = Math.sin(angleInRadians);
    return [c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0];
}
function m4Scale(sx, sy, sz) {
    return [sx, 0, 0, 0, 0, sy, 0, 0, 0, 0, sz, 0, 0, 0, 0, 1];
}
function m4Dot(b, a) {
    return [
        b[0] * a[0] + b[1] * a[4] + b[2] * a[8] + b[3] * a[12],
        b[0] * a[1] + b[1] * a[5] + b[2] * a[9] + b[3] * a[13],
        b[0] * a[2] + b[1] * a[6] + b[2] * a[10] + b[3] * a[14],
        b[0] * a[3] + b[1] * a[7] + b[2] * a[11] + b[3] * a[15],
        b[4] * a[0] + b[5] * a[4] + b[6] * a[8] + b[7] * a[12],
        b[4] * a[1] + b[5] * a[5] + b[6] * a[9] + b[7] * a[13],
        b[4] * a[2] + b[5] * a[6] + b[6] * a[10] + b[7] * a[14],
        b[4] * a[3] + b[5] * a[7] + b[6] * a[11] + b[7] * a[15],
        b[8] * a[0] + b[9] * a[4] + b[10] * a[8] + b[11] * a[12],
        b[8] * a[1] + b[9] * a[5] + b[10] * a[9] + b[11] * a[13],
        b[8] * a[2] + b[9] * a[6] + b[10] * a[10] + b[11] * a[14],
        b[8] * a[3] + b[9] * a[7] + b[10] * a[11] + b[11] * a[15],
        b[12] * a[0] + b[13] * a[4] + b[14] * a[8] + b[15] * a[12],
        b[12] * a[1] + b[13] * a[5] + b[14] * a[9] + b[15] * a[13],
        b[12] * a[2] + b[13] * a[6] + b[14] * a[10] + b[15] * a[14],
        b[12] * a[3] + b[13] * a[7] + b[14] * a[11] + b[15] * a[15],
    ];
}
function m4Inverse(m) {
    var tmp_0 = m[10] * m[15];
    var tmp_1 = m[14] * m[11];
    var tmp_2 = m[6] * m[15];
    var tmp_3 = m[14] * m[7];
    var tmp_4 = m[6] * m[11];
    var tmp_5 = m[10] * m[7];
    var tmp_6 = m[2] * m[15];
    var tmp_7 = m[14] * m[3];
    var tmp_8 = m[2] * m[11];
    var tmp_9 = m[10] * m[3];
    var tmp_10 = m[2] * m[7];
    var tmp_11 = m[6] * m[3];
    var tmp_12 = m[8] * m[13];
    var tmp_13 = m[12] * m[9];
    var tmp_14 = m[4] * m[13];
    var tmp_15 = m[12] * m[5];
    var tmp_16 = m[4] * m[9];
    var tmp_17 = m[8] * m[5];
    var tmp_18 = m[0] * m[13];
    var tmp_19 = m[12] * m[1];
    var tmp_20 = m[0] * m[9];
    var tmp_21 = m[8] * m[1];
    var tmp_22 = m[0] * m[5];
    var tmp_23 = m[4] * m[1];
    var t0 = tmp_0 * m[5] +
        tmp_3 * m[9] +
        tmp_4 * m[13] -
        (tmp_1 * m[5] + tmp_2 * m[9] + tmp_5 * m[13]);
    var t1 = tmp_1 * m[1] +
        tmp_6 * m[9] +
        tmp_9 * m[13] -
        (tmp_0 * m[1] + tmp_7 * m[9] + tmp_8 * m[13]);
    var t2 = tmp_2 * m[1] +
        tmp_7 * m[5] +
        tmp_10 * m[13] -
        (tmp_3 * m[1] + tmp_6 * m[5] + tmp_11 * m[13]);
    var t3 = tmp_5 * m[1] +
        tmp_8 * m[5] +
        tmp_11 * m[9] -
        (tmp_4 * m[1] + tmp_9 * m[5] + tmp_10 * m[9]);
    var d = 1.0 / (m[0] * t0 + m[4] * t1 + m[8] * t2 + m[12] * t3);
    return [
        d * t0,
        d * t1,
        d * t2,
        d * t3,
        d *
            (tmp_1 * m[4] +
                tmp_2 * m[8] +
                tmp_5 * m[12] -
                (tmp_0 * m[4] + tmp_3 * m[8] + tmp_4 * m[12])),
        d *
            (tmp_0 * m[0] +
                tmp_7 * m[8] +
                tmp_8 * m[12] -
                (tmp_1 * m[0] + tmp_6 * m[8] + tmp_9 * m[12])),
        d *
            (tmp_3 * m[0] +
                tmp_6 * m[4] +
                tmp_11 * m[12] -
                (tmp_2 * m[0] + tmp_7 * m[4] + tmp_10 * m[12])),
        d *
            (tmp_4 * m[0] +
                tmp_9 * m[4] +
                tmp_10 * m[8] -
                (tmp_5 * m[0] + tmp_8 * m[4] + tmp_11 * m[8])),
        d *
            (tmp_12 * m[7] +
                tmp_15 * m[11] +
                tmp_16 * m[15] -
                (tmp_13 * m[7] + tmp_14 * m[11] + tmp_17 * m[15])),
        d *
            (tmp_13 * m[3] +
                tmp_18 * m[11] +
                tmp_21 * m[15] -
                (tmp_12 * m[3] + tmp_19 * m[11] + tmp_20 * m[15])),
        d *
            (tmp_14 * m[3] +
                tmp_19 * m[7] +
                tmp_22 * m[15] -
                (tmp_15 * m[3] + tmp_18 * m[7] + tmp_23 * m[15])),
        d *
            (tmp_17 * m[3] +
                tmp_20 * m[7] +
                tmp_23 * m[11] -
                (tmp_16 * m[3] + tmp_21 * m[7] + tmp_22 * m[11])),
        d *
            (tmp_14 * m[10] +
                tmp_17 * m[14] +
                tmp_13 * m[6] -
                (tmp_16 * m[14] + tmp_12 * m[6] + tmp_15 * m[10])),
        d *
            (tmp_20 * m[14] +
                tmp_12 * m[2] +
                tmp_19 * m[10] -
                (tmp_18 * m[10] + tmp_21 * m[14] + tmp_13 * m[2])),
        d *
            (tmp_18 * m[6] +
                tmp_23 * m[14] +
                tmp_15 * m[2] -
                (tmp_22 * m[14] + tmp_14 * m[2] + tmp_19 * m[6])),
        d *
            (tmp_22 * m[10] +
                tmp_16 * m[2] +
                tmp_21 * m[6] -
                (tmp_20 * m[6] + tmp_23 * m[10] + tmp_17 * m[2])),
    ];
}
/** generic singleton class (my preferrable version of using singleton pattern regardless of languages) */
class Singleton {
    constructor() {
        const constructor = this.constructor;
        if (Singleton.instances.has(constructor)) {
            return Singleton.instances.get(constructor);
        }
        Singleton.instances.set(constructor, this);
    }
    static getInstance() {
        const globalKey = Symbol.for(`__singleton__:${this.name}`);
        const g = globalThis;
        g.__registry ?? (g.__registry = new Map());
        const reg = g.__registry;
        if (reg.has(globalKey)) {
            return reg.get(globalKey);
        }
        if (!Singleton.instances.has(this)) {
            new this();
        }
        const inst = Singleton.instances.get(this);
        reg.set(globalKey, inst);
        return inst;
    }
}
Singleton.instances = new Map();
class GLResource {
    constructor() {
        /**
         * internal state
         * - _gl_ptr: the pointer to WebGL2 resource object
         * - _info: the type of WebGL2 resource object
         */
        this._gl_ptr = null;
        this._info = { type: 'not set' };
        this.uid = -1;
    }
}
/** independent gl-context instance manages canvas and webgl in JS side */
class GLContext extends Singleton {
    constructor() {
        // we inherit from singleton class, so need to call super()
        super();
        /** resources managed by this context */
        this.resources = [];
        this.boundBuffers = {};
        this.commands = [];
        this.buffers = [];
        /** matrix state */
        this.projectionMatrix = [];
        this.cameraMatrix = [];
        this.viewMatrix = [];
        this.viewProjMatrix = [];
        /** viewer properties */
        this.isMouseDown = false;
        this.moveDirection = [false, false, false, false];
        this.willRedraw = false;
        /** webgl2 spectorJS (for graphics frame debugger) */
        this.spector = null;
        this.spectorAutoOnce = false;
        this.spectorActive = false;
        this.spectorSpied = false;
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('webgl2', {
            preserveDrawingBuffer: true,
        });
        this.viewBlock = null;
        if (this.ctx === null) {
            console.error('could not create WebGL2 context, this is not supported by your browser');
        }
        else {
            const gl = this.ctx;
            this.viewBlock = gl.createBuffer();
            gl.bindBuffer(gl.UNIFORM_BUFFER, this.viewBlock);
            gl.bufferData(gl.UNIFORM_BUFFER, 256, gl.DYNAMIC_DRAW);
            gl.bindBuffer(gl.UNIFORM_BUFFER, null);
            gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, this.viewBlock);
            // extensions to activate
            gl.getExtension('EXT_color_buffer_float');
            console.log('WebGL2 context is successfully created');
        }
        // clear bound program state
        this.boundProgram = null;
        this.boundVao = null;
    }
    initialize(model) {
        // resize canvas with model's info
        this.resizeCanvas(model);
        // listen to model's changes
        ['width', 'height', 'camera_fov', 'camera_near', 'camera_far'].forEach((p) => model.on(`change:${p}`, () => this.resizeCanvas(model)));
        // listen json-type message events
        // - see python code: GLViewer.execute_commands()
        model.on('msg:custom', (msg, buffers) => {
            this.handleCustomMessages(model, msg, buffers);
        });
        ['camera_pos', 'camera_yaw', 'camera_pitch'].forEach((p) => model.on(`change:${p}`, () => this.runCommands(model)));
        this.cameraMatrix = m4Translation(0, 50, 200);
        this.viewMatrix = m4Inverse(this.cameraMatrix);
        console.log('GLContext.initialize() is called successfully');
    }
    resizeCanvas(model) {
        const width = model.get('width');
        const height = model.get('height');
        this.canvas.setAttribute('width', width.toString());
        this.canvas.setAttribute('height', height.toString());
        if (this.ctx !== null) {
            this.ctx.viewport(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
        }
        this.projectionMatrix = m4ProjectionMatrix(model.get('camera_fov'), width / height, model.get('camera_near'), model.get('camera_far'));
    }
    updateCamera(model) {
        let pos = model.get('camera_pos');
        let yaw = model.get('camera_yaw');
        let pitch = model.get('camera_pitch');
        this.cameraMatrix = m4Translation(pos[0], pos[1], pos[2]);
        this.cameraMatrix = m4Dot(this.cameraMatrix, m4YRotation(yaw));
        this.cameraMatrix = m4Dot(this.cameraMatrix, m4XRotation(pitch));
        this.viewMatrix = m4Inverse(this.cameraMatrix);
        this.viewProjMatrix = m4Dot(this.projectionMatrix, this.viewMatrix);
    }
    glEnumToString(gl, value) {
        const keys = [];
        for (const key in gl) {
            if (gl[key] === value) {
                keys.push(key);
            }
        }
        return keys.length ? keys.join(' | ') : `0x${value.toString(16)}`;
    }
    executeCommand(model, gl, command, convertedBuffers) {
        if (model.get('verbose') > 0) {
            console.log(command);
            if (command.hasOwnProperty('buffer_metadata')) {
                console.log('data');
                console.log(convertedBuffers[command.buffer_metadata.index]);
            }
        }
        switch (command.cmd) {
            case 'viewport':
                gl.viewport(command.x, command.y, command.width, command.height);
                break;
            case 'enable':
            case 'disable':
                {
                    let cap = 0;
                    if (command.blend)
                        cap |= gl.BLEND;
                    if (command.depth_test)
                        cap |= gl.DEPTH_TEST;
                    if (command.dither)
                        cap |= gl.DITHER;
                    if (command.polygon_offset_fill)
                        cap |= gl.POLYGON_OFFSET_FILL;
                    if (command.sample_alpha_to_coverage)
                        cap |= gl.SAMPLE_ALPHA_TO_COVERAGE;
                    if (command.sample_coverage)
                        cap |= gl.SAMPLE_COVERAGE;
                    if (command.scissor_test)
                        cap |= gl.SCISSOR_TEST;
                    if (command.stencil_test)
                        cap |= gl.STENCIL_TEST;
                    if (command.rasterizer_discard)
                        cap |= gl.RASTERIZER_DISCARD;
                    if (command.cull_face)
                        cap |= gl.CULL_FACE;
                    if (command.cmd == 'enable') {
                        gl.enable(cap);
                    }
                    else {
                        gl.disable(cap);
                    }
                }
                break;
            case 'clearColor':
                gl.clearColor(command.r, command.g, command.b, command.a);
                break;
            case 'clear':
                {
                    let bits = 0;
                    if (command.depth)
                        bits |= gl.DEPTH_BUFFER_BIT;
                    if (command.color)
                        bits |= gl.COLOR_BUFFER_BIT;
                    if (command.stencil)
                        bits |= gl.STENCIL_BUFFER_BIT;
                    gl.clear(bits);
                }
                break;
            case 'frontFace':
                {
                    gl.frontFace(gl[command.mode]);
                }
                break;
            case 'cullFace':
                {
                    gl.cullFace(gl[command.mode]);
                }
                break;
            //------------------------------- DEPTH --------------------------------------
            case 'depthFunc':
                {
                    gl.depthFunc(gl[command.func]);
                }
                break;
            case 'depthMask':
                {
                    gl.depthMask(command.flag);
                }
                break;
            case 'depthRange':
                {
                    gl.depthRange(command.z_near, command.z_far);
                }
                break;
            //------------------------------- COLOR --------------------------------------
            case 'createTexture':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createTexture();
                    res._gl_ptr = ptr;
                    res._info = { type: 'texture' };
                }
                break;
            case 'bindTexture':
                {
                    if (command.texture > -1) {
                        const texture = this.getResource(command.texture)._gl_ptr;
                        gl.bindTexture(gl[command.target], texture);
                    }
                    else {
                        gl.bindTexture(gl[command.target], null);
                    }
                }
                break;
            case 'activeTexture':
                gl.activeTexture(gl.TEXTURE0 + command.texture);
                break;
            case 'generateMipmap':
                gl.generateMipmap(gl[command.target]);
                break;
            case 'texImage2D':
                {
                    if (command.hasOwnProperty('buffer_metadata')) {
                        gl.texImage2D(gl[command.target], command.level, gl[command.internal_format], command.width, command.height, command.border, gl[command.format], gl[command.data_type], convertedBuffers[command.buffer_metadata.index]);
                    }
                    else {
                        gl.texImage2D(gl[command.target], command.level, gl[command.internal_format], command.width, command.height, command.border, gl[command.format], gl[command.data_type], null);
                    }
                }
                break;
            case 'texStorage2D':
                {
                    gl.texStorage2D(gl[command.target], command.levels, gl[command.internal_format], command.width, command.height);
                }
                break;
            case 'texImage3D':
                {
                    if (command.hasOwnProperty('buffer_metadata')) {
                        gl.texImage3D(gl[command.target], command.level, gl[command.internal_format], command.width, command.height, command.depth, command.border, gl[command.format], gl[command.data_type], convertedBuffers[command.buffer_metadata.index]);
                    }
                    else {
                        gl.texImage3D(gl[command.target], command.level, gl[command.internal_format], command.width, command.height, command.depth, command.border, gl[command.format], gl[command.data_type], null);
                    }
                }
                break;
            case 'texStorage3D':
                {
                    gl.texStorage3D(gl[command.target], command.levels, gl[command.internal_format], command.width, command.height, command.depth);
                }
                break;
            case 'texParameteri':
                gl.texParameteri(gl[command.target], gl[command.pname], command.param);
                break;
            case 'texParameterf':
                gl.texParameterf(gl[command.target], gl[command.pname], command.param);
                break;
            case 'texParameter_str':
                gl.texParameteri(gl[command.target], gl[command.pname], gl[command.param]);
                break;
            case 'pixelStorei':
                {
                    if (command.pname == 'UNPACK_COLORSPACE_CONVERSION_WEBGL') {
                        gl.pixelStorei(gl[command.pname], gl[command.param]);
                    }
                    else {
                        gl.pixelStorei(gl[command.pname], command.param);
                    }
                }
                break;
            // ------------------------------- SHADERS --------------------------------------
            case 'createShader':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createShader(gl[command.type]);
                    res._gl_ptr = ptr;
                    res._info = { type: 'shader' };
                }
                break;
            case 'shaderSource':
                {
                    const res = this.getResource(command.shader);
                    const ptr = res._gl_ptr;
                    gl.shaderSource(ptr, command.source);
                }
                break;
            case 'compileShader':
                {
                    const res = this.getResource(command.shader);
                    const ptr = res._gl_ptr;
                    gl.compileShader(ptr);
                    let resInfo = res._info;
                    if (!gl.getShaderParameter(ptr, gl.COMPILE_STATUS)) {
                        let info = gl.getShaderInfoLog(ptr);
                        resInfo.message = info || '';
                        // leave error log:
                        console.log(resInfo);
                    }
                    else {
                        resInfo.message = 'compiled';
                    }
                    res._info = resInfo;
                }
                break;
            // ------------------------------- PROGRAMS --------------------------------------
            case 'createProgram':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createProgram();
                    res._gl_ptr = ptr;
                    res._info = { type: 'program' };
                }
                break;
            case 'attachShader':
                {
                    const prog = this.getResource(command.program)
                        ._gl_ptr;
                    const shader = this.getResource(command.shader)
                        ._gl_ptr;
                    gl.attachShader(prog, shader);
                }
                break;
            case 'bindAttribLocation':
                {
                    let res = this.getResource(command.program);
                    const ptr = res._gl_ptr;
                    gl.bindAttribLocation(ptr, command.index, command.name);
                }
                break;
            case 'linkProgram':
                {
                    let res = this.getResource(command.program);
                    const ptr = res._gl_ptr;
                    gl.linkProgram(ptr);
                    gl.validateProgram(ptr);
                    let resInfo = res._info;
                    if (!gl.getProgramParameter(ptr, gl.LINK_STATUS)) {
                        let info = gl.getShaderInfoLog(ptr);
                        resInfo.message = info || '';
                    }
                    else {
                        // bind our view-block:
                        let viewBlockIndex = gl.getUniformBlockIndex(ptr, 'ViewBlock');
                        if (viewBlockIndex < 4294967295) {
                            gl.uniformBlockBinding(ptr, viewBlockIndex, 0);
                        }
                        resInfo.message = 'linked';
                        resInfo.uniformBlocks = [];
                        resInfo.uniforms = [];
                        const numUniforms = gl.getProgramParameter(ptr, gl.ACTIVE_UNIFORMS);
                        const indices = [...Array(numUniforms).keys()];
                        const blockIndices = gl.getActiveUniforms(ptr, indices, gl.UNIFORM_BLOCK_INDEX);
                        const offsets = gl.getActiveUniforms(ptr, indices, gl.UNIFORM_OFFSET);
                        for (let i = 0; i < numUniforms; ++i) {
                            const info = gl.getActiveUniform(ptr, i);
                            if (info) {
                                // regroup the blocks:
                                if (blockIndices[i] > -1) {
                                    let uniformBlock = resInfo.uniformBlocks.find((element) => {
                                        return element.index == blockIndices[i];
                                    });
                                    if (uniformBlock == undefined) {
                                        uniformBlock = {
                                            index: blockIndices[i],
                                            name: gl.getActiveUniformBlockName(ptr, blockIndices[i]),
                                            size: gl.getActiveUniformBlockParameter(ptr, blockIndices[i], gl.UNIFORM_BLOCK_DATA_SIZE),
                                            uniforms: [],
                                        };
                                        resInfo.uniformBlocks.push(uniformBlock);
                                    }
                                    uniformBlock.uniforms.push({
                                        name: info.name,
                                        type: this.glEnumToString(gl, info.type),
                                        size: info.size,
                                        offset: offsets[i],
                                    });
                                }
                                else {
                                    resInfo.uniforms.push({
                                        name: info.name,
                                        type: this.glEnumToString(gl, info.type),
                                        size: info.size,
                                        location: gl.getUniformLocation(ptr, info.name),
                                    });
                                }
                            }
                        }
                        resInfo.attributes = [];
                        const numAttributes = gl.getProgramParameter(ptr, gl.ACTIVE_ATTRIBUTES);
                        for (let i = 0; i < numAttributes; ++i) {
                            const info = gl.getActiveAttrib(ptr, i);
                            if (info) {
                                resInfo.attributes.push({
                                    name: info.name,
                                    type: this.glEnumToString(gl, info.type),
                                    size: info.size,
                                    location: gl.getAttribLocation(ptr, info.name),
                                });
                            }
                        }
                    }
                    res._info = resInfo;
                }
                break;
            case 'useProgram':
                {
                    if (command.program >= 0) {
                        const res = this.getResource(command.program);
                        const ptr = res._gl_ptr;
                        gl.useProgram(ptr);
                        this.boundProgram = res;
                    }
                    else {
                        gl.useProgram(null);
                        this.boundProgram = null;
                    }
                }
                break;
            case 'uniform':
            case 'uniformMatrix':
                {
                    if (this.boundProgram !== null) {
                        let resInfo = this.boundProgram._info;
                        const uniform = resInfo.uniforms.find((element) => {
                            return element.name == command.name;
                        });
                        if (uniform !== undefined) {
                            const location = uniform.location;
                            if (command.cmd == 'uniform') {
                                let shape = command.buffer_metadata.shape[command.buffer_metadata.shape.length - 1];
                                if (command.buffer_metadata.dtype == 'int32') {
                                    let bufArray = convertedBuffers[command.buffer_metadata.index];
                                    if (shape === 1) {
                                        gl.uniform1iv(location, bufArray);
                                    }
                                    else if (shape === 2) {
                                        gl.uniform2iv(location, bufArray);
                                    }
                                    else if (shape === 3) {
                                        gl.uniform3iv(location, bufArray);
                                    }
                                    else if (shape === 4) {
                                        gl.uniform4iv(location, bufArray);
                                    }
                                }
                                if (command.buffer_metadata.dtype == 'uint32') {
                                    let bufArray = convertedBuffers[command.buffer_metadata.index];
                                    if (shape === 1) {
                                        gl.uniform1uiv(location, bufArray);
                                    }
                                    else if (shape === 2) {
                                        gl.uniform2uiv(location, bufArray);
                                    }
                                    else if (shape === 3) {
                                        gl.uniform3uiv(location, bufArray);
                                    }
                                    else if (shape === 4) {
                                        gl.uniform4uiv(location, bufArray);
                                    }
                                }
                                if (command.buffer_metadata.dtype == 'float32') {
                                    let bufArray = convertedBuffers[command.buffer_metadata.index];
                                    if (shape === 1) {
                                        gl.uniform1fv(location, bufArray);
                                    }
                                    else if (shape === 2) {
                                        gl.uniform2fv(location, bufArray);
                                    }
                                    else if (shape === 3) {
                                        gl.uniform3fv(location, bufArray);
                                    }
                                    else if (shape === 4) {
                                        gl.uniform4fv(location, bufArray);
                                    }
                                }
                            }
                            else {
                                let a = command.buffer_metadata.shape[command.buffer_metadata.shape.length - 2];
                                let b = command.buffer_metadata.shape[command.buffer_metadata.shape.length - 1];
                                let bufArray = convertedBuffers[command.buffer_metadata.index];
                                if (a == 2) {
                                    if (b == 2) {
                                        gl.uniformMatrix2fv(location, false, bufArray);
                                    }
                                    else if (b == 3) {
                                        gl.uniformMatrix2x3fv(location, false, bufArray);
                                    }
                                    else if (b == 4) {
                                        gl.uniformMatrix2x4fv(location, false, bufArray);
                                    }
                                }
                                else if (a == 3) {
                                    if (b == 2) {
                                        gl.uniformMatrix3x2fv(location, false, bufArray);
                                    }
                                    else if (b == 3) {
                                        gl.uniformMatrix3fv(location, false, bufArray);
                                    }
                                    else if (b == 4) {
                                        gl.uniformMatrix3x4fv(location, false, bufArray);
                                    }
                                }
                                else if (a == 4) {
                                    if (b == 2) {
                                        gl.uniformMatrix4x2fv(location, false, bufArray);
                                    }
                                    else if (b == 3) {
                                        gl.uniformMatrix4x3fv(location, false, bufArray);
                                    }
                                    else if (b == 4) {
                                        gl.uniformMatrix4fv(location, false, bufArray);
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case 'uniformBlockBinding':
                {
                    let res = this.getResource(command.program);
                    const ptr = res._gl_ptr;
                    const uniformBlock = res._info.uniformBlocks.find((element) => {
                        return element.name == command.uniform_block_name;
                    });
                    if (uniformBlock !== undefined) {
                        gl.uniformBlockBinding(ptr, uniformBlock.index, command.uniform_block_binding);
                    }
                }
                break;
            // ------------------------------- BUFFERS --------------------------------------
            case 'createBuffer':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createBuffer();
                    res._gl_ptr = ptr;
                    res._info = { type: 'Buffer' };
                }
                break;
            case 'bindBuffer':
                {
                    const target = command.target;
                    if (command.buffer >= 0) {
                        const res = this.getResource(command.buffer);
                        const ptr = res._gl_ptr;
                        gl.bindBuffer(gl[target], ptr);
                        this.boundBuffers[target] = res;
                    }
                    else {
                        gl.bindBuffer(gl[target], null);
                        this.boundBuffers[target] = null;
                    }
                }
                break;
            case 'bindBufferBase':
                {
                    const target = command.target;
                    if (command.buffer >= 0) {
                        const res = this.getResource(command.buffer);
                        const ptr = res._gl_ptr;
                        gl.bindBufferBase(gl[target], command.index, ptr);
                    }
                    else {
                        gl.bindBufferBase(gl[target], command.index, null);
                    }
                }
                break;
            case 'bufferData':
                {
                    const target = command.target;
                    const usage = command.usage;
                    if (command.hasOwnProperty('buffer_metadata')) {
                        gl.bufferData(gl[target], convertedBuffers[command.buffer_metadata.index], gl[usage]);
                        let buf = this.boundBuffers[target];
                        if (command.update_info && buf != null) {
                            const size = gl.getBufferParameter(gl[target], gl.BUFFER_SIZE);
                            buf._info = { type: 'Buffer', size: size, target: target };
                        }
                    }
                    else {
                        let buf = this.boundBuffers[target];
                        gl.bufferData(gl[target], null, gl[usage]);
                        if (command.update_info && buf != null) {
                            buf._info = { type: 'Buffer', size: 'undefined', target: target };
                        }
                    }
                }
                break;
            case 'createUniformBuffer':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.buffer;
                    this.registerResource(newResource);
                    let res = this.getResource(command.buffer);
                    const ptr = gl.createBuffer();
                    let info = { type: 'Buffer' };
                    const prog = this.getResource(command.program);
                    const uniformBlock = prog._info.uniformBlocks.find((element) => {
                        return element.name == command.block_name;
                    });
                    if (uniformBlock != undefined) {
                        gl.bindBuffer(gl.UNIFORM_BUFFER, ptr);
                        gl.bufferData(gl.UNIFORM_BUFFER, uniformBlock.size, gl[command.usage]);
                        gl.bindBuffer(gl.UNIFORM_BUFFER, null);
                        this.boundBuffers['UNIFORM_BUFFER'] = null;
                        info['size'] = uniformBlock.size;
                        info['target'] = 'UNIFORM_BUFFER';
                        info['uniformBlock'] = uniformBlock;
                    }
                    res._gl_ptr = ptr;
                    res._info = info;
                }
                break;
            case 'bufferSubData':
            case 'bufferSubDataStr':
                {
                    const target = command.target;
                    let offset = command.dst_byte_offset;
                    if (command.cmd == 'bufferSubDataStr') {
                        offset = 0;
                        let buf = this.boundBuffers[target];
                        if (buf != null) {
                            const uniformBlock = buf._info.uniformBlock;
                            const uniform = uniformBlock.uniforms.find((element) => {
                                return element.name == command.dst_byte_offset;
                            });
                            if (uniform != undefined) {
                                offset = uniform.offset;
                            }
                        }
                    }
                    if (command.hasOwnProperty('buffer_metadata')) {
                        gl.bufferSubData(gl[target], offset, convertedBuffers[command.buffer_metadata.index], command.src_offset);
                    }
                    else {
                        gl.bufferSubData(gl[target], offset, command.src_offset);
                    }
                }
                break;
            // ------------------------------- VERTEX ARRAYS --------------------------------------
            case 'createVertexArray':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createVertexArray();
                    res._gl_ptr = ptr;
                    res._info = { type: 'VertexArrayObject', bindings: [] };
                }
                break;
            case 'bindVertexArray':
                {
                    if (command.vertex_array >= 0) {
                        const res = this.getResource(command.vertex_array);
                        const ptr = res._gl_ptr;
                        gl.bindVertexArray(ptr);
                        this.boundVao = res;
                    }
                    else {
                        gl.bindVertexArray(null);
                        this.boundVao = null;
                    }
                }
                break;
            case 'vertexAttribPointer':
            case 'vertexAttribIPointer':
            case 'enableVertexAttribArray':
            case 'disableVertexAttribArray':
            case 'vertexAttrib[1234]fv':
            case 'vertexAttribI4[u]iv':
            case 'vertexAttribDivisor':
                {
                    let index = -1;
                    if (typeof command.index === 'number') {
                        index = command.index;
                    }
                    else {
                        if (this.boundProgram != null) {
                            const attr = this.boundProgram._info.attributes.find((element) => {
                                return element.name == command.index;
                            });
                            if (attr != undefined) {
                                index = attr.location;
                            }
                        }
                        else {
                            console.error('a program must be bound to find the attribute');
                        }
                    }
                    let buf = this.boundBuffers['ARRAY_BUFFER'];
                    if (index >= 0) {
                        index += command.index_offset;
                        if (command.cmd == 'vertexAttribIPointer') {
                            gl.vertexAttribIPointer(index, command.size, gl[command.type], command.stride, command.offset);
                            if (this.boundVao != null && buf != null) {
                                let vaoInfo = this.boundVao._info;
                                const bufferUid = buf.uid;
                                let bindingInfo = vaoInfo.bindings.find((element) => {
                                    return element.buffer_uid == bufferUid;
                                });
                                if (bindingInfo == undefined) {
                                    bindingInfo = { buffer_uid: bufferUid, attributes: [] };
                                    vaoInfo.bindings.push(bindingInfo);
                                }
                                bindingInfo.attributes.push({
                                    pointer: 'vertexAttribIPointer',
                                    index: index,
                                    size: command.size,
                                    type: command.type,
                                    stride: command.stride,
                                    offset: command.offset,
                                });
                                this.boundVao._info = vaoInfo;
                            }
                        }
                        else if (command.cmd == 'vertexAttribPointer') {
                            gl.vertexAttribPointer(index, command.size, gl[command.type], command.normalized, command.stride, command.offset);
                            if (this.boundVao != null && buf != null) {
                                let vaoInfo = this.boundVao._info;
                                const bufferUid = buf.uid;
                                let bindingInfo = vaoInfo.bindings.find((element) => {
                                    return element.buffer_uid == bufferUid;
                                });
                                if (bindingInfo == undefined) {
                                    bindingInfo = { buffer_uid: bufferUid, attributes: [] };
                                    vaoInfo.bindings.push(bindingInfo);
                                }
                                bindingInfo.attributes.push({
                                    pointer: 'vertexAttribPointer',
                                    index: index,
                                    size: command.size,
                                    type: command.type,
                                    normalized: command.normalized,
                                    stride: command.stride,
                                    offset: command.offset,
                                });
                                this.boundVao._info = vaoInfo;
                            }
                        }
                        else if (command.cmd == 'enableVertexAttribArray') {
                            gl.enableVertexAttribArray(index);
                        }
                        else if (command.cmd == 'disableVertexAttribArray') {
                            gl.disableVertexAttribArray(index);
                        }
                        else if (command.cmd == 'vertexAttrib[1234]fv') {
                            if (command.buffer_metadata.shape[0] == 1) {
                                gl.vertexAttrib1fv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                            else if (command.buffer_metadata.shape[0] == 2) {
                                gl.vertexAttrib2fv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                            else if (command.buffer_metadata.shape[0] == 3) {
                                gl.vertexAttrib3fv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                            else if (command.buffer_metadata.shape[0] == 4) {
                                gl.vertexAttrib4fv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                        }
                        else if (command.cmd == 'vertexAttribI4[u]iv') {
                            if (command.buffer_metadata.dtype == 'uint32') {
                                gl.vertexAttribI4uiv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                            else if (command.buffer_metadata.dtype == 'int32') {
                                gl.vertexAttribI4iv(index, convertedBuffers[command.buffer_metadata.index]);
                            }
                        }
                        else if (command.cmd == 'vertexAttribDivisor') {
                            gl.vertexAttribDivisor(index, command.divisor);
                        }
                    }
                    else {
                        console.error(`attribute ${command.index} location not found`);
                    }
                }
                break;
            // ------------------------------- RENDER --------------------------------------
            case 'drawArrays':
                {
                    gl.drawArrays(gl[command.mode], command.first, command.count);
                }
                break;
            case 'drawArraysInstanced':
                {
                    gl.drawArraysInstanced(gl[command.mode], command.first, command.count, command.instance_count);
                }
                break;
            case 'drawElements':
                {
                    gl.drawElements(gl[command.mode], command.count, gl[command.byte_type], command.offset);
                }
                break;
            case 'drawElementsInstanced':
                {
                    gl.drawElementsInstanced(gl[command.mode], command.count, gl[command.byte_type], command.offset, command.instance_count);
                }
                break;
            // ------------------------------- FRAMEBUFFER --------------------------------------
            case 'createFramebuffer':
                {
                    const newResource = new GLResource();
                    newResource.uid = command.resource;
                    this.registerResource(newResource);
                    let res = this.getResource(command.resource);
                    const ptr = gl.createFramebuffer();
                    res._gl_ptr = ptr;
                    res._info = { type: 'Framebuffer' };
                }
                break;
            case 'bindFramebuffer':
                {
                    if (command.framebuffer >= 0) {
                        let res = this.getResource(command.framebuffer);
                        gl.bindFramebuffer(gl[command.target], res._gl_ptr);
                    }
                    else {
                        gl.bindFramebuffer(gl[command.target], null);
                    }
                }
                break;
            case 'framebufferTexture2D':
                {
                    let res = this.getResource(command.texture);
                    gl.framebufferTexture2D(gl[command.target], gl[command.attachment], gl[command.textarget], res._gl_ptr, command.level);
                }
                break;
            case 'drawBuffers':
                {
                    const buffers = command.buffers.map((element) => {
                        return gl[element];
                    });
                    gl.drawBuffers(buffers);
                }
                break;
        }
    }
    executeCommands(model, commands, convertedBuffers) {
        if (this.ctx === null) {
            return;
        }
        const gl = this.ctx;
        this.captureFrame();
        // update camera
        this.updateCamera(model);
        // update the uniform block:
        const isRowMajor = model.get('shader_matrix_major') == 'row_major';
        let cm = isRowMajor ? m4Transpose(this.cameraMatrix) : this.cameraMatrix;
        const cm_f32 = new Float32Array(cm);
        let vm = isRowMajor ? m4Transpose(this.viewMatrix) : this.viewMatrix;
        const vm_f32 = new Float32Array(vm);
        let pm = isRowMajor
            ? m4Transpose(this.projectionMatrix)
            : this.projectionMatrix;
        const pm_f32 = new Float32Array(pm);
        let vpm = isRowMajor
            ? m4Transpose(this.viewProjMatrix)
            : this.viewProjMatrix;
        const vpm_f32 = new Float32Array(vpm);
        gl.bindBuffer(gl.UNIFORM_BUFFER, this.viewBlock);
        gl.bufferSubData(gl.UNIFORM_BUFFER, 0, cm_f32, 0);
        gl.bufferSubData(gl.UNIFORM_BUFFER, 64, vm_f32, 0);
        gl.bufferSubData(gl.UNIFORM_BUFFER, 128, pm_f32, 0);
        gl.bufferSubData(gl.UNIFORM_BUFFER, 192, vpm_f32, 0);
        gl.bindBuffer(gl.UNIFORM_BUFFER, null);
        commands.forEach((command) => {
            this.executeCommand(model, gl, command, convertedBuffers);
        });
        if (model.get('sync_image_data')) {
            const width = model.get('width');
            const height = model.get('height');
            const pixels = new Uint8ClampedArray(width * height * 4);
            gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
            model.set('image_data', pixels);
            model.save_changes();
        }
    }
    handleCustomMessages(model, command, buffers) {
        if (command.clear == true) {
            this.commands = [];
            this.buffers = [];
        }
        let commands = command.commands;
        let convertedBuffers = [];
        commands.forEach((element) => {
            if (element.hasOwnProperty('buffer_metadata')) {
                const converted = bufferToArray(element.buffer_metadata.dtype, buffers[element.buffer_metadata.index].buffer);
                convertedBuffers.push(converted);
            }
        });
        // only execute once
        if (command.only_once == true) {
            this.executeCommands(model, commands, convertedBuffers);
            return;
        }
        // persistent execution by accmulating separate buffers
        let bufferIdOffset = this.buffers.length;
        this.buffers = this.buffers.concat(convertedBuffers);
        commands.forEach((element) => {
            if (element.hasOwnProperty('buffer_metadata')) {
                element.buffer_metadata.index += bufferIdOffset;
            }
        });
        this.commands = this.commands.concat(commands);
        this.runCommands(model);
    }
    runCommands(model) {
        this.executeCommands(model, this.commands, this.buffers);
    }
    registerResource(resource) {
        if (resource.uid !== this.resources.length) {
            console.error('uid not matching what we have internally');
        }
        this.resources.push(resource);
    }
    getResource(index) {
        return this.resources[index];
    }
    getResourceInfo(index) {
        if (index < 0 || index >= this.resources.length) {
            return null;
        }
        return this.resources[index]._info;
    }
    renderResizeCanvas(model) {
        this.canvas.setAttribute('width', model.get('width'));
        this.canvas.setAttribute('height', model.get('height'));
        this.resizeCanvas(model);
    }
    requestRedraw(model) {
        if (this.willRedraw == false) {
            this.willRedraw = true;
            requestAnimationFrame(() => this.redraw(model));
        }
    }
    redraw(model) {
        this.willRedraw = false;
        // update movement if needed
        if (this.moveDirection[0] ||
            this.moveDirection[1] ||
            this.moveDirection[2] ||
            this.moveDirection[3]) {
            let speed = model.get('move_speed');
            let forwardAxis = m4GetColumnK(this.cameraMatrix);
            let sideAxis = m4GetColumnI(this.cameraMatrix);
            let cameraPos = model.get('camera_pos');
            if (this.moveDirection[0]) {
                cameraPos = v3Add(cameraPos, v3Scale(forwardAxis, -speed));
            }
            if (this.moveDirection[2]) {
                cameraPos = v3Add(cameraPos, v3Scale(forwardAxis, speed));
            }
            if (this.moveDirection[1]) {
                cameraPos = v3Add(cameraPos, v3Scale(sideAxis, -speed));
            }
            if (this.moveDirection[3]) {
                cameraPos = v3Add(cameraPos, v3Scale(sideAxis, speed));
            }
            model.set('camera_pos', cameraPos);
            model.save_changes();
            // request a new frame if we are moving:
            this.requestRedraw(model);
        }
    }
    onMouseMove(model, event) {
        if (this.isMouseDown) {
            let speed = model.get('mouse_speed');
            model.set('camera_yaw', model.get('camera_yaw') - event.movementX * 0.1 * speed);
            model.set('camera_pitch', model.get('camera_pitch') - event.movementY * 0.1 * speed);
            model.save_changes();
            this.requestRedraw(model);
        }
    }
    onMouseDown(event) {
        this.isMouseDown = true;
        this.canvas.focus();
    }
    onMouseUp(event) {
        this.isMouseDown = false;
    }
    onMouseOut(event) {
        this.isMouseDown = false;
        this.moveDirection = [false, false, false, false];
    }
    async onKeyDown(model, event) {
        event.preventDefault();
        event.stopPropagation();
        let keys = model.get('move_keys');
        let captureKey = model.get('capture_frame_key');
        if (event.repeat == false) {
            if (event.key == keys[0]) {
                this.moveDirection[0] = true;
                this.requestRedraw(model);
            }
            else if (event.key == keys[1]) {
                this.moveDirection[1] = true;
                this.requestRedraw(model);
            }
            else if (event.key == keys[2]) {
                this.moveDirection[2] = true;
                this.requestRedraw(model);
            }
            else if (event.key == keys[3]) {
                this.moveDirection[3] = true;
                this.requestRedraw(model);
            }
            else if (event.key == captureKey) {
                await this.requestSpectorStart();
                this.runCommands(model);
                requestAnimationFrame(() => {
                    this.requestSpectorStop();
                });
            }
        }
    }
    onKeyUp(model, event) {
        event.preventDefault();
        event.stopPropagation();
        let keys = model.get('move_keys');
        if (event.key == keys[0]) {
            this.moveDirection[0] = false;
        }
        else if (event.key == keys[1]) {
            this.moveDirection[1] = false;
        }
        else if (event.key == keys[2]) {
            this.moveDirection[2] = false;
        }
        else if (event.key == keys[3]) {
            this.moveDirection[3] = false;
        }
    }
    render(model, el) {
        el.appendChild(this.canvas);
        this.renderResizeCanvas(model);
        ['width', 'height'].forEach((p) => model.on(`change:${p}`, () => this.renderResizeCanvas(model)));
        el.addEventListener('mousemove', (event) => this.onMouseMove(model, event));
        el.addEventListener('mousedown', (event) => this.onMouseDown(event));
        el.addEventListener('mouseup', (event) => this.onMouseUp(event));
        el.addEventListener('mouseout', (event) => this.onMouseOut(event));
        el.addEventListener('keydown', (event) => this.onKeyDown(model, event));
        el.addEventListener('keyup', (event) => this.onKeyUp(model, event));
        el.setAttribute('tabindex', '0');
    }
    async getSpectorInstance() {
        if (this.spector) {
            return this.spector;
        }
        const S = await ensureSpector();
        this.spector = new S.Spector();
        this.spector.onCaptureStarted.add((info) => {
            console.log('[spector] capture started', info);
        });
        this.spector.onError.add((error) => {
            console.error('[spector] error', error);
        });
        if (!this.spectorSpied) {
            try {
                this.spector.spyCanvas();
            }
            catch (e) {
                /* if the canvas is already spied, skip it */
            }
            this.spectorSpied = true;
        }
        this.spector.onCapture.add((capture) => {
            try {
                const blob = new Blob([JSON.stringify(capture, null, 2)], {
                    type: 'application/json',
                });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'spector_capture.json';
                a.click();
            }
            catch (e) {
                console.warn('spector capture download failed: ', e);
            }
        });
        return this.spector;
    }
    async requestSpectorCaptureNext(quick = false) {
        // wait until spector is initialized
        await this.getSpectorInstance();
        this.spectorAutoOnce = true;
    }
    async requestSpectorStart(commandCount = 50000, quick = false) {
        // wait until spector is initialized
        const S = await this.getSpectorInstance();
        S.startCapture(this.ctx, commandCount, quick);
        this.spectorActive = true;
    }
    async requestSpectorStop() {
        // wait until spector is initialized
        const S = await this.getSpectorInstance();
        if (this.spectorActive) {
            S.stopCapture();
            this.spectorActive = false;
        }
    }
    captureFrame() {
        if (!this.spector || !this.ctx) {
            return;
        }
        if (this.spectorAutoOnce) {
            this.spectorAutoOnce = false;
            this.spector.captureNextFrame(this.ctx);
        }
    }
}
// export the singleton instance
const glContext = GLContext.getInstance();


/***/ }),

/***/ 633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _webglcontext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(350);

function displayJson(json, parent) {
    for (const key in json) {
        const jsonKey = document.createElement('div');
        jsonKey.classList.add('ssepywidget-json-key');
        jsonKey.textContent = `${key}:`;
        const jsonValue = document.createElement('div');
        jsonValue.classList.add('ssepywidget-json-value');
        if (typeof json[key] === 'object') {
            const nestedJsonDisplay = document.createElement('div');
            nestedJsonDisplay.classList.add('ssepywidget-json-display');
            displayJson(json[key], nestedJsonDisplay);
            jsonValue.appendChild(nestedJsonDisplay);
        }
        else {
            jsonValue.textContent = json[key];
        }
        parent.appendChild(jsonKey);
        parent.appendChild(jsonValue);
    }
}
function initialize({ model }) { }
function render({ model, el }) {
    const root = el;
    const jsonDisplay = document.createElement('div');
    jsonDisplay.classList.add('ssepywidget-json-display');
    const jsonKey = document.createElement('div');
    jsonKey.classList.add('ssepywidget-json-key');
    jsonKey.textContent = 'uid:';
    const jsonValue = document.createElement('div');
    jsonValue.classList.add('ssepywidget-json-value');
    jsonValue.textContent = model.get('uid');
    jsonDisplay.appendChild(jsonKey);
    jsonDisplay.appendChild(jsonValue);
    const info = _webglcontext__WEBPACK_IMPORTED_MODULE_0__.glContext.getResourceInfo(model.get('uid'));
    if (info !== null) {
        displayJson(info, jsonDisplay);
    }
    root.appendChild(jsonDisplay);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ initialize, render });


/***/ }),

/***/ 775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _webglcontext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(350);

function initialize({ model }) {
    _webglcontext__WEBPACK_IMPORTED_MODULE_0__.glContext.initialize(model);
}
function render({ model, el }) {
    _webglcontext__WEBPACK_IMPORTED_MODULE_0__.glContext.render(model, el);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ initialize, render });


/***/ })

/******/ });
/************************************************************************/
/******/ // The module cache
/******/ var __webpack_module_cache__ = {};
/******/ 
/******/ // The require function
/******/ function __webpack_require__(moduleId) {
/******/ 	// Check if module is in cache
/******/ 	var cachedModule = __webpack_module_cache__[moduleId];
/******/ 	if (cachedModule !== undefined) {
/******/ 		return cachedModule.exports;
/******/ 	}
/******/ 	// Create a new module (and put it into the cache)
/******/ 	var module = __webpack_module_cache__[moduleId] = {
/******/ 		// no module.id needed
/******/ 		// no module.loaded needed
/******/ 		exports: {}
/******/ 	};
/******/ 
/******/ 	// Execute the module function
/******/ 	__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 
/******/ 	// Return the exports of the module
/******/ 	return module.exports;
/******/ }
/******/ 
/************************************************************************/
/******/ /* webpack/runtime/define property getters */
/******/ (() => {
/******/ 	// define getter functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ })();
/******/ 
/******/ /* webpack/runtime/hasOwnProperty shorthand */
/******/ (() => {
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ })();
/******/ 
/******/ /* webpack/runtime/make namespace object */
/******/ (() => {
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ })();
/******/ 
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (extension)
/* harmony export */ });
/* harmony import */ var _glviewer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(775);
/* harmony import */ var _glresource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(633);


const registry = {
    glviewer: _glviewer__WEBPACK_IMPORTED_MODULE_0__["default"],
    glresource: _glresource__WEBPACK_IMPORTED_MODULE_1__["default"],
};
function getFromRegistry(model) {
    const kind = model.get('kind');
    return registry[kind];
}
/* harmony default export */ const extension = (() => {
    return {
        initialize({ model }) {
            try {
                const impl = getFromRegistry(model);
                if (!impl) {
                    console.warn('[ext] no impl found for kind');
                    return;
                }
                impl.initialize?.({ model });
            }
            catch (err) {
                console.error('[ext] initialize error', err);
                throw err;
            }
        },
        render({ model, el }) {
            try {
                const impl = getFromRegistry(model);
                if (!impl) {
                    el.textContent = '[ext] no impl for given kind';
                    return;
                }
                impl.render({ model, el });
            }
            catch (err) {
                console.error('[ext] render error', err);
                throw err;
            }
        },
    };
});

const __webpack_exports__default = __webpack_exports__["default"];
export { __webpack_exports__default as default };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXh0ZW5zaW9uLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtELE1BQU07QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELFVBQVU7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlHQUF5RyxFQUFFO0FBQzNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULHVGQUF1RixFQUFFO0FBQ3pGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscURBQXFELG1CQUFtQjtBQUN4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxpQkFBaUI7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxtQkFBbUI7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMENBQTBDO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0Esb0RBQW9EO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLG9EQUFvRDtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsZUFBZTtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFBOEQsRUFBRTtBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPOzs7Ozs7Ozs7Ozs7O0FDeDNDb0M7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsSUFBSTtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsT0FBTztBQUM3QixrQkFBa0IsV0FBVztBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLG9EQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxFQUFFLG9CQUFvQixFQUFDOzs7Ozs7Ozs7Ozs7O0FDeENLO0FBQzNDLHNCQUFzQixPQUFPO0FBQzdCLElBQUksb0RBQVM7QUFDYjtBQUNBLGtCQUFrQixXQUFXO0FBQzdCLElBQUksb0RBQVM7QUFDYjtBQUNBLGlFQUFlLEVBQUUsb0JBQW9CLEVBQUM7Ozs7Ozs7U0NQdEM7U0FDQTs7U0FFQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTs7U0FFQTtTQUNBOztTQUVBO1NBQ0E7U0FDQTs7Ozs7VUN0QkE7VUFDQTtVQUNBO1VBQ0E7VUFDQSx5Q0FBeUMsd0NBQXdDO1VBQ2pGO1VBQ0E7VUFDQSxFOzs7OztVQ1BBLHdGOzs7OztVQ0FBO1VBQ0E7VUFDQTtVQUNBLHVEQUF1RCxpQkFBaUI7VUFDeEU7VUFDQSxnREFBZ0QsYUFBYTtVQUM3RCxFOzs7Ozs7Ozs7OztBQ05rQztBQUNJO0FBQ3RDO0FBQ0EsY0FBYyxpREFBUTtBQUN0QixnQkFBZ0IsbURBQVU7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFlO0FBQ2Y7QUFDQSxxQkFBcUIsT0FBTztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsT0FBTztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULGlCQUFpQixXQUFXO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixXQUFXO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxDQUFDLEVBQUMiLCJzb3VyY2VzIjpbImFueXdpZGdldDovLy9zcmMvd2ViZ2xjb250ZXh0LnRzIiwiYW55d2lkZ2V0Oi8vL3NyYy9nbHJlc291cmNlLnRzIiwiYW55d2lkZ2V0Oi8vL3NyYy9nbHZpZXdlci50cyIsImFueXdpZGdldDovLy93ZWJwYWNrL2Jvb3RzdHJhcCIsImFueXdpZGdldDovLy93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJhbnl3aWRnZXQ6Ly8vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsImFueXdpZGdldDovLy93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0IiwiYW55d2lkZ2V0Oi8vL3NyYy9leHRlbnNpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gc3BlY3RvciBidW5kbGUgbGF6eSBsb2FkaW5nOlxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlU3BlY3RvcigpIHtcbiAgICBpZiAod2luZG93LlNQRUNUT1IpIHtcbiAgICAgICAgcmV0dXJuIHdpbmRvdy5TUEVDVE9SO1xuICAgIH1cbiAgICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICAgICAgcy5zcmMgPSAnaHR0cHM6Ly91bnBrZy5jb20vc3BlY3RvcmpzL2Rpc3Qvc3BlY3Rvci5idW5kbGUuanMnO1xuICAgICAgICBzLm9ubG9hZCA9ICgpID0+IHJlc29sdmUoKTtcbiAgICAgICAgcy5vbmVycm9yID0gKCkgPT4gcmVqZWN0KG5ldyBFcnJvcignRmFpbGVkIHRvIGxvYWQgU3BlY3RvckpTJykpO1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHMpO1xuICAgIH0pO1xuICAgIHJldHVybiB3aW5kb3cuU1BFQ1RPUjtcbn1cbmZ1bmN0aW9uIGJ1ZmZlclRvQXJyYXkoZHR5cGUsIGJ1ZmZlcikge1xuICAgIGxldCBhcnJheSA9IG51bGw7XG4gICAgc3dpdGNoIChkdHlwZSkge1xuICAgICAgICBjYXNlICdpbnQ4JzpcbiAgICAgICAgICAgIGFycmF5ID0gbmV3IEludDhBcnJheShidWZmZXIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3VpbnQ4JzpcbiAgICAgICAgICAgIGFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdpbnQxNic6XG4gICAgICAgICAgICBhcnJheSA9IG5ldyBJbnQxNkFycmF5KGJ1ZmZlcik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndWludDE2JzpcbiAgICAgICAgICAgIGFycmF5ID0gbmV3IFVpbnQxNkFycmF5KGJ1ZmZlcik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnaW50MzInOlxuICAgICAgICAgICAgYXJyYXkgPSBuZXcgSW50MzJBcnJheShidWZmZXIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3VpbnQzMic6XG4gICAgICAgICAgICBhcnJheSA9IG5ldyBVaW50MzJBcnJheShidWZmZXIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2Zsb2F0MzInOlxuICAgICAgICAgICAgYXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KGJ1ZmZlcik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZmxvYXQ2NCc6XG4gICAgICAgICAgICBhcnJheSA9IG5ldyBGbG9hdDY0QXJyYXkoYnVmZmVyKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCBkdHlwZTogJHtkdHlwZX1gKTtcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5O1xufVxuZnVuY3Rpb24gbTRGcnVzdHVtKGxlZnQsIHJpZ2h0LCBib3R0b20sIHRvcCwgbmVhciwgZmFyKSB7XG4gICAgY29uc3QgYSA9IChyaWdodCArIGxlZnQpIC8gKHJpZ2h0IC0gbGVmdCk7XG4gICAgY29uc3QgYiA9ICh0b3AgKyBib3R0b20pIC8gKHRvcCAtIGJvdHRvbSk7XG4gICAgY29uc3QgYyA9IC0oZmFyICsgbmVhcikgLyAoZmFyIC0gbmVhcik7XG4gICAgY29uc3QgZCA9ICgtMiAqIGZhciAqIG5lYXIpIC8gKGZhciAtIG5lYXIpO1xuICAgIGNvbnN0IGUgPSAoMiAqIG5lYXIpIC8gKHJpZ2h0IC0gbGVmdCk7XG4gICAgY29uc3QgZiA9ICgyICogbmVhcikgLyAodG9wIC0gYm90dG9tKTtcbiAgICByZXR1cm4gW2UsIDAsIGEsIDAsIDAsIGYsIGIsIDAsIDAsIDAsIGMsIGQsIDAsIDAsIC0xLCAwXTtcbn1cbmZ1bmN0aW9uIG00UHJvamVjdGlvbk1hdHJpeChmb3ZZLCBhc3BlY3RSYXRpbywgbmVhciwgZmFyKSB7XG4gICAgY29uc3QgeW1heCA9IG5lYXIgKiBNYXRoLnRhbigoZm92WSAqIE1hdGguUEkpIC8gMzYwLjApO1xuICAgIGNvbnN0IHhtYXggPSB5bWF4ICogYXNwZWN0UmF0aW87XG4gICAgcmV0dXJuIG00RnJ1c3R1bSgteG1heCwgeG1heCwgLXltYXgsIHltYXgsIG5lYXIsIGZhcik7XG59XG5mdW5jdGlvbiBtNE9ydGhvUHJvamVjdGlvbk1hdHJpeCh3aWR0aCwgaGVpZ2h0LCBuZWFyLCBmYXIpIHtcbiAgICBjb25zdCBhID0gMSAvIHdpZHRoO1xuICAgIGNvbnN0IGIgPSAxIC8gaGVpZ2h0O1xuICAgIGNvbnN0IGMgPSAtKGZhciArIG5lYXIpIC8gKGZhciAtIG5lYXIpO1xuICAgIGNvbnN0IGQgPSAtMiAvIChmYXIgLSBuZWFyKTtcbiAgICByZXR1cm4gW2EsIDAsIDAsIDAsIDAsIGIsIDAsIDAsIDAsIDAsIGMsIGQsIDAsIDAsIDAsIDFdO1xufVxuZnVuY3Rpb24gbTRUcmFuc3Bvc2UobSkge1xuICAgIHJldHVybiBbXG4gICAgICAgIG1bMF0sXG4gICAgICAgIG1bNF0sXG4gICAgICAgIG1bOF0sXG4gICAgICAgIG1bMTJdLFxuICAgICAgICBtWzFdLFxuICAgICAgICBtWzVdLFxuICAgICAgICBtWzldLFxuICAgICAgICBtWzEzXSxcbiAgICAgICAgbVsyXSxcbiAgICAgICAgbVs2XSxcbiAgICAgICAgbVsxMF0sXG4gICAgICAgIG1bMTRdLFxuICAgICAgICBtWzNdLFxuICAgICAgICBtWzddLFxuICAgICAgICBtWzExXSxcbiAgICAgICAgbVsxNV0sXG4gICAgXTtcbn1cbmZ1bmN0aW9uIG00R2V0VHJhbnNsYXRpb24obSkge1xuICAgIHJldHVybiBbbVszXSwgbVs3XSwgbVsxMV1dO1xufVxuZnVuY3Rpb24gbTRHZXRDb2x1bW5JKG0pIHtcbiAgICByZXR1cm4gW21bMF0sIG1bNF0sIG1bOF1dO1xufVxuZnVuY3Rpb24gbTRHZXRDb2x1bW5KKG0pIHtcbiAgICByZXR1cm4gW21bMV0sIG1bNV0sIG1bOV1dO1xufVxuZnVuY3Rpb24gbTRHZXRDb2x1bW5LKG0pIHtcbiAgICByZXR1cm4gW21bMl0sIG1bNl0sIG1bMTBdXTtcbn1cbmZ1bmN0aW9uIG00R2V0Q29sdW1uTChtKSB7XG4gICAgcmV0dXJuIFttWzNdLCBtWzddLCBtWzExXV07XG59XG5mdW5jdGlvbiB2M0FkZChhLCBiKSB7XG4gICAgcmV0dXJuIFthWzBdICsgYlswXSwgYVsxXSArIGJbMV0sIGFbMl0gKyBiWzJdXTtcbn1cbmZ1bmN0aW9uIHYzU2NhbGUoYSwgc2NhbGUpIHtcbiAgICByZXR1cm4gW2FbMF0gKiBzY2FsZSwgYVsxXSAqIHNjYWxlLCBhWzJdICogc2NhbGVdO1xufVxuZnVuY3Rpb24gbTRUcmFuc2xhdGlvbih0eCwgdHksIHR6KSB7XG4gICAgcmV0dXJuIFsxLCAwLCAwLCB0eCwgMCwgMSwgMCwgdHksIDAsIDAsIDEsIHR6LCAwLCAwLCAwLCAxXTtcbn1cbmZ1bmN0aW9uIG00WFJvdGF0aW9uKGFuZ2xlSW5SYWRpYW5zKSB7XG4gICAgdmFyIGMgPSBNYXRoLmNvcyhhbmdsZUluUmFkaWFucyk7XG4gICAgdmFyIHMgPSBNYXRoLnNpbihhbmdsZUluUmFkaWFucyk7XG4gICAgcmV0dXJuIFsxLCAwLCAwLCAwLCAwLCBjLCAtcywgMCwgMCwgcywgYywgMCwgMCwgMCwgMCwgMV07XG59XG5mdW5jdGlvbiBtNFlSb3RhdGlvbihhbmdsZUluUmFkaWFucykge1xuICAgIHZhciBjID0gTWF0aC5jb3MoYW5nbGVJblJhZGlhbnMpO1xuICAgIHZhciBzID0gTWF0aC5zaW4oYW5nbGVJblJhZGlhbnMpO1xuICAgIHJldHVybiBbYywgMCwgcywgMCwgMCwgMSwgMCwgMCwgLXMsIDAsIGMsIDAsIDAsIDAsIDAsIDFdO1xufVxuZnVuY3Rpb24gbTRaUm90YXRpb24oYW5nbGVJblJhZGlhbnMpIHtcbiAgICB2YXIgYyA9IE1hdGguY29zKGFuZ2xlSW5SYWRpYW5zKTtcbiAgICB2YXIgcyA9IE1hdGguc2luKGFuZ2xlSW5SYWRpYW5zKTtcbiAgICByZXR1cm4gW2MsIC1zLCAwLCAwLCBzLCBjLCAwLCAwLCAwLCAwLCAxLCAwXTtcbn1cbmZ1bmN0aW9uIG00U2NhbGUoc3gsIHN5LCBzeikge1xuICAgIHJldHVybiBbc3gsIDAsIDAsIDAsIDAsIHN5LCAwLCAwLCAwLCAwLCBzeiwgMCwgMCwgMCwgMCwgMV07XG59XG5mdW5jdGlvbiBtNERvdChiLCBhKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgYlswXSAqIGFbMF0gKyBiWzFdICogYVs0XSArIGJbMl0gKiBhWzhdICsgYlszXSAqIGFbMTJdLFxuICAgICAgICBiWzBdICogYVsxXSArIGJbMV0gKiBhWzVdICsgYlsyXSAqIGFbOV0gKyBiWzNdICogYVsxM10sXG4gICAgICAgIGJbMF0gKiBhWzJdICsgYlsxXSAqIGFbNl0gKyBiWzJdICogYVsxMF0gKyBiWzNdICogYVsxNF0sXG4gICAgICAgIGJbMF0gKiBhWzNdICsgYlsxXSAqIGFbN10gKyBiWzJdICogYVsxMV0gKyBiWzNdICogYVsxNV0sXG4gICAgICAgIGJbNF0gKiBhWzBdICsgYls1XSAqIGFbNF0gKyBiWzZdICogYVs4XSArIGJbN10gKiBhWzEyXSxcbiAgICAgICAgYls0XSAqIGFbMV0gKyBiWzVdICogYVs1XSArIGJbNl0gKiBhWzldICsgYls3XSAqIGFbMTNdLFxuICAgICAgICBiWzRdICogYVsyXSArIGJbNV0gKiBhWzZdICsgYls2XSAqIGFbMTBdICsgYls3XSAqIGFbMTRdLFxuICAgICAgICBiWzRdICogYVszXSArIGJbNV0gKiBhWzddICsgYls2XSAqIGFbMTFdICsgYls3XSAqIGFbMTVdLFxuICAgICAgICBiWzhdICogYVswXSArIGJbOV0gKiBhWzRdICsgYlsxMF0gKiBhWzhdICsgYlsxMV0gKiBhWzEyXSxcbiAgICAgICAgYls4XSAqIGFbMV0gKyBiWzldICogYVs1XSArIGJbMTBdICogYVs5XSArIGJbMTFdICogYVsxM10sXG4gICAgICAgIGJbOF0gKiBhWzJdICsgYls5XSAqIGFbNl0gKyBiWzEwXSAqIGFbMTBdICsgYlsxMV0gKiBhWzE0XSxcbiAgICAgICAgYls4XSAqIGFbM10gKyBiWzldICogYVs3XSArIGJbMTBdICogYVsxMV0gKyBiWzExXSAqIGFbMTVdLFxuICAgICAgICBiWzEyXSAqIGFbMF0gKyBiWzEzXSAqIGFbNF0gKyBiWzE0XSAqIGFbOF0gKyBiWzE1XSAqIGFbMTJdLFxuICAgICAgICBiWzEyXSAqIGFbMV0gKyBiWzEzXSAqIGFbNV0gKyBiWzE0XSAqIGFbOV0gKyBiWzE1XSAqIGFbMTNdLFxuICAgICAgICBiWzEyXSAqIGFbMl0gKyBiWzEzXSAqIGFbNl0gKyBiWzE0XSAqIGFbMTBdICsgYlsxNV0gKiBhWzE0XSxcbiAgICAgICAgYlsxMl0gKiBhWzNdICsgYlsxM10gKiBhWzddICsgYlsxNF0gKiBhWzExXSArIGJbMTVdICogYVsxNV0sXG4gICAgXTtcbn1cbmZ1bmN0aW9uIG00SW52ZXJzZShtKSB7XG4gICAgdmFyIHRtcF8wID0gbVsxMF0gKiBtWzE1XTtcbiAgICB2YXIgdG1wXzEgPSBtWzE0XSAqIG1bMTFdO1xuICAgIHZhciB0bXBfMiA9IG1bNl0gKiBtWzE1XTtcbiAgICB2YXIgdG1wXzMgPSBtWzE0XSAqIG1bN107XG4gICAgdmFyIHRtcF80ID0gbVs2XSAqIG1bMTFdO1xuICAgIHZhciB0bXBfNSA9IG1bMTBdICogbVs3XTtcbiAgICB2YXIgdG1wXzYgPSBtWzJdICogbVsxNV07XG4gICAgdmFyIHRtcF83ID0gbVsxNF0gKiBtWzNdO1xuICAgIHZhciB0bXBfOCA9IG1bMl0gKiBtWzExXTtcbiAgICB2YXIgdG1wXzkgPSBtWzEwXSAqIG1bM107XG4gICAgdmFyIHRtcF8xMCA9IG1bMl0gKiBtWzddO1xuICAgIHZhciB0bXBfMTEgPSBtWzZdICogbVszXTtcbiAgICB2YXIgdG1wXzEyID0gbVs4XSAqIG1bMTNdO1xuICAgIHZhciB0bXBfMTMgPSBtWzEyXSAqIG1bOV07XG4gICAgdmFyIHRtcF8xNCA9IG1bNF0gKiBtWzEzXTtcbiAgICB2YXIgdG1wXzE1ID0gbVsxMl0gKiBtWzVdO1xuICAgIHZhciB0bXBfMTYgPSBtWzRdICogbVs5XTtcbiAgICB2YXIgdG1wXzE3ID0gbVs4XSAqIG1bNV07XG4gICAgdmFyIHRtcF8xOCA9IG1bMF0gKiBtWzEzXTtcbiAgICB2YXIgdG1wXzE5ID0gbVsxMl0gKiBtWzFdO1xuICAgIHZhciB0bXBfMjAgPSBtWzBdICogbVs5XTtcbiAgICB2YXIgdG1wXzIxID0gbVs4XSAqIG1bMV07XG4gICAgdmFyIHRtcF8yMiA9IG1bMF0gKiBtWzVdO1xuICAgIHZhciB0bXBfMjMgPSBtWzRdICogbVsxXTtcbiAgICB2YXIgdDAgPSB0bXBfMCAqIG1bNV0gK1xuICAgICAgICB0bXBfMyAqIG1bOV0gK1xuICAgICAgICB0bXBfNCAqIG1bMTNdIC1cbiAgICAgICAgKHRtcF8xICogbVs1XSArIHRtcF8yICogbVs5XSArIHRtcF81ICogbVsxM10pO1xuICAgIHZhciB0MSA9IHRtcF8xICogbVsxXSArXG4gICAgICAgIHRtcF82ICogbVs5XSArXG4gICAgICAgIHRtcF85ICogbVsxM10gLVxuICAgICAgICAodG1wXzAgKiBtWzFdICsgdG1wXzcgKiBtWzldICsgdG1wXzggKiBtWzEzXSk7XG4gICAgdmFyIHQyID0gdG1wXzIgKiBtWzFdICtcbiAgICAgICAgdG1wXzcgKiBtWzVdICtcbiAgICAgICAgdG1wXzEwICogbVsxM10gLVxuICAgICAgICAodG1wXzMgKiBtWzFdICsgdG1wXzYgKiBtWzVdICsgdG1wXzExICogbVsxM10pO1xuICAgIHZhciB0MyA9IHRtcF81ICogbVsxXSArXG4gICAgICAgIHRtcF84ICogbVs1XSArXG4gICAgICAgIHRtcF8xMSAqIG1bOV0gLVxuICAgICAgICAodG1wXzQgKiBtWzFdICsgdG1wXzkgKiBtWzVdICsgdG1wXzEwICogbVs5XSk7XG4gICAgdmFyIGQgPSAxLjAgLyAobVswXSAqIHQwICsgbVs0XSAqIHQxICsgbVs4XSAqIHQyICsgbVsxMl0gKiB0Myk7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgZCAqIHQwLFxuICAgICAgICBkICogdDEsXG4gICAgICAgIGQgKiB0MixcbiAgICAgICAgZCAqIHQzLFxuICAgICAgICBkICpcbiAgICAgICAgICAgICh0bXBfMSAqIG1bNF0gK1xuICAgICAgICAgICAgICAgIHRtcF8yICogbVs4XSArXG4gICAgICAgICAgICAgICAgdG1wXzUgKiBtWzEyXSAtXG4gICAgICAgICAgICAgICAgKHRtcF8wICogbVs0XSArIHRtcF8zICogbVs4XSArIHRtcF80ICogbVsxMl0pKSxcbiAgICAgICAgZCAqXG4gICAgICAgICAgICAodG1wXzAgKiBtWzBdICtcbiAgICAgICAgICAgICAgICB0bXBfNyAqIG1bOF0gK1xuICAgICAgICAgICAgICAgIHRtcF84ICogbVsxMl0gLVxuICAgICAgICAgICAgICAgICh0bXBfMSAqIG1bMF0gKyB0bXBfNiAqIG1bOF0gKyB0bXBfOSAqIG1bMTJdKSksXG4gICAgICAgIGQgKlxuICAgICAgICAgICAgKHRtcF8zICogbVswXSArXG4gICAgICAgICAgICAgICAgdG1wXzYgKiBtWzRdICtcbiAgICAgICAgICAgICAgICB0bXBfMTEgKiBtWzEyXSAtXG4gICAgICAgICAgICAgICAgKHRtcF8yICogbVswXSArIHRtcF83ICogbVs0XSArIHRtcF8xMCAqIG1bMTJdKSksXG4gICAgICAgIGQgKlxuICAgICAgICAgICAgKHRtcF80ICogbVswXSArXG4gICAgICAgICAgICAgICAgdG1wXzkgKiBtWzRdICtcbiAgICAgICAgICAgICAgICB0bXBfMTAgKiBtWzhdIC1cbiAgICAgICAgICAgICAgICAodG1wXzUgKiBtWzBdICsgdG1wXzggKiBtWzRdICsgdG1wXzExICogbVs4XSkpLFxuICAgICAgICBkICpcbiAgICAgICAgICAgICh0bXBfMTIgKiBtWzddICtcbiAgICAgICAgICAgICAgICB0bXBfMTUgKiBtWzExXSArXG4gICAgICAgICAgICAgICAgdG1wXzE2ICogbVsxNV0gLVxuICAgICAgICAgICAgICAgICh0bXBfMTMgKiBtWzddICsgdG1wXzE0ICogbVsxMV0gKyB0bXBfMTcgKiBtWzE1XSkpLFxuICAgICAgICBkICpcbiAgICAgICAgICAgICh0bXBfMTMgKiBtWzNdICtcbiAgICAgICAgICAgICAgICB0bXBfMTggKiBtWzExXSArXG4gICAgICAgICAgICAgICAgdG1wXzIxICogbVsxNV0gLVxuICAgICAgICAgICAgICAgICh0bXBfMTIgKiBtWzNdICsgdG1wXzE5ICogbVsxMV0gKyB0bXBfMjAgKiBtWzE1XSkpLFxuICAgICAgICBkICpcbiAgICAgICAgICAgICh0bXBfMTQgKiBtWzNdICtcbiAgICAgICAgICAgICAgICB0bXBfMTkgKiBtWzddICtcbiAgICAgICAgICAgICAgICB0bXBfMjIgKiBtWzE1XSAtXG4gICAgICAgICAgICAgICAgKHRtcF8xNSAqIG1bM10gKyB0bXBfMTggKiBtWzddICsgdG1wXzIzICogbVsxNV0pKSxcbiAgICAgICAgZCAqXG4gICAgICAgICAgICAodG1wXzE3ICogbVszXSArXG4gICAgICAgICAgICAgICAgdG1wXzIwICogbVs3XSArXG4gICAgICAgICAgICAgICAgdG1wXzIzICogbVsxMV0gLVxuICAgICAgICAgICAgICAgICh0bXBfMTYgKiBtWzNdICsgdG1wXzIxICogbVs3XSArIHRtcF8yMiAqIG1bMTFdKSksXG4gICAgICAgIGQgKlxuICAgICAgICAgICAgKHRtcF8xNCAqIG1bMTBdICtcbiAgICAgICAgICAgICAgICB0bXBfMTcgKiBtWzE0XSArXG4gICAgICAgICAgICAgICAgdG1wXzEzICogbVs2XSAtXG4gICAgICAgICAgICAgICAgKHRtcF8xNiAqIG1bMTRdICsgdG1wXzEyICogbVs2XSArIHRtcF8xNSAqIG1bMTBdKSksXG4gICAgICAgIGQgKlxuICAgICAgICAgICAgKHRtcF8yMCAqIG1bMTRdICtcbiAgICAgICAgICAgICAgICB0bXBfMTIgKiBtWzJdICtcbiAgICAgICAgICAgICAgICB0bXBfMTkgKiBtWzEwXSAtXG4gICAgICAgICAgICAgICAgKHRtcF8xOCAqIG1bMTBdICsgdG1wXzIxICogbVsxNF0gKyB0bXBfMTMgKiBtWzJdKSksXG4gICAgICAgIGQgKlxuICAgICAgICAgICAgKHRtcF8xOCAqIG1bNl0gK1xuICAgICAgICAgICAgICAgIHRtcF8yMyAqIG1bMTRdICtcbiAgICAgICAgICAgICAgICB0bXBfMTUgKiBtWzJdIC1cbiAgICAgICAgICAgICAgICAodG1wXzIyICogbVsxNF0gKyB0bXBfMTQgKiBtWzJdICsgdG1wXzE5ICogbVs2XSkpLFxuICAgICAgICBkICpcbiAgICAgICAgICAgICh0bXBfMjIgKiBtWzEwXSArXG4gICAgICAgICAgICAgICAgdG1wXzE2ICogbVsyXSArXG4gICAgICAgICAgICAgICAgdG1wXzIxICogbVs2XSAtXG4gICAgICAgICAgICAgICAgKHRtcF8yMCAqIG1bNl0gKyB0bXBfMjMgKiBtWzEwXSArIHRtcF8xNyAqIG1bMl0pKSxcbiAgICBdO1xufVxuLyoqIGdlbmVyaWMgc2luZ2xldG9uIGNsYXNzIChteSBwcmVmZXJyYWJsZSB2ZXJzaW9uIG9mIHVzaW5nIHNpbmdsZXRvbiBwYXR0ZXJuIHJlZ2FyZGxlc3Mgb2YgbGFuZ3VhZ2VzKSAqL1xuY2xhc3MgU2luZ2xldG9uIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgY29uc3QgY29uc3RydWN0b3IgPSB0aGlzLmNvbnN0cnVjdG9yO1xuICAgICAgICBpZiAoU2luZ2xldG9uLmluc3RhbmNlcy5oYXMoY29uc3RydWN0b3IpKSB7XG4gICAgICAgICAgICByZXR1cm4gU2luZ2xldG9uLmluc3RhbmNlcy5nZXQoY29uc3RydWN0b3IpO1xuICAgICAgICB9XG4gICAgICAgIFNpbmdsZXRvbi5pbnN0YW5jZXMuc2V0KGNvbnN0cnVjdG9yLCB0aGlzKTtcbiAgICB9XG4gICAgc3RhdGljIGdldEluc3RhbmNlKCkge1xuICAgICAgICBjb25zdCBnbG9iYWxLZXkgPSBTeW1ib2wuZm9yKGBfX3NpbmdsZXRvbl9fOiR7dGhpcy5uYW1lfWApO1xuICAgICAgICBjb25zdCBnID0gZ2xvYmFsVGhpcztcbiAgICAgICAgZy5fX3JlZ2lzdHJ5ID8/IChnLl9fcmVnaXN0cnkgPSBuZXcgTWFwKCkpO1xuICAgICAgICBjb25zdCByZWcgPSBnLl9fcmVnaXN0cnk7XG4gICAgICAgIGlmIChyZWcuaGFzKGdsb2JhbEtleSkpIHtcbiAgICAgICAgICAgIHJldHVybiByZWcuZ2V0KGdsb2JhbEtleSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFTaW5nbGV0b24uaW5zdGFuY2VzLmhhcyh0aGlzKSkge1xuICAgICAgICAgICAgbmV3IHRoaXMoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnN0ID0gU2luZ2xldG9uLmluc3RhbmNlcy5nZXQodGhpcyk7XG4gICAgICAgIHJlZy5zZXQoZ2xvYmFsS2V5LCBpbnN0KTtcbiAgICAgICAgcmV0dXJuIGluc3Q7XG4gICAgfVxufVxuU2luZ2xldG9uLmluc3RhbmNlcyA9IG5ldyBNYXAoKTtcbmNsYXNzIEdMUmVzb3VyY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvKipcbiAgICAgICAgICogaW50ZXJuYWwgc3RhdGVcbiAgICAgICAgICogLSBfZ2xfcHRyOiB0aGUgcG9pbnRlciB0byBXZWJHTDIgcmVzb3VyY2Ugb2JqZWN0XG4gICAgICAgICAqIC0gX2luZm86IHRoZSB0eXBlIG9mIFdlYkdMMiByZXNvdXJjZSBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIHRoaXMuX2dsX3B0ciA9IG51bGw7XG4gICAgICAgIHRoaXMuX2luZm8gPSB7IHR5cGU6ICdub3Qgc2V0JyB9O1xuICAgICAgICB0aGlzLnVpZCA9IC0xO1xuICAgIH1cbn1cbi8qKiBpbmRlcGVuZGVudCBnbC1jb250ZXh0IGluc3RhbmNlIG1hbmFnZXMgY2FudmFzIGFuZCB3ZWJnbCBpbiBKUyBzaWRlICovXG5jbGFzcyBHTENvbnRleHQgZXh0ZW5kcyBTaW5nbGV0b24ge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyB3ZSBpbmhlcml0IGZyb20gc2luZ2xldG9uIGNsYXNzLCBzbyBuZWVkIHRvIGNhbGwgc3VwZXIoKVxuICAgICAgICBzdXBlcigpO1xuICAgICAgICAvKiogcmVzb3VyY2VzIG1hbmFnZWQgYnkgdGhpcyBjb250ZXh0ICovXG4gICAgICAgIHRoaXMucmVzb3VyY2VzID0gW107XG4gICAgICAgIHRoaXMuYm91bmRCdWZmZXJzID0ge307XG4gICAgICAgIHRoaXMuY29tbWFuZHMgPSBbXTtcbiAgICAgICAgdGhpcy5idWZmZXJzID0gW107XG4gICAgICAgIC8qKiBtYXRyaXggc3RhdGUgKi9cbiAgICAgICAgdGhpcy5wcm9qZWN0aW9uTWF0cml4ID0gW107XG4gICAgICAgIHRoaXMuY2FtZXJhTWF0cml4ID0gW107XG4gICAgICAgIHRoaXMudmlld01hdHJpeCA9IFtdO1xuICAgICAgICB0aGlzLnZpZXdQcm9qTWF0cml4ID0gW107XG4gICAgICAgIC8qKiB2aWV3ZXIgcHJvcGVydGllcyAqL1xuICAgICAgICB0aGlzLmlzTW91c2VEb3duID0gZmFsc2U7XG4gICAgICAgIHRoaXMubW92ZURpcmVjdGlvbiA9IFtmYWxzZSwgZmFsc2UsIGZhbHNlLCBmYWxzZV07XG4gICAgICAgIHRoaXMud2lsbFJlZHJhdyA9IGZhbHNlO1xuICAgICAgICAvKiogd2ViZ2wyIHNwZWN0b3JKUyAoZm9yIGdyYXBoaWNzIGZyYW1lIGRlYnVnZ2VyKSAqL1xuICAgICAgICB0aGlzLnNwZWN0b3IgPSBudWxsO1xuICAgICAgICB0aGlzLnNwZWN0b3JBdXRvT25jZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNwZWN0b3JBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5zcGVjdG9yU3BpZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5jYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICAgICAgdGhpcy5jdHggPSB0aGlzLmNhbnZhcy5nZXRDb250ZXh0KCd3ZWJnbDInLCB7XG4gICAgICAgICAgICBwcmVzZXJ2ZURyYXdpbmdCdWZmZXI6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnZpZXdCbG9jayA9IG51bGw7XG4gICAgICAgIGlmICh0aGlzLmN0eCA9PT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignY291bGQgbm90IGNyZWF0ZSBXZWJHTDIgY29udGV4dCwgdGhpcyBpcyBub3Qgc3VwcG9ydGVkIGJ5IHlvdXIgYnJvd3NlcicpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZ2wgPSB0aGlzLmN0eDtcbiAgICAgICAgICAgIHRoaXMudmlld0Jsb2NrID0gZ2wuY3JlYXRlQnVmZmVyKCk7XG4gICAgICAgICAgICBnbC5iaW5kQnVmZmVyKGdsLlVOSUZPUk1fQlVGRkVSLCB0aGlzLnZpZXdCbG9jayk7XG4gICAgICAgICAgICBnbC5idWZmZXJEYXRhKGdsLlVOSUZPUk1fQlVGRkVSLCAyNTYsIGdsLkRZTkFNSUNfRFJBVyk7XG4gICAgICAgICAgICBnbC5iaW5kQnVmZmVyKGdsLlVOSUZPUk1fQlVGRkVSLCBudWxsKTtcbiAgICAgICAgICAgIGdsLmJpbmRCdWZmZXJCYXNlKGdsLlVOSUZPUk1fQlVGRkVSLCAwLCB0aGlzLnZpZXdCbG9jayk7XG4gICAgICAgICAgICAvLyBleHRlbnNpb25zIHRvIGFjdGl2YXRlXG4gICAgICAgICAgICBnbC5nZXRFeHRlbnNpb24oJ0VYVF9jb2xvcl9idWZmZXJfZmxvYXQnKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdXZWJHTDIgY29udGV4dCBpcyBzdWNjZXNzZnVsbHkgY3JlYXRlZCcpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGNsZWFyIGJvdW5kIHByb2dyYW0gc3RhdGVcbiAgICAgICAgdGhpcy5ib3VuZFByb2dyYW0gPSBudWxsO1xuICAgICAgICB0aGlzLmJvdW5kVmFvID0gbnVsbDtcbiAgICB9XG4gICAgaW5pdGlhbGl6ZShtb2RlbCkge1xuICAgICAgICAvLyByZXNpemUgY2FudmFzIHdpdGggbW9kZWwncyBpbmZvXG4gICAgICAgIHRoaXMucmVzaXplQ2FudmFzKG1vZGVsKTtcbiAgICAgICAgLy8gbGlzdGVuIHRvIG1vZGVsJ3MgY2hhbmdlc1xuICAgICAgICBbJ3dpZHRoJywgJ2hlaWdodCcsICdjYW1lcmFfZm92JywgJ2NhbWVyYV9uZWFyJywgJ2NhbWVyYV9mYXInXS5mb3JFYWNoKChwKSA9PiBtb2RlbC5vbihgY2hhbmdlOiR7cH1gLCAoKSA9PiB0aGlzLnJlc2l6ZUNhbnZhcyhtb2RlbCkpKTtcbiAgICAgICAgLy8gbGlzdGVuIGpzb24tdHlwZSBtZXNzYWdlIGV2ZW50c1xuICAgICAgICAvLyAtIHNlZSBweXRob24gY29kZTogR0xWaWV3ZXIuZXhlY3V0ZV9jb21tYW5kcygpXG4gICAgICAgIG1vZGVsLm9uKCdtc2c6Y3VzdG9tJywgKG1zZywgYnVmZmVycykgPT4ge1xuICAgICAgICAgICAgdGhpcy5oYW5kbGVDdXN0b21NZXNzYWdlcyhtb2RlbCwgbXNnLCBidWZmZXJzKTtcbiAgICAgICAgfSk7XG4gICAgICAgIFsnY2FtZXJhX3BvcycsICdjYW1lcmFfeWF3JywgJ2NhbWVyYV9waXRjaCddLmZvckVhY2goKHApID0+IG1vZGVsLm9uKGBjaGFuZ2U6JHtwfWAsICgpID0+IHRoaXMucnVuQ29tbWFuZHMobW9kZWwpKSk7XG4gICAgICAgIHRoaXMuY2FtZXJhTWF0cml4ID0gbTRUcmFuc2xhdGlvbigwLCA1MCwgMjAwKTtcbiAgICAgICAgdGhpcy52aWV3TWF0cml4ID0gbTRJbnZlcnNlKHRoaXMuY2FtZXJhTWF0cml4KTtcbiAgICAgICAgY29uc29sZS5sb2coJ0dMQ29udGV4dC5pbml0aWFsaXplKCkgaXMgY2FsbGVkIHN1Y2Nlc3NmdWxseScpO1xuICAgIH1cbiAgICByZXNpemVDYW52YXMobW9kZWwpIHtcbiAgICAgICAgY29uc3Qgd2lkdGggPSBtb2RlbC5nZXQoJ3dpZHRoJyk7XG4gICAgICAgIGNvbnN0IGhlaWdodCA9IG1vZGVsLmdldCgnaGVpZ2h0Jyk7XG4gICAgICAgIHRoaXMuY2FudmFzLnNldEF0dHJpYnV0ZSgnd2lkdGgnLCB3aWR0aC50b1N0cmluZygpKTtcbiAgICAgICAgdGhpcy5jYW52YXMuc2V0QXR0cmlidXRlKCdoZWlnaHQnLCBoZWlnaHQudG9TdHJpbmcoKSk7XG4gICAgICAgIGlmICh0aGlzLmN0eCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5jdHgudmlld3BvcnQoMCwgMCwgdGhpcy5jdHguY2FudmFzLndpZHRoLCB0aGlzLmN0eC5jYW52YXMuaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnByb2plY3Rpb25NYXRyaXggPSBtNFByb2plY3Rpb25NYXRyaXgobW9kZWwuZ2V0KCdjYW1lcmFfZm92JyksIHdpZHRoIC8gaGVpZ2h0LCBtb2RlbC5nZXQoJ2NhbWVyYV9uZWFyJyksIG1vZGVsLmdldCgnY2FtZXJhX2ZhcicpKTtcbiAgICB9XG4gICAgdXBkYXRlQ2FtZXJhKG1vZGVsKSB7XG4gICAgICAgIGxldCBwb3MgPSBtb2RlbC5nZXQoJ2NhbWVyYV9wb3MnKTtcbiAgICAgICAgbGV0IHlhdyA9IG1vZGVsLmdldCgnY2FtZXJhX3lhdycpO1xuICAgICAgICBsZXQgcGl0Y2ggPSBtb2RlbC5nZXQoJ2NhbWVyYV9waXRjaCcpO1xuICAgICAgICB0aGlzLmNhbWVyYU1hdHJpeCA9IG00VHJhbnNsYXRpb24ocG9zWzBdLCBwb3NbMV0sIHBvc1syXSk7XG4gICAgICAgIHRoaXMuY2FtZXJhTWF0cml4ID0gbTREb3QodGhpcy5jYW1lcmFNYXRyaXgsIG00WVJvdGF0aW9uKHlhdykpO1xuICAgICAgICB0aGlzLmNhbWVyYU1hdHJpeCA9IG00RG90KHRoaXMuY2FtZXJhTWF0cml4LCBtNFhSb3RhdGlvbihwaXRjaCkpO1xuICAgICAgICB0aGlzLnZpZXdNYXRyaXggPSBtNEludmVyc2UodGhpcy5jYW1lcmFNYXRyaXgpO1xuICAgICAgICB0aGlzLnZpZXdQcm9qTWF0cml4ID0gbTREb3QodGhpcy5wcm9qZWN0aW9uTWF0cml4LCB0aGlzLnZpZXdNYXRyaXgpO1xuICAgIH1cbiAgICBnbEVudW1Ub1N0cmluZyhnbCwgdmFsdWUpIHtcbiAgICAgICAgY29uc3Qga2V5cyA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBnbCkge1xuICAgICAgICAgICAgaWYgKGdsW2tleV0gPT09IHZhbHVlKSB7XG4gICAgICAgICAgICAgICAga2V5cy5wdXNoKGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGtleXMubGVuZ3RoID8ga2V5cy5qb2luKCcgfCAnKSA6IGAweCR7dmFsdWUudG9TdHJpbmcoMTYpfWA7XG4gICAgfVxuICAgIGV4ZWN1dGVDb21tYW5kKG1vZGVsLCBnbCwgY29tbWFuZCwgY29udmVydGVkQnVmZmVycykge1xuICAgICAgICBpZiAobW9kZWwuZ2V0KCd2ZXJib3NlJykgPiAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjb21tYW5kKTtcbiAgICAgICAgICAgIGlmIChjb21tYW5kLmhhc093blByb3BlcnR5KCdidWZmZXJfbWV0YWRhdGEnKSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdkYXRhJyk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHN3aXRjaCAoY29tbWFuZC5jbWQpIHtcbiAgICAgICAgICAgIGNhc2UgJ3ZpZXdwb3J0JzpcbiAgICAgICAgICAgICAgICBnbC52aWV3cG9ydChjb21tYW5kLngsIGNvbW1hbmQueSwgY29tbWFuZC53aWR0aCwgY29tbWFuZC5oZWlnaHQpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZW5hYmxlJzpcbiAgICAgICAgICAgIGNhc2UgJ2Rpc2FibGUnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNhcCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmJsZW5kKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLkJMRU5EO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5kZXB0aF90ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLkRFUFRIX1RFU1Q7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmRpdGhlcilcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcCB8PSBnbC5ESVRIRVI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLnBvbHlnb25fb2Zmc2V0X2ZpbGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXAgfD0gZ2wuUE9MWUdPTl9PRkZTRVRfRklMTDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuc2FtcGxlX2FscGhhX3RvX2NvdmVyYWdlKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLlNBTVBMRV9BTFBIQV9UT19DT1ZFUkFHRTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuc2FtcGxlX2NvdmVyYWdlKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLlNBTVBMRV9DT1ZFUkFHRTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuc2Npc3Nvcl90ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLlNDSVNTT1JfVEVTVDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuc3RlbmNpbF90ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLlNURU5DSUxfVEVTVDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQucmFzdGVyaXplcl9kaXNjYXJkKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLlJBU1RFUklaRVJfRElTQ0FSRDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuY3VsbF9mYWNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2FwIHw9IGdsLkNVTExfRkFDRTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuY21kID09ICdlbmFibGUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5lbmFibGUoY2FwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmRpc2FibGUoY2FwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2NsZWFyQ29sb3InOlxuICAgICAgICAgICAgICAgIGdsLmNsZWFyQ29sb3IoY29tbWFuZC5yLCBjb21tYW5kLmcsIGNvbW1hbmQuYiwgY29tbWFuZC5hKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2NsZWFyJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBiaXRzID0gMDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuZGVwdGgpXG4gICAgICAgICAgICAgICAgICAgICAgICBiaXRzIHw9IGdsLkRFUFRIX0JVRkZFUl9CSVQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmNvbG9yKVxuICAgICAgICAgICAgICAgICAgICAgICAgYml0cyB8PSBnbC5DT0xPUl9CVUZGRVJfQklUO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5zdGVuY2lsKVxuICAgICAgICAgICAgICAgICAgICAgICAgYml0cyB8PSBnbC5TVEVOQ0lMX0JVRkZFUl9CSVQ7XG4gICAgICAgICAgICAgICAgICAgIGdsLmNsZWFyKGJpdHMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2Zyb250RmFjZSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBnbC5mcm9udEZhY2UoZ2xbY29tbWFuZC5tb2RlXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnY3VsbEZhY2UnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2wuY3VsbEZhY2UoZ2xbY29tbWFuZC5tb2RlXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIERFUFRIIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICBjYXNlICdkZXB0aEZ1bmMnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2wuZGVwdGhGdW5jKGdsW2NvbW1hbmQuZnVuY10pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2RlcHRoTWFzayc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBnbC5kZXB0aE1hc2soY29tbWFuZC5mbGFnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdkZXB0aFJhbmdlJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGdsLmRlcHRoUmFuZ2UoY29tbWFuZC56X25lYXIsIGNvbW1hbmQuel9mYXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBDT0xPUiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgY2FzZSAnY3JlYXRlVGV4dHVyZSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXNvdXJjZSA9IG5ldyBHTFJlc291cmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIG5ld1Jlc291cmNlLnVpZCA9IGNvbW1hbmQucmVzb3VyY2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaXN0ZXJSZXNvdXJjZShuZXdSZXNvdXJjZSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQucmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSBnbC5jcmVhdGVUZXh0dXJlKCk7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5fZ2xfcHRyID0gcHRyO1xuICAgICAgICAgICAgICAgICAgICByZXMuX2luZm8gPSB7IHR5cGU6ICd0ZXh0dXJlJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2JpbmRUZXh0dXJlJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLnRleHR1cmUgPiAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dHVyZSA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC50ZXh0dXJlKS5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYmluZFRleHR1cmUoZ2xbY29tbWFuZC50YXJnZXRdLCB0ZXh0dXJlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRUZXh0dXJlKGdsW2NvbW1hbmQudGFyZ2V0XSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdhY3RpdmVUZXh0dXJlJzpcbiAgICAgICAgICAgICAgICBnbC5hY3RpdmVUZXh0dXJlKGdsLlRFWFRVUkUwICsgY29tbWFuZC50ZXh0dXJlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2dlbmVyYXRlTWlwbWFwJzpcbiAgICAgICAgICAgICAgICBnbC5nZW5lcmF0ZU1pcG1hcChnbFtjb21tYW5kLnRhcmdldF0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGV4SW1hZ2UyRCc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5oYXNPd25Qcm9wZXJ0eSgnYnVmZmVyX21ldGFkYXRhJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLnRleEltYWdlMkQoZ2xbY29tbWFuZC50YXJnZXRdLCBjb21tYW5kLmxldmVsLCBnbFtjb21tYW5kLmludGVybmFsX2Zvcm1hdF0sIGNvbW1hbmQud2lkdGgsIGNvbW1hbmQuaGVpZ2h0LCBjb21tYW5kLmJvcmRlciwgZ2xbY29tbWFuZC5mb3JtYXRdLCBnbFtjb21tYW5kLmRhdGFfdHlwZV0sIGNvbnZlcnRlZEJ1ZmZlcnNbY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuaW5kZXhdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLnRleEltYWdlMkQoZ2xbY29tbWFuZC50YXJnZXRdLCBjb21tYW5kLmxldmVsLCBnbFtjb21tYW5kLmludGVybmFsX2Zvcm1hdF0sIGNvbW1hbmQud2lkdGgsIGNvbW1hbmQuaGVpZ2h0LCBjb21tYW5kLmJvcmRlciwgZ2xbY29tbWFuZC5mb3JtYXRdLCBnbFtjb21tYW5kLmRhdGFfdHlwZV0sIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGV4U3RvcmFnZTJEJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGdsLnRleFN0b3JhZ2UyRChnbFtjb21tYW5kLnRhcmdldF0sIGNvbW1hbmQubGV2ZWxzLCBnbFtjb21tYW5kLmludGVybmFsX2Zvcm1hdF0sIGNvbW1hbmQud2lkdGgsIGNvbW1hbmQuaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0ZXhJbWFnZTNEJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmhhc093blByb3BlcnR5KCdidWZmZXJfbWV0YWRhdGEnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wudGV4SW1hZ2UzRChnbFtjb21tYW5kLnRhcmdldF0sIGNvbW1hbmQubGV2ZWwsIGdsW2NvbW1hbmQuaW50ZXJuYWxfZm9ybWF0XSwgY29tbWFuZC53aWR0aCwgY29tbWFuZC5oZWlnaHQsIGNvbW1hbmQuZGVwdGgsIGNvbW1hbmQuYm9yZGVyLCBnbFtjb21tYW5kLmZvcm1hdF0sIGdsW2NvbW1hbmQuZGF0YV90eXBlXSwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wudGV4SW1hZ2UzRChnbFtjb21tYW5kLnRhcmdldF0sIGNvbW1hbmQubGV2ZWwsIGdsW2NvbW1hbmQuaW50ZXJuYWxfZm9ybWF0XSwgY29tbWFuZC53aWR0aCwgY29tbWFuZC5oZWlnaHQsIGNvbW1hbmQuZGVwdGgsIGNvbW1hbmQuYm9yZGVyLCBnbFtjb21tYW5kLmZvcm1hdF0sIGdsW2NvbW1hbmQuZGF0YV90eXBlXSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0ZXhTdG9yYWdlM0QnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2wudGV4U3RvcmFnZTNEKGdsW2NvbW1hbmQudGFyZ2V0XSwgY29tbWFuZC5sZXZlbHMsIGdsW2NvbW1hbmQuaW50ZXJuYWxfZm9ybWF0XSwgY29tbWFuZC53aWR0aCwgY29tbWFuZC5oZWlnaHQsIGNvbW1hbmQuZGVwdGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3RleFBhcmFtZXRlcmknOlxuICAgICAgICAgICAgICAgIGdsLnRleFBhcmFtZXRlcmkoZ2xbY29tbWFuZC50YXJnZXRdLCBnbFtjb21tYW5kLnBuYW1lXSwgY29tbWFuZC5wYXJhbSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0ZXhQYXJhbWV0ZXJmJzpcbiAgICAgICAgICAgICAgICBnbC50ZXhQYXJhbWV0ZXJmKGdsW2NvbW1hbmQudGFyZ2V0XSwgZ2xbY29tbWFuZC5wbmFtZV0sIGNvbW1hbmQucGFyYW0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGV4UGFyYW1ldGVyX3N0cic6XG4gICAgICAgICAgICAgICAgZ2wudGV4UGFyYW1ldGVyaShnbFtjb21tYW5kLnRhcmdldF0sIGdsW2NvbW1hbmQucG5hbWVdLCBnbFtjb21tYW5kLnBhcmFtXSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdwaXhlbFN0b3JlaSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5wbmFtZSA9PSAnVU5QQUNLX0NPTE9SU1BBQ0VfQ09OVkVSU0lPTl9XRUJHTCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLnBpeGVsU3RvcmVpKGdsW2NvbW1hbmQucG5hbWVdLCBnbFtjb21tYW5kLnBhcmFtXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5waXhlbFN0b3JlaShnbFtjb21tYW5kLnBuYW1lXSwgY29tbWFuZC5wYXJhbSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFNIQURFUlMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgIGNhc2UgJ2NyZWF0ZVNoYWRlcic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXNvdXJjZSA9IG5ldyBHTFJlc291cmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIG5ld1Jlc291cmNlLnVpZCA9IGNvbW1hbmQucmVzb3VyY2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaXN0ZXJSZXNvdXJjZShuZXdSZXNvdXJjZSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQucmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSBnbC5jcmVhdGVTaGFkZXIoZ2xbY29tbWFuZC50eXBlXSk7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5fZ2xfcHRyID0gcHRyO1xuICAgICAgICAgICAgICAgICAgICByZXMuX2luZm8gPSB7IHR5cGU6ICdzaGFkZXInIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnc2hhZGVyU291cmNlJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5zaGFkZXIpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSByZXMuX2dsX3B0cjtcbiAgICAgICAgICAgICAgICAgICAgZ2wuc2hhZGVyU291cmNlKHB0ciwgY29tbWFuZC5zb3VyY2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2NvbXBpbGVTaGFkZXInOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLnNoYWRlcik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHB0ciA9IHJlcy5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICBnbC5jb21waWxlU2hhZGVyKHB0cik7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNJbmZvID0gcmVzLl9pbmZvO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWdsLmdldFNoYWRlclBhcmFtZXRlcihwdHIsIGdsLkNPTVBJTEVfU1RBVFVTKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGluZm8gPSBnbC5nZXRTaGFkZXJJbmZvTG9nKHB0cik7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNJbmZvLm1lc3NhZ2UgPSBpbmZvIHx8ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGVhdmUgZXJyb3IgbG9nOlxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzSW5mbyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNJbmZvLm1lc3NhZ2UgPSAnY29tcGlsZWQnO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJlcy5faW5mbyA9IHJlc0luZm87XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBQUk9HUkFNUyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgY2FzZSAnY3JlYXRlUHJvZ3JhbSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXNvdXJjZSA9IG5ldyBHTFJlc291cmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIG5ld1Jlc291cmNlLnVpZCA9IGNvbW1hbmQucmVzb3VyY2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaXN0ZXJSZXNvdXJjZShuZXdSZXNvdXJjZSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQucmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSBnbC5jcmVhdGVQcm9ncmFtKCk7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5fZ2xfcHRyID0gcHRyO1xuICAgICAgICAgICAgICAgICAgICByZXMuX2luZm8gPSB7IHR5cGU6ICdwcm9ncmFtJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2F0dGFjaFNoYWRlcic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9nID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLnByb2dyYW0pXG4gICAgICAgICAgICAgICAgICAgICAgICAuX2dsX3B0cjtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2hhZGVyID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLnNoYWRlcilcbiAgICAgICAgICAgICAgICAgICAgICAgIC5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICBnbC5hdHRhY2hTaGFkZXIocHJvZywgc2hhZGVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdiaW5kQXR0cmliTG9jYXRpb24nOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5wcm9ncmFtKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHRyID0gcmVzLl9nbF9wdHI7XG4gICAgICAgICAgICAgICAgICAgIGdsLmJpbmRBdHRyaWJMb2NhdGlvbihwdHIsIGNvbW1hbmQuaW5kZXgsIGNvbW1hbmQubmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnbGlua1Byb2dyYW0nOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5wcm9ncmFtKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHRyID0gcmVzLl9nbF9wdHI7XG4gICAgICAgICAgICAgICAgICAgIGdsLmxpbmtQcm9ncmFtKHB0cik7XG4gICAgICAgICAgICAgICAgICAgIGdsLnZhbGlkYXRlUHJvZ3JhbShwdHIpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzSW5mbyA9IHJlcy5faW5mbztcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFnbC5nZXRQcm9ncmFtUGFyYW1ldGVyKHB0ciwgZ2wuTElOS19TVEFUVVMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW5mbyA9IGdsLmdldFNoYWRlckluZm9Mb2cocHRyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc0luZm8ubWVzc2FnZSA9IGluZm8gfHwgJyc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBiaW5kIG91ciB2aWV3LWJsb2NrOlxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZpZXdCbG9ja0luZGV4ID0gZ2wuZ2V0VW5pZm9ybUJsb2NrSW5kZXgocHRyLCAnVmlld0Jsb2NrJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmlld0Jsb2NrSW5kZXggPCA0Mjk0OTY3Mjk1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudW5pZm9ybUJsb2NrQmluZGluZyhwdHIsIHZpZXdCbG9ja0luZGV4LCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc0luZm8ubWVzc2FnZSA9ICdsaW5rZWQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzSW5mby51bmlmb3JtQmxvY2tzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNJbmZvLnVuaWZvcm1zID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBudW1Vbmlmb3JtcyA9IGdsLmdldFByb2dyYW1QYXJhbWV0ZXIocHRyLCBnbC5BQ1RJVkVfVU5JRk9STVMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5kaWNlcyA9IFsuLi5BcnJheShudW1Vbmlmb3Jtcykua2V5cygpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJsb2NrSW5kaWNlcyA9IGdsLmdldEFjdGl2ZVVuaWZvcm1zKHB0ciwgaW5kaWNlcywgZ2wuVU5JRk9STV9CTE9DS19JTkRFWCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvZmZzZXRzID0gZ2wuZ2V0QWN0aXZlVW5pZm9ybXMocHRyLCBpbmRpY2VzLCBnbC5VTklGT1JNX09GRlNFVCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bVVuaWZvcm1zOyArK2kpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gZ2wuZ2V0QWN0aXZlVW5pZm9ybShwdHIsIGkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbmZvKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlZ3JvdXAgdGhlIGJsb2NrczpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJsb2NrSW5kaWNlc1tpXSA+IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdW5pZm9ybUJsb2NrID0gcmVzSW5mby51bmlmb3JtQmxvY2tzLmZpbmQoKGVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5pbmRleCA9PSBibG9ja0luZGljZXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1bmlmb3JtQmxvY2sgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5pZm9ybUJsb2NrID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleDogYmxvY2tJbmRpY2VzW2ldLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBnbC5nZXRBY3RpdmVVbmlmb3JtQmxvY2tOYW1lKHB0ciwgYmxvY2tJbmRpY2VzW2ldKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogZ2wuZ2V0QWN0aXZlVW5pZm9ybUJsb2NrUGFyYW1ldGVyKHB0ciwgYmxvY2tJbmRpY2VzW2ldLCBnbC5VTklGT1JNX0JMT0NLX0RBVEFfU0laRSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuaWZvcm1zOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc0luZm8udW5pZm9ybUJsb2Nrcy5wdXNoKHVuaWZvcm1CbG9jayk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bmlmb3JtQmxvY2sudW5pZm9ybXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogaW5mby5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IHRoaXMuZ2xFbnVtVG9TdHJpbmcoZ2wsIGluZm8udHlwZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogaW5mby5zaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9mZnNldDogb2Zmc2V0c1tpXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzSW5mby51bmlmb3Jtcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBpbmZvLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogdGhpcy5nbEVudW1Ub1N0cmluZyhnbCwgaW5mby50eXBlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplOiBpbmZvLnNpemUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYXRpb246IGdsLmdldFVuaWZvcm1Mb2NhdGlvbihwdHIsIGluZm8ubmFtZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc0luZm8uYXR0cmlidXRlcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbnVtQXR0cmlidXRlcyA9IGdsLmdldFByb2dyYW1QYXJhbWV0ZXIocHRyLCBnbC5BQ1RJVkVfQVRUUklCVVRFUyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bUF0dHJpYnV0ZXM7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGluZm8gPSBnbC5nZXRBY3RpdmVBdHRyaWIocHRyLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5mbykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNJbmZvLmF0dHJpYnV0ZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBpbmZvLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aGlzLmdsRW51bVRvU3RyaW5nKGdsLCBpbmZvLnR5cGUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogaW5mby5zaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYXRpb246IGdsLmdldEF0dHJpYkxvY2F0aW9uKHB0ciwgaW5mby5uYW1lKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJlcy5faW5mbyA9IHJlc0luZm87XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndXNlUHJvZ3JhbSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5wcm9ncmFtID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5wcm9ncmFtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHB0ciA9IHJlcy5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wudXNlUHJvZ3JhbShwdHIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3VuZFByb2dyYW0gPSByZXM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC51c2VQcm9ncmFtKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3VuZFByb2dyYW0gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndW5pZm9ybSc6XG4gICAgICAgICAgICBjYXNlICd1bmlmb3JtTWF0cml4JzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmJvdW5kUHJvZ3JhbSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc0luZm8gPSB0aGlzLmJvdW5kUHJvZ3JhbS5faW5mbztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVuaWZvcm0gPSByZXNJbmZvLnVuaWZvcm1zLmZpbmQoKGVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5uYW1lID09IGNvbW1hbmQubmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVuaWZvcm0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxvY2F0aW9uID0gdW5pZm9ybS5sb2NhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5jbWQgPT0gJ3VuaWZvcm0nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzaGFwZSA9IGNvbW1hbmQuYnVmZmVyX21ldGFkYXRhLnNoYXBlW2NvbW1hbmQuYnVmZmVyX21ldGFkYXRhLnNoYXBlLmxlbmd0aCAtIDFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuZHR5cGUgPT0gJ2ludDMyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJ1ZkFycmF5ID0gY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2hhcGUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtMWl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzaGFwZSA9PT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0yaXYobG9jYXRpb24sIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNoYXBlID09PSAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudW5pZm9ybTNpdihsb2NhdGlvbiwgYnVmQXJyYXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc2hhcGUgPT09IDQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtNGl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuYnVmZmVyX21ldGFkYXRhLmR0eXBlID09ICd1aW50MzInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYnVmQXJyYXkgPSBjb252ZXJ0ZWRCdWZmZXJzW2NvbW1hbmQuYnVmZmVyX21ldGFkYXRhLmluZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzaGFwZSA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0xdWl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzaGFwZSA9PT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0ydWl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzaGFwZSA9PT0gMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0zdWl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzaGFwZSA9PT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm00dWl2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuYnVmZmVyX21ldGFkYXRhLmR0eXBlID09ICdmbG9hdDMyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJ1ZkFycmF5ID0gY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2hhcGUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtMWZ2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzaGFwZSA9PT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0yZnYobG9jYXRpb24sIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNoYXBlID09PSAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudW5pZm9ybTNmdihsb2NhdGlvbiwgYnVmQXJyYXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc2hhcGUgPT09IDQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtNGZ2KGxvY2F0aW9uLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhID0gY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuc2hhcGVbY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuc2hhcGUubGVuZ3RoIC0gMl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBiID0gY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuc2hhcGVbY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuc2hhcGUubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBidWZBcnJheSA9IGNvbnZlcnRlZEJ1ZmZlcnNbY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYiA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudW5pZm9ybU1hdHJpeDJmdihsb2NhdGlvbiwgZmFsc2UsIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgPT0gMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm1NYXRyaXgyeDNmdihsb2NhdGlvbiwgZmFsc2UsIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgPT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm1NYXRyaXgyeDRmdihsb2NhdGlvbiwgZmFsc2UsIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChhID09IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChiID09IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtTWF0cml4M3gyZnYobG9jYXRpb24sIGZhbHNlLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChiID09IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtTWF0cml4M2Z2KGxvY2F0aW9uLCBmYWxzZSwgYnVmQXJyYXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoYiA9PSA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudW5pZm9ybU1hdHJpeDN4NGZ2KGxvY2F0aW9uLCBmYWxzZSwgYnVmQXJyYXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGEgPT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGIgPT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm1NYXRyaXg0eDJmdihsb2NhdGlvbiwgZmFsc2UsIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgPT0gMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm1NYXRyaXg0eDNmdihsb2NhdGlvbiwgZmFsc2UsIGJ1ZkFycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgPT0gNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnVuaWZvcm1NYXRyaXg0ZnYobG9jYXRpb24sIGZhbHNlLCBidWZBcnJheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd1bmlmb3JtQmxvY2tCaW5kaW5nJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQucHJvZ3JhbSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHB0ciA9IHJlcy5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1bmlmb3JtQmxvY2sgPSByZXMuX2luZm8udW5pZm9ybUJsb2Nrcy5maW5kKChlbGVtZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5uYW1lID09IGNvbW1hbmQudW5pZm9ybV9ibG9ja19uYW1lO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVuaWZvcm1CbG9jayAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC51bmlmb3JtQmxvY2tCaW5kaW5nKHB0ciwgdW5pZm9ybUJsb2NrLmluZGV4LCBjb21tYW5kLnVuaWZvcm1fYmxvY2tfYmluZGluZyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIEJVRkZFUlMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgIGNhc2UgJ2NyZWF0ZUJ1ZmZlcic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXNvdXJjZSA9IG5ldyBHTFJlc291cmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIG5ld1Jlc291cmNlLnVpZCA9IGNvbW1hbmQucmVzb3VyY2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVnaXN0ZXJSZXNvdXJjZShuZXdSZXNvdXJjZSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQucmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSBnbC5jcmVhdGVCdWZmZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzLl9nbF9wdHIgPSBwdHI7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5faW5mbyA9IHsgdHlwZTogJ0J1ZmZlcicgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdiaW5kQnVmZmVyJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGNvbW1hbmQudGFyZ2V0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5idWZmZXIgPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLmJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwdHIgPSByZXMuX2dsX3B0cjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRCdWZmZXIoZ2xbdGFyZ2V0XSwgcHRyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYm91bmRCdWZmZXJzW3RhcmdldF0gPSByZXM7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5iaW5kQnVmZmVyKGdsW3RhcmdldF0sIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3VuZEJ1ZmZlcnNbdGFyZ2V0XSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdiaW5kQnVmZmVyQmFzZSc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBjb21tYW5kLnRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuYnVmZmVyID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5idWZmZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcHRyID0gcmVzLl9nbF9wdHI7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5iaW5kQnVmZmVyQmFzZShnbFt0YXJnZXRdLCBjb21tYW5kLmluZGV4LCBwdHIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYmluZEJ1ZmZlckJhc2UoZ2xbdGFyZ2V0XSwgY29tbWFuZC5pbmRleCwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdidWZmZXJEYXRhJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGNvbW1hbmQudGFyZ2V0O1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2FnZSA9IGNvbW1hbmQudXNhZ2U7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmhhc093blByb3BlcnR5KCdidWZmZXJfbWV0YWRhdGEnKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYnVmZmVyRGF0YShnbFt0YXJnZXRdLCBjb252ZXJ0ZWRCdWZmZXJzW2NvbW1hbmQuYnVmZmVyX21ldGFkYXRhLmluZGV4XSwgZ2xbdXNhZ2VdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBidWYgPSB0aGlzLmJvdW5kQnVmZmVyc1t0YXJnZXRdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQudXBkYXRlX2luZm8gJiYgYnVmICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzaXplID0gZ2wuZ2V0QnVmZmVyUGFyYW1ldGVyKGdsW3RhcmdldF0sIGdsLkJVRkZFUl9TSVpFKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWYuX2luZm8gPSB7IHR5cGU6ICdCdWZmZXInLCBzaXplOiBzaXplLCB0YXJnZXQ6IHRhcmdldCB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJ1ZiA9IHRoaXMuYm91bmRCdWZmZXJzW3RhcmdldF07XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5idWZmZXJEYXRhKGdsW3RhcmdldF0sIG51bGwsIGdsW3VzYWdlXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC51cGRhdGVfaW5mbyAmJiBidWYgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1Zi5faW5mbyA9IHsgdHlwZTogJ0J1ZmZlcicsIHNpemU6ICd1bmRlZmluZWQnLCB0YXJnZXQ6IHRhcmdldCB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnY3JlYXRlVW5pZm9ybUJ1ZmZlcic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXNvdXJjZSA9IG5ldyBHTFJlc291cmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIG5ld1Jlc291cmNlLnVpZCA9IGNvbW1hbmQuYnVmZmVyO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUmVzb3VyY2UobmV3UmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLmJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHB0ciA9IGdsLmNyZWF0ZUJ1ZmZlcigpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgaW5mbyA9IHsgdHlwZTogJ0J1ZmZlcicgfTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvZyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC5wcm9ncmFtKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdW5pZm9ybUJsb2NrID0gcHJvZy5faW5mby51bmlmb3JtQmxvY2tzLmZpbmQoKGVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50Lm5hbWUgPT0gY29tbWFuZC5ibG9ja19uYW1lO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVuaWZvcm1CbG9jayAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRCdWZmZXIoZ2wuVU5JRk9STV9CVUZGRVIsIHB0cik7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5idWZmZXJEYXRhKGdsLlVOSUZPUk1fQlVGRkVSLCB1bmlmb3JtQmxvY2suc2l6ZSwgZ2xbY29tbWFuZC51c2FnZV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYmluZEJ1ZmZlcihnbC5VTklGT1JNX0JVRkZFUiwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmJvdW5kQnVmZmVyc1snVU5JRk9STV9CVUZGRVInXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZvWydzaXplJ10gPSB1bmlmb3JtQmxvY2suc2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZm9bJ3RhcmdldCddID0gJ1VOSUZPUk1fQlVGRkVSJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZm9bJ3VuaWZvcm1CbG9jayddID0gdW5pZm9ybUJsb2NrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJlcy5fZ2xfcHRyID0gcHRyO1xuICAgICAgICAgICAgICAgICAgICByZXMuX2luZm8gPSBpbmZvO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2J1ZmZlclN1YkRhdGEnOlxuICAgICAgICAgICAgY2FzZSAnYnVmZmVyU3ViRGF0YVN0cic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBjb21tYW5kLnRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IG9mZnNldCA9IGNvbW1hbmQuZHN0X2J5dGVfb2Zmc2V0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5jbWQgPT0gJ2J1ZmZlclN1YkRhdGFTdHInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvZmZzZXQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJ1ZiA9IHRoaXMuYm91bmRCdWZmZXJzW3RhcmdldF07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVmICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1bmlmb3JtQmxvY2sgPSBidWYuX2luZm8udW5pZm9ybUJsb2NrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVuaWZvcm0gPSB1bmlmb3JtQmxvY2sudW5pZm9ybXMuZmluZCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5uYW1lID09IGNvbW1hbmQuZHN0X2J5dGVfb2Zmc2V0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1bmlmb3JtICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvZmZzZXQgPSB1bmlmb3JtLm9mZnNldDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbW1hbmQuaGFzT3duUHJvcGVydHkoJ2J1ZmZlcl9tZXRhZGF0YScpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5idWZmZXJTdWJEYXRhKGdsW3RhcmdldF0sIG9mZnNldCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0sIGNvbW1hbmQuc3JjX29mZnNldCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbC5idWZmZXJTdWJEYXRhKGdsW3RhcmdldF0sIG9mZnNldCwgY29tbWFuZC5zcmNfb2Zmc2V0KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gVkVSVEVYIEFSUkFZUyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgY2FzZSAnY3JlYXRlVmVydGV4QXJyYXknOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3UmVzb3VyY2UgPSBuZXcgR0xSZXNvdXJjZSgpO1xuICAgICAgICAgICAgICAgICAgICBuZXdSZXNvdXJjZS51aWQgPSBjb21tYW5kLnJlc291cmNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUmVzb3VyY2UobmV3UmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLnJlc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHRyID0gZ2wuY3JlYXRlVmVydGV4QXJyYXkoKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzLl9nbF9wdHIgPSBwdHI7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5faW5mbyA9IHsgdHlwZTogJ1ZlcnRleEFycmF5T2JqZWN0JywgYmluZGluZ3M6IFtdIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYmluZFZlcnRleEFycmF5JzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLnZlcnRleF9hcnJheSA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXMgPSB0aGlzLmdldFJlc291cmNlKGNvbW1hbmQudmVydGV4X2FycmF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHB0ciA9IHJlcy5fZ2xfcHRyO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYmluZFZlcnRleEFycmF5KHB0cik7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmJvdW5kVmFvID0gcmVzO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2wuYmluZFZlcnRleEFycmF5KG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3VuZFZhbyA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd2ZXJ0ZXhBdHRyaWJQb2ludGVyJzpcbiAgICAgICAgICAgIGNhc2UgJ3ZlcnRleEF0dHJpYklQb2ludGVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2VuYWJsZVZlcnRleEF0dHJpYkFycmF5JzpcbiAgICAgICAgICAgIGNhc2UgJ2Rpc2FibGVWZXJ0ZXhBdHRyaWJBcnJheSc6XG4gICAgICAgICAgICBjYXNlICd2ZXJ0ZXhBdHRyaWJbMTIzNF1mdic6XG4gICAgICAgICAgICBjYXNlICd2ZXJ0ZXhBdHRyaWJJNFt1XWl2JzpcbiAgICAgICAgICAgIGNhc2UgJ3ZlcnRleEF0dHJpYkRpdmlzb3InOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGluZGV4ID0gLTE7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29tbWFuZC5pbmRleCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ID0gY29tbWFuZC5pbmRleDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmJvdW5kUHJvZ3JhbSAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXR0ciA9IHRoaXMuYm91bmRQcm9ncmFtLl9pbmZvLmF0dHJpYnV0ZXMuZmluZCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5uYW1lID09IGNvbW1hbmQuaW5kZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGF0dHIgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ID0gYXR0ci5sb2NhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdhIHByb2dyYW0gbXVzdCBiZSBib3VuZCB0byBmaW5kIHRoZSBhdHRyaWJ1dGUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBsZXQgYnVmID0gdGhpcy5ib3VuZEJ1ZmZlcnNbJ0FSUkFZX0JVRkZFUiddO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggKz0gY29tbWFuZC5pbmRleF9vZmZzZXQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5jbWQgPT0gJ3ZlcnRleEF0dHJpYklQb2ludGVyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYklQb2ludGVyKGluZGV4LCBjb21tYW5kLnNpemUsIGdsW2NvbW1hbmQudHlwZV0sIGNvbW1hbmQuc3RyaWRlLCBjb21tYW5kLm9mZnNldCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuYm91bmRWYW8gIT0gbnVsbCAmJiBidWYgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFvSW5mbyA9IHRoaXMuYm91bmRWYW8uX2luZm87XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1ZmZlclVpZCA9IGJ1Zi51aWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBiaW5kaW5nSW5mbyA9IHZhb0luZm8uYmluZGluZ3MuZmluZCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQuYnVmZmVyX3VpZCA9PSBidWZmZXJVaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmluZGluZ0luZm8gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5kaW5nSW5mbyA9IHsgYnVmZmVyX3VpZDogYnVmZmVyVWlkLCBhdHRyaWJ1dGVzOiBbXSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFvSW5mby5iaW5kaW5ncy5wdXNoKGJpbmRpbmdJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5kaW5nSW5mby5hdHRyaWJ1dGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9pbnRlcjogJ3ZlcnRleEF0dHJpYklQb2ludGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IGNvbW1hbmQuc2l6ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGNvbW1hbmQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cmlkZTogY29tbWFuZC5zdHJpZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvZmZzZXQ6IGNvbW1hbmQub2Zmc2V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3VuZFZhby5faW5mbyA9IHZhb0luZm87XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoY29tbWFuZC5jbWQgPT0gJ3ZlcnRleEF0dHJpYlBvaW50ZXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wudmVydGV4QXR0cmliUG9pbnRlcihpbmRleCwgY29tbWFuZC5zaXplLCBnbFtjb21tYW5kLnR5cGVdLCBjb21tYW5kLm5vcm1hbGl6ZWQsIGNvbW1hbmQuc3RyaWRlLCBjb21tYW5kLm9mZnNldCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuYm91bmRWYW8gIT0gbnVsbCAmJiBidWYgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFvSW5mbyA9IHRoaXMuYm91bmRWYW8uX2luZm87XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1ZmZlclVpZCA9IGJ1Zi51aWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBiaW5kaW5nSW5mbyA9IHZhb0luZm8uYmluZGluZ3MuZmluZCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQuYnVmZmVyX3VpZCA9PSBidWZmZXJVaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmluZGluZ0luZm8gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5kaW5nSW5mbyA9IHsgYnVmZmVyX3VpZDogYnVmZmVyVWlkLCBhdHRyaWJ1dGVzOiBbXSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFvSW5mby5iaW5kaW5ncy5wdXNoKGJpbmRpbmdJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiaW5kaW5nSW5mby5hdHRyaWJ1dGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9pbnRlcjogJ3ZlcnRleEF0dHJpYlBvaW50ZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogY29tbWFuZC5zaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogY29tbWFuZC50eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9ybWFsaXplZDogY29tbWFuZC5ub3JtYWxpemVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RyaWRlOiBjb21tYW5kLnN0cmlkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9mZnNldDogY29tbWFuZC5vZmZzZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmJvdW5kVmFvLl9pbmZvID0gdmFvSW5mbztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmNtZCA9PSAnZW5hYmxlVmVydGV4QXR0cmliQXJyYXknKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2wuZW5hYmxlVmVydGV4QXR0cmliQXJyYXkoaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoY29tbWFuZC5jbWQgPT0gJ2Rpc2FibGVWZXJ0ZXhBdHRyaWJBcnJheScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC5kaXNhYmxlVmVydGV4QXR0cmliQXJyYXkoaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoY29tbWFuZC5jbWQgPT0gJ3ZlcnRleEF0dHJpYlsxMjM0XWZ2Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5zaGFwZVswXSA9PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYjFmdihpbmRleCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5zaGFwZVswXSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYjJmdihpbmRleCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5zaGFwZVswXSA9PSAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYjNmdihpbmRleCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5zaGFwZVswXSA9PSA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYjRmdihpbmRleCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGNvbW1hbmQuY21kID09ICd2ZXJ0ZXhBdHRyaWJJNFt1XWl2Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5kdHlwZSA9PSAndWludDMyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC52ZXJ0ZXhBdHRyaWJJNHVpdihpbmRleCwgY29udmVydGVkQnVmZmVyc1tjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmJ1ZmZlcl9tZXRhZGF0YS5kdHlwZSA9PSAnaW50MzInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnZlcnRleEF0dHJpYkk0aXYoaW5kZXgsIGNvbnZlcnRlZEJ1ZmZlcnNbY29tbWFuZC5idWZmZXJfbWV0YWRhdGEuaW5kZXhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChjb21tYW5kLmNtZCA9PSAndmVydGV4QXR0cmliRGl2aXNvcicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC52ZXJ0ZXhBdHRyaWJEaXZpc29yKGluZGV4LCBjb21tYW5kLmRpdmlzb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgYXR0cmlidXRlICR7Y29tbWFuZC5pbmRleH0gbG9jYXRpb24gbm90IGZvdW5kYCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIFJFTkRFUiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgY2FzZSAnZHJhd0FycmF5cyc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBnbC5kcmF3QXJyYXlzKGdsW2NvbW1hbmQubW9kZV0sIGNvbW1hbmQuZmlyc3QsIGNvbW1hbmQuY291bnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2RyYXdBcnJheXNJbnN0YW5jZWQnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2wuZHJhd0FycmF5c0luc3RhbmNlZChnbFtjb21tYW5kLm1vZGVdLCBjb21tYW5kLmZpcnN0LCBjb21tYW5kLmNvdW50LCBjb21tYW5kLmluc3RhbmNlX2NvdW50KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdkcmF3RWxlbWVudHMnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2wuZHJhd0VsZW1lbnRzKGdsW2NvbW1hbmQubW9kZV0sIGNvbW1hbmQuY291bnQsIGdsW2NvbW1hbmQuYnl0ZV90eXBlXSwgY29tbWFuZC5vZmZzZXQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2RyYXdFbGVtZW50c0luc3RhbmNlZCc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBnbC5kcmF3RWxlbWVudHNJbnN0YW5jZWQoZ2xbY29tbWFuZC5tb2RlXSwgY29tbWFuZC5jb3VudCwgZ2xbY29tbWFuZC5ieXRlX3R5cGVdLCBjb21tYW5kLm9mZnNldCwgY29tbWFuZC5pbnN0YW5jZV9jb3VudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBGUkFNRUJVRkZFUiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgY2FzZSAnY3JlYXRlRnJhbWVidWZmZXInOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3UmVzb3VyY2UgPSBuZXcgR0xSZXNvdXJjZSgpO1xuICAgICAgICAgICAgICAgICAgICBuZXdSZXNvdXJjZS51aWQgPSBjb21tYW5kLnJlc291cmNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUmVzb3VyY2UobmV3UmVzb3VyY2UpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLnJlc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHRyID0gZ2wuY3JlYXRlRnJhbWVidWZmZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzLl9nbF9wdHIgPSBwdHI7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5faW5mbyA9IHsgdHlwZTogJ0ZyYW1lYnVmZmVyJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2JpbmRGcmFtZWJ1ZmZlcic6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29tbWFuZC5mcmFtZWJ1ZmZlciA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gdGhpcy5nZXRSZXNvdXJjZShjb21tYW5kLmZyYW1lYnVmZmVyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRGcmFtZWJ1ZmZlcihnbFtjb21tYW5kLnRhcmdldF0sIHJlcy5fZ2xfcHRyKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRGcmFtZWJ1ZmZlcihnbFtjb21tYW5kLnRhcmdldF0sIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnZnJhbWVidWZmZXJUZXh0dXJlMkQnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IHRoaXMuZ2V0UmVzb3VyY2UoY29tbWFuZC50ZXh0dXJlKTtcbiAgICAgICAgICAgICAgICAgICAgZ2wuZnJhbWVidWZmZXJUZXh0dXJlMkQoZ2xbY29tbWFuZC50YXJnZXRdLCBnbFtjb21tYW5kLmF0dGFjaG1lbnRdLCBnbFtjb21tYW5kLnRleHRhcmdldF0sIHJlcy5fZ2xfcHRyLCBjb21tYW5kLmxldmVsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdkcmF3QnVmZmVycyc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWZmZXJzID0gY29tbWFuZC5idWZmZXJzLm1hcCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdsW2VsZW1lbnRdO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgZ2wuZHJhd0J1ZmZlcnMoYnVmZmVycyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuICAgIGV4ZWN1dGVDb21tYW5kcyhtb2RlbCwgY29tbWFuZHMsIGNvbnZlcnRlZEJ1ZmZlcnMpIHtcbiAgICAgICAgaWYgKHRoaXMuY3R4ID09PSBudWxsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZ2wgPSB0aGlzLmN0eDtcbiAgICAgICAgdGhpcy5jYXB0dXJlRnJhbWUoKTtcbiAgICAgICAgLy8gdXBkYXRlIGNhbWVyYVxuICAgICAgICB0aGlzLnVwZGF0ZUNhbWVyYShtb2RlbCk7XG4gICAgICAgIC8vIHVwZGF0ZSB0aGUgdW5pZm9ybSBibG9jazpcbiAgICAgICAgY29uc3QgaXNSb3dNYWpvciA9IG1vZGVsLmdldCgnc2hhZGVyX21hdHJpeF9tYWpvcicpID09ICdyb3dfbWFqb3InO1xuICAgICAgICBsZXQgY20gPSBpc1Jvd01ham9yID8gbTRUcmFuc3Bvc2UodGhpcy5jYW1lcmFNYXRyaXgpIDogdGhpcy5jYW1lcmFNYXRyaXg7XG4gICAgICAgIGNvbnN0IGNtX2YzMiA9IG5ldyBGbG9hdDMyQXJyYXkoY20pO1xuICAgICAgICBsZXQgdm0gPSBpc1Jvd01ham9yID8gbTRUcmFuc3Bvc2UodGhpcy52aWV3TWF0cml4KSA6IHRoaXMudmlld01hdHJpeDtcbiAgICAgICAgY29uc3Qgdm1fZjMyID0gbmV3IEZsb2F0MzJBcnJheSh2bSk7XG4gICAgICAgIGxldCBwbSA9IGlzUm93TWFqb3JcbiAgICAgICAgICAgID8gbTRUcmFuc3Bvc2UodGhpcy5wcm9qZWN0aW9uTWF0cml4KVxuICAgICAgICAgICAgOiB0aGlzLnByb2plY3Rpb25NYXRyaXg7XG4gICAgICAgIGNvbnN0IHBtX2YzMiA9IG5ldyBGbG9hdDMyQXJyYXkocG0pO1xuICAgICAgICBsZXQgdnBtID0gaXNSb3dNYWpvclxuICAgICAgICAgICAgPyBtNFRyYW5zcG9zZSh0aGlzLnZpZXdQcm9qTWF0cml4KVxuICAgICAgICAgICAgOiB0aGlzLnZpZXdQcm9qTWF0cml4O1xuICAgICAgICBjb25zdCB2cG1fZjMyID0gbmV3IEZsb2F0MzJBcnJheSh2cG0pO1xuICAgICAgICBnbC5iaW5kQnVmZmVyKGdsLlVOSUZPUk1fQlVGRkVSLCB0aGlzLnZpZXdCbG9jayk7XG4gICAgICAgIGdsLmJ1ZmZlclN1YkRhdGEoZ2wuVU5JRk9STV9CVUZGRVIsIDAsIGNtX2YzMiwgMCk7XG4gICAgICAgIGdsLmJ1ZmZlclN1YkRhdGEoZ2wuVU5JRk9STV9CVUZGRVIsIDY0LCB2bV9mMzIsIDApO1xuICAgICAgICBnbC5idWZmZXJTdWJEYXRhKGdsLlVOSUZPUk1fQlVGRkVSLCAxMjgsIHBtX2YzMiwgMCk7XG4gICAgICAgIGdsLmJ1ZmZlclN1YkRhdGEoZ2wuVU5JRk9STV9CVUZGRVIsIDE5MiwgdnBtX2YzMiwgMCk7XG4gICAgICAgIGdsLmJpbmRCdWZmZXIoZ2wuVU5JRk9STV9CVUZGRVIsIG51bGwpO1xuICAgICAgICBjb21tYW5kcy5mb3JFYWNoKChjb21tYW5kKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmV4ZWN1dGVDb21tYW5kKG1vZGVsLCBnbCwgY29tbWFuZCwgY29udmVydGVkQnVmZmVycyk7XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAobW9kZWwuZ2V0KCdzeW5jX2ltYWdlX2RhdGEnKSkge1xuICAgICAgICAgICAgY29uc3Qgd2lkdGggPSBtb2RlbC5nZXQoJ3dpZHRoJyk7XG4gICAgICAgICAgICBjb25zdCBoZWlnaHQgPSBtb2RlbC5nZXQoJ2hlaWdodCcpO1xuICAgICAgICAgICAgY29uc3QgcGl4ZWxzID0gbmV3IFVpbnQ4Q2xhbXBlZEFycmF5KHdpZHRoICogaGVpZ2h0ICogNCk7XG4gICAgICAgICAgICBnbC5yZWFkUGl4ZWxzKDAsIDAsIHdpZHRoLCBoZWlnaHQsIGdsLlJHQkEsIGdsLlVOU0lHTkVEX0JZVEUsIHBpeGVscyk7XG4gICAgICAgICAgICBtb2RlbC5zZXQoJ2ltYWdlX2RhdGEnLCBwaXhlbHMpO1xuICAgICAgICAgICAgbW9kZWwuc2F2ZV9jaGFuZ2VzKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaGFuZGxlQ3VzdG9tTWVzc2FnZXMobW9kZWwsIGNvbW1hbmQsIGJ1ZmZlcnMpIHtcbiAgICAgICAgaWYgKGNvbW1hbmQuY2xlYXIgPT0gdHJ1ZSkge1xuICAgICAgICAgICAgdGhpcy5jb21tYW5kcyA9IFtdO1xuICAgICAgICAgICAgdGhpcy5idWZmZXJzID0gW107XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGNvbW1hbmRzID0gY29tbWFuZC5jb21tYW5kcztcbiAgICAgICAgbGV0IGNvbnZlcnRlZEJ1ZmZlcnMgPSBbXTtcbiAgICAgICAgY29tbWFuZHMuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGVsZW1lbnQuaGFzT3duUHJvcGVydHkoJ2J1ZmZlcl9tZXRhZGF0YScpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY29udmVydGVkID0gYnVmZmVyVG9BcnJheShlbGVtZW50LmJ1ZmZlcl9tZXRhZGF0YS5kdHlwZSwgYnVmZmVyc1tlbGVtZW50LmJ1ZmZlcl9tZXRhZGF0YS5pbmRleF0uYnVmZmVyKTtcbiAgICAgICAgICAgICAgICBjb252ZXJ0ZWRCdWZmZXJzLnB1c2goY29udmVydGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIG9ubHkgZXhlY3V0ZSBvbmNlXG4gICAgICAgIGlmIChjb21tYW5kLm9ubHlfb25jZSA9PSB0cnVlKSB7XG4gICAgICAgICAgICB0aGlzLmV4ZWN1dGVDb21tYW5kcyhtb2RlbCwgY29tbWFuZHMsIGNvbnZlcnRlZEJ1ZmZlcnMpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIHBlcnNpc3RlbnQgZXhlY3V0aW9uIGJ5IGFjY211bGF0aW5nIHNlcGFyYXRlIGJ1ZmZlcnNcbiAgICAgICAgbGV0IGJ1ZmZlcklkT2Zmc2V0ID0gdGhpcy5idWZmZXJzLmxlbmd0aDtcbiAgICAgICAgdGhpcy5idWZmZXJzID0gdGhpcy5idWZmZXJzLmNvbmNhdChjb252ZXJ0ZWRCdWZmZXJzKTtcbiAgICAgICAgY29tbWFuZHMuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGVsZW1lbnQuaGFzT3duUHJvcGVydHkoJ2J1ZmZlcl9tZXRhZGF0YScpKSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5idWZmZXJfbWV0YWRhdGEuaW5kZXggKz0gYnVmZmVySWRPZmZzZXQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbW1hbmRzID0gdGhpcy5jb21tYW5kcy5jb25jYXQoY29tbWFuZHMpO1xuICAgICAgICB0aGlzLnJ1bkNvbW1hbmRzKG1vZGVsKTtcbiAgICB9XG4gICAgcnVuQ29tbWFuZHMobW9kZWwpIHtcbiAgICAgICAgdGhpcy5leGVjdXRlQ29tbWFuZHMobW9kZWwsIHRoaXMuY29tbWFuZHMsIHRoaXMuYnVmZmVycyk7XG4gICAgfVxuICAgIHJlZ2lzdGVyUmVzb3VyY2UocmVzb3VyY2UpIHtcbiAgICAgICAgaWYgKHJlc291cmNlLnVpZCAhPT0gdGhpcy5yZXNvdXJjZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCd1aWQgbm90IG1hdGNoaW5nIHdoYXQgd2UgaGF2ZSBpbnRlcm5hbGx5Jyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZXNvdXJjZXMucHVzaChyZXNvdXJjZSk7XG4gICAgfVxuICAgIGdldFJlc291cmNlKGluZGV4KSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc291cmNlc1tpbmRleF07XG4gICAgfVxuICAgIGdldFJlc291cmNlSW5mbyhpbmRleCkge1xuICAgICAgICBpZiAoaW5kZXggPCAwIHx8IGluZGV4ID49IHRoaXMucmVzb3VyY2VzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMucmVzb3VyY2VzW2luZGV4XS5faW5mbztcbiAgICB9XG4gICAgcmVuZGVyUmVzaXplQ2FudmFzKG1vZGVsKSB7XG4gICAgICAgIHRoaXMuY2FudmFzLnNldEF0dHJpYnV0ZSgnd2lkdGgnLCBtb2RlbC5nZXQoJ3dpZHRoJykpO1xuICAgICAgICB0aGlzLmNhbnZhcy5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIG1vZGVsLmdldCgnaGVpZ2h0JykpO1xuICAgICAgICB0aGlzLnJlc2l6ZUNhbnZhcyhtb2RlbCk7XG4gICAgfVxuICAgIHJlcXVlc3RSZWRyYXcobW9kZWwpIHtcbiAgICAgICAgaWYgKHRoaXMud2lsbFJlZHJhdyA9PSBmYWxzZSkge1xuICAgICAgICAgICAgdGhpcy53aWxsUmVkcmF3ID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB0aGlzLnJlZHJhdyhtb2RlbCkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJlZHJhdyhtb2RlbCkge1xuICAgICAgICB0aGlzLndpbGxSZWRyYXcgPSBmYWxzZTtcbiAgICAgICAgLy8gdXBkYXRlIG1vdmVtZW50IGlmIG5lZWRlZFxuICAgICAgICBpZiAodGhpcy5tb3ZlRGlyZWN0aW9uWzBdIHx8XG4gICAgICAgICAgICB0aGlzLm1vdmVEaXJlY3Rpb25bMV0gfHxcbiAgICAgICAgICAgIHRoaXMubW92ZURpcmVjdGlvblsyXSB8fFxuICAgICAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uWzNdKSB7XG4gICAgICAgICAgICBsZXQgc3BlZWQgPSBtb2RlbC5nZXQoJ21vdmVfc3BlZWQnKTtcbiAgICAgICAgICAgIGxldCBmb3J3YXJkQXhpcyA9IG00R2V0Q29sdW1uSyh0aGlzLmNhbWVyYU1hdHJpeCk7XG4gICAgICAgICAgICBsZXQgc2lkZUF4aXMgPSBtNEdldENvbHVtbkkodGhpcy5jYW1lcmFNYXRyaXgpO1xuICAgICAgICAgICAgbGV0IGNhbWVyYVBvcyA9IG1vZGVsLmdldCgnY2FtZXJhX3BvcycpO1xuICAgICAgICAgICAgaWYgKHRoaXMubW92ZURpcmVjdGlvblswXSkge1xuICAgICAgICAgICAgICAgIGNhbWVyYVBvcyA9IHYzQWRkKGNhbWVyYVBvcywgdjNTY2FsZShmb3J3YXJkQXhpcywgLXNwZWVkKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5tb3ZlRGlyZWN0aW9uWzJdKSB7XG4gICAgICAgICAgICAgICAgY2FtZXJhUG9zID0gdjNBZGQoY2FtZXJhUG9zLCB2M1NjYWxlKGZvcndhcmRBeGlzLCBzcGVlZCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMubW92ZURpcmVjdGlvblsxXSkge1xuICAgICAgICAgICAgICAgIGNhbWVyYVBvcyA9IHYzQWRkKGNhbWVyYVBvcywgdjNTY2FsZShzaWRlQXhpcywgLXNwZWVkKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5tb3ZlRGlyZWN0aW9uWzNdKSB7XG4gICAgICAgICAgICAgICAgY2FtZXJhUG9zID0gdjNBZGQoY2FtZXJhUG9zLCB2M1NjYWxlKHNpZGVBeGlzLCBzcGVlZCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbW9kZWwuc2V0KCdjYW1lcmFfcG9zJywgY2FtZXJhUG9zKTtcbiAgICAgICAgICAgIG1vZGVsLnNhdmVfY2hhbmdlcygpO1xuICAgICAgICAgICAgLy8gcmVxdWVzdCBhIG5ldyBmcmFtZSBpZiB3ZSBhcmUgbW92aW5nOlxuICAgICAgICAgICAgdGhpcy5yZXF1ZXN0UmVkcmF3KG1vZGVsKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBvbk1vdXNlTW92ZShtb2RlbCwgZXZlbnQpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNNb3VzZURvd24pIHtcbiAgICAgICAgICAgIGxldCBzcGVlZCA9IG1vZGVsLmdldCgnbW91c2Vfc3BlZWQnKTtcbiAgICAgICAgICAgIG1vZGVsLnNldCgnY2FtZXJhX3lhdycsIG1vZGVsLmdldCgnY2FtZXJhX3lhdycpIC0gZXZlbnQubW92ZW1lbnRYICogMC4xICogc3BlZWQpO1xuICAgICAgICAgICAgbW9kZWwuc2V0KCdjYW1lcmFfcGl0Y2gnLCBtb2RlbC5nZXQoJ2NhbWVyYV9waXRjaCcpIC0gZXZlbnQubW92ZW1lbnRZICogMC4xICogc3BlZWQpO1xuICAgICAgICAgICAgbW9kZWwuc2F2ZV9jaGFuZ2VzKCk7XG4gICAgICAgICAgICB0aGlzLnJlcXVlc3RSZWRyYXcobW9kZWwpO1xuICAgICAgICB9XG4gICAgfVxuICAgIG9uTW91c2VEb3duKGV2ZW50KSB7XG4gICAgICAgIHRoaXMuaXNNb3VzZURvd24gPSB0cnVlO1xuICAgICAgICB0aGlzLmNhbnZhcy5mb2N1cygpO1xuICAgIH1cbiAgICBvbk1vdXNlVXAoZXZlbnQpIHtcbiAgICAgICAgdGhpcy5pc01vdXNlRG93biA9IGZhbHNlO1xuICAgIH1cbiAgICBvbk1vdXNlT3V0KGV2ZW50KSB7XG4gICAgICAgIHRoaXMuaXNNb3VzZURvd24gPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uID0gW2ZhbHNlLCBmYWxzZSwgZmFsc2UsIGZhbHNlXTtcbiAgICB9XG4gICAgYXN5bmMgb25LZXlEb3duKG1vZGVsLCBldmVudCkge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgbGV0IGtleXMgPSBtb2RlbC5nZXQoJ21vdmVfa2V5cycpO1xuICAgICAgICBsZXQgY2FwdHVyZUtleSA9IG1vZGVsLmdldCgnY2FwdHVyZV9mcmFtZV9rZXknKTtcbiAgICAgICAgaWYgKGV2ZW50LnJlcGVhdCA9PSBmYWxzZSkge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PSBrZXlzWzBdKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uWzBdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlcXVlc3RSZWRyYXcobW9kZWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoZXZlbnQua2V5ID09IGtleXNbMV0pIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1vdmVEaXJlY3Rpb25bMV0gPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMucmVxdWVzdFJlZHJhdyhtb2RlbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChldmVudC5rZXkgPT0ga2V5c1syXSkge1xuICAgICAgICAgICAgICAgIHRoaXMubW92ZURpcmVjdGlvblsyXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5yZXF1ZXN0UmVkcmF3KG1vZGVsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50LmtleSA9PSBrZXlzWzNdKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uWzNdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlcXVlc3RSZWRyYXcobW9kZWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoZXZlbnQua2V5ID09IGNhcHR1cmVLZXkpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnJlcXVlc3RTcGVjdG9yU3RhcnQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnJ1bkNvbW1hbmRzKG1vZGVsKTtcbiAgICAgICAgICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlcXVlc3RTcGVjdG9yU3RvcCgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIG9uS2V5VXAobW9kZWwsIGV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBsZXQga2V5cyA9IG1vZGVsLmdldCgnbW92ZV9rZXlzJyk7XG4gICAgICAgIGlmIChldmVudC5rZXkgPT0ga2V5c1swXSkge1xuICAgICAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uWzBdID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZXZlbnQua2V5ID09IGtleXNbMV0pIHtcbiAgICAgICAgICAgIHRoaXMubW92ZURpcmVjdGlvblsxXSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGV2ZW50LmtleSA9PSBrZXlzWzJdKSB7XG4gICAgICAgICAgICB0aGlzLm1vdmVEaXJlY3Rpb25bMl0gPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChldmVudC5rZXkgPT0ga2V5c1szXSkge1xuICAgICAgICAgICAgdGhpcy5tb3ZlRGlyZWN0aW9uWzNdID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmVuZGVyKG1vZGVsLCBlbCkge1xuICAgICAgICBlbC5hcHBlbmRDaGlsZCh0aGlzLmNhbnZhcyk7XG4gICAgICAgIHRoaXMucmVuZGVyUmVzaXplQ2FudmFzKG1vZGVsKTtcbiAgICAgICAgWyd3aWR0aCcsICdoZWlnaHQnXS5mb3JFYWNoKChwKSA9PiBtb2RlbC5vbihgY2hhbmdlOiR7cH1gLCAoKSA9PiB0aGlzLnJlbmRlclJlc2l6ZUNhbnZhcyhtb2RlbCkpKTtcbiAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgKGV2ZW50KSA9PiB0aGlzLm9uTW91c2VNb3ZlKG1vZGVsLCBldmVudCkpO1xuICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCAoZXZlbnQpID0+IHRoaXMub25Nb3VzZURvd24oZXZlbnQpKTtcbiAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIChldmVudCkgPT4gdGhpcy5vbk1vdXNlVXAoZXZlbnQpKTtcbiAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VvdXQnLCAoZXZlbnQpID0+IHRoaXMub25Nb3VzZU91dChldmVudCkpO1xuICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGV2ZW50KSA9PiB0aGlzLm9uS2V5RG93bihtb2RlbCwgZXZlbnQpKTtcbiAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCAoZXZlbnQpID0+IHRoaXMub25LZXlVcChtb2RlbCwgZXZlbnQpKTtcbiAgICAgICAgZWwuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICcwJyk7XG4gICAgfVxuICAgIGFzeW5jIGdldFNwZWN0b3JJbnN0YW5jZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuc3BlY3Rvcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3BlY3RvcjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBTID0gYXdhaXQgZW5zdXJlU3BlY3RvcigpO1xuICAgICAgICB0aGlzLnNwZWN0b3IgPSBuZXcgUy5TcGVjdG9yKCk7XG4gICAgICAgIHRoaXMuc3BlY3Rvci5vbkNhcHR1cmVTdGFydGVkLmFkZCgoaW5mbykgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ1tzcGVjdG9yXSBjYXB0dXJlIHN0YXJ0ZWQnLCBpbmZvKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuc3BlY3Rvci5vbkVycm9yLmFkZCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tzcGVjdG9yXSBlcnJvcicsIGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghdGhpcy5zcGVjdG9yU3BpZWQpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zcGVjdG9yLnNweUNhbnZhcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAvKiBpZiB0aGUgY2FudmFzIGlzIGFscmVhZHkgc3BpZWQsIHNraXAgaXQgKi9cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc3BlY3RvclNwaWVkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNwZWN0b3Iub25DYXB0dXJlLmFkZCgoY2FwdHVyZSkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW0pTT04uc3RyaW5naWZ5KGNhcHR1cmUsIG51bGwsIDIpXSwge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgICAgICAgICAgICBhLmhyZWYgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgICAgICAgICAgIGEuZG93bmxvYWQgPSAnc3BlY3Rvcl9jYXB0dXJlLmpzb24nO1xuICAgICAgICAgICAgICAgIGEuY2xpY2soKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdzcGVjdG9yIGNhcHR1cmUgZG93bmxvYWQgZmFpbGVkOiAnLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0aGlzLnNwZWN0b3I7XG4gICAgfVxuICAgIGFzeW5jIHJlcXVlc3RTcGVjdG9yQ2FwdHVyZU5leHQocXVpY2sgPSBmYWxzZSkge1xuICAgICAgICAvLyB3YWl0IHVudGlsIHNwZWN0b3IgaXMgaW5pdGlhbGl6ZWRcbiAgICAgICAgYXdhaXQgdGhpcy5nZXRTcGVjdG9ySW5zdGFuY2UoKTtcbiAgICAgICAgdGhpcy5zcGVjdG9yQXV0b09uY2UgPSB0cnVlO1xuICAgIH1cbiAgICBhc3luYyByZXF1ZXN0U3BlY3RvclN0YXJ0KGNvbW1hbmRDb3VudCA9IDUwMDAwLCBxdWljayA9IGZhbHNlKSB7XG4gICAgICAgIC8vIHdhaXQgdW50aWwgc3BlY3RvciBpcyBpbml0aWFsaXplZFxuICAgICAgICBjb25zdCBTID0gYXdhaXQgdGhpcy5nZXRTcGVjdG9ySW5zdGFuY2UoKTtcbiAgICAgICAgUy5zdGFydENhcHR1cmUodGhpcy5jdHgsIGNvbW1hbmRDb3VudCwgcXVpY2spO1xuICAgICAgICB0aGlzLnNwZWN0b3JBY3RpdmUgPSB0cnVlO1xuICAgIH1cbiAgICBhc3luYyByZXF1ZXN0U3BlY3RvclN0b3AoKSB7XG4gICAgICAgIC8vIHdhaXQgdW50aWwgc3BlY3RvciBpcyBpbml0aWFsaXplZFxuICAgICAgICBjb25zdCBTID0gYXdhaXQgdGhpcy5nZXRTcGVjdG9ySW5zdGFuY2UoKTtcbiAgICAgICAgaWYgKHRoaXMuc3BlY3RvckFjdGl2ZSkge1xuICAgICAgICAgICAgUy5zdG9wQ2FwdHVyZSgpO1xuICAgICAgICAgICAgdGhpcy5zcGVjdG9yQWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2FwdHVyZUZyYW1lKCkge1xuICAgICAgICBpZiAoIXRoaXMuc3BlY3RvciB8fCAhdGhpcy5jdHgpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zcGVjdG9yQXV0b09uY2UpIHtcbiAgICAgICAgICAgIHRoaXMuc3BlY3RvckF1dG9PbmNlID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLnNwZWN0b3IuY2FwdHVyZU5leHRGcmFtZSh0aGlzLmN0eCk7XG4gICAgICAgIH1cbiAgICB9XG59XG4vLyBleHBvcnQgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZVxuZXhwb3J0IGNvbnN0IGdsQ29udGV4dCA9IEdMQ29udGV4dC5nZXRJbnN0YW5jZSgpO1xuIiwiaW1wb3J0IHsgZ2xDb250ZXh0IH0gZnJvbSAnLi93ZWJnbGNvbnRleHQnO1xuZnVuY3Rpb24gZGlzcGxheUpzb24oanNvbiwgcGFyZW50KSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4ganNvbikge1xuICAgICAgICBjb25zdCBqc29uS2V5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgIGpzb25LZXkuY2xhc3NMaXN0LmFkZCgnc3NlcHl3aWRnZXQtanNvbi1rZXknKTtcbiAgICAgICAganNvbktleS50ZXh0Q29udGVudCA9IGAke2tleX06YDtcbiAgICAgICAgY29uc3QganNvblZhbHVlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgIGpzb25WYWx1ZS5jbGFzc0xpc3QuYWRkKCdzc2VweXdpZGdldC1qc29uLXZhbHVlJyk7XG4gICAgICAgIGlmICh0eXBlb2YganNvbltrZXldID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgY29uc3QgbmVzdGVkSnNvbkRpc3BsYXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgIG5lc3RlZEpzb25EaXNwbGF5LmNsYXNzTGlzdC5hZGQoJ3NzZXB5d2lkZ2V0LWpzb24tZGlzcGxheScpO1xuICAgICAgICAgICAgZGlzcGxheUpzb24oanNvbltrZXldLCBuZXN0ZWRKc29uRGlzcGxheSk7XG4gICAgICAgICAgICBqc29uVmFsdWUuYXBwZW5kQ2hpbGQobmVzdGVkSnNvbkRpc3BsYXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAganNvblZhbHVlLnRleHRDb250ZW50ID0ganNvbltrZXldO1xuICAgICAgICB9XG4gICAgICAgIHBhcmVudC5hcHBlbmRDaGlsZChqc29uS2V5KTtcbiAgICAgICAgcGFyZW50LmFwcGVuZENoaWxkKGpzb25WYWx1ZSk7XG4gICAgfVxufVxuZnVuY3Rpb24gaW5pdGlhbGl6ZSh7IG1vZGVsIH0pIHsgfVxuZnVuY3Rpb24gcmVuZGVyKHsgbW9kZWwsIGVsIH0pIHtcbiAgICBjb25zdCByb290ID0gZWw7XG4gICAgY29uc3QganNvbkRpc3BsYXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBqc29uRGlzcGxheS5jbGFzc0xpc3QuYWRkKCdzc2VweXdpZGdldC1qc29uLWRpc3BsYXknKTtcbiAgICBjb25zdCBqc29uS2V5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAganNvbktleS5jbGFzc0xpc3QuYWRkKCdzc2VweXdpZGdldC1qc29uLWtleScpO1xuICAgIGpzb25LZXkudGV4dENvbnRlbnQgPSAndWlkOic7XG4gICAgY29uc3QganNvblZhbHVlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAganNvblZhbHVlLmNsYXNzTGlzdC5hZGQoJ3NzZXB5d2lkZ2V0LWpzb24tdmFsdWUnKTtcbiAgICBqc29uVmFsdWUudGV4dENvbnRlbnQgPSBtb2RlbC5nZXQoJ3VpZCcpO1xuICAgIGpzb25EaXNwbGF5LmFwcGVuZENoaWxkKGpzb25LZXkpO1xuICAgIGpzb25EaXNwbGF5LmFwcGVuZENoaWxkKGpzb25WYWx1ZSk7XG4gICAgY29uc3QgaW5mbyA9IGdsQ29udGV4dC5nZXRSZXNvdXJjZUluZm8obW9kZWwuZ2V0KCd1aWQnKSk7XG4gICAgaWYgKGluZm8gIT09IG51bGwpIHtcbiAgICAgICAgZGlzcGxheUpzb24oaW5mbywganNvbkRpc3BsYXkpO1xuICAgIH1cbiAgICByb290LmFwcGVuZENoaWxkKGpzb25EaXNwbGF5KTtcbn1cbmV4cG9ydCBkZWZhdWx0IHsgaW5pdGlhbGl6ZSwgcmVuZGVyIH07XG4iLCJpbXBvcnQgeyBnbENvbnRleHQgfSBmcm9tICcuL3dlYmdsY29udGV4dCc7XG5mdW5jdGlvbiBpbml0aWFsaXplKHsgbW9kZWwgfSkge1xuICAgIGdsQ29udGV4dC5pbml0aWFsaXplKG1vZGVsKTtcbn1cbmZ1bmN0aW9uIHJlbmRlcih7IG1vZGVsLCBlbCB9KSB7XG4gICAgZ2xDb250ZXh0LnJlbmRlcihtb2RlbCwgZWwpO1xufVxuZXhwb3J0IGRlZmF1bHQgeyBpbml0aWFsaXplLCByZW5kZXIgfTtcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiaW1wb3J0IGdsVmlld2VyIGZyb20gJy4vZ2x2aWV3ZXInO1xuaW1wb3J0IGdsUmVzb3VyY2UgZnJvbSAnLi9nbHJlc291cmNlJztcbmNvbnN0IHJlZ2lzdHJ5ID0ge1xuICAgIGdsdmlld2VyOiBnbFZpZXdlcixcbiAgICBnbHJlc291cmNlOiBnbFJlc291cmNlLFxufTtcbmZ1bmN0aW9uIGdldEZyb21SZWdpc3RyeShtb2RlbCkge1xuICAgIGNvbnN0IGtpbmQgPSBtb2RlbC5nZXQoJ2tpbmQnKTtcbiAgICByZXR1cm4gcmVnaXN0cnlba2luZF07XG59XG5leHBvcnQgZGVmYXVsdCAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5pdGlhbGl6ZSh7IG1vZGVsIH0pIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW1wbCA9IGdldEZyb21SZWdpc3RyeShtb2RlbCk7XG4gICAgICAgICAgICAgICAgaWYgKCFpbXBsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignW2V4dF0gbm8gaW1wbCBmb3VuZCBmb3Iga2luZCcpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGltcGwuaW5pdGlhbGl6ZT8uKHsgbW9kZWwgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW2V4dF0gaW5pdGlhbGl6ZSBlcnJvcicsIGVycik7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICByZW5kZXIoeyBtb2RlbCwgZWwgfSkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbXBsID0gZ2V0RnJvbVJlZ2lzdHJ5KG1vZGVsKTtcbiAgICAgICAgICAgICAgICBpZiAoIWltcGwpIHtcbiAgICAgICAgICAgICAgICAgICAgZWwudGV4dENvbnRlbnQgPSAnW2V4dF0gbm8gaW1wbCBmb3IgZ2l2ZW4ga2luZCc7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW1wbC5yZW5kZXIoeyBtb2RlbCwgZWwgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW2V4dF0gcmVuZGVyIGVycm9yJywgZXJyKTtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgfTtcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=