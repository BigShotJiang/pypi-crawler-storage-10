from pathlib import Path
from ipywidgets import widget_serialization
from ipywidgets.widgets.trait_types import bytes_serialization
import anywidget
import traitlets as t
import numpy as np


def array_to_buffer(array: np.array):
    """turn a numpy array into a binary buffer"""
    # unsupported int64 array in JS
    if array.dtype == np.int64:
        array = array.astype(np.int32)

    # unsupported float16 array in JS
    if array.dtype == np.float16:
        array = array.astype(np.float32)

    # make sure it's congituous
    if not array.flags["C_CONTIGUOUS"]:
        array = np.ascontiguousarray(array)

    return {"shape": list(array.shape), "dtype": str(array.dtype)}, memoryview(
        array.flatten()
    )


_JS = Path(__file__).with_name("widget.js")
_EXTENSION_JS = Path(__file__).with_name("extension.js")
_EXTENSION_CSS = Path(__file__).with_name("extension.css")


class SsePyWidget(anywidget.AnyWidget):
    """minimal any widget-based widget"""

    _esm = _JS

    width = t.Int(640).tag(sync=True)
    height = t.Int(480).tag(sync=True)
    color = t.Unicode("lightblue").tag(sync=True)


class GLResourceWidget(anywidget.AnyWidget):
    """widget for GLResource"""

    # specify kind
    kind = t.Unicode("glresource").tag(sync=True)

    # the identifier wrapper
    uid = t.Int(-1).tag(sync=True)

    # context
    # _context = t.Instance(anywidget.AnyWidget).tag(sync=True, **widget_serialization)

    # specify js extension
    _esm = _EXTENSION_JS
    # specify css extension
    _css = _EXTENSION_CSS

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        return


class GLViewer(anywidget.AnyWidget):
    """the main widget for WebGL2"""

    # specify kind
    kind = t.Unicode("glviewer").tag(sync=True)

    # canvas width and height
    width = t.Int(640).tag(sync=True)
    height = t.Int(480).tag(sync=True)

    # camera
    camera_pos = t.List([0, 50, 200]).tag(sync=True)
    camera_yaw = t.Float(0).tag(sync=True)
    camera_pitch = t.Float(0).tag(sync=True)
    camera_fov = t.Float(50.0).tag(sync=True)
    camera_near = t.Float(1.0).tag(sync=True)
    camera_far = t.Float(5000.0).tag(sync=True)

    # input
    mouse_speed = t.Float(0.5).tag(sync=True)
    move_speed = t.Float(1).tag(sync=True)
    move_keys = t.Unicode("wasd").tag(sync=True)

    # webgl2 related:
    shader_matrix_major = t.Unicode("row_major").tag(sync=True)

    # retriving image data from WebGL2 canvas from the browser
    # - it only triggers when 'sync_image_data' is set to True
    sync_image_data = t.Bool(False).tag(sync=True)
    image_data = t.Bytes(default_value=None, allow_none=True, read_only=True).tag(
        sync=True, **bytes_serialization
    )

    # glview options:
    verbose = t.Int(0).tag(sync=True)

    # capture debugging frame
    capture_frame_key = t.Unicode("F10").tag(sync=True)

    # specify js extension
    _esm = _EXTENSION_JS
    # specify css extension
    _css = _EXTENSION_CSS

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # intermediate containers:
        self._resources = []
        self._commands = []
        self._buffers = []

    def resource(self, index: int):
        """return the resource used by the viewer"""
        return self._resources[index]

    def clear_commands(self):
        """clear the command buffers"""
        self._commands = []
        self._buffers = []

    def execute_commands(self, execute_once=False, clear_previous=True):
        """
        send the command buffers to the webgl frontend
        - when the commands buffer is sent, it will be cleared,you can then start to build a new command buffers
        - by default, the command buffers will stay in memory in frontend, so it can be reexecuted every time, you need to redraw the scene (e.g. camera move)

        args:
        - execute_once(bool, optional): do we execute this only once
        - clear_previous(bool, optional): do we replace the current commands or just append
        """
        self.send(
            {
                "commands": self._commands,
                "only_once": execute_once,
                "clear": clear_previous,
            },
            buffers=self._buffers,
        )
        self.clear_commands()

    def get_image_data(self):
        if self.image_data is None:
            raise Exception(
                "no image data, please activate the sync_image_data flag and render to canvas before using this function"
            )
        return np.flip(
            np.array(list(bytearray(self.image_data)), dtype=np.uint8).reshape(
                self.height, self.width, 4
            ),
            0,
        )

    def viewport(self, x: int, y: int, width: int, height: int):
        self._commands.append(
            {"cmd": "viewport", "x": x, "y": y, "width": width, "height": height}
        )

    def enable(
        self,
        blend=False,
        cull_face=False,
        depth_test=False,
        dither=False,
        polygon_offset_fill=False,
        sample_alpha_to_coverage=False,
        sample_coverage=False,
        sissor_test=False,
        stencil_test=False,
        rasterizer_discard=False,
    ):
        """
        append a enable command to the command buffers

        args:
        - blend(bool, optional): activate blending of the computed fragment color values
        - cull_face(bool, optional): activate culling of polygons
        - dither(bool, optional): activate depth comparison and updates to the depth buffer
        - polygon_offset_fill(bool, optional): activate adding an offset to depth values of polygon's fragments
        - sample_alpha_to_coverage(bool, optional): activate the computation of a temporary coverage value determined by the alpha value
        - sample_coverage(bool, optional): activate ANDing the fragment's coverage with the temporary coverage value
        - scissor_test(bool, optional): activate the scissor test that discards fragments that are outside of the scissor rectangle
        - stencil_test(bool, optional): activate stencil testing and updates to the stencil buffer
        - rasterizer_discard(bool, optional): primitives are discarded immediately before the rasterization stage, but after optional transform feedback stage
        """
        self._commands.append(
            {
                "cmd": "enable",
                "cull_face": cull_face,
                "depth_test": depth_test,
                "dither": dither,
                "polygon_offset_fill": polygon_offset_fill,
                "sample_alpha_to_coverage": sample_alpha_to_coverage,
                "sample_coverage": sample_coverage,
                "sissor_test": sissor_test,
                "stencil_test": stencil_test,
                "rasterizer_discard": rasterizer_discard,
            }
        )

    def disable(
        self,
        blend=False,
        cull_face=False,
        depth_test=False,
        dither=False,
        polygon_offset_fill=False,
        sample_alpha_to_coverage=False,
        sample_coverage=False,
        scissor_test=False,
        stencil_test=False,
        rasterizer_discard=False,
    ):
        """
        append a disable command to the command buffer
        args:
        - blend (bool, optional): deactivates  blending of the computed fragment color values
        - cull_face (bool, optional): deactivates  culling of polygons
        - depth_test (bool, optional): deactivates  depth comparisons and updates to the depth buffer
        - dither (bool, optional): deactivates  dithering of color components before they get written to the color buffer
        - polygon_offset_fill (bool, optional): deactivates  adding an offset to depth values of polygon's fragments. Defaults to False.
        - sample_alpha_to_coverage (bool, optional): deactivates  ates the computation of a temporary coverage value determined by the alpha value
        - sample_coverage (bool, optional): deactivates  ANDing the fragment's coverage with the temporary coverage value
        - scissor_test (bool, optional): deactivates  the scissor test that discards fragments that are outside of the scissor rectangle
        - stencil_test (bool, optional): deactivates  stencil testing and updates to the stencil buffer
        - rasterizer_discard (bool, optional): deactivates that primitives are discarded immediately before the rasterization stage, but after the optional transform feedback stage
        """
        self._commands.append(
            {
                "cmd": "disable",
                "blend": blend,
                "cull_face": cull_face,
                "depth_test": depth_test,
                "dither": dither,
                "polygon_offset_fill": polygon_offset_fill,
                "sample_alpha_to_coverage": sample_alpha_to_coverage,
                "sample_coverage": sample_coverage,
                "scissor_test": scissor_test,
                "stencil_test": stencil_test,
                "rasterizer_discard": rasterizer_discard,
            }
        )

    def clear_color(self, r: float, g: float, b: float, a: float):
        """
        append a clear color command to the command buffer
        args:
        - r (float): red component
        - g (float): green component
        - b (float): blue component
        - a (float): alpha component
        """
        self._commands.append(
            {
                "cmd": "clearColor",
                "r": float(r),
                "g": float(g),
                "b": float(b),
                "a": float(a),
            }
        )

    def clear(
        self, color_buffer_bit=True, depth_buffer_bit=True, stencil_buffer_bit=False
    ):
        """
        append a clear command to the command buffer
        args:
        - color_buffer_bit (bool, optional): clear the color buffer
        - depth_buffer_bit (bool, optional): clear the depth buffer
        - stencil_buffer_bit (bool, optional): clear the stencil buffer
        """
        self._commands.append(
            {
                "cmd": "clear",
                "color": color_buffer_bit,
                "depth": depth_buffer_bit,
                "stencil": stencil_buffer_bit,
            }
        )

    def cull_face(self, mode="BACK"):
        f"""
        append a cull face command to the command buffers
        - polygon culling is disabled by default
        - to enable or disable culling, use enable() or disable()

        args:
        - mode ({"FRONT", "BACK", "FRONT_AND_BACK"}, optional): specify whether front or back facing polygons are candidates for culling
        """
        if mode not in ["FRONT", "BACK", "FRONT_AND_BACK"]:
            raise AttributeError("invalid mode")
        self._commands.append({"cmd": "cullFace", "mode": mode})

    def front_face(self, mode="CCW"):
        """
        append a front face command to the command buffers

        args:
        - mode ({"CCW", "CW"}, optional): specify the winding order as counterclockwise or clockwise
        """
        if mode not in ["CCW", "CW"]:
            raise AttributeError("invalid mode")
        self._commands.append({"cmd": "frontFace", "mode": mode})

    def depth_func(self, func="LESS"):
        """
        append a depth function command to the command buffers

        args:
        - func ({'NEVER', 'LESS', 'EQUAL', 'LEQUAL', 'GREATER', 'NOTEQUAL', 'GEQUAL', 'ALWAYS'}, optional)
        """
        if func not in [
            "NEVER",
            "LESS",
            "EQUAL",
            "LEQUAL",
            "GREATER",
            "NOTEQUAL",
            "GEQUAL",
            "ALWAYS",
        ]:
            raise AttributeError("invalid function")
        self._commands.append({"cmd": "depthFunc", "func": func})

    def depth_mask(self, flag=True):
        """
        append a depth mask command to the command buffers

        args:
        - flag (bool, optional): specify whether or not writing into the depth buffer is enabled
        """
        self._commands.append({"cmd": "depthMask", "flag": flag})

    def depth_range(self, z_near=0.0, z_far=1.0):
        """
        append a depth range command to the command buffers

        args:
        - z_near (float, optional): specify the mapping of the near clipping plane to window or viewport coordinates
          - clamped to the range [0, 1]
          - must be less than or equal to z_far
        - z_far (float, optional): specify the mapping of the far clipping plane to window or viewport coordinates
          - clamped to the range [0, 1]
        """
        self._commands.append({"cmd": "depthRange", "z_near": z_near, "z_far": z_far})

    def blend_color(self, r: float, g: float, b: float, a: float):
        """
        append a blend color command to the command buffers

        args:
        - r (float): red [0, 1]
        - g (float): green [0, 1]
        - b (float): blue [0, 1]
        - a (float): alpha [0, 1]
        """
        self._commands.append(
            {
                "cmd": "blendColor",
                "r": float(r),
                "g": float(g),
                "b": float(b),
                "a": float(a),
            }
        )

    def blend_equation(self, mode: str):
        """
        append a blend equation command to the command buffers

        ['FUNC_ADD', 'FUNC_SUBTRACT', 'FUNC_REVERSE_SUBTRACT', 'MIN', 'MAX']

        args:
        - mode (str): how source and destination colors are combined
        """
        if mode not in [
            "FUNC_ADD",
            "FUNC_SUBTRACT",
            "FUNC_REVERSE_SUBTRACT",
            "MIN",
            "MAX",
        ]:
            raise AttributeError("invalid mode")
        self._commands.append({"cmd": "blendEquation", "mode": mode})

    def blend_equation_separate(self, mode_rgb: str, mode_alpha: str):
        """
        append a blend equation separate command to the command buffers

        ['FUNC_ADD', 'FUNC_SUBTRACT', 'FUNC_REVERSE_SUBTRACT', 'MIN', 'MAX']

        args:
        - mode_rgb (str): how the red, green, and blue components of source and destination colors are combined
        - mode_alpha (str): how the alpha component (transparency) of source and destination colors are combined
        """
        if mode_rgb not in [
            "FUNC_ADD",
            "FUNC_SUBTRACT",
            "FUNC_REVERSE_SUBTRACT",
            "MIN",
            "MAX",
        ]:
            raise AttributeError("invalid mode")
        if mode_alpha not in [
            "FUNC_ADD",
            "FUNC_SUBTRACT",
            "FUNC_REVERSE_SUBTRACT",
            "MIN",
            "MAX",
        ]:
            raise AttributeError("invalid mode")
        self._commands.append(
            {
                "cmd": "blendEquationSeparate",
                "mode_rgb": mode_rgb,
                "mode_alpha": mode_alpha,
            }
        )

    def blend_func(self, src_factor: str, dst_factor: str):
        """
        append a blend function command to the command buffers

        ['ZERO', 'ONE', 'SRC_COLOR', 'ONE_MINUS_SRC_COLOR', 'DST_COLOR', 'ONE_MINUS_DST_COLOR', 'SRC_ALPHA', 'ONE_MINUS_SRC_ALPHA', 'DST_ALPHA', 'ONE_MINUS_DST_ALPHA', 'CONSTANT_COLOR', 'ONE_MINUS_CONSTANT_COLOR', 'CONSTANT_ALPHA', 'ONE_MINUS_CONSTANT_ALPHA', 'SRC_ALPHA_SATURATE']

        args:
        - src_factor (str): a multiplier for the source blending factors
        - dst_factor (str): a multiplier for the destination blending factors
        """
        if src_factor not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid src_factor")
        if dst_factor not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid dst_factor")
        self._commands.append(
            {"cmd": "blendFunc", "s_factor": src_factor, "d_factor": dst_factor}
        )

    def blend_func_separate(
        self, src_rgb: str, dst_rgb: str, src_alpha: str, dst_alpha: str
    ):
        """
        append a blend function separate command to the command buffers

        ['ZERO', 'ONE', 'SRC_COLOR', 'ONE_MINUS_SRC_COLOR', 'DST_COLOR', 'ONE_MINUS_DST_COLOR', 'SRC_ALPHA', 'ONE_MINUS_SRC_ALPHA', 'DST_ALPHA', 'ONE_MINUS_DST_ALPHA', 'CONSTANT_COLOR', 'ONE_MINUS_CONSTANT_COLOR', 'CONSTANT_ALPHA', 'ONE_MINUS_CONSTANT_ALPHA', 'SRC_ALPHA_SATURATE']

        args:
        - src_rgb (str): a multiplier for the source blending factors
        - dst_rgb (str): a multiplier for the destination blending factors
        - src_alpha (str): a multiplier for the source blending factors
        - dst_alpha (str): a multiplier for the destination blending factors
        """
        if src_rgb not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid src_rgb")
        if dst_rgb not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid dst_rgb")
        if src_alpha not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid src_alpha")
        if dst_alpha not in [
            "ZERO",
            "ONE",
            "SRC_COLOR",
            "ONE_MINUS_SRC_COLOR",
            "DST_COLOR",
            "ONE_MINUS_DST_COLOR",
            "SRC_ALPHA",
            "ONE_MINUS_SRC_ALPHA",
            "DST_ALPHA",
            "ONE_MINUS_DST_ALPHA",
            "CONSTANT_COLOR",
            "ONE_MINUS_CONSTANT_COLOR",
            "CONSTANT_ALPHA",
            "ONE_MINUS_CONSTANT_ALPHA",
            "SRC_ALPHA_SATURATE",
        ]:
            raise AttributeError("invalid dst_alpha")
        self._commands.append(
            {
                "cmd": "blendFuncSeparate",
                "src_rgb": src_rgb,
                "dst_rgb": dst_rgb,
                "src_alpha": src_alpha,
                "dst_alpha": dst_alpha,
            }
        )

    def create_texture(self) -> GLResourceWidget:
        """
        append a create texture command to the command buffers

        returns:
        - GLResourceWidget: the resource that will hold the texture
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append({"cmd": "createTexture", "resource": uid})
        return resource

    def bind_texture(self, target: str, texture: GLResourceWidget = None):
        """
        append a bind texture command to the command buffers

        args:
        - target (str): the binding point ["TEXTURE_2D", "TEXTURE_CUBE_MAP", "TEXTURE_3D", "TEXTURE_2D_ARRAY"]
        - texture (GLResourceWidget): the texture resource
        """
        if target not in [
            "TEXTURE_2D",
            "TEXTURE_CUBE_MAP",
            "TEXTURE_3D",
            "TEXTURE_2D_ARRAY",
        ]:
            raise AttributeError("invalid target")
        uid = -1
        if texture is not None:
            uid = texture.uid
        self._commands.append({"cmd": "bindTexture", "texture": uid, "target": target})

    def active_texture(self, texture: int):
        """
        append an active texture command to the command buffers

        args:
        - texture (int): the texture unit to make active
          - the value is a 'gl.TEXTURE0 + texture'
        """
        self._commands.append({"cmd": "activeTexture", "texture": texture})

    def generate_mipmap(self, target: str):
        """
        append a generate mipmap command to the command buffers

        args:
        - target (str): the binding point ["TEXTURE_2D", "TEXTURE_CUBE_MAP", "TEXTURE_3D", "TEXTURE_2D_ARRAY"]
        """
        if target not in [
            "TEXTURE_2D",
            "TEXTURE_CUBE_MAP",
            "TEXTURE_3D",
            "TEXTURE_2D_ARRAY",
        ]:
            raise AttributeError("invalid target")
        self._commands.append({"cmd": "generateMipmap", "target": target})

    def tex_image_2d(
        self,
        target: str,
        level: int,
        internal_format: str,
        width: int,
        height: int,
        border: int,
        format: str,
        data_type: str,
        pixel: np.array,
    ):
        """
        append a tex image 2d command to the command buffers

        target: ['TEXTURE_2D', 'TEXTURE_CUBE_MAP_POSITIVE_X', 'TEXTURE_CUBE_MAP_NEGATIVE_X', 'TEXTURE_CUBE_MAP_POSITIVE_Y', 'TEXTURE_CUBE_MAP_NEGATIVE_Y', 'TEXTURE_CUBE_MAP_POSITIVE_Z', 'TEXTURE_CUBE_MAP_NEGATIVE_Z']

        internal_format: ['RGBA', 'RGB', 'LUMINANCE_ALPHA', 'LUMINANCE', 'ALPHA',
        'R8', 'R8_SNORM', 'RG8', 'RG8_SNORM', 'RGB8', 'RGB8_SNORM', 'RGB565', 'RGBA4', 'RGB5_A1', 'RGBA8', 'RGBA8_SNORM', 'RGB10_A2', 'RGB10_A2UI', 'SRGB8', 'SRGB8_ALPHA8',
        'R16F', 'RG16F', 'RGB16F', 'RGBA16F', 'R32F', 'RG32F', 'RGB32F', 'RGBA32F', 'R11F_G11F_B10F', 'RGB9_E5',
        'R8I', 'R8UI', 'R16I', 'R16UI', 'R32I', 'R32UI', 'RG8I', 'RG8UI', 'RG16I', 'RG16UI', 'RG32I', 'RG32UI',
        'RGB8I', 'RGB8UI', 'RGB16I', 'RGB16UI', 'RGB32I', 'RGB32UI', 'RGBA8I', 'RGBA8UI', 'RGBA16I', 'RGBA16UI', 'RGBA32I', 'RGBA32UI',
        'DEPTH_COMPONENT24', 'DEPTH_COMPONENT32F', 'DEPTH32F_STENCIL8', 'DEPTH24_STENCIL8']

        format = ['RGB', 'RGBA', 'LUMINANCE_ALPHA', 'LUMINANCE', 'ALPHA', 'RED', 'RED_INTEGER', 'RG', 'RG_INTEGER', 'RGB', 'RGB_INTEGER', 'RGBA_INTEGER', 'DEPTH_COMPONENT']

        data_type = ['UNSIGNED_BYTE', 'UNSIGNED_SHORT_5_6_5', 'UNSIGNED_SHORT_4_4_4_4', 'UNSIGNED_SHORT_5_5_5_1', 'BYTE', 'UNSIGNED_SHORT', 'SHORT', 'UNSIGNED_INT', 'INT', 'HALF_FLOAT', 'FLOAT', 'UNSIGNED_INT_2_10_10_10_REV', 'UNSIGNED_INT_10F_11F_11F_REV', 'UNSIGNED_INT_5_9_9_9_REV', 'UNSIGNED_INT_24_8', 'FLOAT_32_UNSIGNED_INT_24_8_REV']

        args:
        - target (str): the binding point (target) of the active texture
        - level (int): the level of detail: level0 is the base image level and level n is the n-th mipmap reduction level
        - internal_format (str): the color components in texture
        - width (int): the width of the texture
        - height (int): the height of the texture
        - border (int): specify the width of the border, must be 0
        - format (str): the format of the pixel data
        - data_type (str): the data type of the texel data
        - pixel (np.array): the buffer
        """
        if target not in [
            "TEXTURE_2D",
            "TEXTURE_CUBE_MAP_POSITIVE_X",
            "TEXTURE_CUBE_MAP_NEGATIVE_X",
            "TEXTURE_CUBE_MAP_POSITIVE_Y",
            "TEXTURE_CUBE_MAP_NEGATIVE_Y",
            "TEXTURE_CUBE_MAP_POSITIVE_Z",
            "TEXTURE_CUBE_MAP_NEGATIVE_Z",
        ]:
            raise AttributeError("invalid target")

        if internal_format not in [
            "RGBA",
            "RGB",
            "LUMINANCE_ALPHA",
            "LUMINANCE",
            "ALPHA",
            "R8",
            "R8_SNORM",
            "RG8",
            "RG8_SNORM",
            "RGB8",
            "RGB8_SNORM",
            "RGB565",
            "RGBA4",
            "RGB5_A1",
            "RGBA8",
            "RGBA8_SNORM",
            "RGB10_A2",
            "RGB10_A2UI",
            "SRGB8",
            "SRGB8_ALPHA8",
            "R16F",
            "RG16F",
            "RGB16F",
            "RGBA16F",
            "R32F",
            "RG32F",
            "RGB32F",
            "RGBA32F",
            "R11F_G11F_B10F",
            "RGB9_E5",
            "R8I",
            "R8UI",
            "R16I",
            "R16UI",
            "R32I",
            "R32UI",
            "RG8I",
            "RG8UI",
            "RG16I",
            "RG16UI",
            "RG32I",
            "RG32UI",
            "RGB8I",
            "RGB8UI",
            "RGB16I",
            "RGB16UI",
            "RGB32I",
            "RGB32UI",
            "RGBA8I",
            "RGBA8UI",
            "RGBA16I",
            "RGBA16UI",
            "RGBA32I",
            "RGBA32UI",
            "DEPTH_COMPONENT24",
            "DEPTH_COMPONENT32F",
            "DEPTH32F_STENCIL8",
            "DEPTH24_STENCIL8",
        ]:
            raise AttributeError("invalid internal_format")

        if format not in [
            "RGB",
            "RGBA",
            "LUMINANCE_ALPHA",
            "LUMINANCE",
            "ALPHA",
            "RED",
            "RED_INTEGER",
            "RG",
            "RG_INTEGER",
            "RGB",
            "RGB_INTEGER",
            "RGBA_INTEGER",
            "DEPTH_COMPONENT",
        ]:
            raise AttributeError("invalid format")

        if data_type not in [
            "UNSIGNED_BYTE",
            "UNSIGNED_SHORT_5_6_5",
            "UNSIGNED_SHORT_4_4_4_4",
            "UNSIGNED_SHORT_5_5_5_1",
            "BYTE",
            "UNSIGNED_SHORT",
            "SHORT",
            "UNSIGNED_INT",
            "INT",
            "HALF_FLOAT",
            "FLOAT",
            "UNSIGNED_INT_2_10_10_10_REV",
            "UNSIGNED_INT_10F_11F_11F_REV",
            "UNSIGNED_INT_5_9_9_9_REV",
            "UNSIGNED_INT_24_8",
            "FLOAT_32_UNSIGNED_INT_24_8_REV",
        ]:
            raise AttributeError("invalid data_type")

        if pixel is not None:
            meta_data = {}
            buffer = []
            meta_data, buffer = array_to_buffer(pixel)
            meta_data["index"] = len(self._buffers)
            self._buffers.append(buffer)
            self._commands.append(
                {
                    "cmd": "texImage2D",
                    "target": target,
                    "level": level,
                    "internal_format": internal_format,
                    "width": width,
                    "height": height,
                    "border": border,
                    "format": format,
                    "data_type": data_type,
                    "buffer_metadata": meta_data,
                }
            )
        else:
            self._commands.append(
                {
                    "cmd": "texImage2D",
                    "target": target,
                    "level": level,
                    "internal_format": internal_format,
                    "width": width,
                    "height": height,
                    "border": border,
                    "format": format,
                    "data_type": data_type,
                }
            )

    def tex_storage_2d(
        self, target: str, levels: int, internal_format: str, width: int, height: int
    ):
        """
        append a tex storage 2d command to the command buffers

        internal_format: ["R8", "R16F", "R32F", "R8UI", "RG8", "RG16F", "RG32F", "RG8UI", "RGB8", "SRGB8", "RGB565", "R11F_G11F_B10F", "RGB9_E5", "RGB16F", "RGB32F", "RGB8UI", "RGBA8", "SRGB8_ALPHA8", "RGB5_A1", "RGBA4", "RGBA16F", "RGBA32F", "RGBA8UI",'DEPTH_COMPONENT16', 'DEPTH_COMPONENT24', 'DEPTH_COMPONENT32F', 'DEPTH32F_STENCIL8', 'DEPTH24_STENCIL8']

        args:
        - target (str): 'TEXTURE_2D', 'TEXTURE_CUBE_MAP'
        - levels (int): the number of mipmap
        - internal_format (str): the internal format
        - width (int): the width of the texture
        - height (int): the height of the texture
        """
        if target not in ["TEXTURE_2D", "TEXTURE_CUBE_MAP"]:
            raise AttributeError("invalid target")
        if internal_format not in [
            "R8",
            "R16F",
            "R32F",
            "R8UI",
            "RG8",
            "RG16F",
            "RG32F",
            "RG8UI",
            "RGB8",
            "SRGB8",
            "RGB565",
            "R11F_G11F_B10F",
            "RGB9_E5",
            "RGB16F",
            "RGB32F",
            "RGB8UI",
            "RGBA8",
            "SRGB8_ALPHA8",
            "RGB5_A1",
            "RGBA4",
            "RGBA16F",
            "RGBA32F",
            "RGBA8UI",
            "DEPTH_COMPONENT16",
            "DEPTH_COMPONENT24",
            "DEPTH_COMPONENT32F",
            "DEPTH32F_STENCIL8",
            "DEPTH24_STENCIL8",
        ]:
            raise AttributeError("invalid internal_format")

        self._commands.append(
            {
                "cmd": "texStorage2D",
                "target": target,
                "levels": levels,
                "internal_format": internal_format,
                "width": width,
                "height": height,
            }
        )

    def tex_image_3d(
        self,
        target: str,
        level: int,
        internal_format: str,
        width: int,
        height: int,
        depth: int,
        border: int,
        format: str,
        data_type: str,
        pixel: np.array,
    ):
        """
        append a tex image 3d command to the command buffers

        internal_format = ['RGBA', 'RGB', 'LUMINANCE_ALPHA', 'LUMINANCE', 'ALPHA', 'R8', 'R16F', 'R32F', 'R8UI', 'RG8', 'RG16F', 'RG32F', 'RGUI', 'RGB8', 'SRGB8', 'RGB565', 'R11F_G11F_B10F', 'RGB9_E5', 'RGB16F', 'RGB32F', 'RGB8UI', 'RGBA8', 'SRGB8_ALPHA8', 'RGB5_A1', 'RGBA4444', 'RGBA16F', 'RGBA32F', 'RGBA8UI']

        format = ['RGB', 'RGBA', 'LUMINANCE_ALPHA', 'LUMINANCE', 'ALPHA', 'RED', 'RED_INTEGER', 'RG', 'RG_INTEGER', 'RGB', 'RGB_INTEGER', 'RGBA_INTEGER']

        data_type = ['UNSIGNED_BYTE', 'UNSIGNED_SHORT_5_6_5', 'UNSIGNED_SHORT_4_4_4_4', 'UNSIGNED_SHORT_5_5_5_1', 'BYTE', 'UNSIGNED_SHORT', 'SHORT', 'UNSIGNED_INT', 'INT', 'HALF_FLOAT', 'FLOAT', 'UNSIGNED_INT_2_10_10_10_REV', 'UNSIGNED_INT_10F_11F_11F_REV', 'UNSIGNED_INT_5_9_9_9_REV', 'UNSIGNED_INT_24_8', 'FLOAT_32_UNSIGNED_INT_24_8_REV']

        args:
        - target (str): the binding point (target) of the active texture
        - level (int): the level of detail. level0 is the base image level and level n is the n-th mipmap reduction level
        - internal_format (str): the color components in the texture
        - width (int): the width of the texture
        - height (int): the height of the texture
        - depth (int): the depth of the texture
        - border (int): specifying the width of the border: must be 0
        - format (str): the format of the texel data
        - data_type (str): the data type of the texel data
        - pixel (np.array): the buffer
        """
        if target not in ["TEXTURE_3D", "TEXTURE_2D_ARRAY"]:
            raise AttributeError("invalid target")

        if internal_format not in [
            "RGBA",
            "RGB",
            "LUMINANCE_ALPHA",
            "LUMINANCE",
            "ALPHA",
            "R8",
            "R16F",
            "R32F",
            "R8UI",
            "RG8",
            "RG16F",
            "RG32F",
            "RGUI",
            "RGB8",
            "SRGB8",
            "RGB565",
            "R11F_G11F_B10F",
            "RGB9_E5",
            "RGB16F",
            "RGB32F",
            "RGB8UI",
            "RGBA8",
            "SRGB8_ALPHA8",
            "RGB5_A1",
            "RGBA4444",
            "RGBA16F",
            "RGBA32F",
            "RGBA8UI",
        ]:
            raise AttributeError("invalid internal_format")

        if format not in [
            "RGB",
            "RGBA",
            "LUMINANCE_ALPHA",
            "LUMINANCE",
            "ALPHA",
            "RED",
            "RED_INTEGER",
            "RG",
            "RG_INTEGER",
            "RGB",
            "RGB_INTEGER",
            "RGBA_INTEGER",
        ]:
            raise AttributeError("invalid format")

        if data_type not in [
            "UNSIGNED_BYTE",
            "UNSIGNED_SHORT_5_6_5",
            "UNSIGNED_SHORT_4_4_4_4",
            "UNSIGNED_SHORT_5_5_5_1",
            "BYTE",
            "UNSIGNED_SHORT",
            "SHORT",
            "UNSIGNED_INT",
            "INT",
            "HALF_FLOAT",
            "FLOAT",
            "UNSIGNED_INT_2_10_10_10_REV",
            "UNSIGNED_INT_10F_11F_11F_REV",
            "UNSIGNED_INT_5_9_9_9_REV",
            "UNSIGNED_INT_24_8",
            "FLOAT_32_UNSIGNED_INT_24_8_REV",
        ]:
            raise AttributeError("invalid data_type")

        if pixel is not None:
            meta_data = {}
            buffer = []
            meta_data, buffer = array_to_buffer(pixel)
            meta_data["index"] = len(self._buffers)
            self._buffers.append(buffer)
            self._commands.append(
                {
                    "cmd": "texImage3D",
                    "target": target,
                    "level": level,
                    "internal_format": internal_format,
                    "width": width,
                    "height": height,
                    "border": border,
                    "depth": depth,
                    "format": format,
                    "data_type": data_type,
                    "buffer_metadata": meta_data,
                }
            )
        else:
            self._commands.append(
                {
                    "cmd": "texImage3D",
                    "target": target,
                    "level": level,
                    "internal_format": internal_format,
                    "width": width,
                    "height": height,
                    "border": border,
                    "depth": depth,
                    "format": format,
                    "data_type": data_type,
                }
            )

    def tex_storage_3d(
        self,
        target: str,
        levels: int,
        internal_format: str,
        width: int,
        height: int,
        depth: int,
    ):
        """
        append a texStorage3D command to the command buffers

        internal_format = ["R8", "R16F", "R32F", "R8UI", "RG8", "RG16F", "RG32F", "RG8UI", "RGB8", "SRGB8", "RGB565", "R11F_G11F_B10F", "RGB9_E5", "RGB16F", "RGB32F", "RGB8UI", "RGBA8", "SRGB8_ALPHA8", "RGB5_A1", "RGBA4", "RGBA16F", "RGBA32F", "RGBA8UI"]

        args:
        - target (str): 'TEXTURE_3D', 'TEXTURE_2D_ARRAY'
        - levels (int): the number of mipmap
        - internal_format (str): the internal format
        - width (int): the width of the texture
        - height (int): the height of the texture
        - depth (int): the depth of the texture
        """
        if target not in ["TEXTURE_3D", "TEXTURE_2D_ARRAY"]:
            raise AttributeError("invalid target")

        if internal_format not in [
            "R8",
            "R16F",
            "R32F",
            "R8UI",
            "RG8",
            "RG16F",
            "RG32F",
            "RG8UI",
            "RGB8",
            "SRGB8",
            "RGB565",
            "R11F_G11F_B10F",
            "RGB9_E5",
            "RGB16F",
            "RGB32F",
            "RGB8UI",
            "RGBA8",
            "SRGB8_ALPHA8",
            "RGB5_A1",
            "RGBA4",
            "RGBA16F",
            "RGBA32F",
            "RGBA8UI",
        ]:
            raise AttributeError("Invalid internal_format")

        self._commands.append(
            {
                "cmd": "texStorage3D",
                "target": target,
                "levels": levels,
                "internal_format": internal_format,
                "width": width,
                "height": height,
                "depth": depth,
            }
        )

    def tex_parameter(self, target: str, pname: str, param):
        """
        append a texParameteri or texParameterf to the command buffers

        pname = ["TEXTURE_MAG_FILTER", "TEXTURE_MIN_FILTER", "TEXTURE_WRAP_S", "TEXTURE_WRAP_T", 'TEXTURE_BASE_LEVEL', 'TEXTURE_COMPARE_FUNC', 'TEXTURE_COMPARE_MODE', 'TEXTURE_MAX_LEVEL', 'TEXTURE_MAX_LOD', 'TEXTURE_MIN_LOD', 'TEXTURE_WRAP_R']

        param = int or float or ['LINEAR', 'NEAREST', 'NEAREST_MIPMAP_NEAREST', 'LINEAR_MIPMAP_NEAREST', 'NEAREST_MIPMAP_LINEAR', 'LINEAR_MIPMAP_LINEAR','REPEAT', 'CLAMP_TO_EDGE', 'MIRRORED_REPEAT', 'LEQUAL', 'GEQUAL', 'LESS', 'GREATER', 'EQUAL', 'NOTEQUAL', 'ALWAYS', 'NEVER','NONE', 'COMPARE_REF_TO_TEXTURE']

        args:
        - target (str): the binding point [TEXTURE_2D, TEXTURE_3D, TEXTURE_2D_ARRAY, TEXTURE_CUBE_MAP]
        - pname (str): the texture parameter name
        - param (int or float or str): the value for the specified parameter
        """
        if target not in [
            "TEXTURE_2D",
            "TEXTURE_3D",
            "TEXTURE_2D_ARRAY",
            "TEXTURE_CUBE_MAP",
        ]:
            raise AttributeError("invalid target")

        if pname not in [
            "TEXTURE_MAG_FILTER",
            "TEXTURE_MIN_FILTER",
            "TEXTURE_WRAP_S",
            "TEXTURE_WRAP_T",
            "TEXTURE_BASE_LEVEL",
            "TEXTURE_COMPARE_FUNC",
            "TEXTURE_COMPARE_MODE",
            "TEXTURE_MAX_LEVEL",
            "TEXTURE_MAX_LOD",
            "TEXTURE_MIN_LOD",
            "TEXTURE_WRAP_R",
        ]:
            raise AttributeError("invalid pname")

        if isinstance(param, int):
            self._commands.append(
                {
                    "cmd": "texParameteri",
                    "target": target,
                    "pname": pname,
                    "param": param,
                }
            )
        elif isinstance(param, float):
            self._commands.append(
                {
                    "cmd": "texParameterf",
                    "target": target,
                    "pname": pname,
                    "param": param,
                }
            )
        else:
            if param not in [
                "LINEAR",
                "NEAREST",
                "NEAREST_MIPMAP_NEAREST",
                "LINEAR_MIPMAP_NEAREST",
                "NEAREST_MIPMAP_LINEAR",
                "LINEAR_MIPMAP_LINEAR",
                "REPEAT",
                "CLAMP_TO_EDGE",
                "MIRRORED_REPEAT",
                "LEQUAL",
                "GEQUAL",
                "LESS",
                "GREATER",
                "EQUAL",
                "NOTEQUAL",
                "ALWAYS",
                "NEVER",
                "NONE",
                "COMPARE_REF_TO_TEXTURE",
            ]:
                raise AttributeError("invalid param")

            self._commands.append(
                {
                    "cmd": "texParameter_str",
                    "target": target,
                    "pname": pname,
                    "param": param,
                }
            )

    def pixel_store_i(self, pname: str, param):
        """
        append a pixelStorei to the command buffers
        """
        if pname not in [
            "PACK_ALIGNMENT",
            "UNPACK_ALIGNMENT",
            "UNPACK_FLIP_Y_WEBGL",
            "UNPACK_PREMULTIPLY_ALPHA_WEBGL",
            "UNPACK_COLORSPACE_CONVERSION_WEBGL",
            "PACK_ROW_LENGTH",
            "PACK_SKIP_PIXELS",
            "PACK_SKIP_ROWS",
            "UNPACK_ROW_LENGTH",
            "UNPACK_IMAGE_HEIGHT",
            "UNPACK_SKIP_PIXELS",
            "UNPACK_SKIP_ROWS",
            "UNPACK_SKIP_IMAGES",
        ]:
            raise AttributeError("Invalid pname")

        if pname == "UNPACK_COLORSPACE_CONVERSION_WEBGL" and param not in [
            "BROWSER_DEFAULT_WEBGL",
            "NONE",
        ]:
            raise AttributeError("Invalid param")

        self._commands.append(
            {
                "cmd": "pixelStorei",
                "pname": pname,
                "param": param,
            }
        )

    def create_shader(self, shader_type: str) -> GLResourceWidget:
        """
        append a createShader command to the command buffers

        args:
        - shader_type(str): type of shader ["VERTEX_SHADER" or "FRAGMENT_SHADER"]

        returns:
        - GLResourceWidget: the resource that will hold the shader
        """
        if shader_type not in ["VERTEX_SHADER", "FRAGMENT_SHADER"]:
            raise AttributeError("Invalid shader_type")

        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append(
            {
                "cmd": "createShader",
                "type": shader_type,
                "resource": uid,
            }
        )
        return resource

    def shader_source(self, shader: GLResourceWidget, source: str):
        """
        append a shaderSource command to the command buffers
        - sets the source code for a shader object

        args:
        - shader(GLResourceWidget): a resource with a shader
        - source(str): a string of GLSL code that defines the shader
        """
        self._commands.append(
            {
                "cmd": "shaderSource",
                "shader": shader.uid,
                "source": source,
            }
        )

    def compile_shader(self, shader: GLResourceWidget):
        """
        append a compileShader command to the command buffers

        args:
        - shader(GLResourceWidget): a resource with a shader
        """
        self._commands.append(
            {
                "cmd": "compileShader",
                "shader": shader.uid,
            }
        )

    def create_program(self) -> GLResourceWidget:
        """
        append a createProgram command to the command buffers

        returns:
        - GLResourceWidget: the resource that will hold the program
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append(
            {
                "cmd": "createProgram",
                "resource": uid,
            }
        )
        return resource

    def link_program(self, program: GLResourceWidget):
        """
        append a linkProgram command to the command buffers

        args:
        - program(GLResourceWidget): a resource with a program
        """
        self._commands.append(
            {
                "cmd": "linkProgram",
                "program": program.uid,
            }
        )

    def use_program(self, program: GLResourceWidget = None):
        """
        append a useProgram command to the command buffers

        args:
        - program(GLResourceWidget): the program to use
        """
        uid = -1
        if program is not None:
            uid = program.uid
        self._commands.append(
            {
                "cmd": "useProgram",
                "program": uid,
            }
        )

    def create_program_ext(
        self,
        vertex_source: str,
        fragment_source: str,
        attribute_location: {} = None,
        auto_execute=True,
    ) -> GLResourceWidget:
        """
        extended function to quickly create a program:
        - this will build the command buffer with all the needed commands for you
        - it creates the shaders, compiles them, creates the program and links it
          and if the auto_execute is on, it will send the command-buffer to the frontend

        args:
        - vertex_source(str): the vertex source code
        - fragment_source(str): the shader source code
        - attribute_location({str: int, ..}): the force attributelocation if we don't want to use the default location
        - auto_execute(bool): do we execute all the commands automatically?

        returns:
        - GLResourceWidget: the resource that will hold the program
        """
        vertex_shader = self.create_shader("VERTEX_SHADER")
        self.shader_source(vertex_shader, vertex_source)
        self.compile_shader(vertex_shader)

        fragment_shader = self.create_shader("FRAGMENT_SHADER")
        self.shader_source(fragment_shader, fragment_source)
        self.compile_shader(fragment_shader)

        program = self.create_program()
        self.attach_shader(program, vertex_shader)
        self.attach_shader(program, fragment_shader)
        if attribute_location is not None:
            for key, value in attribute_location.items():
                self.bind_attrib_location(program, value, key)

        self.link_program(program)
        self.use_program(None)

        if auto_execute:
            self.execute_commands(execute_once=True)

        return program

    def attach_shader(self, program: GLResourceWidget, shader: GLResourceWidget):
        """
        append a attachShader command to the command buffers

        args:
        - program(GLResourceWidget): the program
        - shader(GLResourceWidget): the shader
        """
        self._commands.append(
            {
                "cmd": "attachShader",
                "program": program.uid,
                "shader": shader.uid,
            }
        )

    def bind_attrib_location(self, program: GLResourceWidget, index, name):
        """
        append a bindAttribLocation command to the command buffers

        args:
        - program(int): the WebGL program object
        - index(int): the index of the attribute variable to assign to the bound location
        - name(str): the name of the attribute variable
        """
        self._commands.append(
            {
                "cmd": "bindAttribLocation",
                "program": program.uid,
                "index": index,
                "name": name,
            }
        )

    def uniform(self, name: str, array: np.array):
        """
        append a uniform command to the command buffers

        args:
        - name(str): the name of the uniform
        - array(np.array): the numpy array with the data; even if you send one value, it must be an array
        """
        meta_data, buffer = array_to_buffer(array)
        meta_data["index"] = len(self._buffers)
        self._buffers.append(buffer)
        self._commands.append(
            {
                "cmd": "uniform",
                "name": name,
                "buffer_metadata": meta_data,
            }
        )

    def uniform_matrix(self, name: str, array: np.array):
        """
        append a uniformMatrix command to the command buffers

        args:
        - name(str): the name of the uniform
        - array(np.array): the matrix(matrices) to send: it must be a np.array(dtype=np.float32)
        """
        meta_data, buffer = array_to_buffer(array)
        meta_data["index"] = len(self._buffers)
        self._buffers.append(buffer)
        self._commands.append(
            {
                "cmd": "uniformMatrix",
                "name": name,
                "buffer_metadata": meta_data,
            }
        )

    def uniform_block_binding(
        self,
        program: GLResourceWidget,
        uniform_block_name: str,
        uniform_block_binding: int,
    ):
        """append a uniformBlockBinding command"""
        self._commands.append(
            {
                "cmd": "uniformBlockBinding",
                "program": program.uid,
                "uniform_block_name": uniform_block_name,
                "uniform_block_binding": uniform_block_binding,
            }
        )

    def create_buffer(self) -> GLResourceWidget:
        """
        append a createBuffer command to the command buffers

        returns:
        - GLResourceWidget: a resource that (will) hold the buffer after you call 'execute'
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append(
            {
                "cmd": "createBuffer",
                "resource": uid,
            }
        )
        return resource

    def bind_buffer(
        self, target: str = "ARRAY_BUFFER", buffer: GLResourceWidget = None
    ):
        """
        append a bindBuffer command to the command buffers
        - this function binds a given WebGL buffer to a target: the target must be one of the following strings:
          "ARRAY_BUFFER"
          "ELEMENT_ARRAY_BUFFER"
          "COPY_READ_BUFFER"
          "COPY_WRITE_BUFFER"
          "PIXEL_PACK_BUFFER"
          "PIXEL_UNPACK_BUFFER"
          "TRANSFORM_FEEDBACK_BUFFER"
          "UNIFORM_BUFFER"

        args:
        - target(str): the target string
        - buffer(GLResourceWidget): resource that holds the buffer
        """
        if target not in [
            "ARRAY_BUFFER",
            "ELEMENT_ARRAY_BUFFER",
            "COPY_READ_BUFFER",
            "COPY_WRITE_BUFFER",
            "PIXEL_PACK_BUFFER",
            "PIXEL_UNPACK_BUFFER",
            "TRANSFORM_FEEDBACK_BUFFER",
            "UNIFORM_BUFFER",
        ]:
            raise AttributeError("Invalid target")

        uid = -1
        if buffer is not None:
            uid = buffer.uid

        self._commands.append(
            {
                "cmd": "bindBuffer",
                "target": target,
                "buffer": uid,
            }
        )

    def buffer_data(
        self,
        target="ARRAY_BUFFER",
        src_data=None,
        usage="STATIC_DRAW",
        update_info=False,
    ):
        """
        append a bufferData command to the command buffers

        args:
        - target(str, optional): _description
        - src_data(np.array, optional): the data to send
        - usage(str, optional): _description
        - update_info(bool, optional): do we update the buffer info that are displayed in the widget
        """
        if target not in [
            "ARRAY_BUFFER",
            "ELEMENT_ARRAY_BUFFER",
            "COPY_READ_BUFFER",
            "COPY_WRITE_BUFFER",
            "TRANSFORM_FEEDBACK_BUFFER",
            "UNIFORM_BUFFER",
        ]:
            raise AttributeError("Invalid target")

        if usage not in [
            "STATIC_DRAW",
            "DYNAMIC_DRAW",
            "STREAM_DRAW",
            "STATIC_READ",
            "DYNAMIC_READ",
            "STREAM_READ",
            "STATIC_COPY",
            "DYNAMIC_COPY",
            "STREAM_COPY",
        ]:
            raise AttributeError("Invalid usage")

        if isinstance(src_data, str) and target != "UNIFORM_BUFFER":
            raise AttributeError(
                "src_data can be a tring only if we are passing a uniform buffer"
            )

        meta_data = {}
        buffer = []
        if src_data is not None:
            meta_data, buffer = array_to_buffer(src_data)
            meta_data["index"] = len(self._buffers)
            self._buffers.append(buffer)
            self._commands.append(
                {
                    "cmd": "bufferData",
                    "target": target,
                    "usage": usage,
                    "update_info": update_info,
                    "buffer_metadata": meta_data,
                }
            )
        else:
            self._commands.append(
                {
                    "cmd": "bufferData",
                    "target": target,
                    "usage": usage,
                    "update_info": update_info,
                }
            )

    def create_buffer_ext(
        self,
        target="ARRAY_BUFFER",
        src_data=None,
        usage="STATIC_DRAW",
        auto_execute=True,
    ) -> GLResourceWidget:
        """
        extended create buffer command:

        this builds the command list with the create, bind and buffer_data at the end it unbind the buffer
        - it autoExecute is set, it will send the command buffer to the frontend

        args:
        - target(str, optional): _description (default to "ARRAY_BUFFER")
        - src_data(np.array, optional): the data to send (default to None)
        - usage(str, optional): _description (default to "STATIC_DRAW")
        - auto_execute(bool, optional): do we execute the commands (default to True)
        """
        buffer = self.create_buffer()
        self.bind_buffer(target, buffer)
        self.buffer_data(target, src_data, usage, update_info=True)
        self.bind_buffer(target, None)

        if auto_execute:
            self.execute_commands(execute_once=True)

        return buffer

    def create_uniform_buffer_ext(
        self,
        program: GLResourceWidget,
        block_name: str,
        usage="STATIC_DRAW",
        auto_execute=True,
    ) -> GLResourceWidget:
        """
        create a uniform buffer
        - we have to use this function to create a uniform buffer because the type of data passed tot he buffer is out of sync with the frontend

        args:
        - program(GLResourceWidget): the program where the block is found
        - block_name(str): the name of the block
        - usage(str, optional): _description
        - auto_execute(bool, optional): do we execute the commands

        returns:
        - GLResourceWidget: the resource for the buffer
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append(
            {
                "cmd": "createUniformBuffer",
                "program": program.uid,
                "block_name": block_name,
                "usage": usage,
                "buffer": uid,
            }
        )

        if auto_execute:
            self.execute_commands(execute_once=True)

        return resource

    def bind_buffer_base(
        self, target: str, index: int, buffer: GLResourceWidget = None
    ):
        """
        append a bindBufferBase command to the command buffers
        """
        if target not in ["TRANFORM_FEEDBACK_BUFFER", "UNIFORM_BUFFER"]:
            raise AttributeError("Invalid target")

        uid = -1
        if buffer is not None:
            uid = buffer.uid

        self._commands.append(
            {
                "cmd": "bindBufferBase",
                "target": target,
                "index": index,
                "buffer": uid,
            }
        )

    def buffer_sub_data(
        self, target="ARRAY_BUFFER", dst_byte_offset=0, src_data=None, src_offset=0
    ):
        f"""
        append a bufferSubData command to the command buffers

        target values: ["ARRAY_BUFFER", "ELEMENT_ARRAY_BUFFER", "COPY_READ_BUFFER", "COPY_WRITE_BUFFER", "TRANSFORM_FEEDBACK_BUFFER", "UNIFORM_BUFFER"]

        args:
        - target(str, optional): specifying the binding point (target)
        - dst_byte_offset(int|str, optional): specifying an offset in bytes where the data replacement will start:
          - in the case of UNIFORM_BUFFER, it can be a string with name of the uniform
        - src_data(np.array, optional): the array that will be copied into the data store
        - src_offset(int, optional): specifying the element index offset where to start reading the buffer
        """
        if target not in [
            "ARRAY_BUFFER",
            "ELEMENT_ARRAY_BUFFER",
            "COPY_READ_BUFFER",
            "COPY_WRITE_BUFFER",
            "TRANSFORM_FEEDBACK_BUFFER",
            "UNIFORM_BUFFER",
        ]:
            raise AttributeError("Invalid target")

        meta_data = {}
        buffer = []

        command = "bufferSubData"
        if isinstance(dst_byte_offset, str):
            command = "bufferSubDataStr"

        if src_data is not None:
            meta_data, buffer = array_to_buffer(src_data)
            meta_data["index"] = len(self._buffers)
            self._buffers.append(buffer)
            self._commands.append(
                {
                    "cmd": command,
                    "target": target,
                    "dst_byte_offset": dst_byte_offset,
                    "src_offset": src_offset,
                    "buffer_metadata": meta_data,
                }
            )
        else:
            self._commands.append(
                {
                    "cmd": command,
                    "target": target,
                    "dst_byte_offset": dst_byte_offset,
                    "src_offset": src_offset,
                }
            )

    def create_vertex_array(self) -> GLResourceWidget:
        """
        append a createVertexArray command to the command buffers

        returns:
        - GLResourceWidget: a resource that (will) hold the vao after you call 'execute'
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append(
            {
                "cmd": "createVertexArray",
                "resource": uid,
            }
        )
        return resource

    def bind_vertex_array(self, vertex_array: GLResourceWidget):
        """
        append a bindVertexArray command to the command buffers

        args:
        - vertex_array(GLResourceWidget): the vertex array to bind
        """
        uid = -1
        if vertex_array:
            uid = vertex_array.uid
        self._commands.append(
            {
                "cmd": "bindVertexArray",
                "vertex_array": uid,
            }
        )

    def enable_vertex_attrib_array(self, index, index_offset: int = 0):
        """
        append an enableVertexAttribArray command to the command buffers

        args:
        - index(int or str): specifies the index of the generic vertex attribute to be enabled or the name of the attribute to find in the shader
        - index_offset(int): add an offset to the index(location) found
        """
        self._commands.append(
            {
                "cmd": "enableVertexAttribArray",
                "index": index,
                "index_offset": index_offset,
            }
        )

    def disable_vertex_attrib_array(self, index, index_offset: int = 0):
        """
        append a disableVertexAttribArray command to the command buffers

        args:
        - index(int or str): specifies the index of the generic vertex attribute to be disabled or the name of the attribute to find in the shader
        - index_offset(int): add an offset to the index(location) found
        """
        self._commands.append(
            {
                "cmd": "disableVertexAttribArray",
                "index": index,
                "index_offset": index_offset,
            }
        )

    def vertex_attrib_pointer(
        self,
        index,
        size: int,
        attrib_type: str,
        normalized: bool,
        stride: int,
        offset: int = 0,
        index_offset: int = 0,
    ):
        """
        append a vertexAttribPointer command to the command buffers

        args:
        - index(int or str): the index of the generic vertex attribute to be modified or the name of the attribute to find in the shader
        - size(int): specify the number of components per generic vertex attribute: must be 1,2,3,4
        - attrib_type(str): specify the data type of each component in the array
        - normalized(bool): specify whether integer data values should be nomralized when being casted to a float
        - stride(int): specify the byte offset between consecutive generic vertex attributes
        - offset(int): specify the offset, in bytes, of the first component in the vertex attribute array
        - index_offset(int): add an offset to the index(location) found
        """
        if size < 1 or size > 4:
            raise AttributeError("invalid size")

        if attrib_type not in [
            "BYTE",
            "UNSIGNED_BYTE",
            "SHORT",
            "UNSIGNED_SHORT",
            "FLOAT",
            "HALF_FLOAT",
            "INT",
            "UNSIGNED_INT",
        ]:
            raise AttributeError("Invalid attribtype")

        self._commands.append(
            {
                "cmd": "vertexAttribPointer",
                "index": index,
                "size": size,
                "type": attrib_type,
                "normalized": normalized,
                "stride": stride,
                "offset": offset,
                "index_offset": index_offset,
            }
        )

    def vertex_attrib_i_pointer(
        self,
        index,
        size: int,
        attrib_type: str,
        stride: int,
        offset: int,
        index_offset: int = 0,
    ):
        """
        append a vertexAttribIPointer command to the command buffers

        args:
        - index(int or str): the index of the generic vertex attribute to be modified or the name of the attribute to find in the shader
        - size(int): specify the number of components per generic vertex attribute: must be 1,2,3,4
        - attrib_type(str): specify the data type of each component in the array
        - stride(int): specify the byte offset between consecutive generic vertex attributes
        - offset(int): specify the offset, in bytes, of the first component in the vertex attribute array
        - index_offset(int): add an offset to the index(location) found
        """
        if size < 1 or size > 4:
            raise AttributeError("invalid size")

        if attrib_type not in [
            "BYTE",
            "UNSIGNED_BYTE",
            "SHORT",
            "UNSIGNED_SHORT",
            "INT",
            "UNSIGNED_INT",
        ]:
            raise AttributeError("Invalid attribtype")

        self._commands.append(
            {
                "cmd": "vertexAttribIPointer",
                "index": index,
                "size": size,
                "type": attrib_type,
                "stride": stride,
                "offset": offset,
                "index_offset": index_offset,
            }
        )

    def vertex_attrib_divisor(self, index, divisor: int, index_offset: int = 0):
        """
        append a vertexAttribDivisor command to the command buffers
        - modifies the rate at which generic vertex attributes advance when rendering multiple instances of primitives with gl.drawArraysInstanced() or gl.drawElementsInstanced()

        args:
        - index(int or str): the index of the generic vertex attribute to be modified or the name of the attribute to find in the shader
        - divisor(int): specify the number of instances that will pass between updates of the generic attribute
        - index_offset(int): add an offset to the index(location) found
        """
        self._commands.append(
            {
                "cmd": "vertexAttribDivisor",
                "index": index,
                "divisor": divisor,
                "index_offset": index_offset,
            }
        )

    def create_vertex_array_ext(
        self, program: GLResourceWidget, bindings, indices=None, auto_execute=True
    ) -> GLResourceWidget:
        """
        extended vertex array creation:
        - this creates the vertex array and link all the attributes using the bindings

        the bindings are a list of tuples with:
        - [(buffer, "3f32 3f32, "in_vertex", "in_normal"), ...]
          or [(buffer, "3f32 3f32", 0, 1), ...]
          or [(buffer, "1mat4:1", "in_world"), ...]
        - the buffer is a buffer resource
        - supported type for buffer definitions: [1, 2, 3, 4][i8, i16, i32, u8, u16, u32, f16, f32, mat4](:[1,2,...])
        - the optional ':' is used to set the vertexAttribDivisor on that attribute

        args:
        - program(GLResourceWidget): the program to use
        - bindings(list of tuple): [(buffer, "3f32 3f32", "in_vertex", "in_normal"), ...]"
        - indices(np.array(dtype=u8 or dtype=u16)): the indices buffer to create
        - auto_execute(bool): do we execute the commands?
        """
        attributePointers = []
        for binding in bindings:
            buffer = binding[0]
            descriptions = binding[1]

            stride = 0
            pointer = {"buffer": buffer, "pointers": [], "stride": 0}
            attributePointers.append(pointer)

            for description_index, description_string in enumerate(
                descriptions.split()
            ):
                size = description_string[0]
                attrib_strings = description_string[1:].split(":")
                attrib_type = attrib_strings[0]
                attrib_divisor = 0
                if len(attrib_strings) == 2:
                    attrib_divisor = int(attrib_strings[1])
                name = binding[2 + description_index]

                if size not in ["1", "2", "3", "4"]:
                    raise AttributeError("invalid attribute size")

                if attrib_type not in [
                    "i8",
                    "i16",
                    "i32",
                    "u8",
                    "u16",
                    "u32",
                    "f16",
                    "f32",
                    "mat4",
                ]:
                    raise AttributeError("invalid attribute type")

                def _add(stride, size, attrib_type, index_offset):
                    isize = int(size)
                    attrib_size = {
                        "i8": 1,
                        "i16": 2,
                        "i32": 4,
                        "u8": 1,
                        "u16": 2,
                        "u32": 4,
                        "f16": 2,
                        "f32": 4,
                    }[attrib_type]
                    attrib_gl_type = {
                        "i8": "BYTE",
                        "i16": "SHORT",
                        "i32": "INT",
                        "u8": "UNSIGNED_BYTE",
                        "u16": "UNSIGNED_SHORT",
                        "u32": "UNSIGNED_INT",
                        "f16": "HALF_FLOAT",
                        "f32": "FLOAT",
                    }[attrib_type]
                    pointer["pointers"].append(
                        (
                            name,
                            isize,
                            attrib_gl_type,
                            stride,
                            index_offset,
                            attrib_divisor,
                        )
                    )
                    return stride + attrib_size * isize

                if attrib_type == "mat4":
                    stride = _add(stride, "4", "f32", 0)
                    stride = _add(stride, "4", "f32", 1)
                    stride = _add(stride, "4", "f32", 2)
                    stride = _add(stride, "4", "f32", 3)
                else:
                    stride = _add(stride, size, attrib_type, 0)

            pointer["stride"] = stride

        # create the vertex array
        vao = self.create_vertex_array()
        self.bind_vertex_array(vao)
        self.use_program(program)

        # bind the attributes
        for attrib in attributePointers:
            self.bind_buffer("ARRAY_BUFFER", attrib["buffer"])

            for pointer in attrib["pointers"]:
                self.enable_vertex_attrib_array(pointer[0], pointer[4])
                self.vertex_attrib_pointer(
                    pointer[0],
                    pointer[1],
                    pointer[2],
                    False,
                    attrib["stride"],
                    pointer[3],
                    pointer[4],
                )
                if pointer[5] > 0:
                    self.vertex_attrib_divisor(pointer[0], pointer[5], pointer[4])

        self.bind_buffer("ARRAY_BUFFER", None)

        # check if we need to create indices buffer
        if indices is not None:
            buffer = self.create_buffer()
            self.bind_buffer("ELEMENT_ARRAY_BUFFER", buffer)
            self.buffer_data(
                "ELEMENT_ARRAY_BUFFER", indices, "STATIC_DRAW", update_info=True
            )

        self.bind_vertex_array(None)
        self.use_program(None)

        if auto_execute:
            self.execute_commands(execute_once=True)

        return vao

    def vertex_attrib_fv(self, index, value: np.array, index_offset: int = 0):
        """
        append a vertexAttrib[1234]fv command to the command buffers
        - the type of vertexAttrib function to call will be decided from the shape of the array

        args:
        - index(int or str): specify the index of the generic vertex attribute or the name of the attribute to find in the shader
        - value(np.array(dtype=np.float32)): values to push
        - index_offset(int): add an offset to the index(location) found
        """
        meta_data, buffer = array_to_buffer(value)
        meta_data["index"] = len(self._buffers)
        self._buffers.append(buffer)
        self._commands.append(
            {
                "cmd": "vertexAttrib[1234]fv",
                "index": index,
                "buffer_metadata": meta_data,
                "index_offset": index_offset,
            }
        )

    def vertex_attrib_i4_fv(self, index, value: np.array, index_offset: int = 0):
        """
        append an vertexAttribI4[u]iv command to the command buffers
        - the type of vertexAttrib function to call will be decided from the type of the array

        args:
        - index(int or str): specify the index of the generic vertex attribute or the name of the attribute to find in the shader
        - value(np.array(dtype=np.uint32 or dtype=np.int32)): values to push
        - index_offset(int): add an offset to the index(location) found
        """
        meta_data, buffer = array_to_buffer(value)
        meta_data["index"] = len(self._buffers)
        self._buffers.append(buffer)
        self._commands.append(
            {
                "cmd": "vertexAttribI4[u]iv",
                "index": index,
                "buffer_metadata": meta_data,
                "index_offset": index_offset,
            }
        )

    def draw_arrays(self, mode: str, first: int, count: int):
        f"""
        append a drawArrays command to the command buffers

        args:
        - mode({'POINTS', 'LINE_STRIP', 'LINE_LOOP', 'LINES', 'TRIANGLE_STRIP', 'TRIANGLE_FAN', 'TRIANGLES'}): type of drawing operation
        - first(int): the starting index in the array of vector points
        - count(int): the number of indices to be rendered
        """
        if mode not in [
            "POINTS",
            "LINE_STRIP",
            "LINE_LOOP",
            "LINES",
            "TRIANGLE_STRIP",
            "TRIANGLE_FAN",
            "TRIANGLES",
        ]:
            raise AttributeError("invalid mode")
        self._commands.append(
            {
                "cmd": "drawArrays",
                "mode": mode,
                "first": first,
                "count": count,
            }
        )

    def draw_arrays_instanced(
        self, mode: str, first: int, count: int, instance_count: int
    ):
        """
        append a drawArraysInstanced command to the command buffers

        args:
        - mode({'POINTS', 'LINE_STRIP', 'LINE_LOOP', 'LINES', 'TRIANGLE_STRIP', 'TRIANGLE_FAN', 'TRIANGLES'}): type of drawing operation
        - first(int): the starting index in the array of vector points
        - count(int): the number of indices to be rendered
        - instance_count(int): the number of instances to be rendered
        """
        if mode not in [
            "POINTS",
            "LINE_STRIP",
            "LINE_LOOP",
            "LINES",
            "TRIANGLE_STRIP",
            "TRIANGLE_FAN",
            "TRIANGLES",
        ]:
            raise AttributeError("invalid mode")

        self._commands.append(
            {
                "cmd": "drawArraysInstanced",
                "mode": mode,
                "first": first,
                "count": count,
                "instance_count": instance_count,
            }
        )

    def draw_elements(self, mode: str, count: int, byte_type: str, offset: int):
        """
        append a drawElements command to the command buffers

        args:
        - mode({'POINTS', 'LINE_STRIP', 'LINE_LOOP', 'LINES', 'TRIANGLE_STRIP', 'TRIANGLE_FAN', 'TRIANGLES'}): type of drawing operation
        - count(int): the number of indices to be rendered
        - byte_type({'UNSIGNED_BYTE', 'UNSIGNED_SHORT'}): the type of the indices
        - offset(int): the offset of the indices
        """
        if mode not in [
            "POINTS",
            "LINE_STRIP",
            "LINE_LOOP",
            "LINES",
            "TRIANGLE_STRIP",
            "TRIANGLE_FAN",
            "TRIANGLES",
        ]:
            raise AttributeError("invalid mode")

        if byte_type not in ["UNSIGNED_BYTE", "UNSIGNED_SHORT"]:
            raise AttributeError("invalid byte_type")

        self._commands.append(
            {
                "cmd": "drawElements",
                "mode": mode,
                "count": count,
                "byte_type": byte_type,
                "offset": offset,
            }
        )

    def draw_elements_instanced(
        self, mode: str, count: int, byte_type: str, offset: int, instance_count: int
    ):
        """
        append a drawElementsInstanced command to the command buffers

        args:
        - mode({'POINTS', 'LINE_STRIP', 'LINE_LOOP', 'LINES', 'TRIANGLE_STRIP', 'TRIANGLE_FAN', 'TRIANGLES'}): type of drawing operation
        - count(int): the number of indices to be rendered
        - byte_type({'UNSIGNED_BYTE', 'UNSIGNED_SHORT'}): the type of the indices
        - offset(int): a byte offset in the element array buffer: must be a valid multiple of the size of the given type
        - instance_count(int): the number of instances of the set of elements to execute
        """
        if mode not in [
            "POINTS",
            "LINE_STRIP",
            "LINE_LOOP",
            "LINES",
            "TRIANGLE_STRIP",
            "TRIANGLE_FAN",
            "TRIANGLES",
        ]:
            raise AttributeError("invalid mode")

        if byte_type not in ["UNSIGNED_BYTE", "UNSIGNED_SHORT"]:
            raise AttributeError("invalid byte_type")

        self._commands.append(
            {
                "cmd": "drawElementsInstanced",
                "mode": mode,
                "count": count,
                "byte_type": byte_type,
                "offset": offset,
                "instance_count": instance_count,
            }
        )

    def create_frame_buffer(self) -> GLResourceWidget:
        """
        append a createFramebuffer command to the command buffers

        returns:
        - GLResourceWidget: the resource that will hold the frame-buffer
        """
        uid = len(self._resources)
        resource = GLResourceWidget(uid=uid)
        self._resources.append(resource)
        self._commands.append({"cmd": "createFramebuffer", "resource": uid})
        return resource

    def bind_frame_buffer(self, target: str, frame_buffer: GLResourceWidget):
        """
        append a bindFramebuffer command to the command buffers

        args:
        - target(str): the binding point (target) ["FRAMEBUFFER", "DRAW_FRAMEBUFFER", "READ_FRAMEBUFFER"]
        - frame_buffer(GLResourceWidget): the frame-buffer
        """
        if target not in ["FRAMEBUFFER", "DRAW_FRAMEBUFFER", "READ_FRAMEBUFFER"]:
            raise AttributeError("invalid target")

        uid = -1
        if frame_buffer is not None:
            uid = frame_buffer.uid
        self._commands.append(
            {"cmd": "bindFramebuffer", "target": target, "framebuffer": uid}
        )

    def frame_buffer_texture_2d(
        self,
        target: str,
        attachment: str,
        tex_target: str,
        texture: GLResourceWidget,
        level: int,
    ):
        """
        append a framebufferTexture2D command to the command buffers

        args:
        - target(str): the binding point (target) ["FRAMEBUFFER", "DRAW_FRAMEBUFFER", "READ_FRAMEBUFFER"]
        - attachment(str): the attachment point for the texture ["COLOR_ATTACHMENT0", "DEPTH_ATTACHMENT", "STENCIL_ATTACHMENT", 'DEPTH_STENCIL_ATTACHMENT', 'COLOR_ATTACHMENT1', 'COLOR_ATTACHMENT2', 'COLOR_ATTACHMENT3', 'COLOR_ATTACHMENT4', 'COLOR_ATTACHMENT5', 'COLOR_ATTACHMENT6', 'COLOR_ATTACHMENT7', 'COLOR_ATTACHMENT8', 'COLOR_ATTACHMENT9', 'COLOR_ATTACHMENT10', 'COLOR_ATTACHMENT11', 'COLOR_ATTACHMENT12', 'COLOR_ATTACHMENT13', 'COLOR_ATTACHMENT14', 'COLOR_ATTACHMENT15']:
        - tex_target(str): the texture target ["TEXTURE_2D", "TEXTURE_CUBE_MAP_POSITIVE_X", "TEXTURE_CUBE_MAP_NEGATIVE_X", "TEXTURE_CUBE_MAP_POSITIVE_Y", "TEXTURE_CUBE_MAP_NEGATIVE_Y", "TEXTURE_CUBE_MAP_POSITIVE_Z", "TEXTURE_CUBE_MAP_NEGATIVE_Z"]
        - texture(GLResourceWidget): the texture
        - level(int): the mipmap level of the texture image to be attached: must be 0
        """
        if target not in ["FRAMEBUFFER", "DRAW_FRAMEBUFFER", "READ_FRAMEBUFFER"]:
            raise AttributeError("invalid target")

        if attachment not in [
            "COLOR_ATTACHMENT0",
            "DEPTH_ATTACHMENT",
            "STENCIL_ATTACHMENT",
            "DEPTH_STENCIL_ATTACHMENT",
            "COLOR_ATTACHMENT1",
            "COLOR_ATTACHMENT2",
            "COLOR_ATTACHMENT3",
            "COLOR_ATTACHMENT4",
            "COLOR_ATTACHMENT5",
            "COLOR_ATTACHMENT6",
            "COLOR_ATTACHMENT7",
            "COLOR_ATTACHMENT8",
            "COLOR_ATTACHMENT9",
            "COLOR_ATTACHMENT10",
            "COLOR_ATTACHMENT11",
            "COLOR_ATTACHMENT12",
            "COLOR_ATTACHMENT13",
            "COLOR_ATTACHMENT14",
            "COLOR_ATTACHMENT15",
        ]:
            raise AttributeError("invalid attachment")

        if tex_target not in [
            "TEXTURE_2D",
            "TEXTURE_CUBE_MAP_POSITIVE_X",
            "TEXTURE_CUBE_MAP_NEGATIVE_X",
            "TEXTURE_CUBE_MAP_POSITIVE_Y",
            "TEXTURE_CUBE_MAP_NEGATIVE_Y",
            "TEXTURE_CUBE_MAP_POSITIVE_Z",
            "TEXTURE_CUBE_MAP_NEGATIVE_Z",
        ]:
            raise AttributeError("invalid tex_target")

        self._commands.append(
            {
                "cmd": "framebufferTexture2D",
                "target": target,
                "attachment": attachment,
                "textarget": tex_target,
                "texture": texture.uid,
                "level": level,
            }
        )

    def draw_buffers(self, buffers):
        """append a drawBuffers command to the command buffers"""
        for buf in buffers:
            if buf not in [
                "None",
                "BACK",
                "COLOR_ATTACHMENT0",
                "COLOR_ATTACHMENT1",
                "COLOR_ATTACHMENT2",
                "COLOR_ATTACHMENT3",
                "COLOR_ATTACHMENT4",
                "COLOR_ATTACHMENT5",
                "COLOR_ATTACHMENT6",
                "COLOR_ATTACHMENT7",
                "COLOR_ATTACHMENT8",
                "COLOR_ATTACHMENT9",
                "COLOR_ATTACHMENT10",
                "COLOR_ATTACHMENT11",
                "COLOR_ATTACHMENT12",
                "COLOR_ATTACHMENT13",
                "COLOR_ATTACHMENT14",
                "COLOR_ATTACHMENT15",
            ]:
                raise AttributeError("Invalid buffers")

        self._commands.append({"cmd": "drawBuffers", "buffers": buffers})

    def capture_frame(self):
        self.send({"spector": "capture_next"})
        return

    def capture_start(self, limit=4000, quick=True):
        self.send({"spector": "start", "limit": limit, "quick": quick})
        return

    def capture_stop(self):
        self.send({"spector": "stop"})
        return
