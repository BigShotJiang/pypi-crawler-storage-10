const path = require('path');
const version = require('./package.json').version;

const rules = [
    { test: /\.ts$/, loader: 'ts-loader', exclude: /node_modules/ },
]

const resolve = {
    extensions: ['.ts', '.js'],
}

module.exports = {
    mode: 'production',
    entry: "./src/extension.ts",
    experiments: { outputModule: true },
    output: {
        filename: "extension.js",
        library: { type: 'module' },
        path: path.resolve(__dirname, 'ssepywidget'),
        devtoolModuleFilenameTemplate: info => 'anywidget:///' + path.relative(__dirname, info.absoluteResourcePath).replace(/\\/g, '/'),
    },
    module: {
        rules,
    },    
    devtool: 'inline-source-map',
    resolve,
    optimization: { minimize: false, usedExports: false, concatenateModules: false },
}