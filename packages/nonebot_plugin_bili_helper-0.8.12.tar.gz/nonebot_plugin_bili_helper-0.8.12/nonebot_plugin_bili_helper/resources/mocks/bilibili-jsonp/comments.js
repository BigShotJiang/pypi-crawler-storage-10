jsonp_callback({
  "code": 0,
  "message": "0",
  "ttl": 1,
  "data": {
    "cursor": {
      "is_begin": true,
      "prev": 0,
      "next": 2,
      "is_end": false,
      "pagination_reply": {
        "next_offset": "CAEiAggC"
      },
      "session_id": "",
      "mode": 3,
      "mode_text": "",
      "all_count": 470,
      "support_mode": [
        2,
        3
      ],
      "name": "热门评论"
    },
    "replies": [
      {
        "rpid": 277106846912,
        "oid": 115256957471455,
        "type": 1,
        "mid": 452227304,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 6,
        "rcount": 6,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758790544,
        "mid_str": "452227304",
        "oid_str": "115256957471455",
        "rpid_str": "277106846912",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 12,
        "action": 0,
        "member": {
          "mid": "452227304",
          "uname": "文明鞍山人",
          "sex": "男",
          "sign": "82％的用户年龄在24岁以下，是国内互联网最年轻化的平台。",
          "avatar": "https://i2.hdslb.com/bfs/face/87395fedefa135c117023e46053bed836d7a9bf5.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/87395fedefa135c117023e46053bed836d7a9bf5.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "452227304"
          }
        },
        "content": {
          "message": "最强lcd：iPhone换个lcd屏幕，因为iPhone的LCD三方件有天马之类的厂做，好点的甚至能几乎四边等宽。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275667687953,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 277106846912,
            "parent": 277127523968,
            "dialog": 277127523968,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758805398,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275667687953",
            "root_str": "277106846912",
            "parent_str": "277127523968",
            "dialog_str": "277127523968",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "回复 @ghost3210 :😂",
              "at_name_to_mid": {
                "ghost3210": 105181639
              },
              "at_name_to_mid_str": {
                "ghost3210": "105181639"
              },
              "members": [
                {
                  "mid": "105181639",
                  "uname": "ghost3210",
                  "sex": "保密",
                  "sign": "",
                  "avatar": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
                  "rank": "10000",
                  "face_nft_new": 0,
                  "is_senior_member": 0,
                  "senior": {},
                  "level_info": {
                    "current_level": 5,
                    "current_min": 0,
                    "current_exp": 0,
                    "next_exp": 0
                  },
                  "pendant": {
                    "pid": 0,
                    "name": "",
                    "image": "",
                    "expire": 0,
                    "image_enhance": "",
                    "image_enhance_frame": "",
                    "n_pid": 0
                  },
                  "nameplate": {
                    "nid": 0,
                    "name": "",
                    "image": "",
                    "image_small": "",
                    "level": "",
                    "condition": ""
                  },
                  "official_verify": {
                    "type": -1,
                    "desc": ""
                  },
                  "vip": {
                    "vipType": 1,
                    "vipDueDate": 1687104000000,
                    "dueRemark": "",
                    "accessStatus": 0,
                    "vipStatus": 0,
                    "vipStatusWarn": "",
                    "themeType": 0,
                    "label": {
                      "path": "",
                      "text": "",
                      "label_theme": "",
                      "text_color": "",
                      "bg_style": 0,
                      "bg_color": "",
                      "border_color": "",
                      "use_img_label": true,
                      "img_label_uri_hans": "",
                      "img_label_uri_hant": "",
                      "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                      "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                      "label_id": 0,
                      "label_goto": null
                    },
                    "avatar_subscript": 0,
                    "nickname_color": ""
                  }
                }
              ],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "parent_reply_member": {
              "mid": "105181639",
              "name": "ghost3210"
            },
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 275705204321,
            "oid": 115256957471455,
            "type": 1,
            "mid": 4237404,
            "root": 277106846912,
            "parent": 277106846912,
            "dialog": 275705204321,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758850567,
            "mid_str": "4237404",
            "oid_str": "115256957471455",
            "rpid_str": "275705204321",
            "root_str": "277106846912",
            "parent_str": "277106846912",
            "dialog_str": "275705204321",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "4237404",
              "uname": "皮又浪-So2",
              "sex": "男",
              "sign": "请大家把点赞达到播放量的6%，这样就可以白嫖阿B的奖金了，现在的b站收益简直砍得离谱，还请大家多多点赞吧，这对up很重要",
              "avatar": "https://i0.hdslb.com/bfs/face/9fa29ec000050e999ce18e8286ce73013e770a93.gif",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 10,
                "name": "见习偶像",
                "image": "https://i2.hdslb.com/bfs/face/e93dd9edfa7b9e18bf46fd8d71862327a2350923.png",
                "image_small": "https://i1.hdslb.com/bfs/face/275b468b043ec246737ab8580a2075bee0b1263b.png",
                "level": "普通勋章",
                "condition": "所有自制视频总播放数>=10万"
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1746806400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 4,
                        "res_animation": {
                          "webp_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/9fa29ec000050e999ce18e8286ce73013e770a93.gif",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "4237404"
              }
            },
            "content": {
              "message": "缺点很明显，光感会失灵",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "43分钟前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共6条回复",
          "sub_reply_title_text": "相关回复共6条",
          "time_desc": "17小时前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277058022176,
        "oid": 115256957471455,
        "type": 1,
        "mid": 1135706602,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 1,
        "rcount": 0,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758736154,
        "mid_str": "1135706602",
        "oid_str": "115256957471455",
        "rpid_str": "277058022176",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 21,
        "action": 0,
        "member": {
          "mid": "1135706602",
          "uname": "默悦er",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i1.hdslb.com/bfs/face/27981ef5e373de4cdf471c0160dfd58b118d6130.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i1.hdslb.com/bfs/face/27981ef5e373de4cdf471c0160dfd58b118d6130.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "1135706602"
          }
        },
        "content": {
          "message": "（诶匝哇呃臭鼬水獭海豹）天玑7400卖3000-4000狗看了都摇头。。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": null,
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277111573504,
        "oid": 115256957471455,
        "type": 1,
        "mid": 3546557680978525,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 2,
        "rcount": 2,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758793995,
        "mid_str": "3546557680978525",
        "oid_str": "115256957471455",
        "rpid_str": "277111573504",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 2,
        "action": 0,
        "member": {
          "mid": "3546557680978525",
          "uname": "泉有一方",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i1.hdslb.com/bfs/face/3371fbcd393d0ff569e16f799b99139f08be17ca.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i1.hdslb.com/bfs/face/3371fbcd393d0ff569e16f799b99139f08be17ca.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "3546557680978525"
          }
        },
        "content": {
          "message": "真需要的绝对会买，只不过预期价格可能在2500左右，这是大屏机型，大小跟荣耀x30max一样大，使用了窄边框技术，所以对于大屏LCD党来说这款可以算是你唯一的选择，120刷新加7.2寸护眼屏幕，可以说现在我就是在等这手机国行，海淘12➕512大概在5k左右，属实溢价太高了，很多人看到7400就劝退，目前来说手机核心除了那几个性能大户，一般玩家也就玩个王者绝对是足够了，只不过国外机大概率会没那么在乎散热，喜欢大屏LCD用户这就是你唯一的选择，首发我肯定不会购买，但是一两个月后我会考虑购入",
          "members": [],
          "jump_url": {
            "荣耀x30max": {
              "title": "荣耀x30max",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=%E8%8D%A3%E8%80%80x30max&seid=8472502157008465741&from_avid=115256957471455&from_comid=277111573504",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=%E8%8D%A3%E8%80%80x30max&seid=8472502157008465741&from_avid=115256957471455&from_comid=277111573504",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275668855633,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 277111573504,
            "parent": 277111573504,
            "dialog": 275668855633,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758806227,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668855633",
            "root_str": "277111573504",
            "parent_str": "277111573504",
            "dialog_str": "275668855633",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "🙏🏻",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277164020640,
            "oid": 115256957471455,
            "type": 1,
            "mid": 410538718,
            "root": 277111573504,
            "parent": 277111573504,
            "dialog": 277164020640,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758844722,
            "mid_str": "410538718",
            "oid_str": "115256957471455",
            "rpid_str": "277164020640",
            "root_str": "277111573504",
            "parent_str": "277111573504",
            "dialog_str": "277164020640",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "410538718",
              "uname": "huijing666",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 3,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1721232000000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "410538718"
              }
            },
            "content": {
              "message": "是的。荣耀那款我用了，屏幕还好，大小也还行就是重了点拿久了。tcl买了p10,屏幕比y100t舒服，可以说是最舒服的毕竟磨砂屏比贴膜护眼。大屏出来了价格合理可以考虑",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "2小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共2条回复",
          "sub_reply_title_text": "相关回复共2条",
          "time_desc": "16小时前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 275550536753,
        "oid": 115256957471455,
        "type": 1,
        "mid": 385802498,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 0,
        "rcount": 0,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758699805,
        "mid_str": "385802498",
        "oid_str": "115256957471455",
        "rpid_str": "275550536753",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 4,
        "action": 0,
        "member": {
          "mid": "385802498",
          "uname": "来二两桂花酒",
          "sex": "男",
          "sign": "做人嘛不必太正常",
          "avatar": "https://i2.hdslb.com/bfs/face/ed7914557400d7e8ba63824e0082e4e084470bc2.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1602345600000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/ed7914557400d7e8ba63824e0082e4e084470bc2.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "385802498"
          }
        },
        "content": {
          "message": "听说还不如我红米11t",
          "members": [],
          "jump_url": {
            "红米11t": {
              "title": "红米11t",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=%E7%BA%A2%E7%B1%B311t&seid=8472502157008465741&from_avid=115256957471455&from_comid=275550536753",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=%E7%BA%A2%E7%B1%B311t&seid=8472502157008465741&from_avid=115256957471455&from_comid=275550536753",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": null,
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276997393344,
        "oid": 115256957471455,
        "type": 1,
        "mid": 1890556336,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 52,
        "rcount": 46,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758693072,
        "mid_str": "1890556336",
        "oid_str": "115256957471455",
        "rpid_str": "276997393344",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 87,
        "action": 0,
        "member": {
          "mid": "1890556336",
          "uname": "bigzampro",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1746028800000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "1890556336"
          }
        },
        "content": {
          "message": "7400的CPU部分約等同865，除了重度遊戲都夠用。\n噴價格可以，確實貴了，但噴soc只會讓廠商覺得LCD黨很難搞，以後不出了，而且這台配的是好屏。\nplay商店版的app連835都還能用，瓶頸是4G，XZP拿去擴容8G都還能用。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275569434081,
            "oid": 115256957471455,
            "type": 1,
            "mid": 885972,
            "root": 276997393344,
            "parent": 276997393344,
            "dialog": 275569434081,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758713736,
            "mid_str": "885972",
            "oid_str": "115256957471455",
            "rpid_str": "275569434081",
            "root_str": "276997393344",
            "parent_str": "276997393344",
            "dialog_str": "275569434081",
            "like": 8,
            "action": 0,
            "member": {
              "mid": "885972",
              "uname": "黯風之影",
              "sex": "男",
              "sign": "",
              "avatar": "https://i0.hdslb.com/bfs/face/fbb9e8ac38e17689598e76e561209f1d161e4f42.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 1,
              "senior": {
                "status": 2
              },
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 2,
                "vipDueDate": 1825171200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 1,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
                  "text": "年度大会员",
                  "label_theme": "annual_vip",
                  "text_color": "#FFFFFF",
                  "bg_style": 1,
                  "bg_color": "#FB7299",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/e74c74edc802bc4badba15f03e69d7cff75f2679.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png",
                  "label_id": 47,
                  "label_goto": {
                    "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                    "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
                  }
                },
                "avatar_subscript": 1,
                "nickname_color": "#FB7299"
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/fbb9e8ac38e17689598e76e561209f1d161e4f42.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0333333333333332,
                          "axis_y": 1.0333333333333332
                        },
                        "size_spec": {
                          "width": 0.39999999999999997,
                          "height": 0.39999999999999997
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 5,
                        "res_native_draw": {
                          "draw_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "is_dark_mode_aware": true,
                                "day": {
                                  "argb": "#FFFFFFFF"
                                },
                                "night": {
                                  "argb": "#FF17181A"
                                }
                              }
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0666666666666667,
                          "axis_y": 1.0666666666666667
                        },
                        "size_spec": {
                          "width": 0.3333333333333333,
                          "height": 0.3333333333333333
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 1,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "885972"
              }
            },
            "content": {
              "message": "865都是6年前的芯片了，835是9年前了。而你现在要买一个6年前的旗舰芯片手机，至少也要用2-4年时间",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 275572032945,
            "oid": 115256957471455,
            "type": 1,
            "mid": 383554450,
            "root": 276997393344,
            "parent": 276997393344,
            "dialog": 275572032945,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758715388,
            "mid_str": "383554450",
            "oid_str": "115256957471455",
            "rpid_str": "275572032945",
            "root_str": "276997393344",
            "parent_str": "276997393344",
            "dialog_str": "275572032945",
            "like": 5,
            "action": 0,
            "member": {
              "mid": "383554450",
              "uname": "老旧工具人",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i1.hdslb.com/bfs/face/a1f83ed5b9dba2b5e98dd5591b4429ae7fa573b0.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1743523200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/a1f83ed5b9dba2b5e98dd5591b4429ae7fa573b0.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "383554450"
              }
            },
            "content": {
              "message": "国际版够用了，谷歌本身也不用太好的处理器，广告少，但是要是到国内版，各种广告，国内版app一上，就不好说了",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共46条回复",
          "sub_reply_title_text": "相关回复共46条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276986537808,
        "oid": 115256957471455,
        "type": 1,
        "mid": 441496620,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 12,
        "rcount": 11,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758685790,
        "mid_str": "441496620",
        "oid_str": "115256957471455",
        "rpid_str": "276986537808",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 28,
        "action": 0,
        "member": {
          "mid": "441496620",
          "uname": "财神爷最爱的仔v",
          "sex": "男",
          "sign": "白白胖胖，可可爱爱，傻傻呼呼，无忧无虑……",
          "avatar": "https://i0.hdslb.com/bfs/face/db9be56fbb995a9997d9fc8615795655114acb8e.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/db9be56fbb995a9997d9fc8615795655114acb8e.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "441496620"
          }
        },
        "content": {
          "message": "这下估计又要骂LCD党呼声大雨点小了！\n电池小，处理器差，然后卖了3000多！\n但凡换个好一点的处理器，这个价格也能接受！\n我估计这下LCD档又要被骂了",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 276990963104,
            "oid": 115256957471455,
            "type": 1,
            "mid": 630074106,
            "root": 276986537808,
            "parent": 276986537808,
            "dialog": 276990963104,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758688547,
            "mid_str": "630074106",
            "oid_str": "115256957471455",
            "rpid_str": "276990963104",
            "root_str": "276986537808",
            "parent_str": "276986537808",
            "dialog_str": "276990963104",
            "like": 17,
            "action": 0,
            "member": {
              "mid": "630074106",
              "uname": "bili_630074106",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i0.hdslb.com/bfs/face/c49f61b49ee3bd50b4f305c679d2d6ac85a97027.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1759334400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 1,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "http://i0.hdslb.com/bfs/vip/label_vip.png",
                  "text": "大会员",
                  "label_theme": "vip",
                  "text_color": "#FFFFFF",
                  "bg_style": 1,
                  "bg_color": "#FB7299",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/eedd81c58dd74d47ddc10b4412b84c0f73457959.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/jwXBWRVwa5.png",
                  "label_id": 47,
                  "label_goto": {
                    "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                    "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
                  }
                },
                "avatar_subscript": 1,
                "nickname_color": "#FB7299"
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/c49f61b49ee3bd50b4f305c679d2d6ac85a97027.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0333333333333332,
                          "axis_y": 1.0333333333333332
                        },
                        "size_spec": {
                          "width": 0.39999999999999997,
                          "height": 0.39999999999999997
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 5,
                        "res_native_draw": {
                          "draw_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "is_dark_mode_aware": true,
                                "day": {
                                  "argb": "#FFFFFFFF"
                                },
                                "night": {
                                  "argb": "#FF17181A"
                                }
                              }
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0666666666666667,
                          "axis_y": 1.0666666666666667
                        },
                        "size_spec": {
                          "width": 0.3333333333333333,
                          "height": 0.3333333333333333
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 1,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "630074106"
              }
            },
            "content": {
              "message": "为了lcd也不能总让人吃史吧，另外，销量的高低都跟是不是lcd没关系，你不能证明因为lcd卖的好，同样也证明不了因为lcd卖的差，手机的组成又不只有一块屏，那群人骂的毫无道理。",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277019628432,
            "oid": 115256957471455,
            "type": 1,
            "mid": 666801217,
            "root": 276986537808,
            "parent": 276986537808,
            "dialog": 277019628432,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758710127,
            "mid_str": "666801217",
            "oid_str": "115256957471455",
            "rpid_str": "277019628432",
            "root_str": "276986537808",
            "parent_str": "276986537808",
            "dialog_str": "277019628432",
            "like": 4,
            "action": 0,
            "member": {
              "mid": "666801217",
              "uname": "bili_16885889309",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i1.hdslb.com/bfs/face/ad23e0cd5ff1ac5d7332b9b67739209e1275e491.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/ad23e0cd5ff1ac5d7332b9b67739209e1275e491.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "666801217"
              }
            },
            "content": {
              "message": "不敢奢求8gen3，如果这价格上7gen3我都能接受",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共11条回复",
          "sub_reply_title_text": "相关回复共11条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277073846352,
        "oid": 115256957471455,
        "type": 1,
        "mid": 35423310,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 2,
        "rcount": 2,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758765374,
        "mid_str": "35423310",
        "oid_str": "115256957471455",
        "rpid_str": "277073846352",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 3,
        "action": 0,
        "member": {
          "mid": "35423310",
          "uname": "makeinchina23",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i0.hdslb.com/bfs/face/753466209bba31ed56ee6ec424d07adaff03fb4f.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1741363200000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/753466209bba31ed56ee6ec424d07adaff03fb4f.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "35423310"
          }
        },
        "content": {
          "message": "[妙啊]又要屏幕好又要soc屌，价格还要适中。做啥都要挑毛病 怪不得人家不伺候国内的大爷",
          "members": [],
          "emote": {
            "[妙啊]": {
              "id": 435,
              "package_id": 1,
              "state": 0,
              "type": 1,
              "attr": 0,
              "text": "[妙啊]",
              "url": "https://i0.hdslb.com/bfs/emote/b4cb77159d58614a9b787b91b1cd22a81f383535.png",
              "meta": {
                "size": 1,
                "suggest": [
                  ""
                ]
              },
              "mtime": 1668688325,
              "jump_title": "妙啊"
            }
          },
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275622751409,
            "oid": 115256957471455,
            "type": 1,
            "mid": 447223490,
            "root": 277073846352,
            "parent": 277073846352,
            "dialog": 275622751409,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758772025,
            "mid_str": "447223490",
            "oid_str": "115256957471455",
            "rpid_str": "275622751409",
            "root_str": "277073846352",
            "parent_str": "277073846352",
            "dialog_str": "275622751409",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "447223490",
              "uname": "渐听春雨",
              "sex": "男",
              "sign": "该账号已永久封禁",
              "avatar": "https://i2.hdslb.com/bfs/face/2a2b3c81e92fb1ac798cb0ed66f2cfef9cf42d99.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 3642,
                "name": "星座系列：摩羯座",
                "image": "https://i2.hdslb.com/bfs/garb/item/b145dea561e2cb837d72725d28b483f7841fe78b.png",
                "expire": 0,
                "image_enhance": "https://i2.hdslb.com/bfs/garb/item/b145dea561e2cb837d72725d28b483f7841fe78b.png",
                "image_enhance_frame": "",
                "n_pid": 3642
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1680019200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 0.787,
                          "height": 0.787
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 0.787,
                              "height": 0.787
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/face/2a2b3c81e92fb1ac798cb0ed66f2cfef9cf42d99.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1.375,
                          "height": 1.375
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "PENDENT_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/garb/item/b145dea561e2cb837d72725d28b483f7841fe78b.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "447223490"
              }
            },
            "content": {
              "message": "量少，做不了主流",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "22小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 275668463569,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 277073846352,
            "parent": 277073846352,
            "dialog": 275668463569,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758805955,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668463569",
            "root_str": "277073846352",
            "parent_str": "277073846352",
            "dialog_str": "275668463569",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "😂",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共2条回复",
          "sub_reply_title_text": "相关回复共2条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276986354848,
        "oid": 115256957471455,
        "type": 1,
        "mid": 28833224,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 1,
        "rcount": 1,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758685589,
        "mid_str": "28833224",
        "oid_str": "115256957471455",
        "rpid_str": "276986354848",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 4,
        "action": 0,
        "member": {
          "mid": "28833224",
          "uname": "柠檬树下只有我Bigger",
          "sex": "男",
          "sign": "我以为逗你笑你就会喜欢我，可是却输给了让你哭的人",
          "avatar": "https://i2.hdslb.com/bfs/face/3ed0a5e569e43bf679edbf61ef37a58f553515e8.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/3ed0a5e569e43bf679edbf61ef37a58f553515e8.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "28833224"
          }
        },
        "content": {
          "message": "7400也叫强？",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275548256289,
            "oid": 115256957471455,
            "type": 1,
            "mid": 1602166462,
            "root": 276986354848,
            "parent": 276986354848,
            "dialog": 275548256289,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758697679,
            "mid_str": "1602166462",
            "oid_str": "115256957471455",
            "rpid_str": "275548256289",
            "root_str": "276986354848",
            "parent_str": "276986354848",
            "dialog_str": "275548256289",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "1602166462",
              "uname": "灵翼MAGICWAN",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i1.hdslb.com/bfs/face/d626e52347949061494d552bbf8d81b1868fc556.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/d626e52347949061494d552bbf8d81b1868fc556.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "1602166462"
              }
            },
            "content": {
              "message": "我也想说  就算你屏幕再好，电池一般系统不好用也白搭",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共1条回复",
          "sub_reply_title_text": "相关回复共1条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 275609387681,
        "oid": 115256957471455,
        "type": 1,
        "mid": 30193680,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 2,
        "rcount": 2,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758759148,
        "mid_str": "30193680",
        "oid_str": "115256957471455",
        "rpid_str": "275609387681",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 4,
        "action": 0,
        "member": {
          "mid": "30193680",
          "uname": "我在这里看录像",
          "sex": "男",
          "sign": "",
          "avatar": "https://i0.hdslb.com/bfs/face/f4e9d3dd8ec9712f552daa754a9123ba7afa31a4.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 2,
            "vipDueDate": 1766419200000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 1,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
              "text": "年度大会员",
              "label_theme": "annual_vip",
              "text_color": "#FFFFFF",
              "bg_style": 1,
              "bg_color": "#FB7299",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/181d41061e21336e1265ef93000f19e5ae295e7a.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/uckjAv3Npy.png",
              "label_id": 47,
              "label_goto": {
                "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
              }
            },
            "avatar_subscript": 1,
            "nickname_color": "#FB7299"
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/f4e9d3dd8ec9712f552daa754a9123ba7afa31a4.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 1.0333333333333332,
                      "axis_y": 1.0333333333333332
                    },
                    "size_spec": {
                      "width": 0.39999999999999997,
                      "height": 0.39999999999999997
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 5,
                    "res_native_draw": {
                      "draw_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "is_dark_mode_aware": true,
                            "day": {
                              "argb": "#FFFFFFFF"
                            },
                            "night": {
                              "argb": "#FF17181A"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 1.0666666666666667,
                      "axis_y": 1.0666666666666667
                    },
                    "size_spec": {
                      "width": 0.3333333333333333,
                      "height": 0.3333333333333333
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 1,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "30193680"
          }
        },
        "content": {
          "message": "那还不如淘一个neo3，再不行z6，何必买这个",
          "members": [],
          "jump_url": {
            "neo3": {
              "title": "neo3",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=neo3&seid=8472502157008465741&from_avid=115256957471455&from_comid=275609387681",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=neo3&seid=8472502157008465741&from_avid=115256957471455&from_comid=275609387681",
              "icon_position": 1
            },
            "z6": {
              "title": "z6",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=z6&seid=8472502157008465741&from_avid=115256957471455&from_comid=275609387681",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=z6&seid=8472502157008465741&from_avid=115256957471455&from_comid=275609387681",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275668217185,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 275609387681,
            "parent": 275609387681,
            "dialog": 275668217185,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758805791,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668217185",
            "root_str": "275609387681",
            "parent_str": "275609387681",
            "dialog_str": "275668217185",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "😂",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277095535984,
            "oid": 115256957471455,
            "type": 1,
            "mid": 483701937,
            "root": 275609387681,
            "parent": 275609387681,
            "dialog": 277095535984,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758780919,
            "mid_str": "483701937",
            "oid_str": "115256957471455",
            "rpid_str": "277095535984",
            "root_str": "275609387681",
            "parent_str": "275609387681",
            "dialog_str": "277095535984",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "483701937",
              "uname": "椿泉",
              "sex": "保密",
              "sign": "一起喝下午茶",
              "avatar": "https://i0.hdslb.com/bfs/face/e1ee463ac272b8c3c90496147bd24f2ca9c5cd37.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 4,
                "name": "青铜殿堂",
                "image": "https://i1.hdslb.com/bfs/face/2879cd5fb8518f7c6da75887994c1b2a7fe670bd.png",
                "image_small": "https://i2.hdslb.com/bfs/face/6707c120e00a3445933308fd9b7bd9fad99e9ec4.png",
                "level": "普通勋章",
                "condition": "单个自制视频总播放数>=1万"
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1626364800000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/e1ee463ac272b8c3c90496147bd24f2ca9c5cd37.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "483701937"
              }
            },
            "content": {
              "message": "neo3神🀄神",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "20小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共2条回复",
          "sub_reply_title_text": "相关回复共2条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 275547825665,
        "oid": 115256957471455,
        "type": 1,
        "mid": 8940276,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 1,
        "rcount": 1,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758697358,
        "mid_str": "8940276",
        "oid_str": "115256957471455",
        "rpid_str": "275547825665",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 3,
        "action": 0,
        "member": {
          "mid": "8940276",
          "uname": "吃喝玩乐林一新",
          "sex": "男",
          "sign": "常与高士论高下，不与沙包争长短",
          "avatar": "https://i0.hdslb.com/bfs/face/d0fef8e9e4ccb7100974b90b420a105c036bb7a6.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 1,
            "name": "黄金殿堂",
            "image": "https://i2.hdslb.com/bfs/face/82896ff40fcb4e7c7259cb98056975830cb55695.png",
            "image_small": "https://i1.hdslb.com/bfs/face/627e342851dfda6fe7380c2fa0cbd7fae2e61533.png",
            "level": "稀有勋章",
            "condition": "单个自制视频总播放数>=100万"
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1759248000000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 1,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "http://i0.hdslb.com/bfs/vip/label_vip.png",
              "text": "大会员",
              "label_theme": "vip",
              "text_color": "#FFFFFF",
              "bg_style": 1,
              "bg_color": "#FB7299",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/eedd81c58dd74d47ddc10b4412b84c0f73457959.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/jwXBWRVwa5.png",
              "label_id": 47,
              "label_goto": {
                "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
              }
            },
            "avatar_subscript": 1,
            "nickname_color": "#FB7299"
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/d0fef8e9e4ccb7100974b90b420a105c036bb7a6.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 1.0333333333333332,
                      "axis_y": 1.0333333333333332
                    },
                    "size_spec": {
                      "width": 0.39999999999999997,
                      "height": 0.39999999999999997
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 5,
                    "res_native_draw": {
                      "draw_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "is_dark_mode_aware": true,
                            "day": {
                              "argb": "#FFFFFFFF"
                            },
                            "night": {
                              "argb": "#FF17181A"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 1.0666666666666667,
                      "axis_y": 1.0666666666666667
                    },
                    "size_spec": {
                      "width": 0.3333333333333333,
                      "height": 0.3333333333333333
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 1,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "8940276"
          }
        },
        "content": {
          "message": "这么贵，你凭什么",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275669905041,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 275547825665,
            "parent": 275547825665,
            "dialog": 275669905041,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758806867,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275669905041",
            "root_str": "275547825665",
            "parent_str": "275547825665",
            "dialog_str": "275669905041",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "😂",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "12小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共1条回复",
          "sub_reply_title_text": "相关回复共1条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277014283280,
        "oid": 115256957471455,
        "type": 1,
        "mid": 291191540,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 6,
        "rcount": 6,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758706813,
        "mid_str": "291191540",
        "oid_str": "115256957471455",
        "rpid_str": "277014283280",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 19,
        "action": 0,
        "member": {
          "mid": "291191540",
          "uname": "oc薇",
          "sex": "保密",
          "sign": "我的人生以前挺平凡的，直到遇到这个小破站，才让我黑白的世界里能多出一点光彩，无论以后的我过的好与坏，我都希望能和这唯一的爱好一直走下去。",
          "avatar": "https://i2.hdslb.com/bfs/face/52d9f85187d3caf1fbd00f00e9c11d3c2ccfa8ea.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 90,
            "name": "有爱萌新",
            "image": "https://i1.hdslb.com/bfs/face/51ca16136e570938450bca360f28761ceb609f33.png",
            "image_small": "https://i1.hdslb.com/bfs/face/9abfa4769357f85937782c2dbc40fafda4f57217.png",
            "level": "普通勋章",
            "condition": "当前持有粉丝勋章最高等级>=5级"
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1662912000000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/52d9f85187d3caf1fbd00f00e9c11d3c2ccfa8ea.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "291191540"
          }
        },
        "content": {
          "message": "3000甚至4000买个7300我都能忍受，我就想知道这块屏幕到底比别的LCD屏好在哪里。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275667804865,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 277014283280,
            "parent": 277053030656,
            "dialog": 277053030656,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758805478,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275667804865",
            "root_str": "277014283280",
            "parent_str": "277053030656",
            "dialog_str": "277053030656",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "回复 @bili_36541567142 :🙏🏻",
              "at_name_to_mid": {
                "bili_36541567142": 1318917204
              },
              "at_name_to_mid_str": {
                "bili_36541567142": "1318917204"
              },
              "members": [
                {
                  "mid": "1318917204",
                  "uname": "bili_36541567142",
                  "sex": "保密",
                  "sign": "",
                  "avatar": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
                  "rank": "10000",
                  "face_nft_new": 0,
                  "is_senior_member": 0,
                  "senior": {},
                  "level_info": {
                    "current_level": 5,
                    "current_min": 0,
                    "current_exp": 0,
                    "next_exp": 0
                  },
                  "pendant": {
                    "pid": 0,
                    "name": "",
                    "image": "",
                    "expire": 0,
                    "image_enhance": "",
                    "image_enhance_frame": "",
                    "n_pid": 0
                  },
                  "nameplate": {
                    "nid": 0,
                    "name": "",
                    "image": "",
                    "image_small": "",
                    "level": "",
                    "condition": ""
                  },
                  "official_verify": {
                    "type": -1,
                    "desc": ""
                  },
                  "vip": {
                    "vipType": 0,
                    "vipDueDate": 0,
                    "dueRemark": "",
                    "accessStatus": 0,
                    "vipStatus": 0,
                    "vipStatusWarn": "",
                    "themeType": 0,
                    "label": {
                      "path": "",
                      "text": "",
                      "label_theme": "",
                      "text_color": "",
                      "bg_style": 0,
                      "bg_color": "",
                      "border_color": "",
                      "use_img_label": true,
                      "img_label_uri_hans": "",
                      "img_label_uri_hant": "",
                      "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                      "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                      "label_id": 0,
                      "label_goto": null
                    },
                    "avatar_subscript": 0,
                    "nickname_color": ""
                  }
                }
              ],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "parent_reply_member": {
              "mid": "1318917204",
              "name": "bili_36541567142"
            },
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277053030656,
            "oid": 115256957471455,
            "type": 1,
            "mid": 1318917204,
            "root": 277014283280,
            "parent": 277014283280,
            "dialog": 277053030656,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758731084,
            "mid_str": "1318917204",
            "oid_str": "115256957471455",
            "rpid_str": "277053030656",
            "root_str": "277014283280",
            "parent_str": "277014283280",
            "dialog_str": "277053030656",
            "like": 4,
            "action": 0,
            "member": {
              "mid": "1318917204",
              "uname": "bili_36541567142",
              "sex": "保密",
              "sign": "",
              "avatar": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "1318917204"
              }
            },
            "content": {
              "message": "听说是完整的lcd，没有阉割",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共6条回复",
          "sub_reply_title_text": "相关回复共6条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 275529486497,
        "oid": 115256957471455,
        "type": 1,
        "mid": 73805379,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 5,
        "rcount": 5,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758682767,
        "mid_str": "73805379",
        "oid_str": "115256957471455",
        "rpid_str": "275529486497",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 22,
        "action": 0,
        "member": {
          "mid": "73805379",
          "uname": "农药到底谁在赢",
          "sex": "女",
          "sign": "天生GB圣体",
          "avatar": "https://i0.hdslb.com/bfs/face/60110dafcc5c85513c7b9246a3fbdac20b2a5880.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 149,
            "name": "快把我哥带走",
            "image": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
            "expire": 0,
            "image_enhance": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
            "image_enhance_frame": "",
            "n_pid": 149
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 2,
            "vipDueDate": 1770652800000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 1,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
              "text": "年度大会员",
              "label_theme": "annual_vip",
              "text_color": "#FFFFFF",
              "bg_style": 1,
              "bg_color": "#FB7299",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/e74c74edc802bc4badba15f03e69d7cff75f2679.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png",
              "label_id": 47,
              "label_goto": {
                "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
              }
            },
            "avatar_subscript": 1,
            "nickname_color": "#FB7299"
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": {
              "id": 149,
              "name": "快把我哥带走",
              "image": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
              "jump_url": "",
              "type": "vip",
              "image_enhance": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
              "image_enhance_frame": ""
            },
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {
            "pendant": {
              "id": 149,
              "name": "快把我哥带走",
              "image": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
              "type": "vip",
              "image_enhance": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png"
            }
          },
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 0.787,
                      "height": 0.787
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 0.787,
                          "height": 0.787
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/60110dafcc5c85513c7b9246a3fbdac20b2a5880.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1.375,
                      "height": 1.375
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "PENDENT_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/6b45cf8ceb8cd6eeefbbcb202659e62a56356814.png",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 0.9768333333333333,
                      "axis_y": 0.9934999999999999
                    },
                    "size_spec": {
                      "width": 0.39999999999999997,
                      "height": 0.39999999999999997
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 5,
                    "res_native_draw": {
                      "draw_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "is_dark_mode_aware": true,
                            "day": {
                              "argb": "#FFFFFFFF"
                            },
                            "night": {
                              "argb": "#FF17181A"
                            }
                          }
                        }
                      }
                    }
                  }
                },
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 1,
                      "axis_x": 1.0101666666666667,
                      "axis_y": 1.0268333333333333
                    },
                    "size_spec": {
                      "width": 0.3333333333333333,
                      "height": 0.3333333333333333
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "ICON_LAYER": {}
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 1,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "73805379"
          }
        },
        "content": {
          "message": "呃，天玑7400就算了吧[笑哭]",
          "members": [],
          "emote": {
            "[笑哭]": {
              "id": 509,
              "package_id": 1,
              "state": 0,
              "type": 1,
              "attr": 0,
              "text": "[笑哭]",
              "url": "https://i0.hdslb.com/bfs/emote/c3043ba94babf824dea03ce500d0e73763bf4f40.png",
              "meta": {
                "size": 1,
                "suggest": [
                  ""
                ]
              },
              "mtime": 1668688325,
              "jump_title": "笑哭"
            }
          },
          "jump_url": {
            "天玑7400": {
              "title": "天玑7400",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=%E5%A4%A9%E7%8E%917400&seid=8472502157008465741&from_avid=115256957471455&from_comid=275529486497",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=%E5%A4%A9%E7%8E%917400&seid=8472502157008465741&from_avid=115256957471455&from_comid=275529486497",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275668017937,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 275529486497,
            "parent": 277006216752,
            "dialog": 277006216752,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758805581,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668017937",
            "root_str": "275529486497",
            "parent_str": "277006216752",
            "dialog_str": "277006216752",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "回复 @英雄联盟-小黑鸦 :🙏🏻",
              "at_name_to_mid": {
                "英雄联盟-小黑鸦": 498804301
              },
              "at_name_to_mid_str": {
                "英雄联盟-小黑鸦": "498804301"
              },
              "members": [
                {
                  "mid": "498804301",
                  "uname": "英雄联盟-小黑鸦",
                  "sex": "保密",
                  "sign": "暗爪乌鸦创始人",
                  "avatar": "https://i1.hdslb.com/bfs/face/80aebd14e08b45bf32ed84954ea7f6b1637e637f.jpg",
                  "rank": "10000",
                  "face_nft_new": 0,
                  "is_senior_member": 0,
                  "senior": {},
                  "level_info": {
                    "current_level": 5,
                    "current_min": 0,
                    "current_exp": 0,
                    "next_exp": 0
                  },
                  "pendant": {
                    "pid": 0,
                    "name": "",
                    "image": "",
                    "expire": 0,
                    "image_enhance": "",
                    "image_enhance_frame": "",
                    "n_pid": 0
                  },
                  "nameplate": {
                    "nid": 59,
                    "name": "大收藏家",
                    "image": "https://i1.hdslb.com/bfs/face/d12b5db77341e3285f25cc0db82f73e5681a0190.png",
                    "image_small": "https://i2.hdslb.com/bfs/face/6bd23ec2d295a5a3e3a8cdde107f62605fd4f9b7.png",
                    "level": "普通勋章",
                    "condition": "同时拥有粉丝勋章>=25个"
                  },
                  "official_verify": {
                    "type": -1,
                    "desc": ""
                  },
                  "vip": {
                    "vipType": 1,
                    "vipDueDate": 1626451200000,
                    "dueRemark": "",
                    "accessStatus": 0,
                    "vipStatus": 0,
                    "vipStatusWarn": "",
                    "themeType": 0,
                    "label": {
                      "path": "",
                      "text": "",
                      "label_theme": "",
                      "text_color": "",
                      "bg_style": 0,
                      "bg_color": "",
                      "border_color": "",
                      "use_img_label": true,
                      "img_label_uri_hans": "",
                      "img_label_uri_hant": "",
                      "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                      "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                      "label_id": 0,
                      "label_goto": null
                    },
                    "avatar_subscript": 0,
                    "nickname_color": ""
                  }
                }
              ],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "parent_reply_member": {
              "mid": "498804301",
              "name": "英雄联盟-小黑鸦"
            },
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277006216752,
            "oid": 115256957471455,
            "type": 1,
            "mid": 498804301,
            "root": 275529486497,
            "parent": 275529486497,
            "dialog": 277006216752,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758700640,
            "mid_str": "498804301",
            "oid_str": "115256957471455",
            "rpid_str": "277006216752",
            "root_str": "275529486497",
            "parent_str": "275529486497",
            "dialog_str": "277006216752",
            "like": 5,
            "action": 0,
            "member": {
              "mid": "498804301",
              "uname": "英雄联盟-小黑鸦",
              "sex": "保密",
              "sign": "暗爪乌鸦创始人",
              "avatar": "https://i1.hdslb.com/bfs/face/80aebd14e08b45bf32ed84954ea7f6b1637e637f.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 59,
                "name": "大收藏家",
                "image": "https://i1.hdslb.com/bfs/face/d12b5db77341e3285f25cc0db82f73e5681a0190.png",
                "image_small": "https://i2.hdslb.com/bfs/face/6bd23ec2d295a5a3e3a8cdde107f62605fd4f9b7.png",
                "level": "普通勋章",
                "condition": "同时拥有粉丝勋章>=25个"
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1626451200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/80aebd14e08b45bf32ed84954ea7f6b1637e637f.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "498804301"
              }
            },
            "content": {
              "message": "你用谷歌商店下载软件的话完全够用，只是国内特供版系统感觉低了。",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共5条回复",
          "sub_reply_title_text": "相关回复共5条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276984199504,
        "oid": 115256957471455,
        "type": 1,
        "mid": 472780214,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 17,
        "rcount": 17,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758683944,
        "mid_str": "472780214",
        "oid_str": "115256957471455",
        "rpid_str": "276984199504",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 41,
        "action": 0,
        "member": {
          "mid": "472780214",
          "uname": "472780214",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i2.hdslb.com/bfs/face/7731fbe4f339cfbc97c25f02b5dc563da30f0e0a.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/7731fbe4f339cfbc97c25f02b5dc563da30f0e0a.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "472780214"
          }
        },
        "content": {
          "message": "7.2寸、潜望镜、触控笔，感觉全方向超越我的moto g75。蹲一个屏幕测评",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 276984140144,
            "oid": 115256957471455,
            "type": 1,
            "mid": 472780214,
            "root": 276984199504,
            "parent": 276984199504,
            "dialog": 276984140144,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758683994,
            "mid_str": "472780214",
            "oid_str": "115256957471455",
            "rpid_str": "276984140144",
            "root_str": "276984199504",
            "parent_str": "276984199504",
            "dialog_str": "276984140144",
            "like": 1,
            "action": 0,
            "member": {
              "mid": "472780214",
              "uname": "472780214",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i2.hdslb.com/bfs/face/7731fbe4f339cfbc97c25f02b5dc563da30f0e0a.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": {
                "pendant": null,
                "cardbg": null,
                "cardbg_with_focus": null
              },
              "user_sailing_v2": {},
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/face/7731fbe4f339cfbc97c25f02b5dc563da30f0e0a.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "472780214"
              }
            },
            "content": {
              "message": "还有圆偏，屏幕应该不会太差吧",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 276985685792,
            "oid": 115256957471455,
            "type": 1,
            "mid": 166623302,
            "root": 276984199504,
            "parent": 276984199504,
            "dialog": 276985685792,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758685102,
            "mid_str": "166623302",
            "oid_str": "115256957471455",
            "rpid_str": "276985685792",
            "root_str": "276984199504",
            "parent_str": "276984199504",
            "dialog_str": "276985685792",
            "like": 3,
            "action": 0,
            "member": {
              "mid": "166623302",
              "uname": "黄大火",
              "sex": "保密",
              "sign": "",
              "avatar": "http://i2.hdslb.com/bfs/face/8ded91ffeec29b1d2f25b06bcea6f16f8ccc5ee0.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "http://i2.hdslb.com/bfs/face/8ded91ffeec29b1d2f25b06bcea6f16f8ccc5ee0.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "166623302"
              }
            },
            "content": {
              "message": "屏幕是最不需要担心的[呲牙]，我想看看系统",
              "members": [],
              "emote": {
                "[呲牙]": {
                  "id": 1902,
                  "package_id": 1,
                  "state": 0,
                  "type": 1,
                  "attr": 0,
                  "text": "[呲牙]",
                  "url": "https://i0.hdslb.com/bfs/emote/b5a5898491944a4268360f2e7a84623149672eb6.png",
                  "meta": {
                    "size": 1,
                    "suggest": [
                      ""
                    ]
                  },
                  "mtime": 1668688325,
                  "jump_title": "呲牙"
                }
              },
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共17条回复",
          "sub_reply_title_text": "相关回复共17条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277016350960,
        "oid": 115256957471455,
        "type": 1,
        "mid": 24629814,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 0,
        "rcount": 0,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758708131,
        "mid_str": "24629814",
        "oid_str": "115256957471455",
        "rpid_str": "277016350960",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 3,
        "action": 0,
        "member": {
          "mid": "24629814",
          "uname": "七滴雨1206",
          "sex": "男",
          "sign": "讨厌形式主义",
          "avatar": "https://i0.hdslb.com/bfs/face/2a71bb9e27ae8b13288935ca4b57d6f0b8a29ad4.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 71,
            "name": "资深委员",
            "image": "https://i1.hdslb.com/bfs/face/5beecb936bd7422a5ac11c9c5c8df56f334b2a65.png",
            "image_small": "https://i0.hdslb.com/bfs/face/9f8e0d5cd0201cf7177199d9365be562be1deb05.png",
            "level": "高级勋章",
            "condition": "风纪委员连任期数 >= 6"
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1602432000000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/2a71bb9e27ae8b13288935ca4b57d6f0b8a29ad4.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "24629814"
          }
        },
        "content": {
          "message": "7.2寸也太大了，拿不住",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": null,
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277094689040,
        "oid": 115256957471455,
        "type": 1,
        "mid": 394866731,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 5,
        "rcount": 5,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758780296,
        "mid_str": "394866731",
        "oid_str": "115256957471455",
        "rpid_str": "277094689040",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 3,
        "action": 0,
        "member": {
          "mid": "394866731",
          "uname": "83195845767_bili",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i2.hdslb.com/bfs/face/a9ea623935802ee2ac49c51a73ed538f2eb64b34.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i2.hdslb.com/bfs/face/a9ea623935802ee2ac49c51a73ed538f2eb64b34.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "394866731"
          }
        },
        "content": {
          "message": "台灣只有512g版本，開價15880新台幣，約3700rmb，供大家參考。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275668674289,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 277094689040,
            "parent": 277094689040,
            "dialog": 275668674289,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758806051,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668674289",
            "root_str": "277094689040",
            "parent_str": "277094689040",
            "dialog_str": "275668674289",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "🙏🏻",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 275674661617,
            "oid": 115256957471455,
            "type": 1,
            "mid": 389334670,
            "root": 277094689040,
            "parent": 277094689040,
            "dialog": 275674661617,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758809736,
            "mid_str": "389334670",
            "oid_str": "115256957471455",
            "rpid_str": "275674661617",
            "root_str": "277094689040",
            "parent_str": "277094689040",
            "dialog_str": "275674661617",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "389334670",
              "uname": "老狗还有几颗牙1",
              "sex": "保密",
              "sign": "o",
              "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "389334670"
              }
            },
            "content": {
              "message": "台湾已经在售了？还是刚刚发布配置",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "12小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共5条回复",
          "sub_reply_title_text": "相关回复共5条",
          "time_desc": "20小时前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276983871808,
        "oid": 115256957471455,
        "type": 1,
        "mid": 180512644,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 1,
        "rcount": 1,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758683689,
        "mid_str": "180512644",
        "oid_str": "115256957471455",
        "rpid_str": "276983871808",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 4,
        "action": 0,
        "member": {
          "mid": "180512644",
          "uname": "岩少物理",
          "sex": "保密",
          "sign": "知识领域优质UP主",
          "avatar": "https://i1.hdslb.com/bfs/face/e1e66cfbdac60da44367b920dc7986d6f5675685.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 3,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i1.hdslb.com/bfs/face/e1e66cfbdac60da44367b920dc7986d6f5675685.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "180512644"
          }
        },
        "content": {
          "message": "y300t 才 1400",
          "members": [],
          "jump_url": {
            "y300t": {
              "title": "y300t",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=y300t&seid=8472502157008465741&from_avid=115256957471455&from_comid=276983871808",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=y300t&seid=8472502157008465741&from_avid=115256957471455&from_comid=276983871808",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275669005249,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 276983871808,
            "parent": 276983871808,
            "dialog": 275669005249,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758806251,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275669005249",
            "root_str": "276983871808",
            "parent_str": "276983871808",
            "dialog_str": "275669005249",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "😂",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共1条回复",
          "sub_reply_title_text": "相关回复共1条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276983637424,
        "oid": 115256957471455,
        "type": 1,
        "mid": 47158121,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 14,
        "rcount": 14,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758683508,
        "mid_str": "47158121",
        "oid_str": "115256957471455",
        "rpid_str": "276983637424",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 27,
        "action": 0,
        "member": {
          "mid": "47158121",
          "uname": "报应啊活该",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 1,
            "vipDueDate": 1655827200000,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "47158121"
          }
        },
        "content": {
          "message": "已经在亚马逊下单了要10月22号才能送到[笑哭]",
          "members": [],
          "emote": {
            "[笑哭]": {
              "id": 509,
              "package_id": 1,
              "state": 0,
              "type": 1,
              "attr": 0,
              "text": "[笑哭]",
              "url": "https://i0.hdslb.com/bfs/emote/c3043ba94babf824dea03ce500d0e73763bf4f40.png",
              "meta": {
                "size": 1,
                "suggest": [
                  ""
                ]
              },
              "mtime": 1668688325,
              "jump_title": "笑哭"
            }
          },
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275532129985,
            "oid": 115256957471455,
            "type": 1,
            "mid": 350358354,
            "root": 276983637424,
            "parent": 276983637424,
            "dialog": 275532129985,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758685028,
            "mid_str": "350358354",
            "oid_str": "115256957471455",
            "rpid_str": "275532129985",
            "root_str": "276983637424",
            "parent_str": "276983637424",
            "dialog_str": "275532129985",
            "like": 1,
            "action": 0,
            "member": {
              "mid": "350358354",
              "uname": "妇科圣手隔壁老王",
              "sex": "男",
              "sign": "",
              "avatar": "http://i0.hdslb.com/bfs/face/9e0e2f81623dbeb9de4697ccfd7fb005005e9b83.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 1758,
                "name": "至尊戒",
                "image": "https://i0.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                "expire": 0,
                "image_enhance": "https://i0.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                "image_enhance_frame": "",
                "n_pid": 1758
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 2,
                "vipDueDate": 1778169600000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 1,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
                  "text": "年度大会员",
                  "label_theme": "annual_vip",
                  "text_color": "#FFFFFF",
                  "bg_style": 1,
                  "bg_color": "#FB7299",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/e74c74edc802bc4badba15f03e69d7cff75f2679.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png",
                  "label_id": 47,
                  "label_goto": {
                    "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                    "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
                  }
                },
                "avatar_subscript": 1,
                "nickname_color": "#FB7299"
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 0.787,
                          "height": 0.787
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 0.787,
                              "height": 0.787
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "http://i0.hdslb.com/bfs/face/9e0e2f81623dbeb9de4697ccfd7fb005005e9b83.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1.375,
                          "height": 1.375
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "PENDENT_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 0.9768333333333333,
                          "axis_y": 0.9934999999999999
                        },
                        "size_spec": {
                          "width": 0.39999999999999997,
                          "height": 0.39999999999999997
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 5,
                        "res_native_draw": {
                          "draw_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "is_dark_mode_aware": true,
                                "day": {
                                  "argb": "#FFFFFFFF"
                                },
                                "night": {
                                  "argb": "#FF17181A"
                                }
                              }
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0101666666666667,
                          "axis_y": 1.0268333333333333
                        },
                        "size_spec": {
                          "width": 0.3333333333333333,
                          "height": 0.3333333333333333
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 1,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/bangumi/kt/aba51485c0d02940c89aeefcf6680510d9858472.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "350358354"
              }
            },
            "content": {
              "message": "没事体验高端原生系统",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 276986435872,
            "oid": 115256957471455,
            "type": 1,
            "mid": 47158121,
            "root": 276983637424,
            "parent": 275532129985,
            "dialog": 275532129985,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758685707,
            "mid_str": "47158121",
            "oid_str": "115256957471455",
            "rpid_str": "276986435872",
            "root_str": "276983637424",
            "parent_str": "275532129985",
            "dialog_str": "275532129985",
            "like": 5,
            "action": 0,
            "member": {
              "mid": "47158121",
              "uname": "报应啊活该",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1655827200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": {
                "pendant": null,
                "cardbg": null,
                "cardbg_with_focus": null
              },
              "user_sailing_v2": {},
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "47158121"
              }
            },
            "content": {
              "message": "回复 @妇科圣手隔壁老王 :主要眼睛不行了，以前用LCD的屁事没有，后来想体验高端8E至尊换了红魔半年不到近视加闪光，现在Z10X加se3凑合用着",
              "at_name_to_mid": {
                "妇科圣手隔壁老王": 350358354
              },
              "at_name_to_mid_str": {
                "妇科圣手隔壁老王": "350358354"
              },
              "members": [
                {
                  "mid": "350358354",
                  "uname": "妇科圣手隔壁老王",
                  "sex": "男",
                  "sign": "",
                  "avatar": "http://i0.hdslb.com/bfs/face/9e0e2f81623dbeb9de4697ccfd7fb005005e9b83.jpg",
                  "rank": "10000",
                  "face_nft_new": 0,
                  "is_senior_member": 0,
                  "senior": {},
                  "level_info": {
                    "current_level": 5,
                    "current_min": 0,
                    "current_exp": 0,
                    "next_exp": 0
                  },
                  "pendant": {
                    "pid": 1758,
                    "name": "至尊戒",
                    "image": "https://i0.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                    "expire": 0,
                    "image_enhance": "https://i0.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                    "image_enhance_frame": "",
                    "n_pid": 1758
                  },
                  "nameplate": {
                    "nid": 0,
                    "name": "",
                    "image": "",
                    "image_small": "",
                    "level": "",
                    "condition": ""
                  },
                  "official_verify": {
                    "type": -1,
                    "desc": ""
                  },
                  "vip": {
                    "vipType": 2,
                    "vipDueDate": 1778169600000,
                    "dueRemark": "",
                    "accessStatus": 0,
                    "vipStatus": 1,
                    "vipStatusWarn": "",
                    "themeType": 0,
                    "label": {
                      "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
                      "text": "年度大会员",
                      "label_theme": "annual_vip",
                      "text_color": "#FFFFFF",
                      "bg_style": 1,
                      "bg_color": "#FB7299",
                      "border_color": "",
                      "use_img_label": true,
                      "img_label_uri_hans": "",
                      "img_label_uri_hant": "",
                      "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/e74c74edc802bc4badba15f03e69d7cff75f2679.png",
                      "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png",
                      "label_id": 47,
                      "label_goto": {
                        "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                        "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
                      }
                    },
                    "avatar_subscript": 1,
                    "nickname_color": "#FB7299"
                  }
                }
              ],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "parent_reply_member": {
              "mid": "350358354",
              "name": "妇科圣手隔壁老王"
            },
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共14条回复",
          "sub_reply_title_text": "相关回复共14条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 276983687952,
        "oid": 115256957471455,
        "type": 1,
        "mid": 2006685,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 4,
        "rcount": 4,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758683498,
        "mid_str": "2006685",
        "oid_str": "115256957471455",
        "rpid_str": "276983687952",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 4,
        "action": 0,
        "member": {
          "mid": "2006685",
          "uname": "力量与农药",
          "sex": "保密",
          "sign": "",
          "avatar": "http://i0.hdslb.com/bfs/face/1515178a4b5fc4816113314693fee616554ee866.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 6,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "http://i0.hdslb.com/bfs/face/1515178a4b5fc4816113314693fee616554ee866.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "2006685"
          }
        },
        "content": {
          "message": "p10的TCL系统太减分了，不如moto的系统，都是小众moto就很精简，TCL一堆广告。。。",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275551198801,
            "oid": 115256957471455,
            "type": 1,
            "mid": 37802873,
            "root": 276983687952,
            "parent": 276983687952,
            "dialog": 275551198801,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758700382,
            "mid_str": "37802873",
            "oid_str": "115256957471455",
            "rpid_str": "275551198801",
            "root_str": "276983687952",
            "parent_str": "276983687952",
            "dialog_str": "275551198801",
            "like": 2,
            "action": 0,
            "member": {
              "mid": "37802873",
              "uname": "Bbili平常心",
              "sex": "男",
              "sign": "资质低劣又如何？强敌环伺又如何？九死一生又如何？我是不会放弃的！曾经是，未来是，现在也是！",
              "avatar": "https://i2.hdslb.com/bfs/baselabs/ba6cb9bbcec7ff14fc680d8d558c905b1d6c09a1.jpg",
              "rank": "10000",
              "face_nft_new": 1,
              "is_senior_member": 1,
              "senior": {
                "status": 2
              },
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 1758,
                "name": "至尊戒",
                "image": "https://i2.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                "expire": 0,
                "image_enhance": "https://i2.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                "image_enhance_frame": "",
                "n_pid": 1758
              },
              "nameplate": {
                "nid": 58,
                "name": "收集达人",
                "image": "https://i0.hdslb.com/bfs/face/3f5539e1486303422ffc8595862ccb6606e0b745.png",
                "image_small": "https://i0.hdslb.com/bfs/face/cf85e7908095d256e595ec9759f4e7795f23bc22.png",
                "level": "普通勋章",
                "condition": "同时拥有粉丝勋章>=15个"
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 2,
                "vipDueDate": 1861027200000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 1,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "http://i0.hdslb.com/bfs/vip/label_annual.png",
                  "text": "年度大会员",
                  "label_theme": "annual_vip",
                  "text_color": "#FFFFFF",
                  "bg_style": 1,
                  "bg_color": "#FB7299",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/bangumi/kt/e74c74edc802bc4badba15f03e69d7cff75f2679.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png",
                  "label_id": 47,
                  "label_goto": {
                    "mobile": "https://big.bilibili.com/mobile/index?appId=125&appSubId=minebutton&banner_id=34281&popup_id=34279",
                    "pc_web": "https://account.bilibili.com/big?from_spmid=vipicon"
                  }
                },
                "avatar_subscript": 1,
                "nickname_color": "#FB7299"
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": {
                "region": {
                  "type": 1,
                  "icon": "https://i0.hdslb.com/bfs/activity-plat/static/20220506/334553dd7c506a92b88eaf4d59ac8b4d/j8AeXAkEul.gif",
                  "show_status": 1
                }
              },
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 0.94,
                          "height": 0.94
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 0.94,
                              "height": 0.94
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/baselabs/ba6cb9bbcec7ff14fc680d8d558c905b1d6c09a1.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1.65,
                          "height": 1.65
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "PENDENT_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/garb/item/025d07fa04d38236bc2258be2faf2867e2c48fe1.png",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.0533333333333335,
                          "axis_y": 1.07
                        },
                        "size_spec": {
                          "width": 0.39999999999999997,
                          "height": 0.39999999999999997
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 5,
                        "res_native_draw": {
                          "draw_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "is_dark_mode_aware": true,
                                "day": {
                                  "argb": "#FFFFFFFF"
                                },
                                "night": {
                                  "argb": "#FF17181A"
                                }
                              }
                            }
                          }
                        }
                      }
                    },
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 1,
                          "axis_x": 1.086666666666667,
                          "axis_y": 1.1033333333333335
                        },
                        "size_spec": {
                          "width": 0.3333333333333333,
                          "height": 0.3333333333333333
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "ICON_LAYER": {}
                        }
                      },
                      "resource": {
                        "res_type": 4,
                        "res_animation": {
                          "webp_src": {
                            "src_type": 1,
                            "placeholder": 5,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/activity-plat/static/20220506/334553dd7c506a92b88eaf4d59ac8b4d/j8AeXAkEul.gif",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "37802873"
              }
            },
            "content": {
              "message": "moto为啥不继续出lcd啊，我真服了",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 275668833473,
            "oid": 115256957471455,
            "type": 1,
            "mid": 2000663065,
            "root": 276983687952,
            "parent": 276983687952,
            "dialog": 275668833473,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 268435456,
            "ctime": 1758806185,
            "mid_str": "2000663065",
            "oid_str": "115256957471455",
            "rpid_str": "275668833473",
            "root_str": "276983687952",
            "parent_str": "276983687952",
            "dialog_str": "275668833473",
            "like": 0,
            "action": 0,
            "member": {
              "mid": "2000663065",
              "uname": "独自_欣赏",
              "sex": "男",
              "sign": "孤独为伴，点滴积累，平凡发光",
              "avatar": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 4,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1712246400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i1.hdslb.com/bfs/face/5487ee0db725d757f2109d27b80bc67a0e86aad6.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "2000663065"
              }
            },
            "content": {
              "message": "🙏🏻",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "13小时前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共4条回复",
          "sub_reply_title_text": "相关回复共4条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 277061572416,
        "oid": 115256957471455,
        "type": 1,
        "mid": 871314,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 0,
        "rcount": 0,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758743772,
        "mid_str": "871314",
        "oid_str": "115256957471455",
        "rpid_str": "277061572416",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 1,
        "action": 0,
        "member": {
          "mid": "871314",
          "uname": "bili_871314",
          "sex": "保密",
          "sign": "",
          "avatar": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 4,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "http://i0.hdslb.com/bfs/face/member/noface.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "871314"
          }
        },
        "content": {
          "message": "神经病啊一个手机7寸多，咋不叫自己pad",
          "members": [],
          "jump_url": {},
          "max_line": 6
        },
        "replies": null,
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      },
      {
        "rpid": 275567659041,
        "oid": 115256957471455,
        "type": 1,
        "mid": 431679582,
        "root": 0,
        "parent": 0,
        "dialog": 0,
        "count": 19,
        "rcount": 16,
        "state": 0,
        "fansgrade": 0,
        "attr": 0,
        "ctime": 1758712564,
        "mid_str": "431679582",
        "oid_str": "115256957471455",
        "rpid_str": "275567659041",
        "root_str": "0",
        "parent_str": "0",
        "dialog_str": "0",
        "like": 12,
        "action": 0,
        "member": {
          "mid": "431679582",
          "uname": "啄木鸟km",
          "sex": "保密",
          "sign": "",
          "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
          "rank": "10000",
          "face_nft_new": 0,
          "is_senior_member": 0,
          "senior": {},
          "level_info": {
            "current_level": 5,
            "current_min": 0,
            "current_exp": 0,
            "next_exp": 0
          },
          "pendant": {
            "pid": 0,
            "name": "",
            "image": "",
            "expire": 0,
            "image_enhance": "",
            "image_enhance_frame": "",
            "n_pid": 0
          },
          "nameplate": {
            "nid": 0,
            "name": "",
            "image": "",
            "image_small": "",
            "level": "",
            "condition": ""
          },
          "official_verify": {
            "type": -1,
            "desc": ""
          },
          "vip": {
            "vipType": 0,
            "vipDueDate": 0,
            "dueRemark": "",
            "accessStatus": 0,
            "vipStatus": 0,
            "vipStatusWarn": "",
            "themeType": 0,
            "label": {
              "path": "",
              "text": "",
              "label_theme": "",
              "text_color": "",
              "bg_style": 0,
              "bg_color": "",
              "border_color": "",
              "use_img_label": true,
              "img_label_uri_hans": "",
              "img_label_uri_hant": "",
              "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
              "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
              "label_id": 0,
              "label_goto": null
            },
            "avatar_subscript": 0,
            "nickname_color": ""
          },
          "fans_detail": null,
          "user_sailing": {
            "pendant": null,
            "cardbg": null,
            "cardbg_with_focus": null
          },
          "user_sailing_v2": {},
          "is_contractor": false,
          "contract_desc": "",
          "nft_interaction": null,
          "avatar_item": {
            "container_size": {
              "width": 1.8,
              "height": 1.8
            },
            "fallback_layers": {
              "layers": [
                {
                  "visible": true,
                  "general_spec": {
                    "pos_spec": {
                      "coordinate_pos": 2,
                      "axis_x": 0.9,
                      "axis_y": 0.9
                    },
                    "size_spec": {
                      "width": 1,
                      "height": 1
                    },
                    "render_spec": {
                      "opacity": 1
                    }
                  },
                  "layer_config": {
                    "tags": {
                      "AVATAR_LAYER": {}
                    },
                    "is_critical": true,
                    "layer_mask": {
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "mask_src": {
                        "src_type": 3,
                        "draw": {
                          "draw_type": 1,
                          "fill_mode": 1,
                          "color_config": {
                            "day": {
                              "argb": "#FF000000"
                            }
                          }
                        }
                      }
                    }
                  },
                  "resource": {
                    "res_type": 3,
                    "res_image": {
                      "image_src": {
                        "src_type": 1,
                        "placeholder": 6,
                        "remote": {
                          "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                          "bfs_style": "widget-layer-avatar"
                        }
                      }
                    }
                  }
                }
              ],
              "is_critical_group": true
            },
            "mid": "431679582"
          }
        },
        "content": {
          "message": "看来手机的iQOO neo5活力版换还得再换一块电池继续继续[笑哭]",
          "members": [],
          "emote": {
            "[笑哭]": {
              "id": 509,
              "package_id": 1,
              "state": 0,
              "type": 1,
              "attr": 0,
              "text": "[笑哭]",
              "url": "https://i0.hdslb.com/bfs/emote/c3043ba94babf824dea03ce500d0e73763bf4f40.png",
              "meta": {
                "size": 1,
                "suggest": [
                  ""
                ]
              },
              "mtime": 1668688325,
              "jump_title": "笑哭"
            }
          },
          "jump_url": {
            "iQOO neo5活力": {
              "title": "iQOO neo5活力",
              "state": 0,
              "prefix_icon": "https://i0.hdslb.com/bfs/reply/9f3ad0659e84c96a711b88dd33f4bc2e945045e0.png",
              "app_url_schema": "bilibili://search?from=appcommentline_search&search_from_source=appcommentline_search&direct_return=true&keyword=iQOO%20neo5%E6%B4%BB%E5%8A%9B&seid=8472502157008465741&from_avid=115256957471455&from_comid=275567659041",
              "app_name": "",
              "app_package_name": "",
              "click_report": "",
              "is_half_screen": false,
              "exposure_report": "",
              "extra": {
                "goods_show_type": 0,
                "is_word_search": true,
                "goods_cm_control": 0,
                "goods_click_report": "",
                "goods_exposure_report": ""
              },
              "underline": false,
              "match_once": true,
              "pc_url": "//search.bilibili.com/all?from_source=webcommentline_search&keyword=iQOO%20neo5%E6%B4%BB%E5%8A%9B&seid=8472502157008465741&from_avid=115256957471455&from_comid=275567659041",
              "icon_position": 1
            }
          },
          "max_line": 6
        },
        "replies": [
          {
            "rpid": 275568036769,
            "oid": 115256957471455,
            "type": 1,
            "mid": 65861483,
            "root": 275567659041,
            "parent": 275567659041,
            "dialog": 275568036769,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758712775,
            "mid_str": "65861483",
            "oid_str": "115256957471455",
            "rpid_str": "275568036769",
            "root_str": "275567659041",
            "parent_str": "275567659041",
            "dialog_str": "275568036769",
            "like": 1,
            "action": 0,
            "member": {
              "mid": "65861483",
              "uname": "UMISS2599",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i2.hdslb.com/bfs/face/4aaf1759fb179a92c9546200d1e7da7e9963f4cc.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 6,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 1,
                "vipDueDate": 1725638400000,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i2.hdslb.com/bfs/face/4aaf1759fb179a92c9546200d1e7da7e9963f4cc.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "65861483"
              }
            },
            "content": {
              "message": "我和你一样，看来我的活力版同样得换块电池继续服役了[笑哭]",
              "members": [],
              "emote": {
                "[笑哭]": {
                  "id": 509,
                  "package_id": 1,
                  "state": 0,
                  "type": 1,
                  "attr": 0,
                  "text": "[笑哭]",
                  "url": "https://i0.hdslb.com/bfs/emote/c3043ba94babf824dea03ce500d0e73763bf4f40.png",
                  "meta": {
                    "size": 1,
                    "suggest": [
                      ""
                    ]
                  },
                  "mtime": 1668688325,
                  "jump_title": "笑哭"
                }
              },
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          },
          {
            "rpid": 277056508016,
            "oid": 115256957471455,
            "type": 1,
            "mid": 1726144526,
            "root": 275567659041,
            "parent": 275567659041,
            "dialog": 277056508016,
            "count": 0,
            "rcount": 0,
            "state": 0,
            "fansgrade": 0,
            "attr": 0,
            "ctime": 1758734259,
            "mid_str": "1726144526",
            "oid_str": "115256957471455",
            "rpid_str": "277056508016",
            "root_str": "275567659041",
            "parent_str": "275567659041",
            "dialog_str": "277056508016",
            "like": 1,
            "action": 0,
            "member": {
              "mid": "1726144526",
              "uname": "风陵渡口二点零",
              "sex": "保密",
              "sign": "",
              "avatar": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
              "rank": "10000",
              "face_nft_new": 0,
              "is_senior_member": 0,
              "senior": {},
              "level_info": {
                "current_level": 5,
                "current_min": 0,
                "current_exp": 0,
                "next_exp": 0
              },
              "pendant": {
                "pid": 0,
                "name": "",
                "image": "",
                "expire": 0,
                "image_enhance": "",
                "image_enhance_frame": "",
                "n_pid": 0
              },
              "nameplate": {
                "nid": 0,
                "name": "",
                "image": "",
                "image_small": "",
                "level": "",
                "condition": ""
              },
              "official_verify": {
                "type": -1,
                "desc": ""
              },
              "vip": {
                "vipType": 0,
                "vipDueDate": 0,
                "dueRemark": "",
                "accessStatus": 0,
                "vipStatus": 0,
                "vipStatusWarn": "",
                "themeType": 0,
                "label": {
                  "path": "",
                  "text": "",
                  "label_theme": "",
                  "text_color": "",
                  "bg_style": 0,
                  "bg_color": "",
                  "border_color": "",
                  "use_img_label": true,
                  "img_label_uri_hans": "",
                  "img_label_uri_hant": "",
                  "img_label_uri_hans_static": "https://i0.hdslb.com/bfs/vip/d7b702ef65a976b20ed854cbd04cb9e27341bb79.png",
                  "img_label_uri_hant_static": "https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/KJunwh19T5.png",
                  "label_id": 0,
                  "label_goto": null
                },
                "avatar_subscript": 0,
                "nickname_color": ""
              },
              "fans_detail": null,
              "user_sailing": null,
              "is_contractor": false,
              "contract_desc": "",
              "nft_interaction": null,
              "avatar_item": {
                "container_size": {
                  "width": 1.8,
                  "height": 1.8
                },
                "fallback_layers": {
                  "layers": [
                    {
                      "visible": true,
                      "general_spec": {
                        "pos_spec": {
                          "coordinate_pos": 2,
                          "axis_x": 0.9,
                          "axis_y": 0.9
                        },
                        "size_spec": {
                          "width": 1,
                          "height": 1
                        },
                        "render_spec": {
                          "opacity": 1
                        }
                      },
                      "layer_config": {
                        "tags": {
                          "AVATAR_LAYER": {}
                        },
                        "is_critical": true,
                        "layer_mask": {
                          "general_spec": {
                            "pos_spec": {
                              "coordinate_pos": 2,
                              "axis_x": 0.9,
                              "axis_y": 0.9
                            },
                            "size_spec": {
                              "width": 1,
                              "height": 1
                            },
                            "render_spec": {
                              "opacity": 1
                            }
                          },
                          "mask_src": {
                            "src_type": 3,
                            "draw": {
                              "draw_type": 1,
                              "fill_mode": 1,
                              "color_config": {
                                "day": {
                                  "argb": "#FF000000"
                                }
                              }
                            }
                          }
                        }
                      },
                      "resource": {
                        "res_type": 3,
                        "res_image": {
                          "image_src": {
                            "src_type": 1,
                            "placeholder": 6,
                            "remote": {
                              "url": "https://i0.hdslb.com/bfs/face/member/noface.jpg",
                              "bfs_style": "widget-layer-avatar"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "is_critical_group": true
                },
                "mid": "1726144526"
              }
            },
            "content": {
              "message": "活力板的屏幕应该不如同时期的 红米note 10pro吧？？而且这个tcl 60 ultra的芯片，应该跟红米n10p的 天玑1100大差不差 ？红米n10p那个屏幕也不差，还可以，只是会存在抽奖现象。",
              "members": [],
              "jump_url": {},
              "max_line": 2
            },
            "replies": null,
            "assist": 0,
            "up_action": {
              "like": false,
              "reply": false
            },
            "invisible": false,
            "reply_control": {
              "max_line": 2,
              "time_desc": "1天前发布",
              "translation_switch": 1
            },
            "folder": {
              "has_folded": false,
              "is_folded": false,
              "rule": ""
            },
            "dynamic_id_str": "0",
            "note_cvid_str": "0",
            "track_info": ""
          }
        ],
        "assist": 0,
        "up_action": {
          "like": false,
          "reply": false
        },
        "invisible": false,
        "reply_control": {
          "max_line": 6,
          "sub_reply_entry_text": "共16条回复",
          "sub_reply_title_text": "相关回复共16条",
          "time_desc": "1天前发布",
          "translation_switch": 1
        },
        "folder": {
          "has_folded": false,
          "is_folded": false,
          "rule": ""
        },
        "dynamic_id_str": "0",
        "note_cvid_str": "0",
        "track_info": ""
      }
    ],
    "top": {
      "admin": null,
      "upper": null,
      "vote": null
    },
    "top_replies": [],
    "effects": {
      "preloading": ""
    },
    "assist": 0,
    "blacklist": 0,
    "vote": 0,
    "config": {
      "showtopic": 1,
      "show_up_flag": true,
      "read_only": false
    },
    "upper": {
      "mid": 1594012108
    },
    "control": {
      "input_disable": false,
      "root_input_text": "下面我简单喵两句",
      "child_input_text": "下面我简单喵两句",
      "giveup_input_text": "不发没关系，请继续友善哦~",
      "screenshot_icon_state": 1,
      "upload_picture_icon_state": 1,
      "answer_guide_text": "需要升级成为lv2会员后才可以评论，先去答题转正吧！",
      "answer_guide_icon_url": "http://i0.hdslb.com/bfs/emote/96940d16602cacbbac796245b7bb99fa9b5c970c.png",
      "answer_guide_ios_url": "https://www.bilibili.com/h5/newbie/entry?navhide=1&re_src=12",
      "answer_guide_android_url": "https://www.bilibili.com/h5/newbie/entry?navhide=1&re_src=6",
      "bg_text": "",
      "empty_page": null,
      "show_type": 1,
      "show_text": "",
      "web_selection": false,
      "disable_jump_emote": false,
      "enable_charged": false,
      "enable_cm_biz_helper": false,
      "preload_resources": null
    },
    "note": 1,
    "callbacks": null
  }
})
