"""DATAVOXEL Model. Author: Juste Elysée MALANDILA"""

class Model:
    """Base model for database tables."""
    pass
