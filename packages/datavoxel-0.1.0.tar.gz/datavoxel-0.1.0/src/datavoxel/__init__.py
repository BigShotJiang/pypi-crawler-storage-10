"""
DATAVOXEL - Type-Safe Modern ORM
Data in 3D
Created by Juste Elysée MALANDILA
LinkedIn: https://linkedin.com/in/juste-elysee-malandila
"""

__version__ = "0.1.0"
__author__ = "Juste Elysée MALANDILA"
__email__ = "justech4dev@gmail.com"
__linkedin__ = "https://linkedin.com/in/juste-elysee-malandila"

from .model import Model
from .query import Query

__all__ = ["Model", "Query", "__version__"]
