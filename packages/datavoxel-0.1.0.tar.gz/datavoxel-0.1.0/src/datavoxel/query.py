"""DATAVOXEL Query builder. Author: Juste Elysée MALANDILA"""

class Query:
    """Type-safe query builder."""
    pass
