"""Tests for DATAVOXEL. Author: Juste Elysée MALANDILA"""
import pytest
from datavoxel import Model, Query

def test_model_import():
    """Test can import Model."""
    assert Model is not None

def test_query_import():
    """Test can import Query."""
    assert Query is not None
