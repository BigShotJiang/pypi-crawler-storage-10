import requests
from .. config import BASE_URL
from .. schema.profile_schema import AuthShema

class Profile:
    def __init__(self, sessiond_id=""):
        if sessiond_id != "":
            self.session_id = sessiond_id
        else:
            self.session_id = None

    @property
    def auth_cookies(self):
        return {"session_id": self.session_id}

    def regist(self, login, password):
        response = requests.post(f"{BASE_URL}/authorizate/regist", data={"login": login, "password": password})
        return response.json()
    
    def login_user(self, auth_data: AuthShema):
        response = requests.post(f"{BASE_URL}/authorizate/login", data={"login": auth_data.login, "password": auth_data.password})

        if response.json()["status"] == "success":
            self.session_id = response.json()["session_id"]
            return True, ""
        return False, response.json()["message"]
            

    def logout_user(self):
        response = requests.post(f"{BASE_URL}/authorizate/logout", cookies=self.auth_cookies)

    def get_version(self):
        try:
            response = requests.get(f"{BASE_URL}/authorizate/check_version")
            return True, response.json()["version"]

        except:
            return False, ""

    def get_tg_info(self):
        response = requests.get(f"{BASE_URL}/authorizate/bot_data", cookies=self.auth_cookies)
        return response.json()["data"]
    
    def is_auth(self):
        response = requests.get(f"{BASE_URL}/authorizate/check_auth", cookies=self.auth_cookies)
        if response.json()["status"] == "success":
            return True
        return False
