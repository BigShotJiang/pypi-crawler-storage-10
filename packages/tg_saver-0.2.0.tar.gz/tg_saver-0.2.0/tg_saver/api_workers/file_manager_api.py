import requests
from .auth import Profile
from .. config import BASE_URL



def get_unclose_upload_sessions(profile: Profile):
    response = requests.get(f"{BASE_URL}/files_handler/unclose_upload_session", cookies=profile.auth_cookies)
    

    return response.json()["unclose_upload_sessions_id"]

def get_last_batch_id(profile: Profile, upload_session_id):
    response = requests.get(f"{BASE_URL}/files_handler/{upload_session_id}/last_batch_id", cookies=profile.auth_cookies)

    return response.json()["last_batch_id"]

def delete_file_api(profile: Profile, global_file_id):
    response = requests.post(f"{BASE_URL}/files_handler/{global_file_id}/delete", cookies=profile.auth_cookies)

    return response.json()

def get_all_global_files(profile: Profile):
    response = requests.get(f"{BASE_URL}/files_handler/get_all_global_files", cookies=profile.auth_cookies)

    return response.json()["files_data"]

def get_all_batch_files(profile: Profile, global_file_id):
    response = requests.get(f"{BASE_URL}/files_handler/{global_file_id}/batches", cookies=profile.auth_cookies)

    return response.json()

def get_global_file_info(profile: Profile, global_file_id):
    response = requests.get(f"{BASE_URL}/files_handler/{global_file_id}/info", cookies=profile.auth_cookies)

    return response.json()["files_data"]