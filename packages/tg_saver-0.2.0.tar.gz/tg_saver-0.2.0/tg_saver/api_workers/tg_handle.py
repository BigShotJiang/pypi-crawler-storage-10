import requests



class Bot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.curr_proxy_index = 0
        self.session = requests.Session()

    def send_block(self, data, name, proxies):
        if self.curr_proxy_index >= len(proxies) - 1:
            self.curr_proxy_index = 0
        else:
            self.curr_proxy_index += 1

        if proxies is None:
            response = self.session.post(f"https://api.telegram.org/bot{self.token}/sendDocument", data={"chat_id": self.chat_id}, files={"document": (name, data)})

        response = self.session.post(f"https://api.telegram.org/bot{self.token}/sendDocument", proxies=proxies[self.curr_proxy_index].proxy_link, data={"chat_id": self.chat_id}, files={"document": (name, data)})


        res_data =  response.json()
        response.close()
        return res_data
    
    async def get_download_link_async(self, client, file_id):
        url = f"https://api.telegram.org/bot{self.token}/getFile"
        res = await client.get(url, params={"file_id": file_id})
        file_info = res.json()
        if file_info['ok'] == False:
            print(file_info, file_id)
            return "", False

        file_path = file_info["result"]["file_path"]
        download_url = f"https://api.telegram.org/file/bot{self.token}/{file_path}"

        return download_url, True
    
    def get_download_link(self, file_id):
        url = f"https://api.telegram.org/bot{self.token}/getFile"
        res = requests.get(url, params={"file_id": file_id})
        file_info = res.json()
        if file_info['ok'] == False:
            print(file_info, file_id)
            return "", False

        file_path = file_info["result"]["file_path"]
        download_url = f"https://api.telegram.org/file/bot{self.token}/{file_path}"

        return download_url, True
    
