from pydantic import BaseModel


class AuthShema(BaseModel):
    login: str
    password: str