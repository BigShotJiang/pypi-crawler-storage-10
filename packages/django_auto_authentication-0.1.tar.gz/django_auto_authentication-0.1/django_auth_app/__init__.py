default_app_config = 'django_auth_app.apps.DjangoAuthAppConfig'
