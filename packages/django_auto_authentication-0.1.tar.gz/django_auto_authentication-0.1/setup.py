from setuptools import setup, find_packages

setup(
    name="django_auto_authentication",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "django>=4.0",
    ],
    python_requires='>=3.10',
    description="Reusable Django authentication app with login, register, dashboard, and logout",
    author="Jagriti Srivastava",
    classifiers=[
        "Framework :: Django",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
