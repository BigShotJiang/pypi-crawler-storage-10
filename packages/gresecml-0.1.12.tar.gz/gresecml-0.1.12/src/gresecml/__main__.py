import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' # Suppress TensorFlow logging from console
import click
from gresecml.commands.tensorflow_group import tf as tf_group


@click.group()
def main():
    pass
main.add_command(tf_group)