# ModelRed Python SDK — Changelog

## v0.0.0-coming-soon · Placeholder Release

### 🚧 What’s this?

This release intentionally ships **no functional SDK**. It’s a lightweight placeholder while we prepare the next major version.

- The package may **raise on import** or **raise on any attribute access**, depending on your chosen placeholder style.
- No network calls, no resources, no public API surface is guaranteed in this version.

### 🔁 If you need the working SDK today

Pin a previous stable version:

```bash
pip install "modelred"
```
