# Ginkgo Tools

一套实用的 Python 工具库，包含日志、时间处理和多线程相关的工具函数。

## 功能模块

- `tools_log`: 日志处理工具
- `tools_time`: 时间处理工具
- `tools_threading_target`: 多线程任务处理工具

## 安装

```bash
pip install ginkgo-tools
```

## 使用示例

```python
from ginkgo_tools import tools_log, tools_time, tools_threading_target

# 使用日志工具
tools_log.console_log_debug("这是一条调试信息")

# 使用时间工具
current_time = tools_time.create_time_mark()

# 使用多线程工具
# (需要继承 Base_Operation_Threading_Target 类来创建具体的线程任务)
```