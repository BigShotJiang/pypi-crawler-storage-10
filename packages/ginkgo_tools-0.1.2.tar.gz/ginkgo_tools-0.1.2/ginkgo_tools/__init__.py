"""
Ginkgo Tools - 一套实用的 Python 工具库
包含日志、时间处理和多线程相关的工具函数

版本: 0.1.1
作者: Your Name
"""

__version__ = "0.1.1"
__author__ = "Your Name"

# 导出所有模块
from .tools_log import *
from .tools_time import *
from .tools_threading_target import *

# 定义公共接口
__all__ = [
    'tools_log', 
    'tools_time', 
    'tools_threading_target',
    # 日志工具
    'console_log_debug',
    # 时间工具
    'trans_timestr_to_datetime',
    'trans_timestr_to_stddatestr',
    'trans_datetime_to_describe',
    'get_week_dates',
    'get_week_range',
    'get_month_range',
    'get_quarter_range',
    'get_year_range',
    'get_offset_date',
    'create_timestamp_mark',
    'create_time_mark',
    'analyse_filename_time',
    'analyse_fileattr_time',
    # 线程工具
    'Base_Operation_Threading_Target'
]