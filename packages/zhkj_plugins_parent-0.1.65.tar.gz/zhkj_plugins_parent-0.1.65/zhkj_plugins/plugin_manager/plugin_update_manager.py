import time
import threading
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Callable, Tuple, Any
import logging

from .models import PluginConfig, VersionInfo
from .plugin_loader import PluginLoader
from .version_manager import VersionManager
from .download_manager import DownloadManager
from .archive_handler import ArchiveHandler
from .plugin_runtime_manager import PluginRuntimeManager

logger = logging.getLogger("PluginManager.Update")


class PluginUpdateManager:
    def __init__(self, plugin_loader: PluginLoader, version_manager: VersionManager,
                 download_manager: DownloadManager, archive_handler: ArchiveHandler,
                 plugin_install_dir: Path, runtime_manager: PluginRuntimeManager):
        self.plugin_loader = plugin_loader
        self.version_manager = version_manager
        self.download_manager = download_manager
        self.archive_handler = archive_handler
        self.plugin_install_dir = plugin_install_dir
        self.runtime_manager = runtime_manager

    def _start_auto_update_check(self) -> None:
        """启动自动更新检查后台线程"""

        def check_updates_background():
            while True:
                try:
                    # 每6小时检查一次更新
                    time.sleep(6 * 3600)
                    self.check_all_updates(background=True)
                except Exception as e:
                    logger.error(f"后台更新检查失败: {str(e)}")
                    time.sleep(300)  # 出错后等待5分钟再重试

        thread = threading.Thread(target=check_updates_background, daemon=True)
        thread.start()
        logger.info("自动更新检查线程已启动")

    def check_plugin_update(self, plugin_name: str, plugins: List[PluginConfig]) -> Tuple[bool, Optional[VersionInfo]]:
        """检查插件是否有更新"""
        plugin = self._get_plugin_info(plugin_name, plugins)
        if not plugin:
            logger.warning(f"插件不存在: {plugin_name}")
            return False, None

        # 从远程获取版本检查信息
        remote_info = self.version_manager.get_version_check_info(plugin_name)

        if not remote_info:
            logger.info(f"插件 {plugin_name} 未配置版本检查URL")
            return False, None

        try:
            remote_version = remote_info.get('version', '')
            remote_url = remote_info.get('download_url', '')
            release_notes = remote_info.get('release_notes', '')
            release_date = remote_info.get('release_date', '')
            file_size = remote_info.get('file_size', 0)
            md5_hash = remote_info.get('md5_hash', '')

            if not remote_version or not remote_url:
                logger.warning(f"远程版本信息不完整: {plugin_name}")
                return False, None

            # 比较版本
            current_version = plugin.current_version
            version_comparison = self.version_manager._compare_versions(remote_version, current_version)

            if version_comparison > 0:
                # 有新版本
                version_info = VersionInfo(
                    version=remote_version,
                    download_url=remote_url,
                    release_notes=release_notes,
                    release_date=release_date,
                    file_size=file_size,
                    md5_hash=md5_hash
                )
                logger.info(f"发现插件 {plugin_name} 新版本: {current_version} -> {remote_version}")
                return True, version_info
            else:
                logger.info(f"插件 {plugin_name} 已是最新版本: {current_version}")
                return False, None

        except Exception as e:
            logger.error(f"检查插件 {plugin_name} 更新失败: {str(e)}")
            return False, None

    def check_all_updates(self, plugins: List[PluginConfig], background: bool = False) -> Dict[str, VersionInfo]:
        """检查所有插件的更新"""
        updates = {}

        if not background:
            logger.info("开始检查所有插件更新...")

        for plugin in plugins:
            try:
                has_update, version_info = self.check_plugin_update(plugin.name, plugins)
                if has_update and version_info:
                    updates[plugin.name] = version_info
                    if not background:
                        logger.info(
                            f"🔔 插件 {plugin.name} 有新版本: {plugin.current_version} -> {version_info.version}")
            except Exception as e:
                logger.error(f"检查插件 {plugin.name} 更新时出错: {str(e)}")

        # 更新缓存
        self.version_manager.version_cache['last_update_check'] = datetime.now().isoformat()
        self.version_manager.version_cache['available_updates'] = {
            plugin_name: {
                'version': info.version,
                'release_date': info.release_date
            } for plugin_name, info in updates.items()
        }
        self.version_manager.save_version_cache()

        if not background:
            if updates:
                logger.info(f"发现 {len(updates)} 个插件有更新")
            else:
                logger.info("所有插件都是最新版本")

        return updates

    def update_plugin(
            self,
            plugin_name: str,
            version_info: VersionInfo,
            progress_callback: Optional[Callable[[int, int, float], None]] = None,
            plugins: List[PluginConfig] = None
    ) -> bool:
        """更新指定插件到新版本"""
        plugin = self._get_plugin_info(plugin_name, plugins)
        if not plugin:
            logger.error(f"插件不存在: {plugin_name}")
            return False

        logger.info(f"开始更新插件 {plugin_name}: {plugin.current_version} -> {version_info.version}")

        # 停止运行中的插件
        if self.runtime_manager.is_plugin_running(plugin_name, plugins):
            logger.info(f"停止运行中的插件: {plugin_name}")
            if not self.runtime_manager.stop_plugin(plugin_name, plugins):
                logger.error("停止插件失败，无法更新")
                return False

        # 使用临时目录进行更新操作
        with self.archive_handler.temp_directory() as temp_dir:
            # 下载新版本
            temp_archive = temp_dir / f"{plugin.name}_update.zip"

            version_file_name = f"{plugin_name}-{version_info.version}.zip"
            if not self.download_manager.download_with_progress(version_info.download_url + "/" + version_file_name,
                                                                str(temp_archive),
                                                                progress_callback):
                logger.error(f"下载新版本失败: {plugin_name}")
                return False

            # 验证文件完整性（如果提供了MD5）
            if version_info.md5_hash:
                downloaded_md5 = self.download_manager.calculate_file_md5(temp_archive)
                if downloaded_md5 != version_info.md5_hash.lower():
                    logger.error(f"文件校验失败: MD5不匹配")
                    return False

            # 在临时目录中解压验证
            extract_temp_dir = temp_dir / "extracted"
            if not self.archive_handler.extract_archive(temp_archive, extract_temp_dir):
                logger.error(f"解压新版本失败: {plugin_name}")
                return False

            # 下载配置文件
            config_file_name = f"{plugin_name}-{version_info.version}.yaml"
            plugin_config_path = self.download_manager.download(version_info.download_url + "/" + config_file_name,
                                                                str(extract_temp_dir / config_file_name))
            if not plugin_config_path:
                logger.error(f"下载新版本配置失败: {plugin_name}")
                return False

            # 备份旧版本
            plugin_dir = self.plugin_install_dir / plugin.extract_folder
            backup_success = False
            backup_dir = None

            if plugin_dir.exists():
                try:
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    backup_dir = self.plugin_install_dir / f"{plugin.extract_folder}_backup_{timestamp}"
                    shutil.copytree(plugin_dir, backup_dir)
                    backup_success = True
                    logger.info(f"已创建备份: {backup_dir}")
                except Exception as e:
                    logger.warning(f"备份失败: {str(e)}")

            try:
                # 删除旧版本
                if plugin_dir.exists():
                    shutil.rmtree(plugin_dir)

                # 移动新版本到目标位置
                shutil.move(str(extract_temp_dir), str(plugin_dir))

                # 更新插件配置中的版本号
                plugin.current_version = version_info.version
                if not self.plugin_loader.save_plugin_config(plugin):
                    logger.warning(f"保存插件配置失败，但文件已更新: {plugin_name}")

                # 删除备份
                if backup_success and backup_dir and backup_dir.exists():
                    shutil.rmtree(backup_dir)

                logger.info(f"插件 {plugin_name} 更新完成: {version_info.version}")
                return True

            except Exception as e:
                logger.error(f"更新过程出错: {str(e)}")
                # 恢复备份
                if backup_success and backup_dir and backup_dir.exists():
                    try:
                        if plugin_dir.exists():
                            shutil.rmtree(plugin_dir)
                        shutil.move(str(backup_dir), str(plugin_dir))
                        logger.info(f"已从备份恢复插件: {plugin_name}")
                    except Exception as restore_error:
                        logger.error(f"恢复备份失败: {str(restore_error)}")
                return False

    def auto_update_plugins(self, plugins: List[PluginConfig]) -> Dict[str, bool]:
        """自动更新所有有更新的插件"""
        updates = self.check_all_updates(plugins, background=True)
        results = {}

        for plugin_name, version_info in updates.items():
            try:
                plugin = self._get_plugin_info(plugin_name, plugins)
                version_check_info = self.version_manager.get_version_check_info(plugin_name)
                auto_update = version_check_info.get('auto_update', False)

                if plugin and auto_update:
                    logger.info(f"自动更新插件: {plugin_name}")
                    success = self.update_plugin(plugin_name, version_info, plugins=plugins)
                    results[plugin_name] = success
                else:
                    logger.info(f"插件 {plugin_name} 有更新但未启用自动更新")
                    results[plugin_name] = False
            except Exception as e:
                logger.error(f"自动更新插件 {plugin_name} 失败: {str(e)}")
                results[plugin_name] = False

        return results

    def _get_plugin_info(self, plugin_name: str, plugins: List[PluginConfig]) -> Optional[PluginConfig]:
        """获取插件信息"""
        if plugins is None:
            return None
        return next((p for p in plugins if p.name == plugin_name), None)
