from mcp_server_gaode_thy_http import main

main()