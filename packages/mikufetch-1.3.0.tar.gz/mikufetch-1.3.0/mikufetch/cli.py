# mikufetch/cli.py
"""CLI module for Mikufetch."""
from argparse import ArgumentParser
import json
import os
import sys
from shutil import get_terminal_size
from typing import List, Tuple

from .info import get_sys_info
from .art import MIKU_ART

# ANSI colors (used only for the info text, not for the art itself)
PINK = "\033[38;5;213m"
BLUE = "\033[38;5;39m"
CYAN = "\033[38;5;87m"
GREEN = "\033[38;5;84m"
YELLOW = "\033[38;5;228m"
RESET = "\033[0m"

def _enable_windows_ansi():
    """Try to enable ANSI processing on Windows consoles (best-effort)."""
    if os.name != "nt":
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        h = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint()
        if kernel32.GetConsoleMode(h, ctypes.byref(mode)):
            ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
            kernel32.SetConsoleMode(h, new_mode)
    except Exception:
        # best-effort: if it fails, colors will just be raw escape sequences
        return


def parse_args():
    parser = ArgumentParser(description="Cute cross-platform system info fetch with Miku ASCII art")
    parser.add_argument("--no-art", action="store_true", help="do not display ASCII art")
    parser.add_argument("--no-color", action="store_true", help="disable colors")
    parser.add_argument("--json", action="store_true", help="output info as JSON only")
    return parser.parse_args()


def _prepare_info_lines(info: List[Tuple[str, str]]) -> List[str]:
    """Return list of formatted 'Key: Value' strings (no colors)."""
    return [f"{k}: {v}" for k, v in info]


def display_info(info, no_art: bool = False, no_color: bool = False, json_out: bool = False):
    if json_out:
        data = {k: v for k, v in info}
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    _enable_windows_ansi()  # только если на Windows, чтобы ANSI работал

    colors = {
        "OS": BLUE,
        "Host": BLUE,
        "Kernel": BLUE,
        "Uptime": BLUE,
        "Packages": GREEN,
        "Shell": GREEN,
        "Resolution": GREEN,
        "CPU": CYAN,
        "GPU": CYAN,
        "Memory": YELLOW,
    }

    if no_color or not sys.stdout.isatty():
        for k in colors:
            colors[k] = ""
        global RESET
        RESET = ""

    if no_art:
        for key, value in info:
            print(f"{colors.get(key,'')}{key}:{RESET} {value}")
        return

    art_lines = MIKU_ART.splitlines()
    info_lines = [f"{colors.get(k,'')}{k}:{RESET} {v}" for k, v in info]

    # side-by-side art + инфа
    max_art_width = max(len(line) for line in art_lines)
    padding = 3
    art_height = len(art_lines)
    info_height = len(info_lines)
    start_index = (art_height - info_height) // 2 if art_height > info_height else 0

    for i in range(art_height):
        art_line = art_lines[i]
        if start_index <= i < start_index + info_height:
            info_line = info_lines[i - start_index]
        else:
            info_line = ""
        print(f"{PINK}{art_line.ljust(max_art_width)}{RESET}{' ' * padding}{info_line}")


# convenience: allow cli.py to be used as a module main if needed
def main() -> int:
    args = parse_args()
    info = get_sys_info()
    display_info(info, no_art=args.no_art, no_color=args.no_color, json_out=args.json)
    return 0
