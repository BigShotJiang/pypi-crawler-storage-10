"""System information detection module for Mikufetch."""

import platform
import subprocess
import os

def _run(cmd: str) -> str:
    """Run a shell command and return its output as string."""
    try:
        return subprocess.getoutput(cmd).strip()
    except Exception:
        return ""

def _is_windows() -> bool:
    """Return True if system is Windows."""
    return platform.system().lower() == "windows"

def _is_macos() -> bool:
    """Return True if system is macOS."""
    return platform.system().lower() == "darwin"

def detect_os() -> str:
    """Return OS name."""
    return platform.platform()

def detect_host() -> str:
    """Return host name."""
    return platform.node()

def detect_kernel() -> str:
    """Return kernel version."""
    return platform.release()

def detect_shell() -> str:
    """Return current shell."""
    if _is_windows():
        return os.environ.get("ComSpec", "cmd").split("\\")[-1]
    sh = os.environ.get("SHELL") or _run("echo $SHELL")
    return sh.split("/")[-1] if sh else "Unknown"

def detect_cpu() -> str:
    """Return CPU info."""
    if _is_windows():
        out = _run("powershell -NoProfile -Command "
                   "\"(Get-CimInstance Win32_Processor | Select-Object -ExpandProperty Name | Select-Object -First 1)\"")
        return out or platform.processor() or "Unknown"
    if _is_macos():
        return _run("sysctl -n machdep.cpu.brand_string") or platform.processor() or "Unknown"
    return _run("lscpu | grep 'Model name' | cut -d':' -f2 | xargs") or platform.processor() or "Unknown"

def detect_memory() -> str:
    """Return memory usage."""
    if _is_windows():
        ps = (
            "powershell -NoProfile -Command "
            "\"$o=Get-CimInstance Win32_OperatingSystem; "
            "$u=[int](($o.TotalVisibleMemorySize-$o.FreePhysicalMemory)/1024); "
            "$t=[int]($o.TotalVisibleMemorySize/1024); "
            "'{0}MiB / {1}MiB' -f $u, $t\""
        )
        return _run(ps) or "Unknown"
    # Linux & macOS simplified
    try:
        mem_total = int(_run("grep MemTotal /proc/meminfo | awk '{print $2}'"))
        mem_avail = int(_run("grep MemAvailable /proc/meminfo | awk '{print $2}'"))
        mem_used = mem_total - mem_avail
        return f"{mem_used//1024}MiB / {mem_total//1024}MiB"
    except Exception:
        return "Unknown"

def detect_gpu() -> str:
    """Return GPU info."""
    if _is_windows():
        return _run("powershell -NoProfile -Command "
                    "\"(Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name | Select-Object -First 1)\"") or "Unknown"
    return _run("lspci | grep -i vga | cut -d':' -f3 | xargs") or "Unknown"

def detect_uptime() -> str:
    """Return system uptime."""
    if _is_windows():
        cmd = ("powershell -NoProfile -Command "
               "\"$ts=(Get-Date)-(Get-CimInstance Win32_OperatingSystem).LastBootUpTime; "
               "'{0}d {1}h {2}m' -f [int]$ts.Days,[int]$ts.Hours,[int]$ts.Minutes\"")
        return _run(cmd) or "Unknown"
    return _run("uptime -p") or "Unknown"

def detect_packages() -> str:
    """Return number of installed packages (Linux)."""
    if _is_windows() or _is_macos():
        return "Unknown"
    out = _run("dpkg --list | wc -l")
    if out:
        return f"{out} (dpkg)"
    out = _run("rpm -qa | wc -l")
    if out:
        return f"{out} (rpm)"
    return "Unknown"

def detect_resolution() -> str:
    """Return screen resolution."""
    # Windows / macOS / Linux (simplified)
    return "Unknown"

def get_sys_info() -> list[tuple[str, str]]:
    """Return system info as list of (key, value) tuples."""
    return [
        ("OS", detect_os()),
        ("Host", detect_host()),
        ("Kernel", detect_kernel()),
        ("Uptime", detect_uptime()),
        ("Packages", detect_packages()),
        ("Shell", detect_shell()),
        ("Resolution", detect_resolution()),
        ("CPU", detect_cpu()),
        ("GPU", detect_gpu()),
        ("Memory", detect_memory()),
    ]
