from pathlib import Path

USER_DATA_DIR = Path.home() / ".materia" / "data"
