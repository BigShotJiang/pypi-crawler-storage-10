ILOKO Command-Line Interpreter

This package allows you to run .iloko files directly from your terminal.

Installation

(Once published to PyPI)

pip install iloko-cli


To install locally for testing:

Navigate to this iloko-cli-python folder.

Run pip install -e . (The -e means "editable", so changes are reflected immediately).

Usage

Create a file named test.iloko:

IPAKITA "Hello from the ILOKO CLI!"
IKABIL x = 10
IPAKITA "x * 5 ="
IPAKITA x * 5


Run it from your terminal:

iloko test.iloko


Publishing to PyPI (The 'pip' Store)

Make sure you have setuptools and twine installed: pip install setuptools twine

Build the package: python setup.py sdist bdist_wheel

Upload your package: twine upload dist/*