import re

# Define all possible token types
TOKEN_TYPES = [
    ('PRINT',     r'IPAKITA'),         # Ilocano for "Show"
    ('LET',       r'IKABIL'),          # Ilocano for "Put" or "Assign"
    ('ID',        r'[a-zA-Z_][a-zA-Z0-9_]*'), # Identifiers (variables)
    ('NUMBER',    r'\d+'),             # Numbers (like 10, 200)
    ('STRING',    r'"[^"]*"|\'[^\']*\''), # Support "..." or '...'
    ('PLUS',      r'\+'),              # Plus sign
    ('MINUS',     r'-'),              # Minus sign
    ('MUL',       r'\*'),              # Multiply sign
    ('DIV',       r'/'),              # Divide sign
    ('EQUALS',    r'='),              # Equals sign
    ('LPAREN',    r'\('),              # Left parenthesis
    ('RPAREN',    r'\)'),              # Right parenthesis
    ('NEWLINE',   r'\n'),              # Newline
    ('SKIP',      r'[ \t]+'),          # Skip whitespace
]

# A simple Token object
class Token:
    def __init__(self, type, value):
        self.type = type
        self.value = value
    def __repr__(self):
        """String representation for debugging."""
        return f"Token({self.type}, {repr(self.value)})"

def lex(code):
    """
    The lexer function.
    Takes source code as a string and returns a list of Tokens.
    """
    tokens = []
    # Combine all regex patterns
    tok_regex = '|'.join('(?P<%s>%s)' % pair for pair in TOKEN_TYPES)
    
    for mo in re.finditer(tok_regex, code):
        kind = mo.lastgroup
        value = mo.group()

        if kind == 'NUMBER':
            value = int(value)  # Convert numbers to integers
        elif kind == 'STRING':
            value = value[1:-1] # Remove the surrounding quotes
        elif kind == 'SKIP' or kind == 'NEWLINE':
            continue # Ignore whitespace and newlines
            
        tokens.append(Token(kind, value))
        
    return tokens

