# Import the AST node types from parser.py
# Note the '.parser' which means "import from the same folder"
from .parser import NumNode, StringNode, VarAccessNode, BinOpNode, AssignNode, PrintNode 

class Interpreter:
    def __init__(self):
        self.symbol_table = {}
        # We don't need the 'output_list' for the CLI version!
    
    def visit(self, node):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.no_visit_method)
        return method(node)

    def no_visit_method(self, node):
        raise Exception(f'No visit_{type(node).__name__} method defined')

    def visit_NumNode(self, node):
        return node.value

    def visit_StringNode(self, node):
        return node.value
    
    def visit_VarAccessNode(self, node):
        name = node.name
        if name in self.symbol_table:
            return self.symbol_table[name]
        else:
            raise Exception(f"Variable '{name}' is not defined.")

    def visit_AssignNode(self, node):
        value = self.visit(node.value)
        self.symbol_table[node.name] = value

    def visit_PrintNode(self, node):
        value = self.visit(node.value)
        # --- THIS IS THE KEY CHANGE ---
        # Instead of appending to a list, we just print
        # directly to the console.
        print(value)

    def visit_BinOpNode(self, node):
        left = self.visit(node.left)
        right = self.visit(node.right)
        op = node.op_token.type

        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            if op == 'PLUS': return left + right
            elif op == 'MINUS': return left - right
            elif op == 'MUL': return left * right
            elif op == 'DIV':
                if right == 0: raise Exception("Runtime error: Division by zero")
                # Use integer division for simplicity, or float(left) / right for float division
                return left // right 
        
        elif isinstance(left, str) and isinstance(right, str):
            if op == 'PLUS': return left + right
            else: raise Exception(f"Unsupported operation '{op}' for strings")
        
        else:
            raise Exception(f"Type mismatch: Cannot {op} {type(left).__name__} and {type(right).__name__}")

