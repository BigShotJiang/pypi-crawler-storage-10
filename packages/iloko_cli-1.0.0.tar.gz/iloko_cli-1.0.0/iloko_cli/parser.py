# --- 4. AST NODES ---
class NumNode:
    """Represents a number."""
    def __init__(self, token): 
        self.value = token.value
    def __repr__(self): 
        return f"Num({self.value})"

class StringNode:
    """Represents a string."""
    def __init__(self, token): 
        self.value = token.value
    def __repr__(self): 
        return f"Str({self.value})"

class VarAccessNode:
    """Represents a variable access (e.g., 'PRINT a')"""
    def __init__(self, token): 
        self.name = token.value
    def __repr__(self): 
        return f"Var({self.name})"

class BinOpNode:
    """Represents a binary operation (e.g., 10 + 5)"""
    def __init__(self, left, op_token, right):
        self.left = left
        self.op_token = op_token
        self.right = right
    def __repr__(self): 
        return f"BinOp({self.left}, {self.op_token.type}, {self.right})"

class AssignNode:
    """Represents assignment (e.g., 'LET a = 10')"""
    def __init__(self, name_token, value_node):
        self.name = name_token.value
        self.value = value_node
    def __repr__(self): 
        return f"Assign({self.name}, {self.value})"

class PrintNode:
    """Represents a PRINT statement."""
    def __init__(self, value_node):
        self.value = value_node
    def __repr__(self): 
        return f"Print({self.value})"

# --- 5. PARSER ---
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.idx = -1
        self.current_token = None
        self.advance()

    def advance(self):
        """Move to the next token."""
        self.idx += 1
        self.current_token = self.tokens[self.idx] if self.idx < len(self.tokens) else None
        return self.current_token

    def parse(self):
        """Parse the full list of tokens into a list of AST nodes (statements)."""
        statements = []
        while self.current_token is not None:
            if self.current_token.type == 'LET':
                statements.append(self.parse_let_statement())
            elif self.current_token.type == 'PRINT':
                statements.append(self.parse_print_statement())
            else:
                self.advance() 
        return statements

    def parse_let_statement(self):
        """Parse 'LET a = expression'"""
        self.advance() # Skip LET
        name_token = self.current_token
        
        if name_token.type != 'ID':
             raise Exception("Expected variable name in assignment")
        
        self.advance() # Skip ID
        
        if self.current_token.type != 'EQUALS':
            raise Exception("Expected '=' in assignment")
        
        self.advance() # Skip =
        value_node = self.parse_expression()
        return AssignNode(name_token, value_node)

    def parse_print_statement(self):
        """Parse 'PRINT expression'"""
        self.advance() # Skip PRINT
        value_node = self.parse_expression()
        return PrintNode(value_node)

    def parse_expression(self):
        """Parse a simple expression."""
        left = self.parse_atom()

        while self.current_token and self.current_token.type in ('PLUS', 'MINUS', 'MUL', 'DIV'):
            op_token = self.current_token
            self.advance()
            right = self.parse_atom()
            left = BinOpNode(left, op_token, right)
            
        return left

    def parse_atom(self):
        """Parse a single 'atom' like a NUMBER, STRING, or variable (ID)."""
        token = self.current_token
        if token is None:
            raise Exception("Unexpected end of input")

        self.advance()
        if token.type == 'NUMBER':
            return NumNode(token)
        elif token.type == 'STRING':
            return StringNode(token)
        elif token.type == 'ID':
            return VarAccessNode(token)
        else:
            raise Exception(f"Unexpected token: {token}")

