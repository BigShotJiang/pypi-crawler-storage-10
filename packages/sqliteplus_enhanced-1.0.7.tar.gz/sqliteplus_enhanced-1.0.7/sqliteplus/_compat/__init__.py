"""Utilidades de compatibilidad para dependencias opcionales."""

from sqliteplus._compat.bootstrap import ensure_bcrypt

__all__ = ["ensure_bcrypt"]
