"""Tests for git cloning infrastructure."""
