# Pyarmor 9.0.8 (ci), 008036, 2025-10-30T16:40:01.297617
from .pyarmor_runtime import __pyarmor__
