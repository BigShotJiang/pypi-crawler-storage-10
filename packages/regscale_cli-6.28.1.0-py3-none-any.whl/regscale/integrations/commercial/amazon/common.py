#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RegScale AWS Integrations"""
import re
import logging
from datetime import datetime, timedelta
from typing import Any, Optional, Tuple

from botocore.client import BaseClient
from botocore.exceptions import ClientError
from dateutil import parser

from regscale.core.app.utils.app_utils import create_logger

logger = logging.getLogger("regscale")


def check_finding_severity(comment: Optional[str]) -> str:
    """Check the severity of the finding

    :param Optional[str] comment: Comment from AWS Security Hub finding
    :return: Severity of the finding
    :rtype: str
    """
    result = ""
    if comment:
        match = re.search(r"(?<=Finding Severity: ).*", comment)
        if match:
            result = match.group()
    return result


def get_due_date(earliest_date_performed: str, days: int) -> datetime:
    """Returns the due date for an issue

    :param str earliest_date_performed: Earliest date performed (string format)
    :param int days: Days to add to the earliest date performed
    :return: Due date
    :rtype: datetime
    """
    fmt = "%Y-%m-%dT%H:%M:%S.%fZ"
    try:
        due_date = datetime.strptime(earliest_date_performed, fmt) + timedelta(days=days)
    except ValueError:
        # Try to determine the date format from a string
        due_date = parser.parse(earliest_date_performed) + timedelta(days=days)
    return due_date


def determine_status_and_results(finding: Any) -> Tuple[str, Optional[str]]:
    """
    Determine Status and Results

    :param Any finding: AWS Finding
    :return: Status and Results
    :rtype: Tuple[str, Optional[str]]
    """
    status = "Pass"
    results = None
    if "Compliance" in finding.keys():
        status = "Fail" if finding["Compliance"]["Status"] == "FAILED" else "Pass"
        results = ", ".join(finding.get("Compliance", {}).get("RelatedRequirements", [])) or "N/A"
    if "FindingProviderFields" in finding.keys():
        status = (
            "Fail"
            if finding.get("FindingProviderFields", {}).get("Severity", {}).get("Label", "")
            in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
            else "Pass"
        )
    if "PatchSummary" in finding.keys() and not results:
        results = (
            f"{finding.get('PatchSummary', {}).get('MissingCount', 0)} Missing Patch(s) of "
            "{finding.get('PatchSummary', {}).get('InstalledCount', 0)}"
        )
    return status, results


def get_comments(finding: dict) -> str:
    """
    Get Comments

    :param dict finding: AWS Finding
    :return: Comments
    :rtype: str
    """
    try:
        return (
            finding["Remediation"]["Recommendation"]["Text"]
            + "<br></br>"
            + finding["Remediation"]["Recommendation"]["Url"]
            + "<br></br>"
            + f"""Finding Severity: {finding["FindingProviderFields"]["Severity"]["Label"]}"""
        )
    except KeyError:
        return "No remediation recommendation available"


def _fetch_with_error_handling(
    aws_client: BaseClient, method_name: str, result_key: str, resource_type: str = "items"
) -> list:
    """Generic fetch method with error handling for AWS Security Hub

    :param BaseClient aws_client: AWS Security Hub Client
    :param str method_name: Name of the method to call on the client
    :param str result_key: Key to extract from the response
    :param str resource_type: Type of resource being fetched (for logging)
    :return: List of items from AWS
    :rtype: list
    """
    items = []
    try:
        method = getattr(aws_client, method_name)
        response = method()
        items = response.get(result_key, [])
        logger.info("Fetched %d %s from Security Hub", len(items), resource_type)
    except ClientError as cex:
        logger.error("Unexpected error when fetching %s from AWS: %s", resource_type, cex)
    except AttributeError as aex:
        logger.error("Method %s not found on client: %s", method_name, aex)
    return items


def fetch_aws_findings(aws_client: BaseClient) -> list:
    """Fetch AWS Findings with optimized rate limiting and pagination

    :param BaseClient aws_client: AWS Security Hub Client
    :return: AWS Findings
    :rtype: list
    """
    try:
        # Use optimized SecurityHubPuller for better performance
        from regscale.integrations.commercial.aws.security_hub import SecurityHubPuller

        # Extract region from the client's meta information
        region = aws_client.meta.region_name

        # Create SecurityHubPuller with same region and credentials
        puller = SecurityHubPuller(region_name=region)
        puller.client = aws_client

        # Fetch all findings with optimized pagination and rate limiting
        logger.info("Using optimized SecurityHubPuller for findings retrieval...")
        findings = puller.get_all_findings_with_retries()

        logger.info("Successfully fetched %d findings with rate limiting", len(findings))
        return findings

    except (ImportError, AttributeError) as e:
        # Fallback to original method if SecurityHubPuller not available or region not accessible
        logger.warning("SecurityHubPuller not available (%s), falling back to basic client", type(e).__name__)
        return _fetch_with_error_handling(aws_client, "get_findings", "Findings", "findings")
    except Exception as e:
        logger.error("Error using SecurityHubPuller (%s), falling back to basic client", e)
        return _fetch_with_error_handling(aws_client, "get_findings", "Findings", "findings")


def fetch_aws_findings_v2(aws_client: BaseClient) -> list:
    """Fetch AWS Findings using v2 API

    :param BaseClient aws_client: AWS Security Hub Client
    :return: AWS Findings
    :rtype: list
    """
    return _fetch_with_error_handling(aws_client, "get_findings_v2", "Findings", "findings")


def fetch_aws_resources(aws_client: BaseClient) -> list:
    """Fetch AWS Resources

    :param BaseClient aws_client: AWS Security Hub Client
    :return: AWS Resources
    :rtype: list
    """
    return _fetch_with_error_handling(aws_client, "get_resources_v2", "Resources", "resources")
