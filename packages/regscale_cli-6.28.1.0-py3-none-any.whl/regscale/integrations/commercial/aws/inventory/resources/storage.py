"""AWS storage resource collectors."""

from typing import Dict, List, Any, Optional

from regscale.integrations.commercial.aws.inventory.resources.s3 import S3Collector
from ..base import BaseCollector


class StorageCollector(BaseCollector):
    """Collector for AWS storage resources with filtering support."""

    def __init__(
        self,
        session: Any,
        region: str,
        account_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        enabled_services: Optional[Dict[str, bool]] = None,
    ):
        """
        Initialize storage collector with filtering support.

        :param session: AWS session to use for API calls
        :param str region: AWS region to collect from
        :param str account_id: Optional AWS account ID to filter resources
        :param dict tags: Optional tag filters (AND logic)
        :param dict enabled_services: Optional dict of service names to boolean flags for enabling/disabling collection
        """
        super().__init__(session, region, account_id, tags)
        self.enabled_services = enabled_services or {}

    def get_s3_buckets(self) -> List[Dict[str, Any]]:
        """
        Get information about S3 buckets with filtering.

        :return: List of S3 bucket information
        :rtype: List[Dict[str, Any]]
        """
        try:
            s3_collector = S3Collector(self.session, self.region, self.account_id, self.tags)
            result = s3_collector.collect()
            return result.get("Buckets", [])
        except Exception as e:
            self._handle_error(e, "S3 buckets")
            return []

    def get_ebs_volumes(self) -> List[Dict[str, Any]]:
        """
        Get information about EBS volumes with tag filtering.

        :return: List of EBS volume information
        :rtype: List[Dict[str, Any]]
        """
        volumes = []
        try:
            ec2 = self._get_client("ec2")
            paginator = ec2.get_paginator("describe_volumes")

            for page in paginator.paginate():
                for volume in page.get("Volumes", []):
                    # Apply tag filtering
                    if self.tags and not self._matches_tags(volume.get("Tags", [])):
                        continue

                    # Apply account filtering if ARN available
                    volume_arn = (
                        f"arn:aws:ec2:{self.region}:{volume.get('OwnerId', 'unknown')}:volume/{volume.get('VolumeId')}"
                    )
                    if not self._matches_account(volume_arn):
                        continue

                    attachments = volume.get("Attachments", [])
                    volumes.append(
                        {
                            "Region": self.region,
                            "VolumeId": volume.get("VolumeId"),
                            "Size": volume.get("Size"),
                            "VolumeType": volume.get("VolumeType"),
                            "State": volume.get("State"),
                            "CreateTime": str(volume.get("CreateTime")),
                            "Encrypted": volume.get("Encrypted"),
                            "KmsKeyId": volume.get("KmsKeyId"),
                            "Attachments": [
                                {
                                    "InstanceId": att.get("InstanceId"),
                                    "State": att.get("State"),
                                    "Device": att.get("Device"),
                                }
                                for att in attachments
                            ],
                            "Tags": volume.get("Tags", []),
                        }
                    )
        except Exception as e:
            self._handle_error(e, "EBS volumes")
        return volumes

    def collect(self) -> Dict[str, Any]:
        """
        Collect storage resources based on enabled_services configuration.

        :return: Dictionary containing enabled storage resource information
        :rtype: Dict[str, Any]
        """
        result = {}

        # S3 Buckets
        if self.enabled_services.get("s3", True):
            result["S3Buckets"] = self.get_s3_buckets()

        # EBS Volumes
        if self.enabled_services.get("ebs", True):
            result["EBSVolumes"] = self.get_ebs_volumes()

        return result
