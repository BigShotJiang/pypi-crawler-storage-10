"""AWS networking resource collectors."""

from typing import Dict, List, Any, Optional

from regscale.integrations.commercial.aws.inventory.resources.vpc import VPCCollector
from ..base import BaseCollector


class NetworkingCollector(BaseCollector):
    """Collector for AWS networking resources."""

    def __init__(
        self,
        session: Any,
        region: str,
        account_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        enabled_services: Optional[Dict[str, bool]] = None,
    ):
        """
        Initialize networking collector.

        :param session: AWS session to use for API calls
        :param str region: AWS region to collect from
        :param str account_id: Optional AWS account ID to filter resources
        :param dict tags: Optional tags to filter resources (key-value pairs)
        :param dict enabled_services: Optional dict of service names to boolean flags for enabling/disabling collection
        """
        super().__init__(session, region)
        self.account_id = account_id
        self.tags = tags or {}
        self.enabled_services = enabled_services or {}

    def get_vpcs(self) -> Dict[str, Any]:
        """
        Get information about VPC resources.

        :return: Dictionary containing VPC resource information
        :rtype: Dict[str, Any]
        """
        try:
            vpc_collector = VPCCollector(self.session, self.region, self.account_id, self.tags)
            return vpc_collector.collect()
        except Exception as e:
            self._handle_error(e, "VPC resources")
            return {
                "VPCs": [],
                "Subnets": [],
                "SecurityGroups": [],
                "NetworkACLs": [],
                "RouteTables": [],
                "InternetGateways": [],
                "NATGateways": [],
                "VPCEndpoints": [],
                "VPCPeeringConnections": [],
            }

    def get_elastic_ips(self) -> List[Dict[str, Any]]:
        """
        Get information about Elastic IPs.

        :return: List of Elastic IP information
        :rtype: List[Dict[str, Any]]
        """
        eips = []
        try:
            ec2 = self._get_client("ec2")
            addresses = ec2.describe_addresses().get("Addresses", [])

            for addr in addresses:
                # Filter by tags if specified
                eip_tags = self._convert_tags_to_dict(addr.get("Tags", []))
                if self.tags and not self._matches_tags(eip_tags):
                    continue

                eips.append(
                    {
                        "Region": self.region,
                        "PublicIp": addr.get("PublicIp"),
                        "AllocationId": addr.get("AllocationId"),
                        "InstanceId": addr.get("InstanceId"),
                        "NetworkInterfaceId": addr.get("NetworkInterfaceId"),
                        "NetworkInterfaceOwner": addr.get("NetworkInterfaceOwnerId"),
                        "PrivateIpAddress": addr.get("PrivateIpAddress"),
                        "Tags": addr.get("Tags", []),
                    }
                )
        except Exception as e:
            self._handle_error(e, "Elastic IPs")
        return eips

    def get_load_balancers(self) -> List[Dict[str, Any]]:
        """
        Get information about Load Balancers (ALB/NLB).

        :return: List of Load Balancer information
        :rtype: List[Dict[str, Any]]
        """
        lbs = []
        try:
            elb = self._get_client("elbv2")
            paginator = elb.get_paginator("describe_load_balancers")

            for page in paginator.paginate():
                for lb in page.get("LoadBalancers", []):
                    # Get target groups for this LB
                    target_groups = []
                    tg_paginator = elb.get_paginator("describe_target_groups")
                    for tg_page in tg_paginator.paginate(LoadBalancerArn=lb["LoadBalancerArn"]):
                        target_groups.extend(tg_page.get("TargetGroups", []))

                    lbs.append(
                        {
                            "Region": self.region,
                            "LoadBalancerName": lb.get("LoadBalancerName"),
                            "LoadBalancerArn": lb.get("LoadBalancerArn"),
                            "DNSName": lb.get("DNSName"),
                            "Type": lb.get("Type"),
                            "Scheme": lb.get("Scheme"),
                            "VpcId": lb.get("VpcId"),
                            "State": lb.get("State", {}).get("Code"),
                            "AvailabilityZones": lb.get("AvailabilityZones", []),
                            "SecurityGroups": lb.get("SecurityGroups", []),
                            "Listeners": lb.get("Listeners", []),
                            "TargetGroups": [
                                {
                                    "TargetGroupName": tg.get("TargetGroupName"),
                                    "TargetGroupArn": tg.get("TargetGroupArn"),
                                    "Protocol": tg.get("Protocol"),
                                    "Port": tg.get("Port"),
                                    "HealthCheckProtocol": tg.get("HealthCheckProtocol"),
                                    "HealthCheckPort": tg.get("HealthCheckPort"),
                                    "HealthCheckPath": tg.get("HealthCheckPath"),
                                }
                                for tg in target_groups
                            ],
                        }
                    )
        except Exception as e:
            self._handle_error(e, "Load Balancers")
        return lbs

    def get_cloudfront_distributions(self) -> List[Dict[str, Any]]:
        """
        Get information about CloudFront distributions.

        :return: List of CloudFront distribution information
        :rtype: List[Dict[str, Any]]
        """
        distributions = []
        try:
            cloudfront = self._get_client("cloudfront")
            paginator = cloudfront.get_paginator("list_distributions")

            for page in paginator.paginate():
                for dist in page.get("DistributionList", {}).get("Items", []):
                    distributions.append(
                        {
                            "Region": self.region,
                            "Id": dist.get("Id"),
                            "DomainName": dist.get("DomainName"),
                            "Status": dist.get("Status"),
                            "Enabled": dist.get("Enabled"),
                            "Origins": dist.get("Origins", {}).get("Items", []),
                            "DefaultCacheBehavior": dist.get("DefaultCacheBehavior", {}),
                            "CacheBehaviors": dist.get("CacheBehaviors", {}).get("Items", []),
                            "CustomErrorResponses": dist.get("CustomErrorResponses", {}).get("Items", []),
                            "Comment": dist.get("Comment"),
                            "PriceClass": dist.get("PriceClass"),
                            "LastModifiedTime": str(dist.get("LastModifiedTime")),
                            "WebACLId": dist.get("WebACLId"),
                        }
                    )
        except Exception as e:
            self._handle_error(e, "CloudFront distributions")
        return distributions

    def get_route53_info(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get information about Route53 hosted zones and records.

        :return: Dictionary containing Route53 information
        :rtype: Dict[str, List[Dict[str, Any]]]
        """
        route53_info = {"HostedZones": [], "Records": []}
        try:
            route53 = self._get_client("route53")

            # Get hosted zones
            paginator = route53.get_paginator("list_hosted_zones")
            for page in paginator.paginate():
                for zone in page.get("HostedZones", []):
                    try:
                        # Get records for this zone
                        records = []
                        record_paginator = route53.get_paginator("list_resource_record_sets")
                        for record_page in record_paginator.paginate(HostedZoneId=zone["Id"]):
                            for record in record_page.get("ResourceRecordSets", []):
                                records.append(
                                    {
                                        "Name": record.get("Name"),
                                        "Type": record.get("Type"),
                                        "TTL": record.get("TTL"),
                                        "ResourceRecords": record.get("ResourceRecords", []),
                                        "AliasTarget": record.get("AliasTarget"),
                                        "Weight": record.get("Weight"),
                                        "Region": record.get("Region"),
                                        "GeoLocation": record.get("GeoLocation"),
                                        "Failover": record.get("Failover"),
                                        "MultiValueAnswer": record.get("MultiValueAnswer"),
                                        "HealthCheckId": record.get("HealthCheckId"),
                                    }
                                )

                        route53_info["HostedZones"].append(
                            {
                                "Id": zone.get("Id"),
                                "Name": zone.get("Name"),
                                "CallerReference": zone.get("CallerReference"),
                                "Config": zone.get("Config", {}),
                                "ResourceRecordSetCount": zone.get("ResourceRecordSetCount"),
                                "Records": records,
                            }
                        )
                    except Exception as e:
                        self._handle_error(e, f"Route53 zone {zone['Name']}")
        except Exception as e:
            self._handle_error(e, "Route53 zones")
        return route53_info

    def collect(self) -> Dict[str, Any]:
        """
        Collect networking resources based on enabled_services configuration.

        :return: Dictionary containing enabled networking resource information
        :rtype: Dict[str, Any]
        """
        result = {}

        # VPC Resources
        if self.enabled_services.get("vpc", True):
            vpc_info = self.get_vpcs()
            result.update(vpc_info)

        # Elastic IPs
        if self.enabled_services.get("elastic_ips", True):
            result["ElasticIPs"] = self.get_elastic_ips()

        # Load Balancers
        if self.enabled_services.get("load_balancers", True):
            result["LoadBalancers"] = self.get_load_balancers()

        # CloudFront Distributions
        if self.enabled_services.get("cloudfront", True):
            result["CloudFrontDistributions"] = self.get_cloudfront_distributions()

        # Route53
        if self.enabled_services.get("route53", True):
            result["Route53"] = self.get_route53_info()

        return result

    def _convert_tags_to_dict(self, tags_list: List[Dict[str, str]]) -> Dict[str, str]:
        """
        Convert AWS tags list format to dictionary.

        :param list tags_list: List of tags in format [{"Key": "k", "Value": "v"}]
        :return: Dictionary of tags {key: value}
        :rtype: Dict[str, str]
        """
        return {tag.get("Key", ""): tag.get("Value", "") for tag in tags_list}

    def _matches_tags(self, resource_tags: Dict[str, str]) -> bool:
        """
        Check if resource tags match the specified filter tags.

        :param dict resource_tags: Tags on the resource
        :return: True if all filter tags match
        :rtype: bool
        """
        if not self.tags:
            return True

        # All filter tags must match
        for key, value in self.tags.items():
            if resource_tags.get(key) != value:
                return False

        return True
