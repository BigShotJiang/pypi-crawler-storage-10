"""AWS database resource collectors."""

from typing import Dict, List, Any, Optional

from ..base import BaseCollector


class DatabaseCollector(BaseCollector):
    """Collector for AWS database resources with filtering support."""

    def __init__(
        self,
        session: Any,
        region: str,
        account_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        enabled_services: Optional[Dict[str, bool]] = None,
    ):
        """
        Initialize database collector with filtering support.

        :param session: AWS session to use for API calls
        :param str region: AWS region to collect from
        :param str account_id: Optional AWS account ID to filter resources
        :param dict tags: Optional tag filters (AND logic)
        :param dict enabled_services: Optional dict of service names to boolean flags for enabling/disabling collection
        """
        super().__init__(session, region, account_id, tags)
        self.enabled_services = enabled_services or {}

    def get_rds_instances(self) -> List[Dict[str, Any]]:
        """
        Get information about RDS instances with filtering.

        :return: List of RDS instance information
        :rtype: List[Dict[str, Any]]
        """
        instances = []
        try:
            rds = self._get_client("rds")
            paginator = rds.get_paginator("describe_db_instances")

            for page in paginator.paginate():
                for instance in page.get("DBInstances", []):
                    # Apply tag filtering
                    if self.tags and not self._matches_tags(instance.get("TagList", [])):
                        continue

                    # Apply account filtering using DBInstanceArn
                    instance_arn = instance.get("DBInstanceArn", "")
                    if not self._matches_account(instance_arn):
                        continue

                    instances.append(
                        {
                            "Region": self.region,
                            "DBInstanceIdentifier": instance.get("DBInstanceIdentifier"),
                            "DBInstanceArn": instance.get("DBInstanceArn"),
                            "DBInstanceClass": instance.get("DBInstanceClass"),
                            "Engine": instance.get("Engine"),
                            "EngineVersion": instance.get("EngineVersion"),
                            "DBInstanceStatus": instance.get("DBInstanceStatus"),
                            "Endpoint": instance.get("Endpoint", {}),
                            "AllocatedStorage": instance.get("AllocatedStorage"),
                            "InstanceCreateTime": str(instance.get("InstanceCreateTime")),
                            "VpcId": instance.get("DBSubnetGroup", {}).get("VpcId"),
                            "AvailabilityZone": instance.get("AvailabilityZone"),
                            "MultiAZ": instance.get("MultiAZ"),
                            "PubliclyAccessible": instance.get("PubliclyAccessible"),
                            "StorageEncrypted": instance.get("StorageEncrypted"),
                            "KmsKeyId": instance.get("KmsKeyId"),
                            "Tags": instance.get("TagList", []),
                        }
                    )
        except Exception as e:
            self._handle_error(e, "RDS instances")
        return instances

    def _should_include_table(self, dynamodb, table_arn: str, table_name: str) -> bool:
        """
        Check if table should be included based on account and tag filters.

        :param dynamodb: DynamoDB client
        :param str table_arn: Table ARN
        :param str table_name: Table name
        :return: True if table should be included, False otherwise
        :rtype: bool
        """
        if not self._matches_account(table_arn):
            return False

        if self.tags:
            try:
                tags_response = dynamodb.list_tags_of_resource(ResourceArn=table_arn)
                table_tags = tags_response.get("Tags", [])
                return self._matches_tags(table_tags)
            except Exception as e:
                self._handle_error(e, f"DynamoDB table tags for {table_name}")
                return False

        return True

    def _build_table_data(self, table: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build table data dictionary.

        :param table: Raw table data
        :return: Processed table data
        :rtype: Dict[str, Any]
        """
        return {
            "Region": self.region,
            "TableName": table.get("TableName"),
            "TableStatus": table.get("TableStatus"),
            "CreationDateTime": str(table.get("CreationDateTime")),
            "TableSizeBytes": table.get("TableSizeBytes"),
            "ItemCount": table.get("ItemCount"),
            "TableArn": table.get("TableArn"),
            "ProvisionedThroughput": {
                "ReadCapacityUnits": table.get("ProvisionedThroughput", {}).get("ReadCapacityUnits"),
                "WriteCapacityUnits": table.get("ProvisionedThroughput", {}).get("WriteCapacityUnits"),
            },
            "BillingModeSummary": table.get("BillingModeSummary", {}),
            "GlobalSecondaryIndexes": table.get("GlobalSecondaryIndexes", []),
            "LocalSecondaryIndexes": table.get("LocalSecondaryIndexes", []),
            "StreamSpecification": table.get("StreamSpecification", {}),
            "SSEDescription": table.get("SSEDescription", {}),
        }

    def get_dynamodb_tables(self) -> List[Dict[str, Any]]:
        """
        Get information about DynamoDB tables with filtering.

        :return: List of DynamoDB table information
        :rtype: List[Dict[str, Any]]
        """
        tables = []
        try:
            dynamodb = self._get_client("dynamodb")
            paginator = dynamodb.get_paginator("list_tables")

            for page in paginator.paginate():
                for table_name in page.get("TableNames", []):
                    try:
                        table = dynamodb.describe_table(TableName=table_name)["Table"]
                        table_arn = table.get("TableArn", "")

                        if not self._should_include_table(dynamodb, table_arn, table_name):
                            continue

                        table_data = self._build_table_data(table)
                        tables.append(table_data)
                    except Exception as e:
                        self._handle_error(e, f"DynamoDB table {table_name}")
        except Exception as e:
            self._handle_error(e, "DynamoDB tables")
        return tables

    def collect(self) -> Dict[str, Any]:
        """
        Collect database resources based on enabled_services configuration.

        :return: Dictionary containing enabled database resource information
        :rtype: Dict[str, Any]
        """
        result = {}

        # RDS Instances
        if self.enabled_services.get("rds", True):
            result["RDSInstances"] = self.get_rds_instances()

        # DynamoDB Tables
        if self.enabled_services.get("dynamodb", True):
            result["DynamoDBTables"] = self.get_dynamodb_tables()

        return result
