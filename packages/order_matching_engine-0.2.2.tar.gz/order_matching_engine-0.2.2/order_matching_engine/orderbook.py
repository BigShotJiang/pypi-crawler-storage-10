from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from sortedcontainers import SortedKeyList

from order_matching_engine.order import PriorityType

if TYPE_CHECKING:
    from order_matching_engine.order import LimitOrder


@dataclass
class Orderbook:
    """
    Represents the orderbook with bids and asks.
    """

    priority_type: PriorityType = PriorityType.PRICE_TIME
    bids: SortedKeyList["LimitOrder"] = field(init=False)
    asks: SortedKeyList["LimitOrder"] = field(init=False)

    def __post_init__(self) -> None:
        self.bids = SortedKeyList(key=self._sort_key)
        self.asks = SortedKeyList(key=self._sort_key)

    def get_bid(self) -> int | None:
        return self.bids[0].price if len(self.bids) > 0 else None

    def get_ask(self) -> int | None:
        return self.asks[0].price if len(self.asks) > 0 else None

    def __len__(self):
        return len(self.asks) + len(self.bids)

    def _sort_key(self, order: "LimitOrder") -> tuple:
        return order.sort_key(self.priority_type)
