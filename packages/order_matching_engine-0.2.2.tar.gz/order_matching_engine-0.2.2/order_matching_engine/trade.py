from dataclasses import dataclass, field
from time import time

from order_matching_engine.order import Side


def _current_timestamp() -> int:
    return int(1e6 * time())


@dataclass
class Trade:
    """
    Represents an executed trade.
    """

    side: Side
    price: float
    size: int
    incoming_order_id: int
    book_order_id: int
    timestamp: int = field(default_factory=_current_timestamp)

    def __repr__(self) -> str:
        return (
            "Trade(timestamp={timestamp}, side={side}, price={price}, size={size}, "
            "incoming_order_id={incoming}, book_order_id={book})"
        ).format(
            timestamp=self.timestamp,
            side=self.side.name,
            price=self.price,
            size=self.size,
            incoming=self.incoming_order_id,
            book=self.book_order_id,
        )
