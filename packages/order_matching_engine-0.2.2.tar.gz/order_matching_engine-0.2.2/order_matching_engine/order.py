from dataclasses import dataclass, field
from enum import Enum
from time import time


def _current_timestamp() -> int:
    return int(1e6 * time())


class Side(Enum):
    BUY = 0
    SELL = 1


class TimeInForce(Enum):
    GTC = "GTC"  # Good Till Canceled
    IOC = "IOC"  # Immediate Or Cancel
    FOK = "FOK"  # Fill Or Kill


class PegType(Enum):
    NONE = "NONE"
    MIDPOINT = "MIDPOINT"


class PriorityType(Enum):
    PRICE_TIME = "PRICE_TIME"
    PRICE_SIZE = "PRICE_SIZE"


@dataclass
class Order:
    order_id: int
    timestamp: int = field(default_factory=_current_timestamp, kw_only=True)

    def __getType__(self):
        return self.__class__


@dataclass
class CancelOrder(Order):
    pass


@dataclass
class MarketOrder(Order):
    side: Side
    size: int
    remaining: int = field(init=False)

    def __post_init__(self) -> None:
        self.remaining = self.size


@dataclass
class LimitOrder(MarketOrder):
    limit_price: int
    tif_type: TimeInForce = TimeInForce.GTC
    peg_type: PegType = PegType.NONE
    price: float = field(init=False)

    def __post_init__(self) -> None:
        super().__post_init__()
        self.price = self.limit_price  # effective price

    def sort_key(self, priority: PriorityType) -> tuple:
        price_key = -self.price if self.side == Side.BUY else self.price

        if priority == PriorityType.PRICE_TIME:
            return (price_key, self.timestamp, self.order_id)
        if priority == PriorityType.PRICE_SIZE:
            return (price_key, -self.remaining, self.timestamp, self.order_id)

        raise ValueError("Unsupported priority: {}".format(priority))

    def set_effective_price(self, new_price: float | None) -> float:
        if new_price is None:
            return self.price
        if self.peg_type == PegType.MIDPOINT:
            if self.side == Side.BUY:
                self.price = min(new_price, self.limit_price)
            else:
                self.price = max(new_price, self.limit_price)
        return self.price
