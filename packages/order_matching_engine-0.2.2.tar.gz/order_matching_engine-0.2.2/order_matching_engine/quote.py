from __future__ import annotations

from dataclasses import dataclass, field
from time import time


def _current_timestamp() -> int:
    return int(1e6 * time())


@dataclass(frozen=True)
class Quote:
    """
    Represents an external best bid/ask snapshot.
    """

    bid: float | None
    ask: float | None
    timestamp: int = field(default_factory=_current_timestamp)

    def midpoint(self) -> float | None:
        if self.bid is None or self.ask is None:
            return None
        if self.bid > 0 and self.ask > 0:
            return (self.bid + self.ask) / 2.0
