from typing import Iterable
from prompt_toolkit.completion import CompleteEvent, Completer, Completion
from prompt_toolkit.document import Document
import sqlparse
from sqlparse.sql import Statement

from adam.sql.state_machine import StateMachine, StateTo
from adam.sql.term_completer import TermCompleter

__all__ = [
    "AutomataCompleter",
]

def default_columns(_: list[str]):
    return 'id,x.,y.,z.'.split(',')

class AutomataCompleter(Completer):
    def __init__(self,
                 state_machine: StateMachine,
                 first_term: str,
                 debug = False):
        super().__init__()
        self.machine = state_machine
        self.first_term = first_term
        self.debug = debug

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        text = document.text_before_cursor.lstrip()
        state = ''
        if self.first_term:
            state = f'{self.first_term}_'
            text = f'{self.first_term} {text}'

        completer: Completer = None
        tokens = []
        stmts = sqlparse.parse(text)
        if not stmts:
            tokens = []
        else:
            statement: Statement = stmts[0]
            tokens = statement.tokens

        state: StateTo = self.machine.traverse_tokens(tokens, StateTo(state))
        if self.debug:
            print('\n  =>', state.to_s if isinstance(state, StateTo) else '')

        if state.to_s in self.machine.suggestions:
            terms = []

            for word in self.machine.suggestions[state.to_s].strip(' ').split(','):
                terms.extend(self.terms(state, word))

            if terms:
                completer = TermCompleter(terms)

        if completer:
            for c in completer.get_completions(document, complete_event):
                yield c

    def terms(self, _: str, word: str) -> list[str]:
        return [word]