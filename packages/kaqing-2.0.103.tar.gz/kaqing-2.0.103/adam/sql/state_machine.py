from abc import abstractmethod
from sqlparse.sql import Token
from sqlparse import tokens as T

__all__ = [
    "StateMachine",
]

class StateTo:
    def __init__(self, to_s: str, comeback_token: str = None, comeback_state: str = None):
        self.to_s = to_s
        self.comeback_token = comeback_token
        self.comeback_state = comeback_state
        self.context: dict[str, str] = {}

    def __str__(self):
        return f'{self.to_s if self.to_s else None} comeback[{self.comeback_token} {self.comeback_state}]'

class StateMachine:
    @abstractmethod
    def spec(self) -> str:
        return None

    @abstractmethod
    def keywords(self) -> list[str]:
        return None

    def incomplete_name_transition_condition(self, from_s: str, token: str, to_s: str, suggestions: str) -> list[str]:
        if not suggestions:
            return None

        tokens = [token]
        if '|' in token:
            tokens = token.split('|')

        if 'name' not in tokens:
            return None

        return tokens

    def __init__(self, indent=0, push_level = 0, debug = False):
        self.states: dict[str, StateTo] = {}
        self.suggestions: dict[str, str] = {}

        self.indent = indent
        self.push_level = push_level
        self.comebacks: dict[int, str] = {}
        self.debug = debug

        from_ss_to_add = []
        from_ss = ['']
        words: str = None
        for l in self.spec():
            t_and_w = l.split('^')
            if len(t_and_w) > 1:
                words = t_and_w[1].strip()
            else:
                words = None

            tks = t_and_w[0].strip(' ').split('>')
            if not l.startswith('-'):
                if words:
                    self.suggestions[tks[0].strip(' ')] = words

                if len(tks) == 1:
                    from_ss_to_add.append(tks[0].strip(' '))
                    continue

                from_ss = []
                from_ss.extend(from_ss_to_add)
                from_ss_to_add = []
                from_ss.append(tks[0].strip(' '))

            self.add_transitions(from_ss, tks, words)

    def add_transitions(self, from_ss: list[str], tks: list[str], words: str):
        token = tks[1].strip(' ')
        if len(tks) > 2:
            to_s = tks[2].strip(' ')
            for from_s in from_ss:
                self.add_whitespace_transition(from_s, to_s)
                self.add_transition(from_s, token, to_s)
                self.add_incomplete_name_transition(from_s, token, to_s, words)
        elif '<' in tks[0]:
            from_and_token = tks[0].split('<')
            if len(from_and_token) > 1:
                for from_s in from_ss:
                    self.add_comeback_transition(from_s, from_and_token[1], tks[1].strip(' '))

    def add_whitespace_transition(self, from_s: str, to_s: str):
        if self.witespace_transition_condition(from_s, to_s):
            if self.debug:
                print(f'{from_s[:-1]} > _ = {to_s}')
            self.states[f'{from_s[:-1]} > _'] = StateTo(from_s)

    def witespace_transition_condition(self, from_s: str, to_s: str):
        return from_s.endswith('_')

    def add_incomplete_name_transition(self, from_s: str, token: str, to_s: str, words: str):
        if tokens := self.incomplete_name_transition_condition(from_s, token, to_s, words):
            self.suggestions[to_s] = words
            for token in tokens:
                if self.debug:
                    print(f'{to_s} > {token} = {to_s}')
                self.states[f'{to_s} > {token}'] = StateTo(to_s)

    def add_transition(self, from_s: str, token: str, to_s: str):
        tokens = [token]
        if '|' in token:
            tokens = token.split('|')

        for t in tokens:
            if self.debug:
                print(f'{from_s} > {t} = {to_s}')
            self.states[f'{from_s} > {t}'] = StateTo(to_s)

    def add_comeback_transition(self, from_s: str, token: str, to_s: str):
        key = f'{from_s} > ('
        orig = self.states[key]
        if not orig:
            raise Exception(f'from state not found for {key}')

        orig.comeback_token = token
        orig.comeback_state = to_s
        if self.debug:
            print(f'{from_s} > ) = {to_s}')
        self.states[key] = orig

    def traverse_tokens(self, tokens: list[Token], state: StateTo = StateTo('')):
        def handle_push():
            if f'{state.to_s} > {it}' in self.states:
                state_test = self.states[f'{state.to_s} > {it}']
                if state_test.comeback_token:
                    self.comebacks[self.push_level] = state_test.comeback_state

        def handle_pop():
            if self.push_level in self.comebacks:
                try:
                    return StateTo(self.comebacks[self.push_level])
                finally:
                    del self.comebacks[self.push_level]

            return None

        for token in tokens:
            if self.debug:
                if token.ttype == T.Whitespace:
                    print('_ ', end='')
                elif token.ttype in [T.DML, T.Wildcard, T.Punctuation, T.CTE]:
                    print(f'{token.value} ', end='')
                elif token.ttype:
                    tks = str(token.ttype).split('.')
                    typ = tks[len(tks) - 1]
                    if ' ' in token.value:
                        print(f'"{token.value}:{typ}" ', end='')
                    else:
                        print(f'{token.value}:{typ} ', end='')
            # print("  " * self.indent + f"Token: {token.value}, Type: {token.ttype}@{token.ttype.__class__}")

            last_name = None
            if token.is_group:
                state = self.traverse_tokens(token.tokens, state)
            else:
                comeback_state = None

                it = ''
                if (t := token.value.lower()) in self.keywords():
                    it = t
                elif token.ttype == T.Text.Whitespace:
                    it = '_'
                elif token.ttype == T.Name:
                    it = 'name'
                    last_name = token.value
                elif token.ttype == T.Literal.String.Single:
                    it = 'single'
                elif token.ttype in [T.Literal.Number.Integer, T.Literal.Number.Float]:
                    it = 'num'
                elif token.ttype == T.Wildcard:
                    it = '*'
                elif token.ttype == T.Punctuation:
                    it = token.value

                    if it == '(':
                        handle_push()
                        self.push_level += 1
                    elif it == ')':
                        self.push_level -= 1
                        comeback_state = handle_pop()

                elif token.ttype == T.Operator.Comparison:
                    it = 'comparison'

                try:
                    # print(f'\n{state.to_s} > {it} > ', end='')
                    if comeback_state:
                        state = comeback_state
                    else:
                        context = state.context
                        state = self.states[f'{state.to_s} > {it}']
                        state.context = context

                    if last_name:
                        state.context['last_name'] = last_name
                except:
                    pass

        return state