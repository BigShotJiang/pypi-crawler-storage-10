"""Integration with the scikit-learn library."""

from ._impl import ScikitLearnSplitter

__all__ = [
    "ScikitLearnSplitter",
]
