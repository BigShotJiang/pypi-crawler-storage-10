"""Version information for SpeechAlgo."""

__version__ = "0.1.0"
