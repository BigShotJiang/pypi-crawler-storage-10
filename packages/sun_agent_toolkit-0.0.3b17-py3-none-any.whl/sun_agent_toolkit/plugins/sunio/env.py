DEFAULT_ENV = {
    "mainnet": {"base_url": "https://open.sun.io/apiv2"},
    "nile": {"base_url": "https://tnopenapi.endjgfsv.link/apiv2"},
}
