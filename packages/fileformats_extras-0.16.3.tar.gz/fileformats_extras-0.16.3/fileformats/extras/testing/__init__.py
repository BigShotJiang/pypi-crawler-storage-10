from pydra.compose import python

from fileformats.core import converter
from fileformats.testing import AbstractFile, ConvertibleToFile, EncodedText
from fileformats.text import TextFile


@converter  # pyright: ignore[reportArgumentType]
@python.define(outputs=["out_file"])  # type: ignore[misc]
def ConvertibleToConverter(in_file: AbstractFile) -> ConvertibleToFile:
    return ConvertibleToFile.sample()


@converter  # pyright: ignore[reportArgumentType]
@python.define(outputs=["out_file"])  # type: ignore[misc]
def EncodedFromTextConverter(in_file: TextFile) -> EncodedText:
    contents = in_file.read_text()
    # Encode by shifting ASCII codes forward by 1
    encoded_contents = "".join(chr(ord(c) + 1) for c in contents)
    out_file = EncodedText.sample()
    out_file.write_text(encoded_contents)
    return out_file


@converter  # pyright: ignore[reportArgumentType]
@python.define(outputs=["out_file"])  # type: ignore[misc]
def EncodedToTextConverter(in_file: EncodedText) -> TextFile:
    contents = in_file.read_text()
    # Decode by shifting ASCII codes back by 1
    decoded_contents = "".join(chr(ord(c) - 1) for c in contents)
    out_file = TextFile.sample()
    out_file.write_text(decoded_contents)
    return out_file
