from mayutils.export import OUTPUT_FOLDER


IMAGES_FOLDER = OUTPUT_FOLDER / "Images"
