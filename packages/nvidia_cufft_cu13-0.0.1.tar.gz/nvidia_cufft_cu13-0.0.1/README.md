⚠️ THIS PROJECT 'nvidia-cufft-cu13' IS DEPRECATED.
Please use 'nvidia-cufft' instead.

To install the correct package, use:

    pip install nvidia-cufft

For more information, visit: https://pypi.org/project/nvidia-cufft/
