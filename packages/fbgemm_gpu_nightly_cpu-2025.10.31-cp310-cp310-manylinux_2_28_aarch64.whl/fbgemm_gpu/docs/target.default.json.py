
{
    "version": "2025.10.31",
    "target": "default",
    "variant": "cpu"
}
