# Zeiss SEM TIFF Metadata Parser

A minimal Python library for parsing metadata from Zeiss SEM TIFF files, with special handling for Unicode corruption issues.

## Installation

```bash
pip install zeiss-sem-tiff
```

## Quick Start

```python
from zeiss_sem_tiff import get_zeiss_meta, get_stage_coords, get_timestamp

# Extract metadata
metadata = get_zeiss_meta("path/to/your/image.tif")

# Get acquisition timestamp  
timestamp = get_timestamp(metadata)

# Convert image coordinates to stage position
stage_x, stage_y, stage_r = get_stage_coords(metadata, img_coords=(100, 200))

print(f"Magnification: {metadata['AP_MAG']}")
print(f"Pixel size: {metadata['AP_PIXEL_SIZE']} m")
```

## Features

- Parse Zeiss SEM TIFF metadata
- Handle Unicode corruption (µm → ?m, µA → ?A)
- Convert image coordinates to stage positions
- Extract acquisition timestamps
- Version compatibility checking

## Supported Versions

Tested with SV version: `V07.05.00.00 : 27-Jul-23`

## License

MIT License