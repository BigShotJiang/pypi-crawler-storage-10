"""
Zeiss SEM TIFF Metadata Parser
==============================

A minimal Python library for parsing metadata from Zeiss SEM TIFF files.
Handles Unicode corruption issues with micrometers and microAmperes.

Usage:
    from zeiss_sem_tiff import get_zeiss_meta, get_stage_coords, get_timestamp
    
    # Get metadata from an image
    metadata = get_zeiss_meta("image.tif")
    # Get stage coordinates from an image, in meters and degrees
    stage_pos = get_stage_coords(metadata, (100, 200))
    # Get timestamp from metadata
    timestamp = get_timestamp(metadata)
    # Get width and height as a tuple of integers
    width, height = get_zeiss_width_height(metadata)
    # Get pixel size as a float, in meters
    pixel_size = metadata["AP_PIXEL_SIZE"]
    # Get magnification
    magnification = metadata["AP_MAG"]
"""

from __future__ import annotations
import re
from datetime import datetime, timezone
from PIL import Image
from logging import getLogger


logger = getLogger(__name__)


_SUPPORTED_SV_VERSION = "V07.05.00.00 : 27-Jul-23"
"""
SV version for which this module was tested.
"""

_METADATA_UNITS = {
    "pA": 1e-12,
    "nA": 1e-9,
    "µA": 1e-6,
    "uA": 1e-6,
    "?A": 1e-6,
    "mA": 1e-3,
    "pm": 1e-12,
    "nm": 1e-9,
    "µm": 1e-6,
    "um": 1e-6,
    "?m": 1e-6,
    "mm": 1e-3,
    "V": 1.0,
    "kV": 1e3,
    "K X": 1e3,
}
"""
Unit sizes for Zeiss TIFF SEM metadata.

This dictionary takes into account the unicode parsing errors for
micrometers and microAmperes.
"""


def extract_numbers(text: str) -> float | int | None:
    """Return the first number found (int/float) or None."""
    if not text:
        return None
    m = re.search(r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', text)
    if not m:
        return None
    s = m.group(0)
    return float(s) if any(c in s for c in ('.', 'e', 'E')) else int(s)



def _extract_zeiss_meta_string(img_file: str) -> str | None:
    """
    Extract the Zeiss TIFF metadata string from an image file.

    Parameters
    ----------
    img_file : str
        Path to a .tiff file, containing Zeiss TIFF metadata.

    Returns
    -------
    str | None
        The Zeiss TIFF metadata string, or None, if no metadata was found.
    """
    with Image.open(img_file) as img:
        for _, v in img.getexif().items():
            if isinstance(v, bytes):
                try:
                    v = v.decode('utf-8', errors='ignore')
                except Exception:
                    continue
            if isinstance(v, str) and any(k in v for k in ("AP_PIXEL_SIZE", "AP_TIME", "AP_DATE")):
                return v
    return None


def _parse_time_date_line(line: str, parameter: str) -> bool:
    """
    Check if a line is a time or date line from the Zeiss TIFF metadata.

    Parameters
    ----------
    line : str
        The line to parse.
    parameter : str
        The parameter to parse.

    Returns
    -------
    bool
        True if the line is a time or date line, False otherwise.
    """
    return "Time: " in line and parameter == "AP_TIME" or "Date: " in line and parameter == "AP_DATE"


def _parse_AP_parameter(value: str) -> float | int:
    """
    Parse an AP parameter from the Zeiss TIFF metadata.

    Parameters
    ----------
    value : str
        The value to parse.
    
    Returns
    -------
    float | int
        The parsed value.
    """
    num = extract_numbers(value)
    value = value.replace(str(num), "").replace("0", "").strip()
    unit_size = _METADATA_UNITS.get(value, 1)
    num = num * unit_size
    return num


def check_SV_version(metadata: dict[str, str | float | int]) -> bool:
    """
    Check if the SV version is supported.

    Parameters
    ----------
    metadata : dict[str, str | float | int]
        The Zeiss TIFF metadata.

    Returns
    -------
    bool
        True if the SV version is supported, False otherwise.
    """
    def parse_v(s: str) -> tuple[int, int, int, int]:
        head = s.split(" : ", 1)[0].lstrip("V")
        parts = [int(p) for p in head.split(".")]
        return tuple(parts + [0] * (4 - len(parts)))[:4]

    try:
        supported = parse_v(_SUPPORTED_SV_VERSION)
        current = parse_v(str(metadata["SV_VERSION"]))
    except KeyError:
        logger.debug("SV_VERSION not present in metadata")
        return False

    if current != supported:
        logger.debug(
            "Parsed SV version %s differs from supported %s",
            metadata.get("SV_VERSION"), _SUPPORTED_SV_VERSION
        )
        return False
    return True


def get_zeiss_meta(img_file: str) -> dict[str, str | float | int]:
    """
    Read Zeiss TIFF metadata from a file.

    Fixes problems with micrometers and microAmperes.

    Parameters
    ----------
    img_file : str
        Path to a .tiff file

    Returns
    -------
    dict[str, Any]
        A dictionary with metadata, where parameter names are keys. Parameters
        are given in their machine readable format (e.g., `"AP_PIXEL_SIZE"`
        instead of `"Pixel Size"`).
    """
    metadata = {}
    tiff_tags =_extract_zeiss_meta_string(img_file)
    if tiff_tags is None:
        logger.warning("No Zeiss TIFF metadata found in the image: %s", img_file)
        return metadata

    parameter = ""
    for line in tiff_tags.split('\n'):
        line = line.strip()
        if _parse_time_date_line(line, parameter):
            metadata[parameter] = line[6:]
        elif " = " in line:
            _, value = line.split("=")[: 2]
            value = value.strip()   
            if parameter.startswith("AP_"):
                metadata[parameter] = _parse_AP_parameter(value)
            else:
                metadata[parameter] = value
        else:
            parameter = line
    if not check_SV_version(metadata):
        logger.warning("Different SV version was parsed than the supported version in file: %s", img_file)
    return metadata


def get_timestamp(zeiss_meta: dict[str, str | float | int], tz: timezone | None = None) -> datetime | None:
    """
    Get the timestamp from the Zeiss TIFF metadata.

    Parameters
    ----------
    zeiss_meta : dict[str, str | float | int]
        The Zeiss TIFF metadata.
    tz : timezone | None
        The timezone to use for the timestamp. If None, the local timezone is used.
    Returns
    -------
    datetime | None
        The timestamp, or None if no timestamp was found.
    """
    date_s = zeiss_meta.get("AP_DATE")
    time_s = zeiss_meta.get("AP_TIME")
    if not (date_s and time_s):
        logger.warning("No timestamp found in Zeiss metadata")
        return None
    dt = datetime.strptime(f"{date_s} {time_s}", "%d %b %Y %H:%M:%S")
    return dt if tz is None else dt.replace(tzinfo=tz)


def get_zeiss_width_height(zeiss_meta: dict[str, str | float | int]) -> tuple[int, int]:
    """
    Get the width and height from the Zeiss TIFF metadata.

    Since the width and height are given in "DP_IMAGE_STORE" as "width * height" string, a helper function is
    used to parse it.

    Parameters
    ----------
    zeiss_meta : dict[str, str | float | int]
        The Zeiss TIFF metadata.

    Returns
    -------
    tuple[int, int]
        The width and height of the image.
    """
    width, height = zeiss_meta["DP_IMAGE_STORE"].split(" * ")
    return int(width), int(height)


def get_stage_coords(
        zeiss_meta: dict[str, str | float | int] | str,
        img_coords: tuple[int, int] | None = None,
) -> tuple[float, float, float]:
    """
    Get the stage position from a coordinate on an image from Zeiss SEM.

    Imagine that you want to know the exact stage position of a feature visible in the image. This function
    uses the Zeiss TIFF metadata to calculate the stage position.

    Parameters
    ----------
    zeiss_meta : dict[str, str | float | int] | str
        The Zeiss TIFF metadata, or a path to a .TIFF-file of a Zeiss image.
    img_coords : tuple[int, int] | None
        Coordinates on the image, (x, y). If None, the center of the image is used.
    
    Returns
    -------
    tuple[float, float, float]
        Coordinates of the stage, (X, Y, R) (meters, meters, degrees).
    """
    if isinstance(zeiss_meta, str):
        zeiss_meta = get_zeiss_meta(zeiss_meta)
    px_size = zeiss_meta["AP_IMAGE_PIXEL_SIZE"]
    width, height = get_zeiss_width_height(zeiss_meta)
    img_center_x = width / 2
    img_center_y = height / 2
    img_coord_x, img_coord_y = img_coords if img_coords else (img_center_x, img_center_y)
    stage_x = zeiss_meta["AP_STAGE_AT_X"]
    stage_y = zeiss_meta["AP_STAGE_AT_Y"]
    stage_r = zeiss_meta["AP_STAGE_AT_R"]
    x_diff = (img_coord_x - img_center_x) * px_size
    y_diff = (img_coord_y - img_center_y) * px_size
    return (
        stage_x - x_diff,
        stage_y + y_diff,
        stage_r
    )
