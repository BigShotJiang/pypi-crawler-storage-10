from setuptools import setup, find_packages


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()


setup(
    name="zeiss-sem-tiff",
    version="0.1.0",
    author="R. Gilyazev",
    author_email="gilyazevr@gmail.com",
    description="Parse Zeiss SEM TIFF metadata with Unicode corruption handling",
    long_description=long_description,
    long_description_content_type="text/markdown",
    py_modules=["zeiss_sem_tiff"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Image Processing",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Pillow>=8.0.0",
    ],
)