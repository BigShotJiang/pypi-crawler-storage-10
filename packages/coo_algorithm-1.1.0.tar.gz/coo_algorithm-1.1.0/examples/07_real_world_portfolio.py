"""
Example 7: Portfolio Optimization

Real-world example of financial portfolio optimization.
"""

import numpy as np
from coo_optimizer import COO
import matplotlib.pyplot as plt


def generate_synthetic_returns(n_assets=10, n_days=252):
    """Generate synthetic asset returns."""
    np.random.seed(42)

    # Random correlation matrix
    A = np.random.randn(n_assets, n_assets)
    corr = A @ A.T
    corr = corr / np.outer(np.sqrt(np.diag(corr)), np.sqrt(np.diag(corr)))

    # Generate returns
    mean_returns = np.random.uniform(0.05, 0.15, n_assets)
    std_returns = np.random.uniform(0.1, 0.3, n_assets)

    # Multivariate normal
    cov = np.outer(std_returns, std_returns) * corr
    returns = np.random.multivariate_normal(mean_returns, cov, n_days)

    return returns, mean_returns, cov


def portfolio_objective(weights, returns, risk_aversion=2.0):
    """
    Portfolio optimization objective (Sharpe ratio maximization).

    Maximize: expected_return - risk_aversion * variance
    """
    # Normalize weights
    weights = weights / np.sum(weights)

    # Calculate portfolio metrics
    portfolio_return = np.mean(returns @ weights) * 252  # Annualized
    portfolio_std = np.std(returns @ weights) * np.sqrt(252)

    # Objective: maximize Sharpe ratio (with risk aversion)
    sharpe = portfolio_return / portfolio_std - risk_aversion * portfolio_std

    return sharpe


def main():
    print("="*70)
    print("Example 7: Portfolio Optimization")
    print("="*70)

    n_assets = 10
    returns, mean_returns, cov = generate_synthetic_returns(n_assets)

    print(f"\nOptimizing portfolio of {n_assets} assets")
    print(f"Historical data: 252 days (1 year)")

    # Bounds: weights between 0 and 1
    bounds = [(0, 1)] * n_assets

    # Optimize
    coo = COO(
        bounds=bounds,
        mode='max',  # Maximize Sharpe ratio
        n_packs=2,
        max_iterations=150,
        random_state=42,
        verbose=True
    )

    def objective(w):
        return portfolio_objective(w, returns, risk_aversion=2.0)

    best_weights, best_sharpe, history, diag = coo.optimize(objective)

    # Normalize final weights
    best_weights = best_weights / np.sum(best_weights)

    # Calculate portfolio metrics
    portfolio_return = np.mean(returns @ best_weights) * 252
    portfolio_std = np.std(returns @ best_weights) * np.sqrt(252)
    sharpe_ratio = portfolio_return / portfolio_std

    # Results
    print("\n" + "="*70)
    print("OPTIMAL PORTFOLIO")
    print("="*70)

    for i, w in enumerate(best_weights):
        if w > 0.01:  # Only show significant weights
            print(f"Asset {i+1}: {w*100:.2f}%")

    print(f"\nExpected Annual Return: {portfolio_return*100:.2f}%")
    print(f"Annual Volatility: {portfolio_std*100:.2f}%")
    print(f"Sharpe Ratio: {sharpe_ratio:.4f}")

    # Visualization
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    # Weight distribution
    significant_weights = [(i+1, w)
                           for i, w in enumerate(best_weights) if w > 0.01]
    assets, weights = zip(*significant_weights)

    ax1.barh(range(len(assets)), [
             w*100 for w in weights], color='teal', alpha=0.7)
    ax1.set_yticks(range(len(assets)))
    ax1.set_yticklabels([f'Asset {a}' for a in assets])
    ax1.set_xlabel('Weight (%)', fontsize=11)
    ax1.set_title('Portfolio Allocation', fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.3, axis='x')

    # Convergence
    ax2.plot(history, linewidth=2, color='green')
    ax2.set_xlabel('Iteration', fontsize=11)
    ax2.set_ylabel('Sharpe Ratio', fontsize=11)
    ax2.set_title('Optimization Convergence', fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('example07_portfolio.png', dpi=300)
    print("\nPlot saved as 'example07_portfolio.png'")


if __name__ == "__main__":
    main()
