"""
Example 6: Constrained Optimization

Demonstrates handling constraints using penalty methods.
"""

import numpy as np
from coo_optimizer import COO
import matplotlib.pyplot as plt


def engineering_design(x):
    """
    Engineering design problem with constraints.

    Minimize weight of a welded beam structure.

    Variables:
    x[0] = h (weld thickness)
    x[1] = l (weld length)
    x[2] = t (beam height)
    x[3] = b (beam thickness)
    """
    h, l, t, b = x

    # Objective: minimize weight
    weight = 1.10471 * h**2 * l + 0.04811 * t * b * (14.0 + l)

    # Constraints (inequality, should be <= 0)
    P = 6000  # Load
    L = 14    # Length
    E = 30e6  # Young's modulus
    G = 12e6  # Shear modulus

    tau_max = 13600
    sigma_max = 30000
    delta_max = 0.25

    # Calculate stresses
    tau = P / (np.sqrt(2) * h * l)
    M = P * (L + l/2)
    R = np.sqrt((l**2)/4 + ((h+t)/2)**2)
    J = 2 * np.sqrt(2) * h * l * ((l**2)/12 + ((h+t)/2)**2)
    tau_prime = M * R / J
    tau_total = np.sqrt(tau**2 + tau**2 * tau_prime + tau_prime**2)

    sigma = 6*P*L / (b * t**2)
    Pc = 4.013 * E * np.sqrt((t**2 * b**6) / 36) / L**2
    delta = 4*P*L**3 / (E * b * t**3)

    # Constraint violations (penalty method)
    penalty = 10000  # Large penalty for violations

    g1 = max(0, tau_total - tau_max)
    g2 = max(0, sigma - sigma_max)
    g3 = max(0, h - b)
    g4 = max(0, delta - delta_max)
    g5 = max(0, P - Pc)

    total_penalty = penalty * (g1 + g2 + g3 + g4 + g5)

    return weight + total_penalty


def main():
    print("="*70)
    print("Example 6: Constrained Engineering Design")
    print("="*70)

    print("\nProblem: Welded Beam Design")
    print("Objective: Minimize weight")
    print("Subject to: Stress and deflection constraints")

    # Bounds
    bounds = [
        (0.1, 2.0),   # h
        (0.1, 10.0),  # l
        (0.1, 10.0),  # t
        (0.1, 2.0)    # b
    ]

    # Optimize
    coo = COO(
        bounds=bounds,
        mode='min',
        n_packs=3,
        init_pack_size=12,
        max_iterations=200,
        random_state=42,
        verbose=True
    )

    best_design, best_weight, history, diag = coo.optimize(engineering_design)

    # Results
    print("\n" + "="*70)
    print("OPTIMAL DESIGN")
    print("="*70)
    print(f"Weld thickness (h): {best_design[0]:.4f}")
    print(f"Weld length (l): {best_design[1]:.4f}")
    print(f"Beam height (t): {best_design[2]:.4f}")
    print(f"Beam thickness (b): {best_design[3]:.4f}")
    print(f"\nMinimum weight: {best_weight:.4f}")

    # Plot
    plt.figure(figsize=(10, 6))
    plt.semilogy(history, linewidth=2, color='purple')
    plt.xlabel('Iteration', fontsize=12)
    plt.ylabel('Weight (log scale)', fontsize=12)
    plt.title('Welded Beam Design Optimization',
              fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('example06_constrained.png', dpi=300)
    print("\nPlot saved as 'example06_constrained.png'")


if __name__ == "__main__":
    main()
