"""
Example 4: Hyperparameter Tuning

Demonstrates how to tune COO's hyperparameters for specific problems.
"""

import numpy as np
from coo_optimizer import COO, BenchmarkFunctions
from itertools import product
import pandas as pd
import matplotlib.pyplot as plt


def evaluate_config(config, func, bounds, n_runs=5):
    """Evaluate a hyperparameter configuration."""
    results = []

    for run in range(n_runs):
        coo = COO(
            bounds=bounds,
            mode='min',
            n_packs=config['n_packs'],
            init_pack_size=config['init_pack_size'],
            max_iterations=100,
            use_gradient=config['use_gradient'],
            surrogate_enabled=config['surrogate_enabled'],
            random_state=42 + run,
            verbose=False
        )

        _, best_val, _, _ = coo.optimize(func)
        results.append(best_val)

    return np.mean(results)


def main():
    print("="*70)
    print("Example 4: Hyperparameter Tuning")
    print("="*70)

    # Problem
    func = BenchmarkFunctions.rastrigin
    bounds = BenchmarkFunctions.get_bounds('rastrigin', 20)

    print("\nProblem: Rastrigin 20D")
    print("Tuning hyperparameters using grid search")

    # Hyperparameter grid
    param_grid = {
        'n_packs': [2, 3, 4],
        'init_pack_size': [8, 10, 12],
        'use_gradient': [True, False],
        'surrogate_enabled': [True, False]
    }

    # Generate all combinations
    keys = param_grid.keys()
    values = param_grid.values()
    configs = [dict(zip(keys, v)) for v in product(*values)]

    print(f"\nTesting {len(configs)} configurations...")

    results = []
    for i, config in enumerate(configs, 1):
        print(f"\nConfig {i}/{len(configs)}: {config}")
        score = evaluate_config(config, func, bounds, n_runs=5)
        results.append({**config, 'score': score})
        print(f"  Score: {score:.6e}")

    # Create DataFrame and sort
    df = pd.DataFrame(results)
    df_sorted = df.sort_values('score')

    # Save results
    df_sorted.to_csv('example04_tuning_results.csv', index=False)
    print("\n" + "="*70)
    print("BEST CONFIGURATIONS")
    print("="*70)
    print(df_sorted.head(10).to_string(index=False))

    # Visualize impact of each parameter
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    params = ['n_packs', 'init_pack_size', 'use_gradient', 'surrogate_enabled']

    for idx, param in enumerate(params):
        ax = axes[idx // 2, idx % 2]

        grouped = df.groupby(param)['score'].mean()

        ax.bar(grouped.index.astype(str),
               grouped.values, color='coral', alpha=0.7)
        ax.set_xlabel(param, fontsize=11)
        ax.set_ylabel('Mean Score', fontsize=11)
        ax.set_title(f'Impact of {param}', fontsize=12, fontweight='bold')
        ax.set_yscale('log')
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('example04_hyperparameter_impact.png', dpi=300)
    print("\nPlot saved as 'example04_hyperparameter_impact.png'")


if __name__ == "__main__":
    main()
