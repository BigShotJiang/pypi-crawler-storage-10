"""
Example 2: Basic Maximization Problem

Demonstrates maximizing a custom profit function.
"""
# %%
import numpy as np
from coo_algorithm import COO
import matplotlib.pyplot as plt


def profit_function(params):
    """
    Business profit maximization.

    Parameters:
    -----------
    params[0]: price (5-50)
    params[1]: quantity (10-100)
    params[2]: quality (1-10)
    params[3]: marketing spend (0-20)
    params[4]: discount rate (0-0.3)
    """
    price, quantity, quality, marketing, discount = params

    # Revenue model
    base_demand = 100
    demand = base_demand + 2*marketing - 5*discount - 0.5*price + 3*quality
    actual_quantity = min(quantity, demand)

    revenue = price * actual_quantity * (1 - discount)

    # Cost model
    production_cost = 10 * quantity
    quality_cost = 5 * quality**2
    marketing_cost = marketing * 1000

    total_cost = production_cost + quality_cost + marketing_cost

    # Profit
    profit = revenue - total_cost

    return profit


def main():
    print("="*70)
    print("Example 2: Profit Maximization")
    print("="*70)

    # Define bounds
    bounds = [
        (5, 50),      # price
        (10, 100),    # quantity
        (1, 10),      # quality
        (0, 20),      # marketing
        (0, 0.3)      # discount
    ]

    print("\nOptimization Variables:")
    print("  - Price: [5, 50]")
    print("  - Quantity: [10, 100]")
    print("  - Quality: [1, 10]")
    print("  - Marketing: [0, 20]")
    print("  - Discount: [0, 0.3]")

    # Create optimizer
    coo = COO(
        bounds=bounds,
        mode='max',  # Maximization
        max_iterations=150,
        random_state=42,
        verbose=True
    )

    # Optimize
    print("\nRunning optimization...")
    best_params, max_profit, history, diagnostics = coo.optimize(
        profit_function)

    # Results
    print("\n" + "="*70)
    print("OPTIMAL STRATEGY")
    print("="*70)
    print(f"Price: ${best_params[0]:.2f}")
    print(f"Quantity: {best_params[1]:.0f} units")
    print(f"Quality: {best_params[2]:.2f}/10")
    print(f"Marketing: ${best_params[3]:.2f}k")
    print(f"Discount: {best_params[4]*100:.1f}%")
    print(f"\nMaximum Profit: ${max_profit:.2f}")
    print(f"Total evaluations: {diagnostics['cache_size']}")

    # Plot convergence
    plt.figure(figsize=(10, 6))
    plt.plot(history, linewidth=2, color='green')
    plt.xlabel('Iteration', fontsize=12)
    plt.ylabel('Profit ($)', fontsize=12)
    plt.title('Profit Maximization - Convergence',
              fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('example02_convergence.png', dpi=300)
    print("\nPlot saved as 'example02_convergence.png'")


if __name__ == "__main__":
    main()

# %%
