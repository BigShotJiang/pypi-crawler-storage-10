"""
Example scripts demonstrating COO Optimizer usage.

All examples are self-contained and can be run independently.
"""

__all__ = []
