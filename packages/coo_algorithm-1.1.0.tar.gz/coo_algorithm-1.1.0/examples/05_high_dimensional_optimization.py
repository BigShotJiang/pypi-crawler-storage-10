"""
Example 5: High-Dimensional Optimization

Tests COO on problems with 50, 100, and 200 dimensions.
"""

import numpy as np
from coo_optimizer import COO, BenchmarkFunctions
import matplotlib.pyplot as plt
import time


def main():
    print("="*70)
    print("Example 5: High-Dimensional Optimization")
    print("="*70)

    dimensions = [50, 100, 200]
    func = BenchmarkFunctions.sphere

    results = []

    for dim in dimensions:
        print(f"\n{'='*70}")
        print(f"Dimension: {dim}")
        print(f"{'='*70}")

        bounds = BenchmarkFunctions.get_bounds('sphere', dim)

        coo = COO(
            bounds=bounds,
            mode='min',
            n_packs=3,
            init_pack_size=15,
            max_iterations=300,
            surrogate_enabled=True,
            random_state=42,
            verbose=True
        )

        start = time.time()
        best_pos, best_val, history, diag = coo.optimize(func)
        elapsed = time.time() - start

        results.append({
            'dimension': dim,
            'best_value': best_val,
            'evaluations': diag['cache_size'],
            'time': elapsed,
            'history': history
        })

        print(f"\nBest value: {best_val:.8e}")
        print(f"Time: {elapsed:.2f}s")
        print(f"Evaluations: {diag['cache_size']}")

    # Plot convergence for all dimensions
    plt.figure(figsize=(12, 7))

    for result in results:
        plt.semilogy(result['history'], linewidth=2,
                     label=f"{result['dimension']}D")

    plt.xlabel('Iteration', fontsize=12)
    plt.ylabel('Function Value (log scale)', fontsize=12)
    plt.title('High-Dimensional Optimization Convergence',
              fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('example05_high_dim.png', dpi=300)
    print("\nPlot saved as 'example05_high_dim.png'")

    # Summary
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    for result in results:
        print(f"\n{result['dimension']}D:")
        print(f"  Best: {result['best_value']:.8e}")
        print(f"  Time: {result['time']:.2f}s")
        print(f"  Evaluations: {result['evaluations']}")


if __name__ == "__main__":
    main()
