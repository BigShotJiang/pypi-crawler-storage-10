"""
Example 1: Basic Minimization Problem

Demonstrates minimizing the Rosenbrock function in 10 dimensions.
"""
# %%
import numpy as np
from coo_algorithm import COO, BenchmarkFunctions
import matplotlib.pyplot as plt


def main():
    print("="*70)
    print("Example 1: Basic Minimization - Rosenbrock Function")
    print("="*70)

    # Define problem
    func = BenchmarkFunctions.rosenbrock
    bounds = BenchmarkFunctions.get_bounds('rosenbrock', dim=10)
    optimum_pos = BenchmarkFunctions.get_optimum_position('rosenbrock', 10)
    optimum_val = BenchmarkFunctions.get_optimum('rosenbrock')

    print(f"\nProblem: Minimize Rosenbrock function in 10D")
    print(f"Known optimum: {optimum_val} at position (1, 1, ..., 1)")
    print(f"Search bounds: {bounds[0]}")

    # Create optimizer
    coo = COO(
        bounds=bounds,
        mode='min',
        n_packs=2,
        init_pack_size=10,
        max_iterations=200,
        random_state=42,
        verbose=True
    )

    # Optimize
    print("\nRunning optimization...")
    best_pos, best_val, history, diagnostics = coo.optimize(func)

    # Results
    print("\n" + "="*70)
    print("RESULTS")
    print("="*70)
    print(f"Best value found: {best_val:.8f}")
    print(f"Known optimum: {optimum_val:.8f}")
    print(f"Error: {abs(best_val - optimum_val):.8e}")
    print(
        f"Distance from optimum: {np.linalg.norm(best_pos - optimum_pos):.8e}")
    print(f"Total evaluations: {diagnostics['cache_size']}")
    print(f"Convergence: {history[0]:.6f} → {history[-1]:.6f}")

    # Plot convergence
    plt.figure(figsize=(10, 6))
    plt.semilogy(history, linewidth=2)
    plt.xlabel('Iteration', fontsize=12)
    plt.ylabel('Function Value (log scale)', fontsize=12)
    plt.title('Rosenbrock 10D - Convergence', fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('example01_convergence.png', dpi=300)
    print("\nPlot saved as 'example01_convergence.png'")


if __name__ == "__main__":
    main()

# %%
