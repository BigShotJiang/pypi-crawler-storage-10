"""
Example 3: Benchmark Function Comparison

Compares COO performance across multiple standard benchmarks.
"""

import numpy as np
from coo_optimizer import COO, BenchmarkFunctions
import matplotlib.pyplot as plt
import pandas as pd
import time


def run_benchmark(func_name, dim, n_runs=10):
    """Run benchmark and return statistics."""
    func = getattr(BenchmarkFunctions, func_name)
    bounds = BenchmarkFunctions.get_bounds(func_name, dim)
    optimum = BenchmarkFunctions.get_optimum(func_name)

    results = []
    times = []

    for run in range(n_runs):
        coo = COO(
            bounds=bounds,
            mode='min',
            max_iterations=200,
            random_state=42 + run,
            verbose=False
        )

        start = time.time()
        _, best_val, _, diag = coo.optimize(func)
        elapsed = time.time() - start

        results.append(best_val)
        times.append(elapsed)

    return {
        'function': func_name,
        'dimension': dim,
        'mean': np.mean(results),
        'std': np.std(results),
        'best': np.min(results),
        'worst': np.max(results),
        'optimum': optimum,
        'error': np.mean([abs(r - optimum) for r in results]),
        'time': np.mean(times)
    }


def main():
    print("="*70)
    print("Example 3: Benchmark Function Comparison")
    print("="*70)

    # Test configurations
    functions = ['rosenbrock', 'rastrigin', 'ackley', 'griewank']
    dimensions = [10, 20, 30]

    print(
        f"\nTesting {len(functions)} functions in {len(dimensions)} dimensions")
    print(f"Each configuration run 10 times\n")

    all_results = []

    for dim in dimensions:
        print(f"\n{'='*70}")
        print(f"DIMENSION: {dim}")
        print(f"{'='*70}")

        for func_name in functions:
            print(f"\nTesting {func_name.capitalize()}...")
            result = run_benchmark(func_name, dim, n_runs=10)
            all_results.append(result)

            print(f"  Mean: {result['mean']:.6e}")
            print(f"  Best: {result['best']:.6e}")
            print(f"  Error: {result['error']:.6e}")
            print(f"  Time: {result['time']:.3f}s")

    # Create DataFrame
    df = pd.DataFrame(all_results)

    # Save results
    df.to_csv('example03_results.csv', index=False)
    print("\n" + "="*70)
    print("Results saved to 'example03_results.csv'")

    # Create visualization
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    for idx, func_name in enumerate(functions):
        ax = axes[idx // 2, idx % 2]

        subset = df[df['function'] == func_name]

        ax.bar(subset['dimension'].astype(str), subset['error'],
               color='steelblue', alpha=0.7)
        ax.set_xlabel('Dimension', fontsize=11)
        ax.set_ylabel('Mean Error from Optimum', fontsize=11)
        ax.set_title(func_name.capitalize(), fontsize=12, fontweight='bold')
        ax.set_yscale('log')
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('example03_comparison.png', dpi=300)
    print("Plot saved as 'example03_comparison.png'")

    # Summary table
    print("\n" + "="*70)
    print("SUMMARY TABLE")
    print("="*70)
    print(df[['function', 'dimension', 'error', 'time']].to_string(index=False))


if __name__ == "__main__":
    main()
