# Canine Olfactory Optimizer (COO)

"""

# Canine Olfactory Optimization (COO)

A nature-inspired metaheuristic optimization algorithm based on the olfactory tracking behavior of canines.

## Features

- Bio-inspired algorithm based on canine pack hunting
- Surrogate-assisted optimization for expensive functions
- Multi-pack architecture for diverse exploration
- Adaptive population sizing
- Easy-to-use API

## Installation

```bash
pip install coo-optimizer
```

## Quick Start

```python
from coo_optimizer import CanineOlfactoryOptimization
import numpy as np

# Define your objective function (to maximize)
def sphere(x):
    return -np.sum(x**2)

# Set bounds
bounds = [(-5, 5)] * 10  # 10-dimensional problem

# Create optimizer
coo = CanineOlfactoryOptimization(
    bounds=bounds,
    n_packs=2,
    init_pack_size=10,
    max_iterations=100,
    random_state=42
)

# Optimize
best_position, best_fitness, history, diagnostics = coo.optimize(sphere)

print(f"Best fitness: {best_fitness}")
print(f"Best position: {best_position}")
```

## Testing

Run tests with pytest:

```bash
pytest tests/ -v --cov=coo_optimizer
```

## License

MIT License
"""
