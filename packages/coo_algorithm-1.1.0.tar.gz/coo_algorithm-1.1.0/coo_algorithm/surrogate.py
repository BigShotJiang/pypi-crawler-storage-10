"""
Surrogate Model Ensemble for COO Algorithm

This module provides surrogate models for computational efficiency in
expensive optimization problems.

Author: Sandip Garai
License: MIT
"""

import numpy as np
from typing import List, Tuple, Optional
from joblib import Parallel, delayed
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor


class SurrogateEnsemble:
    """
    Ensemble of surrogate models for fitness approximation.

    Uses Random Forest and Gradient Boosting regressors to create
    inexpensive approximations of expensive objective functions.

    Parameters
    ----------
    kind : str, default='ensemble'
        Type of surrogate: 'rf' (Random Forest only), 'gb' (Gradient Boosting only),
        or 'ensemble' (both models averaged).

    random_state : int, optional
        Random seed for reproducibility.

    n_jobs : int, default=-1
        Number of parallel jobs for training. -1 uses all processors.

    Attributes
    ----------
    models : List[Tuple[str, object]]
        List of (name, trained_model) tuples.

    Examples
    --------
    >>> import numpy as np
    >>> from coo_optimizer.surrogate import SurrogateEnsemble
    >>> 
    >>> # Generate training data
    >>> X_train = np.random.randn(100, 5)
    >>> y_train = np.sum(X_train**2, axis=1)
    >>> 
    >>> # Train surrogate
    >>> surrogate = SurrogateEnsemble(kind='ensemble', random_state=42)
    >>> surrogate.fit(X_train, y_train)
    >>> 
    >>> # Make predictions
    >>> X_test = np.random.randn(10, 5)
    >>> predictions = surrogate.predict(X_test)
    >>> print(f"Predictions shape: {predictions.shape}")

    Notes
    -----
    The ensemble approach reduces prediction variance compared to single models.
    Random Forest is robust to overfitting, while Gradient Boosting captures
    complex patterns. Their average provides balanced predictions.
    """

    def __init__(
        self,
        kind: str = 'ensemble',
        random_state: Optional[int] = 42,
        n_jobs: int = -1
    ):
        """
        Initialize surrogate ensemble.

        Parameters
        ----------
        kind : str
            'rf', 'gb', or 'ensemble'
        random_state : int, optional
            Random seed
        n_jobs : int
            Parallel jobs for training
        """
        if kind not in ['rf', 'gb', 'ensemble']:
            raise ValueError("kind must be 'rf', 'gb', or 'ensemble'")

        self.kind = kind
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.models = []

    def fit(self, X: np.ndarray, y: np.ndarray) -> 'SurrogateEnsemble':
        """
        Train surrogate models on provided data.

        Parameters
        ----------
        X : np.ndarray, shape (n_samples, n_features)
            Training feature vectors.

        y : np.ndarray, shape (n_samples,)
            Training target values (fitness scores).

        Returns
        -------
        self : SurrogateEnsemble
            Fitted surrogate ensemble.

        Raises
        ------
        ValueError
            If X and y have incompatible shapes.

        Examples
        --------
        >>> X = np.random.randn(50, 3)
        >>> y = np.sum(X**2, axis=1)
        >>> surrogate = SurrogateEnsemble(kind='ensemble')
        >>> surrogate.fit(X, y)
        >>> print(f"Trained {len(surrogate.models)} models")
        """
        if X.shape[0] != y.shape[0]:
            raise ValueError(
                f"X and y must have same length: {X.shape[0]} vs {y.shape[0]}")

        if X.shape[0] < 10:
            raise ValueError(f"Need at least 10 samples, got {X.shape[0]}")

        jobs = []

        if self.kind in ('rf', 'ensemble'):
            jobs.append(('rf', RandomForestRegressor(
                n_estimators=80,
                n_jobs=1,
                random_state=self.random_state,
                max_depth=15,
                min_samples_split=2,
                min_samples_leaf=1
            )))

        if self.kind in ('gb', 'ensemble'):
            jobs.append(('gb', GradientBoostingRegressor(
                n_estimators=150,
                learning_rate=0.1,
                max_depth=5,
                random_state=self.random_state,
                subsample=0.8
            )))

        def _fit_one(item):
            """Fit a single model."""
            name, model = item
            model.fit(X, y)
            return (name, model)

        # Parallel training
        n_parallel = min(len(jobs), abs(self.n_jobs)
                         if self.n_jobs != -1 else 2)
        self.models = Parallel(n_jobs=n_parallel)(
            delayed(_fit_one)(item) for item in jobs
        )

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict fitness values for given feature vectors.

        Parameters
        ----------
        X : np.ndarray, shape (n_samples, n_features)
            Feature vectors to predict.

        Returns
        -------
        predictions : np.ndarray, shape (n_samples,)
            Predicted fitness values (ensemble average).

        Raises
        ------
        RuntimeError
            If surrogate has not been trained yet.

        Examples
        --------
        >>> X_train = np.random.randn(50, 3)
        >>> y_train = np.sum(X_train**2, axis=1)
        >>> surrogate = SurrogateEnsemble().fit(X_train, y_train)
        >>> 
        >>> X_test = np.random.randn(10, 3)
        >>> predictions = surrogate.predict(X_test)
        >>> print(f"Predicted {len(predictions)} values")
        """
        if not self.models:
            raise RuntimeError(
                "Surrogate not trained. Call fit() first before making predictions."
            )

        predictions = []
        for name, model in self.models:
            predictions.append(model.predict(X))

        # Return ensemble average
        predictions = np.vstack(predictions)
        return predictions.mean(axis=0)

    def get_feature_importance(self) -> Optional[np.ndarray]:
        """
        Get feature importance scores from trained models.

        Returns
        -------
        importance : np.ndarray or None
            Average feature importance across models, or None if not trained.

        Examples
        --------
        >>> X = np.random.randn(50, 5)
        >>> y = X[:, 0]**2 + 2*X[:, 1]  # y depends mainly on features 0 and 1
        >>> surrogate = SurrogateEnsemble(kind='rf').fit(X, y)
        >>> importance = surrogate.get_feature_importance()
        >>> print(f"Most important feature: {np.argmax(importance)}")
        """
        if not self.models:
            return None

        importances = []
        for name, model in self.models:
            if hasattr(model, 'feature_importances_'):
                importances.append(model.feature_importances_)

        if importances:
            return np.mean(importances, axis=0)
        return None

    def score(self, X: np.ndarray, y: np.ndarray) -> float:
        """
        Calculate R² score on test data.

        Parameters
        ----------
        X : np.ndarray
            Test features.
        y : np.ndarray
            True target values.

        Returns
        -------
        r2_score : float
            Coefficient of determination R².

        Examples
        --------
        >>> X_train = np.random.randn(50, 3)
        >>> y_train = np.sum(X_train**2, axis=1)
        >>> X_test = np.random.randn(20, 3)
        >>> y_test = np.sum(X_test**2, axis=1)
        >>> 
        >>> surrogate = SurrogateEnsemble().fit(X_train, y_train)
        >>> r2 = surrogate.score(X_test, y_test)
        >>> print(f"R² score: {r2:.4f}")
        """
        if not self.models:
            raise RuntimeError("Surrogate not trained. Call fit() first.")

        y_pred = self.predict(X)

        # Calculate R²
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)

        if ss_tot == 0:
            return 0.0

        return 1 - (ss_res / ss_tot)

    def __repr__(self) -> str:
        """String representation."""
        status = "trained" if self.models else "untrained"
        n_models = len(self.models)
        return f"SurrogateEnsemble(kind='{self.kind}', status='{status}', n_models={n_models})"
