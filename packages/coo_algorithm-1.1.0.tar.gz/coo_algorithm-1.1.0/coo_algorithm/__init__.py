"""
Canine Olfactory Optimization (COO) Algorithm

A nature-inspired metaheuristic optimization algorithm based on the
olfactory tracking behavior of canines.

"""
__version__ = "1.1.0"
__author__ = "Sandip Garai"
__email__ = "sandipnicksandy@gmail.com"

from .core import CanineOlfactoryOptimization, COO
from .surrogate import SurrogateEnsemble
from .benchmarks import BenchmarkFunctions

__all__ = [
    'CanineOlfactoryOptimization',
    'COO',
    'SurrogateEnsemble',
    'BenchmarkFunctions'
]
