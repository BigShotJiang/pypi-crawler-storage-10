"""
Integration tests for complete workflows
"""

import pytest
import numpy as np
from coo_optimizer import CanineOlfactoryOptimization, BenchmarkFunctions


class TestIntegration:
    """Integration tests"""

    @pytest.mark.parametrize("func_name", ['rosenbrock', 'rastrigin', 'ackley', 'griewank'])
    @pytest.mark.parametrize("dim", [5, 10])
    def test_optimize_benchmark_functions(self, func_name, dim):
        """Test COO on all benchmark functions"""
        func = getattr(BenchmarkFunctions, func_name)
        bounds = BenchmarkFunctions.get_bounds(func_name, dim)

        coo = CanineOlfactoryOptimization(
            bounds=bounds,
            max_iterations=50,
            random_state=42,
            verbose=False
        )

        best_pos, best_fit, history, diagnostics = coo.optimize(func)

        # Basic checks
        assert best_pos is not None
        assert len(best_pos) == dim
        assert best_fit is not None
        assert len(history) == 50
        assert 'cache_size' in diagnostics

        # Should improve over iterations
        assert history[-1] >= history[0]

    def test_multiple_runs_consistency(self):
        """Test that multiple runs produce consistent results"""
        bounds = [(-5, 5)] * 5

        def sphere(x):
            return -np.sum(x**2)

        results = []
        for seed in range(5):
            coo = CanineOlfactoryOptimization(
                bounds=bounds,
                max_iterations=50,
                random_state=seed,
                verbose=False
            )
            _, best_fit, _, _ = coo.optimize(sphere)
            results.append(best_fit)

        # All runs should find good solutions
        assert all(fit > -1.0 for fit in results)

        # Variance should be reasonable
        assert np.std(results) < 0.5

    def test_high_dimensional_optimization(self):
        """Test optimization in high dimensions"""
        dim = 50
        bounds = [(-5, 5)] * dim

        def sphere(x):
            return -np.sum(x**2)

        coo = CanineOlfactoryOptimization(
            bounds=bounds,
            n_packs=3,
            init_pack_size=15,
            max_iterations=100,
            random_state=42,
            verbose=False
        )

        best_pos, best_fit, _, _ = coo.optimize(sphere)

        assert len(best_pos) == dim
        # Should get reasonable solution even in high dimensions
        assert best_fit > -dim * 2
