"""
Tests for benchmark functions
"""

import pytest
import numpy as np
from coo_optimizer import BenchmarkFunctions


class TestBenchmarkFunctions:
    """Test suite for benchmark functions"""

    def test_rosenbrock_optimum(self):
        """Test Rosenbrock function at optimum"""
        x_opt = np.ones(5)
        result = BenchmarkFunctions.rosenbrock(x_opt)
        assert abs(result - 0.0) < 1e-6

    def test_rastrigin_optimum(self):
        """Test Rastrigin function at optimum"""
        x_opt = np.zeros(5)
        result = BenchmarkFunctions.rastrigin(x_opt)
        assert abs(result - 0.0) < 1e-6

    def test_ackley_optimum(self):
        """Test Ackley function at optimum"""
        x_opt = np.zeros(5)
        result = BenchmarkFunctions.ackley(x_opt)
        assert abs(result - 0.0) < 1e-6

    def test_griewank_optimum(self):
        """Test Griewank function at optimum"""
        x_opt = np.zeros(5)
        result = BenchmarkFunctions.griewank(x_opt)
        assert abs(result - 0.0) < 1e-6

    def test_get_bounds(self):
        """Test bounds retrieval"""
        bounds_ros = BenchmarkFunctions.get_bounds('rosenbrock', 3)
        assert len(bounds_ros) == 3
        assert all(b == (-5, 10) for b in bounds_ros)

        bounds_ras = BenchmarkFunctions.get_bounds('rastrigin', 3)
        assert len(bounds_ras) == 3
        assert all(b == (-5.12, 5.12) for b in bounds_ras)

    def test_get_optimum(self):
        """Test optimum value retrieval"""
        for func_name in ['rosenbrock', 'rastrigin', 'ackley', 'griewank']:
            opt = BenchmarkFunctions.get_optimum(func_name)
            assert opt == 0.0

    def test_function_shapes(self):
        """Test that functions accept different dimensions"""
        for func_name in ['rosenbrock', 'rastrigin', 'ackley', 'griewank']:
            func = getattr(BenchmarkFunctions, func_name)

            for dim in [2, 5, 10]:
                x = np.random.randn(dim)
                result = func(x)
                assert isinstance(result, (int, float, np.number))
