"""
Core functionality tests for COO algorithm
"""

import pytest
import numpy as np
from coo_optimizer import CanineOlfactoryOptimization, COO


class TestCanineOlfactoryOptimization:
    """Test suite for COO algorithm"""

    @pytest.fixture
    def simple_bounds(self):
        """Simple 2D bounds for testing"""
        return [(-5, 5), (-5, 5)]

    @pytest.fixture
    def sphere_function(self):
        """Simple sphere function: f(x) = -sum(x^2)"""
        def sphere(x):
            return -np.sum(x**2)
        return sphere

    def test_initialization(self, simple_bounds):
        """Test COO initialization"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            n_packs=2,
            init_pack_size=10,
            max_iterations=50,
            random_state=42
        )

        assert coo.dim == 2
        assert coo.n_packs == 2
        assert coo.init_pack_size == 10
        assert coo.max_iterations == 50
        assert coo.best_fitness == -np.inf
        assert coo.best_position is None

    def test_bounds_validation(self, simple_bounds):
        """Test bounds are correctly set"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds, random_state=42)

        np.testing.assert_array_equal(coo.lower, [-5, -5])
        np.testing.assert_array_equal(coo.upper, [5, 5])

    def test_optimize_converges(self, simple_bounds, sphere_function):
        """Test that optimization converges to near-optimal solution"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            n_packs=2,
            init_pack_size=10,
            max_iterations=100,
            random_state=42,
            verbose=False
        )

        best_pos, best_fit, history, diagnostics = coo.optimize(
            sphere_function)

        # Check outputs
        assert best_pos is not None
        assert len(best_pos) == 2
        assert best_fit > -1.0  # Should be close to 0 (optimum is 0)
        assert len(history) == 100
        assert 'cache_size' in diagnostics

        # Check convergence
        assert history[-1] >= history[0]  # Fitness should improve

        # Check solution quality (should be near [0, 0])
        assert np.linalg.norm(best_pos) < 1.0

    def test_caching_mechanism(self, simple_bounds):
        """Test evaluation caching works"""
        call_count = [0]

        def counted_function(x):
            call_count[0] += 1
            return -np.sum(x**2)

        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            n_packs=1,
            init_pack_size=5,
            max_iterations=10,
            random_state=42,
            verbose=False
        )

        coo.optimize(counted_function)

        # Cache should reduce total function calls
        assert len(coo.evaluation_cache) > 0
        assert call_count[0] >= len(coo.evaluation_cache)

    def test_reproducibility(self, simple_bounds, sphere_function):
        """Test that same random seed produces same results"""
        coo1 = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            random_state=42,
            max_iterations=50,
            verbose=False
        )
        best_pos1, best_fit1, _, _ = coo1.optimize(sphere_function)

        coo2 = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            random_state=42,
            max_iterations=50,
            verbose=False
        )
        best_pos2, best_fit2, _, _ = coo2.optimize(sphere_function)

        np.testing.assert_array_almost_equal(best_pos1, best_pos2, decimal=6)
        assert abs(best_fit1 - best_fit2) < 1e-6

    def test_different_dimensions(self):
        """Test COO works with different dimensions"""
        for dim in [2, 5, 10, 20]:
            bounds = [(-5, 5)] * dim

            def sphere(x):
                return -np.sum(x**2)

            coo = CanineOlfactoryOptimization(
                bounds=bounds,
                max_iterations=50,
                random_state=42,
                verbose=False
            )

            best_pos, best_fit, _, _ = coo.optimize(sphere)

            assert len(best_pos) == dim
            assert best_fit > -dim * 5  # Reasonable bound

    def test_gradient_refinement(self, simple_bounds, sphere_function):
        """Test gradient refinement improves solution"""
        coo_no_grad = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            use_gradient=False,
            max_iterations=50,
            random_state=42,
            verbose=False
        )
        _, fit_no_grad, _, _ = coo_no_grad.optimize(sphere_function)

        coo_with_grad = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            use_gradient=True,
            max_iterations=50,
            random_state=42,
            verbose=False
        )
        _, fit_with_grad, _, _ = coo_with_grad.optimize(sphere_function)

        # Gradient should help (though not guaranteed on every run)
        # So we just test that it runs without error
        assert fit_with_grad is not None

    def test_adaptive_pack_sizing(self, simple_bounds, sphere_function):
        """Test adaptive pack sizing reduces pack size on stagnation"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            n_packs=2,
            init_pack_size=15,
            min_pack_size=8,
            use_adaptive_pack=True,
            max_iterations=100,
            random_state=42,
            verbose=False
        )

        _, _, _, diagnostics = coo.optimize(sphere_function)

        # Check that pack sizes may have reduced
        final_sizes = diagnostics['final_pack_sizes']
        assert all(size >= 8 for size in final_sizes)
        assert all(size <= 15 for size in final_sizes)

    def test_surrogate_integration(self, simple_bounds, sphere_function):
        """Test surrogate-assisted optimization runs"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            surrogate_enabled=True,
            surrogate_min_samples=20,
            surrogate_retrain_freq=5,
            max_iterations=50,
            random_state=42,
            verbose=False
        )

        best_pos, best_fit, _, _ = coo.optimize(sphere_function)

        assert best_pos is not None
        assert best_fit > -10.0

    def test_elitist_exchange(self, simple_bounds, sphere_function):
        """Test elitist exchange mechanism"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            n_packs=3,
            use_elitist=True,
            elitist_exchange_freq=5,
            max_iterations=50,
            random_state=42,
            verbose=False
        )

        _, _, history, _ = coo.optimize(sphere_function)

        # Should converge
        assert history[-1] >= history[0]

    def test_clip_population(self, simple_bounds):
        """Test population clipping to bounds"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds, random_state=42)

        # Create out-of-bounds population
        population = np.array([
            [-10, 10],
            [0, 0],
            [10, -10]
        ])

        clipped = coo._clip_population(population)

        assert np.all(clipped >= coo.lower)
        assert np.all(clipped <= coo.upper)

    def test_convergence_history(self, simple_bounds, sphere_function):
        """Test convergence history is properly recorded"""
        coo = CanineOlfactoryOptimization(
            bounds=simple_bounds,
            max_iterations=50,
            random_state=42,
            verbose=False
        )

        _, _, history, _ = coo.optimize(sphere_function)

        assert len(history) == 50
        assert all(isinstance(h, (int, float)) for h in history)
        # Should be non-decreasing (maximization)
        for i in range(1, len(history)):
            assert history[i] >= history[i-1] - 1e-10  # Small tolerance

    def test_invalid_bounds(self):
        """Test error handling for invalid bounds"""
        with pytest.raises((ValueError, IndexError)):
            coo = CanineOlfactoryOptimization(bounds=[])

    def test_alias_coo(self, simple_bounds, sphere_function):
        """Test COO alias works"""
        coo = COO(bounds=simple_bounds, max_iterations=10,
                  random_state=42, verbose=False)
        best_pos, best_fit, _, _ = coo.optimize(sphere_function)

        assert best_pos is not None
        assert best_fit is not None
