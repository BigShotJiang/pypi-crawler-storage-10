"""
Tests for COO Optimization package
"""

__version__ = "2.1.0"
