"""
Tests for surrogate model ensemble
"""

import pytest
import numpy as np
from coo_optimizer import SurrogateEnsemble


class TestSurrogateEnsemble:
    """Test suite for surrogate models"""

    @pytest.fixture
    def sample_data(self):
        """Generate sample training data"""
        np.random.seed(42)
        X = np.random.randn(100, 5)
        y = np.sum(X**2, axis=1)
        return X, y

    def test_initialization(self):
        """Test surrogate initialization"""
        surrogate = SurrogateEnsemble(kind='ensemble', random_state=42)
        assert surrogate.kind == 'ensemble'
        assert surrogate.random_state == 42
        assert len(surrogate.models) == 0

    def test_fit_rf(self, sample_data):
        """Test fitting Random Forest"""
        X, y = sample_data
        surrogate = SurrogateEnsemble(kind='rf', random_state=42)
        surrogate.fit(X, y)

        assert len(surrogate.models) == 1
        assert surrogate.models[0][0] == 'rf'

    def test_fit_gb(self, sample_data):
        """Test fitting Gradient Boosting"""
        X, y = sample_data
        surrogate = SurrogateEnsemble(kind='gb', random_state=42)
        surrogate.fit(X, y)

        assert len(surrogate.models) == 1
        assert surrogate.models[0][0] == 'gb'

    def test_fit_ensemble(self, sample_data):
        """Test fitting ensemble"""
        X, y = sample_data
        surrogate = SurrogateEnsemble(kind='ensemble', random_state=42)
        surrogate.fit(X, y)

        assert len(surrogate.models) == 2
        model_names = [name for name, _ in surrogate.models]
        assert 'rf' in model_names
        assert 'gb' in model_names

    def test_predict(self, sample_data):
        """Test prediction"""
        X, y = sample_data
        surrogate = SurrogateEnsemble(kind='ensemble', random_state=42)
        surrogate.fit(X, y)

        X_test = np.random.randn(10, 5)
        predictions = surrogate.predict(X_test)

        assert len(predictions) == 10
        assert all(isinstance(p, (int, float, np.number)) for p in predictions)

    def test_predict_before_fit(self):
        """Test error when predicting before fitting"""
        surrogate = SurrogateEnsemble(random_state=42)
        X_test = np.random.randn(10, 5)

        with pytest.raises(RuntimeError):
            surrogate.predict(X_test)

    def test_prediction_accuracy(self, sample_data):
        """Test that surrogate makes reasonable predictions"""
        X, y = sample_data
        surrogate = SurrogateEnsemble(kind='ensemble', random_state=42)
        surrogate.fit(X, y)

        # Predict on training data
        y_pred = surrogate.predict(X)

        # Calculate R^2
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        r2 = 1 - (ss_res / ss_tot)

        # Should have decent fit on training data
        assert r2 > 0.8
