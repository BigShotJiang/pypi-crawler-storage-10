"""Agent flow management utilities."""
import os
import sys
from typing import Any

def get_flow_variable(
    variable_name:str = None,
    default_value:Any = None
) -> Any:
    """Retrieve flow variable"""
    try:
        run_id = sys.argv[1]
        payload_file_path = sys.argv[2]
        payload = None

        if not os.path.exists(payload_file_path):
            return None

        with open(payload_file_path, 'r') as f:
            payload = json.load(f)

        if not payload:
            return None

        if variable_name:
            if variable_name in payload:
                return payload[variable_name]
            return default_value
            
        return payload
        
    except Exception:
        return None


__all__ = [
    "get_flow_variable",
]
