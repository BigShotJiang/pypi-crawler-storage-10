Curve benchmark demo 2
~~~~~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/curvebenchmark2.png

.. literalinclude:: /../qwt/tests/test_curvebenchmark2.py
   :start-after: SHOW
