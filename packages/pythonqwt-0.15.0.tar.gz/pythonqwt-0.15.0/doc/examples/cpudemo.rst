CPU plot demo
~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/cpudemo.png

.. literalinclude:: /../qwt/tests/test_cpudemo.py
   :start-after: SHOW
