Error bar demo
~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/errorbar.png

.. literalinclude:: /../qwt/tests/test_errorbar.py
   :start-after: SHOW
