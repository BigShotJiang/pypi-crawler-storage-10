Image plot demo
~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/image.png

.. literalinclude:: /../qwt/tests/test_image.py
   :start-after: SHOW
