Cartesian demo
~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/cartesian.png

.. literalinclude:: /../qwt/tests/test_cartesian.py
   :start-after: SHOW
