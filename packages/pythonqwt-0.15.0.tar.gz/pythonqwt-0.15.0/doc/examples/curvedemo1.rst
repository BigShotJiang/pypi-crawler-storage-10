Curve demo 1
~~~~~~~~~~~~

.. image:: /../qwt/tests/data/curvedemo1.png

.. literalinclude:: /../qwt/tests/test_curvedemo1.py
   :start-after: SHOW
