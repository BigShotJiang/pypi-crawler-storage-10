Really simple demo
~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/simple.png

.. literalinclude:: /../qwt/tests/test_simple.py
   :start-after: SHOW
