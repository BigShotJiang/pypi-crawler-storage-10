Curve demo 2
~~~~~~~~~~~~

.. image:: /../qwt/tests/data/curvedemo2.png

.. literalinclude:: /../qwt/tests/test_curvedemo2.py
   :start-after: SHOW
