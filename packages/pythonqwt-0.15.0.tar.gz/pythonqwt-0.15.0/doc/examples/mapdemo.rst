Map demo
~~~~~~~~

.. image:: /../qwt/tests/data/mapdemo.png

.. literalinclude:: /../qwt/tests/test_mapdemo.py
   :start-after: SHOW
