Data demo
~~~~~~~~~

.. image:: /../qwt/tests/data/data.png

.. literalinclude:: /../qwt/tests/test_data.py
   :start-after: SHOW
