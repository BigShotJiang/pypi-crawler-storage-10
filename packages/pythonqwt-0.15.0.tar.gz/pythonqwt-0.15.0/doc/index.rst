.. automodule:: qwt

Contents:

.. toctree::
    :maxdepth: 2
    
    overview
    installation
    examples/index
    reference/index
    

Indices and tables:

* :ref:`genindex`
* :ref:`search`
