.. automodule:: qwt.graphic
