.. automodule:: qwt.interval
