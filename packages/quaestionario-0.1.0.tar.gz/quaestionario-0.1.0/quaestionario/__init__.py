"""
Quaestionario - A Python package for managing questionnaires as weakly connected rooted directed acyclic graphs.

This package provides powerful tools for creating, validating, and analyzing complex questionnaires
with conditional branching and dependencies.
"""

from .models import (
    Questionnaire,
    Question,
    BooleanQuestion,
    TextShortQuestion,
    TextLongQuestion,
    NumberQuestion,
    DateTimeQuestion,
    ScaleQuestion,
    SingleChoiceQuestion,
    MultiChoiceQuestion,
    Condition,
    Option,
)
from .graph import QuestionnaireGraph
from .analyzer import QuestionnaireAnalyzer
from .validation import (
    AnswerValidator,
    ValidationResult,
    ValidationError,
    validate_answer,
)
from .io import (
    load_questionnaire,
    save_questionnaire,
    loads_questionnaire,
    dumps_questionnaire,
    list_formats,
    register_format,
    FormatHandler,
)

__version__ = "0.1.0"
__all__ = [
    "Questionnaire",
    "Question",
    "BooleanQuestion",
    "TextShortQuestion",
    "TextLongQuestion",
    "NumberQuestion",
    "DateTimeQuestion",
    "ScaleQuestion",
    "SingleChoiceQuestion",
    "MultiChoiceQuestion",
    "Condition",
    "Option",
    "QuestionnaireGraph",
    "QuestionnaireAnalyzer",
    "AnswerValidator",
    "ValidationResult",
    "ValidationError",
    "validate_answer",
    "load_questionnaire",
    "save_questionnaire",
    "loads_questionnaire",
    "dumps_questionnaire",
    "list_formats",
    "register_format",
    "FormatHandler",
]