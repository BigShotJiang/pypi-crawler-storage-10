"""
Graph validation and navigation logic for questionnaire DAG structure.
"""

from typing import Set, Dict, List, Optional, Tuple, Any
from collections import defaultdict, deque
from .models import Questionnaire, Question, Option, SingleChoiceQuestion, MultiChoiceQuestion


class QuestionnaireGraph:
    """
    Represents and validates a questionnaire as a directed acyclic graph.
    """

    def __init__(self, questionnaire: Questionnaire):
        self.questionnaire = questionnaire
        self.question_map = {q.id: q for q in questionnaire.questions}
        self._adjacency_list = self._build_adjacency_list()
        self._reverse_adjacency_list = self._build_reverse_adjacency_list()

    def _build_adjacency_list(self) -> Dict[str, Set[str]]:
        """Build adjacency list representing edges from each question to its possible next questions."""
        adj_list = defaultdict(set)

        for question in self.questionnaire.questions:
            # Add default_next if it exists
            if question.default_next:
                adj_list[question.id].add(question.default_next)

            # Add option-specific next questions for choice questions
            if isinstance(question, (SingleChoiceQuestion, MultiChoiceQuestion)):
                for option in question.options:
                    if option.next:
                        adj_list[question.id].add(option.next)

        return dict(adj_list)

    def _build_reverse_adjacency_list(self) -> Dict[str, Set[str]]:
        """Build reverse adjacency list for dependency tracking."""
        reverse_adj = defaultdict(set)

        for question_id, next_questions in self._adjacency_list.items():
            for next_q in next_questions:
                reverse_adj[next_q].add(question_id)

        return dict(reverse_adj)

    def validate_dag(self) -> Tuple[bool, List[str]]:
        """
        Validate that the questionnaire forms a valid DAG.
        Returns (is_valid, errors).
        """
        errors = []

        # Check for cycles using DFS
        if self._has_cycles():
            errors.append("Questionnaire contains cycles")

        # Check that all referenced questions exist
        all_question_ids = set(self.question_map.keys())
        for question in self.questionnaire.questions:
            # Check default_next references
            if question.default_next and question.default_next not in all_question_ids:
                errors.append(f"Question '{question.id}' references non-existent question '{question.default_next}' in default_next")

            # Check option next references
            if isinstance(question, (SingleChoiceQuestion, MultiChoiceQuestion)):
                for option in question.options:
                    if option.next and option.next not in all_question_ids:
                        errors.append(f"Question '{question.id}' option '{option.label}' references non-existent question '{option.next}'")

            # Check condition references
            if question.conditions:
                for condition in question.conditions:
                    if condition.question not in all_question_ids:
                        errors.append(f"Question '{question.id}' condition references non-existent question '{condition.question}'")

        # Check that start_question exists
        if self.questionnaire.start_question not in all_question_ids:
            errors.append(f"start_question '{self.questionnaire.start_question}' does not exist")

        return len(errors) == 0, errors

    def _has_cycles(self) -> bool:
        """Check for cycles using DFS with color marking."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color = defaultdict(lambda: WHITE)

        def dfs(node):
            if color[node] == GRAY:  # Back edge found, cycle detected
                return True
            if color[node] == BLACK:  # Already processed
                return False

            color[node] = GRAY
            for neighbor in self._adjacency_list.get(node, []):
                if dfs(neighbor):
                    return True
            color[node] = BLACK
            return False

        for question_id in self.question_map.keys():
            if color[question_id] == WHITE:
                if dfs(question_id):
                    return True
        return False

    def get_reachable_questions(self, start_question_id: str) -> Set[str]:
        """Get all questions reachable from a given starting question."""
        if start_question_id not in self.question_map:
            return set()

        visited = set()
        queue = deque([start_question_id])

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)

            for next_q in self._adjacency_list.get(current, []):
                if next_q not in visited:
                    queue.append(next_q)

        return visited

    def get_unreachable_questions(self) -> Set[str]:
        """Get questions that are not reachable from the start question."""
        reachable = self.get_reachable_questions(self.questionnaire.start_question)
        all_questions = set(self.question_map.keys())
        return all_questions - reachable

    def get_terminal_questions(self) -> Set[str]:
        """Get questions that have no outgoing edges (leaf nodes)."""
        return {q_id for q_id in self.question_map.keys()
                if not self._adjacency_list.get(q_id)}

    def get_dependencies(self, question_id: str) -> Set[str]:
        """Get all questions that this question depends on (through conditions)."""
        if question_id not in self.question_map:
            return set()

        question = self.question_map[question_id]
        dependencies = set()

        if question.conditions:
            for condition in question.conditions:
                dependencies.add(condition.question)
                # Recursively get dependencies of dependencies
                dependencies.update(self.get_dependencies(condition.question))

        return dependencies

    def get_dependent_questions(self, question_id: str) -> Set[str]:
        """Get all questions that depend on this question (through conditions)."""
        dependents = set()

        for q_id, question in self.question_map.items():
            if question.conditions:
                for condition in question.conditions:
                    if condition.question == question_id:
                        dependents.add(q_id)

        return dependents

    def is_weakly_connected(self) -> bool:
        """Check if the questionnaire graph is weakly connected."""
        if not self.question_map:
            return True

        # For weak connectivity, we need to check if the underlying undirected graph is connected
        # Create undirected adjacency list
        undirected_adj = defaultdict(set)
        for q_id, next_questions in self._adjacency_list.items():
            for next_q in next_questions:
                undirected_adj[q_id].add(next_q)
                undirected_adj[next_q].add(q_id)

        # Add all isolated nodes
        for q_id in self.question_map.keys():
            if q_id not in undirected_adj:
                undirected_adj[q_id] = set()

        # BFS to check connectivity
        start_node = next(iter(self.question_map.keys()))
        visited = set()
        queue = deque([start_node])

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)

            for neighbor in undirected_adj[current]:
                if neighbor not in visited:
                    queue.append(neighbor)

        return len(visited) == len(self.question_map)

    def get_next_questions(self, question_id: str) -> Set[str]:
        """Get the immediate next questions from a given question."""
        return self._adjacency_list.get(question_id, set()).copy()

    def get_next_question_for_answer(self, question_id: str, answer_value: Any) -> Optional[str]:
        """Get the specific next question based on the answer given to a question."""
        if question_id not in self.question_map:
            return None

        question = self.question_map[question_id]

        # For choice questions, check if the answer matches an option with a next question
        if isinstance(question, (SingleChoiceQuestion, MultiChoiceQuestion)):
            for option in question.options:
                if option.value == answer_value and option.next:
                    return option.next

        # Fall back to default_next if no option-specific navigation
        return question.default_next

    def get_previous_questions(self, question_id: str) -> Set[str]:
        """Get questions that can directly lead to this question."""
        return self._reverse_adjacency_list.get(question_id, set()).copy()