"""
Advanced questionnaire analysis for AI-powered insights.
"""

from typing import Set, Dict, List, Optional, Any, Tuple
from collections import defaultdict, deque
from .models import (
    Questionnaire, Question, Condition, ConditionOperator,
    BooleanQuestion, SingleChoiceQuestion, MultiChoiceQuestion
)
from .graph import QuestionnaireGraph


class QuestionnaireAnalyzer:
    """
    Provides advanced analysis capabilities for questionnaire intelligence.
    """

    def __init__(self, questionnaire: Questionnaire):
        self.questionnaire = questionnaire
        self.graph = QuestionnaireGraph(questionnaire)
        self.question_map = {q.id: q for q in questionnaire.questions}

    def get_always_required_questions(self, current_answers: Dict[str, Any]) -> Set[str]:
        """
        Identify questions that MUST be asked based on current answers,
        regardless of future answers. A question is always required if it appears
        in ALL possible completion paths from the current state.
        """
        # Get all possible paths from current state
        possible_paths = self._get_possible_paths_from_current_state(current_answers)

        if not possible_paths:
            return set()

        # Find questions that appear in ALL paths
        always_required = set(possible_paths[0])  # Start with first path
        for path in possible_paths[1:]:
            always_required &= set(path)  # Intersection with each subsequent path

        # Remove already answered questions
        always_required -= set(current_answers.keys())

        return always_required

    def get_optimal_next_questions(self, current_answers: Dict[str, Any], max_suggestions: int = 3) -> List[str]:
        """
        Suggest the optimal next questions to ask to unblock the most
        conditionally dependent questions.
        """
        unanswered_questions = self._get_unanswered_questions(current_answers)
        if not unanswered_questions:
            return []

        # Score each question by how many others it would unblock
        question_scores = {}

        for question_id in unanswered_questions:
            if self._can_question_be_asked(question_id, current_answers):
                # Count how many questions would become available if we answer this one
                dependents = self._get_questions_blocked_by(question_id, current_answers)
                question_scores[question_id] = len(dependents)

        # Sort by score and return top suggestions
        sorted_questions = sorted(question_scores.items(), key=lambda x: x[1], reverse=True)
        return [q_id for q_id, _ in sorted_questions[:max_suggestions]]

    def get_next_question(self, current_answers: Dict[str, Any]) -> Optional[str]:
        """
        Get the next question that should be asked chronologically based on
        current answers, respecting branching logic and conditions.

        This method follows the questionnaire flow:
        1. If no answers provided, returns the start question
        2. Follows navigation edges (option.next, defaultNext) from answered questions
        3. Checks that conditions are satisfied before returning a question
        4. Returns None if questionnaire is complete

        Args:
            current_answers: Dictionary mapping question IDs to their answers

        Returns:
            The ID of the next question to ask, or None if complete

        Example:
            >>> analyzer = QuestionnaireAnalyzer(questionnaire)
            >>> next_q = analyzer.get_next_question({})
            >>> print(f"Start with: {next_q}")
            >>> next_q = analyzer.get_next_question({"q1": "yes"})
            >>> print(f"After q1: {next_q}")
        """
        return self._get_current_question(current_answers)

    def get_completion_bounds(self, current_answers: Dict[str, Any]) -> Tuple[int, int]:
        """
        Calculate the minimum and maximum number of questions left to complete
        the questionnaire.
        """
        # Get all possible completion paths from current state
        possible_paths = self._get_possible_paths_from_current_state(current_answers)

        if not possible_paths:
            return 0, 0

        # Calculate path lengths (excluding already answered questions)
        path_lengths = []
        answered_questions = set(current_answers.keys())

        for path in possible_paths:
            remaining_questions = [q for q in path if q not in answered_questions]
            path_lengths.append(len(remaining_questions))

        min_remaining = min(path_lengths) if path_lengths else 0
        max_remaining = max(path_lengths) if path_lengths else 0

        return min_remaining, max_remaining

    def get_conditional_dependencies(self, question_id: str) -> Dict[str, List[Condition]]:
        """
        Get all conditions that must be satisfied for a question to be shown.
        Returns a mapping of dependent question IDs to their conditions.
        """
        if question_id not in self.question_map:
            return {}

        question = self.question_map[question_id]
        dependencies = {}

        if question.conditions:
            for condition in question.conditions:
                if condition.question not in dependencies:
                    dependencies[condition.question] = []
                dependencies[condition.question].append(condition)

        return dependencies

    def simulate_questionnaire_paths(self, max_paths: int = 100) -> List[List[str]]:
        """
        Simulate possible paths through the questionnaire to understand
        different completion scenarios.
        """
        paths = []
        visited_states = set()

        def dfs_path(current_question: str, path: List[str], depth: int = 0):
            if len(paths) >= max_paths or depth > 50:  # Prevent infinite loops
                return

            state_key = (current_question, tuple(sorted(path)))
            if state_key in visited_states:
                return
            visited_states.add(state_key)

            current_path = path + [current_question]
            next_questions = self.graph.get_next_questions(current_question)

            if not next_questions:  # Terminal question
                paths.append(current_path)
                return

            for next_q in next_questions:
                dfs_path(next_q, current_path, depth + 1)

        dfs_path(self.questionnaire.start_question, [], 0)
        return paths

    def analyze_questionnaire_complexity(self) -> Dict[str, Any]:
        """
        Analyze the overall complexity and characteristics of the questionnaire.
        """
        paths = self.simulate_questionnaire_paths()
        path_lengths = [len(path) for path in paths]

        is_valid, errors = self.graph.validate_dag()

        return {
            "is_valid_dag": is_valid,
            "validation_errors": errors,
            "total_questions": len(self.questionnaire.questions),
            "is_weakly_connected": self.graph.is_weakly_connected(),
            "unreachable_questions": list(self.graph.get_unreachable_questions()),
            "terminal_questions": list(self.graph.get_terminal_questions()),
            "possible_paths": len(paths),
            "min_path_length": min(path_lengths) if path_lengths else 0,
            "max_path_length": max(path_lengths) if path_lengths else 0,
            "avg_path_length": sum(path_lengths) / len(path_lengths) if path_lengths else 0,
            "branching_factor": self._calculate_avg_branching_factor(),
            "conditional_questions": self._count_conditional_questions(),
        }

    def _get_reachable_with_answers(self, current_answers: Dict[str, Any]) -> Set[str]:
        """Get questions reachable given current answers and their conditions."""
        reachable = set()
        queue = deque([self.questionnaire.start_question])

        while queue:
            current = queue.popleft()
            if current in reachable:
                continue

            # Check if this question's conditions are satisfied
            if self._are_conditions_satisfied(current, current_answers):
                reachable.add(current)
                next_questions = self.graph.get_next_questions(current)
                for next_q in next_questions:
                    if next_q not in reachable:
                        queue.append(next_q)

        return reachable

    def _get_unanswered_questions(self, current_answers: Dict[str, Any]) -> Set[str]:
        """Get questions that haven't been answered yet."""
        all_questions = set(self.question_map.keys())
        answered_questions = set(current_answers.keys())
        return all_questions - answered_questions

    def _can_question_be_asked(self, question_id: str, current_answers: Dict[str, Any]) -> bool:
        """Check if a question can be asked given current answers."""
        return self._are_conditions_satisfied(question_id, current_answers)

    def _are_conditions_satisfied(self, question_id: str, current_answers: Dict[str, Any]) -> bool:
        """Check if all conditions for a question are satisfied."""
        if question_id not in self.question_map:
            return False

        question = self.question_map[question_id]
        if not question.conditions:
            return True

        for condition in question.conditions:
            if not self._evaluate_condition(condition, current_answers):
                return False

        return True

    def _evaluate_condition(self, condition: Condition, current_answers: Dict[str, Any]) -> bool:
        """Evaluate a single condition against current answers."""
        question_answer = current_answers.get(condition.question)

        if condition.operator == ConditionOperator.EXISTS:
            return condition.question in current_answers
        elif condition.operator == ConditionOperator.NOT_EXISTS:
            return condition.question not in current_answers

        if question_answer is None:
            return False

        if condition.operator == ConditionOperator.EQUAL:
            return question_answer == condition.value
        elif condition.operator == ConditionOperator.NOT_EQUAL:
            return question_answer != condition.value
        elif condition.operator == ConditionOperator.LESS_THAN:
            return question_answer < condition.value
        elif condition.operator == ConditionOperator.LESS_EQUAL:
            return question_answer <= condition.value
        elif condition.operator == ConditionOperator.GREATER_THAN:
            return question_answer > condition.value
        elif condition.operator == ConditionOperator.GREATER_EQUAL:
            return question_answer >= condition.value
        elif condition.operator == ConditionOperator.CONTAINS:
            return condition.value in question_answer
        elif condition.operator == ConditionOperator.NOT_CONTAINS:
            return condition.value not in question_answer
        elif condition.operator == ConditionOperator.IN:
            return question_answer in condition.value
        elif condition.operator == ConditionOperator.NOT_IN:
            return question_answer not in condition.value

        return False

    def _get_possible_paths_from_current_state(self, current_answers: Dict[str, Any]) -> List[List[str]]:
        """
        Get all possible completion paths from the current state.
        This considers branching logic and conditional questions.
        """
        paths = []
        visited_states = set()

        def explore_all_paths(current_question: str, path: List[str], answers_so_far: Dict[str, Any], depth: int = 0):
            if depth > 50:  # Prevent infinite loops
                return

            state_key = (current_question, tuple(sorted(answers_so_far.keys())))
            if state_key in visited_states:
                return
            visited_states.add(state_key)

            current_path = path + [current_question]

            # Generate possible answer scenarios for current question
            possible_answers = self._generate_possible_answers(current_question)

            # Find which questions become available for each possible answer
            found_next_questions = False

            for answer_value in possible_answers:
                hypothetical_answers = answers_so_far.copy()
                hypothetical_answers[current_question] = answer_value

                # Find the specific next question based on this answer
                available_questions = []

                # Get the specific next question for this answer
                next_question = self.graph.get_next_question_for_answer(current_question, answer_value)
                if next_question and self._are_conditions_satisfied(next_question, hypothetical_answers):
                    available_questions.append(next_question)
                elif next_question is None:
                    # Only check for conditional questions if there's no explicit navigation
                    # and only if the current question is the start or has conditions
                    question = self.question_map[current_question]
                    if (current_question == self.questionnaire.start_question or
                        (question.conditions and len(hypothetical_answers) == 1)):
                        for q_id in self.question_map.keys():
                            if (q_id not in hypothetical_answers and
                                self._are_conditions_satisfied(q_id, hypothetical_answers)):
                                available_questions.append(q_id)
                                break  # Only take the first available question

                # Explore each available question
                for next_q in available_questions:
                    found_next_questions = True
                    explore_all_paths(next_q, current_path, hypothetical_answers, depth + 1)

            # If no next questions found, this is a terminal path
            if not found_next_questions:
                paths.append(current_path)

        # Start from the first unanswered question or start question
        start_question = self._get_current_question(current_answers)
        if start_question:
            explore_all_paths(start_question, [], current_answers.copy(), 0)

        return paths

    def _generate_possible_answers(self, question_id: str) -> List[Any]:
        """Generate possible answers for a question to explore all paths."""
        if question_id not in self.question_map:
            return [True]  # Default fallback

        question = self.question_map[question_id]

        if isinstance(question, BooleanQuestion):
            return [True, False]
        elif isinstance(question, (SingleChoiceQuestion, MultiChoiceQuestion)):
            return [opt.value for opt in question.options]
        else:
            # For other question types, generate some representative values
            return [True, False, "test_value", 1, 0]

    def _get_current_question(self, current_answers: Dict[str, Any]) -> Optional[str]:
        """Get the current question that should be asked next."""
        if not current_answers:
            return self.questionnaire.start_question

        # If we have answers, find the next question following the path
        # Start from the most recently answered question and find its next question
        answered_questions = list(current_answers.keys())

        # Try to find the next question based on the last answered question
        for answered_q in reversed(answered_questions):  # Start with most recent
            answer_value = current_answers[answered_q]
            next_question = self.graph.get_next_question_for_answer(answered_q, answer_value)
            if next_question and next_question not in current_answers:
                if self._are_conditions_satisfied(next_question, current_answers):
                    return next_question

        # Fallback: Find any question that can be asked but hasn't been answered
        for question_id, question in self.question_map.items():
            if (question_id not in current_answers and
                self._are_conditions_satisfied(question_id, current_answers)):
                return question_id

        return None

    def _get_next_possible_questions(self, current_answers: Dict[str, Any]) -> Set[str]:
        """Get questions that can be asked next given current answers."""
        if not current_answers:
            return {self.questionnaire.start_question}

        possible_next = set()
        answered_questions = set(current_answers.keys())

        # For each answered question, check what it can lead to
        for answered_q in answered_questions:
            next_questions = self.graph.get_next_questions(answered_q)
            for next_q in next_questions:
                # Check if conditions are satisfied and not already answered
                if (next_q not in answered_questions and
                    self._are_conditions_satisfied(next_q, current_answers)):
                    possible_next.add(next_q)

        return possible_next

    def _get_questions_blocked_by(self, blocking_question_id: str, current_answers: Dict[str, Any]) -> Set[str]:
        """Get questions that are blocked by not having answered a specific question."""
        blocked = set()

        for question_id, question in self.question_map.items():
            if question.conditions:
                for condition in question.conditions:
                    if condition.question == blocking_question_id:
                        if not self._can_question_be_asked(question_id, current_answers):
                            blocked.add(question_id)

        return blocked

    def _calculate_avg_branching_factor(self) -> float:
        """Calculate average branching factor of the questionnaire graph."""
        total_edges = sum(len(next_qs) for next_qs in self.graph._adjacency_list.values())
        non_terminal_questions = len([q_id for q_id in self.question_map.keys()
                                    if self.graph.get_next_questions(q_id)])

        return total_edges / non_terminal_questions if non_terminal_questions > 0 else 0

    def _count_conditional_questions(self) -> int:
        """Count questions that have conditions."""
        return sum(1 for q in self.questionnaire.questions if q.conditions)