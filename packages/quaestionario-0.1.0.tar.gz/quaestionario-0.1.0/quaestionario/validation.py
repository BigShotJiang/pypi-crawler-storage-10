"""
Answer validation for questionnaire responses.

This module provides validation to ensure answers match question types,
are within valid ranges, and satisfy all constraints.
"""

from typing import Any, List, Optional, Dict, Tuple
from enum import Enum

from .models import (
    Question,
    BooleanQuestion,
    TextShortQuestion,
    TextLongQuestion,
    NumberQuestion,
    DateTimeQuestion,
    ScaleQuestion,
    SingleChoiceQuestion,
    MultiChoiceQuestion,
)


class ValidationError(Exception):
    """Raised when an answer fails validation."""

    def __init__(self, question_id: str, message: str, details: Optional[Dict[str, Any]] = None):
        self.question_id = question_id
        self.message = message
        self.details = details or {}
        super().__init__(f"Question '{question_id}': {message}")


class ValidationResult:
    """Result of validating an answer."""

    def __init__(self, is_valid: bool, errors: List[str] = None, warnings: List[str] = None):
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []

    def __bool__(self):
        return self.is_valid

    def __repr__(self):
        return f"ValidationResult(valid={self.is_valid}, errors={len(self.errors)}, warnings={len(self.warnings)})"


class AnswerValidator:
    """
    Validates answers against question definitions.

    Examples:
        >>> validator = AnswerValidator()
        >>> question = BooleanQuestion(id="q1", type="boolean", text="Are you over 18?")
        >>> result = validator.validate_answer(question, True)
        >>> print(result.is_valid)  # True
        >>> result = validator.validate_answer(question, "yes")
        >>> print(result.is_valid)  # False
        >>> print(result.errors)  # ['Expected boolean, got str']
    """

    def validate_answer(
        self,
        question: Question,
        answer: Any,
        strict: bool = True
    ) -> ValidationResult:
        """
        Validate an answer for a specific question.

        Args:
            question: The question definition
            answer: The user's answer
            strict: If True, raise ValidationError on failure. If False, return ValidationResult

        Returns:
            ValidationResult with validation status and error messages

        Raises:
            ValidationError: If strict=True and validation fails
        """
        errors = []
        warnings = []

        # Check None for required questions
        if answer is None:
            if question.required:
                errors.append("Answer is required")
            else:
                # None is acceptable for non-required questions
                return ValidationResult(is_valid=True)

        # Type-specific validation
        if isinstance(question, BooleanQuestion):
            errors.extend(self._validate_boolean(answer))

        elif isinstance(question, TextShortQuestion):
            errors.extend(self._validate_text_short(answer))

        elif isinstance(question, TextLongQuestion):
            errors.extend(self._validate_text_long(answer))

        elif isinstance(question, NumberQuestion):
            errors.extend(self._validate_number(answer))

        elif isinstance(question, DateTimeQuestion):
            errors.extend(self._validate_datetime(answer, question))

        elif isinstance(question, ScaleQuestion):
            errors.extend(self._validate_scale(answer, question))

        elif isinstance(question, SingleChoiceQuestion):
            errors.extend(self._validate_single_choice(answer, question))

        elif isinstance(question, MultiChoiceQuestion):
            errors.extend(self._validate_multi_choice(answer, question))

        result = ValidationResult(is_valid=len(errors) == 0, errors=errors, warnings=warnings)

        if strict and not result.is_valid:
            raise ValidationError(
                question.id,
                "; ".join(errors),
                {"question_type": question.type, "answer": answer}
            )

        return result

    def validate_answers(
        self,
        questions: Dict[str, Question],
        answers: Dict[str, Any],
        strict: bool = False
    ) -> Dict[str, ValidationResult]:
        """
        Validate multiple answers at once.

        Args:
            questions: Dictionary mapping question IDs to Question objects
            answers: Dictionary mapping question IDs to answers
            strict: If True, raise ValidationError on first failure

        Returns:
            Dictionary mapping question IDs to ValidationResults
        """
        results = {}

        for question_id, answer in answers.items():
            if question_id not in questions:
                results[question_id] = ValidationResult(
                    is_valid=False,
                    errors=[f"Unknown question ID: {question_id}"]
                )
                if strict:
                    raise ValidationError(question_id, f"Unknown question ID: {question_id}")
                continue

            question = questions[question_id]
            results[question_id] = self.validate_answer(question, answer, strict=strict)

        return results

    def _validate_boolean(self, answer: Any) -> List[str]:
        """Validate boolean answer."""
        if not isinstance(answer, bool):
            return [f"Expected boolean, got {type(answer).__name__}"]
        return []

    def _validate_text_short(self, answer: Any, max_length: int = 255) -> List[str]:
        """Validate short text answer."""
        errors = []
        if not isinstance(answer, str):
            errors.append(f"Expected string, got {type(answer).__name__}")
        elif len(answer) > max_length:
            errors.append(f"Text too long ({len(answer)} chars, max {max_length})")
        return errors

    def _validate_text_long(self, answer: Any, max_length: int = 10000) -> List[str]:
        """Validate long text answer."""
        errors = []
        if not isinstance(answer, str):
            errors.append(f"Expected string, got {type(answer).__name__}")
        elif len(answer) > max_length:
            errors.append(f"Text too long ({len(answer)} chars, max {max_length})")
        return errors

    def _validate_number(self, answer: Any) -> List[str]:
        """Validate numeric answer."""
        if not isinstance(answer, (int, float)):
            return [f"Expected number, got {type(answer).__name__}"]
        return []

    def _validate_datetime(self, answer: Any, question: DateTimeQuestion) -> List[str]:
        """Validate date/time answer."""
        # Accept string (ISO format) or datetime objects
        if not isinstance(answer, (str, )):
            return [f"Expected string (ISO format), got {type(answer).__name__}"]

        # Could add more specific date/time parsing validation here
        # For now, just check it's a string
        return []

    def _validate_scale(self, answer: Any, question: ScaleQuestion) -> List[str]:
        """Validate scale answer."""
        errors = []

        if not isinstance(answer, (int, float)):
            errors.append(f"Expected number, got {type(answer).__name__}")
            return errors

        if answer < question.min:
            errors.append(f"Value {answer} is below minimum {question.min}")

        if answer > question.max:
            errors.append(f"Value {answer} is above maximum {question.max}")

        # Check step if specified
        if question.step is not None:
            # Calculate if answer is valid given the step
            steps_from_min = (answer - question.min) / question.step
            if not steps_from_min.is_integer():
                errors.append(
                    f"Value {answer} is not a valid step "
                    f"(min={question.min}, step={question.step})"
                )

        return errors

    def _validate_single_choice(self, answer: Any, question: SingleChoiceQuestion) -> List[str]:
        """Validate single choice answer."""
        errors = []

        # Get valid option values
        valid_values = [opt.value for opt in question.options]

        if answer not in valid_values:
            errors.append(
                f"Invalid choice '{answer}'. "
                f"Valid options: {valid_values}"
            )

        return errors

    def _validate_multi_choice(self, answer: Any, question: MultiChoiceQuestion) -> List[str]:
        """Validate multiple choice answer."""
        errors = []

        if not isinstance(answer, list):
            errors.append(f"Expected list, got {type(answer).__name__}")
            return errors

        # Get valid option values
        valid_values = [opt.value for opt in question.options]

        # Check each selected value is valid
        for value in answer:
            if value not in valid_values:
                errors.append(
                    f"Invalid choice '{value}'. "
                    f"Valid options: {valid_values}"
                )

        # Check max selections
        if question.max_selections is not None:
            if len(answer) > question.max_selections:
                errors.append(
                    f"Too many selections ({len(answer)}, "
                    f"max {question.max_selections})"
                )

        return errors


# Convenience function for single answer validation
def validate_answer(question: Question, answer: Any, strict: bool = True) -> ValidationResult:
    """
    Convenience function to validate a single answer.

    Args:
        question: The question definition
        answer: The user's answer
        strict: If True, raise ValidationError on failure

    Returns:
        ValidationResult

    Example:
        >>> question = ScaleQuestion(id="q1", type="scale", text="Rate us", min=1, max=5)
        >>> result = validate_answer(question, 3)
        >>> print(result.is_valid)  # True
        >>> result = validate_answer(question, 10)  # Raises ValidationError
    """
    validator = AnswerValidator()
    return validator.validate_answer(question, answer, strict=strict)
