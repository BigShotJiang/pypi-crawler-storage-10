"""
Base classes and registry for format handlers.

This provides the pluggable architecture for adding new import/export formats.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from pathlib import Path

from ..models import Questionnaire


class FormatHandler(ABC):
    """
    Abstract base class for format handlers.

    To add a new format:
    1. Subclass FormatHandler
    2. Implement load() and dump() methods
    3. Register with register_format()
    """

    @abstractmethod
    def load(self, data: str) -> Dict[str, Any]:
        """
        Parse a string into a dictionary.

        Args:
            data: String content in this format

        Returns:
            Dictionary representation of questionnaire

        Raises:
            ValueError: If parsing fails
        """
        pass

    @abstractmethod
    def dump(self, questionnaire: Questionnaire, pretty: bool = True) -> str:
        """
        Serialize a questionnaire to a string.

        Args:
            questionnaire: Questionnaire instance to serialize
            pretty: Whether to format output for readability

        Returns:
            String representation in this format
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this format."""
        pass

    @property
    @abstractmethod
    def extensions(self) -> list[str]:
        """List of file extensions for this format (without dots)."""
        pass

    def load_from_file(self, file_path: Path) -> Dict[str, Any]:
        """
        Load questionnaire from a file.

        Args:
            file_path: Path to file

        Returns:
            Dictionary representation of questionnaire
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return self.load(content)

    def dump_to_file(self, questionnaire: Questionnaire, file_path: Path, pretty: bool = True):
        """
        Save questionnaire to a file.

        Args:
            questionnaire: Questionnaire to save
            file_path: Path to save to
            pretty: Whether to format output for readability
        """
        content = self.dump(questionnaire, pretty=pretty)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)


# Format registry
_format_registry: Dict[str, FormatHandler] = {}


def register_format(format_name: str, handler: FormatHandler):
    """
    Register a format handler.

    Args:
        format_name: Name/identifier for the format (e.g., "json", "yaml")
        handler: FormatHandler instance

    Example:
        >>> register_format("json", JSONFormat())
        >>> register_format("quecode", QueCodeFormat())
    """
    _format_registry[format_name.lower()] = handler


def get_format_handler(format_name: str) -> Optional[FormatHandler]:
    """
    Get a registered format handler.

    Args:
        format_name: Format identifier

    Returns:
        FormatHandler instance or None if not found
    """
    return _format_registry.get(format_name.lower())


def list_registered_formats() -> Dict[str, FormatHandler]:
    """
    Get all registered format handlers.

    Returns:
        Dictionary mapping format names to handlers
    """
    return _format_registry.copy()


def detect_format_from_extension(file_path: Path) -> Optional[str]:
    """
    Detect format from file extension.

    Args:
        file_path: Path to file

    Returns:
        Format name or None if not recognized
    """
    extension = file_path.suffix.lstrip('.').lower()

    for format_name, handler in _format_registry.items():
        if extension in handler.extensions:
            return format_name

    return None
