"""
JSON format handler for questionnaires.
"""

import json
from typing import Dict, Any

from .base import FormatHandler
from ..models import Questionnaire


class JSONFormat(FormatHandler):
    """
    JSON format handler for questionnaires.

    Supports standard JSON with optional pretty-printing.
    """

    @property
    def name(self) -> str:
        return "JSON"

    @property
    def extensions(self) -> list[str]:
        return ["json"]

    def load(self, data: str) -> Dict[str, Any]:
        """
        Parse JSON string into dictionary.

        Args:
            data: JSON string

        Returns:
            Dictionary representation

        Raises:
            ValueError: If JSON is invalid
        """
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}")

    def dump(self, questionnaire: Questionnaire, pretty: bool = True) -> str:
        """
        Serialize questionnaire to JSON string.

        Args:
            questionnaire: Questionnaire to serialize
            pretty: Whether to indent for readability

        Returns:
            JSON string
        """
        # Convert Pydantic model to dict (mode='json' converts enums to values)
        data = questionnaire.model_dump(by_alias=True, exclude_none=True, mode='json')

        if pretty:
            return json.dumps(data, indent=2, ensure_ascii=False)
        else:
            return json.dumps(data, ensure_ascii=False)
