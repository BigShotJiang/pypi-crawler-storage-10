"""
High-level API for loading and saving questionnaires.

This provides a clean, user-friendly interface for import/export.
"""

from pathlib import Path
from typing import Union, Optional, Dict, Any

from ..models import Questionnaire
from .base import (
    get_format_handler,
    detect_format_from_extension,
    list_registered_formats,
)


def load_questionnaire(
    file_path: Union[str, Path],
    format: Optional[str] = None,
    validate: bool = True
) -> Questionnaire:
    """
    Load a questionnaire from a file.

    Args:
        file_path: Path to questionnaire file
        format: Format name (e.g., "json", "yaml"). If None, auto-detect from extension
        validate: Whether to validate the questionnaire after loading

    Returns:
        Loaded Questionnaire instance

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If format is unknown or file is invalid

    Examples:
        >>> # Auto-detect format from extension
        >>> q = load_questionnaire("questionnaire.json")
        >>> q = load_questionnaire("questionnaire.yaml")
        >>>
        >>> # Explicit format
        >>> q = load_questionnaire("data.txt", format="json")
    """
    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Detect format if not specified
    if format is None:
        format = detect_format_from_extension(file_path)
        if format is None:
            raise ValueError(
                f"Could not detect format from extension '{file_path.suffix}'. "
                f"Please specify format explicitly."
            )

    # Get handler
    handler = get_format_handler(format)
    if handler is None:
        available = ", ".join(list_registered_formats().keys())
        raise ValueError(
            f"Unknown format '{format}'. Available formats: {available}"
        )

    # Load data
    data = handler.load_from_file(file_path)

    # Create and validate questionnaire
    questionnaire = Questionnaire(**data)

    if validate:
        from ..graph import QuestionnaireGraph
        graph = QuestionnaireGraph(questionnaire)
        is_valid, errors = graph.validate_dag()
        if not is_valid:
            raise ValueError(f"Invalid questionnaire: {'; '.join(errors)}")

    return questionnaire


def save_questionnaire(
    questionnaire: Questionnaire,
    file_path: Union[str, Path],
    format: Optional[str] = None,
    pretty: bool = True,
    overwrite: bool = False
):
    """
    Save a questionnaire to a file.

    Args:
        questionnaire: Questionnaire to save
        file_path: Path to save to
        format: Format name. If None, auto-detect from extension
        pretty: Whether to format output for readability
        overwrite: Whether to overwrite existing file

    Raises:
        FileExistsError: If file exists and overwrite=False
        ValueError: If format is unknown

    Examples:
        >>> # Auto-detect format from extension
        >>> save_questionnaire(q, "output.json")
        >>> save_questionnaire(q, "output.yaml")
        >>>
        >>> # Explicit format
        >>> save_questionnaire(q, "output.txt", format="json")
        >>>
        >>> # Compact output
        >>> save_questionnaire(q, "output.json", pretty=False)
    """
    file_path = Path(file_path)

    # Check if file exists
    if file_path.exists() and not overwrite:
        raise FileExistsError(
            f"File already exists: {file_path}. "
            f"Use overwrite=True to replace it."
        )

    # Detect format if not specified
    if format is None:
        format = detect_format_from_extension(file_path)
        if format is None:
            raise ValueError(
                f"Could not detect format from extension '{file_path.suffix}'. "
                f"Please specify format explicitly."
            )

    # Get handler
    handler = get_format_handler(format)
    if handler is None:
        available = ", ".join(list_registered_formats().keys())
        raise ValueError(
            f"Unknown format '{format}'. Available formats: {available}"
        )

    # Save
    file_path.parent.mkdir(parents=True, exist_ok=True)
    handler.dump_to_file(questionnaire, file_path, pretty=pretty)


def loads_questionnaire(
    data: str,
    format: str,
    validate: bool = True
) -> Questionnaire:
    """
    Load a questionnaire from a string.

    Args:
        data: String content
        format: Format name (e.g., "json", "yaml")
        validate: Whether to validate after loading

    Returns:
        Loaded Questionnaire instance

    Raises:
        ValueError: If format is unknown or data is invalid

    Examples:
        >>> json_str = '{"questionnaireId": "test", ...}'
        >>> q = loads_questionnaire(json_str, format="json")
        >>>
        >>> yaml_str = "questionnaireId: test\\n..."
        >>> q = loads_questionnaire(yaml_str, format="yaml")
    """
    handler = get_format_handler(format)
    if handler is None:
        available = ", ".join(list_registered_formats().keys())
        raise ValueError(
            f"Unknown format '{format}'. Available formats: {available}"
        )

    # Parse
    data_dict = handler.load(data)

    # Create questionnaire
    questionnaire = Questionnaire(**data_dict)

    if validate:
        from ..graph import QuestionnaireGraph
        graph = QuestionnaireGraph(questionnaire)
        is_valid, errors = graph.validate_dag()
        if not is_valid:
            raise ValueError(f"Invalid questionnaire: {'; '.join(errors)}")

    return questionnaire


def dumps_questionnaire(
    questionnaire: Questionnaire,
    format: str,
    pretty: bool = True
) -> str:
    """
    Serialize a questionnaire to a string.

    Args:
        questionnaire: Questionnaire to serialize
        format: Format name (e.g., "json", "yaml")
        pretty: Whether to format for readability

    Returns:
        String representation

    Raises:
        ValueError: If format is unknown

    Examples:
        >>> json_str = dumps_questionnaire(q, format="json")
        >>> yaml_str = dumps_questionnaire(q, format="yaml")
        >>> compact_json = dumps_questionnaire(q, format="json", pretty=False)
    """
    handler = get_format_handler(format)
    if handler is None:
        available = ", ".join(list_registered_formats().keys())
        raise ValueError(
            f"Unknown format '{format}'. Available formats: {available}"
        )

    return handler.dump(questionnaire, pretty=pretty)


def list_formats() -> Dict[str, Dict[str, Any]]:
    """
    List all available formats.

    Returns:
        Dictionary with format information

    Example:
        >>> formats = list_formats()
        >>> for name, info in formats.items():
        ...     print(f"{name}: {info['name']} ({', '.join(info['extensions'])})")
    """
    result = {}
    for format_name, handler in list_registered_formats().items():
        result[format_name] = {
            "name": handler.name,
            "extensions": handler.extensions,
        }
    return result


def convert_questionnaire(
    input_path: Union[str, Path],
    output_path: Union[str, Path],
    input_format: Optional[str] = None,
    output_format: Optional[str] = None,
    pretty: bool = True,
    overwrite: bool = False
):
    """
    Convert a questionnaire from one format to another.

    Args:
        input_path: Path to input file
        output_path: Path to output file
        input_format: Input format (auto-detect if None)
        output_format: Output format (auto-detect if None)
        pretty: Whether to format output for readability
        overwrite: Whether to overwrite existing output file

    Example:
        >>> # Convert JSON to YAML
        >>> convert_questionnaire("input.json", "output.yaml")
        >>>
        >>> # Convert YAML to JSON (compact)
        >>> convert_questionnaire("input.yaml", "output.json", pretty=False)
    """
    # Load
    questionnaire = load_questionnaire(input_path, format=input_format)

    # Save
    save_questionnaire(
        questionnaire,
        output_path,
        format=output_format,
        pretty=pretty,
        overwrite=overwrite
    )
