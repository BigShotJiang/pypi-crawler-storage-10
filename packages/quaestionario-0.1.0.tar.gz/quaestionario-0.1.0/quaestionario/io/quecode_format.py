"""
QueCode format handler.

QueCode is a concise, human-readable DSL for authoring questionnaires.
It uses indentation-based syntax and mirrors how product teams think about flows.
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

from ..models import Questionnaire, Question, Option, Condition
from .base import FormatHandler


class QueCodeFormat(FormatHandler):
    """Handler for QueCode format."""

    @property
    def name(self) -> str:
        return "QueCode"

    @property
    def extensions(self) -> list[str]:
        return ["qc", "quecode"]

    def load(self, data: str) -> Dict[str, Any]:
        """Parse QueCode string into dictionary."""
        try:
            parser = QueCodeParser(data)
            return parser.parse()
        except Exception as e:
            raise ValueError(f"Invalid QueCode: {e}")

    def dump(self, questionnaire: Questionnaire, pretty: bool = True) -> str:
        """Serialize questionnaire to QueCode string."""
        serializer = QueCodeSerializer(questionnaire)
        return serializer.serialize()


class QueCodeParser:
    """Parser for QueCode syntax."""

    def __init__(self, source: str):
        self.source = source
        self.lines = []
        self.current_line = 0
        self._preprocess()

    def _preprocess(self):
        """Remove comments and prepare lines."""
        for line in self.source.split('\n'):
            # Remove comments
            line = re.sub(r'#.*$', '', line)
            line = re.sub(r'//.*$', '', line)
            # Keep the line if it's not empty after stripping
            if line.strip():
                self.lines.append(line)

    def parse(self) -> Dict[str, Any]:
        """Parse the entire QueCode document."""
        if not self.lines:
            raise ValueError("Empty QueCode document")

        # Parse header
        header_line = self.lines[0]
        if not header_line.strip().startswith('quecode '):
            raise ValueError("QueCode document must start with 'quecode' keyword")

        questionnaire_data = self._parse_header(header_line)
        questionnaire_data['questions'] = []

        # Parse questions
        self.current_line = 1
        while self.current_line < len(self.lines):
            question = self._parse_question()
            if question:
                questionnaire_data['questions'].append(question)

        return questionnaire_data

    def _parse_header(self, line: str) -> Dict[str, Any]:
        """Parse the header line."""
        # Extract key=value pairs from header
        data = {}

        # Remove 'quecode' keyword
        line = line.strip()[8:].strip()

        # Parse key=value pairs
        pattern = r'(\w+)=("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|{[^}]*}|\[[^\]]*\]|[^\s]+)'
        matches = re.findall(pattern, line)

        for key, value in matches:
            # Convert to camelCase for schema compatibility
            if key == 'id':
                data['questionnaireId'] = self._parse_value(value)
            elif key == 'start':
                data['startQuestion'] = self._parse_value(value)
            else:
                data[key] = self._parse_value(value)

        return data

    def _parse_value(self, value: str) -> Any:
        """Parse a value (string, number, bool, JSON)."""
        value = value.strip()

        # Remove quotes if present
        if (value.startswith('"') and value.endswith('"')) or \
           (value.startswith("'") and value.endswith("'")):
            return value[1:-1]

        # Try JSON (for objects and arrays)
        if value.startswith('{') or value.startswith('['):
            try:
                return json.loads(value)
            except:
                pass

        # Try boolean
        if value.lower() == 'true':
            return True
        if value.lower() == 'false':
            return False

        # Try null
        if value.lower() == 'null':
            return None

        # Try number
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except:
            pass

        # Return as string
        return value

    def _parse_question(self) -> Optional[Dict[str, Any]]:
        """Parse a question block."""
        if self.current_line >= len(self.lines):
            return None

        line = self.lines[self.current_line]

        # Question line should not be indented
        if line.startswith('  '):
            raise ValueError(f"Unexpected indentation at line {self.current_line + 1}")

        # Parse question declaration: Q1 boolean "Question text"
        match = re.match(r'^(\w+)\s+(\w+)\s+"([^"]*)"', line)
        if not match:
            raise ValueError(f"Invalid question declaration at line {self.current_line + 1}: {line}")

        question_id, question_type, question_text = match.groups()

        question_data = {
            'id': question_id,
            'type': question_type,
            'text': question_text,
        }

        self.current_line += 1

        # Parse directives (indented lines)
        while self.current_line < len(self.lines):
            line = self.lines[self.current_line]

            # If not indented, this is the next question
            if not line.startswith('  '):
                break

            # Remove leading spaces
            directive_line = line.strip()

            if directive_line.startswith('required'):
                question_data['required'] = True
                self.current_line += 1

            elif directive_line.startswith('default ->'):
                next_id = directive_line.split('->')[1].strip()
                question_data['defaultNext'] = next_id
                self.current_line += 1

            elif directive_line.startswith('guideline') or directive_line.startswith('guidance'):
                # Support both 'guideline' (correct) and 'guidance' (common mistake)
                match = re.match(r'(?:guideline|guidance)\s+"([^"]*)"', directive_line)
                if match:
                    question_data['guideline'] = match.group(1)
                self.current_line += 1

            elif directive_line.startswith('facets'):
                match = re.match(r'facets\s+"([^"]*)"', directive_line)
                if match:
                    # Facets is a string, not a list
                    question_data['facets'] = match.group(1)
                self.current_line += 1

            elif directive_line.startswith('meta'):
                match = re.match(r'meta\s+({.*})', directive_line)
                if match:
                    question_data['meta'] = json.loads(match.group(1))
                self.current_line += 1

            elif directive_line.startswith('maxSelections'):
                match = re.match(r'maxSelections\s+(\d+)', directive_line)
                if match:
                    question_data['maxSelections'] = int(match.group(1))
                self.current_line += 1

            elif directive_line.startswith('min '):
                match = re.match(r'min\s+([\d.]+)', directive_line)
                if match:
                    question_data['min'] = self._parse_value(match.group(1))
                self.current_line += 1

            elif directive_line.startswith('max '):
                match = re.match(r'max\s+([\d.]+)', directive_line)
                if match:
                    question_data['max'] = self._parse_value(match.group(1))
                self.current_line += 1

            elif directive_line.startswith('step '):
                match = re.match(r'step\s+([\d.]+)', directive_line)
                if match:
                    question_data['step'] = self._parse_value(match.group(1))
                self.current_line += 1

            elif directive_line.startswith('labels'):
                # Parse labels: labels "Low" | "Mid" | "High"
                match = re.match(r'labels\s+"([^"]*)"(?:\s*\|\s*"([^"]*)")?(?:\s*\|\s*"([^"]*)")?', directive_line)
                if match:
                    labels = [g for g in match.groups() if g is not None]
                    question_data['labels'] = labels
                self.current_line += 1

            elif directive_line.startswith('mode'):
                match = re.match(r'mode\s+(\w+)', directive_line)
                if match:
                    question_data['mode'] = match.group(1)
                self.current_line += 1

            elif directive_line.startswith('option'):
                # Parse option
                if 'options' not in question_data:
                    question_data['options'] = []
                option = self._parse_option(directive_line)
                question_data['options'].append(option)
                self.current_line += 1

            elif directive_line.startswith('when'):
                # Parse condition
                if 'conditions' not in question_data:
                    question_data['conditions'] = []
                condition = self._parse_condition(directive_line)
                question_data['conditions'].append(condition)
                self.current_line += 1

            else:
                raise ValueError(f"Unknown directive at line {self.current_line + 1}: {directive_line}")

        return question_data

    def _parse_option(self, line: str) -> Dict[str, Any]:
        """Parse an option line."""
        # option value -> NEXT_ID "Label" | "Guidance"
        # option value "Label" | "Guidance"
        # option "value with spaces" -> NEXT_ID "Label"

        option_data = {}

        # Remove 'option ' prefix
        line = line[6:].strip()

        # Check for quoted value
        if line.startswith('"'):
            match = re.match(r'^"([^"]*)"', line)
            if not match:
                raise ValueError(f"Invalid option: {line}")
            option_data['value'] = match.group(1)
            line = line[len(match.group(0)):].strip()
        else:
            # Unquoted value (word)
            match = re.match(r'^(\w+)', line)
            if not match:
                raise ValueError(f"Invalid option: {line}")
            option_data['value'] = match.group(1)
            line = line[len(match.group(0)):].strip()

        # Check for -> NEXT_ID
        if line.startswith('->'):
            line = line[2:].strip()
            match = re.match(r'^(\w+)', line)
            if not match:
                raise ValueError(f"Invalid next reference: {line}")
            option_data['next'] = match.group(1)
            line = line[len(match.group(0)):].strip()

        # Parse label (required)
        match = re.match(r'^"([^"]*)"', line)
        if not match:
            raise ValueError(f"Option must have a label: {line}")
        option_data['label'] = match.group(1)
        line = line[len(match.group(0)):].strip()

        # Parse guideline (optional, after |)
        if line.startswith('|'):
            line = line[1:].strip()
            match = re.match(r'^"([^"]*)"', line)
            if match:
                option_data['guideline'] = match.group(1)

        return option_data

    def _parse_condition(self, line: str) -> Dict[str, Any]:
        """Parse a condition line."""
        # when Q1 = "value"
        # when Q1 != null
        # when Q3 contains "hardware"
        # when Q1 in ["remote", "hybrid"]
        # when Q4 >= 4

        line = line[4:].strip()  # Remove 'when '

        # Parse operator (keep actual symbols for Pydantic enum)
        operators = [
            ('not_contains', 'not_contains'),
            ('not_exists', 'not_exists'),
            ('not_in', 'not_in'),
            ('contains', 'contains'),
            ('exists', 'exists'),
            ('in', 'in'),
            ('>=', '>='),
            ('<=', '<='),
            ('>', '>'),
            ('<', '<'),
            ('!=', '!='),
            ('=', '='),
        ]

        condition_data = {}

        for op_str, op_name in operators:
            # For exists/not_exists, check if line ends with the operator
            if op_name in ['exists', 'not_exists']:
                if line.endswith(f' {op_str}'):
                    question_id = line[:-len(op_str)-1].strip()
                    condition_data['question'] = question_id
                    condition_data['operator'] = op_name
                    return condition_data
            else:
                # For other operators, split on the operator
                if f' {op_str} ' in line:
                    parts = line.split(f' {op_str} ', 1)
                    condition_data['question'] = parts[0].strip()
                    condition_data['operator'] = op_name
                    if len(parts) > 1:
                        condition_data['value'] = self._parse_value(parts[1].strip())
                    return condition_data

        raise ValueError(f"Invalid condition: {line}")


class QueCodeSerializer:
    """Serializer for QueCode format."""

    def __init__(self, questionnaire: Questionnaire):
        self.questionnaire = questionnaire

    def serialize(self) -> str:
        """Serialize questionnaire to QueCode string."""
        lines = []

        # Header
        header_parts = [
            f'id="{self.questionnaire.questionnaire_id}"',
            f'version={self._format_value(self.questionnaire.version)}',
            f'start={self.questionnaire.start_question}',
        ]

        if self.questionnaire.title:
            header_parts.append(f'title="{self.questionnaire.title}"')

        if self.questionnaire.description:
            header_parts.append(f'description="{self.questionnaire.description}"')

        if self.questionnaire.meta:
            header_parts.append(f'meta={json.dumps(self.questionnaire.meta)}')

        lines.append('quecode ' + ' '.join(header_parts))
        lines.append('')  # Blank line after header

        # Questions
        for question in self.questionnaire.questions:
            lines.extend(self._serialize_question(question))
            lines.append('')  # Blank line between questions

        return '\n'.join(lines)

    def _serialize_question(self, question: Question) -> List[str]:
        """Serialize a single question."""
        lines = []

        # Question declaration
        lines.append(f'{question.id} {question.type} "{question.text}"')

        # Directives
        if question.required:
            lines.append('  required')

        if question.default_next:
            lines.append(f'  default -> {question.default_next}')

        if question.guideline:
            lines.append(f'  guideline "{question.guideline}"')

        if hasattr(question, 'facets') and question.facets:
            lines.append(f'  facets "{question.facets}"')

        if question.meta:
            lines.append(f'  meta {json.dumps(question.meta)}')

        # Type-specific directives
        if hasattr(question, 'max_selections') and question.max_selections is not None:
            lines.append(f'  maxSelections {question.max_selections}')

        if hasattr(question, 'min') and question.min is not None:
            lines.append(f'  min {question.min}')

        if hasattr(question, 'max') and question.max is not None:
            lines.append(f'  max {question.max}')

        if hasattr(question, 'step') and question.step is not None:
            lines.append(f'  step {question.step}')

        if hasattr(question, 'labels') and question.labels:
            labels_str = ' | '.join([f'"{label}"' for label in question.labels])
            lines.append(f'  labels {labels_str}')

        if hasattr(question, 'mode') and question.mode:
            mode_value = question.mode.value if hasattr(question.mode, 'value') else question.mode
            lines.append(f'  mode {mode_value}')

        # Options
        if hasattr(question, 'options') and question.options:
            for option in question.options:
                lines.append(self._serialize_option(option))

        # Conditions
        if question.conditions:
            for condition in question.conditions:
                lines.append(self._serialize_condition(condition))

        return lines

    def _serialize_option(self, option: Option) -> str:
        """Serialize an option."""
        # Determine if value needs quotes
        value_str = f'"{option.value}"' if ' ' in str(option.value) else str(option.value)

        parts = ['  option', value_str]

        if option.next:
            parts.append(f'-> {option.next}')

        parts.append(f'"{option.label}"')

        if option.guideline:
            parts.append(f'| "{option.guideline}"')

        return ' '.join(parts)

    def _serialize_condition(self, condition: Condition) -> str:
        """Serialize a condition."""
        # Operator values are already the correct symbols in the model
        op_str = condition.operator.value if hasattr(condition.operator, 'value') else condition.operator

        if op_str in ['exists', 'not_exists']:
            return f'  when {condition.question} {op_str}'
        else:
            value_str = self._format_value(condition.value)
            return f'  when {condition.question} {op_str} {value_str}'

    def _format_value(self, value: Any) -> str:
        """Format a value for QueCode output."""
        if value is None:
            return 'null'
        if isinstance(value, bool):
            return 'true' if value else 'false'
        if isinstance(value, str):
            # Quote if contains spaces or special characters
            if ' ' in value or any(c in value for c in [',', '|', '->', '=']):
                return f'"{value}"'
            return value
        if isinstance(value, (list, dict)):
            return json.dumps(value)
        return str(value)
