"""
YAML format handler for questionnaires.
"""

import yaml
from typing import Dict, Any

from .base import FormatHandler
from ..models import Questionnaire


class YAMLFormat(FormatHandler):
    """
    YAML format handler for questionnaires.

    Supports YAML with pretty-printing and safe loading.
    """

    @property
    def name(self) -> str:
        return "YAML"

    @property
    def extensions(self) -> list[str]:
        return ["yaml", "yml"]

    def load(self, data: str) -> Dict[str, Any]:
        """
        Parse YAML string into dictionary.

        Args:
            data: YAML string

        Returns:
            Dictionary representation

        Raises:
            ValueError: If YAML is invalid
        """
        try:
            return yaml.safe_load(data)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML: {e}")

    def dump(self, questionnaire: Questionnaire, pretty: bool = True) -> str:
        """
        Serialize questionnaire to YAML string.

        Args:
            questionnaire: Questionnaire to serialize
            pretty: Whether to format for readability (always True for YAML)

        Returns:
            YAML string
        """
        # Convert Pydantic model to dict (mode='json' converts enums to values)
        data = questionnaire.model_dump(by_alias=True, exclude_none=True, mode='json')

        # YAML is always pretty-printed
        return yaml.dump(
            data,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
            indent=2
        )
