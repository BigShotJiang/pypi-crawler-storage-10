"""
Import/Export functionality for questionnaires.

This module provides a pluggable architecture for loading and saving
questionnaires in various formats (JSON, YAML, and custom formats).
"""

from .base import FormatHandler, register_format, get_format_handler
from .json_format import JSONFormat
from .yaml_format import YAMLFormat
from .quecode_format import QueCodeFormat
from .api import (
    load_questionnaire,
    save_questionnaire,
    loads_questionnaire,
    dumps_questionnaire,
    list_formats,
    convert_questionnaire,
)

# Register built-in formats
register_format("json", JSONFormat())
register_format("yaml", YAMLFormat())
register_format("yml", YAMLFormat())  # Alias
register_format("quecode", QueCodeFormat())
register_format("qc", QueCodeFormat())  # Alias


__all__ = [
    # Low-level API
    "FormatHandler",
    "register_format",
    "get_format_handler",
    "JSONFormat",
    "YAMLFormat",
    "QueCodeFormat",
    # High-level API
    "load_questionnaire",
    "save_questionnaire",
    "loads_questionnaire",
    "dumps_questionnaire",
    "list_formats",
    "convert_questionnaire",
]
