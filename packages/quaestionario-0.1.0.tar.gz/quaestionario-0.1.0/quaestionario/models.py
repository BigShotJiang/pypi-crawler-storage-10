"""
Pydantic models for the Quaestionario questionnaire system.
"""

from typing import Any, Dict, List, Optional, Union, Literal
from enum import Enum
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
from datetime import datetime


class ConditionOperator(str, Enum):
    """Operators for condition evaluation."""
    EQUAL = "="
    NOT_EQUAL = "!="
    LESS_THAN = "<"
    LESS_EQUAL = "<="
    GREATER_THAN = ">"
    GREATER_EQUAL = ">="
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    IN = "in"
    NOT_IN = "not_in"
    EXISTS = "exists"
    NOT_EXISTS = "not_exists"


class Condition(BaseModel):
    """A condition that determines question visibility or flow."""
    question: str = Field(min_length=1, description="Question ID to evaluate")
    operator: ConditionOperator
    value: Optional[Any] = Field(
        None, description="Value to compare against (not needed for exists/not_exists)"
    )

    @model_validator(mode='after')
    def validate_value_for_operator(self):
        """Validate that value is provided/omitted correctly based on operator."""
        if self.operator in (ConditionOperator.EXISTS, ConditionOperator.NOT_EXISTS):
            if self.value is not None:
                raise ValueError(f"Value should be None for {self.operator} operator")
        else:
            if self.value is None:
                raise ValueError(f"Value is required for {self.operator} operator")
        return self


class Option(BaseModel):
    """An option for choice-based questions."""
    value: Union[str, int, float, bool]
    label: str
    guideline: Optional[str] = None
    next: Optional[str] = Field(None, description="Next question ID")


class QuestionBase(BaseModel):
    """Base class for all question types."""
    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(min_length=1)
    type: str
    text: str
    guideline: Optional[str] = None
    facets: Optional[str] = None
    required: Optional[bool] = None
    conditions: Optional[List[Condition]] = None
    default_next: Optional[str] = Field(None, alias="defaultNext")
    meta: Optional[Dict[str, Any]] = None


class BooleanQuestion(QuestionBase):
    """Boolean (yes/no) question."""
    type: Literal["boolean"] = "boolean"


class TextShortQuestion(QuestionBase):
    """Short text input question."""
    type: Literal["text_short"] = "text_short"


class TextLongQuestion(QuestionBase):
    """Long text input question."""
    type: Literal["text_long"] = "text_long"


class NumberQuestion(QuestionBase):
    """Numeric input question."""
    type: Literal["number"] = "number"


class DateTimeMode(str, Enum):
    """Date/time input modes."""
    DATE = "date"
    TIME = "time"
    DATETIME = "datetime"


class DateTimeQuestion(QuestionBase):
    """Date/time input question."""
    type: Literal["date_time"] = "date_time"
    mode: DateTimeMode = DateTimeMode.DATE


class ScaleQuestion(QuestionBase):
    """Scale/rating question."""
    type: Literal["scale"] = "scale"
    min: float
    max: float
    step: Optional[float] = None
    labels: Optional[List[str]] = None

    @model_validator(mode='after')
    def max_greater_than_min(self):
        """Ensure max is greater than min."""
        if self.max <= self.min:
            raise ValueError('max must be greater than min')
        return self


class SingleChoiceQuestion(QuestionBase):
    """Single choice (radio button) question."""
    type: Literal["single_choice"] = "single_choice"
    options: List[Option] = Field(min_length=1)


class MultiChoiceQuestion(QuestionBase):
    """Multiple choice (checkbox) question."""
    model_config = ConfigDict(populate_by_name=True)

    type: Literal["multi_choice"] = "multi_choice"
    options: List[Option] = Field(min_length=1)
    max_selections: Optional[int] = Field(None, alias="maxSelections", ge=1)


# Union type for all question types
Question = Union[
    BooleanQuestion,
    TextShortQuestion,
    TextLongQuestion,
    NumberQuestion,
    DateTimeQuestion,
    ScaleQuestion,
    SingleChoiceQuestion,
    MultiChoiceQuestion,
]


class Questionnaire(BaseModel):
    """A complete questionnaire definition."""
    model_config = ConfigDict(populate_by_name=True)

    questionnaire_id: str = Field(min_length=1, alias="questionnaireId")
    version: Union[int, str]
    start_question: str = Field(min_length=1, alias="startQuestion")
    questions: List[Question] = Field(min_length=1)
    title: Optional[str] = None
    description: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None

    @field_validator('questions')
    @classmethod
    def validate_questions_have_unique_ids(cls, v):
        """Ensure all questions have unique IDs."""
        ids = [q.id for q in v]
        if len(ids) != len(set(ids)):
            raise ValueError("All questions must have unique IDs")
        return v

    @model_validator(mode='after')
    def validate_start_question_exists(self):
        """Ensure start_question references an existing question."""
        question_ids = {q.id for q in self.questions}
        if self.start_question not in question_ids:
            raise ValueError(f"start_question '{self.start_question}' must reference an existing question")
        return self

    def get_question_by_id(self, question_id: str) -> Optional[Question]:
        """Get a question by its ID."""
        for question in self.questions:
            if question.id == question_id:
                return question
        return None

    def get_all_question_ids(self) -> set[str]:
        """Get all question IDs in the questionnaire."""
        return {q.id for q in self.questions}