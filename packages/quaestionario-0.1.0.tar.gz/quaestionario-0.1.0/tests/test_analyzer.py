"""
Tests for questionnaire analyzer.
"""

import pytest
from quaestionario.models import (
    Questionnaire,
    BooleanQuestion,
    SingleChoiceQuestion,
    Option,
    Condition,
    ConditionOperator,
)
from quaestionario.analyzer import QuestionnaireAnalyzer


def create_conditional_questionnaire():
    """Create a questionnaire with conditional logic."""
    return Questionnaire(
        questionnaireId="conditional-test",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(
                id="q1",
                type="boolean",
                text="Are you over 18?",
                defaultNext="q2"
            ),
            BooleanQuestion(
                id="q2",
                type="boolean",
                text="Do you have a driver's license?",
                conditions=[
                    Condition(question="q1", operator=ConditionOperator.EQUAL, value=True)
                ],
                defaultNext="q3"
            ),
            BooleanQuestion(
                id="q3",
                type="boolean",
                text="Can you drive?",
                conditions=[
                    Condition(question="q2", operator=ConditionOperator.EQUAL, value=True)
                ]
            ),
            BooleanQuestion(
                id="q4",
                type="boolean",
                text="Are you a student?",
                conditions=[
                    Condition(question="q1", operator=ConditionOperator.EQUAL, value=False)
                ]
            )
        ]
    )


def create_branching_questionnaire():
    """Create a questionnaire with clear branching paths."""
    return Questionnaire(
        questionnaireId="branching-test",
        version="1.0",
        startQuestion="start",
        questions=[
            SingleChoiceQuestion(
                id="start",
                type="single_choice",
                text="Choose your path",
                options=[
                    Option(value="left", label="Go left", next="left_q1"),
                    Option(value="right", label="Go right", next="right_q1"),
                ]
            ),
            BooleanQuestion(
                id="left_q1",
                type="boolean",
                text="Left path question 1",
                defaultNext="common_end"
            ),
            BooleanQuestion(
                id="right_q1",
                type="boolean",
                text="Right path question 1",
                defaultNext="right_q2"
            ),
            BooleanQuestion(
                id="right_q2",
                type="boolean",
                text="Right path question 2",
                defaultNext="common_end"
            ),
            BooleanQuestion(
                id="common_end",
                type="boolean",
                text="This question appears in ALL paths"
            ),
        ]
    )


def test_always_required_questions():
    """Test identifying always required questions with proper branching analysis."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # With no answers, only q1 should be always required (start question)
    current_answers = {}
    always_required = analyzer.get_always_required_questions(current_answers)
    assert "q1" in always_required

    # With q1 answered as True, q2 becomes reachable but may not be always required
    # depending on whether there are alternative paths
    current_answers = {"q1": True}
    always_required = analyzer.get_always_required_questions(current_answers)
    # The specific assertions depend on the actual questionnaire structure and branching


def test_always_required_with_branching():
    """Test always required questions with clear branching paths."""
    questionnaire = create_branching_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # With no answers, both 'start' and 'common_end' should be always required
    # because 'common_end' appears in ALL possible paths
    current_answers = {}
    always_required = analyzer.get_always_required_questions(current_answers)
    assert "start" in always_required
    assert "common_end" in always_required
    # left_q1 and right_q1/right_q2 are NOT always required because they depend on the path chosen

    # After choosing left path
    current_answers = {"start": "left"}
    always_required = analyzer.get_always_required_questions(current_answers)
    assert "left_q1" in always_required
    assert "common_end" in always_required
    assert "right_q1" not in always_required
    assert "right_q2" not in always_required

    # After choosing right path
    current_answers = {"start": "right"}
    always_required = analyzer.get_always_required_questions(current_answers)
    assert "right_q1" in always_required
    assert "right_q2" in always_required
    assert "common_end" in always_required
    assert "left_q1" not in always_required


def test_optimal_next_questions():
    """Test getting optimal next questions."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # At start, q1 should be suggested
    current_answers = {}
    optimal = analyzer.get_optimal_next_questions(current_answers)
    assert "q1" in optimal

    # After answering q1 as True, q2 should be suggested
    current_answers = {"q1": True}
    optimal = analyzer.get_optimal_next_questions(current_answers)
    assert "q2" in optimal


def test_completion_bounds():
    """Test calculating completion bounds."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # At start
    current_answers = {}
    min_remaining, max_remaining = analyzer.get_completion_bounds(current_answers)
    assert min_remaining >= 0
    assert max_remaining >= min_remaining

    # After answering some questions
    current_answers = {"q1": True, "q2": True}
    min_remaining, max_remaining = analyzer.get_completion_bounds(current_answers)
    assert min_remaining >= 0
    assert max_remaining >= min_remaining


def test_conditional_dependencies():
    """Test getting conditional dependencies."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # q2 depends on q1
    deps = analyzer.get_conditional_dependencies("q2")
    assert "q1" in deps
    assert len(deps["q1"]) == 1
    assert deps["q1"][0].operator == ConditionOperator.EQUAL

    # q3 depends on q2
    deps = analyzer.get_conditional_dependencies("q3")
    assert "q2" in deps

    # q4 depends on q1 (condition: q1 = False)
    deps = analyzer.get_conditional_dependencies("q4")
    assert "q1" in deps
    assert len(deps["q1"]) == 1
    assert deps["q1"][0].operator == ConditionOperator.EQUAL
    assert deps["q1"][0].value == False


def test_questionnaire_complexity_analysis():
    """Test overall complexity analysis."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    complexity = analyzer.analyze_questionnaire_complexity()

    assert complexity["is_valid_dag"] is True
    assert complexity["total_questions"] == 4
    assert complexity["conditional_questions"] >= 2  # q2 and q3 have conditions
    assert complexity["min_path_length"] >= 1
    assert complexity["max_path_length"] >= complexity["min_path_length"]


def test_simulate_questionnaire_paths():
    """Test path simulation."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    paths = analyzer.simulate_questionnaire_paths(max_paths=10)
    assert len(paths) > 0
    assert all(isinstance(path, list) for path in paths)
    assert all(path[0] == "q1" for path in paths)  # All should start with q1


def test_condition_evaluation():
    """Test condition evaluation logic."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # Test various condition evaluations
    condition_eq = Condition(question="q1", operator=ConditionOperator.EQUAL, value=True)
    assert analyzer._evaluate_condition(condition_eq, {"q1": True}) is True
    assert analyzer._evaluate_condition(condition_eq, {"q1": False}) is False

    condition_exists = Condition(question="q1", operator=ConditionOperator.EXISTS)
    assert analyzer._evaluate_condition(condition_exists, {"q1": True}) is True
    assert analyzer._evaluate_condition(condition_exists, {}) is False

    condition_not_exists = Condition(question="q1", operator=ConditionOperator.NOT_EXISTS)
    assert analyzer._evaluate_condition(condition_not_exists, {}) is True
    assert analyzer._evaluate_condition(condition_not_exists, {"q1": True}) is False


def test_simple_questionnaire_analysis():
    """Test analysis on a simple linear questionnaire."""
    simple_questionnaire = Questionnaire(
        questionnaireId="simple",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Q1?", defaultNext="q2"),
            BooleanQuestion(id="q2", type="boolean", text="Q2?"),
        ]
    )

    analyzer = QuestionnaireAnalyzer(simple_questionnaire)
    complexity = analyzer.analyze_questionnaire_complexity()

    assert complexity["is_valid_dag"] is True
    assert complexity["total_questions"] == 2
    assert complexity["conditional_questions"] == 0
    assert complexity["possible_paths"] == 1
    assert complexity["min_path_length"] == 2
    assert complexity["max_path_length"] == 2


def test_get_next_question_linear():
    """Test get_next_question on a linear questionnaire."""
    questionnaire = Questionnaire(
        questionnaireId="linear",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Q1?", defaultNext="q2"),
            BooleanQuestion(id="q2", type="boolean", text="Q2?", defaultNext="q3"),
            BooleanQuestion(id="q3", type="boolean", text="Q3?"),
        ]
    )

    analyzer = QuestionnaireAnalyzer(questionnaire)

    # No answers - should return start question
    assert analyzer.get_next_question({}) == "q1"

    # After answering q1
    assert analyzer.get_next_question({"q1": True}) == "q2"

    # After answering q1 and q2
    assert analyzer.get_next_question({"q1": True, "q2": False}) == "q3"

    # After answering all questions
    assert analyzer.get_next_question({"q1": True, "q2": False, "q3": True}) is None


def test_get_next_question_branching():
    """Test get_next_question with branching logic."""
    questionnaire = create_branching_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # Start with no answers
    assert analyzer.get_next_question({}) == "start"

    # After choosing left path
    assert analyzer.get_next_question({"start": "left"}) == "left_q1"

    # After completing left path
    assert analyzer.get_next_question({"start": "left", "left_q1": True}) == "common_end"

    # After choosing right path
    assert analyzer.get_next_question({"start": "right"}) == "right_q1"

    # After first question on right path
    assert analyzer.get_next_question({"start": "right", "right_q1": True}) == "right_q2"


def test_get_next_question_conditional():
    """Test get_next_question with conditional logic."""
    questionnaire = create_conditional_questionnaire()
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # Start
    assert analyzer.get_next_question({}) == "q1"

    # After q1=True, q2 should be next (has condition: q1=True)
    assert analyzer.get_next_question({"q1": True}) == "q2"

    # After q1=False, q4 should be next (has condition: q1=False)
    assert analyzer.get_next_question({"q1": False}) == "q4"

    # After q1=True, q2=True, q3 should be next
    assert analyzer.get_next_question({"q1": True, "q2": True}) == "q3"