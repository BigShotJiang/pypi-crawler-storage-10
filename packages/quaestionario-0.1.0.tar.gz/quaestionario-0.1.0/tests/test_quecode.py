"""
Tests for QueCode format.
"""

import pytest
from pathlib import Path
from tempfile import TemporaryDirectory

from quaestionario import (
    load_questionnaire,
    save_questionnaire,
    loads_questionnaire,
    dumps_questionnaire,
    Questionnaire,
    BooleanQuestion,
    SingleChoiceQuestion,
    MultiChoiceQuestion,
    ScaleQuestion,
    NumberQuestion,
    Option,
    Condition,
)


def test_simple_quecode_parsing():
    """Test parsing a simple QueCode document."""
    quecode = '''
quecode id="test" version=1 start=Q1

Q1 boolean "Do you like Python?"
  default -> Q2

Q2 text_short "What's your name?"
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert q.questionnaire_id == "test"
    assert q.version == 1  # Version is parsed as int when numeric
    assert q.start_question == "Q1"
    assert len(q.questions) == 2
    assert q.questions[0].id == "Q1"
    assert q.questions[0].type == "boolean"
    assert q.questions[0].text == "Do you like Python?"
    assert q.questions[0].default_next == "Q2"


def test_quecode_with_metadata():
    """Test QueCode with title, description, and metadata."""
    quecode = '''
quecode id="test-meta" version="1.0" start=Q1 title="Test Survey" description="A test questionnaire" meta={"channel":"beta"}

Q1 boolean "Question?"
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert q.title == "Test Survey"
    assert q.description == "A test questionnaire"
    assert q.meta == {"channel": "beta"}


def test_single_choice_with_options():
    """Test parsing single choice with options."""
    quecode = '''
quecode id="choice-test" version=1 start=Q1

Q1 single_choice "Choose your preference?"
  option remote -> Q2 "Work remotely"
  option office -> Q3 "Work from office"
  option hybrid "Hybrid schedule"

Q2 boolean "Remote question?"

Q3 boolean "Office question?"
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert len(q.questions) == 3
    question = q.questions[0]
    assert question.type == "single_choice"
    assert len(question.options) == 3

    assert question.options[0].value == "remote"
    assert question.options[0].next == "Q2"
    assert question.options[0].label == "Work remotely"

    assert question.options[1].value == "office"
    assert question.options[1].next == "Q3"

    assert question.options[2].value == "hybrid"
    assert question.options[2].next is None


def test_option_with_guidance():
    """Test parsing options with guideline."""
    quecode = '''
quecode id="guidance-test" version=1 start=Q1

Q1 single_choice "Choose?"
  option yes "Yes" | "Select this if you agree"
  option no "No" | "Select this if you disagree"
'''

    q = loads_questionnaire(quecode, format="quecode")

    options = q.questions[0].options
    assert options[0].guideline == "Select this if you agree"
    assert options[1].guideline == "Select this if you disagree"


def test_multi_choice_with_max_selections():
    """Test parsing multi-choice with maxSelections."""
    quecode = '''
quecode id="multi-test" version=1 start=Q1

Q1 multi_choice "Select up to 2 options"
  maxSelections 2
  option python "Python"
  option rust "Rust"
  option go "Go"
  default -> Q2

Q2 boolean "Done?"
'''

    q = loads_questionnaire(quecode, format="quecode")

    question = q.questions[0]
    assert question.type == "multi_choice"
    assert question.max_selections == 2
    assert len(question.options) == 3
    assert question.default_next == "Q2"


def test_scale_question():
    """Test parsing scale question with min, max, step, labels."""
    quecode = '''
quecode id="scale-test" version=1 start=Q1

Q1 scale "Rate your experience"
  min 1
  max 5
  step 1
  labels "Poor" | "Good" | "Excellent"
'''

    q = loads_questionnaire(quecode, format="quecode")

    question = q.questions[0]
    assert question.type == "scale"
    assert question.min == 1
    assert question.max == 5
    assert question.step == 1
    assert question.labels == ["Poor", "Good", "Excellent"]


def test_number_question():
    """Test parsing number question."""
    quecode = '''
quecode id="number-test" version=1 start=Q1

Q1 number "Enter your age"
'''

    q = loads_questionnaire(quecode, format="quecode")

    question = q.questions[0]
    assert question.type == "number"


def test_required_directive():
    """Test parsing required directive."""
    quecode = '''
quecode id="required-test" version=1 start=Q1

Q1 boolean "Required question?"
  required
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert q.questions[0].required is True


def test_guideline_directive():
    """Test parsing guideline directive."""
    quecode = '''
quecode id="guideline-test" version=1 start=Q1

Q1 text_short "Enter your name"
  guideline "Please use your full legal name"
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert q.questions[0].guideline == "Please use your full legal name"


def test_conditions():
    """Test parsing conditions with various operators."""
    quecode = '''
quecode id="condition-test" version=1 start=Q1

Q1 single_choice "Choose?"
  option yes "Yes"
  option no "No"

Q2 boolean "Follow-up?"
  when Q1 = "yes"

Q3 boolean "Another follow-up?"
  when Q1 != "no"
'''

    q = loads_questionnaire(quecode, format="quecode")

    q2_condition = q.questions[1].conditions[0]
    assert q2_condition.question == "Q1"
    assert q2_condition.operator == "="
    assert q2_condition.value == "yes"

    q3_condition = q.questions[2].conditions[0]
    assert q3_condition.question == "Q1"
    assert q3_condition.operator == "!="
    assert q3_condition.value == "no"


def test_contains_operator():
    """Test parsing contains operator for multi-choice."""
    quecode = '''
quecode id="contains-test" version=1 start=Q1

Q1 multi_choice "Select languages"
  option python "Python"
  option rust "Rust"
  option go "Go"

Q2 boolean "You like Python?"
  when Q1 contains "python"
'''

    q = loads_questionnaire(quecode, format="quecode")

    condition = q.questions[1].conditions[0]
    assert condition.operator == "contains"
    assert condition.value == "python"


def test_in_operator():
    """Test parsing 'in' operator with list."""
    quecode = '''
quecode id="in-test" version=1 start=Q1

Q1 single_choice "Choose?"
  option a "Option A"
  option b "Option B"
  option c "Option C"

Q2 boolean "Is A or B?"
  when Q1 in ["a", "b"]
'''

    q = loads_questionnaire(quecode, format="quecode")

    condition = q.questions[1].conditions[0]
    assert condition.operator == "in"
    assert condition.value == ["a", "b"]


def test_comparison_operators():
    """Test numeric comparison operators."""
    quecode = '''
quecode id="comparison-test" version=1 start=Q1

Q1 scale "Rate"
  min 1
  max 10

Q2 boolean "High rating?"
  when Q1 >= 7

Q3 boolean "Low rating?"
  when Q1 < 4
'''

    q = loads_questionnaire(quecode, format="quecode")

    q2_condition = q.questions[1].conditions[0]
    assert q2_condition.operator == ">="
    assert q2_condition.value == 7

    q3_condition = q.questions[2].conditions[0]
    assert q3_condition.operator == "<"
    assert q3_condition.value == 4


def test_exists_operator():
    """Test exists and not_exists operators."""
    quecode = '''
quecode id="exists-test" version=1 start=Q1

Q1 text_short "Optional input"

Q2 boolean "Input provided?"
  when Q1 exists

Q3 boolean "No input?"
  when Q1 not_exists
'''

    q = loads_questionnaire(quecode, format="quecode")

    q2_condition = q.questions[1].conditions[0]
    assert q2_condition.operator == "exists"

    q3_condition = q.questions[2].conditions[0]
    assert q3_condition.operator == "not_exists"


def test_quecode_serialization():
    """Test serializing questionnaire to QueCode."""
    q = Questionnaire(
        questionnaireId="serialize-test",
        version="1.0",
        startQuestion="Q1",
        title="Test Questionnaire",
        questions=[
            BooleanQuestion(
                id="Q1",
                type="boolean",
                text="Do you like Python?",
                defaultNext="Q2"
            ),
            SingleChoiceQuestion(
                id="Q2",
                type="single_choice",
                text="Choose your favorite:",
                options=[
                    Option(value="python", label="Python", next="Q3"),
                    Option(value="rust", label="Rust"),
                ]
            ),
        ]
    )

    quecode = dumps_questionnaire(q, format="quecode")

    # Should contain header
    assert 'quecode id="serialize-test"' in quecode
    assert 'version=1.0' in quecode or 'version="1.0"' in quecode
    assert 'start=Q1' in quecode
    assert 'title="Test Questionnaire"' in quecode

    # Should contain questions
    assert 'Q1 boolean "Do you like Python?"' in quecode
    assert 'default -> Q2' in quecode
    assert 'Q2 single_choice "Choose your favorite:"' in quecode
    assert 'option python -> Q3 "Python"' in quecode


def test_roundtrip_simple():
    """Test round-trip conversion: QueCode -> Questionnaire -> QueCode."""
    original_quecode = '''quecode id="roundtrip" version=1 start=Q1 title="Test"

Q1 boolean "Question?"
  default -> Q2

Q2 text_short "Name?"
'''

    # Parse
    q = loads_questionnaire(original_quecode, format="quecode")

    # Serialize
    new_quecode = dumps_questionnaire(q, format="quecode")

    # Parse again
    q2 = loads_questionnaire(new_quecode, format="quecode")

    # Should be equivalent
    assert q.questionnaire_id == q2.questionnaire_id
    assert q.version == q2.version
    assert q.start_question == q2.start_question
    assert len(q.questions) == len(q2.questions)


def test_roundtrip_complex():
    """Test round-trip with complex questionnaire."""
    original_quecode = '''quecode id="complex" version="2.0" start=Q1 title="Complex Survey"

Q1 single_choice "Choose work style?"
  option remote -> Q2 "Remote"
  option office -> Q3 "Office"

Q2 boolean "Track sleep?"
  required
  guideline "This helps us understand your habits"
  default -> Q4
  when Q1 = "remote"

Q3 scale "Rate office?"
  min 1
  max 5
  step 1
  labels "Poor" | "Good" | "Excellent"
  when Q1 = "office"

Q4 multi_choice "Select perks"
  maxSelections 2
  option hardware "Hardware"
  option coaching "Coaching"
'''

    q1 = loads_questionnaire(original_quecode, format="quecode")
    quecode2 = dumps_questionnaire(q1, format="quecode")
    q2 = loads_questionnaire(quecode2, format="quecode")

    assert q1.questionnaire_id == q2.questionnaire_id
    assert len(q1.questions) == len(q2.questions)
    assert q1.questions[1].required == q2.questions[1].required
    assert q1.questions[1].guideline == q2.questions[1].guideline


def test_save_and_load_quecode_file():
    """Test saving and loading QueCode files."""
    q = Questionnaire(
        questionnaireId="file-test",
        version="1.0",
        startQuestion="Q1",
        questions=[
            BooleanQuestion(id="Q1", type="boolean", text="Question?")
        ]
    )

    with TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / "test.qc"

        # Save
        save_questionnaire(q, file_path)

        # Load
        loaded_q = load_questionnaire(file_path)

        assert loaded_q.questionnaire_id == q.questionnaire_id


def test_quecode_comments():
    """Test that comments are stripped."""
    quecode = '''
# This is a comment
quecode id="comment-test" version=1 start=Q1

Q1 boolean "Question?"  # Inline comment
  // C-style comment
  default -> Q2

Q2 text_short "Name?"
'''

    q = loads_questionnaire(quecode, format="quecode")

    assert q.questionnaire_id == "comment-test"
    assert len(q.questions) == 2


def test_convert_json_to_quecode():
    """Test converting from JSON to QueCode."""
    from quaestionario.io import convert_questionnaire

    q = Questionnaire(
        questionnaireId="convert-test",
        version="1.0",
        startQuestion="Q1",
        questions=[
            BooleanQuestion(id="Q1", type="boolean", text="Question?")
        ]
    )

    with TemporaryDirectory() as tmpdir:
        json_path = Path(tmpdir) / "input.json"
        qc_path = Path(tmpdir) / "output.qc"

        # Save as JSON
        save_questionnaire(q, json_path)

        # Convert to QueCode
        convert_questionnaire(json_path, qc_path)

        # Load QueCode
        loaded_q = load_questionnaire(qc_path)

        assert loaded_q.questionnaire_id == q.questionnaire_id


def test_invalid_quecode():
    """Test error handling for invalid QueCode."""
    # Missing header
    with pytest.raises(ValueError, match="Invalid QueCode"):
        loads_questionnaire("Q1 boolean 'test'", format="quecode")

    # Invalid header
    with pytest.raises(ValueError, match="Invalid QueCode"):
        loads_questionnaire("invalid header", format="quecode")


def test_quecode_with_conditions_serialization():
    """Test that conditions are properly serialized."""
    q = Questionnaire(
        questionnaireId="cond-serial",
        version="1.0",
        startQuestion="Q1",
        questions=[
            SingleChoiceQuestion(
                id="Q1",
                type="single_choice",
                text="Choose?",
                options=[Option(value="yes", label="Yes")]
            ),
            BooleanQuestion(
                id="Q2",
                type="boolean",
                text="Follow-up?",
                conditions=[
                    Condition(question="Q1", operator="=", value="yes")
                ]
            ),
        ]
    )

    quecode = dumps_questionnaire(q, format="quecode")

    # Value can be quoted or unquoted depending on content
    assert 'when Q1 = yes' in quecode or 'when Q1 = "yes"' in quecode


def test_quecode_format_in_list():
    """Test that QueCode format appears in format list."""
    from quaestionario import list_formats

    formats = list_formats()

    assert "quecode" in formats
    assert "qc" in formats
    assert formats["quecode"]["name"] == "QueCode"
    assert "qc" in formats["quecode"]["extensions"]
