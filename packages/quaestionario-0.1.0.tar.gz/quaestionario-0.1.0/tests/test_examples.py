"""
Tests for example questionnaires.
"""

import pytest
from examples import (
    load_example,
    list_examples,
    get_example_info,
    analyze_example,
    validate_all_examples,
    SIMPLE_SURVEY,
    PRODUCT_RECOMMENDATION,
    MEDICAL_SCREENING,
    ATHLETE_HABITS,
)
from quaestionario import QuestionnaireGraph, QuestionnaireAnalyzer


def test_list_examples():
    """Test listing available examples."""
    examples = list_examples()
    assert len(examples) > 0
    assert isinstance(examples, list)
    assert all(isinstance(name, str) for name in examples)


def test_validate_all_examples():
    """Test that all examples validate successfully."""
    results = validate_all_examples()
    assert len(results) > 0

    # All examples should be valid
    for name, is_valid in results.items():
        assert is_valid, f"Example '{name}' failed validation"


def test_load_simple_survey():
    """Test loading the simple survey example."""
    questionnaire = load_example(SIMPLE_SURVEY)
    assert questionnaire.questionnaire_id == "simple-survey-v1"
    assert len(questionnaire.questions) == 3
    assert questionnaire.start_question == "satisfaction"


def test_load_product_recommendation():
    """Test loading the product recommendation example."""
    questionnaire = load_example(PRODUCT_RECOMMENDATION)
    assert questionnaire.questionnaire_id == "product-recommendation-v1"
    assert len(questionnaire.questions) == 8


def test_load_medical_screening():
    """Test loading the medical screening example."""
    questionnaire = load_example(MEDICAL_SCREENING)
    assert questionnaire.questionnaire_id == "medical-screening-v1"
    assert len(questionnaire.questions) == 13


def test_load_athlete_habits():
    """Test loading the athlete habits example."""
    questionnaire = load_example(ATHLETE_HABITS)
    assert questionnaire.questionnaire_id == "athlete-habits-v2"
    assert len(questionnaire.questions) == 17


def test_get_example_info():
    """Test getting example metadata."""
    info = get_example_info(SIMPLE_SURVEY)
    assert "id" in info
    assert "title" in info
    assert "num_questions" in info
    assert info["num_questions"] == 3


def test_analyze_example():
    """Test analyzing an example."""
    analysis = analyze_example(SIMPLE_SURVEY)
    assert "metadata" in analysis
    assert "complexity" in analysis
    assert analysis["complexity"]["is_valid_dag"] is True


def test_graph_validation():
    """Test that all examples form valid DAGs."""
    for example_name in list_examples():
        questionnaire = load_example(example_name)
        graph = QuestionnaireGraph(questionnaire)
        is_valid, errors = graph.validate_dag()
        assert is_valid, f"Example '{example_name}' has validation errors: {errors}"


def test_weakly_connected():
    """Test that examples are weakly connected."""
    # Simple survey and product recommendation should be weakly connected
    for example_name in [SIMPLE_SURVEY, PRODUCT_RECOMMENDATION]:
        questionnaire = load_example(example_name)
        graph = QuestionnaireGraph(questionnaire)
        assert graph.is_weakly_connected(), f"Example '{example_name}' is not weakly connected"


def test_no_unreachable_questions():
    """Test that examples have no unreachable questions."""
    for example_name in [SIMPLE_SURVEY, PRODUCT_RECOMMENDATION]:
        questionnaire = load_example(example_name)
        graph = QuestionnaireGraph(questionnaire)
        unreachable = graph.get_unreachable_questions()
        assert len(unreachable) == 0, f"Example '{example_name}' has unreachable questions: {unreachable}"


def test_analyzer_on_examples():
    """Test analyzer functionality on examples."""
    questionnaire = load_example(ATHLETE_HABITS)
    analyzer = QuestionnaireAnalyzer(questionnaire)

    # Test initial state
    always_required = analyzer.get_always_required_questions({})
    assert "Q1" in always_required  # Start question should be always required

    # Test with some answers
    current_answers = {"Q1": "endurance"}
    always_required = analyzer.get_always_required_questions(current_answers)
    assert "Q1" not in always_required  # Already answered

    # Test optimal next questions
    optimal = analyzer.get_optimal_next_questions(current_answers)
    assert len(optimal) > 0

    # Test completion bounds
    min_q, max_q = analyzer.get_completion_bounds(current_answers)
    assert min_q >= 0
    assert max_q >= min_q


def test_path_simulation():
    """Test path simulation on examples."""
    questionnaire = load_example(PRODUCT_RECOMMENDATION)
    analyzer = QuestionnaireAnalyzer(questionnaire)

    paths = analyzer.simulate_questionnaire_paths(max_paths=20)
    assert len(paths) > 0
    assert all(isinstance(path, list) for path in paths)
    assert all(path[0] == "user_type" for path in paths)  # All start with user_type


def test_complexity_analysis():
    """Test complexity analysis on examples."""
    analysis = analyze_example(ATHLETE_HABITS)
    complexity = analysis["complexity"]

    assert complexity["total_questions"] == 17
    assert complexity["conditional_questions"] > 0
    assert complexity["possible_paths"] > 0
    assert complexity["min_path_length"] > 0
    assert complexity["max_path_length"] >= complexity["min_path_length"]
    assert complexity["is_valid_dag"] is True


def test_load_nonexistent_example():
    """Test loading a non-existent example raises error."""
    with pytest.raises(FileNotFoundError):
        load_example("nonexistent_example")
