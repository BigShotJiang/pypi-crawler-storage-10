"""
Tests for import/export functionality.
"""

import pytest
import json
import yaml
from pathlib import Path
from tempfile import TemporaryDirectory

from quaestionario import (
    load_questionnaire,
    save_questionnaire,
    loads_questionnaire,
    dumps_questionnaire,
    list_formats,
    Questionnaire,
    BooleanQuestion,
    SingleChoiceQuestion,
    Option,
)
from quaestionario.io import register_format, FormatHandler, get_format_handler


# Sample questionnaire for testing
def create_test_questionnaire():
    """Create a simple test questionnaire."""
    return Questionnaire(
        questionnaireId="test-io",
        version="1.0",
        startQuestion="q1",
        title="Test Questionnaire",
        questions=[
            BooleanQuestion(
                id="q1",
                type="boolean",
                text="Question 1?",
                defaultNext="q2"
            ),
            SingleChoiceQuestion(
                id="q2",
                type="single_choice",
                text="Question 2?",
                options=[
                    Option(value="a", label="Option A"),
                    Option(value="b", label="Option B"),
                ]
            ),
        ]
    )


def test_list_formats():
    """Test listing available formats."""
    formats = list_formats()

    assert "json" in formats
    assert "yaml" in formats
    assert "yml" in formats

    assert formats["json"]["name"] == "JSON"
    assert "json" in formats["json"]["extensions"]


def test_json_dumps():
    """Test dumping questionnaire to JSON string."""
    q = create_test_questionnaire()

    json_str = dumps_questionnaire(q, format="json")

    # Should be valid JSON
    data = json.loads(json_str)
    assert data["questionnaireId"] == "test-io"
    assert data["version"] == "1.0"
    assert len(data["questions"]) == 2


def test_json_dumps_compact():
    """Test compact JSON output."""
    q = create_test_questionnaire()

    json_str = dumps_questionnaire(q, format="json", pretty=False)

    # Should not have newlines
    assert "\n" not in json_str

    # Should still be valid
    data = json.loads(json_str)
    assert data["questionnaireId"] == "test-io"


def test_json_loads():
    """Test loading questionnaire from JSON string."""
    json_str = '''
    {
        "questionnaireId": "test-loads",
        "version": "1.0",
        "startQuestion": "q1",
        "questions": [
            {
                "id": "q1",
                "type": "boolean",
                "text": "Test?"
            }
        ]
    }
    '''

    q = loads_questionnaire(json_str, format="json")

    assert q.questionnaire_id == "test-loads"
    assert q.version == "1.0"
    assert len(q.questions) == 1


def test_yaml_dumps():
    """Test dumping questionnaire to YAML string."""
    q = create_test_questionnaire()

    yaml_str = dumps_questionnaire(q, format="yaml")

    # Should be valid YAML
    data = yaml.safe_load(yaml_str)
    assert data["questionnaireId"] == "test-io"
    assert data["version"] == "1.0"
    assert len(data["questions"]) == 2


def test_yaml_loads():
    """Test loading questionnaire from YAML string."""
    yaml_str = """
questionnaireId: test-yaml-loads
version: "1.0"
startQuestion: q1
questions:
  - id: q1
    type: boolean
    text: YAML Test?
"""

    q = loads_questionnaire(yaml_str, format="yaml")

    assert q.questionnaire_id == "test-yaml-loads"
    assert q.version == "1.0"
    assert len(q.questions) == 1


def test_save_and_load_json():
    """Test saving and loading JSON file."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / "test.json"

        # Save
        save_questionnaire(q, file_path)

        # File should exist
        assert file_path.exists()

        # Load back
        loaded_q = load_questionnaire(file_path)

        # Should match
        assert loaded_q.questionnaire_id == q.questionnaire_id
        assert loaded_q.version == q.version
        assert len(loaded_q.questions) == len(q.questions)


def test_save_and_load_yaml():
    """Test saving and loading YAML file."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / "test.yaml"

        # Save
        save_questionnaire(q, file_path)

        # File should exist
        assert file_path.exists()

        # Load back
        loaded_q = load_questionnaire(file_path)

        # Should match
        assert loaded_q.questionnaire_id == q.questionnaire_id
        assert loaded_q.version == q.version
        assert len(loaded_q.questions) == len(q.questions)


def test_format_auto_detection():
    """Test automatic format detection from file extension."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        json_path = Path(tmpdir) / "test.json"
        yaml_path = Path(tmpdir) / "test.yaml"
        yml_path = Path(tmpdir) / "test.yml"

        # Save with auto-detection
        save_questionnaire(q, json_path)
        save_questionnaire(q, yaml_path)
        save_questionnaire(q, yml_path)

        # Load with auto-detection
        q_json = load_questionnaire(json_path)
        q_yaml = load_questionnaire(yaml_path)
        q_yml = load_questionnaire(yml_path)

        assert q_json.questionnaire_id == q.questionnaire_id
        assert q_yaml.questionnaire_id == q.questionnaire_id
        assert q_yml.questionnaire_id == q.questionnaire_id


def test_explicit_format():
    """Test explicit format specification."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        # Save JSON with .txt extension
        file_path = Path(tmpdir) / "data.txt"

        save_questionnaire(q, file_path, format="json")

        # Load with explicit format
        loaded_q = load_questionnaire(file_path, format="json")

        assert loaded_q.questionnaire_id == q.questionnaire_id


def test_save_overwrite_protection():
    """Test that save doesn't overwrite by default."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / "test.json"

        # Save once
        save_questionnaire(q, file_path)

        # Try to save again without overwrite
        with pytest.raises(FileExistsError):
            save_questionnaire(q, file_path)

        # With overwrite should work
        save_questionnaire(q, file_path, overwrite=True)


def test_load_nonexistent_file():
    """Test loading non-existent file."""
    with pytest.raises(FileNotFoundError):
        load_questionnaire("nonexistent.json")


def test_unknown_format():
    """Test handling of unknown format."""
    q = create_test_questionnaire()

    with pytest.raises(ValueError, match="Unknown format"):
        dumps_questionnaire(q, format="unknown")

    with pytest.raises(ValueError, match="Unknown format"):
        loads_questionnaire("{}", format="unknown")


def test_unknown_extension():
    """Test handling of unknown file extension."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / "test.xyz"

        # Should raise error without explicit format
        with pytest.raises(ValueError, match="Could not detect format"):
            save_questionnaire(q, file_path)

        # Should work with explicit format
        save_questionnaire(q, file_path, format="json")


def test_invalid_json():
    """Test loading invalid JSON."""
    invalid_json = "{ this is not valid json"

    with pytest.raises(ValueError, match="Invalid JSON"):
        loads_questionnaire(invalid_json, format="json")


def test_invalid_yaml():
    """Test loading invalid YAML."""
    invalid_yaml = ":\n  this: is: not: valid"

    with pytest.raises(ValueError, match="Invalid YAML"):
        loads_questionnaire(invalid_yaml, format="yaml")


def test_validation_on_load():
    """Test that validation catches invalid questionnaires."""
    # Questionnaire with cycle
    invalid_json = '''
    {
        "questionnaireId": "invalid",
        "version": "1.0",
        "startQuestion": "q1",
        "questions": [
            {"id": "q1", "type": "boolean", "text": "Q1?", "defaultNext": "q2"},
            {"id": "q2", "type": "boolean", "text": "Q2?", "defaultNext": "q1"}
        ]
    }
    '''

    with pytest.raises(ValueError, match="Invalid questionnaire"):
        loads_questionnaire(invalid_json, format="json", validate=True)

    # Should work with validate=False
    q = loads_questionnaire(invalid_json, format="json", validate=False)
    assert q.questionnaire_id == "invalid"


def test_roundtrip_json_to_yaml():
    """Test converting from JSON to YAML and back."""
    q = create_test_questionnaire()

    # JSON -> YAML -> JSON
    json_str1 = dumps_questionnaire(q, format="json")
    q_from_json = loads_questionnaire(json_str1, format="json")

    yaml_str = dumps_questionnaire(q_from_json, format="yaml")
    q_from_yaml = loads_questionnaire(yaml_str, format="yaml")

    json_str2 = dumps_questionnaire(q_from_yaml, format="json")

    # Should produce equivalent questionnaires
    data1 = json.loads(json_str1)
    data2 = json.loads(json_str2)

    assert data1["questionnaireId"] == data2["questionnaireId"]
    assert len(data1["questions"]) == len(data2["questions"])


def test_subdirectory_creation():
    """Test that save creates parent directories."""
    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        # Nested path that doesn't exist
        file_path = Path(tmpdir) / "subdir1" / "subdir2" / "test.json"

        # Should create directories
        save_questionnaire(q, file_path)

        assert file_path.exists()


def test_custom_format_handler():
    """Test registering a custom format handler."""

    class SimpleFormat(FormatHandler):
        @property
        def name(self) -> str:
            return "Simple"

        @property
        def extensions(self) -> list[str]:
            return ["simple"]

        def load(self, data: str):
            # Very simple format: just JSON with a prefix
            return json.loads(data.replace("SIMPLE:", ""))

        def dump(self, questionnaire, pretty=True):
            json_str = json.dumps(
                questionnaire.model_dump(by_alias=True, exclude_none=True),
                indent=2 if pretty else None
            )
            return f"SIMPLE:{json_str}"

    # Register it
    register_format("simple", SimpleFormat())

    # Should be in list
    formats = list_formats()
    assert "simple" in formats

    # Test it
    q = create_test_questionnaire()
    simple_str = dumps_questionnaire(q, format="simple")

    assert simple_str.startswith("SIMPLE:")

    # Load back
    q_loaded = loads_questionnaire(simple_str, format="simple")
    assert q_loaded.questionnaire_id == q.questionnaire_id


def test_convert_questionnaire():
    """Test format conversion utility."""
    from quaestionario.io import convert_questionnaire

    q = create_test_questionnaire()

    with TemporaryDirectory() as tmpdir:
        json_path = Path(tmpdir) / "input.json"
        yaml_path = Path(tmpdir) / "output.yaml"

        # Save as JSON
        save_questionnaire(q, json_path)

        # Convert to YAML
        convert_questionnaire(json_path, yaml_path)

        # Both should exist
        assert json_path.exists()
        assert yaml_path.exists()

        # Load YAML
        q_yaml = load_questionnaire(yaml_path)
        assert q_yaml.questionnaire_id == q.questionnaire_id
