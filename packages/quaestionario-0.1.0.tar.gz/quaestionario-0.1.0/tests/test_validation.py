"""
Tests for answer validation.
"""

import pytest
from quaestionario.models import (
    BooleanQuestion,
    TextShortQuestion,
    TextLongQuestion,
    NumberQuestion,
    DateTimeQuestion,
    ScaleQuestion,
    SingleChoiceQuestion,
    MultiChoiceQuestion,
    Option,
)
from quaestionario.validation import (
    AnswerValidator,
    ValidationError,
    ValidationResult,
    validate_answer,
)


def test_boolean_validation():
    """Test validation of boolean answers."""
    question = BooleanQuestion(id="q1", type="boolean", text="Are you over 18?")
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, True, strict=False).is_valid
    assert validator.validate_answer(question, False, strict=False).is_valid

    # Invalid answers
    result = validator.validate_answer(question, "yes", strict=False)
    assert not result.is_valid
    assert "Expected boolean" in result.errors[0]

    result = validator.validate_answer(question, 1, strict=False)
    assert not result.is_valid

    # Strict mode should raise
    with pytest.raises(ValidationError) as exc_info:
        validator.validate_answer(question, "yes", strict=True)
    assert exc_info.value.question_id == "q1"


def test_text_short_validation():
    """Test validation of short text answers."""
    question = TextShortQuestion(id="q1", type="text_short", text="Your name?")
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, "John Doe", strict=False).is_valid
    assert validator.validate_answer(question, "A" * 100, strict=False).is_valid

    # Invalid answers - wrong type
    result = validator.validate_answer(question, 123, strict=False)
    assert not result.is_valid
    assert "Expected string" in result.errors[0]

    # Invalid answers - too long
    result = validator.validate_answer(question, "A" * 300, strict=False)
    assert not result.is_valid
    assert "too long" in result.errors[0]


def test_text_long_validation():
    """Test validation of long text answers."""
    question = TextLongQuestion(id="q1", type="text_long", text="Your story?")
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, "A" * 1000, strict=False).is_valid

    # Invalid answers - wrong type
    result = validator.validate_answer(question, ["list", "of", "strings"], strict=False)
    assert not result.is_valid


def test_number_validation():
    """Test validation of numeric answers."""
    question = NumberQuestion(id="q1", type="number", text="Your age?")
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, 25, strict=False).is_valid
    assert validator.validate_answer(question, 25.5, strict=False).is_valid

    # Invalid answers
    result = validator.validate_answer(question, "25", strict=False)
    assert not result.is_valid
    assert "Expected number" in result.errors[0]


def test_scale_validation():
    """Test validation of scale answers."""
    question = ScaleQuestion(
        id="q1",
        type="scale",
        text="Rate us",
        min=1,
        max=5,
        step=1
    )
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, 1, strict=False).is_valid
    assert validator.validate_answer(question, 3, strict=False).is_valid
    assert validator.validate_answer(question, 5, strict=False).is_valid

    # Invalid - below minimum
    result = validator.validate_answer(question, 0, strict=False)
    assert not result.is_valid
    assert "below minimum" in result.errors[0]

    # Invalid - above maximum
    result = validator.validate_answer(question, 10, strict=False)
    assert not result.is_valid
    assert "above maximum" in result.errors[0]

    # Invalid - wrong step
    result = validator.validate_answer(question, 2.5, strict=False)
    assert not result.is_valid
    assert "not a valid step" in result.errors[0]

    # Invalid - wrong type
    result = validator.validate_answer(question, "3", strict=False)
    assert not result.is_valid
    assert "Expected number" in result.errors[0]


def test_scale_validation_with_decimal_step():
    """Test scale validation with decimal steps."""
    question = ScaleQuestion(
        id="q1",
        type="scale",
        text="Rate",
        min=0,
        max=10,
        step=0.5
    )
    validator = AnswerValidator()

    # Valid
    assert validator.validate_answer(question, 0.5, strict=False).is_valid
    assert validator.validate_answer(question, 5.5, strict=False).is_valid
    assert validator.validate_answer(question, 10, strict=False).is_valid

    # Invalid step
    result = validator.validate_answer(question, 5.3, strict=False)
    assert not result.is_valid


def test_single_choice_validation():
    """Test validation of single choice answers."""
    question = SingleChoiceQuestion(
        id="q1",
        type="single_choice",
        text="Choose color",
        options=[
            Option(value="red", label="Red"),
            Option(value="blue", label="Blue"),
            Option(value="green", label="Green"),
        ]
    )
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, "red", strict=False).is_valid
    assert validator.validate_answer(question, "blue", strict=False).is_valid

    # Invalid - not in options
    result = validator.validate_answer(question, "yellow", strict=False)
    assert not result.is_valid
    assert "Invalid choice" in result.errors[0]
    assert "yellow" in result.errors[0]


def test_single_choice_validation_with_numeric_values():
    """Test single choice with numeric option values."""
    question = SingleChoiceQuestion(
        id="q1",
        type="single_choice",
        text="Choose number",
        options=[
            Option(value=1, label="One"),
            Option(value=2, label="Two"),
            Option(value=3, label="Three"),
        ]
    )
    validator = AnswerValidator()

    # Valid
    assert validator.validate_answer(question, 1, strict=False).is_valid
    assert validator.validate_answer(question, 2, strict=False).is_valid

    # Invalid
    result = validator.validate_answer(question, 5, strict=False)
    assert not result.is_valid


def test_multi_choice_validation():
    """Test validation of multiple choice answers."""
    question = MultiChoiceQuestion(
        id="q1",
        type="multi_choice",
        text="Choose hobbies",
        options=[
            Option(value="reading", label="Reading"),
            Option(value="sports", label="Sports"),
            Option(value="music", label="Music"),
            Option(value="cooking", label="Cooking"),
        ],
        max_selections=3
    )
    validator = AnswerValidator()

    # Valid answers
    assert validator.validate_answer(question, ["reading"], strict=False).is_valid
    assert validator.validate_answer(question, ["reading", "sports"], strict=False).is_valid
    assert validator.validate_answer(question, [], strict=False).is_valid  # Empty list OK

    # Invalid - not a list
    result = validator.validate_answer(question, "reading", strict=False)
    assert not result.is_valid
    assert "Expected list" in result.errors[0]

    # Invalid - invalid option
    result = validator.validate_answer(question, ["reading", "gaming"], strict=False)
    assert not result.is_valid
    assert "Invalid choice 'gaming'" in result.errors[0]

    # Invalid - too many selections
    result = validator.validate_answer(question, ["reading", "sports", "music", "cooking"], strict=False)
    assert not result.is_valid
    assert "Too many selections" in result.errors[0]


def test_required_validation():
    """Test validation of required fields."""
    question = BooleanQuestion(id="q1", type="boolean", text="Required?", required=True)
    validator = AnswerValidator()

    # None for required question
    result = validator.validate_answer(question, None, strict=False)
    assert not result.is_valid
    assert "required" in result.errors[0].lower()

    # None for non-required question
    question.required = False
    result = validator.validate_answer(question, None, strict=False)
    assert result.is_valid


def test_datetime_validation():
    """Test validation of date/time answers."""
    question = DateTimeQuestion(id="q1", type="date_time", text="When?", mode="date")
    validator = AnswerValidator()

    # Valid - ISO format string
    assert validator.validate_answer(question, "2025-01-15", strict=False).is_valid

    # Invalid - wrong type
    result = validator.validate_answer(question, 20250115, strict=False)
    assert not result.is_valid


def test_validate_answers_batch():
    """Test validating multiple answers at once."""
    questions = {
        "q1": BooleanQuestion(id="q1", type="boolean", text="Q1?"),
        "q2": ScaleQuestion(id="q2", type="scale", text="Q2?", min=1, max=5),
    }

    answers = {
        "q1": True,
        "q2": 3,
    }

    validator = AnswerValidator()
    results = validator.validate_answers(questions, answers, strict=False)

    assert len(results) == 2
    assert results["q1"].is_valid
    assert results["q2"].is_valid


def test_validate_answers_with_errors():
    """Test batch validation with errors."""
    questions = {
        "q1": BooleanQuestion(id="q1", type="boolean", text="Q1?"),
        "q2": ScaleQuestion(id="q2", type="scale", text="Q2?", min=1, max=5),
    }

    answers = {
        "q1": "yes",  # Should be boolean
        "q2": 10,     # Outside range
    }

    validator = AnswerValidator()
    results = validator.validate_answers(questions, answers, strict=False)

    assert not results["q1"].is_valid
    assert not results["q2"].is_valid


def test_validate_answers_unknown_question():
    """Test validation with unknown question ID."""
    questions = {
        "q1": BooleanQuestion(id="q1", type="boolean", text="Q1?"),
    }

    answers = {
        "q1": True,
        "q999": "unknown",
    }

    validator = AnswerValidator()
    results = validator.validate_answers(questions, answers, strict=False)

    assert results["q1"].is_valid
    assert not results["q999"].is_valid
    assert "Unknown question ID" in results["q999"].errors[0]


def test_convenience_function():
    """Test the validate_answer convenience function."""
    question = ScaleQuestion(id="q1", type="scale", text="Rate", min=1, max=5)

    # Valid
    result = validate_answer(question, 3, strict=False)
    assert result.is_valid

    # Invalid (strict mode)
    with pytest.raises(ValidationError):
        validate_answer(question, 10, strict=True)


def test_validation_result_bool():
    """Test ValidationResult boolean conversion."""
    valid_result = ValidationResult(is_valid=True)
    assert bool(valid_result) is True

    invalid_result = ValidationResult(is_valid=False, errors=["Error"])
    assert bool(invalid_result) is False


def test_validation_error_details():
    """Test ValidationError includes details."""
    question = ScaleQuestion(id="q1", type="scale", text="Rate", min=1, max=5)

    try:
        validate_answer(question, "invalid", strict=True)
        assert False, "Should have raised ValidationError"
    except ValidationError as e:
        assert e.question_id == "q1"
        assert "Expected number" in e.message
        assert "question_type" in e.details
        assert e.details["question_type"] == "scale"
