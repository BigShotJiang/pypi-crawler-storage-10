"""
Tests for Pydantic models.
"""

import pytest
from pydantic import ValidationError
from quaestionario.models import (
    Questionnaire,
    BooleanQuestion,
    SingleChoiceQuestion,
    Option,
    Condition,
    ConditionOperator,
)


def test_basic_questionnaire_creation():
    """Test creating a simple questionnaire."""
    questionnaire_data = {
        "questionnaireId": "test-1",
        "version": "1.0",
        "startQuestion": "q1",
        "questions": [
            {
                "id": "q1",
                "type": "boolean",
                "text": "Do you like Python?"
            }
        ]
    }

    questionnaire = Questionnaire(**questionnaire_data)
    assert questionnaire.questionnaire_id == "test-1"
    assert questionnaire.version == "1.0"
    assert questionnaire.start_question == "q1"
    assert len(questionnaire.questions) == 1
    assert questionnaire.questions[0].id == "q1"


def test_single_choice_question():
    """Test creating a single choice question with options."""
    question_data = {
        "id": "q1",
        "type": "single_choice",
        "text": "What's your favorite color?",
        "options": [
            {"value": "red", "label": "Red"},
            {"value": "blue", "label": "Blue", "next": "q2"},
        ]
    }

    question = SingleChoiceQuestion(**question_data)
    assert question.type == "single_choice"
    assert len(question.options) == 2
    assert question.options[1].next == "q2"


def test_condition_validation():
    """Test condition validation."""
    # Valid condition with value
    condition = Condition(
        question="q1",
        operator=ConditionOperator.EQUAL,
        value="yes"
    )
    assert condition.operator == ConditionOperator.EQUAL

    # Valid condition without value (exists)
    condition_exists = Condition(
        question="q1",
        operator=ConditionOperator.EXISTS
    )
    assert condition_exists.value is None

    # Invalid: exists with value should fail
    with pytest.raises(ValidationError):
        Condition(
            question="q1",
            operator=ConditionOperator.EXISTS,
            value="should_not_be_here"
        )

    # Invalid: equal without value should fail
    with pytest.raises(ValidationError):
        Condition(
            question="q1",
            operator=ConditionOperator.EQUAL
        )


def test_questionnaire_validation():
    """Test questionnaire validation rules."""
    # Invalid: start_question doesn't exist
    with pytest.raises(ValidationError):
        Questionnaire(
            questionnaireId="test",
            version="1.0",
            startQuestion="nonexistent",
            questions=[
                BooleanQuestion(id="q1", type="boolean", text="Test?")
            ]
        )

    # Invalid: duplicate question IDs
    with pytest.raises(ValidationError):
        Questionnaire(
            questionnaireId="test",
            version="1.0",
            startQuestion="q1",
            questions=[
                BooleanQuestion(id="q1", type="boolean", text="Test 1?"),
                BooleanQuestion(id="q1", type="boolean", text="Test 2?")
            ]
        )


def test_questionnaire_helper_methods():
    """Test helper methods on Questionnaire."""
    questionnaire = Questionnaire(
        questionnaireId="test",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Test 1?"),
            BooleanQuestion(id="q2", type="boolean", text="Test 2?")
        ]
    )

    # Test get_question_by_id
    q1 = questionnaire.get_question_by_id("q1")
    assert q1 is not None
    assert q1.id == "q1"

    nonexistent = questionnaire.get_question_by_id("q999")
    assert nonexistent is None

    # Test get_all_question_ids
    all_ids = questionnaire.get_all_question_ids()
    assert all_ids == {"q1", "q2"}