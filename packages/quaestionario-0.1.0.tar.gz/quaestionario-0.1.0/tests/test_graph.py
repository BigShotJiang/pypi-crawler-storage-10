"""
Tests for graph validation and analysis.
"""

import pytest
from quaestionario.models import (
    Questionnaire,
    BooleanQuestion,
    SingleChoiceQuestion,
    Option,
)
from quaestionario.graph import QuestionnaireGraph


def create_simple_questionnaire():
    """Create a simple test questionnaire."""
    return Questionnaire(
        questionnaireId="test",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Question 1?", defaultNext="q2"),
            BooleanQuestion(id="q2", type="boolean", text="Question 2?"),
            BooleanQuestion(id="q3", type="boolean", text="Question 3?")  # Unreachable
        ]
    )


def create_branching_questionnaire():
    """Create a questionnaire with branching logic."""
    return Questionnaire(
        questionnaireId="test-branch",
        version="1.0",
        startQuestion="start",
        questions=[
            SingleChoiceQuestion(
                id="start",
                type="single_choice",
                text="Choose your path",
                options=[
                    Option(value="left", label="Go left", next="left_path"),
                    Option(value="right", label="Go right", next="right_path"),
                ]
            ),
            BooleanQuestion(id="left_path", type="boolean", text="Left question?"),
            BooleanQuestion(id="right_path", type="boolean", text="Right question?"),
        ]
    )


def test_dag_validation_valid():
    """Test DAG validation on a valid questionnaire."""
    questionnaire = create_simple_questionnaire()
    graph = QuestionnaireGraph(questionnaire)

    is_valid, errors = graph.validate_dag()
    assert is_valid
    assert len(errors) == 0


def test_dag_validation_invalid_reference():
    """Test DAG validation with invalid question reference."""
    questionnaire = Questionnaire(
        questionnaireId="test",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Question 1?", defaultNext="nonexistent")
        ]
    )

    graph = QuestionnaireGraph(questionnaire)
    is_valid, errors = graph.validate_dag()
    assert not is_valid
    assert any("nonexistent" in error for error in errors)


def test_reachable_questions():
    """Test finding reachable questions."""
    questionnaire = create_simple_questionnaire()
    graph = QuestionnaireGraph(questionnaire)

    reachable = graph.get_reachable_questions("q1")
    assert "q1" in reachable
    assert "q2" in reachable
    assert "q3" not in reachable  # Unreachable from q1


def test_unreachable_questions():
    """Test finding unreachable questions."""
    questionnaire = create_simple_questionnaire()
    graph = QuestionnaireGraph(questionnaire)

    unreachable = graph.get_unreachable_questions()
    assert "q3" in unreachable
    assert "q1" not in unreachable
    assert "q2" not in unreachable


def test_terminal_questions():
    """Test finding terminal questions."""
    questionnaire = create_simple_questionnaire()
    graph = QuestionnaireGraph(questionnaire)

    terminal = graph.get_terminal_questions()
    assert "q2" in terminal  # No outgoing edges
    assert "q3" in terminal  # No outgoing edges
    assert "q1" not in terminal  # Has defaultNext


def test_branching_graph():
    """Test graph analysis on branching questionnaire."""
    questionnaire = create_branching_questionnaire()
    graph = QuestionnaireGraph(questionnaire)

    # Should be valid DAG
    is_valid, errors = graph.validate_dag()
    assert is_valid

    # Check next questions for start
    next_questions = graph.get_next_questions("start")
    assert "left_path" in next_questions
    assert "right_path" in next_questions

    # Check previous questions
    prev_left = graph.get_previous_questions("left_path")
    assert "start" in prev_left

    prev_right = graph.get_previous_questions("right_path")
    assert "start" in prev_right


def test_weak_connectivity():
    """Test weak connectivity check."""
    # Connected questionnaire
    questionnaire = create_branching_questionnaire()
    graph = QuestionnaireGraph(questionnaire)
    assert graph.is_weakly_connected()

    # Disconnected questionnaire
    disconnected = create_simple_questionnaire()  # q3 is isolated
    graph_disconnected = QuestionnaireGraph(disconnected)
    assert not graph_disconnected.is_weakly_connected()


def test_cycle_detection():
    """Test cycle detection."""
    # Create questionnaire with cycle
    cycle_questionnaire = Questionnaire(
        questionnaireId="cycle-test",
        version="1.0",
        startQuestion="q1",
        questions=[
            BooleanQuestion(id="q1", type="boolean", text="Q1?", defaultNext="q2"),
            BooleanQuestion(id="q2", type="boolean", text="Q2?", defaultNext="q1"),  # Creates cycle
        ]
    )

    graph = QuestionnaireGraph(cycle_questionnaire)
    is_valid, errors = graph.validate_dag()
    assert not is_valid
    assert any("cycle" in error.lower() for error in errors)