import logging
from typing import Any
from ..exceptions import TransactionError
from .gui_component import GuiComponent
from ..mappings import VKey
from .utils import get_column_idx_map

logger = logging.getLogger(__name__)


class GuiSession:
    def __init__(self, session: Any):
        self._session = session

    def maximize(self):
        """Maximizes the main SAP window"""
        try:
            self._session.findById("wnd[0]").maximize()
        except Exception as e:
            logger.error(f"Error maximizing window 0: {e}")
            raise RuntimeError(f"Error maximizing window 0: {e}")

    def start_transaction(self, tcode: str) -> bool:
        """
        Starts a new SAP transaction.
        Args:
            tcode: Transaction code to start.

        Returns:
            True if transaction started successfully

        Raises:
            TransactionError: If transaction code does not exist or Function is not possible.

        Note: This will end any existing transaction without saving your work. Use this with caution.
        """
        self._session.StartTransaction(tcode)

        status = self.get_status_info()
        if status and "does not exist" in status["text"].lower():
            logger.error(status["text"])
            raise TransactionError(status["text"])

        return True

    def end_transaction(self) -> bool:
        """Ends the current SAP transaction. Calling this function has the same effect as SendCommand("/n")."""
        self._session.EndTransaction()
        return True

    def findById(self, id: str):
        return GuiComponent(self._session.findById(id))

    def sendVKey(self, key: VKey, window: int = 0, times: int = 1) -> bool:
        """
        Sends a virtual key to a window.
        Args:
            key: Virtual key to send.
            window: Window to send the key to.
            times: Number of times to send the key.

        Returns:
            True if key sent successfully.

        Raises:
            RuntimeError: If key could not be sent.
        """
        try:
            for _ in range(times):
                self._session.findById(f"wnd[{window}]").sendVKey(key.value)
            return True
        except Exception as e:
            logger.error(f"Error sending vkey {key} to window {window}: {e}")
            raise RuntimeError(f"Error sending vkey {key} to window {window}")

    def send_enter(self, window: int = 0) -> bool:
        """Sends the ENTER key to a window."""
        return self.sendVKey(VKey.ENTER, window)

    def get_status_info(self) -> dict[str, Any] | None:
        """Gets current status bar information."""
        try:
            status_bar = self._session.findById("wnd[0]/sbar")
            return {
                "id": status_bar.MessageId,
                "text": status_bar.text,
                "type": status_bar.MessageType,
                "number": status_bar.MessageNumber,
                "is_popup": status_bar.MessageAsPopup,
                "parameter": status_bar.MessageParameter,
            }
        except Exception as e:
            logger.error(f"Error getting status bar information: {e}")
            return None

    def get_document_number(self) -> str:
        """Extracts document number from status bar when document is created successfully using va01 transaction."""
        status = self.get_status_info()
        try:
            return status["text"].split(" ")[3]
        except Exception as e:
            logger.error(f"Error getting document number: {status}")
            logger.error(e)
            raise e

    def dismiss_popups_until_none(self, key: VKey | int = VKey.ENTER):
        """
        Continuously dismisses popup dialogs by sending a specified virtual key (vkey)
        until no more popups appear. Assumes that the popup dialog is always the second
        window element (wnd[1]).

        Args:
            key: Virtual key to send to dismiss the popup dialog.

        """
        while True:
            try:
                window = self._session.findById("wnd[1]")
                window.sendVKey(key.value)
            except Exception as e:
                # No popup dialogs found, we can continue
                logger.debug(f"No more popup dialogs found: {e}")
                return

    def fill_table(
        self,
        id: str,
        data: list[dict[str, Any]],
        columns: list[str] | None = None,
        exclude_columns: list[str] | None = None,
    ):
        """
        Populates a specified SAP GUI table with the data from a list of dictionaries.

        Each dictionary in `data` represents a single table row, where keys correspond
        to column titles and values to cell contents. Column name matching is case-insensitive.
        Columns that do not exist in the SAP table are ignored, and columns not present
        in a row’s dictionary remain empty.

        The function automatically handles pagination by sending the ENTER key when the
        visible portion of the table is filled, and any popup dialogs that may appear.

        Args:
            id (str):
            The unique ID of the SAP `GuiTableControl` element to populate.

            data (list[dict[str, Any]]):
                A list of dictionaries, each representing one row of data to fill into
                the table.

            columns (list[str], optional):
                If provided, only these columns will be updated. This allows partial updates
                of the table. Cannot be used together with `exclude_columns`.

            exclude_columns (list[str], optional):
                If provided, these columns will be skipped when populating data.
                Cannot be used together with `columns`.

        Raises:
            ValueError:
                If both `columns` and `exclude_columns` are provided.
            ValueError:
                If the element specified by `id` is not a `GuiTableControl`.

        Notes:
            - Column name comparisons are case-insensitive.
            - Columns or keys that do not match existing table columns are silently ignored.
            - Pagination is handled automatically via simulated ENTER key presses.
        """

        if columns and exclude_columns:
            raise ValueError("Both columns and exclude_columns cannot be used together")

        table = self._session.findById(id)

        if table.type != "GuiTableControl":
            raise ValueError(f"Element {id} is not a table")

        table.VerticalScrollbar.Position = 0
        # Refresh table
        table = self._session.findById(id)

        if not data:
            logger.info("Data contains no items")
            return

        total_rows = len(data)
        logger.info(f"Total rows: {total_rows}")

        col_idx_map = get_column_idx_map(table, columns, exclude_columns)

        visible_rows = table.VisibleRowCount

        i = 0
        page = 0
        for row in data:
            start_row = 0 if page == 0 else 1
            current_row = start_row + (i % visible_rows)

            # Fill row data
            for col, value in row.items():
                col = col.lower()
                if col in col_idx_map:
                    col_idx = col_idx_map[col]
                    text = "" if value is None else str(value)
                    cell = table.GetCell(current_row, col_idx)
                    if cell.type != "GuiComboBox":
                        cell.text = text
                    else:
                        # This is a combo box
                        cell = GuiComponent(cell)
                        cell.text = text

            # Check if we need to move to the next page
            if (current_row + 1) % visible_rows == 0:
                page += 1
                self.send_enter()
                self.dismiss_popups_until_none()
                # Refresh table
                table = self._session.findById(id)

            i += 1

        # After filling all the rows, final commit to save changes
        self.send_enter()
        self.handle_popups_until_none()
