from mcp.server.fastmcp import FastMCP
from mcp.server.lowlevel import NotificationOptions

from vmcp.proxy_server.mcp_dependencies import get_http_request
from vmcp.proxy_server.tool_descriptions import UPLOAD_PROMPT_DESCRIPTION, CREATE_PROMPT_HELPER_TEXT
from typing import List, Dict, Any, Optional
from mcp.types import Prompt, Tool, Resource, ResourceTemplate, CallToolRequest, TextContent, CallToolResult, ReadResourceRequest,\
ServerResult
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import asyncio
import re

# Import routers
#from vmcp.mcps.router import router as mcp_router
#from vmcp.vmcps.router import router as vmcp_router
from vmcp.mcps.router_typesafe import router as mcp_router
from vmcp.vmcps.router_typesafe import router as vmcp_router
from vmcp.vmcps.widget_router import router as widget_router, serve_router as widget_serve_router
from vmcp.mcps.oauth_handler import router as oauth_handler_router
from vmcp.storage.blob_router import router as blob_router
from vmcp.utilities.tracing import add_tracing_middleware, trace_method
from datetime import datetime
from vmcp.utilities.logging import get_logger, setup_logging
from dataclasses import dataclass
from vmcp.vmcps.models import VMCPToolCallRequest
from vmcp.config import settings

# OSS version - no analytics/auth, use dummy JWT service
from vmcp.storage.dummy_jwt import DummyJWTService
JWTService = DummyJWTService  # Alias for compatibility
BASE_URL = settings.base_url

from dataclasses import dataclass

@dataclass
class ReadResourceContents:
    """Contents returned from a read_resource call."""

    content: str | bytes
    mime_type: str | None = None
    meta: dict | None = None
 
# Setup centralized logging for proxy agent server with span correlation
logger = get_logger("vMCP Server")

# Setup Jinja2 templates
from pathlib import Path
templates_dir = Path(__file__).parent / "templates"
templates = Jinja2Templates(directory=str(templates_dir))

def render_unauthorized_template(resource_metadata: str, 
                                 error_description: str, 
                                 vmcp_username: str = None,
                                 vmcp_name: str = None,
                                 base_url: str = None,
                                 share_vMCP: bool = False,
                                 request_type: str = None,
                                 is_sse_request: bool = False) -> HTMLResponse:
    """Render the unauthorized HTML template with proper context"""
    if base_url is None:
        base_url = BASE_URL
    
    # Create a minimal request object for Jinja2 templating
    from starlette.requests import Request
    from starlette.datastructures import URL
    
    # Create a minimal scope for the request
    scope = {
        "type": "http",
        "method": "GET",
        "path": "/vmcp/mcp",
        "query_string": b"",
        "headers": [],
        "client": ("127.0.0.1", 8000),
        "server": ("1xn.ai", 443),
        "scheme": "https",
        "extensions": {}
    }
    
    # Create a minimal request object
    request = Request(scope)
    
    if request_type == "GET" and not is_sse_request:
        return templates.TemplateResponse(
            "simple_unauthorized.html",
            {
                "request": request,
                "resource_metadata": resource_metadata,
                "error_description": error_description,
                "base_url": base_url,
                # get the absolute url of the request
                "request_url": f"{base_url}/{vmcp_username}/{vmcp_name}/vmcp" if vmcp_username else f"{base_url}/{vmcp_name}/vmcp",
                "vmcp_username": vmcp_username,
                "vmcp_name": vmcp_name,
                "share_vMCP": share_vMCP
            },
            status_code=200,
            headers={
                "WWW-Authenticate": f'Bearer error="invalid_token", error_description="{error_description}", resource_metadata="{resource_metadata}"',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Authorization, Content-Type, MCP-Protocol-Version, Accept"
            }
        )
    else:
        return JSONResponse(
            status_code=401,
            content={
                "error": "invalid_token",
                "error_description": error_description,
                "resource_metadata": resource_metadata
            },
            headers={
                "WWW-Authenticate": f'Bearer error="invalid_token", error_description="{error_description}", resource_metadata="{resource_metadata}"',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Authorization, Content-Type, MCP-Protocol-Version, Accept"
            }
        )

class ProxyServer(FastMCP):
    def __init__(self,name:str):
        logger.info(f"🚀 Initializing ProxyServer: {name}")
        # Configure streamable HTTP path to be root so it works when mounted
        super().__init__(name, streamable_http_path="/mcp", instructions="1xn v(irtual)MCP server", log_level=settings.log_level.upper(), debug=settings.debug)
        self._mcp_server.create_initialization_options(
            notification_options=NotificationOptions(prompts_changed=True, resources_changed=True, tools_changed=True), 
            experimental_capabilities={"1xn": {"vmcp": True}})
        
        
        # Proxy server is completely stateless
        # All managers will be created per user request
        logger.info("✅ ProxyServer initialization complete (stateless)")
    
    async def get_user_context_proxy_server(self):
        """Build dependencies for the current request with user context"""
        try:
            # Get the current request context
            from vmcp.proxy_server.mcp_dependencies import get_http_headers
            # from auth_service.jwt_service import JWTService  # OSS - no auth
            from vmcp.storage.base import StorageBase
            
            jwt_service = JWTService()
            token = get_http_request().headers.get('Authorization', '').replace('Bearer ', '').strip()
            token_info = jwt_service.extract_token_info(token)
            if not token_info:
                logger.warning("🔍 No token info found in request state")
                return None
            
            vmcp_name = get_http_request().headers.get('vmcp-name', 'unknown')
            vmcp_username = get_http_request().headers.get('vmcp-username', 'unknown')
            if vmcp_username=="private":
                vmcp_username = None
            user_id = token_info.get("user_id")
            client_id = token_info.get("client_id")
            user_name = token_info.get("user_name")
            user_email = token_info.get("user_email")
            client_name = token_info.get("client_name")
            
            # Get agent name from Bearer token mapping
            global_storage = StorageBase()  # Global mode
            agent_name = global_storage.get_agent_name(token)
            
            if agent_name:
                logger.info(f"🔍 Found agent name for token {token[:10]}...: {agent_name}")
            else:
                logger.warning(f"🔍 No agent name found for token {token[:10]}...")
            
            from vmcp.storage.dummy_user import UserContext
            user_context = UserContext(
                user_id=user_id, 
                user_email=user_email,
                username=user_name,
                token=token,
                vmcp_name=vmcp_name
            )
            
            # Add vMCP-specific attributes to the user context
            user_context.vmcp_name_header = vmcp_name
            user_context.vmcp_username_header = vmcp_username
            user_context.client_id = client_id
            user_context.client_name = client_name
            user_context.agent_name = agent_name
            
            
            # The UserContext now has vmcp_config_manager initialized
            return user_context
        except Exception as e:
            logger.error(f"❌ Traceback: {traceback.format_exc()}")
            logger.error(f"❌ Error building dependencies: {e}")
            return None
    
    async def _execute_upload_prompt(self, arguments: dict) -> dict:
        """Create a custom prompt in the active vMCP. This tool allows users to create new custom prompts that will be available in their current vMCP configuration."""
        try:
            prompt_json = arguments.get("prompt_json")
            
            if not prompt_json:
                return {"status": "error", "message": "Missing required argument: prompt_json"}
            
            if not isinstance(prompt_json, dict):
                return {"status": "error", "message": "prompt_json must be a JSON object"}
            
            # Extract required fields from prompt_json
            name = prompt_json.get("name")
            description = prompt_json.get("description", "")  # Optional, default to empty string
            prompt_text = prompt_json.get("text")
            variables = prompt_json.get("variables", [])
            
            if not all([name, prompt_text]):
                return {"status": "error", "message": "prompt_json must contain name and text fields"}
            
            # Validate variables format if provided
            if variables and not isinstance(variables, list):
                return {"status": "error", "message": "Variables must be a list of objects"}
            
            for var in variables:
                if not isinstance(var, dict):
                    return {"status": "error", "message": "Each variable must be an object"}
                if not all(key in var for key in ["name", "description", "required"]):
                    return {"status": "error", "message": "Each variable must have name, description, and required fields"}
                if not isinstance(var["required"], bool):
                    return {"status": "error", "message": "Variable 'required' field must be a boolean"}
            
            # Get user context
            deps = await self.get_user_context_proxy_server()
            if deps is None:
                return {"status": "error", "message": "No user context available"}
            
            # Get the active vMCP manager
            if deps.vmcp_config_manager:
                active_vmcp_id = deps.vmcp_config_manager.vmcp_id
                vmcp_manager = deps.vmcp_config_manager
            else:
                return {"status": "error", "message": "No vMCP manager available"}
            
            if not active_vmcp_id:
                return {"status": "error", "message": "No active vMCP found"}
            
            # Load current vMCP config
            vmcp_config = vmcp_manager.load_vmcp_config(active_vmcp_id)
            if not vmcp_config:
                return {"status": "error", "message": f"vMCP config not found for ID: {active_vmcp_id}"}
            
            # Validate prompt name and handle conflicts
            final_name = name
            existing_prompts = vmcp_config.custom_prompts or []
            existing_names = {p.get("name") for p in existing_prompts}
            
            counter = 1
            while final_name in existing_names:
                final_name = f"{name}_{counter}"
                counter += 1
            
            # Create the new prompt
            new_prompt = {
                "name": final_name,
                "description": description,
                "text": prompt_text,
                "variables": variables  # Use the provided variables
            }
            
            # Add to existing custom prompts
            updated_custom_prompts = list(existing_prompts)
            updated_custom_prompts.append(new_prompt)
            
            # Update the vMCP config with new custom prompts
            success = vmcp_manager.update_vmcp_config(
                vmcp_id=active_vmcp_id,
                custom_prompts=updated_custom_prompts
            )
            
            if success:
                logger.info(f"✅ Created custom prompt '{final_name}' in vMCP {active_vmcp_id}")
                return {
                    "status": "success",
                    "prompt_name": final_name,
                    "message": f"Custom prompt '{final_name}' created successfully"
                }
            else:
                return {"status": "error", "message": "Failed to save vMCP configuration"}
                
        except Exception as e:
            logger.error(f"❌ Error creating custom prompt: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            return {"status": "error", "message": f"Failed to create prompt: {str(e)}"}

    def _setup_handlers(self) -> None:
        """Set up core MCP protocol handlers."""
        logger.info("🔌 Setting up MCP protocol handlers...")

        self._mcp_server.list_tools()(self.proxy_list_tools)
        logger.debug("   ✅ list_tools handler registered")
        
        # Note: we disable the lowlevel server's input validation.
        # FastMCP does ad hoc conversion of incoming data before validating -
        # for now we preserve this for backwards compatibility.
        # self._mcp_server.call_tool(validate_input=False)(self.proxy_call_tool)
        self._mcp_server.request_handlers[CallToolRequest] = self.root_proxy_call_tool
        logger.debug("   ✅ call_tool handler registered")
        
        self._mcp_server.list_resources()(self.proxy_list_resources)
        logger.debug("   ✅ list_resources handler registered")
        
        self._mcp_server.request_handlers[ReadResourceRequest] = self.proxy_read_resource
        # self._mcp_server.read_resource()(self.proxy_read_resource)
        logger.debug("   ✅ read_resource handler registered")
        
        self._mcp_server.list_prompts()(self.proxy_list_prompts)
        logger.debug("   ✅ list_prompts handler registered")
        
        self._mcp_server.get_prompt()(self.proxy_get_prompt)
        logger.debug("   ✅ get_prompt handler registered")
        
        self._mcp_server.list_resource_templates()(self.proxy_list_resource_templates)
        logger.debug("   ✅ list_resource_templates handler registered")
        
        logger.info("🎉 All MCP protocol handlers registered successfully")

    @trace_method("[PROXY_SERVER]: List Tools")
    async def proxy_list_tools(self) -> List[Tool]:
        """Aggregate tools from all connected servers filtered by active agent or vMCP"""
        logger.info("=" * 60)
        logger.info("🔍 MCP: proxy_list_tools called")
        logger.info("=" * 60)
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.warning("🔍 No dependencies available (no valid token) - returning empty tools list")
            return []
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"🔍 MCP: Listing tools for user {user_id}, client {client_id}, agent {agent_name}")
        
        # Get vMCP tools
        if deps.vmcp_config_manager:
            tools = await deps.vmcp_config_manager.tools_list()
        else:
            tools = []
        logger.info(f"🔍 MCP: Found {len(tools)} vMCP tools")
        
        # Create preset tools manually
        if not(deps.vmcp_username_header and deps.vmcp_username_header.startswith("@")):
            preset_tools = [
                Tool(
                    name="upload_prompt",
                    description=UPLOAD_PROMPT_DESCRIPTION,
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "prompt_json": {
                                "type": "object",
                                "description": "JSON object containing the prompt configuration",
                                "properties": {
                                    "name": {
                                        "type": "string",
                                        "description": "Name for the new prompt"
                                    },
                                    "description": {
                                        "type": "string", 
                                        "description": "Description of what the prompt does (optional)"
                                    },
                                    "text": {
                                        "type": "string",
                                        "description": "The actual prompt text content. Use {variableName} format to reference variables (e.g., {username})"
                                    },
                                    "variables": {
                                        "type": "array",
                                        "description": "Optional list of variables that can be used in the prompt text",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "name": {
                                                    "type": "string",
                                                    "description": "Variable name (referenced as @var.name in prompt text)"
                                                },
                                                "description": {
                                                    "type": "string",
                                                    "description": "Description of what this variable represents"
                                                },
                                                "required": {
                                                    "type": "boolean",
                                                    "description": "Whether this variable is required when using the prompt"
                                                }
                                            },
                                            "required": ["name", "description", "required"]
                                        }
                                    }
                                },
                                "required": ["name", "text"]
                            }
                        },
                        "required": ["prompt_json"]
                    }
                )
            ]
        else:
            preset_tools = []
        logger.info(f"🔍 MCP: Found {len(preset_tools)} preset tools")
        
        # Combine preset tools with vMCP tools
        all_tools = preset_tools + tools
        
        logger.info(f"🔍 MCP: Returning {len(all_tools)} total tools ({len(preset_tools)} preset + {len(tools)} vMCP)")
        # Tools are already Tool objects, no conversion needed
        logger.info(f"🔍 MCP: Returning {len(tools)} tools")
        logger.info("=" * 60)
        
        # Log tool details
        for i, tool in enumerate(all_tools):
            tool_type = "PRESET" if i < len(preset_tools) else "vMCP"
            logger.info(f"🔍 MCP: Tool {i+1} [{tool_type}]: {tool.name} - {tool.description[:50] if tool.description else 'No description'}...")
        
        return all_tools

    @trace_method("[PROXY_SERVER]: List Resources")
    async def proxy_list_resources(self) -> List[Resource]:
        """Aggregate resources from all connected servers filtered by active agent or vMCP"""
        logger.info("🔍 Listing resources from all connected servers...")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.warning("🔍 No dependencies available - returning empty resources list")
            return []
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"🔍 MCP: Listing resources for user {user_id}, client {client_id}, agent {agent_name}")
        
        if deps.vmcp_config_manager:
            resources = await deps.vmcp_config_manager.resources_list()
        else:
            resources = []
        
        return resources
    
    @trace_method("[PROXY_SERVER]: List Resource Templates")
    async def proxy_list_resource_templates(self) -> List[ResourceTemplate]:
        """Aggregate resource templates from all connected servers filtered by active agent or vMCP"""
        logger.info("🔍 Listing resource templates from all connected servers...")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.warning("🔍 No dependencies available - returning empty resource templates list")
            return []
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"🔍 MCP: Listing resource templates for user {user_id}, client {client_id}, agent {agent_name}")
        
        if deps.vmcp_config_manager:
            resource_templates = await deps.vmcp_config_manager.resource_templates_list()
        else:
            resource_templates = []
        
        # Log resource template details
        for i, template in enumerate(resource_templates):
            logger.info(f"🔍 MCP: Resource Template {i+1}: {template.name} - {template.description[:50] if template.description else 'No description'}...")
        
        return resource_templates
    
    @trace_method("[PROXY_SERVER]: List Prompts")
    async def proxy_list_prompts(self) -> List[Prompt]:
        """Aggregate prompts from all connected servers filtered by active agent or vMCP"""
        logger.info("🔍 Listing prompts from all connected servers...")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.warning("🔍 No dependencies available - returning empty prompts list")
            return []
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"🔍 MCP: Listing prompts for user {user_id}, client {client_id}, agent {agent_name}")
        
        if deps.vmcp_config_manager:
            prompts = await deps.vmcp_config_manager.prompts_list()
        else:
            prompts = []
        
        # Add upload_prompt_helper as a built-in prompt
        from mcp.types import Prompt
        if not(deps.vmcp_username_header and deps.vmcp_username_header.startswith("@")):
            upload_prompt_helper_prompt = Prompt(
                name="upload_prompt_helper",
                description="Get helper text for creating custom prompts based on title and description",
                arguments=[
                    {
                        "name": "title",
                        "description": "Title for the prompt you want to create",
                        "required": False
                    },
                    {
                        "name": "description", 
                        "description": "Description of what the prompt should do",
                        "required": False
                    }
                ]
            )
            prompts.append(upload_prompt_helper_prompt)
        
        # Log prompt details
        for i, prompt in enumerate(prompts):
            logger.info(f"🔍 MCP: Prompt {i+1}: {prompt.name} - {prompt.description[:50] if prompt.description else 'No description'}...")
        
        return prompts
    
    @trace_method("[PROXY_SERVER]: Root Tool Call")
    async def root_proxy_call_tool(self, req: CallToolRequest):
        tool_name = req.params.name
        arguments = req.params.arguments or {}
        logger.info(f"🔧 DEBUG root_proxy_call_tool: tool={tool_name}, arguments={arguments}, types={[(k, type(v).__name__) for k, v in arguments.items()]}")
        result = await self.proxy_call_tool(tool_name, arguments)
        return result

    @trace_method("[PROXY_SERVER]: Tool Call", operation="call_tool")
    async def proxy_call_tool(self, name: str, arguments: Dict[str, Any]) -> List[Any]:
        """Route tool calls to appropriate server"""
        logger.info("=" * 60)
        logger.info(f"🛠️  MCP: Tool call requested")
        logger.info("=" * 60)
        logger.info(f"📋 Tool Details:")
        logger.info(f"   Name: {name}")
        logger.info(f"   Arguments: {arguments}")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.error("🔍 No dependencies available - cannot call tool without user context")
            raise Exception("Tool calls require user context")
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"📋 User Context:")
        logger.info(f"   User ID: {user_id}")
        logger.info(f"   Client ID: {client_id}")
        logger.info(f"   Agent Name: {agent_name}")
        
        logger.info(f"🛠️  MCP: Executing tool '{name}' for user {user_id}, client {client_id}, agent {agent_name}")
        
        # Track tool execution start (OSS - analytics disabled)
        # analytics.track_mcp_tool_call(
        #     user_id=user_id,
        #     tool_name=name,
        #     mcp_server="proxy_server",
        #     success=False,
        #     properties={"client_id": client_id, "agent_name": agent_name}
        # )
        
        try:
            # For now, check if this is the vmcp_create_prompt tool
            if name == "upload_prompt":
                logger.info(f"🔧 MCP: Executing PRESET tool '{name}'")
                # Execute the preset tool directly (manually for now)
                result = await self._execute_upload_prompt(arguments)
                logger.info(f"✅ MCP: Preset tool '{name}' executed successfully")
                logger.info(f"📋 Result type: {type(result)}")
                logger.info(f"📋 Result: {result}")
                logger.info("=" * 60)
                
                # Track successful tool execution
                # analytics.track_mcp_tool_call()  # OSS - analytics disabled
                
                # Return MCP-compatible CallToolResult format
                from mcp.types import CallToolResult, TextContent
                return CallToolResult(
                    content=[TextContent(type="text", text=str(result))],
                    isError=False
                )
            else:
                logger.info(f"🔧 MCP: Executing vMCP tool '{name}'")
                if deps.vmcp_config_manager:
                    result = await deps.vmcp_config_manager.call_tool(
                        vmcp_tool_call_request=VMCPToolCallRequest(tool_name=name, arguments=arguments)
                        )
                else:
                    raise Exception("No vMCP manager available for tool execution")
                logger.info(f"✅ MCP: vMCP tool '{name}' executed successfully")
                logger.info(f"📋 Result type: {type(result)}")
                logger.info(f"📋 Result: {result}")
                if isinstance(result, list):
                    logger.info(f"📋 Result count: {len(result)}")
                logger.info("=" * 60)
                
                # Track successful vMCP tool execution
                # analytics.track_mcp_tool_call()  # OSS - analytics disabled
                
                return result
        except Exception as e:
            logger.error(f"❌ MCP: Tool '{name}' failed with error: {e}")
            # Add traceback to logger
            logger.error(f"Full traceback: {traceback.format_exc()}")
            logger.info("=" * 60)
            
            # Track failed tool execution
            # analytics.track_mcp_tool_call()  # OSS - analytics disabled
            
            raise
    
    @trace_method("[PROXY_SERVER]: Get Prompt")
    async def proxy_get_prompt(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        """Get prompt content from appropriate server or agent"""
        logger.info(f"📝 Prompt request: {name}")
        logger.debug(f"   📋 Arguments: {arguments}")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.error("🔍 No dependencies available - cannot get prompt without user context")
            raise Exception("Prompt requests require user context")
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"📝 MCP: Getting prompt '{name}' for user {user_id}, client {client_id}, agent {agent_name}")
        
        # Handle built-in prompts
        if name == "upload_prompt_helper":
            title = arguments.get("title", "") if arguments else ""
            description = arguments.get("description", "") if arguments else ""
            
            # Format the helper text with the provided title and description
            # Use replace() to avoid conflicts with other {variables} in the text
            formatted_text = CREATE_PROMPT_HELPER_TEXT.replace("{title}", title).replace("{description}", description)
            
            from mcp.types import GetPromptResult, PromptMessage
            return GetPromptResult(
                description="Helper text for creating custom prompts",
                messages=[
                    PromptMessage(
                        role="user",
                        content={"type": "text", "text": formatted_text}
                    )
                ]
            )
        
        if deps.vmcp_config_manager:
            prompt = await deps.vmcp_config_manager.get_prompt(name,arguments)
        else:
            raise Exception("No vMCP manager available for prompt retrieval")
        # if name.startswith("vMCP_"):
        # check name against the regex [A-Z0-9_]+
        if re.match(r"[A-Z0-9_]+", name):
            logger.info(f"🔍 MCP: Prompt '{name}' is all uppercase, sending list changed notifications")
            await self.get_context().session.send_tool_list_changed()
            await self.get_context().session.send_resource_list_changed()
            await self.get_context().session.send_prompt_list_changed()
        return prompt
 
    @trace_method("[PROXY_SERVER]: Read Resource")
    async def proxy_read_resource(self, req: ReadResourceRequest) -> ServerResult:
        """Route resource reads to appropriate server"""
        uri = req.params.uri
        logger.info(f"📦 Resource read requested: {uri}")
        
        # Build dependencies from current request
        deps = await self.get_user_context_proxy_server()
        if deps is None:
            logger.error("🔍 No dependencies available - cannot read resource without user context")
            raise Exception("Resource read requests require user context")
        
        # Log user context
        user_id = getattr(deps, 'user_id', 'unknown')
        client_id = getattr(deps, 'client_id', 'unknown')
        agent_name = getattr(deps, 'agent_name', 'unknown')
        logger.info(f"📦 MCP: Reading resource '{uri}' for user {user_id}, client {client_id}, agent {agent_name}")
        

        # For other resources, use the vmcp_config_manager to handle them
        try:
            if deps.vmcp_config_manager:
                resource_result = await deps.vmcp_config_manager.get_resource(uri)
            else:
                raise Exception("No vMCP manager available for resource retrieval")
            if resource_result:
                logger.info(f"✅ Resource read successful: {uri}")
                logger.info(f"🔍 Proxy Server: Resource result type: {type(resource_result)}")
                logger.debug(f"🔍 Proxy Server: Resource result structure: {resource_result}")
                # if isinstance(resource_result, ReadResourceResult):
                    # return ServerResult(resource_result) #[ReadResourceContents(content=c.text, mime_type=c.mimeType, meta=c.meta) if hasattr(c, 'text') else ReadResourceContents(content=c.blob, mime_type=c.mimeType, meta=c.meta) for c in resource_result.contents]
                # else:
                    # return resource_result
                return ServerResult(resource_result)
            else:
                logger.warning(f"⚠️  Resource '{uri}' returned None or invalid result")
                raise ValueError(f"Resource '{uri}' not found")
        except Exception as e:
            logger.error(f"❌ Resource read failed for '{uri}': {e}")
            logger.error(f"   🔍 Exception type: {type(e).__name__}")
            raise

async def handle_agent_initialize(request: Request, json_body: dict, bearer_token: str) -> None:
    """Handle agent initialization and management for MCP initialize requests"""
    logger.info("🚀 MCP INITIALIZE REQUEST DETECTED - Handling agent management")
    
    # Extract clientInfo from params
    params = json_body.get("params", {})
    client_info = params.get("clientInfo", {})
    agent_name = client_info.get("name", "unknown")
    agent_version = client_info.get("version", "unknown")
    
    # Sanitize agent name by replacing "/" with "_" to avoid file path issues
    agent_name = agent_name.replace("/", "_")
    
    logger.info(f"📋 Agent Info:")
    logger.info(f"   Agent Name: {agent_name}")
    logger.info(f"   Agent Version: {agent_version}")
    logger.info(f"   Bearer Token: {bearer_token[:10]}...")
    
    # Validate token and get user info
    # from auth_service.jwt_service import JWTService  # OSS - no auth
    jwt_service = JWTService()
    token_info = jwt_service.extract_token_info(bearer_token)
    
    if not token_info:
        logger.warning("❌ Invalid Bearer token for agent management")
        return
    
    user_id = token_info.get("user_id")
    client_id = token_info.get("client_id", "")
    user_name = token_info.get("user_name", "")
    client_name = token_info.get("client_name", "")
    
    logger.info(f"📋 User Info:")
    logger.info(f"   User ID: {user_id}")
    logger.info(f"   Client ID: {client_id}")
    logger.info(f"   User Name: {user_name}")
    logger.info(f"   Client Name: {client_name}")
    
    # Handle agent management
    try:
        from vmcp.storage.base import StorageBase
        
        # Create global storage handler for agent mappings
        global_storage = StorageBase()  # Global mode
        
        # Save Bearer token to agent name mapping
        mapping_success = global_storage.save_agent_mapping(bearer_token, agent_name)
        if mapping_success:
            logger.info(f"✅ Saved agent mapping: {bearer_token[:10]}... -> {agent_name}")
        else:
            logger.error(f"❌ Failed to save agent mapping")
        
        # Create user-specific storage handler
        user_storage = StorageBase(user_id=user_id)  # User mode
        
        # Save agent info
        agent_info = {
            "name": agent_name,
            "version": agent_version,
            "user_id": user_id,
            "client_id": client_id,
            "user_name": user_name,
            "client_name": client_name,
            "created_at": datetime.now().isoformat(),
            "last_seen": datetime.now().isoformat(),
            "initialize_params": params
        }
        
        info_success = user_storage.save_agent_info(agent_name, agent_info)
        if info_success:
            logger.info(f"✅ Saved agent info for {agent_name}")
        else:
            logger.error(f"❌ Failed to save agent info for {agent_name}")
        
        # Save agent tokens
        tokens_success = user_storage.save_agent_tokens(agent_name, bearer_token)
        if tokens_success:
            logger.info(f"✅ Saved agent tokens for {agent_name}")
        else:
            logger.error(f"❌ Failed to save agent tokens for {agent_name}")
        
        # Log the initialize call
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "method": "initialize",
            "agent_name": agent_name,
            "user_id": user_id,
            "client_id": client_id,
            "params": params,
            "bearer_token": bearer_token[:10] + "...",
            "ip_address": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get('user-agent', 'unknown')
        }
        
        logs_success = user_storage.save_agent_logs(agent_name, log_entry)
        if logs_success:
            logger.info(f"✅ Logged initialize call for {agent_name}")
        else:
            logger.error(f"❌ Failed to log initialize call for {agent_name}")
        
    except Exception as e:
        logger.error(f"❌ Error handling agent management: {e}")
        logger.error(f"Full traceback: {traceback.format_exc()}")
    
    logger.info("✅ MCP INITIALIZE REQUEST PROCESSED")

async def log_mcp_call_for_agent(request: Request, json_body: dict, bearer_token: str) -> None:
    """Log MCP calls for agents (non-initialize requests)"""
    try:
        from vmcp.storage.base import StorageBase
        # from auth_service.jwt_service import JWTService  # OSS - no auth
        
        # Get agent name from mapping
        global_storage = StorageBase()  # Global mode
        agent_name = global_storage.get_agent_name(bearer_token)
        
        if not agent_name or agent_name == "unknown":
            return
        
        # Get user info from token
        jwt_service = JWTService()
        token_info = jwt_service.extract_token_info(bearer_token)
        
        if not token_info:
            return
        
        user_id = token_info.get("user_id")
        client_id = token_info.get("client_id", "")
        
        # Log the MCP call
        user_storage = StorageBase(user_id=user_id)  # User mode
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "method": json_body.get("method", "unknown"),
            "agent_name": agent_name,
            "user_id": user_id,
            "client_id": client_id,
            "params": json_body.get("params", {}),
            "id": json_body.get("id"),
            "bearer_token": bearer_token[:10] + "...",
            "ip_address": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get('user-agent', 'unknown')
        }
        
        user_storage.save_agent_logs(agent_name, log_entry)
        
    except Exception as e:
        # Silently fail for logging - don't affect the main request
        logger.debug(f"Could not log MCP call for agent: {e}")

# Create an MCP server
logger.info("🎬 Creating ProxyServer instance...")
mcp = ProxyServer("1xN MCP Proxy")

# Create unified FastAPI server
# Create the FastMCP HTTP app first to get its lifespan
logger.info("🔧 Creating FastMCP streamable HTTP app...")
mcp_http_app = mcp.streamable_http_app()

# logger.info(f"🔍 MCP HTTP app routes: {mcp_http_app.routes}")

# Lifespan context manager for MCP session management
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage the MCP session manager lifecycle and database initialization"""
    logger.info("🚀 Starting application startup...")
    
    # Initialize database tables (creates missing tables, preserves existing data)
    try:
        from vmcp.storage.database import init_db
        from vmcp.storage.dummy_user import ensure_dummy_user
        
        logger.info("📊 Initializing database tables...")
        init_db()
        
        logger.info("👤 Ensuring dummy user exists...")
        ensure_dummy_user()
        
        logger.info("✅ Database initialization complete")
    except Exception as e:
        logger.warning(f"⚠️ Database initialization warning: {e}")
        logger.info("    Continuing anyway (database may already be initialized)")
    
    logger.info("🚀 Starting MCP session manager...")
    
    # Create shutdown event
    shutdown_event = asyncio.Event()
    session_task = None
    
    async def run_session_manager():
        try:
            async with mcp.session_manager.run():
                # Wait for shutdown signal instead of blocking indefinitely
                await shutdown_event.wait()
        except asyncio.CancelledError:
            logger.info("🛑 MCP session manager cancelled")
        except Exception as e:
            logger.error(f"❌ MCP session manager error: {e}")
    
    # Start the session manager task
    session_task = asyncio.create_task(run_session_manager())
    
    try:
        logger.info("✅ MCP session manager started")
        yield
    finally:
        logger.info("🛑 Shutting down MCP session manager...")
        # Signal shutdown
        shutdown_event.set()
        
        if session_task:
            try:
                await asyncio.wait_for(session_task, timeout=3.0)
            except asyncio.TimeoutError:
                logger.warning("⚠️ MCP session manager shutdown timeout, forcing cancellation")
                session_task.cancel()
                try:
                    await asyncio.wait_for(session_task, timeout=1.0)
                except asyncio.CancelledError:
                    pass  # Expected
            except asyncio.CancelledError:
                pass  # Expected
        logger.info("✅ MCP session manager shutdown complete")


#Create lifespan context manager that includes startup connections
# @asynccontextmanager
# async def mcp_lifespan(app):
#     logger.info("🚀 Starting MCP server lifespan...")
#     logger.info("✅ MCP server lifespan started")
#     try:
#         # Run the MCP session manager (this runs indefinitely)
#         async with mcp.session_manager.run():
#             yield
#     finally:
#         logger.info("🛑 MCP server lifespan ending...")

# # Create FastAPI app with FastMCP's lifespan to fix task group issue
# logger.info("🔧 Creating MCP Proxy Server with shared lifespan...")

# Use custom lifespan management for MCP session
app = FastAPI(
    title="1xN MCP Proxy Server",
    description="MCP proxy server with management API",
    lifespan=lifespan,
    redirect_slashes=False  # Prevent automatic redirects that lose Authorization headers
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# OSS version - no analytics middleware
logger.info("📊 Analytics disabled in OSS version")

# Add tracing middleware with exclusions to reduce noise (if enabled)
if settings.enable_tracing:
    add_tracing_middleware(
        app,
        "vmcp-server",
        excluded_paths={
            "/health",
            "/api/health",
            "/docs",
            "/openapi.json",
            "/redoc",
            "/favicon.ico"
        },
        excluded_prefixes={
            "/static/",
            "/assets/",
            "/app/",
            "/api/docs",
            "/api/traces"
        }
    )
    # Add traces API router
    from vmcp.utilities.tracing import traces_api_router
    app.include_router(traces_api_router, prefix="/api")

# Mount static files
static_dir = Path(__file__).parent / "static"
if static_dir.exists():
    app.mount("/api/proxystatic", StaticFiles(directory=str(static_dir)), name="static")

# Add middleware to redirect /mcp/ to /mcp while preserving headers
# @app.middleware("http")
# async def mcp_redirect_middleware(request: Request, call_next):
#     """Redirect /mcp/ to /mcp while preserving all headers"""
#     logger.warning(f"🔄 MCP Redirect middleware: {request.method} {request.url.path}")

#     # Check if this is a request to /mcp/
#     if request.url.path == "/vmcp/mcp/":
#         logger.warning(f"🔄 MCP Redirect: {request.method} {request.url.path} -> /mcp")
        
#         # Create redirect response
#         from fastapi.responses import RedirectResponse
#         redirect_response = RedirectResponse(url="/vmcp/mcp", status_code=307)
        
#         # Preserve ALL headers from the original request
#         for header_name, header_value in request.headers.items():
#             # Skip some headers that shouldn't be forwarded
#             if header_name.lower() not in ['host', 'content-length']:
#                 redirect_response.headers[header_name] = header_value
        
#         logger.info(f"📋 Preserved headers in redirect: {list(request.headers.keys())}")
#         return redirect_response
    
#     # For all other requests, proceed normally
#     return await call_next(request)

# vMCP URL routing middleware - handles URL patterns like /private/test/vmcp
@app.middleware("http")
async def vmcp_routing_middleware(request: Request, call_next):
    """Middleware to handle vMCP URL patterns and route them to MCP endpoint"""
    
    # Frontend routes that should NOT be processed by vMCP routing
    frontend_routes = {"app", "api", "health", "docs", "documentation", "static", "assets", "_next", "favicon.ico", "manifest.json", "robots.txt", "sitemap.xml"}
    
    path = request.url.path
    
    # Check for vMCP patterns
    import re
    
    # Pattern: /{vmcp_username}/{vmcp_name}/vmcp
    match = re.match(r'^/([^/]+)/([^/]+)/vmcp/?$', path)
    if match:
        vmcp_username, vmcp_name = match.groups()
        
        # Skip if this is a frontend route
        if vmcp_username in frontend_routes or vmcp_name in frontend_routes:
            return await call_next(request)
        
        logger.info(f"🔄 vMCP Middleware: {vmcp_username}/{vmcp_name}/vmcp -> /vmcp/mcp")
        
        # Set headers and forward to MCP endpoint
        request.headers.__dict__["_list"].append((b"vmcp-username", vmcp_username.encode()))
        request.headers.__dict__["_list"].append((b"vmcp-name", vmcp_name.encode()))
        
        # Modify the request path
        request.scope["path"] = "/vmcp/mcp"
        return await call_next(request)
    
    # Pattern: /{vmcp_name}/vmcp (no username)
    match = re.match(r'^/([^/]+)/vmcp/?$', path)
    if match:
        vmcp_name = match.group(1)
        
        # Skip if this is a frontend route
        if vmcp_name in frontend_routes:
            return await call_next(request)
        
        logger.info(f"🔄 vMCP Middleware: {vmcp_name}/vmcp -> /vmcp/mcp")
        
        # Set headers and forward to MCP endpoint
        request.headers.__dict__["_list"].append((b"vmcp-name", vmcp_name.encode()))
        
        # Modify the request path
        request.scope["path"] = "/vmcp/mcp"
        return await call_next(request)
    
    # Pattern: /private/{vmcp_name}/vmcp (special case for private vMCPs)
    match = re.match(r'^/private/([^/]+)/vmcp/?$', path)
    if match:
        vmcp_name = match.group(1)
        
        # Skip if this is a frontend route
        if vmcp_name in frontend_routes:
            return await call_next(request)
        
        logger.info(f"🔄 vMCP Middleware: private/{vmcp_name}/vmcp -> /vmcp/mcp")
        
        # Set headers and forward to MCP endpoint
        request.headers.__dict__["_list"].append((b"vmcp-name", vmcp_name.encode()))
        request.headers.__dict__["_list"].append((b"vmcp-username", b"private"))
        
        # Modify the request path
        request.scope["path"] = "/vmcp/mcp"
        return await call_next(request)
    
    # No vMCP pattern matched, continue with normal processing
    return await call_next(request)

# MCP Authentication middleware - enforces HTTP 401 per MCP spec
@app.middleware("http")
async def mcp_auth_middleware(request: Request, call_next):
    """MCP Authentication middleware per MCP Authorization specification"""
    logger.debug("In mcp_auth_middleware")
    # Determine if this is an MCP request
    is_mcp_request = request.url.path.startswith("/vmcp/mcp") #or request.url.path == "/"
    
    # Skip authentication for OAuth callback endpoints
    if request.url.path.startswith("/otherservers/oauth/callback"):
        logger.info(f"🔄 OAuth callback endpoint - skipping authentication: {request.url.path}")
        return await call_next(request)
    
    if is_mcp_request:
        # Redirect mcp/ -> mcp
        if request.url.path == "/vmcp/mcp/":
            logger.warning(f"🔄 MCP Redirect: {request.method} {request.url.path} -> /mcp")
            
            # Create redirect response
            from fastapi.responses import RedirectResponse
            redirect_response = RedirectResponse(url="/vmcp/mcp", status_code=307)
            
            # Preserve ALL headers from the original request
            for header_name, header_value in request.headers.items():
                # Skip some headers that shouldn't be forwarded
                if header_name.lower() not in ['host', 'content-length']:
                    redirect_response.headers[header_name] = header_value
            
            logger.info(f"📋 Preserved headers in redirect: {list(request.headers.keys())}")
            return redirect_response
        
        # Comprehensive MCP request logging
        logger.info("=" * 80)
        logger.info("🔄 MCP REQUEST RECEIVED")
        logger.info("=" * 80)
        logger.info(f"📋 Request Details:")
        logger.info(f"   Method: {request.method}")
        logger.info(f"   Path: {request.url.path}")
        logger.info(f"   Full URL: {request.url}")
        logger.info(f"   Client Host: {request.client.host if request.client else 'Unknown'}")
        logger.info(f"   User Agent: {request.headers.get('user-agent', 'Unknown')}")
        
        # Log all headers
        logger.info(f"📋 Request Headers:")
        for header_name, header_value in request.headers.items():
            # Mask sensitive headers
            if header_name.lower() in ['authorization', 'cookie']:
                masked_value = f"{header_value[:10]}..." if len(header_value) > 10 else "***"
                logger.info(f"   {header_name}: {masked_value}")
            else:
                logger.info(f"   {header_name}: {header_value}")
        
        # Log query parameters if any
        if request.query_params:
            logger.info(f"📋 Query Parameters:")
            for key, value in request.query_params.items():
                logger.info(f"   {key}: {value}")
        
        # Log request body for POST/PUT requests
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body = await request.body()
                if body:
                    logger.info(f"📋 Request Body: {body}")
                    # Try to parse as JSON for better readability
                    try:
                        import json
                        json_body = json.loads(body)
                        logger.info(f"📋 Parsed JSON Body:")
                        for key, value in json_body.items():
                            logger.info(f"   {key}: {value}")
                        
                        # ==================== Check if this is an initialize request and handle agent management
                        if json_body.get("method") == "initialize":
                            # Extract Bearer token
                            bearer_token = request.headers.get('Authorization', '').replace('Bearer ', '').strip()
                            if bearer_token:
                                await handle_agent_initialize(request, json_body, bearer_token)
                            else:
                                logger.warning("❌ No Bearer token found for agent management")
                        
                        # For all MCP calls, try to log them for the agent
                        else:
                            # Extract Bearer token and try to log the call
                            bearer_token = request.headers.get('Authorization', '').replace('Bearer ', '').strip()
                            if bearer_token:
                                await log_mcp_call_for_agent(request, json_body, bearer_token)
                        # ==================== End of agent management check
                    except json.JSONDecodeError:
                        logger.info(f"📋 Body is not JSON: {body}")
                else:
                    logger.info(f"📋 Request Body: Empty")
            except Exception as e:
                logger.info(f"📋 Could not read request body: {e}")
        
        # Handle CORS preflight
        if request.method == "OPTIONS":
            logger.info("📋 Handling CORS preflight for MCP")
            from fastapi.responses import Response
            return Response(
                status_code=204,
                headers={
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
                    "Access-Control-Allow-Headers": "Authorization, Content-Type, MCP-Protocol-Version, Accept",
                    "Access-Control-Max-Age": "86400"
                }
            )
        
        # MCP Authorization specification: "When authorization is required and not yet proven by the client, 
        # servers MUST respond with HTTP 401 Unauthorized"
        auth_header = request.headers.get('Authorization')
        logger.info(f"🔄 MCP AUTH: Authorization header: {auth_header}")
        vmcp_name = request.headers.get('vmcp-name')
        vmcp_username = request.headers.get('vmcp-username')
        share_vMCP = request.headers.get('share-vMCP', False)
        
        # Check if this is an SSE request (GET with text/event-stream Accept header)
        is_sse_request = (request.method == "GET" and 
                         'text/event-stream' in request.headers.get('Accept', ''))
        if not auth_header:
            logger.info("❌ MCP AUTH: No Authorization header - returning HTTP 401")
            if vmcp_username:
                resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_username}/{vmcp_name}/vmcp"
            else:
                resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_name}/vmcp"

            logger.info(f"🔄 MCP AUTH: Resource metadata URL: {resource_metadata}")
            return render_unauthorized_template(
                resource_metadata=resource_metadata,
                vmcp_username=vmcp_username,
                vmcp_name=vmcp_name,
                error_description="Missing Authorization header",
                share_vMCP=share_vMCP,
                request_type=request.method,  # POST or GET
                is_sse_request=is_sse_request
            )
        
        if not auth_header.startswith('Bearer '):
            logger.info("❌ MCP AUTH: Invalid Authorization header format - returning HTTP 401")
            if vmcp_username:
                resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_username}/{vmcp_name}/vmcp"
            else:
                resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_name}/vmcp"
            return render_unauthorized_template(
                resource_metadata=resource_metadata,
                vmcp_username=vmcp_username,
                vmcp_name=vmcp_name,
                error_description="Invalid authorization header format. Expected: Bearer <token>",
                share_vMCP=share_vMCP,
                request_type=request.method,  # POST or GET
                is_sse_request=is_sse_request
            )
        
        # Extract token for validation
        token = auth_header.replace('Bearer', '').strip()
        
        # Get custom client header
        x_1xn_client = request.headers.get('1xn_client')
        
        # Add detailed token logging
        logger.info(f"🔍 MCP AUTH: Extracted token: {token[:20]}...{token[-10:] if len(token) > 30 else token}")
        logger.info(f"🔍 MCP AUTH: Token length: {len(token)}")
        
        # Validate access token directly using JWT service
        try:
            # from auth_service.jwt_service import JWTService  # OSS - no auth
            # from auth_service.database import get_db  # OSS - no auth
            
            jwt_service = JWTService()
            
            # Validate token and extract information
            token_info = jwt_service.extract_token_info(token)
            logger.info(f"🔍 MCP AUTH: JWT Token payload: {token_info}")
            if not token_info:
                logger.info("❌ MCP AUTH: Invalid access token - returning HTTP 401")
                if vmcp_username:
                    resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_username}/{vmcp_name}/vmcp"
                else:
                    resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_name}/vmcp"
                return render_unauthorized_template(
                    resource_metadata=resource_metadata,
                    vmcp_username=vmcp_username,
                    vmcp_name=vmcp_name,
                    error_description="Invalid or expired access token",
                    share_vMCP=share_vMCP,
                    request_type=request.method,  # POST or GET
                    is_sse_request=is_sse_request
                )
            
            # Check if token is blacklisted (OSS version - no blacklist check)
            # db = next(get_db())  # OSS - no auth database
            # if jwt_service.is_token_blacklisted(token, db):  # OSS - no blacklist
            #     logger.warning("❌ MCP AUTH: Token has been revoked - returning HTTP 401")
            #     if vmcp_username:
            #         resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_username}/{vmcp_name}/vmcp"
            #     else:
            #         resource_metadata = f"{BASE_URL}/.well-known/oauth-protected-resource/{vmcp_name}/vmcp"
            #     return render_unauthorized_template(
            #         resource_metadata=resource_metadata,
            #         vmcp_username=vmcp_username,
            #         vmcp_name=vmcp_name,
            #         error_description="Token has been revoked",
            #         share_vMCP=share_vMCP,
            #         request_type=request.method,  # POST or GET
            #         is_sse_request=is_sse_request
            #     )
            
            user_id = token_info.get("user_id")
            client_id = token_info.get("client_id", "")
            client_name = token_info.get("client_name", "")
            
            # Store user context in request state for MCP methods to access
            request.state.user_id = user_id
            request.state.client_id = client_id
            request.state.client_name = client_name
            
            logger.info(f"✅ MCP AUTH: Verified access token for user {user_id}, client {client_id} - proceeding with request")
            
        except Exception as e:
            logger.error(f"❌ MCP AUTH: Session validation error: {e}")
            from fastapi.responses import JSONResponse
            from fastapi import status
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"error": "auth_service_error"}
            )
    
    # Process the request
    response = await call_next(request)
    
    # Log response for MCP requests
    if is_mcp_request:
        logger.info("=" * 80)
        logger.info("✅ MCP RESPONSE SENT")
        logger.info("=" * 80)
        logger.info(f"📋 Response Details:")
        logger.info(f"   Status Code: {response.status_code}")
        logger.info(f"   Method: {request.method}")
        logger.info(f"   Path: {request.url.path}")
        
        # Log response headers
        logger.info(f"📋 Response Headers:")
        for header_name, header_value in response.headers.items():
            logger.info(f"   {header_name}: {header_value}")
        
        # Log response body for error responses
        if response.status_code >= 400:
            try:
                # For error responses, try to log the response body
                if hasattr(response, 'body'):
                    response_body = response.body
                    if response_body:
                        logger.info(f"📋 Error Response Body: {response_body}")
            except Exception as e:
                logger.info(f"📋 Could not read error response body: {e}")
        
        logger.info("=" * 80)
    
    return response

# OSS: Root redirects directly to vMCP list page
@app.get("/")
async def root():
    """Redirect to vMCP page - OSS has no separate landing page"""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/app/vmcp")

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "ok"}

@app.get("/api/config")
async def get_config():
    """Get server configuration including base URL"""
    return {
        "base_url": settings.base_url,
        "host": settings.host,
        "port": settings.port,
        "app_name": settings.app_name,
        "version": settings.app_version
    }


# Mount the API routes (OSS version - minimal routers)
logger.info("📌 Mounting API routes...")
app.include_router(mcp_router, prefix="/api")
app.include_router(vmcp_router, prefix="/api")
app.include_router(widget_router, prefix="/api")
app.include_router(oauth_handler_router, prefix="/api")
app.include_router(blob_router, prefix="/api")
# Widget serve router (public, no prefix)
app.include_router(widget_serve_router, prefix="/api")

# Mount the MCP server (now with shared lifespan)
logger.info("📌 Mounting MCP server with shared lifespan...")
app.mount("/vmcp/", mcp_http_app, name="1xn_mcp_server")
logger.debug(f"🔍 MCP HTTP app routes: {app.routes}")
logger.info("✅ MCP server mounted at /vmcp/mcp")

# Serve frontend with SPA routing support
from pathlib import Path
from fastapi.responses import FileResponse

# Try to find frontend in public/frontend (for packaged version or development)
# First try: packaged version (public/frontend at package root in site-packages)
frontend_dist = Path(__file__).parent.parent.parent / "public" / "frontend"
# Second try: development version (backend/public/frontend)
if not frontend_dist.exists():
    frontend_dist = Path(__file__).parent.parent.parent.parent / "public" / "frontend"
if frontend_dist.exists():
    logger.info(f"📁 Serving frontend from {frontend_dist}")

    # Serve static assets (CSS, JS, etc.)
    @app.get("/app/assets/{file_path:path}")
    async def serve_assets(file_path: str):
        """Serve static assets"""
        asset_file = frontend_dist / "assets" / file_path
        if asset_file.is_file():
            # Determine media type based on file extension
            media_type = None
            headers = {}

            if file_path.endswith('.css'):
                media_type = 'text/css; charset=utf-8'
                headers['Cache-Control'] = 'public, max-age=31536000'
            elif file_path.endswith('.js'):
                media_type = 'application/javascript; charset=utf-8'
                headers['Cache-Control'] = 'public, max-age=31536000'
            elif file_path.endswith('.ico'):
                media_type = 'image/x-icon'
                headers['Cache-Control'] = 'public, max-age=31536000'

            return FileResponse(asset_file, media_type=media_type, headers=headers)
        raise HTTPException(status_code=404, detail="Asset not found")

    # Catch-all for SPA routes - serve index.html for all other /app/* routes
    @app.get("/app/{full_path:path}")
    async def serve_spa(full_path: str):
        """Serve SPA - index.html for all routes, or specific files if they exist"""
        # Check if it's a specific file request (has extension)
        if "." in full_path:
            file_path = frontend_dist / full_path
            if file_path.is_file():
                return FileResponse(file_path)
        # For routes without extension, serve index.html (SPA routing)
        return FileResponse(frontend_dist / "index.html")

    # Serve index.html for /app/ (root of app)
    @app.get("/app/")
    async def serve_app_root():
        """Serve index.html for app root"""
        return FileResponse(frontend_dist / "index.html")

    logger.info("✅ Frontend served at /app with SPA routing")
else:
    logger.warning(f"⚠️ Frontend build directory not found at {frontend_dist}")

# Serve documentation from public/documentation
documentation_dist = Path(__file__).parent.parent / "public" / "documentation"
if not documentation_dist.exists():
    documentation_dist = Path(__file__).parent.parent.parent.parent / "public" / "documentation"
if documentation_dist.exists():
    logger.info(f"📁 Serving documentation from {documentation_dist}")

    # Mount documentation as static files
    app.mount("/documentation", StaticFiles(directory=str(documentation_dist), html=True), name="documentation")
    logger.info("✅ Documentation served at /documentation")
else:
    logger.warning(f"⚠️ Documentation build directory not found at {documentation_dist}")

def create_app():
    """Factory function to create FastAPI app instance."""
    return app
