from birdgame.constants import HORIZON as HORIZON
from birdgame.constants import GAME_PARAMS as GAME_PARAMS