from .core import combine_html_files
__all__ = ["combine_html_files"]
__version__ = "3.7.2"
