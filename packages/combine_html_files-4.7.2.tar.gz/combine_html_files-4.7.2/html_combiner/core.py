import os


def combine_html_files(base_path,output_path, names_tbl_data, payment_tbl_data, name, year):
    cwd = os.getcwd()
    with open(base_path, 'r') as base_file:
        base_content = base_file.read()
    
    # with open(trrn_names_path, 'r') as trrn_file:
    #     trrn_content = trrn_file.read()
    trrn_content = names_tbl_data
    # with open(payment_details_path, 'r') as payment_file:
    #     payment_content = payment_file.read()
    payment_content = payment_tbl_data
    print("\n\n")
    # print(trrn_content) #this line need to be commetted because of print buffer
    print(type(trrn_content))
    # print(trrn_content)
    print("\n\n")
    
    none_block = 'style="display: none;"'

    combined_content = base_content.replace('<!-- INSERT YEAR HERE -->', year)
    combined_content = combined_content.replace('<!-- INSERT NAME &&& HERE -->', name)

    combined_content = combined_content.replace('<!-- INSERT PAYMENT_DETAILS.HTML HERE -->', payment_content)
    if trrn_content.upper()=="NONE":
        print("TRRN_CONTENT IS EMPTY")
        combined_content = combined_content.replace('style="display: block;"', none_block)
    else:
        combined_content = combined_content.replace('<!-- INSERT TRRN_NAMES.HTML HERE -->', trrn_content)

    
    with open(output_path, 'w') as output_file:
        output_file.write(combined_content)
    return os.path.join(cwd, output_path)


