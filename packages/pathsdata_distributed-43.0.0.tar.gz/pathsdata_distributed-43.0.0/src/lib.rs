// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

use crate::utils::wait_for_future;
use ballista::prelude::*;
use cluster::{PyExecutor, PyScheduler};
use datafusion::execution::SessionStateBuilder;
use datafusion::prelude::*;
use datafusion_python::context::PySessionContext;
use pyo3::prelude::*;
use std::{error::Error, sync::Arc};

use datafusion_iceberg::{
    catalog::catalog::IcebergCatalog,
};
use iceberg_rust::catalog::Catalog ;
use object_store::ObjectStore;
use aws_config::BehaviorVersion;

use iceberg_glue_catalog::GlueCatalog;
use aws_config::Region;
use ballista::{
    extension::SessionConfigExt,
    extension::SessionContextExt,
};
use ballista_core::object_store::{session_state_with_s3_support, S3Options};
use ballista_core::serde::logicalextensioncodec::IcebergExtensionCodec;
use datafusion::execution::object_store::ObjectStoreRegistry;
use url::Url;
use datafusion_common::tree_node::{TransformedResult, TreeNode};
use datafusion_iceberg::planner::{iceberg_transform, IcebergExtensionPlanner};
use datafusion::prelude::{SessionConfig, SessionContext};

mod cluster;
#[allow(dead_code)]
mod codec;
mod utils;

pub(crate) struct TokioRuntime(tokio::runtime::Runtime);

#[pymodule]
fn ballista_internal(_py: Python, m: Bound<'_, PyModule>) -> PyResult<()> {
    pyo3_log::init();

    m.add_class::<PyBallistaBuilder>()?;
    m.add_class::<datafusion_python::dataframe::PyDataFrame>()?;
    m.add_class::<PyScheduler>()?;
    m.add_class::<PyExecutor>()?;

    Ok(())
}

#[pyclass(name = "BallistaBuilder", module = "pathsdata_distributed", subclass)]
pub struct PyBallistaBuilder {
    session_config: SessionConfig,
}

#[pymethods]
impl PyBallistaBuilder {
    #[new]
    pub fn new() -> Self {
        Self {
            session_config: SessionConfig::new_with_ballista(),
        }
    }

    pub fn config(
        mut slf: PyRefMut<'_, Self>,
        key: &str,
        value: &str,
        py: Python,
    ) -> PyResult<PyObject> {
        let _ = slf.session_config.options_mut().set(key, value);

        Ok(slf.into_py(py))
    }

    /// Construct the standalone instance from the SessionContext
    pub fn standalone(&self, py: Python) -> PyResult<PySessionContext> {
        let state = SessionStateBuilder::new()
            .with_config(self.session_config.clone())
            .with_default_features()
            .build();

        let ctx = wait_for_future(py, SessionContext::standalone_with_state(state))?;

        Ok(ctx.into())
    }

    /// Construct the remote instance from the SessionContext
    #[pyo3(signature = (url, s3_url, catalog_name, region))]
    pub fn remote(&self, url: &str, s3_url: &str, catalog_name: &str, region: &str, py: Python) -> PyResult<PySessionContext> {
        let config = SessionConfig::new_with_ballista()
            .with_information_schema(true)
            .with_option_extension(S3Options::default())
            .with_ballista_logical_extension_codec(Arc::new(IcebergExtensionCodec{}));
        
        let state = session_state_with_s3_support(config)?;
    
        let binding = state.clone();
        let object_store_registry = binding.runtime_env().object_store_registry.clone();

        let ctx = wait_for_future(py, SessionContext::remote_with_state(url, state))?;
        
        let sdk_config = wait_for_future(py, aws_config::defaults(BehaviorVersion::v2024_03_28())
            .region(Region::new(region.to_string()))
            .load());

        let region_query = wait_for_future(py, ctx.sql(&format!("SET s3.region = '{}'", region)))?;

        wait_for_future(py, region_query.show())?;

        let catalog: Arc<dyn Catalog> =
            Arc::new(GlueCatalog::with_object_store_reg(&sdk_config, catalog_name, object_store_registry).unwrap());

        let iceberg_catalog = wait_for_future(py, async move {
            IcebergCatalog::new(catalog.clone(), None).await
        })?;
        
        ctx.register_catalog(
            catalog_name,
            Arc::new(iceberg_catalog),
        );

        Ok(ctx.into())
    }

    /// Call ddl statement
    #[pyo3(signature = (ctx, sql_query))]
    pub fn execute_ddl(&self, ctx: &PySessionContext, sql_query: &str, py: Python) -> PyResult<()> {
        let ctx = &ctx.ctx.clone();
        let plan = wait_for_future(py, ctx.state().create_logical_plan(sql_query)).unwrap();

        let transformed = plan.transform(iceberg_transform).data().unwrap();

        let result = wait_for_future(py, async move {
            ctx.execute_logical_plan(transformed).await
        }).expect("Failed to execute query plan.");

        Ok(())
    }

    #[classattr]
    pub fn version() -> &'static str {
        ballista_core::BALLISTA_VERSION
    }
}
