"""Synchronous extraction logic package."""
