from __future__ import annotations

import os
import traceback
from typing import Any, Dict, Optional
import time
import hmac
import hashlib

from fastmcp.server.middleware import Middleware, MiddlewareContext


# ---- OpenTelemetry (OTLP over HTTP to local collector/jaeger) ----
trace: Any = None
TraceContextTextMapPropagator: Any = None
tracer = None
try:
    from opentelemetry import trace  # type: ignore
    from opentelemetry.trace.propagation.tracecontext import (  # type: ignore
        TraceContextTextMapPropagator,
    )
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (  # type: ignore
        OTLPSpanExporter,
    )
    from opentelemetry.sdk.trace import TracerProvider  # type: ignore
    from opentelemetry.sdk.resources import Resource  # type: ignore
    from opentelemetry.sdk.trace.export import BatchSpanProcessor  # type: ignore

    otlp_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://127.0.0.1:4318")
    resource = Resource.create({"service.name": os.getenv("OTEL_SERVICE_NAME", "fastmcp-enhanced")})
    provider = TracerProvider(resource=resource)
    processor = BatchSpanProcessor(OTLPSpanExporter(endpoint=f"{otlp_endpoint}/v1/traces"))
    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)
    tracer = trace.get_tracer(os.getenv("OTEL_SERVICE_NAME", "fastmcp-enhanced"))

    print("OpenTelemetry setup complete")
except Exception:
    print("Error setting up OpenTelemetry:")
    print(traceback.format_exc())
    tracer = None


class CustomHeaderMiddleware(Middleware):
    async def on_request(self, context: MiddlewareContext, call_next):
        method = getattr(context, "method", "UNKNOWN")
        tool_name = getattr(getattr(context, "message", None), "name", None)

        # If OpenTelemetry isn't available, skip tracing entirely
        if tracer is None or "trace" not in globals() or trace is None or "TraceContextTextMapPropagator" not in globals() or TraceContextTextMapPropagator is None:  # type: ignore[name-defined]
            return await call_next(context)

        def _extract_parent_ctx(req) -> Any:
            propagator = TraceContextTextMapPropagator()

            # Try headers first
            try:
                hdr_ctx = propagator.extract(req.headers)
                hdr_span = trace.get_current_span(hdr_ctx).get_span_context()
                if hdr_span and getattr(hdr_span, "is_valid", False):
                    return hdr_ctx
            except Exception:
                pass

            # Fallback to query parameters (?traceparent=&tracestate=)
            try:
                qp = getattr(req, "query_params", None)
                if qp:
                    carrier: Dict[str, str] = {}
                    tp = qp.get("traceparent")
                    ts = qp.get("tracestate")
                    if tp:
                        carrier["traceparent"] = tp
                    if ts:
                        carrier["tracestate"] = ts
                    if carrier:
                        q_ctx = propagator.extract(carrier)
                        q_span = trace.get_current_span(q_ctx).get_span_context()
                        if q_span and getattr(q_span, "is_valid", False):
                            return q_ctx
            except Exception:
                pass

            return None

        parent_ctx: Any = None
        try:
            fast_ctx = getattr(context, "fastmcp_context", None)
            if fast_ctx is not None and getattr(fast_ctx, "request_context", None) is not None:
                req = getattr(fast_ctx.request_context, "request", None)
                if req is not None:
                    parent_ctx = _extract_parent_ctx(req)
        except Exception:
            parent_ctx = None

        span_name = f"mcp.{method}"
        if tool_name:
            span_name = f"mcp.tools.{tool_name}"

        with tracer.start_as_current_span(span_name, context=parent_ctx) as span:  # type: ignore[attr-defined]
            span.set_attribute("mcp.method", method)
            if tool_name:
                span.set_attribute("mcp.tool", tool_name)
            result = await call_next(context)
            return result


class AuthTokenMiddleware(Middleware):
    async def on_request(self, context: MiddlewareContext, call_next):
        expected_token = os.getenv("MCP_AUTH_TOKEN")
        # Only enforce if an expected token is configured
        if expected_token:
            token: Optional[str] = None
            try:
                fast_ctx = getattr(context, "fastmcp_context", None)
                if fast_ctx is not None and getattr(fast_ctx, "request_context", None) is not None:
                    req = getattr(fast_ctx.request_context, "request", None)
                    if req is not None:
                        # 1) Prefer Authorization: Bearer <token>
                        auth = None
                        try:
                            auth = req.headers.get("Authorization")
                        except Exception:
                            auth = None
                        if auth and isinstance(auth, str) and auth.lower().startswith("bearer "):
                            token = auth.split(" ", 1)[1].strip()
                        # 2) Or X-MCP-Token header
                        if not token:
                            try:
                                token = req.headers.get("X-MCP-Token")
                            except Exception:
                                token = None
                        # 3) Dev fallback: query param if allowed
                        allow_query = os.getenv("ALLOW_QUERY_TOKEN", "true").lower() == "true"
                        if not token and allow_query and hasattr(req, "query_params"):
                            token = req.query_params.get("auth_token")
            except Exception:
                token = None

            if not token or token != expected_token:
                raise PermissionError("invalid or missing auth token")

        return await call_next(context)


# Simple HMAC auth: client sends X-MCP-KeyId, X-MCP-Timestamp, X-MCP-Signature.
# Signature is hex(hmac_sha256(secret, f"{ts}\n{method}\n{path}")) with up to 5 minutes skew.
class HMACAuthMiddleware(Middleware):
    def _load_secret(self, key_id: str) -> Optional[str]:
        # Single key via env
        single_id = os.getenv("MCP_HMAC_KEY_ID")
        single_secret = os.getenv("MCP_HMAC_SECRET")
        if single_id and single_secret and key_id == single_id:
            return single_secret
        # TODO: Optionally support JSON map in MCP_HMAC_KEYS_JSON later
        return None

    async def on_request(self, context: MiddlewareContext, call_next):
        # If HMAC is configured via env, enforce; otherwise allow through
        configured = bool(os.getenv("MCP_HMAC_KEY_ID") and os.getenv("MCP_HMAC_SECRET"))
        if not configured:
            return await call_next(context)

        try:
            fast_ctx = getattr(context, "fastmcp_context", None)
            if fast_ctx is None or getattr(fast_ctx, "request_context", None) is None:
                raise PermissionError("missing request context")
            req = getattr(fast_ctx.request_context, "request", None)
            if req is None:
                raise PermissionError("missing request")

            # Extract headers
            key_id = req.headers.get("X-MCP-KeyId") or req.headers.get("X-MCP-Key")
            ts = req.headers.get("X-MCP-Timestamp")
            sig = req.headers.get("X-MCP-Signature")
            if not key_id or not ts or not sig:
                raise PermissionError("missing hmac headers")

            # Timestamp freshness (skew up to 300s)
            try:
                ts_int = int(ts)
            except Exception:
                raise PermissionError("invalid timestamp")
            now = int(time.time())
            if abs(now - ts_int) > 300:
                raise PermissionError("stale timestamp")

            secret = self._load_secret(key_id)
            if not secret:
                raise PermissionError("unknown key id")

            method = (getattr(req, "method", "POST") or "POST").upper()
            path = getattr(getattr(req, "url", None), "path", "/mcp") or "/mcp"
            base = f"{ts}\n{method}\n{path}"
            expected = hmac.new(secret.encode("utf-8"), base.encode("utf-8"), hashlib.sha256).hexdigest()

            if not hmac.compare_digest(expected, sig):
                raise PermissionError("invalid signature")

        except PermissionError:
            raise
        except Exception:
            raise PermissionError("hmac verification failed")

        return await call_next(context)


