from __future__ import annotations

from typing import Callable, Optional, Type, Any, Dict, List, Tuple
from pydantic import BaseModel
from fastmcp import FastMCP


class ToolRegistry:
    def __init__(self) -> None:
        self.entries: List[Dict[str, Any]] = []

    def register(
        self,
        name: str,
        func: Callable[..., Any],
        input_model: Optional[Type[BaseModel]],
        output_model: Optional[Type[BaseModel]],
        description: Optional[str],
    ) -> None:
        self.entries.append(
            {
                "name": name,
                "func": func,
                "in_model": input_model,
                "out_model": output_model,
                "desc": (description or "").strip() or None,
            }
        )


registry = ToolRegistry()


def tool(
    name: str,
    input_model: Optional[Type[BaseModel]] = None,
    output_model: Optional[Type[BaseModel]] = None,
    description: Optional[str] = None,
):
    def deco(func: Callable[..., Any]) -> Callable[..., Any]:
        registry.register(name, func, input_model, output_model, description or getattr(func, "__doc__", None))
        return func

    return deco


def mount_tools(
    mcp: FastMCP,
    schema_builder: Callable[[Optional[type], Optional[type]], Tuple[Dict[str, Any], Dict[str, Any]]],
) -> List[Tuple[Dict[str, Any], Callable[..., Any]]]:
    """Expose tools from the registry on the given FastMCP app and add tools/list."""
    exposed: List[Tuple[Dict[str, Any], Callable[..., Any]]] = []
    for e in registry.entries:
        exposed_fn = mcp.tool(name=e["name"])(e["func"])  # type: ignore[arg-type]
        exposed.append((e, exposed_fn))

    @mcp.tool(name="list_tools")
    def list_tools() -> Dict[str, Any]:
        items: List[Dict[str, Any]] = []
        for e, _ in exposed:
            s_in, s_out = schema_builder(e.get("in_model"), e.get("out_model"))
            items.append(
                {
                    "name": e["name"],
                    "description": e.get("desc"),
                    "inputSchema": s_in,
                    "outputSchema": s_out,
                }
            )
        return {"tools": items}

    return exposed


