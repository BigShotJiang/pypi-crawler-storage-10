from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from fastmcp import FastMCP
import httpx
import yaml


def _overlay(overlay_file: Optional[str]) -> Dict[str, Any]:
    if not overlay_file:
        return {}
    try:
        with open(overlay_file, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def _post(target_url: str, payload: Dict[str, Any], bearer_token: Optional[str]) -> Dict[str, Any]:
    headers = {"Accept": "application/json, text/event-stream", "Content-Type": "application/json"}
    if bearer_token:
        headers["Authorization"] = f"Bearer {bearer_token}"
    r = httpx.post(target_url, headers=headers, content=json.dumps(payload), timeout=15)
    r.raise_for_status()
    return r.json()


def build_proxy_app(target_url: str, overlay_file: Optional[str] = None, bearer_token: Optional[str] = None) -> FastMCP:
    app = FastMCP(name="MCPProxy")

    @app.tool(name="list_tools")
    def list_tools() -> Dict[str, Any]:
        if not target_url:
            return {"tools": []}
        res = _post(target_url, {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}, bearer_token)
        tools: List[Dict[str, Any]] = res.get("result", {}).get("tools", [])
        ov = _overlay(overlay_file)
        ov_map = {t.get("name"): t for t in ov.get("tools", [])}
        merged: List[Dict[str, Any]] = []
        for t in tools:
            name = t.get("name")
            if name in ov_map:
                mt = {**t}
                o = ov_map[name]
                if o.get("description"):
                    mt["description"] = o["description"]
                if o.get("inputSchema"):
                    mt["inputSchema"] = o["inputSchema"]
                if o.get("outputSchema"):
                    mt["outputSchema"] = o["outputSchema"]
                merged.append(mt)
            else:
                merged.append(t)
        return {"tools": merged}

    @app.tool(name="call")
    def call(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if not target_url:
            raise ValueError("Proxy target not configured")
        res = _post(
            target_url,
            {"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": name, "arguments": arguments}},
            bearer_token,
        )
        return res.get("result", {})

    return app


def run_proxy(target_url: str, overlay_file: Optional[str] = None, bearer_token: Optional[str] = None, host: str = "127.0.0.1", port: int = 8010) -> None:
    app = build_proxy_app(target_url, overlay_file, bearer_token)
    app.run(transport="http", host=host, port=port, stateless_http=True)


