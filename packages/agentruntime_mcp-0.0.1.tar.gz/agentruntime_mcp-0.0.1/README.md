# AgentRuntime MCP SDK (Python)

Opinionated SDK for building MCP agents with FastMCP.

## Install
```bash
pip install agentruntime-mcp
```

## Minimal example
```python
from pydantic import BaseModel, Field
from agentruntime.mcp.decorators import tool
from agentruntime.mcp.runtime import run

class In(BaseModel):
    a: float = Field(...)
    b: float = Field(...)

class Out(BaseModel):
    result: float
    expression: str

@tool(name="add", input_model=In, output_model=Out)
def add(a: float, b: float) -> Out:
    return Out(result=a+b, expression=f"{a} + {b}")

if __name__ == "__main__":
    run("config.yaml")
```

## Config
- `config.yaml` controls server host/port, auth mode, and tracing.  
- Env overrides: `HOST`, `PORT`, `MCP_AUTH_MODE`.

Auth modes
- `none`: no auth
- `token`: `Authorization: Bearer <token>` or `X-MCP-Token`; dev fallback `?auth_token=` if `ALLOW_QUERY_TOKEN=true`
- `hmac`: headers `X-MCP-KeyId`, `X-MCP-Timestamp` (unix seconds), `X-MCP-Signature` (hex(HMAC-SHA256(secret, `${ts}\n${method}\n${path}`)))

## Proxy (library)
```python
from agentruntime.mcp.proxy import run_proxy
run_proxy(target_url="http://127.0.0.1:8000/mcp", overlay_file="tools.yaml", host="127.0.0.1", port=8010)
```
