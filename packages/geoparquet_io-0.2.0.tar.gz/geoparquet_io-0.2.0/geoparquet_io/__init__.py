from geoparquet_io.cli.main import cli

__all__ = ["cli"]
