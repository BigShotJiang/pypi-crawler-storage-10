# format Command

For detailed usage and examples, see the [Format User Guide](../guide/format.md).

## Quick Reference

```bash
gpio format --help
```

This will show all available subcommands and options.
