# check Command

For detailed usage and examples, see the [Check User Guide](../guide/check.md).

## Quick Reference

```bash
gpio check --help
```

This will show all available subcommands and options.
