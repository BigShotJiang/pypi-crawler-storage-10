# inspect Command

For detailed usage and examples, see the [Inspect User Guide](../guide/inspect.md).

## Quick Reference

```bash
gpio inspect --help
```

This will show all available options for the `inspect` command.
