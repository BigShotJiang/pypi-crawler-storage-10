"""
Setup script for fuzzy-json-repair.
Uses pyproject.toml for configuration.
"""

from setuptools import setup

# All configuration is in pyproject.toml
setup()
