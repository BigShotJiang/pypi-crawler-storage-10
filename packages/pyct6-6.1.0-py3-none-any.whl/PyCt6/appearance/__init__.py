from .theme_manager import ThemeManager
from .mode_manager import ModeManager

ThemeManager.load_theme("blue")
ModeManager.set_mode("system")
