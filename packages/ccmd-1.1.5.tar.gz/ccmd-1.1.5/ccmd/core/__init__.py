"""Core modules for CCMD"""
