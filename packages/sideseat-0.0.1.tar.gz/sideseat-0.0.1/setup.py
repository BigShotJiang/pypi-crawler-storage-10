from setuptools import setup

setup(
    name="sideseat",
    version="0.0.1",
    author="Your Name",
    author_email="sergey@spugachev.com",
    description="A minimal sideseat package",
    packages=["sideseat"],
    python_requires=">=3.7",
)
