def hello(): print("Hello from sideseat!")
