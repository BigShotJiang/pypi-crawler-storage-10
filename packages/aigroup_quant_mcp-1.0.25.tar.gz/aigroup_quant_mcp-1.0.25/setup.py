"""
AI Group Quantitative Analysis MCP Service
"""
from setuptools import setup

# 从pyproject.toml读取配置
setup()
