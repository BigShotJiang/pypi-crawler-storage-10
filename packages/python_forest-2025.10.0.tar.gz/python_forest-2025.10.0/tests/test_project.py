from pathlib import Path

import pytest

from forest import Project
from forest.project import NoSuchProject


def test_project_should_report_no_error_on_valid_project():
    proj = Project(".")
    assert proj.name == "forest"
    assert proj.root.absolute() == Path().absolute()


def test_project_should_report_error_on_invalid_project():
    with pytest.raises(NoSuchProject):
        Project("./nosuchproj")
