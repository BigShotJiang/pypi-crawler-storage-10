__version__ = "2025.10.0"

from .project import Project
