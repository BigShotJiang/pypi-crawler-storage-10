.. _examples_generating_a_git_repository_template_sec:

Generating a ``git`` repository template
========================================

In the code example below, we generate a local ``git`` repository template using
``pylibtemplate``. You can also find the same code in the file
``examples/generating_a_git_repository_template.py`` of the repository.

.. literalinclude:: ../../examples/generating_a_git_repository_template.py
