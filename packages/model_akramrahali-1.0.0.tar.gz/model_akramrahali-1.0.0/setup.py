from setuptools import setup

setup(
   name='model_akramrahali',
   version='1.0.0',
   author='akram rahali',
   author_email='ak.rahali@esi-sba.dz',
   packages=['model_akramrahali'],
   url='http://pypi.python.org/pypi/model_akramrahali/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['model_akramrahali']
)