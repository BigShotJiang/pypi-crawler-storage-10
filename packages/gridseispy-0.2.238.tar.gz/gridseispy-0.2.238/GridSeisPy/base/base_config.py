import typing
from .base_class import CVDFile


class BaseConfig(CVDFile):
    """
    配置参数要求: 1. 配置参数必须有类型注解, 2. 配置参数必须有默认值, 3. 配置参数可以通过typing.Annotated添加描述(类型注解在最前面, 描述在后面)
    配置基类，用于存储配置参数，要求配置参数必须有类型注解，否则无类型注解变量无法被转换为字典
    并提供to_dict和from_dict方法，用于将配置参数转换为字典和从字典转换为配置参数
    """

    def __getstate__(self):
        """自定义序列化，保存实例属性及类属性"""
        # # 只负责类属性
        # state = type(self).__dict__.copy()
        # return state

        # 保存实例属性及类属性
        state = self.__dict__.copy()  # 保存实例属性
        # 将类属性作为特殊键添加到 state
        cls = type(self)
        for key, value in cls.__dict__.items():
            state[f'_class_{key}'] = value
        return state
    
    def __setstate__(self, state):
        """自定义反序列化，恢复实例属性及类属性"""
        # 只负责类属性
        # state = state.update({k: v for k, v in state.items() if not k.startswith('_class_')})
        # return state

        # 先恢复实例属性
        self.__dict__.update({k: v for k, v in state.items() if not k.startswith('_class_')})
        # 恢复类属性
        cls = type(self)
        for key, value in state.items():
            if key.startswith('_class_'):
                setattr(cls, key[7:], value)
        return cls()

    def to_dict(self) -> dict:
        # 使用 __annotations__ 只获取有类型注解的类变量，并过滤掉可调用对象（如方法）
        dict_config = {
            key: getattr(self, key) for key, value in type(self).__dict__.items() 
            if key in type(self).__annotations__ and not callable(value)
            }
        return dict_config

    @classmethod
    def to_desc(cls) -> dict:
        # cls_name = cls.__qualname__.split('.')[0]
        cls_name = cls.__qualname__
        # 从 __qualname__ 解析出外部类名（如 'UNet3D_Simple.cfg' -> 'UNet3D_Simple'）
        desc_dict = {}
        for key, annotations in cls.__annotations__.items():
            if annotations is callable: continue
            annotations, *desc = typing.get_args(annotations) if typing.get_origin(annotations) == typing.Annotated else (annotations, '')
            
            type_str = annotations.__name__ if type(annotations) == type(type(None)) else str(annotations)
            desc_dict[key] = {'type': type_str , 'default': getattr(cls, key) if hasattr(cls, key) else None, 'description': desc}
        return desc_dict
    
    @classmethod
    def from_dict(cls, dict_config: dict, ) -> 'BaseConfig':
        """ 
        从字典中, 更新配置参数, 并返回新的配置参数类
        配置参数要求: 1. 配置参数必须有类型注解, 2. 配置参数必须有默认值, 3. 配置参数必须有描述
        :param dict_config: 配置参数字典
        :return: 新的配置参数类
        """
        # cls_name = cls.__qualname__.split('.')[0]
        cls_name = cls.__qualname__
        # 从 __qualname__ 解析出外部类名（如 'UNet3D_Simple.cfg' -> 'UNet3D_Simple'）
        for key, value in dict_config.items():
            try: annotations = cls.__annotations__[key]
            except KeyError: raise KeyError(f"配置参数时, {cls_name}的 '{key}' 参数不存在, 请重新配置参数")
            # assert (value is not None) or annotations is None, f"配置参数时, {cls_name}的 '{key}' 参数值不能为空, 请重新配置参数"
            origin_type = typing.get_origin(annotations)
            except_type = annotations if origin_type is None else origin_type
            if except_type == typing.Annotated: # 处理注解类型
                annotations, *desc = typing.get_args(annotations)
                origin_type = typing.get_origin(annotations)
                except_type = annotations if origin_type is None else origin_type

            if except_type == type(int | str): # 处理联合类型
                union_types = typing.get_args(annotations)
                if type(value) not in union_types:
                    assert False, f"配置参数时, {cls_name}的 '{key}' 参数类型不匹配, 期望参数类型: {union_types}, 实际参数类型: {type(value)}, 请重新配置参数"
                except_type = type(value)
            except_type = type(None) if except_type is None else except_type
            assert except_type != callable, f"配置参数时, {cls_name}的 '{key}' 参数类型应为{type(callable)}, 实际参数类型: {type(value)}, 请重新配置参数"
            assert isinstance(value, except_type), f"配置参数时, {cls_name}的 '{key}' 参数类型不匹配, 期望参数类型: {except_type}, 实际参数类型: {type(value)}, 请重新配置参数"
            setattr(cls, key, value)
        return cls()



# from typing import Annotated
# class test_config(BaseConfig):
#     kk : int = None
#     ggg: callable = lambda x: x
#     grid_wells_folder: Annotated[str, '稀疏点数据体文件夹路径'] = 'None'   # 稀疏点数据体文件夹路径
#     prop_mean_input2: Annotated[list[float]| None, '输入属性均值'] = None
#     prop_mean_input3: Annotated[list[float]| int, '输入属性均值'] = 1


#     gg: None = None
#     # gg1: int = None
#     gg2: None| int = None
#     # 网格数据体参数
#     grid_model_folder: Annotated[str| None, '网格数据体文件夹路径'] = ''   # 网格数据体文件夹路径
#     model_keys: Annotated[list[str], '包含属性体'] = []   # 包含属性体
#     gm_skiprows: Annotated[int, '网格数据体文件跳过行数'] = 0   # 网格数据体文件跳过行数
#     gm_skipInVal: Annotated[str, '网格数据体文件跳过值'] = '-999.2500'
#     gm_dimens: Annotated[list | tuple, '网格数据体维度'] = []   # 网格数据体维度
#     gm_compressed: Annotated[bool, '网格数据体是否压缩'] = True   # 网格数据体是否压缩
#     gm_inputSize: Annotated[list | tuple, '网格数据体输入窗口大小'] = [128, 128, 128]   # 网格数据体输入窗口大小
#     gm_stride: Annotated[int, '网格数据体滑动步长'] = 32   # 网格数据体滑动步长
#     gm_grid_size_for_hash: Annotated[int, '网格数据体空间哈希网格大小'] = 64   # 网格数据体空间哈希网格大小

#     # 稀疏点数据体参数
#     # grid_wells_folder: Annotated[str, '稀疏点数据体文件夹路径'] = ''   # 稀疏点数据体文件夹路径
#     sparse_ijk: Annotated[list[str], '稀疏点数据体坐标列名'] = ['i', 'j', 'k']   # 稀疏点数据体坐标列名 ['i', 'j', 'k']
#     sparse_keys: Annotated[list[str], '稀疏点数据体属性列名'] = []   # 稀疏点数据体属性列名 ['v1', 'v2', ...], 索引值从1,1,1开始的
#     gw_skiprows: Annotated[int, '稀疏点数据体跳过行数'] = 0   # 稀疏点数据体跳过行数
#     gw_skipInvVal: Annotated[str, '稀疏点数据体跳过值'] = '-999.2500'

#     # 训练参数
#     batch_size: Annotated[int, '批次大小'] = 32   # 批次大小
#     num_workers: Annotated[int, '工作线程数'] = 0   # 工作线程数
#     train_val_split: Annotated[tuple[float, float], '训练集、验证集比例'] = (0.8, 0.2)   # 训练集、验证集比例

#     # 标准化参数
#     prop_mean_input: Annotated[list[float]| None, '输入属性均值'] = None
#     prop_std_input: Annotated[list[float]| None, '输入属性标准差'] = None
#     prop_mean_label: Annotated[list[float]| None, '输出属性均值'] = None
#     prop_std_label: Annotated[list[float]| None, '输出属性标准差'] = None  
#     a: int = 1
#     b: str = '2'
#     c: float = 3.0
#     d: bool = True
#     e: list[int] = [1, 2, 3]
#     f: tuple[int, str, float] = (1, '2', 3.0)
#     g: dict[str, int] = {'a': 1, 'b': 2, 'c': 3}
#     h: set[int] = {1, 2, 3}
#     i: range| str = range(1, 10)
# CVDFile.SetVDPath()
# # print(type(None) != type(None), typing.get_origin(None))
# a = test_config.from_dict(test_config().to_dict())
# c = a.to_dict()
# d = a.to_desc()
# print(d)
# a.Update2VDFile('test_config')
# b = test_config.GetObjByName('test_config')
# b.to_dict()
