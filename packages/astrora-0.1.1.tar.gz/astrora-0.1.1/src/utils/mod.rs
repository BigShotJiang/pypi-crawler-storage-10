//! Utility functions and helpers

// Placeholder for future implementation
// Will include:
// - Unit conversions
// - Numerical utilities
// - Error types
