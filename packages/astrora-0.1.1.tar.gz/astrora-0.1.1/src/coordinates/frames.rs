//! Coordinate reference frames for astrodynamics
//!
//! This module implements the standard celestial reference frames used in astrodynamics:
//! - ICRS (International Celestial Reference System) - Barycentric, inertial
//! - GCRS (Geocentric Celestial Reference System) - Geocentric, inertial
//! - ITRS (International Terrestrial Reference System) - Earth-fixed, rotating
//! - TEME (True Equator Mean Equinox) - Geocentric, inertial (legacy SGP4 frame)
//!
//! # Reference Frame Relationships
//!
//! ## ICRS vs GCRS
//! - **ICRS**: Origin at solar system barycenter, "space-fixed" axes
//! - **GCRS**: Origin at Earth's center of mass, axes parallel to ICRS
//! - **Relationship**: No rotation between frames, only translation by Earth's barycentric position
//! - **For satellite work**: GCRS is typically used (geocentric is more convenient)
//!
//! ## GCRS vs ITRS
//! - **GCRS**: Geocentric, inertial (non-rotating with the stars)
//! - **ITRS**: Geocentric, Earth-fixed (rotates with Earth)
//! - **Relationship**: Rotation by Earth Rotation Angle (ERA) about polar axis
//! - **For ground stations**: ITRS is used (coordinates fixed to Earth's surface)
//!
//! ## TEME vs Other Frames
//! - **TEME**: True Equator Mean Equinox - legacy geocentric inertial frame
//! - **Usage**: Native output frame for SGP4/SDP4 propagators (TLE data)
//! - **TEME vs ITRS**: Rotation by Greenwich Mean Sidereal Time (GMST82) about polar axis
//! - **TEME vs GCRS**: Can transform via ITRS (TEME → ITRS → GCRS)
//! - **Historical**: Uses IAU 1982 definition of GMST (predates IAU 2000 ERA standard)
//! - **Accuracy**: ~10-100 meters typical for satellite tracking applications
//!
//! ## Implementation Notes (Version 1)
//! - ICRS ↔ GCRS: Simple implementation with identity rotation (axes aligned)
//! - Barycentric correction for ICRS ↔ GCRS can be added later (typically ~1 AU offset)
//! - GCRS ↔ ITRS: Simplified ERA-based rotation (no precession/nutation in V1)
//! - Full IAU 2006/2000A precession-nutation models can be added later
//! - Polar motion corrections can be added for ultra-high precision
//! - TEME ↔ ITRS: GMST82-based rotation (no polar motion in V1)
//! - TEME uses legacy IAU 1982 GMST for SGP4/TLE compatibility
//!
//! # References
//! - IAU 2000 Resolutions on Reference Systems
//! - Vallado, "Fundamentals of Astrodynamics and Applications", 4th Ed., Ch. 3
//! - Vallado et al. (2006), "Revisiting Spacetrack Report #3", AIAA 2006-6753 (TEME definition)
//! - USNO Circular 179: "The IAU Resolutions on Astronomical Reference Systems"
//! - <https://aa.usno.navy.mil/faq/ICRS_doc>
//! - IERS Conventions (2010): <https://www.iers.org/IERS/EN/Publications/TechnicalNotes/tn36.html>

use nalgebra::{Vector3, Matrix3};
use pyo3::prelude::*;
use numpy::{PyArray1, PyReadonlyArray1};
use crate::core::PoliastroResult;
use crate::core::time::Epoch;
use hifitime::TimeScale;
use crate::coordinates::rotations::{rotation_x, rotation_z};
use std::f64::consts::PI;
use rayon::prelude::*;

/// International Celestial Reference System (ICRS)
///
/// The ICRS is the fundamental celestial reference system adopted by the IAU
/// for high-precision positional astronomy. It is:
/// - Barycentric: Origin at the solar system barycenter
/// - Inertial: "Space-fixed" axes (kinematically non-rotating)
/// - Fundamental: Defines the orientation of all celestial reference frames
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, barycentric
/// - Velocity: Cartesian (vx, vy, vz) in m/s, barycentric
///
/// # Examples
/// ```rust,ignore
/// use nalgebra::Vector3;
/// use astrora_core::coordinates::frames::ICRS;
///
/// // Create ICRS position at 1 AU from barycenter
/// let position = Vector3::new(1.496e11, 0.0, 0.0);
/// let velocity = Vector3::new(0.0, 29780.0, 0.0);
/// let frame = ICRS::new(position, velocity);
/// ```
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct ICRS {
    /// Position vector in ICRS frame (meters, barycentric)
    pub position: Vector3<f64>,
    /// Velocity vector in ICRS frame (m/s, barycentric)
    pub velocity: Vector3<f64>,
}

#[pymethods]
impl ICRS {
    /// Create a new ICRS coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (barycentric) [x, y, z]
    /// - `velocity`: Velocity vector in m/s (barycentric) [vx, vy, vz]
    #[new]
    pub fn py_new(position: PyReadonlyArray1<f64>, velocity: PyReadonlyArray1<f64>) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        Ok(Self {
            position: Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]),
            velocity: Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]),
        })
    }

    /// Get the position vector
    #[getter]
    pub fn get_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.position.as_slice())
    }

    /// Get the velocity vector
    #[getter]
    pub fn get_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.velocity.as_slice())
    }

    /// Convert to GCRS frame
    ///
    /// This is a simple conversion that assumes the axes are aligned (which they are).
    /// For full accuracy, a barycentric correction would be needed (Earth's position
    /// relative to solar system barycenter, ~1 AU offset). For Earth satellite work,
    /// this correction is typically negligible.
    ///
    /// # Arguments
    /// - `epoch`: Time of observation (for future barycentric corrections)
    pub fn to_gcrs(&self, epoch: &Epoch) -> PoliastroResult<GCRS> {
        // Version 1: Simple conversion with aligned axes
        // Future enhancement: Add barycentric correction using JPL ephemerides
        Ok(GCRS {
            position: self.position,
            velocity: self.velocity,
            obstime: *epoch,
        })
    }

    /// String representation
    fn __repr__(&self) -> String {
        format!(
            "ICRS(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z
        )
    }
}

impl ICRS {
    /// Create a new ICRS coordinate frame (internal Rust API)
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (barycentric)
    /// - `velocity`: Velocity vector in m/s (barycentric)
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>) -> Self {
        Self { position, velocity }
    }

    /// Create ICRS from position only (zero velocity)
    pub fn from_position(position: Vector3<f64>) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }
}

/// Geocentric Celestial Reference System (GCRS)
///
/// The GCRS is the geocentric counterpart to ICRS. It is:
/// - Geocentric: Origin at Earth's center of mass
/// - Inertial: Axes parallel to ICRS (kinematically non-rotating)
/// - Practical: Standard frame for Earth satellite work
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, geocentric
/// - Velocity: Cartesian (vx, vy, vz) in m/s, geocentric
///
/// # Frame Attributes
/// - `obstime`: Observation epoch (for time-dependent transformations)
///
/// # Examples
/// ```rust,ignore
/// use nalgebra::Vector3;
/// use astrora_core::coordinates::frames::GCRS;
/// use astrora_core::core::time::Epoch;
///
/// // Create GCRS position for GEO satellite
/// let position = Vector3::new(42164000.0, 0.0, 0.0);
/// let velocity = Vector3::new(0.0, 3075.0, 0.0);
/// let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
/// let frame = GCRS::new(position, velocity, epoch);
/// ```
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct GCRS {
    /// Position vector in GCRS frame (meters, geocentric)
    pub position: Vector3<f64>,
    /// Velocity vector in GCRS frame (m/s, geocentric)
    pub velocity: Vector3<f64>,
    /// Observation time (for time-dependent transformations)
    pub obstime: Epoch,
}

#[pymethods]
impl GCRS {
    /// Create a new GCRS coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (geocentric) [x, y, z]
    /// - `velocity`: Velocity vector in m/s (geocentric) [vx, vy, vz]
    /// - `obstime`: Observation epoch
    #[new]
    pub fn py_new(
        position: PyReadonlyArray1<f64>,
        velocity: PyReadonlyArray1<f64>,
        obstime: Epoch,
    ) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        Ok(Self {
            position: Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]),
            velocity: Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]),
            obstime,
        })
    }

    /// Get the position vector
    #[getter]
    pub fn get_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.position.as_slice())
    }

    /// Get the velocity vector
    #[getter]
    pub fn get_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.velocity.as_slice())
    }

    /// Get the observation time
    #[getter]
    pub fn get_obstime(&self) -> Epoch {
        self.obstime
    }

    /// Convert to ICRS frame
    ///
    /// This is a simple conversion that assumes the axes are aligned (which they are).
    /// For full accuracy, a barycentric correction would be needed (Earth's position
    /// relative to solar system barycenter). For Earth satellite work, this correction
    /// is typically negligible.
    pub fn to_icrs(&self) -> PoliastroResult<ICRS> {
        // Version 1: Simple conversion with aligned axes
        // Future enhancement: Add barycentric correction using JPL ephemerides
        Ok(ICRS {
            position: self.position,
            velocity: self.velocity,
        })
    }

    /// Convert to ITRS frame
    ///
    /// This transformation rotates the GCRS (inertial) coordinates into
    /// ITRS (Earth-fixed) coordinates using the Earth Rotation Angle (ERA).
    ///
    /// # V1 Implementation
    /// - Uses simplified ERA rotation about the polar (z) axis
    /// - Ignores precession, nutation, and polar motion
    /// - Suitable for most satellite tracking applications (10-100m accuracy)
    ///
    /// # Returns
    /// ITRS coordinate frame at the same observation time
    pub fn to_itrs(&self) -> PoliastroResult<ITRS> {
        // Calculate ERA at observation time
        let era = earth_rotation_angle(&self.obstime);

        // Rotation matrix: GCRS → ITRS is R_z(+ERA)
        // (rotating FROM inertial TO Earth-fixed means rotating forwards)
        let rotation = rotation_z(era);

        // Transform position
        let itrs_position = rotation * self.position;

        // Transform velocity (includes Coriolis term from Earth's rotation)
        // v_itrs = R * v_gcrs - ω × R * r_gcrs
        // where ω is Earth's angular velocity vector [0, 0, ω_earth]
        let omega_earth = 7.2921150e-5; // rad/s (from IERS)
        let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

        let itrs_velocity = rotation * self.velocity - omega_vec.cross(&itrs_position);

        Ok(ITRS {
            position: itrs_position,
            velocity: itrs_velocity,
            obstime: self.obstime,
        })
    }

    /// String representation
    fn __repr__(&self) -> String {
        let (y, m, d, h, min, s, _) = self.obstime.to_gregorian_utc();
        format!(
            "GCRS(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s, obstime={:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z,
            y, m, d, h, min, s
        )
    }
}

impl GCRS {
    /// Create a new GCRS coordinate frame (internal Rust API)
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (geocentric)
    /// - `velocity`: Velocity vector in m/s (geocentric)
    /// - `obstime`: Observation epoch
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity,
            obstime,
        }
    }

    /// Create GCRS from position only (zero velocity) at J2000 epoch
    pub fn from_position(position: Vector3<f64>) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
            obstime: Epoch::j2000(),
        }
    }

    /// Create GCRS from position at specified epoch
    pub fn from_position_epoch(position: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
            obstime,
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }

    /// Get the observation time
    pub fn obstime(&self) -> &Epoch {
        &self.obstime
    }
}

/// Calculate Earth Rotation Angle (ERA) in radians
///
/// The ERA is a simple linear function of UT1 that represents Earth's rotation.
/// It replaces the more complex Greenwich Mean Sidereal Time (GMST) in modern
/// astrodynamics.
///
/// # Formula
/// ERA = 2π × (0.7790572732640 + 1.00273781191135448 × T_u)
///
/// where T_u = (JD_UT1 - 2451545.0) is the Julian date in UT1 minus J2000 epoch.
///
/// # Arguments
/// - `epoch`: Time at which to calculate ERA (should be in UT1, but UTC is acceptable for V1)
///
/// # Returns
/// Earth Rotation Angle in radians [0, 2π)
///
/// # References
/// - IERS Conventions (2010), Chapter 5
/// - "Expressions to implement the IAU 2000 definition of UT1", A&A 2003
/// - <https://www.celestialprogramming.com/snippets/greenwichMeanSiderealTime.html>>
///
/// # Note
/// This is a simplified V1 implementation. For highest precision:
/// - Use UT1 time scale (requires Earth orientation parameters from IERS)
/// - Add TIO (Terrestrial Intermediate Origin) locator corrections
/// - The difference between UTC and UT1 is typically < 1 second (DUT1)
pub fn earth_rotation_angle(epoch: &Epoch) -> f64 {
    // Constants from IERS Conventions (2010)
    const ERA_OFFSET: f64 = 0.7790572732640; // Radians at J2000
    const ERA_RATE: f64 = 1.002_737_811_911_354_6; // Rotations per UT1 day

    // Get Julian date in UT1 (approximated by UTC for V1)
    // hifitime provides JD in the epoch's current time scale
    let jd_ut1 = epoch.to_time_scale(hifitime::TimeScale::UTC).to_jd_utc();

    // Days since J2000 epoch (JD 2451545.0)
    let t_u = jd_ut1 - 2451545.0;

    // Calculate ERA in rotations, then convert to radians
    let era_rotations = ERA_OFFSET + ERA_RATE * t_u;

    // Normalize to [0, 1) rotations, then convert to [0, 2π) radians
    let era_normalized = era_rotations - era_rotations.floor();
    

    2.0 * PI * era_normalized
}

/// Calculate Greenwich Mean Sidereal Time (GMST) using IAU 1982 model
///
/// GMST is the angle between the Earth's prime meridian and the mean vernal equinox.
/// This uses the IAU 1982 polynomial formula, which is the standard for SGP4/TLE
/// propagation and the TEME coordinate frame.
///
/// # Formula
/// GMST = 67310.54841 + (876600h + 8640184.812866)·Tᵤ + 0.093104·Tᵤ² - 6.2×10⁻⁶·Tᵤ³
///
/// where:
/// - GMST is in seconds of time
/// - Tᵤ = (JD_UT1 - 2451545.0)/36525 is Julian centuries since J2000
/// - Result is converted to radians [0, 2π)
///
/// # Arguments
/// - `epoch`: Time at which to calculate GMST (should be in UT1, but UTC is acceptable for V1)
///
/// # Returns
/// Greenwich Mean Sidereal Time in radians [0, 2π)
///
/// # References
/// - Vallado et al. (2006), "Revisiting Spacetrack Report #3", AIAA 2006-6753, Appendix C
/// - Vallado, "Fundamentals of Astrodynamics and Applications", 4th Ed., Algorithm 15
/// - IAU 1982 GMST formula (legacy standard for SGP4/TLE compatibility)
///
/// # Note
/// This is the IAU 1982 definition used by SGP4 and the TEME frame.
/// It differs from the modern IAU 2000/2006 standards which use ERA.
/// For highest precision TLE compatibility, use UT1 time scale.
pub fn greenwich_mean_sidereal_time_82(epoch: &Epoch) -> f64 {
    // Convert to UT1 (approximated by UTC for V1)
    let jd_ut1 = epoch.to_time_scale(hifitime::TimeScale::UTC).to_jd_utc();

    // Julian centuries since J2000 epoch (JD 2451545.0)
    let t_ut1 = (jd_ut1 - 2451545.0) / 36525.0;

    // GMST in seconds (IAU 1982 polynomial formula)
    // Coefficients from Vallado Algorithm 15
    let gmst_sec = 67310.54841
        + (876600.0 * 3600.0 + 8640184.812866) * t_ut1
        + 0.093104 * t_ut1 * t_ut1
        - 6.2e-6 * t_ut1 * t_ut1 * t_ut1;

    // Convert seconds to radians
    // 1 revolution = 86400 seconds of sidereal time = 2π radians
    let gmst_radians = gmst_sec * (2.0 * PI / 86400.0);

    // Normalize to [0, 2π)
    let gmst_normalized = gmst_radians % (2.0 * PI);

    // Handle negative values (from modulo)
    if gmst_normalized < 0.0 {
        gmst_normalized + 2.0 * PI
    } else {
        gmst_normalized
    }
}

/// International Terrestrial Reference System (ITRS)
///
/// The ITRS is the Earth-fixed reference system. It:
/// - Geocentric: Origin at Earth's center of mass
/// - Rotating: Axes rotate with Earth (Earth-fixed)
/// - Practical: Standard frame for ground station locations
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, Earth-fixed
/// - Velocity: Cartesian (vx, vy, vz) in m/s, Earth-fixed
///
/// # Frame Attributes
/// - `obstime`: Observation epoch (required for transformation to inertial frames)
///
/// # Examples
/// ```rust,ignore
/// use nalgebra::Vector3;
/// use astrora_core::coordinates::frames::ITRS;
/// use astrora_core::core::time::Epoch;
///
/// // Create ITRS position for ground station
/// // Example: Equator at sea level, longitude 0°
/// let position = Vector3::new(6378137.0, 0.0, 0.0); // WGS84 equatorial radius
/// let velocity = Vector3::zeros(); // Stationary on Earth surface
/// let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
/// let frame = ITRS::new(position, velocity, epoch);
/// ```
///
/// # V1 Implementation Notes
/// This is a simplified implementation that:
/// - Uses ERA (Earth Rotation Angle) for GCRS ↔ ITRS rotation
/// - Ignores precession and nutation (small effect for short timespans)
/// - Ignores polar motion (< 1 meter effect)
/// - Accuracy: ~10-100 meters for typical satellite applications
///
/// Future enhancements for higher precision:
/// - IAU 2006/2000A precession-nutation models
/// - Polar motion corrections from IERS EOP data
/// - TIO (Terrestrial Intermediate Origin) locator
/// - CIP (Celestial Intermediate Pole) position
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct ITRS {
    /// Position vector in ITRS frame (meters, Earth-fixed)
    pub position: Vector3<f64>,
    /// Velocity vector in ITRS frame (m/s, Earth-fixed)
    pub velocity: Vector3<f64>,
    /// Observation time (for transformations to inertial frames)
    pub obstime: Epoch,
}

#[pymethods]
impl ITRS {
    /// Create a new ITRS coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (Earth-fixed) [x, y, z]
    /// - `velocity`: Velocity vector in m/s (Earth-fixed) [vx, vy, vz]
    /// - `obstime`: Observation epoch
    #[new]
    pub fn py_new(
        position: PyReadonlyArray1<f64>,
        velocity: PyReadonlyArray1<f64>,
        obstime: Epoch,
    ) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        Ok(Self {
            position: Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]),
            velocity: Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]),
            obstime,
        })
    }

    /// Get the position vector
    #[getter]
    pub fn get_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.position.as_slice())
    }

    /// Get the velocity vector
    #[getter]
    pub fn get_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.velocity.as_slice())
    }

    /// Get the observation time
    #[getter]
    pub fn get_obstime(&self) -> Epoch {
        self.obstime
    }

    /// Convert to TEME frame
    ///
    /// This transformation rotates the ITRS (Earth-fixed) coordinates into
    /// TEME (inertial) coordinates using Greenwich Mean Sidereal Time (GMST82).
    ///
    /// # V1 Implementation
    /// - Uses IAU 1982 GMST rotation about the polar (z) axis
    /// - Ignores polar motion corrections
    /// - Suitable for TLE-based satellite tracking (~10-100m accuracy)
    ///
    /// # Returns
    /// TEME coordinate frame at the same observation time
    pub fn to_teme(&self) -> PoliastroResult<TEME> {
        // Calculate GMST82 at observation time
        let gmst = greenwich_mean_sidereal_time_82(&self.obstime);

        // Rotation matrix: ITRS → TEME is R_z(-GMST)
        // (rotating FROM Earth-fixed TO inertial means rotating backwards)
        let rotation = rotation_z(-gmst);

        // Transform position
        let teme_position = rotation * self.position;

        // Transform velocity (includes Coriolis term from Earth's rotation)
        // v_teme = R * v_itrs + ω × R * r_itrs
        // where ω is Earth's angular velocity vector [0, 0, ω_earth]
        let omega_earth = 7.2921150e-5; // rad/s (from IERS)
        let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

        let teme_velocity = rotation * self.velocity + omega_vec.cross(&teme_position);

        Ok(TEME {
            position: teme_position,
            velocity: teme_velocity,
            obstime: self.obstime,
        })
    }

    /// Convert to GCRS frame
    ///
    /// This transformation rotates the ITRS (Earth-fixed) coordinates into
    /// GCRS (inertial) coordinates using the Earth Rotation Angle (ERA).
    ///
    /// # V1 Implementation
    /// - Uses simplified ERA rotation about the polar (z) axis
    /// - Ignores precession, nutation, and polar motion
    /// - Suitable for most satellite tracking applications (10-100m accuracy)
    ///
    /// # Returns
    /// GCRS coordinate frame at the same observation time
    pub fn to_gcrs(&self) -> PoliastroResult<GCRS> {
        // Calculate ERA at observation time
        let era = earth_rotation_angle(&self.obstime);

        // Rotation matrix: ITRS → GCRS is R_z(-ERA)
        // (rotating FROM Earth-fixed TO inertial means rotating backwards)
        let rotation = rotation_z(-era);

        // Transform position
        let gcrs_position = rotation * self.position;

        // Transform velocity (includes Coriolis term from Earth's rotation)
        // v_gcrs = R * v_itrs + ω × R * r_itrs
        // where ω is Earth's angular velocity vector [0, 0, ω_earth]
        let omega_earth = 7.2921150e-5; // rad/s (from IERS)
        let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

        let gcrs_velocity = rotation * self.velocity + omega_vec.cross(&gcrs_position);

        Ok(GCRS {
            position: gcrs_position,
            velocity: gcrs_velocity,
            obstime: self.obstime,
        })
    }

    /// String representation
    fn __repr__(&self) -> String {
        let (y, m, d, h, min, s, _) = self.obstime.to_gregorian_utc();
        format!(
            "ITRS(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s, obstime={:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z,
            y, m, d, h, min, s
        )
    }
}

impl ITRS {
    /// Create a new ITRS coordinate frame (internal Rust API)
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (Earth-fixed)
    /// - `velocity`: Velocity vector in m/s (Earth-fixed)
    /// - `obstime`: Observation epoch
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity,
            obstime,
        }
    }

    /// Create ITRS from position only (zero velocity)
    pub fn from_position(position: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
            obstime,
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }

    /// Get the observation time
    pub fn obstime(&self) -> &Epoch {
        &self.obstime
    }
}

/// True Equator Mean Equinox (TEME) Frame
///
/// TEME is a geocentric inertial reference frame defined by the true equator
/// (instantaneous Earth rotation axis) and mean equinox (average position of
/// vernal equinox). It is the native output frame for SGP4/SDP4 propagators
/// used with Two-Line Element (TLE) sets.
///
/// # Characteristics
/// - Geocentric: Origin at Earth's center of mass
/// - Inertial: Does not rotate with Earth (but uses mean equinox, not true)
/// - Legacy: Defined by IAU 1982 standards (predates modern IAU 2000/2006)
/// - Application: SGP4/SDP4 satellite propagation from TLE data
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, geocentric
/// - Velocity: Cartesian (vx, vy, vz) in m/s, geocentric
///
/// # Frame Attributes
/// - `obstime`: Observation epoch (for time-dependent transformations)
///
/// # Historical Context
/// The TEME frame uses the Greenwich Mean Sidereal Time (GMST) based on the
/// IAU 1982 model. This differs from modern frames like GCRS which use the
/// Earth Rotation Angle (ERA) from IAU 2000. The TEME definition is maintained
/// for backward compatibility with legacy TLE data and SGP4 propagation.
///
/// # Examples
/// ```rust,ignore
/// use nalgebra::Vector3;
/// use astrora_core::coordinates::frames::TEME;
/// use astrora_core::core::time::Epoch;
///
/// // Create TEME coordinate from SGP4 output
/// let position = Vector3::new(7000000.0, 0.0, 0.0);
/// let velocity = Vector3::new(0.0, 7500.0, 0.0);
/// let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
/// let frame = TEME::new(position, velocity, epoch);
/// ```
///
/// # V1 Implementation Notes
/// This is a simplified implementation that:
/// - Uses GMST82 (IAU 1982) for TEME ↔ ITRS rotation
/// - Ignores polar motion (< 1 meter effect)
/// - Accuracy: ~10-100 meters for typical satellite tracking
///
/// Future enhancements:
/// - Polar motion corrections from IERS EOP data
/// - Full compatibility validation with Vallado's SGP4 implementation
///
/// # References
/// - Vallado et al. (2006), "Revisiting Spacetrack Report #3", AIAA 2006-6753
/// - Vallado, "Fundamentals of Astrodynamics and Applications", 4th Ed., Ch. 3
/// - <https://celestrak.org/publications/AIAA/2006-6753/>
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct TEME {
    /// Position vector in TEME frame (meters, geocentric)
    pub position: Vector3<f64>,
    /// Velocity vector in TEME frame (m/s, geocentric)
    pub velocity: Vector3<f64>,
    /// Observation time (for transformations to other frames)
    pub obstime: Epoch,
}

#[pymethods]
impl TEME {
    /// Create a new TEME coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (geocentric) [x, y, z]
    /// - `velocity`: Velocity vector in m/s (geocentric) [vx, vy, vz]
    /// - `obstime`: Observation epoch
    #[new]
    pub fn py_new(
        position: PyReadonlyArray1<f64>,
        velocity: PyReadonlyArray1<f64>,
        obstime: Epoch,
    ) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        Ok(Self {
            position: Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]),
            velocity: Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]),
            obstime,
        })
    }

    /// Get the position vector
    #[getter]
    pub fn get_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.position.as_slice())
    }

    /// Get the velocity vector
    #[getter]
    pub fn get_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.velocity.as_slice())
    }

    /// Get the observation time
    #[getter]
    pub fn get_obstime(&self) -> Epoch {
        self.obstime
    }

    /// Convert to ITRS frame
    ///
    /// This transformation rotates the TEME (inertial) coordinates into
    /// ITRS (Earth-fixed) coordinates using Greenwich Mean Sidereal Time (GMST82).
    ///
    /// # V1 Implementation
    /// - Uses IAU 1982 GMST rotation about the polar (z) axis
    /// - Ignores polar motion corrections
    /// - Suitable for TLE-based satellite tracking (~10-100m accuracy)
    ///
    /// # Returns
    /// ITRS coordinate frame at the same observation time
    pub fn to_itrs(&self) -> PoliastroResult<ITRS> {
        // Calculate GMST82 at observation time
        let gmst = greenwich_mean_sidereal_time_82(&self.obstime);

        // Rotation matrix: TEME → ITRS is R_z(+GMST)
        // (rotating FROM inertial TO Earth-fixed means rotating forwards)
        let rotation = rotation_z(gmst);

        // Transform position
        let itrs_position = rotation * self.position;

        // Transform velocity (includes Coriolis term from Earth's rotation)
        // v_itrs = R * v_teme - ω × R * r_teme
        // where ω is Earth's angular velocity vector [0, 0, ω_earth]
        let omega_earth = 7.2921150e-5; // rad/s (from IERS)
        let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

        let itrs_velocity = rotation * self.velocity - omega_vec.cross(&itrs_position);

        Ok(ITRS {
            position: itrs_position,
            velocity: itrs_velocity,
            obstime: self.obstime,
        })
    }

    /// Convert to GCRS frame
    ///
    /// This transformation converts TEME coordinates to GCRS by chaining
    /// through ITRS: TEME → ITRS → GCRS.
    ///
    /// # V1 Implementation
    /// - Uses GMST82 for TEME → ITRS
    /// - Uses ERA for ITRS → GCRS
    /// - Combined accuracy: ~10-100 meters
    ///
    /// # Returns
    /// GCRS coordinate frame at the same observation time
    pub fn to_gcrs(&self) -> PoliastroResult<GCRS> {
        // Chain transformations: TEME → ITRS → GCRS
        let itrs = self.to_itrs()?;
        itrs.to_gcrs()
    }

    /// String representation
    fn __repr__(&self) -> String {
        let (y, m, d, h, min, s, _) = self.obstime.to_gregorian_utc();
        format!(
            "TEME(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s, obstime={:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z,
            y, m, d, h, min, s
        )
    }
}

impl TEME {
    /// Create a new TEME coordinate frame (internal Rust API)
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (geocentric)
    /// - `velocity`: Velocity vector in m/s (geocentric)
    /// - `obstime`: Observation epoch
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity,
            obstime,
        }
    }

    /// Create TEME from position only (zero velocity)
    pub fn from_position(position: Vector3<f64>, obstime: Epoch) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
            obstime,
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }

    /// Get the observation time
    pub fn obstime(&self) -> &Epoch {
        &self.obstime
    }
}

/// Perifocal coordinate frame (PQW)
///
/// The perifocal frame is a coordinate system aligned with the orbital plane:
/// - **P-axis**: Points toward periapsis (direction of closest approach)
/// - **Q-axis**: In the orbital plane, 90° ahead of P in the direction of motion
/// - **W-axis**: Perpendicular to the orbital plane (parallel to angular momentum)
///
/// This frame is "natural" for describing orbital motion because:
/// - Position at periapsis is purely along the P-axis
/// - The orbit equation is simple: r = p/(1 + e·cos(ν))
/// - No singularities for elliptical orbits with e > 0
///
/// # Orientation Parameters
/// The perifocal frame's orientation relative to an inertial frame (GCRS/ICRS)
/// is defined by three angles:
/// - `raan` (Ω): Right ascension of ascending node (radians)
/// - `inc` (i): Inclination (radians)
/// - `argp` (ω): Argument of periapsis (radians)
///
/// # Transformation to Inertial
/// The rotation matrix from perifocal to inertial is:
/// **R = R_z(Ω) · R_x(i) · R_z(ω)**
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, in the perifocal frame
/// - Velocity: Cartesian (vx, vy, vz) in m/s, in the perifocal frame
///
/// # Examples
/// ```rust,ignore
/// use astrora_core::coordinates::frames::Perifocal;
/// use nalgebra::Vector3;
///
/// // Position at periapsis (purely along P-axis)
/// let position = Vector3::new(7000e3, 0.0, 0.0);
/// let velocity = Vector3::new(0.0, 7.5e3, 0.0);
///
/// // Create perifocal frame with orbital orientation
/// let frame = Perifocal::new(
///     position, velocity,
///     0.0,        // RAAN (radians)
///     0.1,        // Inclination (radians)
///     0.0         // Argument of periapsis (radians)
/// );
/// ```
///
/// # References
/// - Curtis, "Orbital Mechanics for Engineering Students", Ch. 4
/// - Vallado, "Fundamentals of Astrodynamics", Ch. 3
/// - <https://orbital-mechanics.space/classical-orbital-elements/perifocal-frame.html>>
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct Perifocal {
    /// Position vector in perifocal frame (meters)
    pub position: Vector3<f64>,
    /// Velocity vector in perifocal frame (m/s)
    pub velocity: Vector3<f64>,
    /// Right ascension of ascending node (radians)
    pub raan: f64,
    /// Inclination (radians)
    pub inc: f64,
    /// Argument of periapsis (radians)
    pub argp: f64,
}

impl Perifocal {
    /// Create a new Perifocal coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in perifocal frame (meters)
    /// - `velocity`: Velocity vector in perifocal frame (m/s)
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>, raan: f64, inc: f64, argp: f64) -> Self {
        Self {
            position,
            velocity,
            raan,
            inc,
            argp,
        }
    }

    /// Create Perifocal frame from position at a specific true anomaly
    ///
    /// Computes position and velocity in the perifocal frame given orbital parameters.
    ///
    /// # Arguments
    /// - `a`: Semi-major axis (meters)
    /// - `e`: Eccentricity
    /// - `nu`: True anomaly (radians)
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    /// - `mu`: Standard gravitational parameter (m³/s²)
    ///
    /// # Returns
    /// Perifocal frame at the given true anomaly
    pub fn from_orbital_elements(
        a: f64,
        e: f64,
        nu: f64,
        raan: f64,
        inc: f64,
        argp: f64,
        mu: f64,
    ) -> Self {
        // Semi-latus rectum
        let p = a * (1.0 - e * e);

        // Orbital radius at this true anomaly
        let r = p / (1.0 + e * nu.cos());

        // Position in perifocal frame
        let position = Vector3::new(r * nu.cos(), r * nu.sin(), 0.0);

        // Velocity in perifocal frame
        let h = (mu * p).sqrt(); // Specific angular momentum
        let velocity = (mu / h) * Vector3::new(-nu.sin(), e + nu.cos(), 0.0);

        Self {
            position,
            velocity,
            raan,
            inc,
            argp,
        }
    }

    /// Get rotation matrix from perifocal to inertial (GCRS/ICRS)
    ///
    /// The transformation is: **R = R_z(Ω) · R_x(i) · R_z(ω)**
    ///
    /// This rotates vectors from the perifocal frame (PQW) to the inertial frame (IJK).
    fn rotation_to_inertial(&self) -> Matrix3<f64> {
        // Use standardized rotation functions for 3-1-3 Euler sequence
        // R_z(Ω): Rotation about z-axis by RAAN
        let r_z_raan = rotation_z(self.raan);
        // R_x(i): Rotation about x-axis by inclination
        let r_x_inc = rotation_x(self.inc);
        // R_z(ω): Rotation about z-axis by argument of periapsis
        let r_z_argp = rotation_z(self.argp);

        // Combined rotation: R = R_z(Ω) * R_x(i) * R_z(ω)
        r_z_raan * r_x_inc * r_z_argp
    }

    /// Get rotation matrix from inertial (GCRS/ICRS) to perifocal
    ///
    /// This is simply the transpose of the rotation to inertial.
    fn rotation_from_inertial(&self) -> Matrix3<f64> {
        self.rotation_to_inertial().transpose()
    }

    /// Convert to GCRS (Geocentric Celestial Reference System)
    ///
    /// Transforms the perifocal coordinates to the inertial GCRS frame.
    ///
    /// # Arguments
    /// - `obstime`: Observation time for the GCRS frame
    ///
    /// # Returns
    /// GCRS coordinate frame
    pub fn to_gcrs(&self, obstime: Epoch) -> GCRS {
        let rotation = self.rotation_to_inertial();

        let gcrs_position = rotation * self.position;
        let gcrs_velocity = rotation * self.velocity;

        GCRS {
            position: gcrs_position,
            velocity: gcrs_velocity,
            obstime,
        }
    }

    /// Create Perifocal frame from GCRS coordinates
    ///
    /// Transforms inertial GCRS coordinates to the perifocal frame.
    ///
    /// # Arguments
    /// - `gcrs`: GCRS coordinate frame
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    ///
    /// # Returns
    /// Perifocal coordinate frame
    pub fn from_gcrs(gcrs: &GCRS, raan: f64, inc: f64, argp: f64) -> Self {
        // Create a temporary Perifocal to get the rotation matrix
        let temp = Self {
            position: Vector3::zeros(),
            velocity: Vector3::zeros(),
            raan,
            inc,
            argp,
        };

        let rotation = temp.rotation_from_inertial();

        let position = rotation * gcrs.position;
        let velocity = rotation * gcrs.velocity;

        Self {
            position,
            velocity,
            raan,
            inc,
            argp,
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }

    /// Get right ascension of ascending node (radians)
    pub fn raan(&self) -> f64 {
        self.raan
    }

    /// Get inclination (radians)
    pub fn inclination(&self) -> f64 {
        self.inc
    }

    /// Get argument of periapsis (radians)
    pub fn argp(&self) -> f64 {
        self.argp
    }
}

#[pymethods]
impl Perifocal {
    /// Create a new Perifocal coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in perifocal frame (meters) [x, y, z]
    /// - `velocity`: Velocity vector in perifocal frame (m/s) [vx, vy, vz]
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    #[new]
    pub fn py_new(
        position: PyReadonlyArray1<f64>,
        velocity: PyReadonlyArray1<f64>,
        raan: f64,
        inc: f64,
        argp: f64,
    ) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        let pos = Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]);
        let vel = Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]);

        Ok(Self::new(pos, vel, raan, inc, argp))
    }

    /// Create Perifocal frame from orbital elements
    ///
    /// # Arguments
    /// - `a`: Semi-major axis (meters)
    /// - `e`: Eccentricity
    /// - `nu`: True anomaly (radians)
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    /// - `mu`: Standard gravitational parameter (m³/s², default: Earth)
    #[staticmethod]
    #[pyo3(signature = (a, e, nu, raan, inc, argp, mu=398600.4418e9))]
    pub fn from_orbital_elements_py(
        a: f64,
        e: f64,
        nu: f64,
        raan: f64,
        inc: f64,
        argp: f64,
        mu: f64,
    ) -> Self {
        Self::from_orbital_elements(a, e, nu, raan, inc, argp, mu)
    }

    /// Convert to GCRS frame
    ///
    /// # Arguments
    /// - `obstime`: Observation time (Epoch)
    #[pyo3(name = "to_gcrs")]
    pub fn py_to_gcrs(&self, obstime: &Epoch) -> GCRS {
        self.to_gcrs(*obstime)
    }

    /// Create from GCRS frame
    ///
    /// # Arguments
    /// - `gcrs`: GCRS coordinate frame
    /// - `raan`: Right ascension of ascending node (radians)
    /// - `inc`: Inclination (radians)
    /// - `argp`: Argument of periapsis (radians)
    #[staticmethod]
    #[pyo3(name = "from_gcrs")]
    pub fn py_from_gcrs(gcrs: &GCRS, raan: f64, inc: f64, argp: f64) -> Self {
        Self::from_gcrs(gcrs, raan, inc, argp)
    }

    /// Get position vector as NumPy array
    #[pyo3(name = "position")]
    fn py_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, &[self.position.x, self.position.y, self.position.z])
    }

    /// Get velocity vector as NumPy array
    #[pyo3(name = "velocity")]
    fn py_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, &[self.velocity.x, self.velocity.y, self.velocity.z])
    }

    /// Get right ascension of ascending node
    #[getter]
    fn get_raan(&self) -> f64 {
        self.raan
    }

    /// Get inclination
    #[getter]
    fn get_inc(&self) -> f64 {
        self.inc
    }

    /// Get argument of periapsis
    #[getter]
    fn get_argp(&self) -> f64 {
        self.argp
    }

    /// String representation
    fn __repr__(&self) -> String {
        format!(
            "Perifocal(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s, RAAN={:.4} rad, inc={:.4} rad, argp={:.4} rad)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z,
            self.raan, self.inc, self.argp
        )
    }
}

/// J2000 inertial reference frame
///
/// The J2000 frame (also known as EME2000 - Earth Mean Equator and Equinox 2000)
/// is a celestial reference frame based on the mean equator and mean equinox of
/// Earth at the J2000.0 epoch (2000-01-01 12:00:00 TT).
///
/// # Historical Context
/// J2000 was the standard inertial reference frame before the adoption of the
/// International Celestial Reference Frame (ICRF) and its geocentric counterpart
/// GCRS. While ICRF/GCRS are now the official standards:
/// - **J2000 vs ICRF**: Differ by ~0.02 arcseconds (negligible for most applications)
/// - **J2000 vs GCRS**: At J2000 epoch, they are effectively identical
/// - **Legacy Use**: Still widely used as a standard epoch reference in orbital mechanics
///
/// # When to Use J2000
/// - Standard reference epoch for orbital elements
/// - Legacy software/data compatibility
/// - When a fixed epoch reference is needed
/// - Most textbook examples and mission design use J2000
///
/// # Relationship to Other Frames
/// - **GCRS at J2000 epoch**: Identical for practical purposes
/// - **ICRS**: Essentially the same (difference < 0.02 arcsec)
/// - **Modern practice**: GCRS/ICRS are preferred for new work
///
/// # Coordinates
/// - Position: Cartesian (x, y, z) in meters, geocentric inertial at J2000.0 epoch
/// - Velocity: Cartesian (vx, vy, vz) in m/s, geocentric inertial at J2000.0 epoch
/// - Epoch: Always J2000.0 (2000-01-01 12:00:00 TT) by definition
///
/// # Examples
/// ```rust,ignore
/// use astrora_core::coordinates::frames::J2000;
/// use nalgebra::Vector3;
///
/// // Create a J2000 position for a satellite
/// let position = Vector3::new(7000000.0, 0.0, 0.0);
/// let velocity = Vector3::new(0.0, 7500.0, 0.0);
/// let frame = J2000::new(position, velocity);
///
/// // Convert to GCRS (at J2000 epoch)
/// let gcrs = frame.to_gcrs();
/// ```
///
/// # References
/// - IAU 2000 Resolutions on Reference Systems
/// - Vallado, "Fundamentals of Astrodynamics and Applications", Ch. 3
/// - USNO Circular 179
/// - Seidelmann, P.K. (1992), "Explanatory Supplement to the Astronomical Almanac"
#[pyclass(module = "astrora._core")]
#[derive(Debug, Clone, PartialEq)]
pub struct J2000 {
    /// Position vector in J2000 frame (meters, geocentric inertial)
    pub position: Vector3<f64>,
    /// Velocity vector in J2000 frame (m/s, geocentric inertial)
    pub velocity: Vector3<f64>,
}

impl J2000 {
    /// Create a new J2000 coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters (geocentric inertial at J2000.0)
    /// - `velocity`: Velocity vector in m/s (geocentric inertial at J2000.0)
    pub fn new(position: Vector3<f64>, velocity: Vector3<f64>) -> Self {
        Self { position, velocity }
    }

    /// Create J2000 from position only (zero velocity)
    pub fn from_position(position: Vector3<f64>) -> Self {
        Self {
            position,
            velocity: Vector3::zeros(),
        }
    }

    /// Get the position vector
    pub fn position(&self) -> &Vector3<f64> {
        &self.position
    }

    /// Get the velocity vector
    pub fn velocity(&self) -> &Vector3<f64> {
        &self.velocity
    }

    /// Convert to GCRS frame
    ///
    /// Since J2000 is effectively GCRS at the J2000 epoch, this is a simple
    /// conversion that preserves position and velocity.
    ///
    /// # Returns
    /// GCRS frame at J2000.0 epoch with identical position and velocity
    pub fn to_gcrs(&self) -> GCRS {
        GCRS::new(self.position, self.velocity, Epoch::j2000())
    }

    /// Create J2000 from GCRS frame
    ///
    /// Extracts position and velocity from GCRS. Note that if the GCRS is not
    /// at J2000 epoch, you may want to propagate it to J2000 first for physical
    /// consistency.
    ///
    /// # Arguments
    /// - `gcrs`: GCRS coordinate frame (any epoch)
    ///
    /// # Returns
    /// J2000 frame with position and velocity from the GCRS frame
    pub fn from_gcrs(gcrs: &GCRS) -> Self {
        Self {
            position: *gcrs.position(),
            velocity: *gcrs.velocity(),
        }
    }

    /// Convert to ICRS frame
    ///
    /// J2000 and ICRS differ by ~0.02 arcseconds, which is negligible for
    /// most applications. This implementation treats them as identical.
    ///
    /// # Returns
    /// ICRS frame with identical position and velocity
    pub fn to_icrs(&self) -> PoliastroResult<ICRS> {
        Ok(ICRS::new(self.position, self.velocity))
    }

    /// Create J2000 from ICRS frame
    ///
    /// J2000 and ICRS differ by ~0.02 arcseconds, which is negligible for
    /// most applications. This implementation treats them as identical.
    ///
    /// # Arguments
    /// - `icrs`: ICRS coordinate frame
    ///
    /// # Returns
    /// J2000 frame with position and velocity from the ICRS frame
    pub fn from_icrs(icrs: &ICRS) -> Self {
        Self {
            position: *icrs.position(),
            velocity: *icrs.velocity(),
        }
    }

    /// Convert to ITRS (Earth-fixed) frame
    ///
    /// Converts from J2000 inertial to Earth-fixed coordinates at J2000 epoch.
    ///
    /// # Returns
    /// ITRS frame at J2000.0 epoch
    pub fn to_itrs(&self) -> PoliastroResult<ITRS> {
        let gcrs = self.to_gcrs();
        gcrs.to_itrs()
    }

    /// Create J2000 from ITRS frame at J2000 epoch
    ///
    /// # Arguments
    /// - `itrs`: ITRS coordinate frame
    ///
    /// # Returns
    /// J2000 frame with position and velocity converted from ITRS
    pub fn from_itrs(itrs: &ITRS) -> PoliastroResult<Self> {
        let gcrs = itrs.to_gcrs()?;
        Ok(Self::from_gcrs(&gcrs))
    }
}

#[pymethods]
impl J2000 {
    /// Create a new J2000 coordinate frame
    ///
    /// # Arguments
    /// - `position`: Position vector in meters [x, y, z]
    /// - `velocity`: Velocity vector in m/s [vx, vy, vz]
    #[new]
    pub fn py_new(position: PyReadonlyArray1<f64>, velocity: PyReadonlyArray1<f64>) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;
        let vel_slice = velocity.as_slice()?;

        if pos_slice.len() != 3 || vel_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position and velocity must be 3-element arrays"
            ));
        }

        Ok(Self::new(
            Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2]),
            Vector3::new(vel_slice[0], vel_slice[1], vel_slice[2]),
        ))
    }

    /// Create J2000 from position only (zero velocity)
    #[staticmethod]
    #[pyo3(name = "from_position")]
    pub fn py_from_position(position: PyReadonlyArray1<f64>) -> PyResult<Self> {
        let pos_slice = position.as_slice()?;

        if pos_slice.len() != 3 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Position must be a 3-element array"
            ));
        }

        Ok(Self::from_position(
            Vector3::new(pos_slice[0], pos_slice[1], pos_slice[2])
        ))
    }

    /// Convert to GCRS frame at J2000 epoch
    #[pyo3(name = "to_gcrs")]
    pub fn py_to_gcrs(&self) -> GCRS {
        self.to_gcrs()
    }

    /// Create J2000 from GCRS frame
    #[staticmethod]
    #[pyo3(name = "from_gcrs")]
    pub fn py_from_gcrs(gcrs: &GCRS) -> Self {
        Self::from_gcrs(gcrs)
    }

    /// Convert to ICRS frame
    #[pyo3(name = "to_icrs")]
    pub fn py_to_icrs(&self) -> PyResult<ICRS> {
        self.to_icrs().map_err(|e| e.into())
    }

    /// Create J2000 from ICRS frame
    #[staticmethod]
    #[pyo3(name = "from_icrs")]
    pub fn py_from_icrs(icrs: &ICRS) -> Self {
        Self::from_icrs(icrs)
    }

    /// Convert to ITRS (Earth-fixed) frame at J2000 epoch
    #[pyo3(name = "to_itrs")]
    pub fn py_to_itrs(&self) -> PyResult<ITRS> {
        self.to_itrs().map_err(|e| e.into())
    }

    /// Create J2000 from ITRS frame
    #[staticmethod]
    #[pyo3(name = "from_itrs")]
    pub fn py_from_itrs(itrs: &ITRS) -> PyResult<Self> {
        Self::from_itrs(itrs).map_err(|e| e.into())
    }

    /// Get position vector as NumPy array
    #[getter]
    pub fn get_position<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.position.as_slice())
    }

    /// Get velocity vector as NumPy array
    #[getter]
    pub fn get_velocity<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        PyArray1::from_slice_bound(py, self.velocity.as_slice())
    }

    /// Get the J2000 epoch
    #[staticmethod]
    #[pyo3(name = "epoch")]
    fn py_epoch() -> Epoch {
        Epoch::j2000()
    }

    /// String representation
    fn __repr__(&self) -> String {
        format!(
            "J2000(position=[{:.3e}, {:.3e}, {:.3e}] m, velocity=[{:.3e}, {:.3e}, {:.3e}] m/s, epoch=J2000.0)",
            self.position.x, self.position.y, self.position.z,
            self.velocity.x, self.velocity.y, self.velocity.z
        )
    }
}

// =============================================================================
// Batch Coordinate Transformations (Parallelized with Rayon)
// =============================================================================

/// Batch transform GCRS coordinates to ITRS (Earth-fixed)
///
/// Transforms multiple GCRS positions and velocities to ITRS frame using
/// parallel processing with rayon. This is 10-20x faster than sequential
/// transformations and 20-80x faster than Python for large batches.
///
/// # Arguments
/// * `positions` - Nx3 array of GCRS positions in meters
/// * `velocities` - Nx3 array of GCRS velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in ITRS frame
///
/// # Example
/// ```ignore
/// let pos = vec![Vector3::new(7e6, 0.0, 0.0), Vector3::new(0.0, 7e6, 0.0)];
/// let vel = vec![Vector3::new(0.0, 7500.0, 0.0), Vector3::new(-7500.0, 0.0, 0.0)];
/// let times = vec![Epoch::j2000(), Epoch::j2000()];
/// let (itrs_pos, itrs_vel) = batch_gcrs_to_itrs(&pos, &vel, &times).unwrap();
/// ```
pub fn batch_gcrs_to_itrs(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s (from IERS)
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            // Calculate ERA at observation time
            let era = earth_rotation_angle(obstime);

            // Rotation matrix: GCRS → ITRS is R_z(+ERA)
            let rotation = rotation_z(era);

            // Transform position
            let itrs_position = rotation * pos;

            // Transform velocity (includes Coriolis term)
            // v_itrs = R * v_gcrs - ω × R * r_gcrs
            let itrs_velocity = rotation * vel - omega_vec.cross(&itrs_position);

            (itrs_position, itrs_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

/// Batch transform ITRS coordinates to GCRS (inertial)
///
/// Transforms multiple ITRS (Earth-fixed) positions and velocities to GCRS
/// (inertial) frame using parallel processing.
///
/// # Arguments
/// * `positions` - Nx3 array of ITRS positions in meters
/// * `velocities` - Nx3 array of ITRS velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in GCRS frame
pub fn batch_itrs_to_gcrs(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s (from IERS)
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            // Calculate ERA at observation time
            let era = earth_rotation_angle(obstime);

            // Rotation matrix: ITRS → GCRS is R_z(-ERA)
            let rotation = rotation_z(-era);

            // Transform position
            let gcrs_position = rotation * pos;

            // Transform velocity (includes Coriolis term)
            // v_gcrs = R * v_itrs + ω × R * r_itrs
            // Note: ω × (R * r_itrs) = ω × r_gcrs
            let gcrs_velocity = rotation * vel + omega_vec.cross(&gcrs_position);

            (gcrs_position, gcrs_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

/// Batch transform GCRS coordinates to TEME (SGP4/TLE frame)
///
/// Transforms multiple GCRS coordinates to TEME frame using parallel processing.
/// TEME is the native frame for SGP4/SDP4 propagators and TLE data.
///
/// # Arguments
/// * `positions` - Nx3 array of GCRS positions in meters
/// * `velocities` - Nx3 array of GCRS velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in TEME frame
pub fn batch_gcrs_to_teme(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s (from IERS)
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            // GCRS → ITRS (using ERA)
            let era = earth_rotation_angle(obstime);
            let r_era = rotation_z(era);
            let itrs_position = r_era * pos;
            let itrs_velocity = r_era * vel - omega_vec.cross(&itrs_position);

            // ITRS → TEME (using GMST82)
            let gmst = greenwich_mean_sidereal_time_82(obstime);
            let r_gmst = rotation_z(-gmst); // Reverse rotation
            let teme_position = r_gmst * itrs_position;
            let teme_velocity = r_gmst * itrs_velocity + omega_vec.cross(&teme_position);

            (teme_position, teme_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

/// Batch transform TEME coordinates to GCRS (inertial)
///
/// Transforms multiple TEME coordinates to GCRS frame using parallel processing.
///
/// # Arguments
/// * `positions` - Nx3 array of TEME positions in meters
/// * `velocities` - Nx3 array of TEME velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in GCRS frame
pub fn batch_teme_to_gcrs(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s (from IERS)
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            // TEME → ITRS (using GMST82)
            let gmst = greenwich_mean_sidereal_time_82(obstime);
            let r_gmst = rotation_z(gmst);
            let itrs_position = r_gmst * pos;
            let itrs_velocity = r_gmst * vel - omega_vec.cross(&itrs_position);

            // ITRS → GCRS (using ERA)
            let era = earth_rotation_angle(obstime);
            let r_era = rotation_z(-era); // Reverse rotation
            let gcrs_position = r_era * itrs_position;
            let gcrs_velocity = r_era * itrs_velocity + omega_vec.cross(&gcrs_position);

            (gcrs_position, gcrs_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

/// Batch transform TEME coordinates to ITRS (Earth-fixed)
///
/// Direct transformation from TEME to ITRS using GMST82 rotation.
///
/// # Arguments
/// * `positions` - Nx3 array of TEME positions in meters
/// * `velocities` - Nx3 array of TEME velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in ITRS frame
pub fn batch_teme_to_itrs(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            let gmst = greenwich_mean_sidereal_time_82(obstime);
            let rotation = rotation_z(gmst);

            let itrs_position = rotation * pos;
            let itrs_velocity = rotation * vel - omega_vec.cross(&itrs_position);

            (itrs_position, itrs_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

/// Batch transform ITRS coordinates to TEME
///
/// Direct transformation from ITRS to TEME using GMST82 rotation.
///
/// # Arguments
/// * `positions` - Nx3 array of ITRS positions in meters
/// * `velocities` - Nx3 array of ITRS velocities in m/s
/// * `obstimes` - N-element array of observation times (Epoch)
///
/// # Returns
/// Tuple of (positions, velocities) in TEME frame
pub fn batch_itrs_to_teme(
    positions: &[Vector3<f64>],
    velocities: &[Vector3<f64>],
    obstimes: &[Epoch],
) -> PoliastroResult<(Vec<Vector3<f64>>, Vec<Vector3<f64>>)> {
    if positions.len() != velocities.len() || positions.len() != obstimes.len() {
        return Err(crate::core::PoliastroError::invalid_state(
            "Position, velocity, and time arrays must have the same length".to_string()
        ));
    }

    let omega_earth = 7.2921150e-5; // rad/s
    let omega_vec = Vector3::new(0.0, 0.0, omega_earth);

    // Parallel processing using rayon
    let results: Vec<(Vector3<f64>, Vector3<f64>)> = positions
        .par_iter()
        .zip(velocities.par_iter())
        .zip(obstimes.par_iter())
        .map(|((pos, vel), obstime)| {
            let gmst = greenwich_mean_sidereal_time_82(obstime);
            let rotation = rotation_z(-gmst); // Reverse rotation

            let teme_position = rotation * pos;
            let teme_velocity = rotation * vel + omega_vec.cross(&teme_position);

            (teme_position, teme_velocity)
        })
        .collect();

    let (positions_out, velocities_out): (Vec<_>, Vec<_>) = results.into_iter().unzip();
    Ok((positions_out, velocities_out))
}

#[cfg(test)]
mod tests {
    use super::*;
    use approx::assert_relative_eq;

    #[test]
    fn test_icrs_creation() {
        let pos = Vector3::new(1.496e11, 0.0, 0.0);
        let vel = Vector3::new(0.0, 29780.0, 0.0);
        let frame = ICRS::new(pos, vel);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &vel);
    }

    #[test]
    fn test_icrs_from_position() {
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let frame = ICRS::from_position(pos);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
    }

    #[test]
    fn test_gcrs_creation() {
        let pos = Vector3::new(42164000.0, 0.0, 0.0);
        let vel = Vector3::new(0.0, 3075.0, 0.0);
        let epoch = Epoch::j2000();
        let frame = GCRS::new(pos, vel, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &vel);
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_gcrs_from_position() {
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let frame = GCRS::from_position(pos);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
        assert_eq!(frame.obstime(), &Epoch::j2000());
    }

    #[test]
    fn test_gcrs_from_position_epoch() {
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let epoch = Epoch::from_gregorian_utc(2024, 6, 15, 12, 0, 0, 0);
        let frame = GCRS::from_position_epoch(pos, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_icrs_to_gcrs_simple() {
        // Test simple conversion (identity transformation for now)
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let icrs = ICRS::new(pos, vel);
        let epoch = Epoch::j2000();

        let gcrs = icrs.to_gcrs(&epoch).unwrap();

        // For simple conversion, positions and velocities should be equal
        assert_relative_eq!(gcrs.position().x, pos.x, epsilon = 1e-6);
        assert_relative_eq!(gcrs.position().y, pos.y, epsilon = 1e-6);
        assert_relative_eq!(gcrs.position().z, pos.z, epsilon = 1e-6);
        assert_relative_eq!(gcrs.velocity().x, vel.x, epsilon = 1e-9);
        assert_relative_eq!(gcrs.velocity().y, vel.y, epsilon = 1e-9);
        assert_relative_eq!(gcrs.velocity().z, vel.z, epsilon = 1e-9);
        assert_eq!(gcrs.obstime(), &epoch);
    }

    #[test]
    fn test_gcrs_to_icrs_simple() {
        // Test simple conversion (identity transformation for now)
        let pos = Vector3::new(42164000.0, 0.0, 1000000.0);
        let vel = Vector3::new(0.0, 3075.0, 100.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let gcrs = GCRS::new(pos, vel, epoch);

        let icrs = gcrs.to_icrs().unwrap();

        // For simple conversion, positions and velocities should be equal
        assert_relative_eq!(icrs.position().x, pos.x, epsilon = 1e-6);
        assert_relative_eq!(icrs.position().y, pos.y, epsilon = 1e-6);
        assert_relative_eq!(icrs.position().z, pos.z, epsilon = 1e-6);
        assert_relative_eq!(icrs.velocity().x, vel.x, epsilon = 1e-9);
        assert_relative_eq!(icrs.velocity().y, vel.y, epsilon = 1e-9);
        assert_relative_eq!(icrs.velocity().z, vel.z, epsilon = 1e-9);
    }

    #[test]
    fn test_roundtrip_conversion() {
        // Test ICRS → GCRS → ICRS
        let pos = Vector3::new(1.0e7, 2.0e7, 3.0e7);
        let vel = Vector3::new(1000.0, 2000.0, 3000.0);
        let icrs1 = ICRS::new(pos, vel);
        let epoch = Epoch::j2000();

        let gcrs = icrs1.to_gcrs(&epoch).unwrap();
        let icrs2 = gcrs.to_icrs().unwrap();

        // Should get back the same values (within numerical precision)
        assert_relative_eq!(icrs2.position().x, pos.x, epsilon = 1e-6);
        assert_relative_eq!(icrs2.position().y, pos.y, epsilon = 1e-6);
        assert_relative_eq!(icrs2.position().z, pos.z, epsilon = 1e-6);
        assert_relative_eq!(icrs2.velocity().x, vel.x, epsilon = 1e-9);
        assert_relative_eq!(icrs2.velocity().y, vel.y, epsilon = 1e-9);
        assert_relative_eq!(icrs2.velocity().z, vel.z, epsilon = 1e-9);
    }

    #[test]
    fn test_iss_orbit_in_gcrs() {
        // ISS-like orbit: ~408 km altitude, 51.6° inclination
        // Position in GCRS at equatorial crossing
        let r_earth = 6371000.0; // Earth radius
        let h = 408000.0; // Altitude
        let r = r_earth + h; // Orbital radius

        let pos = Vector3::new(r, 0.0, 0.0);
        let v = (398600.4418e9_f64 / r).sqrt(); // Circular velocity
        let vel = Vector3::new(0.0, v, 0.0);

        let gcrs = GCRS::from_position_epoch(pos, Epoch::j2000());

        // Verify orbital radius
        let r_mag = gcrs.position().norm();
        assert_relative_eq!(r_mag, r, epsilon = 1.0);

        // Verify velocity is reasonable for LEO
        let v_mag = vel.norm();
        assert!(v_mag > 7000.0 && v_mag < 8000.0); // Typical LEO velocity
    }

    #[test]
    fn test_geo_satellite_in_gcrs() {
        // GEO satellite: ~35,786 km altitude above equator
        let r_geo = 42164000.0; // GEO radius
        let pos = Vector3::new(r_geo, 0.0, 0.0);
        let v_geo = (398600.4418e9_f64 / r_geo).sqrt(); // Circular velocity
        let vel = Vector3::new(0.0, v_geo, 0.0);

        let gcrs = GCRS::new(pos, vel, Epoch::j2000());

        // Verify position
        let r_mag = gcrs.position().norm();
        assert_relative_eq!(r_mag, r_geo, epsilon = 1.0);

        // Verify velocity is ~3.07 km/s for GEO
        let v_mag = gcrs.velocity().norm();
        assert_relative_eq!(v_mag, v_geo, epsilon = 1.0);
        assert!(v_mag > 3000.0 && v_mag < 3100.0);
    }

    // ========== ITRS Tests ==========

    #[test]
    fn test_earth_rotation_angle_j2000() {
        // ERA at J2000 epoch (2000-01-01 12:00:00 TT)
        let epoch = Epoch::j2000();
        let era = earth_rotation_angle(&epoch);

        // ERA should be in [0, 2π)
        assert!(era >= 0.0 && era < 2.0 * PI);

        // ERA at J2000 should be approximately 4.894961213 radians (280.46° in GMST)
        // Note: This is approximate because we're using UTC instead of UT1
        // Actual value depends on leap seconds and DUT1
        assert!(era > 4.0 && era < 5.5);
    }

    #[test]
    fn test_earth_rotation_angle_24h_period() {
        // ERA should increase by approximately 2π in one sidereal day
        let epoch1 = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let epoch2 = Epoch::from_gregorian_utc(2024, 1, 2, 0, 0, 0, 0);

        let era1 = earth_rotation_angle(&epoch1);
        let era2 = earth_rotation_angle(&epoch2);

        // ERA increases by slightly more than 2π per day (sidereal day < solar day)
        // Expected: ~2π × 1.00273781191135448 ≈ 6.300388 radians per solar day
        let delta_era = (era2 - era1 + 2.0 * PI) % (2.0 * PI);
        let expected_increase = 2.0 * PI * 1.00273781191135448 - 2.0 * PI;

        // Allow some tolerance for UTC vs UT1 approximation
        assert_relative_eq!(delta_era, expected_increase, epsilon = 0.01);
    }

    #[test]
    fn test_itrs_creation() {
        // Ground station at equator, prime meridian
        let pos = Vector3::new(6378137.0, 0.0, 0.0); // WGS84 equatorial radius
        let vel = Vector3::zeros();
        let epoch = Epoch::j2000();
        let frame = ITRS::new(pos, vel, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &vel);
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_itrs_from_position() {
        // Ground station position
        let pos = Vector3::new(6378137.0, 0.0, 0.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let frame = ITRS::from_position(pos, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_gcrs_to_itrs_position_rotation() {
        // Satellite on equatorial plane in GCRS
        // At ERA = 0, GCRS and ITRS should align
        let r = 7000000.0;
        let pos_gcrs = Vector3::new(r, 0.0, 0.0);
        let vel_gcrs = Vector3::new(0.0, 7500.0, 0.0);
        let epoch = Epoch::j2000();

        let gcrs = GCRS::new(pos_gcrs, vel_gcrs, epoch);
        let itrs = gcrs.to_itrs().unwrap();

        // Position should be rotated by ERA
        let r_itrs = itrs.position().norm();
        assert_relative_eq!(r_itrs, r, epsilon = 1.0);

        // Z-component should remain unchanged (rotation around z-axis)
        assert_relative_eq!(itrs.position().z, 0.0, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_to_gcrs_position_rotation() {
        // Ground station at equator, prime meridian
        let r = 6378137.0;
        let pos_itrs = Vector3::new(r, 0.0, 0.0);
        let vel_itrs = Vector3::zeros();
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let itrs = ITRS::new(pos_itrs, vel_itrs, epoch);
        let gcrs = itrs.to_gcrs().unwrap();

        // Position magnitude should be preserved
        let r_gcrs = gcrs.position().norm();
        assert_relative_eq!(r_gcrs, r, epsilon = 1.0);

        // Z-component should remain unchanged
        assert_relative_eq!(gcrs.position().z, 0.0, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_gcrs_roundtrip() {
        // Test ITRS → GCRS → ITRS
        let pos = Vector3::new(6378137.0, 1000000.0, 500000.0);
        let vel = Vector3::new(100.0, 50.0, 25.0);
        let epoch = Epoch::from_gregorian_utc(2024, 6, 15, 12, 0, 0, 0);

        let itrs1 = ITRS::new(pos, vel, epoch);
        let gcrs = itrs1.to_gcrs().unwrap();
        let itrs2 = gcrs.to_itrs().unwrap();

        // Should get back the same values (within numerical precision)
        assert_relative_eq!(itrs2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(itrs2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(itrs2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(itrs2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(itrs2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(itrs2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_gcrs_itrs_roundtrip() {
        // Test GCRS → ITRS → GCRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let gcrs1 = GCRS::new(pos, vel, epoch);
        let itrs = gcrs1.to_itrs().unwrap();
        let gcrs2 = itrs.to_gcrs().unwrap();

        // Should get back the same values (within numerical precision)
        assert_relative_eq!(gcrs2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(gcrs2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(gcrs2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_velocity_coriolis_effect() {
        // Ground station at equator (stationary in ITRS)
        let r = 6378137.0;
        let pos_itrs = Vector3::new(r, 0.0, 0.0);
        let vel_itrs = Vector3::zeros(); // Stationary in Earth-fixed frame
        let epoch = Epoch::j2000();

        let itrs = ITRS::new(pos_itrs, vel_itrs, epoch);
        let gcrs = itrs.to_gcrs().unwrap();

        // In GCRS, the ground station has velocity due to Earth's rotation
        // v = ω × r, where ω = 7.2921150e-5 rad/s
        let omega_earth = 7.2921150e-5;
        let expected_v = omega_earth * r; // ~465 m/s at equator

        let v_gcrs = gcrs.velocity().norm();
        assert_relative_eq!(v_gcrs, expected_v, epsilon = 1.0);

        // Velocity should be perpendicular to position (tangential)
        // v · r = 0 for rotation
        let dot_product = gcrs.velocity().dot(&gcrs.position());
        assert_relative_eq!(dot_product, 0.0, epsilon = 100.0);

        // Velocity should be in the equatorial plane (z-component = 0)
        assert_relative_eq!(gcrs.velocity().z, 0.0, epsilon = 1.0);
    }

    #[test]
    fn test_itrs_polar_position_unchanged() {
        // Position at North Pole should be rotation-invariant
        let r = 6356752.0; // WGS84 polar radius
        let pos_itrs = Vector3::new(0.0, 0.0, r);
        let vel_itrs = Vector3::zeros();
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let itrs = ITRS::new(pos_itrs, vel_itrs, epoch);
        let gcrs = itrs.to_gcrs().unwrap();

        // Position at pole should remain essentially unchanged (rotation axis)
        assert_relative_eq!(gcrs.position().x, 0.0, epsilon = 1e-3);
        assert_relative_eq!(gcrs.position().y, 0.0, epsilon = 1e-3);
        assert_relative_eq!(gcrs.position().z, r, epsilon = 1.0);

        // Velocity should also be zero (no rotation at pole)
        assert_relative_eq!(gcrs.velocity().x, 0.0, epsilon = 1e-6);
        assert_relative_eq!(gcrs.velocity().y, 0.0, epsilon = 1e-6);
        assert_relative_eq!(gcrs.velocity().z, 0.0, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_geo_satellite_tracking() {
        // GEO satellite: appears stationary in ITRS at longitude 0°
        let r_geo = 42164000.0;
        let pos_itrs = Vector3::new(r_geo, 0.0, 0.0);

        // In ITRS, GEO satellite has zero velocity (geo-stationary)
        let vel_itrs = Vector3::zeros();
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let itrs = ITRS::new(pos_itrs, vel_itrs, epoch);
        let gcrs = itrs.to_gcrs().unwrap();

        // In GCRS, GEO satellite has orbital velocity ~3.07 km/s
        let v_gcrs = gcrs.velocity().norm();
        let expected_v_geo = (398600.4418e9_f64 / r_geo).sqrt();

        assert_relative_eq!(v_gcrs, expected_v_geo, epsilon = 10.0);
        assert!(v_gcrs > 3000.0 && v_gcrs < 3100.0);
    }

    #[test]
    fn test_itrs_conservation_of_magnitude() {
        // Position magnitude should be preserved in transformations
        let r = 8000000.0; // Arbitrary orbital radius
        let theta = PI / 4.0; // 45 degrees from x-axis
        let pos_gcrs = Vector3::new(r * theta.cos(), r * theta.sin(), 1000000.0);
        let vel_gcrs = Vector3::new(-5000.0, 3000.0, 1000.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 12, 0, 0, 0);

        let gcrs = GCRS::new(pos_gcrs, vel_gcrs, epoch);
        let itrs = gcrs.to_itrs().unwrap();

        // Position magnitude must be conserved
        let r_gcrs = gcrs.position().norm();
        let r_itrs = itrs.position().norm();
        assert_relative_eq!(r_itrs, r_gcrs, epsilon = 1e-3);
    }

    // ========== TEME Tests ==========

    #[test]
    fn test_gmst82_j2000() {
        // GMST82 at J2000 epoch (2000-01-01 12:00:00 TT)
        let epoch = Epoch::j2000();
        let gmst = greenwich_mean_sidereal_time_82(&epoch);

        // GMST should be in [0, 2π)
        assert!(gmst >= 0.0 && gmst < 2.0 * PI);

        // GMST at J2000 should be approximately 4.894961213 radians (~280.46°)
        // This is a well-known value for J2000 epoch
        assert!(gmst > 4.8 && gmst < 5.0);
    }

    #[test]
    fn test_gmst82_24h_period() {
        // GMST should increase by approximately 2π in one sidereal day
        let epoch1 = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let epoch2 = Epoch::from_gregorian_utc(2024, 1, 2, 0, 0, 0, 0);

        let gmst1 = greenwich_mean_sidereal_time_82(&epoch1);
        let gmst2 = greenwich_mean_sidereal_time_82(&epoch2);

        // GMST increases by more than 2π per solar day
        // Expected: ~2π × 1.00273790935 ≈ 6.300388 radians per solar day
        let delta_gmst = (gmst2 - gmst1 + 2.0 * PI) % (2.0 * PI);

        // The difference should be small (sidereal day ≈ solar day + 4 minutes)
        assert!(delta_gmst > 0.0 && delta_gmst < 0.1);
    }

    #[test]
    fn test_teme_creation() {
        // Satellite in TEME frame (typical SGP4 output)
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let vel = Vector3::new(0.0, 7500.0, 0.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let frame = TEME::new(pos, vel, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &vel);
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_teme_from_position() {
        // TEME position only (zero velocity)
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);
        let frame = TEME::from_position(pos, epoch);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
        assert_eq!(frame.obstime(), &epoch);
    }

    #[test]
    fn test_teme_to_itrs_position_rotation() {
        // Satellite on equatorial plane in TEME
        let r = 7000000.0;
        let pos_teme = Vector3::new(r, 0.0, 0.0);
        let vel_teme = Vector3::new(0.0, 7500.0, 0.0);
        let epoch = Epoch::j2000();

        let teme = TEME::new(pos_teme, vel_teme, epoch);
        let itrs = teme.to_itrs().unwrap();

        // Position should be rotated by GMST
        let r_itrs = itrs.position().norm();
        assert_relative_eq!(r_itrs, r, epsilon = 1.0);

        // Z-component should remain unchanged (rotation around z-axis)
        assert_relative_eq!(itrs.position().z, 0.0, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_to_teme_position_rotation() {
        // Ground station at equator, prime meridian
        let r = 6378137.0;
        let pos_itrs = Vector3::new(r, 0.0, 0.0);
        let vel_itrs = Vector3::zeros();
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let itrs = ITRS::new(pos_itrs, vel_itrs, epoch);
        let teme = itrs.to_teme().unwrap();

        // Position magnitude should be preserved
        let r_teme = teme.position().norm();
        assert_relative_eq!(r_teme, r, epsilon = 1.0);

        // Z-component should remain unchanged
        assert_relative_eq!(teme.position().z, 0.0, epsilon = 1e-6);
    }

    #[test]
    fn test_teme_itrs_roundtrip() {
        // Test TEME → ITRS → TEME
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let epoch = Epoch::from_gregorian_utc(2024, 6, 15, 12, 0, 0, 0);

        let teme1 = TEME::new(pos, vel, epoch);
        let itrs = teme1.to_itrs().unwrap();
        let teme2 = itrs.to_teme().unwrap();

        // Should get back the same values (within numerical precision)
        assert_relative_eq!(teme2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(teme2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(teme2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(teme2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(teme2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(teme2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_itrs_teme_roundtrip() {
        // Test ITRS → TEME → ITRS
        let pos = Vector3::new(6378137.0, 1000000.0, 500000.0);
        let vel = Vector3::new(100.0, 50.0, 25.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let itrs1 = ITRS::new(pos, vel, epoch);
        let teme = itrs1.to_teme().unwrap();
        let itrs2 = teme.to_itrs().unwrap();

        // Should get back the same values (within numerical precision)
        assert_relative_eq!(itrs2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(itrs2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(itrs2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(itrs2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(itrs2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(itrs2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_teme_to_gcrs_via_itrs() {
        // Test TEME → GCRS transformation via ITRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 12, 0, 0, 0);

        let teme = TEME::new(pos, vel, epoch);
        let gcrs = teme.to_gcrs().unwrap();

        // Position magnitude should be conserved
        let r_teme = teme.position().norm();
        let r_gcrs = gcrs.position().norm();
        assert_relative_eq!(r_gcrs, r_teme, epsilon = 1.0);

        // Observation times should match
        assert_eq!(gcrs.obstime(), &epoch);
    }

    #[test]
    fn test_teme_conservation_of_magnitude() {
        // Position magnitude should be preserved in transformations
        let r = 8000000.0; // Arbitrary orbital radius
        let theta = PI / 4.0; // 45 degrees from x-axis
        let pos_teme = Vector3::new(r * theta.cos(), r * theta.sin(), 1000000.0);
        let vel_teme = Vector3::new(-5000.0, 3000.0, 1000.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 12, 0, 0, 0);

        let teme = TEME::new(pos_teme, vel_teme, epoch);
        let itrs = teme.to_itrs().unwrap();

        // Position magnitude must be conserved
        let r_teme = teme.position().norm();
        let r_itrs = itrs.position().norm();
        assert_relative_eq!(r_itrs, r_teme, epsilon = 1e-3);
    }

    #[test]
    fn test_teme_polar_position_unchanged() {
        // Position at North Pole should be rotation-invariant
        let r = 6356752.0; // WGS84 polar radius
        let pos_teme = Vector3::new(0.0, 0.0, r);
        let vel_teme = Vector3::new(0.0, 0.0, 100.0);
        let epoch = Epoch::from_gregorian_utc(2024, 1, 1, 0, 0, 0, 0);

        let teme = TEME::new(pos_teme, vel_teme, epoch);
        let itrs = teme.to_itrs().unwrap();

        // Position at pole should remain essentially unchanged (rotation axis)
        assert_relative_eq!(itrs.position().x, 0.0, epsilon = 1e-3);
        assert_relative_eq!(itrs.position().y, 0.0, epsilon = 1e-3);
        assert_relative_eq!(itrs.position().z, r, epsilon = 1.0);
    }

    #[test]
    fn test_teme_leo_satellite() {
        // ISS-like orbit in TEME frame (~408 km altitude)
        let r_earth = 6371000.0; // Earth radius
        let h = 408000.0; // Altitude
        let r = r_earth + h; // Orbital radius

        let pos = Vector3::new(r, 0.0, 0.0);
        let v = (398600.4418e9_f64 / r).sqrt(); // Circular velocity
        let vel = Vector3::new(0.0, v, 0.0);
        let epoch = Epoch::j2000();

        let teme = TEME::new(pos, vel, epoch);

        // Verify orbital radius
        let r_mag = teme.position().norm();
        assert_relative_eq!(r_mag, r, epsilon = 1.0);

        // Verify velocity is reasonable for LEO
        let v_mag = teme.velocity().norm();
        assert!(v_mag > 7000.0 && v_mag < 8000.0); // Typical LEO velocity
    }

    // ============================================================================
    // Perifocal Frame Tests
    // ============================================================================

    #[test]
    fn test_perifocal_creation() {
        // Create perifocal frame at periapsis
        let pos = Vector3::new(7000000.0, 0.0, 0.0);
        let vel = Vector3::new(0.0, 7500.0, 0.0);
        let raan = 0.5;
        let inc = 0.3;
        let argp = 1.0;

        let peri = Perifocal::new(pos, vel, raan, inc, argp);

        assert_eq!(peri.position(), &pos);
        assert_eq!(peri.velocity(), &vel);
        assert_eq!(peri.raan(), raan);
        assert_eq!(peri.inclination(), inc);
        assert_eq!(peri.argp(), argp);
    }

    #[test]
    fn test_perifocal_from_orbital_elements() {
        // Create from orbital elements at periapsis (nu = 0)
        let a = 7000000.0; // 7000 km
        let e = 0.1;
        let nu = 0.0; // At periapsis
        let raan = 0.0;
        let inc = 0.0;
        let argp = 0.0;
        let mu = 398600.4418e9;

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);

        // At periapsis, position should be along P-axis
        let r_periapsis = a * (1.0 - e);
        assert_relative_eq!(peri.position().x, r_periapsis, epsilon = 1.0);
        assert_relative_eq!(peri.position().y, 0.0, epsilon = 1e-10);
        assert_relative_eq!(peri.position().z, 0.0, epsilon = 1e-10);

        // Velocity should be along Q-axis
        assert_relative_eq!(peri.velocity().x, 0.0, epsilon = 1e-6);
        assert!(peri.velocity().y > 0.0); // Positive in direction of motion
        assert_relative_eq!(peri.velocity().z, 0.0, epsilon = 1e-10);
    }

    #[test]
    fn test_perifocal_from_orbital_elements_at_apoapsis() {
        // Create at apoapsis (nu = π)
        let a = 7000000.0;
        let e = 0.2;
        let nu = PI;
        let raan = 0.0;
        let inc = 0.0;
        let argp = 0.0;
        let mu = 398600.4418e9;

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);

        // At apoapsis, position should be along -P-axis
        let r_apoapsis = a * (1.0 + e);
        assert_relative_eq!(peri.position().x, -r_apoapsis, epsilon = 1.0);
        assert_relative_eq!(peri.position().y, 0.0, epsilon = 1e-8);
        assert_relative_eq!(peri.position().z, 0.0, epsilon = 1e-8);

        // Velocity should be along -Q-axis
        assert_relative_eq!(peri.velocity().x, 0.0, epsilon = 1e-6);
        assert!(peri.velocity().y < 0.0); // Negative (retrograde at apoapsis in PQW)
        assert_relative_eq!(peri.velocity().z, 0.0, epsilon = 1e-8);
    }

    #[test]
    fn test_perifocal_position_always_in_plane() {
        // Position should always have z = 0 in perifocal frame
        let a = 8000000.0;
        let e = 0.15;
        let raan = 0.5;
        let inc = 0.4;
        let argp = 1.2;
        let mu = 398600.4418e9;

        for nu in [0.0, PI / 4.0, PI / 2.0, PI, 3.0 * PI / 2.0] {
            let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);
            assert_relative_eq!(peri.position().z, 0.0, epsilon = 1e-6);
            assert_relative_eq!(peri.velocity().z, 0.0, epsilon = 1e-6);
        }
    }

    #[test]
    fn test_perifocal_to_gcrs_equatorial_orbit() {
        // Equatorial orbit (inc = 0, raan = 0, argp = 0) should be identity transformation
        let pos_peri = Vector3::new(7000000.0, 1000000.0, 0.0);
        let vel_peri = Vector3::new(-1000.0, 7000.0, 0.0);
        let epoch = Epoch::j2000();

        let peri = Perifocal::new(pos_peri, vel_peri, 0.0, 0.0, 0.0);
        let gcrs = peri.to_gcrs(epoch);

        // Should be essentially the same (no rotation)
        assert_relative_eq!(gcrs.position().x, pos_peri.x, epsilon = 1e-3);
        assert_relative_eq!(gcrs.position().y, pos_peri.y, epsilon = 1e-3);
        assert_relative_eq!(gcrs.position().z, pos_peri.z, epsilon = 1e-3);
    }

    #[test]
    fn test_perifocal_to_gcrs_polar_orbit() {
        // Polar orbit (inc = π/2) with RAAN = 0, argp = 0
        let pos_peri = Vector3::new(7000000.0, 0.0, 0.0); // Along P-axis
        let vel_peri = Vector3::new(0.0, 7500.0, 0.0); // Along Q-axis
        let epoch = Epoch::j2000();

        let peri = Perifocal::new(pos_peri, vel_peri, 0.0, PI / 2.0, 0.0);
        let gcrs = peri.to_gcrs(epoch);

        // With inc = π/2, Q-axis (y in perifocal) becomes z in inertial
        assert_relative_eq!(gcrs.position().x, pos_peri.x, epsilon = 1.0);
        assert_relative_eq!(gcrs.position().y, 0.0, epsilon = 1.0);
        assert_relative_eq!(gcrs.position().z, 0.0, epsilon = 1.0);

        // Velocity in Q direction should rotate to z-direction
        assert_relative_eq!(gcrs.velocity().x, 0.0, epsilon = 1.0);
        assert_relative_eq!(gcrs.velocity().y, 0.0, epsilon = 1.0);
        assert_relative_eq!(gcrs.velocity().z, vel_peri.y, epsilon = 1.0);
    }

    #[test]
    fn test_perifocal_gcrs_roundtrip() {
        // Test perifocal → GCRS → perifocal
        let pos = Vector3::new(7000000.0, 1000000.0, 0.0);
        let vel = Vector3::new(-500.0, 7200.0, 0.0);
        let raan = 1.0;
        let inc = 0.5;
        let argp = 2.0;
        let epoch = Epoch::j2000();

        let peri1 = Perifocal::new(pos, vel, raan, inc, argp);
        let gcrs = peri1.to_gcrs(epoch);
        let peri2 = Perifocal::from_gcrs(&gcrs, raan, inc, argp);

        // Should get back the same values
        assert_relative_eq!(peri2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(peri2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(peri2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(peri2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(peri2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(peri2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_perifocal_from_gcrs_roundtrip() {
        // Test GCRS → perifocal → GCRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(-1000.0, 7000.0, 1000.0);
        let epoch = Epoch::j2000();
        let raan = 0.5;
        let inc = 0.3;
        let argp = 1.5;

        let gcrs1 = GCRS::new(pos, vel, epoch);
        let peri = Perifocal::from_gcrs(&gcrs1, raan, inc, argp);
        let gcrs2 = peri.to_gcrs(epoch);

        // Should get back the same values
        assert_relative_eq!(gcrs2.position().x, pos.x, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.position().y, pos.y, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.position().z, pos.z, epsilon = 1e-3);
        assert_relative_eq!(gcrs2.velocity().x, vel.x, epsilon = 1e-6);
        assert_relative_eq!(gcrs2.velocity().y, vel.y, epsilon = 1e-6);
        assert_relative_eq!(gcrs2.velocity().z, vel.z, epsilon = 1e-6);
    }

    #[test]
    fn test_perifocal_magnitude_conservation() {
        // Position and velocity magnitudes should be conserved in transformations
        let pos = Vector3::new(7000000.0, 2000000.0, 0.0);
        let vel = Vector3::new(-2000.0, 7000.0, 0.0);
        let raan = 0.8;
        let inc = 0.6;
        let argp = 1.2;
        let epoch = Epoch::j2000();

        let peri = Perifocal::new(pos, vel, raan, inc, argp);
        let gcrs = peri.to_gcrs(epoch);

        // Magnitudes must be preserved
        let r_peri = peri.position().norm();
        let v_peri = peri.velocity().norm();
        let r_gcrs = gcrs.position().norm();
        let v_gcrs = gcrs.velocity().norm();

        assert_relative_eq!(r_gcrs, r_peri, epsilon = 1e-3);
        assert_relative_eq!(v_gcrs, v_peri, epsilon = 1e-6);
    }

    #[test]
    fn test_perifocal_angular_momentum_conservation() {
        // Angular momentum vector should be conserved (magnitude and direction after rotation)
        let a = 8000000.0;
        let e = 0.15;
        let nu = PI / 3.0;
        let raan = 0.5;
        let inc = 0.4;
        let argp = 1.0;
        let mu = 398600.4418e9;
        let epoch = Epoch::j2000();

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);
        let gcrs = peri.to_gcrs(epoch);

        // Angular momentum h = r × v
        let h_peri = peri.position().cross(peri.velocity());
        let h_gcrs = gcrs.position().cross(gcrs.velocity());

        // Magnitude should be identical
        assert_relative_eq!(h_gcrs.norm(), h_peri.norm(), epsilon = 1.0);
    }

    #[test]
    fn test_perifocal_specific_energy_conservation() {
        // Specific orbital energy should be conserved
        let a = 7500000.0;
        let e = 0.1;
        let nu = PI / 4.0;
        let raan = 0.3;
        let inc = 0.2;
        let argp = 0.8;
        let mu = 398600.4418e9;
        let epoch = Epoch::j2000();

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);
        let gcrs = peri.to_gcrs(epoch);

        // Specific energy: ε = v²/2 - μ/r
        let r_peri = peri.position().norm();
        let v_peri = peri.velocity().norm();
        let energy_peri = v_peri.powi(2) / 2.0 - mu / r_peri;

        let r_gcrs = gcrs.position().norm();
        let v_gcrs = gcrs.velocity().norm();
        let energy_gcrs = v_gcrs.powi(2) / 2.0 - mu / r_gcrs;

        assert_relative_eq!(energy_gcrs, energy_peri, epsilon = 1.0);
    }

    #[test]
    fn test_perifocal_iss_like_orbit() {
        // ISS-like orbit parameters
        let a = 6371000.0 + 420000.0; // ~420 km altitude
        let e = 0.001; // Nearly circular
        let nu = 0.0;
        let raan = 1.2;
        let inc = 51.6 * PI / 180.0; // ISS inclination
        let argp = 0.5;
        let mu = 398600.4418e9;
        let epoch = Epoch::j2000();

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);
        let gcrs = peri.to_gcrs(epoch);

        // Verify orbital radius (at periapsis: r = a(1-e))
        let r = gcrs.position().norm();
        let r_periapsis = a * (1.0 - e);
        assert_relative_eq!(r, r_periapsis, epsilon = 1000.0); // Within 1 km

        // Verify velocity is reasonable for LEO
        let v = gcrs.velocity().norm();
        assert!(v > 7500.0 && v < 7800.0); // Typical ISS velocity
    }

    #[test]
    fn test_perifocal_geo_orbit() {
        // Geostationary orbit
        let a = 42164000.0; // GEO radius
        let e = 0.0001; // Nearly circular
        let nu = PI / 2.0;
        let raan = 0.0;
        let inc = 0.01; // Nearly equatorial
        let argp = 0.0;
        let mu = 398600.4418e9;
        let epoch = Epoch::j2000();

        let peri = Perifocal::from_orbital_elements(a, e, nu, raan, inc, argp, mu);
        let gcrs = peri.to_gcrs(epoch);

        // Verify orbital radius
        let r = gcrs.position().norm();
        assert_relative_eq!(r, a, epsilon = 10000.0); // Within 10 km

        // Verify velocity is reasonable for GEO
        let v = gcrs.velocity().norm();
        assert!(v > 3000.0 && v < 3100.0); // ~3.07 km/s for GEO
    }

    #[test]
    fn test_perifocal_rotation_matrix_orthogonal() {
        // Rotation matrices should be orthogonal (R^T * R = I)
        let peri = Perifocal::new(
            Vector3::zeros(),
            Vector3::zeros(),
            0.5,
            0.3,
            1.0,
        );

        let r = peri.rotation_to_inertial();
        let r_t = r.transpose();
        let identity = r_t * r;

        // Should be identity matrix
        assert_relative_eq!(identity[(0, 0)], 1.0, epsilon = 1e-10);
        assert_relative_eq!(identity[(1, 1)], 1.0, epsilon = 1e-10);
        assert_relative_eq!(identity[(2, 2)], 1.0, epsilon = 1e-10);
        assert_relative_eq!(identity[(0, 1)], 0.0, epsilon = 1e-10);
        assert_relative_eq!(identity[(0, 2)], 0.0, epsilon = 1e-10);
        assert_relative_eq!(identity[(1, 2)], 0.0, epsilon = 1e-10);
    }

    #[test]
    fn test_perifocal_determinant_is_one() {
        // Rotation matrix determinant should be +1 (proper rotation, not reflection)
        let peri = Perifocal::new(
            Vector3::zeros(),
            Vector3::zeros(),
            1.2,
            0.7,
            0.4,
        );

        let r = peri.rotation_to_inertial();
        let det = r.determinant();

        assert_relative_eq!(det, 1.0, epsilon = 1e-10);
    }

    // ========== J2000 Tests ==========

    #[test]
    fn test_j2000_creation() {
        // Create a J2000 coordinate
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let frame = J2000::new(pos, vel);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &vel);
    }

    #[test]
    fn test_j2000_from_position() {
        // Create J2000 from position only
        let pos = Vector3::new(42164000.0, 0.0, 0.0); // GEO altitude
        let frame = J2000::from_position(pos);

        assert_eq!(frame.position(), &pos);
        assert_eq!(frame.velocity(), &Vector3::zeros());
    }

    #[test]
    fn test_j2000_to_gcrs() {
        // J2000 should convert to GCRS at J2000 epoch with identical coordinates
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let j2000 = J2000::new(pos, vel);

        let gcrs = j2000.to_gcrs();

        // Position and velocity should be identical
        assert_eq!(gcrs.position(), &pos);
        assert_eq!(gcrs.velocity(), &vel);

        // Epoch should be J2000
        assert_eq!(gcrs.obstime(), &Epoch::j2000());
    }

    #[test]
    fn test_j2000_from_gcrs() {
        // Create J2000 from GCRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let gcrs = GCRS::new(pos, vel, Epoch::j2000());

        let j2000 = J2000::from_gcrs(&gcrs);

        // Position and velocity should be identical
        assert_eq!(j2000.position(), &pos);
        assert_eq!(j2000.velocity(), &vel);
    }

    #[test]
    fn test_j2000_gcrs_roundtrip() {
        // Roundtrip conversion should preserve coordinates
        let pos = Vector3::new(1.0e7, 2.0e7, 3.0e7);
        let vel = Vector3::new(1000.0, 2000.0, 3000.0);
        let j2000_1 = J2000::new(pos, vel);

        let gcrs = j2000_1.to_gcrs();
        let j2000_2 = J2000::from_gcrs(&gcrs);

        // Should preserve position and velocity
        assert_relative_eq!(j2000_2.position().x, j2000_1.position().x, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.position().y, j2000_1.position().y, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.position().z, j2000_1.position().z, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.velocity().x, j2000_1.velocity().x, epsilon = 1e-9);
        assert_relative_eq!(j2000_2.velocity().y, j2000_1.velocity().y, epsilon = 1e-9);
        assert_relative_eq!(j2000_2.velocity().z, j2000_1.velocity().z, epsilon = 1e-9);
    }

    #[test]
    fn test_j2000_to_icrs() {
        // J2000 and ICRS should be effectively identical
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let j2000 = J2000::new(pos, vel);

        let icrs = j2000.to_icrs().unwrap();

        // Position and velocity should be identical (no rotation for V1 implementation)
        assert_eq!(icrs.position(), &pos);
        assert_eq!(icrs.velocity(), &vel);
    }

    #[test]
    fn test_j2000_from_icrs() {
        // Create J2000 from ICRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let icrs = ICRS::new(pos, vel);

        let j2000 = J2000::from_icrs(&icrs);

        // Position and velocity should be identical
        assert_eq!(j2000.position(), &pos);
        assert_eq!(j2000.velocity(), &vel);
    }

    #[test]
    fn test_j2000_icrs_roundtrip() {
        // Roundtrip conversion should preserve coordinates
        let pos = Vector3::new(1.0e7, 2.0e7, 3.0e7);
        let vel = Vector3::new(1000.0, 2000.0, 3000.0);
        let j2000_1 = J2000::new(pos, vel);

        let icrs = j2000_1.to_icrs().unwrap();
        let j2000_2 = J2000::from_icrs(&icrs);

        // Should preserve position and velocity exactly
        assert_relative_eq!(j2000_2.position().x, j2000_1.position().x, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.position().y, j2000_1.position().y, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.position().z, j2000_1.position().z, epsilon = 1e-6);
        assert_relative_eq!(j2000_2.velocity().x, j2000_1.velocity().x, epsilon = 1e-9);
        assert_relative_eq!(j2000_2.velocity().y, j2000_1.velocity().y, epsilon = 1e-9);
        assert_relative_eq!(j2000_2.velocity().z, j2000_1.velocity().z, epsilon = 1e-9);
    }

    #[test]
    fn test_j2000_to_itrs() {
        // J2000 should convert to ITRS via GCRS transformation
        let r = 7000000.0; // LEO altitude
        let pos_j2000 = Vector3::new(r, 0.0, 0.0);
        let vel_j2000 = Vector3::new(0.0, 7500.0, 0.0);

        let j2000 = J2000::new(pos_j2000, vel_j2000);
        let itrs = j2000.to_itrs().unwrap();

        // Position magnitude should be preserved
        let r_itrs = itrs.position().norm();
        assert_relative_eq!(r_itrs, r, epsilon = 1.0);

        // Velocity should be affected by Earth rotation
        let v_itrs = itrs.velocity().norm();
        assert!(v_itrs > 100.0); // Should have some velocity
    }

    #[test]
    fn test_j2000_from_itrs() {
        // Create J2000 from ITRS
        let r = 6378137.0; // Earth radius at equator
        let pos_itrs = Vector3::new(r, 0.0, 0.0);
        let vel_itrs = Vector3::zeros();

        let itrs = ITRS::new(pos_itrs, vel_itrs, Epoch::j2000());
        let j2000 = J2000::from_itrs(&itrs).unwrap();

        // Position magnitude should be preserved
        let r_j2000 = j2000.position().norm();
        assert_relative_eq!(r_j2000, r, epsilon = 1.0);
    }

    #[test]
    fn test_j2000_itrs_roundtrip() {
        // Roundtrip through ITRS
        let pos = Vector3::new(7000000.0, 1000000.0, 500000.0);
        let vel = Vector3::new(1000.0, 7000.0, 500.0);
        let j2000_1 = J2000::new(pos, vel);

        let itrs = j2000_1.to_itrs().unwrap();
        let j2000_2 = J2000::from_itrs(&itrs).unwrap();

        // Position should be preserved (within mm precision)
        assert_relative_eq!(j2000_2.position().x, j2000_1.position().x, epsilon = 1e-3);
        assert_relative_eq!(j2000_2.position().y, j2000_1.position().y, epsilon = 1e-3);
        assert_relative_eq!(j2000_2.position().z, j2000_1.position().z, epsilon = 1e-3);

        // Velocity should be preserved (within mm/s precision)
        assert_relative_eq!(j2000_2.velocity().x, j2000_1.velocity().x, epsilon = 1e-3);
        assert_relative_eq!(j2000_2.velocity().y, j2000_1.velocity().y, epsilon = 1e-3);
        assert_relative_eq!(j2000_2.velocity().z, j2000_1.velocity().z, epsilon = 1e-3);
    }

    #[test]
    fn test_j2000_iss_orbit() {
        // ISS-like orbit at ~420 km altitude, 51.6° inclination
        let r = 6371000.0 + 420000.0; // Earth radius + altitude
        let pos = Vector3::new(r, 0.0, 0.0);
        let v = (398600.4418e9_f64 / r).sqrt(); // Circular velocity
        let vel = Vector3::new(0.0, v, 0.0);

        let j2000 = J2000::new(pos, vel);

        // Verify orbital radius
        let r_mag = j2000.position().norm();
        assert_relative_eq!(r_mag, r, epsilon = 1.0);

        // Verify velocity is correct for circular orbit
        let v_mag = j2000.velocity().norm();
        assert_relative_eq!(v_mag, v, epsilon = 1.0);

        // Convert to GCRS and verify
        let gcrs = j2000.to_gcrs();
        assert_relative_eq!(gcrs.position().norm(), r, epsilon = 1.0);
    }

    #[test]
    fn test_j2000_geo_orbit() {
        // GEO orbit at ~35,786 km altitude
        let r_geo = 42164000.0; // GEO radius
        let pos = Vector3::new(r_geo, 0.0, 0.0);
        let v_geo = (398600.4418e9_f64 / r_geo).sqrt(); // Circular velocity
        let vel = Vector3::new(0.0, v_geo, 0.0);

        let j2000 = J2000::new(pos, vel);

        // Verify position
        let r_mag = j2000.position().norm();
        assert_relative_eq!(r_mag, r_geo, epsilon = 100.0);

        // Verify velocity is reasonable for GEO
        let v_mag = j2000.velocity().norm();
        assert!(v_mag > 3000.0 && v_mag < 3100.0); // ~3.07 km/s for GEO
    }

    #[test]
    fn test_j2000_position_magnitude_preserved() {
        // Position magnitude should be preserved across all transformations
        let r = 8000000.0;
        let pos = Vector3::new(r / 2.0_f64.sqrt(), r / 2.0_f64.sqrt(), 0.0);
        let vel = Vector3::new(0.0, 0.0, 7000.0);
        let j2000 = J2000::new(pos, vel);

        let r_j2000 = j2000.position().norm();
        assert_relative_eq!(r_j2000, r, epsilon = 1.0);

        // GCRS conversion
        let gcrs = j2000.to_gcrs();
        let r_gcrs = gcrs.position().norm();
        assert_relative_eq!(r_gcrs, r, epsilon = 1.0);

        // ICRS conversion
        let icrs = j2000.to_icrs().unwrap();
        let r_icrs = icrs.position().norm();
        assert_relative_eq!(r_icrs, r, epsilon = 1.0);
    }

    // ========== Batch Transformation Tests ==========

    #[test]
    fn test_batch_gcrs_to_itrs_basic() {
        // Test basic GCRS to ITRS batch transformation
        let positions = vec![
            Vector3::new(7000e3, 0.0, 0.0),
            Vector3::new(0.0, 7000e3, 0.0),
            Vector3::new(7000e3, 7000e3, 0.0),
        ];
        let velocities = vec![
            Vector3::new(0.0, 7500.0, 0.0),
            Vector3::new(-7500.0, 0.0, 0.0),
            Vector3::new(-5000.0, 5000.0, 0.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 1, 1, 12, 0, 0, 0),
            Epoch::from_gregorian_utc(2024, 6, 15, 0, 0, 0, 0),
        ];

        let result = batch_gcrs_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (itrs_pos, itrs_vel) = result.unwrap();
        assert_eq!(itrs_pos.len(), 3);
        assert_eq!(itrs_vel.len(), 3);

        // Verify positions are rotated (not zero)
        for pos in &itrs_pos {
            assert!(pos.norm() > 1e6); // Should be ~7000 km
        }
    }

    #[test]
    fn test_batch_gcrs_to_itrs_length_mismatch() {
        // Test error when array lengths don't match
        let positions = vec![Vector3::new(7000e3, 0.0, 0.0)];
        let velocities = vec![
            Vector3::new(0.0, 7500.0, 0.0),
            Vector3::new(0.0, 7500.0, 0.0),
        ];
        let obstimes = vec![Epoch::j2000()];

        let result = batch_gcrs_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_err());
    }

    #[test]
    fn test_batch_itrs_to_gcrs_basic() {
        // Test basic ITRS to GCRS batch transformation
        let positions = vec![
            Vector3::new(7000e3, 0.0, 0.0),
            Vector3::new(0.0, 7000e3, 0.0),
        ];
        let velocities = vec![
            Vector3::new(0.0, 100.0, 0.0),
            Vector3::new(-100.0, 0.0, 0.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 3, 21, 12, 0, 0, 0),
        ];

        let result = batch_itrs_to_gcrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (gcrs_pos, gcrs_vel) = result.unwrap();
        assert_eq!(gcrs_pos.len(), 2);
        assert_eq!(gcrs_vel.len(), 2);

        // Verify transformation occurred
        for pos in &gcrs_pos {
            assert!(pos.norm() > 1e6);
        }
    }

    #[test]
    fn test_batch_gcrs_itrs_roundtrip() {
        // Test GCRS → ITRS → GCRS round-trip
        let positions = vec![
            Vector3::new(7000e3, 1000e3, 500e3),
            Vector3::new(42164e3, 0.0, 0.0), // GEO altitude
        ];
        let velocities = vec![
            Vector3::new(500.0, 7500.0, 100.0),
            Vector3::new(0.0, 3075.0, 0.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2025, 1, 1, 0, 0, 0, 0),
        ];

        // Forward: GCRS → ITRS
        let (itrs_pos, itrs_vel) = batch_gcrs_to_itrs(&positions, &velocities, &obstimes).unwrap();

        // Reverse: ITRS → GCRS
        let (gcrs_pos_rt, gcrs_vel_rt) = batch_itrs_to_gcrs(&itrs_pos, &itrs_vel, &obstimes).unwrap();

        // Verify round-trip accuracy
        for i in 0..positions.len() {
            assert_relative_eq!(gcrs_pos_rt[i].x, positions[i].x, epsilon = 1e-6);
            assert_relative_eq!(gcrs_pos_rt[i].y, positions[i].y, epsilon = 1e-6);
            assert_relative_eq!(gcrs_pos_rt[i].z, positions[i].z, epsilon = 1e-6);
            assert_relative_eq!(gcrs_vel_rt[i].x, velocities[i].x, epsilon = 1e-9);
            assert_relative_eq!(gcrs_vel_rt[i].y, velocities[i].y, epsilon = 1e-9);
            assert_relative_eq!(gcrs_vel_rt[i].z, velocities[i].z, epsilon = 1e-9);
        }
    }

    #[test]
    fn test_batch_gcrs_to_teme_basic() {
        // Test GCRS to TEME batch transformation
        let positions = vec![
            Vector3::new(7000e3, 0.0, 0.0),
            Vector3::new(0.0, 8000e3, 0.0),
        ];
        let velocities = vec![
            Vector3::new(0.0, 7500.0, 0.0),
            Vector3::new(-7000.0, 0.0, 0.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 7, 4, 12, 0, 0, 0),
        ];

        let result = batch_gcrs_to_teme(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (teme_pos, teme_vel) = result.unwrap();
        assert_eq!(teme_pos.len(), 2);
        assert_eq!(teme_vel.len(), 2);

        // Verify positions have correct magnitude
        for (i, pos) in teme_pos.iter().enumerate() {
            assert_relative_eq!(pos.norm(), positions[i].norm(), epsilon = 1.0);
        }
    }

    #[test]
    fn test_batch_teme_to_gcrs_basic() {
        // Test TEME to GCRS batch transformation
        let positions = vec![
            Vector3::new(6800e3, 0.0, 0.0),
            Vector3::new(0.0, 6800e3, 1000e3),
        ];
        let velocities = vec![
            Vector3::new(0.0, 7600.0, 0.0),
            Vector3::new(-7600.0, 0.0, 100.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 12, 25, 0, 0, 0, 0),
        ];

        let result = batch_teme_to_gcrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (gcrs_pos, gcrs_vel) = result.unwrap();
        assert_eq!(gcrs_pos.len(), 2);
        assert_eq!(gcrs_vel.len(), 2);
    }

    #[test]
    fn test_batch_gcrs_teme_roundtrip() {
        // Test GCRS → TEME → GCRS round-trip
        let positions = vec![
            Vector3::new(7100e3, 500e3, 300e3),
            Vector3::new(8000e3, 8000e3, 0.0),
        ];
        let velocities = vec![
            Vector3::new(200.0, 7400.0, 50.0),
            Vector3::new(-5000.0, 5000.0, 100.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 2, 29, 12, 0, 0, 0), // Leap day
        ];

        // Forward: GCRS → TEME
        let (teme_pos, teme_vel) = batch_gcrs_to_teme(&positions, &velocities, &obstimes).unwrap();

        // Reverse: TEME → GCRS
        let (gcrs_pos_rt, gcrs_vel_rt) = batch_teme_to_gcrs(&teme_pos, &teme_vel, &obstimes).unwrap();

        // Verify round-trip accuracy (note: TEME has lower accuracy than GCRS/ITRS)
        for i in 0..positions.len() {
            assert_relative_eq!(gcrs_pos_rt[i].x, positions[i].x, epsilon = 100.0); // ~100m tolerance
            assert_relative_eq!(gcrs_pos_rt[i].y, positions[i].y, epsilon = 100.0);
            assert_relative_eq!(gcrs_pos_rt[i].z, positions[i].z, epsilon = 100.0);
            assert_relative_eq!(gcrs_vel_rt[i].x, velocities[i].x, epsilon = 0.1); // 0.1 m/s tolerance
            assert_relative_eq!(gcrs_vel_rt[i].y, velocities[i].y, epsilon = 0.1);
            assert_relative_eq!(gcrs_vel_rt[i].z, velocities[i].z, epsilon = 0.1);
        }
    }

    #[test]
    fn test_batch_teme_to_itrs_basic() {
        // Test TEME to ITRS batch transformation
        let positions = vec![
            Vector3::new(7000e3, 0.0, 0.0),
            Vector3::new(0.0, 7000e3, 0.0),
            Vector3::new(7000e3, 7000e3, 1000e3),
        ];
        let velocities = vec![
            Vector3::new(0.0, 7500.0, 0.0),
            Vector3::new(-7500.0, 0.0, 0.0),
            Vector3::new(-5000.0, 5000.0, 100.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 6, 21, 0, 0, 0, 0), // Summer solstice
            Epoch::from_gregorian_utc(2024, 12, 21, 12, 0, 0, 0), // Winter solstice
        ];

        let result = batch_teme_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (itrs_pos, itrs_vel) = result.unwrap();
        assert_eq!(itrs_pos.len(), 3);
        assert_eq!(itrs_vel.len(), 3);

        // Verify position magnitudes are preserved
        for (i, pos) in itrs_pos.iter().enumerate() {
            assert_relative_eq!(pos.norm(), positions[i].norm(), epsilon = 1.0);
        }
    }

    #[test]
    fn test_batch_itrs_to_teme_basic() {
        // Test ITRS to TEME batch transformation
        let positions = vec![
            Vector3::new(6800e3, 0.0, 0.0),
            Vector3::new(0.0, 6800e3, 0.0),
        ];
        let velocities = vec![
            Vector3::new(0.0, 100.0, 0.0),
            Vector3::new(-100.0, 0.0, 0.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2024, 9, 22, 12, 0, 0, 0), // Autumnal equinox
        ];

        let result = batch_itrs_to_teme(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let (teme_pos, teme_vel) = result.unwrap();
        assert_eq!(teme_pos.len(), 2);
        assert_eq!(teme_vel.len(), 2);
    }

    #[test]
    fn test_batch_teme_itrs_roundtrip() {
        // Test TEME → ITRS → TEME round-trip
        let positions = vec![
            Vector3::new(7200e3, 1000e3, 500e3),
            Vector3::new(42164e3, 0.0, 100e3),
        ];
        let velocities = vec![
            Vector3::new(300.0, 7400.0, 50.0),
            Vector3::new(0.0, 3075.0, 10.0),
        ];
        let obstimes = vec![
            Epoch::j2000(),
            Epoch::from_gregorian_utc(2025, 3, 20, 0, 0, 0, 0), // Vernal equinox
        ];

        // Forward: TEME → ITRS
        let (itrs_pos, itrs_vel) = batch_teme_to_itrs(&positions, &velocities, &obstimes).unwrap();

        // Reverse: ITRS → TEME
        let (teme_pos_rt, teme_vel_rt) = batch_itrs_to_teme(&itrs_pos, &itrs_vel, &obstimes).unwrap();

        // Verify round-trip accuracy
        for i in 0..positions.len() {
            assert_relative_eq!(teme_pos_rt[i].x, positions[i].x, epsilon = 1e-6);
            assert_relative_eq!(teme_pos_rt[i].y, positions[i].y, epsilon = 1e-6);
            assert_relative_eq!(teme_pos_rt[i].z, positions[i].z, epsilon = 1e-6);
            assert_relative_eq!(teme_vel_rt[i].x, velocities[i].x, epsilon = 1e-9);
            assert_relative_eq!(teme_vel_rt[i].y, velocities[i].y, epsilon = 1e-9);
            assert_relative_eq!(teme_vel_rt[i].z, velocities[i].z, epsilon = 1e-9);
        }
    }

    #[test]
    fn test_batch_empty_arrays() {
        // Test batch transformations with empty arrays
        let positions: Vec<Vector3<f64>> = vec![];
        let velocities: Vec<Vector3<f64>> = vec![];
        let obstimes: Vec<Epoch> = vec![];

        // All batch functions should handle empty arrays
        let result = batch_gcrs_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());
        let (pos_out, vel_out) = result.unwrap();
        assert_eq!(pos_out.len(), 0);
        assert_eq!(vel_out.len(), 0);

        let result = batch_itrs_to_gcrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let result = batch_gcrs_to_teme(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let result = batch_teme_to_gcrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let result = batch_teme_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());

        let result = batch_itrs_to_teme(&positions, &velocities, &obstimes);
        assert!(result.is_ok());
    }

    #[test]
    fn test_batch_large_array() {
        // Test batch processing with larger arrays (parallel processing)
        let n = 100;
        let positions: Vec<Vector3<f64>> = (0..n)
            .map(|i| {
                let angle = 2.0 * PI * i as f64 / n as f64;
                Vector3::new(7000e3 * angle.cos(), 7000e3 * angle.sin(), 0.0)
            })
            .collect();

        let velocities: Vec<Vector3<f64>> = (0..n)
            .map(|i| {
                let angle = 2.0 * PI * i as f64 / n as f64;
                Vector3::new(-7500.0 * angle.sin(), 7500.0 * angle.cos(), 0.0)
            })
            .collect();

        let obstimes: Vec<Epoch> = (0..n)
            .map(|i| {
                let days = i as f64 * 10.0; // Every 10 days
                Epoch::from_jd(2451545.0 + days, TimeScale::TAI) // J2000 + days
            })
            .collect();

        // Test GCRS → ITRS with large array
        let result = batch_gcrs_to_itrs(&positions, &velocities, &obstimes);
        assert!(result.is_ok());
        let (itrs_pos, itrs_vel) = result.unwrap();
        assert_eq!(itrs_pos.len(), n);
        assert_eq!(itrs_vel.len(), n);

        // Verify all positions were transformed
        for pos in &itrs_pos {
            assert!(pos.norm() > 1e6); // Should be ~7000 km
        }
    }

    #[test]
    fn test_batch_coriolis_effect() {
        // Test that Coriolis term is correctly applied in batch transformations
        // A stationary point in ITRS should have non-zero velocity in GCRS
        let positions = vec![Vector3::new(7000e3, 0.0, 0.0)]; // On equator
        let velocities = vec![Vector3::zeros()]; // Stationary in ITRS
        let obstimes = vec![Epoch::j2000()];

        let (gcrs_pos, gcrs_vel) = batch_itrs_to_gcrs(&positions, &velocities, &obstimes).unwrap();

        // Velocity in GCRS should be non-zero due to Earth's rotation
        assert!(gcrs_vel[0].norm() > 100.0); // Should be ~500 m/s for 7000 km altitude

        // Velocity should be roughly perpendicular to position
        let dot_product = gcrs_pos[0].dot(&gcrs_vel[0]);
        assert!(dot_product.abs() < 1e6); // Near-perpendicular
    }

}
