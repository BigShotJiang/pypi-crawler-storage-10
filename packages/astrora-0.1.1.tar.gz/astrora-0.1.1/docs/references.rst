References
==========

Key References
-------------

* Curtis, H. D. (2013). *Orbital Mechanics for Engineering Students* (3rd ed.). Butterworth-Heinemann.
* Vallado, D. A. (2013). *Fundamentals of Astrodynamics and Applications* (4th ed.). Microcosm Press.
* Battin, R. H. (1999). *An Introduction to the Mathematics and Methods of Astrodynamics* (Revised ed.). AIAA.

Online Resources
---------------

* `PyO3 User Guide <https://pyo3.rs/>`_
* `Nyx-space <https://github.com/nyx-space/nyx>`_
* `AeroRust Community <https://aerorust.org/>`_
