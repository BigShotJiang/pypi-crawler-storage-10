from typing import Literal

LogLevel = Literal["debug", "success", "info", "notice", "warning", "error", "critical"]