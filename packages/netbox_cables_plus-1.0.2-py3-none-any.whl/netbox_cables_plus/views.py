from django.contrib.contenttypes.models import ContentType
from django.db.models import Case, When, Value, CharField, IntegerField, OuterRef, Subquery, F
from django.db.models.functions import Concat, Lower, Cast, Coalesce
from django.db.models import Func
from netbox.views.generic import ObjectListView
from dcim.models import (
    Cable, CableTermination,
    Interface, FrontPort, RearPort,
    ConsolePort, ConsoleServerPort,
    PowerPort, PowerOutlet, PowerFeed
)
from circuits.models import CircuitTermination
from dcim.filtersets import CableFilterSet
from dcim.forms.filtersets import CableFilterForm
from .tables import CablePlusTable

class SubstringRegex(Func):
    function = 'substring'
    template = "%(function)s(%(expressions)s from %(pattern)s)"
    def __init__(self, expression, pattern, **extra):
        super().__init__(expression, pattern=Value(pattern), **extra)

class TrailingNumber(Func):
    template = "substring(%(expressions)s from '([0-9]+)$')"

def _ct_pk(model):
    return ContentType.objects.get_for_model(model).pk

def _term_selects(end: str):
    base = CableTermination.objects.filter(
        cable=OuterRef('pk'),
        cable_end=end,
    )
    return (
        Subquery(base.values('termination_type')[:1]),
        Subquery(base.values('termination_id')[:1]),
    )

def _dev_name_subquery(model, id_alias: str, dev_field: str):
    return Subquery(
        model.objects.filter(pk=OuterRef(id_alias))
        .annotate(dev_name_l=Lower(F(dev_field)))
        .values('dev_name_l')[:1]
    )

def _comp_name_subquery(model, id_alias: str, field_name: str = 'name'):
    return Subquery(
        model.objects.filter(pk=OuterRef(id_alias))
        .values(field_name)[:1]
    )

def _comp_num_subquery(model, id_alias: str, field_name: str = 'name'):
    return Subquery(
        model.objects
        .filter(pk=OuterRef(id_alias))
        .annotate(num=Cast(TrailingNumber(F(field_name)), IntegerField()))
        .values('num')[:1]
    )

class CablePlusListView(ObjectListView):
    queryset = Cable.objects.all()
    table = CablePlusTable
    filterset = CableFilterSet
    filterset_form = CableFilterForm
    action_buttons = ('add', 'export')

    def get_queryset(self, request):
        qs = super().get_queryset(request)

        # ContentType PKs
        ct_iface = _ct_pk(Interface)
        ct_fp = _ct_pk(FrontPort)
        ct_rp = _ct_pk(RearPort)
        ct_cport = _ct_pk(ConsolePort)
        ct_csrv = _ct_pk(ConsoleServerPort)
        ct_pport = _ct_pk(PowerPort)
        ct_pout = _ct_pk(PowerOutlet)
        ct_pfeed = _ct_pk(PowerFeed)
        ct_cterm = _ct_pk(CircuitTermination)

        # termination type/id для A/B
        a_ct, a_id = _term_selects('A')
        b_ct, b_id = _term_selects('B')

        qs = qs.annotate(
            a_ct_id=a_ct, a_obj_id=a_id,
            b_ct_id=b_ct, b_obj_id=b_id,
        )
        a_dev_iface = _dev_name_subquery(Interface, 'a_obj_id', 'device__name')
        a_dev_fp = _dev_name_subquery(FrontPort, 'a_obj_id', 'device__name')
        a_dev_rp = _dev_name_subquery(RearPort, 'a_obj_id', 'device__name')
        a_dev_cport = _dev_name_subquery(ConsolePort, 'a_obj_id', 'device__name')
        a_dev_csrv = _dev_name_subquery(ConsoleServerPort, 'a_obj_id', 'device__name')
        a_dev_pport = _dev_name_subquery(PowerPort, 'a_obj_id', 'device__name')
        a_dev_pout = _dev_name_subquery(PowerOutlet, 'a_obj_id', 'device__name')
        a_dev_pfeed = _dev_name_subquery(PowerFeed, 'a_obj_id', 'power_panel__name')
        a_dev_cterm = _dev_name_subquery(CircuitTermination, 'a_obj_id', 'circuit__cid')

        a_name_iface = _comp_name_subquery(Interface, 'a_obj_id')
        a_name_fp = _comp_name_subquery(FrontPort, 'a_obj_id')
        a_name_rp = _comp_name_subquery(RearPort, 'a_obj_id')
        a_name_cport = _comp_name_subquery(ConsolePort, 'a_obj_id')
        a_name_csrv = _comp_name_subquery(ConsoleServerPort, 'a_obj_id')
        a_name_pport = _comp_name_subquery(PowerPort, 'a_obj_id')
        a_name_pout = _comp_name_subquery(PowerOutlet, 'a_obj_id')
        a_name_pfeed = _comp_name_subquery(PowerFeed, 'a_obj_id')
        a_name_cterm = _comp_name_subquery(CircuitTermination, 'a_obj_id', 'term_side')

        a_num_iface = _comp_num_subquery(Interface, 'a_obj_id')
        a_num_fp = _comp_num_subquery(FrontPort, 'a_obj_id')
        a_num_rp = _comp_num_subquery(RearPort, 'a_obj_id')
        a_num_cport = _comp_num_subquery(ConsolePort, 'a_obj_id')
        a_num_csrv = _comp_num_subquery(ConsoleServerPort, 'a_obj_id')
        a_num_pport = _comp_num_subquery(PowerPort, 'a_obj_id')
        a_num_pout = _comp_num_subquery(PowerOutlet, 'a_obj_id')
        a_num_pfeed = _comp_num_subquery(PowerFeed, 'a_obj_id')
        a_num_cterm = Value(None, output_field=IntegerField())

        # Subqueries для B
        b_dev_iface = _dev_name_subquery(Interface, 'b_obj_id', 'device__name')
        b_dev_fp = _dev_name_subquery(FrontPort, 'b_obj_id', 'device__name')
        b_dev_rp = _dev_name_subquery(RearPort, 'b_obj_id', 'device__name')
        b_dev_cport = _dev_name_subquery(ConsolePort, 'b_obj_id', 'device__name')
        b_dev_csrv = _dev_name_subquery(ConsoleServerPort, 'b_obj_id', 'device__name')
        b_dev_pport = _dev_name_subquery(PowerPort, 'b_obj_id', 'device__name')
        b_dev_pout = _dev_name_subquery(PowerOutlet, 'b_obj_id', 'device__name')
        b_dev_pfeed = _dev_name_subquery(PowerFeed, 'b_obj_id', 'power_panel__name')
        b_dev_cterm = _dev_name_subquery(CircuitTermination, 'b_obj_id', 'circuit__cid')

        b_name_iface = _comp_name_subquery(Interface, 'b_obj_id')
        b_name_fp = _comp_name_subquery(FrontPort, 'b_obj_id')
        b_name_rp = _comp_name_subquery(RearPort, 'b_obj_id')
        b_name_cport = _comp_name_subquery(ConsolePort, 'b_obj_id')
        b_name_csrv = _comp_name_subquery(ConsoleServerPort, 'b_obj_id')
        b_name_pport = _comp_name_subquery(PowerPort, 'b_obj_id')
        b_name_pout = _comp_name_subquery(PowerOutlet, 'b_obj_id')
        b_name_pfeed = _comp_name_subquery(PowerFeed, 'b_obj_id')
        b_name_cterm = _comp_name_subquery(CircuitTermination, 'b_obj_id', 'term_side')
        b_num_iface = _comp_num_subquery(Interface, 'b_obj_id')
        b_num_fp = _comp_num_subquery(FrontPort, 'b_obj_id')
        b_num_rp = _comp_num_subquery(RearPort, 'b_obj_id')
        b_num_cport = _comp_num_subquery(ConsolePort, 'b_obj_id')
        b_num_csrv = _comp_num_subquery(ConsoleServerPort, 'b_obj_id')
        b_num_pport = _comp_num_subquery(PowerPort, 'b_obj_id')
        b_num_pout = _comp_num_subquery(PowerOutlet, 'b_obj_id')
        b_num_pfeed = _comp_num_subquery(PowerFeed, 'b_obj_id')
        b_num_cterm = Value(None, output_field=IntegerField())
        qs = qs.annotate(
            a_dev_sort=Case(
                When(a_ct_id=ct_iface, then=a_dev_iface),
                When(a_ct_id=ct_fp, then=a_dev_fp),
                When(a_ct_id=ct_rp, then=a_dev_rp),
                When(a_ct_id=ct_cport, then=a_dev_cport),
                When(a_ct_id=ct_csrv, then=a_dev_csrv),
                When(a_ct_id=ct_pport, then=a_dev_pport),
                When(a_ct_id=ct_pout, then=a_dev_pout),
                When(a_ct_id=ct_pfeed, then=a_dev_pfeed),
                When(a_ct_id=ct_cterm, then=a_dev_cterm),
                default=Value('', output_field=CharField()),
                output_field=CharField(),
            ),
            a_name_sort=Case(
                When(a_ct_id=ct_iface, then=a_name_iface),
                When(a_ct_id=ct_fp, then=a_name_fp),
                When(a_ct_id=ct_rp, then=a_name_rp),
                When(a_ct_id=ct_cport, then=a_name_cport),
                When(a_ct_id=ct_csrv, then=a_name_csrv),
                When(a_ct_id=ct_pport, then=a_name_pport),
                When(a_ct_id=ct_pout, then=a_name_pout),
                When(a_ct_id=ct_pfeed, then=a_name_pfeed),
                When(a_ct_id=ct_cterm, then=a_name_cterm),
                default=Value('', output_field=CharField()),
                output_field=CharField(),
            ),
            a_num_sort=Coalesce(Case(
                When(a_ct_id=ct_iface, then=a_num_iface),
                When(a_ct_id=ct_fp, then=a_num_fp),
                When(a_ct_id=ct_rp, then=a_num_rp),
                When(a_ct_id=ct_cport, then=a_num_cport),
                When(a_ct_id=ct_csrv, then=a_num_csrv),
                When(a_ct_id=ct_pport, then=a_num_pport),
                When(a_ct_id=ct_pout, then=a_num_pout),
                When(a_ct_id=ct_pfeed, then=a_num_pfeed),
                When(a_ct_id=ct_cterm, then=a_num_cterm),
                default=Value(None, output_field=IntegerField()),
                output_field=IntegerField(),
            ), Value(2147483647, output_field=IntegerField())),
            b_dev_sort=Case(
                When(b_ct_id=ct_iface, then=b_dev_iface),
                When(b_ct_id=ct_fp, then=b_dev_fp),
                When(b_ct_id=ct_rp, then=b_dev_rp),
                When(b_ct_id=ct_cport, then=b_dev_cport),
                When(b_ct_id=ct_csrv, then=b_dev_csrv),
                When(b_ct_id=ct_pport, then=b_dev_pport),
                When(b_ct_id=ct_pout, then=b_dev_pout),
                When(b_ct_id=ct_pfeed, then=b_dev_pfeed),
                When(b_ct_id=ct_cterm, then=b_dev_cterm),
                default=Value('', output_field=CharField()),
                output_field=CharField(),
            ),
            b_name_sort=Case(
                When(b_ct_id=ct_iface, then=b_name_iface),
                When(b_ct_id=ct_fp, then=b_name_fp),
                When(b_ct_id=ct_rp, then=b_name_rp),
                When(b_ct_id=ct_cport, then=b_name_cport),
                When(b_ct_id=ct_csrv, then=b_name_csrv),
                When(b_ct_id=ct_pport, then=b_name_pport),
                When(b_ct_id=ct_pout, then=b_name_pout),
                When(b_ct_id=ct_pfeed, then=b_name_pfeed),
                When(b_ct_id=ct_cterm, then=b_name_cterm),
                default=Value('', output_field=CharField()),
                output_field=CharField(),
            ),
            b_num_sort=Coalesce(Case(
                When(b_ct_id=ct_iface, then=b_num_iface),
                When(b_ct_id=ct_fp, then=b_num_fp),
                When(b_ct_id=ct_rp, then=b_num_rp),
                When(b_ct_id=ct_cport, then=b_num_cport),
                When(b_ct_id=ct_csrv, then=b_num_csrv),
                When(b_ct_id=ct_pport, then=b_num_pport),
                When(b_ct_id=ct_pout, then=b_num_pout),
                When(b_ct_id=ct_pfeed, then=b_num_pfeed),
                When(b_ct_id=ct_cterm, then=b_num_cterm),
                default=Value(None, output_field=IntegerField()),
                output_field=IntegerField(),
            ), Value(2147483647, output_field=IntegerField())),
        )

        def _position_subquery(model, id_alias: str):
            return Subquery(model.objects.filter(pk=OuterRef(id_alias)).values('device__position')[:1])

        qs = qs.annotate(
            position_a=Case(
                When(a_ct_id=ct_iface, then=_position_subquery(Interface, 'a_obj_id')),
                When(a_ct_id=ct_fp, then=_position_subquery(FrontPort, 'a_obj_id')),
                When(a_ct_id=ct_rp, then=_position_subquery(RearPort, 'a_obj_id')),
                When(a_ct_id=ct_cport, then=_position_subquery(ConsolePort, 'a_obj_id')),
                When(a_ct_id=ct_csrv, then=_position_subquery(ConsoleServerPort, 'a_obj_id')),
                When(a_ct_id=ct_pport, then=_position_subquery(PowerPort, 'a_obj_id')),
                When(a_ct_id=ct_pout, then=_position_subquery(PowerOutlet, 'a_obj_id')),
                default=Value(None, output_field=IntegerField()),
                output_field=IntegerField(),
            ),
            position_b=Case(
                When(b_ct_id=ct_iface, then=_position_subquery(Interface, 'b_obj_id')),
                When(b_ct_id=ct_fp, then=_position_subquery(FrontPort, 'b_obj_id')),
                When(b_ct_id=ct_rp, then=_position_subquery(RearPort, 'b_obj_id')),
                When(b_ct_id=ct_cport, then=_position_subquery(ConsolePort, 'b_obj_id')),
                When(b_ct_id=ct_csrv, then=_position_subquery(ConsoleServerPort, 'b_obj_id')),
                When(b_ct_id=ct_pport, then=_position_subquery(PowerPort, 'b_obj_id')),
                When(b_ct_id=ct_pout, then=_position_subquery(PowerOutlet, 'b_obj_id')),
                default=Value(None, output_field=IntegerField()),
                output_field=IntegerField(),
            ),
        )

        sort = request.GET.get('sort')
        if sort:
            desc = sort.startswith('-')
            key = sort.lstrip('-')

            def orders(prefix: str, desc: bool):
                if desc:
                    return [
                        F(f'{prefix}_dev_sort').desc(),
                        F(f'{prefix}_num_sort').desc(nulls_last=True),
                        F(f'{prefix}_name_sort').desc(),
                        F('id').desc(),
                    ]
                else:
                    return [
                        F(f'{prefix}_dev_sort').asc(),
                        F(f'{prefix}_num_sort').asc(nulls_last=True),
                        F(f'{prefix}_name_sort').asc(),
                        F('id').asc(),
                    ]

            if key in ('a_terminations', 'termination_a'):
                qs = qs.order_by(*orders('a', desc))
            elif key in ('b_terminations', 'termination_b'):
                qs = qs.order_by(*orders('b', desc))

        return qs.prefetch_related('tags')