import copy
import django_tables2 as tables
from dcim.tables.cables import CableTable as CoreCableTable
from django.utils.safestring import mark_safe
from django.utils.html import escape
from django_tables2.utils import Accessor
from django.utils.translation import gettext_lazy as _
from django_tables2.utils import OrderBy, OrderByTuple

class CableTerminationAttributeColumn(tables.Column):
    def __init__(self, cable_end, attr='termination', *args, **kwargs):
        self.cable_end = cable_end
        self.attr = attr
        super().__init__(accessor=Accessor('terminations'), *args, **kwargs)

    def _get_terminations(self, manager):
        terminations = set()
        for cabletermination in manager.all():
            if cabletermination.cable_end == self.cable_end:
                if termination := self._resolve_attr(cabletermination, self.attr):
                    terminations.add(termination)

        return terminations

    def render(self, value):
        links = []
        for term in self._get_terminations(value):
            if term == term.to_integral_value():
                links.append(f"U{escape(f'{term:.0f}')}")
            else:
                links.append(f"U{escape(f'{term:.1f}')}")
        return mark_safe('<br />'.join(links) or '&mdash;')

    def value(self, value):
        return ','.join([str(t) for t in self._get_terminations(value)])

    @staticmethod
    def _resolve_attr(obj, path: str):
        cur = obj
        for part in path.split('.'):
            if cur is None:
                return None
            cur = getattr(cur, part, None)
        return cur


class CablePlusTable(CoreCableTable):
    a_terminations = copy.deepcopy(CoreCableTable.base_columns['a_terminations'])
    a_terminations.orderable = True
    a_terminations.order_by = OrderByTuple((
        OrderBy('a_dev_sort'),
        OrderBy('a_num_sort'),
        OrderBy('a_name_sort'),
        OrderBy('id'),
    ))

    b_terminations = copy.deepcopy(CoreCableTable.base_columns['b_terminations'])
    b_terminations.orderable = True
    b_terminations.order_by = OrderByTuple((
        OrderBy('b_dev_sort'),
        OrderBy('b_num_sort'),
        OrderBy('b_name_sort'),
        OrderBy('id'),
    ))
    device_a = copy.deepcopy(CoreCableTable.base_columns['device_a'])
    device_a.orderable = True
    device_b = copy.deepcopy(CoreCableTable.base_columns['device_b'])
    device_b.orderable = True
    position_a = CableTerminationAttributeColumn(
        cable_end='A',
        attr='_device.position',
        orderable=False,
        verbose_name=_('Unit A'),
    )
    position_b = CableTerminationAttributeColumn(
        cable_end='B',
        attr='_device.position',
        orderable=False,
        verbose_name=_('Unit B'),
    )

    class Meta(CoreCableTable.Meta):
        pass
