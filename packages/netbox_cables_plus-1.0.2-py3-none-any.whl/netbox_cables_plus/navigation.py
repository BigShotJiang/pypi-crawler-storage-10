from netbox.plugins import PluginMenuItem

menu_items = (
    PluginMenuItem(
        link='plugins:netbox_cables_plus:cable_list',
        link_text='Кабели+',
        permissions=['dcim.view_cable'],
    ),
)
