from django.urls import path
from .views import CablePlusListView

app_name = 'netbox_cables_plus'

urlpatterns = [
    path('', CablePlusListView.as_view(), name='cable_list'),
]
