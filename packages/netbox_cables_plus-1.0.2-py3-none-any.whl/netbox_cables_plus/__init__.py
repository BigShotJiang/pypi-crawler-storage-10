from netbox.plugins import PluginConfig

class CablesPlusConfig(PluginConfig):
    name = 'netbox_cables_plus'
    verbose_name = 'Cables+'
    description = 'Cable list with termination sorting and rack unit column'
    version = '1.0.0'
    author = 'IST'
    min_version = '4.3.0'
    max_version = '4.3.99'
    base_url = 'cables-plus'  # URL: /plugins/cables-plus/

config = CablesPlusConfig
