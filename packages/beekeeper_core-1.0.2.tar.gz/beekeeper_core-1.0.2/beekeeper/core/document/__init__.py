from beekeeper.core.document.base import BaseDocument, Document, DocumentWithScore

__all__ = ["BaseDocument", "Document", "DocumentWithScore"]
