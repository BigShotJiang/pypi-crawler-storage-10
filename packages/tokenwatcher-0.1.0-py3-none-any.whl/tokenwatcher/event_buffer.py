"""Event buffering with automatic flushing."""

import atexit
import logging
import threading
import time
from typing import List, Dict, Any, Optional

from tokenwatcher.config import Config
from tokenwatcher.sender import EventSender

logger = logging.getLogger(__name__)


class EventBuffer:
    """Thread-safe event buffer with automatic flushing."""

    def __init__(self, config: Config):
        """
        Initialize event buffer.

        Args:
            config: TokenWatcher configuration
        """
        self.config = config
        self.sender = EventSender(config)
        self.buffer: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        self.flush_thread: Optional[threading.Thread] = None
        self.running = False

        # Start background flush thread
        if config.enabled:
            self._start_flush_thread()

        # Register cleanup on exit
        atexit.register(self.shutdown)

    def add_event(self, event: Dict[str, Any]) -> None:
        """
        Add an event to the buffer.

        Args:
            event: Event dictionary to add
        """
        if not self.config.enabled:
            return

        with self.lock:
            self.buffer.append(event)
            buffer_size = len(self.buffer)

        # Auto-flush if buffer is full
        if buffer_size >= self.config.buffer_size:
            logger.debug(f"Buffer full ({buffer_size} events), triggering flush")
            self.flush()

    def flush(self) -> None:
        """Flush all buffered events to the backend."""
        if not self.config.enabled:
            return

        with self.lock:
            if not self.buffer:
                return

            events_to_send = self.buffer.copy()
            self.buffer.clear()

        logger.debug(f"Flushing {len(events_to_send)} events")
        self.sender.send_batch(events_to_send)

    def _start_flush_thread(self) -> None:
        """Start background thread for periodic flushing."""
        self.running = True
        self.flush_thread = threading.Thread(
            target=self._periodic_flush, daemon=True, name="tokenwatcher-flush"
        )
        self.flush_thread.start()
        logger.debug(
            f"Started flush thread with interval {self.config.flush_interval}s"
        )

    def _periodic_flush(self) -> None:
        """Periodically flush events in background thread."""
        while self.running:
            time.sleep(self.config.flush_interval)
            try:
                self.flush()
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}", exc_info=True)

    def shutdown(self) -> None:
        """Shutdown buffer and flush remaining events."""
        logger.debug("Shutting down event buffer")
        self.running = False

        # Wait for flush thread to finish (with timeout)
        if self.flush_thread and self.flush_thread.is_alive():
            self.flush_thread.join(timeout=2)

        # Final flush of remaining events
        try:
            self.flush()
        except Exception as e:
            logger.error(f"Error during shutdown flush: {e}")

        # Close sender
        self.sender.close()
        logger.debug("Event buffer shutdown complete")

    def __del__(self):
        """Cleanup on garbage collection."""
        try:
            self.shutdown()
        except Exception:
            pass
