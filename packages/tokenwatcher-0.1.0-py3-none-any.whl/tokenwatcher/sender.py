"""HTTP client for sending events to TokenWatcher backend."""

import logging
import time
from typing import List, Dict, Any
import requests

from tokenwatcher.config import Config

logger = logging.getLogger(__name__)


class EventSender:
    """Handles sending events to TokenWatcher backend with retry logic."""

    def __init__(self, config: Config):
        """
        Initialize event sender.

        Args:
            config: TokenWatcher configuration
        """
        self.config = config
        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-Monitor-Key": config.api_key,
                "Content-Type": "application/json",
                "User-Agent": "tokenwatcher-python/0.1.0",
            }
        )

    def send_batch(self, events: List[Dict[str, Any]]) -> bool:
        """
        Send a batch of events to the backend.

        Args:
            events: List of event dictionaries to send

        Returns:
            True if successful, False otherwise
        """
        if not self.config.enabled:
            logger.debug("Monitoring disabled, skipping batch send")
            return True

        if not events:
            logger.debug("No events to send")
            return True

        logger.debug(f"Sending batch of {len(events)} events")

        for attempt in range(1, self.config.max_retries + 1):
            try:
                response = self.session.post(
                    self.config.events_endpoint,
                    json=events,
                    timeout=self.config.timeout,
                )

                if response.status_code == 202:
                    logger.debug(f"Batch sent successfully: {response.json()}")
                    return True
                elif response.status_code == 400:
                    logger.warning(
                        f"Batch rejected (validation error): {response.text}"
                    )
                    return False
                elif response.status_code == 401:
                    logger.error("Authentication failed - check your API key")
                    return False
                else:
                    logger.warning(
                        f"Unexpected status code {response.status_code}: {response.text}"
                    )

            except requests.exceptions.Timeout:
                logger.warning(f"Request timeout (attempt {attempt}/{self.config.max_retries})")
            except requests.exceptions.ConnectionError:
                logger.warning(
                    f"Connection error (attempt {attempt}/{self.config.max_retries})"
                )
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request failed: {e}")
            except Exception as e:
                logger.error(f"Unexpected error sending batch: {e}", exc_info=True)
                return False

            # Exponential backoff before retry
            if attempt < self.config.max_retries:
                backoff_time = 2 ** (attempt - 1)  # 1s, 2s, 4s
                logger.debug(f"Retrying in {backoff_time}s...")
                time.sleep(backoff_time)

        logger.warning(
            f"Failed to send batch after {self.config.max_retries} attempts"
        )
        return False

    def close(self):
        """Close the HTTP session."""
        self.session.close()
