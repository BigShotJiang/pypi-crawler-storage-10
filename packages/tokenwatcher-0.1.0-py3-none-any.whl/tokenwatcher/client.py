"""Client wrappers for OpenAI and Anthropic."""

import logging
import time
from typing import Optional, Any, Dict
from functools import wraps

from tokenwatcher.config import Config
from tokenwatcher.event_buffer import EventBuffer
from tokenwatcher.utils import (
    get_current_timestamp,
    extract_error_type,
    extract_error_message,
    sanitize_metadata,
    get_caller_context,
)

logger = logging.getLogger(__name__)


class MonitoredOpenAI:
    """
    Wrapper for OpenAI client that automatically monitors API calls.

    Usage:
        from openai import OpenAI
        from tokenwatcher import MonitoredOpenAI

        client = MonitoredOpenAI(
            OpenAI(api_key="sk-..."),
            api_key="ym_your_key"
        )

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}]
        )
    """

    def __init__(
        self,
        client: Any,
        api_key: str,
        base_url: Optional[str] = None,
        context: Optional[str] = None,
        user_identifier: Optional[str] = None,
        buffer_size: int = 100,
        flush_interval: int = 10,
        enabled: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize monitored OpenAI client.

        Args:
            client: OpenAI client instance
            api_key: Your TokenWatcher API key
            base_url: Backend API URL (optional)
            context: Optional context tag for events
            user_identifier: Optional user identifier
            buffer_size: Max events before auto-flush
            flush_interval: Seconds between auto-flush
            enabled: Whether monitoring is enabled
            metadata: Optional metadata to attach to all events
        """
        self._client = client
        self._config = Config(
            api_key=api_key,
            base_url=base_url,
            context=context,
            user_identifier=user_identifier,
            buffer_size=buffer_size,
            flush_interval=flush_interval,
            enabled=enabled,
        )
        self._buffer = EventBuffer(self._config)
        self._default_metadata = metadata or {}

        # Wrap the chat.completions to monitor calls
        self._wrap_chat_completions()

    def _wrap_chat_completions(self):
        """Wrap chat completions to monitor calls."""
        original_create = self._client.chat.completions.create

        @wraps(original_create)
        def monitored_create(*args, **kwargs):
            return self._monitor_call(
                original_create, "openai", *args, **kwargs
            )

        self._client.chat.completions.create = monitored_create

    def _monitor_call(self, func, provider: str, *args, **kwargs):
        """
        Monitor an LLM API call.

        Args:
            func: Original function to call
            provider: Provider name (openai/anthropic)
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Original function result
        """
        start_time = time.time()
        model = kwargs.get("model", "unknown")

        # Auto-detect context if user didn't provide one
        context = self._config.context or get_caller_context()

        try:
            # Call original function
            response = func(*args, **kwargs)

            # Calculate latency
            latency_ms = int((time.time() - start_time) * 1000)

            # Extract token usage
            usage = getattr(response, "usage", None)
            input_tokens = getattr(usage, "prompt_tokens", None) if usage else None
            output_tokens = getattr(usage, "completion_tokens", None) if usage else None

            # Create event
            event = {
                "timestamp": get_current_timestamp(),
                "provider": provider,
                "model": model,
                "inputTokens": input_tokens,
                "outputTokens": output_tokens,
                "latencyMs": latency_ms,
                "success": True,
                "context": context,
                "userIdentifier": self._config.user_identifier,
                "metadata": sanitize_metadata(self._default_metadata) if self._default_metadata else None,
            }

            # Add to buffer
            self._buffer.add_event(event)

            return response

        except Exception as e:
            # Calculate latency even for errors
            latency_ms = int((time.time() - start_time) * 1000)

            # Create error event
            event = {
                "timestamp": get_current_timestamp(),
                "provider": provider,
                "model": model,
                "latencyMs": latency_ms,
                "success": False,
                "errorMessage": extract_error_message(e),
                "errorType": extract_error_type(e),
                "context": context,
                "userIdentifier": self._config.user_identifier,
                "metadata": sanitize_metadata(self._default_metadata) if self._default_metadata else None,
            }

            # Add to buffer
            self._buffer.add_event(event)

            # Re-raise the original exception
            raise

    def flush(self) -> None:
        """Manually flush buffered events."""
        self._buffer.flush()

    def shutdown(self) -> None:
        """Shutdown monitoring and flush remaining events."""
        self._buffer.shutdown()

    def __getattr__(self, name: str) -> Any:
        """
        Delegate all other attributes to the wrapped client.

        This ensures the monitored client behaves exactly like the original.
        """
        return getattr(self._client, name)

    def __del__(self):
        """Cleanup on garbage collection."""
        try:
            self.shutdown()
        except Exception:
            pass


class MonitoredAnthropic:
    """
    Wrapper for Anthropic client that automatically monitors API calls.

    Usage:
        from anthropic import Anthropic
        from tokenwatcher import MonitoredAnthropic

        client = MonitoredAnthropic(
            Anthropic(api_key="sk-ant-..."),
            api_key="ym_your_key"
        )

        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}]
        )
    """

    def __init__(
        self,
        client: Any,
        api_key: str,
        base_url: Optional[str] = None,
        context: Optional[str] = None,
        user_identifier: Optional[str] = None,
        buffer_size: int = 100,
        flush_interval: int = 10,
        enabled: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize monitored Anthropic client.

        Args:
            client: Anthropic client instance
            api_key: Your TokenWatcher API key
            base_url: Backend API URL (optional)
            context: Optional context tag for events
            user_identifier: Optional user identifier
            buffer_size: Max events before auto-flush
            flush_interval: Seconds between auto-flush
            enabled: Whether monitoring is enabled
            metadata: Optional metadata to attach to all events
        """
        self._client = client
        self._config = Config(
            api_key=api_key,
            base_url=base_url,
            context=context,
            user_identifier=user_identifier,
            buffer_size=buffer_size,
            flush_interval=flush_interval,
            enabled=enabled,
        )
        self._buffer = EventBuffer(self._config)
        self._default_metadata = metadata or {}

        # Wrap the messages.create to monitor calls
        self._wrap_messages()

    def _wrap_messages(self):
        """Wrap messages to monitor calls."""
        original_create = self._client.messages.create

        @wraps(original_create)
        def monitored_create(*args, **kwargs):
            return self._monitor_call(
                original_create, "anthropic", *args, **kwargs
            )

        self._client.messages.create = monitored_create

    def _monitor_call(self, func, provider: str, *args, **kwargs):
        """
        Monitor an LLM API call.

        Args:
            func: Original function to call
            provider: Provider name (openai/anthropic)
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Original function result
        """
        start_time = time.time()
        model = kwargs.get("model", "unknown")

        # Auto-detect context if user didn't provide one
        context = self._config.context or get_caller_context()

        try:
            # Call original function
            response = func(*args, **kwargs)

            # Calculate latency
            latency_ms = int((time.time() - start_time) * 1000)

            # Extract token usage from Anthropic response
            usage = getattr(response, "usage", None)
            input_tokens = getattr(usage, "input_tokens", None) if usage else None
            output_tokens = getattr(usage, "output_tokens", None) if usage else None

            # Create event
            event = {
                "timestamp": get_current_timestamp(),
                "provider": provider,
                "model": model,
                "inputTokens": input_tokens,
                "outputTokens": output_tokens,
                "latencyMs": latency_ms,
                "success": True,
                "context": context,
                "userIdentifier": self._config.user_identifier,
                "metadata": sanitize_metadata(self._default_metadata) if self._default_metadata else None,
            }

            # Add to buffer
            self._buffer.add_event(event)

            return response

        except Exception as e:
            # Calculate latency even for errors
            latency_ms = int((time.time() - start_time) * 1000)

            # Create error event
            event = {
                "timestamp": get_current_timestamp(),
                "provider": provider,
                "model": model,
                "latencyMs": latency_ms,
                "success": False,
                "errorMessage": extract_error_message(e),
                "errorType": extract_error_type(e),
                "context": context,
                "userIdentifier": self._config.user_identifier,
                "metadata": sanitize_metadata(self._default_metadata) if self._default_metadata else None,
            }

            # Add to buffer
            self._buffer.add_event(event)

            # Re-raise the original exception
            raise

    def flush(self) -> None:
        """Manually flush buffered events."""
        self._buffer.flush()

    def shutdown(self) -> None:
        """Shutdown monitoring and flush remaining events."""
        self._buffer.shutdown()

    def __getattr__(self, name: str) -> Any:
        """
        Delegate all other attributes to the wrapped client.

        This ensures the monitored client behaves exactly like the original.
        """
        return getattr(self._client, name)

    def __del__(self):
        """Cleanup on garbage collection."""
        try:
            self.shutdown()
        except Exception:
            pass
