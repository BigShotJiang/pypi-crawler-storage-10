"""Configuration for TokenWatcher SDK."""

import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class Config:
    """Configuration for TokenWatcher monitoring."""

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        context: Optional[str] = None,
        user_identifier: Optional[str] = None,
        buffer_size: int = 100,
        flush_interval: int = 10,
        enabled: bool = True,
        timeout: int = 5,
        max_retries: int = 3,
    ):
        """
        Initialize TokenWatcher configuration.

        Args:
            api_key: Your TokenWatcher API key (must start with 'ym_')
            base_url: Backend API URL (default: from env or https://api.token-watcher.com)
            context: Optional context tag for events (e.g., 'production/chatbot')
            user_identifier: Optional user identifier to associate with events
            buffer_size: Maximum events to buffer before auto-flush (default: 100)
            flush_interval: Seconds between auto-flush (default: 10)
            enabled: Whether monitoring is enabled (default: True)
            timeout: HTTP request timeout in seconds (default: 5)
            max_retries: Maximum retry attempts for failed requests (default: 3)
        """
        self.api_key = api_key
        self.base_url = base_url or os.getenv(
            "TOKENWATCHER_BASE_URL", "https://api.token-watcher.com"
        )
        self.context = context or os.getenv("TOKENWATCHER_CONTEXT")
        self.user_identifier = user_identifier
        self.buffer_size = buffer_size
        self.flush_interval = flush_interval
        self.enabled = enabled
        self.timeout = timeout
        self.max_retries = max_retries

        # Validate API key
        if not self.api_key.startswith("ym_"):
            logger.warning(
                "TokenWatcher API key should start with 'ym_'. Monitoring may not work correctly."
            )

        # Ensure base_url doesn't have trailing slash
        self.base_url = self.base_url.rstrip("/")

    @property
    def events_endpoint(self) -> str:
        """Get the full events endpoint URL."""
        return f"{self.base_url}/api/v1/events/batch"

    def __repr__(self) -> str:
        return (
            f"Config(api_key={'*' * 8}, base_url={self.base_url}, "
            f"context={self.context}, enabled={self.enabled})"
        )
