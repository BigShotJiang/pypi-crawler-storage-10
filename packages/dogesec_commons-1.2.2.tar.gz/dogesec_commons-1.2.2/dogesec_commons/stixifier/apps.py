from django.apps import AppConfig

class StixifierAppConfig(AppConfig):
    name = 'dogesec_commons.stixifier'
    label = 'dogesec_stixifier'