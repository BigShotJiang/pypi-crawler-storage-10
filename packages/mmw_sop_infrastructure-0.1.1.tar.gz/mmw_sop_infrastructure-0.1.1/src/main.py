"""
Application entry point exposing the FastAPI app.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from fastapi import FastAPI

from mmw_infra.api.routers.hitl_router import router as hitl_router
from mmw_infra.api.routers.workflow_router import router as workflow_router
from mmw_infra.execution.chassis.chassis_builder import ChassisBuilder
from mmw_infra.gwo.global_orchestrator import GlobalWorkflowOrchestrator
from mmw_infra.services.coordinator import ServiceCoordinator
from mmw_infra.services.hbs_manager import HBSManager

from mmw_infra.config import get_settings

# Ensure project root on sys.path for scripts launched outside run.py
PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "mmw_infra"
if str(PROJECT_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT.parent))


settings = get_settings()

app = FastAPI(title="MMW SOP Infrastructure API", version="0.1.1")


def _initialize_services() -> None:
    config = {
        "TIMELINE_DB_URL": settings.timeline_db_url,
        "LTM_DB_URL": settings.ltm_db_url,
        "REDIS_URL": settings.redis_url,
    }
    coordinator = ServiceCoordinator(config=config)

    # Load optimisation hints if the knowledge base exists.
    kb_path = Path(settings.optimization_kb_path)
    if kb_path.exists():
        coordinator.optimization_service.load_knowledge_base(str(kb_path))

    infra_bundle = coordinator.get_infra_bundle()
    chassis_builder = ChassisBuilder(infra_bundle)
    hbs_manager = HBSManager()
    orchestrator = GlobalWorkflowOrchestrator(
        infra=infra_bundle, chassis_builder=chassis_builder, hbs_manager=hbs_manager
    )

    app.state.service_coordinator = coordinator
    app.state.infra_bundle = infra_bundle
    app.state.hbs_manager = hbs_manager
    app.state.workflow_orchestrator = orchestrator


@app.on_event("startup")
async def startup_event():
    _initialize_services()


@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "MMW SOP Infrastructure API is running."}


app.include_router(hitl_router)
app.include_router(workflow_router)
