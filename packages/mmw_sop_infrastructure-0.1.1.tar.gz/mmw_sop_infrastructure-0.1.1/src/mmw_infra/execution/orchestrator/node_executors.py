"""
Execution node executor utilities used by the orchestrator.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Tuple

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import AbstractBLE
from mmw_infra.execution.execution_states import ReasoningGraphState


class BaseNodeExecutor:
    """
    Thin wrapper around a BLE for executing a single reasoning node.
    """

    def __init__(self, ble: AbstractBLE):
        self.ble = ble
        self.logger = logging.getLogger("Orchestrator.NodeExecutor")

    async def execute(
        self, node_id: str, state: ReasoningGraphState
    ) -> Dict[str, Any]:
        self.logger.debug("Executing node %s.", node_id)
        return await self.ble.execute_node(node_id, state)


class JoinNodeExecutor:
    """
    Helper to merge multiple node results (e.g. for parallel branches) into the
    reasoning graph state.
    """

    def merge_results(
        self, current_state: ReasoningGraphState, results: Iterable[Tuple[str, Dict[str, Any]]]
    ) -> None:
        node_results = current_state.setdefault("node_results", {})
        pending = current_state.setdefault("pending_interactions", [])
        history = current_state.setdefault("interaction_history", [])

        for node_id, payload in results:
            node_results[node_id] = payload
            pending.extend(payload.get("pending_interactions", []))
            history.extend(payload.get("interaction_history", []))
