from typing import TypedDict, Dict, Any, Optional, List
from uuid import UUID

from mmw_infra.models.sop_schema import WorkflowStep
from mmw_infra.models.execution_state import AutonomyProfile, ExecutionStatus
from mmw_infra.models.hitl_schema import HITL_InteractionRecord


class ChassisState(TypedDict):
    run_id: UUID
    step_definition: WorkflowStep
    blueprint_node_id: str
    problem_type: str
    input_artifact_map: Dict[str, UUID]
    ltm_snapshot_manifest: Dict[str, UUID]
    execution_node_id: Optional[UUID]
    autonomy_profile: Optional[AutonomyProfile]
    optimization_hint: Optional[str]
    inputs: Dict[str, Any]
    execution_results: Dict[str, Any]
    outputs: Dict[str, Any]
    output_artifact_map: Dict[str, UUID]
    pending_interactions: List[HITL_InteractionRecord]
    interaction_history: List[Dict[str, Any]]
    status: ExecutionStatus
    error_message: Optional[str]


class ReasoningGraphState(TypedDict):
    chassis_context: Dict[str, Any]
    node_results: Dict[str, Any]
    completed_nodes: List[str]
    pending_interactions: List[HITL_InteractionRecord]
    interaction_history: List[Dict[str, Any]]
    status: ExecutionStatus
    error_message: Optional[str]

