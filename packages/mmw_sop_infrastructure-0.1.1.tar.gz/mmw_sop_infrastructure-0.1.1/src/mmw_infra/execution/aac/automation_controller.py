from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple

from mmw_infra.common.dependencies import logging, BaseModel
from mmw_infra.common.interfaces import AutonomyProfileServiceInterface
from mmw_infra.execution.execution_states import ReasoningGraphState
from mmw_infra.models.execution_state import (
    AutonomyProfile,
    InteractionControlMode,
)
from mmw_infra.models.hitl_schema import (
    ConfidenceScore,
    HITL_Input,
    HITL_Output,
    HITL_InteractionRecord,
    ContentBlock,
    VARL_Input,
    VARL_Item_Output,
    VARL_Output,
    VARL_Decision,
    SCA_Input,
    SCA_Output,
)


class GenericHITLResult(BaseModel):
    mode: str
    decision: str
    data: Optional[Any] = None


class ConfidenceHelper:
    """Utility for numerical comparison of confidence levels."""

    _scores = {
        ConfidenceScore.LOW: 1,
        ConfidenceScore.MEDIUM: 2,
        ConfidenceScore.HIGH: 3,
    }

    @classmethod
    def get_weight(cls, score: Optional[ConfidenceScore]) -> int:
        if isinstance(score, str):
            try:
                score = ConfidenceScore(score)
            except ValueError:
                return 0
        return cls._scores.get(score, 0)


class ConfidenceEvaluator:
    """
    Analyzes HITL payloads to determine the overall confidence score for Conditional Bypass.
    """

    def extract_lowest_confidence(
        self, presentation: HITL_Input
    ) -> Optional[ConfidenceScore]:
        scores: List[ConfidenceScore] = []

        def find_scores(data: Any) -> None:
            if isinstance(data, ContentBlock) and data.ai_confidence:
                scores.append(data.ai_confidence)
            elif isinstance(data, BaseModel):
                if hasattr(data, "ai_confidence") and getattr(data, "ai_confidence"):
                    scores.append(getattr(data, "ai_confidence"))
                payload = (
                    data.model_dump()
                    if hasattr(data, "model_dump")
                    else data.dict()
                    if hasattr(data, "dict")
                    else getattr(data, "__dict__", {})
                )
                for value in payload.values():
                    find_scores(value)
            elif isinstance(data, list):
                for item in data:
                    find_scores(item)
            elif isinstance(data, dict):
                conf = data.get("ai_confidence")
                if conf:
                    scores.append(conf)
                for value in data.values():
                    find_scores(value)

        find_scores(presentation)

        if not scores:
            return None

        return min(scores, key=ConfidenceHelper.get_weight)


class BypassProtocolExecutor:
    """Implements automated strategies for bypassing various HITL modes."""

    def __init__(self):
        self.logger = logging.getLogger("BypassProtocolExecutor")

    def execute(self, interaction: HITL_InteractionRecord) -> HITL_Output:
        mode = interaction.mode
        presentation = interaction.ai_presentation

        try:
            if mode == "VARL" and isinstance(presentation, VARL_Input):
                return self._bypass_varl(presentation)
            if mode == "SCA" and isinstance(presentation, SCA_Input):
                return self._bypass_sca(presentation)
            if mode in {"EKI", "IS", "AVL", "GBE", "GAC"}:
                return self._bypass_generic(mode)
            if isinstance(presentation, BaseModel):
                self.logger.warning(
                    "Using generic bypass for unrecognized model in mode %s.", mode
                )
                return self._bypass_generic(mode)
            raise NotImplementedError(
                f"Bypass protocol missing or invalid input structure for mode {mode}"
            )
        except Exception as exc:
            self.logger.error(
                "Error during bypass execution for mode %s: %s", mode, exc
            )
            raise RuntimeError(f"Bypass execution failed for mode {mode}.") from exc

    def _bypass_varl(self, input_data: VARL_Input) -> VARL_Output:
        decisions = [
            VARL_Item_Output(
                content_id=item.content_id,
                decision=VARL_Decision.APPROVE,
                reason_text="Automated Approval (Bypass Protocol)",
            )
            for item in input_data.items_to_review
        ]
        return VARL_Output(decisions=decisions)

    def _bypass_sca(self, input_data: SCA_Input) -> SCA_Output:
        selected_id = input_data.ai_recommendation_id
        reason = "Automated Selection (Bypass Protocol): "
        valid_ids = {option.option_id for option in input_data.options}

        if selected_id and selected_id in valid_ids:
            reason += "Selected AI recommended option."
        else:
            if not input_data.options:
                raise ValueError(
                    "SCA bypass failed: no options available and no valid recommendation."
                )
            selected_id = input_data.options[0].option_id
            reason += "Selected first available option (fallback)."

        return SCA_Output(
            selected_option_id=selected_id,
            strategic_rationale=reason,
        )

    def _bypass_generic(self, mode: str) -> GenericHITLResult:
        if mode == "EKI":
            raise RuntimeError(
                "EKI bypass refused: requires expert intervention."
            )
        decisions = {
            "IS": "Accepted preliminary synthesis.",
            "AVL": "Sustained original output.",
            "GBE": "Approved proposed exploration.",
            "GAC": "Go (Proceeded past milestone).",
        }
        decision_text = decisions.get(mode, "Generic automated action.")
        return GenericHITLResult(mode=mode, decision=f"[Automated] {decision_text}")


class AdaptiveAutomationController:
    """
    Central controller for the Skip-HITL mechanism. Determines whether to pause for human input.
    """

    def __init__(self, autonomy_service: AutonomyProfileServiceInterface):
        self.autonomy_service = autonomy_service
        self.bypass_executor = BypassProtocolExecutor()
        self.confidence_evaluator = ConfidenceEvaluator()
        self.logger = logging.getLogger("AdaptiveAutomationController")

    async def process_interactions(
        self,
        interactions: List[HITL_InteractionRecord],
        state: ReasoningGraphState,
    ) -> Tuple[List[Dict[str, Any]], bool]:
        if not interactions:
            return [], False

        chassis_context = state.get("chassis_context", {})
        autonomy_profile: Optional[AutonomyProfile] = chassis_context.get(
            "autonomy_profile"
        )
        if not autonomy_profile:
            self.logger.error(
                "Autonomy profile missing from chassis context; forcing pause."
            )
            return self._serialize_history(interactions), True

        self.logger.info(
            "Processing %d interactions with profile '%s'.",
            len(interactions),
            autonomy_profile.profile_name,
        )

        requires_pause = False
        for interaction in interactions:
            if requires_pause:
                self.logger.debug(
                    "Interaction %s deferred due to prior pause.", interaction.interaction_id
                )
                continue

            control_mode = self.autonomy_service.get_control_mode(
                autonomy_profile,
                interaction.interaction_specific_id,
                interaction.mode,
            )
            self.logger.debug(
                "Interaction %s (%s): control mode = %s",
                interaction.interaction_id,
                interaction.mode,
                control_mode.value,
            )

            if control_mode == InteractionControlMode.MANDATORY:
                requires_pause = True
                interaction.bypass_reason = "Control Mode: Mandatory"
                continue

            if control_mode == InteractionControlMode.FULL_AUTOMATION:
                if not self._attempt_bypass(
                    interaction, "Control Mode: Full Automation"
                ):
                    requires_pause = True
                continue

            if control_mode == InteractionControlMode.CONDITIONAL_BYPASS:
                bypass_allowed, reason = self._evaluate_conditional_bypass(
                    interaction, autonomy_profile
                )
                if bypass_allowed:
                    if not self._attempt_bypass(
                        interaction, f"Conditional Bypass Met: {reason}"
                    ):
                        requires_pause = True
                else:
                    requires_pause = True
                    interaction.bypass_reason = (
                        f"Conditional Bypass Denied: {reason}"
                    )

        history = self._serialize_history(interactions)
        return history, requires_pause

    def _attempt_bypass(
        self, interaction: HITL_InteractionRecord, reason: str
    ) -> bool:
        self.logger.info(
            "Attempting bypass for %s (%s). Reason: %s",
            interaction.interaction_id,
            interaction.mode,
            reason,
        )
        try:
            automated_output = self.bypass_executor.execute(interaction)
            interaction.was_bypassed = True
            interaction.bypass_reason = reason
            interaction.human_input = automated_output
            interaction.timestamp_processed = datetime.now(timezone.utc)
            return True
        except Exception as exc:
            self.logger.error(
                "Bypass attempt failed for %s: %s",
                interaction.interaction_id,
                exc,
            )
            interaction.was_bypassed = False
            interaction.bypass_reason = f"{reason}. Bypass Execution Failed: {exc}"
            interaction.human_input = None
            return False

    def _evaluate_conditional_bypass(
        self, interaction: HITL_InteractionRecord, profile: AutonomyProfile
    ) -> Tuple[bool, str]:
        config = profile.conditional_config
        if not config:
            return False, "Conditional configuration missing."

        min_confidence = self.confidence_evaluator.extract_lowest_confidence(
            interaction.ai_presentation
        )
        if min_confidence is None:
            return False, "No confidence scores available."

        min_weight = ConfidenceHelper.get_weight(min_confidence)
        threshold_weight = ConfidenceHelper.get_weight(config.confidence_threshold)

        min_val = getattr(min_confidence, "value", str(min_confidence))
        threshold_val = getattr(config.confidence_threshold, "value", str(config.confidence_threshold))

        if min_weight >= threshold_weight:
            return True, f"Min confidence ({min_val}) meets threshold ({threshold_val})."
        return False, f"Min confidence ({min_val}) below threshold ({threshold_val})."

    def _serialize_history(
        self, interactions: List[HITL_InteractionRecord]
    ) -> List[Dict[str, Any]]:
        history: List[Dict[str, Any]] = []
        for interaction in interactions:
            if hasattr(interaction, "model_dump"):
                history.append(interaction.model_dump(mode="json"))
            elif hasattr(interaction, "dict"):
                history.append(interaction.dict())
            else:
                history.append(interaction.__dict__)
        return history
