"""
Configuration settings for the infrastructure services.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

try:
    from pydantic_settings import BaseSettings
except ImportError:  # pragma: no cover - fallback when pydantic-settings missing
    from pydantic import BaseSettings  # type: ignore
from pydantic import Field


DEFAULT_OPTIMIZATION_KB_PATH = (
    Path(__file__).resolve().parent / "data" / "optimization_kb.yaml"
)


class Settings(BaseSettings):
    timeline_db_url: str = "sqlite+aiosqlite:///./mmw_timeline.db"
    ltm_db_url: str = "sqlite+aiosqlite:///./mmw_ltm.db"
    hbs_db_url: str = "sqlite+aiosqlite:///./mmw_hbs.db"

    redis_url: str = "redis://localhost:6379/0"
    optimization_kb_path: str = Field(default=str(DEFAULT_OPTIMIZATION_KB_PATH))

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
