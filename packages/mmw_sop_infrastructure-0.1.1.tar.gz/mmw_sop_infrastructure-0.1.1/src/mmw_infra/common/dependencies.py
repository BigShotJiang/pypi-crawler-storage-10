"""
Centralized dependency management for the MMW SOP Infrastructure.
This module imports all required dependencies directly.
"""
import logging
import sys
from typing import Any, Annotated, TypedDict

# --- Pydantic ---
from pydantic import BaseModel, Field, ConfigDict, Json, ValidationError, model_validator, TypeAdapter

# --- LangChain & LangGraph ---
from langchain_core.runnables import Runnable
from langchain_core.prompts.base import BasePromptTemplate
from langchain_core.prompts import PromptTemplate
from langchain_core.language_models import BaseLanguageModel
from langchain_core.exceptions import OutputParserException
from langchain_core.output_parsers import PydanticOutputParser, JsonOutputParser, StrOutputParser
from langchain_core.runnables.config import RunnableConfig

from langgraph.graph import StateGraph, END, CompiledGraph
from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata
from langgraph.channels.base import EmptyChannelError

# --- FastAPI ---
from fastapi import FastAPI, Depends, HTTPException, status, APIRouter
from fastapi.responses import JSONResponse
import uvicorn

# --- SQLAlchemy ---
import sqlalchemy
from sqlalchemy import create_engine, Column, String, DateTime, Text, ForeignKey, JSON, Boolean, Table, event, update, bindparam
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship, joinedload
from sqlalchemy.types import TypeDecorator, CHAR
from sqlalchemy.exc import SQLAlchemyError

# --- Redis ---
import redis
from redis import Redis
from redis.exceptions import ConnectionError as RedisConnectionError

# --- NetworkX ---
import networkx as nx

# --- PyYAML ---
import yaml

# --- Docker ---
import docker
from docker.errors import APIError, ImageNotFound, NotFound
from requests.exceptions import ReadTimeout as DockerTimeoutError