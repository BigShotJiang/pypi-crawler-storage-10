from typing import Dict, Any, Optional, List, Union, Literal, ForwardRef
from enum import Enum

from ..common.dependencies import (
    BaseModel,
    Field,
    model_validator,
    ConfigDict,
    PYDANTIC_AVAILABLE,
)

# Forward declaration for recursive typing
ExecutionElement = ForwardRef("ExecutionElement")


class DataPort(BaseModel):
    """
    Represents a single input or output data port for a workflow step.
    Defines the metadata and schema expectations for data exchange.
    """

    name: str = Field(
        ...,
        description="The unique name of the data port (e.g., 'Formal Problem Restatement').",
    )
    description: str = Field(
        ...,
        description="A detailed description of the data content and purpose.",
    )
    data_type_hint: str = Field(
        ...,
        description="The expected data type hint (e.g., 'str', 'DataFrame', 'PydanticModelName').",
    )
    required: bool = Field(
        True,
        description="Whether this port is mandatory.",
    )


class IO_Interface(BaseModel):
    """
    Defines the complete Input/Output contract for a workflow step.
    """

    inputs: Dict[str, DataPort] = Field(
        default_factory=dict,
        description="Dictionary of input data ports, keyed by port name.",
    )
    outputs: Dict[str, DataPort] = Field(
        default_factory=dict,
        description="Dictionary of output data ports, keyed by port name.",
    )


class ReasoningNode(BaseModel):
    """
    Represents an atomic unit of work (a specific 'Reasoning Path') within a WorkflowStep.
    """

    type: Literal["Node"] = "Node"  # Discriminator field
    id: str = Field(
        ...,
        description="Unique identifier for the reasoning node (e.g., '1.1-RP1').",
    )
    name: str = Field(
        ...,
        description="Descriptive name of the reasoning path (e.g., 'Semantic Deconstruction').",
    )
    description: str = Field(
        ...,
        description="The detailed description of the reasoning path from the SOP.",
    )


class BlockBase(BaseModel):
    """Base class for execution blocks."""

    description: Optional[str] = Field(
        None,
        description="Optional description for the block (e.g., 'Track A: Hypothesis Generation').",
    )


class SerialBlock(BlockBase):
    """
    [串行] Executes elements sequentially.
    """

    type: Literal["Serial"] = "Serial"  # Discriminator field
    elements: List[ExecutionElement] = Field(
        ...,
        description="The ordered list of elements to execute sequentially.",
    )


class ParallelBlock(BlockBase):
    """
    [并行] Executes elements independently in parallel. Synchronization occurs after the block completes.
    """

    type: Literal["Parallel"] = "Parallel"  # Discriminator field
    elements: List[ExecutionElement] = Field(
        ...,
        description="The list of elements to execute in parallel.",
    )


class ConcurrentBlock(BlockBase):
    """
    [并发/迭代] Executes elements concurrently with potential iteration/interdependency.
    """

    type: Literal["Concurrent"] = "Concurrent"  # Discriminator field
    elements: List[ReasoningNode] = Field(
        ...,
        description="The list of tightly coupled nodes to execute concurrently/iteratively.",
    )
    iteration_details: Optional[str] = Field(
        None,
        description="Description of the iteration mechanism or exit condition.",
    )


if PYDANTIC_AVAILABLE:
    from ..common.dependencies import Annotated  # type: ignore

    ExecutionBlock = Annotated[
        Union[SerialBlock, ParallelBlock, ConcurrentBlock],
        Field(discriminator="type"),
    ]
    ExecutionElement = Annotated[
        Union[ReasoningNode, ExecutionBlock],
        Field(discriminator="type"),
    ]
    if hasattr(SerialBlock, "model_rebuild"):
        SerialBlock.model_rebuild()
        ParallelBlock.model_rebuild()
else:
    ExecutionBlock = Union[SerialBlock, ParallelBlock, ConcurrentBlock]
    ExecutionElement = Union[ReasoningNode, SerialBlock, ParallelBlock, ConcurrentBlock]


class ReasoningGraph(BaseModel):
    """
    Defines the complete execution structure of the Reasoning Paths within a WorkflowStep.
    """

    root_flow: ExecutionBlock = Field(
        ...,
        description="The root ExecutionBlock defining the execution flow.",
    )

    @model_validator(mode="after")
    def validate_node_ids_unique(self):
        """Ensures all node IDs within the graph are unique."""
        seen_ids = set()

        def traverse(element: ExecutionElement):
            if isinstance(element, ReasoningNode):
                if element.id in seen_ids:
                    raise ValueError(f"Duplicate reasoning node ID detected: {element.id}")
                seen_ids.add(element.id)
            elif isinstance(element, (SerialBlock, ParallelBlock)):
                for sub_element in element.elements:
                    traverse(sub_element)
            elif isinstance(element, ConcurrentBlock):
                for node in element.elements:
                    traverse(node)

        traverse(self.root_flow)
        return self


class WorkflowStep(BaseModel):
    """
    Represents an executable SOP step, including its IO interface and reasoning graph.
    """

    id: str = Field(
        ...,
        description="Unique identifier for the step (e.g., '1.1').",
    )
    name: str = Field(
        ...,
        description="The formal name of the step.",
    )
    core_objective: str = Field(
        ...,
        description="The primary goal and expected outcome of the step.",
    )
    io_interface: IO_Interface = Field(
        ...,
        description="The Input/Output contract for the step.",
    )
    reasoning_graph: ReasoningGraph = Field(
        ...,
        description="The internal execution logic and reasoning paths.",
    )


class WorkflowPhase(str, Enum):
    """Defines the major phases of the MMW SOP workflow."""

    PHASE_1 = "Phase 1: Strategic Analysis & Macro Architecture"
    PHASE_2 = "Phase 2: Cyclic Sub-problem Execution"
    PHASE_3 = "Phase 3: Global Synthesis & Paper Forging"


class BlueprintNode(BaseModel):
    """
    Represents an instance of a WorkflowStep within the blueprint DAG.
    """

    node_id: str = Field(
        ...,
        description="Unique ID for this node instance within the blueprint.",
    )
    step_id: str = Field(
        ...,
        description="The ID of the WorkflowStep this node represents.",
    )
    phase: WorkflowPhase = Field(
        ...,
        description="The phase this node belongs to.",
    )
    is_cyclic: bool = Field(
        False,
        description="Indicates if this node is part of a cyclic execution sequence.",
    )


class BlueprintEdge(BaseModel):
    """
    Represents a dependency and data flow between two nodes in the blueprint DAG.
    """

    source_node_id: str = Field(..., description="The ID of the source node.")
    target_node_id: str = Field(..., description="The ID of the target node.")
    data_mapping: Dict[str, str] = Field(
        ...,
        description="Explicit data mapping: {Source Output Port Name: Target Input Port Name}.",
    )


class ArchitecturalBlueprint(BaseModel):
    """
    The complete definition of the MMW SOP workflow structure and execution DAG.
    """

    workflow_name: str = Field(..., description="Name of the workflow.")
    version: str = Field(..., description="Version identifier for the SOP definition.")
    steps_registry: Dict[str, WorkflowStep] = Field(
        ...,
        description="Dictionary of all WorkflowStep definitions, keyed by Step ID.",
    )
    nodes: List[BlueprintNode] = Field(
        ...,
        description="List of all nodes (step instances) in the blueprint.",
    )
    edges: List[BlueprintEdge] = Field(
        ...,
        description="List of all edges (dependencies and data flows) defining the DAG.",
    )
    start_node_id: str = Field(
        ...,
        description="The ID of the entry node for the workflow.",
    )

    model_config = ConfigDict(use_enum_values=True)

    @model_validator(mode="after")
    def validate_blueprint_integrity(self):
        """Ensures the DAG structure is sound and references are valid."""
        node_ids = {node.node_id for node in self.nodes}
        registry_keys = self.steps_registry.keys()

        for node in self.nodes:
            if node.step_id not in registry_keys:
                raise ValueError(
                    f"Node '{node.node_id}' references unknown step_id '{node.step_id}'."
                )

        for edge in self.edges:
            if edge.source_node_id not in node_ids:
                raise ValueError(
                    f"Edge source '{edge.source_node_id}' not found in blueprint nodes."
                )
            if edge.target_node_id not in node_ids:
                raise ValueError(
                    f"Edge target '{edge.target_node_id}' not found in blueprint nodes."
                )

        if self.start_node_id not in node_ids:
            raise ValueError(
                f"Start node ID '{self.start_node_id}' not found in blueprint nodes."
            )

        return self


class ProblemType(str, Enum):
    """Standard problem type taxonomy for optimization hints."""

    TYPE_A_CONTINUOUS = "Type A (Continuous)"
    TYPE_B_DISCRETE_NETWORK = "Type B (Discrete/Network)"
    TYPE_C_DATA_INSIGHTS = "Type C (Data Insights)"
    TYPE_D_OPERATIONS_OPTIMIZATION = "Type D (Operations/Optimization)"
    TYPE_E_ENVIRONMENT_SUSTAINABILITY = "Type E (Environment/Sustainability)"
    TYPE_F_POLICY_SOCIAL_SCIENCE = "Type F (Policy/Social Science)"
    TYPE_G_GENERAL = "Type G (General/Fallback)"


class StepOptimizationHints(BaseModel):
    """Mapping of workflow step IDs to optimization hint strings."""

    hints: Dict[str, str] = Field(default_factory=dict)


class ProblemTypeConfiguration(BaseModel):
    """Configuration block for a specific problem type."""

    problem_type: ProblemType = Field(...)
    description: Optional[str] = None
    optimizations: StepOptimizationHints = Field(...)


class OptimizationKnowledgeBase(BaseModel):
    """Structured representation of the optimization knowledge base YAML file."""

    version: str = Field(...)
    configurations: List[ProblemTypeConfiguration] = Field(...)

    @model_validator(mode="after")
    def ensure_integrity_and_fallback(self):
        if not PYDANTIC_AVAILABLE:
            return self

        found_general = False
        seen_types = set()
        for config in self.configurations:
            problem_type = config.problem_type
            if problem_type in seen_types:
                raise ValueError(
                    f"Duplicate configuration found for Problem Type: {problem_type.value}"
                )
            seen_types.add(problem_type)
            if problem_type == ProblemType.TYPE_G_GENERAL:
                found_general = True

        if not found_general:
            raise ValueError(
                f"Mandatory fallback configuration '{ProblemType.TYPE_G_GENERAL.value}' is missing."
            )
        return self
