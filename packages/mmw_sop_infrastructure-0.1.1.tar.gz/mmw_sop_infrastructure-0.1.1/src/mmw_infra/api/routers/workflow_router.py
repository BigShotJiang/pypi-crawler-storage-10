"""
Workflow orchestration API endpoints.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, status

from mmw_infra.common.dependencies import BaseModel, Field
from mmw_infra.common.interfaces import GWOInterface
from mmw_infra.models.hitl_schema import HITL_Output

router = APIRouter(prefix="/workflow", tags=["Workflow"])


class StartRunRequest(BaseModel):
    blueprint_id: str = Field(..., description="Identifier of the blueprint to execute.")
    run_id: Optional[UUID] = Field(
        None, description="Optional run identifier (auto-generated if omitted)."
    )
    problem_type: str = Field(..., description="Problem type key for optimisation hints.")
    autonomy_profile_id: Optional[UUID] = Field(
        None, description="Optional autonomy profile override."
    )


class ResumeRunRequest(BaseModel):
    interaction_id: UUID = Field(..., description="Identifier of the HITL interaction.")
    human_input: HITL_Output = Field(..., description="Resolved HITL payload.")


def get_orchestrator(request: Request) -> GWOInterface:
    orchestrator: Optional[GWOInterface] = getattr(
        request.app.state, "workflow_orchestrator", None
    )
    if not orchestrator:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Workflow orchestrator not initialised.",
        )
    return orchestrator


@router.post("/runs")
async def start_run(
    payload: StartRunRequest, orchestrator: GWOInterface = Depends(get_orchestrator)
):
    run_id = payload.run_id or uuid4()
    result = await orchestrator.start_run(
        blueprint_id=payload.blueprint_id,
        run_id=run_id,
        problem_type=payload.problem_type,
        autonomy_profile_id=payload.autonomy_profile_id,
    )
    return {"run_id": str(run_id), **result}


@router.post("/runs/{run_id}/resume")
async def resume_run(
    run_id: UUID,
    payload: ResumeRunRequest,
    orchestrator: GWOInterface = Depends(get_orchestrator),
):
    result = await orchestrator.resume_after_hitl(
        run_id=run_id,
        interaction_id=payload.interaction_id,
        human_input=payload.human_input,
    )
    return {"run_id": str(run_id), **result}
