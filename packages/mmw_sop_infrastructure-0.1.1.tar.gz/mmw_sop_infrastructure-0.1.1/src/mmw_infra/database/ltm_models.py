from uuid import uuid4
from datetime import datetime, timezone

from sqlalchemy import Column, String, DateTime, Text, JSON
from sqlalchemy.orm import declarative_base

from mmw_infra.common.utils import GUID

Base = declarative_base()


class ArtifactDB(Base):
    __tablename__ = "ltm_artifacts"

    artifact_id = Column(GUID, primary_key=True, default=uuid4)
    run_id = Column(GUID, nullable=False, index=True)
    producer_step_id = Column(String(50), nullable=False)
    producer_execution_node_id = Column(GUID, nullable=False)
    port_name = Column(String(100), nullable=False)
    data_type_hint = Column(String(100), nullable=False)
    data = Column(Text, nullable=False)
    timestamp_created = Column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class SnapshotDB(Base):
    __tablename__ = "ltm_snapshots"

    snapshot_id = Column(GUID, primary_key=True, default=uuid4)
    run_id = Column(GUID, nullable=False, index=True)
    associated_execution_node_id = Column(GUID, nullable=False)
    artifact_manifest = Column(JSON, nullable=False)

