"""
Core building blocks for the Global Workflow Orchestrator.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Tuple, Type
from uuid import UUID

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import AbstractBLE, ChassisBuilderInterface, InfrastructureServices
from mmw_infra.execution.execution_states import ChassisState
from mmw_infra.models.execution_state import ExecutionStatus
from mmw_infra.models.hitl_schema import HITL_InteractionRecord
from mmw_infra.models.sop_schema import ArchitecturalBlueprint, BlueprintEdge, BlueprintNode, WorkflowStep


class GWOState(Dict[str, Any]):
    """Mutable state dictionary carried through the workflow execution."""


class GWONodeExecutor:
    """
    Adapter that invokes the chassis subgraph for a single blueprint node.
    """

    def __init__(
        self,
        blueprint: ArchitecturalBlueprint,
        node: BlueprintNode,
        subgraph,
        infra: InfrastructureServices,
    ) -> None:
        self.blueprint = blueprint
        self.node = node
        self.subgraph = subgraph
        self.infra = infra
        self.logger = logging.getLogger(f"GWO.Node.{node.node_id}")

    async def __call__(self, state: GWOState) -> Dict[str, Any]:
        step_def = self.blueprint.steps_registry[self.node.step_id]
        chassis_state: ChassisState = {
            "run_id": state["run_id"],
            "step_definition": step_def,
            "blueprint_node_id": self.node.node_id,
            "problem_type": state["problem_type"],
            "input_artifact_map": self._resolve_input_artifacts(state),
            "ltm_snapshot_manifest": state.get("ltm_snapshot_manifest", {}),
            "execution_node_id": None,
            "autonomy_profile": None,
            "optimization_hint": None,
            "inputs": {},
            "execution_results": {},
            "outputs": {},
            "output_artifact_map": {},
            "pending_interactions": [],
            "interaction_history": [],
            "status": ExecutionStatus.PENDING,
            "error_message": None,
        }

        final_chassis_state = await self.subgraph.ainvoke(chassis_state)
        return self._update_gwo_state(state, final_chassis_state)

    def _resolve_input_artifacts(self, state: GWOState) -> Dict[str, UUID]:
        inputs: Dict[str, UUID] = {}
        node_outputs: Dict[str, Dict[str, UUID]] = state.get("node_outputs", {})

        for edge in self._incoming_edges():
            source_outputs = node_outputs.get(edge.source_node_id, {})
            for source_port, target_port in edge.data_mapping.items():
                artifact_id = source_outputs.get(source_port)
                if artifact_id:
                    inputs[target_port] = artifact_id
                else:
                    self.logger.warning(
                        "Missing artifact for mapping %s -> %s from node %s.",
                        source_port,
                        target_port,
                        edge.source_node_id,
                    )
        return inputs

    def _incoming_edges(self) -> List[BlueprintEdge]:
        return [
            edge
            for edge in self.blueprint.edges
            if edge.target_node_id == self.node.node_id
        ]

    def _update_gwo_state(
        self, gwo_state: GWOState, chassis_state: ChassisState
    ) -> Dict[str, Any]:
        status = chassis_state.get("status", ExecutionStatus.COMPLETED)
        update: Dict[str, Any] = {"status": status}

        if status == ExecutionStatus.COMPLETED:
            outputs = chassis_state.get("output_artifact_map", {})
            node_outputs = dict(gwo_state.get("node_outputs", {}))
            node_outputs[self.node.node_id] = outputs
            update["node_outputs"] = node_outputs

            manifest = dict(gwo_state.get("ltm_snapshot_manifest", {}))
            manifest.update(
                {
                    f"{self.node.node_id}.{port}": artifact_id
                    for port, artifact_id in outputs.items()
                }
            )
            update["ltm_snapshot_manifest"] = manifest
        elif status == ExecutionStatus.PAUSED_HITL:
            update["pending_interactions"] = chassis_state.get(
                "pending_interactions", []
            )
            history = list(gwo_state.get("interaction_history", []))
            history.extend(chassis_state.get("interaction_history", []))
            update["interaction_history"] = history
        elif status == ExecutionStatus.FAILED:
            update["error_message"] = chassis_state.get(
                "error_message", f"Node {self.node.node_id} failed."
            )

        return update


class BLERegistry:
    """Maintains the mapping between Step IDs and BLE implementations."""

    def __init__(self) -> None:
        self._registry: Dict[str, Type[AbstractBLE]] = {}

    def register(self, step_id: str, ble_class: Type[AbstractBLE]) -> None:
        self._registry[step_id] = ble_class

    def get_class(self, step_id: str) -> Type[AbstractBLE]:
        ble_class = self._registry.get(step_id)
        if not ble_class:
            raise KeyError(f"No BLE registered for step '{step_id}'.")
        return ble_class


class CompiledBlueprint:
    """Container for compiled node executors and execution ordering."""

    def __init__(
        self,
        blueprint: ArchitecturalBlueprint,
        executors: Dict[str, GWONodeExecutor],
        adjacency: Dict[str, List[str]],
    ) -> None:
        self.blueprint = blueprint
        self.executors = executors
        self.adjacency = adjacency
        self.entry_point = blueprint.start_node_id

    def execution_order(self) -> List[str]:
        """
        Compute a deterministic topological order using Kahn's algorithm.
        """
        in_degree: Dict[str, int] = defaultdict(int)
        for target_list in self.adjacency.values():
            for target in target_list:
                in_degree[target] += 1

        queue = deque(
            node.node_id
            for node in self.blueprint.nodes
            if in_degree[node.node_id] == 0
        )
        order: List[str] = []

        while queue:
            node_id = queue.popleft()
            order.append(node_id)
            for successor in self.adjacency.get(node_id, []):
                in_degree[successor] -= 1
                if in_degree[successor] == 0:
                    queue.append(successor)

        return order


class BlueprintCompiler:
    """
    Compiles an `ArchitecturalBlueprint` into executable node adapters.
    """

    def __init__(
        self,
        chassis_builder: ChassisBuilderInterface,
        ble_registry: BLERegistry,
        infra: InfrastructureServices,
    ) -> None:
        self.chassis_builder = chassis_builder
        self.ble_registry = ble_registry
        self.infra = infra
        self.logger = logging.getLogger("GWO.Compiler")

    def compile(self, blueprint: ArchitecturalBlueprint) -> CompiledBlueprint:
        executors: Dict[str, GWONodeExecutor] = {}

        for node in blueprint.nodes:
            step_def: WorkflowStep = blueprint.steps_registry[node.step_id]
            ble_class = self.ble_registry.get_class(node.step_id)
            subgraph = self.chassis_builder.build_subgraph(step_def, ble_class)
            executors[node.node_id] = GWONodeExecutor(
                blueprint, node, subgraph, self.infra
            )

        adjacency: Dict[str, List[str]] = defaultdict(list)
        for edge in blueprint.edges:
            adjacency[edge.source_node_id].append(edge.target_node_id)

        return CompiledBlueprint(blueprint, executors, adjacency)
