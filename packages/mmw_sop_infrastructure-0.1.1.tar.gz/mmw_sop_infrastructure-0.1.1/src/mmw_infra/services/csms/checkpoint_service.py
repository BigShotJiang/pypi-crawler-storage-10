import pickle
from typing import Optional, Tuple, List, AsyncIterator

from mmw_infra.common.dependencies import (
    LANGGRAPH_AVAILABLE,
    logging,
    Redis,
    BaseCheckpointSaver,
    Checkpoint,
    CheckpointMetadata,
    RunnableConfig,
)


class RedisCheckpointSaver(BaseCheckpointSaver if LANGGRAPH_AVAILABLE else object):
    """
    High-speed checkpointing implementation using Redis, adhering to the LangGraph interface.
    """

    def __init__(self, redis_client: Redis):
        if LANGGRAPH_AVAILABLE:
            super().__init__()
        self.client = redis_client
        self.is_mocked = type(redis_client).__name__ == "MockRedis"
        logging.info("RedisCheckpointSaver initialized (Mocked=%s).", self.is_mocked)

    def _get_key(self, thread_id: str, checkpoint_id: Optional[str] = None) -> str:
        if checkpoint_id:
            return f"mmw:checkpoints:{thread_id}:{checkpoint_id}"
        return f"mmw:checkpoints:{thread_id}:latest"

    def get_tuple(
        self, config: RunnableConfig
    ) -> Optional[Tuple[Checkpoint, CheckpointMetadata]]:
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            raise ValueError("thread_id is required in config['configurable'].")

        checkpoint_id = config.get("configurable", {}).get("thread_ts")
        key = self._get_key(thread_id, checkpoint_id)

        try:
            data = self.client.get(key)
            if data:
                return pickle.loads(data)

            if checkpoint_id:
                return None

            latest_key = self._get_key(thread_id)
            if key != latest_key:
                latest_data = self.client.get(latest_key)
                if latest_data:
                    return pickle.loads(latest_data)
        except Exception as exc:
            logging.error(
                "Error during get_tuple (Redis or deserialization) for thread %s: %s",
                thread_id,
                exc,
            )
            return None

        return None

    def list(self, config: RunnableConfig) -> List[Tuple[Checkpoint, CheckpointMetadata]]:
        logging.warning(
            "RedisCheckpointSaver.list() is partially implemented (returns only latest)."
        )
        latest = self.get_tuple(config)
        return [latest] if latest else []

    def put_tuple(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
    ) -> None:
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            raise ValueError("thread_id is required in config['configurable'].")

        checkpoint_id = checkpoint.get("ts")
        if not checkpoint_id:
            raise ValueError("Checkpoint must contain 'ts' field.")

        key = self._get_key(thread_id, checkpoint_id)
        latest_key = self._get_key(thread_id)

        try:
            data = pickle.dumps((checkpoint, metadata))
        except Exception as exc:
            logging.error("Failed to serialize checkpoint data: %s", exc)
            raise

        try:
            pipe = self.client.pipeline()
            pipe.set(key, data)
            pipe.set(latest_key, data)
            pipe.execute()
            logging.debug(
                "Checkpoint %s saved for thread %s.", checkpoint_id, thread_id
            )
        except Exception as exc:
            logging.error(
                "Error during put_tuple (Redis operation) for thread %s: %s",
                thread_id,
                exc,
            )
            raise

    async def aget_tuple(
        self, config: RunnableConfig
    ) -> Optional[Tuple[Checkpoint, CheckpointMetadata]]:
        return self.get_tuple(config)

    async def alist(
        self, config: RunnableConfig
    ) -> AsyncIterator[Tuple[Checkpoint, CheckpointMetadata]]:
        for item in self.list(config):
            yield item
        if False:  # pragma: no cover - sentinel to mark async generator
            yield

    async def aput_tuple(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
    ) -> None:
        self.put_tuple(config, checkpoint, metadata)
