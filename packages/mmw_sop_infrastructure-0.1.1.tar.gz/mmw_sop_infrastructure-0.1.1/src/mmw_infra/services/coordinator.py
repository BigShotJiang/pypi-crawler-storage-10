from types import SimpleNamespace
from typing import Any, Dict, Optional

from mmw_infra.common.dependencies import logging, Redis, RedisConnectionError
from mmw_infra.services.csms.ltm_service import LTMService
from mmw_infra.services.csms.checkpoint_service import RedisCheckpointSaver
from mmw_infra.services.csms.timeline_service import TimelineService
from mmw_infra.services.csms.csms_service import CSMSService
from mmw_infra.services.cks.optimization_service import OptimizationHintService
from mmw_infra.services.cks.autonomy_service import AutonomyProfileService
from mmw_infra.services.dtias.dtia_service import DTIAService
from mmw_infra.services.ses.sandbox_models import SESEnvironmentConfig
from mmw_infra.services.ses.sandbox_service import SecureExecutionService


class ServiceCoordinator:
    """
    Aggregates and wires together infrastructure services with sensible defaults.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        config = config or {}
        logging.info("Initializing infrastructure services...")

        timeline_db_url = config.get("TIMELINE_DB_URL", "sqlite:///mmw_timeline.db")
        ltm_db_url = config.get("LTM_DB_URL", "sqlite:///mmw_ltm.db")
        redis_url = config.get("REDIS_URL")

        self.timeline_service = TimelineService(db_url=timeline_db_url)
        self.ltm_service = LTMService(db_url=ltm_db_url)
        self.checkpoint_saver = self._initialize_checkpoint_saver(redis_url)
        self.csms_service = CSMSService(self.ltm_service, self.checkpoint_saver)

        self.dtias_service = DTIAService(timeline_service=self.timeline_service)
        self.timeline_service.set_dtias(self.dtias_service)

        self.autonomy_service = AutonomyProfileService()
        self.optimization_service = OptimizationHintService()

        ses_config = config.get("SES_CONFIG")
        if isinstance(ses_config, SESEnvironmentConfig):
            default_ses_config = ses_config
        elif isinstance(ses_config, dict):
            default_ses_config = SESEnvironmentConfig(**ses_config)
        else:
            default_ses_config = SESEnvironmentConfig()
        self.ses_service = SecureExecutionService(default_config=default_ses_config)
        self._infra_bundle = SimpleNamespace(
            timeline_service=self.timeline_service,
            dtias_service=self.dtias_service,
            csms=self.csms_service,
            autonomy_service=self.autonomy_service,
            optimization_service=self.optimization_service,
            ses_service=self.ses_service,
            checkpoint_saver=self.checkpoint_saver,
        )

    def _initialize_checkpoint_saver(
        self, redis_url: Optional[str]
    ) -> Optional[RedisCheckpointSaver]:
        if not redis_url:
            logging.warning("Redis URL not provided. Checkpointing disabled.")
            return None

        try:
            client = Redis.from_url(redis_url, decode_responses=False)
            client.ping()
            logging.info("Connected to Redis at %s", redis_url)
            return RedisCheckpointSaver(client)
        except RedisConnectionError as exc:
            logging.error("Failed to connect to Redis (%s). Checkpointing disabled.", exc)
        except Exception as exc:  # pragma: no cover - defensive logging
            logging.error("Unexpected Redis initialization error: %s", exc)
        return None

    def get_infra_bundle(self) -> SimpleNamespace:
        """Returns an object exposing shared infrastructure services."""
        return self._infra_bundle

