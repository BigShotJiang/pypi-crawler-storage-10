import os
from typing import Dict, Any, Optional

from mmw_infra.common.dependencies import (
    logging,
    PYDANTIC_AVAILABLE,
    PYYAML_AVAILABLE,
    yaml,
)
from mmw_infra.models.sop_schema import (
    ProblemType,
    StepOptimizationHints,
    ProblemTypeConfiguration,
    OptimizationKnowledgeBase,
)


class OptimizationHintService:
    """
    Configuration & Knowledge Service (CKS) component for managing optimization hints.
    """

    def __init__(self):
        self.knowledge_base: Optional[OptimizationKnowledgeBase] = None
        self._lookup_table: Dict[ProblemType, Dict[str, str]] = {}
        self.is_initialized = False
        logging.info("OptimizationHintService initialized.")

    def load_knowledge_base(self, file_path: str) -> None:
        if not os.path.exists(file_path):
            logging.error("Knowledge base file not found at %s", file_path)
            raise FileNotFoundError(f"Knowledge Base file not found: {file_path}")

        if not PYYAML_AVAILABLE:
            logging.error("PyYAML dependency is not available; cannot load knowledge base.")
            raise ImportError("PyYAML is not installed.")

        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                data = yaml.safe_load(handle)
            self._process_loaded_data(data)
            logging.info(
                "Successfully loaded Optimization Knowledge Base from %s.", file_path
            )
        except Exception as exc:
            error_type = type(exc).__name__
            logging.error(
                "Error (%s) loading or validating Knowledge Base file '%s': %s",
                error_type,
                file_path,
                exc,
            )
            self.knowledge_base = None
            self._lookup_table = {}
            self.is_initialized = False
            raise

    def _process_loaded_data(self, data: Dict[str, Any]) -> None:
        if PYDANTIC_AVAILABLE:
            self.knowledge_base = OptimizationKnowledgeBase.model_validate(data)
        else:
            logging.warning(
                "Pydantic unavailable. Performing minimal structural validation of knowledge base."
            )
            if not isinstance(data, dict) or "configurations" not in data:
                raise ValueError("Invalid knowledge base structure (missing 'configurations').")

            configs = []
            for cfg_data in data.get("configurations", []):
                try:
                    problem_type_enum = ProblemType(cfg_data.get("problem_type"))
                except ValueError:
                    logging.warning(
                        "Unknown problem type '%s' encountered; skipping entry.",
                        cfg_data.get("problem_type"),
                    )
                    continue

                hints = cfg_data.get("optimizations", {}).get("hints", {})
                pt_config = ProblemTypeConfiguration(
                    problem_type=problem_type_enum,
                    optimizations=StepOptimizationHints(hints=hints),
                    description=cfg_data.get("description"),
                )
                configs.append(pt_config)

            self.knowledge_base = OptimizationKnowledgeBase(
                version=data.get("version", "unknown"), configurations=configs
            )

        self._build_lookup_table()
        self.is_initialized = True

    def _build_lookup_table(self) -> None:
        if not self.knowledge_base:
            return

        self._lookup_table = {}
        for config in self.knowledge_base.configurations:
            try:
                problem_type_key = (
                    config.problem_type
                    if isinstance(config.problem_type, ProblemType)
                    else ProblemType(config.problem_type)
                )
                self._lookup_table[problem_type_key] = dict(config.optimizations.hints)
            except ValueError as exc:
                logging.error(
                    "Invalid problem type '%s' encountered while building lookup table: %s",
                    config.problem_type,
                    exc,
                )

    def get_optimization_hint(
        self, problem_type: ProblemType, step_id: str
    ) -> Optional[str]:
        if not self.is_initialized or not self._lookup_table:
            return None

        specific_config = self._lookup_table.get(problem_type)
        if specific_config and step_id in specific_config:
            return specific_config[step_id]

        if problem_type != ProblemType.TYPE_G_GENERAL:
            general_config = self._lookup_table.get(ProblemType.TYPE_G_GENERAL)
            if general_config and step_id in general_config:
                return general_config[step_id]

        return None

