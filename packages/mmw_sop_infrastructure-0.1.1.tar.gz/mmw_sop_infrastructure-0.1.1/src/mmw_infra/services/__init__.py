"""
Service package exports.

The coordinator pulls in optional dependencies (e.g., Docker) so we import lazily
to avoid hard failures when those extras are unavailable.
"""
from importlib import import_module

__all__ = ["ServiceCoordinator", "HBSManager"]


def __getattr__(name):
    if name == "ServiceCoordinator":
        return import_module(".coordinator", __name__).ServiceCoordinator
    if name == "HBSManager":
        return import_module(".hbs_manager", __name__).HBSManager
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
