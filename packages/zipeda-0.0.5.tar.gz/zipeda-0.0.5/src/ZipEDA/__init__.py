from .zipeda import zipeda

__all__ = ["zipeda"]