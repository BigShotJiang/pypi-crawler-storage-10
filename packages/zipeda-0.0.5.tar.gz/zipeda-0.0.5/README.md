ZipEDA is a quick and simply Exploratory Data Analysis tool to assist in this important phase of data analytics and science projects.

A simple usage would be:

zipeda(df, target_variable='Column_name')