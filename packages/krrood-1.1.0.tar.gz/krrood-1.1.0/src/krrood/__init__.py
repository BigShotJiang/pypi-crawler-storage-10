import importlib.metadata
import logging

__version__ = "1.1.0"


logger = logging.Logger("krrood")
logger.setLevel(logging.INFO)
