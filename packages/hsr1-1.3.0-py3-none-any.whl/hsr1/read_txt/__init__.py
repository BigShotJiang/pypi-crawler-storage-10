# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 17:02:09 2024

@author: albie
"""


import hsr1.read_txt.ImportHSRFiles as ImportHSRFiles
import hsr1.read_txt.loadFromTxt as loadFromTxt
from hsr1.read_txt.loadFromTxt import *