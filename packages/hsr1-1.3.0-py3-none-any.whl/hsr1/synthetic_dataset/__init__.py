# -*- coding: utf-8 -*-

from hsr1.synthetic_dataset.premadeDatasets import *
from hsr1.synthetic_dataset.syntheticDataset import SyntheticDataset