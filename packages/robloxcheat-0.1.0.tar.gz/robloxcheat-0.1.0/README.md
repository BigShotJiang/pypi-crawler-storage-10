Use this lib only for educational purposes!!!

- attach() is preparing to start exploit. 
- execute("") is to execute scripts.
- change_jump_power(value) will change players jump power to value in parentheses
- change_walk_speed(value) will change players walk speed to value in parentheses
