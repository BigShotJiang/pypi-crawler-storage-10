from pathlib import Path

from owasp_dependency_track_azure_devops import mappers

apply_changes: bool = False
mapper = mappers.default_mapper
template_path: Path | None = None
fix_references: bool = False
