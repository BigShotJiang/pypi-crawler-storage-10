from pathlib import Path

import jinja2
from importlib import resources

__template_env: jinja2.Environment = None
__use_template_path: Path

def setup_jina_env():
    from owasp_dependency_track_azure_devops import globals
    global __template_env, __use_template_path
    if not __template_env:
        search_paths = []
        if globals.template_path:
            __use_template_path = globals.template_path
        else:
            __use_template_path = resources.files("owasp_dependency_track_azure_devops").joinpath("templates/work_item.html.jinja2")

        search_paths.append(__use_template_path.parent)
        template_loader = jinja2.FileSystemLoader(searchpath=search_paths)
        __template_env = jinja2.Environment(
            loader=template_loader,
            trim_blocks=True,
            lstrip_blocks=True
        )
    return __template_env

def get_template():
    env = setup_jina_env()
    return env.get_template(__use_template_path.name)
