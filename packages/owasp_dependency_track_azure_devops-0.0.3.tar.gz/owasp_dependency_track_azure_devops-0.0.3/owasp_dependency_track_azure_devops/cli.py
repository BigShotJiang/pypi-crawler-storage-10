from owasp_dependency_track_azure_devops.args import create_parser
from owasp_dependency_track_azure_devops.log import logger

def main():
    parser = create_parser()
    try:
        args = parser.parse_args()
        args.func(args)
    except (AssertionError, ValueError) as e:
        logger.error(e)
        exit(2)
    except Exception as e:
        logger.exception(e)
        exit(1)

if __name__ == "__main__":  # pragma: no cover
    main()  # pragma: no cover
