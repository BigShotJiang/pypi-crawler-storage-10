# 3Dino Convert

A Python library for converting OBJ files into PBJ files to be used with [NumWorks 3Dino](https://github.com/shrub719/nw-3dino).

## Usage

```sh
pip install nw-3dino-convert

nw-3dino-convert [path to .obj file]

# for example:
nw-3dino-convert meshes/dino.obj
```
