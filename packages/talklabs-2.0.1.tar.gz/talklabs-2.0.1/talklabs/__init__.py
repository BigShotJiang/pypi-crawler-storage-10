"""
TalkLabs SDK - ElevenLabs Compatible TTS with Ultra-Low Latency Redis Streaming
"""

from .tts import (
    TalkLabsClient,
    VoiceSettings,
    generate,
    stream
)

__version__ = "2.0.1"
__all__ = [
    "TalkLabsClient",
    "VoiceSettings",
    "generate",
    "stream"
]
