from setuptools import setup, find_packages

setup(
    name="talklabs",
    version="2.0.1",
    author="Francisco Lima",
    author_email="franciscorllima@gmail.com",
    description="TalkLabs SDK - Ultra-low latency Text-to-Speech with Redis + spaCy streaming (ElevenLabs compatible)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://talklabs.com.br",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
        "websockets>=10.0"
    ],
    python_requires=">=3.8",
)
