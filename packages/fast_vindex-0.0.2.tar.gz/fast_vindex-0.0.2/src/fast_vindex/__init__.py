from fast_vindex.api import patched_vindex

__all__ = ["patched_vindex"]
