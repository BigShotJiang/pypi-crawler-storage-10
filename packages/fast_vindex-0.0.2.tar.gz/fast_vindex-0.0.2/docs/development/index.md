# Development

```{toctree}
:maxdepth: 1

algorithm_step_by_step
<!-- investigate_indexes_complexity
some_ideas -->
```
