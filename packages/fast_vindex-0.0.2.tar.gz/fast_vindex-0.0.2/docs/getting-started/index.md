# Getting Started

```{toctree}
:maxdepth: 1

why-fast-vindex
installation
how-to-use
supported-features
```

<!-- why-fast-vindex

how-to-use -->
