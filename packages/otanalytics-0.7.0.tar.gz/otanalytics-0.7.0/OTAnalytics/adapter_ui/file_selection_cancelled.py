class FileSelectionCancelledException(Exception):
    pass
