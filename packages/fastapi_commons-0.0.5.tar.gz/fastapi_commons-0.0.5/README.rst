FastAPI commons
===============

Re-usable code for FastAPI-based projects
