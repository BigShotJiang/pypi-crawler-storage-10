# Hermes can nodes
[![PyPI version](https://badge.fury.io/py/hermes-can-nodes.svg)](https://pypi.org/project/hermes-can-nodes)

A collection of nodes to interface with CAN bus.

## Installation

### From PyPI

Install the package directly from PyPI using pip:

```bash
pip install hermes-can-nodes
```

### From Source

Clone the repository and install dependencies:

```bash
git clone https://github.com/node-hermes/hermes-can-nodes
pip install -e hermes-can-nodes
```

## Development

This project depends on UV for managing dependencies.
Make sure you have UV installed and set up in your environment.

You can find more information about UV [here](https://docs.astral.sh/uv/getting-started/installation/).

```bash
uv sync
```
