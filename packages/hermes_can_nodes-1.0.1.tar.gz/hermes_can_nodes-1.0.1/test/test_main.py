from hermes_can_nodes import KvaeserCanNode


def test_connection():
    config = KvaeserCanNode.Config(
        type="kvaeser_can",
        channel=0,
        bitrate=500000,
    )

    node = KvaeserCanNode(config)
    node.init()

    assert node.bus is not None, "Bus should be initialized"
    node.deinit()
    assert node.bus is not None, "Bus should still exist after deinit"
    print("Kvaeser CAN node connection test passed.")


if __name__ == "__main__":
    test_connection()
