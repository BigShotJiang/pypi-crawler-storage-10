from .generic_node import GenericCanNode
from .kvaeser_node import KvaeserCanNode

NODES = [KvaeserCanNode]


__all__ = ["KvaeserCanNode", "GenericCanNode"]
