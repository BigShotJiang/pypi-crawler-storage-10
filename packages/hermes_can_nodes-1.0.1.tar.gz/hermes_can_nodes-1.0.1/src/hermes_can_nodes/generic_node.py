from node_hermes_core.nodes import GenericNode
import can

from pydantic import Field
from enum import Enum
from threading import Lock


class GenericCanNode(GenericNode):
    bus: can.BusABC | None = None

    class Config(GenericNode.Config):
        class Bitrates(Enum):
            BITRATE_1000000 = 1000000
            BITRATE_500000 = 500000
            BITRATE_250000 = 250000
            BITRATE_125000 = 125000

        bitrate: Bitrates | int = Field(default=Bitrates.BITRATE_1000000, title="Bitrate")

    lock: Lock

    def init(self):
        # Lock to only allow one thread to access the bus at a time
        self.lock = Lock()
        super().init()

    def deinit(self):
        assert self.bus is not None, "Bus is not initialized"
        self.log.info("Disconnecting from bus")
        self.bus.shutdown()

        super().deinit()
