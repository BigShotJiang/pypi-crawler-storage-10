"""LatentEarth API client package."""

__version__ = "0.0.1"
