# LatentEarth
A minimal Python package for the LatentEarth client.