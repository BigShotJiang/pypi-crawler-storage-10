
# Getting Started with Payments

## Introduction

Use a single API that orchestrates the payment flow to include FraudSight, 3DS and Token creation.

__Authentication__

Set your headers

```
Authorization: {your_credentials}    
Content-Type: application/json    
WP-Api-Version: 2024-06-01
```

Replace `{your_credentials}` with your base64-encoded Basic Auth username and password.

__DNS whitelisting__

Whitelist the following URLs:

* `https://try.access.worldpay.com/`
* `https://access.worldpay.com/`

Please ensure you use DNS whitelisting, not explicit IP whitelisting. When you make a request within Access Worldpay, you should always cache the response returned.

__API collection__

A full set of API examples based on different scenarios.

* __[Download Postman collection](./collections/index.md)__

This API also includes Payment Queries functionality to retrieve and query payment information.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install hamza-payments-query-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/hamza-payments-query-sdk/1.0.0

## Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `pytest` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands


pip install -r test-requirements.txt
pytest


## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `HttpClient` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| proxy_settings | [`ProxySettings`](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| basic_auth_credentials | [`BasicAuthCredentials`](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/auth/basic-authentication.md) | The credential object for Basic Authentication |

The API client can be initialized as follows:

```python
from payments.configuration import Environment
from payments.http.auth.basic_auth import BasicAuthCredentials
from payments.payments_client import PaymentsClient

client = PaymentsClient(
    basic_auth_credentials=BasicAuthCredentials(
        username='BasicAuthUserName',
        password='BasicAuthPassword'
    ),
    environment=Environment.PRODUCTION
)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** Try |
| environment2 | Live |

## Authorization

This API uses the following authentication schemes.

* [`BasicAuth (Basic Authentication)`](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/auth/basic-authentication.md)

## List of APIs

* [3 DS Actions](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/controllers/3-ds-actions.md)
* [Manage Payments](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/controllers/manage-payments.md)
* [Payment Queries](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/controllers/payment-queries.md)
* [Payment](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/controllers/payment.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/proxy-settings.md)

### HTTP

* [HttpResponse](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/http-response.md)
* [HttpRequest](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/MuHamza30/payments-query-python-sdk/tree/1.0.0/doc/unix-date-time.md)

