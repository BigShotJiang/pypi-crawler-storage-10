from .junkie import junkie
from .version import __version__

name = "junkie"

__all__ = ["__version__", "junkie"]
