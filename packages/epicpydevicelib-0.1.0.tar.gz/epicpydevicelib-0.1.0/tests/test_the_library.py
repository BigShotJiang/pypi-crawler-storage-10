import sys
from pathlib import Path

# from epiclibcpp.epiclib.output_tee_globals import Normal_out
# from epiclibcpp.epiclib.statistics import Mean_accumulator

from epicpydevicelib.output_tee_globals import Normal_out

from epicpydevicelib import (
device_exception,
epicpy_auditory_encoder_base,
epicpy_device_base,
epicpy_visual_encoder_base,
epic_standard_symbols,
epic_statistics,
geometric_utilities,
numeric_utilities,
output_tee_globals,
output_tee,
random_utilities,
speech_word,
standard_symbols,
standard_utility_symbols,
Syllable_counter,
symbol,
symbol_utilities,
)

Normal_out.add_py_stream(sys.stdout)

Normal_out(f'{symbol.Symbol(3.3)=}\n')

accumulator = epic_statistics.Mean_accumulator()
# accumulator = Mean_accumulator()

from random import randint
for i in range(10):
    accumulator.update(randint(10,100))

Normal_out(f"{accumulator}\n")
Normal_out(f"{accumulator.get_n()=}\n")
Normal_out(f"{accumulator.get_mean()=}\n")
Normal_out(f"{accumulator.get_est_var()=}\n")

mydevice = epicpy_device_base.EpicPyDevice(parent=None, ot=Normal_out, device_name='mydevice', device_folder=Path(__file__))

Normal_out(f'{mydevice.device_name}')

Normal_out.clear_py_streams()
