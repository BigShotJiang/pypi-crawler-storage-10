class FastGRPCCompilationError(Exception):
    pass


class FastGRPCMiddlewareError(Exception):
    pass


class FastGRPCError(Exception):
    pass
