from .fast_grpc import FastGRPC, FastGRPCRouter

__all__ = ["FastGRPC", "FastGRPCRouter"]
