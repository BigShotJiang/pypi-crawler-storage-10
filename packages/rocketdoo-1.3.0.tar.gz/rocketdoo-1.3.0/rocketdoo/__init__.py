# __init__.py
from .rocketdoo import main
