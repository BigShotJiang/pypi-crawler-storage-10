// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

// Entry point for the notebook bundle containing custom model definitions.
//
// Setup notebook base URL
//
// Some static assets may be required by the custom widget javascript. The base
// url for the notebook is not known at build time and is therefore computed
// dynamically.
// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
// Configure RequireJS for Jupyter Notebook / Colab
if ((window as any).require) {
  (window as any).require.config({
    map: {
      "*": {
        "vizpro-js": "nbextensions/vizpro/index",
      },
    },
  });
}

// Required by Jupyter Notebook
export function load_ipython_extension() {}