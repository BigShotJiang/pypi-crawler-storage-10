"use strict";
(self["webpackChunkvizpro_js"] = self["webpackChunkvizpro_js"] || []).push([["lib_graphs_js-lib_layouts_js-lib_version_js-lib_widgets_js"],{

/***/ "./css/graphs.css":
/*!************************!*\
  !*** ./css/graphs.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_graphs_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./graphs.css */ "./node_modules/css-loader/dist/cjs.js!./css/graphs.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_graphs_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_graphs_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_graphs_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_graphs_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./css/layout.css":
/*!************************!*\
  !*** ./css/layout.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_layout_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./layout.css */ "./node_modules/css-loader/dist/cjs.js!./css/layout.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_layout_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_layout_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_layout_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_layout_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./css/widget.css":
/*!************************!*\
  !*** ./css/widget.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./widget.css */ "./node_modules/css-loader/dist/cjs.js!./css/widget.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./lib/base/base.js":
/*!**************************!*\
  !*** ./lib/base/base.js ***!
  \**************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BaseView = exports.BaseModel = exports.RENDER_INTERVAL = exports.RENDER_TIMEOUT = exports.WIDGET_MARGIN = exports.WIDGET_HEIGHT = void 0;
const base_1 = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
__webpack_require__(/*! ../../css/widget.css */ "./css/widget.css");
const package_json_1 = __importDefault(__webpack_require__(/*! ../../package.json */ "./package.json"));
exports.WIDGET_HEIGHT = 500;
exports.WIDGET_MARGIN = { top: 20, right: 20, bottom: 30, left: 20 };
exports.RENDER_TIMEOUT = 20000;
exports.RENDER_INTERVAL = 100;
class BaseModel extends base_1.DOMWidgetModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_module: BaseModel.model_module,
            _view_module: BaseModel.view_module,
            _model_module_version: BaseModel.model_module_version,
            _view_module_version: BaseModel.view_module_version,
        };
    }
}
exports.BaseModel = BaseModel;
BaseModel.model_module = package_json_1.default.name;
BaseModel.model_module_version = package_json_1.default.version;
BaseModel.view_module = package_json_1.default.name;
BaseModel.view_module_version = package_json_1.default.version;
class BaseView extends base_1.DOMWidgetView {
    constructor() {
        super(...arguments);
        this.element = null;
        this.width = null;
        this.height = null;
        this.elementId = null;
    }
    render() {
        let elapsedTime = 0;
        let intr = setInterval(() => {
            try {
                this.element = this.getElement();
                if (!this.element)
                    return;
                this.setSizes();
                if (this.element && this.width && this.height) {
                    this.plot(this.element);
                    clearInterval(intr);
                }
                elapsedTime += exports.RENDER_INTERVAL;
                if (elapsedTime > exports.RENDER_TIMEOUT) {
                    throw new Error("Widget took too long to render");
                }
            }
            catch (err) {
                if (err instanceof Error) {
                    console.log(err.stack);
                }
                else {
                    console.log(err);
                }
                clearInterval(intr);
            }
        }, exports.RENDER_INTERVAL);
    }
    replot() {
        this.setSizes();
        this.widget.replot(this.params());
    }
    getElement() {
        this.elementId = this.model.get("elementId");
        let element = this.el;
        if (this.elementId) {
            element = document.getElementById(this.elementId);
        }
        return element;
    }
    setSizes() {
        const elementId = this.model.get("elementId");
        this.height = exports.WIDGET_HEIGHT;
        let element = this.el;
        if (elementId) {
            element = document.getElementById(elementId);
            if (element?.clientHeight)
                this.height = element.clientHeight;
            else
                this.height = null;
        }
        if (element?.clientWidth)
            this.width = element.clientWidth;
        else
            this.width = null;
    }
}
exports.BaseView = BaseView;


/***/ }),

/***/ "./lib/base/base_widget.js":
/*!*********************************!*\
  !*** ./lib/base/base_widget.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BaseWidget = void 0;
class BaseWidget {
    constructor(element) {
        this.timeout = null;
        this.element = element;
    }
    replot(params) {
        if (this.timeout) {
            clearTimeout(this.timeout);
        }
        this.timeout = setTimeout(() => {
            this.element.innerHTML = "";
            this.plot(params);
        }, 100);
    }
}
exports.BaseWidget = BaseWidget;


/***/ }),

/***/ "./lib/const/colors.js":
/*!*****************************!*\
  !*** ./lib/const/colors.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.colorbrewer = void 0;
exports.colorbrewer = { YlGn: {
        3: ["#f7fcb9", "#addd8e", "#31a354"],
        4: ["#ffffcc", "#c2e699", "#78c679", "#238443"],
        5: ["#ffffcc", "#c2e699", "#78c679", "#31a354", "#006837"],
        6: ["#ffffcc", "#d9f0a3", "#addd8e", "#78c679", "#31a354", "#006837"],
        7: ["#ffffcc", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#005a32"],
        8: ["#ffffe5", "#f7fcb9", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#005a32"],
        9: ["#ffffe5", "#f7fcb9", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#006837", "#004529"]
    }, YlGnBu: {
        3: ["#edf8b1", "#7fcdbb", "#2c7fb8"],
        4: ["#ffffcc", "#a1dab4", "#41b6c4", "#225ea8"],
        5: ["#ffffcc", "#a1dab4", "#41b6c4", "#2c7fb8", "#253494"],
        6: ["#ffffcc", "#c7e9b4", "#7fcdbb", "#41b6c4", "#2c7fb8", "#253494"],
        7: ["#ffffcc", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#0c2c84"],
        8: ["#ffffd9", "#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#0c2c84"],
        9: ["#ffffd9", "#edf8b1", "#c7e9b4", "#7fcdbb", "#41b6c4", "#1d91c0", "#225ea8", "#253494", "#081d58"]
    }, GnBu: {
        3: ["#e0f3db", "#a8ddb5", "#43a2ca"],
        4: ["#f0f9e8", "#bae4bc", "#7bccc4", "#2b8cbe"],
        5: ["#f0f9e8", "#bae4bc", "#7bccc4", "#43a2ca", "#0868ac"],
        6: ["#f0f9e8", "#ccebc5", "#a8ddb5", "#7bccc4", "#43a2ca", "#0868ac"],
        7: ["#f0f9e8", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#08589e"],
        8: ["#f7fcf0", "#e0f3db", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#08589e"],
        9: ["#f7fcf0", "#e0f3db", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#0868ac", "#084081"]
    }, BuGn: {
        3: ["#e5f5f9", "#99d8c9", "#2ca25f"],
        4: ["#edf8fb", "#b2e2e2", "#66c2a4", "#238b45"],
        5: ["#edf8fb", "#b2e2e2", "#66c2a4", "#2ca25f", "#006d2c"],
        6: ["#edf8fb", "#ccece6", "#99d8c9", "#66c2a4", "#2ca25f", "#006d2c"],
        7: ["#edf8fb", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#005824"],
        8: ["#f7fcfd", "#e5f5f9", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#005824"],
        9: ["#f7fcfd", "#e5f5f9", "#ccece6", "#99d8c9", "#66c2a4", "#41ae76", "#238b45", "#006d2c", "#00441b"]
    }, PuBuGn: {
        3: ["#ece2f0", "#a6bddb", "#1c9099"],
        4: ["#f6eff7", "#bdc9e1", "#67a9cf", "#02818a"],
        5: ["#f6eff7", "#bdc9e1", "#67a9cf", "#1c9099", "#016c59"],
        6: ["#f6eff7", "#d0d1e6", "#a6bddb", "#67a9cf", "#1c9099", "#016c59"],
        7: ["#f6eff7", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016450"],
        8: ["#fff7fb", "#ece2f0", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016450"],
        9: ["#fff7fb", "#ece2f0", "#d0d1e6", "#a6bddb", "#67a9cf", "#3690c0", "#02818a", "#016c59", "#014636"]
    }, PuBu: {
        3: ["#ece7f2", "#a6bddb", "#2b8cbe"],
        4: ["#f1eef6", "#bdc9e1", "#74a9cf", "#0570b0"],
        5: ["#f1eef6", "#bdc9e1", "#74a9cf", "#2b8cbe", "#045a8d"],
        6: ["#f1eef6", "#d0d1e6", "#a6bddb", "#74a9cf", "#2b8cbe", "#045a8d"],
        7: ["#f1eef6", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#034e7b"],
        8: ["#fff7fb", "#ece7f2", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#034e7b"],
        9: ["#fff7fb", "#ece7f2", "#d0d1e6", "#a6bddb", "#74a9cf", "#3690c0", "#0570b0", "#045a8d", "#023858"]
    }, BuPu: {
        3: ["#e0ecf4", "#9ebcda", "#8856a7"],
        4: ["#edf8fb", "#b3cde3", "#8c96c6", "#88419d"],
        5: ["#edf8fb", "#b3cde3", "#8c96c6", "#8856a7", "#810f7c"],
        6: ["#edf8fb", "#bfd3e6", "#9ebcda", "#8c96c6", "#8856a7", "#810f7c"],
        7: ["#edf8fb", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#6e016b"],
        8: ["#f7fcfd", "#e0ecf4", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#6e016b"],
        9: ["#f7fcfd", "#e0ecf4", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#810f7c", "#4d004b"]
    }, RdPu: {
        3: ["#fde0dd", "#fa9fb5", "#c51b8a"],
        4: ["#feebe2", "#fbb4b9", "#f768a1", "#ae017e"],
        5: ["#feebe2", "#fbb4b9", "#f768a1", "#c51b8a", "#7a0177"],
        6: ["#feebe2", "#fcc5c0", "#fa9fb5", "#f768a1", "#c51b8a", "#7a0177"],
        7: ["#feebe2", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177"],
        8: ["#fff7f3", "#fde0dd", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177"],
        9: ["#fff7f3", "#fde0dd", "#fcc5c0", "#fa9fb5", "#f768a1", "#dd3497", "#ae017e", "#7a0177", "#49006a"]
    }, PuRd: {
        3: ["#e7e1ef", "#c994c7", "#dd1c77"],
        4: ["#f1eef6", "#d7b5d8", "#df65b0", "#ce1256"],
        5: ["#f1eef6", "#d7b5d8", "#df65b0", "#dd1c77", "#980043"],
        6: ["#f1eef6", "#d4b9da", "#c994c7", "#df65b0", "#dd1c77", "#980043"],
        7: ["#f1eef6", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#91003f"],
        8: ["#f7f4f9", "#e7e1ef", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#91003f"],
        9: ["#f7f4f9", "#e7e1ef", "#d4b9da", "#c994c7", "#df65b0", "#e7298a", "#ce1256", "#980043", "#67001f"]
    }, OrRd: {
        3: ["#fee8c8", "#fdbb84", "#e34a33"],
        4: ["#fef0d9", "#fdcc8a", "#fc8d59", "#d7301f"],
        5: ["#fef0d9", "#fdcc8a", "#fc8d59", "#e34a33", "#b30000"],
        6: ["#fef0d9", "#fdd49e", "#fdbb84", "#fc8d59", "#e34a33", "#b30000"],
        7: ["#fef0d9", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#990000"],
        8: ["#fff7ec", "#fee8c8", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#990000"],
        9: ["#fff7ec", "#fee8c8", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#b30000", "#7f0000"]
    }, YlOrRd: {
        3: ["#ffeda0", "#feb24c", "#f03b20"],
        4: ["#ffffb2", "#fecc5c", "#fd8d3c", "#e31a1c"],
        5: ["#ffffb2", "#fecc5c", "#fd8d3c", "#f03b20", "#bd0026"],
        6: ["#ffffb2", "#fed976", "#feb24c", "#fd8d3c", "#f03b20", "#bd0026"],
        7: ["#ffffb2", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#b10026"],
        8: ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#b10026"],
        9: ["#ffffcc", "#ffeda0", "#fed976", "#feb24c", "#fd8d3c", "#fc4e2a", "#e31a1c", "#bd0026", "#800026"]
    }, YlOrBr: {
        3: ["#fff7bc", "#fec44f", "#d95f0e"],
        4: ["#ffffd4", "#fed98e", "#fe9929", "#cc4c02"],
        5: ["#ffffd4", "#fed98e", "#fe9929", "#d95f0e", "#993404"],
        6: ["#ffffd4", "#fee391", "#fec44f", "#fe9929", "#d95f0e", "#993404"],
        7: ["#ffffd4", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#8c2d04"],
        8: ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#8c2d04"],
        9: ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#993404", "#662506"]
    }, Purples: {
        3: ["#efedf5", "#bcbddc", "#756bb1"],
        4: ["#f2f0f7", "#cbc9e2", "#9e9ac8", "#6a51a3"],
        5: ["#f2f0f7", "#cbc9e2", "#9e9ac8", "#756bb1", "#54278f"],
        6: ["#f2f0f7", "#dadaeb", "#bcbddc", "#9e9ac8", "#756bb1", "#54278f"],
        7: ["#f2f0f7", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#4a1486"],
        8: ["#fcfbfd", "#efedf5", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#4a1486"],
        9: ["#fcfbfd", "#efedf5", "#dadaeb", "#bcbddc", "#9e9ac8", "#807dba", "#6a51a3", "#54278f", "#3f007d"]
    }, Blues: {
        3: ["#deebf7", "#9ecae1", "#3182bd"],
        4: ["#eff3ff", "#bdd7e7", "#6baed6", "#2171b5"],
        5: ["#eff3ff", "#bdd7e7", "#6baed6", "#3182bd", "#08519c"],
        6: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"],
        7: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#084594"],
        8: ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#084594"],
        9: ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b"]
    }, Greens: {
        3: ["#e5f5e0", "#a1d99b", "#31a354"],
        4: ["#edf8e9", "#bae4b3", "#74c476", "#238b45"],
        5: ["#edf8e9", "#bae4b3", "#74c476", "#31a354", "#006d2c"],
        6: ["#edf8e9", "#c7e9c0", "#a1d99b", "#74c476", "#31a354", "#006d2c"],
        7: ["#edf8e9", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#005a32"],
        8: ["#f7fcf5", "#e5f5e0", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#005a32"],
        9: ["#f7fcf5", "#e5f5e0", "#c7e9c0", "#a1d99b", "#74c476", "#41ab5d", "#238b45", "#006d2c", "#00441b"]
    }, Oranges: {
        3: ["#fee6ce", "#fdae6b", "#e6550d"],
        4: ["#feedde", "#fdbe85", "#fd8d3c", "#d94701"],
        5: ["#feedde", "#fdbe85", "#fd8d3c", "#e6550d", "#a63603"],
        6: ["#feedde", "#fdd0a2", "#fdae6b", "#fd8d3c", "#e6550d", "#a63603"],
        7: ["#feedde", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#8c2d04"],
        8: ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#8c2d04"],
        9: ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#a63603", "#7f2704"]
    }, Reds: {
        3: ["#fee0d2", "#fc9272", "#de2d26"],
        4: ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"],
        5: ["#fee5d9", "#fcae91", "#fb6a4a", "#de2d26", "#a50f15"],
        6: ["#fee5d9", "#fcbba1", "#fc9272", "#fb6a4a", "#de2d26", "#a50f15"],
        7: ["#fee5d9", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#99000d"],
        8: ["#fff5f0", "#fee0d2", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#99000d"],
        9: ["#fff5f0", "#fee0d2", "#fcbba1", "#fc9272", "#fb6a4a", "#ef3b2c", "#cb181d", "#a50f15", "#67000d"]
    }, Greys: {
        3: ["#f0f0f0", "#bdbdbd", "#636363"],
        4: ["#f7f7f7", "#cccccc", "#969696", "#525252"],
        5: ["#f7f7f7", "#cccccc", "#969696", "#636363", "#252525"],
        6: ["#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#636363", "#252525"],
        7: ["#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525"],
        8: ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525"],
        9: ["#ffffff", "#f0f0f0", "#d9d9d9", "#bdbdbd", "#969696", "#737373", "#525252", "#252525", "#000000"]
    }, PuOr: {
        3: ["#f1a340", "#f7f7f7", "#998ec3"],
        4: ["#e66101", "#fdb863", "#b2abd2", "#5e3c99"],
        5: ["#e66101", "#fdb863", "#f7f7f7", "#b2abd2", "#5e3c99"],
        6: ["#b35806", "#f1a340", "#fee0b6", "#d8daeb", "#998ec3", "#542788"],
        7: ["#b35806", "#f1a340", "#fee0b6", "#f7f7f7", "#d8daeb", "#998ec3", "#542788"],
        8: ["#b35806", "#e08214", "#fdb863", "#fee0b6", "#d8daeb", "#b2abd2", "#8073ac", "#542788"],
        9: ["#b35806", "#e08214", "#fdb863", "#fee0b6", "#f7f7f7", "#d8daeb", "#b2abd2", "#8073ac", "#542788"],
        10: ["#7f3b08", "#b35806", "#e08214", "#fdb863", "#fee0b6", "#d8daeb", "#b2abd2", "#8073ac", "#542788", "#2d004b"],
        11: ["#7f3b08", "#b35806", "#e08214", "#fdb863", "#fee0b6", "#f7f7f7", "#d8daeb", "#b2abd2", "#8073ac", "#542788", "#2d004b"]
    }, BrBG: {
        3: ["#d8b365", "#f5f5f5", "#5ab4ac"],
        4: ["#a6611a", "#dfc27d", "#80cdc1", "#018571"],
        5: ["#a6611a", "#dfc27d", "#f5f5f5", "#80cdc1", "#018571"],
        6: ["#8c510a", "#d8b365", "#f6e8c3", "#c7eae5", "#5ab4ac", "#01665e"],
        7: ["#8c510a", "#d8b365", "#f6e8c3", "#f5f5f5", "#c7eae5", "#5ab4ac", "#01665e"],
        8: ["#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#c7eae5", "#80cdc1", "#35978f", "#01665e"],
        9: ["#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#f5f5f5", "#c7eae5", "#80cdc1", "#35978f", "#01665e"],
        10: ["#543005", "#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#c7eae5", "#80cdc1", "#35978f", "#01665e", "#003c30"],
        11: ["#543005", "#8c510a", "#bf812d", "#dfc27d", "#f6e8c3", "#f5f5f5", "#c7eae5", "#80cdc1", "#35978f", "#01665e", "#003c30"]
    }, PRGn: {
        3: ["#af8dc3", "#f7f7f7", "#7fbf7b"],
        4: ["#7b3294", "#c2a5cf", "#a6dba0", "#008837"],
        5: ["#7b3294", "#c2a5cf", "#f7f7f7", "#a6dba0", "#008837"],
        6: ["#762a83", "#af8dc3", "#e7d4e8", "#d9f0d3", "#7fbf7b", "#1b7837"],
        7: ["#762a83", "#af8dc3", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#7fbf7b", "#1b7837"],
        8: ["#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837"],
        9: ["#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837"],
        10: ["#40004b", "#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837", "#00441b"],
        11: ["#40004b", "#762a83", "#9970ab", "#c2a5cf", "#e7d4e8", "#f7f7f7", "#d9f0d3", "#a6dba0", "#5aae61", "#1b7837", "#00441b"]
    }, PiYG: {
        3: ["#e9a3c9", "#f7f7f7", "#a1d76a"],
        4: ["#d01c8b", "#f1b6da", "#b8e186", "#4dac26"],
        5: ["#d01c8b", "#f1b6da", "#f7f7f7", "#b8e186", "#4dac26"],
        6: ["#c51b7d", "#e9a3c9", "#fde0ef", "#e6f5d0", "#a1d76a", "#4d9221"],
        7: ["#c51b7d", "#e9a3c9", "#fde0ef", "#f7f7f7", "#e6f5d0", "#a1d76a", "#4d9221"],
        8: ["#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221"],
        9: ["#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#f7f7f7", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221"],
        10: ["#8e0152", "#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221", "#276419"],
        11: ["#8e0152", "#c51b7d", "#de77ae", "#f1b6da", "#fde0ef", "#f7f7f7", "#e6f5d0", "#b8e186", "#7fbc41", "#4d9221", "#276419"]
    }, RdBu: {
        3: ["#ef8a62", "#f7f7f7", "#67a9cf"],
        4: ["#ca0020", "#f4a582", "#92c5de", "#0571b0"],
        5: ["#ca0020", "#f4a582", "#f7f7f7", "#92c5de", "#0571b0"],
        6: ["#b2182b", "#ef8a62", "#fddbc7", "#d1e5f0", "#67a9cf", "#2166ac"],
        7: ["#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"],
        8: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac"],
        9: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac"],
        10: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac", "#053061"],
        11: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#f7f7f7", "#d1e5f0", "#92c5de", "#4393c3", "#2166ac", "#053061"]
    }, RdGy: {
        3: ["#ef8a62", "#ffffff", "#999999"],
        4: ["#ca0020", "#f4a582", "#bababa", "#404040"],
        5: ["#ca0020", "#f4a582", "#ffffff", "#bababa", "#404040"],
        6: ["#b2182b", "#ef8a62", "#fddbc7", "#e0e0e0", "#999999", "#4d4d4d"],
        7: ["#b2182b", "#ef8a62", "#fddbc7", "#ffffff", "#e0e0e0", "#999999", "#4d4d4d"],
        8: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#e0e0e0", "#bababa", "#878787", "#4d4d4d"],
        9: ["#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#ffffff", "#e0e0e0", "#bababa", "#878787", "#4d4d4d"],
        10: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#e0e0e0", "#bababa", "#878787", "#4d4d4d", "#1a1a1a"],
        11: ["#67001f", "#b2182b", "#d6604d", "#f4a582", "#fddbc7", "#ffffff", "#e0e0e0", "#bababa", "#878787", "#4d4d4d", "#1a1a1a"]
    }, RdYlBu: {
        3: ["#fc8d59", "#ffffbf", "#91bfdb"],
        4: ["#d7191c", "#fdae61", "#abd9e9", "#2c7bb6"],
        5: ["#d7191c", "#fdae61", "#ffffbf", "#abd9e9", "#2c7bb6"],
        6: ["#d73027", "#fc8d59", "#fee090", "#e0f3f8", "#91bfdb", "#4575b4"],
        7: ["#d73027", "#fc8d59", "#fee090", "#ffffbf", "#e0f3f8", "#91bfdb", "#4575b4"],
        8: ["#d73027", "#f46d43", "#fdae61", "#fee090", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4"],
        9: ["#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4"],
        10: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"],
        11: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee090", "#ffffbf", "#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695"]
    }, Spectral: {
        3: ["#fc8d59", "#ffffbf", "#99d594"],
        4: ["#d7191c", "#fdae61", "#abdda4", "#2b83ba"],
        5: ["#d7191c", "#fdae61", "#ffffbf", "#abdda4", "#2b83ba"],
        6: ["#d53e4f", "#fc8d59", "#fee08b", "#e6f598", "#99d594", "#3288bd"],
        7: ["#d53e4f", "#fc8d59", "#fee08b", "#ffffbf", "#e6f598", "#99d594", "#3288bd"],
        8: ["#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#e6f598", "#abdda4", "#66c2a5", "#3288bd"],
        9: ["#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd"],
        10: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#e6f598", "#abdda4", "#66c2a5", "#3288bd", "#5e4fa2"],
        11: ["#9e0142", "#d53e4f", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#e6f598", "#abdda4", "#66c2a5", "#3288bd", "#5e4fa2"]
    }, RdYlGn: {
        3: ["#fc8d59", "#ffffbf", "#91cf60"],
        4: ["#d7191c", "#fdae61", "#a6d96a", "#1a9641"],
        5: ["#d7191c", "#fdae61", "#ffffbf", "#a6d96a", "#1a9641"],
        6: ["#d73027", "#fc8d59", "#fee08b", "#d9ef8b", "#91cf60", "#1a9850"],
        7: ["#d73027", "#fc8d59", "#fee08b", "#ffffbf", "#d9ef8b", "#91cf60", "#1a9850"],
        8: ["#d73027", "#f46d43", "#fdae61", "#fee08b", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850"],
        9: ["#d73027", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850"],
        10: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee08b", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850", "#006837"],
        11: ["#a50026", "#d73027", "#f46d43", "#fdae61", "#fee08b", "#ffffbf", "#d9ef8b", "#a6d96a", "#66bd63", "#1a9850", "#006837"]
    }, Accent: {
        3: ["#7fc97f", "#beaed4", "#fdc086"],
        4: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99"],
        5: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0"],
        6: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f"],
        7: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f", "#bf5b17"],
        8: ["#7fc97f", "#beaed4", "#fdc086", "#ffff99", "#386cb0", "#f0027f", "#bf5b17", "#666666"]
    }, Dark2: {
        3: ["#1b9e77", "#d95f02", "#7570b3"],
        4: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a"],
        5: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e"],
        6: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02"],
        7: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d"],
        8: ["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e", "#e6ab02", "#a6761d", "#666666"]
    }, Paired: {
        3: ["#a6cee3", "#1f78b4", "#b2df8a"],
        4: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c"],
        5: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99"],
        6: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c"],
        7: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f"],
        8: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00"],
        9: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6"],
        10: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a"],
        11: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99"],
        12: ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#e31a1c", "#fdbf6f", "#ff7f00", "#cab2d6", "#6a3d9a", "#ffff99", "#b15928"]
    }, Pastel1: {
        3: ["#fbb4ae", "#b3cde3", "#ccebc5"],
        4: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4"],
        5: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6"],
        6: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc"],
        7: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd"],
        8: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd", "#fddaec"],
        9: ["#fbb4ae", "#b3cde3", "#ccebc5", "#decbe4", "#fed9a6", "#ffffcc", "#e5d8bd", "#fddaec", "#f2f2f2"]
    }, Pastel2: {
        3: ["#b3e2cd", "#fdcdac", "#cbd5e8"],
        4: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4"],
        5: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9"],
        6: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae"],
        7: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae", "#f1e2cc"],
        8: ["#b3e2cd", "#fdcdac", "#cbd5e8", "#f4cae4", "#e6f5c9", "#fff2ae", "#f1e2cc", "#cccccc"]
    }, Set1: {
        3: ["#e41a1c", "#377eb8", "#4daf4a"],
        4: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3"],
        5: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00"],
        6: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33"],
        7: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628"],
        8: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628", "#f781bf"],
        9: ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#ffff33", "#a65628", "#f781bf", "#999999"]
    }, Set2: {
        3: ["#66c2a5", "#fc8d62", "#8da0cb"],
        4: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3"],
        5: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854"],
        6: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f"],
        7: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f", "#e5c494"],
        8: ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854", "#ffd92f", "#e5c494", "#b3b3b3"]
    }, Set3: {
        3: ["#8dd3c7", "#ffffb3", "#bebada"],
        4: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072"],
        5: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3"],
        6: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462"],
        7: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69"],
        8: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5"],
        9: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9"],
        10: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd"],
        11: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd", "#ccebc5"],
        12: ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f"]
    } };


/***/ }),

/***/ "./lib/graphs.js":
/*!***********************!*\
  !*** ./lib/graphs.js ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StarCoordinatesView = exports.StarCoordinatesModel = exports.RadVizView = exports.RadVizModel = exports.HorizonChartView = exports.HorizonChartModel = exports.ScatterPlotView = exports.ScatterPlotModel = exports.BarPlotView = exports.BarPlotModel = void 0;
var barplot_1 = __webpack_require__(/*! ./graphs/barplot */ "./lib/graphs/barplot.js");
Object.defineProperty(exports, "BarPlotModel", ({ enumerable: true, get: function () { return barplot_1.BarPlotModel; } }));
Object.defineProperty(exports, "BarPlotView", ({ enumerable: true, get: function () { return barplot_1.BarPlotView; } }));
var scatterplot_1 = __webpack_require__(/*! ./graphs/scatterplot */ "./lib/graphs/scatterplot.js");
Object.defineProperty(exports, "ScatterPlotModel", ({ enumerable: true, get: function () { return scatterplot_1.ScatterPlotModel; } }));
Object.defineProperty(exports, "ScatterPlotView", ({ enumerable: true, get: function () { return scatterplot_1.ScatterPlotView; } }));
var horizon_1 = __webpack_require__(/*! ./graphs/horizon */ "./lib/graphs/horizon.js");
Object.defineProperty(exports, "HorizonChartModel", ({ enumerable: true, get: function () { return horizon_1.HorizonChartModel; } }));
Object.defineProperty(exports, "HorizonChartView", ({ enumerable: true, get: function () { return horizon_1.HorizonChartView; } }));
var radviz_1 = __webpack_require__(/*! ./graphs/radviz */ "./lib/graphs/radviz.js");
Object.defineProperty(exports, "RadVizModel", ({ enumerable: true, get: function () { return radviz_1.RadVizModel; } }));
Object.defineProperty(exports, "RadVizView", ({ enumerable: true, get: function () { return radviz_1.RadVizView; } }));
var starcoordinates_1 = __webpack_require__(/*! ./graphs/starcoordinates */ "./lib/graphs/starcoordinates.js");
Object.defineProperty(exports, "StarCoordinatesModel", ({ enumerable: true, get: function () { return starcoordinates_1.StarCoordinatesModel; } }));
Object.defineProperty(exports, "StarCoordinatesView", ({ enumerable: true, get: function () { return starcoordinates_1.StarCoordinatesView; } }));


/***/ }),

/***/ "./lib/graphs/barplot.js":
/*!*******************************!*\
  !*** ./lib/graphs/barplot.js ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BarPlotView = exports.BarPlotModel = exports.BarPlot = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const baseplot_1 = __webpack_require__(/*! ./baseplot */ "./lib/graphs/baseplot.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const tools_1 = __webpack_require__(/*! ./tools/tools */ "./lib/graphs/tools/tools.js");
class BarPlot extends baseplot_1.BasePlot {
    verifyDirection(direction, xValue, yValue, data) {
        if (direction === 'vertical') {
            return data.map((item, index) => ({
                ...item,
                x_: item[xValue],
                y_: item[yValue],
                id: index
            }));
        }
        else {
            return data.map((item, index) => ({
                ...item,
                x_: item[yValue],
                y_: item[xValue],
                id: index
            }));
        }
    }
    get_all_hues(RenamedData, hue_value) {
        return RenamedData.reduce((all, row) => {
            const hueValueAsString = String(row[hue_value]);
            if (!all.includes(hueValueAsString)) {
                all.push(hueValueAsString);
            }
            return all;
        }, []);
    }
    plot(params) {
        const { data, xValue, yValue, hue, setSelectedValues, direction, height, noAxes, noSideBar } = params;
        let width = params.width;
        let clickSelectButton = null;
        let boxSelectButton = null;
        let deselectAllButton = null;
        if (!noSideBar)
            width = width ? width - tools_1.SideBar.SIDE_BAR_WIDTH : 0;
        const randomString = Math.floor(Math.random() * Date.now() * 10000).toString(36);
        this.init(width, height);
        const GG = this.gGrid;
        function callUpdateSelected() {
            if (setSelectedValues) {
                const selectedData = GG.selectAll(".bar.selected").data();
                // Filtrar los atributos internos antes de guardar
                const cleanedData = selectedData.map((d) => {
                    const { x_, y_, id, originalData, allOriginalData, ...rest } = d;
                    return rest;
                });
                setSelectedValues(cleanedData);
            }
        }
        const mouseClick = (event, d) => {
            if (clickSelectButton) {
                clickSelectButton.selectionClickEffect(d3.select(event.currentTarget));
                callUpdateSelected();
            }
        };
        const isVertical = direction === 'vertical';
        const RenamedData = this.verifyDirection(direction, xValue, yValue, data);
        let hue_value;
        if (hue)
            hue_value = hue;
        else
            hue_value = 'x_';
        const allHues = this.get_all_hues(RenamedData, hue_value);
        if (hue_value === 'x_') {
            createSingleBars(this);
        }
        function createSingleBars(plot) {
            // Agrega por categoría: suma y cuenta
            const agg = {};
            for (const row of RenamedData) {
                const x = String(row.x_);
                const y = Number(row.y_);
                if (agg[x]) {
                    agg[x].sum += y;
                    agg[x].count += 1;
                    agg[x].rows.push(row);
                }
                else {
                    agg[x] = { sum: y, count: 1, rows: [row] };
                }
            }
            const processedData = Object.keys(agg).map((key, index) => {
                const aggregatedGroup = agg[key];
                const firstRow = aggregatedGroup.rows[0];
                // Crear el objeto procesado manteniendo todos los atributos originales
                const { x_, y_, id, ...originalAttributes } = firstRow;
                const processedRow = {
                    ...originalAttributes, // Primero todos los atributos originales
                    id: index,
                    x_: key,
                    y_: aggregatedGroup.sum / aggregatedGroup.count,
                    originalData: firstRow,
                    allOriginalData: aggregatedGroup.rows,
                };
                return processedRow;
            });
            const groups = processedData
                .map((r) => r.x_)
                .sort((a, b) => a.localeCompare(b));
            const side_domain = [
                d3.min(processedData, (d) => d.y_) ?? 0,
                d3.max(processedData, (d) => d.y_) ?? 0,
            ];
            if (side_domain[0] > 0 && side_domain[1] > 0)
                side_domain[0] = 0;
            else if (side_domain[0] < 0 && side_domain[1] < 0)
                side_domain[1] = 0;
            const scaleConfig = createScaleConfig();
            function createScaleConfig() {
                if (width === null || height === null) {
                    throw new Error("Width and Height must be defined");
                }
                const X = isVertical
                    ? plot.getXBandScale({ values: groups, width, padding: 0.2 })
                    : plot.getXLinearScale({ domain: side_domain, width });
                const Y = isVertical
                    ? plot.getYLinearScale({ domain: side_domain, height })
                    : plot.getYBandScale({ values: groups, height, padding: 0.2 });
                return {
                    X,
                    Y,
                    baseScale: isVertical ? X : Y,
                    sideScale: isVertical ? Y : X,
                    baseAxis: isVertical ? 'x' : 'y',
                    sideAxis: isVertical ? 'y' : 'x',
                    baseLength: isVertical ? 'width' : 'height',
                    sideLength: isVertical ? 'height' : 'width'
                };
            }
            if (!noAxes)
                plot.plotAxes({
                    svg: GG,
                    xScale: scaleConfig.X,
                    yScale: scaleConfig.Y,
                    xLabel: isVertical ? xValue : yValue,
                    yLabel: isVertical ? yValue : xValue
                });
            const color = d3.scaleOrdinal(d3.schemeCategory10)
                .domain(allHues);
            const bars = GG.selectAll(".bar").data(processedData).enter().append("rect");
            bars.attr("id", function (d, i) {
                return "bar-" + randomString + "-" + d.id;
            })
                .attr("class", "bar")
                .attr(scaleConfig.baseAxis, function (d) {
                const bandScale = scaleConfig.baseScale;
                return bandScale(d.x_) ?? 0;
            })
                .attr(scaleConfig.sideAxis, function (d) {
                const linearScale = scaleConfig.sideScale;
                const sideValue = linearScale(d.y_);
                const zeroValue = linearScale(0);
                return Math.min(sideValue, zeroValue);
            })
                .attr(scaleConfig.baseLength, function () {
                const bandScale = scaleConfig.baseScale;
                return bandScale.bandwidth();
            })
                .attr(scaleConfig.sideLength, function (d) {
                const linearScale = scaleConfig.sideScale;
                const sideValue = linearScale(d.y_);
                const zeroValue = linearScale(0);
                return Math.abs(zeroValue - sideValue);
            })
                .attr("fill", function (d) {
                const hueValue = String(d[hue_value] ?? d.x_);
                return color(hueValue);
            })
                .on("click", mouseClick);
            if (!noSideBar) {
                clickSelectButton = new tools_1.ClickSelectButton(true);
                deselectAllButton = new tools_1.DeselectAllButton(bars, callUpdateSelected);
                boxSelectButton = new tools_1.BoxSelectButton({
                    xScale: scaleConfig.X,
                    yScale: scaleConfig.Y,
                    x_value: xValue,
                    y_value: yValue,
                    x_translate: 0,
                    y_translate: 0,
                    selectables: bars,
                    callUpdateSelected: callUpdateSelected,
                    base: GG,
                    selected: false
                });
                const sideBar = new tools_1.SideBar(plot.element, clickSelectButton, boxSelectButton, deselectAllButton);
                sideBar.inicializar();
            }
        }
    }
}
exports.BarPlot = BarPlot;
class BarPlotModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: BarPlotModel.model_name,
            _view_name: BarPlotModel.view_name,
            dataRecords: [],
            direction: String,
            x: String,
            y: String,
            hue: String,
            elementId: String,
            selectedValuesRecords: [],
        };
    }
}
exports.BarPlotModel = BarPlotModel;
BarPlotModel.model_name = "BarPlotModel";
BarPlotModel.view_name = "BarPlotView";
class BarPlotView extends base_1.BaseView {
    params() {
        return {
            data: this.model.get("dataRecords"),
            xValue: this.model.get("x"),
            yValue: this.model.get("y"),
            hue: this.model.get("hue"),
            setSelectedValues: this.setSelectedValues.bind(this),
            direction: this.model.get("direction"),
            width: this.width,
            height: this.height,
            noAxes: false,
            noSideBar: false,
        };
    }
    plot(element) {
        this.widget = new BarPlot(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:x", () => this.replot(), this);
        this.model.on("change:y", () => this.replot(), this);
        this.model.on("change:hue", () => this.replot(), this);
        this.model.on("change:direction", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
    setSelectedValues(values) {
        this.model.set({ selectedValuesRecords: values });
        this.model.save_changes();
    }
}
exports.BarPlotView = BarPlotView;


/***/ }),

/***/ "./lib/graphs/baseplot.js":
/*!********************************!*\
  !*** ./lib/graphs/baseplot.js ***!
  \********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BasePlot = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const d3_axis_1 = __webpack_require__(/*! d3-axis */ "./node_modules/d3-axis/src/index.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
__webpack_require__(/*! ../../css/graphs.css */ "./css/graphs.css");
class BasePlot extends base_widget_1.BaseWidget {
    constructor(element) {
        super(element);
        this.margin = base_1.WIDGET_MARGIN;
    }
    init(width, height) {
        this.svg = d3.select(this.element)
            .append("svg")
            .attr("width", width ? width - 2 : 0)
            .attr("height", height || 0)
            .attr("class", "graph");
        this.gGrid = this.svg.append("g")
            .attr("transform", `translate(${this.margin.left},${this.margin.top})`);
    }
    getXLinearScale(params) {
        const { domain, width, leftPadding = 0 } = params;
        const innerWidth = width - this.margin.left - this.margin.right;
        const scale = d3.scaleLinear().range([leftPadding, innerWidth]);
        scale.domain(domain).nice();
        return scale;
    }
    getYLinearScale(params) {
        const { domain, height, topPadding = 0 } = params;
        const innerHeight = height - this.margin.top - this.margin.bottom;
        const scale = d3.scaleLinear().range([innerHeight, topPadding]);
        scale.domain(domain).nice();
        return scale;
    }
    getXBandScale(params) {
        const { values, padding, width, leftPadding = 0 } = params;
        const innerWidth = width - this.margin.left - this.margin.right;
        const scale = d3.scaleBand().range([leftPadding, innerWidth]);
        scale.domain(values).padding(padding);
        return scale;
    }
    getYBandScale(params) {
        const { values, height, padding, topPadding = 0 } = params;
        const innerHeight = height - this.margin.top - this.margin.bottom;
        const scale = d3.scaleBand().range([innerHeight, topPadding]);
        scale.domain(values).padding(padding);
        return scale;
    }
    plotAxes(params) {
        const { svg, xScale, yScale, xLabel, yLabel, xAxisFormatter, yAxisFormatter } = params;
        const height = this.getScaleRangeStart(yScale);
        // Create and configure Y axis
        const yAxis = this.createYAxis(svg, yScale, yLabel, yAxisFormatter);
        // Calculate max width of Y axis tick labels
        const maxTickWidth = this.calculateMaxTickWidth(yAxis);
        // Adjust X scale range based on Y axis width
        this.adjustXScaleRange(xScale, maxTickWidth);
        // Position Y axis
        yAxis.attr("transform", `translate(${this.getScaleRangeStart(xScale)}, 0)`);
        // Create and configure X axis
        const xAxis = this.createXAxis(svg, xScale, height, xLabel, xAxisFormatter);
        return { xAxis, yAxis };
    }
    createYAxis(svg, yScale, yLabel, yAxisFormatter) {
        const yAxisGenerator = this.isBandScale(yScale)
            ? (0, d3_axis_1.axisLeft)(yScale)
            : (0, d3_axis_1.axisLeft)(yScale);
        if (yAxisFormatter) {
            yAxisFormatter(yAxisGenerator);
        }
        const yAxis = svg
            .append("g")
            .attr("class", "y axis")
            .call(yAxisGenerator);
        // Add Y axis label
        yAxis
            .append("text")
            .attr("class", "label")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dx", -this.getScaleRangeEnd(yScale))
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .attr("fill", "black")
            .text(yLabel);
        return yAxis;
    }
    createXAxis(svg, xScale, height, xLabel, xAxisFormatter) {
        const xAxisGenerator = this.isBandScale(xScale)
            ? (0, d3_axis_1.axisBottom)(xScale)
            : (0, d3_axis_1.axisBottom)(xScale);
        if (xAxisFormatter) {
            xAxisFormatter(xAxisGenerator);
        }
        const xAxis = svg
            .append("g")
            .attr("class", "x axis")
            .attr("transform", `translate(0, ${height})`)
            .call(xAxisGenerator);
        // Add X axis label
        xAxis
            .append("text")
            .attr("class", "label")
            .attr("x", this.getScaleRangeEnd(xScale))
            .attr("y", -6)
            .style("text-anchor", "end")
            .attr("fill", "black")
            .text(xLabel);
        return xAxis;
    }
    calculateMaxTickWidth(yAxis) {
        let maxWidth = 0;
        yAxis.selectAll(".tick text").each(function () {
            const bbox = this.getBBox();
            maxWidth = Math.max(maxWidth, bbox.width);
        });
        return maxWidth;
    }
    adjustXScaleRange(xScale, maxTickWidth) {
        const xRange = xScale.range();
        xRange[0] += maxTickWidth;
        xScale.range(xRange);
    }
    getScaleRangeStart(scale) {
        return scale.range()[0];
    }
    getScaleRangeEnd(scale) {
        return scale.range()[1];
    }
    isBandScale(scale) {
        return typeof scale.bandwidth === "function";
    }
}
exports.BasePlot = BasePlot;


/***/ }),

/***/ "./lib/graphs/horizon.js":
/*!*******************************!*\
  !*** ./lib/graphs/horizon.js ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HorizonChartView = exports.HorizonChartModel = exports.HorizonChart = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const baseplot_1 = __webpack_require__(/*! ./baseplot */ "./lib/graphs/baseplot.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const tools_1 = __webpack_require__(/*! ./tools/tools */ "./lib/graphs/tools/tools.js");
const MARGIN = { top: 30, right: 10, bottom: 10, left: 10 };
class HorizonChart extends baseplot_1.BasePlot {
    // Extrae la lógica de extracción de datos originales
    extractOriginalDataFromSelected(container) {
        const selectedSeries = [];
        container.selectAll('.horizon-series.selected').each(function (d) {
            const [, values] = d;
            const originalData = values.map(point => point.originalData);
            selectedSeries.push(...originalData);
        });
        return selectedSeries;
    }
    // Extrae el manejo del click de serie
    createSeriesClickHandler(clickSelectButton, setSelectedValues, GG) {
        return (event, [seriesKey, seriesValues]) => {
            const canSelect = Boolean(clickSelectButton?.isSelected);
            if (!canSelect)
                return;
            setTimeout(() => {
                const selectedSeries = this.extractOriginalDataFromSelected(GG);
                if (setSelectedValues) {
                    setSelectedValues(selectedSeries);
                }
            }, 0);
        };
    }
    // Extrae la función de actualización desde botones
    createUpdateSelectedFromButtons(GG, setSelectedValues) {
        return () => {
            const selectedSeries = this.extractOriginalDataFromSelected(GG);
            setSelectedValues?.(selectedSeries);
        };
    }
    /**
     * Procesa y transforma los datos crudos en el formato interno del Horizon Chart
     * @param data - Array de objetos con los datos originales
     * @param xValue - Nombre de la columna que contiene las fechas
     * @param yValue - Nombre de la columna que contiene los valores numéricos
     * @param seriesValue - (Opcional) Nombre de la columna para agrupar en series
     * @returns Map donde la clave es el nombre de la serie y el valor es un array de puntos ordenados
     */
    processData(data, xValue, yValue, seriesValue) {
        // Parsers de tiempo: Convierten strings de fecha a objetos Date
        // Soporta formatos: "2025-10-22T14:30:00" o "2025-10-22"
        const parseTime = d3.timeParse("%Y-%m-%dT%H:%M:%S") || d3.timeParse("%Y-%m-%d");
        // Transforma cada fila de datos al formato interno
        const preparedData = data.map((d, index) => ({
            x_: d[xValue] ? parseTime(d[xValue]) || new Date(d[xValue]) : null, // Convierte string a Date
            y_: +d[yValue], // Convierte a número con el operador unario +
            series: seriesValue ? String(d[seriesValue]) : 'default', // Identifica la serie o usa 'default'
            id: index, // Agrega ID único
            originalData: { ...d } // Almacena copia de los datos originales
        })).filter(d => d.x_ instanceof Date && !Number.isNaN(d.x_.getTime()) && Number.isFinite(d.y_)); // Filtra datos inválidos
        // Agrupa los datos por serie y ordena cada grupo cronológicamente
        // d3.rollup crea un Map<string, HorizonDataPoint[]>
        const series = d3.rollup(preparedData, (values) => d3.sort(values, d => d.x_.getTime()), // Ordena por timestamp
        // Ordena por timestamp
        d => d.series // Clave de agrupación: nombre de la serie
        );
        return series;
    }
    /**
     * Método principal que renderiza el Horizon Chart
     * @param params - Parámetros de configuración del gráfico
     */
    plot(params) {
        // Desestructura los parámetros recibidos
        const { data, xValue, yValue, seriesValue, bands, height: containerHeight, noSideBar, setSelectedValues } = params;
        // Calcula el ancho disponible (resta el espacio del sidebar si está visible)
        let width = params.width ?? 0;
        if (!noSideBar)
            width = width ? width - tools_1.SideBar.SIDE_BAR_WIDTH : 0;
        // Procesa los datos crudos y los agrupa por serie
        const seriesData = this.processData(data, xValue, yValue, seriesValue);
        const seriesKeys = Array.from(seriesData.keys());
        // Calcula la altura por serie basada en la altura total del contenedor
        const availableHeight = (containerHeight ?? 400) - MARGIN.top - MARGIN.bottom;
        const singleHeight = seriesKeys.length > 0
            ? Math.max(40, availableHeight / seriesKeys.length) // Mínimo 40px por serie
            : 100; // Valor por defecto si no hay series
        // Usa la altura total del contenedor
        const totalHeight = containerHeight ?? 400;
        // Inicializa el SVG con las dimensiones calculadas
        this.init(width, totalHeight);
        const GG = this.gGrid; // Referencia al grupo SVG principal
        // Genera un ID único para los elementos SVG (clip-paths y paths)
        const uid = `horizon-${Math.random().toString(16).slice(2)}`;
        let clickSelectButton = null;
        // --- CÁLCULO DE DOMINIOS (Rangos de datos) ---
        // 1. Aplana todos los datos de todas las series en un solo array
        const allDataPoints = Array.from(seriesData.values()).flat();
        // 2. Calcula el dominio X (rango de fechas)
        let xDomain;
        const xExtent = d3.extent(allDataPoints, d => d.x_); // Encuentra [fecha_mínima, fecha_máxima]
        // Si no hay datos válidos, usa un rango por defecto (ayer - hoy)
        if (xExtent[0] === undefined || xExtent[1] === undefined) {
            const now = new Date();
            xDomain = [d3.timeDay.offset(now, -1), now];
        }
        else {
            xDomain = [xExtent[0], xExtent[1]];
        }
        // 3. Calcula el dominio Y (rango de valores)
        const yMax = d3.max(allDataPoints, d => d.y_); // Encuentra el valor máximo
        const yDomain = [0, yMax ?? 0]; // Dominio desde 0 hasta el máximo
        // --- FIN DE CÁLCULO DE DOMINIOS ---
        // --- ESCALAS (Mapean datos a posiciones en píxeles) ---
        // Escala X: Convierte fechas a posiciones horizontales en el SVG
        const xScale = d3.scaleTime()
            .domain(xDomain) // Rango de fechas [fecha_inicio, fecha_fin]
            .range([MARGIN.left, width - MARGIN.right]); // Espacio físico disponible en píxeles
        // Escala Y: Convierte valores numéricos a posiciones verticales
        // La multiplicación por 'bands' crea el efecto de superposición del Horizon Chart
        const yScale = d3.scaleLinear()
            .domain(yDomain)
            .range([singleHeight, singleHeight - bands * singleHeight]);
        // --- GENERADOR DE ÁREA (Crea las formas SVG) ---
        // Define cómo convertir datos en paths SVG de área rellena
        const area = d3.area()
            .defined(d => !Number.isNaN(d.y_))
            .x(d => xScale(d.x_))
            .y0(singleHeight)
            .y1(d => yScale(d.y_));
        // --- ESQUEMA DE COLORES ---
        // Selecciona una paleta de azules de D3, ajustada al número de bandas
        const colorScheme = d3.schemeBlues[Math.max(3, bands)] || d3.schemeBlues[3];
        // Toma los colores más intensos (últimos N colores de la paleta)
        const colors = colorScheme.slice(0, bands);
        // --- EJE TEMPORAL (Opcional) ---
        // Crea un eje temporal en la parte superior del gráfico
        GG.append('g')
            .attr('transform', `translate(0, ${MARGIN.top})`) // Posiciona el eje arriba
            .call(d3.axisTop(xScale).ticks(width / 80).tickSizeOuter(0)) // Crea eje con marcas de tiempo
            .call(g => g.select('.domain').remove()); // Remueve la línea base del eje
        // --- CREACIÓN DE GRUPOS POR SERIE ---
        // Grupos por serie: Ajustados a la nueva altura
        const seriesGroup = GG.selectAll('.horizon-series')
            .data(seriesData)
            .enter().append('g')
            .attr('class', 'horizon-series')
            .attr('transform', (d, i) => `translate(0, ${i * singleHeight + MARGIN.top})`);
        const handleSeriesClick = this.createSeriesClickHandler(clickSelectButton, setSelectedValues, GG);
        seriesGroup
            .on('mouseenter.hover', function () {
            const enabled = Boolean(clickSelectButton?.isSelected);
            d3.select(this)
                .classed('click-select-enabled', enabled)
                .style('cursor', enabled ? 'pointer' : 'default');
        })
            .on('mouseleave.hover', function () {
            d3.select(this)
                .classed('click-select-enabled', false)
                .style('cursor', 'default');
        });
        // --- DEFINICIONES SVG (Clip Paths y Paths reutilizables) ---
        seriesGroup.append('defs').each(function ([key, values], i) {
            const defs = d3.select(this);
            defs.append('clipPath')
                .attr('id', `${uid}-clip-${i}`)
                .append('rect')
                .attr('y', 0)
                .attr('width', width)
                .attr('height', singleHeight);
            defs.append('path')
                .attr('id', `${uid}-path-${i}`)
                .attr('d', area(values));
        });
        // Bandas superpuestas: Ajustadas a la nueva altura
        seriesGroup.append('g')
            .attr('clip-path', (d, i) => `url(#${uid}-clip-${i})`)
            .selectAll('use')
            .data((d, i) => new Array(bands).fill(i))
            .enter().append('use')
            .attr('xlink:href', (i) => `#${uid}-path-${i}`)
            .attr('fill', (_, i) => colors[i]) // CORRECCIÓN: Usa el índice directo, no invertido
            .attr('transform', (_, i) => `translate(0, ${i * singleHeight})`); // Desplazamiento dinámico
        // FUNCIONAMIENTO:
        // - Banda 0 (más clara):  transform(0, 0)    - Sin desplazamiento, muestra parte superior
        // - Banda 1:              transform(0, 30)   - Desplazada 30px, muestra segunda franja
        // - Banda 2:              transform(0, 60)   - Desplazada 60px, muestra tercera franja
        // - Banda 3 (más oscura): transform(0, 90)   - Desplazada 90px, muestra parte inferior
        // El clip-path recorta cada banda para que solo sea visible su porción
        // Resultado: Valores altos = más bandas superpuestas = color más intenso
        // --- ETIQUETAS DE SERIE ---
        // Etiquetas: Centradas en la nueva altura
        seriesGroup.append('text')
            .attr('x', MARGIN.left + 4)
            .attr('y', (singleHeight + 1) / 2) // Centrado con el padding
            .attr('dy', '0.35em')
            .attr('fill', 'currentColor')
            .style('font-size', '12px')
            .text(([key]) => key);
        // --- BARRA LATERAL DE HERRAMIENTAS (Opcional) ---
        if (!noSideBar) {
            const updateSelectedFromButtons = this.createUpdateSelectedFromButtons(GG, setSelectedValues);
            clickSelectButton = new tools_1.ClickSelectButton(false);
            clickSelectButton.addWhenSelectedCallback(() => {
                seriesGroup.style('cursor', 'pointer');
            });
            clickSelectButton.addWhenUnselectedCallback(() => {
                seriesGroup.style('cursor', 'default');
            });
            const deselectAllButton = new tools_1.DeselectAllButton(seriesGroup, updateSelectedFromButtons);
            seriesGroup.on('click.clickSelect', (event, d) => {
                if (!clickSelectButton?.isSelected)
                    return;
                clickSelectButton.selectionClickEffect(d3.select(event.currentTarget));
                handleSeriesClick(event, d);
            });
            const sideBar = new tools_1.SideBar(this.element, clickSelectButton, deselectAllButton);
            sideBar.inicializar();
        }
    }
}
exports.HorizonChart = HorizonChart;
class HorizonChartModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: HorizonChartModel.model_name,
            _view_name: HorizonChartModel.view_name,
            dataRecords: [],
            x: String,
            y: String,
            series: String,
            bands: 4,
            mode: 'offset',
            selectedValuesRecords: [],
        };
    }
}
exports.HorizonChartModel = HorizonChartModel;
HorizonChartModel.model_name = "HorizonChartModel";
HorizonChartModel.view_name = "HorizonChartView";
class HorizonChartView extends base_1.BaseView {
    params() {
        return {
            data: this.model.get("dataRecords"),
            xValue: this.model.get("x"),
            yValue: this.model.get("y"),
            seriesValue: this.model.get("series"),
            bands: this.model.get("bands"),
            mode: this.model.get("mode"),
            setSelectedValues: this.setSelectedValues.bind(this),
            width: this.width,
            height: this.height,
            noSideBar: false,
        };
    }
    plot(element) {
        this.widget = new HorizonChart(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:x", () => this.replot(), this);
        this.model.on("change:y", () => this.replot(), this);
        this.model.on("change:series", () => this.replot(), this);
        this.model.on("change:bands", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
    setSelectedValues(values) {
        this.model.set({ selectedValuesRecords: values });
        this.model.save_changes();
    }
}
exports.HorizonChartView = HorizonChartView;


/***/ }),

/***/ "./lib/graphs/radviz.js":
/*!******************************!*\
  !*** ./lib/graphs/radviz.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RadVizView = exports.RadVizModel = exports.RadViz = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const baseplot_1 = __webpack_require__(/*! ./baseplot */ "./lib/graphs/baseplot.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const tools_1 = __webpack_require__(/*! ./tools/tools */ "./lib/graphs/tools/tools.js");
class RadViz extends baseplot_1.BasePlot {
    constructor() {
        super(...arguments);
        this.chartRadius = 0;
        this.centerX = 0;
        this.centerY = 0;
    }
    createAxes(dimensions) {
        const n = dimensions.length;
        return dimensions.map((key, i) => ({
            label: key,
            angle: (2 * Math.PI * i) / n,
            x: Math.cos((2 * Math.PI * i) / n),
            y: Math.sin((2 * Math.PI * i) / n)
        }));
    }
    createNormalizationScales(data, dimensions) {
        const scales = {};
        for (const key of dimensions) {
            const extent = d3.extent(data, d => d[key]);
            scales[key] = d3.scaleLinear().domain(extent).range([0, 1]);
        }
        return scales;
    }
    calculateRadVizPositions(data, dimensions, axes, scales) {
        return data.map((d, index) => {
            let sumW = 0, x = 0, y = 0;
            for (let i = 0; i < dimensions.length; i++) {
                const key = dimensions[i];
                const w = scales[key](d[key]);
                sumW += w;
                x += w * axes[i].x;
                y += w * axes[i].y;
            }
            x /= sumW;
            y /= sumW;
            return {
                x: x * this.chartRadius,
                y: y * this.chartRadius,
                originalData: d,
                id: index
            };
        });
    }
    plot(params) {
        const { data, dimensions, hue, setSelectedValues, width, height, noSideBar } = params;
        let actualWidth = width;
        let clickSelectButton = null;
        let boxSelectButton = null;
        let deselectAllButton = null;
        if (!noSideBar)
            actualWidth = width ? width - tools_1.SideBar.SIDE_BAR_WIDTH : 0;
        this.init(actualWidth, height);
        const GG = this.gGrid;
        // Calculate chart dimensions
        const chartWidth = (actualWidth || this.element.clientWidth || 500) - this.margin.left - this.margin.right;
        const chartHeight = (height || this.element.clientHeight || 500) - this.margin.top - this.margin.bottom;
        this.chartRadius = Math.min(chartWidth, chartHeight) / 2 - 50;
        this.centerX = chartWidth / 2;
        this.centerY = chartHeight / 2;
        // Create dial group
        const dial = GG.append("g")
            .attr("transform", `translate(${this.centerX}, ${this.centerY})`);
        function callUpdateSelected() {
            if (setSelectedValues) {
                const selectedData = dial.selectAll(".point.selected").data();
                const cleanedData = selectedData.map((d) => d.originalData);
                setSelectedValues(cleanedData);
            }
            // Update visual styling based on selection
            updateSelectionStyling();
        }
        function updateSelectionStyling() {
            const selectedPoints = dial.selectAll(".point.selected");
            const unselectedPoints = dial.selectAll(".point:not(.selected)");
            // PRIMERO: Restaurar TODOS los puntos a su estado original
            pointSelection
                .attr("fill", (d) => {
                if (hue && d.originalData[hue] !== undefined) {
                    return colorScale(String(d.originalData[hue]));
                }
                return colorScale("default");
            })
                .attr("fill-opacity", 0.7)
                .attr("stroke", "#000")
                .attr("stroke-width", 0.5);
            // SEGUNDO: Si hay selecciones, aplicar estilos específicos
            if (selectedPoints.size() > 0) {
                // Style selected points (highlighted)
                selectedPoints
                    .attr("fill-opacity", 1)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#000");
                // Style unselected points (grayed out)
                unselectedPoints
                    .attr("fill", "#888")
                    .attr("fill-opacity", 0.3)
                    .attr("stroke", "#666")
                    .attr("stroke-width", 0.5);
            }
        }
        // Use provided dimensions instead of detecting numeric columns
        if (!dimensions || dimensions.length < 2) {
            console.warn("RadViz requires at least 2 dimensions");
            return;
        }
        // Create axes
        const axes = this.createAxes(dimensions);
        // Create normalization scales
        const scales = this.createNormalizationScales(data, dimensions);
        // Calculate RadViz positions
        const points = this.calculateRadVizPositions(data, dimensions, axes, scales);
        // Create color scale
        let colorScale;
        if (hue && data.length > 0) {
            const categories = Array.from(new Set(data.map(d => String(d[hue]))));
            colorScale = d3.scaleOrdinal(d3.schemeCategory10).domain(categories);
        }
        else {
            colorScale = d3.scaleOrdinal(["#1f77b4"]).domain(["default"]);
        }
        // Draw axis labels
        dial.selectAll("text.axis-label")
            .data(axes)
            .enter()
            .append("text")
            .attr("class", "axis-label")
            .attr("x", d => d.x * (this.chartRadius + 15))
            .attr("y", d => d.y * (this.chartRadius + 15))
            .attr("text-anchor", "middle")
            .attr("font-family", "sans-serif")
            .attr("font-size", 12)
            .attr("fill", "black")
            .text(d => d.label);
        const axisPointsSelection = dial.selectAll("circle.axis-point").data(axes);
        const axisPointsEnter = axisPointsSelection.enter()
            .append("circle")
            .attr("class", "axis-point")
            .attr("cx", d => d.x * this.chartRadius)
            .attr("cy", d => d.y * this.chartRadius)
            .attr("r", 6)
            .attr("fill", "#f00a0aff")
            .attr("cursor", "move");
        const axisPoints = axisPointsEnter.merge(axisPointsSelection)
            .attr("cx", d => d.x * this.chartRadius)
            .attr("cy", d => d.y * this.chartRadius);
        // Add drag behavior to axis lines
        const chartRadius = this.chartRadius;
        const pointDragBehavior = d3.drag()
            .on("start", function (event, d) {
            d3.select(this).attr("r", 8);
        })
            .on("drag", (event, d) => {
            // Obtener coordenadas del mouse relativas al centro del dial
            const [mouseX, mouseY] = d3.pointer(event, dial.node());
            // Calcular el ángulo desde el centro hacia el mouse
            const angle = Math.atan2(mouseY, mouseX);
            // Actualizar los datos del eje (valores normalizados entre -1 y 1)
            d.x = Math.cos(angle);
            d.y = Math.sin(angle);
            d.angle = angle;
            // Calcular la posición exacta en el perímetro del círculo (coordenadas absolutas)
            const newX = d.x * chartRadius;
            const newY = d.y * chartRadius;
            // Actualizar el punto del eje correspondiente
            dial.selectAll("circle.axis-point")
                .filter((l) => l === d)
                .attr("cx", newX)
                .attr("cy", newY);
            dial.selectAll("text.axis-label")
                .filter((l) => l === d)
                .attr("x", d.x * (chartRadius + 15))
                .attr("y", d.y * (chartRadius + 15));
            // Recalcular y actualizar posiciones de todos los puntos
            const updatedPoints = this.calculateRadVizPositions(data, dimensions, axes, scales);
            pointSelection
                .data(updatedPoints)
                .attr("cx", (pt) => pt.x)
                .attr("cy", (pt) => pt.y);
        })
            .on("end", function (event, d) {
            d3.select(this).attr("r", 6);
        });
        axisPoints.call(pointDragBehavior);
        // Draw outer circle
        dial.append("circle")
            .attr("cx", 0)
            .attr("cy", 0)
            .attr("r", this.chartRadius)
            .attr("fill", "none")
            .attr("stroke", "#ddd")
            .attr("stroke-width", 1);
        // Draw points
        const pointSelection = dial.selectAll("circle.point")
            .data(points)
            .enter()
            .append("circle")
            .attr("class", "point")
            .attr("cx", d => d.x)
            .attr("cy", d => d.y)
            .attr("r", 4)
            .attr("fill", d => {
            if (hue && d.originalData[hue] !== undefined) {
                return colorScale(String(d.originalData[hue]));
            }
            return colorScale("default");
        })
            .attr("fill-opacity", 0.7)
            .attr("stroke", "#000")
            .attr("stroke-width", 0.5)
            .on("click", (event, d) => {
            if (clickSelectButton) {
                clickSelectButton.selectionClickEffect(d3.select(event.currentTarget));
                callUpdateSelected();
            }
        });
        // Initialize sidebar with selection tools
        if (!noSideBar) {
            clickSelectButton = new tools_1.ClickSelectButton(true);
            deselectAllButton = new tools_1.DeselectAllButton(pointSelection, callUpdateSelected);
            // Create scales for box selection (using chart coordinates)
            const xScale = d3.scaleLinear()
                .domain([-this.chartRadius, this.chartRadius])
                .range([-this.chartRadius, this.chartRadius]);
            const yScale = d3.scaleLinear()
                .domain([-this.chartRadius, this.chartRadius])
                .range([-this.chartRadius, this.chartRadius]);
            boxSelectButton = new tools_1.BoxSelectButton({
                xScale: xScale,
                yScale: yScale,
                x_value: "x",
                y_value: "y",
                x_translate: this.centerX,
                y_translate: this.centerY,
                selectables: pointSelection,
                callUpdateSelected: callUpdateSelected,
                base: dial,
                selected: false
            });
            const sideBar = new tools_1.SideBar(this.element, clickSelectButton, boxSelectButton, deselectAllButton);
            sideBar.inicializar();
        }
    }
}
exports.RadViz = RadViz;
class RadVizModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: RadVizModel.model_name,
            _view_name: RadVizModel.view_name,
            dataRecords: [],
            dimensions: [],
            hue: String,
            elementId: String,
            selectedValuesRecords: [],
        };
    }
}
exports.RadVizModel = RadVizModel;
RadVizModel.model_name = "RadVizModel";
RadVizModel.view_name = "RadVizView";
class RadVizView extends base_1.BaseView {
    params() {
        return {
            data: this.model.get("dataRecords"),
            dimensions: this.model.get("dimensions"),
            hue: this.model.get("hue"),
            setSelectedValues: this.setSelectedValues.bind(this),
            width: this.width,
            height: this.height,
            noSideBar: false,
        };
    }
    plot(element) {
        this.widget = new RadViz(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:hue", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
    setSelectedValues(values) {
        this.model.set({ selectedValuesRecords: values });
        this.model.save_changes();
    }
}
exports.RadVizView = RadVizView;


/***/ }),

/***/ "./lib/graphs/scatterplot.js":
/*!***********************************!*\
  !*** ./lib/graphs/scatterplot.js ***!
  \***********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ScatterPlotView = exports.ScatterPlotModel = exports.ScatterPlot = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const baseplot_1 = __webpack_require__(/*! ./baseplot */ "./lib/graphs/baseplot.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const tools_1 = __webpack_require__(/*! ./tools/tools */ "./lib/graphs/tools/tools.js");
const DEFAULT_COLOR = "#4299e1";
class ScatterPlot extends baseplot_1.BasePlot {
    plot(params) {
        const { data, x, y, size, height, hue, setSelectedValues, noSideBar } = params;
        let { width, opacity, pointSize } = params;
        opacity = opacity ?? 0.7;
        pointSize = pointSize ?? 5;
        if (!noSideBar)
            width = width ? width - tools_1.SideBar.SIDE_BAR_WIDTH : 0;
        let clickSelectButton = null;
        let deselectAllButton = null;
        let boxSelectButton = null;
        const randomString = Math.floor(Math.random() * Date.now() * 10000).toString(36);
        this.init(width, height);
        const GG = this.gGrid;
        function callUpdateSelected() {
            if (setSelectedValues) {
                const selectedData = GG.selectAll(".scatter_dot.selected").data();
                // Filtrar los atributos internos antes de guardar
                const cleanedData = selectedData.map((d) => {
                    const { x_, y_, id, originalData, size_, ...rest } = d;
                    return originalData || rest; // Return original data if available, otherwise filtered data
                });
                setSelectedValues(cleanedData);
            }
        }
        const mouseClick = (event, d) => {
            if (clickSelectButton) {
                clickSelectButton.selectionClickEffect(d3.select(event.currentTarget));
                callUpdateSelected();
            }
        };
        // Procesar datos
        const processedData = data
            .map((row, index) => {
            const xVal = Number.parseFloat(row[x]);
            const yVal = Number.parseFloat(row[y]);
            if (Number.isNaN(xVal) || Number.isNaN(yVal)) {
                return null;
            }
            const processed = {
                ...row,
                x_: xVal,
                y_: yVal,
                id: index,
                originalData: { ...row } // Store a copy of the original row
            };
            if (size && row[size] !== undefined) {
                const sizeVal = Number.parseFloat(row[size]);
                if (!Number.isNaN(sizeVal)) {
                    processed.size_ = sizeVal;
                }
            }
            return processed;
        })
            .filter((d) => d !== null);
        if (processedData.length === 0) {
            console.warn("No hay datos válidos para graficar"); // mensajes de error
            return;
        }
        if (width == null || height == null) {
            throw new Error("Width and height must be defined"); // mensajes de error
        }
        // Crear escalas X e Y
        const xExtent = d3.extent(processedData, d => d.x_);
        const yExtent = d3.extent(processedData, d => d.y_);
        const xScale = this.getXLinearScale({ domain: xExtent, width });
        const yScale = this.getYLinearScale({ domain: yExtent, height });
        // Escala de color categórica
        let colorScale;
        if (hue == null) {
            colorScale = d3.scaleOrdinal([DEFAULT_COLOR]);
        }
        else {
            const categories = Array.from(new Set(processedData
                .map(d => d[hue])
                .filter(v => v !== undefined && v !== null))).map(String);
            if (categories.length === 0) {
                colorScale = d3.scaleOrdinal([DEFAULT_COLOR]);
            }
            else {
                colorScale = d3.scaleOrdinal()
                    .domain(categories)
                    .range(d3.schemeCategory10);
            }
        }
        // Escala de tamaño
        let sizeScale = null;
        if (size && processedData.some(d => d.size_ !== undefined)) {
            const sizeExtent = d3.extent(processedData, d => d.size_);
            sizeScale = d3.scaleLinear()
                .domain(sizeExtent)
                .range([pointSize * 0.5, pointSize * 2]);
        }
        // Dibujar ejes
        this.plotAxes({
            svg: GG,
            xScale,
            yScale,
            xLabel: x,
            yLabel: y
        });
        const dots = GG.selectAll(".scatter_dot").data(processedData).enter().append("circle");
        dots.attr("id", function (d, i) {
            return "scatter_dot-" + randomString + "-" + d.id;
        })
            .attr('class', 'scatter_dot')
            .attr("cx", d => xScale(d.x_))
            .attr("cy", d => yScale(d.y_))
            .attr("r", d => {
            if (sizeScale && d.size_ !== undefined) {
                return sizeScale(d.size_);
            }
            return pointSize;
        })
            .attr("fill", d => {
            if (hue == null)
                return DEFAULT_COLOR;
            return colorScale(String(d[hue]));
        })
            .attr("fill-opacity", opacity)
            .on("click", mouseClick);
        if (!noSideBar) {
            clickSelectButton = new tools_1.ClickSelectButton(true);
            deselectAllButton = new tools_1.DeselectAllButton(dots, callUpdateSelected);
            boxSelectButton = new tools_1.BoxSelectButton({
                xScale: xScale,
                yScale: yScale,
                x_value: x,
                y_value: y,
                x_translate: 0,
                y_translate: 0,
                selectables: dots,
                callUpdateSelected: callUpdateSelected,
                base: GG,
                selected: false
            });
            const sideBar = new tools_1.SideBar(this.element, clickSelectButton, deselectAllButton, boxSelectButton);
            sideBar.inicializar();
        }
    }
}
exports.ScatterPlot = ScatterPlot;
class ScatterPlotModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: ScatterPlotModel.model_name,
            _view_name: ScatterPlotModel.view_name,
            dataRecords: [],
            x: String,
            y: String,
            hue: String,
            size: String,
            pointSize: 5,
            opacity: 0.7,
            elementId: String,
            selectedValuesRecords: []
        };
    }
}
exports.ScatterPlotModel = ScatterPlotModel;
ScatterPlotModel.model_name = "ScatterPlotModel";
ScatterPlotModel.view_name = "ScatterPlotView";
class ScatterPlotView extends base_1.BaseView {
    params() {
        return {
            data: this.model.get("dataRecords"),
            x: this.model.get("x"),
            y: this.model.get("y"),
            hue: this.model.get("hue"),
            setSelectedValues: this.setSelectedValues.bind(this),
            size: this.model.get("size"),
            pointSize: this.model.get("pointSize"),
            opacity: this.model.get("opacity"),
            width: this.width,
            height: this.height,
            noSideBar: false,
        };
    }
    plot(element) {
        this.widget = new ScatterPlot(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:x", () => this.replot(), this);
        this.model.on("change:y", () => this.replot(), this);
        this.model.on("change:hue", () => this.replot(), this);
        this.model.on("change:size", () => this.replot(), this);
        this.model.on("change:pointSize", () => this.replot(), this);
        this.model.on("change:opacity", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
    setSelectedValues(values) {
        this.model.set({ selectedValuesRecords: values });
        this.model.save_changes();
    }
}
exports.ScatterPlotView = ScatterPlotView;


/***/ }),

/***/ "./lib/graphs/starcoordinates.js":
/*!***************************************!*\
  !*** ./lib/graphs/starcoordinates.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.StarCoordinatesView = exports.StarCoordinatesModel = exports.StarCoordinates = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const baseplot_1 = __webpack_require__(/*! ./baseplot */ "./lib/graphs/baseplot.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const tools_1 = __webpack_require__(/*! ./tools/tools */ "./lib/graphs/tools/tools.js");
class StarCoordinates extends baseplot_1.BasePlot {
    constructor() {
        super(...arguments);
        this.chartRadius = 0;
        this.centerX = 0;
        this.centerY = 0;
    }
    createAnchors(dimensions) {
        const n = dimensions.length;
        return dimensions.map((feature, i) => {
            const angle = (2 * Math.PI * i) / n;
            return {
                feature: feature,
                x: Math.cos(angle),
                y: Math.sin(angle)
            };
        });
    }
    createNormalizationScales(data, dimensions) {
        const scales = {};
        for (const key of dimensions) {
            const extent = d3.extent(data, d => d[key]);
            scales[key] = d3.scaleLinear()
                .domain(extent)
                .range([0, 1]);
        }
        return scales;
    }
    calculateStarCoordinatesPositions(data, dimensions, anchors, scales) {
        return data.map((d, index) => {
            let x = 0, y = 0;
            for (let i = 0; i < dimensions.length; i++) {
                const key = dimensions[i];
                const normalizedValue = scales[key](d[key]);
                x += normalizedValue * anchors[i].x;
                y += normalizedValue * anchors[i].y;
            }
            return {
                x: x * this.chartRadius,
                y: y * this.chartRadius,
                originalData: d,
                id: index
            };
        });
    }
    plot(params) {
        const { data, dimensions, hue, setSelectedValues, width, height, noSideBar = false } = params;
        let actualWidth = width;
        let clickSelectButton = null;
        let boxSelectButton = null;
        let deselectAllButton = null;
        if (!noSideBar)
            actualWidth = width ? width - tools_1.SideBar.SIDE_BAR_WIDTH : 0;
        this.init(actualWidth, height);
        const GG = this.gGrid;
        if (!GG)
            return;
        const chartWidth = (actualWidth || this.element.clientWidth || 500) - this.margin.left - this.margin.right;
        const chartHeight = (height || this.element.clientHeight || 500) - this.margin.top - this.margin.bottom;
        this.chartRadius = Math.max(50, (Math.min(chartWidth, chartHeight) / 2) - Math.max(40, Math.min(100, Math.min(chartWidth, chartHeight) * 0.15)));
        this.centerX = chartWidth / 2;
        this.centerY = chartHeight / 2;
        // Create dial group
        const dial = GG.append("g")
            .attr("transform", `translate(${this.centerX}, ${this.centerY})`);
        // Use provided dimensions instead of detecting numeric columns
        if (!dimensions || dimensions.length < 2) {
            console.warn("StarCoordinates requires at least 2 dimensions");
            return;
        }
        // Create anchors
        const anchors = this.createAnchors(dimensions);
        // Create normalization scales
        const scales = this.createNormalizationScales(data, dimensions);
        // Calculate Star Coordinates positions
        const points = this.calculateStarCoordinatesPositions(data, dimensions, anchors, scales);
        // Create color scale
        let colorScale;
        if (hue && data.length > 0) {
            const categories = Array.from(new Set(data.map(d => String(d[hue]))));
            colorScale = d3.scaleOrdinal(d3.schemeCategory10).domain(categories);
        }
        else {
            colorScale = d3.scaleOrdinal(["#1f77b4"]).domain(["default"]);
        }
        // Draw anchor labels
        dial.selectAll("text.anchor-label")
            .data(anchors)
            .enter()
            .append("text")
            .attr("class", "anchor-label")
            .attr("x", d => {
            const offset = 25;
            const anchorX = d.x * this.chartRadius;
            const norm = Math.sqrt(anchorX * anchorX + (d.y * this.chartRadius) * (d.y * this.chartRadius));
            const offsetX = norm > 0 ? (anchorX / norm) * offset : 0;
            return anchorX + offsetX;
        })
            .attr("y", d => {
            const offset = 25;
            const anchorY = d.y * this.chartRadius;
            const norm = Math.sqrt((d.x * this.chartRadius) * (d.x * this.chartRadius) + anchorY * anchorY);
            const offsetY = norm > 0 ? (anchorY / norm) * offset : 0;
            return anchorY + offsetY;
        })
            .attr("text-anchor", d => {
            if (d.x > 0.1)
                return "start";
            if (d.x < -0.1)
                return "end";
            return "middle";
        })
            .attr("dominant-baseline", d => {
            if (d.y > 0.1)
                return "hanging";
            if (d.y < -0.1)
                return "baseline";
            return "central";
        })
            .style("font-size", "12px")
            .style("font-weight", "bold")
            .style("fill", "#333")
            .text(d => d.feature);
        dial.selectAll("line.axis-line")
            .data(anchors)
            .enter()
            .append("line")
            .attr("class", "axis-line")
            .attr("x1", 0)
            .attr("y1", 0)
            .attr("x2", d => d.x * this.chartRadius)
            .attr("y2", d => d.y * this.chartRadius)
            .style("stroke", "#999")
            .style("stroke-width", 1)
            .style("stroke-dasharray", "4 2");
        // Add drag behavior to axis points - WITH BOUNDARY RESTRICTIONS
        const chartRadius = this.chartRadius;
        const pointDragBehavior = d3.drag()
            .on("start", function (event, d) {
            d3.select(this).attr("stroke-width", 4);
        })
            .on("drag", (event, d) => {
            // Get mouse coordinates relative to dial center
            let [mouseX, mouseY] = d3.pointer(event, dial.node());
            // APPLY GENTLER BOUNDARY RESTRICTIONS - allow significant extension
            const maxDistance = chartRadius * 2.5; // Allow 2.5x beyond base radius for more freedom
            const distance = Math.hypot(mouseX, mouseY);
            if (distance > maxDistance) {
                // Scale back to maximum allowed distance
                const scale = maxDistance / distance;
                mouseX *= scale;
                mouseY *= scale;
            }
            // Restrict to reasonable canvas boundaries
            const canvasMargin = 50; // Larger margin for labels
            const maxX = this.centerX - canvasMargin;
            const maxY = this.centerY - canvasMargin;
            const minX = -this.centerX + canvasMargin;
            const minY = -this.centerY + canvasMargin;
            mouseX = Math.max(minX, Math.min(maxX, mouseX));
            mouseY = Math.max(minY, Math.min(maxY, mouseY));
            // Update relative coordinates
            d.x = mouseX / chartRadius;
            d.y = mouseY / chartRadius;
            // Update axis line
            dial.selectAll("line.axis-line")
                .filter((l) => l === d)
                .attr('x2', mouseX)
                .attr('y2', mouseY);
            // Update anchor label with offset from new position
            dial.selectAll("text.anchor-label")
                .filter((l) => l === d)
                .attr("x", () => {
                const offset = 25;
                const norm = Math.hypot(mouseX, mouseY);
                const offsetX = norm > 0 ? (mouseX / norm) * offset : 0;
                return mouseX + offsetX;
            })
                .attr("y", () => {
                const offset = 25;
                const norm = Math.hypot(mouseX, mouseY);
                const offsetY = norm > 0 ? (mouseY / norm) * offset : 0;
                return mouseY + offsetY;
            })
                .attr("text-anchor", () => {
                const normalizedX = mouseX / chartRadius;
                if (normalizedX > 0.1)
                    return "start";
                if (normalizedX < -0.1)
                    return "end";
                return "middle";
            })
                .attr("dominant-baseline", () => {
                const normalizedY = mouseY / chartRadius;
                if (normalizedY > 0.1)
                    return "hanging";
                if (normalizedY < -0.1)
                    return "baseline";
                return "central";
            });
            // Update anchor node position
            dial.selectAll("circle.anchor-node")
                .filter((l) => l === d)
                .attr('cx', mouseX)
                .attr('cy', mouseY);
            // Recalculate and update positions of all points
            const updatedPoints = this.calculateStarCoordinatesPositions(data, dimensions, anchors, scales);
            pointSelection
                .data(updatedPoints)
                .attr("cx", (pt) => pt.x)
                .attr("cy", (pt) => pt.y);
        })
            .on("end", function (event, d) {
            d3.select(this).attr("stroke-width", 2);
        });
        // Draw anchor nodes (black circles)
        dial.selectAll("circle.anchor-node")
            .data(anchors)
            .enter()
            .append("circle")
            .attr("class", "anchor-node")
            .attr("cx", (d) => d.x * this.chartRadius)
            .attr("cy", (d) => d.y * this.chartRadius)
            .attr("r", 6)
            .attr("fill", "#f00b0bff")
            .attr("stroke", "white")
            .attr("stroke-width", 2)
            .style("cursor", "move")
            .style("filter", "drop-shadow(2px 2px 4px rgba(0,0,0,0.3))")
            .call(pointDragBehavior);
        // Draw points
        const pointSelection = dial.selectAll("circle.point")
            .data(points)
            .enter()
            .append("circle")
            .attr("class", "point")
            .attr("cx", d => d.x)
            .attr("cy", d => d.y)
            .attr("r", 4)
            .attr("fill", d => {
            if (hue && d.originalData[hue] !== undefined) {
                return colorScale(String(d.originalData[hue]));
            }
            return colorScale("default");
        })
            .attr("fill-opacity", 0.8)
            .attr("stroke", "white")
            .attr("stroke-width", 2)
            .style("cursor", "pointer")
            .on("click", (event, d) => {
            // Integrate click selection tool if available
            if (clickSelectButton) {
                clickSelectButton.selectionClickEffect(d3.select(event.currentTarget));
                callUpdateSelected();
            }
            else {
                // Fallback: simple log
            }
        });
        function callUpdateSelected() {
            if (setSelectedValues) {
                const selectedData = dial.selectAll(".point.selected").data();
                const cleanedData = selectedData.map((d) => d.originalData);
                setSelectedValues(cleanedData);
            }
            // Update visual styling based on selection
            updateSelectionStyling();
        }
        function updateSelectionStyling() {
            const selectedPoints = dial.selectAll(".point.selected");
            const unselectedPoints = dial.selectAll(".point:not(.selected)");
            // PRIMERO: Restaurar TODOS los puntos a su estado original
            pointSelection
                .attr("fill", (d) => {
                if (hue && d.originalData[hue] !== undefined) {
                    return colorScale(String(d.originalData[hue]));
                }
                return colorScale("default");
            })
                .attr("fill-opacity", 0.8)
                .attr("stroke", "white")
                .attr("stroke-width", 2);
            // SEGUNDO: Si hay selecciones, aplicar estilos específicos
            if (selectedPoints.size() > 0) {
                // Style selected points (highlighted)
                selectedPoints
                    .attr("fill-opacity", 1)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#000");
                // Style unselected points (grayed out)
                unselectedPoints
                    .attr("fill", "#888")
                    .attr("fill-opacity", 0.3)
                    .attr("stroke", "#666")
                    .attr("stroke-width", 0.5);
            }
        }
        // Initialize sidebar with selection tools
        if (!noSideBar) {
            clickSelectButton = new tools_1.ClickSelectButton(true);
            deselectAllButton = new tools_1.DeselectAllButton(pointSelection, callUpdateSelected);
            // Create scales for box selection - matching the coordinate system of the points
            const maxCoord = chartRadius * 2.5; // Match the maximum allowed distance
            const xScale = d3.scaleLinear()
                .domain([-maxCoord, maxCoord])
                .range([-maxCoord, maxCoord]);
            const yScale = d3.scaleLinear()
                .domain([-maxCoord, maxCoord])
                .range([-maxCoord, maxCoord]);
            boxSelectButton = new tools_1.BoxSelectButton({
                xScale: xScale,
                yScale: yScale,
                x_value: "x",
                y_value: "y",
                x_translate: this.centerX, // Use center translation to match dial group
                y_translate: this.centerY, // Use center translation to match dial group
                selectables: pointSelection,
                callUpdateSelected: callUpdateSelected,
                base: dial, // Use the dial group where points are located
                selected: false
            });
            const sideBar = new tools_1.SideBar(this.element, clickSelectButton, boxSelectButton, deselectAllButton);
            sideBar.inicializar();
        }
    }
}
exports.StarCoordinates = StarCoordinates;
class StarCoordinatesModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: "StarCoordinatesModel",
            _view_name: "StarCoordinatesView",
        };
    }
}
exports.StarCoordinatesModel = StarCoordinatesModel;
class StarCoordinatesView extends base_1.BaseView {
    get dataRecords() { return this.model.get("dataRecords"); }
    get dimensions() { return this.model.get("dimensions"); }
    get hue() { return this.model.get("hue"); }
    params() {
        return {
            data: this.dataRecords,
            dimensions: this.dimensions,
            hue: this.hue,
            setSelectedValues: this.setSelectedValues.bind(this),
            width: this.width,
            height: this.height,
            noSideBar: false,
        };
    }
    plot(element) {
        this.widget = new StarCoordinates(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:dimensions", () => this.replot(), this);
        this.model.on("change:hue", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
    setSelectedValues(values) {
        this.model.set({ selectedValuesRecords: values });
        this.model.save_changes();
    }
}
exports.StarCoordinatesView = StarCoordinatesView;


/***/ }),

/***/ "./lib/graphs/tools/button_base.js":
/*!*****************************************!*\
  !*** ./lib/graphs/tools/button_base.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BaseButton = void 0;
const lucide_1 = __webpack_require__(/*! lucide */ "webpack/sharing/consume/default/lucide/lucide");
class BaseButton {
    addWhenSelectedCallback(whenSelectedCallback) {
        this.whenSelectedCallback = whenSelectedCallback;
    }
    addWhenUnselectedCallback(whenUnselectedCallback) {
        this.whenUnselectedCallback = whenUnselectedCallback;
    }
    constructor(selected = false) {
        this.isSelected = selected;
    }
    addClickNotification(notification) {
        this.clickNotify = notification;
    }
    notified() {
        this.unselect();
    }
    select() {
        this.isSelected = true;
        this.button.classList.add("is_selected");
        if (this.whenSelectedCallback)
            this.whenSelectedCallback();
    }
    unselect() {
        this.isSelected = false;
        this.button.classList.remove("is_selected");
        if (this.whenUnselectedCallback)
            this.whenUnselectedCallback();
    }
    createButton(icon) {
        this.button = document.createElement("button");
        if (this.isSelected) {
            this.button.classList.add("is_selected");
            if (this.whenSelectedCallback)
                this.whenSelectedCallback();
        }
        this.button.addEventListener("click", this.on_click.bind(this));
        if (icon) {
            const iconElement = (0, lucide_1.createElement)(icon);
            this.button.appendChild(iconElement);
        }
        return this.button;
    }
    on_click() {
        if (this.isSelected)
            return;
        this.clickNotify(this);
        this.select();
    }
}
exports.BaseButton = BaseButton;


/***/ }),

/***/ "./lib/graphs/tools/button_box_select.js":
/*!***********************************************!*\
  !*** ./lib/graphs/tools/button_box_select.js ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BoxSelectButton = void 0;
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
const lucide_1 = __webpack_require__(/*! lucide */ "webpack/sharing/consume/default/lucide/lucide");
const button_base_1 = __webpack_require__(/*! ./button_base */ "./lib/graphs/tools/button_base.js");
class BoxSelectButton extends button_base_1.BaseButton {
    constructor(params) {
        super(params.selected ?? false);
        this.mode = true;
        this.xScale = params.xScale;
        this.yScale = params.yScale;
        this.x_value = params.x_value;
        this.y_value = params.y_value;
        this.x_translate = params.x_translate;
        this.y_translate = params.y_translate;
        this.selectables = params.selectables;
        this.callUpdateSelected = params.callUpdateSelected;
        this.interationRect = params.base;
        // Compute brush extent from provided scales so the brush covers
        // the same coordinate system as the points (can be negative around center)
        const xRange = this.xScale.range();
        const yRange = this.yScale.range();
        const x0 = Math.min(xRange[0], xRange[1]);
        const x1 = Math.max(xRange[0], xRange[1]);
        const y0 = Math.min(yRange[0], yRange[1]);
        const y1 = Math.max(yRange[0], yRange[1]);
        this.brush = d3
            .brush()
            .extent([[x0, y0], [x1, y1]])
            .on("end", this.brushed.bind(this));
    }
    createButton() {
        return super.createButton(lucide_1.BoxSelect);
    }
    updateScales(xScale, yScale) {
        this.xScale = xScale;
        this.yScale = yScale;
        // When scales update, update the brush extent to match the new ranges
        const xRange = this.xScale.range();
        const yRange = this.yScale.range();
        const x0 = Math.min(xRange[0], xRange[1]);
        const x1 = Math.max(xRange[0], xRange[1]);
        const y0 = Math.min(yRange[0], yRange[1]);
        const y1 = Math.max(yRange[0], yRange[1]);
        this.brush.extent([[x0, y0], [x1, y1]]);
        // If the brush is already attached to the DOM, reapply it so the updated
        // extent takes effect immediately. Otherwise skip.
        const existing = this.interationRect.selectAll(".brush");
        if (!existing.empty()) {
            existing.call(this.brush);
        }
    }
    select() {
        super.select();
        this.mode = true;
        this.button.classList.add("mode_positive");
        this.button.classList.remove("mode_negative");
        this.interationRect
            .append("g")
            .attr("class", "brush")
            .call(this.brush);
    }
    unselect() {
        super.unselect();
        this.interationRect.select(".brush").remove();
    }
    on_click() {
        if (this.isSelected)
            this.changeMode();
        super.on_click();
    }
    changeMode() {
        this.mode = !this.mode;
        if (this.mode) {
            this.button.classList.add("mode_positive");
            this.button.classList.remove("mode_negative");
        }
        else {
            this.button.classList.add("mode_negative");
            this.button.classList.remove("mode_positive");
        }
    }
    brushed(event) {
        if (!event.selection)
            return;
        const [[x0, y0], [x1, y1]] = event.selection;
        // Primero limpiar todas las selecciones anteriores
        this.selectables.classed("selected", false);
        this.selectables.classed("selected", (d, i, nodes) => {
            const node = nodes[i];
            let overlap = false;
            // Distintos tipos de elementos SVG
            if (node.tagName === "rect") {
                const bbox = node.getBBox();
                overlap = !(bbox.x > x1 || bbox.x + bbox.width < x0 || bbox.y > y1 || bbox.y + bbox.height < y0);
            }
            else if (node.tagName === "circle") {
                // No sumar x_translate/y_translate porque el brush ya está en el mismo sistema de coordenadas
                const cx = Number.parseFloat(node.getAttribute("cx") || "0");
                const cy = Number.parseFloat(node.getAttribute("cy") || "0");
                const r = Number.parseFloat(node.getAttribute("r") || "0");
                overlap = cx >= x0 - r && cx <= x1 + r && cy >= y0 - r && cy <= y1 + r;
            }
            // Simplemente devolver si hay overlap (nueva selección reemplaza la anterior)
            return overlap;
        });
        this.callUpdateSelected();
        this.interationRect.select(".brush").call(this.brush.move, null);
    }
}
exports.BoxSelectButton = BoxSelectButton;


/***/ }),

/***/ "./lib/graphs/tools/button_click_select.js":
/*!*************************************************!*\
  !*** ./lib/graphs/tools/button_click_select.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ClickSelectButton = void 0;
const lucide_1 = __webpack_require__(/*! lucide */ "webpack/sharing/consume/default/lucide/lucide");
const button_base_1 = __webpack_require__(/*! ./button_base */ "./lib/graphs/tools/button_base.js");
class ClickSelectButton extends button_base_1.BaseButton {
    createButton() {
        return super.createButton(lucide_1.MousePointer);
    }
    selectionClickEffect(selection) {
        if (this.isSelected) {
            const wasSelected = selection.classed("selected");
            selection.classed("selected", !wasSelected);
        }
    }
}
exports.ClickSelectButton = ClickSelectButton;


/***/ }),

/***/ "./lib/graphs/tools/button_deselect_all.js":
/*!*************************************************!*\
  !*** ./lib/graphs/tools/button_deselect_all.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeselectAllButton = void 0;
const lucide_1 = __webpack_require__(/*! lucide */ "webpack/sharing/consume/default/lucide/lucide");
const button_base_1 = __webpack_require__(/*! ./button_base */ "./lib/graphs/tools/button_base.js");
class DeselectAllButton extends button_base_1.BaseButton {
    constructor(selectables, callUpdateSelected) {
        super();
        this.selectables = selectables;
        this.callUpdateSelected = callUpdateSelected;
    }
    on_click() {
        this.selectables.classed("selected", false);
        this.callUpdateSelected();
    }
    createButton() {
        return super.createButton(lucide_1.X);
    }
    select() {
        // Do nothing on select
    }
    unselect() {
        // Do nothing on unselect
    }
}
exports.DeselectAllButton = DeselectAllButton;


/***/ }),

/***/ "./lib/graphs/tools/side_bar.js":
/*!**************************************!*\
  !*** ./lib/graphs/tools/side_bar.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SideBar = void 0;
class SideBar {
    constructor(element, ...buttons) {
        this.buttons = buttons;
        this.sideBar = document.createElement("div");
        this.sideBar.style.width = SideBar.SIDE_BAR_WIDTH + "px";
        this.sideBar.className = "side_bar";
        this.sideBar.setAttribute("display", "flex");
        this.sideBar.setAttribute("flex-direction", "column");
        this.sideBar.setAttribute("justify-content", "flex-start");
        element.appendChild(this.sideBar);
    }
    inicializar() {
        for (let b of this.buttons) {
            const button = b.createButton();
            b.addClickNotification(this.notifyOtherButtons.bind(this));
            this.sideBar.appendChild(button);
        }
    }
    notifyOtherButtons(button) {
        for (let b of this.buttons) {
            if (b !== button)
                b.notified();
        }
    }
}
exports.SideBar = SideBar;
SideBar.SIDE_BAR_WIDTH = 32;


/***/ }),

/***/ "./lib/graphs/tools/tools.js":
/*!***********************************!*\
  !*** ./lib/graphs/tools/tools.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SideBar = exports.BoxSelectButton = exports.DeselectAllButton = exports.ClickSelectButton = void 0;
var button_click_select_1 = __webpack_require__(/*! ./button_click_select */ "./lib/graphs/tools/button_click_select.js");
Object.defineProperty(exports, "ClickSelectButton", ({ enumerable: true, get: function () { return button_click_select_1.ClickSelectButton; } }));
var button_deselect_all_1 = __webpack_require__(/*! ./button_deselect_all */ "./lib/graphs/tools/button_deselect_all.js");
Object.defineProperty(exports, "DeselectAllButton", ({ enumerable: true, get: function () { return button_deselect_all_1.DeselectAllButton; } }));
var button_box_select_1 = __webpack_require__(/*! ./button_box_select */ "./lib/graphs/tools/button_box_select.js");
Object.defineProperty(exports, "BoxSelectButton", ({ enumerable: true, get: function () { return button_box_select_1.BoxSelectButton; } }));
var side_bar_1 = __webpack_require__(/*! ./side_bar */ "./lib/graphs/tools/side_bar.js");
Object.defineProperty(exports, "SideBar", ({ enumerable: true, get: function () { return side_bar_1.SideBar; } }));


/***/ }),

/***/ "./lib/layouts.js":
/*!************************!*\
  !*** ./lib/layouts.js ***!
  \************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


// Copyright (c) MATIUS
// Distributed under the terms of the Modified BSD License.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatrixCreatorView = exports.MatrixCreatorModel = exports.MatrixLayoutView = exports.MatrixLayoutModel = void 0;
var matrixLayout_1 = __webpack_require__(/*! ./layouts/matrixLayout */ "./lib/layouts/matrixLayout.js");
Object.defineProperty(exports, "MatrixLayoutModel", ({ enumerable: true, get: function () { return matrixLayout_1.MatrixLayoutModel; } }));
Object.defineProperty(exports, "MatrixLayoutView", ({ enumerable: true, get: function () { return matrixLayout_1.MatrixLayoutView; } }));
var matrixCreator_1 = __webpack_require__(/*! ./layouts/matrixCreator */ "./lib/layouts/matrixCreator.js");
Object.defineProperty(exports, "MatrixCreatorModel", ({ enumerable: true, get: function () { return matrixCreator_1.MatrixCreatorModel; } }));
Object.defineProperty(exports, "MatrixCreatorView", ({ enumerable: true, get: function () { return matrixCreator_1.MatrixCreatorView; } }));


/***/ }),

/***/ "./lib/layouts/matrixCreator.js":
/*!**************************************!*\
  !*** ./lib/layouts/matrixCreator.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatrixCreatorView = exports.MatrixCreatorModel = void 0;
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
__webpack_require__(/*! ../../css/layout.css */ "./css/layout.css");
class MatrixCreator extends base_widget_1.BaseWidget {
    constructor(element) {
        super(element);
        this.currentGroup = 1;
        this.isDragging = false;
        this.startCell = null;
        this.groupColors = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#ffff33', '#a65628', '#f781bf', '#999999'];
        this.setupGlobalEventListeners();
    }
    setupGlobalEventListeners() {
        document.addEventListener('mouseup', () => {
            this.isDragging = false;
            this.startCell = null;
        });
    }
    create_node(matrix, style, grid_template_areas) {
        const node = document.createElement("div");
        node.classList.add("matrix-creator-container");
        return node;
    }
    createMatrixGrid(matrix) {
        const matrixGrid = document.createElement("div");
        matrixGrid.className = "matrix-grid";
        for (const [rowIndex, row] of matrix.entries()) {
            const matrixRow = document.createElement("div");
            matrixRow.className = "matrix-row";
            for (const [colIndex] of row.entries()) {
                const matrixCell = document.createElement("div");
                matrixCell.className = "matrix-cell";
                matrixCell.dataset.row = rowIndex.toString();
                matrixCell.dataset.col = colIndex.toString();
                matrixCell.dataset.group = "0";
                // Event listeners para la funcionalidad de arrastrar y seleccionar
                matrixCell.addEventListener('mousedown', (e) => this.handleMouseDown(e, matrixCell));
                matrixCell.addEventListener('mouseenter', (e) => this.handleMouseEnter(e, matrixCell));
                matrixCell.addEventListener('mouseup', (e) => this.handleMouseUp(e, matrixCell));
                matrixRow.appendChild(matrixCell);
            }
            matrixGrid.appendChild(matrixRow);
        }
        return matrixGrid;
    }
    createControlPanel(containerElement) {
        const controlPanel = document.createElement("div");
        controlPanel.className = "control-panel";
        // Información del grupo actual
        const groupInfo = document.createElement("div");
        groupInfo.className = "group-info";
        const groupLabel = document.createElement("span");
        groupLabel.textContent = "Grupo Actual:";
        groupLabel.className = "group-label";
        const currentGroupDisplay = document.createElement("span");
        currentGroupDisplay.id = "current-group-display";
        currentGroupDisplay.textContent = this.currentGroup.toString();
        currentGroupDisplay.className = "current-group-display";
        currentGroupDisplay.style.backgroundColor = this.groupColors[this.currentGroup - 1];
        groupInfo.appendChild(groupLabel);
        groupInfo.appendChild(currentGroupDisplay);
        // Botones de control
        const buttonsContainer = document.createElement("div");
        buttonsContainer.className = "buttons-container";
        const nextGroupBtn = this.createButton("➡️ Siguiente Grupo", () => {
            this.nextGroup();
            this.updateGroupDisplay(currentGroupDisplay);
        });
        const resetGroupsBtn = this.createButton("🔄 Resetear Grupos", () => {
            this.resetGroups(containerElement);
            this.updateGroupDisplay(currentGroupDisplay);
        });
        const getMatrixBtn = this.createButton("📊 Guardar Matriz", () => {
            this.showMatrix(containerElement);
        });
        buttonsContainer.appendChild(nextGroupBtn);
        buttonsContainer.appendChild(resetGroupsBtn);
        buttonsContainer.appendChild(getMatrixBtn);
        controlPanel.appendChild(groupInfo);
        controlPanel.appendChild(buttonsContainer);
        return controlPanel;
    }
    createButton(text, onClick) {
        const button = document.createElement("button");
        button.textContent = text;
        button.className = "matrix-button";
        button.addEventListener('click', onClick);
        return button;
    }
    handleMouseDown(e, cell) {
        e.preventDefault();
        this.isDragging = true;
        this.startCell = cell;
        this.clearTemporarySelection();
        cell.classList.add('selecting');
        cell.style.background = 'rgba(102, 126, 234, 0.3)';
    }
    handleMouseEnter(e, cell) {
        if (!this.isDragging || !this.startCell)
            return;
        this.clearTemporarySelection();
        const startRow = Number.parseInt(this.startCell.dataset.row);
        const startCol = Number.parseInt(this.startCell.dataset.col);
        const endRow = Number.parseInt(cell.dataset.row);
        const endCol = Number.parseInt(cell.dataset.col);
        const minRow = Math.min(startRow, endRow);
        const maxRow = Math.max(startRow, endRow);
        const minCol = Math.min(startCol, endCol);
        const maxCol = Math.max(startCol, endCol);
        const allCells = cell.closest('.matrix-grid')?.querySelectorAll('.matrix-cell');
        if (allCells) {
            for (const c of Array.from(allCells)) {
                const cellElement = c;
                const cellRow = Number.parseInt(cellElement.dataset.row);
                const cellCol = Number.parseInt(cellElement.dataset.col);
                if (cellRow >= minRow && cellRow <= maxRow && cellCol >= minCol && cellCol <= maxCol) {
                    cellElement.classList.add('selecting');
                    cellElement.style.background = 'rgba(102, 126, 234, 0.3)';
                }
            }
        }
    }
    handleMouseUp(e, cell) {
        if (!this.isDragging || !this.startCell)
            return;
        const startRow = Number.parseInt(this.startCell.dataset.row);
        const startCol = Number.parseInt(this.startCell.dataset.col);
        const endRow = Number.parseInt(cell.dataset.row);
        const endCol = Number.parseInt(cell.dataset.col);
        const minRow = Math.min(startRow, endRow);
        const maxRow = Math.max(startRow, endRow);
        const minCol = Math.min(startCol, endCol);
        const maxCol = Math.max(startCol, endCol);
        const allCells = cell.closest('.matrix-grid')?.querySelectorAll('.matrix-cell');
        if (allCells) {
            for (const c of Array.from(allCells)) {
                const cellElement = c;
                const cellRow = Number.parseInt(cellElement.dataset.row);
                const cellCol = Number.parseInt(cellElement.dataset.col);
                if (cellRow >= minRow && cellRow <= maxRow && cellCol >= minCol && cellCol <= maxCol) {
                    cellElement.dataset.group = this.currentGroup.toString();
                    cellElement.style.backgroundColor = this.groupColors[this.currentGroup - 1];
                    cellElement.style.color = '#fff';
                    cellElement.style.fontWeight = 'bold';
                    cellElement.classList.remove('selecting');
                }
            }
        }
        this.isDragging = false;
        this.startCell = null;
    }
    clearTemporarySelection() {
        const selectingCells = document.querySelectorAll('.matrix-cell.selecting');
        for (const cell of Array.from(selectingCells)) {
            const cellElement = cell;
            cellElement.classList.remove('selecting');
            const group = cellElement.dataset.group;
            if (group === '0') {
                cellElement.style.background = '#fff';
            }
        }
    }
    nextGroup() {
        // Verificar si el grupo actual tiene celdas asignadas
        if (!this.hasGroupCells(this.currentGroup)) {
            return;
        }
        this.currentGroup++;
        if (this.currentGroup > 9) {
            this.currentGroup = 1;
        }
    }
    hasGroupCells(groupNumber) {
        // Buscar si existen celdas con el grupo actual asignado
        const cells = document.querySelectorAll('.matrix-cell');
        for (const cell of Array.from(cells)) {
            const cellElement = cell;
            const cellGroup = Number.parseInt(cellElement.dataset.group || '0');
            if (cellGroup === groupNumber) {
                return true;
            }
        }
        return false;
    }
    resetGroups(container) {
        this.currentGroup = 1;
        const cells = container.querySelectorAll('.matrix-cell');
        for (const cell of Array.from(cells)) {
            const cellElement = cell;
            cellElement.dataset.group = '0';
            cellElement.style.backgroundColor = '#fff';
            cellElement.style.color = '#333';
            cellElement.style.fontWeight = 'normal';
            cellElement.classList.remove('selecting');
        }
    }
    updateGroupDisplay(displayElement) {
        displayElement.textContent = this.currentGroup.toString();
        displayElement.style.backgroundColor = this.groupColors[this.currentGroup - 1];
    }
    showMatrix(container) {
        const matrix = [];
        const rows = container.querySelectorAll('.matrix-row');
        for (const row of Array.from(rows)) {
            const matrixRow = [];
            const cells = row.querySelectorAll('.matrix-cell');
            for (const cell of Array.from(cells)) {
                const cellElement = cell;
                const group = Number.parseInt(cellElement.dataset.group || '0');
                matrixRow.push(group);
            }
            matrix.push(matrixRow);
        }
        // Validar que todos los grupos sean rectangulares
        if (!this.validateGroupsAreRectangular(matrix)) {
            this.showErrorMessage('Los grupos deben ser cuadrados o rectangulares. Por favor, corrige los grupos.');
            return;
        }
        // Enviar el evento de matriz generada
        this.element.dispatchEvent(new CustomEvent('matrix_generated', { detail: { matrix } }));
        // Mostrar mensaje de confirmación
        this.showConfirmationMessage(matrix);
    }
    validateGroupsAreRectangular(matrix) {
        // Obtener todos los grupos únicos (excepto 0)
        const uniqueGroups = new Set();
        for (const row of matrix) {
            for (const cell of row) {
                if (cell !== 0) {
                    uniqueGroups.add(cell);
                }
            }
        }
        // Validar cada grupo
        for (const group of uniqueGroups) {
            if (!this.isGroupRectangular(matrix, group)) {
                return false;
            }
        }
        return true;
    }
    isGroupRectangular(matrix, groupNumber) {
        // Encontrar todas las posiciones del grupo
        const positions = [];
        for (const [i, row] of matrix.entries()) {
            for (const [j, cell] of row.entries()) {
                if (cell === groupNumber) {
                    positions.push({ row: i, col: j });
                }
            }
        }
        if (positions.length === 0)
            return true;
        // Encontrar los límites del rectángulo
        const minRow = Math.min(...positions.map(p => p.row));
        const maxRow = Math.max(...positions.map(p => p.row));
        const minCol = Math.min(...positions.map(p => p.col));
        const maxCol = Math.max(...positions.map(p => p.col));
        // Calcular el área esperada del rectángulo
        const expectedArea = (maxRow - minRow + 1) * (maxCol - minCol + 1);
        // Si el número de celdas coincide con el área esperada, es rectangular
        if (positions.length !== expectedArea) {
            return false;
        }
        // Verificar que todas las celdas dentro del rectángulo pertenezcan al grupo
        for (let i = minRow; i <= maxRow; i++) {
            for (let j = minCol; j <= maxCol; j++) {
                if (matrix[i][j] !== groupNumber) {
                    return false;
                }
            }
        }
        return true;
    }
    showConfirmationMessage(matrix) {
        // Buscar el contenedor del mensaje
        const messageContainer = document.getElementById('matrix-message-container');
        if (!messageContainer)
            return;
        // Crear el mensaje de confirmación
        const message = document.createElement('div');
        message.className = 'confirmation-message';
        // Icono de check
        const checkIcon = document.createElement('span');
        checkIcon.textContent = '✓';
        checkIcon.className = 'check-icon';
        // Texto del mensaje
        const messageText = document.createElement('span');
        messageText.textContent = 'Matriz guardada exitosamente';
        // Ensamblar el mensaje
        message.appendChild(checkIcon);
        message.appendChild(messageText);
        // Limpiar cualquier mensaje anterior
        messageContainer.innerHTML = '';
        messageContainer.appendChild(message);
        // Animar entrada
        setTimeout(() => {
            message.classList.add('show');
        }, 10);
        // Auto-ocultar después de 3 segundos
        setTimeout(() => {
            message.classList.remove('show');
            // Remover del DOM después de la animación
            setTimeout(() => {
                if (messageContainer.contains(message)) {
                    message.remove();
                }
            }, 300);
        }, 3000);
    }
    showErrorMessage(errorText) {
        // Buscar el contenedor del mensaje
        const messageContainer = document.getElementById('matrix-message-container');
        if (!messageContainer)
            return;
        // Crear el mensaje de error
        const message = document.createElement('div');
        message.className = 'confirmation-message error-message';
        message.style.background = '#e74c3c';
        // Icono de error
        const errorIcon = document.createElement('span');
        errorIcon.textContent = '✗';
        errorIcon.className = 'check-icon';
        // Texto del mensaje
        const messageText = document.createElement('span');
        messageText.textContent = errorText;
        // Ensamblar el mensaje
        message.appendChild(errorIcon);
        message.appendChild(messageText);
        // Limpiar cualquier mensaje anterior
        messageContainer.innerHTML = '';
        messageContainer.appendChild(message);
        // Animar entrada
        setTimeout(() => {
            message.classList.add('show');
        }, 10);
        // Auto-ocultar después de 4 segundos
        setTimeout(() => {
            message.classList.remove('show');
            // Remover del DOM después de la animación
            setTimeout(() => {
                if (messageContainer.contains(message)) {
                    message.remove();
                }
            }, 300);
        }, 4000);
    }
    generateMatrix(rows, columns) {
        const matrix = [];
        let value = 1;
        console.log(`=== Generando matriz de ${rows}x${columns} ===`);
        for (let i = 0; i < rows; i++) {
            const row = [];
            for (let j = 0; j < columns; j++) {
                row.push(value);
                value++;
            }
            matrix.push(row);
        }
        console.log("=== Matriz generada:", matrix, "===");
        return matrix;
    }
    plot(params) {
        let { matrix, grid_template_areas, style, rows, columns } = params;
        // Si la matriz está vacía o no existe, generar una nueva basada en rows y columns
        if (!matrix || matrix.length === 0 || (matrix.length === 1 && matrix[0].length === 0)) {
            const rowCount = rows || 3;
            const colCount = columns || 3;
            matrix = this.generateMatrix(rowCount, colCount);
        }
        const node = this.create_node(matrix, style, grid_template_areas);
        // Crear contenedor para la matriz y el mensaje
        const leftContainer = document.createElement("div");
        leftContainer.className = "matrix-container";
        // Crear la matriz interactiva
        const matrixGrid = this.createMatrixGrid(matrix);
        // Crear contenedor para el mensaje de confirmación
        const messageContainer = document.createElement("div");
        messageContainer.id = "matrix-message-container";
        messageContainer.className = "message-container";
        // Agregar matriz y mensaje al contenedor izquierdo
        leftContainer.appendChild(matrixGrid);
        leftContainer.appendChild(messageContainer);
        // Crear el panel de control
        const controlPanel = this.createControlPanel(leftContainer);
        // Agregar elementos al nodo principal (matriz a la izquierda, controles a la derecha)
        node.appendChild(leftContainer);
        node.appendChild(controlPanel);
        return node;
    }
}
class MatrixCreatorModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: MatrixCreatorModel.model_name,
            _view_name: MatrixCreatorModel.view_name,
            matrix: [],
            grid_areas: [],
            grid_template_areas: String,
            style: String,
            rows: 3,
            columns: 3,
        };
    }
}
exports.MatrixCreatorModel = MatrixCreatorModel;
MatrixCreatorModel.model_name = "MatrixCreatorModel";
MatrixCreatorModel.view_name = "MatrixCreatorView";
class MatrixCreatorView extends base_1.BaseView {
    params() {
        const rowsStr = this.model.get("rows");
        const columnsStr = this.model.get("columns");
        return {
            matrix: this.model.get("matrix"),
            grid_areas: this.model.get("grid_areas"),
            grid_template_areas: this.model.get("grid_template_areas"),
            style: this.model.get("style"),
            rows: rowsStr ? Number.parseInt(rowsStr) : 3,
            columns: columnsStr ? Number.parseInt(columnsStr) : 3,
        };
    }
    plot(element) {
        const matrixCreator = new MatrixCreator(element);
        const params = this.params();
        const node = matrixCreator.plot(params);
        element.appendChild(node);
        // NUEVO: escuchar el evento y sincronizar con Python
        element.addEventListener('matrix_generated', (ev) => {
            const e = ev;
            const matrix = e.detail.matrix;
            // Actualiza el trait 'matrix' para que Python lo reciba
            this.model.set({ matrix });
            this.model.save_changes();
            // Envía también un mensaje custom si quieres manejar callbacks en Python
            this.send({ event: 'matrix_generated', matrix });
        });
    }
}
exports.MatrixCreatorView = MatrixCreatorView;


/***/ }),

/***/ "./lib/layouts/matrixLayout.js":
/*!*************************************!*\
  !*** ./lib/layouts/matrixLayout.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MatrixLayoutView = exports.MatrixLayoutModel = void 0;
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
__webpack_require__(/*! ../../css/layout.css */ "./css/layout.css");
class MatrixLayout extends base_widget_1.BaseWidget {
    constructor(element) {
        super(element);
    }
    create_node(matrix, style, grid_template_areas) {
        const node = document.createElement("div");
        node.classList.add(style);
        node.style.display = "grid";
        node.style.gridTemplateAreas = grid_template_areas;
        node.style.gridTemplateRows = `repeat(${matrix.length}, 180px)`;
        node.style.gridTemplateColumns = `repeat(${matrix[0].length}, 1fr)`;
        node.style.width = "100%";
        return node;
    }
    plot(params) {
        const { matrix, grid_areas, grid_template_areas } = params;
        let { style } = params;
        if (!style) {
            style = "basic";
        }
        const node = this.create_node(matrix, style, grid_template_areas);
        for (const area of grid_areas) {
            const grid_area = document.createElement("div");
            grid_area.setAttribute("id", area);
            grid_area.style.gridArea = area;
            grid_area.classList.add("dashboard-div");
            console.log(`=== Div creado con id: ${area} ===`);
            node.appendChild(grid_area);
        }
        this.element.appendChild(node);
        console.log("=== DOM completamente construido ===");
    }
}
class MatrixLayoutModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: MatrixLayoutModel.model_name,
            _view_name: MatrixLayoutModel.view_name,
            matrix: [],
            grid_areas: [],
            grid_template_areas: String,
            style: String,
        };
    }
}
exports.MatrixLayoutModel = MatrixLayoutModel;
MatrixLayoutModel.model_name = "MatrixLayoutModel";
MatrixLayoutModel.view_name = "MatrixLayoutView";
class MatrixLayoutView extends base_1.BaseView {
    params() {
        return {
            matrix: this.model.get("matrix"),
            grid_areas: this.model.get("grid_areas"),
            grid_template_areas: this.model.get("grid_template_areas"),
            style: this.model.get("style")
        };
    }
    plot(element) {
        console.log("=== MatrixLayoutView.plot() called ===");
        this.widget = new MatrixLayout(element);
        const runPlot = () => this.widget.plot(this.params());
        if (typeof globalThis !== "undefined" && "requestAnimationFrame" in globalThis) {
            globalThis.requestAnimationFrame(runPlot);
        }
        else {
            runPlot();
        }
    }
}
exports.MatrixLayoutView = MatrixLayoutView;


/***/ }),

/***/ "./lib/version.js":
/*!************************!*\
  !*** ./lib/version.js ***!
  \************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


// Copyright (c) MATIUS
// Distributed under the terms of the Modified BSD License.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MODULE_NAME = exports.MODULE_VERSION = void 0;
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
// eslint-disable-next-line @typescript-eslint/no-var-requires
const data = __webpack_require__(/*! ../package.json */ "./package.json");
/**
 * The _model_module_version/_view_module_version this package implements.
 *
 * The html widget manager assumes that this is the same as the npm package
 * version number.
 */
exports.MODULE_VERSION = data.version;
/*
 * The current package name.
 */
exports.MODULE_NAME = data.name;


/***/ }),

/***/ "./lib/widgets.js":
/*!************************!*\
  !*** ./lib/widgets.js ***!
  \************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


// Copyright (c) MATIUS
// Distributed under the terms of the Modified BSD License.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SelectColorView = exports.SelectColorModel = exports.RangeSliderView = exports.RangeSliderModel = exports.TextAreaView = exports.TextAreaModel = exports.TextView = exports.TextModel = exports.InputView = exports.InputModel = exports.DropdownView = exports.DropdownModel = exports.CheckboxView = exports.CheckboxModel = exports.ButtonView = exports.ButtonModel = void 0;
var button_1 = __webpack_require__(/*! ./widgets/button */ "./lib/widgets/button.js");
Object.defineProperty(exports, "ButtonModel", ({ enumerable: true, get: function () { return button_1.ButtonModel; } }));
Object.defineProperty(exports, "ButtonView", ({ enumerable: true, get: function () { return button_1.ButtonView; } }));
var checkbox_1 = __webpack_require__(/*! ./widgets/checkbox */ "./lib/widgets/checkbox.js");
Object.defineProperty(exports, "CheckboxModel", ({ enumerable: true, get: function () { return checkbox_1.CheckboxModel; } }));
Object.defineProperty(exports, "CheckboxView", ({ enumerable: true, get: function () { return checkbox_1.CheckboxView; } }));
var dropdown_1 = __webpack_require__(/*! ./widgets/dropdown */ "./lib/widgets/dropdown.js");
Object.defineProperty(exports, "DropdownModel", ({ enumerable: true, get: function () { return dropdown_1.DropdownModel; } }));
Object.defineProperty(exports, "DropdownView", ({ enumerable: true, get: function () { return dropdown_1.DropdownView; } }));
var input_1 = __webpack_require__(/*! ./widgets/input */ "./lib/widgets/input.js");
Object.defineProperty(exports, "InputModel", ({ enumerable: true, get: function () { return input_1.InputModel; } }));
Object.defineProperty(exports, "InputView", ({ enumerable: true, get: function () { return input_1.InputView; } }));
var text_1 = __webpack_require__(/*! ./widgets/text */ "./lib/widgets/text.js");
Object.defineProperty(exports, "TextModel", ({ enumerable: true, get: function () { return text_1.TextModel; } }));
Object.defineProperty(exports, "TextView", ({ enumerable: true, get: function () { return text_1.TextView; } }));
var textarea_1 = __webpack_require__(/*! ./widgets/textarea */ "./lib/widgets/textarea.js");
Object.defineProperty(exports, "TextAreaModel", ({ enumerable: true, get: function () { return textarea_1.TextAreaModel; } }));
Object.defineProperty(exports, "TextAreaView", ({ enumerable: true, get: function () { return textarea_1.TextAreaView; } }));
var rangeslider_1 = __webpack_require__(/*! ./widgets/rangeslider */ "./lib/widgets/rangeslider.js");
Object.defineProperty(exports, "RangeSliderModel", ({ enumerable: true, get: function () { return rangeslider_1.RangeSliderModel; } }));
Object.defineProperty(exports, "RangeSliderView", ({ enumerable: true, get: function () { return rangeslider_1.RangeSliderView; } }));
var select_color_1 = __webpack_require__(/*! ./widgets/select_color */ "./lib/widgets/select_color.js");
Object.defineProperty(exports, "SelectColorModel", ({ enumerable: true, get: function () { return select_color_1.SelectColorModel; } }));
Object.defineProperty(exports, "SelectColorView", ({ enumerable: true, get: function () { return select_color_1.SelectColorView; } }));


/***/ }),

/***/ "./lib/widgets/base_text.js":
/*!**********************************!*\
  !*** ./lib/widgets/base_text.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TextBaseView = exports.TextBaseModel = exports.TextBase = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
class TextBase extends base_widget_1.BaseWidget {
    onPlaceholderChanged(placeholder) {
        if (this.text) {
            this.text.setAttribute("placeholder", placeholder);
        }
    }
    onDescriptionChanged(description) {
        this.element.innerHTML = "";
        if (description) {
            const label = document.createElement("label");
            label.setAttribute("title", description);
            label.innerHTML = description + ": ";
            label.style.verticalAlign = "top";
            this.element.appendChild(label);
        }
        if (this.text) {
            this.element.appendChild(this.text);
        }
    }
    onDisabledChanged(disabled) {
        if (this.text) {
            if (disabled)
                this.text.setAttribute("disabled", "");
            else
                this.text.removeAttribute("disabled");
        }
    }
    plot(params) {
        const { value, placeholder, description, disabled } = params;
        this.onTextChanged(value);
        this.onPlaceholderChanged(placeholder);
        this.onDescriptionChanged(description);
        this.onDisabledChanged(disabled);
    }
}
exports.TextBase = TextBase;
class TextBaseModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            value: String,
            placeholder: String,
            description: String,
            disabled: false,
            elementId: String,
        };
    }
}
exports.TextBaseModel = TextBaseModel;
class TextBaseView extends base_1.BaseView {
    setPlaceholder() {
        const placeholder = this.model.get("placeholder");
        this.widget.onPlaceholderChanged(placeholder);
    }
    setDescription() {
        const description = this.model.get("description");
        this.widget.onDescriptionChanged(description);
    }
    setDisabled() {
        const disabled = this.model.get("disabled");
        this.widget.onDisabledChanged(disabled);
    }
    // Método protegido que devuelve los parámetros base
    params() {
        return {
            value: this.model.get("value"),
            placeholder: this.model.get("placeholder"),
            description: this.model.get("description"),
            disabled: this.model.get("disabled")
        };
    }
    plot(element) {
        this.model.on("change:value", () => this.setText(), this);
        this.model.on("change:placeholder", () => this.setPlaceholder(), this);
        this.model.on("change:description", () => this.setDescription(), this);
        this.model.on("change:disabled", () => this.setDisabled(), this);
        window.addEventListener("resize", () => this.replot());
    }
}
exports.TextBaseView = TextBaseView;


/***/ }),

/***/ "./lib/widgets/button.js":
/*!*******************************!*\
  !*** ./lib/widgets/button.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ButtonView = exports.ButtonModel = exports.Button = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
class Button extends base_widget_1.BaseWidget {
    onDescriptionChanged(description) {
        if (this.button) {
            this.button.innerHTML = description;
        }
    }
    onDisabledChanged(disabled) {
        if (this.button) {
            if (disabled)
                this.button.setAttribute("disabled", "");
            else
                this.button.removeAttribute("disabled");
        }
    }
    plot(params) {
        const { description, disabled, setClicked } = params;
        const container = document.createElement("div");
        container.classList.add("button_container");
        this.button = document.createElement("button");
        this.button.classList.add("vp_button");
        this.button.addEventListener("click", setClicked);
        this.onDescriptionChanged(description);
        this.onDisabledChanged(disabled);
        container.appendChild(this.button);
        this.element.appendChild(container);
    }
}
exports.Button = Button;
class ButtonModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: ButtonModel.model_name,
            _view_name: ButtonModel.view_name,
            description: String,
            disabled: false,
            _clicked: Boolean,
            elementId: String,
        };
    }
}
exports.ButtonModel = ButtonModel;
ButtonModel.model_name = "ButtonModel";
ButtonModel.view_name = "ButtonView";
class ButtonView extends base_1.BaseView {
    setDescription() {
        const description = this.model.get("description");
        this.widget.onDescriptionChanged(description);
    }
    setDisabled() {
        const disabled = this.model.get("disabled");
        this.widget.onDisabledChanged(disabled);
    }
    setClicked() {
        const clicked = this.model.get("_clicked");
        this.model.set({ _clicked: !clicked });
        this.model.save_changes();
    }
    params() {
        return {
            description: this.model.get("description"),
            disabled: this.model.get("disabled"),
            setClicked: this.setClicked.bind(this)
        };
    }
    plot(element) {
        this.widget = new Button(element);
        this.model.on("change:description", () => this.setDescription(), this);
        this.model.on("change:disabled", () => this.setDisabled(), this);
        this.widget.plot(this.params());
    }
}
exports.ButtonView = ButtonView;


/***/ }),

/***/ "./lib/widgets/checkbox.js":
/*!*********************************!*\
  !*** ./lib/widgets/checkbox.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CheckboxView = exports.CheckboxModel = exports.Checkbox = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
class Checkbox extends base_widget_1.BaseWidget {
    constructor() {
        super(...arguments);
        this.label = null;
    }
    onDescriptionChanged(description) {
        if (!this.label) {
            this.label = document.createElement("label");
            this.label.htmlFor = this.checkbox.id;
        }
        this.label.textContent = description;
    }
    plot(params) {
        const { description, setChecked } = params;
        this.checkbox = document.createElement("input");
        this.checkbox.type = "checkbox";
        this.checkbox.id = `checkbox-${crypto.randomUUID()}`; // Unique ID for the checkbox
        this.checkbox.addEventListener("change", (e) => {
            setChecked({ checked: e.target.checked });
        });
        this.onDescriptionChanged(description);
        // Limpa o container e adiciona o checkbox e o label
        this.element.innerHTML = "";
        this.element.appendChild(this.checkbox);
        if (this.label) {
            this.element.appendChild(this.label);
        }
    }
}
exports.Checkbox = Checkbox;
class CheckboxModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: CheckboxModel.model_name,
            _view_name: CheckboxModel.view_name,
            description: String,
            checked: false,
            elementId: String,
        };
    }
}
exports.CheckboxModel = CheckboxModel;
CheckboxModel.model_name = "CheckboxModel";
CheckboxModel.view_name = "CheckboxView";
class CheckboxView extends base_1.BaseView {
    setDescription() {
        const description = this.model.get("description");
        this.widget.onDescriptionChanged(description);
    }
    setChecked(change) {
        const checked = change.checked;
        this.model.set({ checked: checked });
        this.model.save_changes();
    }
    params() {
        return {
            description: this.model.get("description"),
            setChecked: this.setChecked.bind(this)
        };
    }
    plot(element) {
        this.widget = new Checkbox(element);
        this.model.on("change:description", () => this.setDescription(), this);
        this.widget.plot(this.params());
    }
}
exports.CheckboxView = CheckboxView;


/***/ }),

/***/ "./lib/widgets/dropdown.js":
/*!*********************************!*\
  !*** ./lib/widgets/dropdown.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DropdownView = exports.DropdownModel = exports.Dropdown = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
class Dropdown extends base_widget_1.BaseWidget {
    onDescriptionChanged(description) {
        if (this.label) {
            this.label.innerHTML = description + ": ";
        }
    }
    onDisabledChanged(disabled) {
        if (this.select) {
            this.select.disabled = disabled;
        }
    }
    onOptionsChanged(data, variable, options) {
        // If options is empty, populate it with unique values from data
        if (options.length === 0 && data.length > 0) {
            options = [...new Set(data.map((d) => d[variable]))].sort((a, b) => {
                if (typeof a === "number" && typeof b === "number") {
                    return a - b;
                }
                return String(a).localeCompare(String(b));
            });
        }
        this.select.innerHTML = "";
        for (const option of options) {
            const optionElement = document.createElement("option");
            optionElement.setAttribute("value", option);
            optionElement.innerHTML = option;
            this.select.appendChild(optionElement);
        }
    }
    onValueChanged() {
        const value = this.select.value;
        this.setValue(value);
    }
    plot(params) {
        const { data, variable, description, options, value, disabled, setValue } = params;
        const randomString = Math.floor(Math.random() * Date.now() * 10000).toString(36);
        this.dropdown = document.createElement("div");
        this.label = document.createElement("label");
        this.label.setAttribute("for", randomString);
        this.onDescriptionChanged(description);
        this.select = document.createElement("select");
        this.select.setAttribute("id", randomString);
        this.setValue = setValue;
        this.select.addEventListener("change", this.onValueChanged.bind(this));
        this.onDisabledChanged(disabled);
        this.dropdown.appendChild(this.label);
        this.dropdown.appendChild(this.select);
        this.onOptionsChanged(data, variable, options);
        if (value) {
            this.select.value = value;
        }
        this.element.appendChild(this.dropdown);
    }
}
exports.Dropdown = Dropdown;
class DropdownModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: DropdownModel.model_name,
            _view_name: DropdownModel.view_name,
            dataRecords: [],
            variable: String,
            description: String,
            options: [],
            value: String,
            disabled: false,
            elementId: String,
        };
    }
}
exports.DropdownModel = DropdownModel;
DropdownModel.model_name = "DropdownModel";
DropdownModel.view_name = "DropdownView";
class DropdownView extends base_1.BaseView {
    setDescription() {
        const description = this.model.get("description");
        this.widget.onDescriptionChanged(description);
    }
    setDisabled() {
        const disabled = this.model.get("disabled");
        this.widget.onDisabledChanged(disabled);
    }
    setOptions() {
        const data = this.model.get("dataRecords");
        const variable = this.model.get("variable");
        const options = this.model.get("options");
        this.widget.onOptionsChanged(data, variable, options);
    }
    setValue(value) {
        this.model.set({ value: value });
        this.model.save_changes();
    }
    params() {
        return {
            data: this.model.get("dataRecords"),
            variable: this.model.get("variable"),
            description: this.model.get("description"),
            options: this.model.get("options"),
            value: this.model.get("value"),
            disabled: this.model.get("disabled"),
            setValue: this.setValue.bind(this)
        };
    }
    plot(element) {
        this.widget = new Dropdown(element);
        this.model.on("change:dataRecords", () => this.setOptions(), this);
        this.model.on("change:variable", () => this.setOptions(), this);
        this.model.on("change:description", () => this.setDescription(), this);
        this.model.on("change:options", () => this.setOptions(), this);
        this.model.on("change:disabled", () => this.setDisabled(), this);
        this.widget.plot(this.params());
    }
}
exports.DropdownView = DropdownView;


/***/ }),

/***/ "./lib/widgets/input.js":
/*!******************************!*\
  !*** ./lib/widgets/input.js ***!
  \******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InputView = exports.InputModel = exports.Input = void 0;
const base_text_1 = __webpack_require__(/*! ./base_text */ "./lib/widgets/base_text.js");
class Input extends base_text_1.TextBase {
    onTextChanged(value) {
        if (this.text) {
            this.text.value = value;
        }
    }
    onValueChanged() {
        const value = this.text.value;
        this.setValue(value);
    }
    plot(params) {
        const { value, placeholder, description, disabled, setValue } = params;
        this.text = document.createElement("input");
        this.setValue = setValue;
        this.text.addEventListener("change", this.onValueChanged.bind(this));
        super.plot({ value, placeholder, description, disabled });
    }
}
exports.Input = Input;
class InputModel extends base_text_1.TextBaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: InputModel.model_name,
            _view_name: InputModel.view_name,
        };
    }
}
exports.InputModel = InputModel;
InputModel.model_name = "InputModel";
InputModel.view_name = "InputView";
class InputView extends base_text_1.TextBaseView {
    setText() {
        const value = this.model.get("value");
        this.widget.onTextChanged(value);
    }
    setValue(value) {
        this.model.set({ value: value });
        this.model.save_changes();
    }
    params() {
        return {
            ...super.params(),
            setValue: this.setValue.bind(this)
        };
    }
    plot(element) {
        this.widget = new Input(element);
        super.plot(element);
        this.widget.plot(this.params());
    }
}
exports.InputView = InputView;


/***/ }),

/***/ "./lib/widgets/rangeslider.js":
/*!************************************!*\
  !*** ./lib/widgets/rangeslider.js ***!
  \************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RangeSliderView = exports.RangeSliderModel = exports.RangeSlider = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const d3 = __importStar(__webpack_require__(/*! d3 */ "webpack/sharing/consume/default/d3/d3"));
class RangeSlider extends base_widget_1.BaseWidget {
    plot(params) {
        const { data, variable, step, description, fromValue, toValue, setValues, setMinMax, margin } = params;
        let { minValue, maxValue } = params;
        this.setValues = setValues;
        const { min, max } = this.calculateMinMax(data, variable, minValue, maxValue);
        minValue = min;
        maxValue = max;
        const rangeOutsideContainer = this.createContainer(description, margin);
        const slidersControl = this.createSlidersControl(rangeOutsideContainer);
        this.createSliders(slidersControl, step, minValue, maxValue, fromValue, toValue);
        const from = Number.parseFloat(this.fromSlider.value);
        const to = Number.parseFloat(this.toSlider.value);
        this.updateValues(from, to);
        setMinMax(min, max);
        this.setupEventListeners();
        this.element.appendChild(rangeOutsideContainer);
    }
    calculateMinMax(data, variable, minValue, maxValue) {
        let min = minValue;
        let max = maxValue;
        if (!min && data.length > 0) {
            min = d3.min(data, (d) => d[variable]);
        }
        if (!max && data.length > 0) {
            max = d3.max(data, (d) => d[variable]);
        }
        return { min: min, max: max };
    }
    createContainer(description, margin) {
        const rangeOutsideContainer = document.createElement("div");
        rangeOutsideContainer.classList.add("range_outside_container");
        rangeOutsideContainer.style.margin = `${margin.top}px ${margin.right}px ${margin.bottom}px ${margin.left}px`;
        const rangeDescription = document.createElement("span");
        rangeDescription.classList.add("range_description");
        rangeDescription.textContent = description;
        rangeOutsideContainer.appendChild(rangeDescription);
        const rangeInsideContainer = document.createElement("div");
        rangeInsideContainer.classList.add("range_inside_container");
        rangeOutsideContainer.appendChild(rangeInsideContainer);
        this.rangeValue = document.createElement("span");
        this.rangeValue.classList.add("range_value");
        rangeOutsideContainer.appendChild(this.rangeValue);
        return rangeOutsideContainer;
    }
    createSlidersControl(container) {
        const rangeInsideContainer = container.querySelector('.range_inside_container');
        const slidersControl = document.createElement("div");
        slidersControl.classList.add("sliders_control");
        rangeInsideContainer.appendChild(slidersControl);
        return slidersControl;
    }
    createSliders(container, step, minValue, maxValue, fromValue, toValue) {
        this.fromSlider = this.createSlider(container, step, minValue, maxValue, fromValue || minValue, "top_slider");
        this.toSlider = this.createSlider(container, step, minValue, maxValue, toValue || maxValue);
    }
    createSlider(container, step, min, max, value, extraClass) {
        const slider = document.createElement("input");
        if (extraClass) {
            slider.classList.add(extraClass);
        }
        slider.setAttribute("step", step.toString());
        slider.setAttribute("type", "range");
        slider.setAttribute("min", min.toString());
        slider.setAttribute("max", max.toString());
        slider.value = value.toString();
        container.appendChild(slider);
        return slider;
    }
    setupEventListeners() {
        this.fromSlider.addEventListener("input", () => this.handleFromSliderInput());
        this.toSlider.addEventListener("input", () => this.handleToSliderInput());
        this.fromSlider.addEventListener("click", () => this.setActiveSlider(this.fromSlider, this.toSlider));
        this.toSlider.addEventListener("click", () => this.setActiveSlider(this.toSlider, this.fromSlider));
    }
    handleFromSliderInput() {
        const from = Number.parseFloat(this.fromSlider.value);
        const to = Number.parseFloat(this.toSlider.value);
        if (from > to) {
            this.fromSlider.value = this.toSlider.value;
        }
        this.updateValues(Number.parseFloat(this.fromSlider.value), to);
    }
    handleToSliderInput() {
        const from = Number.parseFloat(this.fromSlider.value);
        const to = Number.parseFloat(this.toSlider.value);
        if (to < from) {
            this.toSlider.value = this.fromSlider.value;
        }
        this.updateValues(from, Number.parseFloat(this.toSlider.value));
    }
    setActiveSlider(activeSlider, inactiveSlider) {
        activeSlider.classList.add("top_slider");
        inactiveSlider.classList.remove("top_slider");
    }
    updateValues(from, to) {
        this.rangeValue.textContent = `${from} - ${to}`;
        this.setValues(from, to);
    }
}
exports.RangeSlider = RangeSlider;
class RangeSliderModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: RangeSliderModel.model_name,
            _view_name: RangeSliderModel.view_name,
            dataRecords: [],
            variable: String,
            step: Number,
            description: String,
            minValue: Number,
            maxValue: Number,
            elementId: String,
        };
    }
}
exports.RangeSliderModel = RangeSliderModel;
RangeSliderModel.model_name = "RangeSliderModel";
RangeSliderModel.view_name = "RangeSliderView";
class RangeSliderView extends base_1.BaseView {
    setFromTo(from, to) {
        this.model.set({ fromValue: from, toValue: to });
        this.model.save_changes();
    }
    setMinMax(min, max) {
        this.model.set({ minValue: min, maxValue: max });
        this.model.save_changes();
    }
    params() {
        return {
            data: this.model.get("dataRecords"),
            variable: this.model.get("variable"),
            step: this.model.get("step"),
            description: this.model.get("description"),
            fromValue: this.model.get("fromValue"),
            toValue: this.model.get("toValue"),
            minValue: this.model.get("minValue"),
            maxValue: this.model.get("maxValue"),
            setValues: this.setFromTo.bind(this),
            setMinMax: this.setMinMax.bind(this),
            margin: base_1.WIDGET_MARGIN
        };
    }
    plot(element) {
        this.widget = new RangeSlider(element);
        this.model.on("change:dataRecords", () => this.replot(), this);
        this.model.on("change:variable", () => this.replot(), this);
        this.model.on("change:step", () => this.replot(), this);
        this.model.on("change:description", () => this.replot(), this);
        this.model.on("change:minValue", () => this.replot(), this);
        this.model.on("change:maxValue", () => this.replot(), this);
        window.addEventListener("resize", () => this.replot());
        this.widget.plot(this.params());
    }
}
exports.RangeSliderView = RangeSliderView;


/***/ }),

/***/ "./lib/widgets/select_color.js":
/*!*************************************!*\
  !*** ./lib/widgets/select_color.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SelectColorView = exports.SelectColorModel = exports.SelectColor = void 0;
const base_widget_1 = __webpack_require__(/*! ../base/base_widget */ "./lib/base/base_widget.js");
const base_1 = __webpack_require__(/*! ../base/base */ "./lib/base/base.js");
const colors_1 = __webpack_require__(/*! ../const/colors */ "./lib/const/colors.js");
class SelectColor extends base_widget_1.BaseWidget {
    onDescriptionChanged(description) {
        if (this.container) {
            const label = this.container.querySelector("label");
            if (label)
                label.textContent = description;
        }
    }
    onDisabledChanged(disabled) {
        if (this.paletteSelect) {
            if (disabled)
                this.paletteSelect.setAttribute("disabled", "");
            else
                this.paletteSelect.removeAttribute("disabled");
        }
        if (this.numColorsSelect) {
            if (disabled)
                this.numColorsSelect.setAttribute("disabled", "");
            else
                this.numColorsSelect.removeAttribute("disabled");
        }
    }
    onPaletteChanged(paletteName, numColors) {
        if (this.previewContainer && paletteName) {
            this.previewContainer.innerHTML = "";
            const palette = colors_1.colorbrewer[paletteName];
            const colors = palette?.[numColors];
            if (colors) {
                for (const color of colors) {
                    const colorBox = document.createElement("div");
                    colorBox.style.width = "30px";
                    colorBox.style.height = "30px";
                    colorBox.style.backgroundColor = color;
                    colorBox.style.display = "inline-block";
                    colorBox.style.margin = "2px";
                    colorBox.style.border = "1px solid #ccc";
                    colorBox.style.borderRadius = "3px";
                    this.previewContainer.appendChild(colorBox);
                }
            }
        }
    }
    plot(params) {
        const { description, selectedPalette, selectedNumColors, disabled, setPaletteChanged } = params;
        this.container = document.createElement("div");
        this.container.style.padding = "10px";
        this.container.style.fontFamily = "Arial, sans-serif";
        const label = document.createElement("label");
        label.textContent = description;
        label.style.display = "block";
        label.style.marginBottom = "8px";
        label.style.fontWeight = "bold";
        this.container.appendChild(label);
        const selectContainer = document.createElement("div");
        selectContainer.style.marginBottom = "10px";
        selectContainer.style.display = "flex";
        selectContainer.style.gap = "10px";
        this.paletteSelect = document.createElement("select");
        this.paletteSelect.style.padding = "5px";
        this.paletteSelect.style.borderRadius = "4px";
        this.paletteSelect.style.border = "1px solid #ccc";
        this.paletteSelect.addEventListener("change", setPaletteChanged);
        for (const paletteName of Object.keys(colors_1.colorbrewer)) {
            const option = document.createElement("option");
            option.value = paletteName;
            option.textContent = paletteName;
            if (paletteName === selectedPalette) {
                option.selected = true;
            }
            this.paletteSelect.appendChild(option);
        }
        this.numColorsSelect = document.createElement("select");
        this.numColorsSelect.style.padding = "5px";
        this.numColorsSelect.style.borderRadius = "4px";
        this.numColorsSelect.style.border = "1px solid #ccc";
        this.numColorsSelect.addEventListener("change", setPaletteChanged);
        for (let i = 3; i <= 12; i++) {
            const option = document.createElement("option");
            option.value = i.toString();
            option.textContent = `${i} colores`;
            if (i === selectedNumColors) {
                option.selected = true;
            }
            this.numColorsSelect.appendChild(option);
        }
        selectContainer.appendChild(this.paletteSelect);
        selectContainer.appendChild(this.numColorsSelect);
        this.container.appendChild(selectContainer);
        this.previewContainer = document.createElement("div");
        this.previewContainer.style.marginTop = "10px";
        this.previewContainer.style.padding = "10px";
        this.previewContainer.style.border = "1px solid #e0e0e0";
        this.previewContainer.style.borderRadius = "4px";
        this.previewContainer.style.backgroundColor = "#f9f9f9";
        this.container.appendChild(this.previewContainer);
        this.onDescriptionChanged(description);
        this.onDisabledChanged(disabled);
        this.onPaletteChanged(selectedPalette, selectedNumColors);
        this.element.appendChild(this.container);
    }
}
exports.SelectColor = SelectColor;
class SelectColorModel extends base_1.BaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: SelectColorModel.model_name,
            _view_name: SelectColorModel.view_name,
            description: String,
            selectedPalette: String,
            selectedNumColors: Number,
            disabled: false,
            elementId: String,
        };
    }
}
exports.SelectColorModel = SelectColorModel;
SelectColorModel.model_name = "SelectColorModel";
SelectColorModel.view_name = "SelectColorView";
class SelectColorView extends base_1.BaseView {
    setDescription() {
        const description = this.model.get("description");
        this.widget.onDescriptionChanged(description);
    }
    setDisabled() {
        const disabled = this.model.get("disabled");
        this.widget.onDisabledChanged(disabled);
    }
    setPalette() {
        const palette = this.model.get("selectedPalette");
        const numColors = this.model.get("selectedNumColors");
        this.widget.onPaletteChanged(palette, numColors);
    }
    setPaletteChanged() {
        const palette = this.widget.paletteSelect.value;
        const numColors = Number.parseInt(this.widget.numColorsSelect.value);
        this.model.set({
            selectedPalette: palette,
            selectedNumColors: numColors,
            _paletteChanged: !this.model.get("_paletteChanged")
        });
        this.model.save_changes();
    }
    params() {
        return {
            description: this.model.get("description"),
            selectedPalette: this.model.get("selectedPalette"),
            selectedNumColors: this.model.get("selectedNumColors"),
            disabled: this.model.get("disabled"),
            setPaletteChanged: this.setPaletteChanged.bind(this)
        };
    }
    plot(element) {
        this.widget = new SelectColor(element);
        this.model.on("change:description", () => this.setDescription(), this);
        this.model.on("change:disabled", () => this.setDisabled(), this);
        this.model.on("change:selectedPalette", () => this.setPalette(), this);
        this.model.on("change:selectedNumColors", () => this.setPalette(), this);
        this.widget.plot(this.params());
    }
}
exports.SelectColorView = SelectColorView;


/***/ }),

/***/ "./lib/widgets/text.js":
/*!*****************************!*\
  !*** ./lib/widgets/text.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TextView = exports.TextModel = exports.Text = void 0;
const base_text_1 = __webpack_require__(/*! ./base_text */ "./lib/widgets/base_text.js");
class Text extends base_text_1.TextBase {
    onTextChanged(value) {
        if (this.text) {
            this.text.innerHTML = value;
        }
    }
    plot(params) {
        this.text = document.createElement("div");
        this.text.style.marginLeft = "4px";
        this.element.style.display = "flex";
        super.plot(params);
    }
}
exports.Text = Text;
class TextModel extends base_text_1.TextBaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: TextModel.model_name,
            _view_name: TextModel.view_name,
        };
    }
}
exports.TextModel = TextModel;
TextModel.model_name = "TextModel";
TextModel.view_name = "TextView";
class TextView extends base_text_1.TextBaseView {
    setText() {
        const value = this.model.get("value");
        this.widget.onTextChanged(value);
    }
    plot(element) {
        this.widget = new Text(element);
        super.plot(element);
        this.widget.plot(this.params());
    }
}
exports.TextView = TextView;


/***/ }),

/***/ "./lib/widgets/textarea.js":
/*!*********************************!*\
  !*** ./lib/widgets/textarea.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TextAreaView = exports.TextAreaModel = exports.TextArea = void 0;
const base_text_1 = __webpack_require__(/*! ./base_text */ "./lib/widgets/base_text.js");
class TextArea extends base_text_1.TextBase {
    onTextChanged(value) {
        this.text.value = value;
    }
    onValueChanged() {
        const value = this.text.value;
        this.setValue(value);
    }
    plot(params) {
        this.text = document.createElement("textarea");
        this.setValue = params.setValue;
        this.text.addEventListener("change", this.onValueChanged.bind(this));
        super.plot(params);
    }
}
exports.TextArea = TextArea;
class TextAreaModel extends base_text_1.TextBaseModel {
    defaults() {
        return {
            ...super.defaults(),
            _model_name: TextAreaModel.model_name,
            _view_name: TextAreaModel.view_name,
        };
    }
}
exports.TextAreaModel = TextAreaModel;
TextAreaModel.model_name = "TextAreaModel";
TextAreaModel.view_name = "TextAreaView";
class TextAreaView extends base_text_1.TextBaseView {
    setText() {
        const value = this.model.get("value");
        this.widget.onTextChanged(value);
    }
    setValue(value) {
        this.model.set({ value: value });
        this.model.save_changes();
    }
    params() {
        return {
            ...super.params(),
            setValue: this.setValue.bind(this)
        };
    }
    plot(element) {
        this.widget = new TextArea(element);
        super.plot(element);
        this.widget.plot(this.params());
    }
}
exports.TextAreaView = TextAreaView;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./css/graphs.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./css/graphs.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/***** BARPLOT *****/
.bar {
    cursor: pointer;
    transition: opacity 0.2s ease;
}
.bar:hover {
    opacity: 0.8;
}
.bar.selected {
    stroke: #000;
    stroke-width: 3px;
    opacity: 1 !important;
}


/*** Estilos para HorizonChart ***/
.horizon-series {
    cursor: pointer;
    transition: opacity 0.2s ease;
}
.horizon-series.selected {
    stroke: #000;
    stroke-width: 2px;
    opacity: 1 !important;
}
.horizon-series:hover {
    opacity: 0.8;
}

/*** ScatterPlot ***/
.scatter_dot {
    cursor: pointer;
    transition: opacity 0.2s ease;
}
.scatter_dot:hover {
    opacity: 0.8;
}
.scatter_dot.selected {
    stroke: #000;
    stroke-width: 2px;
    opacity: 1 !important;
}`, "",{"version":3,"sources":["webpack://./css/graphs.css"],"names":[],"mappings":"AAAA,oBAAoB;AACpB;IACI,eAAe;IACf,6BAA6B;AACjC;AACA;IACI,YAAY;AAChB;AACA;IACI,YAAY;IACZ,iBAAiB;IACjB,qBAAqB;AACzB;;;AAGA,kCAAkC;AAClC;IACI,eAAe;IACf,6BAA6B;AACjC;AACA;IACI,YAAY;IACZ,iBAAiB;IACjB,qBAAqB;AACzB;AACA;IACI,YAAY;AAChB;;AAEA,oBAAoB;AACpB;IACI,eAAe;IACf,6BAA6B;AACjC;AACA;IACI,YAAY;AAChB;AACA;IACI,YAAY;IACZ,iBAAiB;IACjB,qBAAqB;AACzB","sourcesContent":["/***** BARPLOT *****/\n.bar {\n    cursor: pointer;\n    transition: opacity 0.2s ease;\n}\n.bar:hover {\n    opacity: 0.8;\n}\n.bar.selected {\n    stroke: #000;\n    stroke-width: 3px;\n    opacity: 1 !important;\n}\n\n\n/*** Estilos para HorizonChart ***/\n.horizon-series {\n    cursor: pointer;\n    transition: opacity 0.2s ease;\n}\n.horizon-series.selected {\n    stroke: #000;\n    stroke-width: 2px;\n    opacity: 1 !important;\n}\n.horizon-series:hover {\n    opacity: 0.8;\n}\n\n/*** ScatterPlot ***/\n.scatter_dot {\n    cursor: pointer;\n    transition: opacity 0.2s ease;\n}\n.scatter_dot:hover {\n    opacity: 0.8;\n}\n.scatter_dot.selected {\n    stroke: #000;\n    stroke-width: 2px;\n    opacity: 1 !important;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./css/layout.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./css/layout.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* Estilos SOLO para MatrixCreator */
.matrix-grid .matrix-cell {
    width: 50px;
    height: 50px;
    text-align: center;
    border: 2px solid #34495e;
    font-size: 16px;
    font-weight: 600;
    transition: all 0.2s ease;
    cursor: pointer;
    background: white;
    outline: none;
    border-radius: 0;
    padding: 0;
    margin: 0;
    position: relative;
}

.matrix-grid .matrix-cell:hover {
    box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
    z-index: 10;
    border-color: #667eea;
}

.matrix-grid .matrix-cell.selecting {
    background: rgba(102, 126, 234, 0.3);
    border-color: #667eea;
    box-shadow: inset 0 0 8px rgba(102, 126, 234, 0.4);
    z-index: 5;
}

/* Aplicar border más grueso solo a celdas con grupo EN MATRIX-GRID */
.matrix-grid .matrix-cell[data-group]:not([data-group="0"]) {
    border: 2px solid white;
    margin: 0;
}




/* Estilos para MatrixCreator */
.matrix-grid {
    display: inline-block;
    padding: 1rem;
    background: white;
    border-radius: 15px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
    animation: fadeIn 0.3s ease-out;
    border: 3px solid #000000;
    overflow: visible; /* Cambiado de hidden a visible para permitir el scale */
    position: relative; /* Añadido para contexto de posicionamiento */
}

.matrix-row {
    display: flex;
    gap: 0;
    margin-bottom: 0;
}


/* Contenedor de matriz */
.matrix-container {
    display: flex;
    flex-direction: column; /* Cambiado para apilar matriz y mensaje */
    justify-content: center;
    align-items: center;
    gap: 20px; /* Espacio entre matriz y mensaje */
    min-height: 200px;
    padding: 20px;
}

/* Contenedor del mensaje de confirmación */
.message-container {
    min-height: 60px; /* Aumentado para evitar saltos */
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
}

.confirmation-message {
    background: #4CAF50;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
}

.confirmation-message.show {
    opacity: 1;
    transform: translateY(0);
}

.confirmation-message.error-message {
    background: #e74c3c;
}

.check-icon {
    font-weight: bold;
    font-size: 16px;
}

/* Estilos para el panel de control */
.control-panel {
    display: flex;
    flex-direction: column;
    gap: 15px;
    align-items: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    min-width: 250px;
    align-self: flex-start; /* Mantener el panel en la parte superior */
}


.group-info {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.group-label {
    font-size: 1.2em;
    font-weight: 600;
    color: #333;
}

.current-group-display {
    font-weight: bold;
    padding: 8px 20px;
    border-radius: 4px;
    color: #fff;
    font-size: 1.3em;
    min-width: 50px;
    text-align: center;
}

.buttons-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.matrix-button {
    padding: 8px 16px;
    margin: 5px;
    cursor: pointer;
    border: none;
    border-radius: 4px;
    background: #3498db;
    color: #fff;
    font-weight: 600;
    transition: all 0.3s;
    min-width: 150px;
}

.matrix-button:hover {
    background: #2980b9;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}
.matrix-button:active {
    transform: translateY(1px);
}

/* Estilos para el contenedor de MatrixCreator */
.matrix-creator-container {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: center;
    gap: 40px;
    padding: 20px;
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
}

/* Responsive para MatrixCreator */
@media (max-width: 768px) {
    .matrix-cell {
        width: 35px;
        height: 35px;
        font-size: 0.8em;
    }
    
    .control-panel {
        padding: 15px;
    }
    
    .matrix-button {
        min-width: 120px;
        padding: 6px 12px;
        font-size: 0.9em;
    }
    
    .matrix-creator-container {
        flex-direction: column;
        gap: 20px;
    }
}

/* Animación de fadeIn */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/***** EMBEDDING - Estilos para MatrixLayout *****/
.basic .dashboard-div {
  border: 1px solid black;
  text-align: center;
}

.dark .dashboard-div {
  margin: 2px;
  border-radius: 10px;
  background-color: #262626;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
}

.glassmorphism .dashboard-div {
  margin: 5px;
  border-radius: 10px;
  background: rgb(255, 254, 254);
  border: 1px solid rgb(255, 255, 255);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.neumorphism .dashboard-div {
  margin: 10px;
  border-radius: 15px;
  background-color: #e0e0e0;
  box-shadow: 5px 5px 10px #bebebe, -5px -5px 10px #ffffff;
}

.minimalism .dashboard-div {
  margin-bottom: 5px;
}`, "",{"version":3,"sources":["webpack://./css/layout.css"],"names":[],"mappings":"AAAA,oCAAoC;AACpC;IACI,WAAW;IACX,YAAY;IACZ,kBAAkB;IAClB,yBAAyB;IACzB,eAAe;IACf,gBAAgB;IAChB,yBAAyB;IACzB,eAAe;IACf,iBAAiB;IACjB,aAAa;IACb,gBAAgB;IAChB,UAAU;IACV,SAAS;IACT,kBAAkB;AACtB;;AAEA;IACI,6CAA6C;IAC7C,WAAW;IACX,qBAAqB;AACzB;;AAEA;IACI,oCAAoC;IACpC,qBAAqB;IACrB,kDAAkD;IAClD,UAAU;AACd;;AAEA,qEAAqE;AACrE;IACI,uBAAuB;IACvB,SAAS;AACb;;;;;AAKA,+BAA+B;AAC/B;IACI,qBAAqB;IACrB,aAAa;IACb,iBAAiB;IACjB,mBAAmB;IACnB,yCAAyC;IACzC,+BAA+B;IAC/B,yBAAyB;IACzB,iBAAiB,EAAE,wDAAwD;IAC3E,kBAAkB,EAAE,6CAA6C;AACrE;;AAEA;IACI,aAAa;IACb,MAAM;IACN,gBAAgB;AACpB;;;AAGA,yBAAyB;AACzB;IACI,aAAa;IACb,sBAAsB,EAAE,0CAA0C;IAClE,uBAAuB;IACvB,mBAAmB;IACnB,SAAS,EAAE,mCAAmC;IAC9C,iBAAiB;IACjB,aAAa;AACjB;;AAEA,2CAA2C;AAC3C;IACI,gBAAgB,EAAE,iCAAiC;IACnD,aAAa;IACb,uBAAuB;IACvB,mBAAmB;IACnB,WAAW;AACf;;AAEA;IACI,mBAAmB;IACnB,YAAY;IACZ,kBAAkB;IAClB,kBAAkB;IAClB,eAAe;IACf,gBAAgB;IAChB,aAAa;IACb,mBAAmB;IACnB,QAAQ;IACR,wCAAwC;IACxC,UAAU;IACV,4BAA4B;IAC5B,yBAAyB;AAC7B;;AAEA;IACI,UAAU;IACV,wBAAwB;AAC5B;;AAEA;IACI,mBAAmB;AACvB;;AAEA;IACI,iBAAiB;IACjB,eAAe;AACnB;;AAEA,qCAAqC;AACrC;IACI,aAAa;IACb,sBAAsB;IACtB,SAAS;IACT,mBAAmB;IACnB,aAAa;IACb,mBAAmB;IACnB,mBAAmB;IACnB,wCAAwC;IACxC,gBAAgB;IAChB,sBAAsB,EAAE,2CAA2C;AACvE;;;AAGA;IACI,aAAa;IACb,mBAAmB;IACnB,SAAS;IACT,mBAAmB;AACvB;;AAEA;IACI,gBAAgB;IAChB,gBAAgB;IAChB,WAAW;AACf;;AAEA;IACI,iBAAiB;IACjB,iBAAiB;IACjB,kBAAkB;IAClB,WAAW;IACX,gBAAgB;IAChB,eAAe;IACf,kBAAkB;AACtB;;AAEA;IACI,aAAa;IACb,sBAAsB;IACtB,SAAS;AACb;;AAEA;IACI,iBAAiB;IACjB,WAAW;IACX,eAAe;IACf,YAAY;IACZ,kBAAkB;IAClB,mBAAmB;IACnB,WAAW;IACX,gBAAgB;IAChB,oBAAoB;IACpB,gBAAgB;AACpB;;AAEA;IACI,mBAAmB;IACnB,qCAAqC;AACzC;AACA;IACI,0BAA0B;AAC9B;;AAEA,gDAAgD;AAChD;IACI,aAAa;IACb,mBAAmB;IACnB,uBAAuB;IACvB,uBAAuB;IACvB,SAAS;IACT,aAAa;IACb,WAAW;IACX,iBAAiB;IACjB,cAAc;AAClB;;AAEA,kCAAkC;AAClC;IACI;QACI,WAAW;QACX,YAAY;QACZ,gBAAgB;IACpB;;IAEA;QACI,aAAa;IACjB;;IAEA;QACI,gBAAgB;QAChB,iBAAiB;QACjB,gBAAgB;IACpB;;IAEA;QACI,sBAAsB;QACtB,SAAS;IACb;AACJ;;AAEA,wBAAwB;AACxB;IACI;QACI,UAAU;QACV,4BAA4B;IAChC;IACA;QACI,UAAU;QACV,wBAAwB;IAC5B;AACJ;;AAEA,kDAAkD;AAClD;EACE,uBAAuB;EACvB,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,mBAAmB;EACnB,yBAAyB;EACzB,wCAAwC;AAC1C;;AAEA;EACE,WAAW;EACX,mBAAmB;EACnB,8BAA8B;EAC9B,oCAAoC;EACpC,2BAA2B;EAC3B,wCAAwC;AAC1C;;AAEA;EACE,YAAY;EACZ,mBAAmB;EACnB,yBAAyB;EACzB,wDAAwD;AAC1D;;AAEA;EACE,kBAAkB;AACpB","sourcesContent":["/* Estilos SOLO para MatrixCreator */\n.matrix-grid .matrix-cell {\n    width: 50px;\n    height: 50px;\n    text-align: center;\n    border: 2px solid #34495e;\n    font-size: 16px;\n    font-weight: 600;\n    transition: all 0.2s ease;\n    cursor: pointer;\n    background: white;\n    outline: none;\n    border-radius: 0;\n    padding: 0;\n    margin: 0;\n    position: relative;\n}\n\n.matrix-grid .matrix-cell:hover {\n    box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);\n    z-index: 10;\n    border-color: #667eea;\n}\n\n.matrix-grid .matrix-cell.selecting {\n    background: rgba(102, 126, 234, 0.3);\n    border-color: #667eea;\n    box-shadow: inset 0 0 8px rgba(102, 126, 234, 0.4);\n    z-index: 5;\n}\n\n/* Aplicar border más grueso solo a celdas con grupo EN MATRIX-GRID */\n.matrix-grid .matrix-cell[data-group]:not([data-group=\"0\"]) {\n    border: 2px solid white;\n    margin: 0;\n}\n\n\n\n\n/* Estilos para MatrixCreator */\n.matrix-grid {\n    display: inline-block;\n    padding: 1rem;\n    background: white;\n    border-radius: 15px;\n    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);\n    animation: fadeIn 0.3s ease-out;\n    border: 3px solid #000000;\n    overflow: visible; /* Cambiado de hidden a visible para permitir el scale */\n    position: relative; /* Añadido para contexto de posicionamiento */\n}\n\n.matrix-row {\n    display: flex;\n    gap: 0;\n    margin-bottom: 0;\n}\n\n\n/* Contenedor de matriz */\n.matrix-container {\n    display: flex;\n    flex-direction: column; /* Cambiado para apilar matriz y mensaje */\n    justify-content: center;\n    align-items: center;\n    gap: 20px; /* Espacio entre matriz y mensaje */\n    min-height: 200px;\n    padding: 20px;\n}\n\n/* Contenedor del mensaje de confirmación */\n.message-container {\n    min-height: 60px; /* Aumentado para evitar saltos */\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    width: 100%;\n}\n\n.confirmation-message {\n    background: #4CAF50;\n    color: white;\n    padding: 12px 20px;\n    border-radius: 4px;\n    font-size: 14px;\n    font-weight: 500;\n    display: flex;\n    align-items: center;\n    gap: 8px;\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n    opacity: 0;\n    transform: translateY(-10px);\n    transition: all 0.3s ease;\n}\n\n.confirmation-message.show {\n    opacity: 1;\n    transform: translateY(0);\n}\n\n.confirmation-message.error-message {\n    background: #e74c3c;\n}\n\n.check-icon {\n    font-weight: bold;\n    font-size: 16px;\n}\n\n/* Estilos para el panel de control */\n.control-panel {\n    display: flex;\n    flex-direction: column;\n    gap: 15px;\n    align-items: center;\n    padding: 20px;\n    background: #f8f9fa;\n    border-radius: 10px;\n    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n    min-width: 250px;\n    align-self: flex-start; /* Mantener el panel en la parte superior */\n}\n\n\n.group-info {\n    display: flex;\n    align-items: center;\n    gap: 15px;\n    margin-bottom: 15px;\n}\n\n.group-label {\n    font-size: 1.2em;\n    font-weight: 600;\n    color: #333;\n}\n\n.current-group-display {\n    font-weight: bold;\n    padding: 8px 20px;\n    border-radius: 4px;\n    color: #fff;\n    font-size: 1.3em;\n    min-width: 50px;\n    text-align: center;\n}\n\n.buttons-container {\n    display: flex;\n    flex-direction: column;\n    gap: 10px;\n}\n\n.matrix-button {\n    padding: 8px 16px;\n    margin: 5px;\n    cursor: pointer;\n    border: none;\n    border-radius: 4px;\n    background: #3498db;\n    color: #fff;\n    font-weight: 600;\n    transition: all 0.3s;\n    min-width: 150px;\n}\n\n.matrix-button:hover {\n    background: #2980b9;\n    box-shadow: 0 4px 8px rgba(0,0,0,0.2);\n}\n.matrix-button:active {\n    transform: translateY(1px);\n}\n\n/* Estilos para el contenedor de MatrixCreator */\n.matrix-creator-container {\n    display: flex;\n    flex-direction: row;\n    align-items: flex-start;\n    justify-content: center;\n    gap: 40px;\n    padding: 20px;\n    width: 100%;\n    max-width: 1200px;\n    margin: 0 auto;\n}\n\n/* Responsive para MatrixCreator */\n@media (max-width: 768px) {\n    .matrix-cell {\n        width: 35px;\n        height: 35px;\n        font-size: 0.8em;\n    }\n    \n    .control-panel {\n        padding: 15px;\n    }\n    \n    .matrix-button {\n        min-width: 120px;\n        padding: 6px 12px;\n        font-size: 0.9em;\n    }\n    \n    .matrix-creator-container {\n        flex-direction: column;\n        gap: 20px;\n    }\n}\n\n/* Animación de fadeIn */\n@keyframes fadeIn {\n    from {\n        opacity: 0;\n        transform: translateY(-10px);\n    }\n    to {\n        opacity: 1;\n        transform: translateY(0);\n    }\n}\n\n/***** EMBEDDING - Estilos para MatrixLayout *****/\n.basic .dashboard-div {\n  border: 1px solid black;\n  text-align: center;\n}\n\n.dark .dashboard-div {\n  margin: 2px;\n  border-radius: 10px;\n  background-color: #262626;\n  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);\n}\n\n.glassmorphism .dashboard-div {\n  margin: 5px;\n  border-radius: 10px;\n  background: rgb(255, 254, 254);\n  border: 1px solid rgb(255, 255, 255);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);\n}\n\n.neumorphism .dashboard-div {\n  margin: 10px;\n  border-radius: 15px;\n  background-color: #e0e0e0;\n  box-shadow: 5px 5px 10px #bebebe, -5px -5px 10px #ffffff;\n}\n\n.minimalism .dashboard-div {\n  margin-bottom: 5px;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./css/widget.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./css/widget.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.custom-widget {
  background-color: #f9f9f9;
  padding: 15px;
  border-radius: 8px;
  border: 1px solid #ddd;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

.custom-widget input {
  width: 100%;
  max-width: 280px;
  display: block;
}

.custom-widget svg {
  display: block;
  margin: 10px auto 0;
}

.dot {
  cursor: pointer;
}

.dot:hover {
  fill: #ff6b6b !important;
}

/***** BUTTON *****/
.button_container {
  display: flex;
  width: 100%;
  justify-content: center;
  align-items: center;
  margin: 8px 0;
}

.vp_button {
  appearance: none;
  border: none;
  border-radius: 8px;
  padding: 10px 16px;
  background: linear-gradient(180deg, #4f8df7 0%, #3874e6 100%);
  color: #fff;
  font-weight: 600;
  font-size: 14px;
  letter-spacing: 0.2px;
  box-shadow: 0 2px 6px rgba(56, 116, 230, 0.35);
  transition: transform 0.06s ease, box-shadow 0.2s ease, filter 0.2s ease, background 0.2s ease;
  cursor: pointer;
}

.vp_button:hover {
  filter: brightness(1.05);
  box-shadow: 0 4px 10px rgba(56, 116, 230, 0.45);
}

.vp_button:active {
  transform: translateY(1px);
  box-shadow: 0 2px 6px rgba(56, 116, 230, 0.35);
}

.vp_button:disabled,
.vp_button[disabled] {
  opacity: 0.6;
  cursor: not-allowed;
  filter: grayscale(0.2);
  box-shadow: none;
}

.vp_button:focus-visible {
  outline: 2px solid #b9d2ff;
  outline-offset: 2px;
}


/***** RANGE SLIDER *****/
.range_outside_container {
  display: flex;
  width: 100%;
  max-width: 500px;
  align-items: center;
  justify-content: center;
  gap: 12px;
  margin: 0 auto;
  flex-wrap: wrap;
}

.range_inside_container {
  display: flex;
  flex-direction: column;
  flex: 1 1 320px;
  min-width: 0;
  width: 100%;
  max-width: 100%;
}

.range_description {
  padding-right: 20px;
}

.range_value {
  padding-left: 20px;
  width: 80px;
}

.sliders_control {
  position: relative;
  min-height: 50px;
  width: 100%;
  padding: 0 8px;
  box-sizing: border-box;
}

input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  pointer-events: all;
  width: 24px;
  height: 24px;
  background-color: #fff;
  border-radius: 50%;
  box-shadow: 0 0 0 1px #c6c6c6;
  cursor: pointer;
}

input[type="range"]::-moz-range-thumb {
  appearance: none;
  pointer-events: all;
  width: 24px;
  height: 24px;
  background-color: #fff;
  border-radius: 50%;
  box-shadow: 0 0 0 1px #c6c6c6;
  cursor: pointer;
}

input[type="range"]::-webkit-slider-thumb:hover {
  background: #f7f7f7;
}

input[type="range"]::-webkit-slider-thumb:active {
  box-shadow: inset 0 0 3px #387bbe, 0 0 9px #387bbe;
  -webkit-box-shadow: inset 0 0 3px #387bbe, 0 0 9px #387bbe;
}

input[type="range"] {
  -webkit-appearance: none;
  appearance: none;
  height: 10px;
  width: 100%;
  border: none !important;
  position: absolute;
  background-color: #f79847;
  pointer-events: none;
  left: 0;
  right: 0;
  margin: 0 auto;
  box-sizing: border-box;
}

.top_slider {
  height: 0 !important;
  z-index: 1;
  top: 5px;
}


/***** SIDE BAR *****/
.side_bar {
  margin-top: 10px;
  height: 100%;
  float: right;
  display: flex;
  flex-direction: column;
}

.side_bar button {
  background-color: lightgrey;
  border: lightgrey;
  border-radius: 4px;
  color: white;
  margin: 4px 4px 0px 4px;
  padding: 4px 2px 2px 2px;
}

.side_bar button:hover {
  background-color: darkgrey;
  cursor: pointer;
}

.side_bar button.is_selected {
  background-color: darkgrey;
}

.side_bar button.is_selected.mode_negative {
  background-color: rgb(255, 119, 119);
}

.side_bar button svg {
  width: 16px;
  height: 16px;
}`, "",{"version":3,"sources":["webpack://./css/widget.css"],"names":[],"mappings":"AAAA;EACE,yBAAyB;EACzB,aAAa;EACb,kBAAkB;EAClB,sBAAsB;EACtB,sEAAsE;AACxE;;AAEA;EACE,WAAW;EACX,gBAAgB;EAChB,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,mBAAmB;AACrB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,wBAAwB;AAC1B;;AAEA,mBAAmB;AACnB;EACE,aAAa;EACb,WAAW;EACX,uBAAuB;EACvB,mBAAmB;EACnB,aAAa;AACf;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,kBAAkB;EAClB,kBAAkB;EAClB,6DAA6D;EAC7D,WAAW;EACX,gBAAgB;EAChB,eAAe;EACf,qBAAqB;EACrB,8CAA8C;EAC9C,8FAA8F;EAC9F,eAAe;AACjB;;AAEA;EACE,wBAAwB;EACxB,+CAA+C;AACjD;;AAEA;EACE,0BAA0B;EAC1B,8CAA8C;AAChD;;AAEA;;EAEE,YAAY;EACZ,mBAAmB;EACnB,sBAAsB;EACtB,gBAAgB;AAClB;;AAEA;EACE,0BAA0B;EAC1B,mBAAmB;AACrB;;;AAGA,yBAAyB;AACzB;EACE,aAAa;EACb,WAAW;EACX,gBAAgB;EAChB,mBAAmB;EACnB,uBAAuB;EACvB,SAAS;EACT,cAAc;EACd,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,eAAe;EACf,YAAY;EACZ,WAAW;EACX,eAAe;AACjB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,WAAW;AACb;;AAEA;EACE,kBAAkB;EAClB,gBAAgB;EAChB,WAAW;EACX,cAAc;EACd,sBAAsB;AACxB;;AAEA;EACE,wBAAwB;EACxB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,kBAAkB;EAClB,6BAA6B;EAC7B,eAAe;AACjB;;AAEA;EACE,gBAAgB;EAChB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,sBAAsB;EACtB,kBAAkB;EAClB,6BAA6B;EAC7B,eAAe;AACjB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,kDAAkD;EAClD,0DAA0D;AAC5D;;AAEA;EACE,wBAAwB;EACxB,gBAAgB;EAChB,YAAY;EACZ,WAAW;EACX,uBAAuB;EACvB,kBAAkB;EAClB,yBAAyB;EACzB,oBAAoB;EACpB,OAAO;EACP,QAAQ;EACR,cAAc;EACd,sBAAsB;AACxB;;AAEA;EACE,oBAAoB;EACpB,UAAU;EACV,QAAQ;AACV;;;AAGA,qBAAqB;AACrB;EACE,gBAAgB;EAChB,YAAY;EACZ,YAAY;EACZ,aAAa;EACb,sBAAsB;AACxB;;AAEA;EACE,2BAA2B;EAC3B,iBAAiB;EACjB,kBAAkB;EAClB,YAAY;EACZ,uBAAuB;EACvB,wBAAwB;AAC1B;;AAEA;EACE,0BAA0B;EAC1B,eAAe;AACjB;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,WAAW;EACX,YAAY;AACd","sourcesContent":[".custom-widget {\n  background-color: #f9f9f9;\n  padding: 15px;\n  border-radius: 8px;\n  border: 1px solid #ddd;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;\n}\n\n.custom-widget input {\n  width: 100%;\n  max-width: 280px;\n  display: block;\n}\n\n.custom-widget svg {\n  display: block;\n  margin: 10px auto 0;\n}\n\n.dot {\n  cursor: pointer;\n}\n\n.dot:hover {\n  fill: #ff6b6b !important;\n}\n\n/***** BUTTON *****/\n.button_container {\n  display: flex;\n  width: 100%;\n  justify-content: center;\n  align-items: center;\n  margin: 8px 0;\n}\n\n.vp_button {\n  appearance: none;\n  border: none;\n  border-radius: 8px;\n  padding: 10px 16px;\n  background: linear-gradient(180deg, #4f8df7 0%, #3874e6 100%);\n  color: #fff;\n  font-weight: 600;\n  font-size: 14px;\n  letter-spacing: 0.2px;\n  box-shadow: 0 2px 6px rgba(56, 116, 230, 0.35);\n  transition: transform 0.06s ease, box-shadow 0.2s ease, filter 0.2s ease, background 0.2s ease;\n  cursor: pointer;\n}\n\n.vp_button:hover {\n  filter: brightness(1.05);\n  box-shadow: 0 4px 10px rgba(56, 116, 230, 0.45);\n}\n\n.vp_button:active {\n  transform: translateY(1px);\n  box-shadow: 0 2px 6px rgba(56, 116, 230, 0.35);\n}\n\n.vp_button:disabled,\n.vp_button[disabled] {\n  opacity: 0.6;\n  cursor: not-allowed;\n  filter: grayscale(0.2);\n  box-shadow: none;\n}\n\n.vp_button:focus-visible {\n  outline: 2px solid #b9d2ff;\n  outline-offset: 2px;\n}\n\n\n/***** RANGE SLIDER *****/\n.range_outside_container {\n  display: flex;\n  width: 100%;\n  max-width: 500px;\n  align-items: center;\n  justify-content: center;\n  gap: 12px;\n  margin: 0 auto;\n  flex-wrap: wrap;\n}\n\n.range_inside_container {\n  display: flex;\n  flex-direction: column;\n  flex: 1 1 320px;\n  min-width: 0;\n  width: 100%;\n  max-width: 100%;\n}\n\n.range_description {\n  padding-right: 20px;\n}\n\n.range_value {\n  padding-left: 20px;\n  width: 80px;\n}\n\n.sliders_control {\n  position: relative;\n  min-height: 50px;\n  width: 100%;\n  padding: 0 8px;\n  box-sizing: border-box;\n}\n\ninput[type=\"range\"]::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  pointer-events: all;\n  width: 24px;\n  height: 24px;\n  background-color: #fff;\n  border-radius: 50%;\n  box-shadow: 0 0 0 1px #c6c6c6;\n  cursor: pointer;\n}\n\ninput[type=\"range\"]::-moz-range-thumb {\n  appearance: none;\n  pointer-events: all;\n  width: 24px;\n  height: 24px;\n  background-color: #fff;\n  border-radius: 50%;\n  box-shadow: 0 0 0 1px #c6c6c6;\n  cursor: pointer;\n}\n\ninput[type=\"range\"]::-webkit-slider-thumb:hover {\n  background: #f7f7f7;\n}\n\ninput[type=\"range\"]::-webkit-slider-thumb:active {\n  box-shadow: inset 0 0 3px #387bbe, 0 0 9px #387bbe;\n  -webkit-box-shadow: inset 0 0 3px #387bbe, 0 0 9px #387bbe;\n}\n\ninput[type=\"range\"] {\n  -webkit-appearance: none;\n  appearance: none;\n  height: 10px;\n  width: 100%;\n  border: none !important;\n  position: absolute;\n  background-color: #f79847;\n  pointer-events: none;\n  left: 0;\n  right: 0;\n  margin: 0 auto;\n  box-sizing: border-box;\n}\n\n.top_slider {\n  height: 0 !important;\n  z-index: 1;\n  top: 5px;\n}\n\n\n/***** SIDE BAR *****/\n.side_bar {\n  margin-top: 10px;\n  height: 100%;\n  float: right;\n  display: flex;\n  flex-direction: column;\n}\n\n.side_bar button {\n  background-color: lightgrey;\n  border: lightgrey;\n  border-radius: 4px;\n  color: white;\n  margin: 4px 4px 0px 4px;\n  padding: 4px 2px 2px 2px;\n}\n\n.side_bar button:hover {\n  background-color: darkgrey;\n  cursor: pointer;\n}\n\n.side_bar button.is_selected {\n  background-color: darkgrey;\n}\n\n.side_bar button.is_selected.mode_negative {\n  background-color: rgb(255, 119, 119);\n}\n\n.side_bar button svg {\n  width: 16px;\n  height: 16px;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./package.json":
/*!**********************!*\
  !*** ./package.json ***!
  \**********************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"name":"vizpro-js","version":"0.1.6","description":"A Custom Jupyter Widget Library","keywords":["jupyter","jupyterlab","jupyterlab-extension","widgets"],"files":["lib/**/*.js","dist/*.js","css/*.css"],"homepage":"https://github.com/matius/vizpro","bugs":{"url":"https://github.com/matius/vizpro/issues"},"license":"BSD-3-Clause","author":{"name":"MATIUS","email":"matias.fabricio.maravi@gmail.com"},"main":"lib/index.js","types":"./lib/index.d.ts","repository":{"type":"git","url":"https://github.com/matius/vizpro"},"scripts":{"build":"jlpm run build:lib && jlpm run build:nbextension && jlpm run build:labextension:dev","build:prod":"jlpm run build:lib && jlpm run build:nbextension && jlpm run build:labextension","build:labextension":"jupyter labextension build .","build:labextension:dev":"jupyter labextension build --development True .","build:lib":"tsc","build:nbextension":"webpack","clean":"jlpm run clean:lib && jlpm run clean:nbextension && jlpm run clean:labextension","clean:lib":"rimraf lib","clean:labextension":"rimraf vizpro/labextension","clean:nbextension":"rimraf vizpro/nbextension/static/index.js","lint":"eslint . --ext .ts,.tsx --fix","lint:check":"eslint . --ext .ts,.tsx","prepack":"jlpm run build:lib","test":"jest","watch":"npm-run-all -p watch:*","watch:lib":"tsc -w","watch:nbextension":"webpack --watch --mode=development","watch:labextension":"jupyter labextension watch ."},"dependencies":{"@jupyter-widgets/base":"^1.1.10 || ^2 || ^3 || ^4 || ^5 || ^6","@types/d3":"^7.4.3","d3":"^7.9.0","lucide":"^0.545.0"},"devDependencies":{"@babel/core":"^7.23.7","@babel/preset-env":"^7.23.8","@jupyter-widgets/base-manager":"^1.0.7","@jupyterlab/builder":"^4.0.11","@lumino/application":"^2.3.0","@lumino/widgets":"^2.3.1","@types/jest":"^29.5.11","@types/webpack-env":"^1.18.4","@typescript-eslint/eslint-plugin":"^6.19.1","@typescript-eslint/parser":"^6.19.1","acorn":"^8.11.3","css-loader":"^6.9.1","eslint":"^8.56.0","eslint-config-prettier":"^9.1.0","eslint-plugin-prettier":"^5.1.3","fs-extra":"^11.2.0","identity-obj-proxy":"^3.0.0","jest":"^29.7.0","mkdirp":"^3.0.1","npm-run-all":"^4.1.5","prettier":"^3.2.4","rimraf":"^5.0.5","source-map-loader":"^5.0.0","style-loader":"^3.3.4","ts-jest":"^29.1.2","ts-loader":"^9.5.1","typescript":"~5.3.3","webpack":"^5.90.0","webpack-cli":"^5.1.4"},"devDependenciesComments":{"@jupyterlab/builder":"pinned to the latest JupyterLab 3.x release","@lumino/application":"pinned to the latest Lumino 1.x release","@lumino/widgets":"pinned to the latest Lumino 1.x release"},"jupyterlab":{"extension":"lib/plugin","outputDir":"vizpro/labextension/","sharedPackages":{"@jupyter-widgets/base":{"bundled":false,"singleton":true}}}}');

/***/ })

}]);
//# sourceMappingURL=lib_graphs_js-lib_layouts_js-lib_version_js-lib_widgets_js.98ff1fe315bc1a811b1e.js.map