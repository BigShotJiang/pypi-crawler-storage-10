from someip_py.interface import SOMEIPService

__version__ = "0.0.18"

__all__ = ["SOMEIPService"]
