from .pres import ConfigTreeDialog  # noqa: F401
