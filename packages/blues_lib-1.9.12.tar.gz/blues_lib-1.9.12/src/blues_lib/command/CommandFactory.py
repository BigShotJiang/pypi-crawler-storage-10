from blues_lib.type.factory.Factory import Factory
from blues_lib.type.executor.Command import Command
from blues_lib.namespace.CommandName import CommandName

# standard
from blues_lib.command.standard.Dummy import Dummy
from blues_lib.command.standard.Cleaner import Cleaner

# control
from blues_lib.command.control.Blocker import Blocker
from blues_lib.command.control.Retryer import Retryer
from blues_lib.command.control.Printer import Printer

# browser
from blues_lib.command.browser.Creator import Creator

# sql
from blues_lib.command.sql.Querier import Querier
from blues_lib.command.sql.Updater import Updater
from blues_lib.command.sql.Inserter import Inserter
from blues_lib.command.sql.Deleter import Deleter

# llm
from blues_lib.command.llm.Writer import Writer

# crawler
from blues_lib.command.crawler.Engine import Engine

# material
from blues_lib.command.material.Sinker import Sinker
from blues_lib.command.material.Deduplicator import Deduplicator
from blues_lib.command.material.Validator import Validator
from blues_lib.command.material.Normalizer import Normalizer
from blues_lib.command.material.Localizer import Localizer

# notifier
from blues_lib.command.notifier.Email import Email

# --- flow command ---
# flow
from blues_lib.command.flow.Engine import Engine as FlowEngine

class CommandFactory(Factory):

  _COMMANDS:dict[str,Command] = {
    # standard
    Dummy.NAME:Dummy,
    Cleaner.NAME:Cleaner,
    
    # control
    Blocker.NAME:Blocker,
    Retryer.NAME:Retryer,
    Printer.NAME:Printer,
    
    # browser
    Creator.NAME:Creator,
    
    # llm
    Writer.NAME:Writer,
    
    # crawler
    Engine.NAME:Engine,
    
    # sql
    Querier.NAME:Querier,
    Updater.NAME:Updater,
    Inserter.NAME:Inserter,
    Deleter.NAME:Deleter,
    
    # material
    Sinker.NAME:Sinker,
    Deduplicator.NAME:Deduplicator,
    Validator.NAME:Validator,
    Normalizer.NAME:Normalizer,
    Localizer.NAME:Localizer,
    
    # notifier
    Email.NAME:Email,

    # flow command
    FlowEngine.NAME:FlowEngine,
  }
  
  def __init__(self,context:dict,input:dict,task_id:str) -> None:
    self._context = context
    self._input = input
    self._task_id = task_id
    
  def create(self,name:CommandName)->Command | None:
    # overide
    cmd = self._COMMANDS.get(name)
    return cmd(self._context,self._input,self._task_id) if cmd else None

