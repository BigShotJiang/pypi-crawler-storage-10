"""
advanced usage examples for pytest-casewise-package-install
"""

import pytest
from pytest_casewise_package_install import with_packages


class TestPackageVersions:
    """test class demonstrating different package versions"""

    @with_packages({"click": "8.1.3"})
    def test_click_8_1_3(self):
        """test with click version 8.1.3"""
        import click

        assert click.__version__ == "8.1.3"

    @with_packages({"click": "8.0.0"})
    def test_click_8_0_0(self):
        """test with click version 8.0.0"""
        import click

        assert click.__version__ == "8.0.0"


@pytest.mark.parametrize(
    "package_versions",
    [
        {"pyyaml": "6.0"},
        {"pyyaml": "5.4.1"},
    ],
)
def test_with_parametrize(package_versions):
    """
    example of using parametrize with package versions
    note: this requires the marker approach
    """
    pytest.skip("parametrize with dynamic packages not directly supported, use fixtures instead")


@pytest.fixture
def yaml_6_0_env():
    """fixture that provides yaml 6.0 environment"""
    pytest.importorskip("yaml")
    import yaml

    return yaml


@with_packages({"pyyaml": "6.0"})
def test_with_fixture_and_packages(yaml_6_0_env):
    """test combining fixtures with package requirements"""
    yaml = yaml_6_0_env
    data = {"key": "value"}
    yaml_str = yaml.dump(data)
    assert "key: value" in yaml_str
