# Examples

This directory contains example usage of the pytest-casewise-package-install plugin.

## Running the Examples

1. Install the plugin:
```bash
pip install -e ..
```

2. Run the basic examples:
```bash
pytest test_basic_usage.py -v -s
```

3. Run the advanced examples:
```bash
pytest test_advanced_usage.py -v -s
```

4. Run all examples:
```bash
pytest -v -s
```

## Example Files

### test_basic_usage.py
Contains basic usage examples:
- Using decorator syntax
- Using pytest marker syntax
- Multiple packages in one test
- Tests without package requirements
- Cache reuse demonstration

### test_advanced_usage.py
Contains advanced usage examples:
- Using package requirements in test classes
- Different versions of the same package in different tests
- Combining with fixtures

## Configuration

The `pytest.ini` file in this directory shows available configuration options for the plugin.
