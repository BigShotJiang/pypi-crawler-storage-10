"""
basic usage examples for pytest-casewise-package-install
"""

import pytest
from pytest_casewise_package_install import with_packages


# example 1: using decorator
@with_packages({"requests": "2.31.0"})
def test_with_requests_2_31_0():
    """test with specific requests version using decorator"""
    import requests

    print(f"requests version: {requests.__version__}")
    assert requests.__version__ == "2.31.0"


# example 2: using pytest marker
@pytest.mark.with_packages(packages={"requests": "2.28.0"})
def test_with_requests_2_28_0():
    """test with different requests version using marker"""
    import requests

    print(f"requests version: {requests.__version__}")
    assert requests.__version__ == "2.28.0"


# example 3: multiple packages
@with_packages({"certifi": "2023.7.22", "urllib3": "2.0.4"})
def test_with_multiple_packages():
    """test with multiple package versions"""
    import certifi
    import urllib3

    print(f"certifi version: {certifi.__version__}")
    print(f"urllib3 version: {urllib3.__version__}")
    assert certifi.__version__ == "2023.7.22"
    assert urllib3.__version__ == "2.0.4"


# example 4: test without special packages
def test_without_packages():
    """normal test without package requirements"""
    assert 1 + 1 == 2


# example 5: same packages as example 3, should reuse cache
@with_packages({"certifi": "2023.7.22", "urllib3": "2.0.4"})
def test_with_same_packages_again():
    """test with same package set to verify caching"""
    import certifi
    import urllib3

    assert certifi.__version__ == "2023.7.22"
    assert urllib3.__version__ == "2.0.4"
