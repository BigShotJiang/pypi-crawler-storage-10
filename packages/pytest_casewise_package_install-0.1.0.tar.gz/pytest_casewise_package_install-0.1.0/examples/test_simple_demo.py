"""
simple demonstration of the plugin for quick testing
"""

import pytest
from pytest_casewise_package_install import with_packages


@with_packages({"six": "1.16.0"})
def test_six_1_16():
    """test with six version 1.16.0"""
    import six

    print(f"\n? Successfully imported six version: {six.__version__}")
    assert six.__version__ == "1.16.0"


@with_packages({"six": "1.15.0"})
def test_six_1_15():
    """test with six version 1.15.0"""
    import six

    print(f"\n? Successfully imported six version: {six.__version__}")
    assert six.__version__ == "1.15.0"


def test_without_packages():
    """test without special package requirements"""
    print("\n? Regular test without package requirements")
    assert True


@pytest.mark.with_packages(packages={"six": "1.16.0"})
def test_with_marker():
    """test using pytest marker instead of decorator"""
    import six

    print(f"\n? Using marker: six version {six.__version__}")
    assert six.__version__ == "1.16.0"


if __name__ == "__main__":
    # this allows running the file directly with pytest
    pytest.main([__file__, "-v", "-s"])
