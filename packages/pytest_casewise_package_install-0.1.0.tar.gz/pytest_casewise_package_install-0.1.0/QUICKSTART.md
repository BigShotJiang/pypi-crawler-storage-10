# Quick Start Guide

## Installation

```bash
# Install in development mode
pip install -e .

# Or install from PyPI (when published)
pip install pytest-casewise-package-install
```

## Basic Usage

### 1. Create a Test File

Create a file `test_example.py`:

```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_requests_version():
    import requests
    print(f"Using requests version: {requests.__version__}")
    assert requests.__version__ == "2.31.0"

@with_packages({"requests": "2.28.0"})
def test_different_requests_version():
    import requests
    print(f"Using requests version: {requests.__version__}")
    assert requests.__version__ == "2.28.0"
```

### 2. Run the Test

```bash
pytest test_example.py -v -s
```

The plugin will:
1. Detect the package requirements from the decorator
2. Install the required packages to isolated directories
3. Set up the environment for each test
4. Run the test with the specified package versions
5. Clean up the environment after each test

### 3. View the Cache

The packages are cached in `~/.local_package_cache/`:

```bash
ls ~/.local_package_cache/
# Output example:
# requests_2_28_0/
# requests_2_31_0/
```

## Configuration Example

Create a `pytest.ini` file:

```ini
[pytest]
# custom cache location
casewise_cache_dir = /tmp/my_test_cache

# enable verbose logging
casewise_verbose = true

# set installation timeout (in seconds)
casewise_install_timeout = 600
```

## Advanced Examples

### Using Pytest Marker

```python
import pytest

@pytest.mark.with_packages(packages={"click": "8.1.3"})
def test_with_marker():
    import click
    assert click.__version__ == "8.1.3"
```

### Multiple Packages

```python
from pytest_casewise_package_install import with_packages

@with_packages({
    "numpy": "1.24.0",
    "pandas": "1.5.0"
})
def test_multiple_deps():
    import numpy as np
    import pandas as pd
    
    assert np.__version__ == "1.24.0"
    assert pd.__version__ == "1.5.0"
```

### Test Classes

```python
from pytest_casewise_package_install import with_packages

class TestVersionCompatibility:
    @with_packages({"pyyaml": "6.0"})
    def test_yaml_6_0(self):
        import yaml
        assert yaml.__version__ == "6.0"
    
    @with_packages({"pyyaml": "5.4.1"})
    def test_yaml_5_4_1(self):
        import yaml
        assert yaml.__version__ == "5.4.1"
```

## Troubleshooting

### Issue: Package installation fails

**Solution**: Check the package name and version are correct. Try installing manually first:
```bash
pip install package_name==version
```

### Issue: Import fails even though package is installed

**Solution**: Some packages with complex dependencies might not work with `--target` installation. Consider using virtual environments for such cases.

### Issue: Tests are slow

**Solution**: The first run will be slower as packages are installed. Subsequent runs will use the cache. You can pre-install packages by running a dummy test.

### Issue: Disk space concerns

**Solution**: The cache directory can grow large. You can:
1. Set a custom cache location with less space constraints
2. Manually clean the cache directory: `rm -rf ~/.local_package_cache/`
3. Add cleanup logic to your CI/CD pipeline

## Next Steps

- Check out the `examples/` directory for more usage patterns
- Read the full README.md for detailed documentation
- Run the test suite: `pytest tests/`
