# pytest-casewise-package-install

[English](#english) | [??](#??)

---

## English

A pytest plugin for test case-level dynamic dependency management. Solves dependency conflicts between multiple test cases by automatically installing required package versions before test execution and cleaning up the environment afterward, ensuring isolation and consistency.

### Features

- ?? **Test Case-Level Package Management**: Specify different package versions for each test case
- ?? **Dependency Isolation**: Avoid conflicts between tests requiring different package versions
- ?? **Automatic Installation**: Packages are installed automatically before test execution
- ?? **Automatic Cleanup**: Environment is restored after each test
- ?? **Smart Caching**: Package installations are cached and reused across tests
- ?? **Multiple Usage Patterns**: Decorator or marker-based syntax

### Installation

```bash
pip install pytest-casewise-package-install
```

### Quick Start

#### Using Decorator

```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_with_requests():
    import requests
    assert requests.__version__ == "2.31.0"
```

#### Using Pytest Marker

```python
import pytest

@pytest.mark.with_packages(packages={"requests": "2.28.0"})
def test_with_marker():
    import requests
    assert requests.__version__ == "2.28.0"
```

#### Multiple Packages

```python
from pytest_casewise_package_install import with_packages

@with_packages({
    "numpy": "1.26.4",
    "pandas": "2.0.0"
})
def test_multiple_packages():
    import numpy
    import pandas
    assert numpy.__version__ == "1.26.4"
    assert pandas.__version__ == "2.0.0"
```

### Configuration

You can configure the plugin behavior in `pytest.ini` or `setup.cfg`:

```ini
[pytest]
# custom cache directory (optional)
casewise_cache_dir = ~/.my_custom_cache

# automatically cleanup environment after each test (default: true)
casewise_auto_cleanup = true

# package installation timeout in seconds (default: 300)
casewise_install_timeout = 300

# verbose output (default: false)
casewise_verbose = true
```

Or use environment variables:

```bash
export CASEWISE_CACHE_DIR=~/.my_custom_cache
export CASEWISE_AUTO_CLEANUP=true
export CASEWISE_INSTALL_TIMEOUT=300
export CASEWISE_VERBOSE=true
```

### How It Works

1. **Test Discovery**: The plugin hooks into pytest's test collection phase
2. **Package Detection**: Detects package requirements from decorators or markers
3. **Environment Setup**: Before test execution:
   - Creates isolated installation directory for required packages
   - Installs packages using `pip install --target`
   - Modifies `PYTHONPATH` and `sys.path` to use the isolated packages
4. **Test Execution**: Test runs with the specified package versions
5. **Cleanup**: After test execution:
   - Restores original `PYTHONPATH` and `sys.path`
   - Keeps installed packages cached for future tests

### Advanced Usage

#### Test Class with Different Versions

```python
from pytest_casewise_package_install import with_packages

class TestPackageVersions:
    @with_packages({"click": "8.1.3"})
    def test_click_8_1_3(self):
        import click
        assert click.__version__ == "8.1.3"
    
    @with_packages({"click": "8.0.0"})
    def test_click_8_0_0(self):
        import click
        assert click.__version__ == "8.0.0"
```

#### Reusing Package Sets

The plugin automatically caches package installations. If two tests require the same package set, the second test will reuse the first test's installation:

```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_one():
    import requests
    assert requests.__version__ == "2.31.0"

@with_packages({"requests": "2.31.0"})
def test_two():
    # reuses the installation from test_one
    import requests
    assert requests.__version__ == "2.31.0"
```

### Use Cases

This plugin is particularly useful when:

- Testing compatibility with multiple versions of a dependency
- Running tests that require conflicting package versions
- Testing migration paths between package versions
- Ensuring test isolation in CI/CD pipelines
- Testing against different versions of transitive dependencies

### Limitations

- Package installation happens during test setup, which may increase test duration
- Large packages can consume significant disk space in the cache directory
- Some packages with complex native dependencies may not work correctly with `--target` installation
- Import-time side effects in packages may not be fully isolated

### Development

#### Setup Development Environment

```bash
git clone https://github.com/yourusername/pytest-casewise-package-install
cd pytest-casewise-package-install
pip install -e .
```

#### Run Tests

```bash
pytest tests/
```

#### Run Examples

```bash
cd examples
pytest -v
```

### License

MIT License

---

## ??

????????????????? pytest ?????????????????????????????????????????????????????????

### ????

- ?? **????????**: ???????????????
- ?? **????**: ??????????????????
- ?? **????**: ???????????
- ?? **????**: ?????????
- ?? **????**: ?????????????
- ?? **??????**: ???????????

### ??

```bash
pip install pytest-casewise-package-install
```

### ????

#### ?????

```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_with_requests():
    import requests
    assert requests.__version__ == "2.31.0"
```

#### ?? Pytest Marker

```python
import pytest

@pytest.mark.with_packages(packages={"requests": "2.28.0"})
def test_with_marker():
    import requests
    assert requests.__version__ == "2.28.0"
```

#### ???

```python
from pytest_casewise_package_install import with_packages

@with_packages({
    "numpy": "1.26.4",
    "pandas": "2.0.0"
})
def test_multiple_packages():
    import numpy
    import pandas
    assert numpy.__version__ == "1.26.4"
    assert pandas.__version__ == "2.0.0"
```

### ??

??? `pytest.ini` ? `setup.cfg` ????????

```ini
[pytest]
# ???????????
casewise_cache_dir = ~/.my_custom_cache

# ??????????????: true?
casewise_auto_cleanup = true

# ????????????: 300?
casewise_install_timeout = 300

# ???????: false?
casewise_verbose = true
```

????????

```bash
export CASEWISE_CACHE_DIR=~/.my_custom_cache
export CASEWISE_AUTO_CLEANUP=true
export CASEWISE_INSTALL_TIMEOUT=300
export CASEWISE_VERBOSE=true
```

### ????

1. **????**: ???? pytest ???????
2. **???**: ?????????????
3. **????**: ???????
   - ??????????????
   - ?? `pip install --target` ???
   - ?? `PYTHONPATH` ? `sys.path` ???????
4. **????**: ????????????
5. **??**: ??????
   - ????? `PYTHONPATH` ? `sys.path`
   - ??????????????????

### ????

#### ??????????

```python
from pytest_casewise_package_install import with_packages

class TestPackageVersions:
    @with_packages({"click": "8.1.3"})
    def test_click_8_1_3(self):
        import click
        assert click.__version__ == "8.1.3"
    
    @with_packages({"click": "8.0.0"})
    def test_click_8_0_0(self):
        import click
        assert click.__version__ == "8.0.0"
```

#### ?????

???????????????????????????????????????????

```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_one():
    import requests
    assert requests.__version__ == "2.31.0"

@with_packages({"requests": "2.31.0"})
def test_two():
    # ???? test_one ???
    import requests
    assert requests.__version__ == "2.31.0"
```

### ????

??????????????

- ??????????????
- ????????????
- ????????????
- ? CI/CD ?????????
- ???????????

### ??

- ????????????????????????
- ????????????????????
- ???????????????????? `--target` ??
- ?????????????????

### ??

#### ??????

```bash
git clone https://github.com/yourusername/pytest-casewise-package-install
cd pytest-casewise-package-install
pip install -e .
```

#### ????

```bash
pytest tests/
```

#### ????

```bash
cd examples
pytest -v
```

### ???

MIT License
