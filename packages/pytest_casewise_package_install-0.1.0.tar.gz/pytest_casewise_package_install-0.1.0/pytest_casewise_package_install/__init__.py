"""
pytest-casewise-package-install

a pytest plugin for test case-level dynamic dependency management.
solves dependency conflicts between multiple test cases by automatically
installing required package versions before test execution and cleaning
up the environment afterward, ensuring isolation and consistency.
"""

__version__ = "0.1.0"

from .markers import with_packages
from .package_manager import LocalMultiPackageManager, PackageStatus

__all__ = ["with_packages", "LocalMultiPackageManager", "PackageStatus"]
