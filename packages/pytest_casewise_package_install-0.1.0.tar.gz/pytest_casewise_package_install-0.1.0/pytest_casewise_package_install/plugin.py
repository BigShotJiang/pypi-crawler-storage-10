"""
pytest plugin implementation for casewise package installation
"""

import logging
import os
import sys
from typing import Dict, Optional

import pytest

from .package_manager import LocalMultiPackageManager

logger = logging.getLogger(__name__)


class PackageInstallPlugin:
    """
    pytest plugin for managing test case-level package installations
    """

    def __init__(self):
        self.package_managers: Dict[str, LocalMultiPackageManager] = {}
        self.original_pythonpath: Optional[str] = None
        self.original_sys_path: list = []

    def _get_package_requirements(self, item) -> Optional[Dict[str, str]]:
        """
        extract package requirements from test item

        Args:
            item: pytest test item

        Returns:
            dict of package requirements or None
        """
        # check for decorator attribute
        if hasattr(item.function, "_required_packages"):
            return item.function._required_packages

        # check for pytest marker
        marker = item.get_closest_marker("with_packages")
        if marker:
            if "packages" in marker.kwargs:
                return marker.kwargs["packages"]
            if marker.args:
                return marker.args[0]

        return None

    def _create_package_key(self, packages: Dict[str, str]) -> str:
        """
        create a unique key for package set

        Args:
            packages: dict with package names as keys and versions as values

        Returns:
            unique string key
        """
        sorted_items = sorted(packages.items())
        return "|".join([f"{name}=={version}" for name, version in sorted_items])

    def _get_or_create_manager(self, packages: Dict[str, str]) -> LocalMultiPackageManager:
        """
        get existing package manager or create new one

        Args:
            packages: dict with package names as keys and versions as values

        Returns:
            LocalMultiPackageManager instance
        """
        package_key = self._create_package_key(packages)

        if package_key not in self.package_managers:
            logger.info(f"creating package manager for: {package_key}")
            self.package_managers[package_key] = LocalMultiPackageManager(packages=packages)
        else:
            logger.info(f"reusing existing package manager for: {package_key}")

        return self.package_managers[package_key]

    def _backup_environment(self):
        """backup current environment state"""
        self.original_pythonpath = os.environ.get("PYTHONPATH")
        self.original_sys_path = sys.path.copy()

    def _restore_environment(self):
        """restore original environment state"""
        if self.original_pythonpath is not None:
            os.environ["PYTHONPATH"] = self.original_pythonpath
        elif "PYTHONPATH" in os.environ:
            del os.environ["PYTHONPATH"]

        sys.path = self.original_sys_path.copy()

    def _apply_package_environment(self, manager: LocalMultiPackageManager):
        """
        apply package manager environment to current process

        Args:
            manager: LocalMultiPackageManager instance
        """
        env = manager.get_environment_vars()

        # update os.environ
        if "PYTHONPATH" in env:
            os.environ["PYTHONPATH"] = env["PYTHONPATH"]

        # update sys.path to include package directories
        for package_dir in manager._current_package_directories:
            if package_dir not in sys.path:
                sys.path.insert(0, package_dir)

    def setup_test_packages(self, item):
        """
        setup packages before test execution

        Args:
            item: pytest test item
        """
        packages = self._get_package_requirements(item)
        if not packages:
            return

        logger.info(f"setting up packages for test: {item.nodeid}")

        # backup current environment
        self._backup_environment()

        try:
            # get or create package manager
            manager = self._get_or_create_manager(packages)

            # verify all packages are ready
            all_ready = True
            for package_name, version in packages.items():
                if not manager.is_package_ready(package_name, version):
                    logger.error(f"package {package_name}=={version} is not ready")
                    all_ready = False

            if not all_ready:
                pytest.fail("required packages are not ready")

            # apply package environment
            self._apply_package_environment(manager)

            # store manager reference on item for cleanup
            item._package_manager = manager

        except Exception as e:
            logger.error(f"failed to setup packages: {e}")
            self._restore_environment()
            pytest.fail(f"package setup failed: {e}")

    def teardown_test_packages(self, item):
        """
        cleanup packages after test execution

        Args:
            item: pytest test item
        """
        if hasattr(item, "_package_manager"):
            logger.info(f"cleaning up packages for test: {item.nodeid}")
            self._restore_environment()
            delattr(item, "_package_manager")


# global plugin instance
_plugin_instance = None


def pytest_configure(config):
    """
    pytest hook: configure plugin

    Args:
        config: pytest config object
    """
    global _plugin_instance

    # register custom marker
    config.addinivalue_line(
        "markers",
        "with_packages(packages): specify package requirements for test case",
    )

    # create plugin instance
    _plugin_instance = PackageInstallPlugin()


def pytest_runtest_setup(item):
    """
    pytest hook: setup before test execution

    Args:
        item: pytest test item
    """
    if _plugin_instance:
        _plugin_instance.setup_test_packages(item)


def pytest_runtest_teardown(item):
    """
    pytest hook: teardown after test execution

    Args:
        item: pytest test item
    """
    if _plugin_instance:
        _plugin_instance.teardown_test_packages(item)
