import logging
import os
import re
import subprocess
import sys
from enum import Enum

"""
package helper module for test environment package management

this module provides utilities for managing test-specific package installations
to avoid conflicts with system packages. it creates isolated installation
directories for different package versions and manages environment variables
for proper import paths.

usage:
    # basic usage with default transformers package
    manager = LocalMultiPackageManager()

    # specify custom packages and versions
    manager = LocalMultiPackageManager(packages={"transformers": "4.53.0", "numpy": "1.26.4"})

    # check if package is ready
    is_ready = manager.is_package_ready("transformers", "4.53.0")

    # get environment variables for subprocess
    env = manager.get_environment_vars()

    # install single package
    success = manager.install_single_package("transformers", "4.53.0")
"""

# configure logging
logger = logging.getLogger(__name__)


class PackageStatus(Enum):
    """package status enumeration"""

    READY = "ready"  # green: package is ready to use
    INSTALLING = "installing"  # yellow: package is being installed
    FAILED = "failed"  # red: package installation failed


class LocalMultiPackageManager:
    """
    local package manager for managing test-specific package installations

    """

    def __init__(self, packages: dict[str, str] | None = None):
        """
        initialize the local package manager and ensure packages are available

        Args:
            packages: dict with package names as keys and versions as values
        """
        if packages is None:
            packages = {}

        # memory cache to track installed packages to avoid duplicate operations
        self._installed_packages = set()
        # instance variable to maintain current instance package directories
        self._current_package_directories = []
        # track package status for monitoring
        self._package_status = {}

        self.manager_base_dir = os.path.join(os.path.expanduser("~"), ".local_package_cache")
        self.managed_packages = packages

        # prepare environment variables for subprocess usage
        self.environment_vars = None
        self._prepare_environment_vars()

        if packages:
            self.ensure_all_packages_ready(packages)

    def _sanitize_filesystem_name(self, name: str) -> str:
        """
        sanitize package name or version for filesystem compatibility

        Example:
            _sanitize_filesystem_name("transformers") -> "transformers"
            _sanitize_filesystem_name("4.51.3") -> "4_51_3"
            _sanitize_filesystem_name("my-package@2.0") -> "my_package_2_0"
        """
        # replace any non-alphanumeric characters with underscores
        sanitized = re.sub(r"[^a-zA-Z0-9]", "_", name)
        # collapse multiple consecutive underscores into single underscore
        sanitized = re.sub(r"_+", "_", sanitized)
        # remove leading and trailing underscores
        return sanitized.strip("_")

    def _get_package_install_dir(self, package_name: str, version: str) -> str:
        """
        get installation directory path for a specific package and version

        Args:
            package_name: package name
            version: package version

        Returns:
            str: absolute path to installation directory
        """
        # sanitize package name and version to ensure filesystem compatibility
        sanitized_package_name = self._sanitize_filesystem_name(package_name)
        sanitized_version = self._sanitize_filesystem_name(version)

        # construct installation directory name with sanitized components
        install_folder_name = f"{sanitized_package_name}_{sanitized_version}"

        # build full installation directory path
        install_dir_path = os.path.join(self.manager_base_dir, install_folder_name)
        return os.path.abspath(install_dir_path)

    def _get_package_key(self, package_name: str, version: str) -> str:
        """
        get unique key for package identification

        Args:
            package_name: package name
            version: package version

        Returns:
            str: unique package key
        """
        return f"{package_name}=={version}"

    def _set_package_status(self, package_name: str, version: str, status: PackageStatus) -> None:
        """
        set package status for monitoring

        Args:
            package_name: package name
            version: package version
            status: package status
        """
        package_key = self._get_package_key(package_name, version)
        self._package_status[package_key] = status

        # log status changes with appropriate level
        if status == PackageStatus.READY:
            logger.info(f"package {package_key} status: {status.value}")
        elif status == PackageStatus.INSTALLING:
            logger.warning(f"package {package_key} status: {status.value}")
        elif status == PackageStatus.FAILED:
            logger.error(f"package {package_key} status: {status.value}")

    def get_package_status(self, package_name: str, version: str) -> PackageStatus:
        """
        get current package status

        Args:
            package_name: package name
            version: package version

        Returns:
            PackageStatus: current package status
        """
        package_key = self._get_package_key(package_name, version)
        return self._package_status.get(package_key, PackageStatus.FAILED)

    def _is_package_directory_exists(self, package_name: str, version: str) -> bool:
        """
        check if package installation directory exists

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if installation directory exists, False otherwise
        """
        install_dir = self._get_package_install_dir(package_name, version)
        return os.path.exists(install_dir) and os.path.isdir(install_dir)

    def _is_package_cached_in_memory(self, package_name: str, version: str) -> bool:
        """
        check if package is tracked in memory cache

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if package is in memory cache, False otherwise
        """
        package_key = self._get_package_key(package_name, version)
        return package_key in self._installed_packages

    def _mark_package_as_installed(self, package_name: str, version: str) -> None:
        """
        mark package as installed in memory cache

        Args:
            package_name: package name
            version: package version
        """
        package_key = self._get_package_key(package_name, version)
        self._installed_packages.add(package_key)

        # set status to ready
        self._set_package_status(package_name, version, PackageStatus.READY)

        # add package directory to current instance package directories
        install_dir = self._get_package_install_dir(package_name, version)
        if install_dir not in self._current_package_directories:
            self._current_package_directories.append(install_dir)

        # update environment variables when new package is added
        self._prepare_environment_vars()

    def _create_pip_environment_with_path(self, package_install_dir: str) -> dict:
        """
        create environment with PYTHONPATH for pip commands

        Args:
            package_install_dir: path to package installation directory

        Returns:
            dict: environment variables
        """
        env = os.environ.copy()
        env["PYTHONPATH"] = package_install_dir
        return env

    def _prepare_environment_vars(self) -> None:
        """
        prepare environment variables with PYTHONPATH containing all package directories
        stored as class attribute for easy access
        """
        env = os.environ.copy()
        pythonpath_dirs = self._current_package_directories

        if pythonpath_dirs:
            existing_pythonpath = env.get("PYTHONPATH", "")
            if existing_pythonpath:
                env["PYTHONPATH"] = os.pathsep.join([*pythonpath_dirs, existing_pythonpath])
            else:
                env["PYTHONPATH"] = os.pathsep.join(pythonpath_dirs)

        self.environment_vars = env

    def get_environment_vars(self) -> dict:
        """
        get environment variables with configured PYTHONPATH for subprocess usage

        Returns:
            dict: environment variables ready for subprocess usage
        """
        if self.environment_vars is None:
            self._prepare_environment_vars()
        return self.environment_vars

    def _verify_package_installation_with_pip(self, package_name: str, version: str) -> bool:
        """
        verify package installation using pip show command

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if package is installed, False otherwise
        """
        package_install_dir = self._get_package_install_dir(package_name, version)
        env = self._create_pip_environment_with_path(package_install_dir)

        cmd = [sys.executable, "-m", "pip", "show", package_name]
        result = subprocess.run(cmd, env=env, capture_output=True, text=True)

        if result.returncode != 0:
            return False

        # check if version matches
        version_pattern = f"Version: {version}"
        return version_pattern in result.stdout

    def is_package_ready(self, package_name: str, version: str) -> bool:
        """
        check if a package is ready for use

        Args:
            package_name: package name to check
            version: package version

        Returns:
            bool: True if package is ready, False otherwise
        """
        try:
            # check memory cache first
            if self._is_package_cached_in_memory(package_name, version):
                return True

            # check if package installation directory exists
            if not self._is_package_directory_exists(package_name, version):
                self._set_package_status(package_name, version, PackageStatus.FAILED)
                return False

            # verify package is actually installed in directory
            is_ready = self._verify_package_installation_with_pip(package_name, version)

            # update memory cache and status if ready
            if is_ready:
                self._mark_package_as_installed(package_name, version)
            else:
                self._set_package_status(package_name, version, PackageStatus.FAILED)

            return is_ready

        except Exception:
            self._set_package_status(package_name, version, PackageStatus.FAILED)
            return False

    def _create_package_install_directory(self, package_name: str, version: str) -> bool:
        """
        create installation directory for package

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if directory created successfully, False otherwise
        """
        try:
            package_install_dir = self._get_package_install_dir(package_name, version)
            os.makedirs(package_install_dir, exist_ok=True)
            return True
        except Exception as e:
            logger.error(f"failed to create package install directory: {e}")
            self._set_package_status(package_name, version, PackageStatus.FAILED)
            return False

    def _execute_pip_install_command(self, package_name: str, version: str) -> bool:
        """
        execute pip install command for package

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if installation successful, False otherwise
        """
        package_spec = f"{package_name}=={version}"
        package_install_dir = self._get_package_install_dir(package_name, version)

        # set status to installing
        self._set_package_status(package_name, version, PackageStatus.INSTALLING)

        cmd = [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--target",
            package_install_dir,
            package_spec,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            logger.error(f"package installation failed: {result.stderr}")
            self._set_package_status(package_name, version, PackageStatus.FAILED)
            return False

        return True

    def install_single_package(self, package_name: str, version: str) -> bool:
        """
        install a single package using pip

        Args:
            package_name: package name to install
            version: package version to install

        Returns:
            bool: True if installation successful, False otherwise
        """
        try:
            # check memory cache first
            if self._is_package_cached_in_memory(package_name, version):
                return True

            # check if installation directory already exists
            if self._is_package_directory_exists(package_name, version):
                # verify if package is actually installed correctly
                if self.is_package_ready(package_name, version):
                    self._mark_package_as_installed(package_name, version)
                    return True

            # create installation directory
            if not self._create_package_install_directory(package_name, version):
                return False

            # execute pip install
            if not self._execute_pip_install_command(package_name, version):
                return False

            # mark as installed in memory cache
            self._mark_package_as_installed(package_name, version)
            return True

        except Exception as e:
            logger.error(f"error during package installation: {e}")
            self._set_package_status(package_name, version, PackageStatus.FAILED)
            return False

    def _handle_already_installed_package(self, package_name: str, version: str) -> None:
        """
        handle package that is already installed

        Args:
            package_name: package name
            version: package version
        """
        install_dir = self._get_package_install_dir(package_name, version)
        logger.info(
            f"package {package_name}=={version} installation directory already exists at: {install_dir}"
        )
        self._mark_package_as_installed(package_name, version)

    def _handle_package_installation_needed(self, package_name: str, version: str) -> bool:
        """
        handle package that needs to be installed

        Args:
            package_name: package name
            version: package version

        Returns:
            bool: True if installation successful, False otherwise
        """
        install_dir = self._get_package_install_dir(package_name, version)
        logger.info(
            f"package {package_name}=={version} installation directory not found, installing to: {install_dir}"
        )
        return self.install_single_package(package_name, version)

    def ensure_all_packages_ready(self, packages: dict[str, str]) -> bool:
        """
        ensure all packages are ready by installing them if needed

        Args:
            packages: dict with package names as keys and versions as values

        Returns:
            bool: True if all packages are ready, False otherwise
        """
        if not packages:
            return True

        for package_name, version in packages.items():
            # check if package installation directory exists
            if self._is_package_directory_exists(package_name, version):
                self._handle_already_installed_package(package_name, version)
            elif not self._handle_package_installation_needed(package_name, version):
                return False

        return True

    def get_all_package_status_summary(self) -> dict[str, str]:
        """
        get summary of all package status

        Returns:
            dict: package key to status mapping
        """
        return {key: status.value for key, status in self._package_status.items()}
