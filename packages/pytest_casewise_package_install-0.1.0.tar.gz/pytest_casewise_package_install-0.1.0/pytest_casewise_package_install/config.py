"""
configuration support for pytest-casewise-package-install plugin
"""

import os
from typing import Dict, Optional


class PluginConfig:
    """
    configuration class for plugin behavior
    """

    def __init__(self):
        self.cache_dir: Optional[str] = None
        self.auto_cleanup: bool = True
        self.install_timeout: int = 300  # seconds
        self.verbose: bool = False

    @classmethod
    def from_pytest_config(cls, pytest_config) -> "PluginConfig":
        """
        create plugin config from pytest config

        Args:
            pytest_config: pytest config object

        Returns:
            PluginConfig instance
        """
        config = cls()

        # read from pytest.ini or setup.cfg
        if hasattr(pytest_config, "getini"):
            config.cache_dir = pytest_config.getini("casewise_cache_dir") or None
            auto_cleanup_value = pytest_config.getini("casewise_auto_cleanup")
            if auto_cleanup_value:
                config.auto_cleanup = str(auto_cleanup_value).lower() in ["true", "1", "yes"]

            timeout_value = pytest_config.getini("casewise_install_timeout")
            if timeout_value:
                try:
                    config.install_timeout = int(timeout_value)
                except ValueError:
                    pass

            verbose_value = pytest_config.getini("casewise_verbose")
            if verbose_value:
                config.verbose = str(verbose_value).lower() in ["true", "1", "yes"]

        # override with environment variables if present
        env_cache_dir = os.environ.get("CASEWISE_CACHE_DIR")
        if env_cache_dir:
            config.cache_dir = env_cache_dir

        env_auto_cleanup = os.environ.get("CASEWISE_AUTO_CLEANUP")
        if env_auto_cleanup:
            config.auto_cleanup = env_auto_cleanup.lower() in ["true", "1", "yes"]

        env_timeout = os.environ.get("CASEWISE_INSTALL_TIMEOUT")
        if env_timeout:
            try:
                config.install_timeout = int(env_timeout)
            except ValueError:
                pass

        env_verbose = os.environ.get("CASEWISE_VERBOSE")
        if env_verbose:
            config.verbose = env_verbose.lower() in ["true", "1", "yes"]

        return config

    def get_cache_dir(self) -> str:
        """
        get cache directory path

        Returns:
            cache directory path
        """
        if self.cache_dir:
            return os.path.abspath(os.path.expanduser(self.cache_dir))
        return os.path.join(os.path.expanduser("~"), ".local_package_cache")
