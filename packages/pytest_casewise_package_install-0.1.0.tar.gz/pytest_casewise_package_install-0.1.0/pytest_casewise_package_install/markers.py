"""
markers and decorators for specifying test case dependencies
"""

import functools
from typing import Callable, Dict


def with_packages(packages: Dict[str, str]) -> Callable:
    """
    decorator to specify package requirements for a test case

    Args:
        packages: dict with package names as keys and versions as values

    Usage:
        @with_packages({"numpy": "1.26.4", "pandas": "2.0.0"})
        def test_with_specific_versions():
            import numpy
            assert numpy.__version__ == "1.26.4"

    Alternative usage with pytest marker:
        @pytest.mark.with_packages(packages={"numpy": "1.26.4"})
        def test_with_marker():
            import numpy
            assert numpy.__version__ == "1.26.4"
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        # store package requirements as attribute
        wrapper._required_packages = packages
        return wrapper

    return decorator
