# Installation and Testing Guide

## Quick Installation Test

Follow these steps to install and test the plugin:

### 1. Install the Plugin

```bash
# navigate to project directory
cd /localhome/swqa/workspace/aaa/pytest-casewise-package-install

# install in development mode
pip install -e .
```

### 2. Verify Installation

```bash
# check if plugin is registered
pytest --version
# you should see pytest-casewise-package-install in the plugins list

# or list all plugins
pip list | grep pytest-casewise
```

### 3. Run Unit Tests

```bash
# run all unit tests
pytest tests/ -v

# run with coverage
pytest tests/ --cov=pytest_casewise_package_install --cov-report=term
```

### 4. Run Simple Demo

```bash
# run the simple demo (uses lightweight 'six' package)
cd examples
pytest test_simple_demo.py -v -s
```

Expected output:
```
test_simple_demo.py::test_six_1_16 
? Successfully imported six version: 1.16.0
PASSED

test_simple_demo.py::test_six_1_15 
? Successfully imported six version: 1.15.0
PASSED

test_simple_demo.py::test_without_packages 
? Regular test without package requirements
PASSED

test_simple_demo.py::test_with_marker 
? Using marker: six version 1.16.0
PASSED
```

### 5. Check Package Cache

```bash
# view installed packages in cache
ls -la ~/.local_package_cache/

# you should see directories like:
# six_1_15_0/
# six_1_16_0/
```

### 6. Run All Examples

```bash
cd examples
pytest -v -s

# or use the Makefile
cd ..
make examples
```

### 7. Create Your Own Test

Create a file `my_test.py`:

```python
from pytest_casewise_package_install import with_packages

@with_packages({"six": "1.16.0"})
def test_my_custom_version():
    import six
    print(f"Using six version: {six.__version__}")
    assert six.__version__ == "1.16.0"

@with_packages({"six": "1.15.0"})  
def test_another_version():
    import six
    print(f"Using six version: {six.__version__}")
    assert six.__version__ == "1.15.0"
```

Run it:
```bash
pytest my_test.py -v -s
```

## Troubleshooting

### Issue: Plugin not found

**Solution**: Make sure you installed the package:
```bash
pip install -e .
```

### Issue: Import errors

**Solution**: The plugin modifies PYTHONPATH during test execution. Make sure you're running with pytest, not plain Python:
```bash
# correct
pytest test_file.py

# incorrect (won't work)
python test_file.py
```

### Issue: Package installation fails

**Solution**: 
1. Check your internet connection
2. Try installing the package manually first:
   ```bash
   pip install package_name==version
   ```
3. Check if the package version exists:
   ```bash
   pip index versions package_name
   ```

### Issue: Permission errors

**Solution**: The cache directory needs write permissions:
```bash
# check permissions
ls -la ~/.local_package_cache/

# if needed, fix permissions
chmod -R u+w ~/.local_package_cache/
```

## Development Workflow

### Using Makefile

```bash
# install dev dependencies
make install-dev

# run tests
make test

# run tests with coverage
make test-cov

# run examples
make examples

# format code
make format

# run linting
make lint

# clean build artifacts
make clean

# build distribution
make build
```

### Manual Commands

```bash
# install in dev mode
pip install -e .
pip install -r requirements-dev.txt

# run tests
pytest tests/ -v

# run with coverage
pytest tests/ --cov=pytest_casewise_package_install --cov-report=html

# format code
black pytest_casewise_package_install/ tests/ examples/
isort pytest_casewise_package_install/ tests/ examples/

# lint
flake8 pytest_casewise_package_install/ tests/ examples/

# build
python setup.py sdist bdist_wheel
```

## Next Steps

1. Read the full [README.md](README.md) for detailed documentation
2. Check out [QUICKSTART.md](QUICKSTART.md) for usage examples
3. Review [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) to understand the architecture
4. See [CONTRIBUTING.md](CONTRIBUTING.md) if you want to contribute

## Performance Tips

1. **Cache reuse**: Tests with identical package requirements will reuse cached installations
2. **First run slowness**: Initial package installations take time; subsequent runs are faster
3. **Lightweight packages**: Use lightweight packages like `six` for quick testing
4. **Pre-install**: You can pre-populate the cache by running setup tests

## Cleaning Up

To remove all cached packages:

```bash
rm -rf ~/.local_package_cache/
```

To clean build artifacts:

```bash
make clean
# or manually
rm -rf build/ dist/ *.egg-info .pytest_cache/ __pycache__/
```
