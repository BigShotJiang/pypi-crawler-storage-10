# Project Structure

```
pytest-casewise-package-install/
??? LICENSE                          # MIT license file
??? README.md                        # main documentation (English & Chinese)
??? QUICKSTART.md                    # quick start guide for users
??? CONTRIBUTING.md                  # contribution guidelines
??? PROJECT_STRUCTURE.md             # this file
??? MANIFEST.in                      # package manifest for distribution
??? .gitignore                       # git ignore patterns
??? setup.py                         # setuptools configuration
??? pyproject.toml                   # modern Python project configuration
?
??? pytest_casewise_package_install/ # main package directory
?   ??? __init__.py                  # package initialization, exports public API
?   ??? package_manager.py           # core package management logic
?   ??? plugin.py                    # pytest plugin hooks implementation
?   ??? markers.py                   # decorators and markers for test annotation
?   ??? config.py                    # configuration management
?
??? tests/                           # unit tests
?   ??? test_package_manager.py      # tests for package manager
?   ??? test_plugin.py               # tests for pytest plugin
?   ??? test_markers.py              # tests for markers and decorators
?
??? examples/                        # usage examples
    ??? README.md                    # examples documentation
    ??? pytest.ini                   # example pytest configuration
    ??? test_basic_usage.py          # basic usage examples
    ??? test_advanced_usage.py       # advanced usage examples
```

## Core Components

### `package_manager.py`
- `LocalMultiPackageManager`: Main class for managing package installations
- `PackageStatus`: Enum for tracking package installation status
- Key features:
  - Isolated package installation using `pip install --target`
  - Smart caching to avoid redundant installations
  - Environment variable management (PYTHONPATH)
  - Package version verification

### `plugin.py`
- `PackageInstallPlugin`: Main pytest plugin class
- Pytest hooks:
  - `pytest_configure`: Register custom markers
  - `pytest_runtest_setup`: Setup packages before test
  - `pytest_runtest_teardown`: Cleanup after test
- Key features:
  - Environment backup and restore
  - Package manager lifecycle management
  - Test isolation

### `markers.py`
- `with_packages`: Decorator for specifying package requirements
- Stores package requirements as function attributes
- Works alongside pytest markers

### `config.py`
- `PluginConfig`: Configuration class
- Supports configuration from:
  - pytest.ini / setup.cfg
  - Environment variables
- Configuration options:
  - Cache directory location
  - Auto cleanup behavior
  - Installation timeout
  - Verbose mode

## Usage Patterns

### 1. Decorator Pattern
```python
from pytest_casewise_package_install import with_packages

@with_packages({"requests": "2.31.0"})
def test_example():
    import requests
    assert requests.__version__ == "2.31.0"
```

### 2. Marker Pattern
```python
import pytest

@pytest.mark.with_packages(packages={"requests": "2.31.0"})
def test_example():
    import requests
    assert requests.__version__ == "2.31.0"
```

## Plugin Registration

The plugin is registered via entry points in `setup.py` and `pyproject.toml`:

```python
entry_points={
    "pytest11": [
        "casewise-package-install = pytest_casewise_package_install.plugin",
    ],
}
```

This allows pytest to automatically discover and load the plugin.

## Data Flow

1. **Test Discovery**
   - pytest collects tests
   - Plugin scans for `with_packages` decorator or marker

2. **Setup Phase** (`pytest_runtest_setup`)
   - Extract package requirements
   - Get or create package manager for the package set
   - Backup current environment (PYTHONPATH, sys.path)
   - Install packages if not cached
   - Apply package environment

3. **Test Execution**
   - Test runs with isolated package versions
   - Imports use packages from isolated directories

4. **Teardown Phase** (`pytest_runtest_teardown`)
   - Restore original environment
   - Keep packages cached for future tests

## Cache Structure

Packages are cached in `~/.local_package_cache/` (or custom directory):

```
~/.local_package_cache/
??? requests_2_28_0/          # isolated installation for requests 2.28.0
?   ??? requests/
?   ??? urllib3/
?   ??? ...
??? requests_2_31_0/          # isolated installation for requests 2.31.0
?   ??? requests/
?   ??? urllib3/
?   ??? ...
??? numpy_1_26_4/             # isolated installation for numpy 1.26.4
    ??? numpy/
    ??? ...
```

Each directory contains a complete `pip install --target` installation.

## Development Workflow

1. **Install in development mode**
   ```bash
   pip install -e .
   ```

2. **Run tests**
   ```bash
   pytest tests/ -v
   ```

3. **Run examples**
   ```bash
   cd examples
   pytest -v -s
   ```

4. **Build package**
   ```bash
   python setup.py sdist bdist_wheel
   ```

5. **Install locally**
   ```bash
   pip install dist/pytest_casewise_package_install-0.1.0-py3-none-any.whl
   ```

## Extension Points

To extend the plugin, consider:

1. **Custom package managers**: Subclass `LocalMultiPackageManager`
2. **Additional hooks**: Add more pytest hooks in `plugin.py`
3. **Configuration options**: Extend `PluginConfig`
4. **Package sources**: Support non-PyPI sources
5. **Cleanup strategies**: Implement different cleanup behaviors

## Security Considerations

- Package installations are isolated per version
- Original environment is always restored
- No modification of system-wide packages
- All installations use standard pip
- Cache directory respects user permissions
