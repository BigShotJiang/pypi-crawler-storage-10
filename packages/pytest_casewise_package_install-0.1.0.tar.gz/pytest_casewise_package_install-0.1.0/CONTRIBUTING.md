# Contributing to pytest-casewise-package-install

Thank you for your interest in contributing! This document provides guidelines for contributing to the project.

## Development Setup

1. Fork the repository and clone your fork:
```bash
git clone https://github.com/your-username/pytest-casewise-package-install.git
cd pytest-casewise-package-install
```

2. Install in development mode:
```bash
pip install -e .
```

3. Install development dependencies:
```bash
pip install pytest pytest-cov black isort mypy
```

## Code Style

We follow these style guidelines:

- Use English for all code comments
- Do not capitalize the first letter of comments
- Comments should be lowercase (unless it's a proper noun or acronym)
- No ternary expressions for readability
- Keep code readable - avoid chaining multiple operations in one line
- Follow PEP 8 guidelines

### Formatting

Use `black` for code formatting:
```bash
black pytest_casewise_package_install/ tests/ examples/
```

Use `isort` for import sorting:
```bash
isort pytest_casewise_package_install/ tests/ examples/
```

## Running Tests

Run the test suite:
```bash
pytest tests/ -v
```

Run tests with coverage:
```bash
pytest tests/ --cov=pytest_casewise_package_install --cov-report=html
```

Run the examples:
```bash
cd examples
pytest -v -s
```

## Adding New Features

1. Create a new branch:
```bash
git checkout -b feature/your-feature-name
```

2. Implement your feature with tests

3. Ensure all tests pass:
```bash
pytest tests/
```

4. Update documentation if needed

5. Submit a pull request

## Testing Guidelines

- Write tests for all new features
- Maintain or improve code coverage
- Test both success and failure cases
- Add docstrings to all functions and classes
- Include examples in docstrings when helpful

## Documentation

- Update README.md for user-facing changes
- Update QUICKSTART.md for new features
- Add examples to the `examples/` directory
- Keep docstrings up to date

## Commit Messages

Use clear, descriptive commit messages:
- Use present tense ("add feature" not "added feature")
- Use imperative mood ("move cursor to..." not "moves cursor to...")
- Reference issues and pull requests when relevant

Examples:
```
add support for custom cache directories
fix environment cleanup after test failure
update documentation for marker usage
```

## Pull Request Process

1. Ensure all tests pass
2. Update documentation as needed
3. Add your changes to a new section in README.md if applicable
4. Request review from maintainers

## Bug Reports

When filing a bug report, please include:

- Python version
- pytest version
- Plugin version
- Operating system
- Minimal reproducible example
- Expected behavior
- Actual behavior
- Error messages and tracebacks

## Feature Requests

For feature requests, please describe:

- The problem you're trying to solve
- Your proposed solution
- Alternative solutions you've considered
- Any relevant examples or use cases

## Questions

For questions about usage or development:

- Check existing issues and documentation
- Create a new issue with the "question" label
- Be specific and provide context

## Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on the best outcome for the project
- Be patient with new contributors

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
