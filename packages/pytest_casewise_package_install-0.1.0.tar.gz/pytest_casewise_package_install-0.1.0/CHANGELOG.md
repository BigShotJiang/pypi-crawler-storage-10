# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned Features
- Support for conda packages
- Parallel package installation
- Package cleanup strategies
- Integration with tox
- Support for requirements.txt files
- Fixture-based package management

## [0.1.0] - 2025-10-30

### Added
- Initial release of pytest-casewise-package-install
- Core package manager (`LocalMultiPackageManager`)
  - Isolated package installation using `pip install --target`
  - Smart caching mechanism
  - Environment variable management (PYTHONPATH)
  - Package version verification
- Pytest plugin integration
  - `pytest_configure` hook for marker registration
  - `pytest_runtest_setup` hook for package setup
  - `pytest_runtest_teardown` hook for environment cleanup
- Decorator-based usage (`@with_packages`)
- Pytest marker-based usage (`@pytest.mark.with_packages`)
- Configuration support
  - pytest.ini / setup.cfg configuration
  - Environment variable configuration
  - Configurable cache directory
  - Configurable installation timeout
  - Auto cleanup option
  - Verbose mode
- Comprehensive documentation
  - README with English and Chinese versions
  - Quick start guide
  - Contributing guidelines
  - Project structure documentation
- Example test files
  - Basic usage examples
  - Advanced usage examples
  - Simple demo for quick testing
- Unit tests
  - Package manager tests
  - Plugin tests
  - Marker tests
- Build and development tools
  - setup.py configuration
  - pyproject.toml configuration
  - Makefile for common tasks
  - GitHub Actions CI workflow
  - Development requirements file

### Features
- Test case-level package version management
- Automatic dependency isolation
- Environment backup and restore
- Smart package caching across tests
- Multiple usage patterns (decorator and marker)
- Cross-platform support (Linux, macOS, Windows)
- Python 3.8+ support

### Known Limitations
- Some packages with complex native dependencies may not work with `--target` installation
- Import-time side effects in packages may not be fully isolated
- First test run with new packages can be slower due to installation time

[Unreleased]: https://github.com/yourusername/pytest-casewise-package-install/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/yourusername/pytest-casewise-package-install/releases/tag/v0.1.0
