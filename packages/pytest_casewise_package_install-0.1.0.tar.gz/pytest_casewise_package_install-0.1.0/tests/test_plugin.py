"""
unit tests for pytest plugin
"""

import pytest
from pytest_casewise_package_install.plugin import PackageInstallPlugin
from pytest_casewise_package_install import with_packages


def test_plugin_initialization():
    """test plugin initialization"""
    plugin = PackageInstallPlugin()
    assert plugin.package_managers == {}
    assert plugin.original_pythonpath is None
    assert plugin.original_sys_path == []


def test_create_package_key():
    """test package key creation"""
    plugin = PackageInstallPlugin()

    packages1 = {"numpy": "1.26.4", "pandas": "2.0.0"}
    key1 = plugin._create_package_key(packages1)
    assert key1 == "numpy==1.26.4|pandas==2.0.0"

    packages2 = {"pandas": "2.0.0", "numpy": "1.26.4"}
    key2 = plugin._create_package_key(packages2)
    assert key1 == key2  # should be same regardless of order


def test_get_package_requirements_from_decorator():
    """test extracting package requirements from decorator"""

    @with_packages({"numpy": "1.26.4"})
    def sample_test():
        pass

    plugin = PackageInstallPlugin()

    class MockItem:
        function = sample_test

        def get_closest_marker(self, name):
            return None

    item = MockItem()
    requirements = plugin._get_package_requirements(item)
    assert requirements == {"numpy": "1.26.4"}


def test_get_package_requirements_no_requirements():
    """test when no package requirements are specified"""

    def sample_test():
        pass

    plugin = PackageInstallPlugin()

    class MockItem:
        function = sample_test

        def get_closest_marker(self, name):
            return None

    item = MockItem()
    requirements = plugin._get_package_requirements(item)
    assert requirements is None


def test_backup_and_restore_environment():
    """test environment backup and restore"""
    import os
    import sys

    plugin = PackageInstallPlugin()

    original_path = sys.path.copy()
    original_pythonpath = os.environ.get("PYTHONPATH")

    plugin._backup_environment()
    assert plugin.original_sys_path == original_path

    sys.path.insert(0, "/fake/path")
    os.environ["PYTHONPATH"] = "/fake/pythonpath"

    plugin._restore_environment()
    assert sys.path == original_path

    if original_pythonpath is not None:
        assert os.environ.get("PYTHONPATH") == original_pythonpath
    else:
        assert "PYTHONPATH" not in os.environ or os.environ["PYTHONPATH"] == ""
