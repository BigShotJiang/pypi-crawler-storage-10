"""
unit tests for package manager
"""

import os
import pytest
from pytest_casewise_package_install.package_manager import (
    LocalMultiPackageManager,
    PackageStatus,
)


def test_package_manager_initialization():
    """test package manager initialization"""
    manager = LocalMultiPackageManager(packages={})
    assert manager.managed_packages == {}
    assert manager._installed_packages == set()
    assert manager._current_package_directories == []


def test_sanitize_filesystem_name():
    """test filesystem name sanitization"""
    manager = LocalMultiPackageManager(packages={})

    assert manager._sanitize_filesystem_name("transformers") == "transformers"
    assert manager._sanitize_filesystem_name("4.51.3") == "4_51_3"
    assert manager._sanitize_filesystem_name("my-package@2.0") == "my_package_2_0"
    assert manager._sanitize_filesystem_name("test___package") == "test_package"


def test_get_package_install_dir():
    """test package installation directory path generation"""
    manager = LocalMultiPackageManager(packages={})

    install_dir = manager._get_package_install_dir("numpy", "1.26.4")
    expected_path = os.path.join(manager.manager_base_dir, "numpy_1_26_4")

    assert install_dir == os.path.abspath(expected_path)


def test_get_package_key():
    """test package key generation"""
    manager = LocalMultiPackageManager(packages={})

    key = manager._get_package_key("numpy", "1.26.4")
    assert key == "numpy==1.26.4"


def test_package_status():
    """test package status management"""
    manager = LocalMultiPackageManager(packages={})

    manager._set_package_status("test_pkg", "1.0.0", PackageStatus.INSTALLING)
    status = manager.get_package_status("test_pkg", "1.0.0")
    assert status == PackageStatus.INSTALLING

    manager._set_package_status("test_pkg", "1.0.0", PackageStatus.READY)
    status = manager.get_package_status("test_pkg", "1.0.0")
    assert status == PackageStatus.READY


def test_is_package_cached_in_memory():
    """test memory cache checking"""
    manager = LocalMultiPackageManager(packages={})

    assert not manager._is_package_cached_in_memory("numpy", "1.26.4")

    manager._installed_packages.add("numpy==1.26.4")
    assert manager._is_package_cached_in_memory("numpy", "1.26.4")


def test_get_environment_vars():
    """test environment variables generation"""
    manager = LocalMultiPackageManager(packages={})

    env = manager.get_environment_vars()
    assert isinstance(env, dict)
    assert "PATH" in env  # should contain all original environment variables


def test_mark_package_as_installed():
    """test marking package as installed"""
    manager = LocalMultiPackageManager(packages={})

    manager._mark_package_as_installed("test_pkg", "1.0.0")

    assert "test_pkg==1.0.0" in manager._installed_packages
    assert manager.get_package_status("test_pkg", "1.0.0") == PackageStatus.READY

    install_dir = manager._get_package_install_dir("test_pkg", "1.0.0")
    assert install_dir in manager._current_package_directories


def test_get_all_package_status_summary():
    """test package status summary"""
    manager = LocalMultiPackageManager(packages={})

    manager._set_package_status("pkg1", "1.0.0", PackageStatus.READY)
    manager._set_package_status("pkg2", "2.0.0", PackageStatus.INSTALLING)
    manager._set_package_status("pkg3", "3.0.0", PackageStatus.FAILED)

    summary = manager.get_all_package_status_summary()

    assert summary["pkg1==1.0.0"] == "ready"
    assert summary["pkg2==2.0.0"] == "installing"
    assert summary["pkg3==3.0.0"] == "failed"
