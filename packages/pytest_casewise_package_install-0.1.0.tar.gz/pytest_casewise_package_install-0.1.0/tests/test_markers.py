"""
unit tests for markers and decorators
"""

from pytest_casewise_package_install import with_packages


def test_with_packages_decorator():
    """test with_packages decorator functionality"""

    @with_packages({"numpy": "1.26.4", "pandas": "2.0.0"})
    def sample_function():
        return "test"

    assert hasattr(sample_function, "_required_packages")
    assert sample_function._required_packages == {"numpy": "1.26.4", "pandas": "2.0.0"}
    assert sample_function() == "test"


def test_with_packages_decorator_preserves_function_name():
    """test that decorator preserves function metadata"""

    @with_packages({"numpy": "1.26.4"})
    def my_test_function():
        """my test docstring"""
        pass

    assert my_test_function.__name__ == "my_test_function"
    assert my_test_function.__doc__ == "my test docstring"


def test_with_packages_decorator_empty_dict():
    """test decorator with empty package dict"""

    @with_packages({})
    def sample_function():
        return "test"

    assert hasattr(sample_function, "_required_packages")
    assert sample_function._required_packages == {}
