class CyclicRedundancyCheck:
    r"""
    Cyclic redundancy check (CRC) [Not implemented yet].
    """

    pass
