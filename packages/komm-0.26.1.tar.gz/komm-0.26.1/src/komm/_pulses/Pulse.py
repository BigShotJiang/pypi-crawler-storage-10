from .. import abc


class Pulse(abc.Pulse):
    r"""
    General pulse [Not implemented yet].
    """

    pass
