from .BinarySequence import BinarySequence


class KasamiSequence(BinarySequence):
    r"""
    Kasami sequence [Not implemented yet].
    """

    pass
