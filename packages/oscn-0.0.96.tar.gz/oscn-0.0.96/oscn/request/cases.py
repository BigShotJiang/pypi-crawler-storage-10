import os
import re
import errno
from io import BytesIO
import gzip
import json

from types import FunctionType

import logging
import warnings

import requests
from requests.exceptions import ConnectionError


from .. import settings
from ..parse import append_parsers


oscn_url = settings.OSCN_CASE_URL
warnings.filterwarnings("ignore")
logger = logging.getLogger("oscn")

logger.setLevel(logging.INFO)


# Shared session manager for connection pooling and performance
class SessionManager:
    """Manages a shared requests session for connection pooling."""

    def __init__(self):
        self._session = None

    def get_session(self):
        """Get or create a shared requests session."""
        if self._session is None:
            self._session = requests.Session()
            self._session.headers.update(settings.OSCN_REQUEST_HEADER)
        return self._session

    def close_session(self):
        """Close the shared session and clean up connections."""
        if self._session is not None:
            self._session.close()
            self._session = None


# Module-level instance
_session_manager = SessionManager()


def get_session():
    """Get or create a shared requests session for connection pooling."""
    return _session_manager.get_session()


def close_session():
    """Close the shared session and clean up connections."""
    _session_manager.close_session()


# regex for index parsing

get_court = re.compile(r"^(?P<court>\w+)-")
get_type = re.compile(r"-(?P<type>\w+)-")
get_year = re.compile(r"-(?P<year>\d{4})-")
get_number = re.compile(r"0*(?P<number>\d+\w*)$")


# This decorators adds properties to the OSCNrequest as a shortcut
# for parsing.  This allows access to parse results such as:
# name = Case.judge
# or
# counts = Case.counts
@append_parsers
class Case(object):
    __slots__ = ('county', 'year', 'number', 'type', 'cmid', 'source',
                 'directory', 'text', 'valid', '_oscn_number')

    response = False

    def __init__(
        self,
        index=False,
        type=None,
        county=None,
        year=None,
        number=None,
        cmid=False,
        **kwargs,
    ):

        if index:
            self.county = get_court.match(index).group("court")
            self.number = get_number.search(index).group("number")

            try:
                self.type = get_type.search(index).group("type")
            except AttributeError as exc:
                self.type = None

            try:
                self.year = get_year.search(index).group("year")
            except AttributeError as exc:
                self.year = None

        else:
            self.county = county
            self.year = year
            self.number = number
            self.type = type

        self.cmid = (self.type == "cmid") if self.type else False
        self.source = kwargs.get("source", False)

        # Cache oscn_number early, before any requests
        self._cache_oscn_number()

        if "text" in kwargs:
            self.text = kwargs["text"]
            return
        else:
            self.directory = kwargs.get("directory", "")
            if self.directory:
                self._open_file()
            else:
                # default for test
                self.text = ""
                self._request()

    def _cache_oscn_number(self):
        """Cache the oscn_number to avoid repeated computation."""
        parts = []
        if self.type:
            parts.append(str(self.type))
        if self.year:
            parts.append(str(self.year))
        if self.number:
            parts.append(str(self.number))
        self._oscn_number = "-".join(parts) if parts else ""

    @property
    def oscn_number(self):
        return self._oscn_number

    @property
    def index(self):
        return f"{self.county}-{self.oscn_number}"

    @property
    def inner_path(self):
        path_parts = [self.county] if self.county else []
        if self.type:
            path_parts.append(self.type)
        if self.year:
            path_parts.append(self.year)
        return "/".join(path_parts)

    @property
    def path(self):
        return f"{self.directory}/{self.inner_path}"

    @property
    def file_name(self):
        return f"{self.path}/{self.number}.zip"

    def save(self, **kwargs):
        case_data = {
            "source": self.source,
            "index": self.index,
            "text": self.text,
        }
        file_data = gzip.compress(bytes(json.dumps(case_data), "utf-8"))

        self.directory = kwargs["directory"] if "directory" in kwargs else ""
        if self.directory:
            if not os.path.exists(os.path.dirname(self.file_name)):
                try:
                    os.makedirs(os.path.dirname(self.file_name))
                except OSError as exc:  # Guard against race condition
                    if exc.errno != errno.EEXIST:
                        raise
            with open(self.file_name, "wb") as open_file:
                open_file.write(file_data)

    def _open_file(self):
        try:
            with gzip.GzipFile(self.file_name, "r") as open_file:
                saved_data = json.loads(open_file.read().decode("utf-8"))
                self.__init__(**saved_data)
            self.valid = True
        except FileNotFoundError:
            self.valid = False

    def _valid_response(self, response):
        if not response.ok:
            return False
        for msg in settings.INVALID_CASE_MESSAGES:
            if msg in response.text:
                logger.info("Case %s is invalid", self.oscn_number)
                return False
        return True

    def _request(self, attempts_left=settings.MAX_EMPTY_CASES):
        params = {"db": self.county}
        if self.cmid:
            params["cmid"] = self.number
        else:
            params["number"] = self.oscn_number

        try:
            session = get_session()
            response = session.get(oscn_url, params=params, verify=False)
        except ConnectionError:
            if attempts_left > 0:
                return self._request(attempts_left=attempts_left - 1)
            else:
                raise ConnectionError

        if self._valid_response(response):
            self.valid = True
            self.source = f"{response.url}"
            self.text = response.text
            for msg in settings.UNUSED_CASE_MESSAGES:
                if msg in response.text:
                    self.valid = False
                    return
        else:
            self.valid = False


class CaseList(object):
    def __init__(self, types=[], counties=[], years=[], start=1, stop=20000, **kwargs):

        self.start = start
        self.stop = stop
        self.filters = []

        # allow kwargs to override certain args
        self.types = kwargs["type"] if "type" in kwargs else types
        self.counties = kwargs["county"] if "county" in kwargs else counties
        self.years = kwargs["year"] if "year" in kwargs else years

        # Allow passing a string to list keywords
        # make a str into a single element list otherwise return the value
        str_to_list = lambda val: [val] if type(val) is str else val
        self.types = str_to_list(self.types)
        self.counties = str_to_list(self.counties)
        self.years = str_to_list(self.years)

        # create case request based on storage option
        if "directory" in kwargs:
            self._request_case = self._make_case_requester(
                directory=kwargs["directory"]
            )
        else:
            self._request_case = self._make_case_requester()

        self.all_cases = self._case_generator()

    def _make_case_requester(self, **kwargs):
        def case_request(index=False):
            kwargs["index"] = index
            return Case(**kwargs)

        return case_request

    def _request_generator(self, start, stop):
        case_numbers = range(start, stop + 1)
        for county in self.counties:
            for case_type in self.types:
                for year in self.years:
                    self.exit_year = False
                    for num in case_numbers:
                        case_index = f"{county}-{case_type}-{year}-{num}"
                        yield self._request_case(case_index)
                        if self.exit_year:
                            break

    def _case_generator(self):
        request_attempts = 10
        for case in self._request_generator(self.start, self.stop):
            if case.valid:
                request_attempts = 10
                if case.cmids:
                    for cmid in case.cmids:
                        cmid_index = f"{case.county}-cmid-{case.year}-{cmid}"
                        cmid_case = self._request_case(cmid_index)
                        if cmid_case.valid:
                            if self._passes_filters(cmid_case):
                                yield cmid_case
                elif self._passes_filters(case):
                    yield case
            else:
                if request_attempts > 0:
                    request_attempts -= 1
                else:
                    self.exit_year = True

    def __iter__(self):
        return self

    def __next__(self):
        return next(self.all_cases)

    def _passes_filters(self, case):
        def does_it_pass(filter):
            target, test = filter
            target_value = getattr(case, target)
            if isinstance(test, str):
                return test in target_value
            elif isinstance(test, FunctionType):
                return test(target_value)

        # run the tests
        test_results = map(does_it_pass, self.filters)

        # see if they are all true
        return all(test_results)

    def find(self, **kwargs):
        for kw in kwargs:
            self.filters.append((kw, kwargs[kw]))
        return self
