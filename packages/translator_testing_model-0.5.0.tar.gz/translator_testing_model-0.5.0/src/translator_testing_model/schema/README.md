# Translator Testing Model

[YAML file specified LinkML-based model for Translator Testing](translator_testing_model.yaml).
