# Translator Testing Model Specification

* [schema](src/translator_testing_model/schema/translator_testing_model.yaml) -- LinkML schema
(edit this)
* [datamodel](src/translator_testing_model/datamodel/README.md) -- generated
Python datamodels