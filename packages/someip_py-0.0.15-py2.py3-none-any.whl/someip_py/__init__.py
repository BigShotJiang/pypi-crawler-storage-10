from someip_py.interface import SOMEIPService

__version__ = "0.0.15"

__all__ = ["SOMEIPService"]
