import uuid
from abc import ABC, abstractmethod

from taskiq_dashboard.domain.dto.task import ExecutedTask, QueuedTask, StartedTask, Task
from taskiq_dashboard.domain.dto.task_status import TaskStatus


class TaskService(ABC):
    @abstractmethod
    async def get_tasks(  # noqa: PLR0913
        self,
        page: int = 1,
        per_page: int = 30,
        status: TaskStatus | None = None,
        name_search: str | None = None,
        sort_by: str | None = None,
        sort_order: str = 'desc',
    ) -> tuple[list[Task], int]:
        """
        Retrieve tasks with pagination and filtering.

        Args:
            page: The page number (1-indexed)
            per_page: Number of tasks per page
            status: Filter by task status
            name_search: Filter by task name (fuzzy search)
            sort_by: Column to sort by ('started_at' or 'finished_at')
            sort_order: Sort order ('asc' or 'desc')

        Returns:
            Tuple of (tasks, total_count)
        """
        ...

    @abstractmethod
    async def get_task_by_id(self, task_id: uuid.UUID) -> Task | None:
        """Retrieve a specific task by ID."""
        ...

    @abstractmethod
    async def create_task(
        self,
        task_id: uuid.UUID,
        task_arguments: QueuedTask,
    ) -> None: ...

    @abstractmethod
    async def update_task(
        self,
        task_id: uuid.UUID,
        task_arguments: StartedTask | ExecutedTask,
    ) -> None: ...
