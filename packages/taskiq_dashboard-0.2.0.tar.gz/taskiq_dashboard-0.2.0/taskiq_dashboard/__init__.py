from taskiq_dashboard.interface.application import TaskiqDashboard


__all__ = ['TaskiqDashboard']
