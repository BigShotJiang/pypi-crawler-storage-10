from __future__ import annotations
from typing import Iterator

from chromakitx import ColorType

from inkline.token import TokenType
from inkline.tokenizer import Tokenizer
from inkline.renderer import AnsiRenderer

class AsciiArt:
    def __init__(self, text: str, colors: list[ColorType], bold: bool = False) -> None:
        self._raw_text: str = text
        self._colors: list[ColorType] = colors
        self._bold: bool = bold
        self._renderer: AnsiRenderer = AnsiRenderer()

        self._lines: list[str] = self._preprocess_lines(text)
        self._start: int
        self._end: int
        self._start, self._end = self._calculate_boundaries(self._lines)

    @staticmethod
    def _preprocess_lines(text: str) -> list[str]:
        lines: list[str] = [line for line in text.splitlines() if line.strip()]

        while lines and Tokenizer(lines[-1]).has_no_solid_tokens():
            lines.pop()

        return lines

    @staticmethod
    def _calculate_boundaries(lines: list[str]) -> tuple[int, int]:
        if not lines:
            return 0, 0

        start: float = float("inf")
        end: int = 0

        for line in lines:
            tokenizer: Tokenizer = Tokenizer(line)

            line_start: int = tokenizer.leading_spaces()
            line_end:   int = tokenizer.true_length()

            start: int = min(start, line_start)
            end:   int = max(end, line_end)

        if start == float("inf"):
            return 0, 0

        return int(start), int(end)

    def render_line(self, line: str) -> str:
        tokenizer: Tokenizer = Tokenizer(line)
        output: list[str] = []

        current_color: ColorType | None = None
        current_segment: list[str] = []

        for tok in tokenizer.truncate(self._start, self._end):
            if tok.type == TokenType.COLOR:
                if current_segment:
                    segment_text: str = "".join(current_segment)
                    styled:       str = self._renderer.render_segment(segment_text, current_color, self._bold)

                    output.append(styled)
                    current_segment.clear()

                color_idx: int = int(tok.value or 0)
                current_color = self._colors[color_idx] if color_idx < len(self._colors) else None
            elif tok.type in (TokenType.CHAR, TokenType.SPACE):
                current_segment.append(tok.value or ' ')

        if current_segment:
            segment_text: str = "".join(current_segment)
            styled:       str = self._renderer.render_segment(segment_text, current_color, self._bold)

            output.append(styled)

        return "".join(output)

    def __iter__(self) -> Iterator[str]:
        for line in self._lines:
            yield self.render_line(line)

    def render(self) -> str:
        return "\n".join(self)

    @property
    def width(self) -> int:
        return self._end - self._start

    @property
    def height(self) -> int:
        return len(self._lines)

    @property
    def lines(self) -> list[str]:
        return self._lines.copy()

    @property
    def colors(self) -> list[ColorType]:
        return self._colors.copy()

    @property
    def bold(self) -> bool:
        return self._bold

    def set_colors(self, colors: list[ColorType]) -> None:
        self._colors = colors

    def set_bold(self, bold: bool) -> None:
        self._bold = bold
