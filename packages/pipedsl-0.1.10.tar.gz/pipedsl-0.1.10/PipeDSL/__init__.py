from .services.generate_task import YamlTaskReaderService
from .services.task_scheduler import TaskScheduler


YamlTaskReader = YamlTaskReaderService