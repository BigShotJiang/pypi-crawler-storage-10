# numpyi

## Installation

```bash
pip install numpyi
```
