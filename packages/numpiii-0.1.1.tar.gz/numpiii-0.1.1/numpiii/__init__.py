"""
numpyi — A collection of DWM (Data Warehousing & Mining) code scripts.

This package only provides Python source files for educational and
offline use. After installation, you can find them in:
    <python_install_dir>/Lib/site-packages/numpyi/
"""
__version__ = "0.1.0"
