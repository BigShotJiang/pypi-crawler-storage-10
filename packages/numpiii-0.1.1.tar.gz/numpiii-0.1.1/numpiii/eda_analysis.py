# Step 1: Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Settings
sns.set(style='whitegrid')
plt.rcParams['figure.figsize'] = (10, 6)

# Step 2: Load Dataset
# Replace path with your local CSV path if needed
df = pd.read_csv('insurance.csv')

# Step 3: Data Overview
print("First 5 rows:\n", df.head(), "\n")
print("Data Info:\n")
print(df.info())
print("\nMissing Values:\n", df.isnull().sum())
print("\nStatistical Description:\n", df.describe())

# Step 4: Data Cleaning
## Check missing values
print("\nChecking Missing Values...")
print(df.isnull().sum())

## (This dataset has no missing values, but if it did:)
# df.fillna(df.mean(), inplace=True)

# Outlier Removal with Z-score (for numeric columns)
numeric_cols = ['age', 'bmi', 'children', 'charges']
z_scores = np.abs(stats.zscore(df[numeric_cols]))
df = df[(z_scores < 3).all(axis=1)]

print("\nAfter removing outliers, shape:", df.shape)

# Step 5: Data Discretization
## Binning 'age' into 3 bins by mean (equal-width)
df['age_binned_mean'] = pd.cut(df['age'], bins=3, labels=['Young', 'Middle-aged', 'Old'])

## Binning 'bmi' using boundaries
bmi_bins = [0, 18.5, 25, 30, 100]
bmi_labels = ['Underweight', 'Normal', 'Overweight', 'Obese']
df['bmi_binned_boundary'] = pd.cut(df['bmi'], bins=bmi_bins, labels=bmi_labels)

# Step 6: Normalization
## Min-Max Normalization
df['charges_minmax'] = (df['charges'] - df['charges'].min()) / (df['charges'].max() - df['charges'].min())

## Z-score Normalization
df['charges_zscore'] = (df['charges'] - df['charges'].mean()) / df['charges'].std()

## Decimal Scaling
j = len(str(int(df['charges'].abs().max())))
df['charges_decimal'] = df['charges'] / (10 ** j)

# Step 7: Statistical Summary
print("\nData Types:\n", df.dtypes)
print("\nRange of Numeric Columns:\n", df[numeric_cols].max() - df[numeric_cols].min())
print("\nQuantiles:\n", df[numeric_cols].quantile([0.25, 0.5, 0.75]))

# Step 8: Visualizations

## 8.1 Histogram of Age
plt.hist(df['age'], bins=10, color='skyblue', edgecolor='black')
plt.title('Histogram of Age')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()

## 8.2 Boxplot of Charges
sns.boxplot(y=df['charges'], color='lightgreen')
plt.title('Boxplot of Charges')
plt.ylabel('Charges')
plt.show()

## 8.3 Bar Chart - Count of Age Bins
df['age_binned_mean'].value_counts().plot(kind='bar', color='salmon')
plt.title('Age Bins (Mean) - Bar Chart')
plt.xlabel('Age Bin')
plt.ylabel('Count')
plt.show()

## 8.4 Line Chart - Charges
plt.plot(df['charges'].values, color='purple')
plt.title('Line Chart of Charges')
plt.xlabel('Index')
plt.ylabel('Charges')
plt.show()

## 8.5 Scatter Plot - BMI vs Charges
plt.scatter(df['bmi'], df['charges'], alpha=0.5, color='orange')
plt.title('Scatter Plot: BMI vs Charges')
plt.xlabel('BMI')
plt.ylabel('Charges')
plt.show()

## 8.6 Pie Chart - Smoker Distribution
df['smoker'].value_counts().plot.pie(autopct='%1.1f%%', colors=['lightcoral', 'lightskyblue'])
plt.title('Smoker Distribution')
plt.ylabel('')
plt.show()

## 8.7 Heatmap - Correlation Matrix
corr_matrix = df[numeric_cols].corr()
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()

print("\nEDA Completed Successfully ✅")