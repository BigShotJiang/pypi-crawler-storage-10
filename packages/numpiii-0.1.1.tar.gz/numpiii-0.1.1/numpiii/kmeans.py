import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random

def kmeans(data, k, max_iters=100):
    centers = random.sample(list(data), k)
    
    for _ in range(max_iters):
        labels = []
        for point in data:
            distances = [abs(point - c) for c in centers]
            labels.append(np.argmin(distances))
        
        new_centers = []
        for i in range(k):
            cluster_points = [data[j] for j in range(len(data)) if labels[j] == i]
            if cluster_points:
                new_centers.append(sum(cluster_points) / len(cluster_points))
            else:
                new_centers.append(random.choice(data))
        
        if np.allclose(new_centers, centers):
            break
        centers = new_centers
    
    return labels, centers


if __name__ == "__main__":
    filename = "insurance.csv"
    df = pd.read_csv(filename)

    # Choose numeric column
    column_name = "charges"  # change as needed
    data = df[column_name].dropna().values.astype(float)
    k = 3  # number of clusters

    # Run K-Means
    labels, centers = kmeans(data, k)
    centers = [round(c, 2) for c in centers]

    # --------------------------
    # Cluster Summary Table
    # --------------------------
    print(f"\nK-Means Clustering on '{column_name}' (k={k})\n")
    header = f"{'Cluster':<8} {'Center':<12} {'Count':<8} {'Min':<12} {'Max':<12} {'Mean':<12}"
    print(header)
    print("-" * len(header))

    for i in range(k):
        cluster_points = [data[j] for j in range(len(data)) if labels[j] == i]
        if cluster_points:
            print(f"{i:<8} {centers[i]:<12.2f} {len(cluster_points):<8} "
                  f"{min(cluster_points):<12.2f} {max(cluster_points):<12.2f} "
                  f"{np.mean(cluster_points):<12.2f}")
        else:
            print(f"{i:<8} {centers[i]:<12.2f} {0:<8} {'-':<12} {'-':<12} {'-':<12}")

    # --------------------------
    # Plot
    # --------------------------
    plt.scatter(data, np.zeros_like(data), c=labels, cmap='viridis', s=60)
    plt.scatter(centers, np.zeros_like(centers), c='red', marker='X', s=200, label='Centers')
    plt.xlabel(column_name)
    plt.title(f"1D K-Means Clustering on {column_name}")
    plt.legend()
    plt.show()
