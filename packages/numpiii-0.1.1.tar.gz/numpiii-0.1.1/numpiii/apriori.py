import csv
from itertools import combinations
from collections import Counter
import math

# --------------------------
# Helper: convert continuous values into bins
# --------------------------
def bin_value(value, bin_size):
    return int(math.floor(float(value) / bin_size)) * bin_size

# --------------------------
# Step 1: Read & Preprocess Data
# --------------------------
filename = "insurance.csv"
transactions = []

with open(filename, newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            # Bucket numeric values into ranges
            age_bin = f"age_{bin_value(float(row['age']), 10)}s"
            bmi_bin = f"bmi_{bin_value(float(row['bmi']), 5)}s"
            child = f"children_{row['children']}"
            smoker = f"smoker_{row['smoker']}"
            region = f"region_{row['region']}"
            sex = f"sex_{row['sex']}"
            # Charges bucketed by 10000
            charges_bin = f"charges_{bin_value(float(row['charges']), 10000)}s"

            transaction = {age_bin, bmi_bin, child, smoker, region, sex, charges_bin}
            transactions.append(transaction)
        except ValueError:
            continue

print(f"✅ Loaded {len(transactions)} transactions from insurance.csv")

# --------------------------
# Step 2: Support Calculation
# --------------------------
def get_support(transactions, itemset):
    count = 0
    for transaction in transactions:
        if itemset.issubset(transaction):
            count += 1
    return count / len(transactions)

# --------------------------
# Step 3: Apriori Algorithm
# --------------------------
def apriori(transactions, min_support):
    item_counter = Counter()
    for transaction in transactions:
        for item in transaction:
            item_counter[frozenset([item])] += 1

    num_transactions = len(transactions)
    frequent_itemsets = [item for item in item_counter if (item_counter[item] / num_transactions) >= min_support]
    all_frequent = frequent_itemsets.copy()
    k = 2

    while True:
        candidates = set()
        for i in range(len(frequent_itemsets)):
            for j in range(i + 1, len(frequent_itemsets)):
                union_set = frequent_itemsets[i].union(frequent_itemsets[j])
                if len(union_set) == k:
                    subsets = combinations(union_set, k - 1)
                    if all(frozenset(s) in all_frequent for s in subsets):
                        candidates.add(union_set)

        if not candidates:
            break

        new_frequent = []
        for candidate in candidates:
            support = get_support(transactions, candidate)
            if support >= min_support:
                new_frequent.append(candidate)

        if not new_frequent:
            break

        all_frequent.extend(new_frequent)
        frequent_itemsets = new_frequent
        k += 1

    return all_frequent

# --------------------------
# Step 4: Rule Generation
# --------------------------
def generate_rules(transactions, frequent_itemsets, min_confidence):
    rules = []
    for itemset in frequent_itemsets:
        if len(itemset) < 2:
            continue

        for i in range(1, len(itemset)):
            for antecedent_tuple in combinations(itemset, i):
                antecedent = set(antecedent_tuple)
                consequent = itemset - antecedent

                if not consequent:
                    continue

                support_itemset = get_support(transactions, itemset)
                support_antecedent = get_support(transactions, antecedent)

                if support_antecedent > 0:
                    confidence = support_itemset / support_antecedent
                    if confidence >= min_confidence:
                        rules.append({
                            'antecedent': antecedent,
                            'consequent': consequent,
                            'support': support_itemset,
                            'confidence': confidence
                        })
    return rules

# --------------------------
# Step 5: Pretty Printing
# --------------------------
def print_itemsets(itemsets, min_support):
    print(f"\nFrequent Itemsets (min_support >= {min_support}):")
    print("-" * 60)
    for itemset in itemsets:
        print(f"{', '.join(sorted(itemset))}")

def print_rules(rules, min_confidence):
    print(f"\nAssociation Rules (min_confidence >= {min_confidence}):")
    print("-" * 80)
    print(f"{'Rule':<50} {'Support':<10} {'Confidence':<10}")
    print("-" * 80)
    for rule in rules:
        rule_str = f"{', '.join(rule['antecedent'])} -> {', '.join(rule['consequent'])}"
        print(f"{rule_str:<50} {rule['support']:.3f}     {rule['confidence']:.3f}")

# --------------------------
# Step 6: Run Apriori on insurance.csv
# --------------------------
min_support = 0.05
min_confidence = 0.6

print("\n🔹 Running Apriori on insurance.csv...")
frequent = apriori(transactions, min_support)
print_itemsets(frequent, min_support)

rules = generate_rules(transactions, frequent, min_confidence)
print_rules(rules, min_confidence)
