import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("insurance.csv")

# Create binary target variable
median_charge = df['charges'].median()
df['high_charge'] = (df['charges'] > median_charge).astype(int)

sns.set(style="whitegrid")

# 1. Smoker vs High Charges
plt.figure(figsize=(6,4))
sns.countplot(data=df, x="smoker", hue="high_charge", palette="Set2")
plt.title("Smoker vs High Charges")
plt.xlabel("Smoker")
plt.ylabel("Count")
plt.legend(title="High Charge")
plt.show()

# 2. BMI distribution by High Charges
plt.figure(figsize=(6,4))
sns.kdeplot(
    data=df,
    x="bmi",
    hue=df['high_charge'].astype(str),  # ensure hue is treated as category
    fill=True,
    palette="Set1",
    alpha=0.5
)
plt.title("BMI Distribution by High Charges")
plt.xlabel("BMI")
plt.ylabel("Density")
plt.show()

# 3. Age distribution by High Charges
plt.figure(figsize=(6,4))
sns.kdeplot(
    data=df,
    x="age",
    hue=df['high_charge'].astype(str),
    fill=True,
    palette="Set1",
    alpha=0.5
)
plt.title("Age Distribution by High Charges")
plt.xlabel("Age")
plt.ylabel("Density")
plt.show()

# 4. Region vs High Charges
plt.figure(figsize=(7,4))
sns.countplot(data=df, x="region", hue="high_charge", palette="Set2")
plt.title("Region vs High Charges")
plt.xlabel("Region")
plt.ylabel("Count")
plt.legend(title="High Charge")
plt.show()
