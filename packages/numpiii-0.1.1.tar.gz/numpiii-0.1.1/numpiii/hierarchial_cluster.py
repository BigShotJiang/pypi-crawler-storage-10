import csv
import math
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram

filename = "insurance.csv"

data = []
labels = []

# Load only numeric columns
with open(filename, newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            age = float(row["age"])
            bmi = float(row["bmi"])
            children = float(row["children"])
            charges = float(row["charges"])
            data.append([age, bmi, children, charges])
            labels.append(row.get("region", "Person"))  # optional label
        except ValueError:
            continue

# Optional: limit to first 40 records for visualization clarity
data = data[:40]
labels = labels[:40]

# ---------- Normalization ----------
def mean(values):
    return sum(values) / len(values)

def std(values):
    m = mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / len(values))

columns = list(zip(*data))
normalized = []

for row in data:
    norm_row = []
    for i, val in enumerate(row):
        m = mean(columns[i])
        s = std(columns[i])
        norm_val = (val - m) / s if s != 0 else 0
        norm_row.append(norm_val)
    normalized.append(norm_row)

# ---------- Distance Functions ----------
def euclidean_distance(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(len(a))))

def pairwise_distances(X):
    n = len(X)
    dist_matrix = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                dist_matrix[i][j] = float('inf')
            else:
                dist_matrix[i][j] = euclidean_distance(X[i], X[j])
    return dist_matrix

# ---------- Single Linkage Implementation ----------
def single_linkage_manual(X):
    n = len(X)
    distances = pairwise_distances(X)
    clusters = {i: [i] for i in range(n)}
    cluster_ids = list(clusters.keys())
    merge_history = []
    next_id = n

    while len(clusters) > 1:
        min_dist = float('inf')
        i_idx, j_idx = -1, -1
        for i in range(len(distances)):
            for j in range(len(distances[i])):
                if distances[i][j] < min_dist:
                    min_dist = distances[i][j]
                    i_idx, j_idx = i, j

        ci, cj = cluster_ids[i_idx], cluster_ids[j_idx]
        merge_history.append([ci, cj, min_dist, len(clusters[ci]) + len(clusters[cj])])
        clusters[next_id] = clusters[ci] + clusters[cj]
        del clusters[ci]
        del clusters[cj]
        cluster_ids = [c for k, c in enumerate(cluster_ids) if k not in (i_idx, j_idx)] + [next_id]

        new_row = []
        for k in range(len(distances)):
            if k not in (i_idx, j_idx):
                new_dist = min(distances[i_idx][k], distances[j_idx][k])
                new_row.append(new_dist)

        new_distances = []
        for k in range(len(distances)):
            if k not in (i_idx, j_idx):
                row = [distances[k][m] for m in range(len(distances)) if m not in (i_idx, j_idx)]
                new_distances.append(row)

        for r in new_distances:
            r.append(new_row[new_distances.index(r)])
        new_row.append(float('inf'))
        new_distances.append(new_row)

        distances = new_distances
        next_id += 1

    return [[float(x) for x in row] for row in merge_history]

# ---------- Dendrogram Plot ----------
def plot_dendrogram(merge_history, labels):
    plt.figure(figsize=(12, 7))
    dendrogram(merge_history, labels=labels, leaf_rotation=90)
    plt.title("Single Linkage Dendrogram (Insurance Data)")
    plt.xlabel("Individuals (by region)")
    plt.ylabel("Euclidean Distance")
    plt.tight_layout()
    plt.show()

merge_history = single_linkage_manual(normalized)
plot_dendrogram(merge_history, labels)
