__version__ = '0.44.0.5'
__commit_hash__ = '4a5d4e997abd9d1bab030e52cf69d1a6b3afd0a3'
findlibs_dependencies = ["eckitlib"]
