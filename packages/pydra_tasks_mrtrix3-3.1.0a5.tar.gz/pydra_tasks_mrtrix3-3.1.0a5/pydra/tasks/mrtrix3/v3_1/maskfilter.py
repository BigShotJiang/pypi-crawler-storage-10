# Auto-generated from MRtrix C++ command with '__print_pydra_code__' secret option

import typing as ty
from pathlib import Path  # noqa: F401
from fileformats.generic import File, Directory  # noqa: F401
from fileformats.vendor.mrtrix3.medimage import ImageIn, ImageOut, Tracks  # noqa: F401
from pydra.compose import shell
from pydra.utils.typing import MultiInputObj


@shell.define
class MaskFilter(shell.Task["MaskFilter.Outputs"]):
    """Many filters have their own unique set of optional parameters; see the option groups dedicated to each filter type.


        References
        ----------

            Tournier, J.-D.; Smith, R. E.; Raffelt, D.; Tabbara, R.; Dhollander, T.; Pietsch, M.; Christiaens, D.; Jeurissen, B.; Yeh, C.-H. & Connelly, A. MRtrix3: A fast, flexible and open software framework for medical image processing and visualisation. NeuroImage, 2019, 202, 116137


        MRtrix
        ------

        Version:3.0.4-1402-gd28b95cd, built Aug 22 2025

        Author: Robert E. Smith (robert.smith@florey.edu.au) and David Raffelt (david.raffelt@florey.edu.au) and Thijs Dhollander (thijs.dhollander@gmail.com) and J-Donald Tournier (jdtournier@gmail.com)

        Copyright: Copyright (c) 2008-2025 the MRtrix3 contributors.

    This Source Code Form is subject to the terms of the Mozilla Public
    License, v. 2.0. If a copy of the MPL was not distributed with this
    file, You can obtain one at http://mozilla.org/MPL/2.0/.

    Covered Software is provided under this License on an "as is"
    basis, without warranty of any kind, either expressed, implied, or
    statutory, including, without limitation, warranties that the
    Covered Software is free of defects, merchantable, fit for a
    particular purpose or non-infringing.
    See the Mozilla Public License v. 2.0 for more details.

    For more details, see http://www.mrtrix.org/.
    """

    executable = "maskfilter"

    # Arguments
    in_file: ImageIn = shell.arg(
        argstr="",
        position=1,
        help="""the input mask.""",
    )
    filter: str = shell.arg(
        argstr="",
        position=2,
        help="""the name of the filter to be applied; options are: clean, connect, dilate, erode, fill, median""",
        allowed_values=["clean", "connect", "dilate", "erode", "fill", "median"],
    )

    # Options

    # Options for mask cleaning filter:
    scale: int | None = shell.arg(
        default=None,
        argstr="-scale",
        help="""the maximum scale used to cut bridges. A certain maximum scale cuts bridges up to a width (in voxels) of 2x the provided scale. (Default: 2)""",
    )

    # Options for connected-component filter:
    axes: list[int] | None = shell.arg(
        default=None,
        argstr="-axes",
        help="""specify which axes should be included in the connected components. By default only the first 3 axes are included. The axes should be provided as a comma-separated list of values.""",
        sep=",",
    )
    largest: bool = shell.arg(
        default=False,
        argstr="-largest",
        help="""only retain the largest connected component""",
    )
    connectivity: bool = shell.arg(
        default=False,
        argstr="-connectivity",
        help="""use 26-voxel-neighbourhood connectivity (Default is 6-voxel-neighbourhood)""",
    )
    minsize: int | None = shell.arg(
        default=None,
        argstr="-minsize",
        help="""impose minimum size of segmented components (Default: select all components)""",
    )

    # Options for dilate / erode filters:
    npass: int | None = shell.arg(
        default=None,
        argstr="-npass",
        help="""the number of times to repeatedly apply the filter""",
    )

    # Options for interior-filling filter:
    axes: list[int] | None = shell.arg(
        default=None,
        argstr="-axes",
        help="""specify which axes should be included in the connected components. By default only the first 3 axes are included. The axes should be provided as a comma-separated list of values.""",
        sep=",",
    )
    connectivity: bool = shell.arg(
        default=False,
        argstr="-connectivity",
        help="""use 26-voxel-neighbourhood connectivity (Default is 6-voxel-neighbourhood)""",
    )

    # Options for median filter:
    extent: list[int] | None = shell.arg(
        default=None,
        argstr="-extent",
        help="""specify the extent (width) of kernel size in voxels. This can be specified either as a single value to be used for all axes, or as a comma-separated list of the extent for each axis. The default is 3x3x3.""",
        sep=",",
    )

    # Stride options:
    strides: ty.Any = shell.arg(
        default=None,
        argstr="-strides",
        help="""specify the strides of the output data in memory; either as a comma-separated list of (signed) integers, or as a template image from which the strides shall be extracted and used. The actual strides produced will depend on whether the output image format can support it.""",
    )

    # Standard options
    info: bool = shell.arg(
        default=False,
        argstr="-info",
        help="""display information messages.""",
    )
    quiet: bool = shell.arg(
        default=False,
        argstr="-quiet",
        help="""do not display information messages or progress status; alternatively, this can be achieved by setting the MRTRIX_QUIET environment variable to a non-empty string.""",
    )
    debug: bool = shell.arg(
        default=False,
        argstr="-debug",
        help="""display debugging messages.""",
    )
    force: bool = shell.arg(
        default=False,
        argstr="-force",
        help="""force overwrite of output files (caution: using the same file as input and output might cause unexpected behaviour).""",
    )
    nthreads: int | None = shell.arg(
        default=None,
        argstr="-nthreads",
        help="""use this number of threads in multi-threaded applications (set to 0 to disable multi-threading).""",
    )
    config: MultiInputObj[tuple[str, str]] | None = shell.arg(
        default=None,
        argstr="-config",
        help="""temporarily set the value of an MRtrix config file entry.""",
        sep=" ",
    )

    class Outputs(shell.Outputs):
        out_file: ImageOut = shell.outarg(
            argstr="",
            position=3,
            path_template="out_file.mif",
            help="""the output mask.""",
        )
