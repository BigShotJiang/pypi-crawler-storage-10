# speech-to-text-selenium

This small project demonstrates driving a local speech-to-text demo (`index.html`) using Selenium.

Quick start

1. Create a virtual environment and install dependencies:

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Run locally (this will open Chrome and click the Start button):

```powershell
python .\main.py
# or if you installed the package: speech-listen
```

Notes

- Chrome must be able to access your microphone. Running headless will typically block access to a real microphone. The script uses `--use-fake-ui-for-media-stream` to auto-allow the permission prompt.
- For CI and headless runs, use fake audio with `--use-file-for-fake-audio-capture` and `--use-fake-device-for-media-stream`.
