"""speech_to_text package

Expose a simple `main()` entry point that launches the Selenium-based
listener from the project root.
"""

__all__ = ["main"]
