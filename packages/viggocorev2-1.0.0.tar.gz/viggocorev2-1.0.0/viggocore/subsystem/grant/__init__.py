from viggocore.common import subsystem
from viggocore.subsystem.grant import resource, manager

subsystem = subsystem.Subsystem(
    resource=resource.Grant,
    manager=manager.Manager
)
