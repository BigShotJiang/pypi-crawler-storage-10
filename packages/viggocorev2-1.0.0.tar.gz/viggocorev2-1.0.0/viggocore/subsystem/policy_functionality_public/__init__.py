from viggocore.common import subsystem
from viggocore.subsystem.policy_functionality_public \
    import manager, resource, controller, router

subsystem = subsystem.Subsystem(resource=resource.PolicyFunctionalityPublic,
                                controller=controller.Controller,
                                manager=manager.Manager,
                                router=router.Router)


