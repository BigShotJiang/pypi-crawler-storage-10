// Shim for extensions/core/load3d/AnimationManager.ts
export const AnimationManager = window.comfyAPI.AnimationManager.AnimationManager;
