// Shim for extensions/core/load3d/ViewHelperManager.ts
export const ViewHelperManager = window.comfyAPI.ViewHelperManager.ViewHelperManager;
