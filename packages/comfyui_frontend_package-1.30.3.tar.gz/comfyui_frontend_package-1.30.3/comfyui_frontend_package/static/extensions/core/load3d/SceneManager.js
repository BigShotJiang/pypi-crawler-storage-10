// Shim for extensions/core/load3d/SceneManager.ts
export const SceneManager = window.comfyAPI.SceneManager.SceneManager;
