# def test_import():
#    from nrtk_explorer.app import main  # noqa: F401
