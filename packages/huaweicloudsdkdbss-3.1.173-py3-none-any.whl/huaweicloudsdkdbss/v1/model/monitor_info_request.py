# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MonitorInfoRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'time': 'Duration'
    }

    attribute_map = {
        'time': 'time'
    }

    def __init__(self, time=None):
        r"""MonitorInfoRequest

        The model defined in huaweicloud sdk

        :param time: 
        :type time: :class:`huaweicloudsdkdbss.v1.Duration`
        """
        
        

        self._time = None
        self.discriminator = None

        self.time = time

    @property
    def time(self):
        r"""Gets the time of this MonitorInfoRequest.

        :return: The time of this MonitorInfoRequest.
        :rtype: :class:`huaweicloudsdkdbss.v1.Duration`
        """
        return self._time

    @time.setter
    def time(self, time):
        r"""Sets the time of this MonitorInfoRequest.

        :param time: The time of this MonitorInfoRequest.
        :type time: :class:`huaweicloudsdkdbss.v1.Duration`
        """
        self._time = time

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MonitorInfoRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
