# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AuditScopeSwitchRequestNew:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ids': 'list[str]',
        'status': 'str'
    }

    attribute_map = {
        'ids': 'ids',
        'status': 'status'
    }

    def __init__(self, ids=None, status=None):
        r"""AuditScopeSwitchRequestNew

        The model defined in huaweicloud sdk

        :param ids: 审计范围ID列表
        :type ids: list[str]
        :param status: 状态  - OFF： 关闭  - ON： 启用
        :type status: str
        """
        
        

        self._ids = None
        self._status = None
        self.discriminator = None

        self.ids = ids
        self.status = status

    @property
    def ids(self):
        r"""Gets the ids of this AuditScopeSwitchRequestNew.

        审计范围ID列表

        :return: The ids of this AuditScopeSwitchRequestNew.
        :rtype: list[str]
        """
        return self._ids

    @ids.setter
    def ids(self, ids):
        r"""Sets the ids of this AuditScopeSwitchRequestNew.

        审计范围ID列表

        :param ids: The ids of this AuditScopeSwitchRequestNew.
        :type ids: list[str]
        """
        self._ids = ids

    @property
    def status(self):
        r"""Gets the status of this AuditScopeSwitchRequestNew.

        状态  - OFF： 关闭  - ON： 启用

        :return: The status of this AuditScopeSwitchRequestNew.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this AuditScopeSwitchRequestNew.

        状态  - OFF： 关闭  - ON： 启用

        :param status: The status of this AuditScopeSwitchRequestNew.
        :type status: str
        """
        self._status = status

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AuditScopeSwitchRequestNew):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
