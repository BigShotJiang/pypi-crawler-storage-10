# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SecurityGroupRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'securitygroup_ids': 'list[str]'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'securitygroup_ids': 'securitygroup_ids'
    }

    def __init__(self, instance_id=None, securitygroup_ids=None):
        r"""SecurityGroupRequest

        The model defined in huaweicloud sdk

        :param instance_id: **参数解释**： 实例ID。可通过查询实例列表接口ID字段获取 **约束限制**： 不涉及 **取值范围**： 以查询实例列表接口值为准，字符长度32-64。 **默认取值**： 不涉及 
        :type instance_id: str
        :param securitygroup_ids: 安全组ID列表(目前只支持传一个ID)
        :type securitygroup_ids: list[str]
        """
        
        

        self._instance_id = None
        self._securitygroup_ids = None
        self.discriminator = None

        self.instance_id = instance_id
        self.securitygroup_ids = securitygroup_ids

    @property
    def instance_id(self):
        r"""Gets the instance_id of this SecurityGroupRequest.

        **参数解释**： 实例ID。可通过查询实例列表接口ID字段获取 **约束限制**： 不涉及 **取值范围**： 以查询实例列表接口值为准，字符长度32-64。 **默认取值**： 不涉及 

        :return: The instance_id of this SecurityGroupRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this SecurityGroupRequest.

        **参数解释**： 实例ID。可通过查询实例列表接口ID字段获取 **约束限制**： 不涉及 **取值范围**： 以查询实例列表接口值为准，字符长度32-64。 **默认取值**： 不涉及 

        :param instance_id: The instance_id of this SecurityGroupRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def securitygroup_ids(self):
        r"""Gets the securitygroup_ids of this SecurityGroupRequest.

        安全组ID列表(目前只支持传一个ID)

        :return: The securitygroup_ids of this SecurityGroupRequest.
        :rtype: list[str]
        """
        return self._securitygroup_ids

    @securitygroup_ids.setter
    def securitygroup_ids(self, securitygroup_ids):
        r"""Sets the securitygroup_ids of this SecurityGroupRequest.

        安全组ID列表(目前只支持传一个ID)

        :param securitygroup_ids: The securitygroup_ids of this SecurityGroupRequest.
        :type securitygroup_ids: list[str]
        """
        self._securitygroup_ids = securitygroup_ids

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SecurityGroupRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
