from typing_extensions import override
from typing import Optional, List

from xgae.engine.engine_base import XGAToolSchema
from xgae.engine.prompt_builder import XGAPromptBuilder

class XGAArePromptBuilder(XGAPromptBuilder):
    def __init__(self, system_prompt: Optional[str] = None):
        super().__init__(system_prompt)


    @override
    def build_general_tool_prompt(self, tool_schemas: List[XGAToolSchema]) -> str:
        tool_prompt = self.build_mcp_tool_prompt("templates/general_tool_prompt_template.txt", tool_schemas)
        return tool_prompt




