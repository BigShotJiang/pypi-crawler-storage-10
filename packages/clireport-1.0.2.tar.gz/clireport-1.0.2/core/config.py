# core/config.py
import os
from typing import List

class Config:
    """Configuration class for the report bot"""
    
    # Telegram API credentials (REQUIRED)
    API_ID: int = int(os.getenv("API_ID", 12176206))  # Replace with your API ID
    API_HASH: str = os.getenv("API_HASH", "b8eff20a7e8adcdaa3daa3bc789a5b41")  # Replace with your API Hash
    
    # Admin IDs (REQUIRED)
    ADMIN_IDS: List[int] = [5053851121]
    
    # Report limits
    MAX_REPORTS_PER_REQUEST: int = int(os.getenv("MAX_REPORTS_PER_REQUEST", "10"))
    DELAY_BETWEEN_REPORTS: int = int(os.getenv("DELAY_BETWEEN_REPORTS", "2"))
    
    # Session settings
    SESSION_NAME: str = os.getenv("SESSION_NAME", "report_bot")
    
    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Security
    MAX_COMMENT_LENGTH: int = 200
    REQUEST_TIMEOUT: int = 30
    
    # Bot behavior
    AUTO_RESTART: bool = os.getenv("AUTO_RESTART", "false").lower() == "true"