"""Public API for the hopeit_agents model client plugin."""
