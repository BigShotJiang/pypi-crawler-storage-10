"""hopeit endpoints for the `hopeit_agents.model_client` plugin."""
