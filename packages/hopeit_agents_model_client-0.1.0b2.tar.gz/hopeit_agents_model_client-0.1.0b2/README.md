# hopeit_agents Model Client

Library for connecting to LLM models and optionally exposing a test endpoint for direct LLM calls during development.

Check details at [hopeit.agents README](https://github.com/hopeit-git/hopeit.agents/blob/master/README.md).
