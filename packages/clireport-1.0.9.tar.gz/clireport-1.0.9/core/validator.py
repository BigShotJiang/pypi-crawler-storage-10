
from typing import Tuple, Optional
from core.models import ReportReason
from utils.helpers import validate_t_me_link

class Validator:
    @staticmethod
    def validate_entity(entity: str) -> bool:
        return validate_t_me_link(entity)

    @staticmethod
    def validate_message_id(message_id: Optional[int]) -> bool:
        if message_id is None:
            return True
        try:
            return int(message_id) > 0
        except Exception:
            return False

    @staticmethod
    def parse_reason(reason_str: str) -> Tuple[bool, Optional[ReportReason]]:
        if not reason_str:
            return False, None
        norm = reason_str.strip().lower()
        mapping = {
            "spam": ReportReason.SPAM,
            "violence": ReportReason.VIOLENCE,
            "porn": ReportReason.PORNOGRAPHY,
            "pornography": ReportReason.PORNOGRAPHY,
            "child": ReportReason.CHILD_ABUSE,
            "child_abuse": ReportReason.CHILD_ABUSE,
            "drugs": ReportReason.ILLEGAL_DRUGS,
            "illegal_drugs": ReportReason.ILLEGAL_DRUGS,
            "personal": ReportReason.PERSONAL_DETAILS,
            "personal_details": ReportReason.PERSONAL_DETAILS,
            "illegal": ReportReason.ILLEGAL,
            "other": ReportReason.OTHER,
        }
        return (mapping.get(norm) is not None, mapping.get(norm))
