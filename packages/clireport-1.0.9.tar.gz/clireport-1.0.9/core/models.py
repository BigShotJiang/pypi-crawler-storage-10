
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from typing import Optional

class ReportReason(str, Enum):
    SPAM = "spam"
    VIOLENCE = "violence"
    PORNOGRAPHY = "pornography"
    CHILD_ABUSE = "child_abuse"
    ILLEGAL_DRUGS = "illegal_drugs"
    PERSONAL_DETAILS = "personal_details"
    ILLEGAL = "illegal"
    OTHER = "other"

@dataclass
class ReportRequest:
    target: str                         # @username | t.me/username | t.me/c/<id>/<msg>
    message_id: Optional[int] = None    # optional: if None, report peer
    reason: ReportReason = ReportReason.SPAM
    comment: str = ""
    report_count: int = 1               # number of attempts

@dataclass
class ReportResult:
    successful: int
    failed: int
    target: str
    reason: ReportReason
    comment: str
    message_id: Optional[int]
    start_time: datetime
    end_time: datetime
