
import asyncio
import logging
from typing import Tuple
from pyrogram import Client
from pyrogram.errors import FloodWait, PeerIdInvalid, ChannelInvalid, UserNotParticipant, ChatAdminRequired, RPCError
from pyrogram.raw import functions
from .models import ReportRequest
from data.constants import REASON_MAPPING
from .config import Config

logger = logging.getLogger(__name__)

class ReportExecutor:
    def __init__(self, client: Client):
        self.client = client

    async def _report_message(self, req: ReportRequest) -> bool:
        peer = await self.client.resolve_peer(req.target)
        try:
            await self.client.invoke(
                functions.messages.Report(
                    peer=peer,
                    id=[req.message_id],
                    reason=REASON_MAPPING[req.reason],
                    message=req.comment or ""
                )
            )
            return True
        except FloodWait as e:
            logger.warning(f"FloodWait {e.value}s")
            await asyncio.sleep(int(e.value))
            return False
        except (PeerIdInvalid, ChannelInvalid, UserNotParticipant, ChatAdminRequired) as e:
            logger.error(f"Report failed: {type(e).__name__}")
            return False
        except RPCError as e:
            logger.error(f"RPCError: {e}")
            return False
        except Exception:
            logger.exception("Unexpected error")
            return False

    async def _report_peer(self, req: ReportRequest) -> bool:
        peer = await self.client.resolve_peer(req.target)
        try:
            await self.client.invoke(
                functions.account.ReportPeer(
                    peer=peer,
                    reason=REASON_MAPPING[req.reason],
                    message=req.comment or ""
                )
            )
            return True
        except FloodWait as e:
            logger.warning(f"FloodWait {e.value}s")
            await asyncio.sleep(int(e.value))
            return False
        except (PeerIdInvalid, ChannelInvalid, UserNotParticipant, ChatAdminRequired) as e:
            logger.error(f"Report failed: {type(e).__name__}")
            return False
        except RPCError as e:
            logger.error(f"RPCError: {e}")
            return False
        except Exception:
            logger.exception("Unexpected error")
            return False

    async def run(self, req: ReportRequest) -> Tuple[int, int]:
        ok, fail = 0, 0
        for i in range(max(1, int(req.report_count))):
            success = await (self._report_message(req) if req.message_id else self._report_peer(req))
            if success:
                ok += 1
            else:
                fail += 1
            await asyncio.sleep(Config.DELAY_BETWEEN_REPORTS)
        return ok, fail
