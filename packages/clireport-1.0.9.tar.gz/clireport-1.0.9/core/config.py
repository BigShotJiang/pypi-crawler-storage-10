
import os
from typing import List

class Config:
    API_ID: int = 17221354
    API_HASH: str = "b86bbf4b700b4e922fff2c05b3b8985f"
    SESSION_NAME: str = "report_bot"
    # comma-separated list of admin user ids
    ADMIN_IDS: List[int] = [5053851121]

    MAX_REPORTS_PER_REQUEST: int = int(os.environ.get("MAX_REPORTS_PER_REQUEST", "10"))
    DELAY_BETWEEN_REPORTS: int = int(os.environ.get("DELAY_BETWEEN_REPORTS", "2"))
    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    MAX_COMMENT_LENGTH: int = int(os.environ.get("MAX_COMMENT_LENGTH", "200"))
    REQUEST_TIMEOUT: int = int(os.environ.get("REQUEST_TIMEOUT", "30"))
    AUTO_RESTART: bool = os.environ.get("AUTO_RESTART", "false").lower() == "true"

    @classmethod
    def validate(cls) -> None:
        if cls.API_ID == 0 or not cls.API_HASH:
            raise RuntimeError("API_ID/API_HASH not set in environment. See .env.example")
