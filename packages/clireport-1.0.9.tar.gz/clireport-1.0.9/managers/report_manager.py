
from datetime import datetime
from typing import Optional
from core.models import ReportReason
from data.constants import REASON_PERSIAN

class ReportManager:
    @staticmethod
    def get_persian_name(reason: ReportReason) -> str:
        return REASON_PERSIAN.get(reason, str(reason))

    @staticmethod
    def format_duration(start: datetime, end: datetime) -> str:
        from CliReport.utils.helpers import human_duration
        return human_duration(end - start)
