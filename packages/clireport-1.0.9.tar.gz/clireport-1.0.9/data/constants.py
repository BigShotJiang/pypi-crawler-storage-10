
from pyrogram.raw import types
from core.models import ReportReason

REASON_MAPPING = {
    ReportReason.SPAM: types.InputReportReasonSpam(),
    ReportReason.VIOLENCE: types.InputReportReasonViolence(),
    ReportReason.PORNOGRAPHY: types.InputReportReasonPornography(),
    ReportReason.CHILD_ABUSE: types.InputReportReasonChildAbuse(),
    ReportReason.ILLEGAL_DRUGS: types.InputReportReasonIllegalDrugs(),
    ReportReason.PERSONAL_DETAILS: types.InputReportReasonPersonalDetails(),
    ReportReason.ILLEGAL: types.InputReportReasonOther(),  # فیکس
    ReportReason.OTHER: types.InputReportReasonOther(),
}

REASON_PERSIAN = {
    ReportReason.SPAM: "اسپم",
    ReportReason.VIOLENCE: "خشونت",
    ReportReason.PORNOGRAPHY: "پورنوگرافی",
    ReportReason.CHILD_ABUSE: "کودک‌آزاری",
    ReportReason.ILLEGAL_DRUGS: "مواد غیرقانونی",
    ReportReason.PERSONAL_DETAILS: "افشای اطلاعات شخصی",
    ReportReason.ILLEGAL: "غیرقانونی/سایر",
    ReportReason.OTHER: "سایر",
}
