
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from core.models import ReportRequest, ReportResult
from core.validator import Validator
from core.config import Config
from core.executor import ReportExecutor
from utils.helpers import smart_split, truncate_text, format_entity
from managers.response_builder import ResponseBuilder

def build_help() -> str:
    return (
        "دستور گزارش:\n"
        "`/report <entity> [message_id] <reason> [comment...] [--count N]`\n\n"
        "نمونه‌ها:\n"
        "`/report @badchannel spam تبلیغات مکرر --count 3` (گزارش خود کانال)\n"
        "`/report t.me/c/123/456 spam پیام اسپم` (گزارش پیام با آی‌دی مشخص)\n"
        "reason: spam | violence | pornography | child_abuse | illegal_drugs | personal_details | illegal | other"
    )

# handlers/report_handler.py

from utils.helpers import smart_split, truncate_text, parse_entity_and_message_id
# اگر پکیجت namespaced نیست، مسیر ایمپورت را مطابق پروژهٔ خودت تنظیم کن

def parse_args(text: str) -> ReportRequest | None:
    parts = smart_split(text)
    if not parts or not parts[0].startswith("/report"):
        return None

    parts = parts[1:]
    if not parts:
        return None

    entity_norm, msg_from_link = parse_entity_and_message_id(parts[0])

    message_id = msg_from_link
    reason_str = None
    comment_parts = []
    count = 1
    idx = 1

    # اگر message_id از لینک استخراج نشده و آرگومان بعدی عدد بود
    if message_id is None and len(parts) > 1 and parts[1].isdigit():
        message_id = int(parts[1])
        idx = 2

    if len(parts) > idx:
        reason_str = parts[idx]
        idx += 1
    else:
        return None

    while idx < len(parts):
        if parts[idx] == "--count" and idx + 1 < len(parts) and parts[idx+1].isdigit():
            count = int(parts[idx+1]); idx += 2
        else:
            comment_parts.append(parts[idx]); idx += 1

    ok_reason, reason = Validator.parse_reason(reason_str)
    if not Validator.validate_entity(entity_norm) or not ok_reason or not Validator.validate_message_id(message_id):
        return None

    comment = truncate_text(" ".join(comment_parts).strip(), Config.MAX_COMMENT_LENGTH)

    return ReportRequest(
        target=entity_norm,
        message_id=message_id,
        reason=reason,
        comment=comment,
        report_count=count,
    )

def register_handlers(app: Client) -> None:
    @app.on_message(filters.command("start"))
    async def start_handler(client: Client, message: Message):
        await message.reply_text("سلام! برای گزارش از دستور زیر استفاده کن:\n\n" + build_help())

    @app.on_message(filters.command("help"))
    async def help_handler(client: Client, message: Message):
        await message.reply_text(build_help())

    @app.on_message(filters.command("report"))
    async def report_handler(client: Client, message: Message):
        req = parse_args(message.text or "")
        if req is None:
            await message.reply_text("❗ ورودی نامعتبر.\n\n" + build_help())
            return
        processing = await message.reply_text("⏳ در حال ارسال گزارش…")

        start = datetime.now()
        executor = ReportExecutor(client)
        ok, fail = await executor.run(req)
        end = datetime.now()

        result = ReportResult(
            successful=ok,
            failed=fail,
            target=req.target,
            reason=req.reason,
            comment=req.comment or "",
            message_id=req.message_id,
            start_time=start,
            end_time=end,
        )
        await processing.edit_text(ResponseBuilder.build_summary_text(result))
