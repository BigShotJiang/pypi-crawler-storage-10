# Copyright 2025 qBraid
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Module providing Quantum Fourier Transform (QFT) algorithm implementation.

Functions
----------

.. autosummary::
    :toctree: ../stubs/

    load_program
    generate_subroutine
    QFTLibrary

"""

from .qft import generate_subroutine, load_program
from .qft_lib import QFTLibrary

__all__ = [
    "load_program",
    "generate_subroutine",
    "QFTLibrary"
]
