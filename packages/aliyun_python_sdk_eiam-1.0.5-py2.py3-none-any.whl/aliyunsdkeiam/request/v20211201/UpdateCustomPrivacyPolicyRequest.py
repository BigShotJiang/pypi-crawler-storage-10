# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest

class UpdateCustomPrivacyPolicyRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'Eiam', '2021-12-01', 'UpdateCustomPrivacyPolicy','eiam')
		self.set_protocol_type('https')
		self.set_method('POST')

	def get_DefaultLanguageCode(self): # String
		return self.get_query_params().get('DefaultLanguageCode')

	def set_DefaultLanguageCode(self, DefaultLanguageCode):  # String
		self.add_query_param('DefaultLanguageCode', DefaultLanguageCode)
	def get_UserConsentType(self): # String
		return self.get_query_params().get('UserConsentType')

	def set_UserConsentType(self, UserConsentType):  # String
		self.add_query_param('UserConsentType', UserConsentType)
	def get_CustomPrivacyPolicyContents(self): # Array
		return self.get_query_params().get('CustomPrivacyPolicyContents')

	def set_CustomPrivacyPolicyContents(self, CustomPrivacyPolicyContents):  # Array
		for index1, value1 in enumerate(CustomPrivacyPolicyContents):
			if value1.get('CustomPrivacyPolicyTip') is not None:
				self.add_query_param('CustomPrivacyPolicyContents.' + str(index1 + 1) + '.CustomPrivacyPolicyTip', value1.get('CustomPrivacyPolicyTip'))
			if value1.get('LanguageCode') is not None:
				self.add_query_param('CustomPrivacyPolicyContents.' + str(index1 + 1) + '.LanguageCode', value1.get('LanguageCode'))
			if value1.get('CustomPrivacyPolicyItems') is not None:
				for index2, value2 in enumerate(value1.get('CustomPrivacyPolicyItems')):
					if value2.get('CustomPrivacyPolicyItemUrl') is not None:
						self.add_query_param('CustomPrivacyPolicyContents.' + str(index1 + 1) + '.CustomPrivacyPolicyItems.' + str(index2 + 1) + '.CustomPrivacyPolicyItemUrl', value2.get('CustomPrivacyPolicyItemUrl'))
					if value2.get('CustomPrivacyPolicyItemName') is not None:
						self.add_query_param('CustomPrivacyPolicyContents.' + str(index1 + 1) + '.CustomPrivacyPolicyItems.' + str(index2 + 1) + '.CustomPrivacyPolicyItemName', value2.get('CustomPrivacyPolicyItemName'))
	def get_CustomPrivacyPolicyId(self): # String
		return self.get_query_params().get('CustomPrivacyPolicyId')

	def set_CustomPrivacyPolicyId(self, CustomPrivacyPolicyId):  # String
		self.add_query_param('CustomPrivacyPolicyId', CustomPrivacyPolicyId)
	def get_InstanceId(self): # String
		return self.get_query_params().get('InstanceId')

	def set_InstanceId(self, InstanceId):  # String
		self.add_query_param('InstanceId', InstanceId)
	def get_CustomPrivacyPolicyName(self): # String
		return self.get_query_params().get('CustomPrivacyPolicyName')

	def set_CustomPrivacyPolicyName(self, CustomPrivacyPolicyName):  # String
		self.add_query_param('CustomPrivacyPolicyName', CustomPrivacyPolicyName)
