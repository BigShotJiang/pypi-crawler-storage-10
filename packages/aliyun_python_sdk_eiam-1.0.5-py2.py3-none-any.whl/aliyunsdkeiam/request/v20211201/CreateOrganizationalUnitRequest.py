# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest

class CreateOrganizationalUnitRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'Eiam', '2021-12-01', 'CreateOrganizationalUnit','eiam')
		self.set_protocol_type('https')
		self.set_method('POST')

	def get_OrganizationalUnitExternalId(self): # String
		return self.get_query_params().get('OrganizationalUnitExternalId')

	def set_OrganizationalUnitExternalId(self, OrganizationalUnitExternalId):  # String
		self.add_query_param('OrganizationalUnitExternalId', OrganizationalUnitExternalId)
	def get_Description(self): # String
		return self.get_query_params().get('Description')

	def set_Description(self, Description):  # String
		self.add_query_param('Description', Description)
	def get_ParentId(self): # String
		return self.get_query_params().get('ParentId')

	def set_ParentId(self, ParentId):  # String
		self.add_query_param('ParentId', ParentId)
	def get_OrganizationalUnitName(self): # String
		return self.get_query_params().get('OrganizationalUnitName')

	def set_OrganizationalUnitName(self, OrganizationalUnitName):  # String
		self.add_query_param('OrganizationalUnitName', OrganizationalUnitName)
	def get_InstanceId(self): # String
		return self.get_query_params().get('InstanceId')

	def set_InstanceId(self, InstanceId):  # String
		self.add_query_param('InstanceId', InstanceId)
