version = '1.5.3'
repo = 'https://github.com/makodevai/gpuq'
commit = 'b37b4b6e4d1b58f0af2cddd6a366a9387286c4ca (+2 untracked)'
has_repo = True
