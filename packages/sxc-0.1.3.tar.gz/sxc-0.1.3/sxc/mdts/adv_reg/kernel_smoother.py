import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from scipy.stats import norm

# Kernel Regression Function
def kernel_smoother(train, test, target="target",
                     kernel=["gaussian", "uniform", "triangular", "epanechnikov"],
                     n_repeats=50):
    """
Kernel Smoother: Documentation

This function performs kernel smoothing regression over selected kernels
and bandwidth values, evaluates training and test performance repeatedly,
and visualizes the resulting fits.

---------------------------------------------------------------------------
Parameters
---------------------------------------------------------------------------
train : pandas.DataFrame
    Training dataset with columns:
        • "feature" (predictor)
        • "target"  (response)

test : pandas.DataFrame
    Testing dataset with the same structure as train.

target : str, default = "target"
    Target column name.

kernel : list of str
    Names of kernels to apply. Supported options:
        • "gaussian"
        • "uniform"
        • "epanechnikov"
        • "triangular"
        • "biweight"
        • "triweight"
        • "tricube"

n_repeats : int, default = 50
    Number of repeated evaluations for stable error estimates.

---------------------------------------------------------------------------
Returns
---------------------------------------------------------------------------
pandas.DataFrame
    A summary of average training and testing errors for each kernel-bandwidth
    combination.

---------------------------------------------------------------------------
Example Usage
---------------------------------------------------------------------------
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sxc import mdts

np.random.seed(1234)

def reg(x):
    return 5*np.sin(x) + 23*(np.cos(x))**2

x = np.random.uniform(5, 15, (100, 1))
y = reg(x) + np.random.normal(0, 5, (100, 1))

data = pd.DataFrame({"feature": x.flatten(), "target": y.flatten()})
train, test = train_test_split(data, test_size=0.2, random_state=42)

results = mdts.kernel_smoother(
    train=train,
    test=test,
    target="target",
    kernel=["gaussian","uniform","triangular",
            "epanechnikov","biweight","triweight","tricube"],
    n_repeats=50
)

print(results)
"""

    X_train = train["feature"].values
    y_train = train[target].values
    X_test = test["feature"].values
    y_test = test[target].values

    # Bandwidth values (h or σ)
    bandwidths = [0.1, 0.25, 0.5, 1, 2]
    def gaussian_kernel(u): return (1/np.sqrt(2*np.pi)) * np.exp(-u**2 / 2)
    def uniform_kernel(u): return np.where(np.abs(u) <= 1, 1/2, 0)
    def epanechnikov_kernel(u): return np.where(np.abs(u) <= 1, 3/4 * (1 - u**2), 0)
    def triangular_kernel(u): return np.where(np.abs(u) < 1, (35/32) * (1 - u**2)**3, 0)
    def biweight_kernel(u): return np.where(np.abs(u) <= 1, 15/16 * (1 - u**2)**2, 0)
    def triweight_kernel(u): return np.where(np.abs(u) <= 1, 35/32 * (1 - u**2)**3, 0)
    def tricube_kernel(u): return np.where(np.abs(u) <= 1, 70/81 * (1 - np.abs(u)**3)**3, 0)


    kernels = {
    "gaussian": gaussian_kernel,
    "uniform": uniform_kernel,
    "epanechnikov": epanechnikov_kernel,
    "triangular": triangular_kernel,
    "biweight": biweight_kernel,
    "triweight": triweight_kernel,
    "tricube": tricube_kernel
    }
    results = []

    # Compute Regression for Each Kernel
    for k_name in kernel:
        K = kernels[k_name]
        print(f"\nProcessing Kernel: {k_name.upper()}")

        for h in bandwidths:
            train_errors = []
            test_errors = []

            for _ in range(n_repeats):
                # Predict on train and test
                def kernel_regression(x_query, X, Y, h):
                    weights = K((x_query - X[:, None]) / h)
                    numer = np.dot(weights.T, Y)
                    denom = np.sum(weights, axis=0)
                    denom = np.where(denom == 0, 1e-8, denom) 
                    return numer / denom

                y_pred_train = kernel_regression(X_train, X_train, y_train, h)
                y_pred_test = kernel_regression(X_test, X_train, y_train, h)

                train_mse = mean_squared_error(y_train, y_pred_train)
                test_mse = mean_squared_error(y_test, y_pred_test)

                train_errors.append(train_mse)
                test_errors.append(test_mse)

            avg_train_err = np.mean(train_errors)
            avg_test_err = np.mean(test_errors)
            results.append({
                "Kernel": k_name,
                "h": h,
                "Avg Train error": avg_train_err,
                "Avg Test error": avg_test_err
            })

    Res_df = pd.DataFrame(results)

    # Plot Average Train/Test MSE vs h
    for k_name in kernel:
        df_k = Res_df[Res_df["Kernel"] == k_name]
        plt.figure(figsize=(8, 5))
        plt.plot(df_k["h"], df_k["Avg Train error"], label="Avg Train error", marker="o")
        plt.plot(df_k["h"], df_k["Avg Test error"], label="Avg Test error", marker="s")
        plt.xlabel("Bandwidth (h)", fontsize=14)
        plt.ylabel("Average MSE", fontsize=14)
        plt.title(f"{k_name.capitalize()} Kernel: Train vs Test Error", fontsize=16)
        plt.legend()
        plt.grid(True)
        plt.show()

        # Plot Scatter + Smoothed Line
        plt.figure(figsize=(8, 5))
        plt.scatter(X_train, y_train, color="blue", alpha=0.6, label="Train Data")
        plt.scatter(X_test, y_test, color="orange", alpha=0.6, label="Test Data")

        x_grid = np.linspace(min(X_train), max(X_train), 200)
        y_smooth = []

        best_h = df_k.loc[df_k["Avg Test error"].idxmin(), "h"]
        for xq in x_grid:
            weights = K((xq - X_train) / best_h)
            y_hat = np.sum(weights * y_train) / np.sum(weights)
            y_smooth.append(y_hat)

        plt.plot(x_grid, y_smooth, color="blue", linewidth=1,
                 label=f"Smoothed ({k_name}, h={best_h})")
        plt.xlabel("Feature", fontsize=14)
        plt.ylabel("Target", fontsize=14)
        plt.title(f"{k_name.capitalize()} Kernel Regression Fit", fontsize=16)
        plt.legend()
        plt.grid(True)
        plt.show()

    return Res_df