import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error

def knn_smoother(train, test, target="target", regression=None, 
                 k_values=[1, 2, 5, 10, 20, 40, 80], n_repeats=50):
    """
    Perform repeated KNN smoothing estimation for a univariate nonparametric regression model.

    Parameters
    ----------
    train : pandas.DataFrame
        Training dataset (covariate in first column, response in 'target').
    test : pandas.DataFrame
        Test dataset with same structure as train.
    target : str, optional
        Name of the response variable column. Default is "target".
    regression : callable, optional
        True regression function f(x), used for visualization.
    k_values : list of int, optional
        List of k values for KNN smoothing. Default is [1, 2, 5, 10, 20, 40, 80].
    n_repeats : int, optional
        Number of random splits for averaging errors. Default is 50.
    Example
    -------
    >>> import numpy as np
    >>> import pandas as pd
    >>> from sklearn.model_selection import train_test_split
    >>> from sxc import mdts
    >>> 
    >>> # Define true regression function
    >>> def reg(x):
    ...     return 5 * np.sin(x) + 23 * (np.cos(x))**2
    >>> 
    >>> # Generate synthetic data
    >>> np.random.seed(1234)
    >>> x = np.random.uniform(5, 15, (100, 1))
    >>> y = reg(x) + np.random.normal(0, 5, (100, 1))
    >>> 
    >>> data = pd.DataFrame({
    ...     "feature": x.flatten(),
    ...     "target": y.flatten()
    ... })
    >>> 
    >>> # 80:20 split
    >>> train, test = train_test_split(data, test_size=0.2, random_state=42)
    >>> 
    >>> # Run smoother
    >>> results = mdts.knn_smoother(
    ...     train, test, target="target", regression=reg,
    ...     k_values=[1, 2, 5, 10, 20], n_repeats=50
    ... )
    >>> print(results)
    k   Avg Train MSE   Avg Test MSE
    1       5.8732          9.2241
    2       6.1821         10.0125
    ...

    """
    # Combine train + test to allow random splits
    data = pd.concat([train, test], ignore_index=True)
    x = data.iloc[:, 0].values
    y = data[target].values

    results = []

    for k in k_values:
        train_errors = []
        test_errors = []

        for _ in range(n_repeats):
            idx = np.random.permutation(len(x))
            train_idx, test_idx = idx[:80], idx[80:]
            X_train, X_test = x[train_idx].reshape(-1, 1), x[test_idx].reshape(-1, 1)
            y_train, y_test = y[train_idx], y[test_idx]

            knn = KNeighborsRegressor(n_neighbors=k)
            knn.fit(X_train, y_train)

            y_train_pred = knn.predict(X_train)
            y_test_pred = knn.predict(X_test)

            train_errors.append(mean_squared_error(y_train, y_train_pred))
            test_errors.append(mean_squared_error(y_test, y_test_pred))

        mean_train = np.mean(train_errors)
        mean_test = np.mean(test_errors)

        results.append((k, mean_train, mean_test))
        print(f"k = {k:3d} | Avg Train MSE = {mean_train:.4f} | Avg Test MSE = {mean_test:.4f}")

    df_results = pd.DataFrame(results, columns=["k", "Avg Train MSE", "Avg Test MSE"])

    # Visualization
    plt.figure(figsize=(8,5))
    plt.plot(df_results["k"], df_results["Avg Train MSE"], marker='o', label="Train Error")
    plt.plot(df_results["k"], df_results["Avg Test MSE"], marker='s', label="Test Error")
    plt.xlabel("Number of Neighbors (k)")
    plt.ylabel("Mean Squared Error")
    plt.title(f"KNN Smoother over {n_repeats} Random Splits")
    plt.legend()
    plt.grid(True)
    plt.show()

    return df_results