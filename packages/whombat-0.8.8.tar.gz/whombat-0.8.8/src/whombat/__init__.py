"""Top-level package for Whombat."""

__author__ = """Santiago Martinez Balvanera"""
__email__ = "santiago.balvanera.20@ucl.ac.uk"
__version__ = "0.8.8"
