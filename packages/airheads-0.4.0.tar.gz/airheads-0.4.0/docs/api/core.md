# Core API Reference

::: airheads.build_social_head

::: airheads.build_seo_meta

::: airheads.build_open_graph

::: airheads.build_twitter_card

::: airheads.build_favicon_links

::: airheads.build_json_ld
