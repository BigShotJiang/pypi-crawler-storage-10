# Schema API Reference

## Overview

Schema.org helpers create JSON-LD structured data for rich search results. These functions generate properly formatted JSON without requiring detailed knowledge of schema.org specifications.

## Functions

::: airheads.schema.build_article_schema

::: airheads.schema.build_product_schema

::: airheads.schema.build_person_schema

::: airheads.schema.build_organization_schema

::: airheads.schema.build_website_schema

::: airheads.schema.build_breadcrumb_schema

::: airheads.schema.build_faq_schema

::: airheads.schema.build_howto_schema

::: airheads.schema.build_video_schema
