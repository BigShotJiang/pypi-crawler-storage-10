"""Entry point for running mcp_server as a module."""

import time
from datetime import datetime

# Record import start time
_script_start_time = time.time()
_script_start_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# Print initial startup time (before logging is configured)
print(f"[{_script_start_time_str}] 🚀 Starting MCP Server...")
print(f"[{_script_start_time_str}] 📦 Importing main module...")

# Record time before import
_import_before_time = time.time()
from .main import main
# Record time after import
_import_after_time = time.time()
_import_duration = (_import_after_time - _import_before_time) * 1000  # milliseconds

_import_end_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
print(f"[{_import_end_time_str}] ✅ Main module imported (took {_import_duration:.2f} ms)")

if __name__ == "__main__":
    # Record time before main() call
    _main_before_time = time.time()
    _main_start_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    _total_startup_time = (_main_before_time - _script_start_time) * 1000
    
    print(f"[{_main_start_time_str}] 🎯 Calling main() function (total startup time: {_total_startup_time:.2f} ms)")
    
    try:
        main()
    finally:
        # Record time after main() (if it returns)
        _main_after_time = time.time()
        _main_duration = (_main_after_time - _main_before_time) * 1000
        _main_end_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        print(f"[{_main_end_time_str}] 🛑 main() function completed (duration: {_main_duration:.2f} ms)")
