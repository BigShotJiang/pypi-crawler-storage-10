#!/usr/bin/env python3
"""
FastMCP-based MCP Server for Sandbox Code Interpreter

This server uses FastMCP framework to provide a unified interface
supporting stdio, SSE, and HTTP Streamable transports.
"""

# Record import start time
import time
_import_start_time = time.time()
_import_prev_time = _import_start_time
_import_timestamps = []

def _log_import_time(module_name: str):
    """Record import time for a module (both cumulative and individual)."""
    global _import_prev_time
    current_time = time.time()
    cumulative_ms = (current_time - _import_start_time) * 1000  # Cumulative time in milliseconds
    individual_ms = (current_time - _import_prev_time) * 1000  # Individual module time in milliseconds
    _import_timestamps.append((module_name, cumulative_ms, individual_ms))
    _import_prev_time = current_time

# Standard library imports
import asyncio
_log_import_time("asyncio")
import json
_log_import_time("json")
import logging
_log_import_time("logging")
import os
_log_import_time("os")
import sys
_log_import_time("sys")
import uuid
_log_import_time("uuid")
from typing import Any, Dict, List, Optional
_log_import_time("typing")
from datetime import datetime
_log_import_time("datetime")
import aiohttp
_log_import_time("aiohttp")

# FastMCP imports
from fastmcp import FastMCP
_log_import_time("fastmcp")
from fastmcp.server.context import Context
_log_import_time("fastmcp.server.context")
from fastmcp.server.http import create_sse_app
_log_import_time("fastmcp.server.http")
from starlette.middleware import Middleware
_log_import_time("starlette.middleware")
from starlette.middleware.cors import CORSMiddleware
_log_import_time("starlette.middleware.cors")

# E2B imports
from e2b_on_fc import Sandbox as E2BSandbox
_log_import_time("e2b_on_fc")
from e2b import TimeoutException
_log_import_time("e2b")

# Configure logging with timestamp (including milliseconds)
log_format = '%(asctime)s.%(msecs)03d - %(name)s - %(levelname)s - %(message)s'
date_format = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(
    level=logging.INFO,
    format=log_format,
    datefmt=date_format,
    force=True  # Force reconfiguration even if already configured
)

# Configure uvicorn access logger to include timestamp
uvicorn_access_logger = logging.getLogger("uvicorn.access")
uvicorn_access_logger.setLevel(logging.INFO)

# Configure uvicorn error logger to include timestamp
uvicorn_error_logger = logging.getLogger("uvicorn.error")
uvicorn_error_logger.setLevel(logging.INFO)

# Configure uvicorn logger to include timestamp
uvicorn_logger = logging.getLogger("uvicorn")
uvicorn_logger.setLevel(logging.INFO)

logger = logging.getLogger(__name__)

# Log import timing after logging is configured
_import_total_time = (time.time() - _import_start_time) * 1000  # Total in milliseconds
logger.info("=" * 80)
logger.info("📦 Module Import Timing")
logger.info("=" * 80)
logger.info(f"  {'Module Name':<40s} {'Cumulative (ms)':>15s} {'Individual (ms)':>15s}")
logger.info("-" * 80)
for module_name, cumulative_ms, individual_ms in _import_timestamps:
    logger.info(f"  {module_name:<40s} {cumulative_ms:>15.2f} {individual_ms:>15.2f}")
logger.info("-" * 80)
logger.info(f"  {'Total import time':<40s} {_import_total_time:>15.2f}")
logger.info("=" * 80)

# Global state
contexts: Dict[str, Dict[str, Any]] = {}
e2b_sandbox: Optional[E2BSandbox] = None
configured_sandbox_url: str = "http://localhost:5001"
service_session_id: str = "a" + str(uuid.uuid4()).replace("-", "")[:63]  # 服务级别的 session_id，进程存续期间保持不变，首字符为 a，长度 1-64 字符

# Initialize FastMCP server
mcp = FastMCP("Sandbox Code Interpreter")

def get_session_id(ctx: Optional[Context] = None) -> str:
    """
    获取 session_id，支持不同传输模式：
    - SSE: 从 query 参数中获取 session_id
    - HTTP Streamable: 从请求头中获取 mcp_session_id
    - HTTP: 从请求头中获取 X-CI-SESSION-ID
    - stdio: 使用服务级别的 session_id
    
    所有 session_id 的首字母都会被替换为 'a'
    
    Args:
        ctx: FastMCP Context 对象
        
    Returns:
        session_id 字符串（首字母为 'a'）
    """
    try:
        # 尝试获取 HTTP 请求对象
        from fastmcp.server.dependencies import get_http_request
        request = get_http_request()
        
        # SSE 模式：从 query 参数获取 session_id
        if hasattr(request, 'query_params'):
            session_id = request.query_params.get('session_id')
            if session_id:
                # 确保首字母为 'a'
                if session_id and len(session_id) > 0:
                    session_id = 'a' + session_id[1:] if len(session_id) > 1 else 'a'
                logger.info(f"✅ Using session_id from SSE query params: {session_id}")
                return session_id
        
        # HTTP 模式：从请求头获取 X-CI-SESSION-ID 或 mcp_session_id
        if hasattr(request, 'headers'):
            # 优先检查 HTTP Streamable 协议的 mcp_session_id
            session_id = request.headers.get('mcp_session_id')
            if session_id:
                # 确保首字母为 'a'
                if session_id and len(session_id) > 0:
                    session_id = 'a' + session_id[1:] if len(session_id) > 1 else 'a'
                logger.info(f"✅ Using session_id from HTTP Streamable mcp_session_id header: {session_id}")
                return session_id
            
            # 检查自定义的 X-CI-SESSION-ID
            session_id = request.headers.get('X-CI-SESSION-ID')
            if session_id:
                # 确保首字母为 'a'
                if session_id and len(session_id) > 0:
                    session_id = 'a' + session_id[1:] if len(session_id) > 1 else 'a'
                logger.info(f"✅ Using session_id from HTTP X-CI-SESSION-ID header: {session_id}")
                return session_id
                
    except RuntimeError:
        # 没有活跃的 HTTP 请求上下文（stdio 模式）
        logger.debug("No active HTTP request context found, using service-level session_id")
    
    # stdio 模式或没有请求参数：使用服务级别的 session_id
    logger.debug(f"Using service-level session_id: {service_session_id}")
    return service_session_id

async def initialize_e2b_sandbox(sandbox_url: str = 'http://localhost:5001'):
    """Initialize E2B sandbox connection."""
    global e2b_sandbox, configured_sandbox_url
    try:
        configured_sandbox_url = sandbox_url
        e2b_sandbox = E2BSandbox(envd_url=sandbox_url)
        logger.info(f"E2B sandbox initialized successfully with URL: {sandbox_url}")
    except Exception as e:
        logger.error(f"Failed to initialize E2B sandbox: {e}")
        raise

async def cleanup_e2b_sandbox():
    """Cleanup E2B sandbox connection."""
    global e2b_sandbox
    if e2b_sandbox:
        try:
            # E2B sandbox cleanup
            if hasattr(e2b_sandbox, 'close'):
                await e2b_sandbox.close()
            elif hasattr(e2b_sandbox, 'kill'):
                await e2b_sandbox.kill()
            logger.info("E2B sandbox closed successfully")
        except Exception as e:
            logger.error(f"Error closing E2B sandbox: {e}")
        finally:
            e2b_sandbox = None

async def async_health_check_task(sandbox_url: str):
    """
    异步健康检查任务：检查 sandbox_url/health 端点
    - 每 10 秒检查一次
    - 持续 2 分钟（12 次检查）
    - 超时时间 3 秒
    - 返回 200 状态码时提前结束
    - 使用服务级别的 session_id
    """
    logger.info(f"Starting async health check for sandbox: {sandbox_url}")
    logger.info(f"Using service session_id: {service_session_id}")
    
    # 确保 URL 有 /health 端点
    health_url = sandbox_url
    if not health_url.endswith('/health'):
        if not health_url.endswith('/'):
            health_url += '/'
        health_url += 'health'
    
    max_attempts = 12  # 2 分钟 = 120 秒，每 10 秒一次 = 12 次
    check_interval = 10  # 10 秒
    timeout = 3  # 3 秒超时
    
    # 准备请求头
    headers = {
        "X-CI-SESSION-ID": service_session_id,
        "Accept": "application/json"
    }
    
    for attempt in range(1, max_attempts + 1):
        try:
            logger.info(f"Health check attempt {attempt}/{max_attempts} for {health_url}")
            
            async with aiohttp.ClientSession() as session:
                async with session.get(health_url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                    status_code = response.status
                    
                    if status_code == 200:
                        logger.info(f"✅ Sandbox health check successful! Status: {status_code}")
                        logger.info(f"Sandbox is ready after {attempt} attempts")
                        return True
                    else:
                        logger.warning(f"⚠️ Sandbox health check returned status {status_code} (attempt {attempt}/{max_attempts})")
                        
        except asyncio.TimeoutError:
            logger.warning(f"⏰ Health check timeout for {health_url} (attempt {attempt}/{max_attempts})")
        except aiohttp.ClientError as e:
            logger.warning(f"🔌 Health check connection error for {health_url}: {str(e)} (attempt {attempt}/{max_attempts})")
        except Exception as e:
            logger.warning(f"❌ Health check failed for {health_url}: {str(e)} (attempt {attempt}/{max_attempts})")
        
        # 如果不是最后一次尝试，等待下次检查
        if attempt < max_attempts:
            logger.info(f"Waiting {check_interval} seconds before next health check...")
            await asyncio.sleep(check_interval)
    
    logger.warning(f"❌ Sandbox health check failed after {max_attempts} attempts over 2 minutes")
    logger.warning(f"Sandbox at {health_url} may not be ready")
    return False

@mcp.tool
async def run_code(code: str, context_id: Optional[str] = None, language: Optional[str] = None, ctx: Optional[Context] = None) -> str:
    """
    Execute code in the sandbox environment.
    
    Args:
        code: Code to execute
        context_id: Optional context ID for isolated execution
        language: Programming language (required if context_id is not provided)
        ctx: FastMCP Context object
        
    Returns:
        Execution result as string
    """
    try:
        # Validate parameters: if no context_id, language is required
        if not context_id and not language:
            return "Error: Either context_id or language parameter must be provided"
        
        # 获取 session_id
        session_id = get_session_id(ctx)
        logger.info(f"🔧 MCP run_code request received - Session ID: {session_id}")
        logger.debug(f"Using session_id for run_code: {session_id}")
        
        if not e2b_sandbox:
            await initialize_e2b_sandbox()
        
        # Execute code using E2B sandbox with language parameter
        if language:
            execution = e2b_sandbox.run_code(code, language=language, session_id=session_id)
        else:
            execution = e2b_sandbox.run_code(code, session_id=session_id)
        
        # Format the result
        if execution.error:
            result = f"Error: {execution.error.name}: {execution.error.value}\n{execution.error.traceback}"
        else:
            # 收集所有输出
            output_parts = []
            
            # 添加 stdout 输出
            if execution.logs.stdout:
                stdout_lines = []
                for msg in execution.logs.stdout:
                    if hasattr(msg, 'line'):
                        stdout_lines.append(msg.line)
                    else:
                        stdout_lines.append(str(msg))
                stdout_output = "\n".join(stdout_lines)
                if stdout_output.strip():
                    output_parts.append(stdout_output)
            
            # 添加 stderr 输出
            if execution.logs.stderr:
                stderr_lines = []
                for msg in execution.logs.stderr:
                    if hasattr(msg, 'line'):
                        stderr_lines.append(msg.line)
                    else:
                        stderr_lines.append(str(msg))
                stderr_output = "\n".join(stderr_lines)
                if stderr_output.strip():
                    output_parts.append(f"stderr: {stderr_output}")
            
            # 添加执行结果
            if execution.text:
                output_parts.append(execution.text)
            
            # 组合所有输出
            if output_parts:
                result = "\n".join(output_parts)
            else:
                result = "Code executed successfully (no output)"
        
        # Update context if provided
        if context_id and context_id in contexts:
            contexts[context_id]["last_used"] = datetime.now().isoformat()
        
        return result
        
    except TimeoutException as e:
        error_msg = f"Code execution timeout: {str(e)}. Configured sandbox URL: {configured_sandbox_url}"
        logger.error(error_msg)
        return error_msg
    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}. Configured sandbox URL: {configured_sandbox_url}"
        logger.error(error_msg)
        return error_msg

@mcp.tool
async def create_context(language: str = "python", description: str = "", ctx: Optional[Context] = None) -> str:
    """
    Create a new execution context in the sandbox.
    
    Args:
        language: Programming language (default: python)
        description: Optional description for the context
        ctx: FastMCP Context object
        
    Returns:
        Context ID
    """
    try:
        # 获取 session_id
        session_id = get_session_id(ctx)
        logger.info(f"🔧 MCP create_context request received - Session ID: {session_id}")
        logger.debug(f"Using session_id for create_context: {session_id}")
        
        # 使用 HTTP 客户端创建上下文
        from e2b_on_fc.sandbox_http_client import SandboxHTTPClient
        
        with SandboxHTTPClient(configured_sandbox_url) as client:
            # 在沙盒中创建上下文
            sandbox_context = client.create_context(session_id=session_id, language=language)
            
            context_id = sandbox_context.get('id')
            if not context_id:
                error_msg = f"Failed to get context ID from sandbox response: {sandbox_context}"
                logger.error(error_msg)
                return error_msg
            
            # 在本地记录上下文信息
            contexts[context_id] = {
                "id": context_id,
                "language": language,
                "description": description,
                "created_at": sandbox_context.get('created_at', datetime.now().isoformat()),
                "last_used": datetime.now().isoformat(),
                "cwd": sandbox_context.get('cwd', '')
            }
            
            logger.info(f"Created context {context_id} with language {language} in sandbox")
            return json.dumps({
                "context_id": context_id,
                "language": language,
                "description": description,
                "created_at": contexts[context_id]["created_at"]
            }, indent=2)
        
    except Exception as e:
        error_msg = f"Failed to create context: {str(e)}. Configured sandbox URL: {configured_sandbox_url}"
        logger.error(error_msg)
        return error_msg

@mcp.tool
async def stop_context(context_id: str, ctx: Optional[Context] = None) -> str:
    """
    Stop and remove a context from the sandbox.
    
    Args:
        context_id: Context ID to stop
        ctx: FastMCP Context object
        
    Returns:
        Success message
    """
    try:
        # 获取 session_id
        session_id = get_session_id(ctx)
        logger.info(f"🔧 MCP stop_context request received - Session ID: {session_id}")
        logger.debug(f"Using session_id for stop_context: {session_id}")
        
        # 使用 HTTP 客户端停止上下文
        from e2b_on_fc.sandbox_http_client import SandboxHTTPClient
        
        if context_id not in contexts:
            return json.dumps({
                "success": False,
                "message": f"Context {context_id} not found in local records"
            }, indent=2)
        
        with SandboxHTTPClient(configured_sandbox_url) as client:
            # 在沙盒中删除上下文
            try:
                client.remove_context(context_id, session_id=session_id)
                logger.info(f"Removed context {context_id} from sandbox")
            except Exception as e:
                logger.warning(f"Failed to remove context {context_id} from sandbox: {str(e)}")
        
        # 从本地记录中删除
        del contexts[context_id]
        logger.info(f"Removed context {context_id} from local records")
        
        return json.dumps({
            "success": True,
            "message": f"Context {context_id} stopped successfully"
        }, indent=2)
            
    except Exception as e:
        error_msg = f"Failed to stop context: {str(e)}. Configured sandbox URL: {configured_sandbox_url}"
        logger.error(error_msg)
        return error_msg

@mcp.tool
async def list_contexts(ctx: Optional[Context] = None) -> str:
    """
    List all available contexts from the sandbox.
    
    Args:
        ctx: FastMCP Context object
    
    Returns:
        JSON string of contexts
    """
    try:
        # 获取 session_id
        session_id = get_session_id(ctx)
        logger.info(f"🔧 MCP list_contexts request received - Session ID: {session_id}")
        logger.debug(f"Using session_id for list_contexts: {session_id}")
        
        # 使用 HTTP 客户端列出上下文
        from e2b_on_fc.sandbox_http_client import SandboxHTTPClient
        
        with SandboxHTTPClient(configured_sandbox_url) as client:
            # 从沙盒获取上下文列表
            sandbox_contexts = client.list_contexts(session_id=session_id)
            logger.info(f"Retrieved {len(sandbox_contexts)} contexts from sandbox")
            
            # 更新本地记录，同步沙盒中的上下文
            sandbox_context_ids = {ctx.get('id') for ctx in sandbox_contexts}
            
            # 添加沙盒中存在但本地不存在的上下文
            for ctx in sandbox_contexts:
                context_id = ctx.get('id')
                if context_id and context_id not in contexts:
                    contexts[context_id] = {
                        "id": context_id,
                        "language": ctx.get('language', 'unknown'),
                        "description": "",
                        "created_at": ctx.get('created_at', datetime.now().isoformat()),
                        "last_used": datetime.now().isoformat(),
                        "cwd": ctx.get('cwd', '')
                    }
                    logger.info(f"Added context {context_id} from sandbox to local records")
            
            # 标记本地存在但沙盒中不存在的上下文
            result = []
            for context_id, context_info in contexts.items():
                context_info_copy = context_info.copy()
                context_info_copy['sandbox_exists'] = context_id in sandbox_context_ids
                
                if context_id not in sandbox_context_ids:
                    context_info_copy['status'] = 'orphaned'
                    context_info_copy['warning'] = 'Context exists locally but not in sandbox'
                else:
                    context_info_copy['status'] = 'active'
                
                result.append(context_info_copy)
            
            return json.dumps(result, indent=2)
        
    except Exception as e:
        error_msg = f"Failed to list contexts: {str(e)}. Configured sandbox URL: {configured_sandbox_url}"
        logger.error(error_msg)
        return error_msg

@mcp.tool
async def health_check(ctx: Optional[Context] = None) -> str:
    """
    Check the health status of the FastMCP service.
    
    Args:
        ctx: FastMCP Context object
    
    Returns:
        Health status information
    """
    try:
        # 获取 session_id
        session_id = get_session_id(ctx)
        logger.info(f"🔧 MCP health_check request received - Session ID: {session_id}")
        logger.debug(f"Using session_id for health_check: {session_id}")
        
        # 只检查 FastMCP 服务状态，不检查 sandbox_url 连通性
        result = {
            "status": "healthy",
            "service": "fc-code-interpreter-mcp-server",
            "version": "0.1.6",
            "timestamp": datetime.now().isoformat(),
            "sandbox_url": configured_sandbox_url,
            "sandbox_available": e2b_sandbox is not None,
            "contexts_count": len(contexts),
            "session_id": session_id
        }
        
        logger.info("FastMCP service health check passed")
        return json.dumps(result, indent=2)
        
    except Exception as e:
        error_msg = f"Health check failed: {str(e)}"
        logger.error(error_msg)
        return json.dumps({
            "status": "error",
            "service": "fc-code-interpreter-mcp-server",
            "error": error_msg,
            "timestamp": datetime.now().isoformat()
        }, indent=2)

async def initialize_server(sandbox_url: str):
    """Initialize server resources."""
    try:
        await initialize_e2b_sandbox(sandbox_url)
        logger.info("Server initialized successfully")
        
        # 启动异步健康检查任务（不等待完成）
        asyncio.create_task(async_health_check_task(sandbox_url))
        logger.info("Async health check task started")
        
    except Exception as e:
        logger.error(f"Failed to initialize server: {e}")
        raise

async def cleanup_server():
    """Cleanup server resources."""
    try:
        await cleanup_e2b_sandbox()
        logger.info("Server cleanup completed")
    except Exception as e:
        logger.error(f"Error during server cleanup: {e}")

def get_uvicorn_log_config():
    """Get uvicorn logging configuration with timestamp (including milliseconds)."""
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": log_format,
                "datefmt": date_format,
            },
            "access": {
                "format": log_format,
                "datefmt": date_format,
            },
        },
        "handlers": {
            "default": {
                "formatter": "default",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
            },
            "access": {
                "formatter": "access",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
            },
        },
        "loggers": {
            "uvicorn": {
                "handlers": ["default"],
                "level": "INFO",
                "propagate": False,
            },
            "uvicorn.error": {
                "handlers": ["default"],
                "level": "INFO",
                "propagate": False,
            },
            "uvicorn.access": {
                "handlers": ["access"],
                "level": "INFO",
                "propagate": False,
            },
        },
    }

def parse_args():
    """Parse command line arguments with environment variable support."""
    import argparse
    
    # 从环境变量读取默认值（命令行参数优先级更高）
    default_transport = os.getenv('MCP_TRANSPORT', 'stdio')
    default_host = os.getenv('MCP_HOST', '0.0.0.0')
    default_port = int(os.getenv('MCP_PORT', '3000'))
    default_path = os.getenv('MCP_PATH', '/mcp')
    default_sandbox_url = os.getenv('SANDBOX_URL', 'http://localhost:5001')
    
    parser = argparse.ArgumentParser(description="FastMCP Sandbox Code Interpreter Server")
    parser.add_argument("--transport", choices=["stdio", "sse", "http"], default=default_transport,
                       help=f"Transport protocol to use (default: {default_transport}, env: MCP_TRANSPORT)")
    parser.add_argument("--host", default=default_host, 
                       help=f"Host to bind to (default: {default_host}, env: MCP_HOST)")
    parser.add_argument("--port", type=int, default=default_port, 
                       help=f"Port to bind to (default: {default_port}, env: MCP_PORT)")
    parser.add_argument("--path", default=default_path, 
                       help=f"Path for HTTP transport (default: {default_path}, env: MCP_PATH)")
    parser.add_argument("--sandbox-url", default=default_sandbox_url, 
                       help=f"E2B sandbox URL (default: {default_sandbox_url}, env: SANDBOX_URL)")
    
    return parser.parse_args()

def main():
    """Main entry point."""
    # Record server start time
    main_entry_time = time.time()
    start_time = datetime.now()
    start_time_str = start_time.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]  # Include milliseconds (3 digits)
    
    logger.info("=" * 80)
    logger.info(f"🎯 main() function entry at: {start_time_str}")
    logger.info("=" * 80)
    
    try:
        # Parse arguments
        args = parse_args()
        _args_parse_time = time.time()
        _args_parse_duration = (_args_parse_time - main_entry_time) * 1000
        logger.info(f"⏱️  Argument parsing took: {_args_parse_duration:.2f} ms")
        
        # Get host and port from args or environment
        host = args.host or os.getenv('MCP_HOST', '0.0.0.0')
        port = args.port or int(os.getenv('MCP_PORT', '3000'))
        path = args.path or os.getenv('MCP_PATH', '/mcp')
        
        logger.info("=" * 60)
        logger.info(f"🚀 FastMCP Server Starting...")
        logger.info(f"📅 Start Time: {start_time_str}")
        logger.info("=" * 60)
        logger.info(f"Starting FastMCP server with {args.transport} transport")
        logger.info(f"Host: {host}, Port: {port}")
        logger.info(f"Sandbox URL: {args.sandbox_url}")
        logger.info(f"Service Session ID: {service_session_id}")
        
        # Initialize server with sandbox URL
        _init_before_time = time.time()
        logger.info(f"⏱️  Initializing server (before initialize_server call)...")
        asyncio.run(initialize_server(args.sandbox_url))
        _init_after_time = time.time()
        _init_duration = (_init_after_time - _init_before_time) * 1000
        logger.info(f"⏱️  Server initialization completed (took {_init_duration:.2f} ms)")
        
        if args.transport == "stdio":
            logger.info("Using stdio transport")
            # FastMCP stdio transport
            mcp.run(transport="stdio")
            
        elif args.transport == "sse":
            logger.info(f"Using SSE transport on http://{host}:{port}{path}")
            # Create SSE app with CORS support
            from starlette.applications import Starlette
            from starlette.responses import JSONResponse
            from starlette.routing import Route, Mount
            
            # 创建健康检查端点
            async def health_check_endpoint(request):
                return JSONResponse({
                    "status": "healthy",
                    "service": "fc-code-interpreter-mcp-server",
                    "version": "0.0.10",
                    "timestamp": datetime.now().isoformat(),
                    "transport": "sse",
                    "sandbox_url": configured_sandbox_url,
                    "sandbox_available": e2b_sandbox is not None
                })
            
            # 创建 SSE 应用
            sse_app = create_sse_app(
                server=mcp,
                message_path=f"{path}/message",
                sse_path=path,
                middleware=[
                    Middleware(
                        CORSMiddleware,
                        allow_origins=["*"],
                        allow_credentials=True,
                        allow_methods=["GET", "POST", "OPTIONS"],
                        allow_headers=["*"],
                    )
                ]
            )
            
            # 包装应用添加健康检查端点
            wrapped_app = Starlette(
                routes=[
                    Route("/health_check", health_check_endpoint, methods=["GET"]),
                    Mount("/", app=sse_app),
                ]
            )
            
            # Run the SSE app
            import uvicorn
            _uvicorn_start_time = time.time()
            _total_to_uvicorn = (_uvicorn_start_time - main_entry_time) * 1000
            logger.info(f"⏱️  Starting uvicorn server (total time from main() entry: {_total_to_uvicorn:.2f} ms)")
            logger.info(f"🌐 Uvicorn server starting at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
            uvicorn.run(wrapped_app, host=host, port=port, log_config=get_uvicorn_log_config())
            
        elif args.transport == "http":
            logger.info(f"Using HTTP transport on http://{host}:{port}{path}")
            # FastMCP HTTP transport with CORS support
            from fastmcp.server.http import create_streamable_http_app
            from starlette.applications import Starlette
            from starlette.responses import JSONResponse
            from starlette.routing import Route, Mount
            
            # 创建请求日志中间件
            class RequestLoggingMiddleware:
                def __init__(self, app):
                    self.app = app
                
                async def __call__(self, scope, receive, send):
                    if scope["type"] == "http":
                        # 记录请求详情
                        method = scope.get("method", "UNKNOWN")
                        path = scope.get("path", "UNKNOWN")
                        query_string = scope.get("query_string", b"").decode()
                        headers = dict(scope.get("headers", []))
                        
                        logger.info(f"🔍 HTTP Request: {method} {path}")
                        if query_string:
                            logger.info(f"   Query: {query_string}")
                        logger.info(f"   Headers: {dict(headers)}")
                        
                        # 记录客户端信息
                        client = scope.get("client")
                        if client:
                            logger.info(f"   Client: {client[0]}:{client[1]}")
                        
                        # 如果是 POST 请求，记录请求体
                        if method == "POST":
                            # 创建一个包装的 receive 函数来记录请求体
                            async def wrapped_receive():
                                message = await receive()
                                if message["type"] == "http.request":
                                    body = message.get("body", b"")
                                    if body:
                                        try:
                                            # 尝试解析 JSON
                                            import json
                                            json_body = json.loads(body.decode())
                                            logger.info(f"   Request Body: {json_body}")
                                        except:
                                            logger.info(f"   Request Body (raw): {body[:200]}...")
                                return message
                            
                            await self.app(scope, wrapped_receive, send)
                        else:
                            await self.app(scope, receive, send)
                    else:
                        await self.app(scope, receive, send)
            
            # 创建健康检查端点
            async def health_check_endpoint(request):
                return JSONResponse({
                    "status": "healthy",
                    "service": "fc-code-interpreter-mcp-server",
                    "version": "0.0.10",
                    "timestamp": datetime.now().isoformat(),
                    "transport": "http",
                    "sandbox_url": configured_sandbox_url,
                    "sandbox_available": e2b_sandbox is not None
                })
            
            # 创建 MCP HTTP 应用
            http_app = create_streamable_http_app(
                server=mcp,
                streamable_http_path=path,
                middleware=[
                    Middleware(
                        CORSMiddleware,
                        allow_origins=["*"],
                        allow_credentials=True,
                        allow_methods=["GET", "POST", "OPTIONS"],
                        allow_headers=["*"],
                    )
                ]
            )
            
            # 包装应用添加健康检查端点和请求日志
            # 重要：必须传递 http_app 的 lifespan 以初始化 task group
            wrapped_app = Starlette(
                routes=[
                    Route("/health_check", health_check_endpoint, methods=["GET"]),
                    Mount("/", app=http_app),
                ],
                lifespan=http_app.lifespan  # 传递 FastMCP 的 lifespan
            )
            
            # 添加请求日志中间件
            wrapped_app = RequestLoggingMiddleware(wrapped_app)
            
            # Run the HTTP app
            import uvicorn
            _uvicorn_start_time = time.time()
            _total_to_uvicorn = (_uvicorn_start_time - main_entry_time) * 1000
            logger.info(f"⏱️  Starting uvicorn server (total time from main() entry: {_total_to_uvicorn:.2f} ms)")
            logger.info(f"🌐 Uvicorn server starting at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
            uvicorn.run(wrapped_app, host=host, port=port, log_config=get_uvicorn_log_config())
            
    except KeyboardInterrupt:
        logger.info("Server shutdown requested")
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
