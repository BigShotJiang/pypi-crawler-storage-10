"""Utility helpers for aiogram telemetry."""

__all__ = ["utc_now"]
