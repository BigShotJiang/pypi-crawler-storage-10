"""Logging helper for the package."""

from __future__ import annotations

import logging

logger = logging.getLogger("aiogram_telemetry")
