# Make sure you have the build tools:
pip install build
# Clean up and rebuild:
rm -rf dist build *.egg-info
# Then from the the cloned repo:
python -m build

