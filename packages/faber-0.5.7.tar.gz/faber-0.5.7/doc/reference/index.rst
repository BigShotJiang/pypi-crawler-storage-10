Faber Reference
===============

.. toctree::
   :maxdepth: 1

   feature
   action
   tool
   rule
   artefact
   config
   test
