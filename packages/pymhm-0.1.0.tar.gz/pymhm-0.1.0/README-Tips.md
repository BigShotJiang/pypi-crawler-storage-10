To Run a python file inside module

"C:/Program Files/QGIS 3.40.6/apps/Python312/python.exe" -m pymhm.pymhm  (To run pymhm.py inside pymhm module)

Else run on the same hierarchy of the module