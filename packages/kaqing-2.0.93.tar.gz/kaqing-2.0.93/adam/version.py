#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = "2.0.93"  #: the working version
__release__ = "1.0.0"  #: the release version