from yta_video_opengl.context import OpenGLContext
from yta_video_opengl.texture.utils import TextureUtils
from yta_validation.parameter import ParameterValidator
from yta_validation import PythonValidator
from typing import Union

import numpy as np
import moderngl


class _OpenGLTextureHandler:
    """
    *For internal use only*
    
    A texture handler that is used to handle video frames
    that have been loaded from CPU (probably by reading
    from a video file) and are converted to an OpenGL
    texture in the most efficient way.
    """

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None],
    ):
        ParameterValidator.validate_instance_of('opengl_context', opengl_context, moderngl.Context)

        self.opengl_context: moderngl.Context = (
            OpenGLContext().context
            if opengl_context is None else
            opengl_context
        )
        """
        The context of the OpenGL program.
        """
        self.texture = None
        """
        The OpenGL texture.
        """
        self._dtype: Union[str, None] = None
        """
        The dtype with which the texture was set.
        """
        self._last_shape: Union[tuple[int, int], None] = None
        """
        The last shape with which the texture was set.
        """
        self._last_components: Union[int, None] = None
        """
        The last number of componentes with which the texture
        was set.
        """
        self._dtype: Union[str, None] = None
        """
        The last dtype that was used when the texture was set.
        """

    def update(
        self,
        frame: Union[moderngl.Texture, np.ndarray],
        dtype: str = 'f1'
    ) -> moderngl.Texture:
        """
        Update the texture object content with the 'frame'
        provided. If the frame is a numpy array it will be
        flipped and adapted.

        (!) Do not do 'flipud' before passing the parameter,
        if you read it from a video file, because this 'update'
        method will do it.
        """
        if PythonValidator.is_instance_of(frame, moderngl.Texture):
            return frame
        
        # This will raise exception if invalid dtype
        frame = _prepare_frame_to_texture(
            frame = frame,
            dtype = dtype
        )

        h, w = frame.shape[:2]
        number_of_components = (
            frame.shape[2]
            if frame.ndim == 3 else
            1
        )

        # Create or update texture if needed (different
        # size or number of channels)
        if (
            self.texture is None
            or self._last_shape != (w, h)
            or self._last_components != number_of_components
            or self._dtype != dtype
        ):
            self.texture = self.opengl_context.texture(
                size = (w, h),
                components = number_of_components,
                # Empty texture by now, to fulfill later
                data = None,
                dtype = dtype
            )
            # If we want to repeat or to let it be black pixels
            self.texture.repeat_x = False
            self.texture.repeat_y = False
            self.texture.filter = (moderngl.LINEAR, moderngl.LINEAR)

            self._dtype = dtype
            self._last_shape = (w, h)
            self._last_components = number_of_components

        # Rewrite the frame as a texture
        self.texture.write(frame.tobytes())

        return self.texture
    
def _prepare_frame_to_texture(
    frame: np.ndarray,
    texture_dtype: str = 'f1'
) -> np.ndarray:
    """
    *For internal use only*

    Flip the provided `frame` numpy array and adapt
    its content according to the `texture_dtype`
    provided.
    """
    # Invert vertically for OpenGL
    frame = np.flipud(frame)

    return TextureUtils.numpy_to_texture_dtype(
        input = frame,
        texture_dtype = texture_dtype
    )