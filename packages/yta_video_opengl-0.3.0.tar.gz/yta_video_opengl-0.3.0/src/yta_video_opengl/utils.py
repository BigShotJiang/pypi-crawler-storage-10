import numpy as np
import moderngl


def get_fullscreen_quad_vao(
    context: moderngl.Context,
    program: moderngl.Program
) -> moderngl.VertexArray:
    """
    Get the vertex array object of a quad, by
    using the vertices, the indexes, the vbo,
    the ibo and the vao content.
    """
    # Quad vertices in NDC (-1..1) with texture
    # coords (0..1)
    """
    The UV coordinates to build the quad we
    will use to represent the frame by 
    applying it as a texture.
    """
    vertices = np.array(
        object = [
            # pos.x, pos.y, tex.u, tex.v
            -1.0, -1.0, 0.0, 0.0,  # vertex 0 - bottom left
            1.0, -1.0, 1.0, 0.0,  # vertex 1 - bottom right
            -1.0,  1.0, 0.0, 1.0,  # vertex 2 - top left
            1.0,  1.0, 1.0, 1.0,  # vertex 3 - top right
        ],
        dtype = 'f4'
    )

    """
    The indexes of the vertices (see 'vertices'
    property) to build the 2 opengl triangles
    that will represent the quad we need for
    the frame.
    """
    indices = np.array(
        object = [
            0, 1, 2,
            2, 1, 3
        ],
        dtype = 'i4'
    )

    vbo = context.buffer(vertices.tobytes())
    ibo = context.buffer(indices.tobytes())

    vao_content = [
        # TODO: This is the reason of needing 'in_vert'
        # and 'in_texcoord' variables set in our shaders
        # 2 floats position, 2 floats texcoords
        (vbo, '2f 2f', 'in_vert', 'in_texcoord'),
    ]

    return context.vertex_array(program, vao_content, ibo)