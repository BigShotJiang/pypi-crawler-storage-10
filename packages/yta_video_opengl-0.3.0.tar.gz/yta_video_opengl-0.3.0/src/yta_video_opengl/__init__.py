"""
Module that includes OpenGL and the way to handle
the shaders, the uniforms, etc.

Hey, this is interesting:
- https://youtube.com/playlist?list=PLlrATfBNZ98foTJPJ_Ev03o2oq3-GGOS2&si=r7Pmm6gEtd8DS75-
"""