from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any

class BaseApp(ABC):
    name: str = "BaseApp"
    description: str = "Abstract base app"
    config: Dict[str, Any] = {}

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        if config:
            self.config = config

    # -----------------------------
    # Authentication / Setup hooks
    # -----------------------------
    def connect(self):
        """Optional hook to connect / authenticate."""
        pass

    def disconnect(self):
        """Optional hook to disconnect/remove credentials."""
        pass

    def is_connected(self) -> bool:
        """Return whether the app is ready to accept todos."""
        return True

    # -----------------------------
    # Configuration hook
    # -----------------------------
    @abstractmethod
    def configure(self) -> Dict[str, Any]:
        """
        Ask the user for configuration (API keys, file paths, etc.)
        Returns a dict to be saved in the central config.json
        """
        raise NotImplementedError

    # -----------------------------
    # Main interface
    # -----------------------------
    @abstractmethod
    def write_todos(self, todos: List[Any]):
        """Write todos to the target app."""
        raise NotImplementedError
