from pathlib import Path
from typing import List
from src.apps.base_app import BaseApp
from models.todo import Todo

class JsonApp(BaseApp):
    name = "JSON"
    description = "Writes TODOs to a local JSON file"

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.file_path = Path(self.config.get("file_path", "todos.json"))

    def configure(self) -> dict:
        path = input(f"Enter path to JSON file [{self.file_path}]: ").strip()
        if path:
            self.file_path = Path(path)
        self.config["file_path"] = str(self.file_path)
        return self.config

    def write_todos(self, todos: List[Todo]):
        output = [{
            "summary": t.summary,
            "body": t.body,
            "file_path": t.file_path,
            "line": t.line,
        } for t in todos]

        try:
            with self.file_path.open("w", encoding="utf-8") as f:
                import json
                json.dump(output, f, indent=4, ensure_ascii=False)
            print(f"✅ Saved {len(todos)} todos to {self.file_path}")
        except Exception as e:
            print(f"❌ Failed to write JSON todos: {e}")
