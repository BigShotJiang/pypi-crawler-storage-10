from pathlib import Path
import re
from typing import List

from models.todo import Todo


class TodoService:
    """Service responsible for extracting TODO comments from source files."""

    # Matches lines containing TODO in common comment syntaxes.
    TODO_PATTERN = re.compile(
        r"^\s*(?:#|//|--|<!--|/\*|\*|\").*TODO.*$", re.IGNORECASE
    )

    # Matches lines that look like continuation comment lines.
    COMMENT_CONTINUATION_PATTERN = re.compile(r"^\s*(#|//|\*|\").+")

    def get_todos(self, file_paths: List[str]) -> List[Todo]:
        """
        Scans the given file paths for TODO comments and returns a list of Todo objects.

        Args:
            file_paths: List of file paths to scan.

        Returns:
            A list of Todo objects found across all files.
        """
        todos = []

        for path_str in file_paths:
            path = Path(path_str)
            if not path.is_file():
                continue

            try:
                with path.open(encoding="utf-8") as file:
                    lines = file.readlines()
                todos.extend(self._extract_todos_from_lines(path, lines))
            except (OSError, UnicodeDecodeError) as e:
                print(f"Skipping file {path}: {e}")
                continue

        return todos

    def _extract_todos_from_lines(self, file_path: Path, lines: List[str]) -> List[Todo]:
        """Extracts TODO comments from the given lines of a file."""
        todos = []
        index = 0
        total_lines = len(lines)

        while index < total_lines:
            line = lines[index]
            if not self.TODO_PATTERN.search(line):
                index += 1
                continue

            start_line_number = index + 1
            body_lines = [line.strip()]

            # Capture subsequent comment lines as part of the same TODO block
            index += 1
            while index < total_lines and self.COMMENT_CONTINUATION_PATTERN.match(lines[index]):
                body_lines.append(lines[index].strip())
                index += 1

            summary = body_lines[0]
            body = "\n".join(body_lines)

            todos.append(Todo(summary, body, str(file_path), start_line_number))

        return todos
