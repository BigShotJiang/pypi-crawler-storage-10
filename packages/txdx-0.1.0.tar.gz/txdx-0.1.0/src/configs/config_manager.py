import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
import pkgutil
import importlib
import inspect

from src.apps.base_app import BaseApp


class ConfigManager:
    """
    Manages local configuration and dynamically discovers available apps
    that inherit from BaseApp at runtime.
    """

    CONFIG_DIR_NAME = ".todo_to_task"
    CONFIG_FILE_NAME = "config.json"

    def __init__(self, code_root: Optional[Path] = None):
        self.code_root = Path(code_root or self._find_code_root()).resolve()
        self.apps_package = "src.apps"

        self.config_dir = Path(self._get_config_dir())
        self.config_path = self.config_dir / self.CONFIG_FILE_NAME
        self.config_dir.mkdir(parents=True, exist_ok=True)

        if not self.config_path.exists():
            self._write_config({
                "connected_apps": {},
                "apps_config": {},
                "available_apps": self._discover_available_apps(),
            })

    # -------------------------------
    # Public Methods
    # -------------------------------

    def load(self) -> Dict[str, Any]:
        """Load configuration and refresh available apps dynamically."""
        try:
            with self.config_path.open("r", encoding="utf-8") as f:
                config = json.load(f)
        except (OSError, json.JSONDecodeError):
            config = {"connected_apps": {}, "apps_config": {}, "available_apps": []}

        config["available_apps"] = self._discover_available_apps()
        return config

    def save(self, config: Dict[str, Any]) -> None:
        """Save configuration to disk."""
        self._write_config(config)

    def save_app_config(self, app_name: str, config: dict):
        """Save configuration for a specific app inside central config.json."""
        data = self.load()
        if "apps_config" not in data:
            data["apps_config"] = {}
        data["apps_config"][app_name] = config
        self.save(data)

    def load_app_config(self, app_name: str) -> dict:
        """Load configuration for a specific app."""
        data = self.load()
        return data.get("apps_config", {}).get(app_name, {})

    # -------------------------------
    # Internal Helpers
    # -------------------------------

    def _write_config(self, data: Dict[str, Any]):
        with self.config_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def _get_config_dir(self) -> Path:
        if os.name == "nt":
            return Path(os.getenv("APPDATA", Path.home())) / self.CONFIG_DIR_NAME
        return Path.home() / self.CONFIG_DIR_NAME

    def _find_code_root(self) -> Path:
        """Find project root by walking up to locate `src/apps`."""
        current = Path(__file__).resolve()
        for parent in current.parents:
            if (parent / "src" / "apps").exists():
                return parent
        return Path.cwd()

    def _discover_available_apps(self) -> List[Dict[str, Any]]:
        """
        Dynamically discover all apps in the `src.apps` package that inherit BaseApp.
        Returns a list of dicts with keys: name, description, path.
        """
        apps = []
        package = importlib.import_module(self.apps_package)
        package_path = package.__path__

        for _, name, _ in pkgutil.iter_modules(package_path):
            full_module_name = f"{self.apps_package}.{name}"
            try:
                module = importlib.import_module(full_module_name)
            except Exception:
                continue

            for _, cls in inspect.getmembers(module, inspect.isclass):
                if issubclass(cls, BaseApp) and cls is not BaseApp:
                    apps.append({
                        "name": getattr(cls, "name", cls.__name__),
                        "description": getattr(cls, "description", "No description"),
                        "path": str(module.__file__),
                    })

        return sorted(apps, key=lambda x: x["name"].lower())
