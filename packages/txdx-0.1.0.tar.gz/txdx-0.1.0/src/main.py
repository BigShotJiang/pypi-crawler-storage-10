"""
TODO-to-Task (txdx)
==================
CLI tool that scans codebases for TODO comments and syncs them
with your chosen task management app.
"""

import sys
from cli import CLI


def main():
    """Main entrypoint for the txdx CLI application."""
    cli = CLI()
    cli.run(sys.argv[1:])


if __name__ == "__main__":
    main()
