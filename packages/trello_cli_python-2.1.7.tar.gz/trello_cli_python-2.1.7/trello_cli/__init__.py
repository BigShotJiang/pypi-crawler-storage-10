"""
Trello CLI - Official Python command-line interface for Trello
"""

__version__ = "2.1.7"
__author__ = "Bernard Uriza Orozco"
