# Git Genie CLI  

Git Genie, a AI command-line tool that writes git commits and documentation

## Installation

```bash

pip install Git-Genie-CLI

```
