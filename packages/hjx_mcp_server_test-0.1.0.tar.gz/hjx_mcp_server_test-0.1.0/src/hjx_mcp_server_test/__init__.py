from mcp.server.fastmcp import FastMCP
import logging
logging.basicConfig(level=logging.DEBUG)


mcp = FastMCP("Demo")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a greeting."""
    return f"Hello {name}!"

def main() -> None:
    mcp.run(transport="stdio")
