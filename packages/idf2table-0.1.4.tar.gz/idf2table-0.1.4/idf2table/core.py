"""
Fonctions principales pour la conversion IDF vers DataFrame.
"""
import os
from pathlib import Path
from typing import Union, List, Dict, Any

import pandas as pd
from eppy.modeleditor import IDF
from eppy.iddcurrent import iddcurrent

# Chemins possibles pour le fichier IDD EnergyPlus
POSSIBLE_IDD = [
    r"C:\EnergyPlusV9-4-0\Energy+.idd",
    r"C:\Program Files\EnergyPlusV9-4-0\Energy+.idd",
    r"/Applications/EnergyPlus-9-4-0/Energy+.idd",
    r"./EnergyPlus-9.4.0-998c4b761e-Linux-Ubuntu18.04-x86_64/Energy+.idd",
]


def find_idd() -> Path:
    """
    Trouve le fichier IDD EnergyPlus.

    Recherche le fichier IDD dans les emplacements suivants (dans cet ordre) :
    1. Variable d'environnement ENERGYPLUS_IDD
    2. Emplacements standards selon le système d'exploitation

    Returns:
        Path: Chemin vers le fichier IDD trouvé

    Raises:
        FileNotFoundError: Si aucun fichier IDD n'est trouvé

    Example:
        >>> from idf2table import find_idd
        >>> idd_path = find_idd()
        >>> IDF.setiddname(str(idd_path))
    """
    # Vérifier d'abord la variable d'environnement
    env_idd = os.getenv("ENERGYPLUS_IDD")
    if env_idd and Path(env_idd).is_file():
        return Path(env_idd)

    # Chercher dans les emplacements possibles
    for idd_path in POSSIBLE_IDD:
        p = Path(idd_path)
        if p.is_file():
            return p

    raise FileNotFoundError(
        "Fichier IDD EnergyPlus introuvable. Vérifiez que EnergyPlus est installé "
        "ou définissez la variable d'environnement ENERGYPLUS_IDD."
    )


def idf_to_table(
    idf: Union[IDF, str], object_type: str, idd_file: Union[str, None] = None
) -> pd.DataFrame:
    """
    Convertit tous les objets d'un type donné d'un fichier IDF en DataFrame pandas.

    Cette fonction permet de convertir n'importe quel type d'objet EnergyPlus (Material,
    Zone, Construction, etc.) en DataFrame pandas, où chaque ligne représente un objet
    et chaque colonne représente un attribut de l'objet.

    Args:
        idf: Objet IDF ou chemin vers le fichier .idf
        object_type: Type d'objet à convertir (ex: "Material", "MATERIAL", "Zone")
        idd_file: Chemin vers le fichier IDD (optionnel, utilise le IDD par défaut si non fourni)

    Returns:
        pd.DataFrame: DataFrame pandas où chaque ligne représente un objet et chaque
        colonne représente un attribut/champ de l'objet.

    Raises:
        ValueError: Si le type d'objet spécifié n'existe pas dans le fichier IDF
        FileNotFoundError: Si le fichier IDF ou IDD n'est pas trouvé

    Example:
        >>> from idf2table import idf_to_table, find_idd
        >>> from eppy.modeleditor import IDF
        >>>
        >>> # Configurer le fichier IDD
        >>> idd_path = find_idd()
        >>> IDF.setiddname(str(idd_path))
        >>>
        >>> # Charger le fichier IDF
        >>> idf = IDF('data/OPIO_run.idf')
        >>>
        >>> # Convertir les Material en DataFrame
        >>> materials_df = idf_to_table(idf, "Material")
        >>>
        >>> # Ou directement avec le chemin du fichier
        >>> materials_df = idf_to_table('data/OPIO_run.idf', "Material")
    """
    # Si idf est un chemin de fichier, charger le fichier
    if isinstance(idf, str):
        # Configurer le fichier IDD si nécessaire
        if idd_file:
            IDF.setiddname(idd_file)
        else:
            # Essayer de trouver le IDD automatiquement
            try:
                idd_path = find_idd()
                IDF.setiddname(str(idd_path))
            except FileNotFoundError:
                # Si find_idd() échoue, essayer iddcurrent
                try:
                    idd_file = iddcurrent.iddname()
                    IDF.setiddname(idd_file)
                except Exception:
                    # Si tout échoue, laisser eppy gérer l'erreur
                    pass
        idf = IDF(idf)

    # Normaliser le type d'objet (en majuscules pour eppy)
    object_type_upper = object_type.upper()

    # Récupérer tous les objets du type spécifié
    try:
        objects = idf.idfobjects[object_type_upper]
    except KeyError:
        raise ValueError(
            f"Type d'objet '{object_type}' non trouvé dans le fichier IDF. "
            f"Types disponibles: {list(idf.idfobjects.keys())}"
        )

    if not objects:
        # Si aucun objet trouvé, retourner un DataFrame vide
        return pd.DataFrame()

    # Identifier tous les champs disponibles en examinant le premier objet
    first_obj = objects[0]
    field_names = []

    # Les objets eppy ont un attribut fieldnames qui liste tous les champs
    if hasattr(first_obj, "fieldnames"):
        field_names = first_obj.fieldnames
    else:
        # Fallback : utiliser dir() et filtrer les attributs non privés
        # et non méthodes
        all_attrs = dir(first_obj)
        field_names = [
            attr
            for attr in all_attrs
            if not attr.startswith("_") and not callable(getattr(first_obj, attr, None))
        ]

    # Créer une liste de dictionnaires, un par objet
    data: List[Dict[str, Any]] = []
    for obj in objects:
        row = {}
        for field_name in field_names:
            try:
                # Essayer d'accéder au champ via getattr ou notation []
                if hasattr(obj, field_name):
                    value = getattr(obj, field_name)
                elif hasattr(obj, "__getitem__"):
                    value = obj[field_name]
                else:
                    value = None

                # Nettoyer la valeur si c'est une chaîne (supprimer espaces)
                if isinstance(value, str):
                    value = value.strip()

                row[field_name] = value
            except (AttributeError, KeyError, IndexError):
                # Si le champ n'existe pas pour cet objet, mettre None
                row[field_name] = None
        data.append(row)

    # Créer le DataFrame
    df = pd.DataFrame(data)

    return df

