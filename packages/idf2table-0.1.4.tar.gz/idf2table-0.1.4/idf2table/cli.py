"""
Script de ligne de commande pour l'utilisation de idf2table.
"""
import argparse
from pathlib import Path

from eppy.modeleditor import IDF

from idf2table.core import find_idd, idf_to_table


def main():
    """
    Fonction principale pour la ligne de commande.
    """
    parser = argparse.ArgumentParser(
        description="Convertir des objets IDF EnergyPlus en DataFrame pandas"
    )
    parser.add_argument(
        "idf_file",
        type=str,
        help="Chemin vers le fichier IDF",
    )
    parser.add_argument(
        "object_type",
        type=str,
        help="Type d'objet à convertir (ex: Material, Zone, Construction)",
    )
    parser.add_argument(
        "--idd",
        type=str,
        default=None,
        help="Chemin vers le fichier IDD (optionnel)",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        default=None,
        help="Chemin de sortie pour le fichier Excel (optionnel)",
    )
    parser.add_argument(
        "--csv",
        action="store_true",
        help="Sauvegarder en CSV au lieu d'Excel",
    )

    args = parser.parse_args()

    # Configurer le fichier IDD
    try:
        if args.idd:
            IDF.setiddname(args.idd)
            print(f"Fichier IDD utilisé: {args.idd}")
        else:
            idd_path = find_idd()
            IDF.setiddname(str(idd_path))
            print(f"Fichier IDD utilisé: {idd_path}")
    except FileNotFoundError as e:
        print(f"Erreur: {e}")
        return 1

    # Charger le fichier IDF
    try:
        idf = IDF(args.idf_file)
    except Exception as e:
        print(f"Erreur lors du chargement du fichier IDF: {e}")
        return 1

    # Convertir en DataFrame
    try:
        print(f"Conversion des objets {args.object_type}...")
        df = idf_to_table(idf, args.object_type)
    except ValueError as e:
        print(f"Erreur: {e}")
        return 1

    # Afficher les résultats
    print(f"\nDataFrame créé avec {len(df)} lignes et {len(df.columns)} colonnes")
    print("\nPremières lignes:")
    print(df.head())

    print("\nColonnes:", list(df.columns))

    # Sauvegarder si demandé
    if args.output:
        output_path = Path(args.output)
        if args.csv:
            df.to_csv(output_path, index=False)
            print(f"\n✓ Fichier CSV sauvegardé: {output_path}")
        else:
            df.to_excel(output_path, index=False)
            print(f"\n✓ Fichier Excel sauvegardé: {output_path}")
    elif args.csv:
        output_path = Path(args.idf_file).stem + f"_{args.object_type}.csv"
        df.to_csv(output_path, index=False)
        print(f"\n✓ Fichier CSV sauvegardé: {output_path}")

    return 0


if __name__ == "__main__":
    exit(main())

