# OptiFlow — Usage Guide

OptiFlow is a modular framework for hyperparameter optimization across different machine learning models and optimization strategies.  
It supports algorithms such as Genetic Optimization, PSO, Bayesian Optimization, TPE, Random Search, and Simulated Annealing.

---

## Installation

Install OptiFlow in editable (development) mode:

```bash
git clone https://github.com/Faycal214/optiflow.git
cd optiflow
pip install -e .
