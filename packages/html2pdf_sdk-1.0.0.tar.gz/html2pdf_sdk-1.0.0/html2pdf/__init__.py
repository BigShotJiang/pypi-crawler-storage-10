"""html2pdf-sdk - Official Python SDK for html2pdf service.

This package provides both synchronous and asynchronous clients for the html2pdf service,
allowing you to convert HTML to PDF with ease.

Example:
    ```python
    from html2pdf import Html2PdfClient
    from html2pdf.types import RenderRequest, RenderOptions

    # Synchronous usage
    client = Html2PdfClient(
        base_url="https://api.rendly.cloud",
        api_key="your-api-key"
    )

    result = client.render.create(RenderRequest(
        html="<h1>Hello World</h1>",
        options=RenderOptions(page_size="A4")
    ))

    with open("output.pdf", "wb") as f:
        f.write(result.pdf)
    ```

Async Example:
    ```python
    from html2pdf import AsyncHtml2PdfClient
    from html2pdf.types import RenderRequest, RenderOptions

    async with AsyncHtml2PdfClient(
        base_url="https://api.rendly.cloud",
        api_key="your-api-key"
    ) as client:
        result = await client.render.acreate(RenderRequest(
            html="<h1>Hello World</h1>",
            options=RenderOptions(page_size="A4")
        ))

        with open("output.pdf", "wb") as f:
            f.write(result.pdf)
    ```
"""

__version__ = "1.0.0"

from .client import AsyncHtml2PdfClient, Html2PdfClient
from .errors import (
    AuthenticationError,
    Html2PdfError,
    NetworkError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)

# Export commonly used types for convenience
from .types import (
    BatchItem,
    BatchRequest,
    BatchResponse,
    ComplianceStandard,
    Margins,
    PageSizeEnum,
    RenderOptions,
    RenderRequest,
    RenderResponse,
    TemplateRenderRequest,
    WebhookConfig,
)

__all__ = [
    # Version
    "__version__",
    # Main clients
    "Html2PdfClient",
    "AsyncHtml2PdfClient",
    # Errors
    "Html2PdfError",
    "ValidationError",
    "AuthenticationError",
    "RateLimitError",
    "TimeoutError",
    "NetworkError",
    # Commonly used types
    "RenderRequest",
    "RenderOptions",
    "RenderResponse",
    "Margins",
    "PageSizeEnum",
    "ComplianceStandard",
    "BatchRequest",
    "BatchItem",
    "BatchResponse",
    "TemplateRenderRequest",
    "WebhookConfig",
]
