"""Main client classes for html2pdf SDK."""

from typing import Dict, Optional

from ._http import HttpClient
from .resources import (
    BatchResource,
    ComplianceResource,
    RenderResource,
    TemplatesResource,
    WebhooksResource,
)


class Html2PdfClient:
    """Html2Pdf SDK Client (synchronous).

    Example:
        ```python
        from html2pdf import Html2PdfClient
        from html2pdf.types import RenderRequest, RenderOptions

        # Initialize the client
        client = Html2PdfClient(
            base_url="https://api.html2pdf.example.com",
            api_key="your-api-key"
        )

        # Render HTML to PDF
        result = client.render.create(RenderRequest(
            html="<h1>Hello World</h1>",
            options=RenderOptions(page_size="A4")
        ))

        # Save the PDF
        with open("output.pdf", "wb") as f:
            f.write(result.pdf)

        print(f"Generated {result.metadata.pages} pages in {result.metadata.duration_ms}ms")
        ```
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize the Html2Pdf client.

        Args:
            base_url: Base URL of the html2pdf service (e.g., "https://api.html2pdf.example.com")
            api_key: API key for authentication
            access_token: JWT access token for authentication (alternative to API key)
            timeout: Default timeout for requests in seconds (default: 30.0)
            max_retries: Maximum number of retries for failed requests (default: 3)
            headers: Custom headers to include in all requests

        Raises:
            ValueError: If neither api_key nor access_token is provided, or if base_url is invalid

        Example:
            ```python
            # With API key
            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            # With JWT token
            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                access_token="your-jwt-token"
            )

            # With custom options
            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key",
                timeout=60.0,
                max_retries=5,
                headers={"X-Custom-Header": "value"}
            )
            ```
        """
        self._validate_config(base_url, api_key, access_token)

        # Initialize HTTP client
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            timeout=timeout,
            max_retries=max_retries,
            headers=headers or {},
        )

        # Initialize resource handlers
        self.render = RenderResource(self._http)
        """Render operations (sync and async PDF generation)"""

        self.batch = BatchResource(self._http)
        """Batch processing operations"""

        self.templates = TemplatesResource(self._http)
        """Template-based rendering"""

        self.webhooks = WebhooksResource(self._http)
        """Webhook management"""

        self.compliance = ComplianceResource(self._http)
        """Compliance validation (PDF/A, PDF/UA, WCAG, PDF/X)"""

    def health_check(self) -> bool:
        """Health check - verify the service is available.

        Returns:
            True if service is healthy, False otherwise

        Example:
            ```python
            is_healthy = client.health_check()
            print(f"Service healthy: {is_healthy}")
            ```
        """
        try:
            self._http.request(method="GET", path="/v1/healthz", response_type="text")
            return True
        except Exception:
            return False

    def get_metrics(self) -> str:
        """Get Prometheus metrics from the service.

        Returns:
            Metrics in Prometheus text format

        Example:
            ```python
            metrics = client.get_metrics()
            print(metrics)
            ```
        """
        return self._http.request(method="GET", path="/metrics", response_type="text")

    def close(self) -> None:
        """Close the HTTP client and release resources.

        Example:
            ```python
            client = Html2PdfClient(...)
            try:
                # Use the client
                result = client.render.create(...)
            finally:
                client.close()
            ```
        """
        self._http.close()

    def __enter__(self) -> "Html2PdfClient":
        """Context manager support.

        Example:
            ```python
            with Html2PdfClient(...) as client:
                result = client.render.create(...)
            ```
        """
        return self

    def __exit__(self, *args: object) -> None:
        """Context manager support."""
        self.close()

    @staticmethod
    def _validate_config(
        base_url: str,
        api_key: Optional[str],
        access_token: Optional[str],
    ) -> None:
        """Validate client configuration."""
        if not base_url:
            raise ValueError("base_url is required")

        if not api_key and not access_token:
            raise ValueError("Either api_key or access_token is required")

        # Validate baseUrl format
        from urllib.parse import urlparse
        try:
            result = urlparse(base_url)
            if not all([result.scheme, result.netloc]):
                raise ValueError("base_url must be a valid URL")
        except Exception as e:
            raise ValueError(f"base_url must be a valid URL: {e}") from e


class AsyncHtml2PdfClient:
    """Html2Pdf SDK Client (asynchronous).

    Example:
        ```python
        from html2pdf import AsyncHtml2PdfClient
        from html2pdf.types import RenderRequest, RenderOptions

        # Initialize the client
        async with AsyncHtml2PdfClient(
            base_url="https://api.html2pdf.example.com",
            api_key="your-api-key"
        ) as client:
            # Render HTML to PDF
            result = await client.render.acreate(RenderRequest(
                html="<h1>Hello World</h1>",
                options=RenderOptions(page_size="A4")
            ))

            # Save the PDF
            with open("output.pdf", "wb") as f:
                f.write(result.pdf)

            print(f"Generated {result.metadata.pages} pages")
        ```
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize the async Html2Pdf client.

        Args:
            base_url: Base URL of the html2pdf service
            api_key: API key for authentication
            access_token: JWT access token for authentication (alternative to API key)
            timeout: Default timeout for requests in seconds (default: 30.0)
            max_retries: Maximum number of retries for failed requests (default: 3)
            headers: Custom headers to include in all requests

        Raises:
            ValueError: If neither api_key nor access_token is provided, or if base_url is invalid
        """
        Html2PdfClient._validate_config(base_url, api_key, access_token)

        # Initialize HTTP client
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            timeout=timeout,
            max_retries=max_retries,
            headers=headers or {},
        )

        # Initialize resource handlers
        self.render = RenderResource(self._http)
        """Render operations (async)"""

        self.batch = BatchResource(self._http)
        """Batch processing operations (async)"""

        self.templates = TemplatesResource(self._http)
        """Template-based rendering (async)"""

        self.webhooks = WebhooksResource(self._http)
        """Webhook management (async)"""

        self.compliance = ComplianceResource(self._http)
        """Compliance validation (async)"""

    async def health_check(self) -> bool:
        """Health check - verify the service is available.

        Returns:
            True if service is healthy, False otherwise

        Example:
            ```python
            async with AsyncHtml2PdfClient(...) as client:
                is_healthy = await client.health_check()
                print(f"Service healthy: {is_healthy}")
            ```
        """
        try:
            await self._http.arequest(method="GET", path="/v1/healthz", response_type="text")
            return True
        except Exception:
            return False

    async def get_metrics(self) -> str:
        """Get Prometheus metrics from the service.

        Returns:
            Metrics in Prometheus text format

        Example:
            ```python
            async with AsyncHtml2PdfClient(...) as client:
                metrics = await client.get_metrics()
                print(metrics)
            ```
        """
        return await self._http.arequest(method="GET", path="/metrics", response_type="text")

    async def close(self) -> None:
        """Close the HTTP client and release resources.

        Example:
            ```python
            client = AsyncHtml2PdfClient(...)
            try:
                result = await client.render.acreate(...)
            finally:
                await client.close()
            ```
        """
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncHtml2PdfClient":
        """Async context manager support.

        Example:
            ```python
            async with AsyncHtml2PdfClient(...) as client:
                result = await client.render.acreate(...)
            ```
        """
        return self

    async def __aexit__(self, *args: object) -> None:
        """Async context manager support."""
        await self.close()
