"""Compliance validation resource for PDF standards."""

from typing import TYPE_CHECKING

from ..types import (
    ComplianceCertificateRequest,
    ComplianceCertificateResponse,
)

if TYPE_CHECKING:
    from .._http import HttpClient


class ComplianceResource:
    """Compliance validation operations (PDF/A, PDF/UA, WCAG, PDF/X)."""

    def __init__(self, http: "HttpClient") -> None:
        """Initialize the compliance resource.

        Args:
            http: HTTP client instance
        """
        self._http = http

    def generate_certificate(
        self, request: ComplianceCertificateRequest
    ) -> ComplianceCertificateResponse:
        """Generate a compliance certificate for a PDF.

        Validates the PDF against specified standards and generates a certificate.

        Args:
            request: Compliance certificate request with PDF and standards

        Returns:
            ComplianceCertificateResponse with validation results and optional certificate PDF

        Raises:
            ValidationError: Invalid request
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import ComplianceCertificateRequest

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            with open("document.pdf", "rb") as f:
                pdf_data = f.read()

            certificate = client.compliance.generate_certificate(
                ComplianceCertificateRequest(
                    pdf=pdf_data,
                    standards=["pdfa", "pdfua", "wcag"],
                    format="json"
                )
            )

            print(f"Certificate ID: {certificate.certificate_id}")

            for result in certificate.results:
                print(f"{result.standard}: {'PASS' if result.compliant else 'FAIL'}")
                print(f"Score: {result.score}/100")

                if not result.compliant:
                    print("Issues:")
                    for issue in result.issues:
                        print(f"  [{issue.severity}] {issue.message}")
                        if issue.recommendation:
                            print(f"    → {issue.recommendation}")
            ```
        """
        # Build multipart form data
        import json

        files = {"pdf": ("document.pdf", request.pdf, "application/pdf")}

        data = {}
        if request.standards:
            data["standards"] = json.dumps(request.standards)
        if request.format:
            data["format"] = request.format

        # Note: For multipart requests, we need to handle this differently
        # This is a simplified version - in production, use proper multipart handling
        response_data = self._http.request(
            method="POST",
            path="/v1/compliance/certificate",
            # In a real implementation, we'd use httpx's files parameter
            # For now, this is placeholder - need to update _http.py
            json=data,
            response_type="json",
        )

        return ComplianceCertificateResponse.model_validate(response_data)

    async def agenerate_certificate(
        self, request: ComplianceCertificateRequest
    ) -> ComplianceCertificateResponse:
        """Generate a compliance certificate for a PDF (async version).

        Args:
            request: Compliance certificate request with PDF and standards

        Returns:
            ComplianceCertificateResponse with validation results and optional certificate PDF

        Raises:
            ValidationError: Invalid request
            Html2PdfError: Other API errors
        """
        import json

        data = {}
        if request.standards:
            data["standards"] = json.dumps(request.standards)
        if request.format:
            data["format"] = request.format

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/compliance/certificate",
            json=data,
            response_type="json",
        )

        return ComplianceCertificateResponse.model_validate(response_data)

    def validate_pdfa(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/A standards.

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            with open("document.pdf", "rb") as f:
                pdf_data = f.read()

            result = client.compliance.validate_pdfa(pdf_data)

            if result.results[0].compliant:
                print("PDF/A compliant!")
            else:
                print("PDF/A validation failed")
                for issue in result.results[0].issues:
                    print(f"  - {issue.message}")
            ```
        """
        return self.generate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfa"],
                format="json"
            )
        )

    async def avalidate_pdfa(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/A standards (async version).

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors
        """
        return await self.agenerate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfa"],
                format="json"
            )
        )

    def validate_pdfua(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/UA (accessibility) standards.

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            with open("document.pdf", "rb") as f:
                pdf_data = f.read()

            result = client.compliance.validate_pdfua(pdf_data)

            if result.results[0].compliant:
                print("PDF/UA compliant (accessible)!")
            ```
        """
        return self.generate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfua"],
                format="json"
            )
        )

    async def avalidate_pdfua(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/UA standards (async version).

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors
        """
        return await self.agenerate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfua"],
                format="json"
            )
        )

    def validate_wcag(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against WCAG accessibility standards.

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            with open("document.pdf", "rb") as f:
                pdf_data = f.read()

            result = client.compliance.validate_wcag(pdf_data)

            print(f"WCAG Score: {result.results[0].score}/100")
            ```
        """
        return self.generate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["wcag"],
                format="json"
            )
        )

    async def avalidate_wcag(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against WCAG standards (async version).

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors
        """
        return await self.agenerate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["wcag"],
                format="json"
            )
        )

    def validate_pdfx(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/X (print production) standards.

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            with open("document.pdf", "rb") as f:
                pdf_data = f.read()

            result = client.compliance.validate_pdfx(pdf_data)

            if result.results[0].compliant:
                print("PDF/X compliant (print-ready)!")
            ```
        """
        return self.generate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfx"],
                format="json"
            )
        )

    async def avalidate_pdfx(self, pdf: bytes) -> ComplianceCertificateResponse:
        """Validate a PDF against PDF/X standards (async version).

        Args:
            pdf: PDF binary data

        Returns:
            Compliance validation result

        Raises:
            Html2PdfError: API errors
        """
        return await self.agenerate_certificate(
            ComplianceCertificateRequest(
                pdf=pdf,
                standards=["pdfx"],
                format="json"
            )
        )
