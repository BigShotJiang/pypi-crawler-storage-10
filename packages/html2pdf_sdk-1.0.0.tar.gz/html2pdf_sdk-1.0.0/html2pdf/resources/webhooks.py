"""Webhook management resource."""

import hashlib
import hmac
from typing import TYPE_CHECKING, Optional

from ..types import (
    WebhookConfig,
    WebhookConfigResponse,
    WebhookVerifyRequest,
    WebhookVerifyResponse,
)

if TYPE_CHECKING:
    from .._http import HttpClient


class WebhooksResource:
    """Webhook configuration and management operations."""

    def __init__(self, http: "HttpClient") -> None:
        """Initialize the webhooks resource.

        Args:
            http: HTTP client instance
        """
        self._http = http

    def create(self, config: WebhookConfig) -> WebhookConfigResponse:
        """Register a webhook configuration.

        Args:
            config: Webhook configuration

        Returns:
            WebhookConfigResponse with created webhook details

        Raises:
            ValidationError: Invalid webhook configuration
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import WebhookConfig

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            webhook = client.webhooks.create(WebhookConfig(
                url="https://myapp.com/webhooks/html2pdf",
                secret="your-secret-key-min-16-chars",
                events=["job.completed", "job.failed"],
                enabled=True
            ))

            print(f"Webhook created: {webhook.url}")
            ```
        """
        request_data = config.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/webhooks",
            json=request_data,
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    async def acreate(self, config: WebhookConfig) -> WebhookConfigResponse:
        """Register a webhook configuration (async version).

        Args:
            config: Webhook configuration

        Returns:
            WebhookConfigResponse with created webhook details

        Raises:
            ValidationError: Invalid webhook configuration
            Html2PdfError: Other API errors
        """
        request_data = config.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/webhooks",
            json=request_data,
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    def get(self) -> WebhookConfigResponse:
        """Get current webhook configuration.

        Returns:
            WebhookConfigResponse with webhook details

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            webhook = client.webhooks.get()
            print(f"Webhook URL: {webhook.url}")
            print(f"Events: {webhook.events}")
            ```
        """
        response_data = self._http.request(
            method="GET",
            path="/v1/webhooks",
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    async def aget(self) -> WebhookConfigResponse:
        """Get current webhook configuration (async version).

        Returns:
            WebhookConfigResponse with webhook details

        Raises:
            Html2PdfError: API errors
        """
        response_data = await self._http.arequest(
            method="GET",
            path="/v1/webhooks",
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    def update(self, config: WebhookConfig) -> WebhookConfigResponse:
        """Update webhook configuration.

        Args:
            config: Updated webhook configuration

        Returns:
            WebhookConfigResponse with updated webhook details

        Raises:
            ValidationError: Invalid webhook configuration
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf.types import WebhookConfig

            updated = client.webhooks.update(WebhookConfig(
                url="https://myapp.com/webhooks/html2pdf",
                secret="your-secret-key",
                events=["job.completed"],  # Only subscribe to completed events
                enabled=False  # Disable webhook
            ))
            ```
        """
        request_data = config.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="PATCH",
            path="/v1/webhooks",
            json=request_data,
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    async def aupdate(self, config: WebhookConfig) -> WebhookConfigResponse:
        """Update webhook configuration (async version).

        Args:
            config: Updated webhook configuration

        Returns:
            WebhookConfigResponse with updated webhook details

        Raises:
            ValidationError: Invalid webhook configuration
            Html2PdfError: Other API errors
        """
        request_data = config.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="PATCH",
            path="/v1/webhooks",
            json=request_data,
            response_type="json",
        )

        return WebhookConfigResponse.model_validate(response_data)

    def delete(self) -> None:
        """Delete webhook configuration.

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            client.webhooks.delete()
            ```
        """
        self._http.request(
            method="DELETE",
            path="/v1/webhooks",
            response_type="json",
        )

    async def adelete(self) -> None:
        """Delete webhook configuration (async version).

        Raises:
            Html2PdfError: API errors
        """
        await self._http.arequest(
            method="DELETE",
            path="/v1/webhooks",
            response_type="json",
        )

    def verify_signature(self, request: WebhookVerifyRequest) -> WebhookVerifyResponse:
        """Verify webhook signature via API.

        Args:
            request: Verification request with body, signature, and secret

        Returns:
            WebhookVerifyResponse with validation result

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            from html2pdf.types import WebhookVerifyRequest

            is_valid = client.webhooks.verify_signature(WebhookVerifyRequest(
                body='{"type":"job.completed","jobId":"job_123"}',
                signature="sha256=...",
                secret="your-secret-key"
            ))

            print(f"Valid: {is_valid.valid}")
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/webhooks/verify",
            json=request_data,
            response_type="json",
        )

        return WebhookVerifyResponse.model_validate(response_data)

    async def averify_signature(self, request: WebhookVerifyRequest) -> WebhookVerifyResponse:
        """Verify webhook signature via API (async version).

        Args:
            request: Verification request with body, signature, and secret

        Returns:
            WebhookVerifyResponse with validation result

        Raises:
            Html2PdfError: API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/webhooks/verify",
            json=request_data,
            response_type="json",
        )

        return WebhookVerifyResponse.model_validate(response_data)

    @staticmethod
    def verify_signature_local(body: str, signature: str, secret: str) -> bool:
        """Verify webhook signature locally (without API call).

        This is more efficient than calling the API for verification.

        Args:
            body: Raw request body string
            signature: Signature from x-webhook-signature header
            secret: Webhook secret

        Returns:
            True if signature is valid, False otherwise

        Example:
            ```python
            # In your webhook endpoint (e.g., Flask/FastAPI)
            from html2pdf import Html2PdfClient

            @app.post("/webhooks/html2pdf")
            def handle_webhook(request):
                signature = request.headers.get("x-webhook-signature")
                body = request.get_data(as_text=True)
                secret = "your-secret-key"

                is_valid = Html2PdfClient.webhooks.verify_signature_local(
                    body, signature, secret
                )

                if not is_valid:
                    return {"error": "Invalid signature"}, 401

                # Process webhook event
                event = request.get_json()
                print(f"Event: {event['type']}, Job: {event['jobId']}")

                return {"status": "ok"}
            ```
        """
        if not signature.startswith("sha256="):
            return False

        expected_signature = signature[7:]  # Remove "sha256=" prefix

        # Compute HMAC-SHA256
        computed_signature = hmac.new(
            secret.encode("utf-8"),
            body.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

        # Constant-time comparison
        return hmac.compare_digest(computed_signature, expected_signature)
