"""Rendering resource for synchronous and asynchronous PDF generation."""

import asyncio
import time
from typing import TYPE_CHECKING, Callable, Optional

from ..types import (
    AsyncRenderResponse,
    JobStatusResponse,
    RenderMetadata,
    RenderRequest,
    RenderResponse,
)

if TYPE_CHECKING:
    from .._http import HttpClient


class RenderResource:
    """Render operations (sync and async PDF generation)."""

    def __init__(self, http: "HttpClient") -> None:
        """Initialize the render resource.

        Args:
            http: HTTP client instance
        """
        self._http = http

    def create(self, request: RenderRequest) -> RenderResponse:
        """Render HTML or URL to PDF synchronously.

        Returns the PDF binary data immediately (max 5MB HTML, 30s timeout).

        Args:
            request: Rendering request with HTML/URL and options

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            ValidationError: Invalid request
            AuthenticationError: Authentication failed
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import RenderRequest, RenderOptions, Margins

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            result = client.render.create(RenderRequest(
                html="<h1>Hello World</h1>",
                options=RenderOptions(
                    page_size="A4",
                    margins=Margins(
                        top="1in",
                        right="1in",
                        bottom="1in",
                        left="1in"
                    )
                )
            ))

            print(f"Generated {result.metadata.pages} pages in {result.metadata.duration_ms}ms")

            with open("output.pdf", "wb") as f:
                f.write(result.pdf)
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/render",
            json=request_data,
            response_type="binary",
        )

        # TODO: Extract metadata from response headers if available
        # For now, create a minimal metadata object
        metadata = RenderMetadata(
            duration_ms=0,
            pages=0,
            warnings=[],
        )

        return RenderResponse(pdf=response_data, metadata=metadata)

    async def acreate(self, request: RenderRequest) -> RenderResponse:
        """Render HTML or URL to PDF synchronously (async version).

        Returns the PDF binary data immediately (max 5MB HTML, 30s timeout).

        Args:
            request: Rendering request with HTML/URL and options

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            ValidationError: Invalid request
            AuthenticationError: Authentication failed
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import AsyncHtml2PdfClient
            from html2pdf.types import RenderRequest, RenderOptions

            async with AsyncHtml2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            ) as client:
                result = await client.render.acreate(RenderRequest(
                    html="<h1>Hello World</h1>",
                    options=RenderOptions(page_size="A4")
                ))

                with open("output.pdf", "wb") as f:
                    f.write(result.pdf)
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/render",
            json=request_data,
            response_type="binary",
        )

        # TODO: Extract metadata from response headers if available
        metadata = RenderMetadata(
            duration_ms=0,
            pages=0,
            warnings=[],
        )

        return RenderResponse(pdf=response_data, metadata=metadata)

    def create_async(self, request: RenderRequest) -> AsyncRenderResponse:
        """Submit an async rendering job.

        Returns a job ID for polling status. Use this for large documents
        or complex pages that may take longer than 30 seconds.

        Args:
            request: Rendering request with HTML/URL and options

        Returns:
            AsyncRenderResponse with job ID and status URL

        Raises:
            ValidationError: Invalid request
            AuthenticationError: Authentication failed
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import RenderRequest, RenderOptions

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            # Submit the job
            job = client.render.create_async(RenderRequest(
                url="https://example.com/large-report",
                options=RenderOptions(
                    page_size="Letter",
                    display_header_footer=True,
                    header_template='<div style="font-size: 10px;">Report Header</div>',
                    footer_template='<div>Page <span class="pageNumber"></span></div>'
                )
            ))

            print(f"Job created: {job.job_id}")

            # Poll for completion
            while True:
                status = client.render.get_status(job.job_id)
                if status.status == "succeeded":
                    pdf = client.render.download(job.job_id)
                    with open("output.pdf", "wb") as f:
                        f.write(pdf)
                    break
                elif status.status == "failed":
                    print(f"Render failed: {status.error.message}")
                    break
                time.sleep(1)
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/render-async",
            json=request_data,
            response_type="json",
        )

        return AsyncRenderResponse.model_validate(response_data)

    async def acreate_async(self, request: RenderRequest) -> AsyncRenderResponse:
        """Submit an async rendering job (async version).

        Returns a job ID for polling status. Use this for large documents
        or complex pages that may take longer than 30 seconds.

        Args:
            request: Rendering request with HTML/URL and options

        Returns:
            AsyncRenderResponse with job ID and status URL

        Raises:
            ValidationError: Invalid request
            AuthenticationError: Authentication failed
            Html2PdfError: Other API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/render-async",
            json=request_data,
            response_type="json",
        )

        return AsyncRenderResponse.model_validate(response_data)

    def get_status(self, job_id: str) -> JobStatusResponse:
        """Get the status of an async render job.

        Args:
            job_id: Job ID from create_async()

        Returns:
            JobStatusResponse with current status

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            status = client.render.get_status("job_123")
            print(f"Status: {status.status}")

            if status.status == "succeeded":
                print(f"Download: {status.download_url}")
            elif status.status == "failed":
                print(f"Error: {status.error.message}")
            ```
        """
        response_data = self._http.request(
            method="GET",
            path=f"/v1/status/{job_id}",
            response_type="json",
        )

        return JobStatusResponse.model_validate(response_data)

    async def aget_status(self, job_id: str) -> JobStatusResponse:
        """Get the status of an async render job (async version).

        Args:
            job_id: Job ID from acreate_async()

        Returns:
            JobStatusResponse with current status

        Raises:
            Html2PdfError: API errors
        """
        response_data = await self._http.arequest(
            method="GET",
            path=f"/v1/status/{job_id}",
            response_type="json",
        )

        return JobStatusResponse.model_validate(response_data)

    def download(self, job_id: str) -> bytes:
        """Download the PDF for a completed job.

        Args:
            job_id: Job ID from create_async()

        Returns:
            PDF binary data

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            pdf = client.render.download("job_123")
            with open("output.pdf", "wb") as f:
                f.write(pdf)
            ```
        """
        # Get status first to get download URL
        status = self.get_status(job_id)

        if not status.download_url:
            raise ValueError(f"Job {job_id} does not have a download URL (status: {status.status})")

        # Download from the URL
        # Extract path from download URL
        from urllib.parse import urlparse
        parsed = urlparse(status.download_url)
        path = parsed.path

        return self._http.request(
            method="GET",
            path=path,
            response_type="binary",
        )

    async def adownload(self, job_id: str) -> bytes:
        """Download the PDF for a completed job (async version).

        Args:
            job_id: Job ID from acreate_async()

        Returns:
            PDF binary data

        Raises:
            Html2PdfError: API errors
        """
        # Get status first to get download URL
        status = await self.aget_status(job_id)

        if not status.download_url:
            raise ValueError(f"Job {job_id} does not have a download URL (status: {status.status})")

        # Download from the URL
        from urllib.parse import urlparse
        parsed = urlparse(status.download_url)
        path = parsed.path

        return await self._http.arequest(
            method="GET",
            path=path,
            response_type="binary",
        )

    def download_debug(self, job_id: str) -> bytes:
        """Download the debug bundle for a job (if debug=true).

        Args:
            job_id: Job ID from create_async()

        Returns:
            Debug ZIP bundle binary data

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            debug_zip = client.render.download_debug("job_123")
            with open("debug.zip", "wb") as f:
                f.write(debug_zip)
            ```
        """
        status = self.get_status(job_id)

        if not status.debug_url:
            raise ValueError(f"Job {job_id} does not have a debug URL (debug may not be enabled)")

        from urllib.parse import urlparse
        parsed = urlparse(status.debug_url)
        path = parsed.path

        return self._http.request(
            method="GET",
            path=path,
            response_type="binary",
        )

    async def adownload_debug(self, job_id: str) -> bytes:
        """Download the debug bundle for a job (async version).

        Args:
            job_id: Job ID from acreate_async()

        Returns:
            Debug ZIP bundle binary data

        Raises:
            Html2PdfError: API errors
        """
        status = await self.aget_status(job_id)

        if not status.debug_url:
            raise ValueError(f"Job {job_id} does not have a debug URL (debug may not be enabled)")

        from urllib.parse import urlparse
        parsed = urlparse(status.debug_url)
        path = parsed.path

        return await self._http.arequest(
            method="GET",
            path=path,
            response_type="binary",
        )

    def render_and_wait(
        self,
        request: RenderRequest,
        poll_interval: float = 1.0,
        max_wait_time: float = 300.0,
        on_progress: Optional[Callable[[JobStatusResponse], None]] = None,
    ) -> RenderResponse:
        """Submit an async job and wait for completion (simplified async rendering).

        Args:
            request: Rendering request
            poll_interval: Polling interval in seconds
            max_wait_time: Maximum wait time in seconds
            on_progress: Optional callback for progress updates

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            TimeoutError: Job did not complete within max_wait_time
            Html2PdfError: Rendering failed or other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import RenderRequest, RenderOptions

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            result = client.render.render_and_wait(
                RenderRequest(
                    url="https://example.com",
                    options=RenderOptions(page_size="A4")
                ),
                on_progress=lambda status: print(f"Status: {status.status}")
            )

            with open("output.pdf", "wb") as f:
                f.write(result.pdf)
            ```
        """
        # Submit the job
        job = self.create_async(request)

        start_time = time.time()

        # Poll for completion
        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait_time:
                from ..errors import TimeoutError
                raise TimeoutError(f"Job {job.job_id} did not complete within {max_wait_time}s")

            status = self.get_status(job.job_id)

            if on_progress:
                on_progress(status)

            if status.status == "succeeded":
                # Download the PDF
                pdf = self.download(job.job_id)
                return RenderResponse(
                    pdf=pdf,
                    metadata=status.meta or RenderMetadata(duration_ms=0, pages=0, warnings=[]),
                )
            elif status.status == "failed":
                from ..errors import Html2PdfError
                error_msg = status.error.message if status.error else "Unknown error"
                raise Html2PdfError(f"Rendering failed: {error_msg}")

            # Wait before next poll
            time.sleep(poll_interval)

    async def arender_and_wait(
        self,
        request: RenderRequest,
        poll_interval: float = 1.0,
        max_wait_time: float = 300.0,
        on_progress: Optional[Callable[[JobStatusResponse], None]] = None,
    ) -> RenderResponse:
        """Submit an async job and wait for completion (async version).

        Args:
            request: Rendering request
            poll_interval: Polling interval in seconds
            max_wait_time: Maximum wait time in seconds
            on_progress: Optional callback for progress updates

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            TimeoutError: Job did not complete within max_wait_time
            Html2PdfError: Rendering failed or other API errors

        Example:
            ```python
            from html2pdf import AsyncHtml2PdfClient
            from html2pdf.types import RenderRequest, RenderOptions

            async with AsyncHtml2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            ) as client:
                result = await client.render.arender_and_wait(
                    RenderRequest(
                        url="https://example.com",
                        options=RenderOptions(page_size="A4")
                    ),
                    on_progress=lambda status: print(f"Status: {status.status}")
                )

                with open("output.pdf", "wb") as f:
                    f.write(result.pdf)
            ```
        """
        # Submit the job
        job = await self.acreate_async(request)

        start_time = time.time()

        # Poll for completion
        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait_time:
                from ..errors import TimeoutError
                raise TimeoutError(f"Job {job.job_id} did not complete within {max_wait_time}s")

            status = await self.aget_status(job.job_id)

            if on_progress:
                on_progress(status)

            if status.status == "succeeded":
                # Download the PDF
                pdf = await self.adownload(job.job_id)
                return RenderResponse(
                    pdf=pdf,
                    metadata=status.meta or RenderMetadata(duration_ms=0, pages=0, warnings=[]),
                )
            elif status.status == "failed":
                from ..errors import Html2PdfError
                error_msg = status.error.message if status.error else "Unknown error"
                raise Html2PdfError(f"Rendering failed: {error_msg}")

            # Wait before next poll
            await asyncio.sleep(poll_interval)
