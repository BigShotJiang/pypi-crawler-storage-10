"""Batch processing resource for rendering multiple PDFs."""

import asyncio
import time
from typing import TYPE_CHECKING, Callable, List, Optional

from ..types import (
    BatchRequest,
    BatchResponse,
    BatchStatusResponse,
    BulkStatusRequest,
    BulkStatusResponse,
)

if TYPE_CHECKING:
    from .._http import HttpClient


class BatchResource:
    """Batch processing operations for rendering multiple PDFs."""

    def __init__(self, http: "HttpClient") -> None:
        """Initialize the batch resource.

        Args:
            http: HTTP client instance
        """
        self._http = http

    def create(self, request: BatchRequest) -> BatchResponse:
        """Create a batch rendering job.

        Args:
            request: Batch request with items to render (max 100)

        Returns:
            BatchResponse with batch ID and status URL

        Raises:
            ValidationError: Invalid request
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import BatchRequest, BatchItem

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            batch = client.batch.create(BatchRequest(
                items=[
                    BatchItem(
                        mode="html",
                        html="<h1>Document 1</h1>",
                        item_id="doc1"
                    ),
                    BatchItem(
                        mode="url",
                        url="https://example.com/page1",
                        item_id="doc2"
                    )
                ]
            ))

            print(f"Batch created: {batch.batch_id}")
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/batch",
            json=request_data,
            response_type="json",
        )

        return BatchResponse.model_validate(response_data)

    async def acreate(self, request: BatchRequest) -> BatchResponse:
        """Create a batch rendering job (async version).

        Args:
            request: Batch request with items to render (max 100)

        Returns:
            BatchResponse with batch ID and status URL

        Raises:
            ValidationError: Invalid request
            Html2PdfError: Other API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/batch",
            json=request_data,
            response_type="json",
        )

        return BatchResponse.model_validate(response_data)

    def get_status(self, batch_id: str) -> BatchStatusResponse:
        """Get the status of a batch job.

        Args:
            batch_id: Batch ID from create()

        Returns:
            BatchStatusResponse with batch status and item statuses

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            status = client.batch.get_status("batch_123")
            print(f"Progress: {status.completed}/{status.total} ({status.failed} failed)")
            ```
        """
        response_data = self._http.request(
            method="GET",
            path=f"/v1/batch/{batch_id}",
            response_type="json",
        )

        return BatchStatusResponse.model_validate(response_data)

    async def aget_status(self, batch_id: str) -> BatchStatusResponse:
        """Get the status of a batch job (async version).

        Args:
            batch_id: Batch ID from acreate()

        Returns:
            BatchStatusResponse with batch status and item statuses

        Raises:
            Html2PdfError: API errors
        """
        response_data = await self._http.arequest(
            method="GET",
            path=f"/v1/batch/{batch_id}",
            response_type="json",
        )

        return BatchStatusResponse.model_validate(response_data)

    def cancel(self, batch_id: str) -> None:
        """Cancel a batch job.

        Args:
            batch_id: Batch ID from create()

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            client.batch.cancel("batch_123")
            ```
        """
        self._http.request(
            method="DELETE",
            path=f"/v1/batch/{batch_id}",
            response_type="json",
        )

    async def acancel(self, batch_id: str) -> None:
        """Cancel a batch job (async version).

        Args:
            batch_id: Batch ID from acreate()

        Raises:
            Html2PdfError: API errors
        """
        await self._http.arequest(
            method="DELETE",
            path=f"/v1/batch/{batch_id}",
            response_type="json",
        )

    def download_zip(self, batch_id: str) -> bytes:
        """Download all PDFs in a batch as a ZIP file.

        Args:
            batch_id: Batch ID from create()

        Returns:
            ZIP file binary data

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            zip_data = client.batch.download_zip("batch_123")
            with open("batch-results.zip", "wb") as f:
                f.write(zip_data)
            ```
        """
        # Get status to get download URL
        status = self.get_status(batch_id)

        if not status.download_url:
            raise ValueError(
                f"Batch {batch_id} does not have a download URL (status: {status.status})"
            )

        from urllib.parse import urlparse
        parsed = urlparse(status.download_url)
        path = parsed.path

        return self._http.request(
            method="GET",
            path=path,
            response_type="binary",
        )

    async def adownload_zip(self, batch_id: str) -> bytes:
        """Download all PDFs in a batch as a ZIP file (async version).

        Args:
            batch_id: Batch ID from acreate()

        Returns:
            ZIP file binary data

        Raises:
            Html2PdfError: API errors
        """
        status = await self.aget_status(batch_id)

        if not status.download_url:
            raise ValueError(
                f"Batch {batch_id} does not have a download URL (status: {status.status})"
            )

        from urllib.parse import urlparse
        parsed = urlparse(status.download_url)
        path = parsed.path

        return await self._http.arequest(
            method="GET",
            path=path,
            response_type="binary",
        )

    def create_from_csv(self, csv_data: str) -> BatchResponse:
        """Create a batch from CSV data.

        Args:
            csv_data: CSV string with columns: mode,html,url,itemId

        Returns:
            BatchResponse with batch ID and status URL

        Raises:
            ValidationError: Invalid CSV data
            Html2PdfError: Other API errors

        Example:
            ```python
            csv_data = '''
            mode,html,url,itemId
            html,"<h1>Doc 1</h1>",,doc1
            url,,https://example.com,doc2
            '''

            batch = client.batch.create_from_csv(csv_data)
            ```
        """
        response_data = self._http.request(
            method="POST",
            path="/v1/batch/csv",
            content=csv_data.encode("utf-8"),
            headers={"Content-Type": "text/csv"},
            response_type="json",
        )

        return BatchResponse.model_validate(response_data)

    async def acreate_from_csv(self, csv_data: str) -> BatchResponse:
        """Create a batch from CSV data (async version).

        Args:
            csv_data: CSV string with columns: mode,html,url,itemId

        Returns:
            BatchResponse with batch ID and status URL

        Raises:
            ValidationError: Invalid CSV data
            Html2PdfError: Other API errors
        """
        response_data = await self._http.arequest(
            method="POST",
            path="/v1/batch/csv",
            content=csv_data.encode("utf-8"),
            headers={"Content-Type": "text/csv"},
            response_type="json",
        )

        return BatchResponse.model_validate(response_data)

    def bulk_status(self, request: BulkStatusRequest) -> BulkStatusResponse:
        """Check status of multiple jobs at once.

        Args:
            request: Bulk status request with job IDs (max 100)

        Returns:
            BulkStatusResponse with status for each job

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            from html2pdf.types import BulkStatusRequest

            statuses = client.batch.bulk_status(BulkStatusRequest(
                job_ids=["job_1", "job_2", "job_3"]
            ))

            for job_id, status in statuses.jobs.items():
                print(f"{job_id}: {status.status}")
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/status/bulk",
            json=request_data,
            response_type="json",
        )

        return BulkStatusResponse.model_validate(response_data)

    async def abulk_status(self, request: BulkStatusRequest) -> BulkStatusResponse:
        """Check status of multiple jobs at once (async version).

        Args:
            request: Bulk status request with job IDs (max 100)

        Returns:
            BulkStatusResponse with status for each job

        Raises:
            Html2PdfError: API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/status/bulk",
            json=request_data,
            response_type="json",
        )

        return BulkStatusResponse.model_validate(response_data)

    def wait_for_completion(
        self,
        batch_id: str,
        poll_interval: float = 2.0,
        max_wait_time: float = 600.0,
        on_progress: Optional[Callable[[BatchStatusResponse], None]] = None,
    ) -> BatchStatusResponse:
        """Wait for a batch to complete.

        Args:
            batch_id: Batch ID from create()
            poll_interval: Polling interval in seconds
            max_wait_time: Maximum wait time in seconds
            on_progress: Optional callback for progress updates

        Returns:
            Final BatchStatusResponse

        Raises:
            TimeoutError: Batch did not complete within max_wait_time
            Html2PdfError: Other API errors

        Example:
            ```python
            result = client.batch.wait_for_completion(
                "batch_123",
                on_progress=lambda s: print(f"{s.completed}/{s.total} complete")
            )

            if result.status == "completed":
                zip_data = client.batch.download_zip(batch_id)
            ```
        """
        start_time = time.time()

        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait_time:
                from ..errors import TimeoutError
                raise TimeoutError(
                    f"Batch {batch_id} did not complete within {max_wait_time}s"
                )

            status = self.get_status(batch_id)

            if on_progress:
                on_progress(status)

            if status.status in ("completed", "failed"):
                return status

            time.sleep(poll_interval)

    async def await_for_completion(
        self,
        batch_id: str,
        poll_interval: float = 2.0,
        max_wait_time: float = 600.0,
        on_progress: Optional[Callable[[BatchStatusResponse], None]] = None,
    ) -> BatchStatusResponse:
        """Wait for a batch to complete (async version).

        Args:
            batch_id: Batch ID from acreate()
            poll_interval: Polling interval in seconds
            max_wait_time: Maximum wait time in seconds
            on_progress: Optional callback for progress updates

        Returns:
            Final BatchStatusResponse

        Raises:
            TimeoutError: Batch did not complete within max_wait_time
            Html2PdfError: Other API errors
        """
        start_time = time.time()

        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait_time:
                from ..errors import TimeoutError
                raise TimeoutError(
                    f"Batch {batch_id} did not complete within {max_wait_time}s"
                )

            status = await self.aget_status(batch_id)

            if on_progress:
                on_progress(status)

            if status.status in ("completed", "failed"):
                return status

            await asyncio.sleep(poll_interval)
