"""Template rendering resource."""

from typing import TYPE_CHECKING, Any, Dict

from ..types import (
    RenderOptions,
    RenderResponse,
    TemplateRenderRequest,
    TemplateValidateRequest,
    TemplateValidationResponse,
)

if TYPE_CHECKING:
    from .._http import HttpClient


class TemplatesResource:
    """Template-based PDF rendering operations."""

    def __init__(self, http: "HttpClient") -> None:
        """Initialize the templates resource.

        Args:
            http: HTTP client instance
        """
        self._http = http

    def render(self, request: TemplateRenderRequest) -> RenderResponse:
        """Render a PDF using a pre-built template.

        Args:
            request: Template rendering request with template ID and data

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            ValidationError: Invalid template or data
            Html2PdfError: Other API errors

        Example:
            ```python
            from html2pdf import Html2PdfClient
            from html2pdf.types import TemplateRenderRequest, RenderOptions

            client = Html2PdfClient(
                base_url="https://api.html2pdf.example.com",
                api_key="your-api-key"
            )

            result = client.templates.render(TemplateRenderRequest(
                template="invoice",
                data={
                    "invoiceNumber": "INV-001",
                    "date": "2024-01-15",
                    "customerName": "John Doe",
                    "items": [
                        {
                            "description": "Consulting Services",
                            "quantity": 10,
                            "price": 150,
                            "total": 1500
                        }
                    ],
                    "subtotal": 1500,
                    "tax": 150,
                    "total": 1650
                },
                options=RenderOptions(
                    page_size="A4",
                    print_background=True
                )
            ))

            with open("invoice.pdf", "wb") as f:
                f.write(result.pdf)
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/templates/render",
            json=request_data,
            response_type="binary",
        )

        from ..types import RenderMetadata
        metadata = RenderMetadata(duration_ms=0, pages=0, warnings=[])

        return RenderResponse(pdf=response_data, metadata=metadata)

    async def arender(self, request: TemplateRenderRequest) -> RenderResponse:
        """Render a PDF using a pre-built template (async version).

        Args:
            request: Template rendering request with template ID and data

        Returns:
            RenderResponse with PDF data and metadata

        Raises:
            ValidationError: Invalid template or data
            Html2PdfError: Other API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/templates/render",
            json=request_data,
            response_type="binary",
        )

        from ..types import RenderMetadata
        metadata = RenderMetadata(duration_ms=0, pages=0, warnings=[])

        return RenderResponse(pdf=response_data, metadata=metadata)

    def validate(self, request: TemplateValidateRequest) -> TemplateValidationResponse:
        """Validate template data against schema.

        Args:
            request: Template validation request

        Returns:
            TemplateValidationResponse with validation results

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            from html2pdf.types import TemplateValidateRequest

            validation = client.templates.validate(TemplateValidateRequest(
                template="invoice",
                data={"invoiceNumber": "INV-001"}
            ))

            if not validation.valid:
                print("Validation errors:", validation.errors)
            ```
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = self._http.request(
            method="POST",
            path="/v1/templates/validate",
            json=request_data,
            response_type="json",
        )

        return TemplateValidationResponse.model_validate(response_data)

    async def avalidate(self, request: TemplateValidateRequest) -> TemplateValidationResponse:
        """Validate template data against schema (async version).

        Args:
            request: Template validation request

        Returns:
            TemplateValidationResponse with validation results

        Raises:
            Html2PdfError: API errors
        """
        request_data = request.model_dump(by_alias=True, exclude_none=True)

        response_data = await self._http.arequest(
            method="POST",
            path="/v1/templates/validate",
            json=request_data,
            response_type="json",
        )

        return TemplateValidationResponse.model_validate(response_data)

    def preview(self, template: str, data: Dict[str, Any]) -> str:
        """Preview the rendered HTML for a template (without generating PDF).

        Args:
            template: Template ID or type
            data: Template data/variables

        Returns:
            Rendered HTML string

        Raises:
            Html2PdfError: API errors

        Example:
            ```python
            html = client.templates.preview(
                template="certificate",
                data={
                    "name": "John Doe",
                    "achievement": "Course Completion",
                    "date": "2024-01-15"
                }
            )
            print(html)
            ```
        """
        response_data = self._http.request(
            method="POST",
            path="/v1/templates/preview",
            json={"template": template, "data": data},
            response_type="text",
        )

        return response_data

    async def apreview(self, template: str, data: Dict[str, Any]) -> str:
        """Preview the rendered HTML for a template (async version).

        Args:
            template: Template ID or type
            data: Template data/variables

        Returns:
            Rendered HTML string

        Raises:
            Html2PdfError: API errors
        """
        response_data = await self._http.arequest(
            method="POST",
            path="/v1/templates/preview",
            json={"template": template, "data": data},
            response_type="text",
        )

        return response_data
