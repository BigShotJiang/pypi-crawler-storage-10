"""Resource modules for html2pdf SDK."""

from .batch import BatchResource
from .compliance import ComplianceResource
from .render import RenderResource
from .templates import TemplatesResource
from .webhooks import WebhooksResource

__all__ = [
    "RenderResource",
    "BatchResource",
    "TemplatesResource",
    "WebhooksResource",
    "ComplianceResource",
]
