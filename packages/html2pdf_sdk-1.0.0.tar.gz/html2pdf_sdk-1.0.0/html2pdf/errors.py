"""Custom exception classes for html2pdf SDK."""

from typing import Any, Optional


class Html2PdfError(Exception):
    """Base exception for all html2pdf SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        code: Optional[str] = None,
        details: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.details = details

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class ValidationError(Html2PdfError):
    """Raised when request validation fails (HTTP 400)."""

    def __init__(self, message: str, details: Optional[Any] = None) -> None:
        super().__init__(
            message=message,
            status_code=400,
            code="VALIDATION_ERROR",
            details=details,
        )


class AuthenticationError(Html2PdfError):
    """Raised when authentication fails (HTTP 401)."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(
            message=message,
            status_code=401,
            code="AUTHENTICATION_ERROR",
        )


class RateLimitError(Html2PdfError):
    """Raised when rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__(
            message=message,
            status_code=429,
            code="RATE_LIMIT_ERROR",
        )


class TimeoutError(Html2PdfError):
    """Raised when request times out (HTTP 408)."""

    def __init__(self, message: str = "Request timeout") -> None:
        super().__init__(
            message=message,
            status_code=408,
            code="TIMEOUT_ERROR",
        )


class NetworkError(Html2PdfError):
    """Raised when a network error occurs."""

    def __init__(self, message: str) -> None:
        super().__init__(
            message=message,
            code="NETWORK_ERROR",
        )
