"""HTTP client with retry logic and error handling for html2pdf SDK."""

import asyncio
import time
from typing import Any, Dict, Literal, Optional, Union
from urllib.parse import urljoin

import httpx

from .errors import (
    AuthenticationError,
    Html2PdfError,
    NetworkError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)


class HttpClient:
    """HTTP client for making requests to the html2pdf API.

    Supports both synchronous and asynchronous requests with automatic retries.
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize the HTTP client.

        Args:
            base_url: Base URL of the html2pdf service
            api_key: API key for authentication
            access_token: JWT access token for authentication (alternative to API key)
            timeout: Request timeout in seconds
            max_retries: Maximum number of retries for failed requests
            headers: Custom headers to include in all requests
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self.timeout = timeout
        self.max_retries = max_retries
        self.custom_headers = headers or {}

        # Create sync client
        self._sync_client = httpx.Client(
            timeout=httpx.Timeout(timeout),
            follow_redirects=True,
        )

        # Async client will be created lazily
        self._async_client: Optional[httpx.AsyncClient] = None

    def _get_async_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                follow_redirects=True,
            )
        return self._async_client

    def _build_headers(self, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Build request headers with authentication."""
        headers = {**self.custom_headers}

        # Add authentication
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        elif self.api_key:
            headers["X-API-Key"] = self.api_key

        # Add extra headers
        if extra_headers:
            headers.update(extra_headers)

        return headers

    def _build_url(self, path: str) -> str:
        """Build full URL from path."""
        return urljoin(self.base_url + "/", path.lstrip("/"))

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Handle error responses and raise appropriate exceptions."""
        try:
            error_body = response.json()
            message = error_body.get("error") or error_body.get("message") or response.text
            code = error_body.get("code")
        except Exception:
            message = response.text or response.reason_phrase
            code = None
            error_body = {}

        status_code = response.status_code

        if status_code == 401:
            raise AuthenticationError(message or "Authentication failed")
        elif status_code == 429:
            raise RateLimitError(message or "Rate limit exceeded")
        elif status_code == 400:
            raise ValidationError(message or "Validation failed", details=error_body)
        elif status_code == 408:
            raise TimeoutError(message or "Request timeout")
        else:
            raise Html2PdfError(message, status_code=status_code, code=code)

    def _get_retry_delay(self, retry_count: int) -> float:
        """Calculate retry delay with exponential backoff."""
        return min(1.0 * (2 ** retry_count), 8.0)

    def request(
        self,
        method: Literal["GET", "POST", "PATCH", "DELETE", "PUT"],
        path: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Any] = None,
        content: Optional[bytes] = None,
        timeout: Optional[float] = None,
        response_type: Literal["json", "binary", "text"] = "json",
    ) -> Any:
        """Make a synchronous HTTP request.

        Args:
            method: HTTP method
            path: Request path (relative to base_url)
            headers: Additional headers
            json: JSON body
            content: Binary content
            timeout: Request timeout (overrides default)
            response_type: Expected response type

        Returns:
            Response data based on response_type

        Raises:
            Html2PdfError: On HTTP errors
            NetworkError: On network/connection errors
        """
        url = self._build_url(path)
        request_headers = self._build_headers(headers)

        retry_count = 0
        last_exception: Optional[Exception] = None

        while retry_count <= self.max_retries:
            try:
                response = self._sync_client.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    json=json,
                    content=content,
                    timeout=timeout or self.timeout,
                )

                # Check for retry-able status codes
                if retry_count < self.max_retries and (
                    response.status_code >= 500 or response.status_code == 429
                ):
                    delay = self._get_retry_delay(retry_count)
                    time.sleep(delay)
                    retry_count += 1
                    continue

                # Handle error responses
                if not response.is_success:
                    self._handle_error_response(response)

                # Parse response based on type
                if response_type == "binary":
                    return response.content
                elif response_type == "text":
                    return response.text
                else:  # json
                    if not response.text:
                        return {}
                    return response.json()

            except (httpx.ConnectError, httpx.NetworkError, httpx.TimeoutException) as e:
                last_exception = e
                if retry_count < self.max_retries:
                    delay = self._get_retry_delay(retry_count)
                    time.sleep(delay)
                    retry_count += 1
                    continue
                raise NetworkError(f"Request failed: {str(e)}") from e
            except Html2PdfError:
                raise
            except Exception as e:
                raise NetworkError(f"Unexpected error: {str(e)}") from e

        # If we get here, we've exhausted retries
        raise NetworkError(f"Request failed after {self.max_retries} retries: {str(last_exception)}")

    async def arequest(
        self,
        method: Literal["GET", "POST", "PATCH", "DELETE", "PUT"],
        path: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Any] = None,
        content: Optional[bytes] = None,
        timeout: Optional[float] = None,
        response_type: Literal["json", "binary", "text"] = "json",
    ) -> Any:
        """Make an asynchronous HTTP request.

        Args:
            method: HTTP method
            path: Request path (relative to base_url)
            headers: Additional headers
            json: JSON body
            content: Binary content
            timeout: Request timeout (overrides default)
            response_type: Expected response type

        Returns:
            Response data based on response_type

        Raises:
            Html2PdfError: On HTTP errors
            NetworkError: On network/connection errors
        """
        url = self._build_url(path)
        request_headers = self._build_headers(headers)
        client = self._get_async_client()

        retry_count = 0
        last_exception: Optional[Exception] = None

        while retry_count <= self.max_retries:
            try:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    json=json,
                    content=content,
                    timeout=timeout or self.timeout,
                )

                # Check for retry-able status codes
                if retry_count < self.max_retries and (
                    response.status_code >= 500 or response.status_code == 429
                ):
                    delay = self._get_retry_delay(retry_count)
                    await asyncio.sleep(delay)
                    retry_count += 1
                    continue

                # Handle error responses
                if not response.is_success:
                    self._handle_error_response(response)

                # Parse response based on type
                if response_type == "binary":
                    return response.content
                elif response_type == "text":
                    return response.text
                else:  # json
                    if not response.text:
                        return {}
                    return response.json()

            except (httpx.ConnectError, httpx.NetworkError, httpx.TimeoutException) as e:
                last_exception = e
                if retry_count < self.max_retries:
                    delay = self._get_retry_delay(retry_count)
                    await asyncio.sleep(delay)
                    retry_count += 1
                    continue
                raise NetworkError(f"Request failed: {str(e)}") from e
            except Html2PdfError:
                raise
            except Exception as e:
                raise NetworkError(f"Unexpected error: {str(e)}") from e

        # If we get here, we've exhausted retries
        raise NetworkError(f"Request failed after {self.max_retries} retries: {str(last_exception)}")

    def close(self) -> None:
        """Close the sync HTTP client."""
        self._sync_client.close()

    async def aclose(self) -> None:
        """Close the async HTTP client."""
        if self._async_client is not None:
            await self._async_client.aclose()

    def __enter__(self) -> "HttpClient":
        """Context manager support."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager support."""
        self.close()

    async def __aenter__(self) -> "HttpClient":
        """Async context manager support."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager support."""
        await self.aclose()
