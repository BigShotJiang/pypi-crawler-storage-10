"""Type definitions and Pydantic models for html2pdf SDK."""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator


# ============================================================================
# Enums
# ============================================================================

class PageSizeEnum(str, Enum):
    """Standard page sizes."""
    A4 = "A4"
    LETTER = "Letter"
    LEGAL = "Legal"
    A3 = "A3"
    A5 = "A5"
    TABLOID = "Tabloid"


class ComplianceStandard(str, Enum):
    """PDF compliance standards."""
    PDFA_2 = "pdfa-2"
    PDFA_3 = "pdfa-3"
    PDFX_1A = "pdfx-1a"
    PDFX_3 = "pdfx-3"
    PDFX_4 = "pdfx-4"


class AttachmentRelationship(str, Enum):
    """PDF/A-3 attachment relationship types."""
    SOURCE = "Source"
    DATA = "Data"
    ALTERNATIVE = "Alternative"
    SUPPLEMENT = "Supplement"
    UNSPECIFIED = "Unspecified"


class JobStatus(str, Enum):
    """Status of a rendering job."""
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class BatchJobStatus(str, Enum):
    """Status of a batch job."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class ErrorCode(str, Enum):
    """Error codes for failed jobs."""
    RENDER_ERROR = "RENDER_ERROR"
    RENDER_TIMEOUT = "RENDER_TIMEOUT"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    STORAGE_ERROR = "STORAGE_ERROR"


class AuthMode(str, Enum):
    """Authentication mode for URL rendering."""
    SNAPSHOT = "snapshot"
    SESSION = "session"


class WebhookEvent(str, Enum):
    """Webhook event types."""
    JOB_COMPLETED = "job.completed"
    JOB_FAILED = "job.failed"
    BATCH_COMPLETED = "batch.completed"
    BATCH_FAILED = "batch.failed"


class TemplateType(str, Enum):
    """Available template types."""
    INVOICE = "invoice"
    RECEIPT = "receipt"
    REPORT = "report"
    CERTIFICATE = "certificate"
    LETTER = "letter"


class IssueSeverity(str, Enum):
    """Compliance issue severity."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class PlanTier(str, Enum):
    """Subscription plan tiers."""
    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


# ============================================================================
# Configuration Models
# ============================================================================

class CustomPageSize(BaseModel):
    """Custom page dimensions."""
    width: str = Field(..., description="Page width (e.g., '8.5in', '210mm')")
    height: str = Field(..., description="Page height (e.g., '11in', '297mm')")


class Margins(BaseModel):
    """Page margins."""
    top: str = Field(..., description="Top margin (e.g., '1in', '25mm')")
    right: str = Field(..., description="Right margin")
    bottom: str = Field(..., description="Bottom margin")
    left: str = Field(..., description="Left margin")


class PDFAttachment(BaseModel):
    """PDF attachment for PDF/A-3."""
    filename: str = Field(..., description="Filename of the attachment")
    content: str = Field(..., description="Base64-encoded content")
    description: Optional[str] = Field(None, description="Description of the attachment")
    mime_type: Optional[str] = Field(None, alias="mimeType", description="MIME type")
    relationship: Optional[AttachmentRelationship] = Field(
        None,
        description="Relationship type for PDF/A-3"
    )


class DigitalSignature(BaseModel):
    """Digital signature configuration."""
    certificate: str = Field(..., description="Base64-encoded PKCS#12 certificate")
    password: str = Field(..., description="Password for the certificate")
    reason: Optional[str] = Field(None, description="Reason for signing")
    contact_info: Optional[str] = Field(None, alias="contactInfo", description="Contact information")
    location: Optional[str] = Field(None, description="Location of signing")
    name: Optional[str] = Field(None, description="Name of the signer")


class RenderOptions(BaseModel):
    """Rendering options for PDF generation."""
    page_size: Optional[Union[PageSizeEnum, CustomPageSize]] = Field(
        None,
        alias="pageSize",
        description="Page size (preset or custom dimensions)"
    )
    margins: Optional[Margins] = Field(None, description="Page margins")
    margin_preset: Optional[str] = Field(None, alias="marginPreset", description="Margin preset name")
    scale: Optional[float] = Field(None, ge=0.1, le=2.0, description="Render scale factor")
    print_background: Optional[bool] = Field(None, alias="printBackground", description="Print background graphics")
    display_header_footer: Optional[bool] = Field(None, alias="displayHeaderFooter", description="Display header and footer")
    header_template: Optional[str] = Field(None, alias="headerTemplate", description="HTML template for header")
    footer_template: Optional[str] = Field(None, alias="footerTemplate", description="HTML template for footer")
    prefer_css_page_rules: Optional[bool] = Field(None, alias="preferCSSPageRules", description="Prefer CSS @page rules")
    timeout_ms: Optional[int] = Field(None, alias="timeoutMs", ge=1000, le=120000, description="Page load timeout in ms")
    compliance: Optional[ComplianceStandard] = Field(None, description="PDF compliance standard")
    debug: Optional[bool] = Field(None, description="Generate debug bundle")
    i18n_fonts: Optional[bool] = Field(None, alias="i18nFonts", description="Inject internationalization fonts")
    attachments: Optional[List[PDFAttachment]] = Field(None, description="PDF/A-3 attachments")
    signature: Optional[DigitalSignature] = Field(None, description="Digital signature configuration")
    landscape: Optional[bool] = Field(None, description="Landscape orientation")

    model_config = ConfigDict(populate_by_name=True)


class RenderAuth(BaseModel):
    """Authentication configuration for URL rendering."""
    mode: Optional[AuthMode] = Field(None, description="Authentication mode")
    headers: Optional[Dict[str, str]] = Field(None, description="Custom headers")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Request/Response Models
# ============================================================================

class RenderRequest(BaseModel):
    """Request for PDF rendering."""
    html: Optional[str] = Field(None, description="HTML content to render (for html mode)")
    url: Optional[str] = Field(None, description="URL to render (for url mode)")
    mode: Literal["html", "url"] = Field("html", description="Rendering mode")
    options: Optional[RenderOptions] = Field(None, description="Rendering options")
    auth: Optional[RenderAuth] = Field(None, description="Authentication configuration")

    @field_validator("html", "url")
    @classmethod
    def validate_content(cls, v: Optional[str], info: Any) -> Optional[str]:
        """Validate that either html or url is provided."""
        return v

    model_config = ConfigDict(populate_by_name=True)


class RenderMetadata(BaseModel):
    """Metadata about the rendering process."""
    duration_ms: int = Field(..., alias="durationMs", description="Render duration in milliseconds")
    pages: int = Field(..., description="Number of pages in the PDF")
    warnings: List[str] = Field(default_factory=list, description="Warnings generated during rendering")
    console_logs: Optional[List[str]] = Field(None, alias="consoleLogs", description="Console messages from the page")
    network_errors: Optional[List[str]] = Field(None, alias="networkErrors", description="Network errors encountered")

    model_config = ConfigDict(populate_by_name=True)


class RenderResponse(BaseModel):
    """Response from synchronous rendering."""
    pdf: bytes = Field(..., description="PDF binary data")
    metadata: RenderMetadata = Field(..., description="Rendering metadata")


class AsyncRenderResponse(BaseModel):
    """Response from async rendering job submission."""
    job_id: str = Field(..., alias="jobId", description="Job ID for status polling")
    status_url: str = Field(..., alias="statusUrl", description="Status URL for polling")

    model_config = ConfigDict(populate_by_name=True)


class JobError(BaseModel):
    """Error information for failed jobs."""
    code: ErrorCode = Field(..., description="Error code")
    message: str = Field(..., description="Error message")


class JobStatusResponse(BaseModel):
    """Status response for a rendering job."""
    status: JobStatus = Field(..., description="Current job status")
    meta: Optional[RenderMetadata] = Field(None, description="Rendering metadata (when succeeded)")
    download_url: Optional[str] = Field(None, alias="downloadUrl", description="Download URL for the PDF")
    debug_url: Optional[str] = Field(None, alias="debugUrl", description="Debug bundle URL")
    error: Optional[JobError] = Field(None, description="Error information (when failed)")
    progress: Optional[int] = Field(None, ge=0, le=100, description="Job progress percentage")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Batch Processing Models
# ============================================================================

class BatchItem(BaseModel):
    """Item in a batch rendering request."""
    html: Optional[str] = Field(None, description="HTML content to render (for html mode)")
    url: Optional[str] = Field(None, description="URL to render (for url mode)")
    mode: Literal["html", "url"] = Field(..., description="Rendering mode")
    item_id: Optional[str] = Field(None, alias="itemId", description="Optional item ID for tracking")
    options: Optional[RenderOptions] = Field(None, description="Rendering options")
    auth: Optional[RenderAuth] = Field(None, description="Authentication configuration")

    model_config = ConfigDict(populate_by_name=True)


class BatchRequest(BaseModel):
    """Request for batch rendering."""
    items: List[BatchItem] = Field(..., max_length=100, description="Items to render (max 100)")


class BatchResponse(BaseModel):
    """Response from batch job submission."""
    batch_id: str = Field(..., alias="batchId", description="Batch ID for tracking")
    item_count: int = Field(..., alias="itemCount", description="Number of items in the batch")
    status_url: str = Field(..., alias="statusUrl", description="Status URL for polling")
    download_url: str = Field(..., alias="downloadUrl", description="Download URL for batch results")

    model_config = ConfigDict(populate_by_name=True)


class BatchItemStatus(BaseModel):
    """Status of an individual batch item."""
    item_id: Optional[str] = Field(None, alias="itemId", description="Item ID (if provided)")
    index: int = Field(..., description="Item index in the batch")
    status: JobStatus = Field(..., description="Current status")
    job_id: Optional[str] = Field(None, alias="jobId", description="Job ID for this item")
    download_url: Optional[str] = Field(None, alias="downloadUrl", description="Download URL (when succeeded)")
    error: Optional[JobError] = Field(None, description="Error information (when failed)")

    model_config = ConfigDict(populate_by_name=True)


class BatchStatusResponse(BaseModel):
    """Status response for a batch job."""
    batch_id: str = Field(..., alias="batchId", description="Batch ID")
    status: BatchJobStatus = Field(..., description="Overall batch status")
    total: int = Field(..., description="Total items in batch")
    completed: int = Field(..., description="Number of completed items")
    failed: int = Field(..., description="Number of failed items")
    items: List[BatchItemStatus] = Field(..., description="Status of individual items")
    download_url: Optional[str] = Field(None, alias="downloadUrl", description="ZIP download URL (when all completed)")

    model_config = ConfigDict(populate_by_name=True)


class BulkStatusRequest(BaseModel):
    """Request for bulk status check."""
    job_ids: List[str] = Field(..., alias="jobIds", max_length=100, description="Job IDs to check (max 100)")

    model_config = ConfigDict(populate_by_name=True)


class BulkStatusResponse(BaseModel):
    """Response from bulk status check."""
    jobs: Dict[str, JobStatusResponse] = Field(..., description="Status for each job (keyed by job ID)")


# ============================================================================
# Webhook Models
# ============================================================================

class WebhookConfig(BaseModel):
    """Webhook configuration."""
    url: HttpUrl = Field(..., description="Webhook URL to call")
    secret: str = Field(..., min_length=16, max_length=128, description="Secret for HMAC signature verification")
    events: List[WebhookEvent] = Field(..., description="Events to subscribe to")
    enabled: Optional[bool] = Field(True, description="Whether webhook is enabled")


class WebhookConfigResponse(BaseModel):
    """Webhook configuration response."""
    url: str = Field(..., description="Webhook URL")
    events: List[WebhookEvent] = Field(..., description="Events subscribed to")
    enabled: bool = Field(..., description="Whether webhook is enabled")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    updated_at: str = Field(..., alias="updatedAt", description="Last update timestamp")

    model_config = ConfigDict(populate_by_name=True)


class WebhookVerifyRequest(BaseModel):
    """Request to verify webhook signature."""
    body: str = Field(..., description="Raw request body")
    signature: str = Field(..., description="Signature from x-webhook-signature header")
    secret: str = Field(..., description="Secret used for signing")


class WebhookVerifyResponse(BaseModel):
    """Response from webhook signature verification."""
    valid: bool = Field(..., description="Whether signature is valid")


# ============================================================================
# Template Models
# ============================================================================

class TemplateRenderRequest(BaseModel):
    """Request for template-based rendering."""
    template: str = Field(..., description="Template ID or type")
    data: Dict[str, Any] = Field(..., description="Template data/variables")
    options: Optional[RenderOptions] = Field(None, description="Rendering options")


class TemplateValidateRequest(BaseModel):
    """Request for template validation."""
    template: str = Field(..., description="Template ID or type")
    data: Dict[str, Any] = Field(..., description="Template data/variables")


class TemplateValidationResponse(BaseModel):
    """Response from template validation."""
    valid: bool = Field(..., description="Whether template and data are valid")
    errors: Optional[List[str]] = Field(None, description="Validation errors (if any)")


# ============================================================================
# Compliance Models
# ============================================================================

class ComplianceCertificateRequest(BaseModel):
    """Request for compliance certificate generation."""
    pdf: bytes = Field(..., description="PDF file as binary data")
    standards: Optional[List[Literal["pdfa", "pdfua", "wcag", "pdfx"]]] = Field(
        None,
        description="Standards to validate against"
    )
    format: Literal["pdf", "json"] = Field("pdf", description="Output format")


class ComplianceIssue(BaseModel):
    """Compliance validation issue."""
    severity: IssueSeverity = Field(..., description="Issue severity")
    category: str = Field(..., description="Issue category")
    message: str = Field(..., description="Issue description")
    recommendation: Optional[str] = Field(None, description="Recommendation for fixing")


class ComplianceResult(BaseModel):
    """Compliance validation result for a standard."""
    standard: str = Field(..., description="Standard name")
    compliant: bool = Field(..., description="Whether compliant")
    score: Optional[int] = Field(None, ge=0, le=100, description="Compliance score (0-100)")
    issues: List[ComplianceIssue] = Field(..., description="Issues found")


class ComplianceCertificateResponse(BaseModel):
    """Response from compliance certificate generation."""
    certificate_id: str = Field(..., alias="certificateId", description="Certificate ID")
    results: List[ComplianceResult] = Field(..., description="Results for each standard")
    certificate: Optional[bytes] = Field(None, description="Certificate PDF (if format=pdf)")
    generated_at: str = Field(..., alias="generatedAt", description="Generated timestamp")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Analytics Models
# ============================================================================

class UsageMetrics(BaseModel):
    """Usage metrics."""
    total_renders: int = Field(..., alias="totalRenders", description="Total number of renders")
    successful_renders: int = Field(..., alias="successfulRenders", description="Successful renders")
    failed_renders: int = Field(..., alias="failedRenders", description="Failed renders")
    total_pages: int = Field(..., alias="totalPages", description="Total pages generated")
    avg_render_time_ms: float = Field(..., alias="avgRenderTimeMs", description="Average render time (ms)")
    storage_used_bytes: int = Field(..., alias="storageUsedBytes", description="Storage used (bytes)")

    model_config = ConfigDict(populate_by_name=True)


class CostMetrics(BaseModel):
    """Cost metrics."""
    total_cost: float = Field(..., alias="totalCost", description="Total cost")
    cost_per_render: float = Field(..., alias="costPerRender", description="Cost per render")
    currency: str = Field(..., description="Currency")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Organization Models
# ============================================================================

class OrganizationQuotas(BaseModel):
    """Organization usage quotas."""
    renders: int = Field(..., description="Render quota")
    storage: int = Field(..., description="Storage quota (bytes)")
    api_calls: int = Field(..., alias="apiCalls", description="API call quota")

    model_config = ConfigDict(populate_by_name=True)


class Organization(BaseModel):
    """Organization information."""
    id: str = Field(..., description="Organization ID")
    name: str = Field(..., description="Organization name")
    plan: PlanTier = Field(..., description="Subscription plan")
    quotas: OrganizationQuotas = Field(..., description="Usage quotas")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")

    model_config = ConfigDict(populate_by_name=True)
