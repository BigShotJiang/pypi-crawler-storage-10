from setuptools import setup, find_packages

setup(
    name='name12345',               
    version='1.0.0',
    author='Sirine',                      
    author_email='as.refsi@esi-sba.dz',     
    packages=find_packages(),               
    url='http://pypi.python.org/pypi/my_space_package/',
    license='LICENSE.txt',
    description='A simple rocket simulation package',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    install_requires=[]                    
)