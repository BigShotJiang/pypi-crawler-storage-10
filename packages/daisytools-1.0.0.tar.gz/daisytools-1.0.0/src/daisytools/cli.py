"""
Command-line interface for DaisyTools.
"""

import argparse
import sys
import subprocess
from typing import List

from .core import check_style, fix_style


def check_style_cli():
    """Command-line interface for code style checking."""
    parser = argparse.ArgumentParser(
        description="Check Python code style and report issues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  daisy-code-style-check                    # Check all Python files in current directory
  daisy-code-style-check file1.py file2.py  # Check specific files
        """
    )

    parser.add_argument(
        "files",
        nargs="*",
        help="Python files to check (if not provided, checks all Python files in current directory)"
    )

    parser.add_argument(
        "-p", "--flake8",
        action="store_true",
        help="Show flake8 output instead of code changes"
    )

    args = parser.parse_args()

    try:
        count = check_style(
            files=args.files if args.files else None,
            show_flake8=args.flake8
        )
        sys.exit(count)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def fix_style_cli():
    """Command-line interface for code style fixing."""
    parser = argparse.ArgumentParser(
        description="Fix Python code style issues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  daisy-code-style-fix                    # Fix all Python files in current directory
  daisy-code-style-fix file1.py file2.py  # Fix specific files
  daisy-code-style-fix -n                 # Preview changes without applying them
        """
    )

    parser.add_argument(
        "files",
        nargs="*",
        help="Python files to fix (if not provided, fixes all Python files in current directory)"
    )

    parser.add_argument(
        "-n", "--check",
        action="store_true",
        help="Only show what would be changed without applying fixes"
    )

    parser.add_argument(
        "-p", "--flake8",
        action="store_true",
        help="Show flake8 output (only with -n option)"
    )

    args = parser.parse_args()

    try:
        count = fix_style(
            files=args.files if args.files else None,
            check_only=args.check,
            show_flake8=args.flake8
        )
        sys.exit(count)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def python_wrapper_cli():
    """Python wrapper that selects the best available Python interpreter."""
    # Try Python versions in order of preference
    python_commands = ["python3", "python"]

    for cmd in python_commands:
        try:
            subprocess.run([cmd] + sys.argv[1:], check=True)
            return
        except FileNotFoundError:
            continue
        except subprocess.CalledProcessError as e:
            sys.exit(e.returncode)

    print("Error: No Python interpreter found", file=sys.stderr)
    sys.exit(1)


# For backward compatibility with the setup.py entry points
def check_style():
    """Entry point for daisy-code-style-check command."""
    # Entry points are called without arguments, so we need to parse sys.argv
    check_style_cli()


def fix_style():
    """Entry point for daisy-code-style-fix command."""
    # Entry points are called without arguments, so we need to parse sys.argv
    fix_style_cli()


def python_wrapper():
    """Entry point for daisypython command."""
    python_wrapper_cli()


if __name__ == "__main__":
    # For direct script execution
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check_style_cli()
    elif len(sys.argv) > 1 and sys.argv[1] == "fix":
        fix_style_cli()
    else:
        print("Usage: python -m daisytools [check|fix] [options]")
        sys.exit(1)