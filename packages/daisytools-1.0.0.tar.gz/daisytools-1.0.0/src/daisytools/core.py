"""
Core functionality for DaisyTools code style checking and formatting.
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path
from typing import List, Tuple, Optional


def find_python_files(path: str = ".", recursive: bool = True) -> List[str]:
    """Find Python files in the given directory.

    Args:
        path: Directory path to search
        recursive: Whether to search subdirectories recursively

    Returns:
        List of Python file paths
    """
    path_obj = Path(path)
    if recursive:
        pattern = "**/*.py"
    else:
        pattern = "*.py"

    python_files = []
    for file_path in path_obj.glob(pattern):
        if file_path.is_file():
            python_files.append(str(file_path))

    return python_files


def is_imported_file(file_path: str) -> bool:
    """Check if a file is marked as imported by looking for .imported files.

    Args:
        file_path: Path to the file to check

    Returns:
        True if the file is imported, False otherwise
    """
    current_dir = Path(file_path).parent

    while True:
        imported_marker = current_dir / ".imported"
        if imported_marker.exists():
            print(f"ignoring imported file {file_path}")
            return True

        parent_dir = current_dir.parent
        if parent_dir == current_dir:
            break
        current_dir = parent_dir

    return False


def run_black(file_path: str, check_only: bool = False) -> Tuple[int, str]:
    """Run Black code formatter on a file.

    Args:
        file_path: Path to the Python file
        check_only: If True, only check without formatting

    Returns:
        Tuple of (exit_code, output)
    """
    cmd = ["black", "--line-length", "88", "--target-version", "py36"]

    if check_only:
        cmd.extend(["--quiet", "--diff", file_path])
    else:
        cmd.append(file_path)

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode, result.stdout + result.stderr
    except Exception as e:
        return 1, f"Error running black: {e}"


def run_isort(file_path: str, check_only: bool = False) -> Tuple[int, str]:
    """Run isort import sorter on a file.

    Args:
        file_path: Path to the Python file
        check_only: If True, only check without formatting

    Returns:
        Tuple of (exit_code, output)
    """
    cmd = ["isort", "--profile", "black"]

    if check_only:
        cmd.extend(["--diff", file_path])
    else:
        cmd.append(file_path)

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode, result.stdout + result.stderr
    except Exception as e:
        return 1, f"Error running isort: {e}"


def run_flake8(file_path: str) -> Tuple[int, str]:
    """Run flake8 linter on a file.

    Args:
        file_path: Path to the Python file

    Returns:
        Tuple of (exit_code, output)
    """
    cmd = ["flake8", "--max-line-length=88", "--extend-ignore=E203,W503", file_path]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode, result.stdout
    except Exception as e:
        return 1, f"Error running flake8: {e}"


def check_crlf_line_endings(file_path: str) -> bool:
    """Check if file has DOS-style CRLF line endings.

    Args:
        file_path: Path to the file to check

    Returns:
        True if file has CRLF line endings, False otherwise
    """
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
            return b'\r\n' in content
    except Exception:
        return False


def check_style(
    files: Optional[List[str]] = None,
    show_flake8: bool = False,
    diff_command: str = "diff -u"
) -> int:
    """Check code style and report issues.

    Args:
        files: List of files to check (None for all Python files in current dir)
        show_flake8: Whether to show flake8 output
        diff_command: Diff command to use for showing changes

    Returns:
        Number of files with issues
    """
    count = 0

    if files is None:
        files = find_python_files()

    for file_path in files:
        if not Path(file_path).exists():
            print(f"The file {file_path} does not exist")
            continue

        if not file_path.endswith('.py'):
            print(f"File of unknown type not checked: {file_path}")
            continue

        if is_imported_file(file_path):
            continue

        # Check Black formatting
        black_code, black_output = run_black(file_path, check_only=True)
        if black_code == 0 and black_output:
            print(f"{file_path}:")
            print(black_output)
            count += 1
        elif black_code != 0:
            print(black_output)
            count += 1

        # Check isort imports
        isort_code, isort_output = run_isort(file_path, check_only=True)
        if isort_code == 0 and isort_output:
            print(f"{file_path}:")
            print(isort_output)
            count += 1
        elif isort_code != 0:
            print(isort_output)
            count += 1

        # Check flake8 if requested
        if show_flake8:
            flake8_code, flake8_output = run_flake8(file_path)
            if flake8_code != 0:
                count += 1
                print(flake8_output)

            # Check line endings
            if check_crlf_line_endings(file_path):
                count += 1
                print(f"{file_path}: file has DOS-style (CRLF) line-endings, "
                      f"please use dos2unix or your editor configuration to fix it")

    return count


def fix_style(
    files: Optional[List[str]] = None,
    check_only: bool = False,
    show_flake8: bool = False
) -> int:
    """Fix code style issues.

    Args:
        files: List of files to fix (None for all Python files in current dir)
        check_only: If True, only show what would be changed
        show_flake8: Whether to show flake8 output

    Returns:
        Number of files with issues (if check_only=True) or 0
    """
    if check_only:
        return check_style(files, show_flake8=show_flake8)

    if files is None:
        files = find_python_files()

        # Ask for confirmation if there are many files
        if len(files) > 100:
            print(f"There are {len(files)} Python files in or below the current directory:")
            print(os.getcwd())
            reply = input("Are you sure you want to run fixstyle on all of them? (y/n) ")
            if reply.lower() != 'y':
                return 0

    for file_path in files:
        if not Path(file_path).exists():
            print(f"The file {file_path} does not exist")
            continue

        if not file_path.endswith('.py'):
            print(f"File of unknown type not formatted: {file_path}")
            continue

        if is_imported_file(file_path):
            continue

        # Fix imports with isort
        isort_code, isort_output = run_isort(file_path, check_only=False)
        if isort_code != 0:
            print(f"Error running isort on {file_path}: {isort_output}")

        # Fix formatting with black
        black_code, black_output = run_black(file_path, check_only=False)
        if black_code != 0:
            print(f"Error running black on {file_path}: {black_output}")

        # Check if there are remaining issues
        remaining_issues = check_style([file_path], show_flake8=show_flake8)
        if remaining_issues > 0:
            print(f"Some problems in '{file_path}' could not be fixed, please resolve them manually.")

    return 0