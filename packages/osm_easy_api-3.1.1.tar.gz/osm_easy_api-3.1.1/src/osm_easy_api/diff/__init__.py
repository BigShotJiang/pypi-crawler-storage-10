"""Module responsible for downloading, parsing and returning diff files."""
from .diff import Diff, Frequency 