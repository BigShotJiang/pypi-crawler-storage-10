"""Module to communicate with OpenStreetMap API."""
from .api import Api

from . import exceptions