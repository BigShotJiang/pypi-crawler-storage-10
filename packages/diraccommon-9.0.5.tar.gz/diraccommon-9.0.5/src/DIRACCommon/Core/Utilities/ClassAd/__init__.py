"""ClassAd utilities for DIRACCommon"""
