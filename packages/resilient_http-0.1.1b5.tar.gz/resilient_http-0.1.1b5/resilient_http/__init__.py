"""
resilient_http package
Resilience layer for Python HTTP clients.
"""

__all__ = []
__version__ = "0.1.1b5"
