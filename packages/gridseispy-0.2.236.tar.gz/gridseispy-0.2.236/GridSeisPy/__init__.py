"""
SeisPy is a Python library for seismic data processing.
"""

__version__ = "0.2.236"

from .seis_data import SeisData
from .horiz import Horiz
from .mapping import TraceField, BinField, Trace
from .base.base_class import BaseConfig, CVDFile

__all__ = ['SeisData', 'Horiz', 'TraceField', 'BinField', 'Trace', 'CVDFile', 'BaseConfig']

"""
py -m build
py -m twine check dist/*
py -m twine upload --non-interactive -r pypi dist/*
"""
