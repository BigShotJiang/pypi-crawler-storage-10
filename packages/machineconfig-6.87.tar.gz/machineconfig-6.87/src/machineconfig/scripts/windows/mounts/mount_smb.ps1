
New-SmbMapping -LocalPath 'X:' -RemotePath '\\alex-xps13\share_smb'
