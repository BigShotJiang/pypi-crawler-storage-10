"""
Python Connector for InterBase is a connectivity solution for accessing
InterBase databases from Python applications. It fully implements the Python
DB API 2.0 specification. The connector is distributed as a wheel package
for Windows, macOS, and Linux.
 
Secure communication


Version: 1.3.0 

Homepage: https://www.devart.com/python/interbase/
"""
from .interbase import *
