"""Tap executable."""

from __future__ import annotations

from tap_betterstack.tap import TapBetterStack

TapBetterStack.cli()
