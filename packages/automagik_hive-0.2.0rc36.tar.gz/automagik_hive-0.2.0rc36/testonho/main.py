def main():
    print("Hello from testonho!")


if __name__ == "__main__":
    main()
