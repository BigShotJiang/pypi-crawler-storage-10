import{aO as o,r as s}from"./index-DBvv7-aE.js";const r=o("autoCali",()=>({sessionInfo:s()}));export{r as u};
