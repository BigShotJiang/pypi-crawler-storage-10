import{aO as t,r as o}from"./index-DBvv7-aE.js";const a=t("groupDetail",()=>{const r=o(),e=o();return{groupInfo:r,spaceList:e}});export{a as u};
