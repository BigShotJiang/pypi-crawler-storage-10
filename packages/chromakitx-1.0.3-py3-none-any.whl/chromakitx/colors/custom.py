# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.constants import ANSI_RGB_ESCAPE
from chromakitx.exceptions import InvalidColorError
from chromakitx.models import (RGB, HSL, HEX, HSV)
from chromakitx.utils import (hex_to_rgb, hsl_to_rgb, hsv_to_rgb)
from chromakitx.protocols import ColorFormattable

class CustomColor(ColorFormattable):
    __slots__: tuple[str] = ('_rgb',)

    def __init__(self, color: RGB | HSL | HEX | HSV) -> None:
        if isinstance(color, RGB):
            self._rgb: RGB = color
        elif isinstance(color, HEX):
            self._rgb = hex_to_rgb(color)
        elif isinstance(color, HSL):
            self._rgb = hsl_to_rgb(color)
        elif isinstance(color, HSV):
            self._rgb = hsv_to_rgb(color)
        else:
            raise InvalidColorError(color_value=color, message="CustomColor requires RGB, HSL, HEX or HSV, got " + type(color).__name__)

    def format(self) -> str:
        (r, g, b) = self._rgb
        return ANSI_RGB_ESCAPE % (r, g, b)
