Lager Data CLI tool

Command Line Interface for https://lagerdata.com

Read the docs at https://docs.lagerdata.com/lager-cli/

## ⚠️ IMPORTANT: Legacy Version

This is the **legacy version** of lager-cli. For the latest version, install `lager-cli` instead.

**If you have already used the new lager-cli**, make sure to remove your existing configuration before using this legacy version:

```bash
rm -rf ~/.lager
```

This will reset your configuration to work with the legacy CLI.
