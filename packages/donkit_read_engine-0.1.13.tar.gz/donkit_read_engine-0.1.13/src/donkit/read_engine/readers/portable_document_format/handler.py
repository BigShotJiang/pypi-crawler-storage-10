import base64
import errno
import gc
import io
import json
import os
import pathlib
import re
import shutil
import stat
import sys
import tempfile
import threading
import time
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed

import fitz
import psutil
from dotenv import find_dotenv, load_dotenv
from json_repair import repair_json
from loguru import logger

from ..static_visual_format.models import (
    qwen2_vl_7b_model_agent,
    get_image_analysis_service,
)


# Load .env file with explicit search (important for Windows)
# Try multiple locations in priority order
_env_loaded = False
for _fname in (".env.local", ".env"):
    # 1. Try current working directory
    _cwd_path = pathlib.Path.cwd() / _fname
    if _cwd_path.exists():
        load_dotenv(_cwd_path)
        _env_loaded = True
    # 2. Try parent directories (walk up to 3 levels)
    _parent = pathlib.Path.cwd()
    for _ in range(4):
        _parent = _parent.parent
        _parent_env = _parent / _fname
        if _parent_env.exists():
            load_dotenv(_parent_env)
            _env_loaded = True
            break
    # 3. Fallback to find_dotenv
    if not _env_loaded:
        _found = find_dotenv(filename=_fname, usecwd=True)
        if _found:
            load_dotenv(_found)
            _env_loaded = True


logger.remove()
log_level = os.getenv("RAGOPS_LOG_LEVEL", os.getenv("LOG_LEVEL", "ERROR"))
# Force DEBUG level if no env vars loaded to help debug
if not _env_loaded:
    log_level = "DEBUG"
logger.add(
    sys.stderr,
    level=log_level,
    enqueue=False,
    backtrace=False,
    diagnose=False,
)

# Warn if no .env was loaded
if not _env_loaded:
    logger.warning(
        "⚠️ No .env file found. PDF image analysis may fail without credentials. "
        "Current directory: " + str(pathlib.Path.cwd())
    )


def safe_rmtree(path: pathlib.Path) -> None:
    """Safely remove directory tree with Windows-compatible error handling.

    On Windows, files might still be locked by the system. This function
    handles permission errors by trying to change file permissions before removal.

    Args:
        path: Path to directory to remove
    """
    import gc
    import platform

    # On Windows, force garbage collection and add small delay to release file handles
    if platform.system() == "Windows":
        gc.collect()
        time.sleep(0.1)  # 100ms delay for Windows to release file handles

    def handle_remove_error(func, filepath, exc_info):
        """Handle errors during directory removal on Windows."""
        # If permission error, try to change permissions and retry
        if exc_info[1].errno == errno.EACCES:
            try:
                os.chmod(filepath, stat.S_IWRITE)
                time.sleep(0.05)  # Small delay before retry
                func(filepath)
            except Exception as e:
                logger.warning(f"Could not remove {filepath}: {e}")
        else:
            logger.warning(f"Could not remove {filepath}: {exc_info[1]}")

    try:
        shutil.rmtree(path, onerror=handle_remove_error)
    except Exception as e:
        logger.warning(f"Failed to cleanup directory {path}: {e}")


def _sanitize_json_like(text: str) -> str:
    """Fix common JSON formatting glitches from LLMs using json-repair library.

    Uses json-repair (https://github.com/mangiucugna/json_repair) which handles:
    - Trailing commas
    - Missing commas between elements
    - Single quotes instead of double quotes
    - Incomplete JSON structures
    - Escaped characters issues
    - And many more LLM-specific JSON errors

    Falls back to simple regex fixes if json-repair fails.
    """
    try:
        repaired = repair_json(text)
        if repaired:  # If repair succeeded
            return repaired
    except Exception as e:
        logger.debug(f"json-repair failed: {e}, using fallback")
    s = text
    s = re.sub(r"\]\s*},\s*\"", r"], \"", s)  # Extra '}' after list
    s = re.sub(r",\s*([}\]])", r"\1", s)  # Trailing commas
    return s


def _fix_json_with_llm(invalid_json: str, error_message: str) -> str | None:
    """Attempt to fix invalid JSON by asking LLM to correct it.

    Args:
        invalid_json: The invalid JSON string
        error_message: The error message from JSON parser

    Returns:
        Fixed JSON string or None if LLM call fails
    """
    try:
        # Limit JSON size to prevent excessive processing time (10KB max)
        if len(invalid_json) > 10240:
            logger.debug(
                f"JSON too large for LLM fix ({len(invalid_json)} bytes), skipping"
            )
            return None

        service = get_image_analysis_service()
        # Check if service has text-only method (GeminiImageAnalysisService)
        if not hasattr(service, "call_text_only"):
            logger.debug(
                "Image analysis service doesn't support text-only calls, skipping LLM fix"
            )
            return None

        prompt = f"""Fix the following invalid JSON. The JSON has a syntax error: {error_message}
            
            Invalid JSON:
            ```json
            {invalid_json}
            ```
            
            Return ONLY the corrected valid JSON without any explanations, markdown formatting, or additional text. Just the raw JSON.""".strip()

        logger.debug("Requesting LLM to fix invalid JSON...")
        fixed_json = service.call_text_only(prompt)

        # Strip potential markdown fences from response
        fixed_json = fixed_json.strip()
        if fixed_json.startswith("```json"):
            fixed_json = fixed_json[7:]
        elif fixed_json.startswith("```"):
            fixed_json = fixed_json[3:]
        if fixed_json.endswith("```"):
            fixed_json = fixed_json[:-3]
        fixed_json = fixed_json.strip()

        # Validate that the fix worked
        try:
            json.loads(fixed_json)
            logger.debug("LLM successfully fixed the JSON")
            return fixed_json
        except json.JSONDecodeError as e:
            logger.warning(f"LLM-fixed JSON is still invalid: {e}")
            return None

    except Exception as e:
        logger.warning(f"Failed to fix JSON with LLM: {e}")
        return None


def split_pdf_into_pages(pdf_path: pathlib.Path, output_dir: pathlib.Path) -> None:
    """Splits the PDF into individual pages and saves them in the specified directory.

    :param pdf_path: Path to the input PDF file.
    :param output_dir: Directory where the pages will be saved.
    """
    # Open the PDF document
    if output_dir.exists():
        safe_rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)

    document = fitz.open(pdf_path)
    try:
        # Loop through each page and save it as a separate PDF
        for page_num in range(document.page_count):
            output_file = output_dir / f"page_{page_num + 1}.pdf"
            pdf_writer = fitz.open()
            try:
                pdf_writer.insert_pdf(document, from_page=page_num, to_page=page_num)
                pdf_writer.save(output_file)
            finally:
                pdf_writer.close()  # CRITICAL: Close to release file handle on Windows
    finally:
        document.close()  # Ensure document is closed even if error occurs


def process_pdf_page_as_image(page_path: str) -> str:
    """Converts a PDF page to an image, encodes it in Base64, and sends it to the Qwen2-VL-7B model.

    :param page_path: Path to the saved PDF page.
    :return: The image context returned by the Qwen2-VL-7B model.
    """
    # Open the PDF page
    document = fitz.open(page_path)
    try:
        page = document[0]
        pix = page.get_pixmap()  # Render the page as an image
        try:
            # Convert to PNG bytes
            png_bytes = pix.tobytes("png")
        finally:
            # Explicitly free pixmap memory (important for Windows)
            pix = None
            gc.collect()  # Force garbage collection

        # Create BytesIO buffer for image data
        image_bytes = io.BytesIO(png_bytes)
        try:
            # Encode the image in Base64 format
            encoded_image = base64.b64encode(image_bytes.getvalue()).decode("utf-8")
        finally:
            image_bytes.close()  # Close buffer to release resources on Windows

        # Clear PNG bytes from memory
        del png_bytes
        gc.collect()  # Force garbage collection
    finally:
        document.close()  # Ensure document is closed even if error occurs
        gc.collect()  # Force garbage collection

    # Log Base64 image size for memory tracking
    image_size_mb = len(encoded_image) / 1024 / 1024
    logger.debug(
        f"Base64 image size: {image_size_mb:.2f}MB for {pathlib.Path(page_path).name}"
    )

    # Send the Base64-encoded image to the model and retrieve the context
    image_context = qwen2_vl_7b_model_agent(encoded_image, image_type="Slides")

    # Clear the encoded image from memory BEFORE returning
    del encoded_image
    gc.collect()

    return image_context


def sort_files_naturally(file_list):
    """Sorts a list of filenames in natural order (e.g., page_1, page_2, ..., page_10).

    :param file_list: List of filenames to sort.
    :return: Sorted list of filenames.
    """

    def extract_page_number(filename):
        # Extract the number from the filename using regex
        match = re.search(r"page_(\d+)\.pdf", filename)
        return int(match.group(1)) if match else 0

    return sorted(file_list, key=extract_page_number)


def pdf_read_handler_memory_optimized(
    path: str, batch_size: int = 10
) -> Iterator[dict[str, str | int]]:
    """Memory-optimized PDF processor that yields results as they complete (parallel).

    :param path: Path to the PDF file.
    :param batch_size: Number of pages to process before logging progress.
    :yield: Dictionary containing extracted data from each page.
    """
    # Create a unique temporary directory for page splitting
    pdf_name = pathlib.Path(path).stem
    tmp_dir = pathlib.Path(tempfile.mkdtemp(prefix=f"donkit_pdf_readbatch_{pdf_name}_"))
    logger.debug(
        f"📁 Created unique tmp directory for batch processing: {tmp_dir.name}"
    )

    try:
        split_pdf_into_pages(pathlib.Path(path), tmp_dir)
        sorted_files = sort_files_naturally(os.listdir(tmp_dir))

        logger.debug(f"Processing {len(sorted_files)} pages in parallel")

        # Determine optimal thread count
        max_workers = min(8, len(sorted_files), os.cpu_count() or 4)
        logger.debug(f"Using {max_workers} worker threads")

        completed_count = 0
        progress_lock = threading.Lock()

        # Process pages in parallel and yield results as they complete
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_page = {
                executor.submit(
                    process_single_page, tmp_dir, page_file, page_num
                ): page_num
                for page_num, page_file in enumerate(sorted_files, start=1)
            }

            # Yield results as they complete
            for future in as_completed(future_to_page):
                page_num = future_to_page[future]
                try:
                    result = future.result()
                    result["page"] = page_num

                    with progress_lock:
                        completed_count += 1
                        # Log progress every batch_size pages
                        if completed_count % batch_size == 0 or completed_count == 1:
                            msg = (
                                f"Processing page {completed_count}/{len(sorted_files)}"
                            )
                            print(msg)

                    yield result

                except Exception as e:
                    logger.error(f"Error processing page {page_num}: {e}")
                    # Re-raise to ensure incomplete documents don't enter RAG
                    raise RuntimeError(f"Failed to process page {page_num}: {e}") from e

    finally:
        # Cleanup the temporary directory
        if tmp_dir.exists():
            safe_rmtree(tmp_dir)
            logger.debug("Cleaned up temporary directory")


def process_single_page(
    tmp_dir: pathlib.Path, page_file: str, page_num: int
) -> dict[str, str | int]:
    """Process a single PDF page and return the result.

    :param tmp_dir: Temporary directory containing page files.
    :param page_file: Name of the page file to process.
    :param page_num: Page number for logging.
    :return: Dictionary containing extracted data from the page.
    """
    page_path = os.path.join(tmp_dir, page_file)

    try:
        # Log memory for first few pages to monitor per-page consumption
        if page_num <= 5:
            log_memory_usage(
                f"page_{page_num}_start", f"- Starting page {page_num} processing"
            )

        raw_data_from_model = process_pdf_page_as_image(page_path)

        if page_num <= 5:
            log_memory_usage(
                f"page_{page_num}_after_image", f"- Page {page_num} image processed"
            )

        final_content = parse_model_output(raw_data_from_model, page_num)

        if page_num <= 5:
            log_memory_usage(
                f"page_{page_num}_end", f"- Page {page_num} processing complete"
            )

        return {"type": "Slide", "content": final_content}

    except Exception as e:
        logger.error(f"Error processing page {page_num}: {e}", exc_info=True)
        # Re-raise to ensure incomplete documents don't enter RAG
        raise RuntimeError(f"Failed to process page {page_num}: {e}") from e


def parse_model_output(raw_data_from_model, page_num: int) -> dict:
    """Parse model output into final content format.

    :param raw_data_from_model: Raw output from the model.
    :param page_num: Page number for logging.
    :return: Parsed content dictionary.
    """
    if isinstance(raw_data_from_model, dict):
        return raw_data_from_model
    elif isinstance(raw_data_from_model, str):
        # logger.debug(f"Raw string from model for page {page_num}: '{raw_data_from_model}'")

        text_to_process = raw_data_from_model.strip()

        # Remove markdown fences if present
        if text_to_process.startswith("```json"):
            text_to_process = text_to_process[len("```json") :]
            if text_to_process.endswith("```"):
                text_to_process = text_to_process[: -len("```")]
        elif text_to_process.startswith("```"):
            text_to_process = text_to_process[len("```") :]
            if text_to_process.endswith("```"):
                text_to_process = text_to_process[: -len("```")]

        text_to_process = text_to_process.strip()
        if not text_to_process:
            logger.warning(
                f"Empty string after stripping fences for page {page_num}. Original raw: '{raw_data_from_model}'"
            )
            return {"error": "Empty content from model after stripping fences"}

        try:
            # Attempt 1: Try json-repair first (handles most LLM errors automatically)
            try:
                return json.loads(repair_json(text_to_process, return_objects=False))
            except ImportError:
                # Fallback to standard json.loads if json-repair not available
                return json.loads(text_to_process)
        except json.JSONDecodeError as e_direct:
            logger.warning(
                f"Direct parsing failed for page {page_num}: {e_direct}. "
                f"Attempting fallback strategies..."
            )

            # Attempt 2: Try with manual sanitization
            sanitized = _sanitize_json_like(text_to_process)
            if sanitized != text_to_process:
                try:
                    return json.loads(sanitized)
                except json.JSONDecodeError:
                    pass

            # Attempt 3: Find first '{' or '[' and use raw_decode
            idx_brace = text_to_process.find("{")
            idx_bracket = text_to_process.find("[")
            start_idx = -1

            if idx_brace != -1 and (idx_bracket == -1 or idx_brace < idx_bracket):
                start_idx = idx_brace
            elif idx_bracket != -1:
                start_idx = idx_bracket

            if start_idx != -1:
                json_candidate_str = text_to_process[start_idx:]
                try:
                    decoder = json.JSONDecoder()
                    obj, end_pos = decoder.raw_decode(json_candidate_str)
                    return obj
                except json.JSONDecodeError as e_raw:
                    logger.warning(
                        f"JSONDecodeError with raw_decode for page {page_num}: {e_raw}. "
                        f"Attempting LLM fix as last resort..."
                    )

                    # Attempt 4: Ask LLM to fix the JSON (last resort)
                    fixed_json_str = _fix_json_with_llm(json_candidate_str, str(e_raw))
                    if fixed_json_str:
                        try:
                            return json.loads(fixed_json_str)
                        except json.JSONDecodeError:
                            pass

                    logger.error(
                        f"All JSON parsing attempts failed for page {page_num}. Original error: {e_direct}"
                    )
                    # Fallback: return raw text as plain content instead of error
                    return {
                        "text": text_to_process[:1000],  # First 1000 chars
                        "error": "JSON parsing failed",
                        "raw_content_length": len(text_to_process),
                    }
            else:
                # No '{' or '[' found to attempt raw_decode
                logger.error(
                    f"No JSON start character ('{{' or '[') found after markdown stripping for page {page_num}. Original direct error: {e_direct}. String: '{text_to_process}'"
                )
                return {
                    "error": "No JSON start character found in model output",
                    "details": str(e_direct),
                    "original_string_after_markdown_strip": text_to_process,
                }
    else:
        logger.warning(
            f"Unexpected data type from model for page {page_num}: "
            f"{type(raw_data_from_model)}. Value: {raw_data_from_model!r}"
        )
        return {
            "error": "Unexpected data type from model",
            "type": str(type(raw_data_from_model)),
        }


def log_memory_usage(stage: str, additional_info: str = "") -> None:
    """Log current memory usage with process details.

    :param stage: Stage description (e.g., "start", "after_splitting", "processing", "end")
    :param additional_info: Additional context information
    """
    try:
        import gc

        process = psutil.Process()
        memory_info = process.memory_info()
        memory_percent = process.memory_percent()

        # Convert bytes to MB for readability
        rss_mb = memory_info.rss / 1024 / 1024
        vms_mb = memory_info.vms / 1024 / 1024

        logger.debug(
            f"[MEMORY {stage.upper()}] RSS: {rss_mb:.1f}MB, VMS: {vms_mb:.1f}MB, "
            f"Percent: {memory_percent:.1f}% {additional_info}"
        )

        # Warn if VMS is growing too much (potential memory leak)
        # VMS > 2GB is concerning for PDF processing
        if vms_mb > 2048:
            logger.warning(
                f"⚠️ High VMS memory usage: {vms_mb:.1f}MB (RSS: {rss_mb:.1f}MB). "
                f"This may indicate memory leak. Forcing garbage collection..."
            )
            gc.collect()
            gc.collect()

    except Exception as e:
        logger.warning(f"Failed to log memory usage at {stage}: {e}")


def pdf_read_handler(path: str) -> list[dict[str, str | int]]:
    """Parallel PDF processor using ThreadPoolExecutor.

    Returns full result list for compatibility with document_service.

    :param path: Path to the PDF file.
    :return: A list of dictionaries containing extracted data from each page.
    """
    # Test if image analysis service is available
    # If not, fallback to simple PDF reader without LLM
    try:
        _ = get_image_analysis_service()
        logger.debug("✓ Image analysis service available")
    except (ValueError, Exception) as e:
        logger.warning(
            f"⚠️ Image analysis service not available: {e}. "
            f"Falling back to simple PDF reader without image analysis."
        )
        # Import and use simple reader
        import importlib

        pdf_parser = importlib.import_module(
            "donkit.read_engine.readers.portable_document_format.pdf_parser"
        )
        if hasattr(pdf_parser, "parse_pdf_hybrid"):
            return pdf_parser.parse_pdf_hybrid(path)
        processor = pdf_parser.StructuredPDFProcessor(analyze_images=False)
        return processor.process_pdf(path)

    start_time = time.time()
    log_memory_usage("start", f"- Starting PDF processing: {pathlib.Path(path).name}")
    logger.debug(f"⏱️ PDF processing started at {time.strftime('%H:%M:%S')}")

    # Create a unique temporary directory for page splitting
    pdf_name = pathlib.Path(path).stem
    tmp_dir = pathlib.Path(tempfile.mkdtemp(prefix=f"donkit_pdf_read_{pdf_name}_"))
    tmp_dir.mkdir(parents=True, exist_ok=True)
    logger.debug(f"📁 Created unique tmp directory: {tmp_dir.name}")

    try:
        split_pdf_into_pages(pathlib.Path(path), tmp_dir)
        split_time = time.time()
        logger.debug(f"⏱️ PDF split completed in {split_time - start_time:.2f}s")

        sorted_files = sort_files_naturally(os.listdir(tmp_dir))

        log_memory_usage("after_splitting", f"- Split into {len(sorted_files)} pages")
        logger.debug(
            f"Processing {len(sorted_files)} pages in parallel with ThreadPoolExecutor"
        )

        # Determine optimal thread count (max 8 threads to avoid overwhelming the system)
        max_workers = min(8, len(sorted_files), os.cpu_count() or 4)
        logger.debug(f"Using {max_workers} worker threads")

        # Warn if too many pages might cause RabbitMQ timeout
        if len(sorted_files) > 50:
            estimated_time = (
                len(sorted_files) * 0.5
            )  # Parallel processing: ~0.5s per page
            logger.warning(
                f"⚠️ Large PDF ({len(sorted_files)} pages) - estimated processing time: {estimated_time}s - may cause RabbitMQ timeout!"
            )

        results = []
        processing_start_time = time.time()
        progress_lock = threading.Lock()
        completed_count = 0

        # Process pages in parallel with graceful shutdown
        executor = ThreadPoolExecutor(max_workers=max_workers)
        try:
            # Submit all tasks
            future_to_page = {
                executor.submit(
                    process_single_page, tmp_dir, page_file, page_num
                ): page_num
                for page_num, page_file in enumerate(sorted_files, start=1)
            }

            # Collect results as they complete with timeout per page
            for future in as_completed(future_to_page, timeout=120):
                page_num = future_to_page[future]
                try:
                    result = future.result(timeout=60)  # 60s timeout per page
                    result["page"] = page_num
                    results.append(result)

                    with progress_lock:
                        completed_count += 1
                        # Periodic garbage collection every 5 pages to prevent VMS growth
                        if completed_count % 5 == 0:
                            import gc

                            gc.collect()

                        # Log timing and memory every 10 pages or at key milestones
                        if completed_count % 10 == 0 or completed_count in [
                            1,
                            5,
                            15,
                            25,
                        ]:
                            elapsed_time = time.time() - processing_start_time
                            avg_time_per_page = elapsed_time / completed_count
                            remaining_pages = len(sorted_files) - completed_count
                            estimated_remaining_time = (
                                remaining_pages * avg_time_per_page
                            )
                            msg = f"⏱️ Progress: {completed_count}/{len(sorted_files)} pages ({elapsed_time:.1f}s elapsed, ~{estimated_remaining_time:.1f}s remaining)"
                            print(msg)
                            # Warn if processing is taking too long (potential RabbitMQ timeout)
                            if elapsed_time > 120:  # 2 minutes
                                logger.warning(
                                    f"⚠️ PDF processing taking long ({elapsed_time:.1f}s) - RabbitMQ timeout risk!"
                                )

                            log_memory_usage(
                                "processing",
                                f"- Completed {completed_count}/{len(sorted_files)} pages, results in memory: {len(results)}",
                            )

                except TimeoutError as e:
                    logger.error(f"Timeout processing page {page_num} (>60s)")
                    # Re-raise to ensure incomplete documents don't enter RAG
                    raise RuntimeError(
                        f"Page {page_num} processing timeout (>60s)"
                    ) from e
                except Exception as e:
                    logger.error(
                        f"Error processing page {page_num}: {e}", exc_info=True
                    )
                    # Re-raise to ensure incomplete documents don't enter RAG
                    raise RuntimeError(f"Failed to process page {page_num}: {e}") from e
        finally:
            # Graceful shutdown: wait for remaining tasks with timeout
            executor.shutdown(wait=True)

        # Sort results by page number before returning
        sorting_start_time = time.time()
        log_memory_usage("before_sorting", f"- About to sort {len(results)} results")
        results.sort(key=lambda x: x["page"])

        end_time = time.time()
        total_time = end_time - start_time
        processing_time = end_time - processing_start_time
        sorting_time = end_time - sorting_start_time

        log_memory_usage(
            "end", f"- Processing complete: {len(results)} pages processed"
        )
        logger.debug("⏱️ PDF processing completed:")
        logger.debug(f"   📄 Total time: {total_time:.2f}s for {len(results)} pages")
        logger.debug(
            f"   🔄 Processing time: {processing_time:.2f}s (avg: {processing_time / len(results):.2f}s/page)"
        )
        logger.debug(f"   🔀 Sorting time: {sorting_time:.2f}s")

        # Final warning if total time exceeded reasonable RabbitMQ limits
        if total_time > 300:  # 5 minutes
            logger.error(
                f"🚨 PDF processing took {total_time:.1f}s - VERY HIGH risk of RabbitMQ timeout!"
            )
        elif total_time > 180:  # 3 minutes
            logger.warning(
                f"⚠️ PDF processing took {total_time:.1f}s - HIGH risk of RabbitMQ timeout!"
            )
        elif total_time > 120:  # 2 minutes
            logger.warning(
                f"⚠️ PDF processing took {total_time:.1f}s - moderate RabbitMQ timeout risk"
            )

        return results

    finally:
        # Cleanup the temporary directory with Windows-safe error handling
        if tmp_dir.exists():
            safe_rmtree(tmp_dir)
