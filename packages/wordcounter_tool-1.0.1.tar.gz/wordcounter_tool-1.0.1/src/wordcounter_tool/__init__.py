"""
wordcounter-tool - 多功能单词计数工具包
"""

from .word_counter import (
    count_words,
    count_words_from_text,
    count_words_from_file
)

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    'count_words',
    'count_words_from_text', 
    'count_words_from_file'
]