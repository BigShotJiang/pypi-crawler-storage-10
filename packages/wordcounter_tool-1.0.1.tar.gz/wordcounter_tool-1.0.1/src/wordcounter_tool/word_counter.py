"""
单词计数核心功能模块
"""

import re


def count_words(text):
    """
    统计文本中的单词数量
    
    Args:
        text (str): 输入文本
        
    Returns:
        int: 单词数量
    """
    if not text or not text.strip():
        return 0
    
    # 使用正则表达式匹配单词（字母、数字、下划线组合）
    words = re.findall(r'\b\w+\b', text)
    return len(words)


def count_words_from_text(text):
    """
    从文本字符串统计单词数量（count_words的别名）
    
    Args:
        text (str): 输入文本
        
    Returns:
        int: 单词数量
    """
    return count_words(text)


def count_words_from_file(filename):
    """
    从文件读取内容并统计单词数量
    
    Args:
        filename (str): 文件名
        
    Returns:
        int: 单词数量，如果文件不存在返回0
    """
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            content = file.read()
        return count_words(content)
    except FileNotFoundError:
        print(f"错误：文件 '{filename}' 不存在")
        return 0
    except Exception as e:
        print(f"读取文件时出错: {e}")
        return 0


def input_multiline():
    """
    多行文本输入函数
    
    Returns:
        str: 用户输入的多行文本
    """
    print("请输入多行文本（输入空行结束）:")
    lines = []
    while True:
        line = input()
        if line == "":
            break
        lines.append(line)
    return "\n".join(lines)


def input_single():
    """
    单行文本输入函数
    
    Returns:
        str: 用户输入的单行文本
    """
    return input("请输入文本: ").strip()


def read_from_file(filename):
    """
    从文件读取内容
    
    Args:
        filename (str): 文件名
        
    Returns:
        str: 文件内容，如果文件不存在返回空字符串
    """
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            return file.read()
    except FileNotFoundError:
        print(f"错误：文件 '{filename}' 不存在")
        return ""
    except Exception as e:
        print(f"读取文件时出错: {e}")
        return ""