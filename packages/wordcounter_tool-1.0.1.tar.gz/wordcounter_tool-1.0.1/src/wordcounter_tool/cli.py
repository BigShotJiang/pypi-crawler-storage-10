"""
命令行接口
"""

from .word_counter import (
    count_words,
    count_words_from_text, 
    count_words_from_file,
    input_multiline,
    input_single,
    read_from_file
)


def display_menu():
    """显示菜单选项"""
    print("\n" + "=" * 40)
    print("          单词计数器")
    print("=" * 40)
    print("1. 直接粘贴文本")
    print("2. 多行输入文本")
    print("3. 从文件读取")
    print("4. 退出")
    print("=" * 40)


def main():
    """主函数 - 提供用户交互界面"""
    while True:
        display_menu()
        choice = input("请选择操作 (1-4): ").strip()

        if choice == "1":
            text = input_single()
            if text:
                word_count = count_words(text)
                print(f"\n单词数量: {word_count}")
            else:
                print("未输入任何文本")

        elif choice == "2":
            text = input_multiline()
            if text:
                word_count = count_words(text)
                print(f"\n单词数量: {word_count}")
            else:
                print("未输入任何文本")

        elif choice == "3":
            filename = input("请输入文件名: ").strip()
            if filename:
                text = read_from_file(filename)
                if text:
                    word_count = count_words(text)
                    print(f"\n单词数量: {word_count}")
            else:
                print("未输入文件名")

        elif choice == "4":
            print("感谢使用单词计数器！")
            break

        else:
            print("无效选择，请重新输入")

        if choice in ["1", "2", "3"]:
            input("\n按回车键继续...")


if __name__ == "__main__":
    main()