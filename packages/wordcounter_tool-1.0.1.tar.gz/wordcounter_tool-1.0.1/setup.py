from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="wordcounter-tool",
    version="1.0.1",
    author="fangtangbai",
    author_email="fangtang2233@gmail.com",
    description="A versatile word counting tool supporting multiple input methods",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/baitang2233/wordcounter-tool",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    install_requires=[],
    entry_points={
        "console_scripts": [
            "wordcounter=wordcounter_tool.cli:main",
        ],
    },
)