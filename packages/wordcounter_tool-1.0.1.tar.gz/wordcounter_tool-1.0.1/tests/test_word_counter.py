import unittest
import os
from src.wordcounter_tool import count_words, count_words_from_file


class TestWordCounter(unittest.TestCase):

    def test_empty_text(self):
        self.assertEqual(count_words(""), 0)
        self.assertEqual(count_words("   "), 0)

    def test_single_word(self):
        self.assertEqual(count_words("hello"), 1)
        self.assertEqual(count_words("  hello  "), 1)

    def test_multiple_words(self):
        self.assertEqual(count_words("hello world"), 2)
        self.assertEqual(count_words("hello world, this is a test."), 6)

    def test_with_numbers_and_punctuation(self):
        self.assertEqual(count_words("hello123 world! test..."), 3)

    def test_file_count(self):
        # 创建临时测试文件
        test_content = "This is a test file with several words."
        with open("test_temp.txt", "w", encoding="utf-8") as f:
            f.write(test_content)
        
        try:
            result = count_words_from_file("test_temp.txt")
            self.assertEqual(result, 8)
        finally:
            # 清理临时文件
            if os.path.exists("test_temp.txt"):
                os.remove("test_temp.txt")


if __name__ == "__main__":
    unittest.main()