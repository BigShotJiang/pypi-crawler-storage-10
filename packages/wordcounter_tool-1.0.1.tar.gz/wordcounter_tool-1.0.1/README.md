# WordCounter Tool

一个多功能单词计数工具包，支持直接粘贴、多行输入和文件读取三种方式。

## 功能特点

- 📝 支持直接粘贴文本统计
- 📄 支持多行文本输入
- 📁 支持从文件读取内容
- 🔢 准确的单词计数算法
- 🖥️ 友好的命令行界面

## 安装

```bash
pip install wordcounter-tool
```

## 使用方法

### 命令行使用

安装后，可以直接在命令行中使用：

```bash
wordcounter
```

然后按照菜单提示选择输入方式。

### 作为 Python 模块使用

```python
from wordcounter_tool import count_words, count_words_from_file

# 直接统计文本
text = "Hello world, this is a test."
result = count_words(text)
print(f"单词数量: {result}")

# 从文件统计
result = count_words_from_file("example.txt")
print(f"文件单词数量: {result}")
```

## 输入方式

1. **直接粘贴**: 快速粘贴单行文本
2. **多行输入**: 支持输入多行文本，以空行结束
3. **文件读取**: 从文本文件读取内容

## 许可证

MIT License