"""
Tool streaming exceptions for comprehensive error handling.

Provides specific exception types for tool streaming failures.
"""


class ToolStreamingError(Exception):
    """Base exception for tool streaming errors."""
    
    def __init__(self, message: str, tool_name: str | None = None, original_error: Exception | None = None):
        super().__init__(message)
        self.tool_name = tool_name
        self.original_error = original_error
    
    def __str__(self) -> str:
        base_msg = super().__str__()
        if self.tool_name:
            base_msg = f"[{self.tool_name}] {base_msg}"
        if self.original_error:
            base_msg = f"{base_msg} (caused by: {self.original_error})"
        return base_msg


class StreamContextError(ToolStreamingError):
    """Exception for stream context initialization or operation errors."""
    pass


class EventEmissionError(ToolStreamingError):
    """Exception for event emission failures."""
    pass


class StreamMergingError(ToolStreamingError):
    """Exception for stream merging failures."""
    pass


class ToolConfigurationError(ToolStreamingError):
    """Exception for tool streaming configuration errors."""
    pass


class StreamCleanupError(ToolStreamingError):
    """Exception for stream cleanup failures."""
    pass