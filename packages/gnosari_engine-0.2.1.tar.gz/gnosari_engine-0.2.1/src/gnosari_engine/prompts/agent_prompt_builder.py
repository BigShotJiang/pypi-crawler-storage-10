"""
Default agent prompt builder implementation.
Builds comprehensive agent prompts including traits, knowledge, and tools.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..schemas.domain.agent import Agent
    from ..schemas.domain.team import Team

from .interfaces import IPromptBuilder


class AgentPromptBuilder(IPromptBuilder):
    """
    Default implementation of agent prompt building.
    Follows Single Responsibility Principle - only builds agent prompts.
    """

    def build_agent_prompt(self, agent: "Agent", team: "Team | None" = None) -> str:
        """
        Build enhanced agent prompt including traits, knowledge, and tools.

        Args:
            agent: Agent configuration with base instructions
            team: Optional team context providing available tools, knowledge, and traits

        Returns:
            Enhanced instructions string ready for LLM execution
        """
        prompt_parts = []
        if agent.name:
            prompt_parts.append(f"You are {agent.name}. ")

        # Only add team-based enhancements if team is provided
        if team is not None:
            prompt_parts.append(f"You are part of the team {team.name}. \n")

        prompt_parts.append(agent.instructions)
        # Add traits section - agent has direct trait objects
        if agent.traits:
            prompt_parts.append("\n## Your Traits:")
            for trait in agent.traits:
                prompt_parts.append(f"- **{trait.name}**: {trait.description}")
                # Add trait instructions for behavior modification
                if trait.instructions:
                    prompt_parts.append(f"  Instructions: {trait.instructions}")

        # Add knowledge section - agent has direct knowledge objects
        if agent.knowledge:
            prompt_parts.append("\n## Available Knowledge Sources:")
            prompt_parts.append("Use the knowledge_query tool to search these knowledge bases:")
            for kb in agent.knowledge:
                prompt_parts.append(f"- **{kb.id}** ({kb.name}): {kb.description}")

            prompt_parts.append("\nTo query a knowledge base, use: knowledge_query(query='your search terms', knowledge_name='knowledge_base_id')")

        # Add tools section - agent has direct tool objects
        if agent.tools:
            prompt_parts.append("\n## Available Tools:")
            for tool in agent.tools:
                prompt_parts.append(f"- **{tool.name}**: {tool.description}")

        # Add memory section - only if memory content is not empty
        if agent.memory and not agent.memory.is_empty():
            prompt_parts.append("\n## Your Memory:")
            prompt_parts.append(agent.memory.content)

        return "\n".join(prompt_parts)