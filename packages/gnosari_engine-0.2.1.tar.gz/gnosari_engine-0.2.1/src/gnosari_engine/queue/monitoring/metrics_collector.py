"""
Metrics collection implementations for queue monitoring.
Supports different storage backends for metrics data.
"""

import time
from datetime import datetime, timedelta
from typing import Any

import redis.asyncio as redis

from ..interfaces.monitoring_interfaces import IMetricsCollector
from .exceptions import MetricsCollectionError


class InMemoryMetricsCollector(IMetricsCollector):
    """
    In-memory metrics collector for development and testing.
    
    Stores metrics in memory with simple aggregation.
    Not suitable for production use across multiple processes.
    """
    
    def __init__(self, retention_hours: int = 24) -> None:
        """
        Initialize in-memory metrics collector.
        
        Args:
            retention_hours: How long to keep metrics in memory
        """
        self.retention_hours = retention_hours
        self.metrics: dict[str, list[dict[str, Any]]] = {}
        self.counters: dict[str, int] = {}
        self.timers: dict[str, list[float]] = {}
    
    async def record_metric(
        self, 
        metric_name: str, 
        value: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Record a metric value."""
        try:
            if metric_name not in self.metrics:
                self.metrics[metric_name] = []
            
            metric_entry = {
                "value": value,
                "timestamp": datetime.utcnow().isoformat(),
                "tags": tags or {},
            }
            
            self.metrics[metric_name].append(metric_entry)
            await self._cleanup_old_metrics()
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to record metric: {e}", metric_name) from e
    
    async def increment_counter(
        self, 
        counter_name: str, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Increment a counter metric."""
        try:
            # Create tagged counter name if tags provided
            if tags:
                tagged_name = f"{counter_name}:{','.join(f'{k}={v}' for k, v in tags.items())}"
            else:
                tagged_name = counter_name
            
            self.counters[tagged_name] = self.counters.get(tagged_name, 0) + 1
            
            # Also record as regular metric for time series
            await self.record_metric(counter_name, self.counters[tagged_name], tags)
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to increment counter: {e}", counter_name) from e
    
    async def record_timing(
        self, 
        timer_name: str, 
        duration_ms: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Record a timing metric."""
        try:
            if timer_name not in self.timers:
                self.timers[timer_name] = []
            
            self.timers[timer_name].append(duration_ms)
            
            # Keep only recent timings
            if len(self.timers[timer_name]) > 1000:
                self.timers[timer_name] = self.timers[timer_name][-1000:]
            
            # Record as regular metric too
            await self.record_metric(timer_name, duration_ms, tags)
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to record timing: {e}", timer_name) from e
    
    async def get_metrics(self, metric_name: str) -> list[dict[str, Any]]:
        """Get all values for a metric."""
        return self.metrics.get(metric_name, [])
    
    async def get_counter_value(self, counter_name: str) -> int:
        """Get current counter value."""
        return self.counters.get(counter_name, 0)
    
    async def get_timer_stats(self, timer_name: str) -> dict[str, float]:
        """Get statistics for a timer."""
        timings = self.timers.get(timer_name, [])
        if not timings:
            return {"count": 0, "avg": 0, "min": 0, "max": 0}
        
        return {
            "count": len(timings),
            "avg": sum(timings) / len(timings),
            "min": min(timings),
            "max": max(timings),
        }
    
    async def _cleanup_old_metrics(self) -> None:
        """Remove old metrics beyond retention period."""
        cutoff_time = datetime.utcnow() - timedelta(hours=self.retention_hours)
        cutoff_str = cutoff_time.isoformat()
        
        for metric_name, entries in self.metrics.items():
            self.metrics[metric_name] = [
                entry for entry in entries 
                if entry["timestamp"] > cutoff_str
            ]


class RedisMetricsCollector(IMetricsCollector):
    """
    Redis-based metrics collector for production use.
    
    Stores metrics in Redis with automatic expiration and aggregation.
    Suitable for distributed systems and high-throughput scenarios.
    """
    
    def __init__(
        self, 
        redis_client: redis.Redis,
        key_prefix: str = "metrics:",
        retention_seconds: int = 86400  # 24 hours
    ) -> None:
        """
        Initialize Redis metrics collector.
        
        Args:
            redis_client: Redis client instance
            key_prefix: Prefix for Redis keys
            retention_seconds: How long to keep metrics
        """
        self.redis = redis_client
        self.key_prefix = key_prefix
        self.retention_seconds = retention_seconds
    
    async def record_metric(
        self, 
        metric_name: str, 
        value: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Record a metric value in Redis."""
        try:
            timestamp = int(time.time())
            
            # Create metric key with tags
            tag_suffix = ""
            if tags:
                tag_suffix = ":" + ",".join(f"{k}={v}" for k, v in tags.items())
            
            metric_key = f"{self.key_prefix}{metric_name}{tag_suffix}"
            
            # Store as time series data
            pipe = self.redis.pipeline()
            
            # Add to sorted set with timestamp as score
            pipe.zadd(f"{metric_key}:values", {str(value): timestamp})
            
            # Set expiration
            pipe.expire(f"{metric_key}:values", self.retention_seconds)
            
            # Store latest value
            pipe.set(f"{metric_key}:latest", value, ex=self.retention_seconds)
            
            await pipe.execute()
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to record metric: {e}", metric_name) from e
    
    async def increment_counter(
        self, 
        counter_name: str, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Increment a counter in Redis."""
        try:
            tag_suffix = ""
            if tags:
                tag_suffix = ":" + ",".join(f"{k}={v}" for k, v in tags.items())
            
            counter_key = f"{self.key_prefix}{counter_name}{tag_suffix}:counter"
            
            # Increment counter
            await self.redis.incr(counter_key)
            await self.redis.expire(counter_key, self.retention_seconds)
            
            # Also record as time series
            current_value = await self.redis.get(counter_key)
            if current_value:
                await self.record_metric(counter_name, float(current_value), tags)
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to increment counter: {e}", counter_name) from e
    
    async def record_timing(
        self, 
        timer_name: str, 
        duration_ms: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """Record a timing metric in Redis."""
        try:
            tag_suffix = ""
            if tags:
                tag_suffix = ":" + ",".join(f"{k}={v}" for k, v in tags.items())
            
            timer_key = f"{self.key_prefix}{timer_name}{tag_suffix}:timer"
            
            # Store timing in list (keep last 1000)
            pipe = self.redis.pipeline()
            pipe.lpush(timer_key, duration_ms)
            pipe.ltrim(timer_key, 0, 999)  # Keep last 1000 timings
            pipe.expire(timer_key, self.retention_seconds)
            
            await pipe.execute()
            
            # Also record as regular metric
            await self.record_metric(timer_name, duration_ms, tags)
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to record timing: {e}", timer_name) from e
    
    async def get_metrics(
        self, 
        metric_name: str, 
        start_time: int | None = None,
        end_time: int | None = None
    ) -> list[dict[str, Any]]:
        """Get metrics from Redis within time range."""
        try:
            metric_key = f"{self.key_prefix}{metric_name}:values"
            
            # Get values within time range
            start_score = start_time or 0
            end_score = end_time or int(time.time())
            
            values = await self.redis.zrangebyscore(
                metric_key, start_score, end_score, withscores=True
            )
            
            return [
                {
                    "value": float(value.decode()),
                    "timestamp": int(score),
                    "datetime": datetime.fromtimestamp(score).isoformat(),
                }
                for value, score in values
            ]
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to get metrics: {e}", metric_name) from e
    
    async def get_counter_value(self, counter_name: str, tags: dict[str, str] | None = None) -> int:
        """Get current counter value from Redis."""
        try:
            tag_suffix = ""
            if tags:
                tag_suffix = ":" + ",".join(f"{k}={v}" for k, v in tags.items())
            
            counter_key = f"{self.key_prefix}{counter_name}{tag_suffix}:counter"
            value = await self.redis.get(counter_key)
            
            return int(value) if value else 0
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to get counter: {e}", counter_name) from e
    
    async def get_timer_stats(self, timer_name: str, tags: dict[str, str] | None = None) -> dict[str, float]:
        """Get timer statistics from Redis."""
        try:
            tag_suffix = ""
            if tags:
                tag_suffix = ":" + ",".join(f"{k}={v}" for k, v in tags.items())
            
            timer_key = f"{self.key_prefix}{timer_name}{tag_suffix}:timer"
            
            # Get all timing values
            timings_bytes = await self.redis.lrange(timer_key, 0, -1)
            timings = [float(t.decode()) for t in timings_bytes]
            
            if not timings:
                return {"count": 0, "avg": 0, "min": 0, "max": 0}
            
            return {
                "count": len(timings),
                "avg": sum(timings) / len(timings),
                "min": min(timings),
                "max": max(timings),
            }
            
        except Exception as e:
            raise MetricsCollectionError(f"Failed to get timer stats: {e}", timer_name) from e


class MetricsCollectorFactory:
    """Factory for creating metrics collectors."""
    
    @staticmethod
    def create_in_memory(retention_hours: int = 24) -> InMemoryMetricsCollector:
        """Create in-memory metrics collector."""
        return InMemoryMetricsCollector(retention_hours=retention_hours)
    
    @staticmethod
    def create_redis(
        redis_client: redis.Redis,
        key_prefix: str = "metrics:",
        retention_seconds: int = 86400
    ) -> RedisMetricsCollector:
        """Create Redis metrics collector."""
        return RedisMetricsCollector(
            redis_client=redis_client,
            key_prefix=key_prefix,
            retention_seconds=retention_seconds
        )
    
    @staticmethod
    def create_from_config(config: dict[str, Any]) -> IMetricsCollector:
        """Create metrics collector from configuration."""
        collector_type = config.get("type", "memory")
        
        if collector_type == "memory":
            return MetricsCollectorFactory.create_in_memory(
                retention_hours=config.get("retention_hours", 24)
            )
        elif collector_type == "redis":
            # This would require Redis client to be passed in config
            redis_client = config.get("redis_client")
            if not redis_client:
                raise ValueError("Redis client required for Redis metrics collector")
            
            return MetricsCollectorFactory.create_redis(
                redis_client=redis_client,
                key_prefix=config.get("key_prefix", "metrics:"),
                retention_seconds=config.get("retention_seconds", 86400)
            )
        else:
            raise ValueError(f"Unknown metrics collector type: {collector_type}")