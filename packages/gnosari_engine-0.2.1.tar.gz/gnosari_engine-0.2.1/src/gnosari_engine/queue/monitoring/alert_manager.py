"""
Alert management for queue system monitoring.
Handles alert rules, notifications, and escalation.
"""

import asyncio
from datetime import datetime
from typing import Any, Callable

from ..interfaces.monitoring_interfaces import IAlertManager
from .exceptions import AlertError


class AlertRule:
    """Represents an alert rule with condition and action."""
    
    def __init__(
        self,
        name: str,
        condition: str,
        threshold: float,
        severity: str = "warning",
        cooldown_minutes: int = 5,
        action: Callable[[dict[str, Any]], None] | None = None
    ) -> None:
        """
        Initialize alert rule.
        
        Args:
            name: Rule name
            condition: Condition expression (e.g., 'queue_length > 100')
            threshold: Threshold value for triggering
            severity: Alert severity level
            cooldown_minutes: Minimum time between alerts
            action: Custom action to execute
        """
        self.name = name
        self.condition = condition
        self.threshold = threshold
        self.severity = severity
        self.cooldown_minutes = cooldown_minutes
        self.action = action
        self.last_triggered: datetime | None = None
        self.trigger_count = 0


class SimpleAlertManager(IAlertManager):
    """
    Simple alert manager implementation.
    
    Provides basic alerting capabilities with rule evaluation
    and notification handling.
    """
    
    def __init__(self, enable_console_alerts: bool = True) -> None:
        """
        Initialize alert manager.
        
        Args:
            enable_console_alerts: Whether to print alerts to console
        """
        self.enable_console_alerts = enable_console_alerts
        self.alert_rules: dict[str, AlertRule] = {}
        self.alert_history: list[dict[str, Any]] = []
        self.notification_handlers: list[Callable[[str, str, str, dict[str, Any]], None]] = []
        
        # Built-in alert rules
        self._register_default_rules()
    
    async def send_alert(
        self,
        alert_type: str,
        message: str,
        severity: str = "warning",
        metadata: dict[str, Any] | None = None
    ) -> None:
        """Send an alert notification."""
        try:
            alert_data = {
                "type": alert_type,
                "message": message,
                "severity": severity,
                "metadata": metadata or {},
                "timestamp": datetime.utcnow().isoformat(),
            }
            
            # Store in history
            self.alert_history.append(alert_data)
            
            # Keep only last 1000 alerts
            if len(self.alert_history) > 1000:
                self.alert_history = self.alert_history[-1000:]
            
            # Console output if enabled
            if self.enable_console_alerts:
                print(f"[ALERT] {severity.upper()}: {alert_type} - {message}")
                if metadata:
                    print(f"        Metadata: {metadata}")
            
            # Call notification handlers
            for handler in self.notification_handlers:
                try:
                    await asyncio.create_task(
                        self._safe_call_handler(handler, alert_type, message, severity, metadata or {})
                    )
                except Exception as e:
                    print(f"Alert handler failed: {e}")
            
        except Exception as e:
            raise AlertError(f"Failed to send alert: {e}", alert_type) from e
    
    async def check_alert_rules(self, queue_stats: dict[str, Any]) -> None:
        """Check queue statistics against alert rules."""
        try:
            for rule_name, rule in self.alert_rules.items():
                try:
                    if await self._evaluate_rule(rule, queue_stats):
                        await self._trigger_alert(rule, queue_stats)
                except Exception as e:
                    print(f"Error evaluating rule {rule_name}: {e}")
        
        except Exception as e:
            raise AlertError(f"Failed to check alert rules: {e}") from e
    
    def register_alert_rule(
        self,
        rule_name: str,
        condition: str,
        action: str,
        threshold: float = 0,
        severity: str = "warning",
        cooldown_minutes: int = 5
    ) -> None:
        """Register a new alert rule."""
        try:
            # Parse action (simplified)
            action_func = None
            if action == "log":
                action_func = lambda data: print(f"Rule triggered: {rule_name}")
            elif action == "email":
                action_func = lambda data: print(f"Email alert: {rule_name}")
            
            rule = AlertRule(
                name=rule_name,
                condition=condition,
                threshold=threshold,
                severity=severity,
                cooldown_minutes=cooldown_minutes,
                action=action_func
            )
            
            self.alert_rules[rule_name] = rule
            
        except Exception as e:
            raise AlertError(f"Failed to register rule {rule_name}: {e}") from e
    
    def add_notification_handler(
        self,
        handler: Callable[[str, str, str, dict[str, Any]], None]
    ) -> None:
        """Add a notification handler."""
        self.notification_handlers.append(handler)
    
    def get_alert_history(self, limit: int = 100) -> list[dict[str, Any]]:
        """Get recent alert history."""
        return self.alert_history[-limit:]
    
    def get_alert_rules(self) -> dict[str, dict[str, Any]]:
        """Get all alert rules."""
        return {
            name: {
                "condition": rule.condition,
                "threshold": rule.threshold,
                "severity": rule.severity,
                "cooldown_minutes": rule.cooldown_minutes,
                "trigger_count": rule.trigger_count,
                "last_triggered": rule.last_triggered.isoformat() if rule.last_triggered else None,
            }
            for name, rule in self.alert_rules.items()
        }
    
    # Private methods
    
    def _register_default_rules(self) -> None:
        """Register default alert rules."""
        # Queue length alerts
        self.register_alert_rule(
            "high_queue_length",
            "queue_length > threshold",
            "log",
            threshold=100,
            severity="warning"
        )
        
        self.register_alert_rule(
            "critical_queue_length",
            "queue_length > threshold",
            "log",
            threshold=1000,
            severity="critical"
        )
        
        # Error rate alerts
        self.register_alert_rule(
            "high_error_rate",
            "error_rate > threshold",
            "log",
            threshold=10.0,
            severity="warning"
        )
        
        self.register_alert_rule(
            "critical_error_rate",
            "error_rate > threshold",
            "log",
            threshold=25.0,
            severity="critical"
        )
        
        # Dead letter queue alerts
        self.register_alert_rule(
            "dead_letter_messages",
            "dead_letter_count > threshold",
            "log",
            threshold=0,
            severity="warning"
        )
    
    async def _evaluate_rule(self, rule: AlertRule, stats: dict[str, Any]) -> bool:
        """Evaluate if a rule condition is met."""
        try:
            # Check cooldown period
            if rule.last_triggered:
                time_since_last = datetime.utcnow() - rule.last_triggered
                if time_since_last.total_seconds() < (rule.cooldown_minutes * 60):
                    return False
            
            # Simple condition evaluation
            if "queue_length" in rule.condition:
                queue_length = stats.get("queue_length", 0)
                if ">" in rule.condition:
                    return queue_length > rule.threshold
                elif "<" in rule.condition:
                    return queue_length < rule.threshold
            
            elif "error_rate" in rule.condition:
                error_rate = stats.get("error_rate", 0)
                if ">" in rule.condition:
                    return error_rate > rule.threshold
                elif "<" in rule.condition:
                    return error_rate < rule.threshold
            
            elif "dead_letter_count" in rule.condition:
                dead_letter_count = stats.get("dead_letter_count", 0)
                if ">" in rule.condition:
                    return dead_letter_count > rule.threshold
                elif "<" in rule.condition:
                    return dead_letter_count < rule.threshold
            
            return False
            
        except Exception as e:
            print(f"Error evaluating rule condition: {e}")
            return False
    
    async def _trigger_alert(self, rule: AlertRule, stats: dict[str, Any]) -> None:
        """Trigger an alert for a rule."""
        try:
            rule.last_triggered = datetime.utcnow()
            rule.trigger_count += 1
            
            # Generate alert message
            message = f"Rule '{rule.name}' triggered: {rule.condition}"
            
            # Send alert
            await self.send_alert(
                alert_type=f"rule_{rule.name}",
                message=message,
                severity=rule.severity,
                metadata={
                    "rule_name": rule.name,
                    "condition": rule.condition,
                    "threshold": rule.threshold,
                    "trigger_count": rule.trigger_count,
                    "queue_stats": stats,
                }
            )
            
            # Execute custom action if defined
            if rule.action:
                try:
                    await asyncio.create_task(
                        self._safe_call_action(rule.action, stats)
                    )
                except Exception as e:
                    print(f"Error executing rule action: {e}")
        
        except Exception as e:
            print(f"Error triggering alert for rule {rule.name}: {e}")
    
    async def _safe_call_handler(
        self,
        handler: Callable,
        alert_type: str,
        message: str,
        severity: str,
        metadata: dict[str, Any]
    ) -> None:
        """Safely call notification handler."""
        if asyncio.iscoroutinefunction(handler):
            await handler(alert_type, message, severity, metadata)
        else:
            handler(alert_type, message, severity, metadata)
    
    async def _safe_call_action(self, action: Callable, data: dict[str, Any]) -> None:
        """Safely call rule action."""
        if asyncio.iscoroutinefunction(action):
            await action(data)
        else:
            action(data)