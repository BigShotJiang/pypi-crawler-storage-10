"""Monitoring-related exceptions."""


class MonitoringError(Exception):
    """Base exception for monitoring errors."""
    pass


class MetricsCollectionError(MonitoringError):
    """Raised when metrics collection fails."""
    
    def __init__(self, message: str, metric_name: str | None = None) -> None:
        super().__init__(message)
        self.metric_name = metric_name


class QueueMonitoringError(MonitoringError):
    """Raised when queue monitoring fails."""
    
    def __init__(self, message: str, queue_name: str | None = None) -> None:
        super().__init__(message)
        self.queue_name = queue_name


class AlertError(MonitoringError):
    """Raised when alert operations fail."""
    
    def __init__(self, message: str, alert_type: str | None = None) -> None:
        super().__init__(message)
        self.alert_type = alert_type


class HealthCheckError(MonitoringError):
    """Raised when health check fails."""
    
    def __init__(self, message: str, component: str | None = None) -> None:
        super().__init__(message)
        self.component = component