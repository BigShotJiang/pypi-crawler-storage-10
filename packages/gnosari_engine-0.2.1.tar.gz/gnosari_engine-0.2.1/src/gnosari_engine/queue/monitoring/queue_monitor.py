"""
Queue monitoring implementation for Redis-based queues.
Provides comprehensive monitoring and health check capabilities.
"""

import time
from datetime import datetime, timedelta
from typing import Any

import redis.asyncio as redis

from ..interfaces.monitoring_interfaces import IQueueMonitor
from .exceptions import QueueMonitoringError, HealthCheckError


class RedisQueueMonitor(IQueueMonitor):
    """
    Redis-based queue monitor implementation.
    
    Provides monitoring capabilities for Redis queue systems including
    queue statistics, message status tracking, and health checks.
    """
    
    def __init__(
        self,
        redis_client: redis.Redis,
        cache_ttl_seconds: int = 30
    ) -> None:
        """
        Initialize Redis queue monitor.
        
        Args:
            redis_client: Redis client for monitoring operations
            cache_ttl_seconds: Cache TTL for expensive operations
        """
        self.redis = redis_client
        self.cache_ttl = cache_ttl_seconds
        self._stats_cache: dict[str, dict[str, Any]] = {}
        self._last_cache_update: dict[str, float] = {}
    
    async def get_queue_stats(self, queue_name: str) -> dict[str, Any]:
        """Get comprehensive queue statistics."""
        try:
            # Check cache first
            if self._is_cache_valid(queue_name):
                return self._stats_cache[queue_name]
            
            # Collect fresh statistics
            stats = await self._collect_queue_stats(queue_name)
            
            # Cache results
            self._stats_cache[queue_name] = stats
            self._last_cache_update[queue_name] = time.time()
            
            return stats
            
        except Exception as e:
            raise QueueMonitoringError(f"Failed to get stats for queue {queue_name}: {e}", queue_name) from e
    
    async def get_message_status(self, message_id: str) -> dict[str, Any]:
        """Get detailed message status."""
        try:
            message_key = f"message:{message_id}"
            
            # Get message metadata
            message_data = await self.redis.hgetall(message_key)
            
            if not message_data:
                return {
                    "message_id": message_id,
                    "status": "not_found",
                    "error": "Message not found in system"
                }
            
            # Decode Redis data
            decoded_data = {
                key.decode(): value.decode() if isinstance(value, bytes) else value
                for key, value in message_data.items()
            }
            
            # Calculate processing time if available
            processing_time = None
            if decoded_data.get("started_at") and decoded_data.get("completed_at"):
                start_time = datetime.fromisoformat(decoded_data["started_at"])
                end_time = datetime.fromisoformat(decoded_data["completed_at"])
                processing_time = int((end_time - start_time).total_seconds() * 1000)
            
            return {
                "message_id": message_id,
                "status": decoded_data.get("status", "unknown"),
                "type": decoded_data.get("type"),
                "queue_name": decoded_data.get("queue_name"),
                "created_at": decoded_data.get("created_at"),
                "started_at": decoded_data.get("started_at"),
                "completed_at": decoded_data.get("completed_at"),
                "attempts": int(decoded_data.get("attempts", 0)),
                "processing_time_ms": processing_time,
                "last_error": decoded_data.get("last_error"),
            }
            
        except Exception as e:
            raise QueueMonitoringError(f"Failed to get message status: {e}") from e
    
    async def get_system_health(self) -> dict[str, Any]:
        """Get overall system health."""
        try:
            health_data = {
                "timestamp": datetime.utcnow().isoformat(),
                "overall_status": "healthy",
                "components": {},
                "summary": {
                    "total_queues": 0,
                    "total_messages": 0,
                    "active_consumers": 0,
                    "error_rate": 0.0,
                }
            }
            
            # Check Redis connection
            try:
                await self.redis.ping()
                health_data["components"]["redis"] = {
                    "status": "healthy",
                    "response_time_ms": await self._measure_redis_latency()
                }
            except Exception as e:
                health_data["components"]["redis"] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
                health_data["overall_status"] = "degraded"
            
            # Get queue statistics
            queue_keys = await self.redis.keys("queue_config:*")
            health_data["summary"]["total_queues"] = len(queue_keys)
            
            total_messages = 0
            error_count = 0
            success_count = 0
            
            for queue_key in queue_keys:
                queue_name = queue_key.decode().replace("queue_config:", "")
                try:
                    stats = await self._collect_queue_stats(queue_name)
                    total_messages += stats["queue_length"]
                    total_messages += stats["processing_count"]
                    total_messages += stats["delayed_count"]
                    
                    # Aggregate error rates
                    if "error_rate" in stats and stats["error_rate"] is not None:
                        if stats["error_rate"] > 50:  # More than 50% error rate
                            error_count += 1
                        else:
                            success_count += 1
                    
                except Exception:
                    # Skip problematic queues
                    continue
            
            health_data["summary"]["total_messages"] = total_messages
            
            # Calculate overall error rate
            total_queue_checks = error_count + success_count
            if total_queue_checks > 0:
                health_data["summary"]["error_rate"] = (error_count / total_queue_checks) * 100
            
            # Determine overall status
            if health_data["summary"]["error_rate"] > 25:
                health_data["overall_status"] = "unhealthy"
            elif health_data["summary"]["error_rate"] > 10:
                health_data["overall_status"] = "degraded"
            
            return health_data
            
        except Exception as e:
            raise HealthCheckError(f"Failed to get system health: {e}") from e
    
    async def get_performance_metrics(
        self, 
        time_range_minutes: int = 60
    ) -> dict[str, Any]:
        """Get performance metrics over time range."""
        try:
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(minutes=time_range_minutes)
            
            metrics = {
                "time_range": {
                    "start": start_time.isoformat(),
                    "end": end_time.isoformat(),
                    "duration_minutes": time_range_minutes
                },
                "throughput": await self._calculate_throughput(start_time, end_time),
                "latency": await self._calculate_latency_metrics(),
                "error_rates": await self._calculate_error_rates(start_time, end_time),
                "queue_depths": await self._get_queue_depths(),
            }
            
            return metrics
            
        except Exception as e:
            raise QueueMonitoringError(f"Failed to get performance metrics: {e}") from e
    
    # Private helper methods
    
    def _is_cache_valid(self, queue_name: str) -> bool:
        """Check if cached stats are still valid."""
        if queue_name not in self._last_cache_update:
            return False
        
        age = time.time() - self._last_cache_update[queue_name]
        return age < self.cache_ttl
    
    async def _collect_queue_stats(self, queue_name: str) -> dict[str, Any]:
        """Collect fresh queue statistics."""
        pipe = self.redis.pipeline()
        
        # Get queue lengths
        pipe.llen(queue_name)  # Main queue
        pipe.llen(f"{queue_name}:priority")  # Priority queue
        pipe.zcard(f"{queue_name}:delayed")  # Delayed messages
        pipe.llen(f"{queue_name}:dead_letter")  # Dead letter queue
        
        results = await pipe.execute()
        
        queue_length = results[0] or 0
        priority_length = results[1] or 0
        delayed_count = results[2] or 0
        dead_letter_count = results[3] or 0
        
        # Calculate additional metrics
        total_pending = queue_length + priority_length + delayed_count
        
        # Get processing count (approximate from active message keys)
        processing_pattern = f"message:*"
        processing_keys = await self.redis.keys(processing_pattern)
        processing_count = len([k for k in processing_keys if b"processing" in k])
        
        # Calculate throughput and error rate (simplified)
        throughput = await self._calculate_simple_throughput(queue_name)
        error_rate = await self._calculate_simple_error_rate(queue_name)
        
        return {
            "queue_name": queue_name,
            "queue_length": total_pending,
            "priority_length": priority_length,
            "delayed_count": delayed_count,
            "dead_letter_count": dead_letter_count,
            "processing_count": processing_count,
            "throughput_per_minute": throughput,
            "error_rate": error_rate,
            "last_updated": datetime.utcnow().isoformat(),
        }
    
    async def _measure_redis_latency(self) -> float:
        """Measure Redis response latency."""
        start_time = time.time()
        await self.redis.ping()
        end_time = time.time()
        return (end_time - start_time) * 1000  # Convert to milliseconds
    
    async def _calculate_simple_throughput(self, queue_name: str) -> float:
        """Calculate simple throughput metric."""
        # This is a simplified implementation
        # In production, you'd want to track actual message processing rates
        try:
            completed_key = f"stats:{queue_name}:completed"
            completed_count = await self.redis.get(completed_key)
            return float(completed_count or 0)
        except Exception:
            return 0.0
    
    async def _calculate_simple_error_rate(self, queue_name: str) -> float:
        """Calculate simple error rate."""
        try:
            failed_key = f"stats:{queue_name}:failed"
            completed_key = f"stats:{queue_name}:completed"
            
            failed_count = float(await self.redis.get(failed_key) or 0)
            completed_count = float(await self.redis.get(completed_key) or 0)
            
            total = failed_count + completed_count
            if total == 0:
                return 0.0
            
            return (failed_count / total) * 100
        except Exception:
            return 0.0
    
    async def _calculate_throughput(self, start_time: datetime, end_time: datetime) -> dict[str, float]:
        """Calculate throughput metrics."""
        # Simplified implementation
        return {
            "messages_per_minute": 0.0,
            "messages_per_second": 0.0,
        }
    
    async def _calculate_latency_metrics(self) -> dict[str, float]:
        """Calculate latency metrics."""
        # Simplified implementation
        return {
            "avg_processing_time_ms": 0.0,
            "p50_processing_time_ms": 0.0,
            "p95_processing_time_ms": 0.0,
            "p99_processing_time_ms": 0.0,
        }
    
    async def _calculate_error_rates(self, start_time: datetime, end_time: datetime) -> dict[str, float]:
        """Calculate error rate metrics."""
        # Simplified implementation
        return {
            "overall_error_rate": 0.0,
            "timeout_rate": 0.0,
            "retry_rate": 0.0,
        }
    
    async def _get_queue_depths(self) -> dict[str, int]:
        """Get current queue depths."""
        queue_keys = await self.redis.keys("queue_config:*")
        queue_depths = {}
        
        for queue_key in queue_keys:
            queue_name = queue_key.decode().replace("queue_config:", "")
            try:
                depth = await self.redis.llen(queue_name)
                queue_depths[queue_name] = depth or 0
            except Exception:
                queue_depths[queue_name] = -1  # Error getting depth
        
        return queue_depths