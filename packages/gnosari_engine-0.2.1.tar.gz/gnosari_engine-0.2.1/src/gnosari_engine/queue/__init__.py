"""
Enterprise-grade queue system for Gnosari AI Teams.

This module provides asynchronous message queue functionality with:
- Type-safe message objects with Pydantic validation
- SOLID principles architecture with clear separation of concerns
- Multiple queue provider support (Redis, RabbitMQ, etc.)
- Retry logic with exponential backoff
- Monitoring and observability features
- Horizontal scaling capabilities
"""

from .messages.base import BaseMessage, MessagePriority, MessageStatus
from .interfaces import (
    IMessageSerializer,
    IQueueProducer,
    IQueueConsumer,
    IQueueManager,
    IMessageProcessor,
    IRetryStrategy,
    IQueueMonitor,
)
from .factories.queue_factory import QueueFactory

__all__ = [
    "BaseMessage",
    "MessagePriority", 
    "MessageStatus",
    "IMessageSerializer",
    "IQueueProducer",
    "IQueueConsumer", 
    "IQueueManager",
    "IMessageProcessor",
    "IRetryStrategy",
    "IQueueMonitor",
    "QueueFactory",
]