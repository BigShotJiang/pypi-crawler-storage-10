"""
Message processors for knowledge management operations.
Handles knowledge indexing, querying, and maintenance.
"""

from typing import Any

from ..interfaces.message_interfaces import IMessageProcessor
from ..messages.base import BaseMessage
from ..messages.knowledge_messages import (
    KnowledgeIndexingMessage,
    KnowledgeMaintenanceMessage,
    KnowledgeQueryMessage,
)


class KnowledgeIndexingProcessor(IMessageProcessor[KnowledgeIndexingMessage]):
    """
    Processor for knowledge base indexing operations.
    
    Handles asynchronous indexing of content into knowledge bases.
    """
    
    def __init__(self, knowledge_service: Any = None) -> None:
        """
        Initialize knowledge indexing processor.
        
        Args:
            knowledge_service: Service for knowledge operations
        """
        self.knowledge_service = knowledge_service
        self.supported_types = ["knowledge.indexing"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: KnowledgeIndexingMessage) -> bool:
        """Validate knowledge indexing message."""
        payload = message.payload
        
        if not payload.knowledge_base_id:
            raise ValueError("knowledge_base_id is required")
        if not payload.content_source:
            raise ValueError("content_source is required")
        if not payload.content_type:
            raise ValueError("content_type is required")
        
        # Validate content type
        valid_types = ["website", "file", "text", "document", "api"]
        if payload.content_type not in valid_types:
            raise ValueError(f"content_type must be one of: {valid_types}")
        
        return True
    
    async def process(self, message: KnowledgeIndexingMessage) -> Any:
        """
        Process knowledge indexing message.
        
        Args:
            message: Knowledge indexing message to process
            
        Returns:
            Indexing result
        """
        payload = message.payload
        
        try:
            indexing_result = {
                "knowledge_base_id": payload.knowledge_base_id,
                "content_source": payload.content_source,
                "content_type": payload.content_type,
                "status": "completed",
                "chunks_indexed": 0,
                "total_tokens": 0,
                "indexing_options": payload.indexing_options,
            }
            
            # TODO: Implement actual indexing logic
            if self.knowledge_service:
                indexing_result = await self.knowledge_service.index_content(
                    knowledge_base_id=payload.knowledge_base_id,
                    content_source=payload.content_source,
                    content_type=payload.content_type,
                    force_reindex=payload.force_reindex,
                    chunk_size=payload.chunk_size,
                    overlap_size=payload.overlap_size,
                    indexing_options=payload.indexing_options,
                )
            else:
                # Mock indexing for now
                indexing_result["status"] = "skipped"
                indexing_result["reason"] = "knowledge_service not configured"
                indexing_result["chunks_indexed"] = 0
            
            return indexing_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "knowledge_base_id": payload.knowledge_base_id,
                "content_source": payload.content_source,
                "message_id": message.id,
            }
            
            print(f"Knowledge indexing failed: {error_details}")
            raise


class KnowledgeQueryProcessor(IMessageProcessor[KnowledgeQueryMessage]):
    """
    Processor for knowledge query operations.
    
    Handles asynchronous knowledge base queries.
    """
    
    def __init__(self, knowledge_service: Any = None) -> None:
        """
        Initialize knowledge query processor.
        
        Args:
            knowledge_service: Service for knowledge operations
        """
        self.knowledge_service = knowledge_service
        self.supported_types = ["knowledge.query"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: KnowledgeQueryMessage) -> bool:
        """Validate knowledge query message."""
        payload = message.payload
        
        if not payload.knowledge_base_id:
            raise ValueError("knowledge_base_id is required")
        if not payload.query:
            raise ValueError("query is required")
        
        # Validate parameters
        if payload.top_k <= 0:
            raise ValueError("top_k must be positive")
        if not (0.0 <= payload.similarity_threshold <= 1.0):
            raise ValueError("similarity_threshold must be between 0.0 and 1.0")
        
        return True
    
    async def process(self, message: KnowledgeQueryMessage) -> Any:
        """
        Process knowledge query message.
        
        Args:
            message: Knowledge query message to process
            
        Returns:
            Query result
        """
        payload = message.payload
        
        try:
            query_result = {
                "knowledge_base_id": payload.knowledge_base_id,
                "query": payload.query,
                "results": [],
                "total_results": 0,
                "query_time_ms": 0,
                "filters_applied": payload.filters,
            }
            
            # TODO: Implement actual query logic
            if self.knowledge_service:
                query_result = await self.knowledge_service.query_knowledge(
                    knowledge_base_id=payload.knowledge_base_id,
                    query=payload.query,
                    top_k=payload.top_k,
                    similarity_threshold=payload.similarity_threshold,
                    filters=payload.filters,
                    metadata_fields=payload.metadata_fields,
                )
            else:
                # Mock query for now
                query_result["results"] = []
                query_result["total_results"] = 0
                query_result["reason"] = "knowledge_service not configured"
            
            return query_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "knowledge_base_id": payload.knowledge_base_id,
                "query": payload.query,
                "message_id": message.id,
            }
            
            print(f"Knowledge query failed: {error_details}")
            raise


class KnowledgeMaintenanceProcessor(IMessageProcessor[KnowledgeMaintenanceMessage]):
    """
    Processor for knowledge base maintenance operations.
    
    Handles cleanup, optimization, and other maintenance tasks.
    """
    
    def __init__(self, knowledge_service: Any = None) -> None:
        """
        Initialize knowledge maintenance processor.
        
        Args:
            knowledge_service: Service for knowledge operations
        """
        self.knowledge_service = knowledge_service
        self.supported_types = ["knowledge.maintenance"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: KnowledgeMaintenanceMessage) -> bool:
        """Validate knowledge maintenance message."""
        payload = message.payload
        
        if not payload.knowledge_base_id:
            raise ValueError("knowledge_base_id is required")
        if not payload.operation:
            raise ValueError("operation is required")
        
        # Validate operation type
        valid_operations = [
            "cleanup", "optimize", "reindex", "compact", 
            "backup", "restore", "migrate"
        ]
        if payload.operation not in valid_operations:
            raise ValueError(f"operation must be one of: {valid_operations}")
        
        return True
    
    async def process(self, message: KnowledgeMaintenanceMessage) -> Any:
        """
        Process knowledge maintenance message.
        
        Args:
            message: Knowledge maintenance message to process
            
        Returns:
            Maintenance result
        """
        payload = message.payload
        
        try:
            maintenance_result = {
                "knowledge_base_id": payload.knowledge_base_id,
                "operation": payload.operation,
                "status": "completed",
                "parameters": payload.parameters,
                "schedule_time": payload.schedule_time,
                "items_processed": 0,
                "space_freed": 0,
            }
            
            # TODO: Implement actual maintenance logic
            if self.knowledge_service:
                maintenance_result = await self.knowledge_service.perform_maintenance(
                    knowledge_base_id=payload.knowledge_base_id,
                    operation=payload.operation,
                    parameters=payload.parameters,
                )
            else:
                # Mock maintenance for now
                maintenance_result["status"] = "skipped"
                maintenance_result["reason"] = "knowledge_service not configured"
            
            return maintenance_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "knowledge_base_id": payload.knowledge_base_id,
                "operation": payload.operation,
                "message_id": message.id,
            }
            
            print(f"Knowledge maintenance failed: {error_details}")
            raise