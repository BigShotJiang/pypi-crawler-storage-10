"""
Message processors for system-level operations.
Handles health checks, metrics collection, and system maintenance.
"""

import psutil
from typing import Any

from ..interfaces.message_interfaces import IMessageProcessor
from ..messages.base import BaseMessage
from ..messages.system_messages import (
    SystemCleanupMessage,
    SystemHealthCheckMessage,
    SystemMetricsMessage,
)


class SystemHealthCheckProcessor(IMessageProcessor[SystemHealthCheckMessage]):
    """
    Processor for system health check operations.
    
    Handles various health checks for system components.
    """
    
    def __init__(self, monitoring_service: Any = None) -> None:
        """
        Initialize system health check processor.
        
        Args:
            monitoring_service: Service for system monitoring
        """
        self.monitoring_service = monitoring_service
        self.supported_types = ["system.health_check"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: SystemHealthCheckMessage) -> bool:
        """Validate system health check message."""
        payload = message.payload
        
        if not payload.component:
            raise ValueError("component is required")
        if not payload.check_type:
            raise ValueError("check_type is required")
        
        # Validate component type
        valid_components = [
            "queue", "database", "redis", "api", "worker", 
            "disk", "memory", "cpu", "network"
        ]
        if payload.component not in valid_components:
            raise ValueError(f"component must be one of: {valid_components}")
        
        return True
    
    async def process(self, message: SystemHealthCheckMessage) -> Any:
        """
        Process system health check message.
        
        Args:
            message: Health check message to process
            
        Returns:
            Health check result
        """
        payload = message.payload
        
        try:
            health_result = {
                "component": payload.component,
                "check_type": payload.check_type,
                "status": "healthy",
                "details": {},
                "timestamp": message.created_at.isoformat(),
                "response_time_ms": 0,
            }
            
            # Perform specific health checks based on component
            if payload.component == "memory":
                health_result["details"] = await self._check_memory_health()
            elif payload.component == "cpu":
                health_result["details"] = await self._check_cpu_health()
            elif payload.component == "disk":
                health_result["details"] = await self._check_disk_health()
            elif payload.component == "queue":
                health_result["details"] = await self._check_queue_health()
            else:
                # Generic health check
                health_result["details"] = {"message": "Generic health check passed"}
            
            # Determine overall status based on details
            health_result["status"] = self._determine_health_status(
                health_result["details"], payload.component
            )
            
            return health_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "component": payload.component,
                "check_type": payload.check_type,
                "message_id": message.id,
            }
            
            print(f"Health check failed: {error_details}")
            raise
    
    async def _check_memory_health(self) -> dict[str, Any]:
        """Check system memory health."""
        memory = psutil.virtual_memory()
        return {
            "total_gb": round(memory.total / (1024**3), 2),
            "available_gb": round(memory.available / (1024**3), 2),
            "used_percent": memory.percent,
            "free_percent": round(100 - memory.percent, 2),
        }
    
    async def _check_cpu_health(self) -> dict[str, Any]:
        """Check CPU health."""
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        return {
            "cpu_percent": cpu_percent,
            "cpu_count": cpu_count,
            "load_average": psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None,
        }
    
    async def _check_disk_health(self) -> dict[str, Any]:
        """Check disk health."""
        disk_usage = psutil.disk_usage('/')
        return {
            "total_gb": round(disk_usage.total / (1024**3), 2),
            "used_gb": round(disk_usage.used / (1024**3), 2),
            "free_gb": round(disk_usage.free / (1024**3), 2),
            "used_percent": round((disk_usage.used / disk_usage.total) * 100, 2),
        }
    
    async def _check_queue_health(self) -> dict[str, Any]:
        """Check queue system health."""
        # TODO: Implement actual queue health check
        return {
            "status": "unknown",
            "reason": "queue health check not implemented",
        }
    
    def _determine_health_status(self, details: dict[str, Any], component: str) -> str:
        """Determine health status based on component details."""
        if component == "memory":
            used_percent = details.get("used_percent", 0)
            if used_percent > 90:
                return "critical"
            elif used_percent > 80:
                return "warning"
            else:
                return "healthy"
        
        elif component == "cpu":
            cpu_percent = details.get("cpu_percent", 0)
            if cpu_percent > 90:
                return "critical"
            elif cpu_percent > 80:
                return "warning"
            else:
                return "healthy"
        
        elif component == "disk":
            used_percent = details.get("used_percent", 0)
            if used_percent > 95:
                return "critical"
            elif used_percent > 85:
                return "warning"
            else:
                return "healthy"
        
        else:
            return "healthy"


class SystemMetricsProcessor(IMessageProcessor[SystemMetricsMessage]):
    """
    Processor for system metrics collection.
    
    Handles collection and aggregation of system metrics.
    """
    
    def __init__(self, metrics_service: Any = None) -> None:
        """
        Initialize system metrics processor.
        
        Args:
            metrics_service: Service for metrics collection
        """
        self.metrics_service = metrics_service
        self.supported_types = ["system.metrics"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: SystemMetricsMessage) -> bool:
        """Validate system metrics message."""
        payload = message.payload
        
        if not payload.metric_type:
            raise ValueError("metric_type is required")
        if not payload.time_range:
            raise ValueError("time_range is required")
        
        return True
    
    async def process(self, message: SystemMetricsMessage) -> Any:
        """
        Process system metrics message.
        
        Args:
            message: Metrics message to process
            
        Returns:
            Metrics collection result
        """
        payload = message.payload
        
        try:
            metrics_result = {
                "metric_type": payload.metric_type,
                "time_range": payload.time_range,
                "aggregation": payload.aggregation,
                "filters": payload.filters,
                "metrics": {},
                "collection_time": message.created_at.isoformat(),
            }
            
            # Collect specific metrics based on type
            if payload.metric_type == "system":
                metrics_result["metrics"] = await self._collect_system_metrics()
            elif payload.metric_type == "queue":
                metrics_result["metrics"] = await self._collect_queue_metrics()
            elif payload.metric_type == "performance":
                metrics_result["metrics"] = await self._collect_performance_metrics()
            else:
                metrics_result["metrics"] = {"error": f"Unknown metric type: {payload.metric_type}"}
            
            return metrics_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "metric_type": payload.metric_type,
                "message_id": message.id,
            }
            
            print(f"Metrics collection failed: {error_details}")
            raise
    
    async def _collect_system_metrics(self) -> dict[str, Any]:
        """Collect system-level metrics."""
        return {
            "memory": await SystemHealthCheckProcessor._check_memory_health(self),
            "cpu": await SystemHealthCheckProcessor._check_cpu_health(self),
            "disk": await SystemHealthCheckProcessor._check_disk_health(self),
        }
    
    async def _collect_queue_metrics(self) -> dict[str, Any]:
        """Collect queue-related metrics."""
        # TODO: Implement actual queue metrics collection
        return {
            "messages_processed": 0,
            "average_processing_time": 0,
            "queue_lengths": {},
            "error_rates": {},
        }
    
    async def _collect_performance_metrics(self) -> dict[str, Any]:
        """Collect performance metrics."""
        # TODO: Implement performance metrics collection
        return {
            "response_times": {},
            "throughput": {},
            "error_rates": {},
        }


class SystemCleanupProcessor(IMessageProcessor[SystemCleanupMessage]):
    """
    Processor for system cleanup operations.
    
    Handles cleanup of logs, cache, temporary files, etc.
    """
    
    def __init__(self, cleanup_service: Any = None) -> None:
        """
        Initialize system cleanup processor.
        
        Args:
            cleanup_service: Service for cleanup operations
        """
        self.cleanup_service = cleanup_service
        self.supported_types = ["system.cleanup"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: SystemCleanupMessage) -> bool:
        """Validate system cleanup message."""
        payload = message.payload
        
        if not payload.cleanup_type:
            raise ValueError("cleanup_type is required")
        
        # Validate cleanup type
        valid_types = ["logs", "cache", "temp", "database", "queue", "metrics"]
        if payload.cleanup_type not in valid_types:
            raise ValueError(f"cleanup_type must be one of: {valid_types}")
        
        if payload.retention_days < 0:
            raise ValueError("retention_days must be non-negative")
        
        return True
    
    async def process(self, message: SystemCleanupMessage) -> Any:
        """
        Process system cleanup message.
        
        Args:
            message: Cleanup message to process
            
        Returns:
            Cleanup result
        """
        payload = message.payload
        
        try:
            cleanup_result = {
                "cleanup_type": payload.cleanup_type,
                "retention_days": payload.retention_days,
                "dry_run": payload.dry_run,
                "target_components": payload.target_components,
                "files_processed": 0,
                "space_freed_mb": 0,
                "errors": [],
            }
            
            # Perform cleanup based on type
            if payload.cleanup_type == "logs":
                cleanup_result = await self._cleanup_logs(cleanup_result, payload)
            elif payload.cleanup_type == "cache":
                cleanup_result = await self._cleanup_cache(cleanup_result, payload)
            elif payload.cleanup_type == "temp":
                cleanup_result = await self._cleanup_temp_files(cleanup_result, payload)
            else:
                cleanup_result["errors"].append(f"Cleanup type not implemented: {payload.cleanup_type}")
            
            return cleanup_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "cleanup_type": payload.cleanup_type,
                "message_id": message.id,
            }
            
            print(f"System cleanup failed: {error_details}")
            raise
    
    async def _cleanup_logs(self, result: dict[str, Any], payload: Any) -> dict[str, Any]:
        """Cleanup log files."""
        # TODO: Implement actual log cleanup
        result["files_processed"] = 0
        result["space_freed_mb"] = 0
        result["note"] = "Log cleanup not implemented"
        return result
    
    async def _cleanup_cache(self, result: dict[str, Any], payload: Any) -> dict[str, Any]:
        """Cleanup cache files."""
        # TODO: Implement actual cache cleanup
        result["files_processed"] = 0
        result["space_freed_mb"] = 0
        result["note"] = "Cache cleanup not implemented"
        return result
    
    async def _cleanup_temp_files(self, result: dict[str, Any], payload: Any) -> dict[str, Any]:
        """Cleanup temporary files."""
        # TODO: Implement actual temp file cleanup
        result["files_processed"] = 0
        result["space_freed_mb"] = 0
        result["note"] = "Temp file cleanup not implemented"
        return result