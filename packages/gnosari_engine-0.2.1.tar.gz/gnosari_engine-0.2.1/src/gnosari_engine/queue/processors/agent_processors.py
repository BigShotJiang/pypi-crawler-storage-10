"""
Message processors for agent-related operations.
Handles agent execution, training, and team orchestration.
"""

from typing import Any

from ...runners.gnosari_runner import GnosariRunner
from ..interfaces.message_interfaces import IMessageProcessor
from ..messages.agent_messages import (
    AgentExecutionMessage,
    AgentTrainingMessage,
    TeamOrchestrationMessage,
)
from ..messages.base import BaseMessage


class AgentExecutionProcessor(IMessageProcessor[AgentExecutionMessage]):
    """
    Processor for agent execution messages.
    
    Handles asynchronous execution of individual agents within teams.
    """
    
    def __init__(self, gnosari_runner: GnosariRunner | None = None) -> None:
        """
        Initialize agent execution processor.
        
        Args:
            gnosari_runner: Gnosari runner instance for agent execution
        """
        self.gnosari_runner = gnosari_runner
        self.supported_types = ["agent.execution"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: AgentExecutionMessage) -> bool:
        """Validate agent execution message."""
        payload = message.payload
        
        # Basic validation
        if not payload.team_id:
            raise ValueError("team_id is required")
        if not payload.agent_id:
            raise ValueError("agent_id is required")
        if not payload.message:
            raise ValueError("message is required")
        
        # TODO: Add validation for team/agent existence
        # This would require access to configuration service
        
        return True
    
    async def process(self, message: AgentExecutionMessage) -> Any:
        """
        Process agent execution message.
        
        Args:
            message: Agent execution message to process
            
        Returns:
            Agent execution result
        """
        payload = message.payload
        
        try:
            # Check if runner is available
            if not self.gnosari_runner:
                # Return mock result for testing without gnosari_runner service
                print(f"✅ Mock execution: {payload.agent_id} processed message: {payload.message[:50]}...")
                return {
                    "success": True,
                    "result": f"Mock execution completed for {payload.agent_id}",
                    "agent_id": payload.agent_id,
                    "team_id": payload.team_id,
                    "execution_time": message.get_processing_time_ms(),
                    "note": "Executed without gnosari_runner service (testing mode)",
                }
            
            # Prepare execution context
            execution_context = {
                "session_id": payload.session_id,
                "streaming": payload.streaming,
                "context": payload.context,
            }
            
            # Add model overrides if specified
            if payload.model_override:
                execution_context["model"] = payload.model_override
            if payload.temperature_override is not None:
                execution_context["temperature"] = payload.temperature_override
            
            # Execute agent
            result = await self.gnosari_runner.execute_agent(
                team_id=payload.team_id,
                agent_id=payload.agent_id,
                message=payload.message,
                **execution_context
            )
            
            return {
                "success": True,
                "result": result,
                "agent_id": payload.agent_id,
                "team_id": payload.team_id,
                "execution_time": message.get_processing_time_ms(),
            }
            
        except Exception as e:
            # Log the error and re-raise for retry logic
            error_details = {
                "error": str(e),
                "agent_id": payload.agent_id,
                "team_id": payload.team_id,
                "message_id": message.id,
            }
            
            # TODO: Add proper logging
            print(f"Agent execution failed: {error_details}")
            raise


class AgentTrainingProcessor(IMessageProcessor[AgentTrainingMessage]):
    """
    Processor for agent training messages.
    
    Handles agent learning and improvement operations.
    """
    
    def __init__(self, learning_service: Any = None) -> None:
        """
        Initialize agent training processor.
        
        Args:
            learning_service: Service for agent learning operations
        """
        self.learning_service = learning_service
        self.supported_types = ["agent.training"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: AgentTrainingMessage) -> bool:
        """Validate agent training message."""
        payload = message.payload
        
        if not payload.agent_id:
            raise ValueError("agent_id is required")
        if not payload.training_type:
            raise ValueError("training_type is required")
        if not payload.training_data:
            raise ValueError("training_data is required")
        
        return True
    
    async def process(self, message: AgentTrainingMessage) -> Any:
        """
        Process agent training message.
        
        Args:
            message: Agent training message to process
            
        Returns:
            Training result
        """
        payload = message.payload
        
        try:
            # TODO: Implement actual training logic
            # This would integrate with the learning system
            training_result = {
                "agent_id": payload.agent_id,
                "training_type": payload.training_type,
                "status": "completed",
                "improvements": [],
                "metadata": payload.metadata,
            }
            
            # Placeholder for actual training implementation
            if self.learning_service:
                training_result = await self.learning_service.train_agent(
                    agent_id=payload.agent_id,
                    training_type=payload.training_type,
                    training_data=payload.training_data,
                    metadata=payload.metadata,
                )
            else:
                # Mock training for now
                training_result["status"] = "skipped"
                training_result["reason"] = "learning_service not configured"
            
            return training_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "agent_id": payload.agent_id,
                "training_type": payload.training_type,
                "message_id": message.id,
            }
            
            print(f"Agent training failed: {error_details}")
            raise


class TeamOrchestrationProcessor(IMessageProcessor[TeamOrchestrationMessage]):
    """
    Processor for team orchestration messages.
    
    Handles team-level coordination and workflow management.
    """
    
    def __init__(self, orchestration_service: Any = None) -> None:
        """
        Initialize team orchestration processor.
        
        Args:
            orchestration_service: Service for team orchestration
        """
        self.orchestration_service = orchestration_service
        self.supported_types = ["team.orchestration"]
    
    def can_handle(self, message: BaseMessage) -> bool:
        """Check if processor can handle message type."""
        return message.type in self.supported_types
    
    def get_supported_message_types(self) -> list[str]:
        """Get supported message types."""
        return self.supported_types
    
    async def validate_message(self, message: TeamOrchestrationMessage) -> bool:
        """Validate team orchestration message."""
        payload = message.payload
        
        if not payload.team_id:
            raise ValueError("team_id is required")
        if not payload.orchestration_type:
            raise ValueError("orchestration_type is required")
        
        return True
    
    async def process(self, message: TeamOrchestrationMessage) -> Any:
        """
        Process team orchestration message.
        
        Args:
            message: Team orchestration message to process
            
        Returns:
            Orchestration result
        """
        payload = message.payload
        
        try:
            orchestration_result = {
                "team_id": payload.team_id,
                "orchestration_type": payload.orchestration_type,
                "status": "completed",
                "agents_involved": payload.priority_agents,
                "parameters": payload.parameters,
            }
            
            # TODO: Implement actual orchestration logic
            if self.orchestration_service:
                orchestration_result = await self.orchestration_service.orchestrate_team(
                    team_id=payload.team_id,
                    orchestration_type=payload.orchestration_type,
                    parameters=payload.parameters,
                    priority_agents=payload.priority_agents,
                )
            else:
                # Mock orchestration for now
                orchestration_result["status"] = "skipped"
                orchestration_result["reason"] = "orchestration_service not configured"
            
            return orchestration_result
            
        except Exception as e:
            error_details = {
                "error": str(e),
                "team_id": payload.team_id,
                "orchestration_type": payload.orchestration_type,
                "message_id": message.id,
            }
            
            print(f"Team orchestration failed: {error_details}")
            raise