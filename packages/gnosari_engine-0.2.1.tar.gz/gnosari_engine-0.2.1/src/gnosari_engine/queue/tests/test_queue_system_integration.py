"""
Integration tests for the complete queue system.
Tests the entire queue system working together.
"""

import pytest
import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

from ..factories.queue_factory import QueueSystemBuilder
from ..messages.agent_messages import AgentExecutionMessage, AgentExecutionPayload
from ..messages.system_messages import SystemHealthCheckMessage, SystemHealthCheckPayload
from ..processing.retry_strategies import ExponentialBackoffRetry


class MockRedis:
    """Mock Redis client for testing."""
    
    def __init__(self):
        self.data = {}
        self.lists = {}
        self.sorted_sets = {}
        self.connected = True
    
    async def ping(self):
        """Mock ping."""
        if not self.connected:
            raise ConnectionError("Redis not connected")
        return b"PONG"
    
    async def set(self, key, value, ex=None):
        """Mock set."""
        self.data[key] = value
        return True
    
    async def get(self, key):
        """Mock get."""
        return self.data.get(key)
    
    async def lpush(self, key, *values):
        """Mock lpush."""
        if key not in self.lists:
            self.lists[key] = []
        for value in values:
            self.lists[key].insert(0, value)
        return len(self.lists[key])
    
    async def brpop(self, keys, timeout=1):
        """Mock brpop."""
        if isinstance(keys, str):
            keys = [keys]
        
        for key in keys:
            if key in self.lists and self.lists[key]:
                value = self.lists[key].pop()
                return (key.encode(), value)
        return None
    
    async def llen(self, key):
        """Mock llen."""
        return len(self.lists.get(key, []))
    
    async def zadd(self, key, mapping):
        """Mock zadd."""
        if key not in self.sorted_sets:
            self.sorted_sets[key] = []
        for value, score in mapping.items():
            self.sorted_sets[key].append((value, score))
        return len(mapping)
    
    async def zcard(self, key):
        """Mock zcard."""
        return len(self.sorted_sets.get(key, []))
    
    async def hset(self, key, mapping=None, **kwargs):
        """Mock hset."""
        if key not in self.data:
            self.data[key] = {}
        if mapping:
            self.data[key].update(mapping)
        self.data[key].update(kwargs)
        return len(mapping or kwargs)
    
    async def hgetall(self, key):
        """Mock hgetall."""
        return self.data.get(key, {})
    
    async def keys(self, pattern):
        """Mock keys."""
        matching_keys = []
        for key in self.data.keys():
            if pattern.replace("*", "") in key:
                matching_keys.append(key.encode())
        return matching_keys
    
    async def delete(self, *keys):
        """Mock delete."""
        deleted = 0
        for key in keys:
            if key in self.data:
                del self.data[key]
                deleted += 1
            if key in self.lists:
                del self.lists[key]
                deleted += 1
            if key in self.sorted_sets:
                del self.sorted_sets[key]
                deleted += 1
        return deleted
    
    async def expire(self, key, time):
        """Mock expire."""
        return True
    
    async def incr(self, key):
        """Mock incr."""
        current = int(self.data.get(key, 0))
        self.data[key] = current + 1
        return self.data[key]
    
    async def pipeline(self):
        """Mock pipeline."""
        return MockPipeline(self)
    
    async def aclose(self):
        """Mock aclose."""
        self.connected = False


class MockPipeline:
    """Mock Redis pipeline."""
    
    def __init__(self, redis_mock):
        self.redis = redis_mock
        self.commands = []
    
    def llen(self, key):
        """Mock pipeline llen."""
        self.commands.append(('llen', key))
        return self
    
    def zcard(self, key):
        """Mock pipeline zcard."""
        self.commands.append(('zcard', key))
        return self
    
    async def execute(self):
        """Mock pipeline execute."""
        results = []
        for cmd, key in self.commands:
            if cmd == 'llen':
                results.append(await self.redis.llen(key))
            elif cmd == 'zcard':
                results.append(await self.redis.zcard(key))
        return results


@pytest.fixture
def mock_redis():
    """Create mock Redis client."""
    return MockRedis()


@pytest.fixture
async def queue_system(mock_redis):
    """Create test queue system."""
    # Create builder with mock Redis
    builder = QueueSystemBuilder()
    
    # Configure for testing
    system = await builder.with_redis_config(
        redis_url="redis://localhost:6379",
        serializer_type="json"
    ).with_retry_strategy(
        "exponential",
        base_delay=1,
        max_attempts=3
    ).with_monitoring(
        enabled=True
    ).with_alerts(
        enabled=True
    ).with_metrics(
        "memory"
    ).build()
    
    # Replace Redis client with mock
    system.queue_provider._redis = mock_redis
    system.redis_client = mock_redis
    if system.queue_monitor:
        system.queue_monitor.redis = mock_redis
    
    await system.start()
    return system


class TestQueueSystemIntegration:
    """Integration tests for the complete queue system."""
    
    @pytest.mark.asyncio
    async def test_message_publication_and_consumption(self, queue_system):
        """Test publishing and consuming messages."""
        # Create test message
        payload = AgentExecutionPayload(
            team_id="test_team",
            agent_id="test_agent",
            message="Test message"
        )
        message = AgentExecutionMessage(payload=payload)
        
        # Publish message
        message_id = await queue_system.publish_message(message)
        assert message_id == message.id
        
        # Verify message is in queue
        queue_name = message.get_queue_name()
        queue_length = await queue_system.queue_provider._redis.llen(queue_name)
        assert queue_length == 1
    
    @pytest.mark.asyncio
    async def test_message_processing_with_retry(self, queue_system):
        """Test message processing with retry logic."""
        # Create mock processor that fails first time
        call_count = 0
        
        async def mock_handler(msg):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise Exception("First attempt fails")
            return {"success": True, "attempt": call_count}
        
        # Create test message
        payload = SystemHealthCheckPayload(
            component="test",
            check_type="basic"
        )
        message = SystemHealthCheckMessage(payload=payload)
        
        # Process message (should retry on failure)
        try:
            await queue_system.processing_engine.process_message(message)
        except Exception:
            # Expected to fail, but should trigger retry
            pass
        
        # Verify retry was attempted
        assert message.attempts > 0
    
    @pytest.mark.asyncio
    async def test_system_monitoring(self, queue_system):
        """Test system monitoring capabilities."""
        if not queue_system.queue_monitor:
            pytest.skip("Monitoring not enabled")
        
        # Get system health
        health = await queue_system.queue_monitor.get_system_health()
        
        assert "overall_status" in health
        assert "components" in health
        assert "summary" in health
        assert health["components"]["redis"]["status"] == "healthy"
    
    @pytest.mark.asyncio
    async def test_queue_statistics(self, queue_system):
        """Test queue statistics collection."""
        if not queue_system.queue_monitor:
            pytest.skip("Monitoring not enabled")
        
        # Create and publish test message
        payload = AgentExecutionPayload(
            team_id="test_team",
            agent_id="test_agent",
            message="Test message"
        )
        message = AgentExecutionMessage(payload=payload)
        await queue_system.publish_message(message)
        
        # Get queue stats
        queue_name = message.get_queue_name()
        stats = await queue_system.queue_monitor.get_queue_stats(queue_name)
        
        assert "queue_name" in stats
        assert "queue_length" in stats
        assert stats["queue_name"] == queue_name
    
    @pytest.mark.asyncio
    async def test_metrics_collection(self, queue_system):
        """Test metrics collection."""
        if not queue_system.metrics_collector:
            pytest.skip("Metrics collection not enabled")
        
        # Record test metrics
        await queue_system.metrics_collector.record_metric("test_metric", 42.0)
        await queue_system.metrics_collector.increment_counter("test_counter")
        await queue_system.metrics_collector.record_timing("test_timer", 100.0)
        
        # Verify metrics were recorded
        if hasattr(queue_system.metrics_collector, 'get_metrics'):
            metrics = await queue_system.metrics_collector.get_metrics("test_metric")
            assert len(metrics) > 0
            assert metrics[0]["value"] == 42.0
    
    @pytest.mark.asyncio
    async def test_alert_system(self, queue_system):
        """Test alert system functionality."""
        if not queue_system.alert_manager:
            pytest.skip("Alerting not enabled")
        
        # Send test alert
        await queue_system.alert_manager.send_alert(
            alert_type="test_alert",
            message="Test alert message",
            severity="warning"
        )
        
        # Verify alert was recorded
        history = queue_system.alert_manager.get_alert_history(limit=1)
        assert len(history) > 0
        assert history[0]["type"] == "test_alert"
        assert history[0]["message"] == "Test alert message"
    
    @pytest.mark.asyncio
    async def test_queue_management_operations(self, queue_system):
        """Test queue management operations."""
        test_queue = "test_management_queue"
        
        # Create queue
        await queue_system.queue_provider.create_queue(test_queue)
        
        # Verify queue exists
        assert await queue_system.queue_provider.queue_exists(test_queue)
        
        # List queues
        queues = await queue_system.queue_provider.list_queues()
        assert test_queue in queues
        
        # Purge queue (should return 0 since empty)
        purged = await queue_system.queue_provider.purge_queue(test_queue)
        assert purged == 0
        
        # Delete queue
        await queue_system.queue_provider.delete_queue(test_queue)
    
    @pytest.mark.asyncio
    async def test_different_message_types(self, queue_system):
        """Test handling different message types."""
        # Test agent execution message
        agent_payload = AgentExecutionPayload(
            team_id="test_team",
            agent_id="test_agent",
            message="Test agent message"
        )
        agent_message = AgentExecutionMessage(payload=agent_payload)
        
        agent_id = await queue_system.publish_message(agent_message)
        assert agent_id == agent_message.id
        
        # Test health check message
        health_payload = SystemHealthCheckPayload(
            component="queue",
            check_type="basic"
        )
        health_message = SystemHealthCheckMessage(payload=health_payload)
        
        health_id = await queue_system.publish_message(health_message)
        assert health_id == health_message.id
        
        # Verify messages go to different queues
        assert agent_message.get_queue_name() != health_message.get_queue_name()
    
    @pytest.mark.asyncio
    async def test_system_shutdown(self, queue_system):
        """Test graceful system shutdown."""
        # Create some test data
        payload = AgentExecutionPayload(
            team_id="test_team",
            agent_id="test_agent",
            message="Test message"
        )
        message = AgentExecutionMessage(payload=payload)
        await queue_system.publish_message(message)
        
        # Shutdown system
        await queue_system.shutdown()
        
        # Verify Redis client is closed
        assert not queue_system.queue_provider._connected


class TestRetryStrategies:
    """Test retry strategy implementations."""
    
    def test_exponential_backoff_retry(self):
        """Test exponential backoff retry strategy."""
        strategy = ExponentialBackoffRetry(
            base_delay=2,
            multiplier=2.0,
            max_delay=60,
            max_attempts=5
        )
        
        # Test delay calculation
        assert strategy.get_delay_seconds(1) == 2
        assert strategy.get_delay_seconds(2) == 4
        assert strategy.get_delay_seconds(3) == 8
        assert strategy.get_delay_seconds(4) == 16
        
        # Test max delay
        assert strategy.get_delay_seconds(10) == 60  # Should be capped at max_delay
        
        # Test should_retry
        from ..messages.base import BaseMessage, MessageStatus
        from pydantic import BaseModel
        
        class TestPayload(BaseModel):
            test_field: str = "test"
        
        class TestMessage(BaseMessage[TestPayload]):
            type: str = "test"
            
            def get_routing_key(self) -> str:
                return "test.routing"
            
            def get_queue_name(self) -> str:
                return "test_queue"
        
        message = TestMessage(payload=TestPayload())
        message.attempts = 3
        
        # Should retry if under max attempts
        assert strategy.should_retry(message, Exception("test error"))
        
        # Should not retry if at max attempts
        message.attempts = 5
        assert not strategy.should_retry(message, Exception("test error"))


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])