"""
Redis-based queue provider implementation.
Provides enterprise-grade queueing using Redis as backend.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Any, Callable

import redis.asyncio as redis
from redis.asyncio import Redis

from ..interfaces.queue_interfaces import (
    IQueueConnection,
    IQueueConsumer,
    IQueueManager,
    IQueueProducer,
)
from ..messages.base import BaseMessage, MessageStatus
from ..serialization.strategies import SerializerFactory, get_message_registry
from .exceptions import (
    QueueAckError,
    QueueConnectionError,
    QueueConsumeError,
    QueueManagementError,
    QueueNackError,
    QueuePublishError,
    QueueRejectError,
)


class RedisQueueProvider(
    IQueueProducer[BaseMessage],
    IQueueConsumer[BaseMessage], 
    IQueueManager,
    IQueueConnection
):
    """
    Redis-based queue provider with enterprise features.
    
    Features:
    - Priority queues using Redis sorted sets
    - Delayed message delivery
    - Dead letter queues
    - Message acknowledgment with timeout
    - Connection pooling and reconnection
    - Metrics collection
    """
    
    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        serializer_type: str = "json",
        max_connections: int = 10,
        health_check_interval: int = 30,
        message_ttl: int = 3600,
        visibility_timeout: int = 300,
    ) -> None:
        """
        Initialize Redis queue provider.
        
        Args:
            redis_url: Redis connection URL
            serializer_type: Serialization strategy name
            max_connections: Maximum Redis connections
            health_check_interval: Health check interval in seconds
            message_ttl: Message time-to-live in seconds
            visibility_timeout: Message visibility timeout in seconds
        """
        self.redis_url = redis_url
        self.serializer = SerializerFactory.create(serializer_type)
        self.message_registry = get_message_registry()
        self.max_connections = max_connections
        self.health_check_interval = health_check_interval
        self.message_ttl = message_ttl
        self.visibility_timeout = visibility_timeout
        
        # Connection management
        self._redis: Redis | None = None
        self._connection_pool: redis.ConnectionPool | None = None
        self._connected = False
        self._consumers_running: dict[str, bool] = {}
        self._consumer_tasks: dict[str, asyncio.Task] = {}
        
        # Message tracking
        self._processing_messages: dict[str, dict[str, Any]] = {}
        self._metrics: dict[str, int] = {
            "messages_published": 0,
            "messages_consumed": 0,
            "messages_failed": 0,
            "messages_acknowledged": 0,
        }
    
    # Connection Management
    
    async def connect(self) -> None:
        """Establish connection to Redis."""
        if self._connected:
            return
        
        try:
            self._connection_pool = redis.ConnectionPool.from_url(
                self.redis_url,
                max_connections=self.max_connections,
                decode_responses=False,  # Keep binary for message data
            )
            
            self._redis = Redis(connection_pool=self._connection_pool)
            
            # Test connection
            await self._redis.ping()
            self._connected = True
            
            # Start background tasks
            asyncio.create_task(self._delayed_message_processor())
            asyncio.create_task(self._health_check_task())
            
        except Exception as e:
            raise QueueConnectionError(f"Failed to connect to Redis: {e}", e) from e
    
    async def disconnect(self) -> None:
        """Close connection to Redis."""
        if not self._connected:
            return
        
        try:
            # Stop all consumers
            for queue_name in list(self._consumers_running.keys()):
                await self._stop_consumer(queue_name)
            
            # Close Redis connection
            if self._redis:
                await self._redis.aclose()
            
            if self._connection_pool:
                await self._connection_pool.aclose()
            
            self._connected = False
            
        except Exception as e:
            raise QueueConnectionError(f"Failed to disconnect from Redis: {e}", e) from e
    
    async def is_connected(self) -> bool:
        """Check if connection is active."""
        if not self._connected or not self._redis:
            return False
        
        try:
            await self._redis.ping()
            return True
        except Exception:
            self._connected = False
            return False
    
    async def reconnect(self) -> None:
        """Reconnect to Redis."""
        await self.disconnect()
        await self.connect()
    
    # Producer Implementation
    
    async def publish(self, message: BaseMessage, delay_seconds: int = 0) -> str:
        """Publish message to appropriate queue."""
        await self._ensure_connected()
        
        try:
            queue_name = message.get_queue_name()
            serialized_data = self._serialize_message(message)
            
            if delay_seconds > 0:
                # Delayed message using sorted set
                score = time.time() + delay_seconds
                await self._redis.zadd(f"{queue_name}:delayed", {serialized_data: score})
            else:
                # Immediate message using list
                priority_value = message.priority.value if hasattr(message.priority, 'value') else message.priority
                if priority_value > 2:  # HIGH or CRITICAL
                    await self._redis.lpush(f"{queue_name}:priority", serialized_data)
                else:
                    await self._redis.lpush(queue_name, serialized_data)
            
            # Store message metadata
            await self._store_message_metadata(message)
            
            self._metrics["messages_published"] += 1
            return message.id
            
        except Exception as e:
            raise QueuePublishError(f"Failed to publish message: {e}", e) from e
    
    async def publish_batch(self, messages: list[BaseMessage]) -> list[str]:
        """Publish multiple messages in batch."""
        await self._ensure_connected()
        
        try:
            pipe = self._redis.pipeline()
            message_ids = []
            
            for message in messages:
                queue_name = message.get_queue_name()
                serialized_data = self._serialize_message(message)
                
                priority_value = message.priority.value if hasattr(message.priority, 'value') else message.priority
                if priority_value > 2:
                    pipe.lpush(f"{queue_name}:priority", serialized_data)
                else:
                    pipe.lpush(queue_name, serialized_data)
                
                message_ids.append(message.id)
            
            await pipe.execute()
            
            # Store metadata for all messages
            for message in messages:
                await self._store_message_metadata(message)
            
            self._metrics["messages_published"] += len(messages)
            return message_ids
            
        except Exception as e:
            raise QueuePublishError(f"Failed to publish batch: {e}", e) from e
    
    async def schedule_message(self, message: BaseMessage, schedule_time: datetime) -> str:
        """Schedule message for future delivery."""
        now = datetime.utcnow()
        delay_seconds = int((schedule_time - now).total_seconds())
        
        if delay_seconds <= 0:
            return await self.publish(message)
        else:
            return await self.publish(message, delay_seconds=delay_seconds)
    
    # Consumer Implementation
    
    async def consume(
        self,
        queue_name: str,
        handler: Callable[[BaseMessage], Any],
        max_concurrent: int = 10,
        auto_ack: bool = False
    ) -> None:
        """Start consuming messages from queue."""
        await self._ensure_connected()
        
        if queue_name in self._consumers_running:
            raise QueueConsumeError(f"Consumer already running for queue: {queue_name}")
        
        self._consumers_running[queue_name] = True
        semaphore = asyncio.Semaphore(max_concurrent)
        
        try:
            while self._consumers_running.get(queue_name, False):
                try:
                    # Check priority queue first
                    message_data = await self._redis.brpop(
                        [f"{queue_name}:priority", queue_name], 
                        timeout=1
                    )
                    
                    if message_data:
                        _, serialized_data = message_data
                        
                        # Process message concurrently
                        task = asyncio.create_task(
                            self._process_message(
                                serialized_data, handler, semaphore, auto_ack
                            )
                        )
                        
                        # Don't await - allow concurrent processing
                        asyncio.create_task(self._handle_task_completion(task))
                
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"Error in consumer loop: {e}")
                    await asyncio.sleep(1)
        
        finally:
            self._consumers_running.pop(queue_name, None)
    
    async def acknowledge(self, message_id: str) -> None:
        """Acknowledge message processing."""
        try:
            # Remove from processing set
            self._processing_messages.pop(message_id, None)
            
            # Update message status
            await self._redis.hset(
                f"message:{message_id}",
                mapping={
                    "status": MessageStatus.COMPLETED.value,
                    "completed_at": datetime.utcnow().isoformat(),
                }
            )
            
            self._metrics["messages_acknowledged"] += 1
            
        except Exception as e:
            raise QueueAckError(f"Failed to acknowledge message {message_id}: {e}") from e
    
    async def reject(self, message_id: str, requeue: bool = True) -> None:
        """Reject message processing."""
        try:
            message_info = self._processing_messages.pop(message_id, None)
            
            if requeue and message_info:
                # Requeue with increased attempt count
                message = message_info["message"]
                message.attempts += 1
                
                if message.should_retry():
                    await self.publish(message)
                else:
                    await self._send_to_dead_letter(message)
            
        except Exception as e:
            raise QueueRejectError(f"Failed to reject message {message_id}: {e}") from e
    
    async def nack(self, message_id: str, requeue: bool = True) -> None:
        """Negative acknowledgment."""
        try:
            await self.reject(message_id, requeue)
            self._metrics["messages_failed"] += 1
            
        except Exception as e:
            raise QueueNackError(f"Failed to nack message {message_id}: {e}") from e
    
    # Queue Management Implementation
    
    async def create_queue(
        self,
        name: str,
        durable: bool = True,
        max_priority: int = 4,
        message_ttl: int | None = None,
        max_length: int | None = None
    ) -> None:
        """Create queue configuration."""
        await self._ensure_connected()
        
        try:
            config = {
                "durable": str(durable),
                "max_priority": str(max_priority),
                "created_at": datetime.utcnow().isoformat(),
            }
            
            if message_ttl:
                config["message_ttl"] = str(message_ttl)
            if max_length:
                config["max_length"] = str(max_length)
            
            await self._redis.hset(f"queue_config:{name}", mapping=config)
            
        except Exception as e:
            raise QueueManagementError(f"Failed to create queue {name}: {e}", e) from e
    
    async def delete_queue(self, name: str, if_unused: bool = False) -> None:
        """Delete queue and all its messages."""
        await self._ensure_connected()
        
        try:
            if if_unused:
                length = await self._redis.llen(name)
                if length > 0:
                    raise QueueManagementError(f"Queue {name} is not empty")
            
            # Delete all queue-related keys
            keys_to_delete = [
                name,
                f"{name}:priority", 
                f"{name}:delayed",
                f"{name}:dead_letter",
                f"queue_config:{name}"
            ]
            
            if keys_to_delete:
                await self._redis.delete(*keys_to_delete)
                
        except Exception as e:
            raise QueueManagementError(f"Failed to delete queue {name}: {e}", e) from e
    
    async def purge_queue(self, name: str) -> int:
        """Remove all messages from queue."""
        await self._ensure_connected()
        
        try:
            pipe = self._redis.pipeline()
            
            # Get current lengths
            pipe.llen(name)
            pipe.llen(f"{name}:priority")
            pipe.zcard(f"{name}:delayed")
            
            results = await pipe.execute()
            total_purged = sum(results)
            
            # Delete all messages
            await self._redis.delete(name, f"{name}:priority", f"{name}:delayed")
            
            return total_purged
            
        except Exception as e:
            raise QueueManagementError(f"Failed to purge queue {name}: {e}", e) from e
    
    async def queue_exists(self, name: str) -> bool:
        """Check if queue exists."""
        await self._ensure_connected()
        return await self._redis.exists(f"queue_config:{name}") > 0
    
    async def list_queues(self) -> list[str]:
        """List all existing queues."""
        await self._ensure_connected()
        
        keys = await self._redis.keys("queue_config:*")
        return [key.decode('utf-8').replace("queue_config:", "") for key in keys]
    
    # Private Helper Methods
    
    async def _ensure_connected(self) -> None:
        """Ensure Redis connection is active."""
        if not await self.is_connected():
            await self.connect()
    
    def _serialize_message(self, message: BaseMessage) -> bytes:
        """Serialize message for storage."""
        return self.serializer.serialize(message)
    
    def _deserialize_message(self, data: bytes) -> BaseMessage:
        """Deserialize message from storage."""
        # First deserialize to get message type
        temp_data = json.loads(data.decode('utf-8'))
        message_type = temp_data.get('type', 'unknown')
        
        # Get appropriate message class
        message_class = self.message_registry.get_message_class(message_type)
        
        # Deserialize with correct type
        return self.serializer.deserialize(data, message_class)
    
    async def _store_message_metadata(self, message: BaseMessage) -> None:
        """Store message metadata for tracking."""
        metadata = {
            "id": message.id,
            "type": message.type,
            "status": str(message.status),
            "created_at": message.created_at.isoformat(),
            "attempts": str(message.attempts),
            "queue_name": message.get_queue_name(),
        }
        
        await self._redis.hset(f"message:{message.id}", mapping=metadata)
        await self._redis.expire(f"message:{message.id}", self.message_ttl)
    
    async def _process_message(
        self,
        serialized_data: bytes,
        handler: Callable[[BaseMessage], Any],
        semaphore: asyncio.Semaphore,
        auto_ack: bool
    ) -> None:
        """Process a single message."""
        async with semaphore:
            message = None
            try:
                # Deserialize message
                message = self._deserialize_message(serialized_data)
                message.mark_processing()
                
                # Track processing
                self._processing_messages[message.id] = {
                    "message": message,
                    "started_at": datetime.utcnow(),
                }
                
                # Process message
                await handler(message)
                
                # Auto-acknowledge if enabled
                if auto_ack:
                    await self.acknowledge(message.id)
                
                self._metrics["messages_consumed"] += 1
                
            except Exception as e:
                if message:
                    message.mark_failed(str(e))
                    await self.nack(message.id, requeue=True)
                print(f"Message processing failed: {e}")
    
    async def _handle_task_completion(self, task: asyncio.Task) -> None:
        """Handle task completion and cleanup."""
        try:
            await task
        except Exception as e:
            print(f"Task failed: {e}")
    
    async def _delayed_message_processor(self) -> None:
        """Background task to process delayed messages."""
        while self._connected:
            try:
                # Get all delayed message queues
                queue_keys = await self._redis.keys("*:delayed")
                
                for delayed_key in queue_keys:
                    queue_name = delayed_key.decode('utf-8').replace(':delayed', '')
                    current_time = time.time()
                    
                    # Get ready messages
                    ready_messages = await self._redis.zrangebyscore(
                        delayed_key, 0, current_time, withscores=True
                    )
                    
                    if ready_messages:
                        pipe = self._redis.pipeline()
                        
                        for message_data, _ in ready_messages:
                            # Move to main queue
                            pipe.lpush(queue_name, message_data)
                            pipe.zrem(delayed_key, message_data)
                        
                        await pipe.execute()
                
                await asyncio.sleep(1)  # Check every second
                
            except Exception as e:
                print(f"Error in delayed message processor: {e}")
                await asyncio.sleep(5)
    
    async def _health_check_task(self) -> None:
        """Background health check task."""
        while self._connected:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                if not await self.is_connected():
                    print("Redis connection lost, attempting reconnection...")
                    await self.reconnect()
                
            except Exception as e:
                print(f"Health check failed: {e}")
    
    async def _send_to_dead_letter(self, message: BaseMessage) -> None:
        """Send message to dead letter queue."""
        try:
            message.mark_dead_letter()
            dead_letter_queue = f"{message.get_queue_name()}:dead_letter"
            serialized_data = self._serialize_message(message)
            
            await self._redis.lpush(dead_letter_queue, serialized_data)
            
        except Exception as e:
            print(f"Failed to send message to dead letter queue: {e}")
    
    async def _stop_consumer(self, queue_name: str) -> None:
        """Stop consumer for a queue."""
        self._consumers_running[queue_name] = False
        
        if queue_name in self._consumer_tasks:
            task = self._consumer_tasks[queue_name]
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            del self._consumer_tasks[queue_name]
    
    def get_metrics(self) -> dict[str, int]:
        """Get current metrics."""
        return self._metrics.copy()