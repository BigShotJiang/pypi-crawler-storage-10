"""Queue provider exceptions."""


class QueueProviderError(Exception):
    """Base exception for queue provider errors."""
    pass


class QueueConnectionError(QueueProviderError):
    """Raised when queue connection fails."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class QueuePublishError(QueueProviderError):
    """Raised when message publishing fails."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class QueueConsumeError(QueueProviderError):
    """Raised when message consumption fails."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class QueueManagementError(QueueProviderError):
    """Raised when queue management operations fail."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class QueueAckError(QueueProviderError):
    """Raised when message acknowledgment fails."""
    pass


class QueueRejectError(QueueProviderError):
    """Raised when message rejection fails."""
    pass


class QueueNackError(QueueProviderError):
    """Raised when message negative acknowledgment fails."""
    pass