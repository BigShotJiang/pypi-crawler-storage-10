"""
Base message classes for the queue system.
Follows Single Responsibility and Open/Closed principles.
"""

from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any, Generic, TypeVar
from uuid import uuid4

from pydantic import BaseModel, Field


class MessagePriority(Enum):
    """Message priority levels for queue ordering."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class MessageStatus(Enum):
    """Message processing status."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    DEAD_LETTER = "dead_letter"


T = TypeVar('T', bound=BaseModel)


class BaseMessage(BaseModel, ABC, Generic[T]):
    """
    Base message class for all queue operations.
    
    Provides common message functionality while allowing type-safe payloads
    through generic typing. Each message type should inherit from this class
    and specify their payload type.
    """
    
    id: str = Field(default_factory=lambda: str(uuid4()), description="Unique message identifier")
    type: str = Field(..., description="Message type identifier for routing")
    priority: MessagePriority = Field(default=MessagePriority.NORMAL, description="Message priority")
    status: MessageStatus = Field(default=MessageStatus.PENDING, description="Current processing status")
    
    # Timing information
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Message creation timestamp")
    scheduled_at: datetime | None = Field(default=None, description="When message should be processed")
    started_at: datetime | None = Field(default=None, description="When processing started")
    completed_at: datetime | None = Field(default=None, description="When processing completed")
    
    # Retry configuration
    attempts: int = Field(default=0, description="Number of processing attempts")
    max_attempts: int = Field(default=3, description="Maximum retry attempts")
    timeout_seconds: int = Field(default=300, description="Processing timeout in seconds")
    
    # Message data
    payload: T = Field(..., description="Typed message payload")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional message metadata")
    
    # Error tracking
    last_error: str | None = Field(default=None, description="Last error message")
    error_count: int = Field(default=0, description="Total number of errors")
    
    class Config:
        """Pydantic configuration."""
        arbitrary_types_allowed = True
    
    @abstractmethod
    def get_routing_key(self) -> str:
        """
        Get routing key for message distribution.
        
        Used by queue providers to route messages to appropriate queues
        or exchanges based on message content.
        
        Returns:
            String routing key for this message
        """
        pass
    
    @abstractmethod
    def get_queue_name(self) -> str:
        """
        Get target queue name for this message.
        
        Returns:
            Queue name where this message should be processed
        """
        pass
    
    def mark_processing(self) -> None:
        """Mark message as currently being processed."""
        self.status = MessageStatus.PROCESSING
        self.started_at = datetime.utcnow()
        self.attempts += 1
    
    def mark_completed(self) -> None:
        """Mark message as successfully completed."""
        self.status = MessageStatus.COMPLETED
        self.completed_at = datetime.utcnow()
    
    def mark_failed(self, error_message: str) -> None:
        """Mark message as failed with error details."""
        self.status = MessageStatus.FAILED
        self.last_error = error_message
        self.error_count += 1
    
    def mark_retrying(self) -> None:
        """Mark message for retry."""
        self.status = MessageStatus.RETRYING
    
    def mark_dead_letter(self) -> None:
        """Mark message as permanently failed (dead letter)."""
        self.status = MessageStatus.DEAD_LETTER
    
    def should_retry(self) -> bool:
        """Check if message should be retried based on attempts."""
        return self.attempts < self.max_attempts
    
    def get_processing_time_ms(self) -> int | None:
        """Get processing time in milliseconds if available."""
        if self.started_at and self.completed_at:
            delta = self.completed_at - self.started_at
            return int(delta.total_seconds() * 1000)
        return None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert message to dictionary for serialization."""
        return self.model_dump(mode='json')
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BaseMessage":
        """Create message from dictionary with proper enum handling."""
        # Create a copy to avoid modifying original data
        message_data = data.copy()
        
        # Handle enum conversion for known fields
        if 'priority' in message_data and isinstance(message_data['priority'], (int, str)):
            try:
                message_data['priority'] = MessagePriority(message_data['priority'])
            except (ValueError, TypeError):
                # If conversion fails, let Pydantic handle validation
                pass
                
        if 'status' in message_data and isinstance(message_data['status'], (int, str)):
            try:
                message_data['status'] = MessageStatus(message_data['status'])
            except (ValueError, TypeError):
                # If conversion fails, let Pydantic handle validation
                pass
        
        return cls.model_validate(message_data)