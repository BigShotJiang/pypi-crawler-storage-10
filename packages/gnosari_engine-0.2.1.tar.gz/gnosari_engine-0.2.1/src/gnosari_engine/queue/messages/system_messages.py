"""System-level message types for monitoring and health checks."""

from typing import Any

from pydantic import BaseModel, Field

from .base import BaseMessage


class SystemHealthCheckPayload(BaseModel):
    """Payload for system health check operations."""
    
    component: str = Field(..., description="Component to check (queue, database, etc.)")
    check_type: str = Field(..., description="Type of health check")
    parameters: dict[str, Any] = Field(default_factory=dict, description="Check parameters")
    timeout_seconds: int = Field(default=30, description="Health check timeout")


class SystemHealthCheckMessage(BaseMessage[SystemHealthCheckPayload]):
    """Message for system health checks."""
    
    type: str = Field(default="system.health_check", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by component type."""
        return f"system.health_check.{self.payload.component}"
    
    def get_queue_name(self) -> str:
        """Use system monitoring queue."""
        return "system_monitoring_queue"


class SystemMetricsPayload(BaseModel):
    """Payload for system metrics collection."""
    
    metric_type: str = Field(..., description="Type of metrics to collect")
    time_range: dict[str, str] = Field(..., description="Time range for metrics")
    aggregation: str = Field(default="average", description="Aggregation method")
    filters: dict[str, Any] = Field(default_factory=dict, description="Metric filters")


class SystemMetricsMessage(BaseMessage[SystemMetricsPayload]):
    """Message for system metrics collection."""
    
    type: str = Field(default="system.metrics", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by metric type."""
        return f"system.metrics.{self.payload.metric_type}"
    
    def get_queue_name(self) -> str:
        """Use metrics collection queue."""
        return "system_metrics_queue"


class SystemCleanupPayload(BaseModel):
    """Payload for system cleanup operations."""
    
    cleanup_type: str = Field(..., description="Type of cleanup (logs, cache, etc.)")
    retention_days: int = Field(default=30, description="Data retention period")
    dry_run: bool = Field(default=True, description="Whether to perform dry run first")
    target_components: list[str] = Field(default_factory=list, description="Components to clean")


class SystemCleanupMessage(BaseMessage[SystemCleanupPayload]):
    """Message for system cleanup tasks."""
    
    type: str = Field(default="system.cleanup", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by cleanup type."""
        return f"system.cleanup.{self.payload.cleanup_type}"
    
    def get_queue_name(self) -> str:
        """Use maintenance queue."""
        return "system_maintenance_queue"