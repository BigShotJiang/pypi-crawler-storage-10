"""Knowledge system related message types."""

from typing import Any

from pydantic import BaseModel, Field

from .base import BaseMessage


class KnowledgeIndexingPayload(BaseModel):
    """Payload for knowledge base indexing operations."""
    
    knowledge_base_id: str = Field(..., description="ID of the knowledge base")
    content_source: str = Field(..., description="Source of content to index")
    content_type: str = Field(..., description="Type of content (website, file, etc.)")
    indexing_options: dict[str, Any] = Field(default_factory=dict, description="Indexing configuration")
    force_reindex: bool = Field(default=False, description="Force reindexing existing content")
    chunk_size: int = Field(default=1000, description="Text chunk size for processing")
    overlap_size: int = Field(default=200, description="Overlap between chunks")


class KnowledgeIndexingMessage(BaseMessage[KnowledgeIndexingPayload]):
    """Message for knowledge indexing operations."""
    
    type: str = Field(default="knowledge.indexing", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by knowledge base for consistency."""
        return f"knowledge.indexing.{self.payload.knowledge_base_id}"
    
    def get_queue_name(self) -> str:
        """Use knowledge processing queue."""
        return "knowledge_indexing_queue"


class KnowledgeQueryPayload(BaseModel):
    """Payload for knowledge query operations."""
    
    knowledge_base_id: str = Field(..., description="ID of the knowledge base")
    query: str = Field(..., description="Query text")
    top_k: int = Field(default=5, description="Number of results to return")
    similarity_threshold: float = Field(default=0.7, description="Minimum similarity score")
    filters: dict[str, Any] = Field(default_factory=dict, description="Query filters")
    metadata_fields: list[str] = Field(default_factory=list, description="Metadata fields to return")


class KnowledgeQueryMessage(BaseMessage[KnowledgeQueryPayload]):
    """Message for knowledge query operations."""
    
    type: str = Field(default="knowledge.query", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by knowledge base."""
        return f"knowledge.query.{self.payload.knowledge_base_id}"
    
    def get_queue_name(self) -> str:
        """Use query processing queue."""
        return "knowledge_query_queue"


class KnowledgeMaintenancePayload(BaseModel):
    """Payload for knowledge base maintenance operations."""
    
    knowledge_base_id: str = Field(..., description="ID of the knowledge base")
    operation: str = Field(..., description="Maintenance operation (cleanup, optimize, etc.)")
    parameters: dict[str, Any] = Field(default_factory=dict, description="Operation parameters")
    schedule_time: str | None = Field(default=None, description="Scheduled execution time")


class KnowledgeMaintenanceMessage(BaseMessage[KnowledgeMaintenancePayload]):
    """Message for knowledge base maintenance tasks."""
    
    type: str = Field(default="knowledge.maintenance", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by knowledge base."""
        return f"knowledge.maintenance.{self.payload.knowledge_base_id}"
    
    def get_queue_name(self) -> str:
        """Use maintenance queue."""
        return "knowledge_maintenance_queue"