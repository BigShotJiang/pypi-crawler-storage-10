"""Agent-related message types for queue processing."""

from typing import Any

from pydantic import BaseModel, Field

from .base import BaseMessage


class AgentExecutionPayload(BaseModel):
    """Payload for agent execution requests."""
    
    team_id: str = Field(..., description="ID of the team containing the agent")
    agent_id: str = Field(..., description="ID of the agent to execute")
    message: str = Field(..., description="User message to process")
    context: dict[str, Any] = Field(default_factory=dict, description="Execution context")
    session_id: str | None = Field(default=None, description="Optional session ID for context")
    streaming: bool = Field(default=False, description="Whether to use streaming execution")
    model_override: str | None = Field(default=None, description="Override agent's default model")
    temperature_override: float | None = Field(default=None, description="Override agent's temperature")


class AgentExecutionMessage(BaseMessage[AgentExecutionPayload]):
    """Message for executing an agent asynchronously."""
    
    type: str = Field(default="agent.execution", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by team for load balancing."""
        return f"agent.execution.{self.payload.team_id}"
    
    def get_queue_name(self) -> str:
        """Use dedicated agent execution queue."""
        return "agent_execution_queue"


class AgentTrainingPayload(BaseModel):
    """Payload for agent training/learning requests."""
    
    agent_id: str = Field(..., description="ID of the agent to train")
    training_data: dict[str, Any] = Field(..., description="Training data and configuration")
    training_type: str = Field(..., description="Type of training (feedback, examples, etc.)")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Training metadata")


class AgentTrainingMessage(BaseMessage[AgentTrainingPayload]):
    """Message for agent training operations."""
    
    type: str = Field(default="agent.training", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by agent for consistent training."""
        return f"agent.training.{self.payload.agent_id}"
    
    def get_queue_name(self) -> str:
        """Use dedicated training queue."""
        return "agent_training_queue"


class TeamOrchestrationPayload(BaseModel):
    """Payload for team orchestration requests."""
    
    team_id: str = Field(..., description="ID of the team to orchestrate")
    orchestration_type: str = Field(..., description="Type of orchestration")
    parameters: dict[str, Any] = Field(default_factory=dict, description="Orchestration parameters")
    priority_agents: list[str] = Field(default_factory=list, description="Priority agent execution order")


class TeamOrchestrationMessage(BaseMessage[TeamOrchestrationPayload]):
    """Message for team-level orchestration tasks."""
    
    type: str = Field(default="team.orchestration", description="Message type")
    
    def get_routing_key(self) -> str:
        """Route by team ID."""
        return f"team.orchestration.{self.payload.team_id}"
    
    def get_queue_name(self) -> str:
        """Use orchestration queue."""
        return "team_orchestration_queue"