"""Serialization-related exceptions."""


class QueueSerializationError(Exception):
    """Base exception for serialization errors."""
    pass


class MessageSerializationError(QueueSerializationError):
    """Raised when message serialization fails."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class MessageDeserializationError(QueueSerializationError):
    """Raised when message deserialization fails."""
    
    def __init__(self, message: str, original_error: Exception | None = None) -> None:
        super().__init__(message)
        self.original_error = original_error


class MessageTypeNotFoundError(QueueSerializationError):
    """Raised when message type is not registered."""
    
    def __init__(self, message_type: str) -> None:
        super().__init__(f"Message type not found: {message_type}")
        self.message_type = message_type


class SerializerNotFoundError(QueueSerializationError):
    """Raised when serializer strategy is not found."""
    
    def __init__(self, serializer_name: str) -> None:
        super().__init__(f"Serializer not found: {serializer_name}")
        self.serializer_name = serializer_name