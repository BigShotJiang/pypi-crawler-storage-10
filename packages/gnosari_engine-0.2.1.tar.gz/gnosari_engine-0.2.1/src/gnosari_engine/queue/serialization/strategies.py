"""
Message serialization strategies.
Implements Strategy pattern for different serialization approaches.
"""

import json
import pickle
from typing import Any, Type, TypeVar

from ..interfaces.message_interfaces import IMessageSerializer, IMessageRegistry
from ..messages.base import BaseMessage
from .exceptions import (
    MessageDeserializationError,
    MessageSerializationError,
    MessageTypeNotFoundError,
    SerializerNotFoundError,
)

T = TypeVar('T', bound=BaseMessage)


class JsonMessageSerializer(IMessageSerializer[BaseMessage]):
    """
    JSON-based message serialization strategy.
    
    Provides human-readable serialization with good performance.
    Suitable for most message types but cannot handle complex Python objects.
    """
    
    def serialize(self, message: BaseMessage) -> bytes:
        """Serialize message to JSON bytes."""
        try:
            # Convert message to dictionary with proper enum handling
            message_dict = message.model_dump(mode='json')
            message_dict['__message_type__'] = message.type
            message_dict['__message_class__'] = message.__class__.__name__
            
            # Add enum metadata for proper deserialization
            self._add_enum_metadata(message_dict, message)
            
            # Serialize to JSON with datetime handling
            json_str = json.dumps(message_dict, default=self._json_serializer, ensure_ascii=False)
            return json_str.encode('utf-8')
            
        except (TypeError, ValueError) as e:
            raise MessageSerializationError(
                f"Failed to serialize message to JSON: {e}", e
            ) from e
    
    def deserialize(self, data: bytes, message_type: Type[BaseMessage]) -> BaseMessage:
        """Deserialize JSON bytes to message object."""
        try:
            # Decode and parse JSON
            json_str = data.decode('utf-8')
            message_dict = json.loads(json_str)
            
            # Remove serialization metadata
            message_dict.pop('__message_type__', None)
            message_dict.pop('__message_class__', None)
            
            # Restore enum values from metadata
            self._restore_enum_values(message_dict)
            
            # Create message object
            return message_type.model_validate(message_dict)
            
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as e:
            raise MessageDeserializationError(
                f"Failed to deserialize JSON message: {e}", e
            ) from e
    
    def get_content_type(self) -> str:
        """Get JSON content type."""
        return "application/json"
    
    def _add_enum_metadata(self, message_dict: dict[str, Any], message: BaseMessage) -> None:
        """Add enum type metadata to message dictionary."""
        from ..messages.base import MessagePriority, MessageStatus
        
        enum_metadata = {}
        
        # Check for enum fields and record their types
        if 'priority' in message_dict and hasattr(message, 'priority'):
            enum_metadata['priority'] = {
                'type': 'MessagePriority',
                'module': 'gnosari_engine.queue.messages.base'
            }
            
        if 'status' in message_dict and hasattr(message, 'status'):
            enum_metadata['status'] = {
                'type': 'MessageStatus', 
                'module': 'gnosari_engine.queue.messages.base'
            }
        
        if enum_metadata:
            message_dict['__enum_metadata__'] = enum_metadata
    
    def _restore_enum_values(self, message_dict: dict[str, Any]) -> None:
        """Restore enum objects from serialized values using metadata."""
        enum_metadata = message_dict.pop('__enum_metadata__', {})
        
        if not enum_metadata:
            return
            
        # Import enum classes
        from ..messages.base import MessagePriority, MessageStatus
        
        enum_classes = {
            'MessagePriority': MessagePriority,
            'MessageStatus': MessageStatus,
        }
        
        # Restore enum values
        for field_name, metadata in enum_metadata.items():
            if field_name in message_dict:
                enum_type = metadata['type']
                if enum_type in enum_classes:
                    enum_class = enum_classes[enum_type]
                    try:
                        # Convert value back to enum
                        message_dict[field_name] = enum_class(message_dict[field_name])
                    except ValueError:
                        # If conversion fails, leave as-is and let Pydantic handle it
                        pass

    @staticmethod
    def _json_serializer(obj: Any) -> str:
        """Custom JSON serializer for complex objects."""
        from enum import Enum
        
        if hasattr(obj, 'isoformat'):
            return obj.isoformat()
        elif isinstance(obj, Enum):
            return obj.value
        elif hasattr(obj, '__dict__'):
            return obj.__dict__
        else:
            return str(obj)


class PickleMessageSerializer(IMessageSerializer[BaseMessage]):
    """
    Pickle-based message serialization strategy.
    
    Handles complex Python objects but produces binary data.
    More secure than JSON for trusted environments.
    """
    
    def serialize(self, message: BaseMessage) -> bytes:
        """Serialize message using pickle."""
        try:
            return pickle.dumps(message, protocol=pickle.HIGHEST_PROTOCOL)
        except (pickle.PicklingError, TypeError) as e:
            raise MessageSerializationError(
                f"Failed to pickle message: {e}", e
            ) from e
    
    def deserialize(self, data: bytes, message_type: Type[BaseMessage]) -> BaseMessage:
        """Deserialize pickle bytes to message object."""
        try:
            message = pickle.loads(data)
            
            # Validate type
            if not isinstance(message, message_type):
                raise MessageDeserializationError(
                    f"Deserialized object is not of type {message_type.__name__}"
                )
            
            return message
            
        except (pickle.UnpicklingError, TypeError, AttributeError) as e:
            raise MessageDeserializationError(
                f"Failed to unpickle message: {e}", e
            ) from e
    
    def get_content_type(self) -> str:
        """Get pickle content type."""
        return "application/x-python-pickle"


class CompressedJsonSerializer(JsonMessageSerializer):
    """
    Compressed JSON serialization for large messages.
    
    Uses gzip compression to reduce message size while maintaining
    JSON's human-readable format.
    """
    
    def serialize(self, message: BaseMessage) -> bytes:
        """Serialize and compress message."""
        import gzip
        
        try:
            json_data = super().serialize(message)
            return gzip.compress(json_data, compresslevel=6)
        except Exception as e:
            raise MessageSerializationError(
                f"Failed to compress JSON message: {e}", e
            ) from e
    
    def deserialize(self, data: bytes, message_type: Type[BaseMessage]) -> BaseMessage:
        """Decompress and deserialize message."""
        import gzip
        
        try:
            json_data = gzip.decompress(data)
            return super().deserialize(json_data, message_type)
        except Exception as e:
            raise MessageDeserializationError(
                f"Failed to decompress JSON message: {e}", e
            ) from e
    
    def get_content_type(self) -> str:
        """Get compressed JSON content type."""
        return "application/json+gzip"


class SerializerFactory:
    """
    Factory for creating serialization strategies.
    Follows Factory pattern for strategy selection.
    """
    
    _strategies: dict[str, Type[IMessageSerializer]] = {
        'json': JsonMessageSerializer,
        'pickle': PickleMessageSerializer,
        'compressed_json': CompressedJsonSerializer,
    }
    
    @classmethod
    def create(cls, strategy_name: str) -> IMessageSerializer[BaseMessage]:
        """
        Create serializer instance by strategy name.
        
        Args:
            strategy_name: Name of serialization strategy
            
        Returns:
            Serializer instance
            
        Raises:
            SerializerNotFoundError: If strategy not found
        """
        if strategy_name not in cls._strategies:
            raise SerializerNotFoundError(strategy_name)
        
        strategy_class = cls._strategies[strategy_name]
        return strategy_class()
    
    @classmethod
    def register_strategy(
        cls, 
        name: str, 
        strategy_class: Type[IMessageSerializer]
    ) -> None:
        """
        Register a new serialization strategy.
        
        Args:
            name: Strategy name
            strategy_class: Serializer class
        """
        cls._strategies[name] = strategy_class
    
    @classmethod
    def list_strategies(cls) -> list[str]:
        """List available serialization strategies."""
        return list(cls._strategies.keys())
    
    @classmethod
    def get_default_strategy(cls) -> str:
        """Get default serialization strategy name."""
        return 'json'


class MessageRegistry(IMessageRegistry):
    """
    Registry for message types and their corresponding classes.
    Enables dynamic message type discovery and deserialization.
    """
    
    def __init__(self) -> None:
        self._message_types: dict[str, Type[BaseMessage]] = {}
        self._auto_register_built_in_types()
    
    def register_message_type(
        self, 
        message_type: str, 
        message_class: Type[BaseMessage]
    ) -> None:
        """Register a message type with its class."""
        self._message_types[message_type] = message_class
    
    def get_message_class(self, message_type: str) -> Type[BaseMessage]:
        """Get message class for a message type."""
        if message_type not in self._message_types:
            raise MessageTypeNotFoundError(message_type)
        return self._message_types[message_type]
    
    def list_message_types(self) -> list[str]:
        """List all registered message types."""
        return list(self._message_types.keys())
    
    def is_registered(self, message_type: str) -> bool:
        """Check if message type is registered."""
        return message_type in self._message_types
    
    def _auto_register_built_in_types(self) -> None:
        """Auto-register built-in message types."""
        # Import message types with their payloads
        from ..messages.agent_messages import (
            AgentExecutionMessage,
            AgentExecutionPayload,
            AgentTrainingMessage,
            AgentTrainingPayload,
            TeamOrchestrationMessage,
            TeamOrchestrationPayload,
        )
        from ..messages.knowledge_messages import (
            KnowledgeIndexingMessage,
            KnowledgeIndexingPayload,
            KnowledgeQueryMessage,
            KnowledgeQueryPayload,
            KnowledgeMaintenanceMessage,
            KnowledgeMaintenancePayload,
        )
        from ..messages.system_messages import (
            SystemHealthCheckMessage,
            SystemHealthCheckPayload,
            SystemMetricsMessage,
            SystemMetricsPayload,
            SystemCleanupMessage,
            SystemCleanupPayload,
        )
        
        # Register message types with their default instances
        message_type_mappings = [
            ("agent.execution", AgentExecutionMessage),
            ("agent.training", AgentTrainingMessage),
            ("team.orchestration", TeamOrchestrationMessage),
            ("knowledge.indexing", KnowledgeIndexingMessage),
            ("knowledge.query", KnowledgeQueryMessage),
            ("knowledge.maintenance", KnowledgeMaintenanceMessage),
            ("system.health_check", SystemHealthCheckMessage),
            ("system.metrics", SystemMetricsMessage),
            ("system.cleanup", SystemCleanupMessage),
        ]
        
        for message_type, message_class in message_type_mappings:
            self.register_message_type(message_type, message_class)


# Global message registry instance
_global_registry = MessageRegistry()


def get_message_registry() -> MessageRegistry:
    """Get the global message registry instance."""
    return _global_registry