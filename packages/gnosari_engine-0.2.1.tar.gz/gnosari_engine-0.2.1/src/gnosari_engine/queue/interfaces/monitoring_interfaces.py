"""
Monitoring and observability interfaces for the queue system.
Separated concerns for metrics, health checks, and retry logic.
"""

from abc import ABC, abstractmethod
from typing import Any

from ..messages.base import BaseMessage


class IQueueMonitor(ABC):
    """
    Interface for queue monitoring and metrics collection.
    Provides observability into queue performance and health.
    """
    
    @abstractmethod
    async def get_queue_stats(self, queue_name: str) -> dict[str, Any]:
        """
        Get comprehensive statistics for a queue.
        
        Args:
            queue_name: Name of queue to get stats for
            
        Returns:
            Dictionary with queue statistics:
            - queue_length: Number of pending messages
            - processing_count: Messages currently being processed
            - completed_count: Total completed messages
            - failed_count: Total failed messages
            - average_processing_time: Average processing time in ms
            - throughput_per_minute: Messages processed per minute
            - error_rate: Percentage of failed messages
            
        Raises:
            QueueMonitoringError: If stats collection fails
        """
        pass
    
    @abstractmethod
    async def get_message_status(self, message_id: str) -> dict[str, Any]:
        """
        Get detailed status for a specific message.
        
        Args:
            message_id: ID of message to check
            
        Returns:
            Dictionary with message status information
            
        Raises:
            MessageNotFoundError: If message doesn't exist
        """
        pass
    
    @abstractmethod
    async def get_system_health(self) -> dict[str, Any]:
        """
        Get overall system health metrics.
        
        Returns:
            Dictionary with system health information:
            - connection_status: Queue backend connection status
            - memory_usage: Memory usage statistics
            - cpu_usage: CPU usage statistics
            - active_consumers: Number of active consumers
            - queue_count: Total number of queues
            
        Raises:
            HealthCheckError: If health check fails
        """
        pass
    
    @abstractmethod
    async def get_performance_metrics(
        self, 
        time_range_minutes: int = 60
    ) -> dict[str, Any]:
        """
        Get performance metrics over a time range.
        
        Args:
            time_range_minutes: Time range for metrics collection
            
        Returns:
            Dictionary with performance metrics
            
        Raises:
            MetricsCollectionError: If metrics collection fails
        """
        pass


class IRetryStrategy(ABC):
    """
    Interface for message retry logic.
    Allows different retry strategies (exponential backoff, linear, etc.).
    """
    
    @abstractmethod
    def should_retry(self, message: BaseMessage, error: Exception) -> bool:
        """
        Determine if a message should be retried after failure.
        
        Args:
            message: Failed message
            error: Exception that caused failure
            
        Returns:
            True if message should be retried
        """
        pass
    
    @abstractmethod
    def get_delay_seconds(self, attempt: int) -> int:
        """
        Calculate delay before retry attempt.
        
        Args:
            attempt: Current attempt number (1-based)
            
        Returns:
            Delay in seconds before retry
        """
        pass
    
    @abstractmethod
    def get_max_attempts(self, message: BaseMessage) -> int:
        """
        Get maximum retry attempts for a message.
        
        Args:
            message: Message to check
            
        Returns:
            Maximum number of retry attempts
        """
        pass
    
    @abstractmethod
    def should_dead_letter(self, message: BaseMessage, error: Exception) -> bool:
        """
        Determine if message should be sent to dead letter queue.
        
        Args:
            message: Failed message
            error: Exception that caused failure
            
        Returns:
            True if message should be dead lettered
        """
        pass


class ICircuitBreaker(ABC):
    """
    Interface for circuit breaker pattern implementation.
    Protects system from cascading failures.
    """
    
    @abstractmethod
    async def call(self, operation: Any, *args: Any, **kwargs: Any) -> Any:
        """
        Execute operation through circuit breaker.
        
        Args:
            operation: Function/method to execute
            args: Positional arguments
            kwargs: Keyword arguments
            
        Returns:
            Operation result
            
        Raises:
            CircuitBreakerOpenError: If circuit is open
        """
        pass
    
    @abstractmethod
    def get_state(self) -> str:
        """
        Get current circuit breaker state.
        
        Returns:
            Current state: 'closed', 'open', or 'half_open'
        """
        pass
    
    @abstractmethod
    def reset(self) -> None:
        """Reset circuit breaker to closed state."""
        pass


class IAlertManager(ABC):
    """
    Interface for alert management and notifications.
    Handles alerting on queue system issues.
    """
    
    @abstractmethod
    async def send_alert(
        self, 
        alert_type: str, 
        message: str, 
        severity: str = "warning",
        metadata: dict[str, Any] | None = None
    ) -> None:
        """
        Send an alert notification.
        
        Args:
            alert_type: Type of alert (queue_full, processing_error, etc.)
            message: Alert message
            severity: Alert severity (info, warning, error, critical)
            metadata: Additional alert metadata
            
        Raises:
            AlertSendError: If alert sending fails
        """
        pass
    
    @abstractmethod
    async def check_alert_rules(self, queue_stats: dict[str, Any]) -> None:
        """
        Check queue statistics against alert rules.
        
        Args:
            queue_stats: Queue statistics to check
            
        Raises:
            AlertRuleError: If rule evaluation fails
        """
        pass
    
    @abstractmethod
    def register_alert_rule(
        self, 
        rule_name: str, 
        condition: str, 
        action: str
    ) -> None:
        """
        Register a new alert rule.
        
        Args:
            rule_name: Name of the alert rule
            condition: Condition that triggers alert
            action: Action to take when triggered
            
        Raises:
            AlertRuleRegistrationError: If registration fails
        """
        pass


class IMetricsCollector(ABC):
    """
    Interface for collecting and storing metrics.
    Separated from monitoring for different storage backends.
    """
    
    @abstractmethod
    async def record_metric(
        self, 
        metric_name: str, 
        value: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """
        Record a single metric value.
        
        Args:
            metric_name: Name of the metric
            value: Metric value
            tags: Optional metric tags
            
        Raises:
            MetricRecordingError: If recording fails
        """
        pass
    
    @abstractmethod
    async def increment_counter(
        self, 
        counter_name: str, 
        tags: dict[str, str] | None = None
    ) -> None:
        """
        Increment a counter metric.
        
        Args:
            counter_name: Name of the counter
            tags: Optional metric tags
            
        Raises:
            CounterIncrementError: If increment fails
        """
        pass
    
    @abstractmethod
    async def record_timing(
        self, 
        timer_name: str, 
        duration_ms: float, 
        tags: dict[str, str] | None = None
    ) -> None:
        """
        Record a timing metric.
        
        Args:
            timer_name: Name of the timer
            duration_ms: Duration in milliseconds
            tags: Optional metric tags
            
        Raises:
            TimingRecordingError: If recording fails
        """
        pass