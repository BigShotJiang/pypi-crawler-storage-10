"""
Core queue operation interfaces.
Follows Interface Segregation Principle - separate concerns for different queue operations.
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Generic, TypeVar

from ..messages.base import BaseMessage

T = TypeVar('T', bound=BaseMessage)


class IQueueProducer(ABC, Generic[T]):
    """
    Interface for publishing messages to queues.
    Separated from consumer operations following ISP.
    """
    
    @abstractmethod
    async def publish(self, message: T, delay_seconds: int = 0) -> str:
        """
        Publish a single message to the appropriate queue.
        
        Args:
            message: Message to publish
            delay_seconds: Delay before message becomes available for consumption
            
        Returns:
            Message ID for tracking
            
        Raises:
            QueuePublishError: If publishing fails
        """
        pass
    
    @abstractmethod
    async def publish_batch(self, messages: list[T]) -> list[str]:
        """
        Publish multiple messages in a single operation.
        
        Args:
            messages: List of messages to publish
            
        Returns:
            List of message IDs in same order as input
            
        Raises:
            QueuePublishError: If batch publishing fails
        """
        pass
    
    @abstractmethod
    async def schedule_message(self, message: T, schedule_time: Any) -> str:
        """
        Schedule a message for future delivery.
        
        Args:
            message: Message to schedule
            schedule_time: When message should be delivered
            
        Returns:
            Scheduled message ID
            
        Raises:
            QueueScheduleError: If scheduling fails
        """
        pass


class IQueueConsumer(ABC, Generic[T]):
    """
    Interface for consuming messages from queues.
    Separated from producer operations following ISP.
    """
    
    @abstractmethod
    async def consume(
        self, 
        queue_name: str, 
        handler: Callable[[T], Any],
        max_concurrent: int = 10,
        auto_ack: bool = False
    ) -> None:
        """
        Start consuming messages from a queue.
        
        Args:
            queue_name: Name of queue to consume from
            handler: Async function to process messages
            max_concurrent: Maximum concurrent message processing
            auto_ack: Whether to auto-acknowledge messages
            
        Raises:
            QueueConsumeError: If consumption fails
        """
        pass
    
    @abstractmethod
    async def acknowledge(self, message_id: str) -> None:
        """
        Acknowledge successful message processing.
        
        Args:
            message_id: ID of message to acknowledge
            
        Raises:
            QueueAckError: If acknowledgment fails
        """
        pass
    
    @abstractmethod
    async def reject(self, message_id: str, requeue: bool = True) -> None:
        """
        Reject message processing.
        
        Args:
            message_id: ID of message to reject
            requeue: Whether to requeue message for retry
            
        Raises:
            QueueRejectError: If rejection fails
        """
        pass
    
    @abstractmethod
    async def nack(self, message_id: str, requeue: bool = True) -> None:
        """
        Negative acknowledgment - message processing failed.
        
        Args:
            message_id: ID of message to nack
            requeue: Whether to requeue for retry
            
        Raises:
            QueueNackError: If nack fails
        """
        pass


class IQueueManager(ABC):
    """
    Interface for queue lifecycle management.
    Separated from message operations following ISP.
    """
    
    @abstractmethod
    async def create_queue(
        self, 
        name: str, 
        durable: bool = True,
        max_priority: int = 4,
        message_ttl: int | None = None,
        max_length: int | None = None
    ) -> None:
        """
        Create a queue with specified configuration.
        
        Args:
            name: Queue name
            durable: Whether queue survives server restart
            max_priority: Maximum message priority
            message_ttl: Message time-to-live in seconds
            max_length: Maximum queue length
            
        Raises:
            QueueCreateError: If queue creation fails
        """
        pass
    
    @abstractmethod
    async def delete_queue(self, name: str, if_unused: bool = False) -> None:
        """
        Delete a queue.
        
        Args:
            name: Queue name to delete
            if_unused: Only delete if queue is unused
            
        Raises:
            QueueDeleteError: If deletion fails
        """
        pass
    
    @abstractmethod
    async def purge_queue(self, name: str) -> int:
        """
        Remove all messages from a queue.
        
        Args:
            name: Queue name to purge
            
        Returns:
            Number of messages purged
            
        Raises:
            QueuePurgeError: If purging fails
        """
        pass
    
    @abstractmethod
    async def queue_exists(self, name: str) -> bool:
        """
        Check if a queue exists.
        
        Args:
            name: Queue name to check
            
        Returns:
            True if queue exists
            
        Raises:
            QueueCheckError: If check fails
        """
        pass
    
    @abstractmethod
    async def list_queues(self) -> list[str]:
        """
        List all existing queues.
        
        Returns:
            List of queue names
            
        Raises:
            QueueListError: If listing fails
        """
        pass


class IQueueConnection(ABC):
    """
    Interface for queue connection management.
    Separated for connection lifecycle concerns.
    """
    
    @abstractmethod
    async def connect(self) -> None:
        """
        Establish connection to queue backend.
        
        Raises:
            QueueConnectionError: If connection fails
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """
        Close connection to queue backend.
        
        Raises:
            QueueDisconnectionError: If disconnection fails
        """
        pass
    
    @abstractmethod
    async def is_connected(self) -> bool:
        """
        Check if connection is active.
        
        Returns:
            True if connected
        """
        pass
    
    @abstractmethod
    async def reconnect(self) -> None:
        """
        Reconnect to queue backend.
        
        Raises:
            QueueReconnectionError: If reconnection fails
        """
        pass