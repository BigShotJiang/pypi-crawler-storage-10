"""
Message processing interfaces.
Handles serialization and message processing concerns.
"""

from abc import ABC, abstractmethod
from typing import Any, Type, TypeVar, Generic

from ..messages.base import BaseMessage

T = TypeVar('T', bound=BaseMessage)


class IMessageSerializer(ABC, Generic[T]):
    """
    Interface for message serialization and deserialization.
    Allows different serialization strategies (JSON, Pickle, etc.).
    """
    
    @abstractmethod
    def serialize(self, message: T) -> bytes:
        """
        Serialize message object to bytes for queue storage.
        
        Args:
            message: Message object to serialize
            
        Returns:
            Serialized message as bytes
            
        Raises:
            MessageSerializationError: If serialization fails
        """
        pass
    
    @abstractmethod
    def deserialize(self, data: bytes, message_type: Type[T]) -> T:
        """
        Deserialize bytes back to message object.
        
        Args:
            data: Serialized message bytes
            message_type: Expected message type class
            
        Returns:
            Deserialized message object
            
        Raises:
            MessageDeserializationError: If deserialization fails
        """
        pass
    
    @abstractmethod
    def get_content_type(self) -> str:
        """
        Get content type identifier for this serializer.
        
        Returns:
            Content type string (e.g., 'application/json')
        """
        pass


class IMessageProcessor(ABC, Generic[T]):
    """
    Interface for processing specific message types.
    Follows Single Responsibility - each processor handles one message type.
    """
    
    @abstractmethod
    def can_handle(self, message: BaseMessage) -> bool:
        """
        Check if this processor can handle the given message type.
        
        Args:
            message: Message to check
            
        Returns:
            True if processor can handle this message
        """
        pass
    
    @abstractmethod
    async def process(self, message: T) -> Any:
        """
        Process the message and return result.
        
        Args:
            message: Message to process
            
        Returns:
            Processing result (type depends on message type)
            
        Raises:
            MessageProcessingError: If processing fails
        """
        pass
    
    @abstractmethod
    def get_supported_message_types(self) -> list[str]:
        """
        Get list of message types this processor supports.
        
        Returns:
            List of supported message type strings
        """
        pass
    
    @abstractmethod
    async def validate_message(self, message: T) -> bool:
        """
        Validate message before processing.
        
        Args:
            message: Message to validate
            
        Returns:
            True if message is valid for processing
            
        Raises:
            MessageValidationError: If validation fails
        """
        pass


class IMessageRegistry(ABC):
    """
    Interface for managing message type registration.
    Allows dynamic message type discovery and validation.
    """
    
    @abstractmethod
    def register_message_type(
        self, 
        message_type: str, 
        message_class: Type[BaseMessage]
    ) -> None:
        """
        Register a message type with its corresponding class.
        
        Args:
            message_type: String identifier for message type
            message_class: Message class for this type
            
        Raises:
            MessageRegistrationError: If registration fails
        """
        pass
    
    @abstractmethod
    def get_message_class(self, message_type: str) -> Type[BaseMessage]:
        """
        Get message class for a given message type.
        
        Args:
            message_type: Message type string
            
        Returns:
            Message class for this type
            
        Raises:
            MessageTypeNotFoundError: If type not registered
        """
        pass
    
    @abstractmethod
    def list_message_types(self) -> list[str]:
        """
        List all registered message types.
        
        Returns:
            List of registered message type strings
        """
        pass
    
    @abstractmethod
    def is_registered(self, message_type: str) -> bool:
        """
        Check if a message type is registered.
        
        Args:
            message_type: Message type to check
            
        Returns:
            True if type is registered
        """
        pass


class IMessageValidator(ABC):
    """
    Interface for message validation logic.
    Separated from processing for single responsibility.
    """
    
    @abstractmethod
    async def validate_structure(self, message: BaseMessage) -> list[str]:
        """
        Validate message structure and return any errors.
        
        Args:
            message: Message to validate
            
        Returns:
            List of validation errors (empty if valid)
        """
        pass
    
    @abstractmethod
    async def validate_business_rules(self, message: BaseMessage) -> list[str]:
        """
        Validate business rules for the message.
        
        Args:
            message: Message to validate
            
        Returns:
            List of business rule violations (empty if valid)
        """
        pass
    
    @abstractmethod
    async def validate_security(self, message: BaseMessage) -> list[str]:
        """
        Validate message for security concerns.
        
        Args:
            message: Message to validate
            
        Returns:
            List of security violations (empty if valid)
        """
        pass