"""
Circuit breaker implementation for fault tolerance.
Protects against cascading failures in message processing.
"""

import asyncio
import time
from enum import Enum
from typing import Any, Callable

from ..interfaces.monitoring_interfaces import ICircuitBreaker
from .exceptions import CircuitBreakerOpenError


class CircuitBreakerState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Circuit is open, failing fast
    HALF_OPEN = "half_open"  # Testing if service recovered


class CircuitBreaker(ICircuitBreaker):
    """
    Circuit breaker implementation with configurable thresholds.
    
    Protects services from cascading failures by monitoring error rates
    and temporarily blocking requests when thresholds are exceeded.
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type[Exception] = Exception,
        success_threshold: int = 3,
        timeout: int = 30,
    ) -> None:
        """
        Initialize circuit breaker.
        
        Args:
            failure_threshold: Number of failures before opening circuit
            recovery_timeout: Seconds to wait before trying half-open
            expected_exception: Exception type that triggers circuit opening
            success_threshold: Successful calls needed to close from half-open
            timeout: Timeout for individual operations
        """
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.success_threshold = success_threshold
        self.timeout = timeout
        
        # State tracking
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0
        self._lock = asyncio.Lock()
    
    async def call(self, operation: Callable, *args: Any, **kwargs: Any) -> Any:
        """
        Execute operation through circuit breaker.
        
        Args:
            operation: Function to execute
            *args: Positional arguments for operation
            **kwargs: Keyword arguments for operation
            
        Returns:
            Operation result
            
        Raises:
            CircuitBreakerOpenError: If circuit is open
            TimeoutError: If operation times out
        """
        async with self._lock:
            # Check if we should transition from OPEN to HALF_OPEN
            if (self._state == CircuitBreakerState.OPEN and 
                time.time() - self._last_failure_time >= self.recovery_timeout):
                self._state = CircuitBreakerState.HALF_OPEN
                self._success_count = 0
        
        # Fail fast if circuit is open
        if self._state == CircuitBreakerState.OPEN:
            raise CircuitBreakerOpenError(f"Circuit breaker is open for {operation.__name__}")
        
        try:
            # Execute operation with timeout
            if asyncio.iscoroutinefunction(operation):
                result = await asyncio.wait_for(
                    operation(*args, **kwargs), 
                    timeout=self.timeout
                )
            else:
                result = operation(*args, **kwargs)
            
            # Record success
            await self._record_success()
            return result
            
        except self.expected_exception as e:
            # Record failure for expected exceptions
            await self._record_failure()
            raise
        except asyncio.TimeoutError as e:
            # Timeout also counts as failure
            await self._record_failure()
            raise
    
    async def _record_success(self) -> None:
        """Record successful operation."""
        async with self._lock:
            if self._state == CircuitBreakerState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    # Close circuit after enough successes
                    self._state = CircuitBreakerState.CLOSED
                    self._failure_count = 0
                    self._success_count = 0
            elif self._state == CircuitBreakerState.CLOSED:
                # Reset failure count on success
                self._failure_count = 0
    
    async def _record_failure(self) -> None:
        """Record failed operation."""
        async with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()
            
            if (self._state == CircuitBreakerState.CLOSED and 
                self._failure_count >= self.failure_threshold):
                # Open circuit after threshold breached
                self._state = CircuitBreakerState.OPEN
            elif self._state == CircuitBreakerState.HALF_OPEN:
                # Go back to open if half-open test fails
                self._state = CircuitBreakerState.OPEN
                self._success_count = 0
    
    def get_state(self) -> str:
        """Get current circuit breaker state."""
        return self._state.value
    
    def reset(self) -> None:
        """Reset circuit breaker to closed state."""
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0
    
    def get_stats(self) -> dict[str, Any]:
        """Get circuit breaker statistics."""
        return {
            "state": self._state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "last_failure_time": self._last_failure_time,
            "failure_threshold": self.failure_threshold,
            "recovery_timeout": self.recovery_timeout,
        }


class CircuitBreakerRegistry:
    """Registry for managing multiple circuit breakers."""
    
    def __init__(self) -> None:
        self._breakers: dict[str, CircuitBreaker] = {}
    
    def get_or_create(
        self, 
        name: str, 
        **kwargs
    ) -> CircuitBreaker:
        """Get existing circuit breaker or create new one."""
        if name not in self._breakers:
            self._breakers[name] = CircuitBreaker(**kwargs)
        return self._breakers[name]
    
    def get(self, name: str) -> CircuitBreaker | None:
        """Get circuit breaker by name."""
        return self._breakers.get(name)
    
    def remove(self, name: str) -> bool:
        """Remove circuit breaker."""
        if name in self._breakers:
            del self._breakers[name]
            return True
        return False
    
    def list_breakers(self) -> list[str]:
        """List all circuit breaker names."""
        return list(self._breakers.keys())
    
    def get_all_stats(self) -> dict[str, dict[str, Any]]:
        """Get statistics for all circuit breakers."""
        return {
            name: breaker.get_stats() 
            for name, breaker in self._breakers.items()
        }
    
    def reset_all(self) -> None:
        """Reset all circuit breakers."""
        for breaker in self._breakers.values():
            breaker.reset()


# Global circuit breaker registry
_global_registry = CircuitBreakerRegistry()


def get_circuit_breaker_registry() -> CircuitBreakerRegistry:
    """Get global circuit breaker registry."""
    return _global_registry