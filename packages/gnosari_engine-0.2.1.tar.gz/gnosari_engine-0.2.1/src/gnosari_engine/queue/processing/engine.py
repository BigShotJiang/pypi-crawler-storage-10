"""
Message processing engine with enterprise features.
Orchestrates message processing with retry logic, circuit breakers, and monitoring.
"""

import asyncio
from datetime import datetime
from typing import Any, Dict

from ..interfaces.message_interfaces import IMessageProcessor
from ..interfaces.monitoring_interfaces import IRetryStrategy
from ..interfaces.queue_interfaces import IQueueProducer
from ..messages.base import BaseMessage, MessageStatus
from .circuit_breaker import CircuitBreakerRegistry, get_circuit_breaker_registry
from .exceptions import (
    MessageProcessingError,
    ProcessorNotFoundError,
    RetryExhaustedError,
)
from .retry_strategies import ExponentialBackoffRetry


class ProcessingEngine:
    """
    Central engine for processing messages with enterprise features.
    
    Features:
    - Multiple processor registration and routing
    - Retry logic with configurable strategies
    - Circuit breaker pattern for fault tolerance
    - Metrics collection and monitoring
    - Dead letter queue handling
    - Graceful error handling and recovery
    """
    
    def __init__(
        self,
        queue_producer: IQueueProducer[BaseMessage],
        retry_strategy: IRetryStrategy | None = None,
        circuit_breaker_registry: CircuitBreakerRegistry | None = None,
        enable_circuit_breakers: bool = True,
        default_timeout: int = 300,
    ) -> None:
        """
        Initialize processing engine.
        
        Args:
            queue_producer: Queue producer for retry/dead letter operations
            retry_strategy: Strategy for retry logic
            circuit_breaker_registry: Registry for circuit breakers
            enable_circuit_breakers: Whether to use circuit breakers
            default_timeout: Default processing timeout in seconds
        """
        self.queue_producer = queue_producer
        self.retry_strategy = retry_strategy or ExponentialBackoffRetry()
        self.circuit_breaker_registry = circuit_breaker_registry or get_circuit_breaker_registry()
        self.enable_circuit_breakers = enable_circuit_breakers
        self.default_timeout = default_timeout
        
        # Processor management
        self.processors: Dict[str, IMessageProcessor] = {}
        self.processor_configs: Dict[str, Dict[str, Any]] = {}
        
        # Metrics tracking
        self.metrics = {
            "messages_processed": 0,
            "messages_succeeded": 0,
            "messages_failed": 0,
            "messages_retried": 0,
            "messages_dead_lettered": 0,
            "average_processing_time": 0.0,
            "processor_metrics": {},
        }
        
        # Processing state
        self._shutdown = False
        self._active_tasks: set[asyncio.Task] = set()
    
    def register_processor(
        self, 
        processor: IMessageProcessor,
        timeout: int | None = None,
        circuit_breaker_config: Dict[str, Any] | None = None
    ) -> None:
        """
        Register message processor with optional configuration.
        
        Args:
            processor: Message processor instance
            timeout: Processing timeout override
            circuit_breaker_config: Circuit breaker configuration
        """
        processor_name = processor.__class__.__name__
        self.processors[processor_name] = processor
        
        # Store processor configuration
        config = {
            "timeout": timeout or self.default_timeout,
            "circuit_breaker": circuit_breaker_config or {},
        }
        self.processor_configs[processor_name] = config
        
        # Initialize processor metrics
        self.metrics["processor_metrics"][processor_name] = {
            "processed": 0,
            "succeeded": 0,
            "failed": 0,
            "average_time": 0.0,
        }
        
        # Create circuit breaker if enabled
        if self.enable_circuit_breakers:
            cb_config = circuit_breaker_config or {}
            self.circuit_breaker_registry.get_or_create(
                f"processor_{processor_name}",
                **cb_config
            )
    
    def unregister_processor(self, processor_name: str) -> bool:
        """
        Unregister message processor.
        
        Args:
            processor_name: Name of processor to unregister
            
        Returns:
            True if processor was found and removed
        """
        if processor_name in self.processors:
            del self.processors[processor_name]
            self.processor_configs.pop(processor_name, None)
            self.metrics["processor_metrics"].pop(processor_name, None)
            
            # Remove circuit breaker
            self.circuit_breaker_registry.remove(f"processor_{processor_name}")
            return True
        return False
    
    def list_processors(self) -> list[str]:
        """List registered processors."""
        return list(self.processors.keys())
    
    async def process_message(self, message: BaseMessage) -> Any:
        """
        Process message with full error handling and retry logic.
        
        Args:
            message: Message to process
            
        Returns:
            Processing result
            
        Raises:
            ProcessorNotFoundError: If no processor found for message
            MessageProcessingError: If processing fails after retries
        """
        start_time = datetime.utcnow()
        processor = None
        
        try:
            # Find appropriate processor
            processor = self._find_processor(message)
            if not processor:
                raise ProcessorNotFoundError(message.type)
            
            processor_name = processor.__class__.__name__
            config = self.processor_configs[processor_name]
            
            # Update message status
            message.mark_processing()
            
            # Process with circuit breaker if enabled
            if self.enable_circuit_breakers:
                circuit_breaker = self.circuit_breaker_registry.get_or_create(
                    f"processor_{processor_name}"
                )
                result = await circuit_breaker.call(
                    self._execute_processor,
                    processor,
                    message,
                    config["timeout"]
                )
            else:
                result = await self._execute_processor(
                    processor, message, config["timeout"]
                )
            
            # Mark as completed and update metrics
            message.mark_completed()
            await self._record_success(processor_name, start_time)
            
            return result
            
        except Exception as error:
            # Handle processing failure
            await self._handle_processing_error(message, error, processor, start_time)
            raise
    
    async def process_message_batch(self, messages: list[BaseMessage]) -> list[Any]:
        """
        Process multiple messages concurrently.
        
        Args:
            messages: List of messages to process
            
        Returns:
            List of processing results (None for failed messages)
        """
        tasks = []
        for message in messages:
            task = asyncio.create_task(self._safe_process_message(message))
            tasks.append(task)
            self._active_tasks.add(task)
            task.add_done_callback(self._active_tasks.discard)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results
    
    async def shutdown(self, timeout: int = 30) -> None:
        """
        Gracefully shutdown processing engine.
        
        Args:
            timeout: Timeout for waiting on active tasks
        """
        self._shutdown = True
        
        if self._active_tasks:
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._active_tasks, return_exceptions=True),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                # Cancel remaining tasks
                for task in self._active_tasks:
                    task.cancel()
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get processing metrics."""
        return self.metrics.copy()
    
    def get_processor_metrics(self, processor_name: str) -> Dict[str, Any] | None:
        """Get metrics for specific processor."""
        return self.metrics["processor_metrics"].get(processor_name)
    
    def reset_metrics(self) -> None:
        """Reset all metrics to zero."""
        self.metrics = {
            "messages_processed": 0,
            "messages_succeeded": 0,
            "messages_failed": 0,
            "messages_retried": 0,
            "messages_dead_lettered": 0,
            "average_processing_time": 0.0,
            "processor_metrics": {
                name: {
                    "processed": 0,
                    "succeeded": 0,
                    "failed": 0,
                    "average_time": 0.0,
                }
                for name in self.processors.keys()
            },
        }
    
    # Private Methods
    
    def _find_processor(self, message: BaseMessage) -> IMessageProcessor | None:
        """Find appropriate processor for message."""
        for processor in self.processors.values():
            if processor.can_handle(message):
                return processor
        return None
    
    async def _execute_processor(
        self, 
        processor: IMessageProcessor, 
        message: BaseMessage,
        timeout: int
    ) -> Any:
        """Execute processor with timeout."""
        try:
            # Validate message first
            if hasattr(processor, 'validate_message'):
                await processor.validate_message(message)
            
            # Process with timeout
            result = await asyncio.wait_for(
                processor.process(message),
                timeout=timeout
            )
            
            return result
            
        except asyncio.TimeoutError as e:
            raise MessageProcessingError(
                f"Processing timeout after {timeout}s",
                message.id,
                e
            ) from e
        except Exception as e:
            raise MessageProcessingError(
                f"Processor failed: {e}",
                message.id,
                e
            ) from e
    
    async def _handle_processing_error(
        self,
        message: BaseMessage,
        error: Exception,
        processor: IMessageProcessor | None,
        start_time: datetime
    ) -> None:
        """Handle processing error with retry logic."""
        message.mark_failed(str(error))
        
        processor_name = processor.__class__.__name__ if processor else "unknown"
        await self._record_failure(processor_name, start_time)
        
        # Check if should retry
        if self.retry_strategy.should_retry(message, error):
            await self._schedule_retry(message)
        elif self.retry_strategy.should_dead_letter(message, error):
            await self._send_to_dead_letter(message)
        else:
            # Final failure without dead letter
            self.metrics["messages_failed"] += 1
    
    async def _schedule_retry(self, message: BaseMessage) -> None:
        """Schedule message for retry."""
        try:
            delay = self.retry_strategy.get_delay_seconds(message.attempts)
            message.mark_retrying()
            
            await self.queue_producer.publish(message, delay_seconds=delay)
            self.metrics["messages_retried"] += 1
            
        except Exception as e:
            # If retry scheduling fails, try dead letter
            print(f"Failed to schedule retry for message {message.id}: {e}")
            await self._send_to_dead_letter(message)
    
    async def _send_to_dead_letter(self, message: BaseMessage) -> None:
        """Send message to dead letter queue."""
        try:
            message.mark_dead_letter()
            # Dead letter messages get a special queue name
            original_queue = message.get_queue_name()
            
            # Create a copy with dead letter queue name
            dead_letter_message = message.model_copy()
            dead_letter_message.metadata["original_queue"] = original_queue
            dead_letter_message.metadata["dead_letter_reason"] = message.last_error
            
            # Override queue name for dead letter
            def get_dead_letter_queue():
                return f"{original_queue}_dead_letter"
            
            dead_letter_message.get_queue_name = get_dead_letter_queue
            
            await self.queue_producer.publish(dead_letter_message)
            self.metrics["messages_dead_lettered"] += 1
            
        except Exception as e:
            print(f"Failed to send message {message.id} to dead letter queue: {e}")
    
    async def _record_success(self, processor_name: str, start_time: datetime) -> None:
        """Record successful processing metrics."""
        processing_time = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        # Update global metrics
        self.metrics["messages_processed"] += 1
        self.metrics["messages_succeeded"] += 1
        
        # Update average processing time
        total_processed = self.metrics["messages_processed"]
        current_avg = self.metrics["average_processing_time"]
        self.metrics["average_processing_time"] = (
            (current_avg * (total_processed - 1) + processing_time) / total_processed
        )
        
        # Update processor-specific metrics
        if processor_name in self.metrics["processor_metrics"]:
            proc_metrics = self.metrics["processor_metrics"][processor_name]
            proc_metrics["processed"] += 1
            proc_metrics["succeeded"] += 1
            
            # Update processor average time
            proc_total = proc_metrics["processed"]
            proc_avg = proc_metrics["average_time"]
            proc_metrics["average_time"] = (
                (proc_avg * (proc_total - 1) + processing_time) / proc_total
            )
    
    async def _record_failure(self, processor_name: str, start_time: datetime) -> None:
        """Record failed processing metrics."""
        processing_time = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        # Update global metrics
        self.metrics["messages_processed"] += 1
        
        # Update processor-specific metrics
        if processor_name in self.metrics["processor_metrics"]:
            proc_metrics = self.metrics["processor_metrics"][processor_name]
            proc_metrics["processed"] += 1
            proc_metrics["failed"] += 1
            
            # Update processor average time (include failed attempts)
            proc_total = proc_metrics["processed"]
            proc_avg = proc_metrics["average_time"]
            proc_metrics["average_time"] = (
                (proc_avg * (proc_total - 1) + processing_time) / proc_total
            )
    
    async def _safe_process_message(self, message: BaseMessage) -> Any | None:
        """Safely process message, returning None on error."""
        try:
            return await self.process_message(message)
        except Exception as e:
            print(f"Message processing failed: {e}")
            return None