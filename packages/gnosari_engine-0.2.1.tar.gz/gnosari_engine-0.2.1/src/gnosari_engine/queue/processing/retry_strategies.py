"""
Retry strategy implementations for message processing.
Follows Strategy pattern for different retry approaches.
"""

import math
from typing import Type

from ..interfaces.monitoring_interfaces import IRetryStrategy
from ..messages.base import BaseMessage


class BaseRetryStrategy(IRetryStrategy):
    """Base retry strategy with common functionality."""
    
    def __init__(
        self,
        max_attempts: int = 3,
        dead_letter_errors: list[Type[Exception]] | None = None
    ) -> None:
        """
        Initialize base retry strategy.
        
        Args:
            max_attempts: Maximum retry attempts
            dead_letter_errors: Errors that should go directly to dead letter
        """
        self.max_attempts = max_attempts
        self.dead_letter_errors = dead_letter_errors or []
    
    def should_retry(self, message: BaseMessage, error: Exception) -> bool:
        """Check if message should be retried."""
        # Check if error type should go to dead letter immediately
        if any(isinstance(error, err_type) for err_type in self.dead_letter_errors):
            return False
        
        # Check attempt count
        return message.attempts < self.get_max_attempts(message)
    
    def get_max_attempts(self, message: BaseMessage) -> int:
        """Get maximum attempts for message."""
        # Use message's max_attempts if set, otherwise use strategy default
        return message.max_attempts or self.max_attempts
    
    def should_dead_letter(self, message: BaseMessage, error: Exception) -> bool:
        """Check if message should be dead lettered."""
        # Dead letter if retry attempts exhausted or specific error types
        return (
            message.attempts >= self.get_max_attempts(message) or
            any(isinstance(error, err_type) for err_type in self.dead_letter_errors)
        )


class ExponentialBackoffRetry(BaseRetryStrategy):
    """
    Exponential backoff retry strategy.
    
    Delay increases exponentially with each attempt: base_delay * (multiplier ^ attempt)
    """
    
    def __init__(
        self,
        base_delay: int = 2,
        multiplier: float = 2.0,
        max_delay: int = 300,
        jitter: bool = True,
        **kwargs
    ) -> None:
        """
        Initialize exponential backoff strategy.
        
        Args:
            base_delay: Base delay in seconds
            multiplier: Multiplier for each attempt
            max_delay: Maximum delay in seconds
            jitter: Add random jitter to prevent thundering herd
            **kwargs: Additional arguments for base class
        """
        super().__init__(**kwargs)
        self.base_delay = base_delay
        self.multiplier = multiplier
        self.max_delay = max_delay
        self.jitter = jitter
    
    def get_delay_seconds(self, attempt: int) -> int:
        """Calculate exponential backoff delay."""
        delay = self.base_delay * (self.multiplier ** (attempt - 1))
        delay = min(delay, self.max_delay)
        
        if self.jitter:
            import random
            # Add up to 25% jitter
            jitter_amount = delay * 0.25
            delay += random.uniform(-jitter_amount, jitter_amount)
        
        return max(1, int(delay))


class LinearBackoffRetry(BaseRetryStrategy):
    """
    Linear backoff retry strategy.
    
    Delay increases linearly with each attempt: base_delay + (increment * attempt)
    """
    
    def __init__(
        self,
        base_delay: int = 5,
        increment: int = 5,
        max_delay: int = 300,
        **kwargs
    ) -> None:
        """
        Initialize linear backoff strategy.
        
        Args:
            base_delay: Base delay in seconds
            increment: Delay increment per attempt
            max_delay: Maximum delay in seconds
            **kwargs: Additional arguments for base class
        """
        super().__init__(**kwargs)
        self.base_delay = base_delay
        self.increment = increment
        self.max_delay = max_delay
    
    def get_delay_seconds(self, attempt: int) -> int:
        """Calculate linear backoff delay."""
        delay = self.base_delay + (self.increment * (attempt - 1))
        return min(delay, self.max_delay)


class FixedDelayRetry(BaseRetryStrategy):
    """
    Fixed delay retry strategy.
    
    Uses the same delay for all retry attempts.
    """
    
    def __init__(self, delay: int = 10, **kwargs) -> None:
        """
        Initialize fixed delay strategy.
        
        Args:
            delay: Fixed delay in seconds
            **kwargs: Additional arguments for base class
        """
        super().__init__(**kwargs)
        self.delay = delay
    
    def get_delay_seconds(self, attempt: int) -> int:
        """Return fixed delay."""
        return self.delay


class FibonacciBackoffRetry(BaseRetryStrategy):
    """
    Fibonacci backoff retry strategy.
    
    Delay follows Fibonacci sequence: 1, 1, 2, 3, 5, 8, 13, ...
    """
    
    def __init__(self, base_delay: int = 1, max_delay: int = 300, **kwargs) -> None:
        """
        Initialize Fibonacci backoff strategy.
        
        Args:
            base_delay: Base delay multiplier in seconds
            max_delay: Maximum delay in seconds
            **kwargs: Additional arguments for base class
        """
        super().__init__(**kwargs)
        self.base_delay = base_delay
        self.max_delay = max_delay
    
    def get_delay_seconds(self, attempt: int) -> int:
        """Calculate Fibonacci backoff delay."""
        fib_value = self._fibonacci(attempt)
        delay = self.base_delay * fib_value
        return min(delay, self.max_delay)
    
    @staticmethod
    def _fibonacci(n: int) -> int:
        """Calculate nth Fibonacci number."""
        if n <= 2:
            return 1
        
        a, b = 1, 1
        for _ in range(3, n + 1):
            a, b = b, a + b
        return b


class AdaptiveRetryStrategy(BaseRetryStrategy):
    """
    Adaptive retry strategy that adjusts based on error patterns.
    
    Learns from error types and adjusts retry behavior accordingly.
    """
    
    def __init__(self, **kwargs) -> None:
        """Initialize adaptive retry strategy."""
        super().__init__(**kwargs)
        self.error_patterns: dict[str, dict[str, int]] = {}
        self.success_rates: dict[str, float] = {}
    
    def should_retry(self, message: BaseMessage, error: Exception) -> bool:
        """Adaptive retry decision based on error patterns."""
        error_type = type(error).__name__
        
        # Update error patterns
        if error_type not in self.error_patterns:
            self.error_patterns[error_type] = {"count": 0, "retries": 0, "successes": 0}
        
        pattern = self.error_patterns[error_type]
        pattern["count"] += 1
        
        # Calculate success rate for this error type
        if pattern["retries"] > 0:
            success_rate = pattern["successes"] / pattern["retries"]
            self.success_rates[error_type] = success_rate
        else:
            success_rate = 0.5  # Default to neutral
        
        # Don't retry if success rate is very low
        if success_rate < 0.1 and pattern["retries"] > 5:
            return False
        
        return super().should_retry(message, error)
    
    def get_delay_seconds(self, attempt: int) -> int:
        """Adaptive delay based on current system load."""
        # Start with exponential backoff
        base_delay = 2 * (2 ** (attempt - 1))
        
        # Adjust based on overall system success rate
        avg_success_rate = sum(self.success_rates.values()) / max(len(self.success_rates), 1)
        
        if avg_success_rate < 0.3:
            # System is struggling, increase delays
            base_delay *= 2
        elif avg_success_rate > 0.8:
            # System is healthy, reduce delays
            base_delay = max(1, base_delay // 2)
        
        return min(base_delay, 300)
    
    def record_success(self, error_type: str) -> None:
        """Record a successful retry for error type."""
        if error_type in self.error_patterns:
            self.error_patterns[error_type]["successes"] += 1


class RetryStrategyFactory:
    """Factory for creating retry strategies."""
    
    _strategies = {
        "exponential": ExponentialBackoffRetry,
        "linear": LinearBackoffRetry,
        "fixed": FixedDelayRetry,
        "fibonacci": FibonacciBackoffRetry,
        "adaptive": AdaptiveRetryStrategy,
    }
    
    @classmethod
    def create(cls, strategy_name: str, **kwargs) -> IRetryStrategy:
        """Create retry strategy by name."""
        if strategy_name not in cls._strategies:
            raise ValueError(f"Unknown retry strategy: {strategy_name}")
        
        strategy_class = cls._strategies[strategy_name]
        return strategy_class(**kwargs)
    
    @classmethod
    def register_strategy(
        cls, 
        name: str, 
        strategy_class: Type[IRetryStrategy]
    ) -> None:
        """Register custom retry strategy."""
        cls._strategies[name] = strategy_class
    
    @classmethod
    def list_strategies(cls) -> list[str]:
        """List available retry strategies."""
        return list(cls._strategies.keys())