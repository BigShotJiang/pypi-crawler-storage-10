"""Processing engine exceptions."""


class ProcessingEngineError(Exception):
    """Base exception for processing engine errors."""
    pass


class MessageProcessingError(ProcessingEngineError):
    """Raised when message processing fails."""
    
    def __init__(
        self, 
        message: str, 
        message_id: str | None = None,
        original_error: Exception | None = None
    ) -> None:
        super().__init__(message)
        self.message_id = message_id
        self.original_error = original_error


class ProcessorNotFoundError(ProcessingEngineError):
    """Raised when no processor is found for a message type."""
    
    def __init__(self, message_type: str) -> None:
        super().__init__(f"No processor found for message type: {message_type}")
        self.message_type = message_type


class CircuitBreakerOpenError(ProcessingEngineError):
    """Raised when circuit breaker is open."""
    
    def __init__(self, operation_name: str) -> None:
        super().__init__(f"Circuit breaker is open for operation: {operation_name}")
        self.operation_name = operation_name


class RetryExhaustedError(ProcessingEngineError):
    """Raised when retry attempts are exhausted."""
    
    def __init__(self, message_id: str, attempts: int) -> None:
        super().__init__(f"Retry exhausted for message {message_id} after {attempts} attempts")
        self.message_id = message_id
        self.attempts = attempts


class ProcessorValidationError(ProcessingEngineError):
    """Raised when processor validation fails."""
    
    def __init__(self, processor_name: str, validation_errors: list[str]) -> None:
        super().__init__(f"Validation failed for processor {processor_name}: {validation_errors}")
        self.processor_name = processor_name
        self.validation_errors = validation_errors