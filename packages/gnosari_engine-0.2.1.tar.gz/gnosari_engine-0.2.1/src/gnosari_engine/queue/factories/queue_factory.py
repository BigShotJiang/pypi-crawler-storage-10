"""
Queue system factory for creating and configuring queue components.
Provides a centralized way to build complete queue systems.
"""

from typing import Any

import redis.asyncio as redis

from ..interfaces.queue_interfaces import IQueueProducer, IQueueConsumer, IQueueManager
from ..monitoring.alert_manager import SimpleAlertManager
from ..monitoring.metrics_collector import MetricsCollectorFactory
from ..monitoring.queue_monitor import RedisQueueMonitor
from ..processing.engine import ProcessingEngine
from ..processing.retry_strategies import RetryStrategyFactory
from ..processors.agent_processors import (
    AgentExecutionProcessor,
    AgentTrainingProcessor,
    TeamOrchestrationProcessor,
)
from ..processors.knowledge_processors import (
    KnowledgeIndexingProcessor,
    KnowledgeMaintenanceProcessor,
    KnowledgeQueryProcessor,
)
from ..processors.system_processors import (
    SystemCleanupProcessor,
    SystemHealthCheckProcessor,
    SystemMetricsProcessor,
)
from ..providers.redis_provider import RedisQueueProvider
from ..serialization.strategies import SerializerFactory


class QueueFactory:
    """
    Factory for creating queue system components.
    
    Provides methods to create providers, processors, and monitoring
    components with proper configuration.
    """
    
    @staticmethod
    def create_redis_provider(
        redis_url: str = "redis://localhost:6379",
        serializer_type: str = "json",
        **kwargs
    ) -> RedisQueueProvider:
        """
        Create Redis queue provider.
        
        Args:
            redis_url: Redis connection URL
            serializer_type: Serialization strategy
            **kwargs: Additional provider configuration
            
        Returns:
            Configured Redis queue provider
        """
        return RedisQueueProvider(
            redis_url=redis_url,
            serializer_type=serializer_type,
            **kwargs
        )
    
    @staticmethod
    def create_processing_engine(
        queue_provider: IQueueProducer,
        retry_strategy: str = "exponential",
        retry_config: dict[str, Any] | None = None,
        **kwargs
    ) -> ProcessingEngine:
        """
        Create processing engine with retry strategy.
        
        Args:
            queue_provider: Queue provider for retry operations
            retry_strategy: Retry strategy name
            retry_config: Retry strategy configuration
            **kwargs: Additional engine configuration
            
        Returns:
            Configured processing engine
        """
        retry_config = retry_config or {}
        retry_impl = RetryStrategyFactory.create(retry_strategy, **retry_config)
        
        return ProcessingEngine(
            queue_producer=queue_provider,
            retry_strategy=retry_impl,
            **kwargs
        )
    
    @staticmethod
    def create_queue_monitor(
        redis_client: redis.Redis,
        cache_ttl_seconds: int = 30
    ) -> RedisQueueMonitor:
        """
        Create queue monitor.
        
        Args:
            redis_client: Redis client for monitoring
            cache_ttl_seconds: Cache TTL for stats
            
        Returns:
            Configured queue monitor
        """
        return RedisQueueMonitor(
            redis_client=redis_client,
            cache_ttl_seconds=cache_ttl_seconds
        )
    
    @staticmethod
    def create_alert_manager(
        enable_console_alerts: bool = True
    ) -> SimpleAlertManager:
        """
        Create alert manager.
        
        Args:
            enable_console_alerts: Whether to enable console alerts
            
        Returns:
            Configured alert manager
        """
        return SimpleAlertManager(enable_console_alerts=enable_console_alerts)
    
    @staticmethod
    def create_metrics_collector(
        collector_type: str = "memory",
        config: dict[str, Any] | None = None
    ):
        """
        Create metrics collector.
        
        Args:
            collector_type: Type of collector (memory, redis)
            config: Collector configuration
            
        Returns:
            Configured metrics collector
        """
        config = config or {}
        config["type"] = collector_type
        return MetricsCollectorFactory.create_from_config(config)


class QueueSystemBuilder:
    """
    Builder for creating complete queue systems.
    
    Provides a fluent interface for building queue systems with
    all necessary components configured and connected.
    """
    
    def __init__(self) -> None:
        """Initialize queue system builder."""
        self.config: dict[str, Any] = {
            "redis_url": "redis://localhost:6379",
            "serializer_type": "json",
            "retry_strategy": "exponential",
            "retry_config": {},
            "monitoring_enabled": True,
            "alerts_enabled": True,
            "metrics_type": "memory",
            "metrics_config": {},
        }
        
        # Components
        self._queue_provider: RedisQueueProvider | None = None
        self._processing_engine: ProcessingEngine | None = None
        self._queue_monitor: RedisQueueMonitor | None = None
        self._alert_manager: SimpleAlertManager | None = None
        self._metrics_collector = None
        self._redis_client: redis.Redis | None = None
    
    def with_redis_config(
        self, 
        redis_url: str,
        serializer_type: str = "json",
        **provider_kwargs
    ) -> "QueueSystemBuilder":
        """Configure Redis connection."""
        self.config.update({
            "redis_url": redis_url,
            "serializer_type": serializer_type,
            "provider_kwargs": provider_kwargs,
        })
        return self
    
    def with_retry_strategy(
        self,
        strategy: str,
        **strategy_config
    ) -> "QueueSystemBuilder":
        """Configure retry strategy."""
        self.config.update({
            "retry_strategy": strategy,
            "retry_config": strategy_config,
        })
        return self
    
    def with_monitoring(
        self,
        enabled: bool = True,
        cache_ttl_seconds: int = 30
    ) -> "QueueSystemBuilder":
        """Configure monitoring."""
        self.config.update({
            "monitoring_enabled": enabled,
            "monitoring_cache_ttl": cache_ttl_seconds,
        })
        return self
    
    def with_alerts(
        self,
        enabled: bool = True,
        console_alerts: bool = True
    ) -> "QueueSystemBuilder":
        """Configure alerting."""
        self.config.update({
            "alerts_enabled": enabled,
            "console_alerts": console_alerts,
        })
        return self
    
    def with_metrics(
        self,
        collector_type: str = "memory",
        **metrics_config
    ) -> "QueueSystemBuilder":
        """Configure metrics collection."""
        self.config.update({
            "metrics_type": collector_type,
            "metrics_config": metrics_config,
        })
        return self
    
    async def build(self) -> "QueueSystem":
        """
        Build complete queue system.
        
        Returns:
            Configured queue system ready for use
        """
        # Create Redis client
        self._redis_client = redis.from_url(self.config["redis_url"])
        
        # Create queue provider
        provider_kwargs = self.config.get("provider_kwargs", {})
        self._queue_provider = QueueFactory.create_redis_provider(
            redis_url=self.config["redis_url"],
            serializer_type=self.config["serializer_type"],
            **provider_kwargs
        )
        
        # Create processing engine
        self._processing_engine = QueueFactory.create_processing_engine(
            queue_provider=self._queue_provider,
            retry_strategy=self.config["retry_strategy"],
            retry_config=self.config["retry_config"]
        )
        
        # Create monitoring components if enabled
        if self.config["monitoring_enabled"]:
            self._queue_monitor = QueueFactory.create_queue_monitor(
                redis_client=self._redis_client,
                cache_ttl_seconds=self.config.get("monitoring_cache_ttl", 30)
            )
        
        if self.config["alerts_enabled"]:
            self._alert_manager = QueueFactory.create_alert_manager(
                enable_console_alerts=self.config.get("console_alerts", True)
            )
        
        # Create metrics collector
        metrics_config = self.config["metrics_config"].copy()
        if self.config["metrics_type"] == "redis":
            metrics_config["redis_client"] = self._redis_client
        
        self._metrics_collector = QueueFactory.create_metrics_collector(
            collector_type=self.config["metrics_type"],
            config=metrics_config
        )
        
        # Register default processors
        await self._register_default_processors()
        
        # Create and return queue system
        return QueueSystem(
            queue_provider=self._queue_provider,
            processing_engine=self._processing_engine,
            queue_monitor=self._queue_monitor,
            alert_manager=self._alert_manager,
            metrics_collector=self._metrics_collector,
            redis_client=self._redis_client
        )
    
    async def _register_default_processors(self) -> None:
        """Register default message processors."""
        if not self._processing_engine:
            return
        
        # Register agent processors
        self._processing_engine.register_processor(
            AgentExecutionProcessor(gnosari_runner=None)  # Will be injected later
        )
        self._processing_engine.register_processor(
            AgentTrainingProcessor(learning_service=None)
        )
        self._processing_engine.register_processor(
            TeamOrchestrationProcessor(orchestration_service=None)
        )
        
        # Register knowledge processors
        self._processing_engine.register_processor(
            KnowledgeIndexingProcessor(knowledge_service=None)
        )
        self._processing_engine.register_processor(
            KnowledgeQueryProcessor(knowledge_service=None)
        )
        self._processing_engine.register_processor(
            KnowledgeMaintenanceProcessor(knowledge_service=None)
        )
        
        # Register system processors
        self._processing_engine.register_processor(
            SystemHealthCheckProcessor(monitoring_service=None)
        )
        self._processing_engine.register_processor(
            SystemMetricsProcessor(metrics_service=None)
        )
        self._processing_engine.register_processor(
            SystemCleanupProcessor(cleanup_service=None)
        )


class QueueSystem:
    """
    Complete queue system with all components integrated.
    
    Provides a unified interface to the entire queue system including
    message processing, monitoring, alerting, and metrics collection.
    """
    
    def __init__(
        self,
        queue_provider: RedisQueueProvider,
        processing_engine: ProcessingEngine,
        queue_monitor: RedisQueueMonitor | None = None,
        alert_manager: SimpleAlertManager | None = None,
        metrics_collector=None,
        redis_client: redis.Redis | None = None
    ) -> None:
        """
        Initialize queue system.
        
        Args:
            queue_provider: Queue provider implementation
            processing_engine: Message processing engine
            queue_monitor: Queue monitoring component
            alert_manager: Alert management component
            metrics_collector: Metrics collection component
            redis_client: Redis client
        """
        self.queue_provider = queue_provider
        self.processing_engine = processing_engine
        self.queue_monitor = queue_monitor
        self.alert_manager = alert_manager
        self.metrics_collector = metrics_collector
        self.redis_client = redis_client
    
    async def start(self) -> None:
        """Start the queue system."""
        # Connect queue provider
        await self.queue_provider.connect()
        
        # Create default queues
        await self._create_default_queues()
        
        print("Queue system started successfully")
    
    async def shutdown(self) -> None:
        """Shutdown the queue system gracefully."""
        # Shutdown processing engine
        if self.processing_engine:
            await self.processing_engine.shutdown()
        
        # Disconnect queue provider
        if self.queue_provider:
            await self.queue_provider.disconnect()
        
        # Close Redis client
        if self.redis_client:
            await self.redis_client.aclose()
        
        print("Queue system shutdown complete")
    
    async def publish_message(self, message, delay_seconds: int = 0) -> str:
        """Publish a message to the queue system."""
        return await self.queue_provider.publish(message, delay_seconds)
    
    async def start_consumer(self, queue_name: str, max_concurrent: int = 10) -> None:
        """Start consuming messages from a queue."""
        await self.queue_provider.consume(
            queue_name=queue_name,
            handler=self.processing_engine.process_message,
            max_concurrent=max_concurrent,
            auto_ack=False
        )
    
    async def get_system_stats(self) -> dict[str, Any]:
        """Get comprehensive system statistics."""
        stats = {}
        
        # Processing engine metrics
        if self.processing_engine:
            stats["processing"] = self.processing_engine.get_metrics()
        
        # Queue provider metrics
        if hasattr(self.queue_provider, 'get_metrics'):
            stats["queue_provider"] = self.queue_provider.get_metrics()
        
        # System health
        if self.queue_monitor:
            stats["system_health"] = await self.queue_monitor.get_system_health()
        
        return stats
    
    async def _create_default_queues(self) -> None:
        """Create default queues for the system."""
        default_queues = [
            "agent_execution_queue",
            "agent_training_queue",
            "team_orchestration_queue",
            "knowledge_indexing_queue",
            "knowledge_query_queue",
            "knowledge_maintenance_queue",
            "system_monitoring_queue",
            "system_metrics_queue",
            "system_maintenance_queue",
        ]
        
        for queue_name in default_queues:
            try:
                await self.queue_provider.create_queue(
                    name=queue_name,
                    durable=True,
                    max_priority=4
                )
            except Exception as e:
                print(f"Warning: Could not create queue {queue_name}: {e}")