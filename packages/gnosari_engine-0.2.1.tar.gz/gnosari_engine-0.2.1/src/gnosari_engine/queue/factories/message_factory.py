"""
Message factory for creating type-safe queue messages.
Implements Factory pattern with proper enum handling and validation.
"""

from typing import Type, TypeVar, Any, Dict
from abc import ABC, abstractmethod

from ..messages.base import BaseMessage, MessagePriority, MessageStatus
from ..messages.agent_messages import (
    AgentExecutionMessage,
    AgentExecutionPayload,
    AgentTrainingMessage,
    AgentTrainingPayload,
    TeamOrchestrationMessage,
    TeamOrchestrationPayload,
)

T = TypeVar('T', bound=BaseMessage)


class IMessageFactory(ABC):
    """Interface for message factories."""
    
    @abstractmethod
    def create_message(self, message_type: str, payload_data: Dict[str, Any], **kwargs) -> BaseMessage:
        """Create a message instance from payload data."""
        pass
    
    @abstractmethod
    def supports_message_type(self, message_type: str) -> bool:
        """Check if factory supports the given message type."""
        pass


class AgentMessageFactory(IMessageFactory):
    """Factory for creating agent-related messages."""
    
    _supported_types = {
        "agent.execution": (AgentExecutionMessage, AgentExecutionPayload),
        "agent.training": (AgentTrainingMessage, AgentTrainingPayload),
        "team.orchestration": (TeamOrchestrationMessage, TeamOrchestrationPayload),
    }
    
    def create_message(self, message_type: str, payload_data: Dict[str, Any], **kwargs) -> BaseMessage:
        """Create agent message from payload data."""
        if not self.supports_message_type(message_type):
            raise ValueError(f"Unsupported message type: {message_type}")
        
        message_class, payload_class = self._supported_types[message_type]
        
        # Create payload instance
        payload = payload_class.model_validate(payload_data)
        
        # Extract message-level options
        message_options = self._extract_message_options(kwargs)
        
        # Create message instance
        return message_class(payload=payload, **message_options)
    
    def supports_message_type(self, message_type: str) -> bool:
        """Check if factory supports the message type."""
        return message_type in self._supported_types
    
    def _extract_message_options(self, options: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and validate message-level options."""
        message_options = {}
        
        # Handle priority with proper enum conversion
        if 'priority' in options:
            priority_value = options['priority']
            if isinstance(priority_value, MessagePriority):
                message_options['priority'] = priority_value
            elif isinstance(priority_value, (int, str)):
                try:
                    message_options['priority'] = MessagePriority(priority_value)
                except (ValueError, TypeError) as e:
                    raise ValueError(f"Invalid priority value: {priority_value}") from e
        
        # Handle status with proper enum conversion
        if 'status' in options:
            status_value = options['status']
            if isinstance(status_value, MessageStatus):
                message_options['status'] = status_value
            elif isinstance(status_value, (int, str)):
                try:
                    message_options['status'] = MessageStatus(status_value)
                except (ValueError, TypeError) as e:
                    raise ValueError(f"Invalid status value: {status_value}") from e
        
        # Handle other message fields
        allowed_fields = {
            'max_attempts', 'timeout_seconds', 'scheduled_at', 'metadata'
        }
        
        for field in allowed_fields:
            if field in options:
                message_options[field] = options[field]
        
        return message_options


class MessageFactoryRegistry:
    """
    Registry for message factories.
    Implements Registry pattern for dynamic factory discovery.
    """
    
    def __init__(self):
        self._factories: Dict[str, IMessageFactory] = {}
        self._register_default_factories()
    
    def register_factory(self, factory: IMessageFactory) -> None:
        """Register a message factory."""
        # Register factory for all supported message types
        for message_type in self._get_factory_supported_types(factory):
            self._factories[message_type] = factory
    
    def create_message(self, message_type: str, payload_data: Dict[str, Any], **kwargs) -> BaseMessage:
        """Create message using appropriate factory."""
        if message_type not in self._factories:
            raise ValueError(f"No factory registered for message type: {message_type}")
        
        factory = self._factories[message_type]
        return factory.create_message(message_type, payload_data, **kwargs)
    
    def get_supported_types(self) -> set[str]:
        """Get all supported message types."""
        return set(self._factories.keys())
    
    def _register_default_factories(self) -> None:
        """Register default built-in factories."""
        agent_factory = AgentMessageFactory()
        self.register_factory(agent_factory)
    
    def _get_factory_supported_types(self, factory: IMessageFactory) -> list[str]:
        """Get all message types supported by a factory."""
        # This is a simple implementation that checks the factory's supported types
        if hasattr(factory, '_supported_types'):
            return list(factory._supported_types.keys())
        
        # For custom factories, we would need a different approach
        # This could be extended with introspection or explicit registration
        return []


class TypeSafeMessageBuilder:
    """
    Builder for creating type-safe messages with validation.
    Implements Builder pattern for complex message construction.
    """
    
    def __init__(self, factory_registry: MessageFactoryRegistry):
        self._factory_registry = factory_registry
        self._message_type: str | None = None
        self._payload_data: Dict[str, Any] = {}
        self._options: Dict[str, Any] = {}
    
    def with_type(self, message_type: str) -> "TypeSafeMessageBuilder":
        """Set the message type."""
        self._message_type = message_type
        return self
    
    def with_payload(self, **payload_data) -> "TypeSafeMessageBuilder":
        """Set payload data."""
        self._payload_data.update(payload_data)
        return self
    
    def with_priority(self, priority: MessagePriority | int | str) -> "TypeSafeMessageBuilder":
        """Set message priority."""
        self._options['priority'] = priority
        return self
    
    def with_max_attempts(self, max_attempts: int) -> "TypeSafeMessageBuilder":
        """Set maximum retry attempts."""
        self._options['max_attempts'] = max_attempts
        return self
    
    def with_timeout(self, timeout_seconds: int) -> "TypeSafeMessageBuilder":
        """Set processing timeout."""
        self._options['timeout_seconds'] = timeout_seconds
        return self
    
    def with_metadata(self, **metadata) -> "TypeSafeMessageBuilder":
        """Add metadata."""
        if 'metadata' not in self._options:
            self._options['metadata'] = {}
        self._options['metadata'].update(metadata)
        return self
    
    def build(self) -> BaseMessage:
        """Build the message instance."""
        if not self._message_type:
            raise ValueError("Message type must be specified")
        
        if not self._payload_data:
            raise ValueError("Payload data must be provided")
        
        return self._factory_registry.create_message(
            self._message_type,
            self._payload_data,
            **self._options
        )
    
    def reset(self) -> "TypeSafeMessageBuilder":
        """Reset builder to initial state."""
        self._message_type = None
        self._payload_data = {}
        self._options = {}
        return self


# Global factory registry instance
_global_factory_registry = MessageFactoryRegistry()


def get_message_factory_registry() -> MessageFactoryRegistry:
    """Get the global message factory registry."""
    return _global_factory_registry


def create_message_builder() -> TypeSafeMessageBuilder:
    """Create a new message builder instance."""
    return TypeSafeMessageBuilder(_global_factory_registry)