"""
Factory for creating and configuring message processors.
Provides dependency injection and configuration management for processors.
"""

from typing import Any

from ..interfaces.message_interfaces import IMessageProcessor
from ..processors.agent_processors import (
    AgentExecutionProcessor,
    AgentTrainingProcessor,
    TeamOrchestrationProcessor,
)
from ..processors.knowledge_processors import (
    KnowledgeIndexingProcessor,
    KnowledgeMaintenanceProcessor,
    KnowledgeQueryProcessor,
)
from ..processors.system_processors import (
    SystemCleanupProcessor,
    SystemHealthCheckProcessor,
    SystemMetricsProcessor,
)


class ProcessorFactory:
    """
    Factory for creating message processors with dependency injection.
    
    Allows creation of processors with proper service dependencies
    and configuration.
    """
    
    def __init__(self) -> None:
        """Initialize processor factory."""
        self._services: dict[str, Any] = {}
        self._processor_configs: dict[str, dict[str, Any]] = {}
    
    def register_service(self, service_name: str, service_instance: Any) -> None:
        """
        Register a service for dependency injection.
        
        Args:
            service_name: Name of the service
            service_instance: Service instance
        """
        self._services[service_name] = service_instance
    
    def configure_processor(
        self, 
        processor_type: str, 
        config: dict[str, Any]
    ) -> None:
        """
        Configure processor settings.
        
        Args:
            processor_type: Type of processor
            config: Configuration dictionary
        """
        self._processor_configs[processor_type] = config
    
    def create_agent_execution_processor(self) -> AgentExecutionProcessor:
        """Create agent execution processor with dependencies."""
        gnosari_runner = self._services.get("gnosari_runner")
        return AgentExecutionProcessor(gnosari_runner=gnosari_runner)
    
    def create_agent_training_processor(self) -> AgentTrainingProcessor:
        """Create agent training processor with dependencies."""
        learning_service = self._services.get("learning_service")
        return AgentTrainingProcessor(learning_service=learning_service)
    
    def create_team_orchestration_processor(self) -> TeamOrchestrationProcessor:
        """Create team orchestration processor with dependencies."""
        orchestration_service = self._services.get("orchestration_service")
        return TeamOrchestrationProcessor(orchestration_service=orchestration_service)
    
    def create_knowledge_indexing_processor(self) -> KnowledgeIndexingProcessor:
        """Create knowledge indexing processor with dependencies."""
        knowledge_service = self._services.get("knowledge_service")
        return KnowledgeIndexingProcessor(knowledge_service=knowledge_service)
    
    def create_knowledge_query_processor(self) -> KnowledgeQueryProcessor:
        """Create knowledge query processor with dependencies."""
        knowledge_service = self._services.get("knowledge_service")
        return KnowledgeQueryProcessor(knowledge_service=knowledge_service)
    
    def create_knowledge_maintenance_processor(self) -> KnowledgeMaintenanceProcessor:
        """Create knowledge maintenance processor with dependencies."""
        knowledge_service = self._services.get("knowledge_service")
        return KnowledgeMaintenanceProcessor(knowledge_service=knowledge_service)
    
    def create_system_health_check_processor(self) -> SystemHealthCheckProcessor:
        """Create system health check processor with dependencies."""
        monitoring_service = self._services.get("monitoring_service")
        return SystemHealthCheckProcessor(monitoring_service=monitoring_service)
    
    def create_system_metrics_processor(self) -> SystemMetricsProcessor:
        """Create system metrics processor with dependencies."""
        metrics_service = self._services.get("metrics_service")
        return SystemMetricsProcessor(metrics_service=metrics_service)
    
    def create_system_cleanup_processor(self) -> SystemCleanupProcessor:
        """Create system cleanup processor with dependencies."""
        cleanup_service = self._services.get("cleanup_service")
        return SystemCleanupProcessor(cleanup_service=cleanup_service)
    
    def create_all_processors(self) -> list[IMessageProcessor]:
        """
        Create all available processors.
        
        Returns:
            List of all configured processors
        """
        processors = [
            self.create_agent_execution_processor(),
            self.create_agent_training_processor(),
            self.create_team_orchestration_processor(),
            self.create_knowledge_indexing_processor(),
            self.create_knowledge_query_processor(),
            self.create_knowledge_maintenance_processor(),
            self.create_system_health_check_processor(),
            self.create_system_metrics_processor(),
            self.create_system_cleanup_processor(),
        ]
        
        return processors
    
    def create_processor_by_type(self, processor_type: str) -> IMessageProcessor:
        """
        Create processor by type name.
        
        Args:
            processor_type: Type of processor to create
            
        Returns:
            Configured processor instance
            
        Raises:
            ValueError: If processor type is unknown
        """
        processor_map = {
            "agent_execution": self.create_agent_execution_processor,
            "agent_training": self.create_agent_training_processor,
            "team_orchestration": self.create_team_orchestration_processor,
            "knowledge_indexing": self.create_knowledge_indexing_processor,
            "knowledge_query": self.create_knowledge_query_processor,
            "knowledge_maintenance": self.create_knowledge_maintenance_processor,
            "system_health_check": self.create_system_health_check_processor,
            "system_metrics": self.create_system_metrics_processor,
            "system_cleanup": self.create_system_cleanup_processor,
        }
        
        if processor_type not in processor_map:
            raise ValueError(f"Unknown processor type: {processor_type}")
        
        return processor_map[processor_type]()
    
    def get_registered_services(self) -> list[str]:
        """Get list of registered service names."""
        return list(self._services.keys())
    
    def get_processor_config(self, processor_type: str) -> dict[str, Any]:
        """Get configuration for a processor type."""
        return self._processor_configs.get(processor_type, {})