"""
CLI Services - SOLID implementation of CLI business logic
"""

import uuid
from pathlib import Path
from typing import Optional, Any, Dict

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn

from .interfaces import (
    ConfigurationLoaderInterface,
    ExecutionServiceInterface,
    DisplayServiceInterface,
    SessionManagerInterface,
    DomainFactoryInterface
)
from .event_display import EventDisplayService
from ..factories import ConfigurationServiceFactory
from ..factories.domain_object_factory import DomainObjectFactory
from ..schemas.domain import Team, AgentRun
from ..schemas.domain.execution import ExecutionContext
from ..runners.factory import create_enterprise_runner
from ..sessions.gnosari_session import GnosariSession


class ConfigurationLoader(ConfigurationLoaderInterface):
    """Handles team configuration loading with error handling"""
    
    def __init__(self):
        config_factory = ConfigurationServiceFactory()
        self._config_service = config_factory.create()
    
    def load_team_configuration(self, config_path: Path) -> Team:
        """Load team configuration from file"""
        return self._config_service.load_team_configuration(config_path)


class ExecutionService(ExecutionServiceInterface):
    """Handles execution orchestration for teams and agents"""
    
    def __init__(self):
        self._event_display = EventDisplayService()
    
    
    async def execute_agent(
        self, 
        agent_run: AgentRun, 
        provider: str,
        database_url: Optional[str] = None,
        stream: bool = True,
        debug: bool = False,
    ) -> str:
        """Execute a single agent with advanced event display"""
        # Use session_id from agent_run.metadata if available, otherwise generate one
        session_id = agent_run.metadata.session_id or f"agent-{agent_run.agent.id}-{uuid.uuid4().hex[:8]}"
        agent_run.metadata.session_id = session_id  # Ensure it's set
        
        session_manager = GnosariSession(
            session_id=session_id,
            provider_name=f"{provider}_database",
            agent_run=agent_run,  # Pass AgentRun directly
            database_url=database_url
        )
        
        runner = create_enterprise_runner(provider, agent_run.context)
        
        try:
            await runner.initialize()
            
            if stream:
                final_result = None
                
                # Use live event display system
                with self._event_display.live_event_display(debug=debug):
                    async for event in runner.run_agent_stream(agent_run):
                        # Handle the event through the display service
                        self._event_display.handle_event(event, debug=debug)
                        
                        # Check for completion events and break to end execution
                        if event.event_type == "agent_completed":
                            data = event.data
                            if hasattr(data, 'to_dict'):
                                data = data.to_dict()
                            final_result = data.get("output", "Agent execution completed")
                            break
                        elif event.event_type == "agent_error":
                            data = event.data
                            if hasattr(data, 'to_dict'):
                                data = data.to_dict()
                            final_result = f"Agent error: {data.get('error', 'Unknown error')}"
                            break
                
                # Display execution summary
                if not debug:
                    self._event_display.display_summary()
                
                return final_result or f"Agent {agent_run.agent.name} completed processing"
            else:
                return await runner.run_agent(agent_run)
                
        finally:
            await runner.cleanup()
            await session_manager.cleanup()


class DisplayService(DisplayServiceInterface):
    """Handles all display and formatting concerns"""
    
    def __init__(self):
        self.console = Console()
    
    def display_header(self) -> None:
        return
        """Display the CLI header with ASCII art"""
        header = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║     ██████╗ ███╗   ██╗ ██████╗ ███████╗ █████╗ ██████╗ ██╗   ║
    ║    ██╔════╝ ████╗  ██║██╔═══██╗██╔════╝██╔══██╗██╔══██╗██║   ║
    ║    ██║  ███╗██╔██╗ ██║██║   ██║███████╗███████║██████╔╝██║   ║
    ║    ██║   ██║██║╚██╗██║██║   ██║╚════██║██╔══██║██╔══██╗██║   ║
    ║    ╚██████╔╝██║ ╚████║╚██████╔╝███████║██║  ██║██║  ██║██║   ║
    ║     ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ║
    ║                                                              ║
    ║                 🚀 AI Agent Team Orchestration               ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
        """
        
        text = Text(header, style="bold cyan")
        self.console.print(text, justify="center")
    
    def display_execution_details(
        self, 
        team: Team, 
        provider: str, 
        execution_mode: str,
        session_id: Optional[str] = None
    ) -> None:
        """Display execution details panel"""
        details = (
            f"[bold cyan]Team:[/bold cyan] {team.name}\n"
            f"[bold cyan]Agents:[/bold cyan] {len(team.agents)}\n"
            f"[bold cyan]Provider:[/bold cyan] {provider}\n"
            f"[bold cyan]Mode:[/bold cyan] {execution_mode}"
        )
        
        if session_id:
            details += f"\n[bold cyan]Session:[/bold cyan] {session_id}"
        
        self.console.print(Panel.fit(
            details,
            title="🎯 Execution Details",
            border_style="cyan"
        ))
    
    def display_status(self, message: str, status_type: str = "info") -> None:
        """Display status messages"""
        color_map = {
            "info": "blue",
            "success": "green",
            "warning": "yellow",
            "error": "red"
        }
        color = color_map.get(status_type, "blue")
        self.console.print(f"[{color}]{message}[/{color}]")
    
    def display_streaming_output(self, content: str) -> None:
        """Display streaming content"""
        self.console.print(content, end="")
    
    def display_final_result(self, result: str) -> None:
        """Display final execution result"""
        self.console.print(f"\n[bold green]Final Result:[/bold green] {result}")
    
    def show_loading(self, message: str):
        """Create a loading context manager"""
        return self.console.status(f"[bold blue]{message}[/bold blue]", spinner="dots")
    
    def show_progress(self, description: str):
        """Create a progress context manager"""
        return Progress(
            SpinnerColumn(),
            TextColumn(f"[progress.description]{description}"),
            console=self.console
        )


class SessionManager(SessionManagerInterface):
    """Handles session management concerns"""
    
    def generate_session_id(self) -> str:
        """Generate a new session ID"""
        return f"session-{uuid.uuid4().hex[:8]}"
    


class DomainFactory(DomainFactoryInterface):
    """Handles domain object creation"""
    
    def __init__(self):
        self._domain_factory = DomainObjectFactory()
    
    
    def create_agent_run(
        self, 
        team: Team, 
        agent_id: str, 
        message: str, 
        stream: bool = True, 
        debug: bool = False,
        tool_streaming: bool = True,
        stream_merger: str = "time_ordered"
    ) -> AgentRun:
        """Create agent execution context"""
        agent = team.get_agent_by_id(agent_id) or team.get_agent_by_name(agent_id)
        if not agent:
            raise ValueError(f"Agent '{agent_id}' not found in team configuration")
        
        execution_context = ExecutionContext(
            stream=stream, 
            debug=debug,
            tool_streaming=tool_streaming,
            tool_streaming_merger=stream_merger
        )
        return self._domain_factory.create_agent_run(agent, team, message, execution_context)