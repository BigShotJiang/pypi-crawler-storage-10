"""
Knowledge Command - Handles knowledge base loading and management operations
"""

import asyncio
import sys
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from .base_command import BaseCommand
from ..interfaces import (
    ConfigurationLoaderInterface,
    DisplayServiceInterface,
    DomainFactoryInterface
)
from ..logging_config import LoggingConfigurator
from ...knowledge.services import KnowledgeLoaderService, KnowledgeLoadError, ProgressCallback
from ...knowledge.components import LoadingProgress


class KnowledgeCommand(BaseCommand):
    """
    Single Responsibility: Handle knowledge base operations (load, status, etc.)
    Open/Closed: Easy to extend with new knowledge operations
    Dependency Inversion: Depends on abstractions, not concretions
    """
    
    def __init__(
        self,
        config_loader: ConfigurationLoaderInterface,
        display_service: DisplayServiceInterface,
        domain_factory: DomainFactoryInterface,
        logging_configurator: LoggingConfigurator,
        knowledge_loader_service: Optional[KnowledgeLoaderService] = None
    ):
        super().__init__(display_service)
        self._config_loader = config_loader
        self._domain_factory = domain_factory
        self._logging_configurator = logging_configurator
        self._knowledge_loader_service = knowledge_loader_service or KnowledgeLoaderService()
    
    async def execute(self, *args, **kwargs) -> None:
        """Base execute method - subcommands will override this"""
        raise NotImplementedError("Use specific subcommand methods like load()")
    
    async def load(
        self,
        team_config: Path,
        agent_id: Optional[str] = None,
        provider: str = "opensearch",
        force_reload: bool = False,
        debug: bool = False,
        verbose: bool = False,
        log_level: Optional[str] = None,
        log_file: Optional[str] = None,
        structured_logs: bool = False
    ) -> None:
        """Load knowledge sources for a team or specific agent"""
        
        operation = f"knowledge load for {'agent ' + agent_id if agent_id else 'all agents'}"
        self._log_execution_start(operation)
        
        try:
            # Configure logging first
            self._configure_logging(
                log_level, debug, verbose, log_file, structured_logs
            )
            
            self._display_service.display_header()
            self._display_service.display_status(
                f"🧠 Loading knowledge sources from: {team_config}", 
                "info"
            )
            
            # Create progress callback for display updates
            def progress_callback(progress: LoadingProgress) -> None:
                if verbose:
                    self._display_service.display_status(
                        f"Progress: {progress.progress_percentage:.1f}% - {progress.current_source}", 
                        "info"
                    )
            
            # Use the knowledge loader service
            result = await self._knowledge_loader_service.load_from_team_config(
                team_config_path=team_config,
                agent_id=agent_id,
                provider=provider,
                force_reload=force_reload,
                progress_callback=progress_callback if verbose else None
            )
            
            # Display results
            if result.success:
                self._display_service.display_status(
                    f"✅ Successfully loaded {result.total_documents} documents "
                    f"into {result.total_knowledge_bases} knowledge bases "
                    f"for {result.total_agents} agents", 
                    "success"
                )
            else:
                self._display_service.display_status(
                    f"⚠️ Partially loaded {result.total_documents} documents "
                    f"with {len(result.errors)} errors", 
                    "warning"
                )
            
            # Display errors if any
            if result.errors and verbose:
                for error in result.errors:
                    self._display_service.display_status(f"  ✗ {error}", "error")
            
            self._log_execution_end(operation)
            
        except KnowledgeLoadError as e:
            self._handle_error(e, operation)
            if verbose:
                import traceback
                self._display_service.display_status(traceback.format_exc(), "error")
            sys.exit(1)
        except Exception as e:
            self._handle_error(e, operation)
            if verbose:
                import traceback
                self._display_service.display_status(traceback.format_exc(), "error")
            sys.exit(1)
    
    def _configure_logging(
        self, 
        log_level: Optional[str],
        debug: bool,
        verbose: bool,
        log_file: Optional[str],
        structured_logs: bool
    ) -> None:
        """Configure logging with provided parameters"""
        self._logging_configurator.configure_from_cli_args(
            log_level=log_level,
            debug=debug,
            verbose=verbose,
            log_file=log_file,
            structured_logs=structured_logs,
            session_id=None  # Not applicable for knowledge loading
        )