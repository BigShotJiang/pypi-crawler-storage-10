"""
Queue management CLI commands.
Provides commands for managing the queue system including status, monitoring, and operations.
"""

import asyncio
import json
from typing import Any

import click
from rich.console import Console
from rich.table import Table
from rich.text import Text

from ...queue.factories.queue_factory import QueueSystemBuilder
from ...queue.messages.agent_messages import AgentExecutionMessage, AgentExecutionPayload
from ...queue.messages.system_messages import SystemHealthCheckMessage, SystemHealthCheckPayload


class QueueCommand:
    """Queue management command implementation."""
    
    def __init__(self) -> None:
        """Initialize queue command."""
        self.console = Console()
        self.queue_system = None
    
    async def _get_queue_system(self, redis_url: str = "redis://localhost:6379"):
        """Get or create queue system instance."""
        if not self.queue_system:
            builder = QueueSystemBuilder()
            self.queue_system = await builder.with_redis_config(redis_url).build()
            await self.queue_system.start()
        return self.queue_system
    
    async def status(self, redis_url: str, detailed: bool = False) -> None:
        """Get queue system status."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            # Get system statistics
            stats = await queue_system.get_system_stats()
            
            if detailed:
                self._display_detailed_status(stats)
            else:
                self._display_basic_status(stats)
            
        except Exception as e:
            self.console.print(f"[red]Error getting queue status: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def list_queues(self, redis_url: str) -> None:
        """List all queues in the system."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            # Get list of queues
            queues = await queue_system.queue_provider.list_queues()
            
            if not queues:
                self.console.print("[yellow]No queues found[/yellow]")
                return
            
            # Create table
            table = Table(title="Queue List")
            table.add_column("Queue Name", style="cyan")
            table.add_column("Status", style="green")
            table.add_column("Messages", justify="right")
            
            # Get stats for each queue
            for queue_name in queues:
                try:
                    if queue_system.queue_monitor:
                        queue_stats = await queue_system.queue_monitor.get_queue_stats(queue_name)
                        message_count = queue_stats.get("queue_length", 0)
                        status = "Active" if message_count > 0 else "Empty"
                    else:
                        message_count = "N/A"
                        status = "Unknown"
                    
                    table.add_row(queue_name, status, str(message_count))
                except Exception:
                    table.add_row(queue_name, "Error", "N/A")
            
            self.console.print(table)
            
        except Exception as e:
            self.console.print(f"[red]Error listing queues: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def queue_stats(self, redis_url: str, queue_name: str) -> None:
        """Get detailed statistics for a specific queue."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            if not queue_system.queue_monitor:
                self.console.print("[red]Queue monitoring not available[/red]")
                return
            
            # Get queue statistics
            stats = await queue_system.queue_monitor.get_queue_stats(queue_name)
            
            # Create detailed stats table
            table = Table(title=f"Queue Statistics: {queue_name}")
            table.add_column("Metric", style="cyan")
            table.add_column("Value", style="green")
            
            table.add_row("Queue Length", str(stats.get("queue_length", 0)))
            table.add_row("Priority Messages", str(stats.get("priority_length", 0)))
            table.add_row("Delayed Messages", str(stats.get("delayed_count", 0)))
            table.add_row("Dead Letter Messages", str(stats.get("dead_letter_count", 0)))
            table.add_row("Processing Count", str(stats.get("processing_count", 0)))
            table.add_row("Throughput/min", str(stats.get("throughput_per_minute", 0)))
            table.add_row("Error Rate %", str(stats.get("error_rate", 0)))
            table.add_row("Last Updated", str(stats.get("last_updated", "N/A")))
            
            self.console.print(table)
            
        except Exception as e:
            self.console.print(f"[red]Error getting queue stats: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def send_test_message(self, redis_url: str, message_type: str, **kwargs) -> None:
        """Send a test message to the queue system."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            # Create test message based on type
            if message_type == "agent_execution":
                payload = AgentExecutionPayload(
                    team_id=kwargs.get("team_id", "test_team"),
                    agent_id=kwargs.get("agent_id", "test_agent"),
                    message=kwargs.get("message", "Test message"),
                    context=kwargs.get("context", {})
                )
                test_message = AgentExecutionMessage(payload=payload)
            
            elif message_type == "health_check":
                payload = SystemHealthCheckPayload(
                    component=kwargs.get("component", "queue"),
                    check_type=kwargs.get("check_type", "basic")
                )
                test_message = SystemHealthCheckMessage(payload=payload)
            
            else:
                raise ValueError(f"Unknown message type: {message_type}")
            
            # Send message
            message_id = await queue_system.publish_message(test_message)
            
            self.console.print(f"[green]Test message sent successfully[/green]")
            self.console.print(f"Message ID: {message_id}")
            self.console.print(f"Message Type: {test_message.type}")
            self.console.print(f"Queue: {test_message.get_queue_name()}")
            
        except Exception as e:
            self.console.print(f"[red]Error sending test message: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def start_worker(self, redis_url: str, queue_name: str, max_concurrent: int = 5) -> None:
        """Start a queue worker for processing messages."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            self.console.print(f"[green]Starting worker for queue: {queue_name}[/green]")
            self.console.print(f"Max concurrent: {max_concurrent}")
            self.console.print("Press Ctrl+C to stop...")
            
            # Start consumer (this will run indefinitely)
            await queue_system.start_consumer(
                queue_name=queue_name,
                max_concurrent=max_concurrent
            )
            
        except KeyboardInterrupt:
            self.console.print("\n[yellow]Worker stopped by user[/yellow]")
        except Exception as e:
            self.console.print(f"[red]Error starting worker: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def purge_queue(self, redis_url: str, queue_name: str, confirm: bool = False) -> None:
        """Purge all messages from a queue."""
        try:
            if not confirm:
                response = click.confirm(
                    f"Are you sure you want to purge all messages from queue '{queue_name}'?"
                )
                if not response:
                    self.console.print("[yellow]Operation cancelled[/yellow]")
                    return
            
            queue_system = await self._get_queue_system(redis_url)
            
            # Purge queue
            purged_count = await queue_system.queue_provider.purge_queue(queue_name)
            
            self.console.print(f"[green]Purged {purged_count} messages from queue '{queue_name}'[/green]")
            
        except Exception as e:
            self.console.print(f"[red]Error purging queue: {e}[/red]")
            raise click.ClickException(str(e))
    
    async def monitor_system(self, redis_url: str, refresh_interval: int = 5) -> None:
        """Monitor queue system in real-time."""
        try:
            queue_system = await self._get_queue_system(redis_url)
            
            if not queue_system.queue_monitor:
                self.console.print("[red]Queue monitoring not available[/red]")
                return
            
            self.console.print(f"[green]Monitoring queue system (refresh every {refresh_interval}s)[/green]")
            self.console.print("Press Ctrl+C to stop...")
            
            while True:
                try:
                    # Clear screen and show stats
                    self.console.clear()
                    
                    # Get system health
                    health = await queue_system.queue_monitor.get_system_health()
                    
                    # Display health status
                    status_color = self._get_status_color(health.get("overall_status", "unknown"))
                    self.console.print(f"System Status: [{status_color}]{health.get('overall_status', 'unknown').upper()}[/{status_color}]")
                    self.console.print(f"Timestamp: {health.get('timestamp', 'N/A')}")
                    
                    # Display summary
                    summary = health.get("summary", {})
                    self.console.print(f"Total Queues: {summary.get('total_queues', 0)}")
                    self.console.print(f"Total Messages: {summary.get('total_messages', 0)}")
                    self.console.print(f"Error Rate: {summary.get('error_rate', 0):.2f}%")
                    
                    # Display component status
                    components = health.get("components", {})
                    if components:
                        self.console.print("\nComponent Status:")
                        for component, status in components.items():
                            comp_status = status.get("status", "unknown")
                            color = self._get_status_color(comp_status)
                            self.console.print(f"  {component}: [{color}]{comp_status}[/{color}]")
                    
                    await asyncio.sleep(refresh_interval)
                    
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    self.console.print(f"[red]Monitoring error: {e}[/red]")
                    await asyncio.sleep(refresh_interval)
            
            self.console.print("\n[yellow]Monitoring stopped[/yellow]")
            
        except KeyboardInterrupt:
            self.console.print("\n[yellow]Monitoring stopped by user[/yellow]")
        except Exception as e:
            self.console.print(f"[red]Error starting monitor: {e}[/red]")
            raise click.ClickException(str(e))
    
    def _display_basic_status(self, stats: dict[str, Any]) -> None:
        """Display basic system status."""
        processing_stats = stats.get("processing", {})
        
        table = Table(title="Queue System Status")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Messages Processed", str(processing_stats.get("messages_processed", 0)))
        table.add_row("Messages Succeeded", str(processing_stats.get("messages_succeeded", 0)))
        table.add_row("Messages Failed", str(processing_stats.get("messages_failed", 0)))
        table.add_row("Messages Retried", str(processing_stats.get("messages_retried", 0)))
        table.add_row("Avg Processing Time", f"{processing_stats.get('average_processing_time', 0):.2f}ms")
        
        self.console.print(table)
    
    def _display_detailed_status(self, stats: dict[str, Any]) -> None:
        """Display detailed system status."""
        # Basic status first
        self._display_basic_status(stats)
        
        # Processor metrics
        processing_stats = stats.get("processing", {})
        processor_metrics = processing_stats.get("processor_metrics", {})
        
        if processor_metrics:
            self.console.print("\n")
            
            proc_table = Table(title="Processor Metrics")
            proc_table.add_column("Processor", style="cyan")
            proc_table.add_column("Processed", justify="right")
            proc_table.add_column("Succeeded", justify="right", style="green")
            proc_table.add_column("Failed", justify="right", style="red")
            proc_table.add_column("Avg Time (ms)", justify="right")
            
            for processor_name, metrics in processor_metrics.items():
                proc_table.add_row(
                    processor_name,
                    str(metrics.get("processed", 0)),
                    str(metrics.get("succeeded", 0)),
                    str(metrics.get("failed", 0)),
                    f"{metrics.get('average_time', 0):.2f}"
                )
            
            self.console.print(proc_table)
        
        # System health
        system_health = stats.get("system_health", {})
        if system_health:
            self.console.print("\n")
            
            overall_status = system_health.get("overall_status", "unknown")
            status_color = self._get_status_color(overall_status)
            
            self.console.print(f"System Health: [{status_color}]{overall_status.upper()}[/{status_color}]")
            
            # Component health
            components = system_health.get("components", {})
            if components:
                for component, status in components.items():
                    comp_status = status.get("status", "unknown")
                    color = self._get_status_color(comp_status)
                    self.console.print(f"  {component}: [{color}]{comp_status}[/{color}]")
    
    def _get_status_color(self, status: str) -> str:
        """Get color for status display."""
        status_colors = {
            "healthy": "green",
            "degraded": "yellow",
            "unhealthy": "red",
            "unknown": "gray",
            "active": "green",
            "empty": "blue",
            "error": "red",
        }
        return status_colors.get(status.lower(), "white")
    
    async def cleanup(self) -> None:
        """Cleanup resources."""
        if self.queue_system:
            await self.queue_system.shutdown()