"""
Enhanced Gnosari Runner with tool streaming support.

Extends the base GnosariRunner to add enterprise-grade tool streaming
capabilities following SOLID principles.
"""

import asyncio
import logging
from collections.abc import AsyncGenerator

from ..schemas.domain.execution import AgentRun
from ..tools.streaming.context import NullToolStreamContext, ToolStreamManager
from ..tools.streaming.interfaces import IStreamableTool, IToolStreamContext
from ..tools.streaming.merger import StreamEventMerger, TimeOrderedStreamMerger
from .gnosari_runner import GnosariRunner
from .interfaces import ExecutionResult, StreamEvent

logger = logging.getLogger(__name__)


class StreamingEnhancedGnosariRunner(GnosariRunner):
    """
    Enhanced Gnosari Runner with tool streaming support.
    
    Follows Open/Closed Principle: Extends GnosariRunner without modifying it.
    Follows Single Responsibility Principle: Adds only streaming capabilities.
    """
    
    def __init__(
        self,
        provider_name: str | None = None,
        provider=None,
        provider_factory=None,
        enable_tool_streaming: bool = True,
        stream_merger_type: str = "time_ordered",
        **provider_config
    ):
        super().__init__(provider_name, provider, provider_factory, **provider_config)
        
        self._enable_tool_streaming = enable_tool_streaming
        self._stream_merger_type = stream_merger_type
        self._tool_stream_manager: ToolStreamManager | None = None
        
        logger.debug(f"StreamingEnhancedGnosariRunner initialized with tool streaming: {enable_tool_streaming}")
    
    async def initialize(self) -> None:
        """Initialize the runner and streaming components."""
        await super().initialize()
        
        if self._enable_tool_streaming:
            self._tool_stream_manager = ToolStreamManager()
            logger.debug("Tool stream manager initialized")
    
    async def cleanup(self) -> None:
        """Cleanup runner and streaming resources."""
        if self._tool_stream_manager:
            await self._tool_stream_manager.cleanup()
            self._tool_stream_manager = None
            logger.debug("Tool stream manager cleaned up")
        
        await super().cleanup()
    
    async def run_agent(self, agent_run: AgentRun) -> ExecutionResult:
        """Execute agent synchronously (no streaming)."""
        await self._ensure_initialized()
        
        # For non-streaming execution, inject null context to prevent tool streaming
        agent_run.set_tool_stream_context(NullToolStreamContext())
        
        # Inject streaming context into tools
        await self._inject_tool_contexts(agent_run)
        
        return await super().run_agent(agent_run)
    
    async def run_agent_stream(
        self, agent_run: AgentRun
    ) -> AsyncGenerator[StreamEvent, None]:
        """Execute agent with enhanced tool streaming."""
        await self._ensure_initialized()

        if not self._enable_tool_streaming or not self._tool_stream_manager:
            # Fall back to standard streaming if tool streaming is disabled
            async for event in super().run_agent_stream(agent_run):
                yield event
            return
        
        try:
            # Create tool streaming context
            tool_stream_context = await self._tool_stream_manager.create_stream_context()
            agent_run.set_tool_stream_context(tool_stream_context)
            
            # Inject streaming context into tools
            await self._inject_tool_contexts(agent_run)
            
            # Initialize knowledge bases if any are defined in the team
            if agent_run.team.knowledge:
                await self._initialize_knowledge_bases(agent_run.team.knowledge)
            
            # Get both streams
            agent_stream = self._get_agent_stream(agent_run)
            tool_stream = self._tool_stream_manager.collect_events()
            
            # Merge streams and yield unified events
            merger = self._create_stream_merger()
            async for event in merger.merge_streams(agent_stream, tool_stream):
                # Enrich events if context enricher is available
                if self._context_enricher:
                    enriched_event = self._context_enricher.enrich_event(event)
                    yield enriched_event
                else:
                    yield event
                    
        except Exception as e:
            import traceback
            logger.error(f"Error in enhanced streaming: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            # Emit error event
            if self._context_enricher:
                yield self._context_enricher.create_error_event(e)
            else:
                yield StreamEvent("execution_error", {"error": str(e), "error_type": type(e).__name__})
    
    async def _get_agent_stream(self, agent_run: AgentRun) -> AsyncGenerator[StreamEvent, None]:
        """Get the base agent stream."""
        try:
            # Call the parent's stream method directly
            stream = self._initializer.provider.run_agent_stream(agent_run)
            async for event in stream:
                yield event
        except Exception as e:
            logger.error(f"Error in agent stream: {e}")
            yield StreamEvent("agent_error", {"error": str(e)})
    
    async def _inject_tool_contexts(self, agent_run: AgentRun) -> None:
        """Inject streaming context into streamable tools."""
        if not agent_run.has_tool_streaming():
            return
        
        context = agent_run.get_tool_stream_context()
        tools_configured = 0
        
        try:
            # Get tools from team configuration
            for tool_config in agent_run.team.tools:
                tool_instance = await self._get_tool_instance(tool_config, agent_run)
                
                if tool_instance and isinstance(tool_instance, IStreamableTool):
                    if tool_instance.supports_streaming():
                        tool_instance.set_stream_context(context)
                        tools_configured += 1
                        logger.debug(f"Configured streaming for tool: {tool_config.name}")
            
            logger.info(f"Configured streaming for {tools_configured} tools")
            
        except Exception as e:
            logger.error(f"Error injecting tool contexts: {e}")
    
    async def _get_tool_instance(self, tool_config, agent_run: AgentRun):
        """Get tool instance for configuration (override point for subclasses)."""
        # This is a simplified approach - in practice, you'd use a tool factory
        # or registry to get the actual tool instances
        try:
            # For the knowledge query tool specifically
            if tool_config.name == "knowledge_query":
                from ..tools.builtin.knowledge_query import KnowledgeQueryTool
                return KnowledgeQueryTool(tool_config, agent_run)
            
            # For the coding agent tool
            if tool_config.name == "coding_agent":
                from ..tools.builtin.coding_agent import CodingAgentTool
                return CodingAgentTool(tool_config, agent_run)
            
            # Add other tool types as needed
            logger.debug(f"Tool instance not found for: {tool_config.name}")
            return None
            
        except Exception as e:
            logger.error(f"Error creating tool instance for {tool_config.name}: {e}")
            return None
    
    def _create_stream_merger(self) -> StreamEventMerger:
        """Create appropriate stream merger based on configuration."""
        if self._stream_merger_type == "time_ordered":
            return TimeOrderedStreamMerger()
        else:
            # Default to basic merger
            return StreamEventMerger()
    
    async def switch_provider(self, provider_name: str, **provider_config) -> None:
        """Switch provider and reinitialize streaming components."""
        # Cleanup existing streaming
        if self._tool_stream_manager:
            await self._tool_stream_manager.cleanup()
            self._tool_stream_manager = None
        
        # Switch provider
        await super().switch_provider(provider_name, **provider_config)
        
        # Reinitialize streaming if enabled
        if self._enable_tool_streaming:
            self._tool_stream_manager = ToolStreamManager()
    
    def enable_tool_streaming(self) -> None:
        """Enable tool streaming at runtime."""
        self._enable_tool_streaming = True
        if self.is_initialized and not self._tool_stream_manager:
            self._tool_stream_manager = ToolStreamManager()
        logger.info("Tool streaming enabled")
    
    def disable_tool_streaming(self) -> None:
        """Disable tool streaming at runtime."""
        self._enable_tool_streaming = False
        logger.info("Tool streaming disabled")
    
    def is_tool_streaming_enabled(self) -> bool:
        """Check if tool streaming is enabled."""
        return self._enable_tool_streaming
    
    def get_streaming_stats(self) -> dict[str, any]:
        """Get streaming statistics for monitoring."""
        return {
            "tool_streaming_enabled": self._enable_tool_streaming,
            "stream_merger_type": self._stream_merger_type,
            "tool_stream_manager_active": self._tool_stream_manager is not None,
            "provider_name": self.provider_name,
            "is_initialized": self.is_initialized
        }