"""CLI utilities for Mnemex."""
