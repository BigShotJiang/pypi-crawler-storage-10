# Fabric SDK

**Official Python SDK for Fabric - Distributed AI Compute Network**

Submit AI workloads to the Fabric network programmatically.

## Installation

```bash
pip install fabric-sdk
```

## Quick Start

```python
from fabric_sdk import FabricClient

# Initialize client
client = FabricClient(
    api_url="https://api.fabric.carmel.so",
    email="your@email.com",
    password="your_password"
)

# Submit a job
job = client.submit_job(
    workload_type="pytorch_cnn",
    params={
        "input_size": 784,
        "hidden_size": 128,
        "output_size": 10,
        "num_epochs": 5,
        "batch_size": 32
    },
    requirements={
        "min_cpu_cores": 4,
        "min_ram_gb": 8,
        "gpu_required": True,
        "min_gpu_memory_gb": 4
    }
)

print(f"Job submitted: {job['id']}")

# Wait for completion
result = client.wait_for_job(job['id'], timeout=300)
print(f"Job completed in {result['duration']}s")
print(f"Cost: ${result['cost']}")
```

## Features

- **Automatic Authentication** - JWT token management
- **Job Submission** - Submit AI workloads with custom requirements
- **Job Monitoring** - Track progress and get results
- **Credit Management** - Check balance and purchase credits
- **Node Discovery** - List available compute nodes
- **Auto-Retry** - Built-in network resilience
- **Type Hints** - Full TypeScript-style typing support

## Supported Workload Types

| Type | Description | Requirements |
|------|-------------|--------------|
| `pytorch_cnn` | PyTorch CNN training | GPU recommended |
| `transformer_attention` | Transformer attention computation | GPU required |
| `llm_inference` | LLM token generation | High GPU memory |
| `custom_python` | Custom Python script | Varies |

## License

MIT License - See [LICENSE](./LICENSE)


