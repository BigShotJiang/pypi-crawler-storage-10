"""Type definitions for Fabric SDK"""

from typing import TypedDict, Optional, Dict, Any, Literal
from datetime import datetime


JobStatus = Literal["queued", "executing", "completed", "failed"]
NodeStatus = Literal["active", "inactive", "busy", "removed"]


class Job(TypedDict, total=False):
    """Job representation - matches backend JobResponse model"""
    id: str
    job_type: str
    status: JobStatus
    assigned_node_id: Optional[str]
    estimated_cost: Optional[float]
    actual_cost: Optional[float]
    queued_at: str
    started_at: Optional[str]
    completed_at: Optional[str]
    duration_seconds: Optional[float]
    timeout_at: Optional[str]
    warning: Optional[Dict[str, Any]]


class Node(TypedDict, total=False):
    """Node representation"""
    id: str
    name: str
    owner_id: str
    device_id: str
    status: NodeStatus
    hardware_info: Dict[str, Any]
    total_jobs: int
    total_earned: float
    last_heartbeat: Optional[str]
    created_at: str


class CreditBalance(TypedDict, total=False):
    """Credit balance representation"""
    user_id: str
    credits_balance: float
    pending_earnings: float
    lifetime_earnings: float
    lifetime_spending: float


class JobResult(TypedDict):
    """Job result with metadata"""
    job_id: str
    status: JobStatus
    result: Optional[Dict[str, Any]]
    actual_cost: float
    duration_seconds: Optional[float]
    error_message: Optional[str]

