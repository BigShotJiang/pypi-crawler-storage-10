"""
Simple example: Submit a PyTorch CNN training job
"""

from fabric_sdk import FabricClient

# Initialize client (auto-login)
client = FabricClient(
    api_url="https://api.fabric.carmel.so",
    email="ai@org.com",
    password="Test@1234"
)

# Check credit balance
balance = client.get_credit_balance()
print(f"💰 Credit balance: ${balance['credits_balance']:.2f}")

# List available nodes
nodes = client.list_nodes(status='active')
print(f"🖥️  Available nodes: {len(nodes)}")

# Submit a job
print("\n📤 Submitting PyTorch CNN job...")
job = client.submit_job(
    workload_type="pytorch_cnn_training",
    params={
        "input_size": 784,
        "hidden_size": 128,
        "output_size": 10,
        "num_epochs": 3,
        "batch_size": 32
    },
    requirements={
        "min_cpu_cores": 2,
        "min_ram_gb": 4,
        "gpu_required": False
    }
)

print(f"✅ Job submitted: {job['id']}")
print(f"   Status: {job['status']}")

# Wait for completion
print("\n⏳ Waiting for job to complete...")
result = client.wait_for_job(job['id'], timeout=300, poll_interval=3)

if result['status'] == 'completed':
    print(f"✅ Job completed!")
    if result.get('duration_seconds'):
        print(f"   Duration: {result['duration_seconds']:.1f}s")
    print(f"   Cost: ${result['actual_cost']:.6f}")
    if result.get('result') and result['result'].get('metrics'):
        print(f"   Loss: {result['result']['metrics']['final_loss']:.4f}")
        print(f"   Accuracy: {result['result']['metrics']['accuracy']:.2%}")
else:
    print(f"❌ Job failed: {result['error_message']}")

