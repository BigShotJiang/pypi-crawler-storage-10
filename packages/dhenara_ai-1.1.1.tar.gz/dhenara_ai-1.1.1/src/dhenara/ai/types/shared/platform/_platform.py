from dhenara.ai.types.shared.base import BaseEnum


class PlatformEnvTypeEnum(BaseEnum):
    test = "test"
    live = "live"
