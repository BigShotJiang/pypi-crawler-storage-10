import requests

class DiaramaAPIClient:
    def __init__(self, api_key: str, base_url: str = "https://api.diaramastudio.ru"):
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }

    def _get(self, endpoint, params=None):
        r = requests.get(f"{self.base_url}{endpoint}", headers=self.headers, params=params)
        r.raise_for_status()
        return r.json()

    def _post(self, endpoint, data=None):
        r = requests.post(f"{self.base_url}{endpoint}", headers=self.headers, json=data)
        r.raise_for_status()
        return r.json()

    def _put(self, endpoint, data=None):
        r = requests.put(f"{self.base_url}{endpoint}", headers=self.headers, json=data)
        r.raise_for_status()
        return r.json()

    def _delete(self, endpoint):
        r = requests.delete(f"{self.base_url}{endpoint}", headers=self.headers)
        r.raise_for_status()
        return r.json()
