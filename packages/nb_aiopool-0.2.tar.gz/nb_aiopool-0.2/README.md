# nb_aiopool - 异步IO并发池工具库

即使在 asyncio 编程生态中，并发池仍然有其用武之地。虽然 asyncio 本身提供了事件循环机制来处理并发，但在实际应用中，我们仍然需要对并发数量进行控制，以避免资源耗尽和系统过载。nb_aiopool 提供了多种异步IO并发池实现，帮助开发者更好地管理并发任务。

## 为什么需要并发池？

尽管 asyncio 可以轻松创建成千上万个协程，但无限制的并发可能导致以下问题：

1. **资源耗尽**：同时创建大量协程会消耗大量内存
2. **系统过载**：过多并发请求可能导致目标服务崩溃
3. **缺乏控制**：难以控制任务执行速率和资源使用
4. **错误处理困难**：大量并发任务的错误处理和资源回收复杂

并发池提供了以下优势：

1. **控制并发数量**：限制同时执行的任务数量，避免系统过载
2. **复用任务资源**：通过任务复用提高效率
3. **合理管理内存**：控制任务创建速度，避免瞬间创建大量任务导致内存激增
4. **优雅的资源管理**：提供自动化的资源回收和错误处理机制

## 安装

```bash
pip install nb_aiopool
```

## 快速开始

```python
from nb_aiopool import SmartAioPool

async def my_task(x):
    await asyncio.sleep(1)
    return x * 2

async def main():
    # 创建一个并发池，最大并发数为10
    pool = SmartAioPool(max_concurrency=10)
    
    await pool.submit(my_task, i) 
    

asyncio.run(main())
```

## 并发池类型

### 1. SmartAioPool - 智能并发池

功能最丰富的并发池实现，具有动态工作线程管理、任务队列管理、自动资源清理等特性。

主要特性：
- 动态工作线程管理：根据任务负载自动增减工作线程数量
- 任务队列管理：支持最大队列大小限制，防止内存溢出
- 自动资源清理：程序退出时自动等待未完成任务
- 灵活的任务提交方式：支持阻塞/非阻塞提交、同步/异步获取结果
- 自适应扩展：当任务队列中有等待任务且未达到最大并发数时自动创建工作线程
- 空闲回收：工作线程空闲超时后自动回收，保留最小工作线程数

```python
from nb_aiopool import SmartAioPool

pool = SmartAioPool(
    max_concurrency=100,   # 最大并发数
    max_queue_size=1000,   # 最大队列大小
    min_workers=1,         # 最小工作线程数
    idle_timeout=5.0,      # 空闲超时时间
    auto_shutdown=True     # 程序退出时自动等待任务完成
)
```

### 2. CommonAioPool - 通用并发池

基于队列的经典并发池实现，提供稳定的并发控制。

主要特性：
- 基于队列的任务分发机制
- 固定最大并发数
- 支持阻塞和非阻塞任务提交
- 优雅的资源管理

```python
from nb_aiopool import CommonAioPool

pool = CommonAioPool(
    max_concurrency=100,   # 最大并发数
    max_queue_size=1000    # 最大队列大小
)
```

### 3. NoQueueAioPool - 无队列并发池

轻量级的无队列并发池实现，通过直接控制活跃任务数量来管理并发。

主要特性：
- 无队列设计，直接控制任务并发
- 轻量级实现
- 高性能
- 适用于简单并发控制场景

```python
from nb_aiopool import NoQueueAioPool

pool = NoQueueAioPool(max_concurrency=100)  # 最大并发数
```

## 使用示例

### 基本用法

```python
import asyncio
from nb_aiopool import SmartAioPool

async def sample_task(x):
    await asyncio.sleep(0.1)
    return x * 2

async def main():
    # 使用上下文管理器（推荐）
    async with SmartAioPool(max_concurrency=10) as pool:
        # run是提交任务并等待结果，相当于 await (await pool.submit(sample_task(5)))
        result = await pool.run(sample_task(5))
        print(f"结果: {result}")
        
        # 批量提交任务
        futures = [await pool.submit(sample_task(i)) for i in range(20)]
        results = await asyncio.gather(*futures)
        print(f"批量结果: {results}")

asyncio.run(main())
```

### 自动资源管理

```python
from nb_aiopool import SmartAioPool, smart_run

# 启用自动关机功能
pool = SmartAioPool(auto_shutdown=True)

async def main():
    # 提交任务但不等待
    await pool.submit(sample_task(1))
    await pool.submit(sample_task(2))
    await pool.submit(sample_task(3))
    # 程序退出时会自动等待所有任务完成

# 使用 smart_run 自动等待所有任务完成，
# 由于SmartAioPool 黑科技实现，你使用asyncio.run运行main()也可以，在程序退出前自动等待所有tasks完成   
smart_run(main())
```

## 并发池对比

### SmartAioPool ：
**优点：** 
1. 自动增加减少协程数量，节制开启新协程（虽然协程创建代价比线程小太多）    
2. 自动在程序退出前自动等待所有任务完成，这是黑科技，是代码中最难实现的   
**缺点：**  
要实现上面2个优点，导致源码实现极其复杂，导致性能也低一些。     
对于asyncio 并发池，要实现自动在程序退出前自动等待所有任务完成，比 concurrent.futures.ThreadPoolExecutor 并发池要复杂得多。     
因为等到 atexit 钩子触发时，事件循环loop已经关闭，无法直接await loop.run_until_complete(asyncio.gather(*tasks)) 等待所有任务完成。

### CommonAioPool ：
**优点：** 
1. 简单易用，实现简单粗暴。直接启动并发数个协程，不停地从asyncio.Queue中获取任务并执行。 
2. 性能比 `SmartAioPool` 更好
**缺点：** 
1. 不能自动在程序退出前自动等待所有任务完成，这点不如 SmartAioPool 
```
如果用户 不用 async with CommonAioPool 创建并发池，而且忘了调用 shutdown() 方法，
如果只submit，但不await 返回的future对象，程序会提前退出，导致未完成任务丢失。 

相当于你asyncio.create_task() 创建了大量任务，但忘了 await asyncio.gather(*tasks) 等待所有任务完成，
程序会提前退出，产生悲剧。
```

**CommonAioPool 可以在你的起点协程函数最后调用 await shutdown_all_common_aiopools() 来等待所有任务完成**

### NoQueueAioPool：
**优点：** 
1. 简单易用，直接创建asyncio.Task对象，不使用 `asyncio.Queue`
2. 性能高，源码实现简单，性能比 `SmartAioPool` 更好
**缺点：** 
1. 不能自动在程序退出前自动等待所有任务完成,这点不如 SmartAioPool


## 最后，为什么asyncio 也需要协程并发池？

例如1000协程，压测web接口1000万次的需求   

你用 asyncio.Semaphore(1000) 来控制1000并发，但是 
tasks = [make_request(url, session, semaphore) for _ in range(10000000)]   
迅速创建1000万tasks，造成内存 cpu loop压力都很大。

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTTP压力测试工具 - 无池版本（极端愚蠢版）

用于向指定主机和端口发送大量HTTP请求以进行性能测试。
此版本不使用任何连接池或任务池，而是直接创建1000万个任务，极端浪费资源。
说明，即使是在asyncio 编程生态，并发池任然是有必要的。

此版本用于演示aiopool的价值：
1. 控制并发数量，避免系统过载
2. 复用任务（task）资源，提高效率
3. 合理管理内存使用
4. 控制task的创建速度，避免瞬间创建大量任务导致内存激增
"""

import asyncio
import aiohttp


async def make_request(url, session, semaphore):
    """发送单个HTTP请求"""
    async with semaphore:
        try:
            async with session.get(url) as response:
                await response.read()
        except:
            pass


async def main():
    """主函数 - 请求1000万次"""
    url = "http://localhost:8000"
    
    # 极端愚蠢的做法：直接创建1000万个任务
    print("正在创建1000万个任务...")

    semaphore = asyncio.Semaphore(1000)
    # 创建共享的session和semaphore
    async with aiohttp.ClientSession() as session:
        # 极端愚蠢，瞬间创建1000万个任务，导致内存激增，loop cpu压力也大
        tasks = [make_request(url, session, semaphore) for _ in range(10000000)] 
        # 执行所有请求
        print("开始执行请求...")
        await asyncio.gather(*tasks)
        print("执行完成")


if __name__ == "__main__":
    asyncio.run(main())
```

## 许可证

MIT