# PyCorrCPI
PyCorrCPI - corelation analysis for charged-particle imaging experiments

`pip install PyCorrCPI`

See an example and demonstration in `Examples/Thiophenone Covariance Analysis Example May 24 - Simulated Data.ipynb`.

Find documentation [here](https://htmlpreview.github.io/?https://github.com/f-allum/PyCorrCPI/blob/main/docs/_build/html/index.html)
