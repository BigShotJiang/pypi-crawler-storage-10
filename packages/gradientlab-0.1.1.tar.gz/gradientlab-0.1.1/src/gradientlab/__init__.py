def hello() -> str:
    return "Hello from gradientlab!"
