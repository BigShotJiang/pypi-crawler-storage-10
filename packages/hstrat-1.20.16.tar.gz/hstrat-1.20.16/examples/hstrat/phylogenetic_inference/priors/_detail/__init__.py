from ._PriorBase import PriorBase

__all__ = [
    "PriorBase",
]
