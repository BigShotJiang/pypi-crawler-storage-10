from ._calc_rank_of_parity_segue_between_naive import (
    calc_rank_of_parity_segue_between_naive,
)

calc_rank_of_parity_segue_between = calc_rank_of_parity_segue_between_naive
