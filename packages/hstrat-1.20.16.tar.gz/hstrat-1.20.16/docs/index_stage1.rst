========
Overview
========

.. include:: readme.rst

.. toctree::
   :maxdepth: 1
   :hidden:

   self
   quickstart
   demo-ping
   mechanism
   policies
   api
   publications
   projects
   citing
   contributing
   authors
   history
   indices
