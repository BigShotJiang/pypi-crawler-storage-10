.. automodule:: sigima.tools
