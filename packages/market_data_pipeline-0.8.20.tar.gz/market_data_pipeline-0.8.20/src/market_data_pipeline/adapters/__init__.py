"""Adapters for external systems (providers, sinks, etc.)."""

