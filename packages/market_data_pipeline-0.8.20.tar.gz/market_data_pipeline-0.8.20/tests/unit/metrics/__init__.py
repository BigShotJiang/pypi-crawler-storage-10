"""Unit tests for metrics module."""

