"""Tests for Pulse integration (Phase 10.1)."""

