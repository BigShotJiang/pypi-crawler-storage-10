from __future__ import annotations

from typing import List, Dict
from dataclasses import asdict

# 框架依赖
from ..framework.command import Command
from ..framework.context import Context
from ..framework.command_registry import CommandRegistry

# 解析工具方法（仅保留元数据解析）
from ..common.word.docx_file_parse_util import (
    extract_docx_content_with_metadata,
)

# 为拼接多行标题引入 docx 读取
from docx import Document
import re


class DocxFileParseCommand(Command):
    """
    框架命令子类：按“标题-表格-脚注/段落”分块（仅元数据）。
    仅使用 `extract_docx_content_with_metadata` 进行解析。
    """

    def is_satisfied(self, context: Context) -> bool:
        return context.has_document()

    def execute(self, context: Context) -> Context:
        # 解析输入路径（支持文件或文件夹），仅处理 .docx
        paths = context.resolve_document_paths(patterns=["*.docx"])
        if not paths:
            context.add_error("No DOCX files resolved from context")
            return context

        def _clean_text(s: str) -> str:
            s = (s or "")
            s = s.replace("\u200b", "").replace("\xa0", " ")
            s = re.sub(r"\s+", " ", s).strip()
            return s

        def _para_font_signature(para) -> tuple:
            """获取段落的字体签名 (name_lower, size_pt)。优先 run 上的显式设置，其次样式。"""
            name = None
            size_pt = None
            try:
                for r in para.runs:
                    if not (r.text or "").strip():
                        continue
                    if r.font.name and not name:
                        name = r.font.name
                    if r.font.size and not size_pt:
                        # python-docx Length -> points
                        try:
                            size_pt = float(r.font.size.pt)
                        except Exception:
                            size_pt = None
                    if name and size_pt:
                        break
                # 样式回退
                if not name:
                    try:
                        name = para.style.font.name
                    except Exception:
                        name = None
                if not size_pt:
                    try:
                        st_size = para.style.font.size
                        size_pt = float(st_size.pt) if st_size else None
                    except Exception:
                        size_pt = None
            except Exception:
                pass
            name = (name or "").strip().lower() or None
            return (name, size_pt)

        def _same_font(a: tuple, b: tuple) -> bool:
            """判定字体与字号是否一致；字号允许极小误差（±0.5pt）。"""
            if not a or not b:
                return False
            an, asz = a
            bn, bsz = b
            if an != bn:
                return False
            if asz is None or bsz is None:
                return False
            return abs(asz - bsz) <= 0.5

        def _assemble_title_and_extra_footnotes(docx_path: str, indices: List[int]):
            """
            组装单行标题并识别额外脚注：
            - 仅将与首个非空标题段落字体+字号一致的段落并入标题；
            - 若遇到空段落（仅空白）视为分隔符，之后的非空段落归入脚注；
            - 返回 (single_line_title, extra_footnote_text, extra_footnote_indices)。
            """
            try:
                doc = Document(docx_path)
            except Exception:
                return "", "", []
            title_parts: List[str] = []
            foot_parts: List[str] = []
            foot_indices: List[int] = []

            base_sig = None
            started_title = False
            separated = False
            for i in sorted(set(int(x) for x in (indices or []))):
                if i < 0 or i >= len(doc.paragraphs):
                    continue
                para = doc.paragraphs[i]
                text = _clean_text(para.text)
                # 空段落作为分隔符（仅在已开始标题后生效）
                if not text:
                    if started_title:
                        separated = True
                    continue
                sig = _para_font_signature(para)
                if base_sig is None:
                    base_sig = sig
                    started_title = True
                    title_parts.append(text)
                    continue
                if separated or not _same_font(sig, base_sig):
                    foot_parts.append(text)
                    foot_indices.append(i)
                else:
                    title_parts.append(text)

            title = _clean_text(" ".join(title_parts))
            extra_foot = _clean_text(" ".join(foot_parts))
            return title, extra_foot, foot_indices

        # 将解析得到的 TableItem 列表转为结构化字典，并写入 Context.sections
        parsed_sections: List[Dict] = []
        for p in paths:
            sections = extract_docx_content_with_metadata(str(p))
            for sec in sections:
                d = asdict(sec)
                # 组装标题并识别额外脚注（标题下方、不同字体/字号或空行后的内容）
                full_title, extra_foot, extra_indices = _assemble_title_and_extra_footnotes(str(p), sec.title_indices)
                if full_title:
                    d["title"] = full_title
                if extra_foot:
                    prev = (d.get("footnote") or "").strip()
                    d["footnote"] = f"{prev}\n{extra_foot}".strip() if prev else extra_foot
                    d["footnote_indices"] = (d.get("footnote_indices") or []) + extra_indices
                    # 从标题索引中移除这些被判定为脚注的段落，避免拆分时复制到标题里
                    if d.get("title_indices"):
                        rm = set(extra_indices)
                        d["title_indices"] = [i for i in d["title_indices"] if i not in rm]
                d["source_file"] = str(p)
                parsed_sections.append(d)

        # 更新上下文
        context.doc_type = "docx"
        context.sections = parsed_sections
        context.processing_summary["title_table_footnote_partition"] = {
            "files_processed": len(paths),
            "sections_extracted": len(parsed_sections),
            "mode": "metadata_only",
        }
        return context


# 注册到命令注册表，便于 Pipeline 通过 YAML 创建
CommandRegistry.register("DocxFileParseCommand", DocxFileParseCommand)