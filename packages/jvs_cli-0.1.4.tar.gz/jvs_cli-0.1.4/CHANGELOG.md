# Changelog

## [0.1.4] - 2025-10-24

### Added
- Added `exit` and `quit` commands (without slash) to exit CLI
- Improved conversation_id extraction from both jarvis_metadata and jarvis_step.data

### Fixed
- Fixed conversation continuity: conversations now persist within the same REPL session
- Removed confusing "Starting conversation:" message
- Better visual feedback when continuing an existing conversation

### Changed
- Updated help text to include new exit commands
- Improved debug logging for conversation tracking

## [0.1.3] - 2025-10-24

### Changed
- Simplified config init to only 3 fields: URL, Login Code, Theme
- All display options now default to enabled
- Added `login_code` field (backward compatible with `user_id`)

## [0.1.1] - 2025-10-24

### Fixed
- Fixed AttributeError in `jvs-cli config show` command

## [0.1.0] - 2025-10-23

Initial release

### Features
- Interactive REPL mode
- Streaming responses
- AI thinking visualization
- Conversation history
- Configurable display options
- OpenAI-compatible API support
