"""
Python Connector for NetSuite is a connectivity solution for accessing
NetSuite from Python applications to read and update data. It fully implements
the Python DB API 2.0 specification. The connector is distributed as a wheel
package for Windows and Windows Server.
 
Standard SQL syntax

    The connector fully supports the ANSI SQL standard and lets you execute SQL
    statements against your NetSuite data just like you would normally work with
    relational databases. Simple queries are directly converted to NetSuite API
    calls and executed on the NetSuite side.

Version: 1.3.0 

Homepage: https://www.devart.com/python/netsuite/
"""
from .netsuite import *
