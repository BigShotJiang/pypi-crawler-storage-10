"""Alias mínimos de tipos usados únicamente para anotaciones."""

from typing import Any, Iterable, Mapping, MutableMapping, Sequence, Tuple, Union

RequestContent = Any
RequestFiles = Any
QueryParamTypes = Union[str, Mapping[str, Any], Sequence[Tuple[str, Any]]]
HeaderTypes = Mapping[str, str] | Sequence[Tuple[str, str]]
CookieTypes = Mapping[str, str] | Sequence[Tuple[str, str]]
AuthTypes = Any
TimeoutTypes = Union[float, Tuple[float, float, float, float]]
URLTypes = Union[str, "URL"]
