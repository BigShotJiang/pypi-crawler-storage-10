"""Utilidades mínimas para imitar la API de httpx._client."""


class UseClientDefault:
    """Objeto centinela usado en anotaciones y argumentos opcionales."""


USE_CLIENT_DEFAULT = UseClientDefault()
