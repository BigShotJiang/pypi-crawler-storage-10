"""Componentes de metacognición para AGIX."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from .self_organization import SelfOrganizationMonitor
from .intention_evaluator import IntentionEvaluator
from .metareflection_engine import MetaReflectionEngine, InternalVoice

__all__ = [
    "MetaReflectionEngine",
    "InternalVoice",
    "IntentionEvaluator",
    "SelfOrganizationMonitor",
]

try:  # pragma: no cover - dependencias opcionales
    from .manager import MetacognitionManager
    from .dynamic_evaluator import DynamicMetaEvaluator

    __all__ += ["MetacognitionManager", "DynamicMetaEvaluator"]
except Exception:  # noqa: BLE001
    pass
