"""Utilidades de interfaz de usuario para AGIX."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from .styles import (
    Border,
    Colors,
    DEFAULT_THEME,
    Margin,
    Padding,
    Theme,
    Typography,
    create_theme,
    style_button,
    style_container,
    style_text,
)
from .components import Button, Card, ListItem
from .responsive import (
    Breakpoint,
    ResponsiveManager,
    responsive_row,
    responsive_visibility,
)

__all__ = [
    "Border",
    "Colors",
    "DEFAULT_THEME",
    "Margin",
    "Padding",
    "Theme",
    "Typography",
    "create_theme",
    "style_button",
    "style_container",
    "style_text",
    "Button",
    "Card",
    "ListItem",
    "Breakpoint",
    "ResponsiveManager",
    "responsive_row",
    "responsive_visibility",
]
