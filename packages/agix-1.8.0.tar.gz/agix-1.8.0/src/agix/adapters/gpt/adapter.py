from __future__ import annotations


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from typing import Callable

from agix.adapters.base import DomainAdapter
from agix.language.emotional_translator import SemanticEmotionalTranslator


class GPTQualiaAdapter(DomainAdapter):
    """Adaptador para interactuar con un modelo tipo GPT."""

    def __init__(
        self,
        client: Callable[[str], str],
        source_lang: str = "es",
        target_lang: str = "en",
    ) -> None:
        self.client = client
        self.translator = SemanticEmotionalTranslator()
        self.source_lang = source_lang
        self.target_lang = target_lang

    # ------------------------------------------------------------------
    def adapt_input(self, observation: str) -> str:
        """Prepara el mensaje para el modelo GPT."""
        return observation

    # ------------------------------------------------------------------
    def adapt_output(self, action: str) -> str:
        """Traduce términos emocionales en la respuesta."""
        return self.translator.translate(
            action, source_lang=self.source_lang, target_lang=self.target_lang
        )

    # ------------------------------------------------------------------
    def generate_reply(self, prompt: str) -> str:
        """Obtiene una respuesta del cliente GPT traduciendo las emociones."""
        prompt = self.adapt_input(prompt)
        raw = self.client(prompt)
        return self.adapt_output(raw)
