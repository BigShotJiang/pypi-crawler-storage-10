
if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from typing import Any, Dict

from agix.adapters.base import DomainAdapter


class ServiceAdapter(DomainAdapter):
    """Adaptador para exponer agentes vía servicios HTTP."""

    def adapt_input(self, request: Dict[str, Any]) -> Any:
        """Convierte un payload HTTP en la observación interna."""
        if not isinstance(request, dict):
            raise ValueError("La petición debe ser un diccionario JSON")
        if "observation" not in request:
            raise ValueError("Falta la clave 'observation' en la petición")
        return request["observation"]

    def adapt_output(self, action: Any) -> Dict[str, Any]:
        """Formatea la acción del agente para responder al cliente."""
        return {"action": action}
