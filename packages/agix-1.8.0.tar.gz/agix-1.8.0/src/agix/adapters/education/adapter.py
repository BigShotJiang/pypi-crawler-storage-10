
if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

import numpy as np

from agix.adapters.base import DomainAdapter


class EducationAdapter(DomainAdapter):
    """Convierte interacciones genéricas a un formato educativo simple."""

    def adapt_input(self, observation: str) -> np.ndarray:
        """Codifica texto y lo expande a un vector de longitud 10."""
        length = len(observation)
        vec = np.full(10, float(length))
        return vec

    def adapt_output(self, action: int) -> str:
        """Mapea acciones numéricas a sugerencias pedagógicas."""
        mapping = {0: "continuar", 1: "repasar", 2: "evaluar"}
        return mapping.get(action, "continuar")
