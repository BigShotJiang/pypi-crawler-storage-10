"""Módulos de orquestación y coordinación."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from .hub import QualiaHub
from .virtual import VirtualQualia
from .emotion_hub import EmotionHub, EMOTIONAL_STATE
from .synthetic_loop import SyntheticLoop, run_cycle

__all__ = [
    "QualiaHub",
    "VirtualQualia",
    "EmotionHub",
    "EMOTIONAL_STATE",
    "SyntheticLoop",
    "run_cycle",
]
