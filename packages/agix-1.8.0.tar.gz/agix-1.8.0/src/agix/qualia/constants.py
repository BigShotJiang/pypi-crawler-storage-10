"""Constantes compartidas para la comunicación de Qualia."""

QUALIA_WS_PATH = "/ws/qualia"
