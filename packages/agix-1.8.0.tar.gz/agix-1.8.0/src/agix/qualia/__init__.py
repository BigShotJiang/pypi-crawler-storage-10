"""Subpaquete de procesos cualitativos y estado emocional."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))



from .qualia_engine import QualiaEngine

__all__ = [
    "ConceptClassifier",
    "HeuristicQualiaSpirit",
    "EmotionalRNN",
    "AffectiveVector",
    "QualiaMiddleware",
    "QualiaEngine",
    "QualiaSpiritCore",
]


def __getattr__(name):
    if name == "ConceptClassifier":
        from .concept_classifier import ConceptClassifier

        return ConceptClassifier
    if name == "HeuristicQualiaSpirit":
        from .heuristic_spirit import HeuristicQualiaSpirit

        return HeuristicQualiaSpirit
    if name == "EmotionalRNN":
        from .emotional_rnn import EmotionalRNN

        return EmotionalRNN

    if name == "AffectiveVector":
        from .afe_vec import AffectiveVector

        return AffectiveVector

    if name == "QualiaMiddleware":
        from .middleware import QualiaMiddleware
        return QualiaMiddleware
    if name == "QualiaSpiritCore":
        from .qualia_spirit_core import QualiaSpiritCore
        return QualiaSpiritCore

    raise AttributeError(name)
