"""Motor para modelos Claude de Anthropic."""

from __future__ import annotations


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from typing import Optional

from .base import LogicEngine


class ClaudeEngine(LogicEngine):
    """Integra la API de Anthropic para utilizar Claude."""

    def __init__(self, model: str = "claude-3-haiku", api_key: Optional[str] = None) -> None:
        self.model = model
        self.api_key = api_key
        self._client = None  # carga diferida

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                import anthropic
            except ImportError as exc:
                raise ImportError("Se requiere 'anthropic' para ClaudeEngine") from exc
            self._client = anthropic.Client(api_key=self.api_key)

    def infer(self, prompt: str) -> str:
        return self.generate(prompt)

    def generate(self, prompt: str) -> str:
        self._ensure_client()
        response = self._client.messages.create(
            model=self.model,
            max_tokens=256,
            messages=[{"role": "user", "content": prompt}],
        )
        content = response.get("content")
        if isinstance(content, list) and content:
            item = content[0]
            return item.get("text", str(item))
        return str(content)
