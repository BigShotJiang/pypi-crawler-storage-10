"""Gestor de motores lógicos."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from importlib import metadata
from typing import Dict, Iterable

from .base import LogicEngine


class LogicEngineManager:
    """Carga motores registrados bajo el grupo ``agix.logic_engines``."""

    def __init__(self) -> None:
        self.engines: Dict[str, LogicEngine] = {}

    def register(self, engine: LogicEngine) -> None:
        """Registra un motor disponible."""
        self.engines[engine.__class__.__name__] = engine

    def discover(self) -> None:
        """Descubre e instancia motores a través de *entry points*."""
        eps: Iterable[metadata.EntryPoint] = metadata.entry_points(group="agix.logic_engines")
        for ep in eps:
            engine_cls = ep.load()
            engine = engine_cls()
            self.register(engine)

    def get(self, name: str) -> LogicEngine:
        """Obtiene un motor por nombre de clase."""
        return self.engines[name]
