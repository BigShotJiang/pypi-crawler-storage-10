from __future__ import annotations


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

"""Simulador de dilemas éticos con emociones y narrativa."""

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List

from .alignment import AlignmentInterface
from .moral_emotions import MoralEmotionSimulator
from agix.autonarrative.autonarrative_core import AutonarrativeCore, Experience


@dataclass
class ScenarioAction:
    """Representa una acción posible dentro de un escenario."""

    nombre: str
    impacto: Dict[str, float]


class EthicalDilemmaSimulator:
    """Genera escenarios, evalúa acciones y registra narrativas."""

    def __init__(self, frameworks: Iterable | None = None) -> None:
        self.alignment = AlignmentInterface(frameworks)
        self.emotions = MoralEmotionSimulator()
        self.autonarrative = AutonarrativeCore()

    # ------------------------------------------------------------------
    def _generar_acciones(self, descripcion: str) -> List[ScenarioAction]:
        """Crea acciones simples asociadas al escenario.

        Por simplicidad se generan dos acciones básicas con distintos
        impactos simbólicos.
        """

        acciones = [
            ScenarioAction(
                "accion_positiva",
                {"pro_vida": 0.9, "no_dano": 0.8, "respeto": 0.7},
            ),
            ScenarioAction(
                "accion_negativa", {"pro_vida": 0.2, "no_dano": 0.3, "respeto": 0.1}
            ),
        ]
        return acciones

    # ------------------------------------------------------------------
    def simulate_scenario(self, descripcion: str) -> Dict[str, Any]:
        """Evalúa un escenario y retorna resultados éticos y afectivos."""

        acciones = self._generar_acciones(descripcion)
        evaluaciones: Dict[str, Any] = {}
        narrativa_lineas: List[str] = []

        for accion in acciones:
            juicio = self.alignment.judge(accion.impacto)
            evaluaciones[accion.nombre] = juicio

            labels: List[str]
            if isinstance(juicio, dict):
                labels = [lbl for _, lbl in juicio.values()]
            else:
                labels = [juicio[1]]

            for lbl in labels:
                self.emotions.actualizar(
                    "positivo" if lbl in {"justo", "aceptable"} else "negativo"
                )
            narrativa_lineas.append(
                f"La acción {accion.nombre} fue considerada {labels[0]}."
            )

        narrativa = f"{descripcion}. " + " ".join(narrativa_lineas)
        estado_emocional = self.emotions.estado()

        metadata = {
            "values": ["etica"],
            "evaluation": evaluaciones,
            "affective_states": [k for k, v in estado_emocional.items() if v > 0],
        }
        self.autonarrative.store_experience(Experience(text=narrativa, metadata=metadata))

        return {
            "evaluacion": evaluaciones,
            "emociones": estado_emocional,
            "narrativa": narrativa,
        }
