"""Submódulos especializados disponibles en :mod:`agix.modules`.

Se evita importar los paquetes pesados (por ejemplo ``torch``) hasta que se
solicitan explícitamente, lo que permite usar partes livianas del paquete sin
depender de librerías externas opcionales.
"""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from importlib import import_module
from typing import TYPE_CHECKING

__all__ = ["neuroinspired", "temporal_inrf"]

if TYPE_CHECKING:  # pragma: no cover - sólo para comprobación estática
    from . import neuroinspired, temporal_inrf


def __getattr__(name: str):
    if name in __all__:
        return import_module(f"{__name__}.{name}")
    raise AttributeError(name)
