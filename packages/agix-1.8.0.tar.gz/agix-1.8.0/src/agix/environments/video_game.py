"""Entornos de videojuegos para AGI."""


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from .env_base import AGIEnvironment
import numpy as np


class VideoGameEnvironment(AGIEnvironment):
    """Interfaz genérica para videojuegos basada en ``AGIEnvironment``.

    Permite conectar con engines como Pygame o Unity. La implementación por
    defecto genera observaciones aleatorias para propósitos de prueba.
    """

    def __init__(self, engine: str = "pygame", obs_size: int = 8, action_space_size: int = 4, max_steps: int = 10):
        super().__init__()
        self.engine = engine
        self.obs_size = obs_size
        self.action_space_size = action_space_size
        self.max_steps = max_steps
        self.steps = 0

    def reset(self):
        self.steps = 0
        # Aquí se inicializaría el motor de juego real
        return np.zeros(self.obs_size)

    def step(self, action):
        self.steps += 1
        reward = 1.0 if action == 0 else 0.0
        done = self.steps >= self.max_steps
        obs = np.random.rand(self.obs_size)
        return obs, reward, done, {}

    def render(self):
        # En una integración real se delegaría al motor seleccionado
        pass
