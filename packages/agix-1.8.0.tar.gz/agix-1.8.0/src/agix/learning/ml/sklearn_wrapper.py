from __future__ import annotations


if __package__ in {None, ""}:  # pragma: no cover - permite ejecución como script
    import sys
    from pathlib import Path

    _current_file = Path(__file__).resolve()
    for _parent in (_current_file.parent, *_current_file.parents):
        if (_parent / "pyproject.toml").exists() or (_parent / ".git").exists():
            _project_root = _parent
            break
    else:
        _project_root = _current_file.parents[2]
    _src_root = _project_root / "src"
    for _path in (_project_root, _src_root):
        _path_str = str(_path)
        if _path_str not in sys.path:
            sys.path.insert(0, _path_str)
    from agix._script_utils import bootstrap_script_environment

    bootstrap_script_environment("__main__", str(_current_file))

from typing import Any

from .base import BaseLearner


class SklearnLearner(BaseLearner):
    """Envoltorio para estimadores de scikit-learn."""

    def __init__(self, estimator: Any):
        self.estimator = estimator
        self._supports_incremental = hasattr(estimator, "partial_fit")

    def train(self, X, y):
        self.estimator.fit(X, y)
        return self

    def predict(self, X):
        return self.estimator.predict(X)

    def train_incremental(self, X, y, **kwargs):
        if self._supports_incremental:
            self.estimator.partial_fit(X, y, **kwargs)
            return self
        return super().train_incremental(X, y, **kwargs)
