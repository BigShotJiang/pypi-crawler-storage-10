"""Implementaciones mínimas de scikit-learn para entornos sin la dependencia real."""

from .linear_model import LogisticRegression, SGDClassifier

__all__ = ["LogisticRegression", "SGDClassifier"]
