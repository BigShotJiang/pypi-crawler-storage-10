# balaji

A simple Python package that greets you with a friendly message!

## Installation

You can install it from PyPI:

```bash
pip install balaji
````

## Usage

### 1. Run from the terminal

After installation, you can run:

```bash
balaji
```

Output:

```
Hey, how's it going?
```

### 2. Use it in Python code

You can also import and call the function directly:

```python
from balaji import hello

hello()
```

Output:

```
Hey, how's it going?
```

## About

It includes a console script entry point as well as an importable function.

