from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    description = f.read()

setup(
    name="balaji",
    version="0.0.1",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'balaji=balaji.main:hello',
        ],
    },
    long_description=description,
    long_description_content_type="text/markdown",
)