"""pantsonfire - Find wrong information in technical docs online"""

__version__ = "0.3.7"

from .factory import create_app

__all__ = ["create_app", "__version__"]
