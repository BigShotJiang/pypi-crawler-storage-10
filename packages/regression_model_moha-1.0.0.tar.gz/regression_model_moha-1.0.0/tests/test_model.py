from regression_model import SimpleLinearRegression

def test_fit_and_predict():
    X = [1, 2, 3, 4, 5]
    y = [2, 4, 5, 4, 5]
    model = SimpleLinearRegression()
    model.fit(X, y)
    preds = model.predict([6])
    assert isinstance(preds, list)
