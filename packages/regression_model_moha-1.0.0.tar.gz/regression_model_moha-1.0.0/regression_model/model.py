class SimpleLinearRegression:
    def __init__(self):
        self.slope = 0
        self.intercept = 0

    def fit(self, X, y):
        X_mean = sum(X) / len(X)
        y_mean = sum(y) / len(y)
        num = sum((X[i] - X_mean) * (y[i] - y_mean) for i in range(len(X)))
        den = sum((X[i] - X_mean) ** 2 for i in range(len(X)))
        self.slope = num / den
        self.intercept = y_mean - self.slope * X_mean

    def predict(self, X):
        return [self.slope * x + self.intercept for x in X]
