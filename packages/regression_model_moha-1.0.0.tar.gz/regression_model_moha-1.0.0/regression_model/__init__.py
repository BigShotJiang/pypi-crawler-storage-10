from .model import SimpleLinearRegression
