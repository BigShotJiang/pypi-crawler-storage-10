# Regression Model (Challenge 5)

This package implements a Simple Linear Regression model from scratch in Python.

## Installation

### Offline
```
pip install dist/regression_model_moha-1.0.0-py3-none-any.whl
```

### Online
```
pip install regression-model-moha
```

## Usage
```python
from regression_model import SimpleLinearRegression

X = [1, 2, 3, 4, 5]
y = [2, 4, 5, 4, 5]
model = SimpleLinearRegression()
model.fit(X, y)
print(model.predict([6]))
```
