from setuptools import setup, find_packages

setup(
    name="regression_model_moha",
    version="1.0.0",
    author="Moha",
    author_email="moha@example.com",
    description="Simple Linear Regression implemented from scratch",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
)
