# TGZ Messaging SDK

An Official Python SDK from TechGenzi for sending messages across multiple channels like WhatsApp, *(Email, SMS).

`NOTE: * - module is illustrative and may not be fully implemented yet.`

`Package`: ``tgz-message-sdk``

`Author`: Suwethan M <suwethan.m@techgenzi.com>

`License`: MIT

## Overview

The TGZ Messaging SDK provides a simple and efficient way to integrate messaging functionalities into your Python applications.

### Project layout (high-level Bird view)
- / (root)
  - tests/
    - __init__.py
  - tgz_message/
  - .gitignore
  - LICENSE
  - pyproject.toml
  - README.md

## Installation

Install from PyPI:

```bash
  pip install tgz-message-sdk
```

    Requires: Python 3.7 or higher

### Dependencies
- requests


## Contact & Support

Author: Suwethan M — suwethan.tgz@gmail.com

## License

This project is licensed under the MIT License. See `LICENSE` for details.
