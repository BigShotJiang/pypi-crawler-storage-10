# Table of Contents

- [Table of Contents](#table-of-contents)
- [About](#about)
  - [Operating System Support](#operating-system-support)
  - [Python Version Support](#python-version-support)

# About

`ni.measurements.metadata.v1.proto` is a Python package that provides data types and a service stub for NI gRPC APIs in
the [ni.measurements.metadata.v1 package](https://github.com/ni/ni-apis/tree/main/ni/measurements/metadata/v1).

NI created and supports this package.

## Operating System Support

`ni.measurements.metadata.v1.proto` supports Windows and Linux operating systems.

## Python Version Support

`ni.measurements.metadata.v1.proto` supports CPython 3.9+.

## Installation

You can directly install the `ni.measurements.metadata.v1.proto` package using `pip` or by listing it as a
dependency in your project's `pyproject.toml` file.