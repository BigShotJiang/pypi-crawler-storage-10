class gist_save():
    def load_from_gist():
        url = f"https://api.github.com/gists/{GIST_ID}"
        headers = {"Authorization": f"token {GITHUB_TOKEN}"}
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            files = r.json().get("files", {})
            if GIST_FILE in files:
                import json
                return json.loads(files[GIST_FILE]["content"])
        print(matrix)
        return matrix


    def save_to_gist(matrix_data):
        url = f"https://api.github.com/gists/{GIST_ID}"
        headers = {"Authorization": f"token {GITHUB_TOKEN}"}
        import json
        data = {
            "files": {
                GIST_FILE: {
                    "content": json.dumps(matrix_data, indent=2)
                }
            }
        }
        r = requests.patch(url, headers=headers, json=data)
        if r.status_code not in (200, 201):
            raise Exception(f"Не удалось сохранить в Gist: {r.text}")
