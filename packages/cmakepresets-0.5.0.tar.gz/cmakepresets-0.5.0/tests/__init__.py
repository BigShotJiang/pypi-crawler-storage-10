from cmakepresets import log, logger

logger.setLevel(log.CRITICAL + 1)
