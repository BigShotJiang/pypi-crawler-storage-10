import cupy as cp
import numpy as np
import pixtreme as px
import os

from scopeon import Waveform, VectorScope, ScopeGrid

test_data_path = "example/example.png"


def test_scopegrid() -> None:
    """Test ScopeGrid with NumPy arrays"""
    os.makedirs("test_output", exist_ok=True)

    with px.Device(0):
        # Read real image (as CuPy array)
        cp_image = px.imread(test_data_path)

        # Convert to NumPy array
        image = px.to_numpy(cp_image)

        # Create scopes
        waveform = Waveform()
        vectorscope = VectorScope()

        # Get scope images
        wf_h = waveform.get(image, vertical=False)
        wf_v = waveform.get(image, vertical=True)
        vs = vectorscope.get(image)

        # Save individual images
        px.imwrite("test_output/grid_00_image.png", image)
        px.imwrite("test_output/grid_01_waveform_v.png", wf_v)
        px.imwrite("test_output/grid_02_waveform_h.png", wf_h)
        px.imwrite("test_output/grid_03_vectorscope.png", vs)

        # Compose grid
        result = ScopeGrid.grid_2x2(image, wf_v, wf_h, vs)

        # Save grid result
        px.imwrite("test_output/grid_04_result_2x2.png", result)

    # Verify output
    assert result.shape[0] == image.shape[0] * 2
    assert result.shape[1] == image.shape[1] * 2
    assert isinstance(result, cp.ndarray)  # Now always returns CuPy array


if __name__ == "__main__":
    test_scopegrid()
