"""Tests for ScopeGrid class"""
import numpy as np
import pytest
import pixtreme as px
import cupy as cp
import os


class TestScopeGridNumPy:
    """ScopeGrid tests with NumPy arrays"""

    def test_grid_2x2_with_same_size_images(self):
        """2x2 grid composition with same-size images"""
        from scopeon import ScopeGrid

        # Create images with different values (for identification)
        top_left = np.ones((100, 100, 3), dtype=np.float32) * 0.1
        top_right = np.ones((100, 100, 3), dtype=np.float32) * 0.2
        bottom_left = np.ones((100, 100, 3), dtype=np.float32) * 0.3
        bottom_right = np.ones((100, 100, 3), dtype=np.float32) * 0.4

        result = ScopeGrid.grid_2x2(top_left, top_right, bottom_left, bottom_right)

        # Verify result size
        assert result.shape == (200, 200, 3)
        assert result.dtype == np.float32
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array

        # Verify each region's values
        assert np.allclose(result[0:100, 0:100], 0.1)  # Top-left
        assert np.allclose(result[0:100, 100:200], 0.2)  # Top-right
        assert np.allclose(result[100:200, 0:100], 0.3)  # Bottom-left
        assert np.allclose(result[100:200, 100:200], 0.4)  # Bottom-right

    def test_hstack_two_images(self):
        """Horizontal concatenation of 2 images"""
        from scopeon import ScopeGrid

        img1 = np.ones((100, 50, 3), dtype=np.float32) * 0.5
        img2 = np.ones((100, 50, 3), dtype=np.float32) * 0.8

        result = ScopeGrid.hstack(img1, img2)

        assert result.shape == (100, 100, 3)
        assert result.dtype == np.float32
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array
        assert np.allclose(result[:, 0:50], 0.5)
        assert np.allclose(result[:, 50:100], 0.8)

    def test_hstack_three_images(self):
        """Horizontal concatenation of 3 images"""
        from scopeon import ScopeGrid

        img1 = np.ones((100, 50, 3), dtype=np.float32) * 0.3
        img2 = np.ones((100, 50, 3), dtype=np.float32) * 0.6
        img3 = np.ones((100, 50, 3), dtype=np.float32) * 0.9

        result = ScopeGrid.hstack(img1, img2, img3)

        assert result.shape == (100, 150, 3)
        assert result.dtype == np.float32

    def test_vstack_two_images(self):
        """Vertical concatenation of 2 images"""
        from scopeon import ScopeGrid

        img1 = np.ones((50, 100, 3), dtype=np.float32) * 0.2
        img2 = np.ones((50, 100, 3), dtype=np.float32) * 0.7

        result = ScopeGrid.vstack(img1, img2)

        assert result.shape == (100, 100, 3)
        assert result.dtype == np.float32
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array
        assert np.allclose(result[0:50, :], 0.2)
        assert np.allclose(result[50:100, :], 0.7)

    def test_vstack_three_images(self):
        """Vertical concatenation of 3 images"""
        from scopeon import ScopeGrid

        img1 = np.ones((50, 100, 3), dtype=np.float32) * 0.1
        img2 = np.ones((50, 100, 3), dtype=np.float32) * 0.5
        img3 = np.ones((50, 100, 3), dtype=np.float32) * 0.9

        result = ScopeGrid.vstack(img1, img2, img3)

        assert result.shape == (150, 100, 3)
        assert result.dtype == np.float32


class TestScopeGridCuPy:
    """ScopeGrid tests with CuPy arrays"""

    def test_grid_2x2_with_cupy_arrays(self):
        """2x2 grid composition with CuPy arrays"""
        from scopeon import ScopeGrid

        # Create with CuPy arrays
        top_left = cp.ones((100, 100, 3), dtype=cp.float32) * 0.1
        top_right = cp.ones((100, 100, 3), dtype=cp.float32) * 0.2
        bottom_left = cp.ones((100, 100, 3), dtype=cp.float32) * 0.3
        bottom_right = cp.ones((100, 100, 3), dtype=cp.float32) * 0.4

        result = ScopeGrid.grid_2x2(top_left, top_right, bottom_left, bottom_right)

        # Verify returned as CuPy array
        assert isinstance(result, cp.ndarray)
        assert result.shape == (200, 200, 3)
        assert result.dtype == cp.float32

    def test_hstack_with_cupy_arrays(self):
        """Horizontal concatenation with CuPy arrays"""
        from scopeon import ScopeGrid

        img1 = cp.ones((100, 50, 3), dtype=cp.float32) * 0.5
        img2 = cp.ones((100, 50, 3), dtype=cp.float32) * 0.8

        result = ScopeGrid.hstack(img1, img2)

        assert isinstance(result, cp.ndarray)
        assert result.shape == (100, 100, 3)

    def test_vstack_with_cupy_arrays(self):
        """Vertical concatenation with CuPy arrays"""
        from scopeon import ScopeGrid

        img1 = cp.ones((50, 100, 3), dtype=cp.float32) * 0.2
        img2 = cp.ones((50, 100, 3), dtype=cp.float32) * 0.7

        result = ScopeGrid.vstack(img1, img2)

        assert isinstance(result, cp.ndarray)
        assert result.shape == (100, 100, 3)


class TestScopeGridWithRealImage:
    """ScopeGrid tests with real images"""

    def test_grid_2x2_with_real_image(self):
        """2x2 grid composition with real image"""
        from scopeon import ScopeGrid, Waveform, VectorScope

        os.makedirs("test_output", exist_ok=True)

        with px.Device(0):
            # Read real image (as CuPy array)
            cp_image = px.imread("example/example.png")

            # Convert to NumPy array
            image = px.to_numpy(cp_image)

            # Generate various scopes
            waveform = Waveform()
            vectorscope = VectorScope()

            wf_h = waveform.get(image, vertical=False)
            wf_v = waveform.get(image, vertical=True)
            vs = vectorscope.get(image)

            # Compose 2x2 grid
            result = ScopeGrid.grid_2x2(image, wf_v, wf_h, vs)

            # Save as image
            px.imwrite("test_output/test_grid_2x2.png", result)

        # Verify
        assert result.shape[0] == image.shape[0] * 2
        assert result.shape[1] == image.shape[1] * 2
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array
        assert result.dtype == np.float32

    def test_hstack_with_real_image(self):
        """Horizontal concatenation with real image"""
        from scopeon import ScopeGrid, Waveform

        os.makedirs("test_output", exist_ok=True)

        with px.Device(0):
            # Read real image (as CuPy array)
            cp_image = px.imread("example/example.png")

            # Convert to NumPy array
            image = px.to_numpy(cp_image)

            # Generate Waveform
            waveform = Waveform()
            wf = waveform.get(image, vertical=False)

            # Horizontal concatenation: Original | Waveform
            result = ScopeGrid.hstack(image, wf)

            # Save as image
            px.imwrite("test_output/test_grid_hstack.png", result)

        # Verify
        assert result.shape[0] == image.shape[0]
        assert result.shape[1] == image.shape[1] * 2
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array

    def test_vstack_with_real_image(self):
        """Vertical concatenation with real image"""
        from scopeon import ScopeGrid, VectorScope

        os.makedirs("test_output", exist_ok=True)

        with px.Device(0):
            # Read real image (as CuPy array)
            cp_image = px.imread("example/example.png")

            # Convert to NumPy array
            image = px.to_numpy(cp_image)

            # Generate VectorScope
            vectorscope = VectorScope()
            vs = vectorscope.get(image)

            # Vertical concatenation: Original image above VectorScope
            result = ScopeGrid.vstack(image, vs)

            # Save as image
            px.imwrite("test_output/test_grid_vstack.png", result)

        # Verify
        assert result.shape[0] == image.shape[0] * 2
        assert result.shape[1] == image.shape[1]
        assert isinstance(result, cp.ndarray)  # Now always returns CuPy array


class TestScopeGridPerformance:
    """Performance tests for ScopeGrid 2x2 layout"""

    def test_performance_full_hd_4scopes(self):
        """Performance test for 4-scope 2x2 layout with Full HD (300 iterations average)"""
        from scopeon import Histogram, ScopeGrid, VectorScope, Waveform

        # Generate Full HD random image
        height, width = 1080, 1920
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create scope instances
        wf = Waveform()
        vs = VectorScope()
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # First run (to exclude graticule generation)
        wf_image = wf.get(image)
        vs_image = vs.get(image)
        hist_image = hist.get(image)
        ScopeGrid.grid_2x2(image, hist_image, wf_image, vs_image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            # Generate all scopes
            wf_image = wf.get(image)
            vs_image = vs.get(image)
            hist_image = hist.get(image)
            # Compose 2x2 grid
            result = ScopeGrid.grid_2x2(image, hist_image, wf_image, vs_image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\nFull HD (1920x1080) 4-scope grid performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")
        print(f"  Layout: Original | Histogram")
        print(f"          Waveform | VectorScope")

        # Verify results
        assert result.shape == (height * 2, width * 2, 3)
        # Total processing time (within 500ms)
        assert avg_time < 500.0, f"Full HD 4-scope processing too slow: {avg_time:.2f}ms > 500ms"

    def test_performance_4k_4scopes(self):
        """Performance test for 4-scope 2x2 layout with 4K (300 iterations average)"""
        from scopeon import Histogram, ScopeGrid, VectorScope, Waveform

        # Generate 4K random image
        height, width = 2160, 3840
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create scope instances
        wf = Waveform()
        vs = VectorScope()
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # First run (to exclude graticule generation)
        wf_image = wf.get(image)
        vs_image = vs.get(image)
        hist_image = hist.get(image)
        ScopeGrid.grid_2x2(image, hist_image, wf_image, vs_image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            # Generate all scopes
            wf_image = wf.get(image)
            vs_image = vs.get(image)
            hist_image = hist.get(image)
            # Compose 2x2 grid
            result = ScopeGrid.grid_2x2(image, hist_image, wf_image, vs_image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\n4K (3840x2160) 4-scope grid performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")
        print(f"  Layout: Original | Histogram")
        print(f"          Waveform | VectorScope")

        # Verify results
        assert result.shape == (height * 2, width * 2, 3)
        # Total processing time (within 1500ms)
        assert avg_time < 1500.0, f"4K 4-scope processing too slow: {avg_time:.2f}ms > 1500ms"
