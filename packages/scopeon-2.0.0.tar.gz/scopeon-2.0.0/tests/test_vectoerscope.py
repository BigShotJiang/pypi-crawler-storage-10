import cupy as cp
import numpy as np
import pixtreme as px
import os

import scopeon as sf


def test_vectorscope():
    os.makedirs("test_output", exist_ok=True)

    with px.Device(0):
        cp_image = px.imread("example/example.png")
        print(f"cp_image.shape: {cp_image.shape}")
        px.imwrite("test_output/vectorscope_00_input.png", cp_image)

        scope = sf.VectorScope()

        result = scope.get(cp_image)
        px.imwrite("test_output/vectorscope_01_result.png", result)


class TestVectorScopePerformance:
    """Performance tests for VectorScope processing"""

    def test_performance_full_hd(self):
        """Processing time test with Full HD image (1920x1080) - 300 iterations average"""
        from scopeon import VectorScope

        # Generate Full HD random image
        height, width = 1080, 1920
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create VectorScope instance
        vs = VectorScope()

        # First run (to exclude graticule generation)
        vs.get(image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            result = vs.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\nFull HD (1920x1080) VectorScope performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")

        # Verify results
        assert result.shape == (height, width, 3)
        # Processing time after graticule caching (within 500ms)
        assert avg_time < 500.0, f"Full HD processing too slow: {avg_time:.2f}ms > 500ms"

    def test_performance_4k(self):
        """Processing time test with 4K image (3840x2160) - 300 iterations average"""
        from scopeon import VectorScope

        # Generate 4K random image
        height, width = 2160, 3840
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create VectorScope instance
        vs = VectorScope()

        # First run (to exclude graticule generation)
        vs.get(image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            result = vs.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\n4K (3840x2160) VectorScope performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")

        # Verify results
        assert result.shape == (height, width, 3)
        # Processing time after graticule caching (within 1500ms)
        assert avg_time < 1500.0, f"4K processing too slow: {avg_time:.2f}ms > 1500ms"

    def test_graticule_caching_effect(self):
        """Test graticule caching effect (verify 2nd+ runs are faster)"""
        from scopeon import VectorScope

        # Generate Full HD random image
        height, width = 1080, 1920
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create VectorScope instance
        vs = VectorScope()

        # First run (with graticule generation)
        start = cp.cuda.Event()
        end = cp.cuda.Event()

        start.record()
        vs.get(image)
        end.record()
        end.synchronize()

        first_time = cp.cuda.get_elapsed_time(start, end)

        # Subsequent runs (using cache)
        times = []
        for _ in range(10):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            vs.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_cached_time = sum(times) / len(times)

        print(f"\nVectorScope caching effect:")
        print(f"  First time (with graticule generation): {first_time:.2f}ms")
        print(f"  Average cached time (10 runs): {avg_cached_time:.2f}ms")
        print(f"  Speedup: {first_time / avg_cached_time:.2f}x")

        # Verify caching effect (2nd+ average is faster or equal to 1st run)
        # Caching effect may be minimal in some environments, so equal or better is OK
        assert avg_cached_time <= first_time * 1.1, (
            f"Caching not effective: first={first_time:.2f}ms, "
            f"avg_cached={avg_cached_time:.2f}ms"
        )
