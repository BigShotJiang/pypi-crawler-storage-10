"""
Test module for Histogram display functionality

Tests Histogram class and related functionality using TDD approach.
"""

from typing import Union

import cupy as cp
import numpy as np
import pixtreme as px
import pytest


class TestHistogramImport:
    """Tests for Histogram class import"""

    def test_import_histogram_class(self):
        """Verify Histogram class can be imported"""
        from scopeon import Histogram

        assert Histogram is not None
        assert callable(Histogram)


class TestHistogramComputation:
    """Tests for histogram computation functionality"""

    def test_compute_histogram_single_channel(self):
        """Verify accuracy of single-channel histogram computation"""
        from scopeon.histogram.histogram import compute_histogram_channel

        # Create synthetic image with known value distribution
        height, width = 100, 100
        channel_data = cp.zeros((height, width), dtype=cp.float32)

        # Distribution: 0.0 at 50%, 0.5 at 30%, 1.0 at 20%
        num_pixels = height * width
        channel_data[:50, :] = 0.0  # 5000 pixels
        channel_data[50:80, :] = 0.5  # 3000 pixels
        channel_data[80:, :] = 1.0  # 2000 pixels

        num_bins = 512
        histogram = compute_histogram_channel(channel_data, num_bins, height, width)

        # Verify histogram sum matches pixel count
        assert cp.sum(histogram) == num_pixels

        # Bin 0 region (0.0) has about 5000 pixels
        assert histogram[0] == 5000

        # Bin 256 region (0.5) has about 3000 pixels
        bin_256 = int(0.5 * (num_bins - 1))
        assert histogram[bin_256] == 3000

        # Bin 511 (1.0) has about 2000 pixels
        assert histogram[num_bins - 1] == 2000

    def test_histogram_normalization(self):
        """Verify accuracy of histogram normalization"""
        from scopeon.histogram.histogram import normalize_histogram

        # Create random histogram data
        num_bins = 512
        histogram = cp.array([100, 200, 500, 300, 150], dtype=cp.int32)

        # Normalize
        normalized = normalize_histogram(histogram)

        # Verify max value is 1.0
        assert cp.max(normalized) == 1.0

        # Verify data type is float32
        assert normalized.dtype == cp.float32

        # Verify relative ratios are preserved (max value 500 becomes 1.0)
        assert normalized[2] == 1.0  # Max value 500
        assert abs(normalized[0] - 0.2) < 0.01  # 100/500 = 0.2
        assert abs(normalized[1] - 0.4) < 0.01  # 200/500 = 0.4


class TestHistogramEndToEnd:
    """End-to-end tests for Histogram class"""

    def test_histogram_basic_usage(self):
        """Verify basic usage of Histogram class"""
        from scopeon import Histogram

        # Create sample image (100x100 random image)
        height, width = 100, 100
        image_bgr = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create Histogram instance
        hist = Histogram(num_bins=512, show_indicator=False, layout="vertical")

        # Generate histogram image
        result = hist.get(image_bgr)

        # Verify output size matches input size
        assert result.shape == image_bgr.shape

        # Verify output is CuPy array (CuPy input → CuPy output)
        assert isinstance(result, cp.ndarray)

    def test_histogram_numpy_input(self):
        """Verify type handling with NumPy array input"""
        from scopeon import Histogram

        # Create sample image with NumPy array
        height, width = 100, 100
        image_bgr = np.random.rand(height, width, 3).astype(np.float32)

        # Create Histogram instance
        hist = Histogram(num_bins=256, show_indicator=False)

        # Generate histogram image
        result = hist.get(image_bgr)

        # Verify output is CuPy array (always CuPy output regardless of input)
        assert isinstance(result, cp.ndarray)

        # Verify output size matches input size
        assert result.shape == image_bgr.shape


class TestHistogramWithRealImage:
    """Histogram tests with real images"""

    def test_histogram_vertical_layout(self):
        """Real image test with vertical layout"""
        from scopeon import Histogram

        # Read real image
        image = px.imread("example/example.png")
        image = px.to_float32(image)

        # Create Histogram instance (vertical)
        hist = Histogram(num_bins=512, show_indicator=True, layout="vertical")

        # Generate histogram image
        result = hist.get(image)

        # Save to test_output/
        px.imwrite("test_output/histogram_vertical.png", result)

        # Verify size matches
        assert result.shape == image.shape

    def test_histogram_horizontal_layout(self):
        """Real image test with horizontal layout"""
        from scopeon import Histogram

        # Read real image
        image = px.imread("example/example.png")
        image = px.to_float32(image)

        # Create Histogram instance (horizontal)
        hist = Histogram(num_bins=512, show_indicator=True, layout="horizontal")

        # Generate histogram image
        result = hist.get(image)

        # Save to test_output/
        px.imwrite("test_output/histogram_horizontal.png", result)

        # Verify size matches
        assert result.shape == image.shape

    def test_histogram_overlay_layout(self):
        """Real image test with overlay layout"""
        from scopeon import Histogram

        # Read real image
        image = px.imread("example/example.png")
        image = px.to_float32(image)

        # Create Histogram instance (overlay)
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # Generate histogram image
        result = hist.get(image)

        # Save to test_output/
        px.imwrite("test_output/histogram_overlay.png", result)

        # Verify size matches
        assert result.shape == image.shape


class TestScopeGridIntegration:
    """ScopeGrid integration tests"""

    def test_scopegrid_grid_2x2_with_histogram(self):
        """4-pane layout including Histogram with grid_2x2"""
        from scopeon import Histogram, ScopeGrid, VectorScope, Waveform

        # Read real image
        image = px.imread("example/example.png")
        image = px.to_float32(image)

        # Generate each scope
        wf = Waveform()
        vs = VectorScope()
        hist = Histogram(num_bins=512, show_indicator=True, layout="vertical")

        wf_image = wf.get(image, vertical=True)
        vs_image = vs.get(image)
        hist_image = hist.get(image)

        # Compose 2x2 grid
        result = ScopeGrid.grid_2x2(image, wf_image, vs_image, hist_image)

        # Save to test_output/
        px.imwrite("test_output/histogram_grid_2x2.png", result)

        # Verify size is 2x2 grid (height and width doubled)
        assert result.shape[0] == image.shape[0] * 2
        assert result.shape[1] == image.shape[1] * 2

    def test_scopegrid_hstack_with_histogram(self):
        """Horizontal concatenation including Histogram with hstack"""
        from scopeon import Histogram, ScopeGrid

        # Read real image
        image = px.imread("example/example.png")
        image = px.to_float32(image)

        # Generate Histograms with different layouts
        hist_v = Histogram(num_bins=256, show_indicator=False, layout="vertical")
        hist_h = Histogram(num_bins=256, show_indicator=False, layout="horizontal")
        hist_o = Histogram(num_bins=256, show_indicator=False, layout="overlay")

        hist_v_image = hist_v.get(image)
        hist_h_image = hist_h.get(image)
        hist_o_image = hist_o.get(image)

        # Horizontal concatenation
        result = ScopeGrid.hstack(hist_v_image, hist_h_image, hist_o_image)

        # Save to test_output/
        px.imwrite("test_output/histogram_hstack.png", result)

        # Verify width is tripled
        assert result.shape[0] == image.shape[0]
        assert result.shape[1] == image.shape[1] * 3


class TestHistogramPerformance:
    """Performance tests for Histogram processing"""

    def test_performance_full_hd(self):
        """Processing time test with Full HD image (1920x1080) - 300 iterations average"""
        from scopeon import Histogram

        # Generate Full HD random image
        height, width = 1080, 1920
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create Histogram instance
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # First run (to exclude graticule generation)
        hist.get(image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            result = hist.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\nFull HD (1920x1080) performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")

        # Verify results
        assert result.shape == (height, width, 3)
        # Processing time after graticule caching (within 500ms)
        assert avg_time < 500.0, f"Full HD processing too slow: {avg_time:.2f}ms > 500ms"

    def test_performance_4k(self):
        """Processing time test with 4K image (3840x2160) - 300 iterations average"""
        from scopeon import Histogram

        # Generate 4K random image
        height, width = 2160, 3840
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create Histogram instance
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # First run (to exclude graticule generation)
        hist.get(image)

        # Measure GPU processing time (300 iterations)
        num_iterations = 300
        times = []
        for _ in range(num_iterations):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            result = hist.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_time = sum(times) / len(times)
        fps = 1000.0 / avg_time if avg_time > 0 else 0

        print(f"\n4K (3840x2160) performance:")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  FPS: {fps:.2f}")
        print(f"  Iterations: {num_iterations}")

        # Verify results
        assert result.shape == (height, width, 3)
        # Processing time after graticule caching (within 1500ms)
        assert avg_time < 1500.0, f"4K processing too slow: {avg_time:.2f}ms > 1500ms"

    def test_graticule_caching_effect(self):
        """Test graticule caching effect (verify 2nd+ runs are faster)"""
        from scopeon import Histogram

        # Generate Full HD random image
        height, width = 1080, 1920
        image = cp.random.rand(height, width, 3).astype(cp.float32)

        # Create Histogram instance
        hist = Histogram(num_bins=512, show_indicator=True, layout="overlay")

        # First run (with graticule generation)
        start = cp.cuda.Event()
        end = cp.cuda.Event()

        start.record()
        hist.get(image)
        end.record()
        end.synchronize()

        first_time = cp.cuda.get_elapsed_time(start, end)

        # Subsequent runs (using cache)
        times = []
        for _ in range(10):
            start = cp.cuda.Event()
            end = cp.cuda.Event()

            start.record()
            hist.get(image)
            end.record()
            end.synchronize()

            elapsed_ms = cp.cuda.get_elapsed_time(start, end)
            times.append(elapsed_ms)

        avg_cached_time = sum(times) / len(times)

        print(f"\nFirst time (with graticule generation): {first_time:.2f}ms")
        print(f"Average cached time (10 runs): {avg_cached_time:.2f}ms")
        print(f"Speedup: {first_time / avg_cached_time:.2f}x")

        # Verify caching effect (2nd+ average is faster or equal to 1st run)
        # Caching effect may be minimal in some environments, so equal or better is OK
        assert avg_cached_time <= first_time * 1.1, (
            f"Caching not effective: first={first_time:.2f}ms, "
            f"avg_cached={avg_cached_time:.2f}ms"
        )
