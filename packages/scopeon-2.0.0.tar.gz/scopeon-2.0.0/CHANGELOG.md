# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-10-27

### Added
- **Waveform Scope**: Brightness distribution visualization with parade and overlay modes
- **VectorScope**: Color distribution and saturation analysis
- **Histogram**: RGB histogram visualization with vertical, horizontal, and overlay layouts
- **ScopeGrid**: Flexible image composition utility (grid_2x2, hstack, vstack)
- GPU-accelerated processing using CuPy CUDA kernels
- Graticule (grid lines and labels) for all scopes with caching
- Comprehensive test suite (36 tests: 25 functional + 11 performance)

### Performance
- **VectorScope**: 321 FPS (Full HD), 83 FPS (4K)
- **Histogram**: 315 FPS (Full HD), 108 FPS (4K)
- **Waveform**: 247 FPS (Full HD), 57 FPS (4K)
- **ScopeGrid (2×2)**: 93 FPS (Full HD), 24 FPS (4K)

### Technical Details
- Build System: hatchling (PEP 517/518 compliant)
- Version Management: Manual version control
- Python Support: 3.12+
- CUDA Support: 12.x
- Dependencies: CuPy, NumPy, OpenCV, pixtreme

### Notes
- First stable release
- Beta status (Development Status: 4 - Beta)
- Production-ready for image and video analysis workflows

[1.0.0]: https://github.com/sync-dev-org/scopeon/releases/tag/v1.0.0
