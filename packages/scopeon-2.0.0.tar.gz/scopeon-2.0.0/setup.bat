@echo off
cd /d %~dp0
set WORKING_DIR=%~dp0
echo WORKING_DIR %WORKING_DIR%

if exist venv (
    echo venv exists
) else (
    echo venv does not exist
    py -3.12 -m venv venv
)

call venv\Scripts\activate

python --version
for /f "delims=" %%i in ('python -c "import sys; print(sys.executable)"') do set TEMP_PYTHON_PATH=%%i
echo TEMP_PYTHON_PATH %TEMP_PYTHON_PATH%
echo VIRTUAL_ENV %VIRTUAL_ENV%

if "%TEMP_PYTHON_PATH%" == "%VIRTUAL_ENV%\Scripts\python.exe" (
    echo Inside venv
    python -m pip install --upgrade pip
    python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
    python -m pip install -r requirements.txt
    python -m pip install pytest
    python -m pip install -e .
) else (
    echo Not inside venv
    echo Perhaps you called from within venv?
    echo Please remove venv and try again.
)
