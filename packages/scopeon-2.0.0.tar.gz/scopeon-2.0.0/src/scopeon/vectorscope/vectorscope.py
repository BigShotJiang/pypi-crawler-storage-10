from typing import Union

import cupy as cp
import numpy as np
import pixtreme as px

from .indicator import vectorscope_indicator


def plot(image: cp.ndarray, scope_size: int) -> cp.ndarray:
    image_rgb = image
    image_ycbcr = px.rgb_to_ycbcr(image_rgb)

    height, width, _ = image_rgb.shape
    image_scope = cp.zeros((scope_size, scope_size, 3), dtype=cp.float32)

    block_size = (16, 16, 1)
    grid_size = ((width + block_size[0] - 1) // block_size[0], (height + block_size[1] - 1) // block_size[1])

    vectorscope_kernel(
        grid_size,
        block_size,
        (image_rgb.ravel(), image_ycbcr.ravel(), image_scope, width, height, scope_size),
    )

    return image_scope


def plot_cp(image: cp.ndarray, scope_size: int) -> cp.ndarray:
    image_rgb = image
    image_ycbcr = px.rgb_to_ycbcr(image_rgb)

    height, width, _ = image_rgb.shape
    num_pixels = width * height

    # Extract Cb and Cr from YCbCr, shift center by 0.5, and scale saturation
    scale = 0.75
    cb = (image_ycbcr[:, :, 1].flatten() - 0.5) * scale
    cr = (image_ycbcr[:, :, 2].flatten() - 0.5) * scale

    # Calculate x, y coordinates from CbCr
    x = ((cb * scope_size) + (scope_size / 2)).astype(cp.int32)
    x = cp.clip(x, 0, scope_size - 1).astype(cp.int32)

    y = ((cr * scope_size) + (scope_size / 2)).astype(cp.int32)
    y = cp.clip(y, 0, scope_size - 1).astype(cp.int32)
    y = scope_size - y - 1  # Flip Y coordinate

    # Initialize vectorscope image
    image_scope = cp.zeros((scope_size, scope_size, 3), dtype=cp.float32)

    # Create pixel index array
    pixel_indices = cp.arange(num_pixels)

    # For each pixel, add RGB values to appropriate positions on vectorscope
    for i in range(3):  # Process each RGB channel
        # Get channel values from flattened RGB
        rgb_values = image_rgb.reshape(-1, 3)[:, i]

        # Use add.at to add RGB values at calculated (x, y) positions
        cp.add.at(image_scope, (y[pixel_indices], x[pixel_indices], cp.full(num_pixels, i, dtype=cp.int32)), rgb_values)

    return image_scope


class VectorScope:
    def __init__(self, show_indicator: bool = True, padding: bool = True) -> None:
        self.scope_size = 0
        self.indicator = None
        self.show_indicator = show_indicator
        self.padding = padding
        self.stream = cp.cuda.Stream(non_blocking=True)

    def get(self, image: Union[np.ndarray, cp.ndarray]) -> cp.ndarray:
        """
        Vectorscope

        Parameters
        ----------
        image : Union[np.ndarray, cp.ndarray]
            Input frame. Shape 3D array (height, width, 3) in BGR 4:4:4 format.

        Returns
        -------
        cp.ndarray
            Vectorscope. Shape 3D array (height, width, 3) in BGR 4:4:4 format.
        """
        # Convert to CuPy if NumPy
        if isinstance(image, np.ndarray):
            image = px.to_cupy(image)

        image = px.to_float32(image)
        image_rgb = px.bgr_to_rgb(image)
        height, width, _ = image_rgb.shape

        self.initialize(image_rgb)
        image_scope = plot(image_rgb, self.scope_size)
        image_scope = self.finalize(image_scope, height, width)
        image_scope = px.rgb_to_bgr(image_scope)

        # Always return CuPy array
        return image_scope

    def initialize(self, image: cp.ndarray) -> None:
        if self.show_indicator:
            if self.indicator is None or self.scope_size != image.shape[0]:
                self.scope_size = image.shape[0]
                self.indicator = vectorscope_indicator(image)
        return

    def finalize(self, image_scope: cp.ndarray, height: int, width: int) -> cp.ndarray:
        image_scope /= 1024.0
        image_scope = cp.power(image_scope, 1.0 / 2.4)
        image_scope_hsv = px.rgb_to_hsv(image_scope)
        image_scope_hsv[:, :, 1] *= 3.0
        image_scope_hsv[:, :, 2] *= 3.0
        image_scope = px.hsv_to_rgb(image_scope_hsv)

        if self.show_indicator:
            image_scope = cp.add(image_scope, self.indicator)

        if self.padding:
            pad_y = max(0, height - self.scope_size) // 2
            pad_x = max(0, width - self.scope_size) // 2
            pad_y_top = height - self.scope_size - pad_y
            pad_x_left = width - self.scope_size - pad_x
            pad_y_bottom = height - self.scope_size - pad_y_top
            pad_x_right = width - self.scope_size - pad_x_left

            pad_y_top = max(0, pad_y_top)
            pad_x_left = max(0, pad_x_left)
            pad_y_bottom = max(0, pad_y_bottom)
            pad_x_right = max(0, pad_x_right)

            image_scope = cp.pad(
                image_scope,
                (
                    (pad_y_top, pad_y_bottom),
                    (pad_x_left, pad_x_right),
                    (0, 0),
                ),
                mode="constant",
                constant_values=0,
            )

        image_scope = cp.clip(image_scope, 0, 1.0)

        return image_scope


_vectorscope_kernel_code = """
extern "C" __global__
void vectorscope_kernel(const float* ycbcr, const float* rgb, float* vectorscope, int frame_size, int num_pixels) {
    __shared__ float sharedYCbCr[1024 * 3];

    int idx = blockDim.x * blockIdx.x + threadIdx.x;
    int thread_idx = threadIdx.x;

    if (idx >= num_pixels) return;

    sharedYCbCr[thread_idx * 3] = ycbcr[idx * 3];
    sharedYCbCr[thread_idx * 3 + 1] = ycbcr[idx * 3 + 1] - 0.5;
    sharedYCbCr[thread_idx * 3 + 2] = ycbcr[idx * 3 + 2] - 0.5;

    __syncthreads();

    float cb = sharedYCbCr[thread_idx * 3 + 1];
    float cr = sharedYCbCr[thread_idx * 3 + 2];

    //float hue_angle = atan2f(cb, cr);
    float hue_angle = atan2f(cr, cb);
    float saturation = hypotf(cb, cr) * 1.5;

    float cos_hue_angle, sin_hue_angle;
    __sincosf(hue_angle, &sin_hue_angle, &cos_hue_angle);

    int x = static_cast<int>((saturation * cos_hue_angle * (frame_size / 2)) + (frame_size / 2));
    int y = static_cast<int>((saturation * sin_hue_angle * (frame_size / 2)) + (frame_size / 2));

    //x = frame_size - max(0, min(x, frame_size - 1)) - 1;
    x = max(0, min(x, frame_size - 1));
    y = frame_size - max(0, min(y, frame_size - 1)) - 1;
    //y = max(0, min(y, frame_size - 1));

    atomicAdd(&vectorscope[(y * frame_size + x) * 3], rgb[idx * 3]);
    atomicAdd(&vectorscope[(y * frame_size + x) * 3 + 1], rgb[idx * 3 + 1]);
    atomicAdd(&vectorscope[(y * frame_size + x) * 3 + 2], rgb[idx * 3 + 2]);
}
"""

vectorscope_kernel_code = """
__constant__ float scale_factor = 0.75;
__constant__ float offset = 0.5;

extern "C" __global__
void vectorscope_kernel(const float* frame_rgb, const float* frame_ycbcr, float* vectorscope,
                      int width, int height, int scope_size) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;

    int idx = (y * width + x) * 3; // Index for the flat input arrays
    int cb = static_cast<int>(((frame_ycbcr[idx + 1] - offset) * scale_factor + offset) * scope_size);
    int cr = static_cast<int>(((frame_ycbcr[idx + 2] - offset) * scale_factor + offset) * scope_size);

    // Clip cb and cr to the scope size
    cb = min(max(cb, 0), scope_size - 1);
    cr = scope_size - 1 - min(max(cr, 0), scope_size - 1); // Flip Y coordinate

    // Calculate the index for the vectorscope, preventing out-of-bounds memory access
    int scope_idx = (cr * scope_size + cb) * 3;
    if (scope_idx >= 0 && scope_idx < scope_size * scope_size * 3) {
        atomicAdd(&vectorscope[scope_idx], frame_rgb[idx]);     // R channel
        atomicAdd(&vectorscope[scope_idx + 1], frame_rgb[idx + 1]); // G channel
        atomicAdd(&vectorscope[scope_idx + 2], frame_rgb[idx + 2]); // B channel
    }
}
"""
vectorscope_kernel = cp.RawKernel(vectorscope_kernel_code, "vectorscope_kernel")
