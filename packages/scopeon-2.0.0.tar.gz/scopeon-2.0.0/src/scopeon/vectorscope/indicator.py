import cupy as cp
import cv2
import numpy as np
import pixtreme as px


def vectorscope_indicator(frame_rgb: cp.ndarray) -> cp.ndarray:
    # Draw Circle and Cross
    scope_size = frame_rgb.shape[0]
    draw_size = scope_size * 8
    indicator = np.zeros((draw_size, draw_size, 3), dtype=np.float32)
    limit_factor = 0.99
    center = (indicator.shape[1] // 2, indicator.shape[0] // 2)
    top = (center[0], int(indicator.shape[0] - indicator.shape[0] * limit_factor))
    bottom = (center[0], int(indicator.shape[0] * limit_factor))
    left = (int(indicator.shape[1] - indicator.shape[1] * limit_factor), center[1])
    right = (int(indicator.shape[1] * limit_factor), center[1])
    radius = int(indicator.shape[0] * limit_factor) // 2

    color_positions = {
        "100": {
            "true_red": {
                "point": (0.4037037, 0.08240741),
                "title": "R",
            },
            "true_yellow": {
                "point": (0.08240741, 0.46111111),
                "title": "Y",
            },
            "true_green": {
                "point": (0.1787037, 0.87777778),
                "title": "G",
            },
            "true_cyan": {
                "point": (0.59537037, 0.91666667),
                "title": "C",
            },
            "true_blue": {
                "point": (0.91666667, 0.53796296),
                "title": "B",
            },
            "true_magenta": {
                "point": (0.82037037, 0.1212963),
                "title": "M",
            },
        },
        "75": {
            "red": {
                "point": (0.42777778, 0.18703704),
                "title": "R",
            },
            "yellow": {
                "point": (0.18703704, 0.4712963),
                "title": "Y",
            },
            "green": {
                "point": (0.25833333, 0.78333333),
                "title": "G",
            },
            "cyan": {
                "point": (0.5712963, 0.81203704),
                "title": "C",
            },
            "blue": {
                "point": (0.81203704, 0.52777778),
                "title": "B",
            },
            "magenta": {
                "point": (0.74074074, 0.21574074),
                "title": "M",
            },
        },
    }

    rectangle_size = int(indicator.shape[0] * 0.02)
    cross_size = int(indicator.shape[0] * 0.04)
    line_color = (0.3, 0.2, 0.0)
    dark_line_color = (0.3, 0.2, 0.0)
    thickness = scope_size // 50

    # Draw Color Positions
    for color_range in color_positions:
        start_point = (0, 0)
        previos_point = (0, 0)
        for i, color_name in enumerate(color_positions[color_range]):
            color_position = color_positions[color_range][color_name]["point"]
            color_title = color_positions[color_range][color_name]["title"]
            color_point = (
                int(indicator.shape[1] * color_position[0]),
                int(indicator.shape[0] * color_position[1]),
            )
            cv2.putText(
                img=indicator,
                text=color_title,
                org=(color_point[0] + rectangle_size, color_point[1] + (rectangle_size * 2)),
                fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                fontScale=rectangle_size / 30,
                color=dark_line_color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )  # type: ignore[call-overload]
            cv2.rectangle(
                img=indicator,
                pt1=(color_point[0] - rectangle_size, color_point[1] - rectangle_size),
                pt2=(color_point[0] + rectangle_size, color_point[1] + rectangle_size),
                color=dark_line_color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )
            cv2.line(
                img=indicator,
                pt1=(color_point[0] - cross_size, color_point[1]),
                pt2=(color_point[0] + cross_size, color_point[1]),
                color=dark_line_color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )
            cv2.line(
                img=indicator,
                pt1=(color_point[0], color_point[1] - cross_size),
                pt2=(color_point[0], color_point[1] + cross_size),
                color=dark_line_color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )
            if i > 0:
                cv2.line(
                    img=indicator,
                    pt1=previos_point,
                    pt2=color_point,
                    color=dark_line_color,
                    thickness=thickness,
                    lineType=cv2.LINE_AA,
                )
            else:
                start_point = color_point
            if i == len(color_positions[color_range]) - 1:
                cv2.line(
                    img=indicator,
                    pt1=color_point,
                    pt2=start_point,
                    color=dark_line_color,
                    thickness=thickness,
                    lineType=cv2.LINE_AA,
                )
            previos_point = color_point

    # Draw Circle and Cross
    cv2.circle(
        img=indicator,
        center=center,
        radius=radius,
        color=line_color,
        thickness=thickness,
        lineType=cv2.LINE_AA,
    )
    cv2.line(
        img=indicator,
        pt1=(left),
        pt2=(right),
        color=line_color,
        thickness=thickness,
        lineType=cv2.LINE_AA,
    )
    cv2.line(
        img=indicator,
        pt1=(top),
        pt2=(bottom),
        color=line_color,
        thickness=thickness,
        lineType=cv2.LINE_AA,
    )

    border_size = int((draw_size * 0.1) // 2)
    indicator = cv2.copyMakeBorder(
        src=indicator,
        top=border_size,
        bottom=border_size,
        left=border_size,
        right=border_size,
        borderType=cv2.BORDER_CONSTANT,
        value=(0, 0, 0),
    )

    indicator = px.to_cupy(indicator)
    indicator = px.resize(indicator, (scope_size, scope_size), interpolation=px.INTER_AREA)

    return indicator
