"""
Histogram graticule (grid lines) generation module

Generates graticule images using the same pattern as Waveform and VectorScope.
"""

from typing import Tuple

import cupy as cp
import cv2
import numpy as np
import pixtreme as px


def histogram_indicator(scope_size: Tuple[int, int, int]) -> cp.ndarray:
    """
    Generate graticule image for histogram

    Parameters:
        scope_size: Image size (height, width, 3)

    Returns:
        Graticule image (shape: scope_size, float32)
    """
    height, width, _ = scope_size

    # Draw at high resolution (adaptive scale factor based on image size)
    # Full HD and below: 16x, 4K: 4x (to prevent CUDA memory issues)
    total_pixels = height * width
    if total_pixels > 1920 * 1080:  # Larger than Full HD
        scale_factor = 4
    else:
        scale_factor = 16
    draw_size = (height * scale_factor, width * scale_factor, 3)
    indicator = np.zeros(draw_size, dtype=np.float32)

    shorter_side = min(height, width)
    line_color = (0.5, 0.35, 0.0)  # Use bright color (same as Waveform's bright_line_color)
    thickness = shorter_side // 40
    font_scale = thickness // 2  # Same as Waveform

    # Vertical axis labels (frequency: 0%, 25%, 50%, 75%, 100%)
    for i, percent in enumerate([100, 75, 50, 25, 0]):
        # Y coordinate (top to bottom)
        y = int((i / 4) * (draw_size[0] - 1))

        # Draw horizontal line
        cv2.line(indicator, (0, y), (draw_size[1], y), line_color, thickness)

        # Draw label (baseline consideration: top line goes below, others go above)
        title = f"{percent}%"
        title_y = y - int(thickness * 8) if i != 0 else y + int(thickness * 16)
        cv2.putText(
            img=indicator,
            text=title,
            org=(thickness // 8, title_y),
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=font_scale,
            color=line_color,
            thickness=int(thickness * 1.5),
            lineType=cv2.LINE_AA,
        )

    # Horizontal axis: vertical lines (luminance: 0, 256, 512, 768, 1023 - 10bit)
    for i in range(5):
        # X coordinate (left to right)
        x = int((i / 4) * (draw_size[1] - 1))
        # Draw vertical line
        cv2.line(indicator, (x, 0), (x, draw_size[0]), line_color, thickness)

    # Horizontal axis labels (luminance: 256, 512, 768, 1023 - omit 0 to avoid overlap with 100%)
    for i, luminance in enumerate([256, 512, 768, 1023]):
        # X coordinate (left to right)
        x = int(((i + 1) / 4) * (draw_size[1] - 1))

        # Draw label near the vertical line, at the top
        title = str(luminance)
        # Position label slightly offset from the line, ensuring it stays within bounds
        # Use small offset like Waveform uses for its vertical labels
        title_x = x + int(thickness // 4)
        # Position at top with enough space below the edge
        title_y = int(thickness * 20)
        cv2.putText(
            img=indicator,
            text=title,
            org=(title_x, title_y),
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=font_scale,
            color=line_color,
            thickness=int(thickness * 1.5),
            lineType=cv2.LINE_AA,
        )

    # Convert to CuPy array and resize (anti-aliasing)
    indicator = px.to_cupy(indicator)
    assert indicator is not None
    indicator = px.resize(indicator, (width, height), interpolation=px.INTER_AREA)

    return indicator
