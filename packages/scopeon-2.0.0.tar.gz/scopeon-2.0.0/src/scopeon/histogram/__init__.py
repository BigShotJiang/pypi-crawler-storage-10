"""
Histogram display module

Generates RGB channel histograms with GPU acceleration for high-speed processing.
"""

from .histogram import Histogram

__all__ = ["Histogram"]
