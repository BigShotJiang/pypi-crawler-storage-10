"""
Histogram class - RGB channel histogram display

A stateful scope class following the same architectural pattern
as Waveform and VectorScope.
"""

from typing import Literal, Tuple, Union

import cupy as cp
import numpy as np
import pixtreme as px

from .indicator import histogram_indicator


# CUDA kernel: Histogram computation (Atomic Add method)
histogram_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void histogram_kernel(const float* channel_data, int* histogram,
                      int width, int height, int num_bins) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;

    int idx = y * width + x;
    float value = channel_data[idx];  // [0.0, 1.0]

    // Calculate bin index
    int bin = static_cast<int>(value * (num_bins - 1));
    bin = max(0, min(num_bins - 1, bin));

    // Update histogram with Atomic Add
    atomicAdd(&histogram[bin], 1);
}
""",
    "histogram_kernel",
)


# CUDA kernel: Draw histogram bar chart
draw_histogram_bar_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void draw_histogram_bar_kernel(const float *histogram_data, const float *color,
                                float *output, int width, int height, int num_bins) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;

    // Calculate bin index from x coordinate
    int bin_idx = static_cast<int>((float)x / width * num_bins);
    if (bin_idx >= num_bins) bin_idx = num_bins - 1;

    // Get histogram value
    float bar_height = histogram_data[bin_idx];

    // Check if pixel is within drawing range based on y coordinate
    float y_normalized = 1.0f - (float)y / height;

    if (y_normalized <= bar_height) {
        // Set color if within drawing range
        int idx = (y * width + x) * 3;
        output[idx + 0] = color[0];
        output[idx + 1] = color[1];
        output[idx + 2] = color[2];
    }
}
""",
    "draw_histogram_bar_kernel",
)


def compute_histogram_channel(
    channel_data: cp.ndarray, num_bins: int, height: int, width: int
) -> cp.ndarray:
    """
    Compute histogram for a single channel

    Parameters:
        channel_data: Channel data (shape: (height, width), float32)
        num_bins: Number of bins
        height: Image height
        width: Image width

    Returns:
        Histogram data (shape: (num_bins,), int32)
    """
    # Initialize histogram array
    histogram = cp.zeros(num_bins, dtype=cp.int32)

    # Execute CUDA kernel
    block_dim = (16, 16)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    histogram_kernel(grid_dim, block_dim, (channel_data, histogram, width, height, num_bins))

    return histogram


def normalize_histogram(histogram: cp.ndarray) -> cp.ndarray:
    """
    Normalize histogram data (maximum value to 1.0)

    Parameters:
        histogram: Histogram data (shape: (num_bins,), int32)

    Returns:
        Normalized histogram data (shape: (num_bins,), float32)
    """
    # Convert to float32
    histogram_float = histogram.astype(cp.float32)

    # Normalize by maximum value
    max_value = cp.max(histogram_float)
    if max_value > 0:
        histogram_float /= max_value

    return histogram_float


def draw_histogram_bar(
    histogram_data: cp.ndarray, color: cp.ndarray, scope_size: Tuple[int, int, int], num_bins: int
) -> cp.ndarray:
    """
    Draw histogram as bar chart using GPU parallel processing

    Parameters:
        histogram_data: Normalized histogram data (shape: (num_bins,), float32)
        color: Drawing color (shape: (3,), RGB, float32)
        scope_size: Output image size (height, width, 3)
        num_bins: Number of bins

    Returns:
        Bar chart image (shape: scope_size, float32)
    """
    height, width, _ = scope_size
    bar_image = cp.zeros((height, width, 3), dtype=cp.float32)

    # Execute CUDA kernel for GPU parallel drawing
    block_dim = (32, 32)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    draw_histogram_bar_kernel(
        grid_dim, block_dim, (histogram_data, color, bar_image, width, height, num_bins)
    )

    return bar_image


def plot_histogram_vertical(
    image_rgb: cp.ndarray, num_bins: int, indicator: Union[cp.ndarray, None] = None
) -> cp.ndarray:
    """
    Generate histogram image with vertical layout

    Parameters:
        image_rgb: RGB image (shape: (height, width, 3), float32)
        num_bins: Number of bins
        indicator: Graticule image (shape: (height//3, width, 3), float32)

    Returns:
        Histogram image (shape: (height, width, 3), RGB, float32)
    """
    height, width, _ = image_rgb.shape
    scope_height = height // 3
    scope_size = (scope_height, width, 3)

    # Compute histogram for each RGB channel
    r_hist = compute_histogram_channel(image_rgb[:, :, 0], num_bins, height, width)
    g_hist = compute_histogram_channel(image_rgb[:, :, 1], num_bins, height, width)
    b_hist = compute_histogram_channel(image_rgb[:, :, 2], num_bins, height, width)

    # Normalize
    r_hist_norm = normalize_histogram(r_hist)
    g_hist_norm = normalize_histogram(g_hist)
    b_hist_norm = normalize_histogram(b_hist)

    # Color definition (same as Waveform pattern)
    red_color = cp.array([0.8, 0.1, 0.1], dtype=cp.float32)
    green_color = cp.array([0.1, 0.8, 0.1], dtype=cp.float32)
    blue_color = cp.array([0.1, 0.1, 0.8], dtype=cp.float32)

    # Draw bar charts
    r_bar = draw_histogram_bar(r_hist_norm, red_color, scope_size, num_bins)
    g_bar = draw_histogram_bar(g_hist_norm, green_color, scope_size, num_bins)
    b_bar = draw_histogram_bar(b_hist_norm, blue_color, scope_size, num_bins)

    # Add graticule to each channel
    if indicator is not None:
        r_bar = cp.add(r_bar, indicator)
        g_bar = cp.add(g_bar, indicator)
        b_bar = cp.add(b_bar, indicator)
        r_bar = cp.clip(r_bar, 0.0, 1.0)
        g_bar = cp.clip(g_bar, 0.0, 1.0)
        b_bar = cp.clip(b_bar, 0.0, 1.0)

    # Concatenate vertically (same pattern as Waveform's plot_rgb_parade())
    hist_image = cp.concatenate((r_bar, g_bar, b_bar), axis=0)

    # Resize to original size
    hist_image = px.resize(hist_image, (width, height), interpolation=px.INTER_AUTO)

    return hist_image


def plot_histogram_horizontal(
    image_rgb: cp.ndarray, num_bins: int, indicator: Union[cp.ndarray, None] = None
) -> cp.ndarray:
    """
    Generate histogram image with horizontal layout

    Parameters:
        image_rgb: RGB image (shape: (height, width, 3), float32)
        num_bins: Number of bins
        indicator: Graticule image (shape: (height, width//3, 3), float32)

    Returns:
        Histogram image (shape: (height, width, 3), RGB, float32)
    """
    height, width, _ = image_rgb.shape
    scope_width = width // 3
    scope_size = (height, scope_width, 3)

    # Compute histogram for each RGB channel
    r_hist = compute_histogram_channel(image_rgb[:, :, 0], num_bins, height, width)
    g_hist = compute_histogram_channel(image_rgb[:, :, 1], num_bins, height, width)
    b_hist = compute_histogram_channel(image_rgb[:, :, 2], num_bins, height, width)

    # Normalize
    r_hist_norm = normalize_histogram(r_hist)
    g_hist_norm = normalize_histogram(g_hist)
    b_hist_norm = normalize_histogram(b_hist)

    # Color definition
    red_color = cp.array([0.8, 0.1, 0.1], dtype=cp.float32)
    green_color = cp.array([0.1, 0.8, 0.1], dtype=cp.float32)
    blue_color = cp.array([0.1, 0.1, 0.8], dtype=cp.float32)

    # Draw bar charts
    r_bar = draw_histogram_bar(r_hist_norm, red_color, scope_size, num_bins)
    g_bar = draw_histogram_bar(g_hist_norm, green_color, scope_size, num_bins)
    b_bar = draw_histogram_bar(b_hist_norm, blue_color, scope_size, num_bins)

    # Add graticule to each channel
    if indicator is not None:
        r_bar = cp.add(r_bar, indicator)
        g_bar = cp.add(g_bar, indicator)
        b_bar = cp.add(b_bar, indicator)
        r_bar = cp.clip(r_bar, 0.0, 1.0)
        g_bar = cp.clip(g_bar, 0.0, 1.0)
        b_bar = cp.clip(b_bar, 0.0, 1.0)

    # Concatenate horizontally
    hist_image = cp.concatenate((r_bar, g_bar, b_bar), axis=1)

    # Resize to original size
    hist_image = px.resize(hist_image, (width, height), interpolation=px.INTER_AUTO)

    return hist_image


def plot_histogram_overlay(
    image_rgb: cp.ndarray, num_bins: int, indicator: Union[cp.ndarray, None] = None
) -> cp.ndarray:
    """
    Generate histogram image with overlay layout

    Parameters:
        image_rgb: RGB image (shape: (height, width, 3), float32)
        num_bins: Number of bins
        indicator: Graticule image (shape: (height, width, 3), float32)

    Returns:
        Histogram image (shape: (height, width, 3), RGB, float32)
    """
    height, width, _ = image_rgb.shape
    scope_size = (height, width, 3)

    # Compute histogram for each RGB channel
    r_hist = compute_histogram_channel(image_rgb[:, :, 0], num_bins, height, width)
    g_hist = compute_histogram_channel(image_rgb[:, :, 1], num_bins, height, width)
    b_hist = compute_histogram_channel(image_rgb[:, :, 2], num_bins, height, width)

    # Normalize
    r_hist_norm = normalize_histogram(r_hist)
    g_hist_norm = normalize_histogram(g_hist)
    b_hist_norm = normalize_histogram(b_hist)

    # Color definition
    red_color = cp.array([0.8, 0.1, 0.1], dtype=cp.float32)
    green_color = cp.array([0.1, 0.8, 0.1], dtype=cp.float32)
    blue_color = cp.array([0.1, 0.1, 0.8], dtype=cp.float32)

    # Draw bar charts
    r_bar = draw_histogram_bar(r_hist_norm, red_color, scope_size, num_bins)
    g_bar = draw_histogram_bar(g_hist_norm, green_color, scope_size, num_bins)
    b_bar = draw_histogram_bar(b_hist_norm, blue_color, scope_size, num_bins)

    # Additive composition (same pattern as Waveform's plot_rgb())
    hist_image = r_bar + g_bar + b_bar

    # Add graticule
    if indicator is not None:
        hist_image = cp.add(hist_image, indicator)

    # Clipping
    hist_image = cp.clip(hist_image, 0.0, 1.0)

    return hist_image


class Histogram:
    """
    Class for generating RGB channel histograms

    Provides a unified Pythonic API consistent with Waveform and VectorScope.
    Supports real-time video processing through GPU parallel computation using CuPy RawKernel.

    Attributes:
        num_bins: Number of histogram bins
        show_indicator: Graticule display flag
        layout: Layout mode ('vertical', 'horizontal', 'overlay')
        stream: Asynchronous CUDA stream
        indicator_cache: Graticule cache per layout mode
        scope_size_cache: Scope size cache per layout mode
    """

    def __init__(
        self,
        num_bins: int = 512,
        show_indicator: bool = True,
        layout: Literal["vertical", "horizontal", "overlay"] = "vertical",
    ) -> None:
        """
        Initialize Histogram class

        Parameters:
            num_bins: Number of histogram bins (default: 512)
            show_indicator: Graticule display flag (default: True)
            layout: Layout mode (default: 'vertical')

        Raises:
            ValueError: If layout is an unsupported value
            ValueError: If num_bins is out of range
        """
        # Parameter validation
        if layout not in ["vertical", "horizontal", "overlay"]:
            raise ValueError("layout must be 'vertical', 'horizontal', or 'overlay'")
        if num_bins <= 0 or num_bins > 2048:
            raise ValueError("num_bins must be between 1 and 2048")

        self.num_bins = num_bins
        self.show_indicator = show_indicator
        self.layout = layout

        # Initialize asynchronous CUDA stream
        self.stream = cp.cuda.Stream(non_blocking=True)

        # Initialize graticule cache (per layout mode)
        self.indicator_cache: dict[str, Union[cp.ndarray, None]] = {
            "vertical": None,
            "horizontal": None,
            "overlay": None,
        }
        self.scope_size_cache: dict[str, Union[tuple[int, int, int], None]] = {
            "vertical": None,
            "horizontal": None,
            "overlay": None,
        }

    def get(self, image: Union[np.ndarray, cp.ndarray]) -> cp.ndarray:
        """
        Generate histogram image

        Parameters:
            image: BGR image (float32/uint8/uint16), shape (height, width, 3)

        Returns:
            Histogram image (BGR, cp.ndarray), shape (height, width, 3)

        Raises:
            ValueError: If image shape is invalid (2D array or 4D tensor)
        """
        # Validate image shape
        if image.ndim != 3:
            raise ValueError("Input image must be 3D array (height, width, 3)")

        # Convert to CuPy if NumPy
        if isinstance(image, np.ndarray):
            image = px.to_cupy(image)

        # Convert to float32 and BGR to RGB
        image = px.to_float32(image)
        image_rgb = px.bgr_to_rgb(image)

        # Initialize graticule (cached per layout mode)
        indicator = self._get_indicator(image_rgb)

        # Generate histogram based on layout mode
        if self.layout == "vertical":
            hist_image_rgb = plot_histogram_vertical(image_rgb, self.num_bins, indicator)
        elif self.layout == "horizontal":
            hist_image_rgb = plot_histogram_horizontal(image_rgb, self.num_bins, indicator)
        elif self.layout == "overlay":
            hist_image_rgb = plot_histogram_overlay(image_rgb, self.num_bins, indicator)
        else:
            # Default is vertical (already validated)
            hist_image_rgb = plot_histogram_vertical(image_rgb, self.num_bins, indicator)

        # Convert RGB to BGR
        hist_image_bgr = px.rgb_to_bgr(hist_image_rgb)

        # Always return CuPy array
        return hist_image_bgr

    def _get_indicator(self, image_rgb: cp.ndarray) -> Union[cp.ndarray, None]:
        """
        Get graticule (cache management)

        Parameters:
            image_rgb: RGB image (CuPy array)

        Returns:
            Graticule image (None if show_indicator is False)
        """
        if not self.show_indicator:
            return None

        height, width, _ = image_rgb.shape

        # Calculate scope size per layout mode
        if self.layout == "vertical":
            scope_size = (height // 3, width, 3)
        elif self.layout == "horizontal":
            scope_size = (height, width // 3, 3)
        else:  # overlay
            scope_size = (height, width, 3)

        # Check cache
        if self.scope_size_cache[self.layout] != scope_size:
            # Regenerate if no cache or size has changed
            self.indicator_cache[self.layout] = histogram_indicator(scope_size)
            self.scope_size_cache[self.layout] = scope_size

        return self.indicator_cache[self.layout]
