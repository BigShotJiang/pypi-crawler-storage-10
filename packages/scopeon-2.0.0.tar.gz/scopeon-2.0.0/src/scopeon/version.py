"""Version information for scopeon package."""

__version__ = "2.0.0"
__all__ = ["__version__"]
