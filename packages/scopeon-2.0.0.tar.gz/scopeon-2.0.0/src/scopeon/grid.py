"""ScopeGrid - Scope image composition utility"""
from typing import TypeAlias, Union

import cupy as cp
import numpy as np

ArrayLike: TypeAlias = Union[np.ndarray, cp.ndarray]


class ScopeGrid:
    """Scope image composition utility (static methods only)"""

    @staticmethod
    def grid_2x2(
        top_left: ArrayLike,
        top_right: ArrayLike,
        bottom_left: ArrayLike,
        bottom_right: ArrayLike
    ) -> cp.ndarray:
        """
        Compose 2x2 grid

        Parameters:
            top_left: Top-left image
            top_right: Top-right image
            bottom_left: Bottom-left image
            bottom_right: Bottom-right image

        Returns:
            Composed image (cp.ndarray)

        Raises:
            ValueError: Image size mismatch
        """
        # Convert to CuPy if NumPy
        if isinstance(top_left, np.ndarray):
            top_left = cp.asarray(top_left)
        if isinstance(top_right, np.ndarray):
            top_right = cp.asarray(top_right)
        if isinstance(bottom_left, np.ndarray):
            bottom_left = cp.asarray(bottom_left)
        if isinstance(bottom_right, np.ndarray):
            bottom_right = cp.asarray(bottom_right)

        # Horizontal concatenation for top row
        top = cp.hstack([top_left, top_right])
        # Horizontal concatenation for bottom row
        bottom = cp.hstack([bottom_left, bottom_right])
        # Vertical concatenation
        result = cp.vstack([top, bottom])

        return result

    @staticmethod
    def hstack(*images: ArrayLike) -> cp.ndarray:
        """
        Horizontal concatenation

        Parameters:
            *images: Images to concatenate (variadic)

        Returns:
            Horizontally concatenated image (cp.ndarray)
        """
        if len(images) == 0:
            raise ValueError("At least one image is required")

        # Convert to CuPy if NumPy
        images_cp = [cp.asarray(img) if isinstance(img, np.ndarray) else img for img in images]

        return cp.hstack(images_cp)

    @staticmethod
    def vstack(*images: ArrayLike) -> cp.ndarray:
        """
        Vertical concatenation

        Parameters:
            *images: Images to concatenate (variadic)

        Returns:
            Vertically concatenated image (cp.ndarray)
        """
        if len(images) == 0:
            raise ValueError("At least one image is required")

        # Convert to CuPy if NumPy
        images_cp = [cp.asarray(img) if isinstance(img, np.ndarray) else img for img in images]

        return cp.vstack(images_cp)
