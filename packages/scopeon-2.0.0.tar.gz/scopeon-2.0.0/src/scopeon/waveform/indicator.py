from typing import Tuple

import cupy as cp
import cv2
import numpy as np
import pixtreme as px


def waveform_indicator(scope_size: Tuple[int, int]) -> cp.ndarray:
    # Draw indicator with adaptive scale factor
    # Full HD and below: 16x, 4K: 4x (to prevent CUDA memory issues)
    total_pixels = scope_size[0] * scope_size[1]
    if total_pixels > 1920 * 1080:  # Larger than Full HD
        scale_factor = 4
    else:
        scale_factor = 16
    draw_size = (scope_size[0] * scale_factor, scope_size[1] * scale_factor, 3)
    indicator = np.zeros(draw_size, dtype=np.float32)
    shorter_side = min(scope_size)
    line_color = (0.25, 0.18, 0.0)
    bright_line_color = (0.5, 0.35, 0.0)
    thickness = shorter_side // 40
    font_scale = thickness // 2

    y = draw_size[0] - int(draw_size[0] * 64 / 1023)
    title_y = y - int(thickness * 8)
    cv2.line(indicator, (0, y), (draw_size[1], y), bright_line_color, thickness)
    cv2.putText(
        img=indicator,
        text="64",
        org=(thickness // 8, title_y),
        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
        fontScale=font_scale,
        color=bright_line_color,
        thickness=int(thickness * 1.5),
        lineType=cv2.LINE_AA,
    )

    y = draw_size[0] - int(draw_size[0] * 940 / 1023)
    title_y = y - int(thickness * 8)
    cv2.line(indicator, (0, y), (draw_size[1], y), bright_line_color, thickness)
    cv2.putText(
        img=indicator,
        text="940",
        org=(thickness // 8, title_y),
        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
        fontScale=font_scale,
        color=bright_line_color,
        thickness=int(thickness * 1.5),
        lineType=cv2.LINE_AA,
    )

    # Draw indicator
    # Horizontal line 0-100% per 10%
    for i in range(0, 9):
        y = int((draw_size[0] // 8) * i)
        title = f"{int((8-i)*128)}" if i != 0 else "1023"
        title_y = y - int(thickness * 8) if i != 0 else y + int(thickness * 16)
        cv2.line(indicator, (0, y), (draw_size[1], y), line_color, thickness)
        cv2.putText(
            img=indicator,
            text=f"{title}",
            org=(thickness // 8, title_y),
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=font_scale,
            color=line_color,
            thickness=int(thickness * 1.5),
            lineType=cv2.LINE_AA,
        )

    indicator = px.to_cupy(indicator)
    assert indicator is not None
    indicator = px.resize(indicator, (scope_size[1], scope_size[0]), interpolation=px.INTER_AREA)

    return indicator
