from typing import Union

import cupy as cp
import numpy as np
import pixtreme as px

from .indicator import waveform_indicator


def plot(image: cp.ndarray, is_vertical: bool = False) -> cp.ndarray:
    height, width, _ = image.shape
    rgb = image
    image_scope = cp.zeros((height, width, 3), dtype=cp.float32)

    block_dim = (32, 32)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    if not is_vertical:
        waveform_kernel(grid_dim, block_dim, (rgb, image_scope, width, height))
    else:
        waveform_vertical_kernel(grid_dim, block_dim, (rgb, image_scope, width, height))

    image_scope = image_scope.reshape((height, width, 3))
    return image_scope


def plot_rgb(image: cp.ndarray, is_vertical: bool = False) -> cp.ndarray:
    height, width, _ = image.shape
    rgb = image
    red_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    green_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    blue_scope = cp.zeros((height, width, 3), dtype=cp.float32)

    r = rgb[:, :, 0] / 1.0
    g = rgb[:, :, 1] / 1.0
    b = rgb[:, :, 2] / 1.0
    red_color = cp.array([0.8, 0.3, 0.3], dtype=cp.float32)
    green_color = cp.array([0.3, 0.8, 0.3], dtype=cp.float32)
    blue_color = cp.array([0.3, 0.3, 0.8], dtype=cp.float32)

    block_dim = (32, 32)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    if not is_vertical:
        waveform_single_kernel(grid_dim, block_dim, (r, red_scope, width, height, red_color))
        waveform_single_kernel(grid_dim, block_dim, (g, green_scope, width, height, green_color))
        waveform_single_kernel(grid_dim, block_dim, (b, blue_scope, width, height, blue_color))
    else:
        waveform_single_vertical_kernel(grid_dim, block_dim, (r, red_scope, width, height, red_color))
        waveform_single_vertical_kernel(grid_dim, block_dim, (g, green_scope, width, height, green_color))
        waveform_single_vertical_kernel(grid_dim, block_dim, (b, blue_scope, width, height, blue_color))

    image_scope = red_scope + green_scope + blue_scope

    return image_scope


def plot_rgb_parade(image: cp.ndarray, is_vertical: bool = False) -> cp.ndarray:
    if not is_vertical:
        image_resized = px.resize(image, (image.shape[1], image.shape[0]), interpolation=px.INTER_AUTO)
    else:
        image_resized = px.resize(image, (image.shape[1], int(image.shape[0] / 3)), interpolation=px.INTER_AUTO)

    height, width, _ = image_resized.shape
    r = image_resized[:, :, 0]
    g = image_resized[:, :, 1]
    b = image_resized[:, :, 2]
    r_image_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    g_image_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    b_image_scope = cp.zeros((height, width, 3), dtype=cp.float32)

    block_dim = (32, 32)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    red_color = cp.array([0.8, 0.1, 0.1], dtype=cp.float32)
    green_color = cp.array([0.1, 0.8, 0.1], dtype=cp.float32)
    blue_color = cp.array([0.1, 0.1, 0.8], dtype=cp.float32)

    if not is_vertical:
        waveform_single_kernel(grid_dim, block_dim, (r, r_image_scope, width, height, red_color))
        waveform_single_kernel(grid_dim, block_dim, (g, g_image_scope, width, height, green_color))
        waveform_single_kernel(grid_dim, block_dim, (b, b_image_scope, width, height, blue_color))
    else:
        waveform_single_vertical_kernel(grid_dim, block_dim, (r, r_image_scope, width, height, red_color))
        waveform_single_vertical_kernel(grid_dim, block_dim, (g, g_image_scope, width, height, green_color))
        waveform_single_vertical_kernel(grid_dim, block_dim, (b, b_image_scope, width, height, blue_color))

    r_image_scope = r_image_scope.reshape((height, width, 3))
    g_image_scope = g_image_scope.reshape((height, width, 3))
    b_image_scope = b_image_scope.reshape((height, width, 3))

    if not is_vertical:
        image_scope = cp.concatenate((r_image_scope, g_image_scope, b_image_scope), axis=1)
    else:
        image_scope = cp.concatenate((r_image_scope, g_image_scope, b_image_scope), axis=0)

    image_scope = px.resize(image_scope, (image.shape[1], image.shape[0]), interpolation=px.INTER_AUTO)

    return image_scope


def plot_cbcr(image: Union[np.ndarray, cp.ndarray], is_vertical: bool = False) -> cp.ndarray:
    frame_ycbcr = px.rgb_to_ycbcr(image)
    cb = frame_ycbcr[:, :, 1] / 1.0
    cr = frame_ycbcr[:, :, 2] / 1.0

    height, width, _ = image.shape
    cb_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    cr_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    cb_color = cp.array([1.0, 0.5, 0.0], dtype=cp.float32)
    cr_color = cp.array([0.0, 0.5, 1.0], dtype=cp.float32)

    block_dim = (32, 32)
    grid_dim = ((width + block_dim[0] - 1) // block_dim[0], (height + block_dim[1] - 1) // block_dim[1])

    if not is_vertical:
        waveform_single_kernel(grid_dim, block_dim, (cb, cb_scope, width, height, cb_color))
        waveform_single_kernel(grid_dim, block_dim, (cr, cr_scope, width, height, cr_color))
    else:
        waveform_single_vertical_kernel(grid_dim, block_dim, (cb, cb_scope, width, height, cb_color))
        waveform_single_vertical_kernel(grid_dim, block_dim, (cr, cr_scope, width, height, cr_color))

    cb_scope = cb_scope.reshape((height, width, 3))
    cr_scope = cr_scope.reshape((height, width, 3))

    image_scope = cb_scope + cr_scope

    return image_scope


def plot_cp(image: cp.ndarray, is_colorize: bool = True) -> cp.ndarray:
    """
    Waveform Scope

    Parameters
    ----------
    frame_rgb : cp.ndarray
        Input frame. Shape 3D array (height, width, 3) in RGB 4:4:4 format.

    Returns
    -------
    waveform : cp.ndarray
        Waveform scope. Shape 3D array (height, width, 3) in RGB 4:4:4 format.
    """
    image_rgb = image
    image_ycbcr = px.rgb_to_ycbcr(image_rgb)

    # count the number of channels
    if is_colorize:
        fill_color = image_rgb
    else:
        fill_color = cp.ones_like(image_rgb) * 0.5

    image_grayscale = px.ycbcr_to_grayscale(image_ycbcr)
    image_y = image_ycbcr[:, :, 0]

    # Calculate the positions of the waveform
    width = image_grayscale.shape[1]
    height = image_grayscale.shape[0]
    positions = ((1.0 - image_y) * height).astype(int)
    positions = cp.clip(positions, 0, height - 1)

    # Make a waveform matrix with rgb channels
    image_scope = cp.zeros((height, width, 3), dtype=cp.float32)
    cp.add.at(image_scope, (positions, cp.arange(width)), fill_color)

    return image_scope


class Waveform:
    def __init__(
        self,
        colorize: bool = True,
        density: float = 1.0,
        show_indicator: bool = True,
        padding: bool = False,
    ) -> None:
        self.scope_size = (0, 0)
        self.colorize = colorize
        self.density = density
        self.indicator_h = None
        self.indicator_v = None
        self.show_indicator = show_indicator
        self.padding = padding
        self.stream = cp.cuda.Stream(non_blocking=True)

    def get(
        self, image: Union[np.ndarray, cp.ndarray], vertical: bool = False, mode: str = "normal"
    ) -> cp.ndarray:
        # Convert to CuPy if NumPy
        if isinstance(image, np.ndarray):
            image = px.to_cupy(image)

        image = px.to_float32(image)
        image_rgb = px.bgr_to_rgb(image)
        image_rgb = self.initialize(image_rgb, vertical)

        if mode == "rgb":
            image_scope = plot_rgb(image_rgb, vertical)
        elif mode == "parade":
            image_scope = plot_rgb_parade(image_rgb, vertical)
        elif mode == "cbcr":
            image_scope = plot_cbcr(image_rgb, vertical)
        else:
            image_scope = plot(image_rgb, vertical)

        result = self.finalize(image_scope)
        result = px.rgb_to_bgr(result)

        # Always return CuPy array
        return result

    def initialize(self, image: cp.ndarray, is_vertical: bool = False) -> cp.ndarray:
        if self.density != 1.0:
            image = px.resize(
                image,
                (int(image.shape[1] * self.density), int(image.shape[0] * self.density)),
                interpolation=px.INTER_AUTO,
            )

        if self.show_indicator:
            if self.indicator_h is None or self.indicator_v is None or self.scope_size != image.shape[:2]:
                self.scope_size = image.shape[:2]
                self.indicator_h = waveform_indicator(self.scope_size)
                self.indicator_v = waveform_indicator((self.scope_size[1], self.scope_size[0]))
                self.is_vertical = is_vertical
                self.indicator_v = cp.rot90(self.indicator_v, 3)

        return image

    def finalize(self, image_scope: cp.ndarray) -> cp.ndarray:
        # zero fill waveform_matrix row[0] and row[height-1]
        image_scope_width = image_scope.shape[1]
        image_scope_height = image_scope.shape[0]
        image_scope[0] = cp.zeros((image_scope_width, 3))
        image_scope[image_scope_height - 1] = cp.zeros((image_scope_width, 3))

        # adjust color
        image_scope /= 32.0
        image_scope = cp.power(image_scope, 1.0 / 2.4)
        image_scope_hsv = px.rgb_to_hsv(image_scope)
        image_scope_hsv[..., 1] *= 2.0
        image_scope_hsv[..., 2] *= 1.5
        image_scope = px.hsv_to_rgb(image_scope_hsv)

        # add indicator
        if self.show_indicator:
            if self.is_vertical:
                image_scope = cp.add(image_scope, self.indicator_v)
            else:
                image_scope = cp.add(image_scope, self.indicator_h)

        # density resize
        if self.density != 1.0:
            image_scope = px.resize(image_scope, (self.scope_size[1], self.scope_size[0]), interpolation=px.INTER_AUTO)

        # zero fill padding
        if self.padding:
            scale_factor = 0.9
            scaled_size_y = int(image_scope.shape[0] * scale_factor)
            scaled_size_x = int(image_scope.shape[1] * scale_factor)
            pad_y = max(0, image_scope.shape[0] - scaled_size_y) // 2
            pad_x = max(0, image_scope.shape[1] - scaled_size_x) // 2
            image_scope_resized = px.resize(image_scope, (scaled_size_x, scaled_size_y), interpolation=px.INTER_AUTO)

            pad_y_top = image_scope.shape[0] - scaled_size_y - pad_y
            pad_x_left = image_scope.shape[1] - scaled_size_x - pad_x
            pad_y_bottom = image_scope.shape[0] - scaled_size_y - pad_y_top
            pad_x_right = image_scope.shape[1] - scaled_size_x - pad_x_left

            print(pad_y_top, pad_y_bottom, pad_x_left, pad_x_right)

            image_scope = cp.pad(
                image_scope_resized,
                (
                    (pad_y_top, pad_y_bottom),
                    (pad_x_left, pad_x_right),
                    (0, 0),
                ),
                mode="constant",
                constant_values=0,
            )

        # clip
        image_scope = cp.clip(image_scope, 0.0, 1.0)

        return image_scope


waveform_single_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_single_kernel(const float *y_val, float *waveform, int width, int height, const float *tint_color) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float y_component = y_val[idx];

    int pos_y = static_cast<int>((1.0f - y_component) * (height - 1));
    pos_y = max(0, min(height - 1, pos_y));

    for (int channel = 0; channel < 3; ++channel) {
        int wave_idx = (pos_y * width + x) * 3 + channel;
        atomicAdd(&waveform[wave_idx], tint_color[channel]);
    }
}
""",
    "waveform_single_kernel",
)

waveform_single_vertical_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_single_vertical_kernel(const float *y_val, float *waveform, int width, int height, const float *tint_color) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float y_component = y_val[idx];

    int pos_x = static_cast<int>(y_component * (width - 1));
    pos_x = max(0, min(width - 1, pos_x));

    int pos_y = y;

    for (int channel = 0; channel < 3; ++channel) {
        int wave_idx = (pos_y * width + pos_x) * 3 + channel;
        atomicAdd(&waveform[wave_idx], tint_color[channel]);
    }
}
""",
    "waveform_single_vertical_kernel",
)
waveform_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_kernel(const float *rgb, float *waveform, int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float r = rgb[(y * width + x) * 3];
    float g = rgb[(y * width + x) * 3 + 1];
    float b = rgb[(y * width + x) * 3 + 2];

    float y_component = 0.2126f * r + 0.7152f * g + 0.0722f * b;
    y_component = (y_component * 219.0f + 16.0f) / 255.0f;

    int pos_y = static_cast<int>((1.0f - y_component) * (height - 1));
    pos_y = max(0, min(height - 1, pos_y));

    for (int channel = 0; channel < 3; ++channel) {
        int wave_idx = (pos_y * width + x) * 3 + channel;
        int color_idx = idx * 3 + channel;
        atomicAdd(&waveform[wave_idx], rgb[color_idx]);
    }
}
""",
    "waveform_kernel",
)

waveform_vertical_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_vertical_kernel(const float *rgb, float *waveform, int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float r = rgb[idx * 3];
    float g = rgb[idx * 3 + 1];
    float b = rgb[idx * 3 + 2];

    float y_component = 0.2126f * r + 0.7152f * g + 0.0722f * b;
    y_component = (y_component * 219.0f + 16.0f) / 255.0f;

    int pos_x = static_cast<int>(y_component * (width - 1));
    pos_x = max(0, min(width - 1, pos_x));

    int pos_y = y;

    for (int channel = 0; channel < 3; ++channel) {
        int wave_idx = (pos_y * width + pos_x) * 3 + channel;
        atomicAdd(&waveform[wave_idx], rgb[idx * 3 + channel]);
    }
}
""",
    "waveform_vertical_kernel",
)

waveform_rgb_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_rgb_kernel(const float *rgb, float *waveform, int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float r = rgb[(y * width + x) * 3];
    float g = rgb[(y * width + x) * 3 + 1];
    float b = rgb[(y * width + x) * 3 + 2];
    r = (r * 219.0f + 16.0f) / 255.0f;
    g = (g * 219.0f + 16.0f) / 255.0f;
    b = (b * 219.0f + 16.0f) / 255.0f;

    int pos_r = static_cast<int>((1.0f - r) * (height - 1));
    pos_r = max(0, min(height - 1, pos_r));

    int pos_g = static_cast<int>((1.0f - g) * (height - 1));
    pos_g = max(0, min(height - 1, pos_g));

    int pos_b = static_cast<int>((1.0f - b) * (height - 1));
    pos_b = max(0, min(height - 1, pos_b));

    // add r
    int wave_idx_r = (pos_r * width + x) * 3;
    int color_idx_r = idx * 3;
    atomicAdd(&waveform[wave_idx_r], rgb[color_idx_r]);

    // add g
    int wave_idx_g = (pos_g * width + x) * 3 + 1;
    int color_idx_g = idx * 3 + 1;
    atomicAdd(&waveform[wave_idx_g], rgb[color_idx_g]);

    // add b
    int wave_idx_b = (pos_b * width + x) * 3 + 2;
    int color_idx_b = idx * 3 + 2;
    atomicAdd(&waveform[wave_idx_b], rgb[color_idx_b]);

}
""",
    "waveform_rgb_kernel",
)


waveform_rgb_vertical_kernel = cp.RawKernel(
    r"""
extern "C" __global__
void waveform_rgb_vertical_kernel(const float *rgb, float *waveform, int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) return;
    int idx = y * width + x;

    float r = rgb[idx * 3];
    float g = rgb[idx * 3 + 1];
    float b = rgb[idx * 3 + 2];
    r = (r * 219.0f + 16.0f) / 255.0f;
    g = (g * 219.0f + 16.0f) / 255.0f;
    b = (b * 219.0f + 16.0f) / 255.0f;

    int pos_r = static_cast<int>(r * (width - 1));
    pos_r = max(0, min(width - 1, pos_r));

    int pos_g = static_cast<int>(g * (width - 1));
    pos_g = max(0, min(width - 1, pos_g));

    int pos_b = static_cast<int>(b * (width - 1));
    pos_b = max(0, min(width - 1, pos_b));

    int pos_y = y;

    // add r
    int wave_idx_r = (pos_y * width + pos_r) * 3;
    int color_idx_r = idx * 3;
    atomicAdd(&waveform[wave_idx_r], rgb[color_idx_r]);

    // add g
    int wave_idx_g = (pos_y * width + pos_g) * 3 + 1;
    int color_idx_g = idx * 3 + 1;
    atomicAdd(&waveform[wave_idx_g], rgb[color_idx_g]);

    // add b
    int wave_idx_b = (pos_y * width + pos_b) * 3 + 2;
    int color_idx_b = idx * 3 + 2;
    atomicAdd(&waveform[wave_idx_b], rgb[color_idx_b]);
}
""",
    "waveform_rgb_vertical_kernel",
)
