# libcups

A useful Python package with utility functions.

## Installation

```bash
pip install libcups
```

## Usage

```python
import libcups

print(libcups.hello_world())
result = libcups.add_numbers(5, 3)
print(result)
```
