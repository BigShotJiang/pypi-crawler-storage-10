⚠️ THIS PROJECT 'nvidia-cublas-cu13' IS DEPRECATED.
Please use 'nvidia-cublas' instead.

To install the correct package, use:

    pip install nvidia-cublas

For more information, visit: https://pypi.org/project/nvidia-cublas/
