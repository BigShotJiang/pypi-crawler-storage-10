import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-cublas-cu13' IS DEPRECATED.
Please use 'nvidia-cublas' instead.

To install the correct package, use:

    pip install nvidia-cublas

For more information, visit: https://pypi.org/project/nvidia-cublas/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
