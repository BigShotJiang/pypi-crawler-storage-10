"""Response models for ArkForge API."""

from datetime import datetime
from typing import Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, field_validator

from .common import ActionType, HealthStatusType


class RiskTarget(BaseModel):
    """Risk management target specification for stop-loss and take-profit.

    Supports structured format with explicit type and value to distinguish between
    percentages, absolute prices, and technical analysis signals.

    Attributes:
        type: Target type - "percentage", "price", or "ta_signal"
        value: Target value (float for percentage/price, str for TA signals)
        label: Optional human-readable label for display purposes

    Examples:
        >>> # Percentage-based
        >>> RiskTarget(type="percentage", value=0.2)  # 20% gain
        >>> RiskTarget(type="percentage", value=-0.1, label="Conservative stop")

        >>> # Absolute price
        >>> RiskTarget(type="price", value=120000.0, label="Target exit price")

        >>> # Technical analysis signal
        >>> RiskTarget(type="ta_signal", value="RSI>70", label="Overbought exit")
    """

    type: Literal["percentage", "price", "ta_signal"]
    value: Union[float, str]
    label: Optional[str] = None

    def __str__(self) -> str:
        """String representation for display."""
        if self.type == "percentage":
            pct = float(self.value) * 100
            return f"{pct:+.1f}%"
        elif self.type == "price":
            return f"${self.value:,.2f}"
        else:  # ta_signal
            return str(self.value)

    def __repr__(self) -> str:
        """Developer representation."""
        return f"RiskTarget(type='{self.type}', value={self.value!r})"

    model_config = {"frozen": True}


class Action(BaseModel):
    """Portfolio action recommendation with TA-enhanced risk management.

    Attributes:
        action: Type of action (buy, sell, hold)
        symbol: Asset symbol
        target_percentage: Recommended allocation percentage
        current_percentage: Current allocation percentage
        change: Change in percentage points
        amount: USD amount for action (optional)
        reason: Rationale for action (optional)
        sl: Stop-loss percentage (e.g., -0.10 = -10%)
        tp: Take-profit target (e.g., "RSI>70" or percentage)
    """

    action: ActionType
    symbol: str
    target_percentage: float = Field(..., alias="targetPercentage", ge=0, le=100)
    current_percentage: float = Field(..., alias="currentPercentage", ge=0, le=100)
    change: float = Field(..., ge=-100, le=100)
    amount: Optional[float] = Field(None, ge=0, description="USD amount")
    reason: Optional[str] = Field(None, description="Action rationale")

    # TA-based risk management
    sl: Optional[RiskTarget] = Field(None, description="Stop-loss target")
    tp: Optional[RiskTarget] = Field(None, description="Take-profit target")

    @field_validator("sl", "tp", mode="before")
    @classmethod
    def normalize_risk_target(cls, v: Optional[Union[Dict, RiskTarget]]) -> Optional[RiskTarget]:
        """Normalize risk targets to RiskTarget format.

        Accepts structured format from API: {"type": "percentage", "value": 0.2}

        Args:
            v: Input value - dict or RiskTarget

        Returns:
            RiskTarget instance or None
        """
        if v is None:
            return None

        # Already a RiskTarget
        if isinstance(v, RiskTarget):
            return v

        # Structured format from API
        if isinstance(v, dict):
            return RiskTarget(**v)

        return v

    model_config = {"frozen": True, "populate_by_name": True}


class SwapInstruction(BaseModel):
    """Token swap instruction.

    Attributes:
        type: Instruction type (always "swap")
        from_token: Token to swap from
        from_amount: Amount to swap from
        to_token: Token to swap to
        to_amount: Amount to receive
        reason: Reason for swap
    """

    type: str = "swap"
    from_token: str = Field(..., alias="fromToken")
    from_amount: float = Field(..., alias="fromAmount")
    to_token: str = Field(..., alias="toToken")
    to_amount: float = Field(..., alias="toAmount")
    reason: str

    model_config = {"frozen": True, "populate_by_name": True}


class Rationale(BaseModel):
    """Optimization rationale and insights with TA integration.

    Attributes:
        drivers: Key drivers of the recommendation
        risks: Identified risks and concerns
        market_context: Current market context
        forecast_insights: Insights from price forecasts
        sentiment_insights: Insights from sentiment analysis
        ta_insights: TA-based insights (when TA enabled)
        enforce_summary: Risk control enforcement summary
    """

    drivers: List[str]
    risks: List[str]
    market_context: str = Field(..., alias="marketContext")
    forecast_insights: str = Field(..., alias="forecastInsights")
    sentiment_insights: str = Field(..., alias="sentimentInsights")

    # TA and risk control insights
    ta_insights: Optional[str] = Field(
        None, alias="taInsights", description="Technical Analysis insights (when TA enabled)"
    )
    enforce_summary: Optional[str] = Field(
        None, alias="enforceSummary", description="Risk control enforcement summary"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class Metadata(BaseModel):
    """Response metadata with TA processing information.

    Attributes:
        workflow_id: Workflow execution ID
        timestamp: Response timestamp
        processing_time: Processing time in milliseconds
        llm_provider: LLM provider used
        llm_model: LLM model used
        request_id: Request ID for support
        ta_enabled: Whether TA was enabled
        ta_processing_time: TA processing time in ms
        duration: Total request duration in ms (alias for processing_time)
    """

    workflow_id: str = Field(..., alias="workflowId")
    timestamp: datetime
    processing_time: int = Field(..., alias="processingTime", description="Processing time in ms")
    llm_provider: str = Field(..., alias="llmProvider")
    llm_model: str = Field(..., alias="llmModel")
    request_id: str = Field(..., alias="requestId")

    # TA-specific metadata
    ta_enabled: Optional[bool] = Field(None, alias="taEnabled", description="TA was enabled")
    ta_processing_time: Optional[int] = Field(
        None, alias="taProcessingTime", description="TA processing time in ms"
    )
    duration: Optional[int] = Field(None, description="Total duration (alias for processing_time)")

    model_config = {"frozen": True, "populate_by_name": True}


class PortfolioRecommendation(BaseModel):
    """Portfolio optimization recommendation.

    This is the main response from portfolio optimization requests.

    Example:
        >>> recommendation = PortfolioRecommendation.model_validate(response_data)
        >>> print(recommendation.allocation)
        {'BTC': 40.0, 'ETH': 35.0, 'SOL': 25.0}
        >>> print(f"Sharpe Ratio: {recommendation.sharpe_ratio:.2f}")
        Sharpe Ratio: 1.45
    """

    # Allocation
    allocation: Dict[str, float] = Field(..., description="Recommended allocation percentages")

    # Metrics
    expected_return: float = Field(
        ..., alias="expectedReturn", description="Annualized expected return (0.15 = 15%)"
    )
    expected_volatility: float = Field(
        ..., alias="expectedVolatility", description="Annualized volatility (0.25 = 25%)"
    )
    sharpe_ratio: float = Field(..., alias="sharpeRatio", description="Risk-adjusted return metric")
    confidence: float = Field(..., ge=0, le=1, description="Confidence in recommendation (0-1)")

    # Actions
    actions: List[Action]
    swaps: Optional[List[SwapInstruction]] = None

    # Rationale (optional, depends on request)
    rationale: Optional[Rationale] = None

    # Metadata (optional)
    metadata: Optional[Metadata] = None

    model_config = {"frozen": True, "populate_by_name": True}


class RiskProfile(BaseModel):
    """Risk profile description.

    Attributes:
        name: Profile name
        description: Profile description
        target_volatility: Target volatility range
        max_drawdown: Maximum acceptable drawdown
        expected_return: Expected return range
        asset_preferences: Preferred asset types
    """

    name: str
    description: str
    target_volatility: str = Field(..., alias="targetVolatility")
    max_drawdown: str = Field(..., alias="maxDrawdown")
    expected_return: str = Field(..., alias="expectedReturn")
    asset_preferences: List[str] = Field(..., alias="assetPreferences")

    model_config = {"frozen": True, "populate_by_name": True}


class CreateKeyResponse(BaseModel):
    """API key creation response.

    WARNING: The full api_key is only shown once! Store it securely.

    Attributes:
        api_key: Full API key (shown only once!)
        key_id: Numeric key ID
        prefix: Key prefix (first 16 characters)
        warning: Security warning message
    """

    api_key: str = Field(..., alias="apiKey", description="Full API key (shown once!)")
    key_id: int = Field(..., alias="keyId")
    prefix: str = Field(..., description="Key prefix (first 16 chars)")
    warning: str = "This API key will only be shown once. Store it securely."

    model_config = {"frozen": True, "populate_by_name": True}


class ApiKeyInfo(BaseModel):
    """API key information (without full key).

    Attributes:
        id: Key ID
        prefix: Key prefix
        name: Key name
        scopes: Key scopes
        created_at: Creation timestamp
        last_used_at: Last usage timestamp
        expires_at: Expiration timestamp
        is_active: Whether key is active
    """

    id: int
    prefix: str
    name: str
    scopes: List[str]
    created_at: datetime = Field(..., alias="createdAt")
    last_used_at: Optional[datetime] = Field(None, alias="lastUsedAt")
    expires_at: datetime = Field(..., alias="expiresAt")
    is_active: bool = Field(..., alias="isActive")

    model_config = {"frozen": True, "populate_by_name": True}


class ApiKeyUsage(BaseModel):
    """API key usage statistics.

    Attributes:
        total_requests: Total requests made
        successful_requests: Successful requests
        failed_requests: Failed requests
        last_request_at: Timestamp of last request
        average_duration: Average request duration in ms
    """

    total_requests: int = Field(..., alias="totalRequests")
    successful_requests: int = Field(..., alias="successfulRequests")
    failed_requests: int = Field(..., alias="failedRequests")
    last_request_at: Optional[datetime] = Field(None, alias="lastRequestAt")
    average_duration: float = Field(..., alias="averageDuration")

    model_config = {"frozen": True, "populate_by_name": True}


class ApiKeyDetails(ApiKeyInfo):
    """Detailed API key information with usage stats.

    Inherits from ApiKeyInfo and adds usage statistics.
    """

    usage: ApiKeyUsage

    model_config = {"frozen": True, "populate_by_name": True}


class ServiceStatus(BaseModel):
    """Individual service status.

    Attributes:
        status: Service status (ok, degraded, unknown)
    """

    status: str

    model_config = {"frozen": True, "populate_by_name": True}


class HealthStatus(BaseModel):
    """Service health status.

    Attributes:
        status: Overall status
        timestamp: Status timestamp
        uptime: Service uptime in seconds
        services: Individual service statuses
    """

    status: HealthStatusType
    timestamp: datetime
    uptime: float
    services: Dict[str, str]

    model_config = {"frozen": True, "populate_by_name": True}
