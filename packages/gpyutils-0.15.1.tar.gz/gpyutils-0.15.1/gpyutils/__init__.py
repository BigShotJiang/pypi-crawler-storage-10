# gpyutils
# (c) 2013-2025 Michał Górny <mgorny@gentoo.org>
# SPDX-License-Identifier: GPL-2.0-or-later

"""Maintenance scripts for Gentoo Python packages"""

__version__ = "0.15.1"
