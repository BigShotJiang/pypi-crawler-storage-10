"""Language mix detection and non-alphabetical heuristics."""
