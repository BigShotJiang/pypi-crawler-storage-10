"""
Entry point for running DeltaTask as a module.
This allows the package to be executed with 'python -m deltatask'.
"""

import sys
import os

# Add the parent directory to the path to import server
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from server import main
except ImportError:
    # Try importing from the current directory structure
    import importlib.util
    import sys

    # Get the path to server.py in the parent directory
    server_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'server.py')

    # Load the server module dynamically
    spec = importlib.util.spec_from_file_location("server", server_path)
    server_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(server_module)
    main = server_module.main

if __name__ == "__main__":
    main()