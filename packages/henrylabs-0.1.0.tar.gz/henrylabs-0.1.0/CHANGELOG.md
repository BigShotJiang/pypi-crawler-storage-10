# Changelog

## 0.1.0 (2025-10-28)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/Henry-Social/henry-sdk-py/compare/v0.0.1...v0.1.0)

### Chores

* configure new SDK language ([4be628a](https://github.com/Henry-Social/henry-sdk-py/commit/4be628a8197ffc24748f2dc6e2d29971676ffb04))
* update SDK settings ([eab8148](https://github.com/Henry-Social/henry-sdk-py/commit/eab81481d9faf4036c1cbdd243cdc3175b443730))
* update SDK settings ([1bb30aa](https://github.com/Henry-Social/henry-sdk-py/commit/1bb30aa4a7d6b94ec7e00393b71de9b21f4540de))
