from fastmcp import FastMCP
from fastapi import HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import httpx

# ------------------------------------------------------
# 初始化 FastMCP (同時也是 FastAPI app)
# ------------------------------------------------------
mcp = FastMCP(
    name="meeting-room-api"
)

BASE_URL = "http://0.tcp.jp.ngrok.io:14868"

# ------------------------------------------------------
# 資料模型 (Pydantic)
# ------------------------------------------------------
class Room(BaseModel):
    id: int
    name: str
    capacity: int

class ReservationRequest(BaseModel):
    room_id: int = Field(..., description="會議室 ID")
    start_time: str = Field(..., description="開始時間 (ISO 格式)")
    end_time: str = Field(..., description="結束時間 (ISO 格式)")
    reserved_by: str = Field(..., description="預約人姓名")

class ReservationResponse(BaseModel):
    reservation_id: Optional[int]
    status: str

class RoomReservation(BaseModel):
    id: int
    room_id: int
    start_time: str
    end_time: str
    reserved_by: str


# ------------------------------------------------------
# 建立 HTTP 客戶端
# ------------------------------------------------------
async def get_client():
    return httpx.AsyncClient(timeout=10.0)


# ------------------------------------------------------
# API 實作
# ------------------------------------------------------
@mcp.get("/rooms", response_model=List[Room])
async def list_rooms():
    """查詢所有會議室"""
    async with await get_client() as client:
        try:
            r = await client.get(f"{BASE_URL}/rooms")
            r.raise_for_status()
            return r.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"連線錯誤：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@mcp.get("/rooms/{room_id}/reservations", response_model=List[RoomReservation])
async def list_room_reservations(room_id: int):
    """查詢某間會議室的預約紀錄"""
    async with await get_client() as client:
        try:
            r = await client.get(f"{BASE_URL}/rooms/{room_id}/reservations")
            r.raise_for_status()
            return r.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"連線錯誤：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@mcp.post("/reservations", response_model=ReservationResponse)
async def create_reservation(req: ReservationRequest):
    """預約會議室"""
    async with await get_client() as client:
        try:
            r = await client.post(f"{BASE_URL}/reservations", json=req.dict())
            r.raise_for_status()
            return r.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線伺服器：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ------------------------------------------------------
# 執行入口
# ------------------------------------------------------
if __name__ == "__main__":
    mcp.run()
