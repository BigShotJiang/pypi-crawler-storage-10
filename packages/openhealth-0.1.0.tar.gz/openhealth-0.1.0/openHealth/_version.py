"""Version information for openHealth package."""

__version__ = "0.1.0"