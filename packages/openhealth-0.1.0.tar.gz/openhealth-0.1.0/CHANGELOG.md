# Changelog

All notable changes to openHealth will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial release of openHealth
- Health monitoring for backend and frontend services
- Multiple notification channels (email, Slack)
- Web dashboard for real-time monitoring
- CLI tool for easy management
- Configuration validation with JSON schema
- Retry mechanisms with exponential backoff
- Comprehensive test suite

### Features
- **Core Health Checking**: HTTP endpoint monitoring with configurable intervals, timeouts, and retries
- **Notifications**: Email alerts via SMTP and Slack webhook integration
- **Web Dashboard**: Real-time Flask-based dashboard for service status visualization
- **CLI Tool**: Command-line interface for managing health checks
- **Configuration**: JSON-based configuration with validation
- **Extensible**: Plugin-based architecture for custom notifications
- **Performance Monitoring**: Response time tracking and performance metrics
- **Status History**: Historical data tracking with configurable retention

### Technical
- **Python 3.7+ Support**: Compatible with Python 3.7 through 3.11
- **Type Hints**: Full type annotation support
- **Async Support**: Non-blocking health checks
- **Thread Safe**: Safe for concurrent operations
- **Logging**: Comprehensive logging with configurable levels

## [0.1.0] - 2025-10-27

### Added
- Initial public release
- Core health monitoring functionality
- Email and Slack notification systems
- Web dashboard with real-time updates
- Command-line interface
- Comprehensive documentation
- Example configurations and scripts
- Full test coverage with pytest
- PyPI package distribution setup

### Documentation
- README with installation and usage instructions
- API documentation
- Configuration guide
- Contributing guidelines
- Security policy
- Code of conduct

### Packaging
- Complete PyPI compliance
- Modern Python packaging with pyproject.toml
- Cross-platform compatibility
- Dependency management
- Development tools configuration (black, flake8, mypy, pytest)

## [Migration Guide]

### From health-checker to openHealth
The package has been renamed from `health-checker` to `openHealth`. Migration steps:
1. Update imports: `from health_checker import HealthChecker` → `from openHealth import HealthChecker`
2. Update CLI command: `health-checker` → `openhealth`
3. Update configuration files (package references)
4. Update dependencies in requirements.txt

### Breaking Changes
- Package name changed from `health-checker` to `openHealth`
- CLI command changed from `health-checker` to `openhealth`
- Import paths changed from `health_checker.*` to `openHealth.*`
- Author and maintainer information updated
- Repository location changed

## [Support]

- **Documentation**: https://openhealth.readthedocs.io/
- **Issues**: https://github.com/Dhruv1969Karnwal/openHealth/issues
- **Discussions**: https://github.com/Dhruv1969Karnwal/openHealth/discussions
- **Source**: https://github.com/Dhruv1969Karnwal/openHealth

## [Contributing]

See [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to contribute to openHealth.

## [License]

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.