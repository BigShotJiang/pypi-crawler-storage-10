Data taken on February 7, 2025

Distance between the suspension point and top of the wood: 108.3 cm
Distance between the suspension point and the optical gate: 115.1 cm
Wood dimensions: 3.4 x 3.4 28.0
Lead dimensions: 2.1 x 0.7 x 10.7
Flag dimensions: 1.94 x 0.20 x 6.7

Wood mass = 100--200 g
Lead mass = 180 g

Distance between the suspension point and the wood baricenter: 108.3 + 3.4 / 2 = 110 cm
Distance between the suspension point and the lead baricenter: 108.3 + 3.4 + 0.7 / 2 = 112 cm

Pendulum length: 110.9--111.3
