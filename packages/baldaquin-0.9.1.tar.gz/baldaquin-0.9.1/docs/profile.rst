:mod:`~baldaquin.profile` --- Profiling
=======================================


Module documentation
--------------------

.. automodule:: baldaquin.profile
