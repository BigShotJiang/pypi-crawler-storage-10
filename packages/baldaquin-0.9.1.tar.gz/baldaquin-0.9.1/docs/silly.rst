:mod:`~baldaquin.silly` --- Mock objects
========================================


Module documentation
--------------------

.. automodule:: baldaquin.silly
