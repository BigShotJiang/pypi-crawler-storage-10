.. _app:

:mod:`~baldaquin.app` --- User applications
===========================================


Module documentation
--------------------

.. automodule:: baldaquin.app
