<img src="https://raw.githubusercontent.com/lucabaldini/baldaquin/main/docs/_static/baldaquin_logo_small_light.png" alt="baldaquin logo" width="175">

[![PyPI](https://img.shields.io/pypi/v/baldaquin.svg)](https://pypi.org/project/baldaquin/)
![Python versions](https://img.shields.io/badge/python-3.7--3.13-blue)
![License](https://img.shields.io/github/license/lucabaldini/baldaquin.svg)
[![CI](https://github.com/lucabaldini/baldaquin/actions/workflows/ci.yml/badge.svg)](https://github.com/lucabaldini/baldaquin/actions/workflows/ci.yml)
[![Docs](https://github.com/lucabaldini/baldaquin/actions/workflows/docs.yml/badge.svg)](https://github.com/lucabaldini/baldaquin/actions/workflows/docs.yml)
![GitHub last commit](https://img.shields.io/github/last-commit/lucabaldini/baldaquin)

[![Ceasefire Now](https://badge.techforpalestine.org/default)](https://techforpalestine.org/learn-more)

baldaquin (or the BALd DAQ User INterface) is an attempt at a general-purpose, modular
and reusable data acquisition framework.
[Read more](https://lucabaldini.github.io/baldaquin/).
