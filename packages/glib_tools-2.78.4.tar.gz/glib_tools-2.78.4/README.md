# glib-tools

A useful Python package with utility functions.

## Installation

```bash
pip install glib-tools
```

## Usage

```python
import glib-tools

print(glib-tools.hello_world())
result = glib-tools.add_numbers(5, 3)
print(result)
```
