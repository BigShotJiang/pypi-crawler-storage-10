"""
glib-tools - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from glib-tools!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "glib-tools",
        "version": "2.78.4",
        "description": "A useful Python package"
    }

# Package version
__version__ = "2.78.4"
