"""Content fetching helpers for web pages and PDFs."""
from __future__ import annotations

import io
import logging
from dataclasses import dataclass
from typing import List, Optional

import requests
from PIL import Image
from playwright.sync_api import TimeoutError, sync_playwright

try:
    import fitz  # type: ignore
except ImportError as exc:  # pragma: no cover - surfaced during runtime
    raise ImportError("PyMuPDF is required to extract PDF content.") from exc


@dataclass
class WebContent:
    """Normalized representation of extracted content."""

    text: str
    images: List[bytes]
    source_type: str


USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
)


def _resolve_logger(logger: Optional[logging.Logger]) -> logging.Logger:
    if logger is not None:
        return logger
    default_logger = logging.getLogger("aiknowledge")
    if not default_logger.handlers:
        default_logger.addHandler(logging.NullHandler())
    return default_logger


def _head_request(url: str, timeout: int, logger: logging.Logger) -> Optional[requests.Response]:
    try:
        response = requests.head(url, allow_redirects=True, timeout=timeout, headers={"User-Agent": USER_AGENT})
        response.raise_for_status()
        return response
    except requests.RequestException as exc:
        logger.warning("HEAD request failed for %s: %s", url, exc)
        return None


def _is_pdf(url: str, head_response: Optional[requests.Response]) -> bool:
    if head_response and "pdf" in head_response.headers.get("Content-Type", "").lower():
        return True
    return url.lower().endswith(".pdf")


def _truncate_text(text: str, max_chars: int) -> str:
    text = " ".join(text.split())
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + " ... [truncated]"


def _ensure_image_size(image: Image.Image, max_bytes: int, logger: logging.Logger) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    data = buffer.getvalue()

    while len(data) > max_bytes and image.height > 200:
        new_height = max(200, int(image.height * 0.9))
        image = image.crop((0, 0, image.width, new_height))
        buffer = io.BytesIO()
        image.save(buffer, format="PNG", optimize=True)
        data = buffer.getvalue()
        logger.debug("Cropped screenshot to %spx height (%.2f MB)", new_height, len(data) / (1024 * 1024))

    return data


def _fetch_web_page(
    url: str,
    *,
    logger: logging.Logger,
    max_chars: int,
    max_image_mb: float,
    request_timeout: int,
) -> WebContent:
    max_bytes = int(max_image_mb * 1024 * 1024)
    text_content = ""
    screenshot_bytes: List[bytes] = []

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.set_default_timeout(request_timeout * 1000)
            page.goto(url, wait_until="networkidle")
            raw_text = page.inner_text("body")
            text_content = _truncate_text(raw_text, max_chars)
            screenshot = page.screenshot(full_page=True)
            image = Image.open(io.BytesIO(screenshot))
            screenshot_bytes.append(_ensure_image_size(image, max_bytes, logger))
            page.close()
            browser.close()
    except TimeoutError as exc:
        logger.error("Timed out while loading %s: %s", url, exc)
    except Exception as exc:  # pragma: no cover - Playwright errors are runtime specific
        logger.error("Failed to capture web page %s: %s", url, exc)

    return WebContent(text=text_content, images=screenshot_bytes, source_type="web")


def _fetch_pdf(
    url: str,
    *,
    logger: logging.Logger,
    max_chars: int,
    max_pages: int,
    request_timeout: int,
) -> WebContent:
    try:
        response = requests.get(url, timeout=request_timeout, headers={"User-Agent": USER_AGENT})
        response.raise_for_status()
    except requests.RequestException as exc:
        logger.error("Failed to download PDF %s: %s", url, exc)
        return WebContent(text="", images=[], source_type="pdf")

    doc = fitz.open(stream=response.content, filetype="pdf")
    texts = []
    images: List[bytes] = []

    try:
        for index, page in enumerate(doc):
            if index >= max_pages:
                break
            text = page.get_text("text")
            texts.append(text)
            pix = page.get_pixmap()
            images.append(pix.tobytes("png"))
    finally:
        doc.close()

    aggregated = _truncate_text("\n\n".join(texts), max_chars)
    return WebContent(text=aggregated, images=images, source_type="pdf")


def fetch_web_or_pdf(
    url: str,
    *,
    logger: Optional[logging.Logger] = None,
    max_chars: int,
    max_image_mb: float,
    max_pdf_pages: int,
    request_timeout: int,
) -> WebContent:
    """Fetch content from a web page or PDF URL."""

    resolved_logger = _resolve_logger(logger)
    head_response = _head_request(url, request_timeout, resolved_logger)

    if _is_pdf(url, head_response):
        resolved_logger.debug("Detected PDF content at %s", url)
        return _fetch_pdf(
            url,
            logger=resolved_logger,
            max_chars=max_chars,
            max_pages=max_pdf_pages,
            request_timeout=request_timeout,
        )

    resolved_logger.debug("Detected web page content at %s", url)
    return _fetch_web_page(
        url,
        logger=resolved_logger,
        max_chars=max_chars,
        max_image_mb=max_image_mb,
        request_timeout=request_timeout,
    )
