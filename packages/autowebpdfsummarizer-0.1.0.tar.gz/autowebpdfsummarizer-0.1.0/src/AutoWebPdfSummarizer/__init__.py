"""Tools for summarizing web pages and PDFs with Gemini."""

from .summarizer import SummarizationResult, summarize_url

__all__ = ["SummarizationResult", "summarize_url"]
