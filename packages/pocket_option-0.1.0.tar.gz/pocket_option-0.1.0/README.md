# ⚡ PocketOption API SDK (Unofficial)

Асинхронный **Python-SDK для взаимодействия с PocketOption API** (неофициальный).

Полностью типизирован, построен на `pydantic`, с поддержкой middleware, событий.

>⚠️ Проект не связан с PocketOption. Предназначен для интеграций, анализа и автоматизации.

> Поддерживает Python 3.13+ и полностью асинхронен (`asyncio` + `aiohttp`).

> ## Предупреждение о рисках:
> Инвестирование в финансовые продукты сопряжено с рисками. Прошлые результаты не гарантируют будущую доходность, а стоимость активов может изменяться в зависимости от рыночных условий и колебаний базовых инструментов. Любые прогнозы или иллюстрации приведены исключительно для справки и не являются гарантией результата. Этот проект не является приглашением или рекомендацией к инвестированию. Перед инвестированием проконсультируйтесь с финансовыми, юридическими и налоговыми специалистами и решите, подходит ли данный продукт вашим целям, допустимому уровню риска и текущей ситуации.

> P.S. У них демо прикольное, чисто позалипать кайф

## 🚀 Возможности

- 🔌 Подключение к WebSocket-API PocketOption (через `socket io`)

- 🔐 Авторизация по активной сессии

- 💹 Управление ордерами и сделками (демо / реальный счёт)

- 📊 Подписка на рыночные потоки

- 💾 Встроенные in-memory-хранилища (`MemoryCandleStorage`, `MemoryDealsStorage`)

- ⚙️ Middleware-цепочка для перехвата событий и запросов

- 💬 Событийная модель с декораторами (`@client.on.*`)

- ✅ Строгая типизация


## ⚙️ Пример использования

```python
import asyncio
import os
from pocket_option import PocketOptionClient
from pocket_option.models import Asset, OrderAction
from pocket_option.constants import Regions



async def on_update_stream(assets: list[UpdateStreamItem]):
    print("Assets updated: ", assets)

async def main():
    client = PocketOptionClient()
    client.on.update_stream(on_update_stream)

    deals = MemoryDealsStorage(client)

    await client.connect(Regions.DEMO)
    await client.emit.auth(AuthorizationData.model_validate({
        "session": os.environ["PO_SESSION"],
        "isDemo": 1,
        "uid": int(os.environ["PO_UID"]),
        "platform": 2,
        "isFastHistory": True,
        "isOptimized": True,
    }))

    deal = await deals.open_deal(
        asset=Asset.AUDCAD_otc,
        amount=10,
        action=OrderAction.CALL,
        is_demo=1,
        option_type=100,
        time=60,
    )
    print("✅ Opened deal:", deal)
    result = await deals.check_deal_result(wait_time=60, deal=deal)
    print("✅ Deal result:", result)

asyncio.run(main())

```


## 📜 Лицензия

**MIT License** — делай что хочешь, но на свой страх и риск.