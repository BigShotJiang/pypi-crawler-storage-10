CRD_GROUP = "devserver.io"
CRD_VERSION = "v1"

CRD_PLURAL_DEVSERVER = "devservers"
CRD_PLURAL_DEVSERVERFLAVOR = "devserverflavors"
CRD_PLURAL_DEVSERVERUSER = "devserverusers"
