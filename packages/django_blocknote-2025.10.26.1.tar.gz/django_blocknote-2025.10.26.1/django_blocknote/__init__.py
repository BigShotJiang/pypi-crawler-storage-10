# django_blocknote/__init__.py
__version__ = "2025.10.26.1"