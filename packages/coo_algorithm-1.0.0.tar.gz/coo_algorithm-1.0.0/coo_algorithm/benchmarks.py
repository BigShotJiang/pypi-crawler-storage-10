"""
Benchmark Functions for Optimization Testing

This module provides standard benchmark functions for testing optimization
algorithms, including Rosenbrock, Rastrigin, Ackley, and Griewank functions.

Author: Your Name
License: MIT
"""

import numpy as np
from typing import List, Tuple


class BenchmarkFunctions:
    """
    Collection of standard benchmark functions for optimization.
    
    All functions are formulated for **minimization** (finding the minimum value).
    The global minimum for all functions is 0.0 at specific points.
    
    For use with COO in maximization mode, negate the function:
    >>> coo = COO(bounds=bounds, mode='max')
    >>> result = coo.optimize(lambda x: -BenchmarkFunctions.rosenbrock(x))
    
    For minimization mode, use directly:
    >>> coo = COO(bounds=bounds, mode='min')
    >>> result = coo.optimize(BenchmarkFunctions.rosenbrock)
    
    Examples
    --------
    >>> import numpy as np
    >>> from coo_optimizer import BenchmarkFunctions, COO
    >>> 
    >>> # Test Rosenbrock function
    >>> x_opt = np.ones(5)  # Optimum at (1, 1, ..., 1)
    >>> val = BenchmarkFunctions.rosenbrock(x_opt)
    >>> print(f"Value at optimum: {val:.6f}")  # Should be ~0.0
    >>> 
    >>> # Use with COO (minimization)
    >>> bounds = BenchmarkFunctions.get_bounds('rosenbrock', 5)
    >>> coo = COO(bounds=bounds, mode='min', max_iterations=100)
    >>> best_pos, best_val, _, _ = coo.optimize(BenchmarkFunctions.rosenbrock)
    >>> print(f"Found minimum: {best_val:.6f}")
    """
    
    @staticmethod
    def rosenbrock(x: np.ndarray) -> float:
        """
        Rosenbrock function (minimization).
        
        Also known as the "banana function" or "valley function". Has a narrow
        parabolic valley that is difficult to navigate.
        
        Global minimum: f(x*) = 0 at x* = (1, 1, ..., 1)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension >= 2.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = Σ[100(x_{i+1} - x_i²)² + (1 - x_i)²] for i=1 to n-1
        
        Properties
        ----------
        - Unimodal (single minimum)
        - Non-separable
        - Smooth but with narrow valley
        - Search domain: typically [-5, 10]^n
        
        Examples
        --------
        >>> x = np.ones(5)  # Global optimum
        >>> print(BenchmarkFunctions.rosenbrock(x))  # Should be 0.0
        0.0
        
        >>> x = np.zeros(5)  # Away from optimum
        >>> val = BenchmarkFunctions.rosenbrock(x)
        >>> print(f"At zero: {val:.2f}")
        """
        return np.sum(100.0 * (x[1:] - x[:-1]**2)**2 + (1 - x[:-1])**2)
    
    @staticmethod
    def rastrigin(x: np.ndarray) -> float:
        """
        Rastrigin function (minimization).
        
        Highly multimodal function with many local minima arranged in a
        regular lattice. One of the most difficult functions to optimize.
        
        Global minimum: f(x*) = 0 at x* = (0, 0, ..., 0)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = 10n + Σ[x_i² - 10cos(2πx_i)] for i=1 to n
        
        Properties
        ----------
        - Highly multimodal (many local minima)
        - Separable
        - Regular structure of local minima
        - Search domain: typically [-5.12, 5.12]^n
        
        Examples
        --------
        >>> x = np.zeros(5)  # Global optimum
        >>> print(BenchmarkFunctions.rastrigin(x))  # Should be 0.0
        0.0
        
        >>> x = np.ones(5)  # Local minimum
        >>> val = BenchmarkFunctions.rastrigin(x)
        >>> print(f"At ones: {val:.2f}")
        """
        n = len(x)
        return 10 * n + np.sum(x**2 - 10 * np.cos(2 * np.pi * x))
    
    @staticmethod
    def ackley(x: np.ndarray) -> float:
        """
        Ackley function (minimization).
        
        Characterized by a nearly flat outer region and a large hole at the
        center. Many local minima but only one global minimum.
        
        Global minimum: f(x*) = 0 at x* = (0, 0, ..., 0)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = -20·exp(-0.2·√(Σx_i²/n)) - exp(Σcos(2πx_i)/n) + 20 + e
        
        Properties
        ----------
        - Multimodal
        - Non-separable
        - Nearly flat outer region makes search difficult
        - Search domain: typically [-32.768, 32.768]^n
        
        Examples
        --------
        >>> x = np.zeros(5)  # Global optimum
        >>> val = BenchmarkFunctions.ackley(x)
        >>> print(f"At optimum: {val:.6f}")  # Should be ~0.0
        0.0
        
        >>> x = np.ones(5) * 10  # Far from optimum
        >>> val = BenchmarkFunctions.ackley(x)
        >>> print(f"Far from optimum: {val:.2f}")
        """
        n = len(x)
        sum_sq = np.sum(x**2)
        sum_cos = np.sum(np.cos(2 * np.pi * x))
        return (-20 * np.exp(-0.2 * np.sqrt(sum_sq / n)) - 
                np.exp(sum_cos / n) + 20 + np.e)
    
    @staticmethod
    def griewank(x: np.ndarray) -> float:
        """
        Griewank function (minimization).
        
        Similar to Rastrigin but with product term creating interdependencies.
        Has many widespread local minima.
        
        Global minimum: f(x*) = 0 at x* = (0, 0, ..., 0)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = Σ(x_i²/4000) - Π(cos(x_i/√i)) + 1
        
        Properties
        ----------
        - Multimodal
        - Non-separable due to product term
        - Increasing dimension increases difficulty
        - Search domain: typically [-600, 600]^n
        
        Examples
        --------
        >>> x = np.zeros(5)  # Global optimum
        >>> print(BenchmarkFunctions.griewank(x))  # Should be 0.0
        0.0
        
        >>> x = np.array([100, 100, 100])
        >>> val = BenchmarkFunctions.griewank(x)
        >>> print(f"At (100,100,100): {val:.2f}")
        """
        sum_sq = np.sum(x**2)
        prod_cos = np.prod(np.cos(x / np.sqrt(np.arange(1, len(x) + 1))))
        return sum_sq / 4000 - prod_cos + 1
    
    @staticmethod
    def sphere(x: np.ndarray) -> float:
        """
        Sphere function (minimization).
        
        Simplest benchmark function. Convex, unimodal, and separable.
        
        Global minimum: f(x*) = 0 at x* = (0, 0, ..., 0)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = Σx_i² for i=1 to n
        
        Examples
        --------
        >>> x = np.zeros(5)
        >>> print(BenchmarkFunctions.sphere(x))
        0.0
        """
        return np.sum(x**2)
    
    @staticmethod
    def schwefel(x: np.ndarray) -> float:
        """
        Schwefel function (minimization).
        
        Deceptive function where the global minimum is far from the next best
        local minima, making it difficult for optimization algorithms.
        
        Global minimum: f(x*) = 0 at x* = (420.9687, ..., 420.9687)
        
        Parameters
        ----------
        x : np.ndarray
            Input vector of any dimension.
        
        Returns
        -------
        float
            Function value (to be minimized).
        
        Mathematical Form
        -----------------
        f(x) = 418.9829n - Σ(x_i·sin(√|x_i|))
        
        Examples
        --------
        >>> x = np.ones(5) * 420.9687
        >>> val = BenchmarkFunctions.schwefel(x)
        >>> print(f"Near optimum: {val:.2f}")
        """
        n = len(x)
        return 418.9829 * n - np.sum(x * np.sin(np.sqrt(np.abs(x))))
    
    @staticmethod
    def get_bounds(func_name: str, dim: int) -> List[Tuple[float, float]]:
        """
        Get recommended search bounds for a benchmark function.
        
        Parameters
        ----------
        func_name : str
            Name of the function: 'rosenbrock', 'rastrigin', 'ackley',
            'griewank', 'sphere', or 'schwefel'.
        
        dim : int
            Number of dimensions.
        
        Returns
        -------
        bounds : List[Tuple[float, float]]
            List of (min, max) tuples for each dimension.
        
        Raises
        ------
        ValueError
            If func_name is not recognized.
        
        Examples
        --------
        >>> bounds = BenchmarkFunctions.get_bounds('rastrigin', 10)
        >>> print(f"10D Rastrigin bounds: {bounds[0]}")
        (-5.12, 5.12)
        
        >>> bounds = BenchmarkFunctions.get_bounds('rosenbrock', 5)
        >>> print(f"Dimension: {len(bounds)}")
        5
        """
        bounds_map = {
            'rosenbrock': [(-5, 10)] * dim,
            'rastrigin': [(-5.12, 5.12)] * dim,
            'ackley': [(-32.768, 32.768)] * dim,
            'griewank': [(-600, 600)] * dim,
            'sphere': [(-100, 100)] * dim,
            'schwefel': [(-500, 500)] * dim,
        }
        
        if func_name not in bounds_map:
            raise ValueError(
                f"Unknown function '{func_name}'. "
                f"Available: {list(bounds_map.keys())}"
            )
        
        return bounds_map[func_name]
    
    @staticmethod
    def get_optimum(func_name: str, dim: Optional[int] = None) -> float:
        """
        Get the known global optimum value for a benchmark function.
        
        Parameters
        ----------
        func_name : str
            Name of the function.
        
        dim : int, optional
            Dimension (only needed for some functions).
        
        Returns
        -------
        optimum : float
            Global minimum value.
        
        Examples
        --------
        >>> opt = BenchmarkFunctions.get_optimum('rosenbrock')
        >>> print(f"Rosenbrock optimum: {opt}")
        0.0
        
        >>> opt = BenchmarkFunctions.get_optimum('rastrigin')
        >>> print(f"Rastrigin optimum: {opt}")
        0.0
        """
        # All standard benchmarks have optimum at 0
        return 0.0
    
    @staticmethod
    def get_optimum_position(func_name: str, dim: int) -> np.ndarray:
        """
        Get the position of the global optimum.
        
        Parameters
        ----------
        func_name : str
            Name of the function.
        
        dim : int
            Number of dimensions.
        
        Returns
        -------
        position : np.ndarray
            Global optimum position.
        
        Examples
        --------
        >>> pos = BenchmarkFunctions.get_optimum_position('rosenbrock', 5)
        >>> print(f"Rosenbrock optimum: {pos}")
        [1. 1. 1. 1. 1.]
        
        >>> pos = BenchmarkFunctions.get_optimum_position('rastrigin', 3)
        >>> print(f"Rastrigin optimum: {pos}")
        [0. 0. 0.]
        """
        position_map = {
            'rosenbrock': np.ones(dim),
            'rastrigin': np.zeros(dim),
            'ackley': np.zeros(dim),
            'griewank': np.zeros(dim),
            'sphere': np.zeros(dim),
            'schwefel': np.ones(dim) * 420.9687,
        }
        
        if func_name not in position_map:
            raise ValueError(f"Unknown function '{func_name}'")
        
        return position_map[func_name]
    
    @staticmethod
    def evaluate_at_optimum(func_name: str, dim: int) -> float:
        """
        Evaluate function at its known optimum (for verification).
        
        Parameters
        ----------
        func_name : str
            Name of the function.
        
        dim : int
            Number of dimensions.
        
        Returns
        -------
        value : float
            Function value at optimum (should be 0.0 for standard benchmarks).
        
        Examples
        --------
        >>> val = BenchmarkFunctions.evaluate_at_optimum('rosenbrock', 5)
        >>> print(f"Rosenbrock at optimum: {val:.10f}")
        0.0000000000
        """
        func = getattr(BenchmarkFunctions, func_name)
        position = BenchmarkFunctions.get_optimum_position(func_name, dim)
        return func(position)
