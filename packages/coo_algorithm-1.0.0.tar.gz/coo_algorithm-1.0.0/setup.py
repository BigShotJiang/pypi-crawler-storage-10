from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip()
                    and not line.startswith("#")]

setup(
    name="coo_algorithm",
    version="1.0.0",
    author="Sandip Garai",
    author_email="sandipnicksandy@gmail.com",
    description="Canine Olfactory Optimization (COO) Algorithm: A nature-inspired metaheuristic optimization algorithm based on the olfactory tracking behavior of canines.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/SandipGarai/coo_algorithm",
    packages=find_packages(exclude=['tests', 'tests.*']),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Mathematics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    extras_require={
        'dev': [
            'pytest>=6.0.0',
            'pytest-cov>=2.10.0',
            'pytest-mock>=3.3.0',
            'black>=21.0',
            'flake8>=3.8.0',
            'mypy>=0.900',
            'sphinx>=4.0.0',
            'sphinx-rtd-theme>=0.5.0',
        ],
        'benchmarks': [
            'matplotlib>=3.3.0',
            'pandas>=1.1.0',
            'seaborn>=0.11.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'coo-benchmark=coo_algorithm.cli:benchmark_cli',
        ],
    },
    keywords="optimization, metaheuristic, hyperparameter-tuning, machine-learning, evolutionary-algorithm",
    include_package_data=True,
    zip_safe=False,
    project_urls={
        "Bug Reports": "https://github.com/SandipGarai/coo_algorithm/issues",
        "Source": "https://github.com/SandipGarai/coo_algorithm",
        "Documentation": "https://github.com/SandipGarai/coo_algorithm/blob/main/README.md",
    },
)
