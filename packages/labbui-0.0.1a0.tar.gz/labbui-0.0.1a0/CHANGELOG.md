## 0.0.1a (Oct 26, 2025)

### Features
* create button sub ([#2](https://github.com/labbhq/labb/issues/2))


---


