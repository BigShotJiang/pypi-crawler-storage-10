# Тесты для skopeo-wrapper
