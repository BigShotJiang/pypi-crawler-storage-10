## Typing stubs for pycurl

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`pycurl`](https://github.com/pycurl/pycurl) package. It can be used by type checkers
to check code that uses `pycurl`. This version of
`types-pycurl` aims to provide accurate annotations for
`pycurl==7.45.7`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/pycurl`](https://github.com/python/typeshed/tree/main/stubs/pycurl)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`be34e9201db75891a67d4d3ce5e5705ee6636f6f`](https://github.com/python/typeshed/commit/be34e9201db75891a67d4d3ce5e5705ee6636f6f).