# -*- coding: utf-8 -*-
# remote/mention_manager.py
#
# مدیریت منشن تکی و گروهی با پذیرش آیدی عددی و @username
# - بدون parse_mode (نه HTML و نه Markdown)
# - تولید «منشن واقعی» با استفاده از entities (TEXT_LINK → tg://user?id=...)
# - سازگار با هندلرهای main.py شما:
#     set_mention_cmd(message, config.spam_config)
#     remove_mention_cmd(message, config.spam_config)
#     toggle_mention_cmd(message, config.spam_config)
#     group_mention_cmd(message, config.spam_config)
#
# نکته مهم: برای منشن واقعی، باید هنگام send_message علاوه بر text، entities هم پاس داده شود.
# این فایل هم خروجی ساده‌ی رشته‌ای می‌دهد (get_active_mentions) و هم خروجی متن+entities
# (get_active_mentions_with_entities). اسپمر/سایر بخش‌ها برای منشن واقعی باید دومی را مصرف کنند.


import re
import logging
from typing import List, Tuple, Dict, Any, Iterable

from pyrogram.types import MessageEntity
from pyrogram import enums

logger = logging.getLogger(__name__)

# --- حالت/تنظیمات داخلی ماژول ---
_STATE: Dict[str, Any] = {
    # منشن تکی
    "single_enabled": False,
    "single_text": "",
    "single_user_id": None,  # int

    # منشن گروهی
    "group_enabled": False,
    "group_text": "",
    "group_user_ids": [],  # List[int]
}

# الگوی یوزرنیم معتبر تلگرام: با حرف شروع، حداقل 5 کاراکتر
UN_RE = r"@[A-Za-z][A-Za-z0-9_]{4,31}"
# آیدی عددی: طول محافظه‌کارانه
ID_RE = r"\d{7,20}"
TOKEN_RE = re.compile(rf"(?:{UN_RE}|{ID_RE})")


# ---------- ابزارهای کمکی ----------

def _parse_single_input(raw: str) -> Tuple[str, str]:
    """
    فرمان تکی:
      menshen <متن...> <@username|ID>
    خروجی: (base_text, target_token)  یا ("","")
    """
    raw = (raw or "").strip()
    parts = raw.split(None, 1)  # نام فرمان + بقیه
    if len(parts) < 2:
        return "", ""
    rest = parts[1].strip()

    matches = list(TOKEN_RE.finditer(rest))
    if not matches:
        return "", ""

    last = matches[-1]
    base_text = rest[:last.start()].strip()
    target = last.group(0).strip()
    return base_text, target


def _parse_group_input(raw: str) -> Tuple[str, List[str]]:
    """
    فرمان گروهی:
      group_menshen <متن چندکلمه‌ای> <@user1|ID1> <@user2|ID2> ...
    خروجی: (base_text, [targets...])  یا ("",[])
    """
    raw = (raw or "").strip()
    parts = raw.split(None, 1)  # نام فرمان + بقیه
    if len(parts) < 2:
        return "", []

    rest = parts[1]

    m = TOKEN_RE.search(rest)
    if not m:
        # مقصدی پیدا نشد → کل rest متن است
        return rest.strip(), []

    first_idx = m.start()
    base_text = rest[:first_idx].strip()
    targets = TOKEN_RE.findall(rest[first_idx:])

    # حذف تکراری‌ها با حفظ ترتیب
    seen, uniq = set(), []
    for t in targets:
        t = t.strip()
        if t and (t not in seen):
            uniq.append(t)
            seen.add(t)

    return base_text, uniq


async def _resolve_to_ids(pyro_client, tokens: List[str]) -> List[int]:
    """
    تبدیل ترکیب @username/ID به لیست آیدی‌های عددی.
    """
    ids: List[int] = []
    for t in tokens:
        t = (t or "").strip()
        if not t:
            continue
        if t.startswith("@"):
            try:
                u = await pyro_client.get_users(t)
                ids.append(int(u.id))
            except Exception as e:
                logger.warning("_resolve_to_ids: cannot resolve %r -> %s", t, e)
        else:
            try:
                ids.append(int(t))
            except Exception:
                logger.warning("_resolve_to_ids: invalid numeric id %r", t)
    # یکتاسازی با حفظ ترتیب
    ids = list(dict.fromkeys(ids))
    return ids


def _make_text_link_entities(labels_and_ids: Iterable[Tuple[str, int]], sep: str = " ") -> Tuple[str, List[MessageEntity]]:
    """
    از لیست (label, user_id) یک متن و مجموعه entities از نوع TEXT_LINK می‌سازد.
    - sep: جداکننده بین لینک‌ها (مثلاً " " یا "\n" یا "، ")
    خروجی: (text, entities)
    """
    pieces: List[str] = []
    entities: List[MessageEntity] = []
    cursor = 0  # offset جاری

    for i, (label, uid) in enumerate(labels_and_ids):
        label = (label or "کاربر").strip() or "کاربر"
        link = f"tg://user?id={int(uid)}"

        if i > 0:
            pieces.append(sep)
            cursor += len(sep)

        pieces.append(label)
        length = len(label)
        entities.append(
            MessageEntity(
                type=enums.MessageEntityType.TEXT_LINK,
                offset=cursor,
                length=length,
                url=link
            )
        )
        cursor += length

    return "".join(pieces), entities


# ---------- API فرمان‌ها (امضاها مطابق هندلرهای main.py) ----------

async def set_mention_cmd(message, _spam_config=None):
    """
    ست‌کردن منشن تکی:
      setmenshen <متن...> <@username|ID>
    """
    base_text, target = _parse_single_input(message.text)

    if not target:
        await message.reply("استفاده: `setmenshen TEXT <@username|ID>`")
        return
    if not base_text:
        await message.reply("⚠️ متن منشن خالی است.")
        return

    # به آیدی عددی تبدیل
    if target.startswith("@"):
        try:
            u = await message._client.get_users(target)
            uid = int(u.id)
        except Exception as e:
            await message.reply(f"❌ خطا در resolve {target}: {e}")
            return
    else:
        try:
            uid = int(target)
        except Exception:
            await message.reply("❌ آیدی عددی معتبر نیست.")
            return

    # ذخیره در حالت داخلی
    _STATE["single_text"] = base_text
    _STATE["single_user_id"] = uid
    _STATE["single_enabled"] = True

    # پیش‌نمایش ساده (بدون parse_mode)
    preview_text, preview_entities = _make_text_link_entities([(base_text, uid)], sep=" ")
    await message.reply(f"✅ منشن تکی ذخیره شد:\n{preview_text}", entities=preview_entities, disable_web_page_preview=True)


async def remove_mention_cmd(message, _spam_config=None):
    """حذف تنظیمات منشن تکی"""
    _STATE["single_text"] = ""
    _STATE["single_user_id"] = None
    _STATE["single_enabled"] = False
    await message.reply("🗑 منشن تکی پاک شد.")


async def toggle_mention_cmd(message, _spam_config=None):
    """روشن/خاموش کردن منشن تکی"""
    _STATE["single_enabled"] = not _STATE.get("single_enabled", False)
    status = "روشن" if _STATE["single_enabled"] else "خاموش"

    info_text = ""
    info_entities: List[MessageEntity] = []
    if _STATE["single_user_id"] and _STATE["single_text"]:
        info_text, info_entities = _make_text_link_entities(
            [(_STATE["single_text"], _STATE["single_user_id"])],
            sep=" "
        )

    # اگر info_text وجود دارد، آن را در خط بعد نشان بده
    text = f"🔘 وضعیت منشن تکی: {status}"
    if info_text:
        text += f"\n— {info_text}"

    # ارسال بدون parse_mode
    await message.reply(text, entities=info_entities if info_text else None, disable_web_page_preview=True)


async def group_mention_cmd(message, _spam_config=None):
    """
    ست‌کردن منشن گروهی:
      group_menshen <متن...> <@user1|ID1> <@user2|ID2> ...
    """
    base_text, targets = _parse_group_input(message.text)

    if not base_text:
        await message.reply("⚠️ متن منشن خالی است.")
        return
    if not targets:
        await message.reply("❌ مقصدی داده نشد. @username یا آیدی عددی بده.")
        return

    try:
        ids = await _resolve_to_ids(message._client, targets)
    except Exception as e:
        await message.reply(f"❌ خطا در resolve مقصدها: {e}")
        return

    if not ids:
        await message.reply("❌ هیچ مقصد معتبری پیدا نشد.")
        return

    _STATE["group_text"] = base_text
    _STATE["group_user_ids"] = ids
    _STATE["group_enabled"] = True

    # پیش‌نمایش (بدون parse_mode) با entities
    # فقط 10 مورد اول را برای کوتاهی نشان می‌دهیم
    sample = ids[:10]
    preview_text, preview_entities = _make_text_link_entities([(base_text, i) for i in sample], sep="، ")
    more = f" و {len(ids)-10} مورد دیگر..." if len(ids) > 10 else ""
    await message.reply(
        f"✅ منشن گروهی ذخیره شد برای {len(ids)} کاربر:\n{preview_text}{more}",
        entities=preview_entities,
        disable_web_page_preview=True
    )


# ---------- API جهت مصرف سایر ماژول‌ها ----------

def get_single_mention_state() -> Dict[str, Any]:
    """خواندن وضعیت منشن تکی."""
    return {
        "enabled": bool(_STATE.get("single_enabled")),
        "text": _STATE.get("single_text") or "",
        "user_id": _STATE.get("single_user_id"),
    }


def get_group_mention_state() -> Dict[str, Any]:
    """خواندن وضعیت منشن گروهی."""
    return {
        "enabled": bool(_STATE.get("group_enabled")),
        "text": _STATE.get("group_text") or "",
        "user_ids": list(_STATE.get("group_user_ids") or []),
    }


def get_active_mentions(spam_config=None, sep: str = " ") -> str:
    """
    نسخه‌ی ساده‌ی رشته‌ای (بدون entities). اگر فقط متن می‌خواهی:
      "سلام (tg://user?id=...) ..."
    توجه: این «منشن واقعی» نمی‌سازد؛ برای منشن واقعی از تابع زیر استفاده کن.
    """
    parts: List[str] = []

    # تکی
    if _STATE.get("single_enabled") and _STATE.get("single_user_id") and (_STATE.get("single_text") or "").strip():
        txt, _ = _make_text_link_entities([(_STATE["single_text"], _STATE["single_user_id"])], sep=sep)
        parts.append(txt)

    # گروهی
    if _STATE.get("group_enabled") and _STATE.get("group_user_ids") and (_STATE.get("group_text") or "").strip():
        txt, _ = _make_text_link_entities(
            [(_STATE["group_text"], uid) for uid in _STATE["group_user_ids"]],
            sep=sep
        )
        parts.append(txt)

    return (sep.join(parts)).strip()


def get_active_mentions_with_entities(spam_config=None, sep: str = " ") -> Tuple[str, List[MessageEntity]]:
    """
    نسخه‌ی منشن واقعی:
      خروجی: (text, entities)
    - text شامل برچسب‌های منشن است (مثلاً چند بار کلمه «سلام»).
    - entities شامل TEXT_LINK‌هاست که هر کدام به tg://user?id=... اشاره می‌کند.
    - از parse_mode استفاده نمی‌شود.
    """
    labels_and_ids: List[Tuple[str, int]] = []

    # تکی
    if _STATE.get("single_enabled") and _STATE.get("single_user_id") and (_STATE.get("single_text") or "").strip():
        labels_and_ids.append((_STATE["single_text"], _STATE["single_user_id"]))

    # گروهی
    if _STATE.get("group_enabled") and _STATE.get("group_user_ids") and (_STATE.get("group_text") or "").strip():
        for uid in _STATE["group_user_ids"]:
            labels_and_ids.append((_STATE["group_text"], uid))

    if not labels_and_ids:
        return "", []

    return _make_text_link_entities(labels_and_ids, sep=sep)
