## Test data

Unless exception, files are the result of transforming `./test.txt` into desired test format.
