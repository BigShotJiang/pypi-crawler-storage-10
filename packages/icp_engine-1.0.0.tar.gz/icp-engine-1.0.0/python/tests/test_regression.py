import json
import pathlib

import icp_engine

TESTS_FOLDER = pathlib.Path(__file__).parent.absolute()
DATA_FOLDER = TESTS_FOLDER / "data"
DB_FOLDER = icp_engine.database_path / "db"


def test_issue_48():
    # issue https://github.com/elastic/die-python/issues/28
    # pr https://github.com/elastic/die-python/pull/30
    fpath = DATA_FOLDER / "test.rar"
    res = icp_engine.scan_file(fpath, icp_engine.ScanFlags.RESULT_AS_JSON, str(DB_FOLDER))
    assert res
    js = json.loads(res)
    assert len(js["detects"]) == 1
    assert js["detects"][0]["filetype"] == "Binary"

    values = js["detects"][0]["values"]
    assert len(values) > 0
    value = values[0]
    assert value["name"] == "RAR"
    assert value["string"].startswith("Archive: RAR(")
