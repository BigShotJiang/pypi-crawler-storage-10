# Hurley Generic Plot

A Python package for creating clinical trial plots.

## Installation
