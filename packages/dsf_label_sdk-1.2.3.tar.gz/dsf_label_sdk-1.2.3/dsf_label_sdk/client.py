# dsf_label_sdk/client.py
"""Main SDK Client with Async Support - Updated for new Gateway"""

import requests
from typing import Dict, List, Optional, Union, Any
from urllib.parse import urljoin
import time
from functools import wraps
import logging

from . import __version__
from .exceptions import ValidationError, LicenseError, APIError, RateLimitError
from .models import Field, Config, EvaluationResult
from itertools import islice

MAX_BATCH_EVAL = 1000

logger = logging.getLogger(__name__)

def _ensure_len(name: str, seq, max_len: int):
    """Asegura que una lista no exceda una longitud máxima."""
    if isinstance(seq, list) and len(seq) > max_len:
        raise ValidationError(f"{name} es demasiado grande — máximo {max_len}")

def _normalize_config_for_wire(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Ordena las claves del config para consistencia."""
    if not isinstance(cfg, dict):
        return {}
    return {k: cfg[k] for k in sorted(cfg.keys())}

def _sanitize_records(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Limpia los datos para que sean serializables a JSON."""
    return records

def _chunked(seq, size):
    """Divide una secuencia en sublotes (chunks) más pequeños."""
    it = iter(seq)
    return iter(lambda: list(islice(it, size)), [])

def retry_on_failure(max_retries: int = 3, delay: float = 1.0):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except RateLimitError as e:
                    if attempt < max_retries - 1:
                        sleep_time = e.retry_after
                        logger.warning(f"Rate limited. Retrying after {sleep_time}s...")
                        time.sleep(sleep_time)
                    last_exception = e
                except (requests.RequestException, APIError) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (2 ** attempt))
                        logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying...")
            logger.error(f"Request failed after {max_retries} attempts: {last_exception}")
            raise last_exception
        return wrapper
    return decorator

class LabelSDK:
    """
    SDK cliente para DSF Label API.
    Soporta evaluaciones asíncronas (sync removido en v2.0).
    """
    
    # ✅ ACTUALIZADO: Base URL sin /evaluate
    BASE_URL = 'https://label-poo0te5w2-api-dsfuptech.vercel.app/api'
    TIERS = {'community', 'professional', 'enterprise'}
    
    def __init__(
        self,
        license_key: Optional[str] = None,
        tier: str = 'community',
        base_url: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
        verify_ssl: bool = True
    ):
        """
        Inicializa el cliente SDK.
        
        Args:
            license_key: Clave de licencia para tiers premium
            tier: Tier de servicio (community, professional, enterprise)
            base_url: URL base de la API (default: Vercel /api)
            timeout: Timeout para requests HTTP
            max_retries: Número máximo de reintentos
            verify_ssl: Verificar certificados SSL
        """
        if tier not in self.TIERS:
            raise ValidationError(f"Invalid tier. Must be one of: {self.TIERS}")
        
        self.license_key = license_key
        self.tier = tier
        self.base_url = base_url or self.BASE_URL
        self.timeout = timeout
        self.max_retries = max_retries
        self.verify_ssl = verify_ssl
        
        # Configure session for connection pooling
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'DSF-Label-SDK-Python/{__version__}'
        })
        
        # Validate license on initialization for premium tiers
        if tier != 'community' and license_key:
            self._validate_license()
    
    def _validate_license(self) -> None:
        """Valida la licencia con un health check"""
        if self.tier == 'community' or not self.license_key:
            return

        try:
            # Simple health check - el gateway validará la licencia en enqueue
            resp = self.session.get(
                f"{self.base_url}/health",
                timeout=self.timeout,
                verify=self.verify_ssl
            )
            resp.raise_for_status()
            logger.debug(f"Gateway health OK for tier={self.tier}")
        except Exception as e:
            logger.warning(f"Health check failed: {e}")
    
    @retry_on_failure(max_retries=3, delay=1.5)
    def _make_request(self, endpoint: str, data: dict, method: str = "POST") -> dict:
        """
        Realiza request HTTP con reintentos.
        
        ✅ ACTUALIZADO: Routing simplificado para nuevo gateway
        """
        base = self.base_url.rstrip("/")
        ep = endpoint.strip().strip("/")
        
        # Construir URL
        if ep:
            url = f"{base}/{ep}"
        else:
            url = base

        try:
            if method == "GET":
                resp = self.session.get(url, timeout=self.timeout, verify=self.verify_ssl)
            else:
                resp = self.session.post(url, json=data, timeout=self.timeout, verify=self.verify_ssl)
        except requests.RequestException as e:
            raise APIError(f"Request failed: {str(e)}")

        # Handle 429 rate limiting
        if resp.status_code == 429:
            try:
                err = resp.json()
            except ValueError:
                err = {}
            retry_after = err.get("retry_after") or resp.headers.get("Retry-After", "60")
            try:
                retry_after_int = int(retry_after)
            except (ValueError, TypeError):
                retry_after_int = 60
            limit = err.get("limit")
            raise RateLimitError(
                err.get("error", "Rate limited by server"),
                retry_after=retry_after_int,
                limit=limit
            )

        # Parse response
        try:
            j = resp.json()
        except ValueError:
            j = {}

        if resp.status_code >= 400:
            msg = j.get("error", f"API returned HTTP {resp.status_code}")
            if resp.status_code == 403:
                raise LicenseError(msg)
            raise APIError(msg, status_code=resp.status_code)

        return j
    
    # ----------------------------------
    # ASYNC METHODS (única forma soportada)
    # ----------------------------------
    
    def submit_batch_async(
        self,
        data_points: List[Dict[str, Any]],
        config: Optional[Union[Dict, Config]] = None,
        mode: str = 'standard'
    ) -> str:
        """
        Envía batch a cola asíncrona.
        
        ✅ ACTUALIZADO: Usa /enqueue con payload correcto
        
        Args:
            data_points: Lista de datos a evaluar
            config: Configuración de campos
            mode: Modo de evaluación (standard, temporal_forgetting)
            
        Returns:
            job_id para consultar estado
            
        Example:
            >>> job_id = sdk.submit_batch_async(data, config)
            >>> result = sdk.wait_for_result(job_id)
        """
        if self.tier == "community":
            raise LicenseError("Async batch evaluation requires professional or enterprise tier")
        
        if isinstance(config, Config):
            config = config.to_dict()
        
        _ensure_len("data_points", data_points, MAX_BATCH_EVAL * 10)
        
        # ✅ Payload actualizado para nuevo gateway
        request_data = {
            'data_batch': _sanitize_records(data_points),
            'config': _normalize_config_for_wire(config or {}),
            'tier': self.tier,
            'license_key': self.license_key,
            'mode': mode
        }
        
        # ✅ POST a /enqueue
        response = self._make_request('enqueue', request_data, method='POST')
        job_id = response.get('job_id')
        
        if not job_id:
            raise APIError("Server did not return job_id")
        
        logger.info(f"Async job submitted: {job_id} ({len(data_points)} records)")
        return job_id
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Consulta el estado de un job asíncrono.
        
        ✅ ACTUALIZADO: Usa GET /status/{job_id}
        
        Args:
            job_id: ID del job a consultar
            
        Returns:
            Dict con 'status' y opcionalmente 'result' si completado
            
        Status posibles:
            - 'queued': En cola esperando procesamiento
            - 'running': Siendo procesado
            - 'completed': Finalizado exitosamente
            - 'failed': Error en procesamiento
        """
        # ✅ GET a /status/{job_id}
        try:
            response = self._make_request(f'status/{job_id}', {}, method='GET')
            logger.debug(f"Fetched status for job {job_id}: {response.get('status')}")
            return response
        except Exception as e:
            logger.error(f"Error fetching status for {job_id}: {e}")
            raise
    
    def wait_for_result(
        self,
        job_id: str,
        poll_interval: int = 5,
        timeout: int = 300
    ) -> List[EvaluationResult]:
        """
        Espera a que un job se complete con polling.
        
        Args:
            job_id: ID del job a esperar
            poll_interval: Segundos entre consultas de estado
            timeout: Timeout máximo en segundos
            
        Returns:
            Lista de EvaluationResult
            
        Raises:
            TimeoutError: Si excede timeout
            APIError: Si el job falla
        """
        start = time.time()
        
        while True:
            status_resp = self.get_job_status(job_id)
            status = status_resp.get('status')
            
            if status == 'completed':
                result = status_resp.get('result', {})
                scores = result.get('scores', [])
                
                if not scores:
                    raise APIError("Job completed but no scores returned")
                
                return [
                    EvaluationResult(
                        score=float(s),
                        tier=result.get('tier', self.tier),
                        confidence_level=result.get('confidence_level', 0.65),
                        metrics=result.get('metrics')
                    )
                    for s in scores
                ]
            
            elif status == 'failed':
                error_msg = status_resp.get('error', 'Unknown error')
                raise APIError(f"Job failed: {error_msg}")
            
            elif status in ('queued', 'running'):
                elapsed = time.time() - start
                if elapsed > timeout:
                    raise TimeoutError(f"Job {job_id} timed out after {timeout}s")
                
                # Warning si se acerca al timeout
                if elapsed > timeout * 0.8:
                    logger.warning(f"Job {job_id} running >{int((elapsed/timeout)*100)}% of timeout ({elapsed:.1f}s/{timeout}s)")
                
                logger.info(f"Job {job_id} status: {status}, waiting {poll_interval}s...")
                time.sleep(poll_interval)
            
            else:
                raise APIError(f"Unknown job status: {status}")
    
    def batch_evaluate_async(
        self,
        data_points: List[Dict[str, Any]],
        config: Optional[Union[Dict, Config]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        mode: str = 'standard'
    ) -> List[EvaluationResult]:
        """
        Método conveniente: submit + wait en una sola llamada.
        
        Args:
            data_points: Lista de datos a evaluar
            config: Configuración de campos
            poll_interval: Segundos entre consultas
            timeout: Timeout máximo
            mode: Modo de evaluación
            
        Returns:
            Lista de EvaluationResult
        """
        job_id = self.submit_batch_async(data_points, config, mode)
        logger.info(f"Batch job submitted: {job_id}")
        return self.wait_for_result(job_id, poll_interval, timeout)
    
    # ----------------------------------
    # DEPRECATED METHODS (compatibility)
    # ----------------------------------
    
    def evaluate(self, *args, **kwargs):
        """DEPRECATED: Sync evaluation removed. Use batch_evaluate_async()"""
        raise NotImplementedError(
            "Synchronous evaluation removed in v2.0. "
            "Use batch_evaluate_async() for async processing."
        )
    
    def batch_evaluate(self, *args, **kwargs):
        """DEPRECATED: Use batch_evaluate_async() instead"""
        logger.warning("batch_evaluate() is deprecated. Use batch_evaluate_async()")
        return self.batch_evaluate_async(*args, **kwargs)
    
    # ----------------------------------
    # UTILITY METHODS
    # ----------------------------------
    
    def create_config(self) -> Config:
        """Crea un builder de configuración."""
        return Config()
    
    def get_metrics(self) -> Optional[Dict]:
        """
        Obtiene métricas de performance (Premium feature).
        
        ⚠️ Not implemented in async-only architecture
        """
        logger.warning("Metrics not available in async-only mode")
        return None
    
    def close(self):
        """Cierra la sesión HTTP."""
        self.session.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
    
    def __repr__(self):
        return f"LabelSDK(tier='{self.tier}', url='{self.base_url}')"
