---
QUILL: usaf_memo
letterhead_title: DEPARTMENT OF THE AIR FORCE
letterhead_caption: YOUR SQUADRON HERE
memo_for:
  - ORG/SYM
  # - 2nd ORG/SYM
memo_from:
  - ORG/SYMBOL
  - ORGANIZATION
  - Street Address
  - City St 12345-6789
subject: Comply without pain -- markdown to official memo
signature_block:
  - FIRST M. LAST, Rank, USAF
tag_line: Aim High
---

Write your paragraphs here. Separate them with two new lines.

- Use bullets to nest paragraphs.
  - Indent to go deeper.

You can also **bold**, _italicize_, `code`, ~strikethrough~,
and [link](https://example.com/) your text.

Less formatting. More lethality.
