# setup.py
from setuptools import setup, find_packages

setup(
    name='rocket-amina',  
    version='0.1.0',
    packages=find_packages(),
    install_requires=[],  
    author='Fezazi Amina Khadidja',
    author_email='your.email@example.com',
    description='A simple package simulating rockets and circular rockets.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    license='MIT',
    url='https://github.com/yourusername/rocket',  
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)
