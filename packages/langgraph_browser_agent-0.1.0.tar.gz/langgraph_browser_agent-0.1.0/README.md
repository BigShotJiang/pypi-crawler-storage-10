# LangGraph Browser Agent

This project is a web browser agent built with LangGraph. It can navigate websites, fill out forms, and interact with web elements.

This library is built on top of LangGraph, a powerful framework for building agent applications, and leverages [deepagents](https://github.com/langchain-ai/deepagents/tree/master) and [langchain-mcp-adapters](https://github.com/langchain-ai/langchain-mcp-adapters/tree/main). It also supports two browser manipulation backends: [playwright-mcp](https://github.com/microsoft/playwright-mcp) and [BrowserMCP](https://github.com/BrowserMCP/mcp).

## Demo

![Demo](assets/demo.gif)

## Getting Started

1.  **Prerequisites:**

    This agent requires Node.js to be installed and the `npx` command to be available in your path.

    If you are using the `browsermcp` backend (the default), please read the documentation at https://docs.browsermcp.io/setup-extension to set up the browser extension.

2.  **Clone the repository:**

    ```bash
    git clone https://github.com/your-username/langgraph-browser-agent.git
    cd langgraph-browser-agent
    ```

2.  **Install dependencies:**

    ```bash
    uv pip install -e .
    ```

3.  **Set up your environment:**

    This agent uses Ollama by default. Make sure you have Ollama installed and running. You can pull the default model with:

    ```bash
    ollama pull gpt-oss:20b
    ```

    You can also use other models by specifying them when creating the agent.

## Usage

To use the browser agent in your own project, you can import the `create_browser_agent` function and use it in an async context:

```python
import asyncio
from langgraph_browser_agent import create_browser_agent

OBJECTIVE = "Go to google.com and search for 'what is langgraph?'"

async def main() -> None:
    """Run the github example."""
    async with create_browser_agent(model="openai:gpt-5") as agent:
        final_result = await agent.ainvoke({"messages": [("human", OBJECTIVE)]})
        final_result["messages"][-1].pretty_print()

if __name__ == "__main__":
    asyncio.run(main())
```

You can also specify a different model when creating the agent:

```python
async with create_browser_agent(model="ollama:qwen3:8b") as agent:
    # ...
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request if you have any suggestions or improvements.

## License

This project is licensed under the MIT License.