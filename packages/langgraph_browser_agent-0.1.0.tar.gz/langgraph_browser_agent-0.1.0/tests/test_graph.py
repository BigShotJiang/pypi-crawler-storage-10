import pytest
from langgraph_browser_agent import create_browser_agent
from langgraph.graph.state import CompiledStateGraph
from langchain_core.language_models.fake_chat_models import FakeChatModel

@pytest.mark.asyncio
class TestGraph:
    async def test_base(self):
        async with create_browser_agent(
            model=FakeChatModel(),
        ) as agent:
            assert isinstance(agent, CompiledStateGraph)