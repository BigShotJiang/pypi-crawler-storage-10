"""The core graph definition for the browser agent."""

import asyncio
from collections.abc import AsyncGenerator, Callable, Sequence
from contextlib import AsyncExitStack, asynccontextmanager
from typing import Any

from deepagents import create_deep_agent
from deepagents.middleware.subagents import CompiledSubAgent, SubAgent
from deepmerge import always_merger
from langchain.agents.middleware import (
    LLMToolSelectorMiddleware,
    ToolRetryMiddleware,
)
from langchain.agents.middleware.types import AgentMiddleware
from langchain.agents.structured_output import ResponseFormat
from langchain.chat_models import init_chat_model
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.cache.base import BaseCache
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.types import Checkpointer

_DEFAULT_MODEL: str = "ollama:gpt-oss:20b"
_MCP_CONFIG: dict[str, Any] = {
    "browser": {
        "transport": "stdio",
        "command": "npx",
    },
}
_RETRY_MIDDLEWARE_CONFIG: dict[str, Any] = {
    "max_retries": 3,
    "backoff_factor": 2.0,
    "initial_delay": 1.0,
    "max_delay": 60.0,
    "jitter": True,
}
_BROWSER_TOOL_SELECTOR_INSTRUCTIONS: str = """
Your goal is to select the single most appropriate browser tool to accomplish the user's objective.

**AVAILABLE TOOLS:**
{TOOLS}

**IMPORTANT RULES:**
- You can select a maximum of one browser manipulation action tool (e.g., click, type, navigate).
- If you select one browser action, you must also include the snapshot action.
"""


@asynccontextmanager
async def create_browser_agent(
    backend: str = "browsermcp",
    model: str | BaseChatModel = _DEFAULT_MODEL,
    tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
    *,
    system_prompt: str | None = None,
    middleware: Sequence[AgentMiddleware] = (),
    subagents: list[SubAgent | CompiledSubAgent] | None = None,
    response_format: ResponseFormat | None = None,
    context_schema: type[Any] | None = None,
    checkpointer: Checkpointer | None = None,
    store: BaseStore | None = None,
    use_longterm_memory: bool = False,
    interrupt_on: dict[str, Any] | None = None,
    debug: bool = False,
    name: str | None = None,
    cache: BaseCache | None = None,
    mcp_config: dict[str, Any] | None = None,
) -> AsyncGenerator[CompiledStateGraph, None]:
    """Create a browser agent.

    This agent is specialized for controlling a web browser and has access to
    browser control tools by default. It uses the Multi-Server MCP Client to
    communicate with browser automation backends.

    Args:
        backend: The browser automation backend to use. Can be 'browsermcp' or
            'playwright'.
        model: The model to use for the agent. Can be a string identifier or a
            BaseChatModel instance.
        tools: Additional tools the agent should have access to, besides the
            default browser tools.
        system_prompt: Additional instructions for the agent's system prompt.
        middleware: A sequence of AgentMiddleware to apply to the agent.
            ToolRetryMiddleware and LLMToolSelectorMiddleware are added by default.
        subagents: A list of subagents that the main agent can call.
        response_format: The structured output response format to use for the agent.
        context_schema: The schema for the agent's context.
        checkpointer: A checkpointer for persisting agent state between runs.
        store: A store for persisting long-term memories.
        use_longterm_memory: Whether to use long-term memory. Requires 'store' to be
            provided.
        interrupt_on: A dictionary mapping tool names to interrupt configurations.
        debug: Whether to enable debug mode.
        name: The name of the agent.
        cache: The cache to use for the agent.
        mcp_config: A custom configuration for the Multi-Server MCP Client.

    Yields:
        A configured and compiled deep agent capable of browser interaction.
    """
    if not isinstance(model, BaseChatModel):
        model = init_chat_model(model)

    default_mcp_config = _MCP_CONFIG.copy()
    match backend:
        case "browsermcp":
            default_mcp_config["browser"]["args"] = ["@browsermcp/mcp@latest"]
        case "playwright":
            default_mcp_config["browser"]["args"] = ["@playwright/mcp@latest"]
        case _:
            err_msg = f"Unsupported backend: {backend}"
            raise ValueError(err_msg)

    if mcp_config:
        always_merger.merge(default_mcp_config, mcp_config or {})
    mcp_client = MultiServerMCPClient(default_mcp_config)

    async with AsyncExitStack() as st:
        sessions = [await st.enter_async_context(mcp_client.session(server)) for server in mcp_client.connections]
        default_tools = [tool for sublist in await asyncio.gather(*map(load_mcp_tools, sessions)) for tool in sublist]
        if middleware is not None:
            if "ToolRetryMiddleware" not in [type(m).__name__ for m in middleware]:
                middleware = [*list(middleware), ToolRetryMiddleware(**_RETRY_MIDDLEWARE_CONFIG)]
            if "LLMToolSelectorMiddleware" not in [type(m).__name__ for m in middleware]:
                middleware = [
                    *list(middleware),
                    LLMToolSelectorMiddleware(
                        model=model,
                        system_prompt=_BROWSER_TOOL_SELECTOR_INSTRUCTIONS.format(
                            TOOLS="".join([f"- `{tool.name}: {tool.description}`\n" for tool in default_tools])
                        ),
                        max_tools=2,
                    ),
                ]
        yield create_deep_agent(
            model=model,
            tools=[*default_tools, *(tools or [])],
            system_prompt=system_prompt,
            middleware=middleware,
            subagents=subagents,
            response_format=response_format,
            context_schema=context_schema,
            checkpointer=checkpointer,
            store=store,
            use_longterm_memory=use_longterm_memory,
            interrupt_on=interrupt_on,
            debug=debug,
            name=name,
            cache=cache,
        )
