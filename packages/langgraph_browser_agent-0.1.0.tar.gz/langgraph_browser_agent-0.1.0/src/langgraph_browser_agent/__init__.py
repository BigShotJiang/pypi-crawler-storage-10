"""LangGraph Browser Agent."""

from langgraph_browser_agent.graph import create_browser_agent

__all__ = ["create_browser_agent"]
