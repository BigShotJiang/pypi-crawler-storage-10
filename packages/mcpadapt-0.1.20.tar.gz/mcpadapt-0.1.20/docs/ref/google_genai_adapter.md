# `Google GenAI Adapter`

::: mcpadapt.google_genai_adapter
