#!/usr/bin/env bash
# Example script: login using az and run a dry-run create-assignment against a management group.
set -euo pipefail

if [ -z "${AZURE_SUBSCRIPTION_ID-}" ]; then
  echo "Please set AZURE_SUBSCRIPTION_ID and optionally AZURE_TENANT_ID and AZURE_CLIENT_ID/SECRET for service principal login, or run 'az login'." >&2
  exit 2
fi

# ensure azure CLI login (interactive) if no service principal env vars present
if [ -z "${AZURE_CLIENT_ID-}" ] || [ -z "${AZURE_CLIENT_SECRET-}" ] || [ -z "${AZURE_TENANT_ID-}" ]; then
  echo "No SP credentials found; calling 'az login' for interactive auth..."
  az login
fi

export AZPE_SUBSCRIPTION_ID="$AZURE_SUBSCRIPTION_ID"

echo "Running dry-run assignment for management group 'my-mg'..."
python -m azure_policy_engine.cli --backend sdk --mgmt-group my-mg --dry-run create-assignment exampleAssign examples/assign-mg.json

