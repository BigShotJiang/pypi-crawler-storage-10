//
// Copyright 2016 (c) Stefan Seefeld
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt)

#include "greet.h"

int main()
{
  greet();
  return 0;
}
