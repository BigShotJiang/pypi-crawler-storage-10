Command-line interface
======================

.. argparse::
   :module: faber.cli
   :func: make_parser
   :prog: faber
