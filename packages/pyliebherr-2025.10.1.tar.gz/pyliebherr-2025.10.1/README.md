# PyLiebherr:  Access the Smart Home Device API Library

Python library to access the [Liebherr Smart Home API](https://developer.liebherr.com/apis/smartdevice-homeapi/) (account required).