"""
TikExt - مكتبة شاملة للتفاعل مع TikTok API
مطور بواسطة TOFEY - @qneeee
"""

from .core import TikExt

__version__ = "1.0.1"
__author__ = "tofey"
__email__ = "tofey.amrie@gmail.com"
__all__ = ['TikExt']