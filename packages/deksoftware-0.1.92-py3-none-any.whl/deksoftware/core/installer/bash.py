from .base import register_installer_bash

register_installer_bash('diskexpend', 'history', 'libvirt', 'sinicization', 'node')
