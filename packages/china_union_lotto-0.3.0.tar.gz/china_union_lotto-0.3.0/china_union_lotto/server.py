from datetime import datetime, timedelta
from enum import Enum
import json
from typing import Sequence

from zoneinfo import ZoneInfo
from tzlocal import get_localzone_name  # ← returns "Europe/Paris", etc.

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource
from mcp.shared.exceptions import McpError

from pydantic import BaseModel


class LottoTools(str, Enum):
    GET_CURRENT_TIME = "select_numbers"


class LottoResult(BaseModel):
    numbers: list[str]

class LottoServer:
    def select_numbers(self,count:int) -> LottoResult:
        ret=list()
        ret.append('1 2 3 4 5 6 7 ')   
        ret.append('11 2 3 4 5 6 7 ')   
        ret.append('21 2 3 4 5 6 7 ')   
        return LottoResult(numbers=ret)

async def serve() -> None:
    server = Server("mcp-china-union-lotto")
    lotto_server=LottoServer()

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available lotto tools."""
        return [
            Tool(
                name=LottoTools.SELECT_NUMBERS.value,
                description="select numbers for china union lotto",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "count": {
                            "type": "int",
                            "description": f"how many numbers to select",
                        }
                    },
                    "required": ["count"],
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(
        name: str, arguments: dict
    ) -> Sequence[TextContent]:
        """Handle tool calls for lotto."""
        try:
            match name:
                case LottoTools.SELECT_NUMBERS.value:
                    count = arguments.get("count")
                    if not count:
                        count = 5
                    result = lotto_server.select_numbers(count)
                case _:
                    raise ValueError(f"Unknown tool: {name}")

            return [
                TextContent(type="text", text=json.dumps(result.model_dump(), indent=2))
            ]

        except Exception as e:
            raise ValueError(f"Error processing lotto tool: {str(e)}")

    options = server.create_initialization_options()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, options)
