whistle
=======

.. automodule:: whistle
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::
    :maxdepth: 1

    whistle.dispatchers
    whistle.errors
    whistle.event
    whistle.listeners
    whistle.typing
