whistle.typing.listener
=======================

.. automodule:: whistle.typing.listener
    :members:
    :undoc-members:
    :show-inheritance:
