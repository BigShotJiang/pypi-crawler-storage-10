whistle.errors
==============

.. automodule:: whistle.errors
    :members:
    :undoc-members:
    :show-inheritance:
