from . import console

console.app()
