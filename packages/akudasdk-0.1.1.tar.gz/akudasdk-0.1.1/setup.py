from setuptools import setup, find_packages

setup(
    name="akudasdk",                # Your package name
    version="0.1.1",                     # Version number
    author="Your Name",                  # Your name
    description="A simple greeting package example",
    packages=find_packages(),            # Automatically find packages
    python_requires=">=3.8",             # Minimum Python version
)
