def say_hello(name: str) -> str:
    """Return a friendly greeting."""
    return f"Hello, {name}! Welcome to my package 😄😄"
