# This file makes Python treat the directory as a package.
# You can import key functions here for convenience.

from .greetings import say_hello

# Optional: define what is available when doing `from hello_package import *`
__all__ = ["say_hello"]
