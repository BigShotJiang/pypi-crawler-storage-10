# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Group Service."""

__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .create_member_role_admin_v1 import CreateMemberRoleAdminV1
from .delete_member_role_admin_v1 import DeleteMemberRoleAdminV1
from .delete_member_role_public_v1 import DeleteMemberRolePublicV1
from .delete_member_role_public_v2 import DeleteMemberRolePublicV2
from .get_member_roles_list_admin_v1 import GetMemberRolesListAdminV1
from .get_member_roles_list_p_5c76d5 import GetMemberRolesListPublicV1
from .get_member_roles_list_p_25257f import GetMemberRolesListPublicV2
from .get_single_member_role__4d5402 import GetSingleMemberRoleAdminV1
from .update_member_role_admin_v1 import UpdateMemberRoleAdminV1
from .update_member_role_perm_09ed62 import UpdateMemberRolePermissionAdminV1
from .update_member_role_public_v1 import UpdateMemberRolePublicV1
from .update_member_role_public_v2 import UpdateMemberRolePublicV2
