# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import threading
import logging
import bstack_utils.accessibility as bstack1l11l1lll_opy_
from bstack_utils.helper import bstack1l11lll11_opy_
logger = logging.getLogger(__name__)
def bstack1111l11ll_opy_(bstack1ll1l1l111_opy_):
  return True if bstack1ll1l1l111_opy_ in threading.current_thread().__dict__.keys() else False
def bstack1l1l1l1l1l_opy_(context, *args):
    tags = getattr(args[0], bstack1l11_opy_ (u"ࠬࡺࡡࡨࡵࠪភ"), [])
    bstack111l111l_opy_ = bstack1l11l1lll_opy_.bstack111lll1l11_opy_(tags)
    threading.current_thread().isA11yTest = bstack111l111l_opy_
    try:
      bstack111111l1_opy_ = threading.current_thread().bstackSessionDriver if bstack1111l11ll_opy_(bstack1l11_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬម")) else context.browser
      if bstack111111l1_opy_ and bstack111111l1_opy_.session_id and bstack111l111l_opy_ and bstack1l11lll11_opy_(
              threading.current_thread(), bstack1l11_opy_ (u"ࠧࡢ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭យ"), None):
          threading.current_thread().isA11yTest = bstack1l11l1lll_opy_.bstack11ll11lll1_opy_(bstack111111l1_opy_, bstack111l111l_opy_)
    except Exception as e:
       logger.debug(bstack1l11_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡥ࠶࠷ࡹࠡ࡫ࡱࠤࡧ࡫ࡨࡢࡸࡨ࠾ࠥࢁࡽࠨរ").format(str(e)))
def bstack1ll1111l_opy_(bstack111111l1_opy_):
    if bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ល"), None) and bstack1l11lll11_opy_(
      threading.current_thread(), bstack1l11_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩវ"), None) and not bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠫࡦ࠷࠱ࡺࡡࡶࡸࡴࡶࠧឝ"), False):
      threading.current_thread().a11y_stop = True
      bstack1l11l1lll_opy_.bstack111l111ll_opy_(bstack111111l1_opy_, name=bstack1l11_opy_ (u"ࠧࠨឞ"), path=bstack1l11_opy_ (u"ࠨࠢស"))