# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import json
import logging
import datetime
import threading
from bstack_utils.helper import bstack11ll1l1ll11_opy_, bstack1l11l1l11l_opy_, get_host_info, bstack11l11l1l11l_opy_, \
 bstack11ll1ll1l_opy_, bstack1l11lll11_opy_, error_handler, bstack11l1111l11l_opy_, bstack1llll1l1_opy_
import bstack_utils.accessibility as bstack1l11l1lll_opy_
from bstack_utils.bstack1ll1l111_opy_ import bstack11l11ll11l_opy_
from bstack_utils.bstack111ll11lll_opy_ import bstack1l1l1l1111_opy_
from bstack_utils.percy import bstack1lll111lll_opy_
from bstack_utils.config import Config
bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
logger = logging.getLogger(__name__)
percy = bstack1lll111lll_opy_()
@error_handler(class_method=False)
def bstack1llll11ll1ll_opy_(bs_config, bstack1l1lll1ll1_opy_):
  try:
    data = {
        bstack1l11_opy_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ⇲"): bstack1l11_opy_ (u"ࠫ࡯ࡹ࡯࡯ࠩ⇳"),
        bstack1l11_opy_ (u"ࠬࡶࡲࡰ࡬ࡨࡧࡹࡥ࡮ࡢ࡯ࡨࠫ⇴"): bs_config.get(bstack1l11_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫ⇵"), bstack1l11_opy_ (u"ࠧࠨ⇶")),
        bstack1l11_opy_ (u"ࠨࡰࡤࡱࡪ࠭⇷"): bs_config.get(bstack1l11_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ⇸"), os.path.basename(os.path.abspath(os.getcwd()))),
        bstack1l11_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭⇹"): bs_config.get(bstack1l11_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭⇺")),
        bstack1l11_opy_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪ⇻"): bs_config.get(bstack1l11_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡉ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩ⇼"), bstack1l11_opy_ (u"ࠧࠨ⇽")),
        bstack1l11_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬ⇾"): bstack1llll1l1_opy_(),
        bstack1l11_opy_ (u"ࠩࡷࡥ࡬ࡹࠧ⇿"): bstack11l11l1l11l_opy_(bs_config),
        bstack1l11_opy_ (u"ࠪ࡬ࡴࡹࡴࡠ࡫ࡱࡪࡴ࠭∀"): get_host_info(),
        bstack1l11_opy_ (u"ࠫࡨ࡯࡟ࡪࡰࡩࡳࠬ∁"): bstack1l11l1l11l_opy_(),
        bstack1l11_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣࡷࡻ࡮ࡠ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ∂"): os.environ.get(bstack1l11_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡈࡕࡊࡎࡇࡣࡗ࡛ࡎࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖࠬ∃")),
        bstack1l11_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪ࡟ࡵࡧࡶࡸࡸࡥࡲࡦࡴࡸࡲࠬ∄"): os.environ.get(bstack1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓ࠭∅"), False),
        bstack1l11_opy_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࡢࡧࡴࡴࡴࡳࡱ࡯ࠫ∆"): bstack11ll1l1ll11_opy_(),
        bstack1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ∇"): bstack1lll1lllll11_opy_(bs_config),
        bstack1l11_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡥࡧࡷࡥ࡮ࡲࡳࠨ∈"): bstack1llll1111l11_opy_(bstack1l1lll1ll1_opy_),
        bstack1l11_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹࡥ࡭ࡢࡲࠪ∉"): bstack1llll111l111_opy_(bs_config, bstack1l1lll1ll1_opy_.get(bstack1l11_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡸࡷࡪࡪࠧ∊"), bstack1l11_opy_ (u"ࠧࠨ∋"))),
        bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪ∌"): bstack11ll1ll1l_opy_(bs_config),
        bstack1l11_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡰࡴࡦ࡬ࡪࡹࡴࡳࡣࡷ࡭ࡴࡴࠧ∍"): bstack1llll1111l1l_opy_(bs_config)
    }
    return data
  except Exception as error:
    logger.error(bstack1l11_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡱࡣࡼࡰࡴࡧࡤࠡࡨࡲࡶ࡚ࠥࡥࡴࡶࡋࡹࡧࡀࠠࠡࡽࢀࠦ∎").format(str(error)))
    return None
def bstack1llll1111l11_opy_(framework):
  return {
    bstack1l11_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡎࡢ࡯ࡨࠫ∏"): framework.get(bstack1l11_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡰࡤࡱࡪ࠭∐"), bstack1l11_opy_ (u"࠭ࡐࡺࡶࡨࡷࡹ࠭∑")),
    bstack1l11_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭࡙ࡩࡷࡹࡩࡰࡰࠪ−"): framework.get(bstack1l11_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ∓")),
    bstack1l11_opy_ (u"ࠩࡶࡨࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭∔"): framework.get(bstack1l11_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ∕")),
    bstack1l11_opy_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭∖"): bstack1l11_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ∗"),
    bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡊࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭∘"): framework.get(bstack1l11_opy_ (u"ࠧࡵࡧࡶࡸࡋࡸࡡ࡮ࡧࡺࡳࡷࡱࠧ∙"))
  }
def bstack1llll1111l1l_opy_(bs_config):
  bstack1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࡒࡦࡶࡸࡶࡳࡹࠠࡵࡪࡨࠤࡹ࡫ࡳࡵࠢࡲࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯ࠢࡧࡥࡹࡧࠠࡧࡱࡵࠤࡧࡻࡩ࡭ࡦࠣࡷࡹࡧࡲࡵ࠰ࠍࠤࠥࠨࠢࠣ√")
  if not bs_config:
    return {}
  bstack1111l1ll111_opy_ = bstack11l11ll11l_opy_(bs_config).bstack1111ll11ll1_opy_(bs_config)
  return bstack1111l1ll111_opy_
def bstack111l11l11_opy_(bs_config, framework):
  bstack11llll1lll_opy_ = False
  bstack1l11lllll_opy_ = False
  bstack1lll1lllllll_opy_ = False
  if bstack1l11_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭∛") in bs_config:
    bstack1lll1lllllll_opy_ = True
  elif bstack1l11_opy_ (u"ࠪࡥࡵࡶࠧ∜") in bs_config:
    bstack11llll1lll_opy_ = True
  else:
    bstack1l11lllll_opy_ = True
  bstack1l1lll11l_opy_ = {
    bstack1l11_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫ∝"): bstack1l1l1l1111_opy_.bstack1llll11111l1_opy_(bs_config, framework),
    bstack1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ∞"): bstack1l11l1lll_opy_.bstack1ll111ll1_opy_(bs_config),
    bstack1l11_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬ∟"): bs_config.get(bstack1l11_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠭∠"), False),
    bstack1l11_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪ∡"): bstack1l11lllll_opy_,
    bstack1l11_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨ∢"): bstack11llll1lll_opy_,
    bstack1l11_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧ∣"): bstack1lll1lllllll_opy_
  }
  return bstack1l1lll11l_opy_
@error_handler(class_method=False)
def bstack1lll1lllll11_opy_(bs_config):
  try:
    bstack1llll1111lll_opy_ = json.loads(os.getenv(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡠࡃࡆࡇࡊ࡙ࡓࡊࡄࡌࡐࡎ࡚࡙ࡠࡅࡒࡒࡋࡏࡇࡖࡔࡄࡘࡎࡕࡎࡠ࡛ࡐࡐࠬ∤"), bstack1l11_opy_ (u"ࠬࢁࡽࠨ∥")))
    bstack1llll1111lll_opy_ = bstack1lll1lllll1l_opy_(bs_config, bstack1llll1111lll_opy_)
    return {
        bstack1l11_opy_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ∦"): bstack1llll1111lll_opy_
    }
  except Exception as error:
    logger.error(bstack1l11_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡦࡶࡪࡧࡴࡪࡰࡪࠤ࡬࡫ࡴࡠࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡠࡵࡨࡸࡹ࡯࡮ࡨࡵࠣࡪࡴࡸࠠࡕࡧࡶࡸࡍࡻࡢ࠻ࠢࠣࡿࢂࠨ∧").format(str(error)))
    return {}
def bstack1lll1lllll1l_opy_(bs_config, bstack1llll1111lll_opy_):
  if ((bstack1l11_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࠬ∨") in bs_config or not bstack11ll1ll1l_opy_(bs_config)) and bstack1l11l1lll_opy_.bstack1ll111ll1_opy_(bs_config)):
    bstack1llll1111lll_opy_[bstack1l11_opy_ (u"ࠤ࡬ࡲࡨࡲࡵࡥࡧࡈࡲࡨࡵࡤࡦࡦࡈࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠧ∩")] = True
  return bstack1llll1111lll_opy_
def bstack1llll111ll11_opy_(array, bstack1llll1111ll1_opy_, bstack1lll1llll1ll_opy_):
  result = {}
  for o in array:
    key = o[bstack1llll1111ll1_opy_]
    result[key] = o[bstack1lll1llll1ll_opy_]
  return result
def bstack1llll1l111l1_opy_(bstack11l1l1lll1_opy_=bstack1l11_opy_ (u"ࠪࠫ∪")):
  bstack1lll1llllll1_opy_ = bstack1l11l1lll_opy_.on()
  bstack1llll111111l_opy_ = bstack1l1l1l1111_opy_.on()
  bstack1llll1111111_opy_ = percy.bstack1l1lllllll_opy_()
  if bstack1llll1111111_opy_ and not bstack1llll111111l_opy_ and not bstack1lll1llllll1_opy_:
    return bstack11l1l1lll1_opy_ not in [bstack1l11_opy_ (u"ࠫࡈࡈࡔࡔࡧࡶࡷ࡮ࡵ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠨ∫"), bstack1l11_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩ∬")]
  elif bstack1lll1llllll1_opy_ and not bstack1llll111111l_opy_:
    return bstack11l1l1lll1_opy_ not in [bstack1l11_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧ∭"), bstack1l11_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ∮"), bstack1l11_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬ∯")]
  return bstack1lll1llllll1_opy_ or bstack1llll111111l_opy_ or bstack1llll1111111_opy_
@error_handler(class_method=False)
def bstack1llll1l1111l_opy_(bstack11l1l1lll1_opy_, test=None):
  bstack1llll11111ll_opy_ = bstack1l11l1lll_opy_.on()
  if not bstack1llll11111ll_opy_ or bstack11l1l1lll1_opy_ not in [bstack1l11_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ∰")] or test == None:
    return None
  return {
    bstack1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ∱"): bstack1llll11111ll_opy_ and bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪ∲"), None) == True and bstack1l11l1lll_opy_.bstack111lll1l11_opy_(test[bstack1l11_opy_ (u"ࠬࡺࡡࡨࡵࠪ∳")])
  }
def bstack1llll111l111_opy_(bs_config, framework):
  bstack11llll1lll_opy_ = False
  bstack1l11lllll_opy_ = False
  bstack1lll1lllllll_opy_ = False
  if bstack1l11_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪ∴") in bs_config:
    bstack1lll1lllllll_opy_ = True
  elif bstack1l11_opy_ (u"ࠧࡢࡲࡳࠫ∵") in bs_config:
    bstack11llll1lll_opy_ = True
  else:
    bstack1l11lllll_opy_ = True
  bstack1l1lll11l_opy_ = {
    bstack1l11_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠨ∶"): bstack1l1l1l1111_opy_.bstack1llll11111l1_opy_(bs_config, framework),
    bstack1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩ∷"): bstack1l11l1lll_opy_.bstack11ll1l11l_opy_(bs_config),
    bstack1l11_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩ∸"): bs_config.get(bstack1l11_opy_ (u"ࠫࡵ࡫ࡲࡤࡻࠪ∹"), False),
    bstack1l11_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡫ࠧ∺"): bstack1l11lllll_opy_,
    bstack1l11_opy_ (u"࠭ࡡࡱࡲࡢࡥࡺࡺ࡯࡮ࡣࡷࡩࠬ∻"): bstack11llll1lll_opy_,
    bstack1l11_opy_ (u"ࠧࡵࡷࡵࡦࡴࡹࡣࡢ࡮ࡨࠫ∼"): bstack1lll1lllllll_opy_
  }
  return bstack1l1lll11l_opy_