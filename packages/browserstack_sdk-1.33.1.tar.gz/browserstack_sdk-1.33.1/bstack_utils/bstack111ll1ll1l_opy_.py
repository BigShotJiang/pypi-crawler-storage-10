# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import bstack1llll1l1_opy_, bstack111llllllll_opy_
from bstack_utils.bstack1l1ll1ll11_opy_ import bstack1llllll11ll1_opy_
class bstack111l11ll11_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, started_at=None, framework=None, tags=[], scope=[], bstack1llll1lll111_opy_=None, bstack1llll1ll1lll_opy_=True, bstack1l111l11ll1_opy_=None, bstack11l1l1lll1_opy_=None, result=None, duration=None, bstack1111ll1lll_opy_=None, meta={}):
        self.bstack1111ll1lll_opy_ = bstack1111ll1lll_opy_
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack1llll1ll1lll_opy_:
            self.uuid = uuid4().__str__()
        self.started_at = started_at
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack1llll1lll111_opy_ = bstack1llll1lll111_opy_
        self.bstack1l111l11ll1_opy_ = bstack1l111l11ll1_opy_
        self.bstack11l1l1lll1_opy_ = bstack11l1l1lll1_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
        self.hooks = []
    def bstack1111ll1l1l_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack111l1ll11l_opy_(self, meta):
        self.meta = meta
    def bstack111ll11ll1_opy_(self, hooks):
        self.hooks = hooks
    def bstack1llll1lll1l1_opy_(self):
        bstack1llll1lllll1_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack1l11_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ⁱ"): bstack1llll1lllll1_opy_,
            bstack1l11_opy_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭⁲"): bstack1llll1lllll1_opy_,
            bstack1l11_opy_ (u"ࠬࡼࡣࡠࡨ࡬ࡰࡪࡶࡡࡵࡪࠪ⁳"): bstack1llll1lllll1_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack1l11_opy_ (u"ࠨࡕ࡯ࡧࡻࡴࡪࡩࡴࡦࡦࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸ࠿ࠦࠢ⁴") + key)
            setattr(self, key, val)
    def bstack1lllll11111l_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ⁵"): self.name,
            bstack1l11_opy_ (u"ࠨࡤࡲࡨࡾ࠭⁶"): {
                bstack1l11_opy_ (u"ࠩ࡯ࡥࡳ࡭ࠧ⁷"): bstack1l11_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ⁸"),
                bstack1l11_opy_ (u"ࠫࡨࡵࡤࡦࠩ⁹"): self.code
            },
            bstack1l11_opy_ (u"ࠬࡹࡣࡰࡲࡨࡷࠬ⁺"): self.scope,
            bstack1l11_opy_ (u"࠭ࡴࡢࡩࡶࠫ⁻"): self.tags,
            bstack1l11_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪ⁼"): self.framework,
            bstack1l11_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬ⁽"): self.started_at
        }
    def bstack1llll1llll1l_opy_(self):
        return {
         bstack1l11_opy_ (u"ࠩࡰࡩࡹࡧࠧ⁾"): self.meta
        }
    def bstack1llll1llll11_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠪࡧࡺࡹࡴࡰ࡯ࡕࡩࡷࡻ࡮ࡑࡣࡵࡥࡲ࠭ⁿ"): {
                bstack1l11_opy_ (u"ࠫࡷ࡫ࡲࡶࡰࡢࡲࡦࡳࡥࠨ₀"): self.bstack1llll1lll111_opy_
            }
        }
    def bstack1llll1llllll_opy_(self, bstack1lllll1111l1_opy_, details):
        step = next(filter(lambda st: st[bstack1l11_opy_ (u"ࠬ࡯ࡤࠨ₁")] == bstack1lllll1111l1_opy_, self.meta[bstack1l11_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬ₂")]), None)
        step.update(details)
    def bstack1lll111l11_opy_(self, bstack1lllll1111l1_opy_):
        step = next(filter(lambda st: st[bstack1l11_opy_ (u"ࠧࡪࡦࠪ₃")] == bstack1lllll1111l1_opy_, self.meta[bstack1l11_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧ₄")]), None)
        step.update({
            bstack1l11_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭₅"): bstack1llll1l1_opy_()
        })
    def bstack111l1llll1_opy_(self, bstack1lllll1111l1_opy_, result, duration=None):
        bstack1l111l11ll1_opy_ = bstack1llll1l1_opy_()
        if bstack1lllll1111l1_opy_ is not None and self.meta.get(bstack1l11_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩ₆")):
            step = next(filter(lambda st: st[bstack1l11_opy_ (u"ࠫ࡮ࡪࠧ₇")] == bstack1lllll1111l1_opy_, self.meta[bstack1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫ₈")]), None)
            step.update({
                bstack1l11_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫ₉"): bstack1l111l11ll1_opy_,
                bstack1l11_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ₊"): duration if duration else bstack111llllllll_opy_(step[bstack1l11_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬ₋")], bstack1l111l11ll1_opy_),
                bstack1l11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ₌"): result.result,
                bstack1l11_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫ₍"): str(result.exception) if result.exception else None
            })
    def add_step(self, bstack1llll1ll1ll1_opy_):
        if self.meta.get(bstack1l11_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪ₎")):
            self.meta[bstack1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫ₏")].append(bstack1llll1ll1ll1_opy_)
        else:
            self.meta[bstack1l11_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬₐ")] = [ bstack1llll1ll1ll1_opy_ ]
    def bstack1llll1ll1l1l_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠧࡶࡷ࡬ࡨࠬₑ"): self.bstack1111ll1l1l_opy_(),
            **self.bstack1lllll11111l_opy_(),
            **self.bstack1llll1lll1l1_opy_(),
            **self.bstack1llll1llll1l_opy_()
        }
    def bstack1llll1lll1ll_opy_(self):
        if not self.result:
            return {}
        data = {
            bstack1l11_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ₒ"): self.bstack1l111l11ll1_opy_,
            bstack1l11_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࡣ࡮ࡴ࡟࡮ࡵࠪₓ"): self.duration,
            bstack1l11_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪₔ"): self.result.result
        }
        if data[bstack1l11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫₕ")] == bstack1l11_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬₖ"):
            data[bstack1l11_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬₗ")] = self.result.bstack111111111l_opy_()
            data[bstack1l11_opy_ (u"ࠧࡧࡣ࡬ࡰࡺࡸࡥࠨₘ")] = [{bstack1l11_opy_ (u"ࠨࡤࡤࡧࡰࡺࡲࡢࡥࡨࠫₙ"): self.result.bstack111lll11l11_opy_()}]
        return data
    def bstack1lllll111111_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠩࡸࡹ࡮ࡪࠧₚ"): self.bstack1111ll1l1l_opy_(),
            **self.bstack1lllll11111l_opy_(),
            **self.bstack1llll1lll1l1_opy_(),
            **self.bstack1llll1lll1ll_opy_(),
            **self.bstack1llll1llll1l_opy_()
        }
    def bstack1111ll111l_opy_(self, event, result=None):
        if result:
            self.result = result
        if bstack1l11_opy_ (u"ࠪࡗࡹࡧࡲࡵࡧࡧࠫₛ") in event:
            return self.bstack1llll1ll1l1l_opy_()
        elif bstack1l11_opy_ (u"ࠫࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ₜ") in event:
            return self.bstack1lllll111111_opy_()
    def bstack1111lll11l_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack1l111l11ll1_opy_ = time if time else bstack1llll1l1_opy_()
        self.duration = duration if duration else bstack111llllllll_opy_(self.started_at, self.bstack1l111l11ll1_opy_)
        if result:
            self.result = result
class bstack111ll1l111_opy_(bstack111l11ll11_opy_):
    def __init__(self, hooks=[], bstack111ll11l11_opy_={}, *args, **kwargs):
        self.hooks = hooks
        self.bstack111ll11l11_opy_ = bstack111ll11l11_opy_
        super().__init__(*args, **kwargs, bstack11l1l1lll1_opy_=bstack1l11_opy_ (u"ࠬࡺࡥࡴࡶࠪ₝"))
    @classmethod
    def bstack1llll1ll11ll_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l11_opy_ (u"࠭ࡩࡥࠩ₞"): id(step),
                bstack1l11_opy_ (u"ࠧࡵࡧࡻࡸࠬ₟"): step.name,
                bstack1l11_opy_ (u"ࠨ࡭ࡨࡽࡼࡵࡲࡥࠩ₠"): step.keyword,
            })
        return bstack111ll1l111_opy_(
            **kwargs,
            meta={
                bstack1l11_opy_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࠪ₡"): {
                    bstack1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨ₢"): feature.name,
                    bstack1l11_opy_ (u"ࠫࡵࡧࡴࡩࠩ₣"): feature.filename,
                    bstack1l11_opy_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪ₤"): feature.description
                },
                bstack1l11_opy_ (u"࠭ࡳࡤࡧࡱࡥࡷ࡯࡯ࠨ₥"): {
                    bstack1l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ₦"): scenario.name
                },
                bstack1l11_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧ₧"): steps,
                bstack1l11_opy_ (u"ࠩࡨࡼࡦࡳࡰ࡭ࡧࡶࠫ₨"): bstack1llllll11ll1_opy_(test)
            }
        )
    def bstack1llll1ll1l11_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩ₩"): self.hooks
        }
    def bstack1lllll1111ll_opy_(self):
        if self.bstack111ll11l11_opy_:
            return {
                bstack1l11_opy_ (u"ࠫ࡮ࡴࡴࡦࡩࡵࡥࡹ࡯࡯࡯ࡵࠪ₪"): self.bstack111ll11l11_opy_
            }
        return {}
    def bstack1lllll111111_opy_(self):
        return {
            **super().bstack1lllll111111_opy_(),
            **self.bstack1llll1ll1l11_opy_()
        }
    def bstack1llll1ll1l1l_opy_(self):
        return {
            **super().bstack1llll1ll1l1l_opy_(),
            **self.bstack1lllll1111ll_opy_()
        }
    def bstack1111lll11l_opy_(self):
        return bstack1l11_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴࠧ₫")
class bstack111l1lll1l_opy_(bstack111l11ll11_opy_):
    def __init__(self, hook_type, *args,bstack111ll11l11_opy_={}, **kwargs):
        self.hook_type = hook_type
        self.bstack1ll11l1lll1_opy_ = None
        self.bstack111ll11l11_opy_ = bstack111ll11l11_opy_
        super().__init__(*args, **kwargs, bstack11l1l1lll1_opy_=bstack1l11_opy_ (u"࠭ࡨࡰࡱ࡮ࠫ€"))
    def bstack1111l1l11l_opy_(self):
        return self.hook_type
    def bstack1llll1lll11l_opy_(self):
        return {
            bstack1l11_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪ₭"): self.hook_type
        }
    def bstack1lllll111111_opy_(self):
        return {
            **super().bstack1lllll111111_opy_(),
            **self.bstack1llll1lll11l_opy_()
        }
    def bstack1llll1ll1l1l_opy_(self):
        return {
            **super().bstack1llll1ll1l1l_opy_(),
            bstack1l11_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢ࡭ࡩ࠭₮"): self.bstack1ll11l1lll1_opy_,
            **self.bstack1llll1lll11l_opy_()
        }
    def bstack1111lll11l_opy_(self):
        return bstack1l11_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࠫ₯")
    def bstack111ll1l1ll_opy_(self, bstack1ll11l1lll1_opy_):
        self.bstack1ll11l1lll1_opy_ = bstack1ll11l1lll1_opy_