# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import threading
import tempfile
import os
import time
from datetime import datetime
from bstack_utils.bstack11ll111111l_opy_ import bstack11ll11111ll_opy_
from bstack_utils.constants import bstack11l1l1l1ll1_opy_, bstack1l1l1ll111_opy_
from bstack_utils.bstack1ll1l111_opy_ import bstack11l11ll11l_opy_
from bstack_utils import bstack1l111llll_opy_
bstack11l1l1111l1_opy_ = 10
class bstack1llll1111_opy_:
    def __init__(self, bstack11ll1111ll_opy_, config, bstack11l1l11l11l_opy_=0):
        self.bstack11l1l11ll1l_opy_ = set()
        self.lock = threading.Lock()
        self.bstack11l11lll1ll_opy_ = bstack1l11_opy_ (u"ࠧࢁࡽ࠰ࡶࡨࡷࡹࡵࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲ࠴ࡧࡰࡪ࠱ࡹ࠵࠴࡬ࡡࡪ࡮ࡨࡨ࠲ࡺࡥࡴࡶࡶࠦ᫻").format(bstack11l1l1l1ll1_opy_)
        self.bstack11l1l111l1l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠨࡡࡣࡱࡵࡸࡤࡨࡵࡪ࡮ࡧࡣࢀࢃࠢ᫼").format(os.environ.get(bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬ᫽"))))
        self.bstack11l11llll11_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࡠࡶࡨࡷࡹࡹ࡟ࡼࡿ࠱ࡸࡽࡺࠢ᫾").format(os.environ.get(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧ᫿"))))
        self.bstack11l1l111l11_opy_ = 2
        self.bstack11ll1111ll_opy_ = bstack11ll1111ll_opy_
        self.config = config
        self.logger = bstack1l111llll_opy_.get_logger(__name__, bstack1l1l1ll111_opy_)
        self.bstack11l1l11l11l_opy_ = bstack11l1l11l11l_opy_
        self.bstack11l1l111lll_opy_ = False
        self.bstack11l11lllll1_opy_ = not (
                            os.environ.get(bstack1l11_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅ࡙ࡎࡒࡄࡠࡔࡘࡒࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠤᬀ")) and
                            os.environ.get(bstack1l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡒࡔࡊࡅࡠࡋࡑࡈࡊ࡞ࠢᬁ")) and
                            os.environ.get(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡕࡔࡂࡎࡢࡒࡔࡊࡅࡠࡅࡒ࡙ࡓ࡚ࠢᬂ"))
                        )
        if bstack11l11ll11l_opy_.bstack11l1l1111ll_opy_(config):
            self.bstack11l1l111l11_opy_ = bstack11l11ll11l_opy_.bstack11l11llllll_opy_(config, self.bstack11l1l11l11l_opy_)
            self.bstack11l1l11lll1_opy_()
    def bstack11l11lll1l1_opy_(self):
        return bstack1l11_opy_ (u"ࠨࡻࡾࡡࡾࢁࠧᬃ").format(self.config.get(bstack1l11_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪᬄ")), os.environ.get(bstack1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡗࡌࡐࡉࡥࡒࡖࡐࡢࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧᬅ")))
    def bstack11l1l11l1ll_opy_(self):
        try:
            if self.bstack11l11lllll1_opy_:
                return
            with self.lock:
                try:
                    with open(self.bstack11l11llll11_opy_, bstack1l11_opy_ (u"ࠤࡵࠦᬆ")) as f:
                        bstack11l1l111ll1_opy_ = set(line.strip() for line in f if line.strip())
                except FileNotFoundError:
                    bstack11l1l111ll1_opy_ = set()
                bstack11l1l111111_opy_ = bstack11l1l111ll1_opy_ - self.bstack11l1l11ll1l_opy_
                if not bstack11l1l111111_opy_:
                    return
                self.bstack11l1l11ll1l_opy_.update(bstack11l1l111111_opy_)
                data = {bstack1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࡗࡩࡸࡺࡳࠣᬇ"): list(self.bstack11l1l11ll1l_opy_), bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠢᬈ"): self.config.get(bstack1l11_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨᬉ")), bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡗࡻ࡮ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠦᬊ"): os.environ.get(bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡂࡖࡋࡏࡈࡤࡘࡕࡏࡡࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗ࠭ᬋ")), bstack1l11_opy_ (u"ࠣࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪࠨᬌ"): self.config.get(bstack1l11_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧᬍ"))}
            response = bstack11ll11111ll_opy_.bstack11l1l11ll11_opy_(self.bstack11l11lll1ll_opy_, data)
            if response.get(bstack1l11_opy_ (u"ࠥࡷࡹࡧࡴࡶࡵࠥᬎ")) == 200:
                self.logger.debug(bstack1l11_opy_ (u"ࠦࡘࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠣࡷࡪࡴࡴࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡨࡷࡹࡹ࠺ࠡࡽࢀࠦᬏ").format(data))
            else:
                self.logger.debug(bstack1l11_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡦࡢ࡫࡯ࡩࡩࠦࡴࡦࡵࡷࡷ࠿ࠦࡻࡾࠤᬐ").format(response))
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡧࡹࡷ࡯࡮ࡨࠢࡶࡩࡳࡪࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦࠣࡸࡪࡹࡴࡴ࠼ࠣࡿࢂࠨᬑ").format(e))
    def bstack11l11llll1l_opy_(self):
        if self.bstack11l11lllll1_opy_:
            with self.lock:
                try:
                    with open(self.bstack11l11llll11_opy_, bstack1l11_opy_ (u"ࠢࡳࠤᬒ")) as f:
                        bstack11l1l11l1l1_opy_ = set(line.strip() for line in f if line.strip())
                    failed_count = len(bstack11l1l11l1l1_opy_)
                except FileNotFoundError:
                    failed_count = 0
                self.logger.debug(bstack1l11_opy_ (u"ࠣࡒࡲࡰࡱ࡫ࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡨࡷࡹࡹࠠࡤࡱࡸࡲࡹࠦࠨ࡭ࡱࡦࡥࡱ࠯࠺ࠡࡽࢀࠦᬓ").format(failed_count))
                if failed_count >= self.bstack11l1l111l11_opy_:
                    self.logger.info(bstack1l11_opy_ (u"ࠤࡗ࡬ࡷ࡫ࡳࡩࡱ࡯ࡨࠥࡩࡲࡰࡵࡶࡩࡩࠦࠨ࡭ࡱࡦࡥࡱ࠯࠺ࠡࡽࢀࠤࡃࡃࠠࡼࡿࠥᬔ").format(failed_count, self.bstack11l1l111l11_opy_))
                    self.bstack11l1l11l111_opy_(failed_count)
                    self.bstack11l1l111lll_opy_ = True
            return
        try:
            response = bstack11ll11111ll_opy_.bstack11l11llll1l_opy_(bstack1l11_opy_ (u"ࠥࡿࢂࡅࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦ࠿ࡾࢁࠫࡨࡵࡪ࡮ࡧࡖࡺࡴࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࡀࡿࢂࠬࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࡁࢀࢃࠢᬕ").format(self.bstack11l11lll1ll_opy_, self.config.get(bstack1l11_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧᬖ")), os.environ.get(bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇ࡛ࡉࡍࡆࡢࡖ࡚ࡔ࡟ࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠫᬗ")), self.config.get(bstack1l11_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫᬘ"))))
            if response.get(bstack1l11_opy_ (u"ࠢࡴࡶࡤࡸࡺࡹࠢᬙ")) == 200:
                failed_count = response.get(bstack1l11_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࡕࡧࡶࡸࡸࡉ࡯ࡶࡰࡷࠦᬚ"), 0)
                self.logger.debug(bstack1l11_opy_ (u"ࠤࡓࡳࡱࡲࡥࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡷࡩࡸࡺࡳࠡࡥࡲࡹࡳࡺ࠺ࠡࡽࢀࠦᬛ").format(failed_count))
                if failed_count >= self.bstack11l1l111l11_opy_:
                    self.logger.info(bstack1l11_opy_ (u"ࠥࡘ࡭ࡸࡥࡴࡪࡲࡰࡩࠦࡣࡳࡱࡶࡷࡪࡪ࠺ࠡࡽࢀࠤࡃࡃࠠࡼࡿࠥᬜ").format(failed_count, self.bstack11l1l111l11_opy_))
                    self.bstack11l1l11l111_opy_(failed_count)
                    self.bstack11l1l111lll_opy_ = True
            else:
                self.logger.error(bstack1l11_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡱࡱ࡯ࡰࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡺࡥࡴࡶࡶ࠾ࠥࢁࡽࠣᬝ").format(response))
        except Exception as e:
            self.logger.error(bstack1l11_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡦࡸࡶ࡮ࡴࡧࠡࡲࡲࡰࡱ࡯࡮ࡨ࠼ࠣࡿࢂࠨᬞ").format(e))
    def bstack11l1l11l111_opy_(self, failed_count):
        with open(self.bstack11l1l111l1l_opy_, bstack1l11_opy_ (u"ࠨࡷࠣᬟ")) as f:
            f.write(bstack1l11_opy_ (u"ࠢࡕࡪࡵࡩࡸ࡮࡯࡭ࡦࠣࡧࡷࡵࡳࡴࡧࡧࠤࡦࡺࠠࡼࡿ࡟ࡲࠧᬠ").format(datetime.now()))
            f.write(bstack1l11_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡨࡷࡹࡹࠠࡤࡱࡸࡲࡹࡀࠠࡼࡿ࡟ࡲࠧᬡ").format(failed_count))
        self.logger.debug(bstack1l11_opy_ (u"ࠤࡄࡦࡴࡸࡴࠡࡄࡸ࡭ࡱࡪࠠࡧ࡫࡯ࡩࠥࡩࡲࡦࡣࡷࡩࡩࡀࠠࡼࡿࠥᬢ").format(self.bstack11l1l111l1l_opy_))
    def bstack11l1l11lll1_opy_(self):
        def bstack11l1l11111l_opy_():
            while not self.bstack11l1l111lll_opy_:
                time.sleep(bstack11l1l1111l1_opy_)
                self.bstack11l1l11l1ll_opy_()
                self.bstack11l11llll1l_opy_()
        bstack11l11lll11l_opy_ = threading.Thread(target=bstack11l1l11111l_opy_, daemon=True)
        bstack11l11lll11l_opy_.start()