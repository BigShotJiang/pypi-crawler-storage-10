# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import tempfile
import math
from bstack_utils import bstack1l111llll_opy_
from bstack_utils.constants import bstack1l1l1ll111_opy_, bstack11l1ll11l11_opy_
from bstack_utils.helper import bstack111ll1l1l1l_opy_, get_host_info
from bstack_utils.bstack11ll111111l_opy_ import bstack11ll11111ll_opy_
import json
import re
import sys
bstack1111ll11111_opy_ = bstack1l11_opy_ (u"ࠨࡲࡦࡶࡵࡽ࡙࡫ࡳࡵࡵࡒࡲࡋࡧࡩ࡭ࡷࡵࡩࠧṼ")
bstack1111l1l11l1_opy_ = bstack1l11_opy_ (u"ࠢࡢࡤࡲࡶࡹࡈࡵࡪ࡮ࡧࡓࡳࡌࡡࡪ࡮ࡸࡶࡪࠨṽ")
bstack1111l1l1l1l_opy_ = bstack1l11_opy_ (u"ࠣࡴࡸࡲࡕࡸࡥࡷ࡫ࡲࡹࡸࡲࡹࡇࡣ࡬ࡰࡪࡪࡆࡪࡴࡶࡸࠧṾ")
bstack1111llll111_opy_ = bstack1l11_opy_ (u"ࠤࡵࡩࡷࡻ࡮ࡑࡴࡨࡺ࡮ࡵࡵࡴ࡮ࡼࡊࡦ࡯࡬ࡦࡦࠥṿ")
bstack1111l1l1lll_opy_ = bstack1l11_opy_ (u"ࠥࡷࡰ࡯ࡰࡇ࡮ࡤ࡯ࡾࡧ࡮ࡥࡈࡤ࡭ࡱ࡫ࡤࠣẀ")
bstack1111l1l1111_opy_ = bstack1l11_opy_ (u"ࠦࡷࡻ࡮ࡔ࡯ࡤࡶࡹ࡙ࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠣẁ")
bstack1111l1l1ll1_opy_ = {
    bstack1111ll11111_opy_,
    bstack1111l1l11l1_opy_,
    bstack1111l1l1l1l_opy_,
    bstack1111llll111_opy_,
    bstack1111l1l1lll_opy_,
    bstack1111l1l1111_opy_
}
bstack1111lll1l1l_opy_ = {bstack1l11_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬẂ")}
logger = bstack1l111llll_opy_.get_logger(__name__, bstack1l1l1ll111_opy_)
class bstack1111llllll1_opy_:
    def __init__(self):
        self.enabled = False
        self.name = None
    def enable(self, name):
        self.enabled = True
        self.name = name
    def disable(self):
        self.enabled = False
        self.name = None
    def bstack1111ll1llll_opy_(self):
        return self.enabled
    def get_name(self):
        return self.name
class bstack11l11ll11l_opy_:
    _1ll1ll11l1l_opy_ = None
    def __init__(self, config):
        self.bstack1111ll1ll11_opy_ = False
        self.bstack1111l1lll11_opy_ = False
        self.bstack1111lll1111_opy_ = False
        self.bstack111l1111lll_opy_ = False
        self.bstack1111ll11l11_opy_ = None
        self.bstack1111ll1ll1l_opy_ = bstack1111llllll1_opy_()
        self.bstack1111l1ll1ll_opy_ = None
        opts = config.get(bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡓࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࡒࡴࡹ࡯࡯࡯ࡵࠪẃ"), {})
        self.bstack1111lll1ll1_opy_ = config.get(bstack1l11_opy_ (u"ࠧࡴ࡯ࡤࡶࡹ࡙ࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࡇࡧࡤࡸࡺࡸࡥࡃࡴࡤࡲࡨ࡮ࡥࡴࡇࡑ࡚ࠬẄ"), bstack1l11_opy_ (u"ࠣࠤẅ"))
        self.bstack1111ll11lll_opy_ = config.get(bstack1l11_opy_ (u"ࠩࡶࡱࡦࡸࡴࡔࡧ࡯ࡩࡨࡺࡩࡰࡰࡉࡩࡦࡺࡵࡳࡧࡅࡶࡦࡴࡣࡩࡧࡶࡇࡑࡏࠧẆ"), bstack1l11_opy_ (u"ࠥࠦẇ"))
        bstack1111llll1l1_opy_ = opts.get(bstack1111l1l1111_opy_, {})
        bstack111l11111l1_opy_ = None
        if bstack1l11_opy_ (u"ࠫࡸࡵࡵࡳࡥࡨࠫẈ") in bstack1111llll1l1_opy_:
            bstack111l11111l1_opy_ = bstack1111llll1l1_opy_[bstack1l11_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬẉ")]
            if bstack111l11111l1_opy_ is None:
                bstack111l11111l1_opy_ = []
        self.__1111l1l1l11_opy_(
            bstack1111llll1l1_opy_.get(bstack1l11_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧẊ"), False),
            bstack1111llll1l1_opy_.get(bstack1l11_opy_ (u"ࠧ࡮ࡱࡧࡩࠬẋ"), bstack1l11_opy_ (u"ࠨࡴࡨࡰࡪࡼࡡ࡯ࡶࡉ࡭ࡷࡹࡴࠨẌ")),
            bstack111l11111l1_opy_
        )
        self.__111l111111l_opy_(opts.get(bstack1111l1l1l1l_opy_, False))
        self.__1111ll111l1_opy_(opts.get(bstack1111llll111_opy_, False))
        self.__111l1111l1l_opy_(opts.get(bstack1111l1l1lll_opy_, False))
    @classmethod
    def bstack1llll11111_opy_(cls, config=None):
        if cls._1ll1ll11l1l_opy_ is None and config is not None:
            cls._1ll1ll11l1l_opy_ = bstack11l11ll11l_opy_(config)
        return cls._1ll1ll11l1l_opy_
    @staticmethod
    def bstack11lll11l1_opy_(config: dict) -> bool:
        bstack1111lll1l11_opy_ = config.get(bstack1l11_opy_ (u"ࠩࡷࡩࡸࡺࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࡕࡰࡵ࡫ࡲࡲࡸ࠭ẍ"), {}).get(bstack1111ll11111_opy_, {})
        return bstack1111lll1l11_opy_.get(bstack1l11_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫẎ"), False)
    @staticmethod
    def bstack11ll11l1l1_opy_(config: dict) -> int:
        bstack1111lll1l11_opy_ = config.get(bstack1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨẏ"), {}).get(bstack1111ll11111_opy_, {})
        retries = 0
        if bstack11l11ll11l_opy_.bstack11lll11l1_opy_(config):
            retries = bstack1111lll1l11_opy_.get(bstack1l11_opy_ (u"ࠬࡳࡡࡹࡔࡨࡸࡷ࡯ࡥࡴࠩẐ"), 1)
        return retries
    @staticmethod
    def bstack11lll111ll_opy_(config: dict) -> dict:
        bstack1111l1ll111_opy_ = config.get(bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡓࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࡒࡴࡹ࡯࡯࡯ࡵࠪẑ"), {})
        return {
            key: value for key, value in bstack1111l1ll111_opy_.items() if key in bstack1111l1l1ll1_opy_
        }
    @staticmethod
    def bstack1111ll1l11l_opy_():
        bstack1l11_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡈ࡮ࡥࡤ࡭ࠣ࡭࡫ࠦࡴࡩࡧࠣࡥࡧࡵࡲࡵࠢࡥࡹ࡮ࡲࡤࠡࡨ࡬ࡰࡪࠦࡥࡹ࡫ࡶࡸࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦẒ")
        return os.path.exists(os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠣࡣࡥࡳࡷࡺ࡟ࡣࡷ࡬ࡰࡩࡥࡻࡾࠤẓ").format(os.getenv(bstack1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠢẔ")))))
    @staticmethod
    def bstack1111lll111l_opy_(test_name: str):
        bstack1l11_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡄࡪࡨࡧࡰࠦࡩࡧࠢࡷ࡬ࡪࠦࡡࡣࡱࡵࡸࠥࡨࡵࡪ࡮ࡧࠤ࡫࡯࡬ࡦࠢࡨࡼ࡮ࡹࡴࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢẕ")
        bstack1111lllll11_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࡢࡿࢂ࠴ࡴࡹࡶࠥẖ").format(os.getenv(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠥẗ"))))
        with open(bstack1111lllll11_opy_, bstack1l11_opy_ (u"࠭ࡡࠨẘ")) as file:
            file.write(bstack1l11_opy_ (u"ࠢࡼࡿ࡟ࡲࠧẙ").format(test_name))
    @staticmethod
    def bstack1111l1l111l_opy_(framework: str) -> bool:
       return framework.lower() in bstack1111lll1l1l_opy_
    @staticmethod
    def bstack11l1l1111ll_opy_(config: dict) -> bool:
        bstack1111l1lllll_opy_ = config.get(bstack1l11_opy_ (u"ࠨࡶࡨࡷࡹࡕࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲࡔࡶࡴࡪࡱࡱࡷࠬẚ"), {}).get(bstack1111l1l11l1_opy_, {})
        return bstack1111l1lllll_opy_.get(bstack1l11_opy_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪẛ"), False)
    @staticmethod
    def bstack11l11llllll_opy_(config: dict, bstack11l1l11l11l_opy_: int = 0) -> int:
        bstack1l11_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡈࡧࡷࠤࡹ࡮ࡥࠡࡨࡤ࡭ࡱࡻࡲࡦࠢࡷ࡬ࡷ࡫ࡳࡩࡱ࡯ࡨ࠱ࠦࡷࡩ࡫ࡦ࡬ࠥࡩࡡ࡯ࠢࡥࡩࠥࡧ࡮ࠡࡣࡥࡷࡴࡲࡵࡵࡧࠣࡲࡺࡳࡢࡦࡴࠣࡳࡷࠦࡡࠡࡲࡨࡶࡨ࡫࡮ࡵࡣࡪࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࡂࡴࡪࡷ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡧ࡫ࡪࠤ࠭ࡪࡩࡤࡶࠬ࠾࡚ࠥࡨࡦࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡨࡺࡩࡰࡰࡤࡶࡾ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡺ࡯ࡵࡣ࡯ࡣࡹ࡫ࡳࡵࡵࠣࠬ࡮ࡴࡴࠪ࠼ࠣࡘ࡭࡫ࠠࡵࡱࡷࡥࡱࠦ࡮ࡶ࡯ࡥࡩࡷࠦ࡯ࡧࠢࡷࡩࡸࡺࡳࠡࠪࡵࡩࡶࡻࡩࡳࡧࡧࠤ࡫ࡵࡲࠡࡲࡨࡶࡨ࡫࡮ࡵࡣࡪࡩ࠲ࡨࡡࡴࡧࡧࠤࡹ࡮ࡲࡦࡵ࡫ࡳࡱࡪࡳࠪ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡗ࡫ࡴࡶࡴࡱࡷ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮ࡴࡴ࠻ࠢࡗ࡬ࡪࠦࡦࡢ࡫࡯ࡹࡷ࡫ࠠࡵࡪࡵࡩࡸ࡮࡯࡭ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣẜ")
        bstack1111l1lllll_opy_ = config.get(bstack1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨẝ"), {}).get(bstack1l11_opy_ (u"ࠬࡧࡢࡰࡴࡷࡆࡺ࡯࡬ࡥࡑࡱࡊࡦ࡯࡬ࡶࡴࡨࠫẞ"), {})
        bstack1111lll11ll_opy_ = 0
        bstack1111l1ll1l1_opy_ = 0
        if bstack11l11ll11l_opy_.bstack11l1l1111ll_opy_(config):
            bstack1111l1ll1l1_opy_ = bstack1111l1lllll_opy_.get(bstack1l11_opy_ (u"࠭࡭ࡢࡺࡉࡥ࡮ࡲࡵࡳࡧࡶࠫẟ"), 5)
            if isinstance(bstack1111l1ll1l1_opy_, str) and bstack1111l1ll1l1_opy_.endswith(bstack1l11_opy_ (u"ࠧࠦࠩẠ")):
                try:
                    percentage = int(bstack1111l1ll1l1_opy_.strip(bstack1l11_opy_ (u"ࠨࠧࠪạ")))
                    if bstack11l1l11l11l_opy_ > 0:
                        bstack1111lll11ll_opy_ = math.ceil((percentage * bstack11l1l11l11l_opy_) / 100)
                    else:
                        raise ValueError(bstack1l11_opy_ (u"ࠤࡗࡳࡹࡧ࡬ࠡࡶࡨࡷࡹࡹࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡲࡵࡳࡻ࡯ࡤࡦࡦࠣࡪࡴࡸࠠࡱࡧࡵࡧࡪࡴࡴࡢࡩࡨ࠱ࡧࡧࡳࡦࡦࠣࡸ࡭ࡸࡥࡴࡪࡲࡰࡩࡹ࠮ࠣẢ"))
                except ValueError as e:
                    raise ValueError(bstack1l11_opy_ (u"ࠥࡍࡳࡼࡡ࡭࡫ࡧࠤࡵ࡫ࡲࡤࡧࡱࡸࡦ࡭ࡥࠡࡸࡤࡰࡺ࡫ࠠࡧࡱࡵࠤࡲࡧࡸࡇࡣ࡬ࡰࡺࡸࡥࡴ࠼ࠣࡿࢂࠨả").format(bstack1111l1ll1l1_opy_)) from e
            else:
                bstack1111lll11ll_opy_ = int(bstack1111l1ll1l1_opy_)
        logger.info(bstack1l11_opy_ (u"ࠦࡒࡧࡸࠡࡨࡤ࡭ࡱࡻࡲࡦࡵࠣࡸ࡭ࡸࡥࡴࡪࡲࡰࡩࠦࡳࡦࡶࠣࡸࡴࡀࠠࡼࡿࠣࠬ࡫ࡸ࡯࡮ࠢࡦࡳࡳ࡬ࡩࡨ࠼ࠣࡿࢂ࠯ࠢẤ").format(bstack1111lll11ll_opy_, bstack1111l1ll1l1_opy_))
        return bstack1111lll11ll_opy_
    def bstack1111l1llll1_opy_(self):
        return self.bstack111l1111lll_opy_
    def bstack111l1111ll1_opy_(self):
        return self.bstack1111ll11l11_opy_
    def bstack1111ll1l1ll_opy_(self):
        return self.bstack1111l1ll1ll_opy_
    def __1111l1l1l11_opy_(self, enabled, mode, source=None):
        try:
            self.bstack111l1111lll_opy_ = bool(enabled)
            if mode not in [bstack1l11_opy_ (u"ࠬࡸࡥ࡭ࡧࡹࡥࡳࡺࡆࡪࡴࡶࡸࠬấ"), bstack1l11_opy_ (u"࠭ࡲࡦ࡮ࡨࡺࡦࡴࡴࡐࡰ࡯ࡽࠬẦ")]:
                logger.warning(bstack1l11_opy_ (u"ࠢࡊࡰࡹࡥࡱ࡯ࡤࠡࡵࡰࡥࡷࡺࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡱࡴࡪࡥࠡࠩࡾࢁࠬࠦࡰࡳࡱࡹ࡭ࡩ࡫ࡤ࠯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡬ࡲ࡬ࠦࡴࡰࠢࠪࡶࡪࡲࡥࡷࡣࡱࡸࡋ࡯ࡲࡴࡶࠪ࠲ࠧầ").format(mode))
                mode = bstack1l11_opy_ (u"ࠨࡴࡨࡰࡪࡼࡡ࡯ࡶࡉ࡭ࡷࡹࡴࠨẨ")
            self.bstack1111ll11l11_opy_ = mode
            if source is None:
                self.bstack1111l1ll1ll_opy_ = None
            elif isinstance(source, list):
                self.bstack1111l1ll1ll_opy_ = source
            elif isinstance(source, str) and source.endswith(bstack1l11_opy_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨẩ")):
                self.bstack1111l1ll1ll_opy_ = self._111l1111111_opy_(source)
            self.__1111ll1111l_opy_()
        except Exception as e:
            logger.error(bstack1l11_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡦࡶࠣࡷࡲࡧࡲࡵࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥ࠳ࠠࡦࡰࡤࡦࡱ࡫ࡤ࠻ࠢࡾࢁ࠱ࠦ࡭ࡰࡦࡨ࠾ࠥࢁࡽ࠭ࠢࡶࡳࡺࡸࡣࡦ࠼ࠣࡿࢂ࠴ࠠࡆࡴࡵࡳࡷࡀࠠࡼࡿࠥẪ").format(enabled, mode, source, e))
    def bstack111l1111l11_opy_(self):
        return self.bstack1111ll1ll11_opy_
    def __111l111111l_opy_(self, value):
        self.bstack1111ll1ll11_opy_ = bool(value)
        self.__1111ll1111l_opy_()
    def bstack1111lll11l1_opy_(self):
        return self.bstack1111l1lll11_opy_
    def __1111ll111l1_opy_(self, value):
        self.bstack1111l1lll11_opy_ = bool(value)
        self.__1111ll1111l_opy_()
    def bstack1111l1l11ll_opy_(self):
        return self.bstack1111lll1111_opy_
    def __111l1111l1l_opy_(self, value):
        self.bstack1111lll1111_opy_ = bool(value)
        self.__1111ll1111l_opy_()
    def __1111ll1111l_opy_(self):
        if self.bstack111l1111lll_opy_:
            self.bstack1111ll1ll11_opy_ = False
            self.bstack1111l1lll11_opy_ = False
            self.bstack1111lll1111_opy_ = False
            self.bstack1111ll1ll1l_opy_.enable(bstack1111l1l1111_opy_)
        elif self.bstack1111ll1ll11_opy_:
            self.bstack1111l1lll11_opy_ = False
            self.bstack1111lll1111_opy_ = False
            self.bstack111l1111lll_opy_ = False
            self.bstack1111ll1ll1l_opy_.enable(bstack1111l1l1l1l_opy_)
        elif self.bstack1111l1lll11_opy_:
            self.bstack1111ll1ll11_opy_ = False
            self.bstack1111lll1111_opy_ = False
            self.bstack111l1111lll_opy_ = False
            self.bstack1111ll1ll1l_opy_.enable(bstack1111llll111_opy_)
        elif self.bstack1111lll1111_opy_:
            self.bstack1111ll1ll11_opy_ = False
            self.bstack1111l1lll11_opy_ = False
            self.bstack111l1111lll_opy_ = False
            self.bstack1111ll1ll1l_opy_.enable(bstack1111l1l1lll_opy_)
        else:
            self.bstack1111ll1ll1l_opy_.disable()
    def bstack11ll1lll_opy_(self):
        return self.bstack1111ll1ll1l_opy_.bstack1111ll1llll_opy_()
    def bstack1l1l1l1ll_opy_(self):
        if self.bstack1111ll1ll1l_opy_.bstack1111ll1llll_opy_():
            return self.bstack1111ll1ll1l_opy_.get_name()
        return None
    def _111l1111111_opy_(self, bstack1111llll1ll_opy_):
        bstack1l11_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡒࡤࡶࡸ࡫ࠠࡋࡕࡒࡒࠥࡹ࡯ࡶࡴࡦࡩࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥ࡬ࡩ࡭ࡧࠣࡥࡳࡪࠠࡧࡱࡵࡱࡦࡺࠠࡪࡶࠣࡪࡴࡸࠠࡴ࡯ࡤࡶࡹࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡆࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡵࡲࡹࡷࡩࡥࡠࡨ࡬ࡰࡪࡥࡰࡢࡶ࡫ࠤ࠭ࡹࡴࡳࠫ࠽ࠤࡕࡧࡴࡩࠢࡷࡳࠥࡺࡨࡦࠢࡍࡗࡔࡔࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡧ࡫࡯ࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࡬ࡪࡵࡷ࠾ࠥࡌ࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡹࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦẫ")
        if not os.path.isfile(bstack1111llll1ll_opy_):
            logger.error(bstack1l11_opy_ (u"࡙ࠧ࡯ࡶࡴࡦࡩࠥ࡬ࡩ࡭ࡧࠣࠫࢀࢃࠧࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡩࡽ࡯ࡳࡵ࠰ࠥẬ").format(bstack1111llll1ll_opy_))
            return []
        data = None
        try:
            with open(bstack1111llll1ll_opy_, bstack1l11_opy_ (u"ࠨࡲࠣậ")) as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error(bstack1l11_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡰࡢࡴࡶ࡭ࡳ࡭ࠠࡋࡕࡒࡒࠥ࡬ࡲࡰ࡯ࠣࡷࡴࡻࡲࡤࡧࠣࡪ࡮ࡲࡥࠡࠩࡾࢁࠬࡀࠠࡼࡿࠥẮ").format(bstack1111llll1ll_opy_, e))
            return []
        _1111ll1l111_opy_ = None
        _1111l1ll11l_opy_ = None
        def _1111l1lll1l_opy_():
            bstack1111ll111ll_opy_ = {}
            bstack1111ll11l1l_opy_ = {}
            try:
                if self.bstack1111lll1ll1_opy_.startswith(bstack1l11_opy_ (u"ࠨࡽࠪắ")) and self.bstack1111lll1ll1_opy_.endswith(bstack1l11_opy_ (u"ࠩࢀࠫẰ")):
                    bstack1111ll111ll_opy_ = json.loads(self.bstack1111lll1ll1_opy_)
                else:
                    bstack1111ll111ll_opy_ = dict(item.split(bstack1l11_opy_ (u"ࠪ࠾ࠬằ")) for item in self.bstack1111lll1ll1_opy_.split(bstack1l11_opy_ (u"ࠫ࠱࠭Ẳ")) if bstack1l11_opy_ (u"ࠬࡀࠧẳ") in item) if self.bstack1111lll1ll1_opy_ else {}
                if self.bstack1111ll11lll_opy_.startswith(bstack1l11_opy_ (u"࠭ࡻࠨẴ")) and self.bstack1111ll11lll_opy_.endswith(bstack1l11_opy_ (u"ࠧࡾࠩẵ")):
                    bstack1111ll11l1l_opy_ = json.loads(self.bstack1111ll11lll_opy_)
                else:
                    bstack1111ll11l1l_opy_ = dict(item.split(bstack1l11_opy_ (u"ࠨ࠼ࠪẶ")) for item in self.bstack1111ll11lll_opy_.split(bstack1l11_opy_ (u"ࠩ࠯ࠫặ")) if bstack1l11_opy_ (u"ࠪ࠾ࠬẸ") in item) if self.bstack1111ll11lll_opy_ else {}
            except json.JSONDecodeError as e:
                logger.error(bstack1l11_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡴࡦࡸࡳࡪࡰࡪࠤ࡫࡫ࡡࡵࡷࡵࡩࠥࡨࡲࡢࡰࡦ࡬ࠥࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠺ࠡࡽࢀࠦẹ").format(e))
            logger.debug(bstack1l11_opy_ (u"ࠧࡌࡥࡢࡶࡸࡶࡪࠦࡢࡳࡣࡱࡧ࡭ࠦ࡭ࡢࡲࡳ࡭ࡳ࡭ࡳࠡࡨࡵࡳࡲࠦࡥ࡯ࡸ࠽ࠤࢀࢃࠬࠡࡅࡏࡍ࠿ࠦࡻࡾࠤẺ").format(bstack1111ll111ll_opy_, bstack1111ll11l1l_opy_))
            return bstack1111ll111ll_opy_, bstack1111ll11l1l_opy_
        if _1111ll1l111_opy_ is None or _1111l1ll11l_opy_ is None:
            _1111ll1l111_opy_, _1111l1ll11l_opy_ = _1111l1lll1l_opy_()
        def bstack1111lllllll_opy_(name, bstack1111ll1l1l1_opy_):
            if name in _1111l1ll11l_opy_:
                return _1111l1ll11l_opy_[name]
            if name in _1111ll1l111_opy_:
                return _1111ll1l111_opy_[name]
            if bstack1111ll1l1l1_opy_.get(bstack1l11_opy_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡂࡳࡣࡱࡧ࡭࠭ẻ")):
                return bstack1111ll1l1l1_opy_[bstack1l11_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡃࡴࡤࡲࡨ࡮ࠧẼ")]
            return None
        if isinstance(data, dict):
            bstack111l11111ll_opy_ = []
            bstack1111ll1lll1_opy_ = re.compile(bstack1l11_opy_ (u"ࡳࠩࡡ࡟ࡆ࠳࡚࠱࠯࠼ࡣࡢ࠱ࠤࠨẽ"))
            for name, bstack1111ll1l1l1_opy_ in data.items():
                if not isinstance(bstack1111ll1l1l1_opy_, dict):
                    continue
                if not bstack1111ll1l1l1_opy_.get(bstack1l11_opy_ (u"ࠩࡸࡶࡱ࠭Ế")):
                    logger.warning(bstack1l11_opy_ (u"ࠥࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠠࡖࡔࡏࠤ࡮ࡹࠠ࡮࡫ࡶࡷ࡮ࡴࡧࠡࡨࡲࡶࠥࡹ࡯ࡶࡴࡦࡩࠥ࠭ࡻࡾࠩ࠽ࠤࢀࢃࠢế").format(name, bstack1111ll1l1l1_opy_))
                    continue
                if not bstack1111ll1lll1_opy_.match(name):
                    logger.warning(bstack1l11_opy_ (u"ࠦࡎࡴࡶࡢ࡮࡬ࡨࠥࡹ࡯ࡶࡴࡦࡩࠥ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠢࡩࡳࡷࡳࡡࡵࠢࡩࡳࡷࠦࠧࡼࡿࠪ࠾ࠥࢁࡽࠣỀ").format(name, bstack1111ll1l1l1_opy_))
                    continue
                if len(name) > 30 or len(name) < 1:
                    logger.warning(bstack1l11_opy_ (u"࡙ࠧ࡯ࡶࡴࡦࡩࠥ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠢࠪࡿࢂ࠭ࠠ࡮ࡷࡶࡸࠥ࡮ࡡࡷࡧࠣࡥࠥࡲࡥ࡯ࡩࡷ࡬ࠥࡨࡥࡵࡹࡨࡩࡳࠦ࠱ࠡࡣࡱࡨࠥ࠹࠰ࠡࡥ࡫ࡥࡷࡧࡣࡵࡧࡵࡷ࠳ࠨề").format(name))
                    continue
                bstack1111ll1l1l1_opy_ = bstack1111ll1l1l1_opy_.copy()
                bstack1111ll1l1l1_opy_[bstack1l11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫỂ")] = name
                bstack1111ll1l1l1_opy_[bstack1l11_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡃࡴࡤࡲࡨ࡮ࠧể")] = bstack1111lllllll_opy_(name, bstack1111ll1l1l1_opy_)
                if not bstack1111ll1l1l1_opy_.get(bstack1l11_opy_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡄࡵࡥࡳࡩࡨࠨỄ")):
                    logger.warning(bstack1l11_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧࠣࡦࡷࡧ࡮ࡤࡪࠣࡲࡴࡺࠠࡴࡲࡨࡧ࡮࡬ࡩࡦࡦࠣࡪࡴࡸࠠࡴࡱࡸࡶࡨ࡫ࠠࠨࡽࢀࠫ࠿ࠦࡻࡾࠤễ").format(name, bstack1111ll1l1l1_opy_))
                    continue
                if bstack1111ll1l1l1_opy_.get(bstack1l11_opy_ (u"ࠪࡦࡦࡹࡥࡃࡴࡤࡲࡨ࡮ࠧỆ")) and bstack1111ll1l1l1_opy_[bstack1l11_opy_ (u"ࠫࡧࡧࡳࡦࡄࡵࡥࡳࡩࡨࠨệ")] == bstack1111ll1l1l1_opy_[bstack1l11_opy_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡈࡲࡢࡰࡦ࡬ࠬỈ")]:
                    logger.warning(bstack1l11_opy_ (u"ࠨࡆࡦࡣࡷࡹࡷ࡫ࠠࡣࡴࡤࡲࡨ࡮ࠠࡢࡰࡧࠤࡧࡧࡳࡦࠢࡥࡶࡦࡴࡣࡩࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥࡺࡨࡦࠢࡶࡥࡲ࡫ࠠࡧࡱࡵࠤࡸࡵࡵࡳࡥࡨࠤࠬࢁࡽࠨ࠼ࠣࡿࢂࠨỉ").format(name, bstack1111ll1l1l1_opy_))
                    continue
                bstack111l11111ll_opy_.append(bstack1111ll1l1l1_opy_)
            return bstack111l11111ll_opy_
        return data
    def bstack111l11l1l11_opy_(self):
        data = {
            bstack1l11_opy_ (u"ࠧࡳࡷࡱࡣࡸࡳࡡࡳࡶࡢࡷࡪࡲࡥࡤࡶ࡬ࡳࡳ࠭Ị"): {
                bstack1l11_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩị"): self.bstack1111l1llll1_opy_(),
                bstack1l11_opy_ (u"ࠩࡰࡳࡩ࡫ࠧỌ"): self.bstack111l1111ll1_opy_(),
                bstack1l11_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪọ"): self.bstack1111ll1l1ll_opy_()
            }
        }
        return data
    def bstack1111ll11ll1_opy_(self, config):
        bstack1111llll11l_opy_ = {}
        bstack1111llll11l_opy_[bstack1l11_opy_ (u"ࠫࡷࡻ࡮ࡠࡵࡰࡥࡷࡺ࡟ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠪỎ")] = {
            bstack1l11_opy_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ỏ"): self.bstack1111l1llll1_opy_(),
            bstack1l11_opy_ (u"࠭࡭ࡰࡦࡨࠫỐ"): self.bstack111l1111ll1_opy_()
        }
        bstack1111llll11l_opy_[bstack1l11_opy_ (u"ࠧࡳࡧࡵࡹࡳࡥࡰࡳࡧࡹ࡭ࡴࡻࡳ࡭ࡻࡢࡪࡦ࡯࡬ࡦࡦࠪố")] = {
            bstack1l11_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩỒ"): self.bstack1111lll11l1_opy_()
        }
        bstack1111llll11l_opy_[bstack1l11_opy_ (u"ࠩࡵࡹࡳࡥࡰࡳࡧࡹ࡭ࡴࡻࡳ࡭ࡻࡢࡪࡦ࡯࡬ࡦࡦࡢࡪ࡮ࡸࡳࡵࠩồ")] = {
            bstack1l11_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫỔ"): self.bstack111l1111l11_opy_()
        }
        bstack1111llll11l_opy_[bstack1l11_opy_ (u"ࠫࡸࡱࡩࡱࡡࡩࡥ࡮ࡲࡩ࡯ࡩࡢࡥࡳࡪ࡟ࡧ࡮ࡤ࡯ࡾ࠭ổ")] = {
            bstack1l11_opy_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭Ỗ"): self.bstack1111l1l11ll_opy_()
        }
        if self.bstack11lll11l1_opy_(config):
            bstack1111llll11l_opy_[bstack1l11_opy_ (u"࠭ࡲࡦࡶࡵࡽࡤࡺࡥࡴࡶࡶࡣࡴࡴ࡟ࡧࡣ࡬ࡰࡺࡸࡥࠨỗ")] = {
                bstack1l11_opy_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨỘ"): True,
                bstack1l11_opy_ (u"ࠨ࡯ࡤࡼࡤࡸࡥࡵࡴ࡬ࡩࡸ࠭ộ"): self.bstack11ll11l1l1_opy_(config)
            }
        if self.bstack11l1l1111ll_opy_(config):
            bstack1111llll11l_opy_[bstack1l11_opy_ (u"ࠩࡤࡦࡴࡸࡴࡠࡤࡸ࡭ࡱࡪ࡟ࡰࡰࡢࡪࡦ࡯࡬ࡶࡴࡨࠫỚ")] = {
                bstack1l11_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫớ"): True,
                bstack1l11_opy_ (u"ࠫࡲࡧࡸࡠࡨࡤ࡭ࡱࡻࡲࡦࡵࠪỜ"): self.bstack11l11llllll_opy_(config)
            }
        return bstack1111llll11l_opy_
    def bstack1llll111ll_opy_(self, config):
        bstack1l11_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࡆࡳࡱࡲࡥࡤࡶࡶࠤࡧࡻࡩ࡭ࡦࠣࡨࡦࡺࡡࠡࡤࡼࠤࡲࡧ࡫ࡪࡰࡪࠤࡦࠦࡣࡢ࡮࡯ࠤࡹࡵࠠࡵࡪࡨࠤࡨࡵ࡬࡭ࡧࡦࡸ࠲ࡨࡵࡪ࡮ࡧ࠱ࡩࡧࡴࡢࠢࡨࡲࡩࡶ࡯ࡪࡰࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡁࡳࡩࡶ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡺ࡯࡬ࡥࡡࡸࡹ࡮ࡪࠠࠩࡵࡷࡶ࠮ࡀࠠࡕࡪࡨࠤ࡚࡛ࡉࡅࠢࡲࡪࠥࡺࡨࡦࠢࡥࡹ࡮ࡲࡤࠡࡶࡲࠤࡨࡵ࡬࡭ࡧࡦࡸࠥࡪࡡࡵࡣࠣࡪࡴࡸ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡕࡩࡹࡻࡲ࡯ࡵ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡧ࡭ࡨࡺ࠺ࠡࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡩ࡯࡭࡮ࡨࡧࡹ࠳ࡢࡶ࡫࡯ࡨ࠲ࡪࡡࡵࡣࠣࡩࡳࡪࡰࡰ࡫ࡱࡸ࠱ࠦ࡯ࡳࠢࡑࡳࡳ࡫ࠠࡪࡨࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣờ")
        if not (config.get(bstack1l11_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩỞ"), None) in bstack11l1ll11l11_opy_ and self.bstack1111l1llll1_opy_()):
            return None
        bstack1111lll1lll_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬở"), None)
        logger.debug(bstack1l11_opy_ (u"ࠣ࡝ࡦࡳࡱࡲࡥࡤࡶࡅࡹ࡮ࡲࡤࡅࡣࡷࡥࡢࠦࡃࡰ࡮࡯ࡩࡨࡺࡩ࡯ࡩࠣࡦࡺ࡯࡬ࡥࠢࡧࡥࡹࡧࠠࡧࡱࡵࠤࡧࡻࡩ࡭ࡦ࡙࡚ࠣࡏࡄ࠻ࠢࡾࢁࠧỠ").format(bstack1111lll1lll_opy_))
        try:
            bstack11ll111l1l1_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡯ࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳ࠵ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾ࠱ࡦࡳࡱࡲࡥࡤࡶ࠰ࡦࡺ࡯࡬ࡥ࠯ࡧࡥࡹࡧࠢỡ").format(bstack1111lll1lll_opy_)
            payload = {
                bstack1l11_opy_ (u"ࠥࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠣỢ"): config.get(bstack1l11_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠩợ"), bstack1l11_opy_ (u"ࠬ࠭Ụ")),
                bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠤụ"): config.get(bstack1l11_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪỦ"), os.path.basename(os.path.abspath(os.getcwd()))),
                bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪࡒࡶࡰࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷࠨủ"): os.environ.get(bstack1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡄࡘࡍࡑࡊ࡟ࡓࡗࡑࡣࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠣỨ"), bstack1l11_opy_ (u"ࠥࠦứ")),
                bstack1l11_opy_ (u"ࠦࡳࡵࡤࡦࡋࡱࡨࡪࡾࠢỪ"): int(os.environ.get(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡓࡕࡄࡆࡡࡌࡒࡉࡋࡘࠣừ")) or bstack1l11_opy_ (u"ࠨ࠰ࠣỬ")),
                bstack1l11_opy_ (u"ࠢࡵࡱࡷࡥࡱࡔ࡯ࡥࡧࡶࠦử"): int(os.environ.get(bstack1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡑࡗࡅࡑࡥࡎࡐࡆࡈࡣࡈࡕࡕࡏࡖࠥỮ")) or bstack1l11_opy_ (u"ࠤ࠴ࠦữ")),
                bstack1l11_opy_ (u"ࠥ࡬ࡴࡹࡴࡊࡰࡩࡳࠧỰ"): get_host_info(),
            }
            logger.debug(bstack1l11_opy_ (u"ࠦࡠࡩ࡯࡭࡮ࡨࡧࡹࡈࡵࡪ࡮ࡧࡈࡦࡺࡡ࡞ࠢࡖࡩࡳࡪࡩ࡯ࡩࠣࡦࡺ࡯࡬ࡥࠢࡧࡥࡹࡧࠠࡱࡣࡼࡰࡴࡧࡤ࠻ࠢࡾࢁࠧự").format(payload))
            response = bstack11ll11111ll_opy_.bstack1111lllll1l_opy_(bstack11ll111l1l1_opy_, payload)
            if response:
                logger.debug(bstack1l11_opy_ (u"ࠧࡡࡣࡰ࡮࡯ࡩࡨࡺࡂࡶ࡫࡯ࡨࡉࡧࡴࡢ࡟ࠣࡆࡺ࡯࡬ࡥࠢࡧࡥࡹࡧࠠࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࡀࠠࡼࡿࠥỲ").format(response))
                return response
            else:
                logger.error(bstack1l11_opy_ (u"ࠨ࡛ࡤࡱ࡯ࡰࡪࡩࡴࡃࡷ࡬ࡰࡩࡊࡡࡵࡣࡠࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡤࡱ࡯ࡰࡪࡩࡴࠡࡤࡸ࡭ࡱࡪࠠࡥࡣࡷࡥࠥ࡬࡯ࡳࠢࡥࡹ࡮ࡲࡤࠡࡗࡘࡍࡉࡀࠠࡼࡿࠥỳ").format(bstack1111lll1lll_opy_))
                return None
        except Exception as e:
            logger.error(bstack1l11_opy_ (u"ࠢ࡜ࡥࡲࡰࡱ࡫ࡣࡵࡄࡸ࡭ࡱࡪࡄࡢࡶࡤࡡࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡴࡧࠡࡤࡸ࡭ࡱࡪࠠࡥࡣࡷࡥࠥ࡬࡯ࡳࠢࡥࡹ࡮ࡲࡤࠡࡗࡘࡍࡉࠦࡻࡾ࠼ࠣࡿࢂࠨỴ").format(bstack1111lll1lll_opy_, e))
            return None