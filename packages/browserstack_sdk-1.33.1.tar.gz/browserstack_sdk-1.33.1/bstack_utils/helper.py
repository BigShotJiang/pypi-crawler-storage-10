# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import collections
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
import tempfile
import multiprocessing
import threading
import sys
import logging
from math import ceil
from unittest import result
import urllib
from urllib.parse import urlparse
import copy
import zipfile
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import (bstack1ll111llll_opy_, bstack1ll11llll1_opy_, bstack1lll11lll1_opy_,
                                    bstack11l1l1l1lll_opy_, bstack11l1l11llll_opy_, bstack11l1ll11lll_opy_, bstack11l1ll1ll1l_opy_)
from bstack_utils.measure import measure
from bstack_utils.messages import bstack11l1111l1_opy_, bstack1lll111l_opy_
from bstack_utils.proxy import bstack111lll1l1_opy_, bstack1ll1ll111_opy_
from bstack_utils.constants import *
from bstack_utils import bstack1l111llll_opy_
from bstack_utils.bstack1l11l1l1l1_opy_ import bstack1lll1l1l_opy_
from browserstack_sdk._version import __version__
bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
logger = bstack1l111llll_opy_.get_logger(__name__, bstack1l111llll_opy_.bstack1lll11l1ll1_opy_())
def bstack11ll1ll11ll_opy_(config):
    return config[bstack1l11_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪᬯ")]
def bstack11ll11lllll_opy_(config):
    return config[bstack1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬᬰ")]
def bstack11lll1ll_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack111ll1ll1ll_opy_(obj):
    values = []
    bstack111llllll11_opy_ = re.compile(bstack1l11_opy_ (u"ࡵࠦࡣࡉࡕࡔࡖࡒࡑࡤ࡚ࡁࡈࡡ࡟ࡨ࠰ࠪࠢᬱ"), re.I)
    for key in obj.keys():
        if bstack111llllll11_opy_.match(key):
            values.append(obj[key])
    return values
def bstack11l11l1l11l_opy_(config):
    tags = []
    tags.extend(bstack111ll1ll1ll_opy_(os.environ))
    tags.extend(bstack111ll1ll1ll_opy_(config))
    return tags
def bstack111ll11llll_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack11l11ll11l1_opy_(bstack11l111lll1l_opy_):
    if not bstack11l111lll1l_opy_:
        return bstack1l11_opy_ (u"ࠫࠬᬲ")
    return bstack1l11_opy_ (u"ࠧࢁࡽࠡࠪࡾࢁ࠮ࠨᬳ").format(bstack11l111lll1l_opy_.name, bstack11l111lll1l_opy_.email)
def bstack11ll1l1ll11_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack111lll1llll_opy_ = repo.common_dir
        info = {
            bstack1l11_opy_ (u"ࠨࡳࡩࡣ᬴ࠥ"): repo.head.commit.hexsha,
            bstack1l11_opy_ (u"ࠢࡴࡪࡲࡶࡹࡥࡳࡩࡣࠥᬵ"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1l11_opy_ (u"ࠣࡤࡵࡥࡳࡩࡨࠣᬶ"): repo.active_branch.name,
            bstack1l11_opy_ (u"ࠤࡷࡥ࡬ࠨᬷ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡷࡩࡷࠨᬸ"): bstack11l11ll11l1_opy_(repo.head.commit.committer),
            bstack1l11_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡸࡪࡸ࡟ࡥࡣࡷࡩࠧᬹ"): repo.head.commit.committed_datetime.isoformat(),
            bstack1l11_opy_ (u"ࠧࡧࡵࡵࡪࡲࡶࠧᬺ"): bstack11l11ll11l1_opy_(repo.head.commit.author),
            bstack1l11_opy_ (u"ࠨࡡࡶࡶ࡫ࡳࡷࡥࡤࡢࡶࡨࠦᬻ"): repo.head.commit.authored_datetime.isoformat(),
            bstack1l11_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠣᬼ"): repo.head.commit.message,
            bstack1l11_opy_ (u"ࠣࡴࡲࡳࡹࠨᬽ"): repo.git.rev_parse(bstack1l11_opy_ (u"ࠤ࠰࠱ࡸ࡮࡯ࡸ࠯ࡷࡳࡵࡲࡥࡷࡧ࡯ࠦᬾ")),
            bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡰࡰࡢ࡫࡮ࡺ࡟ࡥ࡫ࡵࠦᬿ"): bstack111lll1llll_opy_,
            bstack1l11_opy_ (u"ࠦࡼࡵࡲ࡬ࡶࡵࡩࡪࡥࡧࡪࡶࡢࡨ࡮ࡸࠢᭀ"): subprocess.check_output([bstack1l11_opy_ (u"ࠧ࡭ࡩࡵࠤᭁ"), bstack1l11_opy_ (u"ࠨࡲࡦࡸ࠰ࡴࡦࡸࡳࡦࠤᭂ"), bstack1l11_opy_ (u"ࠢ࠮࠯ࡪ࡭ࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡤࡪࡴࠥᭃ")]).strip().decode(
                bstack1l11_opy_ (u"ࠨࡷࡷࡪ࠲࠾᭄ࠧ")),
            bstack1l11_opy_ (u"ࠤ࡯ࡥࡸࡺ࡟ࡵࡣࡪࠦᭅ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡶࡣࡸ࡯࡮ࡤࡧࡢࡰࡦࡹࡴࡠࡶࡤ࡫ࠧᭆ"): repo.git.rev_list(
                bstack1l11_opy_ (u"ࠦࢀࢃ࠮࠯ࡽࢀࠦᭇ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack11l11ll1l1l_opy_ = []
        for remote in remotes:
            bstack11l111111ll_opy_ = {
                bstack1l11_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᭈ"): remote.name,
                bstack1l11_opy_ (u"ࠨࡵࡳ࡮ࠥᭉ"): remote.url,
            }
            bstack11l11ll1l1l_opy_.append(bstack11l111111ll_opy_)
        bstack111ll111lll_opy_ = {
            bstack1l11_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᭊ"): bstack1l11_opy_ (u"ࠣࡩ࡬ࡸࠧᭋ"),
            **info,
            bstack1l11_opy_ (u"ࠤࡵࡩࡲࡵࡴࡦࡵࠥᭌ"): bstack11l11ll1l1l_opy_
        }
        bstack111ll111lll_opy_ = bstack11l11l11111_opy_(bstack111ll111lll_opy_)
        return bstack111ll111lll_opy_
    except git.InvalidGitRepositoryError:
        return {}
    except Exception as err:
        print(bstack1l11_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡳࡵࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡇࡪࡶࠣࡱࡪࡺࡡࡥࡣࡷࡥࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨ᭍").format(err))
        return {}
def bstack111ll1l1l1l_opy_(bstack111lll11ll1_opy_=None):
    bstack1l11_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࡌ࡫ࡴࠡࡩ࡬ࡸࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡴࡲࡨࡧ࡮࡬ࡩࡤࡣ࡯ࡰࡾࠦࡦࡰࡴࡰࡥࡹࡺࡥࡥࠢࡩࡳࡷࠦࡁࡊࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡻࡳࡦࠢࡦࡥࡸ࡫ࡳࠡࡨࡲࡶࠥ࡫ࡡࡤࡪࠣࡪࡴࡲࡤࡦࡴࠣ࡭ࡳࠦࡴࡩࡧࠣࡰ࡮ࡹࡴ࠯ࠌࠣࠤࠥࠦࡁࡳࡩࡶ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡦࡰ࡮ࡧࡩࡷࡹࠠࠩ࡮࡬ࡷࡹ࠲ࠠࡰࡲࡷ࡭ࡴࡴࡡ࡭ࠫ࠽ࠤࡑ࡯ࡳࡵࠢࡲࡪࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪࡶࠤࡹࡵࠠࡦࡺࡷࡶࡦࡩࡴࠡࡩ࡬ࡸࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡧࡴࡲࡱ࠳ࠦࡄࡦࡨࡤࡹࡱࡺࡳࠡࡶࡲࠤࡠࡵࡳ࠯ࡩࡨࡸࡨࡽࡤࠩࠫࡠ࠲ࠏࠦࠠࠡࠢࡕࡩࡹࡻࡲ࡯ࡵ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡲࡩࡴࡶ࠽ࠤࡑ࡯ࡳࡵࠢࡲࡪࠥࡪࡩࡤࡶࡶ࠰ࠥ࡫ࡡࡤࡪࠣࡧࡴࡴࡴࡢ࡫ࡱ࡭ࡳ࡭ࠠࡨ࡫ࡷࠤࡲ࡫ࡴࡢࡦࡤࡸࡦࠦࡦࡰࡴࠣࡥࠥ࡬࡯࡭ࡦࡨࡶ࠳ࠐࠠࠡࠢࠣࠦࠧࠨ᭎")
    if bstack111lll11ll1_opy_ == None: # bstack11l11l1l1l1_opy_ for bstack11l11l1ll11_opy_-repo
        bstack111lll11ll1_opy_ = [os.getcwd()]
    results = []
    for folder in bstack111lll11ll1_opy_:
        try:
            repo = git.Repo(folder, search_parent_directories=True)
            result = {
                bstack1l11_opy_ (u"ࠧࡶࡲࡊࡦࠥ᭏"): bstack1l11_opy_ (u"ࠨࠢ᭐"),
                bstack1l11_opy_ (u"ࠢࡧ࡫࡯ࡩࡸࡉࡨࡢࡰࡪࡩࡩࠨ᭑"): [],
                bstack1l11_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࡴࠤ᭒"): [],
                bstack1l11_opy_ (u"ࠤࡳࡶࡉࡧࡴࡦࠤ᭓"): bstack1l11_opy_ (u"ࠥࠦ᭔"),
                bstack1l11_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡑࡪࡹࡳࡢࡩࡨࡷࠧ᭕"): [],
                bstack1l11_opy_ (u"ࠧࡶࡲࡕ࡫ࡷࡰࡪࠨ᭖"): bstack1l11_opy_ (u"ࠨࠢ᭗"),
                bstack1l11_opy_ (u"ࠢࡱࡴࡇࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ᭘"): bstack1l11_opy_ (u"ࠣࠤ᭙"),
                bstack1l11_opy_ (u"ࠤࡳࡶࡗࡧࡷࡅ࡫ࡩࡪࠧ᭚"): bstack1l11_opy_ (u"ࠥࠦ᭛")
            }
            bstack11l11l11l1l_opy_ = repo.active_branch.name
            bstack111lll11lll_opy_ = repo.head.commit
            result[bstack1l11_opy_ (u"ࠦࡵࡸࡉࡥࠤ᭜")] = bstack111lll11lll_opy_.hexsha
            bstack11l111lllll_opy_ = _11l111l1l1l_opy_(repo)
            logger.debug(bstack1l11_opy_ (u"ࠧࡈࡡࡴࡧࠣࡦࡷࡧ࡮ࡤࡪࠣࡪࡴࡸࠠࡤࡱࡰࡴࡦࡸࡩࡴࡱࡱ࠾ࠥࠨ᭝") + str(bstack11l111lllll_opy_) + bstack1l11_opy_ (u"ࠨࠢ᭞"))
            if bstack11l111lllll_opy_:
                try:
                    bstack111ll1l11l1_opy_ = repo.git.diff(bstack1l11_opy_ (u"ࠢ࠮࠯ࡱࡥࡲ࡫࠭ࡰࡰ࡯ࡽࠧ᭟"), bstack1111l111ll_opy_ (u"ࠣࡽࡥࡥࡸ࡫࡟ࡣࡴࡤࡲࡨ࡮ࡽ࠯࠰࠱ࡿࡨࡻࡲࡳࡧࡱࡸࡤࡨࡲࡢࡰࡦ࡬ࢂࠨ᭠")).split(bstack1l11_opy_ (u"ࠩ࡟ࡲࠬ᭡"))
                    logger.debug(bstack1l11_opy_ (u"ࠥࡇ࡭ࡧ࡮ࡨࡧࡧࠤ࡫࡯࡬ࡦࡵࠣࡦࡪࡺࡷࡦࡧࡱࠤࢀࡨࡡࡴࡧࡢࡦࡷࡧ࡮ࡤࡪࢀࠤࡦࡴࡤࠡࡽࡦࡹࡷࡸࡥ࡯ࡶࡢࡦࡷࡧ࡮ࡤࡪࢀ࠾ࠥࠨ᭢") + str(bstack111ll1l11l1_opy_) + bstack1l11_opy_ (u"ࠦࠧ᭣"))
                    result[bstack1l11_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡶࡇ࡭ࡧ࡮ࡨࡧࡧࠦ᭤")] = [f.strip() for f in bstack111ll1l11l1_opy_ if f.strip()]
                    commits = list(repo.iter_commits(bstack1111l111ll_opy_ (u"ࠨࡻࡣࡣࡶࡩࡤࡨࡲࡢࡰࡦ࡬ࢂ࠴࠮ࡼࡥࡸࡶࡷ࡫࡮ࡵࡡࡥࡶࡦࡴࡣࡩࡿࠥ᭥")))
                except Exception:
                    logger.debug(bstack1l11_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣ࡫ࡪࡺࠠࡤࡪࡤࡲ࡬࡫ࡤࠡࡨ࡬ࡰࡪࡹࠠࡧࡴࡲࡱࠥࡨࡲࡢࡰࡦ࡬ࠥࡩ࡯࡮ࡲࡤࡶ࡮ࡹ࡯࡯࠰ࠣࡊࡦࡲ࡬ࡪࡰࡪࠤࡧࡧࡣ࡬ࠢࡷࡳࠥࡸࡥࡤࡧࡱࡸࠥࡩ࡯࡮࡯࡬ࡸࡸ࠴ࠢ᭦"))
                    commits = list(repo.iter_commits(max_count=10))
                    if commits:
                        result[bstack1l11_opy_ (u"ࠣࡨ࡬ࡰࡪࡹࡃࡩࡣࡱ࡫ࡪࡪࠢ᭧")] = _11l1111l1l1_opy_(commits[:5])
            else:
                commits = list(repo.iter_commits(max_count=10))
                if commits:
                    result[bstack1l11_opy_ (u"ࠤࡩ࡭ࡱ࡫ࡳࡄࡪࡤࡲ࡬࡫ࡤࠣ᭨")] = _11l1111l1l1_opy_(commits[:5])
            bstack11l1111l111_opy_ = set()
            bstack111llll111l_opy_ = []
            for commit in commits:
                logger.debug(bstack1l11_opy_ (u"ࠥࡔࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡤࡱࡰࡱ࡮ࡺ࠺ࠡࠤ᭩") + str(commit.message) + bstack1l11_opy_ (u"ࠦࠧ᭪"))
                bstack11l111111l1_opy_ = commit.author.name if commit.author else bstack1l11_opy_ (u"࡛ࠧ࡮࡬ࡰࡲࡻࡳࠨ᭫")
                bstack11l1111l111_opy_.add(bstack11l111111l1_opy_)
                bstack111llll111l_opy_.append({
                    bstack1l11_opy_ (u"ࠨ࡭ࡦࡵࡶࡥ࡬࡫᭬ࠢ"): commit.message.strip(),
                    bstack1l11_opy_ (u"ࠢࡶࡵࡨࡶࠧ᭭"): bstack11l111111l1_opy_
                })
            result[bstack1l11_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࡴࠤ᭮")] = list(bstack11l1111l111_opy_)
            result[bstack1l11_opy_ (u"ࠤࡦࡳࡲࡳࡩࡵࡏࡨࡷࡸࡧࡧࡦࡵࠥ᭯")] = bstack111llll111l_opy_
            result[bstack1l11_opy_ (u"ࠥࡴࡷࡊࡡࡵࡧࠥ᭰")] = bstack111lll11lll_opy_.committed_datetime.strftime(bstack1l11_opy_ (u"ࠦࠪ࡟࠭ࠦ࡯࠰ࠩࡩࠨ᭱"))
            if (not result[bstack1l11_opy_ (u"ࠧࡶࡲࡕ࡫ࡷࡰࡪࠨ᭲")] or result[bstack1l11_opy_ (u"ࠨࡰࡳࡖ࡬ࡸࡱ࡫ࠢ᭳")].strip() == bstack1l11_opy_ (u"ࠢࠣ᭴")) and bstack111lll11lll_opy_.message:
                bstack111lll1l11l_opy_ = bstack111lll11lll_opy_.message.strip().splitlines()
                result[bstack1l11_opy_ (u"ࠣࡲࡵࡘ࡮ࡺ࡬ࡦࠤ᭵")] = bstack111lll1l11l_opy_[0] if bstack111lll1l11l_opy_ else bstack1l11_opy_ (u"ࠤࠥ᭶")
                if len(bstack111lll1l11l_opy_) > 2:
                    result[bstack1l11_opy_ (u"ࠥࡴࡷࡊࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥ᭷")] = bstack1l11_opy_ (u"ࠫࡡࡴࠧ᭸").join(bstack111lll1l11l_opy_[2:]).strip()
            results.append(result)
        except Exception as err:
            logger.error(bstack1l11_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡵࡰࡶ࡮ࡤࡸ࡮ࡴࡧࠡࡉ࡬ࡸࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡧࡱࡵࠤࡆࡏࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࠬ࡫ࡵ࡬ࡥࡧࡵ࠾ࠥࢁࡦࡰ࡮ࡧࡩࡷࢃࠩ࠻ࠢࠥ᭹") + str(err) + bstack1l11_opy_ (u"ࠨࠢ᭺"))
    filtered_results = [
        result
        for result in results
        if _11l1111l1ll_opy_(result)
    ]
    return filtered_results
def _11l1111l1ll_opy_(result):
    bstack1l11_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡉࡧ࡯ࡴࡪࡸࠠࡵࡱࠣࡧ࡭࡫ࡣ࡬ࠢ࡬ࡪࠥࡧࠠࡨ࡫ࡷࠤࡲ࡫ࡴࡢࡦࡤࡸࡦࠦࡲࡦࡵࡸࡰࡹࠦࡩࡴࠢࡹࡥࡱ࡯ࡤࠡࠪࡱࡳࡳ࠳ࡥ࡮ࡲࡷࡽࠥ࡬ࡩ࡭ࡧࡶࡇ࡭ࡧ࡮ࡨࡧࡧࠤࡦࡴࡤࠡࡣࡸࡸ࡭ࡵࡲࡴࠫ࠱ࠎࠥࠦࠠࠡࠤࠥࠦ᭻")
    return (
        isinstance(result.get(bstack1l11_opy_ (u"ࠣࡨ࡬ࡰࡪࡹࡃࡩࡣࡱ࡫ࡪࡪࠢ᭼"), None), list)
        and len(result[bstack1l11_opy_ (u"ࠤࡩ࡭ࡱ࡫ࡳࡄࡪࡤࡲ࡬࡫ࡤࠣ᭽")]) > 0
        and isinstance(result.get(bstack1l11_opy_ (u"ࠥࡥࡺࡺࡨࡰࡴࡶࠦ᭾"), None), list)
        and len(result[bstack1l11_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࡷࠧ᭿")]) > 0
    )
def _11l111l1l1l_opy_(repo):
    bstack1l11_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤ࡚ࠥࡲࡺࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡨࡡࡴࡧࠣࡦࡷࡧ࡮ࡤࡪࠣࡪࡴࡸࠠࡵࡪࡨࠤ࡬࡯ࡶࡦࡰࠣࡶࡪࡶ࡯ࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢ࡫ࡥࡷࡪࡣࡰࡦࡨࡨࠥࡴࡡ࡮ࡧࡶࠤࡦࡴࡤࠡࡹࡲࡶࡰࠦࡷࡪࡶ࡫ࠤࡦࡲ࡬ࠡࡘࡆࡗࠥࡶࡲࡰࡸ࡬ࡨࡪࡸࡳ࠯ࠌࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹࠠࡵࡪࡨࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥࡨࡲࡢࡰࡦ࡬ࠥ࡯ࡦࠡࡲࡲࡷࡸ࡯ࡢ࡭ࡧ࠯ࠤࡪࡲࡳࡦࠢࡑࡳࡳ࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣᮀ")
    try:
        try:
            origin = repo.remotes.origin
            bstack11l1111ll1l_opy_ = origin.refs[bstack1l11_opy_ (u"࠭ࡈࡆࡃࡇࠫᮁ")]
            target = bstack11l1111ll1l_opy_.reference.name
            if target.startswith(bstack1l11_opy_ (u"ࠧࡰࡴ࡬࡫࡮ࡴ࠯ࠨᮂ")):
                return target
        except Exception:
            pass
        if repo.remotes and repo.remotes.origin.refs:
            for ref in repo.remotes.origin.refs:
                if ref.name.startswith(bstack1l11_opy_ (u"ࠨࡱࡵ࡭࡬࡯࡮࠰ࠩᮃ")):
                    return ref.name
        if repo.heads:
            return repo.heads[0].name
    except Exception:
        pass
    return None
def _11l1111l1l1_opy_(commits):
    bstack1l11_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࡊࡩࡹࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡤࡪࡤࡲ࡬࡫ࡤࠡࡨ࡬ࡰࡪࡹࠠࡧࡴࡲࡱࠥࡧࠠ࡭࡫ࡶࡸࠥࡵࡦࠡࡥࡲࡱࡲ࡯ࡴࡴ࠰ࠍࠤࠥࠦࠠࠣࠤࠥᮄ")
    bstack111ll1l11l1_opy_ = set()
    try:
        for commit in commits:
            if commit.parents:
                for parent in commit.parents:
                    diff = commit.diff(parent)
                    for bstack111ll11l1l1_opy_ in diff:
                        if bstack111ll11l1l1_opy_.a_path:
                            bstack111ll1l11l1_opy_.add(bstack111ll11l1l1_opy_.a_path)
                        if bstack111ll11l1l1_opy_.b_path:
                            bstack111ll1l11l1_opy_.add(bstack111ll11l1l1_opy_.b_path)
    except Exception:
        pass
    return list(bstack111ll1l11l1_opy_)
def bstack11l11l11111_opy_(bstack111ll111lll_opy_):
    bstack11l111l111l_opy_ = bstack11l11l11l11_opy_(bstack111ll111lll_opy_)
    if bstack11l111l111l_opy_ and bstack11l111l111l_opy_ > bstack11l1l1l1lll_opy_:
        bstack111ll1ll111_opy_ = bstack11l111l111l_opy_ - bstack11l1l1l1lll_opy_
        bstack111lll1l1l1_opy_ = bstack111ll1lll1l_opy_(bstack111ll111lll_opy_[bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡢࡱࡪࡹࡳࡢࡩࡨࠦᮅ")], bstack111ll1ll111_opy_)
        bstack111ll111lll_opy_[bstack1l11_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡣࡲ࡫ࡳࡴࡣࡪࡩࠧᮆ")] = bstack111lll1l1l1_opy_
        logger.info(bstack1l11_opy_ (u"࡚ࠧࡨࡦࠢࡦࡳࡲࡳࡩࡵࠢ࡫ࡥࡸࠦࡢࡦࡧࡱࠤࡹࡸࡵ࡯ࡥࡤࡸࡪࡪ࠮ࠡࡕ࡬ࡾࡪࠦ࡯ࡧࠢࡦࡳࡲࡳࡩࡵࠢࡤࡪࡹ࡫ࡲࠡࡶࡵࡹࡳࡩࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡽࢀࠤࡐࡈࠢᮇ")
                    .format(bstack11l11l11l11_opy_(bstack111ll111lll_opy_) / 1024))
    return bstack111ll111lll_opy_
def bstack11l11l11l11_opy_(bstack1l1l111ll1_opy_):
    try:
        if bstack1l1l111ll1_opy_:
            bstack111llll1lll_opy_ = json.dumps(bstack1l1l111ll1_opy_)
            bstack111lllllll1_opy_ = sys.getsizeof(bstack111llll1lll_opy_)
            return bstack111lllllll1_opy_
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"ࠨࡓࡰ࡯ࡨࡸ࡭࡯࡮ࡨࠢࡺࡩࡳࡺࠠࡸࡴࡲࡲ࡬ࠦࡷࡩ࡫࡯ࡩࠥࡩࡡ࡭ࡥࡸࡰࡦࡺࡩ࡯ࡩࠣࡷ࡮ࢀࡥࠡࡱࡩࠤࡏ࡙ࡏࡏࠢࡲࡦ࡯࡫ࡣࡵ࠼ࠣࡿࢂࠨᮈ").format(e))
    return -1
def bstack111ll1lll1l_opy_(field, bstack11l111l11ll_opy_):
    try:
        bstack111llll1l11_opy_ = len(bytes(bstack11l1l11llll_opy_, bstack1l11_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭ᮉ")))
        bstack11l11111l11_opy_ = bytes(field, bstack1l11_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧᮊ"))
        bstack111llll11l1_opy_ = len(bstack11l11111l11_opy_)
        bstack11l11ll1ll1_opy_ = ceil(bstack111llll11l1_opy_ - bstack11l111l11ll_opy_ - bstack111llll1l11_opy_)
        if bstack11l11ll1ll1_opy_ > 0:
            bstack11l11l1llll_opy_ = bstack11l11111l11_opy_[:bstack11l11ll1ll1_opy_].decode(bstack1l11_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᮋ"), errors=bstack1l11_opy_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᮌ")) + bstack11l1l11llll_opy_
            return bstack11l11l1llll_opy_
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡯࡬ࡦࠢࡷࡶࡺࡴࡣࡢࡶ࡬ࡲ࡬ࠦࡦࡪࡧ࡯ࡨ࠱ࠦ࡮ࡰࡶ࡫࡭ࡳ࡭ࠠࡸࡣࡶࠤࡹࡸࡵ࡯ࡥࡤࡸࡪࡪࠠࡩࡧࡵࡩ࠿ࠦࡻࡾࠤᮍ").format(e))
    return field
def bstack1l11l1l11l_opy_():
    env = os.environ
    if (bstack1l11_opy_ (u"ࠧࡐࡅࡏࡍࡌࡒࡘࡥࡕࡓࡎࠥᮎ") in env and len(env[bstack1l11_opy_ (u"ࠨࡊࡆࡐࡎࡍࡓ࡙࡟ࡖࡔࡏࠦᮏ")]) > 0) or (
            bstack1l11_opy_ (u"ࠢࡋࡇࡑࡏࡎࡔࡓࡠࡊࡒࡑࡊࠨᮐ") in env and len(env[bstack1l11_opy_ (u"ࠣࡌࡈࡒࡐࡏࡎࡔࡡࡋࡓࡒࡋࠢᮑ")]) > 0):
        return {
            bstack1l11_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᮒ"): bstack1l11_opy_ (u"ࠥࡎࡪࡴ࡫ࡪࡰࡶࠦᮓ"),
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᮔ"): env.get(bstack1l11_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣ࡚ࡘࡌࠣᮕ")),
            bstack1l11_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᮖ"): env.get(bstack1l11_opy_ (u"ࠢࡋࡑࡅࡣࡓࡇࡍࡆࠤᮗ")),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᮘ"): env.get(bstack1l11_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣᮙ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠥࡇࡎࠨᮚ")) == bstack1l11_opy_ (u"ࠦࡹࡸࡵࡦࠤᮛ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡈࡏࠢᮜ"))):
        return {
            bstack1l11_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᮝ"): bstack1l11_opy_ (u"ࠢࡄ࡫ࡵࡧࡱ࡫ࡃࡊࠤᮞ"),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᮟ"): env.get(bstack1l11_opy_ (u"ࠤࡆࡍࡗࡉࡌࡆࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧᮠ")),
            bstack1l11_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᮡ"): env.get(bstack1l11_opy_ (u"ࠦࡈࡏࡒࡄࡎࡈࡣࡏࡕࡂࠣᮢ")),
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᮣ"): env.get(bstack1l11_opy_ (u"ࠨࡃࡊࡔࡆࡐࡊࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࠤᮤ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠢࡄࡋࠥᮥ")) == bstack1l11_opy_ (u"ࠣࡶࡵࡹࡪࠨᮦ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠤࡗࡖࡆ࡜ࡉࡔࠤᮧ"))):
        return {
            bstack1l11_opy_ (u"ࠥࡲࡦࡳࡥࠣᮨ"): bstack1l11_opy_ (u"࡙ࠦࡸࡡࡷ࡫ࡶࠤࡈࡏࠢᮩ"),
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬᮪ࠣ"): env.get(bstack1l11_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࡥࡂࡖࡋࡏࡈࡤ࡝ࡅࡃࡡࡘࡖࡑࠨ᮫")),
            bstack1l11_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᮬ"): env.get(bstack1l11_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥᮭ")),
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᮮ"): env.get(bstack1l11_opy_ (u"ࠥࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤᮯ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠦࡈࡏࠢ᮰")) == bstack1l11_opy_ (u"ࠧࡺࡲࡶࡧࠥ᮱") and env.get(bstack1l11_opy_ (u"ࠨࡃࡊࡡࡑࡅࡒࡋࠢ᮲")) == bstack1l11_opy_ (u"ࠢࡤࡱࡧࡩࡸ࡮ࡩࡱࠤ᮳"):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨ᮴"): bstack1l11_opy_ (u"ࠤࡆࡳࡩ࡫ࡳࡩ࡫ࡳࠦ᮵"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨ᮶"): None,
            bstack1l11_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ᮷"): None,
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ᮸"): None
        }
    if env.get(bstack1l11_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡅࡖࡆࡔࡃࡉࠤ᮹")) and env.get(bstack1l11_opy_ (u"ࠢࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡇࡔࡓࡍࡊࡖࠥᮺ")):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᮻ"): bstack1l11_opy_ (u"ࠤࡅ࡭ࡹࡨࡵࡤ࡭ࡨࡸࠧᮼ"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᮽ"): env.get(bstack1l11_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡈࡋࡗࡣࡍ࡚ࡔࡑࡡࡒࡖࡎࡍࡉࡏࠤᮾ")),
            bstack1l11_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᮿ"): None,
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᯀ"): env.get(bstack1l11_opy_ (u"ࠢࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤᯁ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠣࡅࡌࠦᯂ")) == bstack1l11_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᯃ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠥࡈࡗࡕࡎࡆࠤᯄ"))):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᯅ"): bstack1l11_opy_ (u"ࠧࡊࡲࡰࡰࡨࠦᯆ"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᯇ"): env.get(bstack1l11_opy_ (u"ࠢࡅࡔࡒࡒࡊࡥࡂࡖࡋࡏࡈࡤࡒࡉࡏࡍࠥᯈ")),
            bstack1l11_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᯉ"): None,
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᯊ"): env.get(bstack1l11_opy_ (u"ࠥࡈࡗࡕࡎࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣᯋ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠦࡈࡏࠢᯌ")) == bstack1l11_opy_ (u"ࠧࡺࡲࡶࡧࠥᯍ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠨࡓࡆࡏࡄࡔࡍࡕࡒࡆࠤᯎ"))):
        return {
            bstack1l11_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᯏ"): bstack1l11_opy_ (u"ࠣࡕࡨࡱࡦࡶࡨࡰࡴࡨࠦᯐ"),
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᯑ"): env.get(bstack1l11_opy_ (u"ࠥࡗࡊࡓࡁࡑࡊࡒࡖࡊࡥࡏࡓࡉࡄࡒࡎࡠࡁࡕࡋࡒࡒࡤ࡛ࡒࡍࠤᯒ")),
            bstack1l11_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᯓ"): env.get(bstack1l11_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥᯔ")),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᯕ"): env.get(bstack1l11_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࡢࡎࡔࡈ࡟ࡊࡆࠥᯖ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠣࡅࡌࠦᯗ")) == bstack1l11_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᯘ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠥࡋࡎ࡚ࡌࡂࡄࡢࡇࡎࠨᯙ"))):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᯚ"): bstack1l11_opy_ (u"ࠧࡍࡩࡵࡎࡤࡦࠧᯛ"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᯜ"): env.get(bstack1l11_opy_ (u"ࠢࡄࡋࡢࡎࡔࡈ࡟ࡖࡔࡏࠦᯝ")),
            bstack1l11_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᯞ"): env.get(bstack1l11_opy_ (u"ࠤࡆࡍࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᯟ")),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᯠ"): env.get(bstack1l11_opy_ (u"ࠦࡈࡏ࡟ࡋࡑࡅࡣࡎࡊࠢᯡ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠧࡉࡉࠣᯢ")) == bstack1l11_opy_ (u"ࠨࡴࡳࡷࡨࠦᯣ") and bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠢࡃࡗࡌࡐࡉࡑࡉࡕࡇࠥᯤ"))):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᯥ"): bstack1l11_opy_ (u"ࠤࡅࡹ࡮ࡲࡤ࡬࡫ࡷࡩ᯦ࠧ"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᯧ"): env.get(bstack1l11_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋ࡟ࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥᯨ")),
            bstack1l11_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᯩ"): env.get(bstack1l11_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡏࡅࡇࡋࡌࠣᯪ")) or env.get(bstack1l11_opy_ (u"ࠢࡃࡗࡌࡐࡉࡑࡉࡕࡇࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤࡔࡁࡎࡇࠥᯫ")),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᯬ"): env.get(bstack1l11_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᯭ"))
        }
    if bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠥࡘࡋࡥࡂࡖࡋࡏࡈࠧᯮ"))):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᯯ"): bstack1l11_opy_ (u"ࠧ࡜ࡩࡴࡷࡤࡰ࡙ࠥࡴࡶࡦ࡬ࡳ࡚ࠥࡥࡢ࡯ࠣࡗࡪࡸࡶࡪࡥࡨࡷࠧᯰ"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᯱ"): bstack1l11_opy_ (u"ࠢࡼࡿࡾࢁ᯲ࠧ").format(env.get(bstack1l11_opy_ (u"ࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡌࡏࡖࡐࡇࡅ࡙ࡏࡏࡏࡕࡈࡖ࡛ࡋࡒࡖࡔࡌ᯳ࠫ")), env.get(bstack1l11_opy_ (u"ࠩࡖ࡝ࡘ࡚ࡅࡎࡡࡗࡉࡆࡓࡐࡓࡑࡍࡉࡈ࡚ࡉࡅࠩ᯴"))),
            bstack1l11_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧ᯵"): env.get(bstack1l11_opy_ (u"ࠦࡘ࡟ࡓࡕࡇࡐࡣࡉࡋࡆࡊࡐࡌࡘࡎࡕࡎࡊࡆࠥ᯶")),
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ᯷"): env.get(bstack1l11_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉࠨ᯸"))
        }
    if bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠢࡂࡒࡓ࡚ࡊ࡟ࡏࡓࠤ᯹"))):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨ᯺"): bstack1l11_opy_ (u"ࠤࡄࡴࡵࡼࡥࡺࡱࡵࠦ᯻"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨ᯼"): bstack1l11_opy_ (u"ࠦࢀࢃ࠯ࡱࡴࡲ࡮ࡪࡩࡴ࠰ࡽࢀ࠳ࢀࢃ࠯ࡣࡷ࡬ࡰࡩࡹ࠯ࡼࡿࠥ᯽").format(env.get(bstack1l11_opy_ (u"ࠬࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡖࡔࡏࠫ᯾")), env.get(bstack1l11_opy_ (u"࠭ࡁࡑࡒ࡙ࡉ࡞ࡕࡒࡠࡃࡆࡇࡔ࡛ࡎࡕࡡࡑࡅࡒࡋࠧ᯿")), env.get(bstack1l11_opy_ (u"ࠧࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡓࡖࡔࡐࡅࡄࡖࡢࡗࡑ࡛ࡇࠨᰀ")), env.get(bstack1l11_opy_ (u"ࠨࡃࡓࡔ࡛ࡋ࡙ࡐࡔࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠬᰁ"))),
            bstack1l11_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᰂ"): env.get(bstack1l11_opy_ (u"ࠥࡅࡕࡖࡖࡆ࡛ࡒࡖࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᰃ")),
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᰄ"): env.get(bstack1l11_opy_ (u"ࠧࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᰅ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠨࡁ࡛ࡗࡕࡉࡤࡎࡔࡕࡒࡢ࡙ࡘࡋࡒࡠࡃࡊࡉࡓ࡚ࠢᰆ")) and env.get(bstack1l11_opy_ (u"ࠢࡕࡈࡢࡆ࡚ࡏࡌࡅࠤᰇ")):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᰈ"): bstack1l11_opy_ (u"ࠤࡄࡾࡺࡸࡥࠡࡅࡌࠦᰉ"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᰊ"): bstack1l11_opy_ (u"ࠦࢀࢃࡻࡾ࠱ࡢࡦࡺ࡯࡬ࡥ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡦࡺ࡯࡬ࡥࡋࡧࡁࢀࢃࠢᰋ").format(env.get(bstack1l11_opy_ (u"࡙࡙ࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡉࡓ࡚ࡔࡄࡂࡖࡌࡓࡓ࡙ࡅࡓࡘࡈࡖ࡚ࡘࡉࠨᰌ")), env.get(bstack1l11_opy_ (u"࠭ࡓ࡚ࡕࡗࡉࡒࡥࡔࡆࡃࡐࡔࡗࡕࡊࡆࡅࡗࠫᰍ")), env.get(bstack1l11_opy_ (u"ࠧࡃࡗࡌࡐࡉࡥࡂࡖࡋࡏࡈࡎࡊࠧᰎ"))),
            bstack1l11_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᰏ"): env.get(bstack1l11_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊࡉࡅࠤᰐ")),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᰑ"): env.get(bstack1l11_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡋࡇࠦᰒ"))
        }
    if any([env.get(bstack1l11_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᰓ")), env.get(bstack1l11_opy_ (u"ࠨࡃࡐࡆࡈࡆ࡚ࡏࡌࡅࡡࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘࡕࡕࡓࡅࡈࡣ࡛ࡋࡒࡔࡋࡒࡒࠧᰔ")), env.get(bstack1l11_opy_ (u"ࠢࡄࡑࡇࡉࡇ࡛ࡉࡍࡆࡢࡗࡔ࡛ࡒࡄࡇࡢ࡚ࡊࡘࡓࡊࡑࡑࠦᰕ"))]):
        return {
            bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᰖ"): bstack1l11_opy_ (u"ࠤࡄ࡛ࡘࠦࡃࡰࡦࡨࡆࡺ࡯࡬ࡥࠤᰗ"),
            bstack1l11_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᰘ"): env.get(bstack1l11_opy_ (u"ࠦࡈࡕࡄࡆࡄࡘࡍࡑࡊ࡟ࡑࡗࡅࡐࡎࡉ࡟ࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥᰙ")),
            bstack1l11_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᰚ"): env.get(bstack1l11_opy_ (u"ࠨࡃࡐࡆࡈࡆ࡚ࡏࡌࡅࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠦᰛ")),
            bstack1l11_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᰜ"): env.get(bstack1l11_opy_ (u"ࠣࡅࡒࡈࡊࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᰝ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠤࡥࡥࡲࡨ࡯ࡰࡡࡥࡹ࡮ࡲࡤࡏࡷࡰࡦࡪࡸࠢᰞ")):
        return {
            bstack1l11_opy_ (u"ࠥࡲࡦࡳࡥࠣᰟ"): bstack1l11_opy_ (u"ࠦࡇࡧ࡭ࡣࡱࡲࠦᰠ"),
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᰡ"): env.get(bstack1l11_opy_ (u"ࠨࡢࡢ࡯ࡥࡳࡴࡥࡢࡶ࡫࡯ࡨࡗ࡫ࡳࡶ࡮ࡷࡷ࡚ࡸ࡬ࠣᰢ")),
            bstack1l11_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᰣ"): env.get(bstack1l11_opy_ (u"ࠣࡤࡤࡱࡧࡵ࡯ࡠࡵ࡫ࡳࡷࡺࡊࡰࡤࡑࡥࡲ࡫ࠢᰤ")),
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᰥ"): env.get(bstack1l11_opy_ (u"ࠥࡦࡦࡳࡢࡰࡱࡢࡦࡺ࡯࡬ࡥࡐࡸࡱࡧ࡫ࡲࠣᰦ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࠧᰧ")) or env.get(bstack1l11_opy_ (u"ࠧ࡝ࡅࡓࡅࡎࡉࡗࡥࡍࡂࡋࡑࡣࡕࡏࡐࡆࡎࡌࡒࡊࡥࡓࡕࡃࡕࡘࡊࡊࠢᰨ")):
        return {
            bstack1l11_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᰩ"): bstack1l11_opy_ (u"ࠢࡘࡧࡵࡧࡰ࡫ࡲࠣᰪ"),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᰫ"): env.get(bstack1l11_opy_ (u"ࠤ࡚ࡉࡗࡉࡋࡆࡔࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᰬ")),
            bstack1l11_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᰭ"): bstack1l11_opy_ (u"ࠦࡒࡧࡩ࡯ࠢࡓ࡭ࡵ࡫࡬ࡪࡰࡨࠦᰮ") if env.get(bstack1l11_opy_ (u"ࠧ࡝ࡅࡓࡅࡎࡉࡗࡥࡍࡂࡋࡑࡣࡕࡏࡐࡆࡎࡌࡒࡊࡥࡓࡕࡃࡕࡘࡊࡊࠢᰯ")) else None,
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᰰ"): env.get(bstack1l11_opy_ (u"ࠢࡘࡇࡕࡇࡐࡋࡒࡠࡉࡌࡘࡤࡉࡏࡎࡏࡌࡘࠧᰱ"))
        }
    if any([env.get(bstack1l11_opy_ (u"ࠣࡉࡆࡔࡤࡖࡒࡐࡌࡈࡇ࡙ࠨᰲ")), env.get(bstack1l11_opy_ (u"ࠤࡊࡇࡑࡕࡕࡅࡡࡓࡖࡔࡐࡅࡄࡖࠥᰳ")), env.get(bstack1l11_opy_ (u"ࠥࡋࡔࡕࡇࡍࡇࡢࡇࡑࡕࡕࡅࡡࡓࡖࡔࡐࡅࡄࡖࠥᰴ"))]):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᰵ"): bstack1l11_opy_ (u"ࠧࡍ࡯ࡰࡩ࡯ࡩࠥࡉ࡬ࡰࡷࡧࠦᰶ"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᰷"): None,
            bstack1l11_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ᰸"): env.get(bstack1l11_opy_ (u"ࠣࡒࡕࡓࡏࡋࡃࡕࡡࡌࡈࠧ᰹")),
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣ᰺"): env.get(bstack1l11_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡌࡈࠧ᰻"))
        }
    if env.get(bstack1l11_opy_ (u"ࠦࡘࡎࡉࡑࡒࡄࡆࡑࡋࠢ᰼")):
        return {
            bstack1l11_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ᰽"): bstack1l11_opy_ (u"ࠨࡓࡩ࡫ࡳࡴࡦࡨ࡬ࡦࠤ᰾"),
            bstack1l11_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ᰿"): env.get(bstack1l11_opy_ (u"ࠣࡕࡋࡍࡕࡖࡁࡃࡎࡈࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢ᱀")),
            bstack1l11_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ᱁"): bstack1l11_opy_ (u"ࠥࡎࡴࡨࠠࠤࡽࢀࠦ᱂").format(env.get(bstack1l11_opy_ (u"ࠫࡘࡎࡉࡑࡒࡄࡆࡑࡋ࡟ࡋࡑࡅࡣࡎࡊࠧ᱃"))) if env.get(bstack1l11_opy_ (u"࡙ࠧࡈࡊࡒࡓࡅࡇࡒࡅࡠࡌࡒࡆࡤࡏࡄࠣ᱄")) else None,
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧ᱅"): env.get(bstack1l11_opy_ (u"ࠢࡔࡊࡌࡔࡕࡇࡂࡍࡇࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠤ᱆"))
        }
    if bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠣࡐࡈࡘࡑࡏࡆ࡚ࠤ᱇"))):
        return {
            bstack1l11_opy_ (u"ࠤࡱࡥࡲ࡫ࠢ᱈"): bstack1l11_opy_ (u"ࠥࡒࡪࡺ࡬ࡪࡨࡼࠦ᱉"),
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢ᱊"): env.get(bstack1l11_opy_ (u"ࠧࡊࡅࡑࡎࡒ࡝ࡤ࡛ࡒࡍࠤ᱋")),
            bstack1l11_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣ᱌"): env.get(bstack1l11_opy_ (u"ࠢࡔࡋࡗࡉࡤࡔࡁࡎࡇࠥᱍ")),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᱎ"): env.get(bstack1l11_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡋࡇࠦᱏ"))
        }
    if bstack1lll1lll1_opy_(env.get(bstack1l11_opy_ (u"ࠥࡋࡎ࡚ࡈࡖࡄࡢࡅࡈ࡚ࡉࡐࡐࡖࠦ᱐"))):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ᱑"): bstack1l11_opy_ (u"ࠧࡍࡩࡵࡊࡸࡦࠥࡇࡣࡵ࡫ࡲࡲࡸࠨ᱒"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᱓"): bstack1l11_opy_ (u"ࠢࡼࡿ࠲ࡿࢂ࠵ࡡࡤࡶ࡬ࡳࡳࡹ࠯ࡳࡷࡱࡷ࠴ࢁࡽࠣ᱔").format(env.get(bstack1l11_opy_ (u"ࠨࡉࡌࡘࡍ࡛ࡂࡠࡕࡈࡖ࡛ࡋࡒࡠࡗࡕࡐࠬ᱕")), env.get(bstack1l11_opy_ (u"ࠩࡊࡍ࡙ࡎࡕࡃࡡࡕࡉࡕࡕࡓࡊࡖࡒࡖ࡞࠭᱖")), env.get(bstack1l11_opy_ (u"ࠪࡋࡎ࡚ࡈࡖࡄࡢࡖ࡚ࡔ࡟ࡊࡆࠪ᱗"))),
            bstack1l11_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ᱘"): env.get(bstack1l11_opy_ (u"ࠧࡍࡉࡕࡊࡘࡆࡤ࡝ࡏࡓࡍࡉࡐࡔ࡝ࠢ᱙")),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᱚ"): env.get(bstack1l11_opy_ (u"ࠢࡈࡋࡗࡌ࡚ࡈ࡟ࡓࡗࡑࡣࡎࡊࠢᱛ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠣࡅࡌࠦᱜ")) == bstack1l11_opy_ (u"ࠤࡷࡶࡺ࡫ࠢᱝ") and env.get(bstack1l11_opy_ (u"࡚ࠥࡊࡘࡃࡆࡎࠥᱞ")) == bstack1l11_opy_ (u"ࠦ࠶ࠨᱟ"):
        return {
            bstack1l11_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᱠ"): bstack1l11_opy_ (u"ࠨࡖࡦࡴࡦࡩࡱࠨᱡ"),
            bstack1l11_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᱢ"): bstack1l11_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࡽࢀࠦᱣ").format(env.get(bstack1l11_opy_ (u"࡙ࠩࡉࡗࡉࡅࡍࡡࡘࡖࡑ࠭ᱤ"))),
            bstack1l11_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᱥ"): None,
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᱦ"): None,
        }
    if env.get(bstack1l11_opy_ (u"࡚ࠧࡅࡂࡏࡆࡍ࡙࡟࡟ࡗࡇࡕࡗࡎࡕࡎࠣᱧ")):
        return {
            bstack1l11_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᱨ"): bstack1l11_opy_ (u"ࠢࡕࡧࡤࡱࡨ࡯ࡴࡺࠤᱩ"),
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᱪ"): None,
            bstack1l11_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᱫ"): env.get(bstack1l11_opy_ (u"ࠥࡘࡊࡇࡍࡄࡋࡗ࡝ࡤࡖࡒࡐࡌࡈࡇ࡙ࡥࡎࡂࡏࡈࠦᱬ")),
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᱭ"): env.get(bstack1l11_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᱮ"))
        }
    if any([env.get(bstack1l11_opy_ (u"ࠨࡃࡐࡐࡆࡓ࡚ࡘࡓࡆࠤᱯ")), env.get(bstack1l11_opy_ (u"ࠢࡄࡑࡑࡇࡔ࡛ࡒࡔࡇࡢ࡙ࡗࡒࠢᱰ")), env.get(bstack1l11_opy_ (u"ࠣࡅࡒࡒࡈࡕࡕࡓࡕࡈࡣ࡚࡙ࡅࡓࡐࡄࡑࡊࠨᱱ")), env.get(bstack1l11_opy_ (u"ࠤࡆࡓࡓࡉࡏࡖࡔࡖࡉࡤ࡚ࡅࡂࡏࠥᱲ"))]):
        return {
            bstack1l11_opy_ (u"ࠥࡲࡦࡳࡥࠣᱳ"): bstack1l11_opy_ (u"ࠦࡈࡵ࡮ࡤࡱࡸࡶࡸ࡫ࠢᱴ"),
            bstack1l11_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᱵ"): None,
            bstack1l11_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᱶ"): env.get(bstack1l11_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡊࡐࡄࡢࡒࡆࡓࡅࠣᱷ")) or None,
            bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᱸ"): env.get(bstack1l11_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡋࡇࠦᱹ"), 0)
        }
    if env.get(bstack1l11_opy_ (u"ࠥࡋࡔࡥࡊࡐࡄࡢࡒࡆࡓࡅࠣᱺ")):
        return {
            bstack1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᱻ"): bstack1l11_opy_ (u"ࠧࡍ࡯ࡄࡆࠥᱼ"),
            bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᱽ"): None,
            bstack1l11_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ᱾"): env.get(bstack1l11_opy_ (u"ࠣࡉࡒࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨ᱿")),
            bstack1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᲀ"): env.get(bstack1l11_opy_ (u"ࠥࡋࡔࡥࡐࡊࡒࡈࡐࡎࡔࡅࡠࡅࡒ࡙ࡓ࡚ࡅࡓࠤᲁ"))
        }
    if env.get(bstack1l11_opy_ (u"ࠦࡈࡌ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤᲂ")):
        return {
            bstack1l11_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᲃ"): bstack1l11_opy_ (u"ࠨࡃࡰࡦࡨࡊࡷ࡫ࡳࡩࠤᲄ"),
            bstack1l11_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᲅ"): env.get(bstack1l11_opy_ (u"ࠣࡅࡉࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢᲆ")),
            bstack1l11_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᲇ"): env.get(bstack1l11_opy_ (u"ࠥࡇࡋࡥࡐࡊࡒࡈࡐࡎࡔࡅࡠࡐࡄࡑࡊࠨᲈ")),
            bstack1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᲉ"): env.get(bstack1l11_opy_ (u"ࠧࡉࡆࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᲊ"))
        }
    return {bstack1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧ᲋"): None}
def get_host_info():
    return {
        bstack1l11_opy_ (u"ࠢࡩࡱࡶࡸࡳࡧ࡭ࡦࠤ᲌"): platform.node(),
        bstack1l11_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ᲍"): platform.system(),
        bstack1l11_opy_ (u"ࠤࡷࡽࡵ࡫ࠢ᲎"): platform.machine(),
        bstack1l11_opy_ (u"ࠥࡺࡪࡸࡳࡪࡱࡱࠦ᲏"): platform.version(),
        bstack1l11_opy_ (u"ࠦࡦࡸࡣࡩࠤᲐ"): platform.architecture()[0]
    }
def bstack1lll1l1lll_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack111lllll111_opy_():
    if bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭Ბ")):
        return bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬᲒ")
    return bstack1l11_opy_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࡠࡩࡵ࡭ࡩ࠭Დ")
def bstack11l11ll111l_opy_(driver):
    info = {
        bstack1l11_opy_ (u"ࠨࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠧᲔ"): driver.capabilities,
        bstack1l11_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡢ࡭ࡩ࠭Ვ"): driver.session_id,
        bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫᲖ"): driver.capabilities.get(bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩᲗ"), None),
        bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᲘ"): driver.capabilities.get(bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᲙ"), None),
        bstack1l11_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩᲚ"): driver.capabilities.get(bstack1l11_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡑࡥࡲ࡫ࠧᲛ"), None),
        bstack1l11_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᲜ"):driver.capabilities.get(bstack1l11_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠬᲝ"), None),
    }
    if bstack111lllll111_opy_() == bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪᲞ"):
        if bstack1l111l11ll_opy_():
            info[bstack1l11_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹ࠭Ჟ")] = bstack1l11_opy_ (u"࠭ࡡࡱࡲ࠰ࡥࡺࡺ࡯࡮ࡣࡷࡩࠬᲠ")
        elif driver.capabilities.get(bstack1l11_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᲡ"), {}).get(bstack1l11_opy_ (u"ࠨࡶࡸࡶࡧࡵࡳࡤࡣ࡯ࡩࠬᲢ"), False):
            info[bstack1l11_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪᲣ")] = bstack1l11_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫ࠧᲤ")
        else:
            info[bstack1l11_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࠬᲥ")] = bstack1l11_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡫ࠧᲦ")
    return info
def bstack1l111l11ll_opy_():
    if bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"࠭ࡡࡱࡲࡢࡥࡺࡺ࡯࡮ࡣࡷࡩࠬᲧ")):
        return True
    if bstack1lll1lll1_opy_(os.environ.get(bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨᲨ"), None)):
        return True
    return False
def bstack11l1l1l111_opy_(bstack11l11ll1lll_opy_, url, data, config):
    headers = config.get(bstack1l11_opy_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩᲩ"), None)
    proxies = bstack111lll1l1_opy_(config, url)
    auth = config.get(bstack1l11_opy_ (u"ࠩࡤࡹࡹ࡮ࠧᲪ"), None)
    response = requests.request(
            bstack11l11ll1lll_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1ll11ll1l_opy_(bstack11lll1l1l_opy_, size):
    bstack1lll1l11l1_opy_ = []
    while len(bstack11lll1l1l_opy_) > size:
        bstack11ll1111l1_opy_ = bstack11lll1l1l_opy_[:size]
        bstack1lll1l11l1_opy_.append(bstack11ll1111l1_opy_)
        bstack11lll1l1l_opy_ = bstack11lll1l1l_opy_[size:]
    bstack1lll1l11l1_opy_.append(bstack11lll1l1l_opy_)
    return bstack1lll1l11l1_opy_
def bstack11l1111l11l_opy_(message, bstack111ll11ll11_opy_=False):
    os.write(1, bytes(message, bstack1l11_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᲫ")))
    os.write(1, bytes(bstack1l11_opy_ (u"ࠫࡡࡴࠧᲬ"), bstack1l11_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᲭ")))
    if bstack111ll11ll11_opy_:
        with open(bstack1l11_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࠳࡯࠲࠳ࡼ࠱ࠬᲮ") + os.environ[bstack1l11_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉ࠭Ჯ")] + bstack1l11_opy_ (u"ࠨ࠰࡯ࡳ࡬࠭Ჰ"), bstack1l11_opy_ (u"ࠩࡤࠫᲱ")) as f:
            f.write(message + bstack1l11_opy_ (u"ࠪࡠࡳ࠭Ჲ"))
def bstack1l1ll1l1ll1_opy_():
    return os.environ[bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠧᲳ")].lower() == bstack1l11_opy_ (u"ࠬࡺࡲࡶࡧࠪᲴ")
def bstack1llll1l1_opy_():
    return bstack1111l1lll1_opy_().replace(tzinfo=None).isoformat() + bstack1l11_opy_ (u"࡚࠭ࠨᲵ")
def bstack111llllllll_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack1l11_opy_ (u"࡛ࠧࠩᲶ"))) - datetime.datetime.fromisoformat(start.rstrip(bstack1l11_opy_ (u"ࠨ࡜ࠪᲷ")))).total_seconds() * 1000
def bstack111lll1l1ll_opy_(timestamp):
    return bstack111lll11l1l_opy_(timestamp).isoformat() + bstack1l11_opy_ (u"ࠩ࡝ࠫᲸ")
def bstack111ll11l1ll_opy_(bstack11l111ll111_opy_):
    date_format = bstack1l11_opy_ (u"ࠪࠩ࡞ࠫ࡭ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ࠳ࠫࡦࠨᲹ")
    bstack111ll11ll1l_opy_ = datetime.datetime.strptime(bstack11l111ll111_opy_, date_format)
    return bstack111ll11ll1l_opy_.isoformat() + bstack1l11_opy_ (u"ࠫ࡟࠭Ჺ")
def bstack11l11ll1l11_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1l11_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ᲻")
    else:
        return bstack1l11_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭᲼")
def bstack1lll1lll1_opy_(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack1l11_opy_ (u"ࠧࡵࡴࡸࡩࠬᲽ")
def bstack111ll11l11l_opy_(val):
    return val.__str__().lower() == bstack1l11_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧᲾ")
def error_handler(bstack11l11l11ll1_opy_=Exception, class_method=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack11l11l11ll1_opy_ as e:
                print(bstack1l11_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡿࢂࠦ࠭࠿ࠢࡾࢁ࠿ࠦࡻࡾࠤᲿ").format(func.__name__, bstack11l11l11ll1_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack111ll111l1l_opy_(bstack11l111l1lll_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack11l111l1lll_opy_(cls, *args, **kwargs)
            except bstack11l11l11ll1_opy_ as e:
                print(bstack1l11_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࢀࢃࠠ࠮ࡀࠣࡿࢂࡀࠠࡼࡿࠥ᳀").format(bstack11l111l1lll_opy_.__name__, bstack11l11l11ll1_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if class_method:
        return bstack111ll111l1l_opy_
    else:
        return decorator
def bstack11ll1ll1l_opy_(bstack11111ll1ll_opy_):
    if os.getenv(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠧ᳁")) is not None:
        return bstack1lll1lll1_opy_(os.getenv(bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡆ࡛ࡔࡐࡏࡄࡘࡎࡕࡎࠨ᳂")))
    if bstack1l11_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪ᳃") in bstack11111ll1ll_opy_ and bstack111ll11l11l_opy_(bstack11111ll1ll_opy_[bstack1l11_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫ᳄")]):
        return False
    if bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪ᳅") in bstack11111ll1ll_opy_ and bstack111ll11l11l_opy_(bstack11111ll1ll_opy_[bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫ᳆")]):
        return False
    return True
def bstack1l111ll11_opy_():
    try:
        from pytest_bdd import reporting
        bstack111ll11l111_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡘࡗࡊࡘ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠥ᳇"), None)
        return bstack111ll11l111_opy_ is None or bstack111ll11l111_opy_ == bstack1l11_opy_ (u"ࠦࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠣ᳈")
    except Exception as e:
        return False
def bstack1llll1l1ll_opy_(hub_url, CONFIG):
    if bstack1lllll1ll_opy_() <= version.parse(bstack1l11_opy_ (u"ࠬ࠹࠮࠲࠵࠱࠴ࠬ᳉")):
        if hub_url:
            return bstack1l11_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ᳊") + hub_url + bstack1l11_opy_ (u"ࠢ࠻࠺࠳࠳ࡼࡪ࠯ࡩࡷࡥࠦ᳋")
        return bstack1ll11llll1_opy_
    if hub_url:
        return bstack1l11_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥ᳌") + hub_url + bstack1l11_opy_ (u"ࠤ࠲ࡻࡩ࠵ࡨࡶࡤࠥ᳍")
    return bstack1lll11lll1_opy_
def bstack11l111llll1_opy_():
    return isinstance(os.getenv(bstack1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓ࡝࡙ࡋࡓࡕࡡࡓࡐ࡚ࡍࡉࡏࠩ᳎")), str)
def bstack11l1llll1_opy_(url):
    return urlparse(url).hostname
def bstack11ll111l1l_opy_(hostname):
    for bstack11l11l1l11_opy_ in bstack1ll111llll_opy_:
        regex = re.compile(bstack11l11l1l11_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack11l11l1l111_opy_(bstack11l111ll1l1_opy_, file_name, logger):
    bstack1l111lll11_opy_ = os.path.join(os.path.expanduser(bstack1l11_opy_ (u"ࠫࢃ࠭᳏")), bstack11l111ll1l1_opy_)
    try:
        if not os.path.exists(bstack1l111lll11_opy_):
            os.makedirs(bstack1l111lll11_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1l11_opy_ (u"ࠬࢄࠧ᳐")), bstack11l111ll1l1_opy_, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1l11_opy_ (u"࠭ࡷࠨ᳑")):
                pass
            with open(file_path, bstack1l11_opy_ (u"ࠢࡸ࠭ࠥ᳒")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack11l1111l1_opy_.format(str(e)))
def bstack111ll1l1l11_opy_(file_name, key, value, logger):
    file_path = bstack11l11l1l111_opy_(bstack1l11_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨ᳓"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1111l111_opy_ = json.load(open(file_path, bstack1l11_opy_ (u"ࠩࡵࡦ᳔ࠬ")))
        else:
            bstack1111l111_opy_ = {}
        bstack1111l111_opy_[key] = value
        with open(file_path, bstack1l11_opy_ (u"ࠥࡻ࠰ࠨ᳕")) as outfile:
            json.dump(bstack1111l111_opy_, outfile)
def bstack1l1lll111l_opy_(file_name, logger):
    file_path = bstack11l11l1l111_opy_(bstack1l11_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮᳖ࠫ"), file_name, logger)
    bstack1111l111_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1l11_opy_ (u"ࠬࡸ᳗ࠧ")) as bstack1l1lll1l1_opy_:
            bstack1111l111_opy_ = json.load(bstack1l1lll1l1_opy_)
    return bstack1111l111_opy_
def bstack1l1111ll_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡦࡨࡰࡪࡺࡩ࡯ࡩࠣࡪ࡮ࡲࡥ࠻᳘ࠢࠪ") + file_path + bstack1l11_opy_ (u"᳙ࠧࠡࠩ") + str(e))
def bstack1lllll1ll_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1l11_opy_ (u"ࠣ࠾ࡑࡓ࡙࡙ࡅࡕࡀࠥ᳚")
def bstack1l11l11ll_opy_(config):
    if bstack1l11_opy_ (u"ࠩ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠨ᳛") in config:
        del (config[bstack1l11_opy_ (u"ࠪ࡭ࡸࡖ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ᳜ࠩ")])
        return False
    if bstack1lllll1ll_opy_() < version.parse(bstack1l11_opy_ (u"ࠫ࠸࠴࠴࠯࠲᳝ࠪ")):
        return False
    if bstack1lllll1ll_opy_() >= version.parse(bstack1l11_opy_ (u"ࠬ࠺࠮࠲࠰࠸᳞ࠫ")):
        return True
    if bstack1l11_opy_ (u"࠭ࡵࡴࡧ࡚࠷ࡈ᳟࠭") in config and config[bstack1l11_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧ᳠")] is False:
        return False
    else:
        return True
def bstack1l11ll1111_opy_(args_list, bstack11l11ll1111_opy_):
    index = -1
    for value in bstack11l11ll1111_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
def bstack11ll1ll1l11_opy_(a, b):
  for k, v in b.items():
    if isinstance(v, dict) and k in a and isinstance(a[k], dict):
        bstack11ll1ll1l11_opy_(a[k], v)
    else:
        a[k] = v
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack111ll11l1l_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack111ll11l1l_opy_ = bstack111ll11l1l_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack1l11_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ᳡"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack1l11_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥ᳢ࠩ"), exception=exception)
    def bstack111111111l_opy_(self):
        if self.result != bstack1l11_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦ᳣ࠪ"):
            return None
        if isinstance(self.exception_type, str) and bstack1l11_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴ᳤ࠢ") in self.exception_type:
            return bstack1l11_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࡆࡴࡵࡳࡷࠨ᳥")
        return bstack1l11_opy_ (u"ࠨࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸ᳦ࠢ")
    def bstack111lll11l11_opy_(self):
        if self.result != bstack1l11_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪ᳧ࠧ"):
            return None
        if self.bstack111ll11l1l_opy_:
            return self.bstack111ll11l1l_opy_
        return bstack11l11111111_opy_(self.exception)
def bstack11l11111111_opy_(exc):
    return [traceback.format_exception(exc)]
def bstack11l11111lll_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack1l11lll11_opy_(object, key, default_value):
    if not object or not object.__dict__:
        return default_value
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1111ll11_opy_(config, logger):
    try:
        import playwright
        bstack11l1111llll_opy_ = playwright.__file__
        bstack11l1111ll11_opy_ = os.path.split(bstack11l1111llll_opy_)
        bstack11l11l1lll1_opy_ = bstack11l1111ll11_opy_[0] + bstack1l11_opy_ (u"ࠨ࠱ࡧࡶ࡮ࡼࡥࡳ࠱ࡳࡥࡨࡱࡡࡨࡧ࠲ࡰ࡮ࡨ࠯ࡤ࡮࡬࠳ࡨࡲࡩ࠯࡬ࡶ᳨ࠫ")
        os.environ[bstack1l11_opy_ (u"ࠩࡊࡐࡔࡈࡁࡍࡡࡄࡋࡊࡔࡔࡠࡊࡗࡘࡕࡥࡐࡓࡑ࡛࡝ࠬᳩ")] = bstack1ll1ll111_opy_(config)
        with open(bstack11l11l1lll1_opy_, bstack1l11_opy_ (u"ࠪࡶࠬᳪ")) as f:
            bstack1l11l1111l_opy_ = f.read()
            bstack111ll111ll1_opy_ = bstack1l11_opy_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯࠱ࡦ࡭ࡥ࡯ࡶࠪᳫ")
            bstack111lll1l111_opy_ = bstack1l11l1111l_opy_.find(bstack111ll111ll1_opy_)
            if bstack111lll1l111_opy_ == -1:
              process = subprocess.Popen(bstack1l11_opy_ (u"ࠧࡴࡰ࡮ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣ࡫ࡱࡵࡢࡢ࡮࠰ࡥ࡬࡫࡮ࡵࠤᳬ"), shell=True, cwd=bstack11l1111ll11_opy_[0])
              process.wait()
              bstack11l11l111ll_opy_ = bstack1l11_opy_ (u"࠭ࠢࡶࡵࡨࠤࡸࡺࡲࡪࡥࡷࠦࡀ᳭࠭")
              bstack11l111l1111_opy_ = bstack1l11_opy_ (u"ࠢࠣࠤࠣࡠࠧࡻࡳࡦࠢࡶࡸࡷ࡯ࡣࡵ࡞ࠥ࠿ࠥࡩ࡯࡯ࡵࡷࠤࢀࠦࡢࡰࡱࡷࡷࡹࡸࡡࡱࠢࢀࠤࡂࠦࡲࡦࡳࡸ࡭ࡷ࡫ࠨࠨࡩ࡯ࡳࡧࡧ࡬࠮ࡣࡪࡩࡳࡺࠧࠪ࠽ࠣ࡭࡫ࠦࠨࡱࡴࡲࡧࡪࡹࡳ࠯ࡧࡱࡺ࠳ࡍࡌࡐࡄࡄࡐࡤࡇࡇࡆࡐࡗࡣࡍ࡚ࡔࡑࡡࡓࡖࡔ࡞࡙ࠪࠢࡥࡳࡴࡺࡳࡵࡴࡤࡴ࠭࠯࠻ࠡࠤࠥࠦᳮ")
              bstack111ll11lll1_opy_ = bstack1l11l1111l_opy_.replace(bstack11l11l111ll_opy_, bstack11l111l1111_opy_)
              with open(bstack11l11l1lll1_opy_, bstack1l11_opy_ (u"ࠨࡹࠪᳯ")) as f:
                f.write(bstack111ll11lll1_opy_)
    except Exception as e:
        logger.error(bstack1lll111l_opy_.format(str(e)))
def bstack1l111l1l1_opy_():
  try:
    bstack111llll1111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠩࡲࡴࡹ࡯࡭ࡢ࡮ࡢ࡬ࡺࡨ࡟ࡶࡴ࡯࠲࡯ࡹ࡯࡯ࠩᳰ"))
    bstack11l1111111l_opy_ = []
    if os.path.exists(bstack111llll1111_opy_):
      with open(bstack111llll1111_opy_) as f:
        bstack11l1111111l_opy_ = json.load(f)
      os.remove(bstack111llll1111_opy_)
    return bstack11l1111111l_opy_
  except:
    pass
  return []
def bstack1l11111ll_opy_(bstack1ll1l1l1l1_opy_):
  try:
    bstack11l1111111l_opy_ = []
    bstack111llll1111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠪࡳࡵࡺࡩ࡮ࡣ࡯ࡣ࡭ࡻࡢࡠࡷࡵࡰ࠳ࡰࡳࡰࡰࠪᳱ"))
    if os.path.exists(bstack111llll1111_opy_):
      with open(bstack111llll1111_opy_) as f:
        bstack11l1111111l_opy_ = json.load(f)
    bstack11l1111111l_opy_.append(bstack1ll1l1l1l1_opy_)
    with open(bstack111llll1111_opy_, bstack1l11_opy_ (u"ࠫࡼ࠭ᳲ")) as f:
        json.dump(bstack11l1111111l_opy_, f)
  except:
    pass
def bstack11l1l11l_opy_(logger, bstack111llll1ll1_opy_ = False):
  try:
    test_name = os.environ.get(bstack1l11_opy_ (u"ࠬࡖ࡙ࡕࡇࡖࡘࡤ࡚ࡅࡔࡖࡢࡒࡆࡓࡅࠨᳳ"), bstack1l11_opy_ (u"࠭ࠧ᳴"))
    if test_name == bstack1l11_opy_ (u"ࠧࠨᳵ"):
        test_name = threading.current_thread().__dict__.get(bstack1l11_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡃࡦࡧࡣࡹ࡫ࡳࡵࡡࡱࡥࡲ࡫ࠧᳶ"), bstack1l11_opy_ (u"ࠩࠪ᳷"))
    bstack11l111l11l1_opy_ = bstack1l11_opy_ (u"ࠪ࠰ࠥ࠭᳸").join(threading.current_thread().bstackTestErrorMessages)
    if bstack111llll1ll1_opy_:
        bstack1l1l11ll11_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫ᳹"), bstack1l11_opy_ (u"ࠬ࠶ࠧᳺ"))
        bstack1llll1ll_opy_ = {bstack1l11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ᳻"): test_name, bstack1l11_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭᳼"): bstack11l111l11l1_opy_, bstack1l11_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ᳽"): bstack1l1l11ll11_opy_}
        bstack11l11l1111l_opy_ = []
        bstack11l11l1ll1l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡳࡴࡵࡥࡥࡳࡴࡲࡶࡤࡲࡩࡴࡶ࠱࡮ࡸࡵ࡮ࠨ᳾"))
        if os.path.exists(bstack11l11l1ll1l_opy_):
            with open(bstack11l11l1ll1l_opy_) as f:
                bstack11l11l1111l_opy_ = json.load(f)
        bstack11l11l1111l_opy_.append(bstack1llll1ll_opy_)
        with open(bstack11l11l1ll1l_opy_, bstack1l11_opy_ (u"ࠪࡻࠬ᳿")) as f:
            json.dump(bstack11l11l1111l_opy_, f)
    else:
        bstack1llll1ll_opy_ = {bstack1l11_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᴀ"): test_name, bstack1l11_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫᴁ"): bstack11l111l11l1_opy_, bstack1l11_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬᴂ"): str(multiprocessing.current_process().name)}
        if bstack1l11_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷࠫᴃ") not in multiprocessing.current_process().__dict__.keys():
            multiprocessing.current_process().bstack_error_list = []
        multiprocessing.current_process().bstack_error_list.append(bstack1llll1ll_opy_)
  except Exception as e:
      logger.warn(bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸࡺ࡯ࡳࡧࠣࡴࡾࡺࡥࡴࡶࠣࡪࡺࡴ࡮ࡦ࡮ࠣࡨࡦࡺࡡ࠻ࠢࡾࢁࠧᴄ").format(e))
def bstack1lll1l1l1_opy_(error_message, test_name, index, logger):
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1l11_opy_ (u"ࠩࡩ࡭ࡱ࡫࡬ࡰࡥ࡮ࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨ࠰ࠥࡻࡳࡪࡰࡪࠤࡧࡧࡳࡪࡥࠣࡪ࡮ࡲࡥࠡࡱࡳࡩࡷࡧࡴࡪࡱࡱࡷࠬᴅ"))
    try:
      bstack111ll1lllll_opy_ = []
      bstack1llll1ll_opy_ = {bstack1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨᴆ"): test_name, bstack1l11_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪᴇ"): error_message, bstack1l11_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫᴈ"): index}
      bstack111ll1l111l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"࠭ࡲࡰࡤࡲࡸࡤ࡫ࡲࡳࡱࡵࡣࡱ࡯ࡳࡵ࠰࡭ࡷࡴࡴࠧᴉ"))
      if os.path.exists(bstack111ll1l111l_opy_):
          with open(bstack111ll1l111l_opy_) as f:
              bstack111ll1lllll_opy_ = json.load(f)
      bstack111ll1lllll_opy_.append(bstack1llll1ll_opy_)
      with open(bstack111ll1l111l_opy_, bstack1l11_opy_ (u"ࠧࡸࠩᴊ")) as f:
          json.dump(bstack111ll1lllll_opy_, f)
    except Exception as e:
      logger.warn(bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸࡺ࡯ࡳࡧࠣࡶࡴࡨ࡯ࡵࠢࡩࡹࡳࡴࡥ࡭ࠢࡧࡥࡹࡧ࠺ࠡࡽࢀࠦᴋ").format(e))
    return
  bstack111ll1lllll_opy_ = []
  bstack1llll1ll_opy_ = {bstack1l11_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᴌ"): test_name, bstack1l11_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩᴍ"): error_message, bstack1l11_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪᴎ"): index}
  bstack111ll1l111l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࡣࡪࡸࡲࡰࡴࡢࡰ࡮ࡹࡴ࠯࡬ࡶࡳࡳ࠭ᴏ"))
  lock_file = bstack111ll1l111l_opy_ + bstack1l11_opy_ (u"࠭࠮࡭ࡱࡦ࡯ࠬᴐ")
  try:
    with FileLock(lock_file, timeout=10):
      if os.path.exists(bstack111ll1l111l_opy_):
          with open(bstack111ll1l111l_opy_, bstack1l11_opy_ (u"ࠧࡳࠩᴑ")) as f:
              content = f.read().strip()
              if content:
                  bstack111ll1lllll_opy_ = json.load(open(bstack111ll1l111l_opy_))
      bstack111ll1lllll_opy_.append(bstack1llll1ll_opy_)
      with open(bstack111ll1l111l_opy_, bstack1l11_opy_ (u"ࠨࡹࠪᴒ")) as f:
          json.dump(bstack111ll1lllll_opy_, f)
  except Exception as e:
    logger.warn(bstack1l11_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡴࡰࡴࡨࠤࡷࡵࡢࡰࡶࠣࡪࡺࡴ࡮ࡦ࡮ࠣࡨࡦࡺࡡࠡࡹ࡬ࡸ࡭ࠦࡦࡪ࡮ࡨࠤࡱࡵࡣ࡬࡫ࡱ࡫࠿ࠦࡻࡾࠤᴓ").format(e))
def bstack1ll11111l_opy_(bstack1111ll1l1_opy_, name, logger):
  try:
    bstack1llll1ll_opy_ = {bstack1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨᴔ"): name, bstack1l11_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪᴕ"): bstack1111ll1l1_opy_, bstack1l11_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫᴖ"): str(threading.current_thread()._name)}
    return bstack1llll1ll_opy_
  except Exception as e:
    logger.warn(bstack1l11_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡶࡸࡴࡸࡥࠡࡤࡨ࡬ࡦࡼࡥࠡࡨࡸࡲࡳ࡫࡬ࠡࡦࡤࡸࡦࡀࠠࡼࡿࠥᴗ").format(e))
  return
def bstack11l111l1ll1_opy_():
    return platform.system() == bstack1l11_opy_ (u"ࠧࡘ࡫ࡱࡨࡴࡽࡳࠨᴘ")
def bstack1ll1ll1l1l_opy_(bstack111ll1llll1_opy_, config, logger):
    bstack11l11l111l1_opy_ = {}
    try:
        return {key: config[key] for key in config if bstack111ll1llll1_opy_.match(key)}
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤ࡫࡯࡬ࡵࡧࡵࠤࡨࡵ࡮ࡧ࡫ࡪࠤࡰ࡫ࡹࡴࠢࡥࡽࠥࡸࡥࡨࡧࡻࠤࡲࡧࡴࡤࡪ࠽ࠤࢀࢃࠢᴙ").format(e))
    return bstack11l11l111l1_opy_
def bstack111lll1ll11_opy_(bstack11l111ll11l_opy_, bstack11l11111l1l_opy_):
    bstack111lll1ll1l_opy_ = version.parse(bstack11l111ll11l_opy_)
    bstack111ll1l1lll_opy_ = version.parse(bstack11l11111l1l_opy_)
    if bstack111lll1ll1l_opy_ > bstack111ll1l1lll_opy_:
        return 1
    elif bstack111lll1ll1l_opy_ < bstack111ll1l1lll_opy_:
        return -1
    else:
        return 0
def bstack1111l1lll1_opy_():
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def bstack111lll11l1l_opy_(timestamp):
    return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).replace(tzinfo=None)
def bstack111lll1111l_opy_(framework):
    from browserstack_sdk._version import __version__
    return str(framework) + str(__version__)
def bstack1l1ll1l111_opy_(options, framework, config, bstack1l1lll11l_opy_={}):
    if options is None:
        return
    if getattr(options, bstack1l11_opy_ (u"ࠩࡪࡩࡹ࠭ᴚ"), None):
        caps = options
    else:
        caps = options.to_capabilities()
    bstack1llll1l1l_opy_ = caps.get(bstack1l11_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᴛ"))
    bstack111ll1l1ll1_opy_ = True
    bstack11llllll11_opy_ = os.environ[bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩᴜ")]
    bstack1ll11l1l11l_opy_ = config.get(bstack1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᴝ"), False)
    if bstack1ll11l1l11l_opy_:
        bstack1ll1l1l111l_opy_ = config.get(bstack1l11_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᴞ"), {})
        bstack1ll1l1l111l_opy_[bstack1l11_opy_ (u"ࠧࡢࡷࡷ࡬࡙ࡵ࡫ࡦࡰࠪᴟ")] = os.getenv(bstack1l11_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭ᴠ"))
        bstack11ll1ll11l1_opy_ = json.loads(os.getenv(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪᴡ"), bstack1l11_opy_ (u"ࠪࡿࢂ࠭ᴢ"))).get(bstack1l11_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᴣ"))
    if bstack111ll11l11l_opy_(caps.get(bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡺࡹࡥࡘ࠵ࡆࠫᴤ"))) or bstack111ll11l11l_opy_(caps.get(bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡻࡳࡦࡡࡺ࠷ࡨ࠭ᴥ"))):
        bstack111ll1l1ll1_opy_ = False
    if bstack1l11l11ll_opy_({bstack1l11_opy_ (u"ࠢࡶࡵࡨ࡛࠸ࡉࠢᴦ"): bstack111ll1l1ll1_opy_}):
        bstack1llll1l1l_opy_ = bstack1llll1l1l_opy_ or {}
        bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪᴧ")] = bstack111lll1111l_opy_(framework)
        bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᴨ")] = bstack1l1ll1l1ll1_opy_()
        bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠪࡸࡪࡹࡴࡩࡷࡥࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭ᴩ")] = bstack11llllll11_opy_
        bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭ᴪ")] = bstack1l1lll11l_opy_
        if bstack1ll11l1l11l_opy_:
            bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᴫ")] = bstack1ll11l1l11l_opy_
            bstack1llll1l1l_opy_[bstack1l11_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᴬ")] = bstack1ll1l1l111l_opy_
            bstack1llll1l1l_opy_[bstack1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧᴭ")][bstack1l11_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩᴮ")] = bstack11ll1ll11l1_opy_
        if getattr(options, bstack1l11_opy_ (u"ࠩࡶࡩࡹࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵࡻࠪᴯ"), None):
            options.set_capability(bstack1l11_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫᴰ"), bstack1llll1l1l_opy_)
        else:
            options[bstack1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᴱ")] = bstack1llll1l1l_opy_
    else:
        if getattr(options, bstack1l11_opy_ (u"ࠬࡹࡥࡵࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸࡾ࠭ᴲ"), None):
            options.set_capability(bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧᴳ"), bstack111lll1111l_opy_(framework))
            options.set_capability(bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᴴ"), bstack1l1ll1l1ll1_opy_())
            options.set_capability(bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡵࡧࡶࡸ࡭ࡻࡢࡃࡷ࡬ࡰࡩ࡛ࡵࡪࡦࠪᴵ"), bstack11llllll11_opy_)
            options.set_capability(bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡸ࡭ࡱࡪࡐࡳࡱࡧࡹࡨࡺࡍࡢࡲࠪᴶ"), bstack1l1lll11l_opy_)
            if bstack1ll11l1l11l_opy_:
                options.set_capability(bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᴷ"), bstack1ll11l1l11l_opy_)
                options.set_capability(bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪᴸ"), bstack1ll1l1l111l_opy_)
                options.set_capability(bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶ࠲ࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᴹ"), bstack11ll1ll11l1_opy_)
        else:
            options[bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧᴺ")] = bstack111lll1111l_opy_(framework)
            options[bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᴻ")] = bstack1l1ll1l1ll1_opy_()
            options[bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡵࡧࡶࡸ࡭ࡻࡢࡃࡷ࡬ࡰࡩ࡛ࡵࡪࡦࠪᴼ")] = bstack11llllll11_opy_
            options[bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡸ࡭ࡱࡪࡐࡳࡱࡧࡹࡨࡺࡍࡢࡲࠪᴽ")] = bstack1l1lll11l_opy_
            if bstack1ll11l1l11l_opy_:
                options[bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᴾ")] = bstack1ll11l1l11l_opy_
                options[bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪᴿ")] = bstack1ll1l1l111l_opy_
                options[bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫᵀ")][bstack1l11_opy_ (u"࠭ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᵁ")] = bstack11ll1ll11l1_opy_
    return options
def bstack111ll1lll11_opy_(bstack11l111lll11_opy_, framework):
    bstack1l1lll11l_opy_ = bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"ࠢࡑࡎࡄ࡝࡜ࡘࡉࡈࡊࡗࡣࡕࡘࡏࡅࡗࡆࡘࡤࡓࡁࡑࠤᵂ"))
    if bstack11l111lll11_opy_ and len(bstack11l111lll11_opy_.split(bstack1l11_opy_ (u"ࠨࡥࡤࡴࡸࡃࠧᵃ"))) > 1:
        ws_url = bstack11l111lll11_opy_.split(bstack1l11_opy_ (u"ࠩࡦࡥࡵࡹ࠽ࠨᵄ"))[0]
        if bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠭ᵅ") in ws_url:
            from browserstack_sdk._version import __version__
            bstack111ll1ll11l_opy_ = json.loads(urllib.parse.unquote(bstack11l111lll11_opy_.split(bstack1l11_opy_ (u"ࠫࡨࡧࡰࡴ࠿ࠪᵆ"))[1]))
            bstack111ll1ll11l_opy_ = bstack111ll1ll11l_opy_ or {}
            bstack11llllll11_opy_ = os.environ[bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪᵇ")]
            bstack111ll1ll11l_opy_[bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧᵈ")] = str(framework) + str(__version__)
            bstack111ll1ll11l_opy_[bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᵉ")] = bstack1l1ll1l1ll1_opy_()
            bstack111ll1ll11l_opy_[bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡵࡧࡶࡸ࡭ࡻࡢࡃࡷ࡬ࡰࡩ࡛ࡵࡪࡦࠪᵊ")] = bstack11llllll11_opy_
            bstack111ll1ll11l_opy_[bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡸ࡭ࡱࡪࡐࡳࡱࡧࡹࡨࡺࡍࡢࡲࠪᵋ")] = bstack1l1lll11l_opy_
            bstack11l111lll11_opy_ = bstack11l111lll11_opy_.split(bstack1l11_opy_ (u"ࠪࡧࡦࡶࡳ࠾ࠩᵌ"))[0] + bstack1l11_opy_ (u"ࠫࡨࡧࡰࡴ࠿ࠪᵍ") + urllib.parse.quote(json.dumps(bstack111ll1ll11l_opy_))
    return bstack11l111lll11_opy_
def bstack1llll1l11l_opy_():
    global bstack1l1111ll1_opy_
    from playwright._impl._browser_type import BrowserType
    bstack1l1111ll1_opy_ = BrowserType.connect
    return bstack1l1111ll1_opy_
def bstack1l1llllll1_opy_(framework_name):
    global bstack1l1lll1l_opy_
    bstack1l1lll1l_opy_ = framework_name
    return framework_name
def bstack11l111l11l_opy_(self, *args, **kwargs):
    global bstack1l1111ll1_opy_
    try:
        global bstack1l1lll1l_opy_
        if bstack1l11_opy_ (u"ࠬࡽࡳࡆࡰࡧࡴࡴ࡯࡮ࡵࠩᵎ") in kwargs:
            kwargs[bstack1l11_opy_ (u"࠭ࡷࡴࡇࡱࡨࡵࡵࡩ࡯ࡶࠪᵏ")] = bstack111ll1lll11_opy_(
                kwargs.get(bstack1l11_opy_ (u"ࠧࡸࡵࡈࡲࡩࡶ࡯ࡪࡰࡷࠫᵐ"), None),
                bstack1l1lll1l_opy_
            )
    except Exception as e:
        logger.error(bstack1l11_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪࡨࡲࠥࡶࡲࡰࡥࡨࡷࡸ࡯࡮ࡨࠢࡖࡈࡐࠦࡣࡢࡲࡶ࠾ࠥࢁࡽࠣᵑ").format(str(e)))
    return bstack1l1111ll1_opy_(self, *args, **kwargs)
def bstack11l1111lll1_opy_(bstack11l11111ll1_opy_, proxies):
    proxy_settings = {}
    try:
        if not proxies:
            proxies = bstack111lll1l1_opy_(bstack11l11111ll1_opy_, bstack1l11_opy_ (u"ࠤࠥᵒ"))
        if proxies and proxies.get(bstack1l11_opy_ (u"ࠥ࡬ࡹࡺࡰࡴࠤᵓ")):
            parsed_url = urlparse(proxies.get(bstack1l11_opy_ (u"ࠦ࡭ࡺࡴࡱࡵࠥᵔ")))
            if parsed_url and parsed_url.hostname: proxy_settings[bstack1l11_opy_ (u"ࠬࡶࡲࡰࡺࡼࡌࡴࡹࡴࠨᵕ")] = str(parsed_url.hostname)
            if parsed_url and parsed_url.port: proxy_settings[bstack1l11_opy_ (u"࠭ࡰࡳࡱࡻࡽࡕࡵࡲࡵࠩᵖ")] = str(parsed_url.port)
            if parsed_url and parsed_url.username: proxy_settings[bstack1l11_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡛ࡳࡦࡴࠪᵗ")] = str(parsed_url.username)
            if parsed_url and parsed_url.password: proxy_settings[bstack1l11_opy_ (u"ࠨࡲࡵࡳࡽࡿࡐࡢࡵࡶࠫᵘ")] = str(parsed_url.password)
        return proxy_settings
    except:
        return proxy_settings
def bstack1l1ll1l1_opy_(bstack11l11111ll1_opy_):
    bstack111lll11111_opy_ = {
        bstack11l1ll1ll1l_opy_[bstack111lllll1ll_opy_]: bstack11l11111ll1_opy_[bstack111lllll1ll_opy_]
        for bstack111lllll1ll_opy_ in bstack11l11111ll1_opy_
        if bstack111lllll1ll_opy_ in bstack11l1ll1ll1l_opy_
    }
    bstack111lll11111_opy_[bstack1l11_opy_ (u"ࠤࡳࡶࡴࡾࡹࡔࡧࡷࡸ࡮ࡴࡧࡴࠤᵙ")] = bstack11l1111lll1_opy_(bstack11l11111ll1_opy_, bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"ࠥࡴࡷࡵࡸࡺࡕࡨࡸࡹ࡯࡮ࡨࡵࠥᵚ")))
    bstack11l11ll11ll_opy_ = [element.lower() for element in bstack11l1ll11lll_opy_]
    bstack111ll1ll1l1_opy_(bstack111lll11111_opy_, bstack11l11ll11ll_opy_)
    return bstack111lll11111_opy_
def bstack111ll1ll1l1_opy_(d, keys):
    for key in list(d.keys()):
        if key.lower() in keys:
            d[key] = bstack1l11_opy_ (u"ࠦ࠯࠰ࠪࠫࠤᵛ")
    for value in d.values():
        if isinstance(value, dict):
            bstack111ll1ll1l1_opy_(value, keys)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    bstack111ll1ll1l1_opy_(item, keys)
def bstack1l1l1l1lll1_opy_():
    bstack111lll1lll1_opy_ = [os.environ.get(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡏࡌࡆࡕࡢࡈࡎࡘࠢᵜ")), os.path.join(os.path.expanduser(bstack1l11_opy_ (u"ࠨࡾࠣᵝ")), bstack1l11_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧᵞ")), os.path.join(bstack1l11_opy_ (u"ࠨ࠱ࡷࡱࡵ࠭ᵟ"), bstack1l11_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩᵠ"))]
    for path in bstack111lll1lll1_opy_:
        if path is None:
            continue
        try:
            if os.path.exists(path):
                logger.debug(bstack1l11_opy_ (u"ࠥࡊ࡮ࡲࡥࠡࠩࠥᵡ") + str(path) + bstack1l11_opy_ (u"ࠦࠬࠦࡥࡹ࡫ࡶࡸࡸ࠴ࠢᵢ"))
                if not os.access(path, os.W_OK):
                    logger.debug(bstack1l11_opy_ (u"ࠧࡍࡩࡷ࡫ࡱ࡫ࠥࡶࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠣࡪࡴࡸࠠࠨࠤᵣ") + str(path) + bstack1l11_opy_ (u"ࠨࠧࠣᵤ"))
                    os.chmod(path, 0o777)
                else:
                    logger.debug(bstack1l11_opy_ (u"ࠢࡇ࡫࡯ࡩࠥ࠭ࠢᵥ") + str(path) + bstack1l11_opy_ (u"ࠣࠩࠣࡥࡱࡸࡥࡢࡦࡼࠤ࡭ࡧࡳࠡࡶ࡫ࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡱࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷ࠳ࠨᵦ"))
            else:
                logger.debug(bstack1l11_opy_ (u"ࠤࡆࡶࡪࡧࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࠪࠦᵧ") + str(path) + bstack1l11_opy_ (u"ࠥࠫࠥࡽࡩࡵࡪࠣࡻࡷ࡯ࡴࡦࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳ࠴ࠢᵨ"))
                os.makedirs(path, exist_ok=True)
                os.chmod(path, 0o777)
            logger.debug(bstack1l11_opy_ (u"ࠦࡔࡶࡥࡳࡣࡷ࡭ࡴࡴࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡪࡴࡸࠠࠨࠤᵩ") + str(path) + bstack1l11_opy_ (u"ࠧ࠭࠮ࠣᵪ"))
            return path
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡹࠦࡵࡱࠢࡩ࡭ࡱ࡫ࠠࠨࡽࡳࡥࡹ࡮ࡽࠨ࠼ࠣࠦᵫ") + str(e) + bstack1l11_opy_ (u"ࠢࠣᵬ"))
    logger.debug(bstack1l11_opy_ (u"ࠣࡃ࡯ࡰࠥࡶࡡࡵࡪࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠧᵭ"))
    return None
@measure(event_name=EVENTS.bstack11l1ll1l111_opy_, stage=STAGE.bstack1l11l1ll_opy_)
def bstack1ll1lllllll_opy_(binary_path, bstack1lll111l1ll_opy_, bs_config):
    logger.debug(bstack1l11_opy_ (u"ࠤࡆࡹࡷࡸࡥ࡯ࡶࠣࡇࡑࡏࠠࡑࡣࡷ࡬ࠥ࡬࡯ࡶࡰࡧ࠾ࠥࢁࡽࠣᵮ").format(binary_path))
    bstack111llll11ll_opy_ = bstack1l11_opy_ (u"ࠪࠫᵯ")
    bstack111lllll11l_opy_ = {
        bstack1l11_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩᵰ"): __version__,
        bstack1l11_opy_ (u"ࠧࡵࡳࠣᵱ"): platform.system(),
        bstack1l11_opy_ (u"ࠨ࡯ࡴࡡࡤࡶࡨ࡮ࠢᵲ"): platform.machine(),
        bstack1l11_opy_ (u"ࠢࡤ࡮࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧᵳ"): bstack1l11_opy_ (u"ࠨ࠲ࠪᵴ"),
        bstack1l11_opy_ (u"ࠤࡶࡨࡰࡥ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠣᵵ"): bstack1l11_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪᵶ")
    }
    bstack11l11lll111_opy_(bstack111lllll11l_opy_)
    try:
        if binary_path:
            bstack111lllll11l_opy_[bstack1l11_opy_ (u"ࠫࡨࡲࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࠩᵷ")] = subprocess.check_output([binary_path, bstack1l11_opy_ (u"ࠧࡼࡥࡳࡵ࡬ࡳࡳࠨᵸ")]).strip().decode(bstack1l11_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬᵹ"))
        response = requests.request(
            bstack1l11_opy_ (u"ࠧࡈࡇࡗࠫᵺ"),
            url=bstack1lll1l1l_opy_(bstack11l1l1l1l1l_opy_),
            headers=None,
            auth=(bs_config[bstack1l11_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪᵻ")], bs_config[bstack1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬᵼ")]),
            json=None,
            params=bstack111lllll11l_opy_
        )
        data = response.json()
        if response.status_code == 200 and bstack1l11_opy_ (u"ࠪࡹࡷࡲࠧᵽ") in data.keys() and bstack1l11_opy_ (u"ࠫࡺࡶࡤࡢࡶࡨࡨࡤࡩ࡬ࡪࡡࡹࡩࡷࡹࡩࡰࡰࠪᵾ") in data.keys():
            logger.debug(bstack1l11_opy_ (u"ࠧࡔࡥࡦࡦࠣࡸࡴࠦࡵࡱࡦࡤࡸࡪࠦࡢࡪࡰࡤࡶࡾ࠲ࠠࡤࡷࡵࡶࡪࡴࡴࠡࡤ࡬ࡲࡦࡸࡹࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠣࡿࢂࠨᵿ").format(bstack111lllll11l_opy_[bstack1l11_opy_ (u"࠭ࡣ࡭࡫ࡢࡺࡪࡸࡳࡪࡱࡱࠫᶀ")]))
            if bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡂࡊࡐࡄࡖ࡞ࡥࡕࡓࡎࠪᶁ") in os.environ:
                logger.debug(bstack1l11_opy_ (u"ࠣࡕ࡮࡭ࡵࡶࡩ࡯ࡩࠣࡦ࡮ࡴࡡࡳࡻࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡧࡳࠡࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡋࡑࡅࡗ࡟࡟ࡖࡔࡏࠤ࡮ࡹࠠࡴࡧࡷࠦᶂ"))
                data[bstack1l11_opy_ (u"ࠩࡸࡶࡱ࠭ᶃ")] = os.environ[bstack1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅࡍࡓࡇࡒ࡚ࡡࡘࡖࡑ࠭ᶄ")]
            bstack111ll1l11ll_opy_ = bstack111llllll1l_opy_(data[bstack1l11_opy_ (u"ࠫࡺࡸ࡬ࠨᶅ")], bstack1lll111l1ll_opy_)
            bstack111llll11ll_opy_ = os.path.join(bstack1lll111l1ll_opy_, bstack111ll1l11ll_opy_)
            os.chmod(bstack111llll11ll_opy_, 0o777) # bstack111ll1l1111_opy_ permission
            return bstack111llll11ll_opy_
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡰࡨࡻ࡙ࠥࡄࡌࠢࡾࢁࠧᶆ").format(e))
    return binary_path
def bstack11l11lll111_opy_(bstack111lllll11l_opy_):
    try:
        if bstack1l11_opy_ (u"࠭࡬ࡪࡰࡸࡼࠬᶇ") not in bstack111lllll11l_opy_[bstack1l11_opy_ (u"ࠧࡰࡵࠪᶈ")].lower():
            return
        if os.path.exists(bstack1l11_opy_ (u"ࠣ࠱ࡨࡸࡨ࠵࡯ࡴ࠯ࡵࡩࡱ࡫ࡡࡴࡧࠥᶉ")):
            with open(bstack1l11_opy_ (u"ࠤ࠲ࡩࡹࡩ࠯ࡰࡵ࠰ࡶࡪࡲࡥࡢࡵࡨࠦᶊ"), bstack1l11_opy_ (u"ࠥࡶࠧᶋ")) as f:
                bstack11l111ll1ll_opy_ = {}
                for line in f:
                    if bstack1l11_opy_ (u"ࠦࡂࠨᶌ") in line:
                        key, value = line.rstrip().split(bstack1l11_opy_ (u"ࠧࡃࠢᶍ"), 1)
                        bstack11l111ll1ll_opy_[key] = value.strip(bstack1l11_opy_ (u"࠭ࠢ࡝ࠩࠪᶎ"))
                bstack111lllll11l_opy_[bstack1l11_opy_ (u"ࠧࡥ࡫ࡶࡸࡷࡵࠧᶏ")] = bstack11l111ll1ll_opy_.get(bstack1l11_opy_ (u"ࠣࡋࡇࠦᶐ"), bstack1l11_opy_ (u"ࠤࠥᶑ"))
        elif os.path.exists(bstack1l11_opy_ (u"ࠥ࠳ࡪࡺࡣ࠰ࡣ࡯ࡴ࡮ࡴࡥ࠮ࡴࡨࡰࡪࡧࡳࡦࠤᶒ")):
            bstack111lllll11l_opy_[bstack1l11_opy_ (u"ࠫࡩ࡯ࡳࡵࡴࡲࠫᶓ")] = bstack1l11_opy_ (u"ࠬࡧ࡬ࡱ࡫ࡱࡩࠬᶔ")
    except Exception as e:
        logger.debug(bstack1l11_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡪࡩࡹࠦࡤࡪࡵࡷࡶࡴࠦ࡯ࡧࠢ࡯࡭ࡳࡻࡸࠣᶕ") + e)
@measure(event_name=EVENTS.bstack11l1ll1l1ll_opy_, stage=STAGE.bstack1l11l1ll_opy_)
def bstack111llllll1l_opy_(bstack11l11l11lll_opy_, bstack111lll111l1_opy_):
    logger.debug(bstack1l11_opy_ (u"ࠢࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࡙ࠥࡄࡌࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡶࡴࡳ࠺ࠡࠤᶖ") + str(bstack11l11l11lll_opy_) + bstack1l11_opy_ (u"ࠣࠤᶗ"))
    zip_path = os.path.join(bstack111lll111l1_opy_, bstack1l11_opy_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࡥࡦࡪ࡮ࡨ࠲ࡿ࡯ࡰࠣᶘ"))
    bstack111ll1l11ll_opy_ = bstack1l11_opy_ (u"ࠪࠫᶙ")
    with requests.get(bstack11l11l11lll_opy_, stream=True) as response:
        response.raise_for_status()
        with open(zip_path, bstack1l11_opy_ (u"ࠦࡼࡨࠢᶚ")) as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        logger.debug(bstack1l11_opy_ (u"ࠧࡌࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠴ࠢᶛ"))
    with zipfile.ZipFile(zip_path, bstack1l11_opy_ (u"࠭ࡲࠨᶜ")) as zip_ref:
        bstack11l111l1l11_opy_ = zip_ref.namelist()
        if len(bstack11l111l1l11_opy_) > 0:
            bstack111ll1l11ll_opy_ = bstack11l111l1l11_opy_[0] # bstack111lll111ll_opy_ bstack11l1ll111ll_opy_ will be bstack11111ll1l1_opy_ 1 file i.e. the binary in the zip
        zip_ref.extractall(bstack111lll111l1_opy_)
        logger.debug(bstack1l11_opy_ (u"ࠢࡇ࡫࡯ࡩࡸࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥ࡫ࡸࡵࡴࡤࡧࡹ࡫ࡤࠡࡶࡲࠤࠬࠨᶝ") + str(bstack111lll111l1_opy_) + bstack1l11_opy_ (u"ࠣࠩࠥᶞ"))
    os.remove(zip_path)
    return bstack111ll1l11ll_opy_
def get_cli_dir():
    bstack111llll1l1l_opy_ = bstack1l1l1l1lll1_opy_()
    if bstack111llll1l1l_opy_:
        bstack1lll111l1ll_opy_ = os.path.join(bstack111llll1l1l_opy_, bstack1l11_opy_ (u"ࠤࡦࡰ࡮ࠨᶟ"))
        if not os.path.exists(bstack1lll111l1ll_opy_):
            os.makedirs(bstack1lll111l1ll_opy_, mode=0o777, exist_ok=True)
        return bstack1lll111l1ll_opy_
    else:
        raise FileNotFoundError(bstack1l11_opy_ (u"ࠥࡒࡴࠦࡷࡳ࡫ࡷࡥࡧࡲࡥࠡࡦ࡬ࡶࡪࡩࡴࡰࡴࡼࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡕࡇࡏࠥࡨࡩ࡯ࡣࡵࡽ࠳ࠨᶠ"))
def bstack1lll11l1lll_opy_(bstack1lll111l1ll_opy_):
    bstack1l11_opy_ (u"ࠦࠧࠨࡇࡦࡶࠣࡸ࡭࡫ࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯࡙ࠥࡄࡌࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡲࠥࡧࠠࡸࡴ࡬ࡸࡦࡨ࡬ࡦࠢࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠳ࠨࠢࠣᶡ")
    bstack11l11l1l1ll_opy_ = [
        os.path.join(bstack1lll111l1ll_opy_, f)
        for f in os.listdir(bstack1lll111l1ll_opy_)
        if os.path.isfile(os.path.join(bstack1lll111l1ll_opy_, f)) and f.startswith(bstack1l11_opy_ (u"ࠧࡨࡩ࡯ࡣࡵࡽ࠲ࠨᶢ"))
    ]
    if len(bstack11l11l1l1ll_opy_) > 0:
        return max(bstack11l11l1l1ll_opy_, key=os.path.getmtime) # get bstack111lllll1l1_opy_ binary
    return bstack1l11_opy_ (u"ࠨࠢᶣ")
def bstack11ll11l11ll_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1ll1111ll1l_opy_(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = bstack1ll1111ll1l_opy_(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack11lll11ll1_opy_(data, keys, default=None):
    bstack1l11_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡔࡣࡩࡩࡱࡿࠠࡨࡧࡷࠤࡦࠦ࡮ࡦࡵࡷࡩࡩࠦࡶࡢ࡮ࡸࡩࠥ࡬ࡲࡰ࡯ࠣࡥࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺࠢࡲࡶࠥࡲࡩࡴࡶ࠱ࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡦࡤࡸࡦࡀࠠࡕࡪࡨࠤࡩ࡯ࡣࡵ࡫ࡲࡲࡦࡸࡹࠡࡱࡵࠤࡱ࡯ࡳࡵࠢࡷࡳࠥࡺࡲࡢࡸࡨࡶࡸ࡫࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡱࡥࡺࡵ࠽ࠤࡆࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠ࡬ࡧࡼࡷ࠴࡯࡮ࡥ࡫ࡦࡩࡸࠦࡲࡦࡲࡵࡩࡸ࡫࡮ࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡳࡥࡹ࡮࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡪࡥࡧࡣࡸࡰࡹࡀࠠࡗࡣ࡯ࡹࡪࠦࡴࡰࠢࡵࡩࡹࡻࡲ࡯ࠢ࡬ࡪࠥࡺࡨࡦࠢࡳࡥࡹ࡮ࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡨࡼ࡮ࡹࡴ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡࡖ࡫ࡩࠥࡼࡡ࡭ࡷࡨࠤࡦࡺࠠࡵࡪࡨࠤࡳ࡫ࡳࡵࡧࡧࠤࡵࡧࡴࡩ࠮ࠣࡳࡷࠦࡤࡦࡨࡤࡹࡱࡺࠠࡪࡨࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩ࠴ࠊࠡࠢࠣࠤࠧࠨࠢᶤ")
    if not data:
        return default
    current = data
    try:
        for key in keys:
            if isinstance(current, dict):
                current = current[key]
            elif isinstance(current, list) and isinstance(key, int):
                current = current[key]
            else:
                return default
        return current
    except (KeyError, IndexError, TypeError):
        return default