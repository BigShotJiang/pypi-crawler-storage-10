# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from filelock import FileLock
import json
import os
import time
import uuid
import logging
from typing import Dict, List, Optional
from bstack_utils.bstack1l111llll_opy_ import get_logger
logger = get_logger(__name__)
bstack1lllllll1lll_opy_: Dict[str, float] = {}
bstack1lllllllllll_opy_: List = []
bstack1lllllllll1l_opy_ = 5
bstack1l11ll11ll_opy_ = os.path.join(os.getcwd(), bstack1l11_opy_ (u"ࠧ࡭ࡱࡪࠫό"), bstack1l11_opy_ (u"ࠨ࡭ࡨࡽ࠲ࡳࡥࡵࡴ࡬ࡧࡸ࠴ࡪࡴࡱࡱࠫὺ"))
logging.getLogger(bstack1l11_opy_ (u"ࠩࡩ࡭ࡱ࡫࡬ࡰࡥ࡮ࠫύ")).setLevel(logging.WARNING)
lock = FileLock(bstack1l11ll11ll_opy_+bstack1l11_opy_ (u"ࠥ࠲ࡱࡵࡣ࡬ࠤὼ"))
class bstack1llllllll1ll_opy_:
    duration: float
    name: str
    startTime: float
    worker: int
    status: bool
    failure: str
    details: Optional[str]
    entryType: str
    platform: Optional[int]
    command: Optional[str]
    hookType: Optional[str]
    cli: Optional[bool]
    def __init__(self, duration: float, name: str, start_time: float, bstack1llllllllll1_opy_: int, status: bool, failure: str, details: Optional[str] = None, platform: Optional[int] = None, command: Optional[str] = None, test_name: Optional[str] = None, hook_type: Optional[str] = None, cli: Optional[bool] = False) -> None:
        self.duration = duration
        self.name = name
        self.startTime = start_time
        self.worker = bstack1llllllllll1_opy_
        self.status = status
        self.failure = failure
        self.details = details
        self.entryType = bstack1l11_opy_ (u"ࠦࡲ࡫ࡡࡴࡷࡵࡩࠧώ")
        self.platform = platform
        self.command = command
        self.testName = test_name
        self.hookType = hook_type
        self.cli = cli
class bstack1ll1l1l11l1_opy_:
    global bstack1lllllll1lll_opy_
    @staticmethod
    def bstack1ll111l111l_opy_(key: str):
        bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack11ll1ll1111_opy_(key)
        bstack1ll1l1l11l1_opy_.mark(bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧ὾"))
        return bstack1ll11ll11l1_opy_
    @staticmethod
    def mark(key: str) -> None:
        try:
            bstack1lllllll1lll_opy_[key] = time.time_ns() / 1000000
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠨࡅࡳࡴࡲࡶ࠿ࠦࡻࡾࠤ὿").format(e))
    @staticmethod
    def end(label: str, start: str, end: str, status: bool, failure: Optional[str] = None, hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            bstack1ll1l1l11l1_opy_.mark(end)
            bstack1ll1l1l11l1_opy_.measure(label, start, end, status, failure, hook_type, details, command, test_name)
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡩ࡯ࠢ࡮ࡩࡾࠦ࡭ࡦࡶࡵ࡭ࡨࡹ࠺ࠡࡽࢀࠦᾀ").format(e))
    @staticmethod
    def measure(label: str, start: str, end: str, status: bool, failure: Optional[str], hook_type: Optional[str] = None, details: Optional[str] = None, command: Optional[str] = None, test_name: Optional[str] = None) -> None:
        try:
            if start not in bstack1lllllll1lll_opy_ or end not in bstack1lllllll1lll_opy_:
                logger.debug(bstack1l11_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡪࡰࠣࡷࡹࡧࡲࡵࠢ࡮ࡩࡾࠦࡷࡪࡶ࡫ࠤࡻࡧ࡬ࡶࡧࠣࡿࢂࠦ࡯ࡳࠢࡨࡲࡩࠦ࡫ࡦࡻࠣࡻ࡮ࡺࡨࠡࡸࡤࡰࡺ࡫ࠠࡼࡿࠥᾁ").format(start,end))
                return
            duration: float = bstack1lllllll1lll_opy_[end] - bstack1lllllll1lll_opy_[start]
            bstack1lllllllll11_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡄࡌࡒࡆࡘ࡙ࡠࡋࡖࡣࡗ࡛ࡎࡏࡋࡑࡋࠧᾂ"), bstack1l11_opy_ (u"ࠥࡪࡦࡲࡳࡦࠤᾃ")).lower() == bstack1l11_opy_ (u"ࠦࡹࡸࡵࡦࠤᾄ")
            bstack1lllllll1ll1_opy_: bstack1llllllll1ll_opy_ = bstack1llllllll1ll_opy_(duration, label, bstack1lllllll1lll_opy_[start], os.getpid(), status, failure, details, os.environ.get(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡒࡁࡕࡈࡒࡖࡒࡥࡉࡏࡆࡈ࡜ࠧᾅ"), 0), command, test_name, hook_type, bstack1lllllllll11_opy_)
            del bstack1lllllll1lll_opy_[start]
            del bstack1lllllll1lll_opy_[end]
            bstack1ll1l1l11l1_opy_.bstack1llllllll1l1_opy_(bstack1lllllll1ll1_opy_)
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡲ࡫ࡡࡴࡷࡵ࡭ࡳ࡭ࠠ࡬ࡧࡼࠤࡲ࡫ࡴࡳ࡫ࡦࡷ࠿ࠦࡻࡾࠤᾆ").format(e))
    @staticmethod
    def bstack1llllllll1l1_opy_(bstack1lllllll1ll1_opy_):
        os.makedirs(os.path.dirname(bstack1l11ll11ll_opy_)) if not os.path.exists(os.path.dirname(bstack1l11ll11ll_opy_)) else None
        bstack1ll1l1l11l1_opy_.bstack1llllllll111_opy_()
        try:
            with lock:
                with open(bstack1l11ll11ll_opy_, bstack1l11_opy_ (u"ࠢࡳ࠭ࠥᾇ"), encoding=bstack1l11_opy_ (u"ࠣࡷࡷࡪ࠲࠾ࠢᾈ")) as file:
                    try:
                        data = json.load(file)
                    except json.JSONDecodeError:
                        data = []
                    data.append(bstack1lllllll1ll1_opy_.__dict__)
                    file.seek(0)
                    file.truncate()
                    json.dump(data, file, indent=4)
        except FileNotFoundError as bstack1llllllll11l_opy_:
            logger.debug(bstack1l11_opy_ (u"ࠤࡉ࡭ࡱ࡫ࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠣࡿࢂࠨᾉ").format(bstack1llllllll11l_opy_))
            with lock:
                with open(bstack1l11ll11ll_opy_, bstack1l11_opy_ (u"ࠥࡻࠧᾊ"), encoding=bstack1l11_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥᾋ")) as file:
                    data = [bstack1lllllll1ll1_opy_.__dict__]
                    json.dump(data, file, indent=4)
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡹ࡫࡭ࡱ࡫ࠠ࡬ࡧࡼࠤࡲ࡫ࡴࡳ࡫ࡦࡷࠥࡧࡰࡱࡧࡱࡨࠥࢁࡽࠣᾌ").format(str(e)))
        finally:
            if os.path.exists(bstack1l11ll11ll_opy_+bstack1l11_opy_ (u"ࠨ࠮࡭ࡱࡦ࡯ࠧᾍ")):
                os.remove(bstack1l11ll11ll_opy_+bstack1l11_opy_ (u"ࠢ࠯࡮ࡲࡧࡰࠨᾎ"))
    @staticmethod
    def bstack1llllllll111_opy_():
        attempt = 0
        while (attempt < bstack1lllllllll1l_opy_):
            attempt += 1
            if os.path.exists(bstack1l11ll11ll_opy_+bstack1l11_opy_ (u"ࠣ࠰࡯ࡳࡨࡱࠢᾏ")):
                time.sleep(0.5)
            else:
                break
    @staticmethod
    def bstack11ll1ll1111_opy_(label: str) -> str:
        try:
            return bstack1l11_opy_ (u"ࠤࡾࢁ࠿ࢁࡽࠣᾐ").format(label,str(uuid.uuid4().hex)[:6])
        except Exception as e:
            logger.debug(bstack1l11_opy_ (u"ࠥࡉࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨᾑ").format(e))