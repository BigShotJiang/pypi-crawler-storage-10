# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import sys
import logging
import tarfile
import io
import os
import time
import requests
import re
from requests_toolbelt.multipart.encoder import MultipartEncoder
from bstack_utils.constants import bstack11l1lll1l11_opy_, bstack11l1l1lll11_opy_, bstack11l1ll11lll_opy_
import tempfile
import json
bstack111l11lllll_opy_ = os.getenv(bstack1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡎࡒࡋࡤࡌࡉࡍࡇ᷐ࠥ"), None) or os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡧࡩࡧࡻࡧ࠯࡮ࡲ࡫ࠧ᷑"))
bstack111l1l111ll_opy_ = os.path.join(bstack1l11_opy_ (u"ࠦࡱࡵࡧࠣ᷒"), bstack1l11_opy_ (u"ࠬࡹࡤ࡬࠯ࡦࡰ࡮࠳ࡤࡦࡤࡸ࡫࠳ࡲ࡯ࡨࠩᷓ"))
logging.Formatter.converter = time.gmtime
def get_logger(name=__name__, level=None):
  logger = logging.getLogger(name)
  if level:
    logging.basicConfig(
      level=level,
      format=bstack1l11_opy_ (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤࡠࠫࠨ࡯ࡣࡰࡩ࠮ࡹ࡝࡜ࠧࠫࡰࡪࡼࡥ࡭ࡰࡤࡱࡪ࠯ࡳ࡞ࠢ࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩᷔ"),
      datefmt=bstack1l11_opy_ (u"࡛ࠧࠦ࠰ࠩࡲ࠳ࠥࡥࡖࠨࡌ࠿ࠫࡍ࠻ࠧࡖ࡞ࠬᷕ"),
      stream=sys.stdout
    )
  return logger
def bstack1lll11l1ll1_opy_():
  bstack111l1l111l1_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡋࡑࡅࡗ࡟࡟ࡅࡇࡅ࡙ࡌࠨᷖ"), bstack1l11_opy_ (u"ࠤࡩࡥࡱࡹࡥࠣᷗ"))
  return logging.DEBUG if bstack111l1l111l1_opy_.lower() == bstack1l11_opy_ (u"ࠥࡸࡷࡻࡥࠣᷘ") else logging.INFO
def bstack1l1lll11l11_opy_():
  global bstack111l11lllll_opy_
  if os.path.exists(bstack111l11lllll_opy_):
    os.remove(bstack111l11lllll_opy_)
  if os.path.exists(bstack111l1l111ll_opy_):
    os.remove(bstack111l1l111ll_opy_)
def bstack11ll1111_opy_():
  for handler in logging.getLogger().handlers:
    logging.getLogger().removeHandler(handler)
def configure_logger(config, log_level):
  bstack111l11lll1l_opy_ = log_level
  if bstack1l11_opy_ (u"ࠫࡱࡵࡧࡍࡧࡹࡩࡱ࠭ᷙ") in config and config[bstack1l11_opy_ (u"ࠬࡲ࡯ࡨࡎࡨࡺࡪࡲࠧᷚ")] in bstack11l1l1lll11_opy_:
    bstack111l11lll1l_opy_ = bstack11l1l1lll11_opy_[config[bstack1l11_opy_ (u"࠭࡬ࡰࡩࡏࡩࡻ࡫࡬ࠨᷛ")]]
  if config.get(bstack1l11_opy_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡂࡷࡷࡳࡈࡧࡰࡵࡷࡵࡩࡑࡵࡧࡴࠩᷜ"), False):
    logging.getLogger().setLevel(bstack111l11lll1l_opy_)
    return bstack111l11lll1l_opy_
  global bstack111l11lllll_opy_
  bstack11ll1111_opy_()
  bstack111l1l1l11l_opy_ = logging.Formatter(
    fmt=bstack1l11_opy_ (u"ࠨࠧࠫࡥࡸࡩࡴࡪ࡯ࡨ࠭ࡸ࡛ࠦࠦࠪࡱࡥࡲ࡫ࠩࡴ࡟࡞ࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࡠࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫᷝ"),
    datefmt=bstack1l11_opy_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࡘࠪࡎ࠺ࠦࡏ࠽ࠩࡘࡠࠧᷞ"),
  )
  bstack111l11llll1_opy_ = logging.StreamHandler(sys.stdout)
  file_handler = logging.FileHandler(bstack111l11lllll_opy_)
  file_handler.setFormatter(bstack111l1l1l11l_opy_)
  bstack111l11llll1_opy_.setFormatter(bstack111l1l1l11l_opy_)
  file_handler.setLevel(logging.DEBUG)
  bstack111l11llll1_opy_.setLevel(log_level)
  file_handler.addFilter(lambda r: r.name != bstack1l11_opy_ (u"ࠪࡷࡪࡲࡥ࡯࡫ࡸࡱ࠳ࡽࡥࡣࡦࡵ࡭ࡻ࡫ࡲ࠯ࡴࡨࡱࡴࡺࡥ࠯ࡴࡨࡱࡴࡺࡥࡠࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠬᷟ"))
  logging.getLogger().setLevel(logging.DEBUG)
  bstack111l11llll1_opy_.setLevel(bstack111l11lll1l_opy_)
  logging.getLogger().addHandler(bstack111l11llll1_opy_)
  logging.getLogger().addHandler(file_handler)
  return bstack111l11lll1l_opy_
def bstack111l1l1ll11_opy_(config):
  try:
    bstack111l1l1111l_opy_ = set(bstack11l1ll11lll_opy_)
    bstack111l1l11ll1_opy_ = bstack1l11_opy_ (u"ࠫࠬᷠ")
    with open(bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡾࡳ࡬ࠨᷡ")) as bstack111l1ll1l11_opy_:
      bstack111l1ll1111_opy_ = bstack111l1ll1l11_opy_.read()
      bstack111l1l11ll1_opy_ = re.sub(bstack1l11_opy_ (u"ࡸࠧ࡟ࠪ࡟ࡷ࠰࠯࠿ࠤ࠰࠭ࠨࡡࡴࠧᷢ"), bstack1l11_opy_ (u"ࠧࠨᷣ"), bstack111l1ll1111_opy_, flags=re.M)
      bstack111l1l11ll1_opy_ = re.sub(
        bstack1l11_opy_ (u"ࡳࠩࡡࠬࡡࡹࠫࠪࡁࠫࠫᷤ") + bstack1l11_opy_ (u"ࠩࡿࠫᷥ").join(bstack111l1l1111l_opy_) + bstack1l11_opy_ (u"ࠪ࠭࠳࠰ࠤࠨᷦ"),
        bstack1l11_opy_ (u"ࡶࠬࡢ࠲࠻ࠢ࡞ࡖࡊࡊࡁࡄࡖࡈࡈࡢ࠭ᷧ"),
        bstack111l1l11ll1_opy_, flags=re.M | re.I
      )
    def bstack111l1l1l1l1_opy_(dic):
      bstack111l1l11lll_opy_ = {}
      for key, value in dic.items():
        if key in bstack111l1l1111l_opy_:
          bstack111l1l11lll_opy_[key] = bstack1l11_opy_ (u"ࠬࡡࡒࡆࡆࡄࡇ࡙ࡋࡄ࡞ࠩᷨ")
        else:
          if isinstance(value, dict):
            bstack111l1l11lll_opy_[key] = bstack111l1l1l1l1_opy_(value)
          else:
            bstack111l1l11lll_opy_[key] = value
      return bstack111l1l11lll_opy_
    bstack111l1l11lll_opy_ = bstack111l1l1l1l1_opy_(config)
    return {
      bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿ࡭࡭ࠩᷩ"): bstack111l1l11ll1_opy_,
      bstack1l11_opy_ (u"ࠧࡧ࡫ࡱࡥࡱࡩ࡯࡯ࡨ࡬࡫࠳ࡰࡳࡰࡰࠪᷪ"): json.dumps(bstack111l1l11lll_opy_)
    }
  except Exception as e:
    return {}
def bstack111l1l1ll1l_opy_(inipath, rootpath):
  log_dir = os.path.join(os.getcwd(), bstack1l11_opy_ (u"ࠨ࡮ࡲ࡫ࠬᷫ"))
  if not os.path.exists(log_dir):
    os.makedirs(log_dir)
  bstack111l1l11111_opy_ = os.path.join(log_dir, bstack1l11_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡦࡳࡳ࡬ࡩࡨࡵࠪᷬ"))
  if not os.path.exists(bstack111l1l11111_opy_):
    bstack111l1ll11l1_opy_ = {
      bstack1l11_opy_ (u"ࠥ࡭ࡳ࡯ࡰࡢࡶ࡫ࠦᷭ"): str(inipath),
      bstack1l11_opy_ (u"ࠦࡷࡵ࡯ࡵࡲࡤࡸ࡭ࠨᷮ"): str(rootpath)
    }
    with open(os.path.join(log_dir, bstack1l11_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡩ࡯࡯ࡨ࡬࡫ࡸ࠴ࡪࡴࡱࡱࠫᷯ")), bstack1l11_opy_ (u"࠭ࡷࠨᷰ")) as bstack111l1l11l1l_opy_:
      bstack111l1l11l1l_opy_.write(json.dumps(bstack111l1ll11l1_opy_))
def bstack111l1ll11ll_opy_():
  try:
    bstack111l1l11111_opy_ = os.path.join(os.getcwd(), bstack1l11_opy_ (u"ࠧ࡭ࡱࡪࠫᷱ"), bstack1l11_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡥࡲࡲ࡫࡯ࡧࡴ࠰࡭ࡷࡴࡴࠧᷲ"))
    if os.path.exists(bstack111l1l11111_opy_):
      with open(bstack111l1l11111_opy_, bstack1l11_opy_ (u"ࠩࡵࠫᷳ")) as bstack111l1l11l1l_opy_:
        bstack111l1l11l11_opy_ = json.load(bstack111l1l11l1l_opy_)
      return bstack111l1l11l11_opy_.get(bstack1l11_opy_ (u"ࠪ࡭ࡳ࡯ࡰࡢࡶ࡫ࠫᷴ"), bstack1l11_opy_ (u"ࠫࠬ᷵")), bstack111l1l11l11_opy_.get(bstack1l11_opy_ (u"ࠬࡸ࡯ࡰࡶࡳࡥࡹ࡮ࠧ᷶"), bstack1l11_opy_ (u"᷷࠭ࠧ"))
  except:
    pass
  return None, None
def bstack111l1ll111l_opy_():
  try:
    bstack111l1l11111_opy_ = os.path.join(os.getcwd(), bstack1l11_opy_ (u"ࠧ࡭ࡱࡪ᷸ࠫ"), bstack1l11_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡥࡲࡲ࡫࡯ࡧࡴ࠰࡭ࡷࡴࡴ᷹ࠧ"))
    if os.path.exists(bstack111l1l11111_opy_):
      os.remove(bstack111l1l11111_opy_)
  except:
    pass
def bstack111l11l1l_opy_(config):
  try:
    from bstack_utils.helper import bstack11l1l111ll_opy_, bstack11lll11ll1_opy_
    from browserstack_sdk.sdk_cli.cli import cli
    global bstack111l11lllll_opy_
    if config.get(bstack1l11_opy_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡄࡹࡹࡵࡃࡢࡲࡷࡹࡷ࡫ࡌࡰࡩࡶ᷺ࠫ"), False):
      return
    uuid = os.getenv(bstack1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨ᷻")) if os.getenv(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩ᷼")) else bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"ࠧࡹࡤ࡬ࡔࡸࡲࡎࡪ᷽ࠢ"))
    if not uuid or uuid == bstack1l11_opy_ (u"࠭࡮ࡶ࡮࡯ࠫ᷾"):
      return
    bstack111l1l1l1ll_opy_ = [bstack1l11_opy_ (u"ࠧࡳࡧࡴࡹ࡮ࡸࡥ࡮ࡧࡱࡸࡸ࠴ࡴࡹࡶ᷿ࠪ"), bstack1l11_opy_ (u"ࠨࡒ࡬ࡴ࡫࡯࡬ࡦࠩḀ"), bstack1l11_opy_ (u"ࠩࡳࡽࡵࡸ࡯࡫ࡧࡦࡸ࠳ࡺ࡯࡮࡮ࠪḁ"), bstack111l11lllll_opy_, bstack111l1l111ll_opy_]
    bstack111l1l1lll1_opy_, root_path = bstack111l1ll11ll_opy_()
    if bstack111l1l1lll1_opy_ != None:
      bstack111l1l1l1ll_opy_.append(bstack111l1l1lll1_opy_)
    if root_path != None:
      bstack111l1l1l1ll_opy_.append(os.path.join(root_path, bstack1l11_opy_ (u"ࠪࡧࡴࡴࡦࡵࡧࡶࡸ࠳ࡶࡹࠨḂ")))
    bstack11ll1111_opy_()
    logging.shutdown()
    output_file = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠱ࡱࡵࡧࡴ࠯ࠪḃ") + uuid + bstack1l11_opy_ (u"ࠬ࠴ࡴࡢࡴ࠱࡫ࡿ࠭Ḅ"))
    with tarfile.open(output_file, bstack1l11_opy_ (u"ࠨࡷ࠻ࡩࡽࠦḅ")) as archive:
      for file in filter(lambda f: os.path.exists(f), bstack111l1l1l1ll_opy_):
        try:
          archive.add(file,  arcname=os.path.basename(file))
        except:
          pass
      for name, data in bstack111l1l1ll11_opy_(config).items():
        tarinfo = tarfile.TarInfo(name)
        bstack111l1l1llll_opy_ = data.encode()
        tarinfo.size = len(bstack111l1l1llll_opy_)
        archive.addfile(tarinfo, io.BytesIO(bstack111l1l1llll_opy_))
    bstack1llll1ll11_opy_ = MultipartEncoder(
      fields= {
        bstack1l11_opy_ (u"ࠧࡥࡣࡷࡥࠬḆ"): (os.path.basename(output_file), open(os.path.abspath(output_file), bstack1l11_opy_ (u"ࠨࡴࡥࠫḇ")), bstack1l11_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡪࡾ࡮ࡶࠧḈ")),
        bstack1l11_opy_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡅࡹ࡮ࡲࡤࡖࡷ࡬ࡨࠬḉ"): uuid
      }
    )
    bstack111l1l1l111_opy_ = bstack11lll11ll1_opy_(cli.config, [bstack1l11_opy_ (u"ࠦࡦࡶࡩࡴࠤḊ"), bstack1l11_opy_ (u"ࠧࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠧḋ"), bstack1l11_opy_ (u"ࠨࡵࡱ࡮ࡲࡥࡩࠨḌ")], bstack11l1lll1l11_opy_)
    response = requests.post(
      bstack1l11_opy_ (u"ࠢࡼࡿ࠲ࡧࡱ࡯ࡥ࡯ࡶ࠰ࡰࡴ࡭ࡳ࠰ࡷࡳࡰࡴࡧࡤࠣḍ").format(bstack111l1l1l111_opy_),
      data=bstack1llll1ll11_opy_,
      headers={bstack1l11_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧḎ"): bstack1llll1ll11_opy_.content_type},
      auth=(config[bstack1l11_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫḏ")], config[bstack1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭Ḑ")])
    )
    os.remove(output_file)
    if response.status_code != 200:
      get_logger().debug(bstack1l11_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣࡹࡵࡲ࡯ࡢࡦࠣࡰࡴ࡭ࡳ࠻ࠢࠪḑ") + response.status_code)
  except Exception as e:
    get_logger().debug(bstack1l11_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡸ࡫࡮ࡥ࡫ࡱ࡫ࠥࡲ࡯ࡨࡵ࠽ࠫḒ") + str(e))
  finally:
    try:
      bstack1l1lll11l11_opy_()
      bstack111l1ll111l_opy_()
    except:
      pass