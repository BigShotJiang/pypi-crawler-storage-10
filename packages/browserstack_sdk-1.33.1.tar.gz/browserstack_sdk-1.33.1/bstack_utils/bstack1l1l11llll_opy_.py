# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
from bstack_utils.constants import *
from browserstack_sdk.sdk_cli.cli import cli
from bstack_utils.bstack111l111l1l1_opy_ import bstack111l11l1lll_opy_
from bstack_utils.bstack1ll1l111_opy_ import bstack11l11ll11l_opy_
from bstack_utils.helper import bstack1lll1lll1_opy_
import json
class bstack1lll1111_opy_:
    _1ll1ll11l1l_opy_ = None
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.bstack111l111l11l_opy_ = bstack111l11l1lll_opy_(self.config, logger)
        self.bstack1ll1l111_opy_ = bstack11l11ll11l_opy_.bstack1llll11111_opy_(config=self.config)
        self.bstack111l111ll11_opy_ = {}
        self.bstack1111l1111l_opy_ = False
        self.bstack111l11l11l1_opy_ = (
            self.__111l11l1l1l_opy_()
            and self.bstack1ll1l111_opy_ is not None
            and self.bstack1ll1l111_opy_.bstack11ll1lll_opy_()
            and config.get(bstack1l11_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫṠ"), None) is not None
            and config.get(bstack1l11_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪṡ"), os.path.basename(os.getcwd())) is not None
        )
    @classmethod
    def bstack1llll11111_opy_(cls, config, logger):
        if cls._1ll1ll11l1l_opy_ is None and config is not None:
            cls._1ll1ll11l1l_opy_ = bstack1lll1111_opy_(config, logger)
        return cls._1ll1ll11l1l_opy_
    def bstack11ll1lll_opy_(self):
        bstack1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡊ࡯ࠡࡰࡲࡸࠥࡧࡰࡱ࡮ࡼࠤࡹ࡫ࡳࡵࠢࡲࡶࡩ࡫ࡲࡪࡰࡪࠤࡼ࡮ࡥ࡯࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡑ࠴࠵ࡾࠦࡩࡴࠢࡱࡳࡹࠦࡥ࡯ࡣࡥࡰࡪࡪࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡕࡲࡥࡧࡵ࡭ࡳ࡭ࠠࡪࡵࠣࡲࡴࡺࠠࡦࡰࡤࡦࡱ࡫ࡤࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠤ࡮ࡹࠠࡏࡱࡱࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡦࡺ࡯࡬ࡥࡐࡤࡱࡪࠦࡩࡴࠢࡑࡳࡳ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦṢ")
        return self.bstack111l11l11l1_opy_ and self.bstack111l111lll1_opy_()
    def bstack111l111lll1_opy_(self):
        bstack111l11l11ll_opy_ = os.getenv(bstack1l11_opy_ (u"ࠩࡉࡖࡆࡓࡅࡘࡑࡕࡏࡤ࡛ࡓࡆࡆࠪṣ"), self.config.get(bstack1l11_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭Ṥ"), None))
        return bstack111l11l11ll_opy_ in bstack11l1ll11l11_opy_
    def __111l11l1l1l_opy_(self):
        bstack11l1llll111_opy_ = False
        for fw in bstack11l1l1l111l_opy_:
            if fw in self.config.get(bstack1l11_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧṥ"), bstack1l11_opy_ (u"ࠬ࠭Ṧ")):
                bstack11l1llll111_opy_ = True
        return bstack1lll1lll1_opy_(self.config.get(bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪṧ"), bstack11l1llll111_opy_))
    def bstack111l11l1ll1_opy_(self):
        return (not self.bstack11ll1lll_opy_() and
                self.bstack1ll1l111_opy_ is not None and self.bstack1ll1l111_opy_.bstack11ll1lll_opy_())
    def bstack111l111l111_opy_(self):
        if not self.bstack111l11l1ll1_opy_():
            return
        if self.config.get(bstack1l11_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬṨ"), None) is None or self.config.get(bstack1l11_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫṩ"), os.path.basename(os.getcwd())) is None:
            self.logger.info(bstack1l11_opy_ (u"ࠤࡗࡩࡸࡺࠠࡓࡧࡲࡶࡩ࡫ࡲࡪࡰࡪࠤࡨࡧ࡮ࠨࡶࠣࡻࡴࡸ࡫ࠡࡣࡶࠤࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠠࡰࡴࠣࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠡ࡫ࡶࠤࡳࡻ࡬࡭࠰ࠣࡔࡱ࡫ࡡࡴࡧࠣࡷࡪࡺࠠࡢࠢࡱࡳࡳ࠳࡮ࡶ࡮࡯ࠤࡻࡧ࡬ࡶࡧ࠱ࠦṪ"))
        if not self.__111l11l1l1l_opy_():
            self.logger.info(bstack1l11_opy_ (u"ࠥࡘࡪࡹࡴࠡࡔࡨࡳࡷࡪࡥࡳ࡫ࡱ࡫ࠥࡩࡡ࡯ࠩࡷࠤࡼࡵࡲ࡬ࠢࡤࡷࠥࡺࡥࡴࡶࡕࡩࡵࡵࡲࡵ࡫ࡱ࡫ࠥ࡯ࡳࠡࡦ࡬ࡷࡦࡨ࡬ࡦࡦ࠱ࠤࡕࡲࡥࡢࡵࡨࠤࡪࡴࡡࡣ࡮ࡨࠤ࡮ࡺࠠࡧࡴࡲࡱࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡾࡳ࡬ࠡࡨ࡬ࡰࡪ࠴ࠢṫ"))
    def bstack111l11l111l_opy_(self):
        return self.bstack1111l1111l_opy_
    def bstack11111l1ll1_opy_(self, bstack111l111l1ll_opy_):
        self.bstack1111l1111l_opy_ = bstack111l111l1ll_opy_
        self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠦࡦࡶࡰ࡭࡫ࡨࡨࠧṬ"), bstack111l111l1ll_opy_)
    def bstack11111ll111_opy_(self, test_files):
        try:
            if test_files is None:
                self.logger.debug(bstack1l11_opy_ (u"ࠧࡡࡲࡦࡱࡵࡨࡪࡸ࡟ࡵࡧࡶࡸࡤ࡬ࡩ࡭ࡧࡶࡡࠥࡔ࡯ࠡࡶࡨࡷࡹࠦࡦࡪ࡮ࡨࡷࠥࡶࡲࡰࡸ࡬ࡨࡪࡪࠠࡧࡱࡵࠤࡴࡸࡤࡦࡴ࡬ࡲ࡬࠴ࠢṭ"))
                return None
            orchestration_strategy = None
            bstack1ll1lll1l11_opy_ = self.bstack1ll1l111_opy_.bstack111l11l1l11_opy_()
            if self.bstack1ll1l111_opy_ is not None:
                orchestration_strategy = self.bstack1ll1l111_opy_.bstack1l1l1l1ll_opy_()
            if orchestration_strategy is None:
                self.logger.error(bstack1l11_opy_ (u"ࠨࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࠦࡳࡵࡴࡤࡸࡪ࡭ࡹࠡ࡫ࡶࠤࡓࡵ࡮ࡦ࠰ࠣࡇࡦࡴ࡮ࡰࡶࠣࡴࡷࡵࡣࡦࡧࡧࠤࡼ࡯ࡴࡩࠢࡷࡩࡸࡺࠠࡰࡴࡦ࡬ࡪࡹࡴࡳࡣࡷ࡭ࡴࡴࠠࡴࡧࡶࡷ࡮ࡵ࡮࠯ࠤṮ"))
                return None
            self.logger.info(bstack1l11_opy_ (u"ࠢࡓࡧࡲࡶࡩ࡫ࡲࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡩ࡭ࡱ࡫ࡳࠡࡹ࡬ࡸ࡭ࠦ࡯ࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࠦࡳࡵࡴࡤࡸࡪ࡭ࡹ࠻ࠢࡾࢁࠧṯ").format(orchestration_strategy))
            if cli.is_running():
                self.logger.debug(bstack1l11_opy_ (u"ࠣࡗࡶ࡭ࡳ࡭ࠠࡄࡎࡌࠤ࡫ࡲ࡯ࡸࠢࡩࡳࡷࠦࡴࡦࡵࡷࠤ࡫࡯࡬ࡦࡵࠣࡳࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰ࠱ࠦṰ"))
                ordered_test_files = cli.test_orchestration_session(test_files, orchestration_strategy, json.dumps(bstack1ll1lll1l11_opy_))
            else:
                self.logger.debug(bstack1l11_opy_ (u"ࠤࡘࡷ࡮ࡴࡧࠡࡵࡧ࡯ࠥ࡬࡬ࡰࡹࠣࡪࡴࡸࠠࡵࡧࡶࡸࠥ࡬ࡩ࡭ࡧࡶࠤࡴࡸࡣࡩࡧࡶࡸࡷࡧࡴࡪࡱࡱ࠲ࠧṱ"))
                self.bstack111l111l11l_opy_.bstack111l11l1111_opy_(test_files, orchestration_strategy, bstack1ll1lll1l11_opy_)
                ordered_test_files = self.bstack111l111l11l_opy_.bstack111l111llll_opy_()
            if not ordered_test_files:
                return None
            self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠥࡹࡵࡲ࡯ࡢࡦࡨࡨ࡙࡫ࡳࡵࡈ࡬ࡰࡪࡹࡃࡰࡷࡱࡸࠧṲ"), len(test_files))
            self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠦࡳࡵࡤࡦࡋࡱࡨࡪࡾࠢṳ"), int(os.environ.get(bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡓࡕࡄࡆࡡࡌࡒࡉࡋࡘࠣṴ")) or bstack1l11_opy_ (u"ࠨ࠰ࠣṵ")))
            self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠢࡵࡱࡷࡥࡱࡔ࡯ࡥࡧࡶࠦṶ"), int(os.environ.get(bstack1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡏࡑࡇࡉࡤࡉࡏࡖࡐࡗࠦṷ")) or bstack1l11_opy_ (u"ࠤ࠴ࠦṸ")))
            self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࡔࡦࡵࡷࡊ࡮ࡲࡥࡴࡅࡲࡹࡳࡺࠢṹ"), len(ordered_test_files))
            self.bstack11111l11l1_opy_(bstack1l11_opy_ (u"ࠦࡸࡶ࡬ࡪࡶࡗࡩࡸࡺࡳࡂࡒࡌࡇࡦࡲ࡬ࡄࡱࡸࡲࡹࠨṺ"), self.bstack111l111l11l_opy_.bstack111l111ll1l_opy_())
            return ordered_test_files
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡡࡲࡦࡱࡵࡨࡪࡸ࡟ࡵࡧࡶࡸࡤ࡬ࡩ࡭ࡧࡶࡡࠥࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡰࡴࡧࡩࡷ࡯࡮ࡨࠢࡷࡩࡸࡺࠠࡤ࡮ࡤࡷࡸ࡫ࡳ࠻ࠢࡾࢁࠧṻ").format(e))
        return None
    def bstack11111l11l1_opy_(self, key, value):
        self.bstack111l111ll11_opy_[key] = value
    def bstack11ll111l11_opy_(self):
        return self.bstack111l111ll11_opy_