# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import json
import requests
import logging
import threading
import bstack_utils.constants as bstack11ll1lll11l_opy_
from urllib.parse import urlparse
from bstack_utils.constants import bstack11ll1l1111l_opy_ as bstack11ll1l1llll_opy_, EVENTS
from bstack_utils.bstack1lll11l1l1_opy_ import bstack1lll11l1l1_opy_
from bstack_utils.helper import bstack1llll1l1_opy_, bstack1111l1lll1_opy_, bstack11ll1ll1l_opy_, bstack11ll1ll11ll_opy_, \
  bstack11ll11lllll_opy_, bstack1l11l1l11l_opy_, get_host_info, bstack11ll1l1ll11_opy_, bstack11l1l1l111_opy_, error_handler, bstack11ll1ll1l11_opy_, bstack11ll11l11ll_opy_, bstack1l11lll11_opy_
from browserstack_sdk._version import __version__
from bstack_utils.bstack1l111llll_opy_ import get_logger
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
from selenium.webdriver.chrome.options import Options as ChromeOptions
from browserstack_sdk.sdk_cli.cli import cli
from bstack_utils.constants import *
logger = get_logger(__name__)
bstack1l11l1ll11_opy_ = bstack1ll1l1l11l1_opy_()
@error_handler(class_method=False)
def _11ll11l111l_opy_(driver, bstack1111l1l111_opy_):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack1l11_opy_ (u"ࠩࡲࡷࡤࡴࡡ࡮ࡧࠪᘶ"): caps.get(bstack1l11_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦࠩᘷ"), None),
        bstack1l11_opy_ (u"ࠫࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨᘸ"): bstack1111l1l111_opy_.get(bstack1l11_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨᘹ"), None),
        bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟࡯ࡣࡰࡩࠬᘺ"): caps.get(bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬᘻ"), None),
        bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪᘼ"): caps.get(bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᘽ"), None)
    }
  except Exception as error:
    logger.debug(bstack1l11_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡩࡩࡹࡩࡨࡪࡰࡪࠤࡵࡲࡡࡵࡨࡲࡶࡲࠦࡤࡦࡶࡤ࡭ࡱࡹࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵࠤ࠿ࠦࠧᘾ") + str(error))
  return response
def on():
    if os.environ.get(bstack1l11_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᘿ"), None) is None or os.environ[bstack1l11_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᙀ")] == bstack1l11_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦᙁ"):
        return False
    return True
def bstack1ll111ll1_opy_(config):
  return config.get(bstack1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᙂ"), False) or any([p.get(bstack1l11_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᙃ"), False) == True for p in config.get(bstack1l11_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬᙄ"), [])])
def bstack11ll1llll_opy_(config, bstack1l1l11ll11_opy_):
  try:
    bstack11ll1l111l1_opy_ = config.get(bstack1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᙅ"), False)
    if int(bstack1l1l11ll11_opy_) < len(config.get(bstack1l11_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧᙆ"), [])) and config[bstack1l11_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᙇ")][bstack1l1l11ll11_opy_]:
      bstack11ll1l1l1ll_opy_ = config[bstack1l11_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩᙈ")][bstack1l1l11ll11_opy_].get(bstack1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᙉ"), None)
    else:
      bstack11ll1l1l1ll_opy_ = config.get(bstack1l11_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᙊ"), None)
    if bstack11ll1l1l1ll_opy_ != None:
      bstack11ll1l111l1_opy_ = bstack11ll1l1l1ll_opy_
    bstack11ll1lll111_opy_ = os.getenv(bstack1l11_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧᙋ")) is not None and len(os.getenv(bstack1l11_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨᙌ"))) > 0 and os.getenv(bstack1l11_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᙍ")) != bstack1l11_opy_ (u"ࠬࡴࡵ࡭࡮ࠪᙎ")
    return bstack11ll1l111l1_opy_ and bstack11ll1lll111_opy_
  except Exception as error:
    logger.debug(bstack1l11_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡼࡥࡳ࡫ࡩࡽ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡷࡪࡶ࡫ࠤࡪࡸࡲࡰࡴࠣ࠾ࠥ࠭ᙏ") + str(error))
  return False
def bstack111lll1l11_opy_(test_tags):
  bstack1ll111l11l1_opy_ = os.getenv(bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨᙐ"))
  if bstack1ll111l11l1_opy_ is None:
    return True
  bstack1ll111l11l1_opy_ = json.loads(bstack1ll111l11l1_opy_)
  try:
    include_tags = bstack1ll111l11l1_opy_[bstack1l11_opy_ (u"ࠨ࡫ࡱࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ᙑ")] if bstack1l11_opy_ (u"ࠩ࡬ࡲࡨࡲࡵࡥࡧࡗࡥ࡬ࡹࡉ࡯ࡖࡨࡷࡹ࡯࡮ࡨࡕࡦࡳࡵ࡫ࠧᙒ") in bstack1ll111l11l1_opy_ and isinstance(bstack1ll111l11l1_opy_[bstack1l11_opy_ (u"ࠪ࡭ࡳࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨᙓ")], list) else []
    exclude_tags = bstack1ll111l11l1_opy_[bstack1l11_opy_ (u"ࠫࡪࡾࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩᙔ")] if bstack1l11_opy_ (u"ࠬ࡫ࡸࡤ࡮ࡸࡨࡪ࡚ࡡࡨࡵࡌࡲ࡙࡫ࡳࡵ࡫ࡱ࡫ࡘࡩ࡯ࡱࡧࠪᙕ") in bstack1ll111l11l1_opy_ and isinstance(bstack1ll111l11l1_opy_[bstack1l11_opy_ (u"࠭ࡥࡹࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫᙖ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack1l11_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩ࡫࡯ࡩࠥࡼࡡ࡭࡫ࡧࡥࡹ࡯࡮ࡨࠢࡷࡩࡸࡺࠠࡤࡣࡶࡩࠥ࡬࡯ࡳࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡥࡩ࡫ࡵࡲࡦࠢࡶࡧࡦࡴ࡮ࡪࡰࡪ࠲ࠥࡋࡲࡳࡱࡵࠤ࠿ࠦࠢᙗ") + str(error))
  return False
def bstack11ll11ll1ll_opy_(config, bstack11ll11l1111_opy_, bstack11ll1l11ll1_opy_, bstack11ll1l1l11l_opy_):
  bstack11ll1ll1lll_opy_ = bstack11ll1ll11ll_opy_(config)
  bstack11ll11l11l1_opy_ = bstack11ll11lllll_opy_(config)
  if bstack11ll1ll1lll_opy_ is None or bstack11ll11l11l1_opy_ is None:
    logger.error(bstack1l11_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣࡧࡷ࡫ࡡࡵ࡫ࡱ࡫ࠥࡺࡥࡴࡶࠣࡶࡺࡴࠠࡧࡱࡵࠤࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࠺ࠡࡏ࡬ࡷࡸ࡯࡮ࡨࠢࡤࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡸࡴࡱࡥ࡯ࠩᙘ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪᙙ"), bstack1l11_opy_ (u"ࠪࡿࢂ࠭ᙚ")))
    data = {
        bstack1l11_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠩᙛ"): config[bstack1l11_opy_ (u"ࠬࡶࡲࡰ࡬ࡨࡧࡹࡔࡡ࡮ࡧࠪᙜ")],
        bstack1l11_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩᙝ"): config.get(bstack1l11_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪᙞ"), os.path.basename(os.getcwd())),
        bstack1l11_opy_ (u"ࠨࡵࡷࡥࡷࡺࡔࡪ࡯ࡨࠫᙟ"): bstack1llll1l1_opy_(),
        bstack1l11_opy_ (u"ࠩࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧᙠ"): config.get(bstack1l11_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ᙡ"), bstack1l11_opy_ (u"ࠫࠬᙢ")),
        bstack1l11_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬᙣ"): {
            bstack1l11_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡐࡤࡱࡪ࠭ᙤ"): bstack11ll11l1111_opy_,
            bstack1l11_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭࡙ࡩࡷࡹࡩࡰࡰࠪᙥ"): bstack11ll1l11ll1_opy_,
            bstack1l11_opy_ (u"ࠨࡵࡧ࡯࡛࡫ࡲࡴ࡫ࡲࡲࠬᙦ"): __version__,
            bstack1l11_opy_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫᙧ"): bstack1l11_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪᙨ"),
            bstack1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡈࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫᙩ"): bstack1l11_opy_ (u"ࠬࡹࡥ࡭ࡧࡱ࡭ࡺࡳࠧᙪ"),
            bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡊࡷࡧ࡭ࡦࡹࡲࡶࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᙫ"): bstack11ll1l1l11l_opy_
        },
        bstack1l11_opy_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴࠩᙬ"): settings,
        bstack1l11_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࡅࡲࡲࡹࡸ࡯࡭ࠩ᙭"): bstack11ll1l1ll11_opy_(),
        bstack1l11_opy_ (u"ࠩࡦ࡭ࡎࡴࡦࡰࠩ᙮"): bstack1l11l1l11l_opy_(),
        bstack1l11_opy_ (u"ࠪ࡬ࡴࡹࡴࡊࡰࡩࡳࠬᙯ"): get_host_info(),
        bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᙰ"): bstack11ll1ll1l_opy_(config)
    }
    headers = {
        bstack1l11_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᙱ"): bstack1l11_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩᙲ"),
    }
    config = {
        bstack1l11_opy_ (u"ࠧࡢࡷࡷ࡬ࠬᙳ"): (bstack11ll1ll1lll_opy_, bstack11ll11l11l1_opy_),
        bstack1l11_opy_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩᙴ"): headers
    }
    response = bstack11l1l1l111_opy_(bstack1l11_opy_ (u"ࠩࡓࡓࡘ࡚ࠧᙵ"), bstack11ll1l1llll_opy_ + bstack1l11_opy_ (u"ࠪ࠳ࡻ࠸࠯ࡵࡧࡶࡸࡤࡸࡵ࡯ࡵࠪᙶ"), data, config)
    bstack11ll1ll111l_opy_ = response.json()
    if bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬᙷ")]:
      parsed = json.loads(os.getenv(bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᙸ"), bstack1l11_opy_ (u"࠭ࡻࡾࠩᙹ")))
      parsed[bstack1l11_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᙺ")] = bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠨࡦࡤࡸࡦ࠭ᙻ")][bstack1l11_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᙼ")]
      os.environ[bstack1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫᙽ")] = json.dumps(parsed)
      bstack1lll11l1l1_opy_.bstack1llll11l11_opy_(bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠫࡩࡧࡴࡢࠩᙾ")][bstack1l11_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸࡸ࠭ᙿ")])
      bstack1lll11l1l1_opy_.bstack11ll11ll1l1_opy_(bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"࠭ࡤࡢࡶࡤࠫ ")][bstack1l11_opy_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡴࠩᚁ")])
      bstack1lll11l1l1_opy_.store()
      return bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠨࡦࡤࡸࡦ࠭ᚂ")][bstack1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡖࡲ࡯ࡪࡴࠧᚃ")], bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠪࡨࡦࡺࡡࠨᚄ")][bstack1l11_opy_ (u"ࠫ࡮ࡪࠧᚅ")]
    else:
      logger.error(bstack1l11_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡹ࡫࡭ࡱ࡫ࠠࡳࡷࡱࡲ࡮ࡴࡧࠡࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱ࠾ࠥ࠭ᚆ") + bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᚇ")])
      if bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᚈ")] == bstack1l11_opy_ (u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡳࡥࡸࡹࡥࡥ࠰ࠪᚉ"):
        for bstack11ll11lll11_opy_ in bstack11ll1ll111l_opy_[bstack1l11_opy_ (u"ࠩࡨࡶࡷࡵࡲࡴࠩᚊ")]:
          logger.error(bstack11ll11lll11_opy_[bstack1l11_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᚋ")])
      return None, None
  except Exception as error:
    logger.error(bstack1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦࡣࡳࡧࡤࡸ࡮ࡴࡧࠡࡶࡨࡷࡹࠦࡲࡶࡰࠣࡪࡴࡸࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰ࠽ࠤࠧᚌ") +  str(error))
    return None, None
def bstack11ll11llll1_opy_():
  if os.getenv(bstack1l11_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᚍ")) is None:
    return {
        bstack1l11_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ᚎ"): bstack1l11_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ᚏ"),
        bstack1l11_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᚐ"): bstack1l11_opy_ (u"ࠩࡅࡹ࡮ࡲࡤࠡࡥࡵࡩࡦࡺࡩࡰࡰࠣ࡬ࡦࡪࠠࡧࡣ࡬ࡰࡪࡪ࠮ࠨᚑ")
    }
  data = {bstack1l11_opy_ (u"ࠪࡩࡳࡪࡔࡪ࡯ࡨࠫᚒ"): bstack1llll1l1_opy_()}
  headers = {
      bstack1l11_opy_ (u"ࠫࡆࡻࡴࡩࡱࡵ࡭ࡿࡧࡴࡪࡱࡱࠫᚓ"): bstack1l11_opy_ (u"ࠬࡈࡥࡢࡴࡨࡶࠥ࠭ᚔ") + os.getenv(bstack1l11_opy_ (u"ࠨࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠦᚕ")),
      bstack1l11_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᚖ"): bstack1l11_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᚗ")
  }
  response = bstack11l1l1l111_opy_(bstack1l11_opy_ (u"ࠩࡓ࡙࡙࠭ᚘ"), bstack11ll1l1llll_opy_ + bstack1l11_opy_ (u"ࠪ࠳ࡹ࡫ࡳࡵࡡࡵࡹࡳࡹ࠯ࡴࡶࡲࡴࠬᚙ"), data, { bstack1l11_opy_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬᚚ"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack1l11_opy_ (u"ࠧࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡖࡨࡷࡹࠦࡒࡶࡰࠣࡱࡦࡸ࡫ࡦࡦࠣࡥࡸࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡤࡸࠥࠨ᚛") + bstack1111l1lll1_opy_().isoformat() + bstack1l11_opy_ (u"࡚࠭ࠨ᚜"))
      return {bstack1l11_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ᚝"): bstack1l11_opy_ (u"ࠨࡵࡸࡧࡨ࡫ࡳࡴࠩ᚞"), bstack1l11_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ᚟"): bstack1l11_opy_ (u"ࠪࠫᚠ")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡰࡪࠦ࡭ࡢࡴ࡮࡭ࡳ࡭ࠠࡤࡱࡰࡴࡱ࡫ࡴࡪࡱࡱࠤࡴ࡬ࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡘࡪࡹࡴࠡࡔࡸࡲ࠿ࠦࠢᚡ") + str(error))
    return {
        bstack1l11_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬᚢ"): bstack1l11_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬᚣ"),
        bstack1l11_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᚤ"): str(error)
    }
def bstack11ll1ll1l1l_opy_(bstack11ll1l11111_opy_):
    return re.match(bstack1l11_opy_ (u"ࡳࠩࡡࡠࡩ࠱ࠨ࡝࠰࡟ࡨ࠰࠯࠿ࠥࠩᚥ"), bstack11ll1l11111_opy_.strip()) is not None
def bstack11l1111lll_opy_(caps, options, desired_capabilities={}, config=None):
    try:
        if options:
          bstack11ll1lll1l1_opy_ = options.to_capabilities()
        elif desired_capabilities:
          bstack11ll1lll1l1_opy_ = desired_capabilities
        else:
          bstack11ll1lll1l1_opy_ = {}
        bstack1ll1111l1ll_opy_ = (bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠨᚦ"), bstack1l11_opy_ (u"ࠪࠫᚧ")).lower() or caps.get(bstack1l11_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡔࡡ࡮ࡧࠪᚨ"), bstack1l11_opy_ (u"ࠬ࠭ᚩ")).lower())
        if bstack1ll1111l1ll_opy_ == bstack1l11_opy_ (u"࠭ࡩࡰࡵࠪᚪ"):
            return True
        if bstack1ll1111l1ll_opy_ == bstack1l11_opy_ (u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨᚫ"):
            bstack1ll11l1llll_opy_ = str(float(caps.get(bstack1l11_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯࡙ࡩࡷࡹࡩࡰࡰࠪᚬ")) or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᚭ"), {}).get(bstack1l11_opy_ (u"ࠪࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᚮ"),bstack1l11_opy_ (u"ࠫࠬᚯ"))))
            if bstack1ll1111l1ll_opy_ == bstack1l11_opy_ (u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭ᚰ") and int(bstack1ll11l1llll_opy_.split(bstack1l11_opy_ (u"࠭࠮ࠨᚱ"))[0]) < float(bstack11ll1l1ll1l_opy_):
                logger.warning(str(bstack11ll1ll1ll1_opy_))
                return False
            return True
        bstack1ll111l1111_opy_ = caps.get(bstack1l11_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᚲ"), {}).get(bstack1l11_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠬᚳ"), caps.get(bstack1l11_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩᚴ"), bstack1l11_opy_ (u"ࠪࠫᚵ")))
        if bstack1ll111l1111_opy_:
            logger.warning(bstack1l11_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡰࡱࠦࡲࡶࡰࠣࡳࡳࡲࡹࠡࡱࡱࠤࡉ࡫ࡳ࡬ࡶࡲࡴࠥࡨࡲࡰࡹࡶࡩࡷࡹ࠮ࠣᚶ"))
            return False
        browser = caps.get(bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪᚷ"), bstack1l11_opy_ (u"࠭ࠧᚸ")).lower() or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬᚹ"), bstack1l11_opy_ (u"ࠨࠩᚺ")).lower()
        if browser != bstack1l11_opy_ (u"ࠩࡦ࡬ࡷࡵ࡭ࡦࠩᚻ"):
            logger.warning(bstack1l11_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡸࡵ࡯ࠢࡲࡲࡱࡿࠠࡰࡰࠣࡇ࡭ࡸ࡯࡮ࡧࠣࡦࡷࡵࡷࡴࡧࡵࡷ࠳ࠨᚼ"))
            return False
        browser_version = caps.get(bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᚽ")) or caps.get(bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᚾ")) or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᚿ")) or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᛀ"), {}).get(bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩᛁ")) or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᛂ"), {}).get(bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᛃ"))
        bstack1ll111l1l11_opy_ = bstack11ll1lll11l_opy_.bstack1ll1111l11l_opy_
        bstack11ll11ll111_opy_ = False
        if config is not None:
          bstack11ll11ll111_opy_ = bstack1l11_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨᛄ") in config and str(config[bstack1l11_opy_ (u"ࠬࡺࡵࡳࡤࡲࡗࡨࡧ࡬ࡦࠩᛅ")]).lower() != bstack1l11_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬᛆ")
        if os.environ.get(bstack1l11_opy_ (u"ࠧࡊࡕࡢࡒࡔࡔ࡟ࡃࡕࡗࡅࡈࡑ࡟ࡊࡐࡉࡖࡆࡥࡁ࠲࠳࡜ࡣࡘࡋࡓࡔࡋࡒࡒࠬᛇ"), bstack1l11_opy_ (u"ࠨࠩᛈ")).lower() == bstack1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧᛉ") or bstack11ll11ll111_opy_:
          bstack1ll111l1l11_opy_ = bstack11ll1lll11l_opy_.bstack1ll111l1lll_opy_
        if browser_version and browser_version != bstack1l11_opy_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪᛊ") and int(browser_version.split(bstack1l11_opy_ (u"ࠫ࠳࠭ᛋ"))[0]) <= bstack1ll111l1l11_opy_:
          logger.warning(bstack1111l111ll_opy_ (u"ࠬࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠࡳࡷࡱࠤࡴࡴ࡬ࡺࠢࡲࡲࠥࡉࡨࡳࡱࡰࡩࠥࡨࡲࡰࡹࡶࡩࡷࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡨࡴࡨࡥࡹ࡫ࡲࠡࡶ࡫ࡥࡳࠦࡻ࡮࡫ࡱࡣࡦ࠷࠱ࡺࡡࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡤࡩࡨࡳࡱࡰࡩࡤࡼࡥࡳࡵ࡬ࡳࡳࢃ࠮ࠨᛌ"))
          return False
        if not options:
          bstack1ll11lllll1_opy_ = caps.get(bstack1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫᛍ")) or bstack11ll1lll1l1_opy_.get(bstack1l11_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬᛎ"), {})
          if bstack1l11_opy_ (u"ࠨ࠯࠰࡬ࡪࡧࡤ࡭ࡧࡶࡷࠬᛏ") in bstack1ll11lllll1_opy_.get(bstack1l11_opy_ (u"ࠩࡤࡶ࡬ࡹࠧᛐ"), []):
              logger.warning(bstack1l11_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡴ࡯ࡵࠢࡵࡹࡳࠦ࡯࡯ࠢ࡯ࡩ࡬ࡧࡣࡺࠢ࡫ࡩࡦࡪ࡬ࡦࡵࡶࠤࡲࡵࡤࡦ࠰ࠣࡗࡼ࡯ࡴࡤࡪࠣࡸࡴࠦ࡮ࡦࡹࠣ࡬ࡪࡧࡤ࡭ࡧࡶࡷࠥࡳ࡯ࡥࡧࠣࡳࡷࠦࡡࡷࡱ࡬ࡨࠥࡻࡳࡪࡰࡪࠤ࡭࡫ࡡࡥ࡮ࡨࡷࡸࠦ࡭ࡰࡦࡨ࠲ࠧᛑ"))
              return False
        return True
    except Exception as error:
        logger.debug(bstack1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡺࡦࡲࡩࡥࡣࡷࡩࠥࡧ࠱࠲ࡻࠣࡷࡺࡶࡰࡰࡴࡷࠤ࠿ࠨᛒ") + str(error))
        return False
def set_capabilities(caps, config):
  try:
    bstack1ll1l1l111l_opy_ = config.get(bstack1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬᛓ"), {})
    bstack1ll1l1l111l_opy_[bstack1l11_opy_ (u"࠭ࡡࡶࡶ࡫ࡘࡴࡱࡥ࡯ࠩᛔ")] = os.getenv(bstack1l11_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᛕ"))
    bstack11ll1ll11l1_opy_ = json.loads(os.getenv(bstack1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡤࡇࡃࡄࡇࡖࡗࡎࡈࡉࡍࡋࡗ࡝ࡤࡉࡏࡏࡈࡌࡋ࡚ࡘࡁࡕࡋࡒࡒࡤ࡟ࡍࡍࠩᛖ"), bstack1l11_opy_ (u"ࠩࡾࢁࠬᛗ"))).get(bstack1l11_opy_ (u"ࠪࡷࡨࡧ࡮࡯ࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᛘ"))
    if not config[bstack1l11_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡓࡶࡴࡪࡵࡤࡶࡐࡥࡵ࠭ᛙ")].get(bstack1l11_opy_ (u"ࠧࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠦᛚ")):
      if bstack1l11_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧᛛ") in caps:
        caps[bstack1l11_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᛜ")][bstack1l11_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᛝ")] = bstack1ll1l1l111l_opy_
        caps[bstack1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᛞ")][bstack1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪᛟ")][bstack1l11_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᛠ")] = bstack11ll1ll11l1_opy_
      else:
        caps[bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫᛡ")] = bstack1ll1l1l111l_opy_
        caps[bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬᛢ")][bstack1l11_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᛣ")] = bstack11ll1ll11l1_opy_
  except Exception as error:
    logger.debug(bstack1l11_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣࡷࡪࡺࡴࡪࡰࡪࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹ࠮ࠡࡇࡵࡶࡴࡸ࠺ࠡࠤᛤ") +  str(error))
def bstack11ll11lll1_opy_(driver, bstack11ll11l1l1l_opy_):
  try:
    setattr(driver, bstack1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡃ࠴࠵ࡾ࡙ࡨࡰࡷ࡯ࡨࡘࡩࡡ࡯ࠩᛥ"), True)
    session = driver.session_id
    if session:
      bstack11ll1l11lll_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack11ll1l11lll_opy_ = False
      bstack11ll1l11lll_opy_ = url.scheme in [bstack1l11_opy_ (u"ࠥ࡬ࡹࡺࡰࠣᛦ"), bstack1l11_opy_ (u"ࠦ࡭ࡺࡴࡱࡵࠥᛧ")]
      if bstack11ll1l11lll_opy_:
        if bstack11ll11l1l1l_opy_:
          logger.info(bstack1l11_opy_ (u"࡙ࠧࡥࡵࡷࡳࠤ࡫ࡵࡲࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡶࡨࡷࡹ࡯࡮ࡨࠢ࡫ࡥࡸࠦࡳࡵࡣࡵࡸࡪࡪ࠮ࠡࡃࡸࡸࡴࡳࡡࡵࡧࠣࡸࡪࡹࡴࠡࡥࡤࡷࡪࠦࡥࡹࡧࡦࡹࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠࡣࡧࡪ࡭ࡳࠦ࡭ࡰ࡯ࡨࡲࡹࡧࡲࡪ࡮ࡼ࠲ࠧᛨ"))
      return bstack11ll11l1l1l_opy_
  except Exception as e:
    logger.error(bstack1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡹࡴࡢࡴࡷ࡭ࡳ࡭ࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡸࡩࡡ࡯ࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫࠺ࠡࠤᛩ") + str(e))
    return False
def bstack111l111ll_opy_(driver, name, path):
  try:
    bstack1ll11111l1l_opy_ = {
        bstack1l11_opy_ (u"ࠧࡵࡪࡗࡩࡸࡺࡒࡶࡰࡘࡹ࡮ࡪࠧᛪ"): threading.current_thread().current_test_uuid,
        bstack1l11_opy_ (u"ࠨࡶ࡫ࡆࡺ࡯࡬ࡥࡗࡸ࡭ࡩ࠭᛫"): os.environ.get(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧ᛬"), bstack1l11_opy_ (u"ࠪࠫ᛭")),
        bstack1l11_opy_ (u"ࠫࡹ࡮ࡊࡸࡶࡗࡳࡰ࡫࡮ࠨᛮ"): os.environ.get(bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩᛯ"), bstack1l11_opy_ (u"࠭ࠧᛰ"))
    }
    bstack1ll11ll11l1_opy_ = bstack1l11l1ll11_opy_.bstack1ll111l111l_opy_(EVENTS.bstack1l1llll1ll_opy_.value)
    logger.debug(bstack1l11_opy_ (u"ࠧࡑࡧࡵࡪࡴࡸ࡭ࡪࡰࡪࠤࡸࡩࡡ࡯ࠢࡥࡩ࡫ࡵࡲࡦࠢࡶࡥࡻ࡯࡮ࡨࠢࡵࡩࡸࡻ࡬ࡵࡵࠪᛱ"))
    try:
      if (bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠨ࡫ࡶࡅࡵࡶࡁ࠲࠳ࡼࡘࡪࡹࡴࠨᛲ"), None) and bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠩࡤࡴࡵࡇ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫᛳ"), None)):
        scripts = {bstack1l11_opy_ (u"ࠪࡷࡨࡧ࡮ࠨᛴ"): bstack1lll11l1l1_opy_.perform_scan}
        bstack11ll1l11l11_opy_ = json.loads(scripts[bstack1l11_opy_ (u"ࠦࡸࡩࡡ࡯ࠤᛵ")].replace(bstack1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࠣᛶ"), bstack1l11_opy_ (u"ࠨࠢᛷ")))
        bstack11ll1l11l11_opy_[bstack1l11_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪᛸ")][bstack1l11_opy_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࠨ᛹")] = None
        scripts[bstack1l11_opy_ (u"ࠤࡶࡧࡦࡴࠢ᛺")] = bstack1l11_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࠨ᛻") + json.dumps(bstack11ll1l11l11_opy_)
        bstack1lll11l1l1_opy_.bstack1llll11l11_opy_(scripts)
        bstack1lll11l1l1_opy_.store()
        logger.debug(driver.execute_script(bstack1lll11l1l1_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack1lll11l1l1_opy_.perform_scan, {bstack1l11_opy_ (u"ࠦࡲ࡫ࡴࡩࡱࡧࠦ᛼"): name}))
      bstack1l11l1ll11_opy_.end(EVENTS.bstack1l1llll1ll_opy_.value, bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧ᛽"), bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠨ࠺ࡦࡰࡧࠦ᛾"), True, None)
    except Exception as error:
      bstack1l11l1ll11_opy_.end(EVENTS.bstack1l1llll1ll_opy_.value, bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢ᛿"), bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨᜀ"), False, str(error))
    bstack1ll11ll11l1_opy_ = bstack1l11l1ll11_opy_.bstack11ll1ll1111_opy_(EVENTS.bstack1ll111llll1_opy_.value)
    bstack1l11l1ll11_opy_.mark(bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤᜁ"))
    try:
      if (bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠪ࡭ࡸࡇࡰࡱࡃ࠴࠵ࡾ࡚ࡥࡴࡶࠪᜂ"), None) and bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠫࡦࡶࡰࡂ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭ᜃ"), None)):
        scripts = {bstack1l11_opy_ (u"ࠬࡹࡣࡢࡰࠪᜄ"): bstack1lll11l1l1_opy_.perform_scan}
        bstack11ll1l11l11_opy_ = json.loads(scripts[bstack1l11_opy_ (u"ࠨࡳࡤࡣࡱࠦᜅ")].replace(bstack1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࠥᜆ"), bstack1l11_opy_ (u"ࠣࠤᜇ")))
        bstack11ll1l11l11_opy_[bstack1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬᜈ")][bstack1l11_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪᜉ")] = None
        scripts[bstack1l11_opy_ (u"ࠦࡸࡩࡡ࡯ࠤᜊ")] = bstack1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࠣᜋ") + json.dumps(bstack11ll1l11l11_opy_)
        bstack1lll11l1l1_opy_.bstack1llll11l11_opy_(scripts)
        bstack1lll11l1l1_opy_.store()
        logger.debug(driver.execute_script(bstack1lll11l1l1_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack1lll11l1l1_opy_.bstack11ll11l1lll_opy_, bstack1ll11111l1l_opy_))
      bstack1l11l1ll11_opy_.end(bstack1ll11ll11l1_opy_, bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠨ࠺ࡴࡶࡤࡶࡹࠨᜌ"), bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠢ࠻ࡧࡱࡨࠧᜍ"),True, None)
    except Exception as error:
      bstack1l11l1ll11_opy_.end(bstack1ll11ll11l1_opy_, bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣᜎ"), bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠤ࠽ࡩࡳࡪࠢᜏ"),False, str(error))
    logger.info(bstack1l11_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡸࡪࡹࡴࡪࡰࡪࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦࠢ࡫ࡥࡸࠦࡥ࡯ࡦࡨࡨ࠳ࠨᜐ"))
  except Exception as bstack1ll11l1l1ll_opy_:
    logger.error(bstack1l11_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡩ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡤࡨࠤࡵࡸ࡯ࡤࡧࡶࡷࡪࡪࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨ࠾ࠥࠨᜑ") + str(path) + bstack1l11_opy_ (u"ࠧࠦࡅࡳࡴࡲࡶࠥࡀࠢᜒ") + str(bstack1ll11l1l1ll_opy_))
def bstack11ll1l111ll_opy_(driver):
    caps = driver.capabilities
    if caps.get(bstack1l11_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡏࡣࡰࡩࠧᜓ")) and str(caps.get(bstack1l11_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪࠨ᜔"))).lower() == bstack1l11_opy_ (u"ࠣࡣࡱࡨࡷࡵࡩࡥࠤ᜕"):
        bstack1ll11l1llll_opy_ = caps.get(bstack1l11_opy_ (u"ࠤࡤࡴࡵ࡯ࡵ࡮࠼ࡳࡰࡦࡺࡦࡰࡴࡰ࡚ࡪࡸࡳࡪࡱࡱࠦ᜖")) or caps.get(bstack1l11_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠧ᜗"))
        if bstack1ll11l1llll_opy_ and int(str(bstack1ll11l1llll_opy_)) < bstack11ll1l1ll1l_opy_:
            return False
    return True
def bstack11ll1l11l_opy_(config):
  if bstack1l11_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ᜘") in config:
        return config[bstack1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ᜙")]
  for platform in config.get(bstack1l11_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ᜚"), []):
      if bstack1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧ᜛") in platform:
          return platform[bstack1l11_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ᜜")]
  return None
def bstack11l111ll_opy_(bstack11l1ll111l_opy_):
  try:
    browser_name = bstack11l1ll111l_opy_[bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡲࡦࡳࡥࠨ᜝")]
    browser_version = bstack11l1ll111l_opy_[bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ᜞")]
    chrome_options = bstack11l1ll111l_opy_[bstack1l11_opy_ (u"ࠫࡨ࡮ࡲࡰ࡯ࡨࡣࡴࡶࡴࡪࡱࡱࡷࠬᜟ")]
    try:
        bstack11ll1l1lll1_opy_ = int(browser_version.split(bstack1l11_opy_ (u"ࠬ࠴ࠧᜠ"))[0])
    except ValueError as e:
        logger.error(bstack1l11_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡨࡵ࡮ࡷࡧࡵࡸ࡮ࡴࡧࠡࡤࡵࡳࡼࡹࡥࡳࠢࡹࡩࡷࡹࡩࡰࡰࠥᜡ") + str(e))
        return False
    if not (browser_name and browser_name.lower() == bstack1l11_opy_ (u"ࠧࡤࡪࡵࡳࡲ࡫ࠧᜢ")):
        logger.warning(bstack1l11_opy_ (u"ࠣࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡶࡺࡴࠠࡰࡰ࡯ࡽࠥࡵ࡮ࠡࡅ࡫ࡶࡴࡳࡥࠡࡤࡵࡳࡼࡹࡥࡳࡵ࠱ࠦᜣ"))
        return False
    if bstack11ll1l1lll1_opy_ < bstack11ll1lll11l_opy_.bstack1ll111l1lll_opy_:
        logger.warning(bstack1111l111ll_opy_ (u"ࠩࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡲࡦࡳࡸ࡭ࡷ࡫ࡳࠡࡅ࡫ࡶࡴࡳࡥࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡾࡇࡔࡔࡓࡕࡃࡑࡘࡘ࠴ࡍࡊࡐࡌࡑ࡚ࡓ࡟ࡏࡑࡑࡣࡇ࡙ࡔࡂࡅࡎࡣࡎࡔࡆࡓࡃࡢࡅ࠶࠷࡙ࡠࡕࡘࡔࡕࡕࡒࡕࡇࡇࡣࡈࡎࡒࡐࡏࡈࡣ࡛ࡋࡒࡔࡋࡒࡒࢂࠦ࡯ࡳࠢ࡫࡭࡬࡮ࡥࡳ࠰ࠪᜤ"))
        return False
    if chrome_options and any(bstack1l11_opy_ (u"ࠪ࠱࠲࡮ࡥࡢࡦ࡯ࡩࡸࡹࠧᜥ") in value for value in chrome_options.values() if isinstance(value, str)):
        logger.warning(bstack1l11_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡰࡱࠦ࡮ࡰࡶࠣࡶࡺࡴࠠࡰࡰࠣࡰࡪ࡭ࡡࡤࡻࠣ࡬ࡪࡧࡤ࡭ࡧࡶࡷࠥࡳ࡯ࡥࡧ࠱ࠤࡘࡽࡩࡵࡥ࡫ࠤࡹࡵࠠ࡯ࡧࡺࠤ࡭࡫ࡡࡥ࡮ࡨࡷࡸࠦ࡭ࡰࡦࡨࠤࡴࡸࠠࡢࡸࡲ࡭ࡩࠦࡵࡴ࡫ࡱ࡫ࠥ࡮ࡥࡢࡦ࡯ࡩࡸࡹࠠ࡮ࡱࡧࡩ࠳ࠨᜦ"))
        return False
    return True
  except Exception as e:
    logger.error(bstack1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡤࡪࡨࡧࡰ࡯࡮ࡨࠢࡳࡰࡦࡺࡦࡰࡴࡰࠤࡸࡻࡰࡱࡱࡵࡸࠥ࡬࡯ࡳࠢ࡯ࡳࡨࡧ࡬ࠡࡅ࡫ࡶࡴࡳࡥ࠻ࠢࠥᜧ") + str(e))
    return False
def bstack1l111111ll_opy_(bstack11l1l1l1l_opy_, config):
    try:
      bstack1ll11l1l11l_opy_ = bstack1l11_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭ᜨ") in config and config[bstack1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᜩ")] == True
      bstack11ll11ll111_opy_ = bstack1l11_opy_ (u"ࠨࡶࡸࡶࡧࡵࡓࡤࡣ࡯ࡩࠬᜪ") in config and str(config[bstack1l11_opy_ (u"ࠩࡷࡹࡷࡨ࡯ࡔࡥࡤࡰࡪ࠭ᜫ")]).lower() != bstack1l11_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩᜬ")
      if not (bstack1ll11l1l11l_opy_ and (not bstack11ll1ll1l_opy_(config) or bstack11ll11ll111_opy_)):
        return bstack11l1l1l1l_opy_
      bstack11ll1l1l1l1_opy_ = bstack1lll11l1l1_opy_.bstack11ll11l1l11_opy_
      if bstack11ll1l1l1l1_opy_ is None:
        logger.debug(bstack1l11_opy_ (u"ࠦࡌࡵ࡯ࡨ࡮ࡨࠤࡨ࡮ࡲࡰ࡯ࡨࠤࡴࡶࡴࡪࡱࡱࡷࠥࡧࡲࡦࠢࡑࡳࡳ࡫ࠢᜭ"))
        return bstack11l1l1l1l_opy_
      bstack11ll11l1ll1_opy_ = int(str(bstack11ll11l11ll_opy_()).split(bstack1l11_opy_ (u"ࠬ࠴ࠧᜮ"))[0])
      logger.debug(bstack1l11_opy_ (u"ࠨࡓࡦ࡮ࡨࡲ࡮ࡻ࡭ࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡧࡩࡹ࡫ࡣࡵࡧࡧ࠾ࠥࠨᜯ") + str(bstack11ll11l1ll1_opy_) + bstack1l11_opy_ (u"ࠢࠣᜰ"))
      if bstack11ll11l1ll1_opy_ == 3 and isinstance(bstack11l1l1l1l_opy_, dict) and bstack1l11_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨᜱ") in bstack11l1l1l1l_opy_ and bstack11ll1l1l1l1_opy_ is not None:
        if bstack1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧᜲ") not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᜳ")]:
          bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠫࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶ᜴ࠫ")][bstack1l11_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪ᜵")] = {}
        if bstack1l11_opy_ (u"࠭ࡡࡳࡩࡶࠫ᜶") in bstack11ll1l1l1l1_opy_:
          if bstack1l11_opy_ (u"ࠧࡢࡴࡪࡷࠬ᜷") not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨ᜸")][bstack1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ᜹")]:
            bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪ᜺")][bstack1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩ᜻")][bstack1l11_opy_ (u"ࠬࡧࡲࡨࡵࠪ᜼")] = []
          for arg in bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"࠭ࡡࡳࡩࡶࠫ᜽")]:
            if arg not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠧࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠧ᜾")][bstack1l11_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭᜿")][bstack1l11_opy_ (u"ࠩࡤࡶ࡬ࡹࠧᝀ")]:
              bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᝁ")][bstack1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝂ")][bstack1l11_opy_ (u"ࠬࡧࡲࡨࡵࠪᝃ")].append(arg)
        if bstack1l11_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪᝄ") in bstack11ll1l1l1l1_opy_:
          if bstack1l11_opy_ (u"ࠧࡦࡺࡷࡩࡳࡹࡩࡰࡰࡶࠫᝅ") not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨᝆ")][bstack1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧᝇ")]:
            bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᝈ")][bstack1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝉ")][bstack1l11_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩᝊ")] = []
          for ext in bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪᝋ")]:
            if ext not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠧࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠧᝌ")][bstack1l11_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ᝍ")][bstack1l11_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ᝎ")]:
              bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᝏ")][bstack1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝐ")][bstack1l11_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩᝑ")].append(ext)
        if bstack1l11_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬᝒ") in bstack11ll1l1l1l1_opy_:
          if bstack1l11_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭ᝓ") not in bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨ᝔")][bstack1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ᝕")]:
            bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪ᝖")][bstack1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩ᝗")][bstack1l11_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫ᝘")] = {}
          bstack11ll1ll1l11_opy_(bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭᝙")][bstack1l11_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ᝚")][bstack1l11_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧ᝛")],
                    bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨ᝜")])
        os.environ[bstack1l11_opy_ (u"ࠪࡍࡘࡥࡎࡐࡐࡢࡆࡘ࡚ࡁࡄࡍࡢࡍࡓࡌࡒࡂࡡࡄ࠵࠶࡟࡟ࡔࡇࡖࡗࡎࡕࡎࠨ᝝")] = bstack1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩ᝞")
        return bstack11l1l1l1l_opy_
      else:
        chrome_options = None
        if isinstance(bstack11l1l1l1l_opy_, ChromeOptions):
          chrome_options = bstack11l1l1l1l_opy_
        elif isinstance(bstack11l1l1l1l_opy_, dict):
          for value in bstack11l1l1l1l_opy_.values():
            if isinstance(value, ChromeOptions):
              chrome_options = value
              break
        if chrome_options is None:
          chrome_options = ChromeOptions()
          if isinstance(bstack11l1l1l1l_opy_, dict):
            bstack11l1l1l1l_opy_[bstack1l11_opy_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡸ࠭᝟")] = chrome_options
          else:
            bstack11l1l1l1l_opy_ = chrome_options
        if bstack11ll1l1l1l1_opy_ is not None:
          if bstack1l11_opy_ (u"࠭ࡡࡳࡩࡶࠫᝠ") in bstack11ll1l1l1l1_opy_:
                bstack11ll1l11l1l_opy_ = chrome_options.arguments or []
                new_args = bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"ࠧࡢࡴࡪࡷࠬᝡ")]
                for arg in new_args:
                    if arg not in bstack11ll1l11l1l_opy_:
                        chrome_options.add_argument(arg)
          if bstack1l11_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬᝢ") in bstack11ll1l1l1l1_opy_:
                existing_extensions = chrome_options.experimental_options.get(bstack1l11_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ᝣ"), [])
                bstack11ll11ll11l_opy_ = bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧᝤ")]
                for extension in bstack11ll11ll11l_opy_:
                    if extension not in existing_extensions:
                        chrome_options.add_encoded_extension(extension)
          if bstack1l11_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪᝥ") in bstack11ll1l1l1l1_opy_:
                bstack11ll1l1l111_opy_ = chrome_options.experimental_options.get(bstack1l11_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫᝦ"), {})
                bstack11ll11lll1l_opy_ = bstack11ll1l1l1l1_opy_[bstack1l11_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬᝧ")]
                bstack11ll1ll1l11_opy_(bstack11ll1l1l111_opy_, bstack11ll11lll1l_opy_)
                chrome_options.add_experimental_option(bstack1l11_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭ᝨ"), bstack11ll1l1l111_opy_)
        os.environ[bstack1l11_opy_ (u"ࠨࡋࡖࡣࡓࡕࡎࡠࡄࡖࡘࡆࡉࡋࡠࡋࡑࡊࡗࡇ࡟ࡂ࠳࠴࡝ࡤ࡙ࡅࡔࡕࡌࡓࡓ࠭ᝩ")] = bstack1l11_opy_ (u"ࠩࡷࡶࡺ࡫ࠧᝪ")
        return bstack11l1l1l1l_opy_
    except Exception as e:
      logger.error(bstack1l11_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡࡣࡧࡨ࡮ࡴࡧࠡࡰࡲࡲ࠲ࡈࡓࠡ࡫ࡱࡪࡷࡧࠠࡢ࠳࠴ࡽࠥࡩࡨࡳࡱࡰࡩࠥࡵࡰࡵ࡫ࡲࡲࡸࡀࠠࠣᝫ") + str(e))
      return bstack11l1l1l1l_opy_