# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from _pytest import fixtures
from _pytest.python import _call_with_optional_argument
from pytest import Module, Class
from bstack_utils.helper import Result, bstack111lll1ll11_opy_
from browserstack_sdk.bstack1l11l1ll1l_opy_ import bstack1111l11l_opy_
def _111l1ll1lll_opy_(method, this, arg):
    arg_count = method.__code__.co_argcount
    if arg_count > 1:
        method(this, arg)
    else:
        method(this)
class bstack111l1lllll1_opy_:
    def __init__(self, handler):
        self._111ll1111l1_opy_ = {}
        self._111l1llllll_opy_ = {}
        self.handler = handler
        self.patch()
        pass
    def patch(self):
        pytest_version = bstack1111l11l_opy_.version()
        if bstack111lll1ll11_opy_(pytest_version, bstack1l11_opy_ (u"ࠣ࠺࠱࠵࠳࠷ࠢᶥ")) >= 0:
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶦ")] = Module._register_setup_function_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠪࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠫᶧ")] = Module._register_setup_module_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠫࡨࡲࡡࡴࡵࡢࡪ࡮ࡾࡴࡶࡴࡨࠫᶨ")] = Class._register_setup_class_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ᶩ")] = Class._register_setup_method_fixture
            Module._register_setup_function_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᶪ"))
            Module._register_setup_module_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠧ࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨᶫ"))
            Class._register_setup_class_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠨࡥ࡯ࡥࡸࡹ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨᶬ"))
            Class._register_setup_method_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࠪᶭ"))
        else:
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ᶮ")] = Module._inject_setup_function_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠫࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶯ")] = Module._inject_setup_module_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"ࠬࡩ࡬ࡢࡵࡶࡣ࡫࡯ࡸࡵࡷࡵࡩࠬᶰ")] = Class._inject_setup_class_fixture
            self._111ll1111l1_opy_[bstack1l11_opy_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࠧᶱ")] = Class._inject_setup_method_fixture
            Module._inject_setup_function_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠪᶲ"))
            Module._inject_setup_module_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠨ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᶳ"))
            Class._inject_setup_class_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠩࡦࡰࡦࡹࡳࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᶴ"))
            Class._inject_setup_method_fixture = self.bstack111l1llll1l_opy_(bstack1l11_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪ࡮ࡾࡴࡶࡴࡨࠫᶵ"))
    def bstack111l1llll11_opy_(self, bstack111ll1111ll_opy_, hook_type):
        bstack111l1lll1ll_opy_ = id(bstack111ll1111ll_opy_.__class__)
        if (bstack111l1lll1ll_opy_, hook_type) in self._111l1llllll_opy_:
            return
        meth = getattr(bstack111ll1111ll_opy_, hook_type, None)
        if meth is not None and fixtures.getfixturemarker(meth) is None:
            self._111l1llllll_opy_[(bstack111l1lll1ll_opy_, hook_type)] = meth
            setattr(bstack111ll1111ll_opy_, hook_type, self.bstack111l1ll1ll1_opy_(hook_type, bstack111l1lll1ll_opy_))
    def bstack111l1ll1l1l_opy_(self, instance, bstack111ll11111l_opy_):
        if bstack111ll11111l_opy_ == bstack1l11_opy_ (u"ࠦ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠢᶶ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠧࡹࡥࡵࡷࡳࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠨᶷ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠨࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࠥᶸ"))
        if bstack111ll11111l_opy_ == bstack1l11_opy_ (u"ࠢ࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠣᶹ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠣࡵࡨࡸࡺࡶ࡟࡮ࡱࡧࡹࡱ࡫ࠢᶺ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࠦᶻ"))
        if bstack111ll11111l_opy_ == bstack1l11_opy_ (u"ࠥࡧࡱࡧࡳࡴࡡࡩ࡭ࡽࡺࡵࡳࡧࠥᶼ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࡢࡧࡱࡧࡳࡴࠤᶽ"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴ࡟ࡤ࡮ࡤࡷࡸࠨᶾ"))
        if bstack111ll11111l_opy_ == bstack1l11_opy_ (u"ࠨ࡭ࡦࡶ࡫ࡳࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࠢᶿ"):
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠢࡴࡧࡷࡹࡵࡥ࡭ࡦࡶ࡫ࡳࡩࠨ᷀"))
            self.bstack111l1llll11_opy_(instance.obj, bstack1l11_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡱࡪࡺࡨࡰࡦࠥ᷁"))
    @staticmethod
    def bstack111l1lll11l_opy_(hook_type, func, args):
        if hook_type in [bstack1l11_opy_ (u"ࠩࡶࡩࡹࡻࡰࡠ࡯ࡨࡸ࡭ࡵࡤࠨ᷂"), bstack1l11_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳࡥࡵࡪࡲࡨࠬ᷃")]:
            _111l1ll1lll_opy_(func, args[0], args[1])
            return
        _call_with_optional_argument(func, args[0])
    def bstack111l1ll1ll1_opy_(self, hook_type, bstack111l1lll1ll_opy_):
        def bstack111ll111111_opy_(arg=None):
            self.handler(hook_type, bstack1l11_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࠫ᷄"))
            result = None
            try:
                bstack1llll1ll111_opy_ = self._111l1llllll_opy_[(bstack111l1lll1ll_opy_, hook_type)]
                self.bstack111l1lll11l_opy_(hook_type, bstack1llll1ll111_opy_, (arg,))
                result = Result(result=bstack1l11_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬ᷅"))
            except Exception as e:
                result = Result(result=bstack1l11_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭᷆"), exception=e)
                self.handler(hook_type, bstack1l11_opy_ (u"ࠧࡢࡨࡷࡩࡷ࠭᷇"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l11_opy_ (u"ࠨࡣࡩࡸࡪࡸࠧ᷈"), result)
        def bstack111l1lll1l1_opy_(this, arg=None):
            self.handler(hook_type, bstack1l11_opy_ (u"ࠩࡥࡩ࡫ࡵࡲࡦࠩ᷉"))
            result = None
            exception = None
            try:
                self.bstack111l1lll11l_opy_(hook_type, self._111l1llllll_opy_[hook_type], (this, arg))
                result = Result(result=bstack1l11_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦ᷊ࠪ"))
            except Exception as e:
                result = Result(result=bstack1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ᷋"), exception=e)
                self.handler(hook_type, bstack1l11_opy_ (u"ࠬࡧࡦࡵࡧࡵࠫ᷌"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l11_opy_ (u"࠭ࡡࡧࡶࡨࡶࠬ᷍"), result)
        if hook_type in [bstack1l11_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥ࡭ࡦࡶ࡫ࡳࡩ᷎࠭"), bstack1l11_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡱࡪࡺࡨࡰࡦ᷏ࠪ")]:
            return bstack111l1lll1l1_opy_
        return bstack111ll111111_opy_
    def bstack111l1llll1l_opy_(self, bstack111ll11111l_opy_):
        def bstack111ll111l11_opy_(this, *args, **kwargs):
            self.bstack111l1ll1l1l_opy_(this, bstack111ll11111l_opy_)
            self._111ll1111l1_opy_[bstack111ll11111l_opy_](this, *args, **kwargs)
        return bstack111ll111l11_opy_