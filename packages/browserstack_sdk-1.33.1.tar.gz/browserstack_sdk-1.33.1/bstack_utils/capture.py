# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import builtins
import logging
class bstack111l1ll1ll_opy_:
    def __init__(self, handler):
        self._11l1lllll1l_opy_ = builtins.print
        self.handler = handler
        self._started = False
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        self._11l1llll1l1_opy_ = {
            level: getattr(self.logger, level)
            for level in [bstack1l11_opy_ (u"ࠧࡪࡰࡩࡳࠬហ"), bstack1l11_opy_ (u"ࠨࡦࡨࡦࡺ࡭ࠧឡ"), bstack1l11_opy_ (u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࠪអ"), bstack1l11_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩឣ")]
        }
    def start(self):
        if self._started:
            return
        self._started = True
        builtins.print = self._11l1lllll11_opy_
        self._11l1lllllll_opy_()
    def _11l1lllll11_opy_(self, *args, **kwargs):
        self._11l1lllll1l_opy_(*args, **kwargs)
        message = bstack1l11_opy_ (u"ࠫࠥ࠭ឤ").join(map(str, args)) + bstack1l11_opy_ (u"ࠬࡢ࡮ࠨឥ")
        self._log_message(bstack1l11_opy_ (u"࠭ࡉࡏࡈࡒࠫឦ"), message)
    def _log_message(self, level, msg, *args, **kwargs):
        if self.handler:
            self.handler({bstack1l11_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ឧ"): level, bstack1l11_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩឨ"): msg})
    def _11l1lllllll_opy_(self):
        for level, bstack11l1llll1ll_opy_ in self._11l1llll1l1_opy_.items():
            setattr(logging, level, self._11l1llllll1_opy_(level, bstack11l1llll1ll_opy_))
    def _11l1llllll1_opy_(self, level, bstack11l1llll1ll_opy_):
        def wrapper(msg, *args, **kwargs):
            bstack11l1llll1ll_opy_(msg, *args, **kwargs)
            self._log_message(level.upper(), msg)
        return wrapper
    def reset(self):
        if not self._started:
            return
        self._started = False
        builtins.print = self._11l1lllll1l_opy_
        for level, bstack11l1llll1ll_opy_ in self._11l1llll1l1_opy_.items():
            setattr(logging, level, bstack11l1llll1ll_opy_)