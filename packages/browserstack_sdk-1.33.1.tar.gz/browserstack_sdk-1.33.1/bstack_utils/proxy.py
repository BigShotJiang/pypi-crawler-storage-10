# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.config import Config
from bstack_utils.messages import bstack111l11ll1ll_opy_
bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
def bstack1llllll1llll_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1lllllll1l1l_opy_(bstack1lllllll111l_opy_, bstack1lllllll1l11_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1lllllll111l_opy_):
        with open(bstack1lllllll111l_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1llllll1llll_opy_(bstack1lllllll111l_opy_):
        pac = get_pac(url=bstack1lllllll111l_opy_)
    else:
        raise Exception(bstack1l11_opy_ (u"ࠫࡕࡧࡣࠡࡨ࡬ࡰࡪࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡧࡻ࡭ࡸࡺ࠺ࠡࡽࢀࠫᾒ").format(bstack1lllllll111l_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1l11_opy_ (u"ࠧ࠾࠮࠹࠰࠻࠲࠽ࠨᾓ"), 80))
        bstack1lllllll1111_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1lllllll1111_opy_ = bstack1l11_opy_ (u"࠭࠰࠯࠲࠱࠴࠳࠶ࠧᾔ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1lllllll1l11_opy_, bstack1lllllll1111_opy_)
    return proxy_url
def bstack111lll11l_opy_(config):
    return bstack1l11_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪᾕ") in config or bstack1l11_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬᾖ") in config
def bstack1ll1ll111_opy_(config):
    if not bstack111lll11l_opy_(config):
        return
    if config.get(bstack1l11_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬᾗ")):
        return config.get(bstack1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭ᾘ"))
    if config.get(bstack1l11_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨᾙ")):
        return config.get(bstack1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩᾚ"))
def bstack111lll1l1_opy_(config, bstack1lllllll1l11_opy_):
    proxy = bstack1ll1ll111_opy_(config)
    proxies = {}
    if config.get(bstack1l11_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩᾛ")) or config.get(bstack1l11_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫᾜ")):
        if proxy.endswith(bstack1l11_opy_ (u"ࠨ࠰ࡳࡥࡨ࠭ᾝ")):
            proxies = bstack11lll11lll_opy_(proxy, bstack1lllllll1l11_opy_)
        else:
            proxies = {
                bstack1l11_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨᾞ"): proxy
            }
    bstack11l1l111ll_opy_.bstack11l11ll111_opy_(bstack1l11_opy_ (u"ࠪࡴࡷࡵࡸࡺࡕࡨࡸࡹ࡯࡮ࡨࡵࠪᾟ"), proxies)
    return proxies
def bstack11lll11lll_opy_(bstack1lllllll111l_opy_, bstack1lllllll1l11_opy_):
    proxies = {}
    global bstack1lllllll11ll_opy_
    if bstack1l11_opy_ (u"ࠫࡕࡇࡃࡠࡒࡕࡓ࡝࡟ࠧᾠ") in globals():
        return bstack1lllllll11ll_opy_
    try:
        proxy = bstack1lllllll1l1l_opy_(bstack1lllllll111l_opy_, bstack1lllllll1l11_opy_)
        if bstack1l11_opy_ (u"ࠧࡊࡉࡓࡇࡆࡘࠧᾡ") in proxy:
            proxies = {}
        elif bstack1l11_opy_ (u"ࠨࡈࡕࡖࡓࠦᾢ") in proxy or bstack1l11_opy_ (u"ࠢࡉࡖࡗࡔࡘࠨᾣ") in proxy or bstack1l11_opy_ (u"ࠣࡕࡒࡇࡐ࡙ࠢᾤ") in proxy:
            bstack1lllllll11l1_opy_ = proxy.split(bstack1l11_opy_ (u"ࠤࠣࠦᾥ"))
            if bstack1l11_opy_ (u"ࠥ࠾࠴࠵ࠢᾦ") in bstack1l11_opy_ (u"ࠦࠧᾧ").join(bstack1lllllll11l1_opy_[1:]):
                proxies = {
                    bstack1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫᾨ"): bstack1l11_opy_ (u"ࠨࠢᾩ").join(bstack1lllllll11l1_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l11_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭ᾪ"): str(bstack1lllllll11l1_opy_[0]).lower() + bstack1l11_opy_ (u"ࠣ࠼࠲࠳ࠧᾫ") + bstack1l11_opy_ (u"ࠤࠥᾬ").join(bstack1lllllll11l1_opy_[1:])
                }
        elif bstack1l11_opy_ (u"ࠥࡔࡗࡕࡘ࡚ࠤᾭ") in proxy:
            bstack1lllllll11l1_opy_ = proxy.split(bstack1l11_opy_ (u"ࠦࠥࠨᾮ"))
            if bstack1l11_opy_ (u"ࠧࡀ࠯࠰ࠤᾯ") in bstack1l11_opy_ (u"ࠨࠢᾰ").join(bstack1lllllll11l1_opy_[1:]):
                proxies = {
                    bstack1l11_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭ᾱ"): bstack1l11_opy_ (u"ࠣࠤᾲ").join(bstack1lllllll11l1_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l11_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨᾳ"): bstack1l11_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦᾴ") + bstack1l11_opy_ (u"ࠦࠧ᾵").join(bstack1lllllll11l1_opy_[1:])
                }
        else:
            proxies = {
                bstack1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫᾶ"): proxy
            }
    except Exception as e:
        print(bstack1l11_opy_ (u"ࠨࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠥᾷ"), bstack111l11ll1ll_opy_.format(bstack1lllllll111l_opy_, str(e)))
    bstack1lllllll11ll_opy_ = proxies
    return proxies