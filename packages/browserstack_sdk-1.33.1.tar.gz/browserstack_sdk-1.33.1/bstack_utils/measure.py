# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import logging
from functools import wraps
from typing import Optional
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.bstack1l111llll_opy_ import get_logger
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
bstack1l11l1ll11_opy_ = bstack1ll1l1l11l1_opy_()
logger = get_logger(__name__)
def measure(event_name: EVENTS, stage: STAGE, hook_type: Optional[str] = None, bstack11l11l1l1_opy_: Optional[str] = None):
    bstack1l11_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡄࡦࡥࡲࡶࡦࡺ࡯ࡳࠢࡷࡳࠥࡲ࡯ࡨࠢࡷ࡬ࡪࠦࡳࡵࡣࡵࡸࠥࡺࡩ࡮ࡧࠣࡳ࡫ࠦࡡࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡩࡽ࡫ࡣࡶࡶ࡬ࡳࡳࠐࠠࠡࠢࠣࡥࡱࡵ࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡦࡸࡨࡲࡹࠦ࡮ࡢ࡯ࡨࠤࡦࡴࡤࠡࡵࡷࡥ࡬࡫࠮ࠋࠢࠣࠤࠥࠨࠢࠣḓ")
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            label: str = event_name.value
            bstack1ll11ll11l1_opy_: str = bstack1l11l1ll11_opy_.bstack11ll1ll1111_opy_(label)
            start_mark: str = label + bstack1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢḔ")
            end_mark: str = label + bstack1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨḕ")
            result = None
            try:
                if stage.value == STAGE.bstack11l11l1lll_opy_.value:
                    bstack1l11l1ll11_opy_.mark(start_mark)
                    result = func(*args, **kwargs)
                elif stage.value == STAGE.END.value:
                    result = func(*args, **kwargs)
                    bstack1l11l1ll11_opy_.end(label, start_mark, end_mark, status=True, failure=None,hook_type=hook_type,test_name=bstack11l11l1l1_opy_)
                elif stage.value == STAGE.bstack1l11l1ll_opy_.value:
                    start_mark: str = bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤḖ")
                    end_mark: str = bstack1ll11ll11l1_opy_ + bstack1l11_opy_ (u"ࠥ࠾ࡪࡴࡤࠣḗ")
                    bstack1l11l1ll11_opy_.mark(start_mark)
                    result = func(*args, **kwargs)
                    bstack1l11l1ll11_opy_.end(label, start_mark, end_mark, status=True, failure=None, hook_type=hook_type,test_name=bstack11l11l1l1_opy_)
            except Exception as e:
                bstack1l11l1ll11_opy_.end(label, start_mark, end_mark, status=False, failure=str(e), hook_type=hook_type,
                                       test_name=bstack11l11l1l1_opy_)
            return result
        return wrapper
    return decorator