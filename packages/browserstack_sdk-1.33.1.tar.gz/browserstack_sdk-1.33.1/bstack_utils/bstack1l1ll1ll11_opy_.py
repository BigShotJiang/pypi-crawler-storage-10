# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import re
from bstack_utils.bstack11ll1l111l_opy_ import bstack1llllll11lll_opy_
def bstack1llllll11l1l_opy_(fixture_name):
    if fixture_name.startswith(bstack1l11_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᾸ")):
        return bstack1l11_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩᾹ")
    elif fixture_name.startswith(bstack1l11_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡶࡩࡹࡻࡰࡠ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᾺ")):
        return bstack1l11_opy_ (u"ࠪࡷࡪࡺࡵࡱ࠯ࡰࡳࡩࡻ࡬ࡦࠩΆ")
    elif fixture_name.startswith(bstack1l11_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩᾼ")):
        return bstack1l11_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ᾽")
    elif fixture_name.startswith(bstack1l11_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠫι")):
        return bstack1l11_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡰࡳࡩࡻ࡬ࡦࠩ᾿")
def bstack1llllll1lll1_opy_(fixture_name):
    return bool(re.match(bstack1l11_opy_ (u"ࠨࡠࡢࡼࡺࡴࡩࡵࡡࠫࡷࡪࡺࡵࡱࡾࡷࡩࡦࡸࡤࡰࡹࡱ࠭ࡤ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡽ࡯ࡲࡨࡺࡲࡥࠪࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭῀"), fixture_name))
def bstack1llllll1ll1l_opy_(fixture_name):
    return bool(re.match(bstack1l11_opy_ (u"ࠩࡡࡣࡽࡻ࡮ࡪࡶࡢࠬࡸ࡫ࡴࡶࡲࡿࡸࡪࡧࡲࡥࡱࡺࡲ࠮ࡥ࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫࡟࠯ࠬࠪ῁"), fixture_name))
def bstack1llllll111l1_opy_(fixture_name):
    return bool(re.match(bstack1l11_opy_ (u"ࠪࡢࡤࡾࡵ࡯࡫ࡷࡣ࠭ࡹࡥࡵࡷࡳࢀࡹ࡫ࡡࡳࡦࡲࡻࡳ࠯࡟ࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫࡟࠯ࠬࠪῂ"), fixture_name))
def bstack1llllll11l11_opy_(fixture_name):
    if fixture_name.startswith(bstack1l11_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡸ࡫ࡴࡶࡲࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ῃ")):
        return bstack1l11_opy_ (u"ࠬࡹࡥࡵࡷࡳ࠱࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ῄ"), bstack1l11_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫ῅")
    elif fixture_name.startswith(bstack1l11_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥ࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫ࠧῆ")):
        return bstack1l11_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭࡮ࡱࡧࡹࡱ࡫ࠧῇ"), bstack1l11_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡄࡐࡑ࠭Ὲ")
    elif fixture_name.startswith(bstack1l11_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨΈ")):
        return bstack1l11_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠳ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨῊ"), bstack1l11_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠩΉ")
    elif fixture_name.startswith(bstack1l11_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩῌ")):
        return bstack1l11_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡰࡳࡩࡻ࡬ࡦࠩ῍"), bstack1l11_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡂࡎࡏࠫ῎")
    return None, None
def bstack1llllll1ll11_opy_(hook_name):
    if hook_name in [bstack1l11_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ῏"), bstack1l11_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࠬῐ")]:
        return hook_name.capitalize()
    return hook_name
def bstack1llllll1111l_opy_(hook_name):
    if hook_name in [bstack1l11_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࠬῑ"), bstack1l11_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠫῒ")]:
        return bstack1l11_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫΐ")
    elif hook_name in [bstack1l11_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥ࡭ࡰࡦࡸࡰࡪ࠭῔"), bstack1l11_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟ࡤ࡮ࡤࡷࡸ࠭῕")]:
        return bstack1l11_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡄࡐࡑ࠭ῖ")
    elif hook_name in [bstack1l11_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧῗ"), bstack1l11_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩ࠭Ῐ")]:
        return bstack1l11_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠩῙ")
    elif hook_name in [bstack1l11_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨῚ"), bstack1l11_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡦࡰࡦࡹࡳࠨΊ")]:
        return bstack1l11_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡂࡎࡏࠫ῜")
    return hook_name
def bstack1llllll111ll_opy_(node, scenario):
    if hasattr(node, bstack1l11_opy_ (u"ࠩࡦࡥࡱࡲࡳࡱࡧࡦࠫ῝")):
        parts = node.nodeid.rsplit(bstack1l11_opy_ (u"ࠥ࡟ࠧ῞"))
        params = parts[-1]
        return bstack1l11_opy_ (u"ࠦࢀࢃࠠ࡜ࡽࢀࠦ῟").format(scenario.name, params)
    return scenario.name
def bstack1llllll11ll1_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack1l11_opy_ (u"ࠬࡩࡡ࡭࡮ࡶࡴࡪࡩࠧῠ")):
            examples = list(node.callspec.params[bstack1l11_opy_ (u"࠭࡟ࡱࡻࡷࡩࡸࡺ࡟ࡣࡦࡧࡣࡪࡾࡡ࡮ࡲ࡯ࡩࠬῡ")].values())
        return examples
    except:
        return []
def bstack1llllll1l1ll_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack1llllll1l1l1_opy_(report):
    try:
        status = bstack1l11_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧῢ")
        if report.passed or (report.failed and hasattr(report, bstack1l11_opy_ (u"ࠣࡹࡤࡷࡽ࡬ࡡࡪ࡮ࠥΰ"))):
            status = bstack1l11_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩῤ")
        elif report.skipped:
            status = bstack1l11_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫῥ")
        bstack1llllll11lll_opy_(status)
    except:
        pass
def bstack1ll1l11l1_opy_(status):
    try:
        bstack1llllll1l111_opy_ = bstack1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫῦ")
        if status == bstack1l11_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬῧ"):
            bstack1llllll1l111_opy_ = bstack1l11_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭Ῠ")
        elif status == bstack1l11_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨῩ"):
            bstack1llllll1l111_opy_ = bstack1l11_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩῪ")
        bstack1llllll11lll_opy_(bstack1llllll1l111_opy_)
    except:
        pass
def bstack1llllll1l11l_opy_(item=None, report=None, summary=None, extra=None):
    return