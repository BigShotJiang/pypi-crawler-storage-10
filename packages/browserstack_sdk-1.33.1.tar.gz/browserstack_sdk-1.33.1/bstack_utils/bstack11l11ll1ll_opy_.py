# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
class bstack1ll1l1ll11_opy_:
    def __init__(self, handler):
        self._1lllll11l1l1_opy_ = None
        self.handler = handler
        self._1lllll11l11l_opy_ = self.bstack1lllll11l111_opy_()
        self.patch()
    def patch(self):
        self._1lllll11l1l1_opy_ = self._1lllll11l11l_opy_.execute
        self._1lllll11l11l_opy_.execute = self.bstack1lllll11l1ll_opy_()
    def bstack1lllll11l1ll_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1l11_opy_ (u"ࠧࡨࡥࡧࡱࡵࡩࠧ※"), driver_command, None, this, args)
            response = self._1lllll11l1l1_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1l11_opy_ (u"ࠨࡡࡧࡶࡨࡶࠧ‼"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._1lllll11l11l_opy_.execute = self._1lllll11l1l1_opy_
    @staticmethod
    def bstack1lllll11l111_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver