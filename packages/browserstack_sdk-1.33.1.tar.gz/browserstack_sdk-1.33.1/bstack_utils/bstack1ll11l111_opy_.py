# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from time import sleep
from datetime import datetime
from urllib.parse import urlencode
from bstack_utils.bstack11ll111111l_opy_ import bstack11ll11111ll_opy_
from bstack_utils.constants import *
import json
class bstack11llll11l_opy_:
    def __init__(self, bstack111ll111_opy_, bstack11ll11111l1_opy_):
        self.bstack111ll111_opy_ = bstack111ll111_opy_
        self.bstack11ll11111l1_opy_ = bstack11ll11111l1_opy_
        self.bstack11ll1111ll1_opy_ = None
    def __call__(self):
        bstack11ll1111lll_opy_ = {}
        while True:
            self.bstack11ll1111ll1_opy_ = bstack11ll1111lll_opy_.get(
                bstack1l11_opy_ (u"ࠩࡱࡩࡽࡺ࡟ࡱࡱ࡯ࡰࡤࡺࡩ࡮ࡧࠪឍ"),
                int(datetime.now().timestamp() * 1000)
            )
            bstack11ll111l111_opy_ = self.bstack11ll1111ll1_opy_ - int(datetime.now().timestamp() * 1000)
            if bstack11ll111l111_opy_ > 0:
                sleep(bstack11ll111l111_opy_ / 1000)
            params = {
                bstack1l11_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪណ"): self.bstack111ll111_opy_,
                bstack1l11_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧត"): int(datetime.now().timestamp() * 1000)
            }
            bstack11ll1111l11_opy_ = bstack1l11_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠢថ") + bstack11ll1111111_opy_ + bstack1l11_opy_ (u"ࠨ࠯ࡢࡷࡷࡳࡲࡧࡴࡦ࠱ࡤࡴ࡮࠵ࡶ࠲࠱ࠥទ")
            if self.bstack11ll11111l1_opy_.lower() == bstack1l11_opy_ (u"ࠢࡳࡧࡶࡹࡱࡺࡳࠣធ"):
                bstack11ll1111lll_opy_ = bstack11ll11111ll_opy_.results(bstack11ll1111l11_opy_, params)
            else:
                bstack11ll1111lll_opy_ = bstack11ll11111ll_opy_.bstack11ll1111l1l_opy_(bstack11ll1111l11_opy_, params)
            if str(bstack11ll1111lll_opy_.get(bstack1l11_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨន"), bstack1l11_opy_ (u"ࠩ࠵࠴࠵࠭ប"))) != bstack1l11_opy_ (u"ࠪ࠸࠵࠺ࠧផ"):
                break
        return bstack11ll1111lll_opy_.get(bstack1l11_opy_ (u"ࠫࡩࡧࡴࡢࠩព"), bstack11ll1111lll_opy_)