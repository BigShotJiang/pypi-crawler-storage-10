# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import json
from bstack_utils.bstack1l111llll_opy_ import get_logger
logger = get_logger(__name__)
class bstack11ll111ll1l_opy_(object):
  bstack1l111lll11_opy_ = os.path.join(os.path.expanduser(bstack1l11_opy_ (u"ࠫࢃ࠭ᝬ")), bstack1l11_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ᝭"))
  bstack11ll111l1ll_opy_ = os.path.join(bstack1l111lll11_opy_, bstack1l11_opy_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡳ࠯࡬ࡶࡳࡳ࠭ᝮ"))
  commands_to_wrap = None
  perform_scan = None
  bstack11llll1l11_opy_ = None
  bstack11llll111l_opy_ = None
  bstack11ll11l1lll_opy_ = None
  bstack11ll11l1l11_opy_ = None
  def __new__(cls):
    if not hasattr(cls, bstack1l11_opy_ (u"ࠧࡪࡰࡶࡸࡦࡴࡣࡦࠩᝯ")):
      cls.instance = super(bstack11ll111ll1l_opy_, cls).__new__(cls)
      cls.instance.bstack11ll111lll1_opy_()
    return cls.instance
  def bstack11ll111lll1_opy_(self):
    try:
      with open(self.bstack11ll111l1ll_opy_, bstack1l11_opy_ (u"ࠨࡴࠪᝰ")) as bstack1l1lll1l1_opy_:
        bstack11ll111ll11_opy_ = bstack1l1lll1l1_opy_.read()
        data = json.loads(bstack11ll111ll11_opy_)
        if bstack1l11_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶࠫ᝱") in data:
          self.bstack11ll11ll1l1_opy_(data[bstack1l11_opy_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡷࠬᝲ")])
        if bstack1l11_opy_ (u"ࠫࡸࡩࡲࡪࡲࡷࡷࠬᝳ") in data:
          self.bstack1llll11l11_opy_(data[bstack1l11_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸࡸ࠭᝴")])
        if bstack1l11_opy_ (u"࠭࡮ࡰࡰࡅࡗࡹࡧࡣ࡬ࡋࡱࡪࡷࡧࡁ࠲࠳ࡼࡇ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪ᝵") in data:
          self.bstack11ll111llll_opy_(data[bstack1l11_opy_ (u"ࠧ࡯ࡱࡱࡆࡘࡺࡡࡤ࡭ࡌࡲ࡫ࡸࡡࡂ࠳࠴ࡽࡈ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫ᝶")])
    except:
      pass
  def bstack11ll111llll_opy_(self, bstack11ll11l1l11_opy_):
    if bstack11ll11l1l11_opy_ != None:
      self.bstack11ll11l1l11_opy_ = bstack11ll11l1l11_opy_
  def bstack1llll11l11_opy_(self, scripts):
    if scripts != None:
      self.perform_scan = scripts.get(bstack1l11_opy_ (u"ࠨࡵࡦࡥࡳ࠭᝷"),bstack1l11_opy_ (u"ࠩࠪ᝸"))
      self.bstack11llll1l11_opy_ = scripts.get(bstack1l11_opy_ (u"ࠪ࡫ࡪࡺࡒࡦࡵࡸࡰࡹࡹࠧ᝹"),bstack1l11_opy_ (u"ࠫࠬ᝺"))
      self.bstack11llll111l_opy_ = scripts.get(bstack1l11_opy_ (u"ࠬ࡭ࡥࡵࡔࡨࡷࡺࡲࡴࡴࡕࡸࡱࡲࡧࡲࡺࠩ᝻"),bstack1l11_opy_ (u"࠭ࠧ᝼"))
      self.bstack11ll11l1lll_opy_ = scripts.get(bstack1l11_opy_ (u"ࠧࡴࡣࡹࡩࡗ࡫ࡳࡶ࡮ࡷࡷࠬ᝽"),bstack1l11_opy_ (u"ࠨࠩ᝾"))
  def bstack11ll11ll1l1_opy_(self, commands_to_wrap):
    if commands_to_wrap != None and len(commands_to_wrap) != 0:
      self.commands_to_wrap = commands_to_wrap
  def store(self):
    try:
      with open(self.bstack11ll111l1ll_opy_, bstack1l11_opy_ (u"ࠩࡺࠫ᝿")) as file:
        json.dump({
          bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࡷࠧក"): self.commands_to_wrap,
          bstack1l11_opy_ (u"ࠦࡸࡩࡲࡪࡲࡷࡷࠧខ"): {
            bstack1l11_opy_ (u"ࠧࡹࡣࡢࡰࠥគ"): self.perform_scan,
            bstack1l11_opy_ (u"ࠨࡧࡦࡶࡕࡩࡸࡻ࡬ࡵࡵࠥឃ"): self.bstack11llll1l11_opy_,
            bstack1l11_opy_ (u"ࠢࡨࡧࡷࡖࡪࡹࡵ࡭ࡶࡶࡗࡺࡳ࡭ࡢࡴࡼࠦង"): self.bstack11llll111l_opy_,
            bstack1l11_opy_ (u"ࠣࡵࡤࡺࡪࡘࡥࡴࡷ࡯ࡸࡸࠨច"): self.bstack11ll11l1lll_opy_
          },
          bstack1l11_opy_ (u"ࠤࡱࡳࡳࡈࡓࡵࡣࡦ࡯ࡎࡴࡦࡳࡣࡄ࠵࠶ࡿࡃࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸࠨឆ"): self.bstack11ll11l1l11_opy_
        }, file)
    except Exception as e:
      logger.error(bstack1l11_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡࡵࡷࡳࡷ࡯࡮ࡨࠢࡦࡳࡲࡳࡡ࡯ࡦࡶ࠾ࠥࢁࡽࠣជ").format(e))
      pass
  def bstack111lll1l_opy_(self, command_name):
    try:
      return any(command.get(bstack1l11_opy_ (u"ࠫࡳࡧ࡭ࡦࠩឈ")) == command_name for command in self.commands_to_wrap)
    except:
      return False
bstack1lll11l1l1_opy_ = bstack11ll111ll1l_opy_()