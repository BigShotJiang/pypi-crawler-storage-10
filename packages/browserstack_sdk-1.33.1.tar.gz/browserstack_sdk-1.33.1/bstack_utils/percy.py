# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import re
import sys
import json
import time
import shutil
import tempfile
import requests
import subprocess
from threading import Thread
from os.path import expanduser
from bstack_utils.constants import *
from requests.auth import HTTPBasicAuth
from bstack_utils.helper import bstack11l1l1l111_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack1l11l1l1l1_opy_ import bstack1lll1l1l_opy_
class bstack1lll111lll_opy_:
  working_dir = os.getcwd()
  bstack1l111l11ll_opy_ = False
  config = {}
  bstack111ll1l11ll_opy_ = bstack1l11_opy_ (u"ࠨࠩỵ")
  binary_path = bstack1l11_opy_ (u"ࠩࠪỶ")
  bstack1111l11ll11_opy_ = bstack1l11_opy_ (u"ࠪࠫỷ")
  bstack1lllll1l11_opy_ = False
  bstack11111l11ll1_opy_ = None
  bstack11111ll1lll_opy_ = {}
  bstack1111l111lll_opy_ = 300
  bstack1111111llll_opy_ = False
  logger = None
  bstack11111l1l11l_opy_ = False
  bstack1l1l11111l_opy_ = False
  percy_build_id = None
  bstack1111l111ll1_opy_ = bstack1l11_opy_ (u"ࠫࠬỸ")
  bstack11111lll11l_opy_ = {
    bstack1l11_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬỹ") : 1,
    bstack1l11_opy_ (u"࠭ࡦࡪࡴࡨࡪࡴࡾࠧỺ") : 2,
    bstack1l11_opy_ (u"ࠧࡦࡦࡪࡩࠬỻ") : 3,
    bstack1l11_opy_ (u"ࠨࡵࡤࡪࡦࡸࡩࠨỼ") : 4
  }
  def __init__(self) -> None: pass
  def bstack11111l1lll1_opy_(self):
    bstack111111ll111_opy_ = bstack1l11_opy_ (u"ࠩࠪỽ")
    bstack111111ll11l_opy_ = sys.platform
    bstack11111l1ll11_opy_ = bstack1l11_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩỾ")
    if re.match(bstack1l11_opy_ (u"ࠦࡩࡧࡲࡸ࡫ࡱࢀࡲࡧࡣࠡࡱࡶࠦỿ"), bstack111111ll11l_opy_) != None:
      bstack111111ll111_opy_ = bstack11l1lll111l_opy_ + bstack1l11_opy_ (u"ࠧ࠵ࡰࡦࡴࡦࡽ࠲ࡵࡳࡹ࠰ࡽ࡭ࡵࠨἀ")
      self.bstack1111l111ll1_opy_ = bstack1l11_opy_ (u"࠭࡭ࡢࡥࠪἁ")
    elif re.match(bstack1l11_opy_ (u"ࠢ࡮ࡵࡺ࡭ࡳࢂ࡭ࡴࡻࡶࢀࡲ࡯࡮ࡨࡹࡿࡧࡾ࡭ࡷࡪࡰࡿࡦࡨࡩࡷࡪࡰࡿࡻ࡮ࡴࡣࡦࡾࡨࡱࡨࢂࡷࡪࡰ࠶࠶ࠧἂ"), bstack111111ll11l_opy_) != None:
      bstack111111ll111_opy_ = bstack11l1lll111l_opy_ + bstack1l11_opy_ (u"ࠣ࠱ࡳࡩࡷࡩࡹ࠮ࡹ࡬ࡲ࠳ࢀࡩࡱࠤἃ")
      bstack11111l1ll11_opy_ = bstack1l11_opy_ (u"ࠤࡳࡩࡷࡩࡹ࠯ࡧࡻࡩࠧἄ")
      self.bstack1111l111ll1_opy_ = bstack1l11_opy_ (u"ࠪࡻ࡮ࡴࠧἅ")
    else:
      bstack111111ll111_opy_ = bstack11l1lll111l_opy_ + bstack1l11_opy_ (u"ࠦ࠴ࡶࡥࡳࡥࡼ࠱ࡱ࡯࡮ࡶࡺ࠱ࡾ࡮ࡶࠢἆ")
      self.bstack1111l111ll1_opy_ = bstack1l11_opy_ (u"ࠬࡲࡩ࡯ࡷࡻࠫἇ")
    return bstack111111ll111_opy_, bstack11111l1ll11_opy_
  def bstack111111l1l1l_opy_(self):
    try:
      bstack11111l1ll1l_opy_ = [os.path.join(expanduser(bstack1l11_opy_ (u"ࠨࡾࠣἈ")), bstack1l11_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧἉ")), self.working_dir, tempfile.gettempdir()]
      for path in bstack11111l1ll1l_opy_:
        if(self.bstack111111l11ll_opy_(path)):
          return path
      raise bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠧἊ")
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡬ࡩ࡯ࡦࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡࡲࡨࡶࡨࡿࠠࡥࡱࡺࡲࡱࡵࡡࡥ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦ࠭ࠡࡽࢀࠦἋ").format(e))
  def bstack111111l11ll_opy_(self, path):
    try:
      if not os.path.exists(path):
        os.makedirs(path)
      return True
    except:
      return False
  def bstack111111l1ll1_opy_(self, bstack11111l11111_opy_):
    return os.path.join(bstack11111l11111_opy_, self.bstack111ll1l11ll_opy_ + bstack1l11_opy_ (u"ࠥ࠲ࡪࡺࡡࡨࠤἌ"))
  def bstack111111l1111_opy_(self, bstack11111l11111_opy_, bstack11111ll111l_opy_):
    if not bstack11111ll111l_opy_: return
    try:
      bstack1111l11111l_opy_ = self.bstack111111l1ll1_opy_(bstack11111l11111_opy_)
      with open(bstack1111l11111l_opy_, bstack1l11_opy_ (u"ࠦࡼࠨἍ")) as f:
        f.write(bstack11111ll111l_opy_)
        self.logger.debug(bstack1l11_opy_ (u"࡙ࠧࡡࡷࡧࡧࠤࡳ࡫ࡷࠡࡇࡗࡥ࡬ࠦࡦࡰࡴࠣࡴࡪࡸࡣࡺࠤἎ"))
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡶࡥࡻ࡫ࠠࡵࡪࡨࠤࡪࡺࡡࡨ࠮ࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨἏ").format(e))
  def bstack11111ll1l1l_opy_(self, bstack11111l11111_opy_):
    try:
      bstack1111l11111l_opy_ = self.bstack111111l1ll1_opy_(bstack11111l11111_opy_)
      if os.path.exists(bstack1111l11111l_opy_):
        with open(bstack1111l11111l_opy_, bstack1l11_opy_ (u"ࠢࡳࠤἐ")) as f:
          bstack11111ll111l_opy_ = f.read().strip()
          return bstack11111ll111l_opy_ if bstack11111ll111l_opy_ else None
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡ࡮ࡲࡥࡩ࡯࡮ࡨࠢࡈࡘࡦ࡭ࠬࠡࡧࡵࡶࡴࡸ࠺ࠡࡽࢀࠦἑ").format(e))
  def bstack1111l1111ll_opy_(self, bstack11111l11111_opy_, bstack111111ll111_opy_):
    bstack11111l1111l_opy_ = self.bstack11111ll1l1l_opy_(bstack11111l11111_opy_)
    if bstack11111l1111l_opy_:
      try:
        bstack111111l1lll_opy_ = self.bstack11111ll1l11_opy_(bstack11111l1111l_opy_, bstack111111ll111_opy_)
        if not bstack111111l1lll_opy_:
          self.logger.debug(bstack1l11_opy_ (u"ࠤࡓࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠡ࡫ࡶࠤࡺࡶࠠࡵࡱࠣࡨࡦࡺࡥࠡࠪࡈࡘࡦ࡭ࠠࡶࡰࡦ࡬ࡦࡴࡧࡦࡦࠬࠦἒ"))
          return True
        self.logger.debug(bstack1l11_opy_ (u"ࠥࡒࡪࡽࠠࡑࡧࡵࡧࡾࠦࡢࡪࡰࡤࡶࡾࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧ࠯ࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡸࡴࡩࡧࡴࡦࠤἓ"))
        return False
      except Exception as e:
        self.logger.warn(bstack1l11_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡤࡪࡨࡧࡰࠦࡦࡰࡴࠣࡦ࡮ࡴࡡࡳࡻࠣࡹࡵࡪࡡࡵࡧࡶ࠰ࠥࡻࡳࡪࡰࡪࠤࡪࡾࡩࡴࡶ࡬ࡲ࡬ࠦࡢࡪࡰࡤࡶࡾࡀࠠࡼࡿࠥἔ").format(e))
    return False
  def bstack11111ll1l11_opy_(self, bstack11111l1111l_opy_, bstack111111ll111_opy_):
    try:
      headers = {
        bstack1l11_opy_ (u"ࠧࡏࡦ࠮ࡐࡲࡲࡪ࠳ࡍࡢࡶࡦ࡬ࠧἕ"): bstack11111l1111l_opy_
      }
      response = bstack11l1l1l111_opy_(bstack1l11_opy_ (u"࠭ࡇࡆࡖࠪ἖"), bstack111111ll111_opy_, {}, {bstack1l11_opy_ (u"ࠢࡩࡧࡤࡨࡪࡸࡳࠣ἗"): headers})
      if response.status_code == 304:
        return False
      return True
    except Exception as e:
      raise(bstack1l11_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡤࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡐࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥࡻࡰࡥࡣࡷࡩࡸࡀࠠࡼࡿࠥἘ").format(e))
  @measure(event_name=EVENTS.bstack11l1l1ll11l_opy_, stage=STAGE.bstack1l11l1ll_opy_)
  def bstack11111ll1ll1_opy_(self, bstack111111ll111_opy_, bstack11111l1ll11_opy_):
    try:
      bstack11111l1llll_opy_ = self.bstack111111l1l1l_opy_()
      bstack111111ll1ll_opy_ = os.path.join(bstack11111l1llll_opy_, bstack1l11_opy_ (u"ࠩࡳࡩࡷࡩࡹ࠯ࡼ࡬ࡴࠬἙ"))
      bstack111111l11l1_opy_ = os.path.join(bstack11111l1llll_opy_, bstack11111l1ll11_opy_)
      if self.bstack1111l1111ll_opy_(bstack11111l1llll_opy_, bstack111111ll111_opy_): # if bstack111111l111l_opy_, bstack1l1l11l111l_opy_ bstack11111ll111l_opy_ is bstack111111l1l11_opy_ to bstack111lllll1l1_opy_ version available (response 304)
        if os.path.exists(bstack111111l11l1_opy_):
          self.logger.info(bstack1l11_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࢀࢃࠬࠡࡵ࡮࡭ࡵࡶࡩ࡯ࡩࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠧἚ").format(bstack111111l11l1_opy_))
          return bstack111111l11l1_opy_
        if os.path.exists(bstack111111ll1ll_opy_):
          self.logger.info(bstack1l11_opy_ (u"ࠦࡕ࡫ࡲࡤࡻࠣࡾ࡮ࡶࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡾࢁ࠱ࠦࡵ࡯ࡼ࡬ࡴࡵ࡯࡮ࡨࠤἛ").format(bstack111111ll1ll_opy_))
          return self.bstack11111ll11l1_opy_(bstack111111ll1ll_opy_, bstack11111l1ll11_opy_)
      self.logger.info(bstack1l11_opy_ (u"ࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡴࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺࠢࡩࡶࡴࡳࠠࡼࡿࠥἜ").format(bstack111111ll111_opy_))
      response = bstack11l1l1l111_opy_(bstack1l11_opy_ (u"࠭ࡇࡆࡖࠪἝ"), bstack111111ll111_opy_, {}, {})
      if response.status_code == 200:
        bstack1111l111111_opy_ = response.headers.get(bstack1l11_opy_ (u"ࠢࡆࡖࡤ࡫ࠧ἞"), bstack1l11_opy_ (u"ࠣࠤ἟"))
        if bstack1111l111111_opy_:
          self.bstack111111l1111_opy_(bstack11111l1llll_opy_, bstack1111l111111_opy_)
        with open(bstack111111ll1ll_opy_, bstack1l11_opy_ (u"ࠩࡺࡦࠬἠ")) as file:
          file.write(response.content)
        self.logger.info(bstack1l11_opy_ (u"ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡱࡧࡵࡧࡾࠦࡢࡪࡰࡤࡶࡾࠦࡡ࡯ࡦࠣࡷࡦࡼࡥࡥࠢࡤࡸࠥࢁࡽࠣἡ").format(bstack111111ll1ll_opy_))
        return self.bstack11111ll11l1_opy_(bstack111111ll1ll_opy_, bstack11111l1ll11_opy_)
      else:
        raise(bstack1l11_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡷ࡬ࡪࠦࡦࡪ࡮ࡨ࠲࡙ࠥࡴࡢࡶࡸࡷࠥࡩ࡯ࡥࡧ࠽ࠤࢀࢃࠢἢ").format(response.status_code))
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡪࡸࡣࡺࠢࡥ࡭ࡳࡧࡲࡺ࠼ࠣࡿࢂࠨἣ").format(e))
  def bstack11111l111ll_opy_(self, bstack111111ll111_opy_, bstack11111l1ll11_opy_):
    try:
      retry = 2
      bstack111111l11l1_opy_ = None
      bstack1111111ll1l_opy_ = False
      while retry > 0:
        bstack111111l11l1_opy_ = self.bstack11111ll1ll1_opy_(bstack111111ll111_opy_, bstack11111l1ll11_opy_)
        bstack1111111ll1l_opy_ = self.bstack111111llll1_opy_(bstack111111ll111_opy_, bstack11111l1ll11_opy_, bstack111111l11l1_opy_)
        if bstack1111111ll1l_opy_:
          break
        retry -= 1
      return bstack111111l11l1_opy_, bstack1111111ll1l_opy_
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡪࡩࡹࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥࡶࡡࡵࡪࠥἤ").format(e))
    return bstack111111l11l1_opy_, False
  def bstack111111llll1_opy_(self, bstack111111ll111_opy_, bstack11111l1ll11_opy_, bstack111111l11l1_opy_, bstack11111l111l1_opy_ = 0):
    if bstack11111l111l1_opy_ > 1:
      return False
    if bstack111111l11l1_opy_ == None or os.path.exists(bstack111111l11l1_opy_) == False:
      self.logger.warn(bstack1l11_opy_ (u"ࠢࡑࡧࡵࡧࡾࠦࡰࡢࡶ࡫ࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠬࠡࡴࡨࡸࡷࡿࡩ࡯ࡩࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠧἥ"))
      return False
    bstack111111lll11_opy_ = bstack1l11_opy_ (u"ࡳࠤࡡ࠲࠯ࡆࡰࡦࡴࡦࡽ࠴ࡩ࡬ࡪࠢ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠤἦ")
    command = bstack1l11_opy_ (u"ࠩࡾࢁࠥ࠳࠭ࡷࡧࡵࡷ࡮ࡵ࡮ࠨἧ").format(bstack111111l11l1_opy_)
    bstack1111l111l11_opy_ = subprocess.check_output(command, shell=True, text=True)
    if re.match(bstack111111lll11_opy_, bstack1111l111l11_opy_) != None:
      return True
    else:
      self.logger.error(bstack1l11_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡹࡩࡷࡹࡩࡰࡰࠣࡧ࡭࡫ࡣ࡬ࠢࡩࡥ࡮ࡲࡥࡥࠤἨ"))
      return False
  def bstack11111ll11l1_opy_(self, bstack111111ll1ll_opy_, bstack11111l1ll11_opy_):
    try:
      working_dir = os.path.dirname(bstack111111ll1ll_opy_)
      shutil.unpack_archive(bstack111111ll1ll_opy_, working_dir)
      bstack111111l11l1_opy_ = os.path.join(working_dir, bstack11111l1ll11_opy_)
      os.chmod(bstack111111l11l1_opy_, 0o755)
      return bstack111111l11l1_opy_
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡶࡰࡽ࡭ࡵࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠧἩ"))
  def bstack1111111lll1_opy_(self):
    try:
      bstack11111l1l111_opy_ = self.config.get(bstack1l11_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫἪ"))
      bstack1111111lll1_opy_ = bstack11111l1l111_opy_ or (bstack11111l1l111_opy_ is None and self.bstack1l111l11ll_opy_)
      if not bstack1111111lll1_opy_ or self.config.get(bstack1l11_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩἫ"), None) not in bstack11l1l1llll1_opy_:
        return False
      self.bstack1lllll1l11_opy_ = True
      return True
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡤࡶࠣࡴࡪࡸࡣࡺ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤἬ").format(e))
  def bstack11111lllll1_opy_(self):
    try:
      bstack11111lllll1_opy_ = self.percy_capture_mode
      return bstack11111lllll1_opy_
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡥࡷࠤࡵ࡫ࡲࡤࡻࠣࡧࡦࡶࡴࡶࡴࡨࠤࡲࡵࡤࡦ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤἭ").format(e))
  def init(self, bstack1l111l11ll_opy_, config, logger):
    self.bstack1l111l11ll_opy_ = bstack1l111l11ll_opy_
    self.config = config
    self.logger = logger
    if not self.bstack1111111lll1_opy_():
      return
    self.bstack11111ll1lll_opy_ = config.get(bstack1l11_opy_ (u"ࠩࡳࡩࡷࡩࡹࡐࡲࡷ࡭ࡴࡴࡳࠨἮ"), {})
    self.percy_capture_mode = config.get(bstack1l11_opy_ (u"ࠪࡴࡪࡸࡣࡺࡅࡤࡴࡹࡻࡲࡦࡏࡲࡨࡪ࠭Ἧ"))
    try:
      bstack111111ll111_opy_, bstack11111l1ll11_opy_ = self.bstack11111l1lll1_opy_()
      self.bstack111ll1l11ll_opy_ = bstack11111l1ll11_opy_
      bstack111111l11l1_opy_, bstack1111111ll1l_opy_ = self.bstack11111l111ll_opy_(bstack111111ll111_opy_, bstack11111l1ll11_opy_)
      if bstack1111111ll1l_opy_:
        self.binary_path = bstack111111l11l1_opy_
        thread = Thread(target=self.bstack111111lllll_opy_)
        thread.start()
      else:
        self.bstack11111l1l11l_opy_ = True
        self.logger.error(bstack1l11_opy_ (u"ࠦࡎࡴࡶࡢ࡮࡬ࡨࠥࡶࡥࡳࡥࡼࠤࡵࡧࡴࡩࠢࡩࡳࡺࡴࡤࠡ࠯ࠣࡿࢂ࠲ࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡓࡩࡷࡩࡹࠣἰ").format(bstack111111l11l1_opy_))
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡱࡧࡵࡧࡾ࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡿࢂࠨἱ").format(e))
  def bstack11111l1l1l1_opy_(self):
    try:
      logfile = os.path.join(self.working_dir, bstack1l11_opy_ (u"࠭࡬ࡰࡩࠪἲ"), bstack1l11_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠴࡬ࡰࡩࠪἳ"))
      os.makedirs(os.path.dirname(logfile)) if not os.path.exists(os.path.dirname(logfile)) else None
      self.logger.debug(bstack1l11_opy_ (u"ࠣࡒࡸࡷ࡭࡯࡮ࡨࠢࡳࡩࡷࡩࡹࠡ࡮ࡲ࡫ࡸࠦࡡࡵࠢࡾࢁࠧἴ").format(logfile))
      self.bstack1111l11ll11_opy_ = logfile
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡥࡵࠢࡳࡩࡷࡩࡹࠡ࡮ࡲ࡫ࠥࡶࡡࡵࡪ࠯ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡼࡿࠥἵ").format(e))
  @measure(event_name=EVENTS.bstack11l1lll1ll1_opy_, stage=STAGE.bstack1l11l1ll_opy_)
  def bstack111111lllll_opy_(self):
    bstack1111l11l1l1_opy_ = self.bstack11111llll11_opy_()
    if bstack1111l11l1l1_opy_ == None:
      self.bstack11111l1l11l_opy_ = True
      self.logger.error(bstack1l11_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡷࡳࡰ࡫࡮ࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧ࠰ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡱࡧࡵࡧࡾࠨἶ"))
      return False
    bstack11111lll1l1_opy_ = [bstack1l11_opy_ (u"ࠦࡦࡶࡰ࠻ࡧࡻࡩࡨࡀࡳࡵࡣࡵࡸࠧἷ") if self.bstack1l111l11ll_opy_ else bstack1l11_opy_ (u"ࠬ࡫ࡸࡦࡥ࠽ࡷࡹࡧࡲࡵࠩἸ")]
    bstack111l1l11111_opy_ = self.bstack11111l11l1l_opy_()
    if bstack111l1l11111_opy_ != None:
      bstack11111lll1l1_opy_.append(bstack1l11_opy_ (u"ࠨ࠭ࡤࠢࡾࢁࠧἹ").format(bstack111l1l11111_opy_))
    env = os.environ.copy()
    env[bstack1l11_opy_ (u"ࠢࡑࡇࡕࡇ࡞ࡥࡔࡐࡍࡈࡒࠧἺ")] = bstack1111l11l1l1_opy_
    env[bstack1l11_opy_ (u"ࠣࡖࡋࡣࡇ࡛ࡉࡍࡆࡢ࡙࡚ࡏࡄࠣἻ")] = os.environ.get(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧἼ"), bstack1l11_opy_ (u"ࠪࠫἽ"))
    bstack11111llll1l_opy_ = [self.binary_path]
    self.bstack11111l1l1l1_opy_()
    self.bstack11111l11ll1_opy_ = self.bstack1111l11llll_opy_(bstack11111llll1l_opy_ + bstack11111lll1l1_opy_, env)
    self.logger.debug(bstack1l11_opy_ (u"ࠦࡘࡺࡡࡳࡶ࡬ࡲ࡬ࠦࡈࡦࡣ࡯ࡸ࡭ࠦࡃࡩࡧࡦ࡯ࠧἾ"))
    bstack11111l111l1_opy_ = 0
    while self.bstack11111l11ll1_opy_.poll() == None:
      bstack1111l11lll1_opy_ = self.bstack1111l111l1l_opy_()
      if bstack1111l11lll1_opy_:
        self.logger.debug(bstack1l11_opy_ (u"ࠧࡎࡥࡢ࡮ࡷ࡬ࠥࡉࡨࡦࡥ࡮ࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠣἿ"))
        self.bstack1111111llll_opy_ = True
        return True
      bstack11111l111l1_opy_ += 1
      self.logger.debug(bstack1l11_opy_ (u"ࠨࡈࡦࡣ࡯ࡸ࡭ࠦࡃࡩࡧࡦ࡯ࠥࡘࡥࡵࡴࡼࠤ࠲ࠦࡻࡾࠤὀ").format(bstack11111l111l1_opy_))
      time.sleep(2)
    self.logger.error(bstack1l11_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡳࡩࡷࡩࡹ࠭ࠢࡋࡩࡦࡲࡴࡩࠢࡆ࡬ࡪࡩ࡫ࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡣࡩࡸࡪࡸࠠࡼࡿࠣࡥࡹࡺࡥ࡮ࡲࡷࡷࠧὁ").format(bstack11111l111l1_opy_))
    self.bstack11111l1l11l_opy_ = True
    return False
  def bstack1111l111l1l_opy_(self, bstack11111l111l1_opy_ = 0):
    if bstack11111l111l1_opy_ > 10:
      return False
    try:
      bstack11111l11lll_opy_ = os.environ.get(bstack1l11_opy_ (u"ࠨࡒࡈࡖࡈ࡟࡟ࡔࡇࡕ࡚ࡊࡘ࡟ࡂࡆࡇࡖࡊ࡙ࡓࠨὂ"), bstack1l11_opy_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸ࠿࠻࠳࠴࠺ࠪὃ"))
      bstack1111l11l1ll_opy_ = bstack11111l11lll_opy_ + bstack11l1l1l1111_opy_
      response = requests.get(bstack1111l11l1ll_opy_)
      data = response.json()
      self.percy_build_id = data.get(bstack1l11_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࠩὄ"), {}).get(bstack1l11_opy_ (u"ࠫ࡮ࡪࠧὅ"), None)
      return True
    except:
      self.logger.debug(bstack1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡴࡩࡣࡶࡴࡵࡩࡩࠦࡷࡩ࡫࡯ࡩࠥࡶࡲࡰࡥࡨࡷࡸ࡯࡮ࡨࠢ࡫ࡩࡦࡲࡴࡩࠢࡦ࡬ࡪࡩ࡫ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧࠥ὆"))
      return False
  def bstack11111llll11_opy_(self):
    bstack111111ll1l1_opy_ = bstack1l11_opy_ (u"࠭ࡡࡱࡲࠪ὇") if self.bstack1l111l11ll_opy_ else bstack1l11_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦࠩὈ")
    bstack11111l1l1ll_opy_ = bstack1l11_opy_ (u"ࠣࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠦὉ") if self.config.get(bstack1l11_opy_ (u"ࠩࡳࡩࡷࡩࡹࠨὊ")) is None else True
    bstack11ll111l1l1_opy_ = bstack1l11_opy_ (u"ࠥࡥࡵ࡯࠯ࡢࡲࡳࡣࡵ࡫ࡲࡤࡻ࠲࡫ࡪࡺ࡟ࡱࡴࡲ࡮ࡪࡩࡴࡠࡶࡲ࡯ࡪࡴ࠿࡯ࡣࡰࡩࡂࢁࡽࠧࡶࡼࡴࡪࡃࡻࡾࠨࡳࡩࡷࡩࡹ࠾ࡽࢀࠦὋ").format(self.config[bstack1l11_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠩὌ")], bstack111111ll1l1_opy_, bstack11111l1l1ll_opy_)
    if self.percy_capture_mode:
      bstack11ll111l1l1_opy_ += bstack1l11_opy_ (u"ࠧࠬࡰࡦࡴࡦࡽࡤࡩࡡࡱࡶࡸࡶࡪࡥ࡭ࡰࡦࡨࡁࢀࢃࠢὍ").format(self.percy_capture_mode)
    uri = bstack1lll1l1l_opy_(bstack11ll111l1l1_opy_)
    try:
      response = bstack11l1l1l111_opy_(bstack1l11_opy_ (u"࠭ࡇࡆࡖࠪ὎"), uri, {}, {bstack1l11_opy_ (u"ࠧࡢࡷࡷ࡬ࠬ὏"): (self.config[bstack1l11_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪὐ")], self.config[bstack1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬὑ")])})
      if response.status_code == 200:
        data = response.json()
        self.bstack1lllll1l11_opy_ = data.get(bstack1l11_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫὒ"))
        self.percy_capture_mode = data.get(bstack1l11_opy_ (u"ࠫࡵ࡫ࡲࡤࡻࡢࡧࡦࡶࡴࡶࡴࡨࡣࡲࡵࡤࡦࠩὓ"))
        os.environ[bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡋࡒࡄ࡛ࠪὔ")] = str(self.bstack1lllll1l11_opy_)
        os.environ[bstack1l11_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡅࡓࡅ࡜ࡣࡈࡇࡐࡕࡗࡕࡉࡤࡓࡏࡅࡇࠪὕ")] = str(self.percy_capture_mode)
        if bstack11111l1l1ll_opy_ == bstack1l11_opy_ (u"ࠢࡶࡰࡧࡩ࡫࡯࡮ࡦࡦࠥὖ") and str(self.bstack1lllll1l11_opy_).lower() == bstack1l11_opy_ (u"ࠣࡶࡵࡹࡪࠨὗ"):
          self.bstack1l1l11111l_opy_ = True
        if bstack1l11_opy_ (u"ࠤࡷࡳࡰ࡫࡮ࠣ὘") in data:
          return data[bstack1l11_opy_ (u"ࠥࡸࡴࡱࡥ࡯ࠤὙ")]
        else:
          raise bstack1l11_opy_ (u"࡙ࠫࡵ࡫ࡦࡰࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩࠦ࠭ࠡࡽࢀࠫ὚").format(data)
      else:
        raise bstack1l11_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡨࡨࡸࡨ࡮ࠠࡱࡧࡵࡧࡾࠦࡴࡰ࡭ࡨࡲ࠱ࠦࡒࡦࡵࡳࡳࡳࡹࡥࠡࡵࡷࡥࡹࡻࡳࠡ࠯ࠣࡿࢂ࠲ࠠࡓࡧࡶࡴࡴࡴࡳࡦࠢࡅࡳࡩࡿࠠ࠮ࠢࡾࢁࠧὛ").format(response.status_code, response.json())
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡱࡧࡵࡧࡾࠦࡰࡳࡱ࡭ࡩࡨࡺࠢ὜").format(e))
  def bstack11111l11l1l_opy_(self):
    bstack1111l11l11l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11_opy_ (u"ࠢࡱࡧࡵࡧࡾࡉ࡯࡯ࡨ࡬࡫࠳ࡰࡳࡰࡰࠥὝ"))
    try:
      if bstack1l11_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ὞") not in self.bstack11111ll1lll_opy_:
        self.bstack11111ll1lll_opy_[bstack1l11_opy_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪὟ")] = 2
      with open(bstack1111l11l11l_opy_, bstack1l11_opy_ (u"ࠪࡻࠬὠ")) as fp:
        json.dump(self.bstack11111ll1lll_opy_, fp)
      return bstack1111l11l11l_opy_
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡤࡴࡨࡥࡹ࡫ࠠࡱࡧࡵࡧࡾࠦࡣࡰࡰࡩ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡽࢀࠦὡ").format(e))
  def bstack1111l11llll_opy_(self, cmd, env = os.environ.copy()):
    try:
      if self.bstack1111l111ll1_opy_ == bstack1l11_opy_ (u"ࠬࡽࡩ࡯ࠩὢ"):
        bstack11111lll1ll_opy_ = [bstack1l11_opy_ (u"࠭ࡣ࡮ࡦ࠱ࡩࡽ࡫ࠧὣ"), bstack1l11_opy_ (u"ࠧ࠰ࡥࠪὤ")]
        cmd = bstack11111lll1ll_opy_ + cmd
      cmd = bstack1l11_opy_ (u"ࠨࠢࠪὥ").join(cmd)
      self.logger.debug(bstack1l11_opy_ (u"ࠤࡕࡹࡳࡴࡩ࡯ࡩࠣࡿࢂࠨὦ").format(cmd))
      with open(self.bstack1111l11ll11_opy_, bstack1l11_opy_ (u"ࠥࡥࠧὧ")) as bstack11111ll1111_opy_:
        process = subprocess.Popen(cmd, shell=True, stdout=bstack11111ll1111_opy_, text=True, stderr=bstack11111ll1111_opy_, env=env, universal_newlines=True)
      return process
    except Exception as e:
      self.bstack11111l1l11l_opy_ = True
      self.logger.error(bstack1l11_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡶࡤࡶࡹࠦࡰࡦࡴࡦࡽࠥࡽࡩࡵࡪࠣࡧࡲࡪࠠ࠮ࠢࡾࢁ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡿࢂࠨὨ").format(cmd, e))
  def shutdown(self):
    try:
      if self.bstack1111111llll_opy_:
        self.logger.info(bstack1l11_opy_ (u"࡙ࠧࡴࡰࡲࡳ࡭ࡳ࡭ࠠࡑࡧࡵࡧࡾࠨὩ"))
        cmd = [self.binary_path, bstack1l11_opy_ (u"ࠨࡥࡹࡧࡦ࠾ࡸࡺ࡯ࡱࠤὪ")]
        self.bstack1111l11llll_opy_(cmd)
        self.bstack1111111llll_opy_ = False
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡹࡵࡰࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡺ࡭ࡹ࡮ࠠࡤࡱࡰࡱࡦࡴࡤࠡ࠯ࠣࡿࢂ࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰ࠽ࠤࢀࢃࠢὫ").format(cmd, e))
  def bstack11ll1l1111_opy_(self):
    if not self.bstack1lllll1l11_opy_:
      return
    try:
      bstack1111l11l111_opy_ = 0
      while not self.bstack1111111llll_opy_ and bstack1111l11l111_opy_ < self.bstack1111l111lll_opy_:
        if self.bstack11111l1l11l_opy_:
          self.logger.info(bstack1l11_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡴࡧࡷࡹࡵࠦࡦࡢ࡫࡯ࡩࡩࠨὬ"))
          return
        time.sleep(1)
        bstack1111l11l111_opy_ += 1
      os.environ[bstack1l11_opy_ (u"ࠩࡓࡉࡗࡉ࡙ࡠࡄࡈࡗ࡙ࡥࡐࡍࡃࡗࡊࡔࡘࡍࠨὭ")] = str(self.bstack11111lll111_opy_())
      self.logger.info(bstack1l11_opy_ (u"ࠥࡔࡪࡸࡣࡺࠢࡶࡩࡹࡻࡰࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠦὮ"))
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡧࡷࡹࡵࠦࡰࡦࡴࡦࡽ࠱ࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡾࢁࠧὯ").format(e))
  def bstack11111lll111_opy_(self):
    if self.bstack1l111l11ll_opy_:
      return
    try:
      bstack1111l1111l1_opy_ = [platform[bstack1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪὰ")].lower() for platform in self.config.get(bstack1l11_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩά"), [])]
      bstack11111l11l11_opy_ = sys.maxsize
      bstack1111l11ll1l_opy_ = bstack1l11_opy_ (u"ࠧࠨὲ")
      for browser in bstack1111l1111l1_opy_:
        if browser in self.bstack11111lll11l_opy_:
          bstack111111lll1l_opy_ = self.bstack11111lll11l_opy_[browser]
        if bstack111111lll1l_opy_ < bstack11111l11l11_opy_:
          bstack11111l11l11_opy_ = bstack111111lll1l_opy_
          bstack1111l11ll1l_opy_ = browser
      return bstack1111l11ll1l_opy_
    except Exception as e:
      self.logger.error(bstack1l11_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤ࡫࡯࡮ࡥࠢࡥࡩࡸࡺࠠࡱ࡮ࡤࡸ࡫ࡵࡲ࡮࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤέ").format(e))
  @classmethod
  def bstack1l1lllllll_opy_(self):
    return os.getenv(bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡈࡖࡈ࡟ࠧὴ"), bstack1l11_opy_ (u"ࠪࡊࡦࡲࡳࡦࠩή")).lower()
  @classmethod
  def bstack1ll11111ll_opy_(self):
    return os.getenv(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡊࡘࡃ࡚ࡡࡆࡅࡕ࡚ࡕࡓࡇࡢࡑࡔࡊࡅࠨὶ"), bstack1l11_opy_ (u"ࠬ࠭ί"))
  @classmethod
  def bstack1l1l11ll1ll_opy_(cls, value):
    cls.bstack1l1l11111l_opy_ = value
  @classmethod
  def bstack11111ll11ll_opy_(cls):
    return cls.bstack1l1l11111l_opy_
  @classmethod
  def bstack1l1l11l1ll1_opy_(cls, value):
    cls.percy_build_id = value
  @classmethod
  def bstack11111llllll_opy_(cls):
    return cls.percy_build_id