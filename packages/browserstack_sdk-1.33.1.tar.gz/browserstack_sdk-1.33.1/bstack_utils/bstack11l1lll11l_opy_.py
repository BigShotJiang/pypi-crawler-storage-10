# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import threading
from collections import deque
from bstack_utils.constants import *
class bstack1l111lll1_opy_:
    def __init__(self):
        self._11111111l1l_opy_ = deque()
        self._111111111l1_opy_ = {}
        self._1111111l11l_opy_ = False
        self._lock = threading.RLock()
    def bstack11111111ll1_opy_(self, test_name, bstack111111111ll_opy_):
        with self._lock:
            bstack1111111l1l1_opy_ = self._111111111l1_opy_.get(test_name, {})
            return bstack1111111l1l1_opy_.get(bstack111111111ll_opy_, 0)
    def bstack1111111l1ll_opy_(self, test_name, bstack111111111ll_opy_):
        with self._lock:
            bstack1111111l111_opy_ = self.bstack11111111ll1_opy_(test_name, bstack111111111ll_opy_)
            self.bstack11111111lll_opy_(test_name, bstack111111111ll_opy_)
            return bstack1111111l111_opy_
    def bstack11111111lll_opy_(self, test_name, bstack111111111ll_opy_):
        with self._lock:
            if test_name not in self._111111111l1_opy_:
                self._111111111l1_opy_[test_name] = {}
            bstack1111111l1l1_opy_ = self._111111111l1_opy_[test_name]
            bstack1111111l111_opy_ = bstack1111111l1l1_opy_.get(bstack111111111ll_opy_, 0)
            bstack1111111l1l1_opy_[bstack111111111ll_opy_] = bstack1111111l111_opy_ + 1
    def bstack1l1l11l11_opy_(self, bstack1111111ll11_opy_, bstack1111111111l_opy_):
        bstack11111111l11_opy_ = self.bstack1111111l1ll_opy_(bstack1111111ll11_opy_, bstack1111111111l_opy_)
        event_name = bstack11l1ll11ll1_opy_[bstack1111111111l_opy_]
        bstack1l1l11ll11l_opy_ = bstack1l11_opy_ (u"ࠨࡻࡾ࠯ࡾࢁ࠲ࢁࡽࠣὸ").format(bstack1111111ll11_opy_, event_name, bstack11111111l11_opy_)
        with self._lock:
            self._11111111l1l_opy_.append(bstack1l1l11ll11l_opy_)
    def bstack1lllll11l_opy_(self):
        with self._lock:
            return len(self._11111111l1l_opy_) == 0
    def bstack111ll1ll_opy_(self):
        with self._lock:
            if self._11111111l1l_opy_:
                bstack11111111111_opy_ = self._11111111l1l_opy_.popleft()
                return bstack11111111111_opy_
            return None
    def capturing(self):
        with self._lock:
            return self._1111111l11l_opy_
    def bstack1ll1ll11l_opy_(self):
        with self._lock:
            self._1111111l11l_opy_ = True
    def bstack11l1lll1ll_opy_(self):
        with self._lock:
            self._1111111l11l_opy_ = False