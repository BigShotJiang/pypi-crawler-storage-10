# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from browserstack_sdk.bstack1l11l1ll1l_opy_ import bstack1111l11l_opy_
from browserstack_sdk.bstack111l1l11ll_opy_ import RobotHandler
def bstack1ll1ll1l_opy_(framework):
    if framework.lower() == bstack1l11_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪᬣ"):
        return bstack1111l11l_opy_.version()
    elif framework.lower() == bstack1l11_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪᬤ"):
        return RobotHandler.version()
    elif framework.lower() == bstack1l11_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬᬥ"):
        import behave
        return behave.__version__
    else:
        return bstack1l11_opy_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧᬦ")
def bstack1l1l111lll_opy_():
    import importlib.metadata
    framework_name = []
    framework_version = []
    try:
        from selenium import webdriver
        framework_name.append(bstack1l11_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮ࠩᬧ"))
        framework_version.append(importlib.metadata.version(bstack1l11_opy_ (u"ࠣࡵࡨࡰࡪࡴࡩࡶ࡯ࠥᬨ")))
    except:
        pass
    try:
        import playwright
        framework_name.append(bstack1l11_opy_ (u"ࠩࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠭ᬩ"))
        framework_version.append(importlib.metadata.version(bstack1l11_opy_ (u"ࠥࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢᬪ")))
    except:
        pass
    return {
        bstack1l11_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᬫ"): bstack1l11_opy_ (u"ࠬࡥࠧᬬ").join(framework_name),
        bstack1l11_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧᬭ"): bstack1l11_opy_ (u"ࠧࡠࠩᬮ").join(framework_version)
    }