# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11l11l1l111_opy_, bstack11l1llll1_opy_, bstack1l11lll11_opy_, bstack11ll111l1l_opy_, \
    bstack111ll1l1l11_opy_
from bstack_utils.measure import measure
def bstack111ll1ll1_opy_(bstack1lllll111ll1_opy_):
    for driver in bstack1lllll111ll1_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack1lll1l111l_opy_, stage=STAGE.bstack1l11l1ll_opy_)
def bstack11lllll11l_opy_(driver, status, reason=bstack1l11_opy_ (u"ࠧࠨ‽")):
    bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
    if bstack11l1l111ll_opy_.bstack111111l1l1_opy_():
        return
    bstack111ll1lll_opy_ = bstack1ll1llll11_opy_(bstack1l11_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫ‾"), bstack1l11_opy_ (u"ࠩࠪ‿"), status, reason, bstack1l11_opy_ (u"ࠪࠫ⁀"), bstack1l11_opy_ (u"ࠫࠬ⁁"))
    driver.execute_script(bstack111ll1lll_opy_)
@measure(event_name=EVENTS.bstack1lll1l111l_opy_, stage=STAGE.bstack1l11l1ll_opy_)
def bstack1l1l11ll_opy_(page, status, reason=bstack1l11_opy_ (u"ࠬ࠭⁂")):
    try:
        if page is None:
            return
        bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
        if bstack11l1l111ll_opy_.bstack111111l1l1_opy_():
            return
        bstack111ll1lll_opy_ = bstack1ll1llll11_opy_(bstack1l11_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠩ⁃"), bstack1l11_opy_ (u"ࠧࠨ⁄"), status, reason, bstack1l11_opy_ (u"ࠨࠩ⁅"), bstack1l11_opy_ (u"ࠩࠪ⁆"))
        page.evaluate(bstack1l11_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦ⁇"), bstack111ll1lll_opy_)
    except Exception as e:
        print(bstack1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡬࡯ࡳࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡻࡾࠤ⁈"), e)
def bstack1ll1llll11_opy_(type, name, status, reason, bstack1l1ll111_opy_, bstack1l1ll1llll_opy_):
    bstack1l111l1ll1_opy_ = {
        bstack1l11_opy_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬ⁉"): type,
        bstack1l11_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ⁊"): {}
    }
    if type == bstack1l11_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩ⁋"):
        bstack1l111l1ll1_opy_[bstack1l11_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ⁌")][bstack1l11_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ⁍")] = bstack1l1ll111_opy_
        bstack1l111l1ll1_opy_[bstack1l11_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭⁎")][bstack1l11_opy_ (u"ࠫࡩࡧࡴࡢࠩ⁏")] = json.dumps(str(bstack1l1ll1llll_opy_))
    if type == bstack1l11_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭⁐"):
        bstack1l111l1ll1_opy_[bstack1l11_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ⁑")][bstack1l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ⁒")] = name
    if type == bstack1l11_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫ⁓"):
        bstack1l111l1ll1_opy_[bstack1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ⁔")][bstack1l11_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ⁕")] = status
        if status == bstack1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ⁖") and str(reason) != bstack1l11_opy_ (u"ࠧࠨ⁗"):
            bstack1l111l1ll1_opy_[bstack1l11_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ⁘")][bstack1l11_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ⁙")] = json.dumps(str(reason))
    bstack1111l1lll_opy_ = bstack1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭⁚").format(json.dumps(bstack1l111l1ll1_opy_))
    return bstack1111l1lll_opy_
def bstack1ll111l11l_opy_(url, config, logger, bstack1lllll1111_opy_=False):
    hostname = bstack11l1llll1_opy_(url)
    is_private = bstack11ll111l1l_opy_(hostname)
    try:
        if is_private or bstack1lllll1111_opy_:
            file_path = bstack11l11l1l111_opy_(bstack1l11_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩ⁛"), bstack1l11_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩ⁜"), logger)
            if os.environ.get(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ⁝")) and eval(
                    os.environ.get(bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡑࡕࡃࡂࡎࡢࡒࡔ࡚࡟ࡔࡇࡗࡣࡊࡘࡒࡐࡔࠪ⁞"))):
                return
            if (bstack1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ ") in config and not config[bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ⁠")]):
                os.environ[bstack1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭⁡")] = str(True)
                bstack1lllll111l1l_opy_ = {bstack1l11_opy_ (u"ࠩ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠫ⁢"): hostname}
                bstack111ll1l1l11_opy_(bstack1l11_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩ⁣"), bstack1l11_opy_ (u"ࠫࡳࡻࡤࡨࡧࡢࡰࡴࡩࡡ࡭ࠩ⁤"), bstack1lllll111l1l_opy_, logger)
    except Exception as e:
        pass
def bstack1l11lll1ll_opy_(caps, bstack1lllll111l11_opy_):
    if bstack1l11_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭⁥") in caps:
        caps[bstack1l11_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧ⁦")][bstack1l11_opy_ (u"ࠧ࡭ࡱࡦࡥࡱ࠭⁧")] = True
        if bstack1lllll111l11_opy_:
            caps[bstack1l11_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ⁨")][bstack1l11_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ⁩")] = bstack1lllll111l11_opy_
    else:
        caps[bstack1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰࡯ࡳࡨࡧ࡬ࠨ⁪")] = True
        if bstack1lllll111l11_opy_:
            caps[bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ⁫")] = bstack1lllll111l11_opy_
def bstack1llllll11lll_opy_(bstack111l1l1l1l_opy_):
    bstack1lllll111lll_opy_ = bstack1l11lll11_opy_(threading.current_thread(), bstack1l11_opy_ (u"ࠬࡺࡥࡴࡶࡖࡸࡦࡺࡵࡴࠩ⁬"), bstack1l11_opy_ (u"࠭ࠧ⁭"))
    if bstack1lllll111lll_opy_ == bstack1l11_opy_ (u"ࠧࠨ⁮") or bstack1lllll111lll_opy_ == bstack1l11_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩ⁯"):
        threading.current_thread().testStatus = bstack111l1l1l1l_opy_
    else:
        if bstack111l1l1l1l_opy_ == bstack1l11_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ⁰"):
            threading.current_thread().testStatus = bstack111l1l1l1l_opy_