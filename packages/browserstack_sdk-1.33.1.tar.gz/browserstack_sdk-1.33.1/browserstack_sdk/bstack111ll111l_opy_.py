# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import json
import multiprocessing
import os
from bstack_utils.config import Config
class bstack1111lll1l_opy_():
  def __init__(self, args, logger, bstack11111ll1ll_opy_, bstack11111l1lll_opy_, bstack1111111l1l_opy_):
    self.args = args
    self.logger = logger
    self.bstack11111ll1ll_opy_ = bstack11111ll1ll_opy_
    self.bstack11111l1lll_opy_ = bstack11111l1lll_opy_
    self.bstack1111111l1l_opy_ = bstack1111111l1l_opy_
  def bstack1ll1ll1lll_opy_(self, bstack111111l11l_opy_, bstack11l1ll1l_opy_, bstack1111111l11_opy_=False):
    bstack111l11111_opy_ = []
    manager = multiprocessing.Manager()
    bstack11111l11ll_opy_ = manager.list()
    bstack11l1l111ll_opy_ = Config.bstack1llll11111_opy_()
    if bstack1111111l11_opy_:
      for index, platform in enumerate(self.bstack11111ll1ll_opy_[bstack1l11_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ႜ")]):
        if index == 0:
          bstack11l1ll1l_opy_[bstack1l11_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧႝ")] = self.args
        bstack111l11111_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack111111l11l_opy_,
                                                    args=(bstack11l1ll1l_opy_, bstack11111l11ll_opy_)))
    else:
      for index, platform in enumerate(self.bstack11111ll1ll_opy_[bstack1l11_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ႞")]):
        bstack111l11111_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack111111l11l_opy_,
                                                    args=(bstack11l1ll1l_opy_, bstack11111l11ll_opy_)))
    i = 0
    for t in bstack111l11111_opy_:
      try:
        if bstack11l1l111ll_opy_.get_property(bstack1l11_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ႟")):
          os.environ[bstack1l11_opy_ (u"ࠧࡄࡗࡕࡖࡊࡔࡔࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡈࡆ࡚ࡁࠨႠ")] = json.dumps(self.bstack11111ll1ll_opy_[bstack1l11_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫႡ")][i % self.bstack1111111l1l_opy_])
      except Exception as e:
        self.logger.debug(bstack1l11_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡴࡶࡲࡶ࡮ࡴࡧࠡࡥࡸࡶࡷ࡫࡮ࡵࠢࡳࡰࡦࡺࡦࡰࡴࡰࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠿ࠦࡻࡾࠤႢ").format(str(e)))
      i += 1
      t.start()
    for t in bstack111l11111_opy_:
      t.join()
    return list(bstack11111l11ll_opy_)