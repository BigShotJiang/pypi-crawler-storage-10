# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, List, Any, Tuple
from browserstack_sdk.sdk_cli.bstack1llllll1ll1_opy_ import bstack1llll11ll1l_opy_
from browserstack_sdk.sdk_cli.utils.bstack11l11111ll_opy_ import bstack1l111ll1lll_opy_
from pathlib import Path
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.test_framework import (
    TestFramework,
    bstack1ll1ll1l1ll_opy_,
    bstack1lll111l11l_opy_,
    bstack1llll11l11l_opy_,
    bstack1l111ll1l1l_opy_,
    bstack1lll1l11l1l_opy_,
)
import traceback
from bstack_utils.helper import bstack1l1l1l1lll1_opy_
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
from bstack_utils.constants import EVENTS
from browserstack_sdk.sdk_cli.utils.bstack1lll11ll111_opy_ import bstack1ll1lll1ll1_opy_
from browserstack_sdk.sdk_cli.bstack1llllllllll_opy_ import bstack1lllllll1l1_opy_
bstack1l1l1ll1l11_opy_ = bstack1l1l1l1lll1_opy_()
bstack1l1lll11l1l_opy_ = bstack1l11_opy_ (u"ࠢࡖࡲ࡯ࡳࡦࡪࡥࡥࡃࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡸ࠳ࠢᑊ")
bstack1l11111llll_opy_ = bstack1l11_opy_ (u"ࠣࡊࡲࡳࡰࡒࡥࡷࡧ࡯ࠦᑋ")
bstack1l111l11l1l_opy_ = bstack1l11_opy_ (u"ࠤࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࡎ࡯ࡰ࡭ࡈࡺࡪࡴࡴࠣᑌ")
bstack1l111111lll_opy_ = 1.0
_1l1ll1ll1l1_opy_ = set()
class PytestBDDFramework(TestFramework):
    bstack1l1111l1l1l_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡨ࡬ࡼࡹࡻࡲࡦࡵࠥᑍ")
    bstack1l1111lllll_opy_ = bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱࡳࡠࡵࡷࡥࡷࡺࡥࡥࠤᑎ")
    bstack1l1111111ll_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡴࡡࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠦᑏ")
    bstack11lllll1l11_opy_ = bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡ࡯ࡥࡸࡺ࡟ࡴࡶࡤࡶࡹ࡫ࡤࠣᑐ")
    bstack11lllll111l_opy_ = bstack1l11_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡰࡦࡹࡴࡠࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠥᑑ")
    bstack11lllll1lll_opy_: bool
    bstack1llllllllll_opy_: bstack1lllllll1l1_opy_  = None
    bstack1l11111l11l_opy_ = [
        bstack1ll1ll1l1ll_opy_.BEFORE_ALL,
        bstack1ll1ll1l1ll_opy_.AFTER_ALL,
        bstack1ll1ll1l1ll_opy_.BEFORE_EACH,
        bstack1ll1ll1l1ll_opy_.AFTER_EACH,
    ]
    def __init__(
        self,
        bstack11llll1l1ll_opy_: Dict[str, str],
        bstack1ll11ll1l11_opy_: List[str]=[bstack1l11_opy_ (u"ࠣࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠧᑒ")],
        bstack1llllllllll_opy_: bstack1lllllll1l1_opy_ = None,
        bstack1ll1llllll1_opy_=None
    ):
        super().__init__(bstack1ll11ll1l11_opy_, bstack11llll1l1ll_opy_, bstack1llllllllll_opy_)
        self.bstack11lllll1lll_opy_ = any(bstack1l11_opy_ (u"ࠤࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠨᑓ") in item.lower() for item in bstack1ll11ll1l11_opy_)
        self.bstack1ll1llllll1_opy_ = bstack1ll1llllll1_opy_
    def track_event(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        super().track_event(self, context, test_framework_state, test_hook_state, *args, **kwargs)
        if test_framework_state == bstack1ll1ll1l1ll_opy_.TEST or test_framework_state in PytestBDDFramework.bstack1l11111l11l_opy_:
            bstack1l111ll1lll_opy_(test_framework_state, test_hook_state)
        if test_framework_state == bstack1ll1ll1l1ll_opy_.NONE:
            self.logger.warning(bstack1l11_opy_ (u"ࠥ࡭࡬ࡴ࡯ࡳࡧࡧࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽࠡࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࡀࠦᑔ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠦࠧᑕ"))
            return
        if not self.bstack11lllll1lll_opy_:
            self.logger.warning(bstack1l11_opy_ (u"ࠧࡺࡲࡢࡥ࡮ࡣࡪࡼࡥ࡯ࡶ࠽ࠤࡺࡴࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡂࠨᑖ") + str(str(self.bstack1ll11ll1l11_opy_)) + bstack1l11_opy_ (u"ࠨࠢᑗ"))
            return
        if not isinstance(args, tuple) or len(args) == 0:
            self.logger.warning(bstack1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡥࡷࡧࡱࡸ࠿ࠦࡵ࡯ࡧࡻࡴࡪࡩࡴࡦࡦࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᑘ") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤᑙ"))
            return
        instance = self.__11llll1llll_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        if not instance:
            self.logger.debug(bstack1l11_opy_ (u"ࠤࡷࡶࡦࡩ࡫ࡠࡧࡹࡩࡳࡺ࠺ࠡࡷࡱ࡬ࡦࡴࡤ࡭ࡧࡧࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࢁࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥࡾࠢࡤࡶ࡬ࡹ࠽ࠣᑚ") + str(args) + bstack1l11_opy_ (u"ࠥࠦᑛ"))
            return
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack1l11111l11l_opy_ and test_hook_state == bstack1llll11l11l_opy_.PRE:
                bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack1ll111l111l_opy_(EVENTS.bstack1111l1111_opy_.value)
                name = str(EVENTS.bstack1111l1111_opy_.name)+bstack1l11_opy_ (u"ࠦ࠿ࠨᑜ")+str(test_framework_state.name)
                TestFramework.bstack1l111l11lll_opy_(instance, name, bstack1ll11ll11l1_opy_)
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡭ࡵ࡯࡬ࠢࡨࡶࡷࡵࡲࠡࡲࡵࡩ࠿ࠦࡻࡾࠤᑝ").format(e))
        try:
            if test_framework_state == bstack1ll1ll1l1ll_opy_.TEST:
                if not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1111ll11l_opy_) and test_hook_state == bstack1llll11l11l_opy_.PRE:
                    if not (len(args) >= 3):
                        return
                    test = PytestBDDFramework.__11llllll1l1_opy_(args)
                    if test:
                        instance.data.update(test)
                        self.logger.debug(bstack1l11_opy_ (u"ࠨ࡬ࡰࡣࡧࡩࡩࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࡽ࡬ࡲࡸࡺࡡ࡯ࡥࡨ࠲ࡷ࡫ࡦࠩࠫࢀࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࠨᑞ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠢࠣᑟ"))
                if test_hook_state == bstack1llll11l11l_opy_.PRE and not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1ll1l1l11_opy_):
                    TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1ll1l1l11_opy_, datetime.now(tz=timezone.utc))
                    PytestBDDFramework.__1l11111l1ll_opy_(instance, args)
                    self.logger.debug(bstack1l11_opy_ (u"ࠣࡵࡨࡸࠥࡺࡥࡴࡶ࠰ࡷࡹࡧࡲࡵࠢࡩࡳࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࡽ࡬ࡲࡸࡺࡡ࡯ࡥࡨ࠲ࡷ࡫ࡦࠩࠫࢀࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࠨᑠ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠤࠥᑡ"))
                elif test_hook_state == bstack1llll11l11l_opy_.POST and not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1l1l111ll_opy_):
                    TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1l1l111ll_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l11_opy_ (u"ࠥࡷࡪࡺࠠࡵࡧࡶࡸ࠲࡫࡮ࡥࠢࡩࡳࡷࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࡽ࡬ࡲࡸࡺࡡ࡯ࡥࡨ࠲ࡷ࡫ࡦࠩࠫࢀࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࠨᑢ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠦࠧᑣ"))
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.STEP:
                if test_hook_state == bstack1llll11l11l_opy_.PRE:
                    PytestBDDFramework.__1l111ll111l_opy_(instance, args)
                elif test_hook_state == bstack1llll11l11l_opy_.POST:
                    PytestBDDFramework.__11llllllll1_opy_(instance, args)
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG and test_hook_state == bstack1llll11l11l_opy_.POST:
                PytestBDDFramework.__1l11111l111_opy_(instance, *args)
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG_REPORT and test_hook_state == bstack1llll11l11l_opy_.POST:
                self.__11lllllllll_opy_(instance, *args)
                self.__1l111ll11l1_opy_(instance)
            elif test_framework_state in PytestBDDFramework.bstack1l11111l11l_opy_:
                self.__11llll1lll1_opy_(instance, test_framework_state, test_hook_state, *args)
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡺࡲࡢࡥ࡮ࡣࡪࡼࡥ࡯ࡶ࠽ࠤ࡭ࡧ࡮ࡥ࡮ࡨࡨࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࡻࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦࡿࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡂࠨᑤ") + str(instance.ref()) + bstack1l11_opy_ (u"ࠨࠢᑥ"))
        except Exception as e:
            self.logger.error(e)
            traceback.print_exc()
        self.bstack1l1111ll1ll_opy_(instance, (test_framework_state, test_hook_state), *args, **kwargs)
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack1l11111l11l_opy_ and test_hook_state == bstack1llll11l11l_opy_.POST:
                name = str(EVENTS.bstack1111l1111_opy_.name)+bstack1l11_opy_ (u"ࠢ࠻ࠤᑦ")+str(test_framework_state.name)
                bstack1ll11ll11l1_opy_ = TestFramework.bstack11lllllll1l_opy_(instance, name)
                bstack1ll1l1l11l1_opy_.end(EVENTS.bstack1111l1111_opy_.value, bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣᑧ"), bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠤ࠽ࡩࡳࡪࠢᑨ"), True, None, test_framework_state.name)
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢ࡫ࡳࡴࡱࠠࡦࡴࡵࡳࡷࡀࠠࡼࡿࠥᑩ").format(e))
    def bstack1l1l1l11l1l_opy_(self):
        return self.bstack11lllll1lll_opy_
    def __1l111l1l1l1_opy_(self, *args):
        if len(args) > 2 and callable(getattr(args[2], bstack1l11_opy_ (u"ࠦ࡬࡫ࡴࡠࡴࡨࡷࡺࡲࡴࠣᑪ"), None)):
            rep = args[2].get_result()
            if rep:
                return TestFramework.bstack1l1ll11ll1l_opy_(rep, [bstack1l11_opy_ (u"ࠧࡽࡨࡦࡰࠥᑫ"), bstack1l11_opy_ (u"ࠨ࡯ࡶࡶࡦࡳࡲ࡫ࠢᑬ"), bstack1l11_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪࠢᑭ"), bstack1l11_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣᑮ"), bstack1l11_opy_ (u"ࠤࡶ࡯࡮ࡶࡰࡦࡦࠥᑯ"), bstack1l11_opy_ (u"ࠥࡰࡴࡴࡧࡳࡧࡳࡶࡹ࡫ࡸࡵࠤᑰ")])
        return None
    def __11lllllllll_opy_(self, instance: bstack1lll111l11l_opy_, *args):
        result = self.__1l111l1l1l1_opy_(*args)
        if not result:
            return
        failure = None
        bstack111111111l_opy_ = None
        if result.get(bstack1l11_opy_ (u"ࠦࡴࡻࡴࡤࡱࡰࡩࠧᑱ"), None) == bstack1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧᑲ") and len(args) > 1 and getattr(args[1], bstack1l11_opy_ (u"ࠨࡥࡹࡥ࡬ࡲ࡫ࡵࠢᑳ"), None) is not None:
            failure = [{bstack1l11_opy_ (u"ࠧࡣࡣࡦ࡯ࡹࡸࡡࡤࡧࠪᑴ"): [args[1].excinfo.exconly(), result.get(bstack1l11_opy_ (u"ࠣ࡮ࡲࡲ࡬ࡸࡥࡱࡴࡷࡩࡽࡺࠢᑵ"), None)]}]
            bstack111111111l_opy_ = bstack1l11_opy_ (u"ࠤࡄࡷࡸ࡫ࡲࡵ࡫ࡲࡲࡊࡸࡲࡰࡴࠥᑶ") if bstack1l11_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨᑷ") in getattr(args[1].excinfo, bstack1l11_opy_ (u"ࠦࡹࡿࡰࡦࡰࡤࡱࡪࠨᑸ"), bstack1l11_opy_ (u"ࠧࠨᑹ")) else bstack1l11_opy_ (u"ࠨࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸࠢᑺ")
        bstack1l111111l1l_opy_ = result.get(bstack1l11_opy_ (u"ࠢࡰࡷࡷࡧࡴࡳࡥࠣᑻ"), TestFramework.bstack11lllll1111_opy_)
        if bstack1l111111l1l_opy_ != TestFramework.bstack11lllll1111_opy_:
            TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1lll111ll_opy_, datetime.now(tz=timezone.utc))
        TestFramework.bstack1l111lll11l_opy_(instance, {
            TestFramework.bstack1l11lllll1l_opy_: failure,
            TestFramework.bstack1l111ll1l11_opy_: bstack111111111l_opy_,
            TestFramework.bstack1l11lllllll_opy_: bstack1l111111l1l_opy_,
        })
    def __11llll1llll_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        instance = None
        if test_framework_state == bstack1ll1ll1l1ll_opy_.SETUP_FIXTURE:
            instance = self.__11llll1ll1l_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        else:
            target = None # bstack1l1111l11l1_opy_ bstack1l111111l11_opy_ this to be bstack1l11_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣᑼ")
            if test_framework_state == bstack1ll1ll1l1ll_opy_.INIT_TEST:
                target = args[0] if isinstance(args[0], str) else None
                if target:
                    self.__11llllll1ll_opy_(context, test_framework_state, target, *args)
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG:
                nodeid = getattr(getattr(args[0], bstack1l11_opy_ (u"ࠤࡱࡳࡩ࡫ࠢᑽ"), None), bstack1l11_opy_ (u"ࠥࡲࡴࡪࡥࡪࡦࠥᑾ"), None) if args else None
                if isinstance(nodeid, str):
                    target = nodeid
            elif getattr(args[0], bstack1l11_opy_ (u"ࠦࡳࡵࡤࡦࠤᑿ"), None):
                target = args[0].node.nodeid
            elif getattr(args[0], bstack1l11_opy_ (u"ࠧࡴ࡯ࡥࡧ࡬ࡨࠧᒀ"), None):
                target = args[0].nodeid
            instance = TestFramework.bstack1llll1l111l_opy_(target) if target else None
        return instance
    def __11llll1lll1_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
    ):
        key = test_framework_state.name
        bstack11lllll11l1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, PytestBDDFramework.bstack1l1111lllll_opy_, {})
        if not key in bstack11lllll11l1_opy_:
            bstack11lllll11l1_opy_[key] = []
        bstack1l1111l1111_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, PytestBDDFramework.bstack1l1111111ll_opy_, {})
        if not key in bstack1l1111l1111_opy_:
            bstack1l1111l1111_opy_[key] = []
        bstack1l111ll11ll_opy_ = {
            PytestBDDFramework.bstack1l1111lllll_opy_: bstack11lllll11l1_opy_,
            PytestBDDFramework.bstack1l1111111ll_opy_: bstack1l1111l1111_opy_,
        }
        if test_hook_state == bstack1llll11l11l_opy_.PRE:
            hook_name = args[1] if len(args) > 1 else None
            hook = {
                bstack1l11_opy_ (u"ࠨ࡫ࡦࡻࠥᒁ"): key,
                TestFramework.bstack1l111111ll1_opy_: uuid4().__str__(),
                TestFramework.bstack1l111111111_opy_: TestFramework.bstack1l11111ll1l_opy_,
                TestFramework.bstack11llll1l11l_opy_: datetime.now(tz=timezone.utc),
                TestFramework.bstack1l111ll1111_opy_: [],
                TestFramework.bstack1l1111111l1_opy_: hook_name,
                TestFramework.bstack1l11111ll11_opy_: bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()
            }
            bstack11lllll11l1_opy_[key].append(hook)
            bstack1l111ll11ll_opy_[PytestBDDFramework.bstack11lllll1l11_opy_] = key
        elif test_hook_state == bstack1llll11l11l_opy_.POST:
            bstack1l11111111l_opy_ = bstack11lllll11l1_opy_.get(key, [])
            hook = bstack1l11111111l_opy_.pop() if bstack1l11111111l_opy_ else None
            if hook:
                result = self.__1l111l1l1l1_opy_(*args)
                if result:
                    bstack11llll1l1l1_opy_ = result.get(bstack1l11_opy_ (u"ࠢࡰࡷࡷࡧࡴࡳࡥࠣᒂ"), TestFramework.bstack1l11111ll1l_opy_)
                    if bstack11llll1l1l1_opy_ != TestFramework.bstack1l11111ll1l_opy_:
                        hook[TestFramework.bstack1l111111111_opy_] = bstack11llll1l1l1_opy_
                hook[TestFramework.bstack1l111l11111_opy_] = datetime.now(tz=timezone.utc)
                hook[TestFramework.bstack1l11111ll11_opy_] = bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()
                self.bstack11lllll11ll_opy_(hook)
                logs = hook.get(TestFramework.bstack1l111l1l11l_opy_, [])
                self.bstack1l1ll11l11l_opy_(instance, logs)
                bstack1l1111l1111_opy_[key].append(hook)
                bstack1l111ll11ll_opy_[PytestBDDFramework.bstack11lllll111l_opy_] = key
        TestFramework.bstack1l111lll11l_opy_(instance, bstack1l111ll11ll_opy_)
        self.logger.debug(bstack1l11_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡩࡱࡲ࡯ࡤ࡫ࡶࡦࡰࡷ࠾ࠥࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫࠽ࡼ࡭ࡨࡽࢂ࠴ࡻࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦࡿࠣ࡬ࡴࡵ࡫ࡴࡡࡶࡸࡦࡸࡴࡦࡦࡀࡿ࡭ࡵ࡯࡬ࡵࡢࡷࡹࡧࡲࡵࡧࡧࢁࠥ࡮࡯ࡰ࡭ࡶࡣ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡃࠢᒃ") + str(bstack1l1111l1111_opy_) + bstack1l11_opy_ (u"ࠤࠥᒄ"))
    def __11llll1ll1l_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        fixturedef = TestFramework.bstack1l1ll11ll1l_opy_(args[0], [bstack1l11_opy_ (u"ࠥࡷࡨࡵࡰࡦࠤᒅ"), bstack1l11_opy_ (u"ࠦࡦࡸࡧ࡯ࡣࡰࡩࠧᒆ"), bstack1l11_opy_ (u"ࠧࡶࡡࡳࡣࡰࡷࠧᒇ"), bstack1l11_opy_ (u"ࠨࡩࡥࡵࠥᒈ"), bstack1l11_opy_ (u"ࠢࡶࡰ࡬ࡸࡹ࡫ࡳࡵࠤᒉ"), bstack1l11_opy_ (u"ࠣࡤࡤࡷࡪ࡯ࡤࠣᒊ")]) if len(args) > 0 else {}
        request = args[1] if len(args) > 1 else None
        scenario = args[2] if len(args) == 3 else None
        scope = request.scope if hasattr(request, bstack1l11_opy_ (u"ࠤࡶࡧࡴࡶࡥࠣᒋ")) else fixturedef.get(bstack1l11_opy_ (u"ࠥࡷࡨࡵࡰࡦࠤᒌ"), None)
        fixturename = request.fixturename if hasattr(request, bstack1l11_opy_ (u"ࠦ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦࠤᒍ")) else None
        node = request.node if hasattr(request, bstack1l11_opy_ (u"ࠧࡴ࡯ࡥࡧࠥᒎ")) else None
        target = request.node.nodeid if hasattr(node, bstack1l11_opy_ (u"ࠨ࡮ࡰࡦࡨ࡭ࡩࠨᒏ")) else None
        baseid = fixturedef.get(bstack1l11_opy_ (u"ࠢࡣࡣࡶࡩ࡮ࡪࠢᒐ"), None) or bstack1l11_opy_ (u"ࠣࠤᒑ")
        if (not target or len(baseid) > 0) and hasattr(request, bstack1l11_opy_ (u"ࠤࡢࡴࡾ࡬ࡵ࡯ࡥ࡬ࡸࡪࡳࠢᒒ")):
            target = PytestBDDFramework.__1l111l111ll_opy_(request._pyfuncitem.location) if hasattr(request._pyfuncitem, bstack1l11_opy_ (u"ࠥࡰࡴࡩࡡࡵ࡫ࡲࡲࠧᒓ")) else None
            if target and not TestFramework.bstack1llll1l111l_opy_(target):
                self.__11llllll1ll_opy_(context, test_framework_state, target, (target, request._pyfuncitem.location))
                node = request._pyfuncitem
                self.logger.debug(bstack1l11_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡪ࡮ࡾࡴࡶࡴࡨࡣࡪࡼࡥ࡯ࡶ࠽ࠤ࡫ࡧ࡬࡭ࡤࡤࡧࡰࠦࡴࡢࡴࡪࡩࡹࡃࡻࡵࡣࡵ࡫ࡪࡺࡽࠡࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࡃࡻࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࢂࠦ࡮ࡰࡦࡨࡁࢀࡴ࡯ࡥࡧࢀࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࠨᒔ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠧࠨᒕ"))
        if not fixturedef or not scope or not target:
            self.logger.warning(bstack1l11_opy_ (u"ࠨࡴࡳࡣࡦ࡯ࡤ࡬ࡩࡹࡶࡸࡶࡪࡥࡥࡷࡧࡱࡸ࠿ࠦࡵ࡯ࡪࡤࡲࡩࡲࡥࡥࠢࡨࡺࡪࡴࡴ࠾ࡽࡷࡩࡸࡺ࡟ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡹࡧࡴࡦࡿ࠱ࡿࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱ࡟ࡴࡶࡤࡸࡪࢃࠠࡧ࡫ࡻࡸࡺࡸࡥࡥࡧࡩࡁࢀ࡬ࡩࡹࡶࡸࡶࡪࡪࡥࡧࡿࠣࡷࡨࡵࡰࡦ࠿ࡾࡷࡨࡵࡰࡦࡿࠣࡸࡦࡸࡧࡦࡶࡀࠦᒖ") + str(target) + bstack1l11_opy_ (u"ࠢࠣᒗ"))
            return None
        instance = TestFramework.bstack1llll1l111l_opy_(target)
        if not instance:
            self.logger.warning(bstack1l11_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡠࡧࡹࡩࡳࡺ࠺ࠡࡷࡱ࡬ࡦࡴࡤ࡭ࡧࡧࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࢁࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥࡾࠢࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫࠽ࡼࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࢃࠠࡴࡥࡲࡴࡪࡃࡻࡴࡥࡲࡴࡪࢃࠠࡣࡣࡶࡩ࡮ࡪ࠽ࡼࡤࡤࡷࡪ࡯ࡤࡾࠢࡷࡥࡷ࡭ࡥࡵ࠿ࠥᒘ") + str(target) + bstack1l11_opy_ (u"ࠤࠥᒙ"))
            return None
        bstack1l111l1ll11_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, PytestBDDFramework.bstack1l1111l1l1l_opy_, {})
        if os.getenv(bstack1l11_opy_ (u"ࠥࡗࡉࡑ࡟ࡄࡎࡌࡣࡋࡒࡁࡈࡡࡉࡍ࡝࡚ࡕࡓࡇࡖࠦᒚ"), bstack1l11_opy_ (u"ࠦ࠶ࠨᒛ")) == bstack1l11_opy_ (u"ࠧ࠷ࠢᒜ"):
            bstack11llllll11l_opy_ = bstack1l11_opy_ (u"ࠨ࠺ࠣᒝ").join((scope, fixturename))
            bstack11lllllll11_opy_ = datetime.now(tz=timezone.utc)
            bstack1l111lll111_opy_ = {
                bstack1l11_opy_ (u"ࠢ࡬ࡧࡼࠦᒞ"): bstack11llllll11l_opy_,
                bstack1l11_opy_ (u"ࠣࡶࡤ࡫ࡸࠨᒟ"): PytestBDDFramework.__1l1111l11ll_opy_(request.node, scenario),
                bstack1l11_opy_ (u"ࠤࡩ࡭ࡽࡺࡵࡳࡧࠥᒠ"): fixturedef,
                bstack1l11_opy_ (u"ࠥࡷࡨࡵࡰࡦࠤᒡ"): scope,
                bstack1l11_opy_ (u"ࠦࡹࡿࡰࡦࠤᒢ"): None,
            }
            try:
                if test_hook_state == bstack1llll11l11l_opy_.POST and callable(getattr(args[-1], bstack1l11_opy_ (u"ࠧ࡭ࡥࡵࡡࡵࡩࡸࡻ࡬ࡵࠤᒣ"), None)):
                    bstack1l111lll111_opy_[bstack1l11_opy_ (u"ࠨࡴࡺࡲࡨࠦᒤ")] = TestFramework.bstack1l1l1l11111_opy_(args[-1].get_result())
            except Exception as e:
                pass
            if test_hook_state == bstack1llll11l11l_opy_.PRE:
                bstack1l111lll111_opy_[bstack1l11_opy_ (u"ࠢࡶࡷ࡬ࡨࠧᒥ")] = uuid4().__str__()
                bstack1l111lll111_opy_[PytestBDDFramework.bstack11llll1l11l_opy_] = bstack11lllllll11_opy_
            elif test_hook_state == bstack1llll11l11l_opy_.POST:
                bstack1l111lll111_opy_[PytestBDDFramework.bstack1l111l11111_opy_] = bstack11lllllll11_opy_
            if bstack11llllll11l_opy_ in bstack1l111l1ll11_opy_:
                bstack1l111l1ll11_opy_[bstack11llllll11l_opy_].update(bstack1l111lll111_opy_)
                self.logger.debug(bstack1l11_opy_ (u"ࠣࡷࡳࡨࡦࡺࡥࡥࠢࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫࠽ࡼࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࢃࠠࡴࡥࡲࡴࡪࡃࡻࡴࡥࡲࡴࡪࢃࠠࡧ࡫ࡻࡸࡺࡸࡥ࠾ࠤᒦ") + str(bstack1l111l1ll11_opy_[bstack11llllll11l_opy_]) + bstack1l11_opy_ (u"ࠤࠥᒧ"))
            else:
                bstack1l111l1ll11_opy_[bstack11llllll11l_opy_] = bstack1l111lll111_opy_
                self.logger.debug(bstack1l11_opy_ (u"ࠥࡷࡦࡼࡥࡥࠢࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫࠽ࡼࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࢃࠠࡴࡥࡲࡴࡪࡃࡻࡴࡥࡲࡴࡪࢃࠠࡧ࡫ࡻࡸࡺࡸࡥ࠾ࡽࡷࡩࡸࡺ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡾࠢࡷࡶࡦࡩ࡫ࡦࡦࡢࡪ࡮ࡾࡴࡶࡴࡨࡷࡂࠨᒨ") + str(len(bstack1l111l1ll11_opy_)) + bstack1l11_opy_ (u"ࠦࠧᒩ"))
        TestFramework.bstack1lllll1ll11_opy_(instance, PytestBDDFramework.bstack1l1111l1l1l_opy_, bstack1l111l1ll11_opy_)
        self.logger.debug(bstack1l11_opy_ (u"ࠧࡹࡡࡷࡧࡧࠤ࡫࡯ࡸࡵࡷࡵࡩࡸࡃࡻ࡭ࡧࡱࠬࡹࡸࡡࡤ࡭ࡨࡨࡤ࡬ࡩࡹࡶࡸࡶࡪࡹࠩࡾࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࠧᒪ") + str(instance.ref()) + bstack1l11_opy_ (u"ࠨࠢᒫ"))
        return instance
    def __11llllll1ll_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        target: Any,
        *args,
    ):
        ctx = bstack1llll11ll1l_opy_.create_context(target)
        ob = bstack1lll111l11l_opy_(ctx, self.bstack1ll11ll1l11_opy_, self.bstack11llll1l1ll_opy_, test_framework_state)
        TestFramework.bstack1l111lll11l_opy_(ob, {
            TestFramework.bstack1ll11l1111l_opy_: context.test_framework_name,
            TestFramework.bstack1l1ll1l1111_opy_: context.test_framework_version,
            TestFramework.bstack1l1111l1ll1_opy_: [],
            PytestBDDFramework.bstack1l1111l1l1l_opy_: {},
            PytestBDDFramework.bstack1l1111111ll_opy_: {},
            PytestBDDFramework.bstack1l1111lllll_opy_: {},
        })
        if len(args) > 1 and isinstance(args[1], tuple):
            TestFramework.bstack1lllll1ll11_opy_(ob, TestFramework.bstack1l111ll1ll1_opy_, str(args[1][0]))
        if context.platform_index >= 0:
            TestFramework.bstack1lllll1ll11_opy_(ob, TestFramework.bstack1ll11lll1ll_opy_, context.platform_index)
        TestFramework.bstack1lllll1llll_opy_[ctx.id] = ob
        self.logger.debug(bstack1l11_opy_ (u"ࠢࡴࡣࡹࡩࡩࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠡࡥࡷࡼ࠳࡯ࡤ࠾ࡽࡦࡸࡽ࠴ࡩࡥࡿࠣࡸࡦࡸࡧࡦࡶࡀࡿࡹࡧࡲࡨࡧࡷࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡸࡃࠢᒬ") + str(TestFramework.bstack1lllll1llll_opy_.keys()) + bstack1l11_opy_ (u"ࠣࠤᒭ"))
        return ob
    @staticmethod
    def __1l11111l1ll_opy_(instance, args):
        request, feature, scenario = args
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l11_opy_ (u"ࠩ࡬ࡨࠬᒮ"): id(step),
                bstack1l11_opy_ (u"ࠪࡸࡪࡾࡴࠨᒯ"): step.name,
                bstack1l11_opy_ (u"ࠫࡰ࡫ࡹࡸࡱࡵࡨࠬᒰ"): step.keyword,
            })
        meta = {
            bstack1l11_opy_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪ࠭ᒱ"): {
                bstack1l11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᒲ"): feature.name,
                bstack1l11_opy_ (u"ࠧࡱࡣࡷ࡬ࠬᒳ"): feature.filename,
                bstack1l11_opy_ (u"ࠨࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ᒴ"): feature.description
            },
            bstack1l11_opy_ (u"ࠩࡶࡧࡪࡴࡡࡳ࡫ࡲࠫᒵ"): {
                bstack1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨᒶ"): scenario.name
            },
            bstack1l11_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪᒷ"): steps,
            bstack1l11_opy_ (u"ࠬ࡫ࡸࡢ࡯ࡳࡰࡪࡹࠧᒸ"): PytestBDDFramework.__1l1111l1l11_opy_(request.node)
        }
        instance.data.update(
            {
                TestFramework.bstack1l11111l1l1_opy_: meta
            }
        )
    def bstack11lllll11ll_opy_(self, hook: Dict[str, Any]) -> None:
        bstack1l11_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡔࡷࡵࡣࡦࡵࡶࡩࡸࠦࡴࡩࡧࠣࡌࡴࡵ࡫ࡍࡧࡹࡩࡱࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶࠤࡸ࡯࡭ࡪ࡮ࡤࡶࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡐࡡࡷࡣࠣ࡭ࡲࡶ࡬ࡦ࡯ࡨࡲࡹࡧࡴࡪࡱࡱ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡲ࡫ࡴࡩࡱࡧ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡇ࡭࡫ࡣ࡬ࡵࠣࡸ࡭࡫ࠠࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮ࠣࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠦࡩ࡯ࡵ࡬ࡨࡪࠦࡾ࠰࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠰ࡗࡳࡰࡴࡧࡤࡦࡦࡄࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡆࡰࡴࠣࡩࡦࡩࡨࠡࡨ࡬ࡰࡪࠦࡩ࡯ࠢ࡫ࡳࡴࡱ࡟࡭ࡧࡹࡩࡱࡥࡦࡪ࡮ࡨࡷ࠱ࠦࡲࡦࡲ࡯ࡥࡨ࡫ࡳࠡࠤࡗࡩࡸࡺࡌࡦࡸࡨࡰࠧࠦࡷࡪࡶ࡫ࠤࠧࡎ࡯ࡰ࡭ࡏࡩࡻ࡫࡬ࠣࠢ࡬ࡲࠥ࡯ࡴࡴࠢࡳࡥࡹ࡮࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡉࡧࠢࡤࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡺࡨࡦࠢࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠥࡳࡡࡵࡥ࡫ࡩࡸࠦࡡࠡ࡯ࡲࡨ࡮࡬ࡩࡦࡦࠣ࡬ࡴࡵ࡫࠮࡮ࡨࡺࡪࡲࠠࡧ࡫࡯ࡩ࠱ࠦࡩࡵࠢࡦࡶࡪࡧࡴࡦࡵࠣࡥࠥࡒ࡯ࡨࡇࡱࡸࡷࡿࠠࡰࡤ࡭ࡩࡨࡺࠠࡸ࡫ࡷ࡬ࠥࡧࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࠢࡧࡩࡹࡧࡩ࡭ࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡖ࡭ࡲ࡯࡬ࡢࡴ࡯ࡽ࠱ࠦࡩࡵࠢࡳࡶࡴࡩࡥࡴࡵࡨࡷࠥࡈࡵࡪ࡮ࡧࡐࡪࡼࡥ࡭ࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡ࡫ࡱࠤࡍࡵ࡯࡬ࡎࡨࡺࡪࡲ࠯ࡃࡷ࡬ࡰࡩࡒࡥࡷࡧ࡯ࡌࡴࡵ࡫ࡆࡸࡨࡲࡹࠦࡢࡺࠢࡵࡩࡵࡲࡡࡤ࡫ࡱ࡫ࠥࠨࡂࡶ࡫࡯ࡨࡑ࡫ࡶࡦ࡮ࠥࠤࡼ࡯ࡴࡩࠢࠥࡌࡴࡵ࡫ࡍࡧࡹࡩࡱ࠵ࡂࡶ࡫࡯ࡨࡑ࡫ࡶࡦ࡮ࡋࡳࡴࡱࡅࡷࡧࡱࡸࠧ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠱࡚ࠥࡨࡦࠢࡦࡶࡪࡧࡴࡦࡦࠣࡐࡴ࡭ࡅ࡯ࡶࡵࡽࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡡࡳࡧࠣࡥࡩࡪࡥࡥࠢࡷࡳࠥࡺࡨࡦࠢ࡫ࡳࡴࡱࠧࡴࠢࠥࡰࡴ࡭ࡳࠣࠢ࡯࡭ࡸࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡄࡶ࡬ࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡨࡰࡱ࡮࠾࡚ࠥࡨࡦࠢࡨࡺࡪࡴࡴࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡯࡮ࡨࠢࡨࡼ࡮ࡹࡴࡪࡰࡪࠤࡱࡵࡧࡴࠢࡤࡲࡩࠦࡨࡰࡱ࡮ࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡪࡲࡳࡰࡥ࡬ࡦࡸࡨࡰࡤ࡬ࡩ࡭ࡧࡶ࠾ࠥࡒࡩࡴࡶࠣࡳ࡫ࠦࡐࡢࡶ࡫ࠤࡴࡨࡪࡦࡥࡷࡷࠥ࡬ࡲࡰ࡯ࠣࡸ࡭࡫ࠠࡕࡧࡶࡸࡑ࡫ࡶࡦ࡮ࠣࡱࡴࡴࡩࡵࡱࡵ࡭ࡳ࡭࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡢࡶ࡫࡯ࡨࡤࡲࡥࡷࡧ࡯ࡣ࡫࡯࡬ࡦࡵ࠽ࠤࡑ࡯ࡳࡵࠢࡲࡪࠥࡖࡡࡵࡪࠣࡳࡧࡰࡥࡤࡶࡶࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡂࡶ࡫࡯ࡨࡑ࡫ࡶࡦ࡮ࠣࡱࡴࡴࡩࡵࡱࡵ࡭ࡳ࡭࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧᒹ")
        global _1l1ll1ll1l1_opy_
        platform_index = os.environ[bstack1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᒺ")]
        bstack1l1ll1l11ll_opy_ = os.path.join(bstack1l1l1ll1l11_opy_, (bstack1l1lll11l1l_opy_ + str(platform_index)), bstack1l11111llll_opy_)
        if not os.path.exists(bstack1l1ll1l11ll_opy_) or not os.path.isdir(bstack1l1ll1l11ll_opy_):
            return
        logs = hook.get(bstack1l11_opy_ (u"ࠣ࡮ࡲ࡫ࡸࠨᒻ"), [])
        with os.scandir(bstack1l1ll1l11ll_opy_) as entries:
            for entry in entries:
                abs_path = os.path.abspath(entry.path)
                if abs_path in _1l1ll1ll1l1_opy_:
                    self.logger.info(bstack1l11_opy_ (u"ࠤࡓࡥࡹ࡮ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡࡲࡵࡳࡨ࡫ࡳࡴࡧࡧࠤࢀࢃࠢᒼ").format(abs_path))
                    continue
                if entry.is_file():
                    try:
                        timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                    except Exception:
                        timestamp = bstack1l11_opy_ (u"ࠥࠦᒽ")
                    log_entry = bstack1lll1l11l1l_opy_(
                        kind=bstack1l11_opy_ (u"࡙ࠦࡋࡓࡕࡡࡄࡘ࡙ࡇࡃࡉࡏࡈࡒ࡙ࠨᒾ"),
                        message=bstack1l11_opy_ (u"ࠧࠨᒿ"),
                        level=bstack1l11_opy_ (u"ࠨࠢᓀ"),
                        timestamp=timestamp,
                        fileName=entry.name,
                        bstack1l1ll1lll1l_opy_=entry.stat().st_size,
                        bstack1l1ll11llll_opy_=bstack1l11_opy_ (u"ࠢࡎࡃࡑ࡙ࡆࡒ࡟ࡖࡒࡏࡓࡆࡊࠢᓁ"),
                        bstack11ll11_opy_=os.path.abspath(entry.path),
                        bstack11llll1ll11_opy_=hook.get(TestFramework.bstack1l111111ll1_opy_)
                    )
                    logs.append(log_entry)
                    _1l1ll1ll1l1_opy_.add(abs_path)
        platform_index = os.environ[bstack1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨᓂ")]
        bstack1l111l1111l_opy_ = os.path.join(bstack1l1l1ll1l11_opy_, (bstack1l1lll11l1l_opy_ + str(platform_index)), bstack1l11111llll_opy_, bstack1l111l11l1l_opy_)
        if not os.path.exists(bstack1l111l1111l_opy_) or not os.path.isdir(bstack1l111l1111l_opy_):
            self.logger.info(bstack1l11_opy_ (u"ࠤࡑࡳࠥࡈࡵࡪ࡮ࡧࡐࡪࡼࡥ࡭ࡊࡲࡳࡰࡋࡶࡦࡰࡷࠤࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴࠢࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽࠥ࡬࡯ࡶࡰࡧࠤࡦࡺ࠺ࠡࡽࢀࠦᓃ").format(bstack1l111l1111l_opy_))
        else:
            self.logger.info(bstack1l11_opy_ (u"ࠥࡔࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡃࡷ࡬ࡰࡩࡒࡥࡷࡧ࡯ࡌࡴࡵ࡫ࡆࡸࡨࡲࡹࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶࠤ࡫ࡸ࡯࡮ࠢࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠿ࠦࡻࡾࠤᓄ").format(bstack1l111l1111l_opy_))
            with os.scandir(bstack1l111l1111l_opy_) as entries:
                for entry in entries:
                    abs_path = os.path.abspath(entry.path)
                    if abs_path in _1l1ll1ll1l1_opy_:
                        self.logger.info(bstack1l11_opy_ (u"ࠦࡕࡧࡴࡩࠢࡤࡰࡷ࡫ࡡࡥࡻࠣࡴࡷࡵࡣࡦࡵࡶࡩࡩࠦࡻࡾࠤᓅ").format(abs_path))
                        continue
                    if entry.is_file():
                        try:
                            timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                        except Exception:
                            timestamp = bstack1l11_opy_ (u"ࠧࠨᓆ")
                        log_entry = bstack1lll1l11l1l_opy_(
                            kind=bstack1l11_opy_ (u"ࠨࡔࡆࡕࡗࡣࡆ࡚ࡔࡂࡅࡋࡑࡊࡔࡔࠣᓇ"),
                            message=bstack1l11_opy_ (u"ࠢࠣᓈ"),
                            level=bstack1l11_opy_ (u"ࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠧᓉ"),
                            timestamp=timestamp,
                            fileName=entry.name,
                            bstack1l1ll1lll1l_opy_=entry.stat().st_size,
                            bstack1l1ll11llll_opy_=bstack1l11_opy_ (u"ࠤࡐࡅࡓ࡛ࡁࡍࡡࡘࡔࡑࡕࡁࡅࠤᓊ"),
                            bstack11ll11_opy_=os.path.abspath(entry.path),
                            bstack1l1ll11lll1_opy_=hook.get(TestFramework.bstack1l111111ll1_opy_)
                        )
                        logs.append(log_entry)
                        _1l1ll1ll1l1_opy_.add(abs_path)
        hook[bstack1l11_opy_ (u"ࠥࡰࡴ࡭ࡳࠣᓋ")] = logs
    def bstack1l1ll11l11l_opy_(
        self,
        bstack1l1lll11111_opy_: bstack1lll111l11l_opy_,
        entries: List[bstack1lll1l11l1l_opy_],
    ):
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = os.environ.get(bstack1l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡑࡏ࡟ࡃࡋࡑࡣࡘࡋࡓࡔࡋࡒࡒࡤࡏࡄࠣᓌ"))
        req.platform_index = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1ll11lll1ll_opy_)
        req.execution_context.hash = str(bstack1l1lll11111_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l1lll11111_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l1lll11111_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1ll11l1111l_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1l1ll1l1111_opy_)
            log_entry.uuid = entry.bstack11llll1ll11_opy_ if entry.bstack11llll1ll11_opy_ else TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1ll11ll1l1l_opy_)
            log_entry.test_framework_state = bstack1l1lll11111_opy_.state.name
            log_entry.message = entry.message.encode(bstack1l11_opy_ (u"ࠧࡻࡴࡧ࠯࠻ࠦᓍ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            if isinstance(entry.level, str) and len(entry.level.strip()) > 0:
                log_entry.level = entry.level.strip()
            if entry.kind == bstack1l11_opy_ (u"ࠨࡔࡆࡕࡗࡣࡆ࡚ࡔࡂࡅࡋࡑࡊࡔࡔࠣᓎ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1l1ll1lll1l_opy_
                log_entry.file_path = entry.bstack11ll11_opy_
        def bstack1l1l1ll11ll_opy_():
            bstack1l1111ll11_opy_ = datetime.now()
            try:
                self.bstack1ll1llllll1_opy_.LogCreatedEvent(req)
                bstack1l1lll11111_opy_.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠢࡨࡴࡳࡧ࠿ࡹࡥ࡯ࡦࡢࡰࡴ࡭࡟ࡤࡴࡨࡥࡹ࡫ࡤࡠࡧࡹࡩࡳࡺ࡟ࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࠦᓏ"), datetime.now() - bstack1l1111ll11_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l11_opy_ (u"ࠣࡴࡳࡧ࠲࡫ࡲࡳࡱࡵ࠾ࠥࡹࡥ࡯ࡦࡢࡰࡴ࡭࡟ࡤࡴࡨࡥࡹ࡫ࡤࡠࡧࡹࡩࡳࡺ࡟ࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࠤࢀࢃࠢᓐ").format(str(e)))
                traceback.print_exc()
        self.bstack1llllllllll_opy_.enqueue(bstack1l1l1ll11ll_opy_)
    def __1l111ll11l1_opy_(self, instance) -> None:
        bstack1l11_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡌࡰࡣࡧࡷࠥࡩࡵࡴࡶࡲࡱࠥࡺࡡࡨࡵࠣࡪࡴࡸࠠࡵࡪࡨࠤ࡬࡯ࡶࡦࡰࠣࡸࡪࡹࡴࠡࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠤ࡮ࡴࡳࡵࡣࡱࡧࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࡅࡵࡩࡦࡺࡥࡴࠢࡤࠤࡩ࡯ࡣࡵࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡴࡦࡵࡷࠤࡱ࡫ࡶࡦ࡮ࠣࡧࡺࡹࡴࡰ࡯ࠣࡱࡪࡺࡡࡥࡣࡷࡥࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࡤࠡࡨࡵࡳࡲࠐࠠࠡࠢࠣࠤࠥࠦࠠࡄࡷࡶࡸࡴࡳࡔࡢࡩࡐࡥࡳࡧࡧࡦࡴࠣࡥࡳࡪࠠࡶࡲࡧࡥࡹ࡫ࡳࠡࡶ࡫ࡩࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠠࡴࡶࡤࡸࡪࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡡࡶࡸࡦࡺࡥࡠࡧࡱࡸࡷ࡯ࡥࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢᓑ")
        bstack1l111ll11ll_opy_ = {bstack1l11_opy_ (u"ࠥࡧࡺࡹࡴࡰ࡯ࡢࡱࡪࡺࡡࡥࡣࡷࡥࠧᓒ"): bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()}
        TestFramework.bstack1l111lll11l_opy_(instance, bstack1l111ll11ll_opy_)
    @staticmethod
    def __1l111ll111l_opy_(instance, args):
        request, bstack1l111l1lll1_opy_ = args
        bstack1l111l1llll_opy_ = id(bstack1l111l1lll1_opy_)
        bstack1l1111lll1l_opy_ = instance.data[TestFramework.bstack1l11111l1l1_opy_]
        step = next(filter(lambda st: st[bstack1l11_opy_ (u"ࠫ࡮ࡪࠧᓓ")] == bstack1l111l1llll_opy_, bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫᓔ")]), None)
        step.update({
            bstack1l11_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᓕ"): datetime.now(tz=timezone.utc)
        })
        index = next((i for i, st in enumerate(bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᓖ")]) if st[bstack1l11_opy_ (u"ࠨ࡫ࡧࠫᓗ")] == step[bstack1l11_opy_ (u"ࠩ࡬ࡨࠬᓘ")]), None)
        if index is not None:
            bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᓙ")][index] = step
        instance.data[TestFramework.bstack1l11111l1l1_opy_] = bstack1l1111lll1l_opy_
    @staticmethod
    def __11llllllll1_opy_(instance, args):
        bstack1l11_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡹ࡫ࡩࡳࠦ࡬ࡦࡰࠣࡥࡷ࡭ࡳࠡ࡫ࡶࠤ࠷࠲ࠠࡪࡶࠣࡷ࡮࡭࡮ࡪࡨ࡬ࡩࡸࠦࡴࡩࡧࡵࡩࠥ࡯ࡳࠡࡰࡲࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡧࡲࡨࡵࠣࡥࡷ࡫ࠠ࠮ࠢ࡞ࡶࡪࡷࡵࡦࡵࡷ࠰ࠥࡹࡴࡦࡲࡠࠎࠥࠦࠠࠡࠢࠣࠤࠥ࡯ࡦࠡࡣࡵ࡫ࡸࠦࡡࡳࡧࠣ࠷ࠥࡺࡨࡦࡰࠣࡸ࡭࡫ࠠ࡭ࡣࡶࡸࠥࡼࡡ࡭ࡷࡨࠤ࡮ࡹࠠࡦࡺࡦࡩࡵࡺࡩࡰࡰࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢᓚ")
        bstack1l111l11ll1_opy_ = datetime.now(tz=timezone.utc)
        request = args[0]
        bstack1l111l1lll1_opy_ = args[1]
        bstack1l111l1llll_opy_ = id(bstack1l111l1lll1_opy_)
        bstack1l1111lll1l_opy_ = instance.data[TestFramework.bstack1l11111l1l1_opy_]
        step = None
        if bstack1l111l1llll_opy_ is not None and bstack1l1111lll1l_opy_.get(bstack1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫᓛ")):
            step = next(filter(lambda st: st[bstack1l11_opy_ (u"࠭ࡩࡥࠩᓜ")] == bstack1l111l1llll_opy_, bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᓝ")]), None)
            step.update({
                bstack1l11_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᓞ"): bstack1l111l11ll1_opy_,
            })
        if len(args) > 2:
            exception = args[2]
            step.update({
                bstack1l11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᓟ"): bstack1l11_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᓠ"),
                bstack1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᓡ"): str(exception)
            })
        else:
            if step is not None:
                step.update({
                    bstack1l11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᓢ"): bstack1l11_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ᓣ"),
                })
        index = next((i for i, st in enumerate(bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᓤ")]) if st[bstack1l11_opy_ (u"ࠨ࡫ࡧࠫᓥ")] == step[bstack1l11_opy_ (u"ࠩ࡬ࡨࠬᓦ")]), None)
        if index is not None:
            bstack1l1111lll1l_opy_[bstack1l11_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᓧ")][index] = step
        instance.data[TestFramework.bstack1l11111l1l1_opy_] = bstack1l1111lll1l_opy_
    @staticmethod
    def __1l1111l1l11_opy_(node):
        try:
            examples = []
            if hasattr(node, bstack1l11_opy_ (u"ࠫࡨࡧ࡬࡭ࡵࡳࡩࡨ࠭ᓨ")):
                examples = list(node.callspec.params[bstack1l11_opy_ (u"ࠬࡥࡰࡺࡶࡨࡷࡹࡥࡢࡥࡦࡢࡩࡽࡧ࡭ࡱ࡮ࡨࠫᓩ")].values())
            return examples
        except:
            return []
    def bstack1l1ll1ll1ll_opy_(self, instance: bstack1lll111l11l_opy_, bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]):
        bstack1l111l1l1ll_opy_ = (
            PytestBDDFramework.bstack11lllll1l11_opy_
            if bstack1llll1lllll_opy_[1] == bstack1llll11l11l_opy_.PRE
            else PytestBDDFramework.bstack11lllll111l_opy_
        )
        hook = PytestBDDFramework.bstack1l1111ll111_opy_(instance, bstack1l111l1l1ll_opy_)
        entries = hook.get(TestFramework.bstack1l111ll1111_opy_, []) if isinstance(hook, dict) else []
        entries.extend(TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, []))
        return entries
    def bstack1l1lll11l11_opy_(self, instance: bstack1lll111l11l_opy_, bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]):
        bstack1l111l1l1ll_opy_ = (
            PytestBDDFramework.bstack11lllll1l11_opy_
            if bstack1llll1lllll_opy_[1] == bstack1llll11l11l_opy_.PRE
            else PytestBDDFramework.bstack11lllll111l_opy_
        )
        PytestBDDFramework.bstack1l111l1l111_opy_(instance, bstack1l111l1l1ll_opy_)
        TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, []).clear()
    @staticmethod
    def bstack1l1111ll111_opy_(instance: bstack1lll111l11l_opy_, bstack1l111l1l1ll_opy_: str):
        bstack1l111l11l11_opy_ = (
            PytestBDDFramework.bstack1l1111111ll_opy_
            if bstack1l111l1l1ll_opy_ == PytestBDDFramework.bstack11lllll111l_opy_
            else PytestBDDFramework.bstack1l1111lllll_opy_
        )
        bstack1l1111ll1l1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l1l1ll_opy_, None)
        bstack11lllll1ll1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l11l11_opy_, None) if bstack1l1111ll1l1_opy_ else None
        return (
            bstack11lllll1ll1_opy_[bstack1l1111ll1l1_opy_][-1]
            if isinstance(bstack11lllll1ll1_opy_, dict) and len(bstack11lllll1ll1_opy_.get(bstack1l1111ll1l1_opy_, [])) > 0
            else None
        )
    @staticmethod
    def bstack1l111l1l111_opy_(instance: bstack1lll111l11l_opy_, bstack1l111l1l1ll_opy_: str):
        hook = PytestBDDFramework.bstack1l1111ll111_opy_(instance, bstack1l111l1l1ll_opy_)
        if isinstance(hook, dict):
            hook.get(TestFramework.bstack1l111ll1111_opy_, []).clear()
    @staticmethod
    def __1l11111l111_opy_(instance: bstack1lll111l11l_opy_, *args):
        if len(args) < 2 or not callable(getattr(args[1], bstack1l11_opy_ (u"ࠨࡧࡦࡶࡢࡶࡪࡩ࡯ࡳࡦࡶࠦᓪ"), None)):
            return
        if os.getenv(bstack1l11_opy_ (u"ࠢࡔࡆࡎࡣࡈࡒࡉࡠࡈࡏࡅࡌࡥࡌࡐࡉࡖࠦᓫ"), bstack1l11_opy_ (u"ࠣ࠳ࠥᓬ")) != bstack1l11_opy_ (u"ࠤ࠴ࠦᓭ"):
            PytestBDDFramework.logger.warning(bstack1l11_opy_ (u"ࠥ࡭࡬ࡴ࡯ࡳ࡫ࡱ࡫ࠥࡩࡡࡱ࡮ࡲ࡫ࠧᓮ"))
            return
        bstack1l111lll1l1_opy_ = {
            bstack1l11_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࠥᓯ"): (PytestBDDFramework.bstack11lllll1l11_opy_, PytestBDDFramework.bstack1l1111lllll_opy_),
            bstack1l11_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴࠢᓰ"): (PytestBDDFramework.bstack11lllll111l_opy_, PytestBDDFramework.bstack1l1111111ll_opy_),
        }
        for when in (bstack1l11_opy_ (u"ࠨࡳࡦࡶࡸࡴࠧᓱ"), bstack1l11_opy_ (u"ࠢࡤࡣ࡯ࡰࠧᓲ"), bstack1l11_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࠥᓳ")):
            bstack1l1111lll11_opy_ = args[1].get_records(when)
            if not bstack1l1111lll11_opy_:
                continue
            records = [
                bstack1lll1l11l1l_opy_(
                    kind=TestFramework.bstack1l1ll111111_opy_,
                    message=r.message,
                    level=r.levelname if hasattr(r, bstack1l11_opy_ (u"ࠤ࡯ࡩࡻ࡫࡬࡯ࡣࡰࡩࠧᓴ")) and r.levelname else None,
                    timestamp=(
                        datetime.fromtimestamp(r.created, tz=timezone.utc)
                        if hasattr(r, bstack1l11_opy_ (u"ࠥࡧࡷ࡫ࡡࡵࡧࡧࠦᓵ")) and r.created
                        else None
                    ),
                )
                for r in bstack1l1111lll11_opy_
                if isinstance(getattr(r, bstack1l11_opy_ (u"ࠦࡲ࡫ࡳࡴࡣࡪࡩࠧᓶ"), None), str) and r.message.strip()
            ]
            if not records:
                continue
            bstack1l1111l1lll_opy_, bstack1l111l11l11_opy_ = bstack1l111lll1l1_opy_.get(when, (None, None))
            bstack1l111l1ll1l_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l1111l1lll_opy_, None) if bstack1l1111l1lll_opy_ else None
            bstack11lllll1ll1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l11l11_opy_, None) if bstack1l111l1ll1l_opy_ else None
            if isinstance(bstack11lllll1ll1_opy_, dict) and len(bstack11lllll1ll1_opy_.get(bstack1l111l1ll1l_opy_, [])) > 0:
                hook = bstack11lllll1ll1_opy_[bstack1l111l1ll1l_opy_][-1]
                if isinstance(hook, dict) and TestFramework.bstack1l111ll1111_opy_ in hook:
                    hook[TestFramework.bstack1l111ll1111_opy_].extend(records)
                    continue
            logs = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, [])
            logs.extend(records)
    @staticmethod
    def __11llllll1l1_opy_(args) -> Dict[str, Any]:
        request, feature, scenario = args
        bstack1ll1llll1_opy_ = request.node.nodeid
        test_name = PytestBDDFramework.__1l1111l111l_opy_(request.node, scenario)
        bstack1l111l111l1_opy_ = feature.filename
        if not bstack1ll1llll1_opy_ or not test_name or not bstack1l111l111l1_opy_:
            return None
        code = None
        return {
            TestFramework.bstack1ll11ll1l1l_opy_: uuid4().__str__(),
            TestFramework.bstack1l1111ll11l_opy_: bstack1ll1llll1_opy_,
            TestFramework.bstack1ll11l11l1l_opy_: test_name,
            TestFramework.bstack1l1l11llll1_opy_: bstack1ll1llll1_opy_,
            TestFramework.bstack1l11111lll1_opy_: bstack1l111l111l1_opy_,
            TestFramework.bstack11llllll111_opy_: PytestBDDFramework.__1l1111l11ll_opy_(feature, scenario),
            TestFramework.bstack11lllll1l1l_opy_: code,
            TestFramework.bstack1l11lllllll_opy_: TestFramework.bstack11lllll1111_opy_,
            TestFramework.bstack1l11l1l1111_opy_: test_name
        }
    @staticmethod
    def __1l1111l111l_opy_(node, scenario):
        if hasattr(node, bstack1l11_opy_ (u"ࠬࡩࡡ࡭࡮ࡶࡴࡪࡩࠧᓷ")):
            parts = node.nodeid.rsplit(bstack1l11_opy_ (u"ࠨ࡛ࠣᓸ"))
            params = parts[-1]
            return bstack1l11_opy_ (u"ࠢࡼࡿࠣ࡟ࢀࢃࠢᓹ").format(scenario.name, params)
        return scenario.name
    @staticmethod
    def __1l1111l11ll_opy_(feature, scenario) -> List[str]:
        return (list(feature.tags) if hasattr(feature, bstack1l11_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭ᓺ")) else []) + (list(scenario.tags) if hasattr(scenario, bstack1l11_opy_ (u"ࠩࡷࡥ࡬ࡹࠧᓻ")) else [])
    @staticmethod
    def __1l111l111ll_opy_(location):
        return bstack1l11_opy_ (u"ࠥ࠾࠿ࠨᓼ").join(filter(lambda x: isinstance(x, str), location))