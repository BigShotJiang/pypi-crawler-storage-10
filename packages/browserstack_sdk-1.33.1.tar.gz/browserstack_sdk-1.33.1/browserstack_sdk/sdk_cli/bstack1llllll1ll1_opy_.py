# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import threading
import os
from typing import Dict, Any
from dataclasses import dataclass
from collections import defaultdict
from datetime import timedelta
@dataclass
class bstack1llllll1lll_opy_:
    id: str
    hash: str
    thread_id: int
    process_id: int
    type: str
class bstack1llll11ll1l_opy_:
    bstack11lll1l1lll_opy_ = bstack1l11_opy_ (u"ࠥࡦࡪࡴࡣࡩ࡯ࡤࡶࡰࠨᗿ")
    context: bstack1llllll1lll_opy_
    data: Dict[str, Any]
    platform_index: int
    def __init__(self, context: bstack1llllll1lll_opy_):
        self.context = context
        self.data = dict({bstack1llll11ll1l_opy_.bstack11lll1l1lll_opy_: defaultdict(lambda: timedelta(microseconds=0))})
        self.platform_index = int(os.environ.get(bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᘀ"), bstack1l11_opy_ (u"ࠬ࠶ࠧᘁ")))
    def ref(self) -> str:
        return str(self.context.id)
    def bstack1lllllll11l_opy_(self, target: object):
        return bstack1llll11ll1l_opy_.create_context(target) == self.context
    def bstack1l1llll11l1_opy_(self, context: bstack1llllll1lll_opy_):
        return context and context.thread_id == self.context.thread_id and context.process_id == self.context.process_id
    def bstack11l111l111_opy_(self, key: str, value: timedelta):
        self.data[bstack1llll11ll1l_opy_.bstack11lll1l1lll_opy_][key] += value
    def bstack1lll1l1llll_opy_(self) -> dict:
        return self.data[bstack1llll11ll1l_opy_.bstack11lll1l1lll_opy_]
    @staticmethod
    def create_context(
        target: object,
        thread_id=threading.get_ident(),
        process_id=os.getpid(),
    ):
        return bstack1llllll1lll_opy_(
            id=hash(target),
            hash=hash(target),
            thread_id=thread_id,
            process_id=process_id,
            type=target,
        )