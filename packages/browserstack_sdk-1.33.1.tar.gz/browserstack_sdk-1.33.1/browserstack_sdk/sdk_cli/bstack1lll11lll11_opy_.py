# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from typing import Dict, List, Any, Callable, Tuple, Union
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1lll1111l11_opy_ import bstack1ll1l11ll11_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
    bstack1llllll11l1_opy_,
)
from bstack_utils.helper import  bstack1l11lll11_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll11l1l1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1ll1ll1l1ll_opy_, bstack1lll111l11l_opy_, bstack1llll11l11l_opy_, bstack1lll1l11l1l_opy_
from typing import Tuple, Any
import threading
from bstack_utils.bstack11l1lll11l_opy_ import bstack1l111lll1_opy_
from browserstack_sdk.sdk_cli.bstack1ll1lllll11_opy_ import bstack1ll1ll1l1l1_opy_
from bstack_utils.percy import bstack1lll111lll_opy_
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.constants import *
import re
class bstack1ll1llll1ll_opy_(bstack1ll1l11ll11_opy_):
    def __init__(self, bstack1l1l11l1l1l_opy_: Dict[str, str]):
        super().__init__()
        self.bstack1l1l11l1l1l_opy_ = bstack1l1l11l1l1l_opy_
        self.percy = bstack1lll111lll_opy_()
        self.bstack1lllll1l11_opy_ = bstack1l111lll1_opy_()
        self.bstack1l1l11l11ll_opy_()
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_, bstack1llll1l1lll_opy_.PRE), self.bstack1l1l11l1l11_opy_)
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.POST), self.bstack1ll111ll1ll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1lll11ll1_opy_(self, instance: bstack1llllll11l1_opy_, driver: object):
        bstack1l1l1l11ll1_opy_ = TestFramework.bstack1lllll1lll1_opy_(instance.context)
        for t in bstack1l1l1l11ll1_opy_:
            bstack1l1l1lll111_opy_ = TestFramework.bstack1lllll1l1l1_opy_(t, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
            if any(instance is d[1] for d in bstack1l1l1lll111_opy_) or instance == driver:
                return t
    def bstack1l1l11l1l11_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if not bstack1lll11l1l1l_opy_.bstack1ll11l1l1l1_opy_(method_name):
                return
            platform_index = f.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_, 0)
            bstack1l1lll11111_opy_ = self.bstack1l1lll11ll1_opy_(instance, driver)
            bstack1l1l11ll11l_opy_ = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1l1l11llll1_opy_, None)
            if not bstack1l1l11ll11l_opy_:
                self.logger.debug(bstack1l11_opy_ (u"ࠦࡴࡴ࡟ࡱࡴࡨࡣࡪࡾࡥࡤࡷࡷࡩ࠿ࠦࡲࡦࡶࡸࡶࡳ࡯࡮ࡨࠢࡤࡷࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡩࡴࠢࡱࡳࡹࠦࡹࡦࡶࠣࡷࡹࡧࡲࡵࡧࡧࠦዷ"))
                return
            driver_command = f.bstack1ll1111lll1_opy_(*args)
            for command in bstack11l1ll1l1l_opy_:
                if command == driver_command:
                    self.bstack1l11ll1ll1_opy_(driver, platform_index)
            bstack1l1lllll1l_opy_ = self.percy.bstack1ll11111ll_opy_()
            if driver_command in bstack111l1l1l1_opy_[bstack1l1lllll1l_opy_]:
                self.bstack1lllll1l11_opy_.bstack1l1l11l11_opy_(bstack1l1l11ll11l_opy_, driver_command)
        except Exception as e:
            self.logger.error(bstack1l11_opy_ (u"ࠧࡵ࡮ࡠࡲࡵࡩࡤ࡫ࡸࡦࡥࡸࡸࡪࡀࠠࡦࡴࡵࡳࡷࠨዸ"), e)
    def bstack1ll111ll1ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
        bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠨ࡯࡯ࡡࡤࡪࡹ࡫ࡲࡠࡶࡨࡷࡹࡀࠠ࡯ࡱࠣࡨࡷ࡯ࡶࡦࡴࡶࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣዹ") + str(kwargs) + bstack1l11_opy_ (u"ࠢࠣዺ"))
            return
        if len(bstack1l1l1lll111_opy_) > 1:
            self.logger.debug(bstack1l11_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡾࡰࡪࡴࠨࡥࡴ࡬ࡺࡪࡸ࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥዻ") + str(kwargs) + bstack1l11_opy_ (u"ࠤࠥዼ"))
        bstack1l1l11lll11_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1lll111_opy_[0]
        driver = bstack1l1l11lll11_opy_()
        if not driver:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡳࡳࡥࡡࡧࡶࡨࡶࡤࡺࡥࡴࡶ࠽ࠤࡳࡵࠠࡥࡴ࡬ࡺࡪࡸࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦዽ") + str(kwargs) + bstack1l11_opy_ (u"ࠦࠧዾ"))
            return
        bstack1l1l11ll111_opy_ = {
            TestFramework.bstack1ll11l11l1l_opy_: bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࠣࡲࡦࡳࡥࠣዿ"),
            TestFramework.bstack1ll11ll1l1l_opy_: bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࠤࡺࡻࡩࡥࠤጀ"),
            TestFramework.bstack1l1l11llll1_opy_: bstack1l11_opy_ (u"ࠢࡵࡧࡶࡸࠥࡸࡥࡳࡷࡱࠤࡳࡧ࡭ࡦࠤጁ")
        }
        bstack1l1l11lll1l_opy_ = { key: f.bstack1lllll1l1l1_opy_(instance, key) for key in bstack1l1l11ll111_opy_ }
        bstack1l1l11lllll_opy_ = [key for key, value in bstack1l1l11lll1l_opy_.items() if not value]
        if bstack1l1l11lllll_opy_:
            for key in bstack1l1l11lllll_opy_:
                self.logger.debug(bstack1l11_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡰ࡭ࡸࡹࡩ࡯ࡩࠣࠦጂ") + str(key) + bstack1l11_opy_ (u"ࠤࠥጃ"))
            return
        platform_index = f.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_, 0)
        if self.bstack1l1l11l1l1l_opy_.percy_capture_mode == bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡤࡣࡶࡩࠧጄ"):
            bstack1111l11l1_opy_ = bstack1l1l11lll1l_opy_.get(TestFramework.bstack1l1l11llll1_opy_) + bstack1l11_opy_ (u"ࠦ࠲ࡺࡥࡴࡶࡦࡥࡸ࡫ࠢጅ")
            bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack1ll111l111l_opy_(EVENTS.bstack1l1l11l1lll_opy_.value)
            PercySDK.screenshot(
                driver,
                bstack1111l11l1_opy_,
                bstack1ll11l1l_opy_=bstack1l1l11lll1l_opy_[TestFramework.bstack1ll11l11l1l_opy_],
                bstack1llll11l_opy_=bstack1l1l11lll1l_opy_[TestFramework.bstack1ll11ll1l1l_opy_],
                bstack1ll111ll11_opy_=platform_index
            )
            bstack1ll1l1l11l1_opy_.end(EVENTS.bstack1l1l11l1lll_opy_.value, bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧጆ"), bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠨ࠺ࡦࡰࡧࠦጇ"), True, None, None, None, None, test_name=bstack1111l11l1_opy_)
    def bstack1l11ll1ll1_opy_(self, driver, platform_index):
        if self.bstack1lllll1l11_opy_.bstack1lllll11l_opy_() is True or self.bstack1lllll1l11_opy_.capturing() is True:
            return
        self.bstack1lllll1l11_opy_.bstack1ll1ll11l_opy_()
        while not self.bstack1lllll1l11_opy_.bstack1lllll11l_opy_():
            bstack1l1l11ll11l_opy_ = self.bstack1lllll1l11_opy_.bstack111ll1ll_opy_()
            self.bstack1lll111111_opy_(driver, bstack1l1l11ll11l_opy_, platform_index)
        self.bstack1lllll1l11_opy_.bstack11l1lll1ll_opy_()
    def bstack1lll111111_opy_(self, driver, bstack11llll11l1_opy_, platform_index, test=None):
        from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
        bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack1ll111l111l_opy_(EVENTS.bstack11l1lll111_opy_.value)
        if test != None:
            bstack1ll11l1l_opy_ = getattr(test, bstack1l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬገ"), None)
            bstack1llll11l_opy_ = getattr(test, bstack1l11_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ጉ"), None)
            PercySDK.screenshot(driver, bstack11llll11l1_opy_, bstack1ll11l1l_opy_=bstack1ll11l1l_opy_, bstack1llll11l_opy_=bstack1llll11l_opy_, bstack1ll111ll11_opy_=platform_index)
        else:
            PercySDK.screenshot(driver, bstack11llll11l1_opy_)
        bstack1ll1l1l11l1_opy_.end(EVENTS.bstack11l1lll111_opy_.value, bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤጊ"), bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠥ࠾ࡪࡴࡤࠣጋ"), True, None, None, None, None, test_name=bstack11llll11l1_opy_)
    def bstack1l1l11l11ll_opy_(self):
        os.environ[bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡊࡘࡃ࡚ࠩጌ")] = str(self.bstack1l1l11l1l1l_opy_.success)
        os.environ[bstack1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡋࡒࡄ࡛ࡢࡇࡆࡖࡔࡖࡔࡈࡣࡒࡕࡄࡆࠩግ")] = str(self.bstack1l1l11l1l1l_opy_.percy_capture_mode)
        self.percy.bstack1l1l11ll1ll_opy_(self.bstack1l1l11l1l1l_opy_.is_percy_auto_enabled)
        self.percy.bstack1l1l11l1ll1_opy_(self.bstack1l1l11l1l1l_opy_.percy_build_id)