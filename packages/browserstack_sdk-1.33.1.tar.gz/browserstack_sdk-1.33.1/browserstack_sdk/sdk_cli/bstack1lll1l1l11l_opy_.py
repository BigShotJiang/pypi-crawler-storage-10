# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import json
import time
import os
import threading
import asyncio
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
    bstack1llllll11l1_opy_,
    bstack1llllll1lll_opy_,
)
from typing import Tuple, Dict, Any, List, Union
from bstack_utils.helper import bstack1l1ll1l1ll1_opy_, bstack1l111ll11_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll11l1l1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_, bstack1lll111l11l_opy_
from browserstack_sdk.sdk_cli.bstack1lll1l1ll11_opy_ import bstack1lll11ll1ll_opy_
from browserstack_sdk.sdk_cli.bstack1l1lll1l1l1_opy_ import bstack1l1lll1ll11_opy_
from typing import Tuple, List, Any
from bstack_utils.bstack11ll1l111l_opy_ import bstack1ll1llll11_opy_, bstack11lllll11l_opy_, bstack1l1l11ll_opy_
from browserstack_sdk import sdk_pb2 as structs
class bstack1lll1lll1ll_opy_(bstack1l1lll1ll11_opy_):
    bstack1l11llll111_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡥࡴ࡬ࡺࡪࡸࡳࠣጭ")
    bstack1l1ll111lll_opy_ = bstack1l11_opy_ (u"ࠥࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠤጮ")
    bstack1l11lllll11_opy_ = bstack1l11_opy_ (u"ࠦࡳࡵ࡮ࡠࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠨጯ")
    bstack1l11ll1llll_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡷࡪࡹࡳࡪࡱࡱࡷࠧጰ")
    bstack1l11lll1l1l_opy_ = bstack1l11_opy_ (u"ࠨࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢ࡭ࡳࡹࡴࡢࡰࡦࡩࡤࡸࡥࡧࡵࠥጱ")
    bstack1l1ll11111l_opy_ = bstack1l11_opy_ (u"ࠢࡤࡤࡷࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡤࡩࡲࡦࡣࡷࡩࡩࠨጲ")
    bstack1l11lll1lll_opy_ = bstack1l11_opy_ (u"ࠣࡥࡥࡸࡤࡹࡥࡴࡵ࡬ࡳࡳࡥ࡮ࡢ࡯ࡨࠦጳ")
    bstack1l11lll11l1_opy_ = bstack1l11_opy_ (u"ࠤࡦࡦࡹࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡴࡶࡤࡸࡺࡹࠢጴ")
    def __init__(self):
        super().__init__(bstack1l1lll11lll_opy_=self.bstack1l11llll111_opy_, frameworks=[bstack1lll11l1l1l_opy_.NAME])
        if not self.is_enabled():
            return
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.BEFORE_EACH, bstack1llll11l11l_opy_.POST), self.bstack1l11lll1ll1_opy_)
        if bstack1l111ll11_opy_():
            TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.POST), self.bstack1ll111ll111_opy_)
        else:
            TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.PRE), self.bstack1ll111ll111_opy_)
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.POST), self.bstack1ll111ll1ll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11lll1ll1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        bstack1l11ll1lll1_opy_ = self.bstack1l11lll1111_opy_(instance.context)
        if not bstack1l11ll1lll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡷࡪࡺ࡟ࡢࡥࡷ࡭ࡻ࡫࡟ࡱࡣࡪࡩ࠿ࠦ࡮ࡰࠢࡳࡥ࡬࡫ࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࠣጵ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠦࠧጶ"))
            return
        f.bstack1lllll1ll11_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll111lll_opy_, bstack1l11ll1lll1_opy_)
    def bstack1l11lll1111_opy_(self, context: bstack1llllll1lll_opy_, bstack1l11lll11ll_opy_= True):
        if bstack1l11lll11ll_opy_:
            bstack1l11ll1lll1_opy_ = self.bstack1l1llll1l11_opy_(context, reverse=True)
        else:
            bstack1l11ll1lll1_opy_ = self.bstack1l1lll1ll1l_opy_(context, reverse=True)
        return [f for f in bstack1l11ll1lll1_opy_ if f[1].state != bstack1lllll111ll_opy_.QUIT]
    def bstack1ll111ll111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1ll1_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if not bstack1l1ll1l1ll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠ࡯ࡱࡷࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠣࡷࡪࡹࡳࡪࡱࡱࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣጷ") + str(kwargs) + bstack1l11_opy_ (u"ࠨࠢጸ"))
            return
        bstack1l11ll1lll1_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l11ll1lll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠢࡰࡰࡢࡦࡪ࡬࡯ࡳࡧࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥጹ") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤጺ"))
            return
        if len(bstack1l11ll1lll1_opy_) > 1:
            self.logger.debug(
                bstack1111l111ll_opy_ (u"ࠤࡲࡲࡤࡨࡥࡧࡱࡵࡩࡤࡺࡥࡴࡶ࠽ࠤࢀࡲࡥ࡯ࠪࡳࡥ࡬࡫࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࡾ࡯ࡼࡧࡲࡨࡵࢀࠦጻ"))
        bstack1l11llll1ll_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11ll1lll1_opy_[0]
        page = bstack1l11llll1ll_opy_()
        if not page:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡲࡤ࡫ࡪࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥጼ") + str(kwargs) + bstack1l11_opy_ (u"ࠦࠧጽ"))
            return
        bstack11l11l1l1_opy_ = getattr(args[0], bstack1l11_opy_ (u"ࠧࡴ࡯ࡥࡧ࡬ࡨࠧጾ"), None)
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡇࡴࡴࡴࡦࡺࡷࡓࡵࡺࡩࡰࡰࡶࠦጿ")).get(bstack1l11_opy_ (u"ࠢࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠤፀ")):
            try:
                page.evaluate(bstack1l11_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤፁ"),
                            bstack1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨ࡮ࡢ࡯ࡨࠦ࠿࠭ፂ") + json.dumps(
                                bstack11l11l1l1_opy_) + bstack1l11_opy_ (u"ࠥࢁࢂࠨፃ"))
            except Exception as e:
                self.logger.debug(bstack1l11_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡰࡤࡱࡪࠦࡻࡾࠤፄ"), e)
    def bstack1ll111ll1ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1ll1_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if not bstack1l1ll1l1ll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠ࡯ࡱࡷࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠣࡷࡪࡹࡳࡪࡱࡱࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣፅ") + str(kwargs) + bstack1l11_opy_ (u"ࠨࠢፆ"))
            return
        bstack1l11ll1lll1_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l11ll1lll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠢࡰࡰࡢࡦࡪ࡬࡯ࡳࡧࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥፇ") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤፈ"))
            return
        if len(bstack1l11ll1lll1_opy_) > 1:
            self.logger.debug(
                bstack1111l111ll_opy_ (u"ࠤࡲࡲࡤࡨࡥࡧࡱࡵࡩࡤࡺࡥࡴࡶ࠽ࠤࢀࡲࡥ࡯ࠪࡳࡥ࡬࡫࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࡾ࡯ࡼࡧࡲࡨࡵࢀࠦፉ"))
        bstack1l11llll1ll_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11ll1lll1_opy_[0]
        page = bstack1l11llll1ll_opy_()
        if not page:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡲࡤ࡫ࡪࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥፊ") + str(kwargs) + bstack1l11_opy_ (u"ࠦࠧፋ"))
            return
        status = f.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l11lllllll_opy_, None)
        if not status:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡴ࡯ࠡࡵࡷࡥࡹࡻࡳࠡࡨࡲࡶࠥࡺࡥࡴࡶ࠯ࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࠣፌ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠨࠢፍ"))
            return
        bstack1l11llll11l_opy_ = {bstack1l11_opy_ (u"ࠢࡴࡶࡤࡸࡺࡹࠢፎ"): status.lower()}
        bstack1l11lll111l_opy_ = f.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l11lllll1l_opy_, None)
        if status.lower() == bstack1l11_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨፏ") and bstack1l11lll111l_opy_ is not None:
            bstack1l11llll11l_opy_[bstack1l11_opy_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩፐ")] = bstack1l11lll111l_opy_[0][bstack1l11_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ፑ")][0] if isinstance(bstack1l11lll111l_opy_, list) else str(bstack1l11lll111l_opy_)
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡅࡲࡲࡹ࡫ࡸࡵࡑࡳࡸ࡮ࡵ࡮ࡴࠤፒ")).get(bstack1l11_opy_ (u"ࠧࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤፓ")):
            try:
                page.evaluate(
                        bstack1l11_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢፔ"),
                        bstack1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࠬፕ")
                        + json.dumps(bstack1l11llll11l_opy_)
                        + bstack1l11_opy_ (u"ࠣࡿࠥፖ")
                    )
            except Exception as e:
                self.logger.debug(bstack1l11_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࠦࡻࡾࠤፗ"), e)
    def bstack1l1ll1ll111_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        f: TestFramework,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1ll1_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if not bstack1l1ll1l1ll1_opy_:
            self.logger.debug(
                bstack1111l111ll_opy_ (u"ࠥࡱࡦࡸ࡫ࡠࡱ࠴࠵ࡾࡥࡳࡺࡰࡦ࠾ࠥࡴ࡯ࡵࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡵࡨࡷࡸ࡯࡯࡯࠮ࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࡾ࡯ࡼࡧࡲࡨࡵࢀࠦፘ"))
            return
        bstack1l11ll1lll1_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l11ll1lll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠦࡴࡴ࡟ࡣࡧࡩࡳࡷ࡫࡟ࡵࡧࡶࡸ࠿ࠦ࡮ࡰࠢࡧࡶ࡮ࡼࡥࡳࡵࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢፙ") + str(kwargs) + bstack1l11_opy_ (u"ࠧࠨፚ"))
            return
        if len(bstack1l11ll1lll1_opy_) > 1:
            self.logger.debug(
                bstack1111l111ll_opy_ (u"ࠨ࡯࡯ࡡࡥࡩ࡫ࡵࡲࡦࡡࡷࡩࡸࡺ࠺ࠡࡽ࡯ࡩࡳ࠮ࡰࡢࡩࡨࡣ࡮ࡴࡳࡵࡣࡱࡧࡪࡹࠩࡾࠢࡧࡶ࡮ࡼࡥࡳࡵࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࡻ࡬ࡹࡤࡶ࡬ࡹࡽࠣ፛"))
        bstack1l11llll1ll_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11ll1lll1_opy_[0]
        page = bstack1l11llll1ll_opy_()
        if not page:
            self.logger.debug(bstack1l11_opy_ (u"ࠢ࡮ࡣࡵ࡯ࡤࡵ࠱࠲ࡻࡢࡷࡾࡴࡣ࠻ࠢࡱࡳࠥࡶࡡࡨࡧࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢ፜") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤ፝"))
            return
        timestamp = int(time.time() * 1000)
        data = bstack1l11_opy_ (u"ࠤࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡼࡲࡨࡀࠢ፞") + str(timestamp)
        try:
            page.evaluate(
                bstack1l11_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦ፟"),
                bstack1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ፠").format(
                    json.dumps(
                        {
                            bstack1l11_opy_ (u"ࠧࡧࡣࡵ࡫ࡲࡲࠧ፡"): bstack1l11_opy_ (u"ࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ።"),
                            bstack1l11_opy_ (u"ࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ፣"): {
                                bstack1l11_opy_ (u"ࠣࡶࡼࡴࡪࠨ፤"): bstack1l11_opy_ (u"ࠤࡄࡲࡳࡵࡴࡢࡶ࡬ࡳࡳࠨ፥"),
                                bstack1l11_opy_ (u"ࠥࡨࡦࡺࡡࠣ፦"): data,
                                bstack1l11_opy_ (u"ࠦࡱ࡫ࡶࡦ࡮ࠥ፧"): bstack1l11_opy_ (u"ࠧࡪࡥࡣࡷࡪࠦ፨")
                            }
                        }
                    )
                )
            )
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠨࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡲ࠵࠶ࡿࠠࡢࡰࡱࡳࡹࡧࡴࡪࡱࡱࠤࡲࡧࡲ࡬࡫ࡱ࡫ࠥࢁࡽࠣ፩"), e)
    def bstack1l1l1l1111l_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        f: TestFramework,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11lll1ll1_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if f.bstack1lllll1l1l1_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll11111l_opy_, False):
            return
        self.bstack1ll11l111ll_opy_()
        req = structs.TestSessionEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11lll1ll_opy_)
        req.test_framework_name = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11l1111l_opy_)
        req.test_framework_version = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1ll1l1111_opy_)
        req.test_framework_state = bstack1llll1lllll_opy_[0].name
        req.test_hook_state = bstack1llll1lllll_opy_[1].name
        req.test_uuid = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11ll1l1l_opy_)
        for bstack1l11llll1l1_opy_ in bstack1lll11ll1ll_opy_.bstack1lllll1llll_opy_.values():
            session = req.automation_sessions.add()
            session.provider = (
                bstack1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠨ፪")
                if bstack1l1ll1l1ll1_opy_
                else bstack1l11_opy_ (u"ࠣࡷࡱ࡯ࡳࡵࡷ࡯ࡡࡪࡶ࡮ࡪࠢ፫")
            )
            session.ref = bstack1l11llll1l1_opy_.ref()
            session.hub_url = bstack1lll11ll1ll_opy_.bstack1lllll1l1l1_opy_(bstack1l11llll1l1_opy_, bstack1lll11ll1ll_opy_.bstack1l1l1111l11_opy_, bstack1l11_opy_ (u"ࠤࠥ፬"))
            session.framework_name = bstack1l11llll1l1_opy_.framework_name
            session.framework_version = bstack1l11llll1l1_opy_.framework_version
            session.framework_session_id = bstack1lll11ll1ll_opy_.bstack1lllll1l1l1_opy_(bstack1l11llll1l1_opy_, bstack1lll11ll1ll_opy_.bstack1l1l111lll1_opy_, bstack1l11_opy_ (u"ࠥࠦ፭"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        return req
    def bstack1ll11l1l111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs
    ):
        bstack1l11ll1lll1_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1lll1lll1ll_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l11ll1lll1_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠦ࡬࡫ࡴࡠࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡪࡲࡪࡸࡨࡶ࠿ࠦ࡮ࡰࠢࡳࡥ࡬࡫ࡳࠡࡨࡲࡶࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࡽ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࢂࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤࡰࡽࡡࡳࡩࡶࡁࠧ፮") + str(kwargs) + bstack1l11_opy_ (u"ࠧࠨ፯"))
            return
        if len(bstack1l11ll1lll1_opy_) > 1:
            self.logger.debug(bstack1l11_opy_ (u"ࠨࡧࡦࡶࡢࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡥࡴ࡬ࡺࡪࡸ࠺ࠡࡽ࡯ࡩࡳ࠮ࡰࡢࡩࡨࡣ࡮ࡴࡳࡵࡣࡱࡧࡪࡹࠩࡾࠢࡧࡶ࡮ࡼࡥࡳࡵࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢ፰") + str(kwargs) + bstack1l11_opy_ (u"ࠢࠣ፱"))
        bstack1l11llll1ll_opy_, bstack1l1l11ll1l1_opy_ = bstack1l11ll1lll1_opy_[0]
        page = bstack1l11llll1ll_opy_()
        if not page:
            self.logger.debug(bstack1l11_opy_ (u"ࠣࡩࡨࡸࡤࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࡡࡧࡶ࡮ࡼࡥࡳ࠼ࠣࡲࡴࠦࡰࡢࡩࡨࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣ፲") + str(kwargs) + bstack1l11_opy_ (u"ࠤࠥ፳"))
            return
        return page
    def bstack1ll11l11lll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs
    ):
        caps = {}
        bstack1l11lll1l11_opy_ = {}
        for bstack1l11llll1l1_opy_ in bstack1lll11ll1ll_opy_.bstack1lllll1llll_opy_.values():
            caps = bstack1lll11ll1ll_opy_.bstack1lllll1l1l1_opy_(bstack1l11llll1l1_opy_, bstack1lll11ll1ll_opy_.bstack1l1l11l11l1_opy_, bstack1l11_opy_ (u"ࠥࠦ፴"))
        bstack1l11lll1l11_opy_[bstack1l11_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠤ፵")] = caps.get(bstack1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࠨ፶"), bstack1l11_opy_ (u"ࠨࠢ፷"))
        bstack1l11lll1l11_opy_[bstack1l11_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪࠨ፸")] = caps.get(bstack1l11_opy_ (u"ࠣࡱࡶࠦ፹"), bstack1l11_opy_ (u"ࠤࠥ፺"))
        bstack1l11lll1l11_opy_[bstack1l11_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠧ፻")] = caps.get(bstack1l11_opy_ (u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ፼"), bstack1l11_opy_ (u"ࠧࠨ፽"))
        bstack1l11lll1l11_opy_[bstack1l11_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠢ፾")] = caps.get(bstack1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ፿"), bstack1l11_opy_ (u"ࠣࠤᎀ"))
        return bstack1l11lll1l11_opy_
    def bstack1ll11ll111l_opy_(self, page: object, bstack1ll1111llll_opy_, args={}):
        try:
            bstack1l11llllll1_opy_ = bstack1l11_opy_ (u"ࠤࠥࠦ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࠩ࠰࠱࠲ࡧࡹࡴࡢࡥ࡮ࡗࡩࡱࡁࡳࡩࡶ࠭ࠥࢁࡻࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࠣࡲࡪࡽࠠࡑࡴࡲࡱ࡮ࡹࡥࠩࠪࡵࡩࡸࡵ࡬ࡷࡧ࠯ࠤࡷ࡫ࡪࡦࡥࡷ࠭ࠥࡃ࠾ࠡࡽࡾࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡸࡺࡡࡤ࡭ࡖࡨࡰࡇࡲࡨࡵ࠱ࡴࡺࡹࡨࠩࡴࡨࡷࡴࡲࡶࡦࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡿ࡫ࡴ࡟ࡣࡱࡧࡽࢂࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡿࢀ࠭ࡀࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࢃࠩࠩࡽࡤࡶ࡬ࡥࡪࡴࡱࡱࢁ࠮ࠨࠢࠣᎁ")
            bstack1ll1111llll_opy_ = bstack1ll1111llll_opy_.replace(bstack1l11_opy_ (u"ࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨᎂ"), bstack1l11_opy_ (u"ࠦࡧࡹࡴࡢࡥ࡮ࡗࡩࡱࡁࡳࡩࡶࠦᎃ"))
            script = bstack1l11llllll1_opy_.format(fn_body=bstack1ll1111llll_opy_, arg_json=json.dumps(args))
            return page.evaluate(script)
        except Exception as e:
            self.logger.error(bstack1l11_opy_ (u"ࠧࡧ࠱࠲ࡻࡢࡷࡨࡸࡩࡱࡶࡢࡩࡽ࡫ࡣࡶࡶࡨ࠾ࠥࡋࡲࡳࡱࡵࠤࡪࡾࡥࡤࡷࡷ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡦ࠷࠱ࡺࠢࡶࡧࡷ࡯ࡰࡵ࠮ࠣࠦᎄ") + str(e) + bstack1l11_opy_ (u"ࠨࠢᎅ"))