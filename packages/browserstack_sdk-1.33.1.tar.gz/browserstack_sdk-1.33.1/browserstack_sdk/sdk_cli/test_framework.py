# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import logging
from enum import Enum
import os
import threading
import traceback
from typing import Dict, List, Any, Callable, Tuple, Union
import abc
from datetime import datetime, timezone
from dataclasses import dataclass
from browserstack_sdk.sdk_cli.bstack1llllllllll_opy_ import bstack1lllllll1l1_opy_
from browserstack_sdk.sdk_cli.bstack1llllll1ll1_opy_ import bstack1llll11ll1l_opy_, bstack1llllll1lll_opy_
class bstack1llll11l11l_opy_(Enum):
    PRE = 0
    POST = 1
    def __repr__(self) -> str:
        return bstack1l11_opy_ (u"ࠨࡔࡦࡵࡷࡌࡴࡵ࡫ࡔࡶࡤࡸࡪ࠴ࡻࡾࠤᗑ").format(self.name)
class bstack1ll1ll1l1ll_opy_(Enum):
    NONE = 0
    BEFORE_ALL = 1
    LOG = 2
    SETUP_FIXTURE = 3
    INIT_TEST = 4
    BEFORE_EACH = 5
    AFTER_EACH = 6
    TEST = 7
    STEP = 8
    LOG_REPORT = 9
    AFTER_ALL = 10
    def __eq__(self, other):
        if self.__class__ is other.__class__:
            return self.value == other.value
        return NotImplemented
    def __lt__(self, other):
        if self.__class__ is other.__class__:
            return self.value < other.value
        return NotImplemented
    def __repr__(self) -> str:
        return bstack1l11_opy_ (u"ࠢࡕࡧࡶࡸࡋࡸࡡ࡮ࡧࡺࡳࡷࡱࡓࡵࡣࡷࡩ࠳ࢁࡽࠣᗒ").format(self.name)
class bstack1lll111l11l_opy_(bstack1llll11ll1l_opy_):
    bstack1ll11ll1l11_opy_: List[str]
    bstack11llll1l1ll_opy_: Dict[str, str]
    state: bstack1ll1ll1l1ll_opy_
    bstack1lllll11111_opy_: datetime
    bstack1llll1ll11l_opy_: datetime
    def __init__(
        self,
        context: bstack1llllll1lll_opy_,
        bstack1ll11ll1l11_opy_: List[str],
        bstack11llll1l1ll_opy_: Dict[str, str],
        state=bstack1ll1ll1l1ll_opy_.NONE,
    ):
        super().__init__(context)
        self.bstack1ll11ll1l11_opy_ = bstack1ll11ll1l11_opy_
        self.bstack11llll1l1ll_opy_ = bstack11llll1l1ll_opy_
        self.state = state
        self.bstack1lllll11111_opy_ = datetime.now(tz=timezone.utc)
        self.bstack1llll1ll11l_opy_ = datetime.now(tz=timezone.utc)
    def bstack1lllll1ll11_opy_(self, bstack1llll11ll11_opy_: bstack1ll1ll1l1ll_opy_):
        bstack1llll1lll1l_opy_ = bstack1ll1ll1l1ll_opy_(bstack1llll11ll11_opy_).name
        if not bstack1llll1lll1l_opy_:
            return False
        if bstack1llll11ll11_opy_ == self.state:
            return False
        self.state = bstack1llll11ll11_opy_
        self.bstack1llll1ll11l_opy_ = datetime.now(tz=timezone.utc)
        return True
@dataclass
class bstack1l111ll1l1l_opy_:
    test_framework_name: str
    test_framework_version: str
    platform_index: int
@dataclass
class bstack1lll1l11l1l_opy_:
    kind: str
    message: str
    level: Union[None, str] = None
    timestamp: Union[None, datetime] = datetime.now(tz=timezone.utc)
    fileName: str = None
    bstack1l1ll1lll1l_opy_: int = None
    bstack1l1ll11llll_opy_: str = None
    bstack11ll11_opy_: str = None
    bstack111ll111_opy_: str = None
    bstack1l1ll11lll1_opy_: str = None
    bstack11llll1ll11_opy_: str = None
class TestFramework(abc.ABC):
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    bstack1ll11ll1l1l_opy_ = bstack1l11_opy_ (u"ࠣࡶࡨࡷࡹࡥࡵࡶ࡫ࡧࠦᗓ")
    bstack1l1111ll11l_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡪࡦࠥᗔ")
    bstack1ll11l11l1l_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡰࡤࡱࡪࠨᗕ")
    bstack1l11111lll1_opy_ = bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡩ࡭ࡱ࡫࡟ࡱࡣࡷ࡬ࠧᗖ")
    bstack11llllll111_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡸࡦ࡭ࡳࠣᗗ")
    bstack1l11lllllll_opy_ = bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣࡷ࡫ࡳࡶ࡮ࡷࠦᗘ")
    bstack1l1lll111ll_opy_ = bstack1l11_opy_ (u"ࠢࡵࡧࡶࡸࡤࡸࡥࡴࡷ࡯ࡸࡤࡧࡴࠣᗙ")
    bstack1l1ll1l1l11_opy_ = bstack1l11_opy_ (u"ࠣࡶࡨࡷࡹࡥࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠥᗚ")
    bstack1l1l1l111ll_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡦࡰࡧࡩࡩࡥࡡࡵࠤᗛ")
    bstack1l111ll1ll1_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠ࡮ࡲࡧࡦࡺࡩࡰࡰࠥᗜ")
    bstack1ll11l1111l_opy_ = bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡴࡡ࡮ࡧࠥᗝ")
    bstack1l1ll1l1111_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠢᗞ")
    bstack11lllll1l1l_opy_ = bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣࡨࡵࡤࡦࠤᗟ")
    bstack1l1l11llll1_opy_ = bstack1l11_opy_ (u"ࠢࡵࡧࡶࡸࡤࡸࡥࡳࡷࡱࡣࡳࡧ࡭ࡦࠤᗠ")
    bstack1ll11lll1ll_opy_ = bstack1l11_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢ࡭ࡳࡪࡥࡹࠤᗡ")
    bstack1l11lllll1l_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡧࡣ࡬ࡰࡺࡸࡥࠣᗢ")
    bstack1l111ll1l11_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡨࡤ࡭ࡱࡻࡲࡦࡡࡷࡽࡵ࡫ࠢᗣ")
    bstack1l1111l1ll1_opy_ = bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡ࡯ࡳ࡬ࡹࠢᗤ")
    bstack1l11111l1l1_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡱࡪࡺࡡࠣᗥ")
    bstack11llll11l1l_opy_ = bstack1l11_opy_ (u"࠭ࡴࡦࡵࡷࡣࡸࡩ࡯ࡱࡧࡶࠫᗦ")
    bstack1l11l1l1111_opy_ = bstack1l11_opy_ (u"ࠢࡢࡷࡷࡳࡲࡧࡴࡦࡡࡶࡩࡸࡹࡩࡰࡰࡢࡲࡦࡳࡥࠣᗧ")
    bstack11llll1l11l_opy_ = bstack1l11_opy_ (u"ࠣࡧࡹࡩࡳࡺ࡟ࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠦᗨ")
    bstack1l111l11111_opy_ = bstack1l11_opy_ (u"ࠤࡨࡺࡪࡴࡴࡠࡧࡱࡨࡪࡪ࡟ࡢࡶࠥᗩ")
    bstack1l111111ll1_opy_ = bstack1l11_opy_ (u"ࠥ࡬ࡴࡵ࡫ࡠ࡫ࡧࠦᗪ")
    bstack1l111111111_opy_ = bstack1l11_opy_ (u"ࠦ࡭ࡵ࡯࡬ࡡࡵࡩࡸࡻ࡬ࡵࠤᗫ")
    bstack1l111ll1111_opy_ = bstack1l11_opy_ (u"ࠧ࡮࡯ࡰ࡭ࡢࡰࡴ࡭ࡳࠣᗬ")
    bstack1l1111111l1_opy_ = bstack1l11_opy_ (u"ࠨࡨࡰࡱ࡮ࡣࡳࡧ࡭ࡦࠤᗭ")
    bstack1l111l1l11l_opy_ = bstack1l11_opy_ (u"ࠢ࡭ࡱࡪࡷࠧᗮ")
    bstack1l11111ll11_opy_ = bstack1l11_opy_ (u"ࠣࡥࡸࡷࡹࡵ࡭ࡠ࡯ࡨࡸࡦࡪࡡࡵࡣࠥᗯ")
    bstack11lllll1111_opy_ = bstack1l11_opy_ (u"ࠤࡳࡩࡳࡪࡩ࡯ࡩࠥᗰ")
    bstack1l11111ll1l_opy_ = bstack1l11_opy_ (u"ࠥࡴࡪࡴࡤࡪࡰࡪࠦᗱ")
    bstack1l1ll1l111l_opy_ = bstack1l11_opy_ (u"࡙ࠦࡋࡓࡕࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙ࠨᗲ")
    bstack1l1ll111111_opy_ = bstack1l11_opy_ (u"࡚ࠧࡅࡔࡖࡢࡐࡔࡍࠢᗳ")
    bstack1l1l1llll1l_opy_ = bstack1l11_opy_ (u"ࠨࡔࡆࡕࡗࡣࡆ࡚ࡔࡂࡅࡋࡑࡊࡔࡔࠣᗴ")
    bstack1lllll1llll_opy_: Dict[str, bstack1lll111l11l_opy_] = dict()
    bstack11lll1lllll_opy_: Dict[str, List[Callable]] = dict()
    bstack1ll11ll1l11_opy_: List[str]
    bstack11llll1l1ll_opy_: Dict[str, str]
    def __init__(
        self,
        bstack1ll11ll1l11_opy_: List[str],
        bstack11llll1l1ll_opy_: Dict[str, str],
        bstack1llllllllll_opy_: bstack1lllllll1l1_opy_
    ):
        self.bstack1ll11ll1l11_opy_ = bstack1ll11ll1l11_opy_
        self.bstack11llll1l1ll_opy_ = bstack11llll1l1ll_opy_
        self.bstack1llllllllll_opy_ = bstack1llllllllll_opy_
    def track_event(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        self.logger.debug(bstack1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡥࡷࡧࡱࡸ࠿ࠦࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࡃࡻࡾࠢࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࡁࢀࢃࠠࡢࡴࡪࡷࡂࢁࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࡽࢀࠦᗵ").format(test_framework_state,test_hook_state,args,kwargs))
    def bstack1l1111ll1ll_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        bstack1l11l111l11_opy_ = TestFramework.bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_)
        if not bstack1l11l111l11_opy_ in TestFramework.bstack11lll1lllll_opy_:
            return
        self.logger.debug(bstack1l11_opy_ (u"ࠣ࡫ࡱࡺࡴࡱࡩ࡯ࡩࠣࡿࢂࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࡴࠤᗶ").format(len(TestFramework.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_])))
        for callback in TestFramework.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_]:
            try:
                callback(self, instance, bstack1llll1lllll_opy_, *args, **kwargs)
            except Exception as e:
                self.logger.error(bstack1l11_opy_ (u"ࠤࡨࡶࡷࡵࡲࠡ࡫ࡱࡺࡴࡱࡩ࡯ࡩࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯࠿ࠦࡻࡾࠤᗷ").format(e))
                traceback.print_exc()
    @abc.abstractmethod
    def bstack1l1l1l11l1l_opy_(self):
        return
    @abc.abstractmethod
    def bstack1l1ll1ll1ll_opy_(self, instance, bstack1llll1lllll_opy_):
        return
    @abc.abstractmethod
    def bstack1l1lll11l11_opy_(self, instance, bstack1llll1lllll_opy_):
        return
    @staticmethod
    def bstack1llll1l111l_opy_(target: object, strict=True):
        if target is None:
            return None
        ctx = bstack1llll11ll1l_opy_.create_context(target)
        instance = TestFramework.bstack1lllll1llll_opy_.get(ctx.id, None)
        if instance and instance.bstack1lllllll11l_opy_(target):
            return instance
        return instance if instance and not strict else None
    @staticmethod
    def bstack1l1l1ll11l1_opy_(reverse=True) -> List[bstack1lll111l11l_opy_]:
        thread_id = threading.get_ident()
        process_id = os.getpid()
        return sorted(
            filter(
                lambda t: t.context.thread_id == thread_id
                and t.context.process_id == process_id,
                TestFramework.bstack1lllll1llll_opy_.values(),
            ),
            key=lambda t: t.bstack1lllll11111_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1lllll1lll1_opy_(ctx: bstack1llllll1lll_opy_, reverse=True) -> List[bstack1lll111l11l_opy_]:
        return sorted(
            filter(
                lambda t: t.context.thread_id == ctx.thread_id
                and t.context.process_id == ctx.process_id,
                TestFramework.bstack1lllll1llll_opy_.values(),
            ),
            key=lambda t: t.bstack1lllll11111_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1lllll1l11l_opy_(instance: bstack1lll111l11l_opy_, key: str):
        return instance and key in instance.data
    @staticmethod
    def bstack1lllll1l1l1_opy_(instance: bstack1lll111l11l_opy_, key: str, default_value=None):
        return instance.data.get(key, default_value) if instance else default_value
    @staticmethod
    def bstack1lllll1ll11_opy_(instance: bstack1lll111l11l_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1l11_opy_ (u"ࠥࡷࡪࡺ࡟ࡴࡶࡤࡸࡪࡀࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠿ࡾࢁࠥࡱࡥࡺ࠿ࡾࢁࠥࡼࡡ࡭ࡷࡨࡁࢀࢃࠢᗸ").format(instance.ref(),key,value))
        instance.data[key] = value
        return True
    @staticmethod
    def bstack1l111lll11l_opy_(instance: bstack1lll111l11l_opy_, entries: Dict[str, Any]):
        TestFramework.logger.debug(bstack1l11_opy_ (u"ࠦࡸ࡫ࡴࡠࡵࡷࡥࡹ࡫࡟ࡦࡰࡷࡶ࡮࡫ࡳ࠻ࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀࢃࠠࡦࡰࡷࡶ࡮࡫ࡳ࠾ࡽࢀࠦᗹ").format(instance.ref(),entries,))
        instance.data.update(entries)
        return True
    @staticmethod
    def bstack11lll1ll111_opy_(instance: bstack1ll1ll1l1ll_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1l11_opy_ (u"ࠧࡻࡰࡥࡣࡷࡩࡤࡹࡴࡢࡶࡨ࠾ࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࡼࡿࠣ࡯ࡪࡿ࠽ࡼࡿࠣࡺࡦࡲࡵࡦ࠿ࡾࢁࠧᗺ").format(instance.ref(),key,value))
        instance.data.update(key, value)
        return True
    @staticmethod
    def get_data(key: str, target: object, strict=True, default_value=None):
        instance = TestFramework.bstack1llll1l111l_opy_(target, strict)
        return TestFramework.bstack1lllll1l1l1_opy_(instance, key, default_value)
    @staticmethod
    def set_data(key: str, value: Any, target: object, strict=True):
        instance = TestFramework.bstack1llll1l111l_opy_(target, strict)
        if not instance:
            return False
        instance.data[key] = value
        return True
    @staticmethod
    def bstack1l111l11lll_opy_(instance: bstack1lll111l11l_opy_, key: str, value: object):
        if instance == None:
            return
        instance.data[key] = value
    @staticmethod
    def bstack11lllllll1l_opy_(instance: bstack1lll111l11l_opy_, key: str):
        return instance.data[key]
    @staticmethod
    def bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]):
        return bstack1l11_opy_ (u"ࠨ࠺ࠣᗻ").join((bstack1ll1ll1l1ll_opy_(bstack1llll1lllll_opy_[0]).name, bstack1llll11l11l_opy_(bstack1llll1lllll_opy_[1]).name))
    @staticmethod
    def bstack1ll111l11ll_opy_(bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_], callback: Callable):
        bstack1l11l111l11_opy_ = TestFramework.bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_)
        TestFramework.logger.debug(bstack1l11_opy_ (u"ࠢࡴࡧࡷࡣ࡭ࡵ࡯࡬ࡡࡦࡥࡱࡲࡢࡢࡥ࡮࠾ࠥ࡮࡯ࡰ࡭ࡢࡶࡪ࡭ࡩࡴࡶࡵࡽࡤࡱࡥࡺ࠿ࡾࢁࠧᗼ").format(bstack1l11l111l11_opy_))
        if not bstack1l11l111l11_opy_ in TestFramework.bstack11lll1lllll_opy_:
            TestFramework.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_] = []
        TestFramework.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_].append(callback)
    @staticmethod
    def bstack1l1l1l11111_opy_(o):
        klass = o.__class__
        module = klass.__module__
        if module == bstack1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡺࡩ࡯ࡵࠥᗽ"):
            return klass.__qualname__
        return module + bstack1l11_opy_ (u"ࠤ࠱ࠦᗾ") + klass.__qualname__
    @staticmethod
    def bstack1l1ll11ll1l_opy_(obj, keys, default_value=None):
        return {k: getattr(obj, k, default_value) for k in keys}