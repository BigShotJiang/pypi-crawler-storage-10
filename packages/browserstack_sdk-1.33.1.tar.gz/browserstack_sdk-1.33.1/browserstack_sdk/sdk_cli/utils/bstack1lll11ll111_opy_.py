# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import re
from typing import List, Dict, Any
from bstack_utils.bstack1l111llll_opy_ import get_logger
logger = get_logger(__name__)
class bstack1ll1lll1ll1_opy_:
    bstack1l11_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡃࡶࡵࡷࡳࡲ࡚ࡡࡨࡏࡤࡲࡦ࡭ࡥࡳࠢࡳࡶࡴࡼࡩࡥࡧࡶࠤࡺࡺࡩ࡭࡫ࡷࡽࠥࡳࡥࡵࡪࡲࡨࡸࠦࡴࡰࠢࡶࡩࡹࠦࡡ࡯ࡦࠣࡶࡪࡺࡲࡪࡧࡹࡩࠥࡩࡵࡴࡶࡲࡱࠥࡺࡡࡨࠢࡰࡩࡹࡧࡤࡢࡶࡤ࠲ࠏࠦࠠࠡࠢࡌࡸࠥࡳࡡࡪࡰࡷࡥ࡮ࡴࡳࠡࡶࡺࡳࠥࡹࡥࡱࡣࡵࡥࡹ࡫ࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡧ࡭ࡨࡺࡩࡰࡰࡤࡶ࡮࡫ࡳࠡࡨࡲࡶࠥࡺࡥࡴࡶࠣࡰࡪࡼࡥ࡭ࠢࡤࡲࡩࠦࡢࡶ࡫࡯ࡨࠥࡲࡥࡷࡧ࡯ࠤࡨࡻࡳࡵࡱࡰࠤࡹࡧࡧࡴ࠰ࠍࠤࠥࠦࠠࡆࡣࡦ࡬ࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡦࡰࡷࡶࡾࠦࡩࡴࠢࡨࡼࡵ࡫ࡣࡵࡧࡧࠤࡹࡵࠠࡣࡧࠣࡷࡹࡸࡵࡤࡶࡸࡶࡪࡪࠠࡢࡵ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࡰ࡫ࡹ࠻ࠢࡾࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡩ࡭ࡪࡲࡤࡠࡶࡼࡴࡪࠨ࠺ࠡࠤࡰࡹࡱࡺࡩࡠࡦࡵࡳࡵࡪ࡯ࡸࡰࠥ࠰ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡺࡦࡲࡵࡦࡵࠥ࠾ࠥࡡ࡬ࡪࡵࡷࠤࡴ࡬ࠠࡵࡣࡪࠤࡻࡧ࡬ࡶࡧࡶࡡࠏࠦࠠࠡࠢࠣࠤࠥࢃࠊࠡࠢࠣࠤࠧࠨࠢᘂ")
    _11lll1l1l11_opy_: Dict[str, Dict[str, Any]] = {}
    _11lll1l1ll1_opy_: Dict[str, Dict[str, Any]] = {}
    @staticmethod
    def set_custom_tag(bstack1ll1l1l111_opy_: str, key_value: str, bstack11lll1l11ll_opy_: bool = False) -> None:
        if not bstack1ll1l1l111_opy_ or not key_value or bstack1ll1l1l111_opy_.strip() == bstack1l11_opy_ (u"ࠢࠣᘃ") or key_value.strip() == bstack1l11_opy_ (u"ࠣࠤᘄ"):
            logger.error(bstack1l11_opy_ (u"ࠤ࡮ࡩࡾࡥ࡮ࡢ࡯ࡨࠤࡦࡴࡤࠡ࡭ࡨࡽࡤࡼࡡ࡭ࡷࡨࠤࡲࡻࡳࡵࠢࡥࡩࠥࡴ࡯࡯࠯ࡱࡹࡱࡲࠠࡢࡰࡧࠤࡳࡵ࡮࠮ࡧࡰࡴࡹࡿࠢᘅ"))
        values: List[str] = bstack1ll1lll1ll1_opy_.bstack11lll11ll1l_opy_(key_value)
        bstack11lll1l111l_opy_ = {bstack1l11_opy_ (u"ࠥࡪ࡮࡫࡬ࡥࡡࡷࡽࡵ࡫ࠢᘆ"): bstack1l11_opy_ (u"ࠦࡲࡻ࡬ࡵ࡫ࡢࡨࡷࡵࡰࡥࡱࡺࡲࠧᘇ"), bstack1l11_opy_ (u"ࠧࡼࡡ࡭ࡷࡨࡷࠧᘈ"): values}
        bstack11lll1l11l1_opy_ = bstack1ll1lll1ll1_opy_._11lll1l1ll1_opy_ if bstack11lll1l11ll_opy_ else bstack1ll1lll1ll1_opy_._11lll1l1l11_opy_
        if bstack1ll1l1l111_opy_ in bstack11lll1l11l1_opy_:
            bstack11lll1l1111_opy_ = bstack11lll1l11l1_opy_[bstack1ll1l1l111_opy_]
            bstack11lll11llll_opy_ = bstack11lll1l1111_opy_.get(bstack1l11_opy_ (u"ࠨࡶࡢ࡮ࡸࡩࡸࠨᘉ"), [])
            for val in values:
                if val not in bstack11lll11llll_opy_:
                    bstack11lll11llll_opy_.append(val)
            bstack11lll1l1111_opy_[bstack1l11_opy_ (u"ࠢࡷࡣ࡯ࡹࡪࡹࠢᘊ")] = bstack11lll11llll_opy_
        else:
            bstack11lll1l11l1_opy_[bstack1ll1l1l111_opy_] = bstack11lll1l111l_opy_
    @staticmethod
    def bstack1l1111llll1_opy_() -> Dict[str, Dict[str, Any]]:
        return bstack1ll1lll1ll1_opy_._11lll1l1l11_opy_
    @staticmethod
    def bstack11lll1l1l1l_opy_() -> Dict[str, Dict[str, Any]]:
        return bstack1ll1lll1ll1_opy_._11lll1l1ll1_opy_
    @staticmethod
    def bstack11lll11ll1l_opy_(bstack11lll11lll1_opy_: str) -> List[str]:
        bstack1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤ࡙ࠥࡰ࡭࡫ࡷࡷࠥࡺࡨࡦࠢ࡬ࡲࡵࡻࡴࠡࡵࡷࡶ࡮ࡴࡧࠡࡤࡼࠤࡨࡵ࡭࡮ࡣࡶࠤࡼ࡮ࡩ࡭ࡧࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡳ࡭ࠠࡥࡱࡸࡦࡱ࡫࠭ࡲࡷࡲࡸࡪࡪࠠࡴࡷࡥࡷࡹࡸࡩ࡯ࡩࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡆࡰࡴࠣࡩࡽࡧ࡭ࡱ࡮ࡨ࠾ࠥ࠭ࡡ࠭ࠢࠥࡦ࠱ࡩࠢ࠭ࠢࡧࠫࠥ࠳࠾ࠡ࡝ࠪࡥࠬ࠲ࠠࠨࡤ࠯ࡧࠬ࠲ࠠࠨࡦࠪࡡࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤᘋ")
        pattern = re.compile(bstack1l11_opy_ (u"ࡴࠪࠦ࠭ࡡ࡞ࠣ࡟࠭࠭ࠧࢂࠨ࡜ࡠ࠯ࡡ࠰࠯ࠧᘌ"))
        result = []
        for match in pattern.finditer(bstack11lll11lll1_opy_):
            if match.group(1) is not None:
                result.append(match.group(1).strip())
            elif match.group(2) is not None:
                result.append(match.group(2).strip())
        return result
    def __new__(cls, *args, **kwargs):
        raise Exception(bstack1l11_opy_ (u"࡙ࠥࡹ࡯࡬ࡪࡶࡼࠤࡨࡲࡡࡴࡵࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡲࡴࡺࠠࡣࡧࠣ࡭ࡳࡹࡴࡢࡰࡷ࡭ࡦࡺࡥࡥࠤᘍ"))