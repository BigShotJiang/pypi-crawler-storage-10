# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
import traceback
from typing import Dict, Tuple, Callable, Type, List, Any
from urllib.parse import urlparse
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1llllll1l1l_opy_,
    bstack1llllll11l1_opy_,
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
)
import copy
from datetime import datetime, timezone, timedelta
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
from bstack_utils.constants import EVENTS
class bstack1lll11l1l1l_opy_(bstack1llllll1l1l_opy_):
    bstack1l111lll1ll_opy_ = bstack1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕࡒࡁࡕࡈࡒࡖࡒࡥࡉࡏࡆࡈ࡜ࠧᖘ")
    NAME = bstack1l11_opy_ (u"ࠨࡳࡦ࡮ࡨࡲ࡮ࡻ࡭ࠣᖙ")
    bstack1l1l1111l11_opy_ = bstack1l11_opy_ (u"ࠢࡩࡷࡥࡣࡺࡸ࡬ࠣᖚ")
    bstack1l1l111lll1_opy_ = bstack1l11_opy_ (u"ࠣࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡤ࡯ࡤࠣᖛ")
    bstack11lll1lll1l_opy_ = bstack1l11_opy_ (u"ࠤ࡬ࡲࡵࡻࡴࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠢᖜ")
    bstack1l1l11l11l1_opy_ = bstack1l11_opy_ (u"ࠥࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᖝ")
    bstack1l11l11l111_opy_ = bstack1l11_opy_ (u"ࠦ࡮ࡹ࡟ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡨࡶࡤࠥᖞ")
    bstack11lll1ll11l_opy_ = bstack1l11_opy_ (u"ࠧࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠤᖟ")
    bstack11llll111l1_opy_ = bstack1l11_opy_ (u"ࠨࡥ࡯ࡦࡨࡨࡤࡧࡴࠣᖠ")
    bstack1ll11lll1ll_opy_ = bstack1l11_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡡ࡬ࡲࡩ࡫ࡸࠣᖡ")
    bstack1l11ll1l1ll_opy_ = bstack1l11_opy_ (u"ࠣࡰࡨࡻࡸ࡫ࡳࡴ࡫ࡲࡲࠧᖢ")
    bstack11lll1llll1_opy_ = bstack1l11_opy_ (u"ࠤࡪࡩࡹࠨᖣ")
    bstack1l1l1ll111l_opy_ = bstack1l11_opy_ (u"ࠥࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࠢᖤ")
    bstack1l11l11111l_opy_ = bstack1l11_opy_ (u"ࠦࡼ࠹ࡣࡦࡺࡨࡧࡺࡺࡥࡴࡥࡵ࡭ࡵࡺࠢᖥ")
    bstack1l111lllll1_opy_ = bstack1l11_opy_ (u"ࠧࡽ࠳ࡤࡧࡻࡩࡨࡻࡴࡦࡵࡦࡶ࡮ࡶࡴࡢࡵࡼࡲࡨࠨᖦ")
    bstack11lll1lll11_opy_ = bstack1l11_opy_ (u"ࠨࡱࡶ࡫ࡷࠦᖧ")
    bstack11lll1lllll_opy_: Dict[str, List[Callable]] = dict()
    bstack1l11ll111l1_opy_: str
    platform_index: int
    options: Any
    desired_capabilities: Any
    bstack1lll1lll111_opy_: Any
    bstack1l111llll11_opy_: Dict
    def __init__(
        self,
        bstack1l11ll111l1_opy_: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        classes: List[Type],
        bstack1lll1lll111_opy_: Dict[str, Any],
        methods=[bstack1l11_opy_ (u"ࠢࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠࠤᖨ"), bstack1l11_opy_ (u"ࠣࡵࡷࡥࡷࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠣᖩ"), bstack1l11_opy_ (u"ࠤࡨࡼࡪࡩࡵࡵࡧࠥᖪ"), bstack1l11_opy_ (u"ࠥࡵࡺ࡯ࡴࠣᖫ")],
    ):
        super().__init__(
            framework_name,
            framework_version,
            classes,
        )
        self.bstack1l11ll111l1_opy_ = bstack1l11ll111l1_opy_
        self.platform_index = platform_index
        self.bstack1lllll11l11_opy_(methods)
        self.bstack1lll1lll111_opy_ = bstack1lll1lll111_opy_
    @staticmethod
    def session_id(target: object, strict=True):
        return bstack1llllll1l1l_opy_.get_data(bstack1lll11l1l1l_opy_.bstack1l1l111lll1_opy_, target, strict)
    @staticmethod
    def hub_url(target: object, strict=True):
        return bstack1llllll1l1l_opy_.get_data(bstack1lll11l1l1l_opy_.bstack1l1l1111l11_opy_, target, strict)
    @staticmethod
    def bstack11llll11111_opy_(target: object, strict=True):
        return bstack1llllll1l1l_opy_.get_data(bstack1lll11l1l1l_opy_.bstack11lll1lll1l_opy_, target, strict)
    @staticmethod
    def capabilities(target: object, strict=True):
        return bstack1llllll1l1l_opy_.get_data(bstack1lll11l1l1l_opy_.bstack1l1l11l11l1_opy_, target, strict)
    @staticmethod
    def bstack1l1lll1l111_opy_(instance: bstack1llllll11l1_opy_) -> bool:
        return bstack1llllll1l1l_opy_.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1l11l11l111_opy_, False)
    @staticmethod
    def bstack1ll111l1l1l_opy_(instance: bstack1llllll11l1_opy_, default_value=None):
        return bstack1llllll1l1l_opy_.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1l1l1111l11_opy_, default_value)
    @staticmethod
    def bstack1ll11lll1l1_opy_(instance: bstack1llllll11l1_opy_, default_value=None):
        return bstack1llllll1l1l_opy_.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1l1l11l11l1_opy_, default_value)
    @staticmethod
    def bstack1l1lllll1ll_opy_(hub_url: str, bstack11llll1111l_opy_=bstack1l11_opy_ (u"ࠦ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭ࠣᖬ")):
        try:
            bstack11lll1ll1l1_opy_ = str(urlparse(hub_url).netloc) if hub_url else None
            return bstack11lll1ll1l1_opy_.endswith(bstack11llll1111l_opy_)
        except:
            pass
        return False
    @staticmethod
    def bstack1ll11l1l1l1_opy_(method_name: str):
        return method_name == bstack1l11_opy_ (u"ࠧ࡫ࡸࡦࡥࡸࡸࡪࠨᖭ")
    @staticmethod
    def bstack1ll11lll11l_opy_(method_name: str, *args):
        return (
            bstack1lll11l1l1l_opy_.bstack1ll11l1l1l1_opy_(method_name)
            and bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args) == bstack1lll11l1l1l_opy_.bstack1l11ll1l1ll_opy_
        )
    @staticmethod
    def bstack1ll111ll11l_opy_(method_name: str, *args):
        if not bstack1lll11l1l1l_opy_.bstack1ll11l1l1l1_opy_(method_name):
            return False
        if not bstack1lll11l1l1l_opy_.bstack1l11l11111l_opy_ in bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args):
            return False
        bstack1l1llllll1l_opy_ = bstack1lll11l1l1l_opy_.bstack1l1llll1ll1_opy_(*args)
        return bstack1l1llllll1l_opy_ and bstack1l11_opy_ (u"ࠨࡳࡤࡴ࡬ࡴࡹࠨᖮ") in bstack1l1llllll1l_opy_ and bstack1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᖯ") in bstack1l1llllll1l_opy_[bstack1l11_opy_ (u"ࠣࡵࡦࡶ࡮ࡶࡴࠣᖰ")]
    @staticmethod
    def bstack1ll1111111l_opy_(method_name: str, *args):
        if not bstack1lll11l1l1l_opy_.bstack1ll11l1l1l1_opy_(method_name):
            return False
        if not bstack1lll11l1l1l_opy_.bstack1l11l11111l_opy_ in bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args):
            return False
        bstack1l1llllll1l_opy_ = bstack1lll11l1l1l_opy_.bstack1l1llll1ll1_opy_(*args)
        return (
            bstack1l1llllll1l_opy_
            and bstack1l11_opy_ (u"ࠤࡶࡧࡷ࡯ࡰࡵࠤᖱ") in bstack1l1llllll1l_opy_
            and bstack1l11_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡡࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡳࡤࡴ࡬ࡴࡹࠨᖲ") in bstack1l1llllll1l_opy_[bstack1l11_opy_ (u"ࠦࡸࡩࡲࡪࡲࡷࠦᖳ")]
        )
    @staticmethod
    def bstack1l11l1l11l1_opy_(*args):
        return str(bstack1lll11l1l1l_opy_.bstack1ll1111lll1_opy_(*args)).lower()
    @staticmethod
    def bstack1ll1111lll1_opy_(*args):
        return args[0] if args and type(args) in [list, tuple] and isinstance(args[0], str) else None
    @staticmethod
    def bstack1l1llll1ll1_opy_(*args):
        return args[1] if len(args) > 1 and isinstance(args[1], dict) else None
    @staticmethod
    def bstack1llll1l1ll_opy_(driver):
        command_executor = getattr(driver, bstack1l11_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᖴ"), None)
        if not command_executor:
            return None
        hub_url = str(command_executor) if isinstance(command_executor, (str, bytes)) else None
        hub_url = str(command_executor._url) if not hub_url and getattr(command_executor, bstack1l11_opy_ (u"ࠨ࡟ࡶࡴ࡯ࠦᖵ"), None) else None
        if not hub_url:
            client_config = getattr(command_executor, bstack1l11_opy_ (u"ࠢࡠࡥ࡯࡭ࡪࡴࡴࡠࡥࡲࡲ࡫࡯ࡧࠣᖶ"), None)
            if not client_config:
                return None
            hub_url = getattr(client_config, bstack1l11_opy_ (u"ࠣࡴࡨࡱࡴࡺࡥࡠࡵࡨࡶࡻ࡫ࡲࡠࡣࡧࡨࡷࠨᖷ"), None)
        return hub_url
    def bstack1l11l1l1lll_opy_(self, instance, driver, hub_url: str):
        result = False
        if not hub_url:
            return result
        command_executor = getattr(driver, bstack1l11_opy_ (u"ࠤࡦࡳࡲࡳࡡ࡯ࡦࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠧᖸ"), None)
        if command_executor:
            if isinstance(command_executor, (str, bytes)):
                setattr(driver, bstack1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࡣࡪࡾࡥࡤࡷࡷࡳࡷࠨᖹ"), hub_url)
                result = True
            elif hasattr(command_executor, bstack1l11_opy_ (u"ࠦࡤࡻࡲ࡭ࠤᖺ")):
                setattr(command_executor, bstack1l11_opy_ (u"ࠧࡥࡵࡳ࡮ࠥᖻ"), hub_url)
                result = True
        if result:
            self.bstack1l11ll111l1_opy_ = hub_url
            bstack1lll11l1l1l_opy_.bstack1lllll1ll11_opy_(instance, bstack1lll11l1l1l_opy_.bstack1l1l1111l11_opy_, hub_url)
            bstack1lll11l1l1l_opy_.bstack1lllll1ll11_opy_(
                instance, bstack1lll11l1l1l_opy_.bstack1l11l11l111_opy_, bstack1lll11l1l1l_opy_.bstack1l1lllll1ll_opy_(hub_url)
            )
        return result
    @staticmethod
    def bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_]):
        return bstack1l11_opy_ (u"ࠨ࠺ࠣᖼ").join((bstack1lllll111ll_opy_(bstack1llll1lllll_opy_[0]).name, bstack1llll1l1lll_opy_(bstack1llll1lllll_opy_[1]).name))
    @staticmethod
    def bstack1ll111l11ll_opy_(bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_], callback: Callable):
        bstack1l11l111l11_opy_ = bstack1lll11l1l1l_opy_.bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_)
        if not bstack1l11l111l11_opy_ in bstack1lll11l1l1l_opy_.bstack11lll1lllll_opy_:
            bstack1lll11l1l1l_opy_.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_] = []
        bstack1lll11l1l1l_opy_.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_].append(callback)
    def bstack1llll1lll11_opy_(self, instance: bstack1llllll11l1_opy_, method_name: str, bstack1lllllll111_opy_: timedelta, *args, **kwargs):
        if not instance or method_name in (bstack1l11_opy_ (u"ࠢࡴࡶࡤࡶࡹࡥࡳࡦࡵࡶ࡭ࡴࡴࠢᖽ")):
            return
        cmd = args[0] if method_name == bstack1l11_opy_ (u"ࠣࡧࡻࡩࡨࡻࡴࡦࠤᖾ") and args and type(args) in [list, tuple] and isinstance(args[0], str) else None
        bstack11lll1ll1ll_opy_ = bstack1l11_opy_ (u"ࠤ࠽ࠦᖿ").join(map(str, filter(None, [method_name, cmd])))
        instance.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠥࡨࡷ࡯ࡶࡦࡴ࠽ࠦᗀ") + bstack11lll1ll1ll_opy_, bstack1lllllll111_opy_)
    def bstack1llll1ll1ll_opy_(
        self,
        target: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ) -> Callable[..., Any]:
        instance, method_name = exec
        bstack1llllll111l_opy_, bstack1l11l111111_opy_ = bstack1llll1lllll_opy_
        bstack1l11l111l11_opy_ = bstack1lll11l1l1l_opy_.bstack1l11l1111l1_opy_(bstack1llll1lllll_opy_)
        self.logger.debug(bstack1l11_opy_ (u"ࠦࡴࡴ࡟ࡩࡱࡲ࡯࠿ࠦ࡭ࡦࡶ࡫ࡳࡩࡥ࡮ࡢ࡯ࡨࡁࢀࡳࡥࡵࡪࡲࡨࡤࡴࡡ࡮ࡧࢀࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦᗁ") + str(kwargs) + bstack1l11_opy_ (u"ࠧࠨᗂ"))
        if bstack1llllll111l_opy_ == bstack1lllll111ll_opy_.QUIT:
            if bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.PRE:
                bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack1ll111l111l_opy_(EVENTS.bstack11llll1l_opy_.value)
                bstack1llllll1l1l_opy_.bstack1lllll1ll11_opy_(instance, EVENTS.bstack11llll1l_opy_.value, bstack1ll11ll11l1_opy_)
                self.logger.debug(bstack1l11_opy_ (u"ࠨࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࡽࢀࠤࡲ࡫ࡴࡩࡱࡧࡣࡳࡧ࡭ࡦ࠿ࡾࢁࠥ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫࠽ࡼࡿࠣ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫࠽ࡼࡿࠥᗃ").format(instance, method_name, bstack1llllll111l_opy_, bstack1l11l111111_opy_))
        if bstack1llllll111l_opy_ == bstack1lllll111ll_opy_.bstack1llll11lll1_opy_:
            if bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.POST and not bstack1lll11l1l1l_opy_.bstack1l1l111lll1_opy_ in instance.data:
                session_id = getattr(target, bstack1l11_opy_ (u"ࠢࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡫ࡧࠦᗄ"), None)
                if session_id:
                    instance.data[bstack1lll11l1l1l_opy_.bstack1l1l111lll1_opy_] = session_id
        elif (
            bstack1llllll111l_opy_ == bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_
            and bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args) == bstack1lll11l1l1l_opy_.bstack1l11ll1l1ll_opy_
        ):
            if bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.PRE:
                hub_url = bstack1lll11l1l1l_opy_.bstack1llll1l1ll_opy_(target)
                if hub_url:
                    instance.data.update(
                        {
                            bstack1lll11l1l1l_opy_.bstack1l1l1111l11_opy_: hub_url,
                            bstack1lll11l1l1l_opy_.bstack1l11l11l111_opy_: bstack1lll11l1l1l_opy_.bstack1l1lllll1ll_opy_(hub_url),
                            bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_: int(
                                os.environ.get(bstack1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠣᗅ"), str(self.platform_index))
                            ),
                        }
                    )
                bstack1l1llllll1l_opy_ = bstack1lll11l1l1l_opy_.bstack1l1llll1ll1_opy_(*args)
                bstack11llll11111_opy_ = bstack1l1llllll1l_opy_.get(bstack1l11_opy_ (u"ࠤࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣᗆ"), None) if bstack1l1llllll1l_opy_ else None
                if isinstance(bstack11llll11111_opy_, dict):
                    instance.data[bstack1lll11l1l1l_opy_.bstack11lll1lll1l_opy_] = copy.deepcopy(bstack11llll11111_opy_)
                    instance.data[bstack1lll11l1l1l_opy_.bstack1l1l11l11l1_opy_] = bstack11llll11111_opy_
            elif bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.POST:
                if isinstance(result, dict):
                    framework_session_id = result.get(bstack1l11_opy_ (u"ࠥࡺࡦࡲࡵࡦࠤᗇ"), dict()).get(bstack1l11_opy_ (u"ࠦࡸ࡫ࡳࡴ࡫ࡲࡲࡎࡪࠢᗈ"), None)
                    if framework_session_id:
                        instance.data.update(
                            {
                                bstack1lll11l1l1l_opy_.bstack1l1l111lll1_opy_: framework_session_id,
                                bstack1lll11l1l1l_opy_.bstack11lll1ll11l_opy_: datetime.now(tz=timezone.utc),
                            }
                        )
        elif (
            bstack1llllll111l_opy_ == bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_
            and bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args) == bstack1lll11l1l1l_opy_.bstack11lll1lll11_opy_
            and bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.POST
        ):
            instance.data[bstack1lll11l1l1l_opy_.bstack11llll111l1_opy_] = datetime.now(tz=timezone.utc)
        if bstack1l11l111l11_opy_ in bstack1lll11l1l1l_opy_.bstack11lll1lllll_opy_:
            bstack1l11l1111ll_opy_ = None
            for callback in bstack1lll11l1l1l_opy_.bstack11lll1lllll_opy_[bstack1l11l111l11_opy_]:
                try:
                    bstack1l111llllll_opy_ = callback(self, target, exec, bstack1llll1lllll_opy_, result, *args, **kwargs)
                    if bstack1l11l1111ll_opy_ == None:
                        bstack1l11l1111ll_opy_ = bstack1l111llllll_opy_
                except Exception as e:
                    self.logger.error(bstack1l11_opy_ (u"ࠧ࡫ࡲࡳࡱࡵࠤ࡮ࡴࡶࡰ࡭࡬ࡲ࡬ࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫࠻ࠢࠥᗉ") + str(e) + bstack1l11_opy_ (u"ࠨࠢᗊ"))
                    traceback.print_exc()
            if bstack1llllll111l_opy_ == bstack1lllll111ll_opy_.QUIT:
                if bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.POST:
                    bstack1ll11ll11l1_opy_ = bstack1llllll1l1l_opy_.bstack1lllll1l1l1_opy_(instance, EVENTS.bstack11llll1l_opy_.value)
                    if bstack1ll11ll11l1_opy_!=None:
                        bstack1ll1l1l11l1_opy_.end(EVENTS.bstack11llll1l_opy_.value, bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢᗋ"), bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨᗌ"), True, None)
            if bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.PRE and callable(bstack1l11l1111ll_opy_):
                return bstack1l11l1111ll_opy_
            elif bstack1l11l111111_opy_ == bstack1llll1l1lll_opy_.POST and bstack1l11l1111ll_opy_:
                return bstack1l11l1111ll_opy_
    def bstack1lllll1111l_opy_(
        self, method_name, previous_state: bstack1lllll111ll_opy_, *args, **kwargs
    ) -> bstack1lllll111ll_opy_:
        if method_name == bstack1l11_opy_ (u"ࠤࡢࡣ࡮ࡴࡩࡵࡡࡢࠦᗍ") or method_name == bstack1l11_opy_ (u"ࠥࡷࡹࡧࡲࡵࡡࡶࡩࡸࡹࡩࡰࡰࠥᗎ"):
            return bstack1lllll111ll_opy_.bstack1llll11lll1_opy_
        if method_name == bstack1l11_opy_ (u"ࠦࡶࡻࡩࡵࠤᗏ"):
            return bstack1lllll111ll_opy_.QUIT
        if method_name == bstack1l11_opy_ (u"ࠧ࡫ࡸࡦࡥࡸࡸࡪࠨᗐ"):
            if previous_state != bstack1lllll111ll_opy_.NONE:
                command_name = bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args)
                if command_name == bstack1lll11l1l1l_opy_.bstack1l11ll1l1ll_opy_:
                    return bstack1lllll111ll_opy_.bstack1llll11lll1_opy_
            return bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_
        return bstack1lllll111ll_opy_.NONE