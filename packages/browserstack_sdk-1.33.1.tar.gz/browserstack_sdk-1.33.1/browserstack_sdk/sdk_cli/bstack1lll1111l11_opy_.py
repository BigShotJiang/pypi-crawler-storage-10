# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import logging
import abc
from browserstack_sdk.sdk_cli.bstack1llllllllll_opy_ import bstack1lllllll1l1_opy_
class bstack1ll1l11ll11_opy_(abc.ABC):
    bin_session_id: str
    bstack1llllllllll_opy_: bstack1lllllll1l1_opy_
    def __init__(self):
        self.bstack1ll1llllll1_opy_ = None
        self.config = None
        self.bin_session_id = None
        self.bstack1llllllllll_opy_ = None
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
    def bstack1lll1ll1l1l_opy_(self):
        return (self.bstack1ll1llllll1_opy_ != None and self.bin_session_id != None and self.bstack1llllllllll_opy_ != None)
    def configure(self, bstack1ll1llllll1_opy_, config, bin_session_id: str, bstack1llllllllll_opy_: bstack1lllllll1l1_opy_):
        self.bstack1ll1llllll1_opy_ = bstack1ll1llllll1_opy_
        self.config = config
        self.bin_session_id = bin_session_id
        self.bstack1llllllllll_opy_ = bstack1llllllllll_opy_
        if self.bin_session_id:
            self.logger.debug(bstack1l11_opy_ (u"ࠦࡠࢁࡩࡥࠪࡶࡩࡱ࡬ࠩࡾ࡟ࠣࡧࡴࡴࡦࡪࡩࡸࡶࡪࡪࠠ࡮ࡱࡧࡹࡱ࡫ࠠࡼࡵࡨࡰ࡫࠴࡟ࡠࡥ࡯ࡥࡸࡹ࡟ࡠ࠰ࡢࡣࡳࡧ࡭ࡦࡡࡢࢁ࠿ࠦࡢࡪࡰࡢࡷࡪࡹࡳࡪࡱࡱࡣ࡮ࡪ࠽ࠣቤ") + str(self.bin_session_id) + bstack1l11_opy_ (u"ࠧࠨብ"))
    def bstack1ll11l111ll_opy_(self):
        if not self.bin_session_id:
            raise ValueError(bstack1l11_opy_ (u"ࠨࡢࡪࡰࡢࡷࡪࡹࡳࡪࡱࡱࡣ࡮ࡪࠠࡤࡣࡱࡲࡴࡺࠠࡣࡧࠣࡒࡴࡴࡥࠣቦ"))
    @abc.abstractmethod
    def is_enabled(self) -> bool:
        return False