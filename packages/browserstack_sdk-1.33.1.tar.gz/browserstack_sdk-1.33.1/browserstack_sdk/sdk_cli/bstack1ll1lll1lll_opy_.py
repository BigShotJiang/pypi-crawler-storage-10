# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, List, Any, Tuple
from browserstack_sdk.sdk_cli.bstack1llllll1ll1_opy_ import bstack1llll11ll1l_opy_
from browserstack_sdk.sdk_cli.utils.bstack11l11111ll_opy_ import bstack1l111ll1lll_opy_
from browserstack_sdk.sdk_cli.test_framework import (
    TestFramework,
    bstack1ll1ll1l1ll_opy_,
    bstack1lll111l11l_opy_,
    bstack1llll11l11l_opy_,
    bstack1l111ll1l1l_opy_,
    bstack1lll1l11l1l_opy_,
)
from pathlib import Path
import grpc
from browserstack_sdk import sdk_pb2 as structs
from datetime import datetime, timezone
from typing import List, Dict, Any
import traceback
from bstack_utils.helper import bstack1l1l1l1lll1_opy_
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
from bstack_utils.constants import EVENTS
from browserstack_sdk.sdk_cli.bstack1llllllllll_opy_ import bstack1lllllll1l1_opy_
from browserstack_sdk.sdk_cli.utils.bstack1lll11ll111_opy_ import bstack1ll1lll1ll1_opy_
from bstack_utils.bstack111ll11lll_opy_ import bstack1l1l1l1111_opy_
bstack1l1l1ll1l11_opy_ = bstack1l1l1l1lll1_opy_()
bstack1l111111lll_opy_ = 1.0
bstack1l1lll11l1l_opy_ = bstack1l11_opy_ (u"࡚ࠦࡶ࡬ࡰࡣࡧࡩࡩࡇࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡵ࠰ࠦᓽ")
bstack11llll1l111_opy_ = bstack1l11_opy_ (u"࡚ࠧࡥࡴࡶࡏࡩࡻ࡫࡬ࠣᓾ")
bstack11llll11lll_opy_ = bstack1l11_opy_ (u"ࠨࡂࡶ࡫࡯ࡨࡑ࡫ࡶࡦ࡮ࠥᓿ")
bstack11llll111ll_opy_ = bstack1l11_opy_ (u"ࠢࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮ࠥᔀ")
bstack11llll11ll1_opy_ = bstack1l11_opy_ (u"ࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࡍࡵ࡯࡬ࡇࡹࡩࡳࡺࠢᔁ")
_1l1ll1ll1l1_opy_ = set()
class bstack1ll1ll1ll11_opy_(TestFramework):
    bstack1l1111l1l1l_opy_ = bstack1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡴࠤᔂ")
    bstack1l1111lllll_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡪࡲࡳࡰࡹ࡟ࡴࡶࡤࡶࡹ࡫ࡤࠣᔃ")
    bstack1l1111111ll_opy_ = bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱࡳࡠࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠥᔄ")
    bstack11lllll1l11_opy_ = bstack1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠ࡮ࡤࡷࡹࡥࡳࡵࡣࡵࡸࡪࡪࠢᔅ")
    bstack11lllll111l_opy_ = bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡ࡯ࡥࡸࡺ࡟ࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠤᔆ")
    bstack11lllll1lll_opy_: bool
    bstack1llllllllll_opy_: bstack1lllllll1l1_opy_  = None
    bstack1ll1llllll1_opy_ = None
    bstack1l11111l11l_opy_ = [
        bstack1ll1ll1l1ll_opy_.BEFORE_ALL,
        bstack1ll1ll1l1ll_opy_.AFTER_ALL,
        bstack1ll1ll1l1ll_opy_.BEFORE_EACH,
        bstack1ll1ll1l1ll_opy_.AFTER_EACH,
    ]
    def __init__(
        self,
        bstack11llll1l1ll_opy_: Dict[str, str],
        bstack1ll11ll1l11_opy_: List[str]=[bstack1l11_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺࠢᔇ")],
        bstack1llllllllll_opy_: bstack1lllllll1l1_opy_=None,
        bstack1ll1llllll1_opy_=None
    ):
        super().__init__(bstack1ll11ll1l11_opy_, bstack11llll1l1ll_opy_, bstack1llllllllll_opy_)
        self.bstack11lllll1lll_opy_ = any(bstack1l11_opy_ (u"ࠣࡲࡼࡸࡪࡹࡴࠣᔈ") in item.lower() for item in bstack1ll11ll1l11_opy_)
        self.bstack1ll1llllll1_opy_ = bstack1ll1llllll1_opy_
    def track_event(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        super().track_event(self, context, test_framework_state, test_hook_state, *args, **kwargs)
        if test_framework_state == bstack1ll1ll1l1ll_opy_.TEST or test_framework_state in bstack1ll1ll1ll11_opy_.bstack1l11111l11l_opy_:
            bstack1l111ll1lll_opy_(test_framework_state, test_hook_state)
        if test_framework_state == bstack1ll1ll1l1ll_opy_.NONE:
            self.logger.warning(bstack1l11_opy_ (u"ࠤ࡬࡫ࡳࡵࡲࡦࡦࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃࠠࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦ࠿ࠥᔉ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠥࠦᔊ"))
            return
        if not self.bstack11lllll1lll_opy_:
            self.logger.warning(bstack1l11_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡹࡳࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠡࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡁࠧᔋ") + str(str(self.bstack1ll11ll1l11_opy_)) + bstack1l11_opy_ (u"ࠧࠨᔌ"))
            return
        if not isinstance(args, tuple) or len(args) == 0:
            self.logger.warning(bstack1l11_opy_ (u"ࠨࡴࡳࡣࡦ࡯ࡤ࡫ࡶࡦࡰࡷ࠾ࠥࡻ࡮ࡦࡺࡳࡩࡨࡺࡥࡥࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣᔍ") + str(kwargs) + bstack1l11_opy_ (u"ࠢࠣᔎ"))
            return
        instance = self.__11llll1llll_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        if not instance:
            self.logger.debug(bstack1l11_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡦࡸࡨࡲࡹࡀࠠࡶࡰ࡫ࡥࡳࡪ࡬ࡦࡦࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࢀࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫ࡽࠡࡣࡵ࡫ࡸࡃࠢᔏ") + str(args) + bstack1l11_opy_ (u"ࠤࠥᔐ"))
            return
        try:
            if instance!= None and test_framework_state in bstack1ll1ll1ll11_opy_.bstack1l11111l11l_opy_ and test_hook_state == bstack1llll11l11l_opy_.PRE:
                bstack1ll11ll11l1_opy_ = bstack1ll1l1l11l1_opy_.bstack1ll111l111l_opy_(EVENTS.bstack1111l1111_opy_.value)
                name = str(EVENTS.bstack1111l1111_opy_.name)+bstack1l11_opy_ (u"ࠥ࠾ࠧᔑ")+str(test_framework_state.name)
                TestFramework.bstack1l111l11lll_opy_(instance, name, bstack1ll11ll11l1_opy_)
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡬ࡴࡵ࡫ࠡࡧࡵࡶࡴࡸࠠࡱࡴࡨ࠾ࠥࢁࡽࠣᔒ").format(e))
        try:
            if not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1111ll11l_opy_) and test_hook_state == bstack1llll11l11l_opy_.PRE:
                test = bstack1ll1ll1ll11_opy_.__11llllll1l1_opy_(args[0])
                if test:
                    instance.data.update(test)
                    self.logger.debug(bstack1l11_opy_ (u"ࠧࡲ࡯ࡢࡦࡨࡨࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࡼ࡫ࡱࡷࡹࡧ࡮ࡤࡧ࠱ࡶࡪ࡬ࠨࠪࡿࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࠧᔓ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠨࠢᔔ"))
            if test_framework_state == bstack1ll1ll1l1ll_opy_.TEST:
                if test_hook_state == bstack1llll11l11l_opy_.PRE and not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1ll1l1l11_opy_):
                    TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1ll1l1l11_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l11_opy_ (u"ࠢࡴࡧࡷࠤࡹ࡫ࡳࡵ࠯ࡶࡸࡦࡸࡴࠡࡨࡲࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࡼ࡫ࡱࡷࡹࡧ࡮ࡤࡧ࠱ࡶࡪ࡬ࠨࠪࡿࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࠧᔕ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠣࠤᔖ"))
                elif test_hook_state == bstack1llll11l11l_opy_.POST and not TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1l1l1l111ll_opy_):
                    TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1l1l111ll_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l11_opy_ (u"ࠤࡶࡩࡹࠦࡴࡦࡵࡷ࠱ࡪࡴࡤࠡࡨࡲࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࡼ࡫ࡱࡷࡹࡧ࡮ࡤࡧ࠱ࡶࡪ࡬ࠨࠪࡿࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࠧᔗ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠥࠦᔘ"))
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG and test_hook_state == bstack1llll11l11l_opy_.POST:
                bstack1ll1ll1ll11_opy_.__1l11111l111_opy_(instance, *args)
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG_REPORT and test_hook_state == bstack1llll11l11l_opy_.POST:
                self.__11lllllllll_opy_(instance, *args)
                self.__1l111ll11l1_opy_(instance)
            elif test_framework_state in bstack1ll1ll1ll11_opy_.bstack1l11111l11l_opy_:
                self.__11llll1lll1_opy_(instance, test_framework_state, test_hook_state, *args)
            self.logger.debug(bstack1l11_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡩࡻ࡫࡮ࡵ࠼ࠣ࡬ࡦࡴࡤ࡭ࡧࡧࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࢁࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥࡾࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࠧᔙ") + str(instance.ref()) + bstack1l11_opy_ (u"ࠧࠨᔚ"))
        except Exception as e:
            self.logger.error(e)
            traceback.print_exc()
        self.bstack1l1111ll1ll_opy_(instance, (test_framework_state, test_hook_state), *args, **kwargs)
        try:
            if instance!= None and test_framework_state in bstack1ll1ll1ll11_opy_.bstack1l11111l11l_opy_ and test_hook_state == bstack1llll11l11l_opy_.POST:
                name = str(EVENTS.bstack1111l1111_opy_.name)+bstack1l11_opy_ (u"ࠨ࠺ࠣᔛ")+str(test_framework_state.name)
                bstack1ll11ll11l1_opy_ = TestFramework.bstack11lllllll1l_opy_(instance, name)
                bstack1ll1l1l11l1_opy_.end(EVENTS.bstack1111l1111_opy_.value, bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢᔜ"), bstack1ll11ll11l1_opy_+bstack1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨᔝ"), True, None, test_framework_state.name)
        except Exception as e:
            self.logger.debug(bstack1l11_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡪࡲࡳࡰࠦࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠤᔞ").format(e))
    def bstack1l1l1l11l1l_opy_(self):
        return self.bstack11lllll1lll_opy_
    def __1l111l1l1l1_opy_(self, *args):
        if len(args) > 2 and callable(getattr(args[2], bstack1l11_opy_ (u"ࠥ࡫ࡪࡺ࡟ࡳࡧࡶࡹࡱࡺࠢᔟ"), None)):
            rep = args[2].get_result()
            if rep:
                return TestFramework.bstack1l1ll11ll1l_opy_(rep, [bstack1l11_opy_ (u"ࠦࡼ࡮ࡥ࡯ࠤᔠ"), bstack1l11_opy_ (u"ࠧࡵࡵࡵࡥࡲࡱࡪࠨᔡ"), bstack1l11_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠨᔢ"), bstack1l11_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠢᔣ"), bstack1l11_opy_ (u"ࠣࡵ࡮࡭ࡵࡶࡥࡥࠤᔤ"), bstack1l11_opy_ (u"ࠤ࡯ࡳࡳ࡭ࡲࡦࡲࡵࡸࡪࡾࡴࠣᔥ")])
        return None
    def __11lllllllll_opy_(self, instance: bstack1lll111l11l_opy_, *args):
        result = self.__1l111l1l1l1_opy_(*args)
        if not result:
            return
        failure = None
        bstack111111111l_opy_ = None
        if result.get(bstack1l11_opy_ (u"ࠥࡳࡺࡺࡣࡰ࡯ࡨࠦᔦ"), None) == bstack1l11_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦᔧ") and len(args) > 1 and getattr(args[1], bstack1l11_opy_ (u"ࠧ࡫ࡸࡤ࡫ࡱࡪࡴࠨᔨ"), None) is not None:
            failure = [{bstack1l11_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩᔩ"): [args[1].excinfo.exconly(), result.get(bstack1l11_opy_ (u"ࠢ࡭ࡱࡱ࡫ࡷ࡫ࡰࡳࡶࡨࡼࡹࠨᔪ"), None)]}]
            bstack111111111l_opy_ = bstack1l11_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࡉࡷࡸ࡯ࡳࠤᔫ") if bstack1l11_opy_ (u"ࠤࡄࡷࡸ࡫ࡲࡵ࡫ࡲࡲࠧᔬ") in getattr(args[1].excinfo, bstack1l11_opy_ (u"ࠥࡸࡾࡶࡥ࡯ࡣࡰࡩࠧᔭ"), bstack1l11_opy_ (u"ࠦࠧᔮ")) else bstack1l11_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨᔯ")
        bstack1l111111l1l_opy_ = result.get(bstack1l11_opy_ (u"ࠨ࡯ࡶࡶࡦࡳࡲ࡫ࠢᔰ"), TestFramework.bstack11lllll1111_opy_)
        if bstack1l111111l1l_opy_ != TestFramework.bstack11lllll1111_opy_:
            TestFramework.bstack1lllll1ll11_opy_(instance, TestFramework.bstack1l1lll111ll_opy_, datetime.now(tz=timezone.utc))
        TestFramework.bstack1l111lll11l_opy_(instance, {
            TestFramework.bstack1l11lllll1l_opy_: failure,
            TestFramework.bstack1l111ll1l11_opy_: bstack111111111l_opy_,
            TestFramework.bstack1l11lllllll_opy_: bstack1l111111l1l_opy_,
        })
    def __11llll1llll_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        instance = None
        if test_framework_state == bstack1ll1ll1l1ll_opy_.SETUP_FIXTURE:
            instance = self.__11llll1ll1l_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        else:
            target = None # bstack1l1111l11l1_opy_ bstack1l111111l11_opy_ this to be bstack1l11_opy_ (u"ࠢ࡯ࡱࡧࡩ࡮ࡪࠢᔱ")
            if test_framework_state == bstack1ll1ll1l1ll_opy_.INIT_TEST:
                target = args[0] if isinstance(args[0], str) else None
                if target:
                    self.__11llllll1ll_opy_(context, test_framework_state, target, *args)
            elif test_framework_state == bstack1ll1ll1l1ll_opy_.LOG:
                nodeid = getattr(getattr(args[0], bstack1l11_opy_ (u"ࠣࡰࡲࡨࡪࠨᔲ"), None), bstack1l11_opy_ (u"ࠤࡱࡳࡩ࡫ࡩࡥࠤᔳ"), None) if args else None
                if isinstance(nodeid, str):
                    target = nodeid
            elif getattr(args[0], bstack1l11_opy_ (u"ࠥࡲࡴࡪࡥࡪࡦࠥᔴ"), None):
                target = args[0].nodeid
            instance = TestFramework.bstack1llll1l111l_opy_(target) if target else None
        return instance
    def __11llll1lll1_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
    ):
        key = test_framework_state.name
        bstack11lllll11l1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1ll11_opy_.bstack1l1111lllll_opy_, {})
        if not key in bstack11lllll11l1_opy_:
            bstack11lllll11l1_opy_[key] = []
        bstack1l1111l1111_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1ll11_opy_.bstack1l1111111ll_opy_, {})
        if not key in bstack1l1111l1111_opy_:
            bstack1l1111l1111_opy_[key] = []
        bstack1l111ll11ll_opy_ = {
            bstack1ll1ll1ll11_opy_.bstack1l1111lllll_opy_: bstack11lllll11l1_opy_,
            bstack1ll1ll1ll11_opy_.bstack1l1111111ll_opy_: bstack1l1111l1111_opy_,
        }
        if test_hook_state == bstack1llll11l11l_opy_.PRE:
            hook = {
                bstack1l11_opy_ (u"ࠦࡰ࡫ࡹࠣᔵ"): key,
                TestFramework.bstack1l111111ll1_opy_: uuid4().__str__(),
                TestFramework.bstack1l111111111_opy_: TestFramework.bstack1l11111ll1l_opy_,
                TestFramework.bstack11llll1l11l_opy_: datetime.now(tz=timezone.utc),
                TestFramework.bstack1l111ll1111_opy_: [],
                TestFramework.bstack1l1111111l1_opy_: args[1] if len(args) > 1 else bstack1l11_opy_ (u"ࠬ࠭ᔶ"),
                TestFramework.bstack1l11111ll11_opy_: bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()
            }
            bstack11lllll11l1_opy_[key].append(hook)
            bstack1l111ll11ll_opy_[bstack1ll1ll1ll11_opy_.bstack11lllll1l11_opy_] = key
        elif test_hook_state == bstack1llll11l11l_opy_.POST:
            bstack1l11111111l_opy_ = bstack11lllll11l1_opy_.get(key, [])
            hook = bstack1l11111111l_opy_.pop() if bstack1l11111111l_opy_ else None
            if hook:
                result = self.__1l111l1l1l1_opy_(*args)
                if result:
                    bstack11llll1l1l1_opy_ = result.get(bstack1l11_opy_ (u"ࠨ࡯ࡶࡶࡦࡳࡲ࡫ࠢᔷ"), TestFramework.bstack1l11111ll1l_opy_)
                    if bstack11llll1l1l1_opy_ != TestFramework.bstack1l11111ll1l_opy_:
                        hook[TestFramework.bstack1l111111111_opy_] = bstack11llll1l1l1_opy_
                hook[TestFramework.bstack1l111l11111_opy_] = datetime.now(tz=timezone.utc)
                hook[TestFramework.bstack1l11111ll11_opy_]= bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()
                self.bstack11lllll11ll_opy_(hook)
                logs = hook.get(TestFramework.bstack1l111l1l11l_opy_, [])
                if logs: self.bstack1l1ll11l11l_opy_(instance, logs)
                bstack1l1111l1111_opy_[key].append(hook)
                bstack1l111ll11ll_opy_[bstack1ll1ll1ll11_opy_.bstack11lllll111l_opy_] = key
        TestFramework.bstack1l111lll11l_opy_(instance, bstack1l111ll11ll_opy_)
        self.logger.debug(bstack1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡨࡰࡱ࡮ࡣࡪࡼࡥ࡯ࡶ࠽ࠤࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱ࡟ࡴࡶࡤࡸࡪࡃࡻ࡬ࡧࡼࢁ࠳ࢁࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥࡾࠢ࡫ࡳࡴࡱࡳࡠࡵࡷࡥࡷࡺࡥࡥ࠿ࡾ࡬ࡴࡵ࡫ࡴࡡࡶࡸࡦࡸࡴࡦࡦࢀࠤ࡭ࡵ࡯࡬ࡵࡢࡪ࡮ࡴࡩࡴࡪࡨࡨࡂࠨᔸ") + str(bstack1l1111l1111_opy_) + bstack1l11_opy_ (u"ࠣࠤᔹ"))
    def __11llll1ll1l_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        test_hook_state: bstack1llll11l11l_opy_,
        *args,
        **kwargs,
    ):
        fixturedef = TestFramework.bstack1l1ll11ll1l_opy_(args[0], [bstack1l11_opy_ (u"ࠤࡶࡧࡴࡶࡥࠣᔺ"), bstack1l11_opy_ (u"ࠥࡥࡷ࡭࡮ࡢ࡯ࡨࠦᔻ"), bstack1l11_opy_ (u"ࠦࡵࡧࡲࡢ࡯ࡶࠦᔼ"), bstack1l11_opy_ (u"ࠧ࡯ࡤࡴࠤᔽ"), bstack1l11_opy_ (u"ࠨࡵ࡯࡫ࡷࡸࡪࡹࡴࠣᔾ"), bstack1l11_opy_ (u"ࠢࡣࡣࡶࡩ࡮ࡪࠢᔿ")]) if len(args) > 0 else {}
        request = args[1] if len(args) > 1 else None
        scope = request.scope if hasattr(request, bstack1l11_opy_ (u"ࠣࡵࡦࡳࡵ࡫ࠢᕀ")) else fixturedef.get(bstack1l11_opy_ (u"ࠤࡶࡧࡴࡶࡥࠣᕁ"), None)
        fixturename = request.fixturename if hasattr(request, bstack1l11_opy_ (u"ࠥࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥࠣᕂ")) else None
        node = request.node if hasattr(request, bstack1l11_opy_ (u"ࠦࡳࡵࡤࡦࠤᕃ")) else None
        target = request.node.nodeid if hasattr(node, bstack1l11_opy_ (u"ࠧࡴ࡯ࡥࡧ࡬ࡨࠧᕄ")) else None
        baseid = fixturedef.get(bstack1l11_opy_ (u"ࠨࡢࡢࡵࡨ࡭ࡩࠨᕅ"), None) or bstack1l11_opy_ (u"ࠢࠣᕆ")
        if (not target or len(baseid) > 0) and hasattr(request, bstack1l11_opy_ (u"ࠣࡡࡳࡽ࡫ࡻ࡮ࡤ࡫ࡷࡩࡲࠨᕇ")):
            target = bstack1ll1ll1ll11_opy_.__1l111l111ll_opy_(request._pyfuncitem.location) if hasattr(request._pyfuncitem, bstack1l11_opy_ (u"ࠤ࡯ࡳࡨࡧࡴࡪࡱࡱࠦᕈ")) else None
            if target and not TestFramework.bstack1llll1l111l_opy_(target):
                self.__11llllll1ll_opy_(context, test_framework_state, target, (target, request._pyfuncitem.location))
                node = request._pyfuncitem
                self.logger.debug(bstack1l11_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡࡩ࡭ࡽࡺࡵࡳࡧࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡪࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡺࡡࡳࡩࡨࡸࡂࢁࡴࡢࡴࡪࡩࡹࢃࠠࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࡂࢁࡦࡪࡺࡷࡹࡷ࡫࡮ࡢ࡯ࡨࢁࠥࡴ࡯ࡥࡧࡀࡿࡳࡵࡤࡦࡿࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࠧᕉ") + str(test_hook_state) + bstack1l11_opy_ (u"ࠦࠧᕊ"))
        if not fixturedef or not scope or not target:
            self.logger.warning(bstack1l11_opy_ (u"ࠧࡺࡲࡢࡥ࡮ࡣ࡫࡯ࡸࡵࡷࡵࡩࡤ࡫ࡶࡦࡰࡷ࠾ࠥࡻ࡮ࡩࡣࡱࡨࡱ࡫ࡤࠡࡧࡹࡩࡳࡺ࠽ࡼࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡸࡦࡺࡥࡾ࠰ࡾࡸࡪࡹࡴࡠࡪࡲࡳࡰࡥࡳࡵࡣࡷࡩࢂࠦࡦࡪࡺࡷࡹࡷ࡫ࡤࡦࡨࡀࡿ࡫࡯ࡸࡵࡷࡵࡩࡩ࡫ࡦࡾࠢࡶࡧࡴࡶࡥ࠾ࡽࡶࡧࡴࡶࡥࡾࠢࡷࡥࡷ࡭ࡥࡵ࠿ࠥᕋ") + str(target) + bstack1l11_opy_ (u"ࠨࠢᕌ"))
            return None
        instance = TestFramework.bstack1llll1l111l_opy_(target)
        if not instance:
            self.logger.warning(bstack1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡦࡪࡺࡷࡹࡷ࡫࡟ࡦࡸࡨࡲࡹࡀࠠࡶࡰ࡫ࡥࡳࡪ࡬ࡦࡦࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࢀࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫ࡽࠡࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࡃࡻࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࢂࠦࡳࡤࡱࡳࡩࡂࢁࡳࡤࡱࡳࡩࢂࠦࡢࡢࡵࡨ࡭ࡩࡃࡻࡣࡣࡶࡩ࡮ࡪࡽࠡࡶࡤࡶ࡬࡫ࡴ࠾ࠤᕍ") + str(target) + bstack1l11_opy_ (u"ࠣࠤᕎ"))
            return None
        bstack1l111l1ll11_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1ll11_opy_.bstack1l1111l1l1l_opy_, {})
        if os.getenv(bstack1l11_opy_ (u"ࠤࡖࡈࡐࡥࡃࡍࡋࡢࡊࡑࡇࡇࡠࡈࡌ࡜࡙࡛ࡒࡆࡕࠥᕏ"), bstack1l11_opy_ (u"ࠥ࠵ࠧᕐ")) == bstack1l11_opy_ (u"ࠦ࠶ࠨᕑ"):
            bstack11llllll11l_opy_ = bstack1l11_opy_ (u"ࠧࡀࠢᕒ").join((scope, fixturename))
            bstack11lllllll11_opy_ = datetime.now(tz=timezone.utc)
            bstack1l111lll111_opy_ = {
                bstack1l11_opy_ (u"ࠨ࡫ࡦࡻࠥᕓ"): bstack11llllll11l_opy_,
                bstack1l11_opy_ (u"ࠢࡵࡣࡪࡷࠧᕔ"): bstack1ll1ll1ll11_opy_.__1l1111l11ll_opy_(request.node),
                bstack1l11_opy_ (u"ࠣࡨ࡬ࡼࡹࡻࡲࡦࠤᕕ"): fixturedef,
                bstack1l11_opy_ (u"ࠤࡶࡧࡴࡶࡥࠣᕖ"): scope,
                bstack1l11_opy_ (u"ࠥࡸࡾࡶࡥࠣᕗ"): None,
            }
            try:
                if test_hook_state == bstack1llll11l11l_opy_.POST and callable(getattr(args[-1], bstack1l11_opy_ (u"ࠦ࡬࡫ࡴࡠࡴࡨࡷࡺࡲࡴࠣᕘ"), None)):
                    bstack1l111lll111_opy_[bstack1l11_opy_ (u"ࠧࡺࡹࡱࡧࠥᕙ")] = TestFramework.bstack1l1l1l11111_opy_(args[-1].get_result())
            except Exception as e:
                pass
            if test_hook_state == bstack1llll11l11l_opy_.PRE:
                bstack1l111lll111_opy_[bstack1l11_opy_ (u"ࠨࡵࡶ࡫ࡧࠦᕚ")] = uuid4().__str__()
                bstack1l111lll111_opy_[bstack1ll1ll1ll11_opy_.bstack11llll1l11l_opy_] = bstack11lllllll11_opy_
            elif test_hook_state == bstack1llll11l11l_opy_.POST:
                bstack1l111lll111_opy_[bstack1ll1ll1ll11_opy_.bstack1l111l11111_opy_] = bstack11lllllll11_opy_
            if bstack11llllll11l_opy_ in bstack1l111l1ll11_opy_:
                bstack1l111l1ll11_opy_[bstack11llllll11l_opy_].update(bstack1l111lll111_opy_)
                self.logger.debug(bstack1l11_opy_ (u"ࠢࡶࡲࡧࡥࡹ࡫ࡤࠡࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࡃࡻࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࢂࠦࡳࡤࡱࡳࡩࡂࢁࡳࡤࡱࡳࡩࢂࠦࡦࡪࡺࡷࡹࡷ࡫࠽ࠣᕛ") + str(bstack1l111l1ll11_opy_[bstack11llllll11l_opy_]) + bstack1l11_opy_ (u"ࠣࠤᕜ"))
            else:
                bstack1l111l1ll11_opy_[bstack11llllll11l_opy_] = bstack1l111lll111_opy_
                self.logger.debug(bstack1l11_opy_ (u"ࠤࡶࡥࡻ࡫ࡤࠡࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࡃࡻࡧ࡫ࡻࡸࡺࡸࡥ࡯ࡣࡰࡩࢂࠦࡳࡤࡱࡳࡩࡂࢁࡳࡤࡱࡳࡩࢂࠦࡦࡪࡺࡷࡹࡷ࡫࠽ࡼࡶࡨࡷࡹࡥࡦࡪࡺࡷࡹࡷ࡫ࡽࠡࡶࡵࡥࡨࡱࡥࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࡶࡁࠧᕝ") + str(len(bstack1l111l1ll11_opy_)) + bstack1l11_opy_ (u"ࠥࠦᕞ"))
        TestFramework.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1ll11_opy_.bstack1l1111l1l1l_opy_, bstack1l111l1ll11_opy_)
        self.logger.debug(bstack1l11_opy_ (u"ࠦࡸࡧࡶࡦࡦࠣࡪ࡮ࡾࡴࡶࡴࡨࡷࡂࢁ࡬ࡦࡰࠫࡸࡷࡧࡣ࡬ࡧࡧࡣ࡫࡯ࡸࡵࡷࡵࡩࡸ࠯ࡽࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࠦᕟ") + str(instance.ref()) + bstack1l11_opy_ (u"ࠧࠨᕠ"))
        return instance
    def __11llllll1ll_opy_(
        self,
        context: bstack1l111ll1l1l_opy_,
        test_framework_state: bstack1ll1ll1l1ll_opy_,
        target: Any,
        *args,
    ):
        ctx = bstack1llll11ll1l_opy_.create_context(target)
        ob = bstack1lll111l11l_opy_(ctx, self.bstack1ll11ll1l11_opy_, self.bstack11llll1l1ll_opy_, test_framework_state)
        TestFramework.bstack1l111lll11l_opy_(ob, {
            TestFramework.bstack1ll11l1111l_opy_: context.test_framework_name,
            TestFramework.bstack1l1ll1l1111_opy_: context.test_framework_version,
            TestFramework.bstack1l1111l1ll1_opy_: [],
            bstack1ll1ll1ll11_opy_.bstack1l1111l1l1l_opy_: {},
            bstack1ll1ll1ll11_opy_.bstack1l1111111ll_opy_: {},
            bstack1ll1ll1ll11_opy_.bstack1l1111lllll_opy_: {},
        })
        if len(args) > 1 and isinstance(args[1], tuple):
            TestFramework.bstack1lllll1ll11_opy_(ob, TestFramework.bstack1l111ll1ll1_opy_, str(args[1][0]))
        if context.platform_index >= 0:
            TestFramework.bstack1lllll1ll11_opy_(ob, TestFramework.bstack1ll11lll1ll_opy_, context.platform_index)
        TestFramework.bstack1lllll1llll_opy_[ctx.id] = ob
        self.logger.debug(bstack1l11_opy_ (u"ࠨࡳࡢࡸࡨࡨࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠠࡤࡶࡻ࠲࡮ࡪ࠽ࡼࡥࡷࡼ࠳࡯ࡤࡾࠢࡷࡥࡷ࡭ࡥࡵ࠿ࡾࡸࡦࡸࡧࡦࡶࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡷࡂࠨᕡ") + str(TestFramework.bstack1lllll1llll_opy_.keys()) + bstack1l11_opy_ (u"ࠢࠣᕢ"))
        return ob
    def bstack1l1ll1ll1ll_opy_(self, instance: bstack1lll111l11l_opy_, bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]):
        bstack1l111l1l1ll_opy_ = (
            bstack1ll1ll1ll11_opy_.bstack11lllll1l11_opy_
            if bstack1llll1lllll_opy_[1] == bstack1llll11l11l_opy_.PRE
            else bstack1ll1ll1ll11_opy_.bstack11lllll111l_opy_
        )
        hook = bstack1ll1ll1ll11_opy_.bstack1l1111ll111_opy_(instance, bstack1l111l1l1ll_opy_)
        entries = hook.get(TestFramework.bstack1l111ll1111_opy_, []) if isinstance(hook, dict) else []
        entries.extend(TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, []))
        return entries
    def bstack1l1lll11l11_opy_(self, instance: bstack1lll111l11l_opy_, bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]):
        bstack1l111l1l1ll_opy_ = (
            bstack1ll1ll1ll11_opy_.bstack11lllll1l11_opy_
            if bstack1llll1lllll_opy_[1] == bstack1llll11l11l_opy_.PRE
            else bstack1ll1ll1ll11_opy_.bstack11lllll111l_opy_
        )
        bstack1ll1ll1ll11_opy_.bstack1l111l1l111_opy_(instance, bstack1l111l1l1ll_opy_)
        TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, []).clear()
    def bstack11lllll11ll_opy_(self, hook: Dict[str, Any]) -> None:
        bstack1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡖࡲࡰࡥࡨࡷࡸ࡫ࡳࠡࡶ࡫ࡩࠥࡎ࡯ࡰ࡭ࡏࡩࡻ࡫࡬ࠡࡣࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡸࠦࡳࡪ࡯࡬ࡰࡦࡸࠠࡵࡱࠣࡸ࡭࡫ࠠࡋࡣࡹࡥࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡢࡶ࡬ࡳࡳ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡉࡨࡦࡥ࡮ࡷࠥࡺࡨࡦࠢࡋࡳࡴࡱࡌࡦࡸࡨࡰࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡ࡫ࡱࡷ࡮ࡪࡥࠡࢀ࠲࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠲࡙ࡵࡲ࡯ࡢࡦࡨࡨࡆࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡈࡲࡶࠥ࡫ࡡࡤࡪࠣࡪ࡮ࡲࡥࠡ࡫ࡱࠤ࡭ࡵ࡯࡬ࡡ࡯ࡩࡻ࡫࡬ࡠࡨ࡬ࡰࡪࡹࠬࠡࡴࡨࡴࡱࡧࡣࡦࡵ࡙ࠣࠦ࡫ࡳࡵࡎࡨࡺࡪࡲࠢࠡࡹ࡬ࡸ࡭ࠦࠢࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮ࠥࠤ࡮ࡴࠠࡪࡶࡶࠤࡵࡧࡴࡩ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡋࡩࠤࡦࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡵࡪࡨࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࡮ࡣࡷࡧ࡭࡫ࡳࠡࡣࠣࡱࡴࡪࡩࡧ࡫ࡨࡨࠥ࡮࡯ࡰ࡭࠰ࡰࡪࡼࡥ࡭ࠢࡩ࡭ࡱ࡫ࠬࠡ࡫ࡷࠤࡨࡸࡥࡢࡶࡨࡷࠥࡧࠠࡍࡱࡪࡉࡳࡺࡲࡺࠢࡲࡦ࡯࡫ࡣࡵࠢࡺ࡭ࡹ࡮ࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡘ࡯࡭ࡪ࡮ࡤࡶࡱࡿࠬࠡ࡫ࡷࠤࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠠࡃࡷ࡬ࡰࡩࡒࡥࡷࡧ࡯ࠤࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴࠢ࡯ࡳࡨࡧࡴࡦࡦࠣ࡭ࡳࠦࡈࡰࡱ࡮ࡐࡪࡼࡥ࡭࠱ࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࡎ࡯ࡰ࡭ࡈࡺࡪࡴࡴࠡࡤࡼࠤࡷ࡫ࡰ࡭ࡣࡦ࡭ࡳ࡭ࠠࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠧࠦࡷࡪࡶ࡫ࠤࠧࡎ࡯ࡰ࡭ࡏࡩࡻ࡫࡬࠰ࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࡍࡵ࡯࡬ࡇࡹࡩࡳࡺࠢ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡕࡪࡨࠤࡨࡸࡥࡢࡶࡨࡨࠥࡒ࡯ࡨࡇࡱࡸࡷࡿࠠࡰࡤ࡭ࡩࡨࡺࡳࠡࡣࡵࡩࠥࡧࡤࡥࡧࡧࠤࡹࡵࠠࡵࡪࡨࠤ࡭ࡵ࡯࡬ࠩࡶࠤࠧࡲ࡯ࡨࡵࠥࠤࡱ࡯ࡳࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡆࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡪࡲࡳࡰࡀࠠࡕࡪࡨࠤࡪࡼࡥ࡯ࡶࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡪࡾࡩࡴࡶ࡬ࡲ࡬ࠦ࡬ࡰࡩࡶࠤࡦࡴࡤࠡࡪࡲࡳࡰࠦࡩ࡯ࡨࡲࡶࡲࡧࡴࡪࡱࡱ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࡬ࡴࡵ࡫ࡠ࡮ࡨࡺࡪࡲ࡟ࡧ࡫࡯ࡩࡸࡀࠠࡍ࡫ࡶࡸࠥࡵࡦࠡࡒࡤࡸ࡭ࠦ࡯ࡣ࡬ࡨࡧࡹࡹࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡗࡩࡸࡺࡌࡦࡸࡨࡰࠥࡳ࡯࡯࡫ࡷࡳࡷ࡯࡮ࡨ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡤࡸ࡭ࡱࡪ࡟࡭ࡧࡹࡩࡱࡥࡦࡪ࡮ࡨࡷ࠿ࠦࡌࡪࡵࡷࠤࡴ࡬ࠠࡑࡣࡷ࡬ࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠥࡳ࡯࡯࡫ࡷࡳࡷ࡯࡮ࡨ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢᕣ")
        global _1l1ll1ll1l1_opy_
        platform_index = os.environ[bstack1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡍࡓࡊࡅ࡙ࠩᕤ")]
        bstack1l1ll1l11ll_opy_ = os.path.join(bstack1l1l1ll1l11_opy_, (bstack1l1lll11l1l_opy_ + str(platform_index)), bstack11llll111ll_opy_)
        if not os.path.exists(bstack1l1ll1l11ll_opy_) or not os.path.isdir(bstack1l1ll1l11ll_opy_):
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡧࡻ࡭ࡸࡺࡳࠡࡶࡲࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࢁࡽࠣᕥ").format(bstack1l1ll1l11ll_opy_))
            return
        logs = hook.get(bstack1l11_opy_ (u"ࠦࡱࡵࡧࡴࠤᕦ"), [])
        with os.scandir(bstack1l1ll1l11ll_opy_) as entries:
            for entry in entries:
                abs_path = os.path.abspath(entry.path)
                if abs_path in _1l1ll1ll1l1_opy_:
                    self.logger.info(bstack1l11_opy_ (u"ࠧࡖࡡࡵࡪࠣࡥࡱࡸࡥࡢࡦࡼࠤࡵࡸ࡯ࡤࡧࡶࡷࡪࡪࠠࡼࡿࠥᕧ").format(abs_path))
                    continue
                if entry.is_file():
                    try:
                        timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                    except Exception:
                        timestamp = bstack1l11_opy_ (u"ࠨࠢᕨ")
                    log_entry = bstack1lll1l11l1l_opy_(
                        kind=bstack1l11_opy_ (u"ࠢࡕࡇࡖࡘࡤࡇࡔࡕࡃࡆࡌࡒࡋࡎࡕࠤᕩ"),
                        message=bstack1l11_opy_ (u"ࠣࠤᕪ"),
                        level=bstack1l11_opy_ (u"ࠤࠥᕫ"),
                        timestamp=timestamp,
                        fileName=entry.name,
                        bstack1l1ll1lll1l_opy_=entry.stat().st_size,
                        bstack1l1ll11llll_opy_=bstack1l11_opy_ (u"ࠥࡑࡆࡔࡕࡂࡎࡢ࡙ࡕࡒࡏࡂࡆࠥᕬ"),
                        bstack11ll11_opy_=os.path.abspath(entry.path),
                        bstack11llll1ll11_opy_=hook.get(TestFramework.bstack1l111111ll1_opy_)
                    )
                    logs.append(log_entry)
                    _1l1ll1ll1l1_opy_.add(abs_path)
        platform_index = os.environ[bstack1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᕭ")]
        bstack1l111l1111l_opy_ = os.path.join(bstack1l1l1ll1l11_opy_, (bstack1l1lll11l1l_opy_ + str(platform_index)), bstack11llll111ll_opy_, bstack11llll11ll1_opy_)
        if not os.path.exists(bstack1l111l1111l_opy_) or not os.path.isdir(bstack1l111l1111l_opy_):
            self.logger.info(bstack1l11_opy_ (u"ࠧࡔ࡯ࠡࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࡍࡵ࡯࡬ࡇࡹࡩࡳࡺࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡷࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡࡨࡲࡹࡳࡪࠠࡢࡶ࠽ࠤࢀࢃࠢᕮ").format(bstack1l111l1111l_opy_))
        else:
            self.logger.info(bstack1l11_opy_ (u"ࠨࡐࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹࠠࡧࡴࡲࡱࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠻ࠢࡾࢁࠧᕯ").format(bstack1l111l1111l_opy_))
            with os.scandir(bstack1l111l1111l_opy_) as entries:
                for entry in entries:
                    abs_path = os.path.abspath(entry.path)
                    if abs_path in _1l1ll1ll1l1_opy_:
                        self.logger.info(bstack1l11_opy_ (u"ࠢࡑࡣࡷ࡬ࠥࡧ࡬ࡳࡧࡤࡨࡾࠦࡰࡳࡱࡦࡩࡸࡹࡥࡥࠢࡾࢁࠧᕰ").format(abs_path))
                        continue
                    if entry.is_file():
                        try:
                            timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                        except Exception:
                            timestamp = bstack1l11_opy_ (u"ࠣࠤᕱ")
                        log_entry = bstack1lll1l11l1l_opy_(
                            kind=bstack1l11_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡂࡖࡗࡅࡈࡎࡍࡆࡐࡗࠦᕲ"),
                            message=bstack1l11_opy_ (u"ࠥࠦᕳ"),
                            level=bstack1l11_opy_ (u"ࠦࡇࡻࡩ࡭ࡦࡏࡩࡻ࡫࡬ࠣᕴ"),
                            timestamp=timestamp,
                            fileName=entry.name,
                            bstack1l1ll1lll1l_opy_=entry.stat().st_size,
                            bstack1l1ll11llll_opy_=bstack1l11_opy_ (u"ࠧࡓࡁࡏࡗࡄࡐࡤ࡛ࡐࡍࡑࡄࡈࠧᕵ"),
                            bstack11ll11_opy_=os.path.abspath(entry.path),
                            bstack1l1ll11lll1_opy_=hook.get(TestFramework.bstack1l111111ll1_opy_)
                        )
                        logs.append(log_entry)
                        _1l1ll1ll1l1_opy_.add(abs_path)
        hook[bstack1l11_opy_ (u"ࠨ࡬ࡰࡩࡶࠦᕶ")] = logs
    def bstack1l1ll11l11l_opy_(
        self,
        bstack1l1lll11111_opy_: bstack1lll111l11l_opy_,
        entries: List[bstack1lll1l11l1l_opy_],
    ):
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = os.environ.get(bstack1l11_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡍࡋࡢࡆࡎࡔ࡟ࡔࡇࡖࡗࡎࡕࡎࡠࡋࡇࠦᕷ"))
        req.platform_index = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1ll11lll1ll_opy_)
        req.execution_context.hash = str(bstack1l1lll11111_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l1lll11111_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l1lll11111_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1ll11l1111l_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lllll1l1l1_opy_(bstack1l1lll11111_opy_, TestFramework.bstack1l1ll1l1111_opy_)
            log_entry.uuid = entry.bstack11llll1ll11_opy_
            log_entry.test_framework_state = bstack1l1lll11111_opy_.state.name
            log_entry.message = entry.message.encode(bstack1l11_opy_ (u"ࠣࡷࡷࡪ࠲࠾ࠢᕸ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            log_entry.level = bstack1l11_opy_ (u"ࠤࠥᕹ")
            if entry.kind == bstack1l11_opy_ (u"ࠥࡘࡊ࡙ࡔࡠࡃࡗࡘࡆࡉࡈࡎࡇࡑࡘࠧᕺ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1l1ll1lll1l_opy_
                log_entry.file_path = entry.bstack11ll11_opy_
        def bstack1l1l1ll11ll_opy_():
            bstack1l1111ll11_opy_ = datetime.now()
            try:
                self.bstack1ll1llllll1_opy_.LogCreatedEvent(req)
                bstack1l1lll11111_opy_.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠦ࡬ࡸࡰࡤ࠼ࡶࡩࡳࡪ࡟࡭ࡱࡪࡣࡨࡸࡥࡢࡶࡨࡨࡤ࡫ࡶࡦࡰࡷࡣࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࠣᕻ"), datetime.now() - bstack1l1111ll11_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l11_opy_ (u"ࠧࡸࡰࡤ࠯ࡨࡶࡷࡵࡲ࠻ࠢࡶࡩࡳࡪ࡟࡭ࡱࡪࡣࡨࡸࡥࡢࡶࡨࡨࡤ࡫ࡶࡦࡰࡷࡣࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࠡࡽࢀࠦᕼ").format(str(e)))
                traceback.print_exc()
        self.bstack1llllllllll_opy_.enqueue(bstack1l1l1ll11ll_opy_)
    def __1l111ll11l1_opy_(self, instance) -> None:
        bstack1l11_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡐࡴࡧࡤࡴࠢࡦࡹࡸࡺ࡯࡮ࠢࡷࡥ࡬ࡹࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡩ࡬ࡺࡪࡴࠠࡵࡧࡶࡸࠥ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡉࡲࡦࡣࡷࡩࡸࠦࡡࠡࡦ࡬ࡧࡹࠦࡣࡰࡰࡷࡥ࡮ࡴࡩ࡯ࡩࠣࡸࡪࡹࡴࠡ࡮ࡨࡺࡪࡲࠠࡤࡷࡶࡸࡴࡳࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡵࡩࡹࡸࡩࡦࡸࡨࡨࠥ࡬ࡲࡰ࡯ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡈࡻࡳࡵࡱࡰࡘࡦ࡭ࡍࡢࡰࡤ࡫ࡪࡸࠠࡢࡰࡧࠤࡺࡶࡤࡢࡶࡨࡷࠥࡺࡨࡦࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠤࡸࡺࡡࡵࡧࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡥࡳࡵࡣࡷࡩࡤ࡫࡮ࡵࡴ࡬ࡩࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦᕽ")
        bstack1l111ll11ll_opy_ = {bstack1l11_opy_ (u"ࠢࡤࡷࡶࡸࡴࡳ࡟࡮ࡧࡷࡥࡩࡧࡴࡢࠤᕾ"): bstack1ll1lll1ll1_opy_.bstack1l1111llll1_opy_()}
        from browserstack_sdk.sdk_cli.test_framework import TestFramework
        TestFramework.bstack1l111lll11l_opy_(instance, bstack1l111ll11ll_opy_)
    @staticmethod
    def bstack1l1111ll111_opy_(instance: bstack1lll111l11l_opy_, bstack1l111l1l1ll_opy_: str):
        bstack1l111l11l11_opy_ = (
            bstack1ll1ll1ll11_opy_.bstack1l1111111ll_opy_
            if bstack1l111l1l1ll_opy_ == bstack1ll1ll1ll11_opy_.bstack11lllll111l_opy_
            else bstack1ll1ll1ll11_opy_.bstack1l1111lllll_opy_
        )
        bstack1l1111ll1l1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l1l1ll_opy_, None)
        bstack11lllll1ll1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l11l11_opy_, None) if bstack1l1111ll1l1_opy_ else None
        return (
            bstack11lllll1ll1_opy_[bstack1l1111ll1l1_opy_][-1]
            if isinstance(bstack11lllll1ll1_opy_, dict) and len(bstack11lllll1ll1_opy_.get(bstack1l1111ll1l1_opy_, [])) > 0
            else None
        )
    @staticmethod
    def bstack1l111l1l111_opy_(instance: bstack1lll111l11l_opy_, bstack1l111l1l1ll_opy_: str):
        hook = bstack1ll1ll1ll11_opy_.bstack1l1111ll111_opy_(instance, bstack1l111l1l1ll_opy_)
        if isinstance(hook, dict):
            hook.get(TestFramework.bstack1l111ll1111_opy_, []).clear()
    @staticmethod
    def __1l11111l111_opy_(instance: bstack1lll111l11l_opy_, *args):
        if len(args) < 2 or not callable(getattr(args[1], bstack1l11_opy_ (u"ࠣࡩࡨࡸࡤࡸࡥࡤࡱࡵࡨࡸࠨᕿ"), None)):
            return
        if os.getenv(bstack1l11_opy_ (u"ࠤࡖࡈࡐࡥࡃࡍࡋࡢࡊࡑࡇࡇࡠࡎࡒࡋࡘࠨᖀ"), bstack1l11_opy_ (u"ࠥ࠵ࠧᖁ")) != bstack1l11_opy_ (u"ࠦ࠶ࠨᖂ"):
            bstack1ll1ll1ll11_opy_.logger.warning(bstack1l11_opy_ (u"ࠧ࡯ࡧ࡯ࡱࡵ࡭ࡳ࡭ࠠࡤࡣࡳࡰࡴ࡭ࠢᖃ"))
            return
        bstack1l111lll1l1_opy_ = {
            bstack1l11_opy_ (u"ࠨࡳࡦࡶࡸࡴࠧᖄ"): (bstack1ll1ll1ll11_opy_.bstack11lllll1l11_opy_, bstack1ll1ll1ll11_opy_.bstack1l1111lllll_opy_),
            bstack1l11_opy_ (u"ࠢࡵࡧࡤࡶࡩࡵࡷ࡯ࠤᖅ"): (bstack1ll1ll1ll11_opy_.bstack11lllll111l_opy_, bstack1ll1ll1ll11_opy_.bstack1l1111111ll_opy_),
        }
        for when in (bstack1l11_opy_ (u"ࠣࡵࡨࡸࡺࡶࠢᖆ"), bstack1l11_opy_ (u"ࠤࡦࡥࡱࡲࠢᖇ"), bstack1l11_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࠧᖈ")):
            bstack1l1111lll11_opy_ = args[1].get_records(when)
            if not bstack1l1111lll11_opy_:
                continue
            records = [
                bstack1lll1l11l1l_opy_(
                    kind=TestFramework.bstack1l1ll111111_opy_,
                    message=r.message,
                    level=r.levelname if hasattr(r, bstack1l11_opy_ (u"ࠦࡱ࡫ࡶࡦ࡮ࡱࡥࡲ࡫ࠢᖉ")) and r.levelname else None,
                    timestamp=(
                        datetime.fromtimestamp(r.created, tz=timezone.utc)
                        if hasattr(r, bstack1l11_opy_ (u"ࠧࡩࡲࡦࡣࡷࡩࡩࠨᖊ")) and r.created
                        else None
                    ),
                )
                for r in bstack1l1111lll11_opy_
                if isinstance(getattr(r, bstack1l11_opy_ (u"ࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢᖋ"), None), str) and r.message.strip()
            ]
            if not records:
                continue
            bstack1l1111l1lll_opy_, bstack1l111l11l11_opy_ = bstack1l111lll1l1_opy_.get(when, (None, None))
            bstack1l111l1ll1l_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l1111l1lll_opy_, None) if bstack1l1111l1lll_opy_ else None
            bstack11lllll1ll1_opy_ = TestFramework.bstack1lllll1l1l1_opy_(instance, bstack1l111l11l11_opy_, None) if bstack1l111l1ll1l_opy_ else None
            if isinstance(bstack11lllll1ll1_opy_, dict) and len(bstack11lllll1ll1_opy_.get(bstack1l111l1ll1l_opy_, [])) > 0:
                hook = bstack11lllll1ll1_opy_[bstack1l111l1ll1l_opy_][-1]
                if isinstance(hook, dict) and TestFramework.bstack1l111ll1111_opy_ in hook:
                    hook[TestFramework.bstack1l111ll1111_opy_].extend(records)
                    continue
            logs = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1111l1ll1_opy_, [])
            logs.extend(records)
    @staticmethod
    def __11llllll1l1_opy_(test) -> Dict[str, Any]:
        bstack1ll1llll1_opy_ = bstack1ll1ll1ll11_opy_.__1l111l111ll_opy_(test.location) if hasattr(test, bstack1l11_opy_ (u"ࠢ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠤᖌ")) else getattr(test, bstack1l11_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣᖍ"), None)
        test_name = test.name if hasattr(test, bstack1l11_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᖎ")) else None
        bstack1l111l111l1_opy_ = test.fspath.strpath if hasattr(test, bstack1l11_opy_ (u"ࠥࡪࡸࡶࡡࡵࡪࠥᖏ")) and test.fspath else None
        if not bstack1ll1llll1_opy_ or not test_name or not bstack1l111l111l1_opy_:
            return None
        code = None
        if hasattr(test, bstack1l11_opy_ (u"ࠦࡴࡨࡪࠣᖐ")):
            try:
                import inspect
                code = inspect.getsource(test.obj)
            except:
                pass
        bstack11llll11l11_opy_ = []
        try:
            bstack11llll11l11_opy_ = bstack1l1l1l1111_opy_.bstack111l1l1l11_opy_(test)
        except:
            bstack1ll1ll1ll11_opy_.logger.warning(bstack1l11_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡨ࡬ࡲࡩࠦࡴࡦࡵࡷࠤࡸࡩ࡯ࡱࡧࡶ࠰ࠥࡺࡥࡴࡶࠣࡷࡨࡵࡰࡦࡵࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡩࠦࡩ࡯ࠢࡆࡐࡎࠨᖑ"))
        return {
            TestFramework.bstack1ll11ll1l1l_opy_: uuid4().__str__(),
            TestFramework.bstack1l1111ll11l_opy_: bstack1ll1llll1_opy_,
            TestFramework.bstack1ll11l11l1l_opy_: test_name,
            TestFramework.bstack1l1l11llll1_opy_: getattr(test, bstack1l11_opy_ (u"ࠨ࡮ࡰࡦࡨ࡭ࡩࠨᖒ"), None),
            TestFramework.bstack1l11111lll1_opy_: bstack1l111l111l1_opy_,
            TestFramework.bstack11llllll111_opy_: bstack1ll1ll1ll11_opy_.__1l1111l11ll_opy_(test),
            TestFramework.bstack11lllll1l1l_opy_: code,
            TestFramework.bstack1l11lllllll_opy_: TestFramework.bstack11lllll1111_opy_,
            TestFramework.bstack1l11l1l1111_opy_: bstack1ll1llll1_opy_,
            TestFramework.bstack11llll11l1l_opy_: bstack11llll11l11_opy_
        }
    @staticmethod
    def __1l1111l11ll_opy_(test) -> List[str]:
        markers = []
        current = test
        while current:
            own_markers = getattr(current, bstack1l11_opy_ (u"ࠢࡰࡹࡱࡣࡲࡧࡲ࡬ࡧࡵࡷࠧᖓ"), [])
            markers.extend([getattr(m, bstack1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᖔ"), None) for m in own_markers if getattr(m, bstack1l11_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᖕ"), None)])
            current = getattr(current, bstack1l11_opy_ (u"ࠥࡴࡦࡸࡥ࡯ࡶࠥᖖ"), None)
        return markers
    @staticmethod
    def __1l111l111ll_opy_(location):
        return bstack1l11_opy_ (u"ࠦ࠿ࡀࠢᖗ").join(filter(lambda x: isinstance(x, str), location))