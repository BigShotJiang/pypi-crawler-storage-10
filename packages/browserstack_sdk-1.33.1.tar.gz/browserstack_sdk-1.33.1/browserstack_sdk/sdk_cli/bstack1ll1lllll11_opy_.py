# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import json
import time
from datetime import datetime, timezone
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
    bstack1llllll1l1l_opy_,
    bstack1llllll11l1_opy_,
    bstack1llllll1lll_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll11l1l1l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_, bstack1lll111l11l_opy_
from browserstack_sdk.sdk_cli.bstack1l1lll1l1l1_opy_ import bstack1l1lll1ll11_opy_
from typing import Tuple, Dict, Any, List, Union
from bstack_utils.helper import bstack1l1ll1l1ll1_opy_
from browserstack_sdk import sdk_pb2 as structs
from bstack_utils.measure import measure
from bstack_utils.constants import *
from typing import Tuple, List, Any
class bstack1ll1ll1l1l1_opy_(bstack1l1lll1ll11_opy_):
    bstack1l11llll111_opy_ = bstack1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡦࡵ࡭ࡻ࡫ࡲࡴࠤᏝ")
    bstack1l1ll111lll_opy_ = bstack1l11_opy_ (u"ࠦࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡵࡨࡷࡸ࡯࡯࡯ࡵࠥᏞ")
    bstack1l11lllll11_opy_ = bstack1l11_opy_ (u"ࠧࡴ࡯࡯ࡡࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࡤࡹࡥࡴࡵ࡬ࡳࡳࡹࠢᏟ")
    bstack1l11ll1llll_opy_ = bstack1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠨᏠ")
    bstack1l11lll1l1l_opy_ = bstack1l11_opy_ (u"ࠢࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣ࡮ࡴࡳࡵࡣࡱࡧࡪࡥࡲࡦࡨࡶࠦᏡ")
    bstack1l1ll11111l_opy_ = bstack1l11_opy_ (u"ࠣࡥࡥࡸࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡣࡳࡧࡤࡸࡪࡪࠢᏢ")
    bstack1l11lll1lll_opy_ = bstack1l11_opy_ (u"ࠤࡦࡦࡹࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟࡯ࡣࡰࡩࠧᏣ")
    bstack1l11lll11l1_opy_ = bstack1l11_opy_ (u"ࠥࡧࡧࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡠࡵࡷࡥࡹࡻࡳࠣᏤ")
    def __init__(self):
        super().__init__(bstack1l1lll11lll_opy_=self.bstack1l11llll111_opy_, frameworks=[bstack1lll11l1l1l_opy_.NAME])
        if not self.is_enabled():
            return
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.BEFORE_EACH, bstack1llll11l11l_opy_.POST), self.bstack1l11l11ll11_opy_)
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.PRE), self.bstack1ll111ll111_opy_)
        TestFramework.bstack1ll111l11ll_opy_((bstack1ll1ll1l1ll_opy_.TEST, bstack1llll11l11l_opy_.POST), self.bstack1ll111ll1ll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11l11ll11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        bstack1l1l1lll111_opy_ = self.bstack1l11l111ll1_opy_(instance.context)
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠦࡸ࡫ࡴࡠࡣࡦࡸ࡮ࡼࡥࡠࡦࡵ࡭ࡻ࡫ࡲࡴ࠼ࠣࡲࡴࠦࡤࡳ࡫ࡹࡩࡷࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࠢᏥ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠧࠨᏦ"))
        f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, bstack1l1l1lll111_opy_)
        bstack1l11l11lll1_opy_ = self.bstack1l11l111ll1_opy_(instance.context, bstack1l11l111l1l_opy_=False)
        f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lllll11_opy_, bstack1l11l11lll1_opy_)
    def bstack1ll111ll111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if not f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll1lll_opy_, False):
            self.__1l11l11l11l_opy_(f,instance,bstack1llll1lllll_opy_)
    def bstack1ll111ll1ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        if not f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll1lll_opy_, False):
            self.__1l11l11l11l_opy_(f, instance, bstack1llll1lllll_opy_)
        if not f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll11l1_opy_, False):
            self.__1l11l11llll_opy_(f, instance, bstack1llll1lllll_opy_)
    def bstack1l11l11ll1l_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if not f.bstack1l1lll1l111_opy_(instance):
            return
        if f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll11l1_opy_, False):
            return
        driver.execute_script(
            bstack1l11_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠦᏧ").format(
                json.dumps(
                    {
                        bstack1l11_opy_ (u"ࠢࡢࡥࡷ࡭ࡴࡴࠢᏨ"): bstack1l11_opy_ (u"ࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦᏩ"),
                        bstack1l11_opy_ (u"ࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧᏪ"): {bstack1l11_opy_ (u"ࠥࡷࡹࡧࡴࡶࡵࠥᏫ"): result},
                    }
                )
            )
        )
        f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll11l1_opy_, True)
    def bstack1l11l111ll1_opy_(self, context: bstack1llllll1lll_opy_, bstack1l11l111l1l_opy_= True):
        if bstack1l11l111l1l_opy_:
            bstack1l1l1lll111_opy_ = self.bstack1l1llll1l11_opy_(context, reverse=True)
        else:
            bstack1l1l1lll111_opy_ = self.bstack1l1lll1ll1l_opy_(context, reverse=True)
        return [f for f in bstack1l1l1lll111_opy_ if f[1].state != bstack1lllll111ll_opy_.QUIT]
    @measure(event_name=EVENTS.bstack1lll1l111l_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def __1l11l11llll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡅࡲࡲࡹ࡫ࡸࡵࡑࡳࡸ࡮ࡵ࡮ࡴࠤᏬ")).get(bstack1l11_opy_ (u"ࠧࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤᏭ")):
            bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
            if not bstack1l1l1lll111_opy_:
                self.logger.debug(bstack1l11_opy_ (u"ࠨࡳࡦࡶࡢࡥࡨࡺࡩࡷࡧࡢࡨࡷ࡯ࡶࡦࡴࡶ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࠡࡨࡲࡶࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࠤᏮ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠢࠣᏯ"))
                return
            driver = bstack1l1l1lll111_opy_[0][0]()
            status = f.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l11lllllll_opy_, None)
            if not status:
                self.logger.debug(bstack1l11_opy_ (u"ࠣࡵࡨࡸࡤࡧࡣࡵ࡫ࡹࡩࡤࡪࡲࡪࡸࡨࡶࡸࡀࠠ࡯ࡱࠣࡷࡹࡧࡴࡶࡵࠣࡪࡴࡸࠠࡵࡧࡶࡸ࠱ࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࠥᏰ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠤࠥᏱ"))
                return
            bstack1l11llll11l_opy_ = {bstack1l11_opy_ (u"ࠥࡷࡹࡧࡴࡶࡵࠥᏲ"): status.lower()}
            bstack1l11lll111l_opy_ = f.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l11lllll1l_opy_, None)
            if status.lower() == bstack1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᏳ") and bstack1l11lll111l_opy_ is not None:
                bstack1l11llll11l_opy_[bstack1l11_opy_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬᏴ")] = bstack1l11lll111l_opy_[0][bstack1l11_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩᏵ")][0] if isinstance(bstack1l11lll111l_opy_, list) else str(bstack1l11lll111l_opy_)
            driver.execute_script(
                bstack1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠧ᏶").format(
                    json.dumps(
                        {
                            bstack1l11_opy_ (u"ࠣࡣࡦࡸ࡮ࡵ࡮ࠣ᏷"): bstack1l11_opy_ (u"ࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧᏸ"),
                            bstack1l11_opy_ (u"ࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨᏹ"): bstack1l11llll11l_opy_,
                        }
                    )
                )
            )
            f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll11l1_opy_, True)
    @measure(event_name=EVENTS.bstack11l1ll11l1_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def __1l11l11l11l_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_]
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡅࡲࡲࡹ࡫ࡸࡵࡑࡳࡸ࡮ࡵ࡮ࡴࠤᏺ")).get(bstack1l11_opy_ (u"ࠧࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢᏻ")):
            test_name = f.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l11l1l1111_opy_, None)
            if not test_name:
                self.logger.debug(bstack1l11_opy_ (u"ࠨ࡯࡯ࡡࡥࡩ࡫ࡵࡲࡦࡡࡷࡩࡸࡺ࠺ࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢࡷࡩࡸࡺࠠ࡯ࡣࡰࡩࠧᏼ"))
                return
            bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
            if not bstack1l1l1lll111_opy_:
                self.logger.debug(bstack1l11_opy_ (u"ࠢࡴࡧࡷࡣࡦࡩࡴࡪࡸࡨࡣࡩࡸࡩࡷࡧࡵࡷ࠿ࠦ࡮ࡰࠢࡶࡸࡦࡺࡵࡴࠢࡩࡳࡷࠦࡴࡦࡵࡷ࠰ࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࠤᏽ") + str(bstack1llll1lllll_opy_) + bstack1l11_opy_ (u"ࠣࠤ᏾"))
                return
            for bstack1l1l11lll11_opy_, bstack1l11l11l1l1_opy_ in bstack1l1l1lll111_opy_:
                if not bstack1lll11l1l1l_opy_.bstack1l1lll1l111_opy_(bstack1l11l11l1l1_opy_):
                    continue
                driver = bstack1l1l11lll11_opy_()
                if not driver:
                    continue
                driver.execute_script(
                    bstack1l11_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠢ᏿").format(
                        json.dumps(
                            {
                                bstack1l11_opy_ (u"ࠥࡥࡨࡺࡩࡰࡰࠥ᐀"): bstack1l11_opy_ (u"ࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧᐁ"),
                                bstack1l11_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣᐂ"): {bstack1l11_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᐃ"): test_name},
                            }
                        )
                    )
                )
            f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lll1lll_opy_, True)
    def bstack1l1ll1ll111_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        f: TestFramework,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        bstack1l1l1lll111_opy_ = [d for d, _ in f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])]
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠢࡰࡰࡢࡥ࡫ࡺࡥࡳࡡࡷࡩࡸࡺ࠺ࠡࡰࡲࠤࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠦࡴࡰࠢ࡯࡭ࡳࡱࠢᐄ"))
            return
        if not bstack1l1ll1l1ll1_opy_():
            self.logger.debug(bstack1l11_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨᐅ"))
            return
        for bstack1l11l11l1ll_opy_ in bstack1l1l1lll111_opy_:
            driver = bstack1l11l11l1ll_opy_()
            if not driver:
                continue
            timestamp = int(time.time() * 1000)
            data = bstack1l11_opy_ (u"ࠤࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡼࡲࡨࡀࠢᐆ") + str(timestamp)
            driver.execute_script(
                bstack1l11_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠣᐇ").format(
                    json.dumps(
                        {
                            bstack1l11_opy_ (u"ࠦࡦࡩࡴࡪࡱࡱࠦᐈ"): bstack1l11_opy_ (u"ࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢᐉ"),
                            bstack1l11_opy_ (u"ࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤᐊ"): {
                                bstack1l11_opy_ (u"ࠢࡵࡻࡳࡩࠧᐋ"): bstack1l11_opy_ (u"ࠣࡃࡱࡲࡴࡺࡡࡵ࡫ࡲࡲࠧᐌ"),
                                bstack1l11_opy_ (u"ࠤࡧࡥࡹࡧࠢᐍ"): data,
                                bstack1l11_opy_ (u"ࠥࡰࡪࡼࡥ࡭ࠤᐎ"): bstack1l11_opy_ (u"ࠦࡩ࡫ࡢࡶࡩࠥᐏ")
                            }
                        }
                    )
                )
            )
    def bstack1l1l1l1111l_opy_(
        self,
        instance: bstack1lll111l11l_opy_,
        f: TestFramework,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l11l11ll11_opy_(f, instance, bstack1llll1lllll_opy_, *args, **kwargs)
        keys = [
            bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_,
            bstack1ll1ll1l1l1_opy_.bstack1l11lllll11_opy_,
        ]
        bstack1l1l1lll111_opy_ = []
        for key in keys:
            bstack1l1l1lll111_opy_.extend(f.bstack1lllll1l1l1_opy_(instance, key, []))
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡵ࡮ࡠࡣࡩࡸࡪࡸ࡟ࡵࡧࡶࡸ࠿ࠦࡵ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡩ࡭ࡳࡪࠠࡢࡰࡼࠤࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠦࡴࡰࠢ࡯࡭ࡳࡱࠢᐐ"))
            return
        if f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll11111l_opy_, False):
            self.logger.debug(bstack1l11_opy_ (u"ࠨ࡯࡯ࡡࡤࡪࡹ࡫ࡲࡠࡶࡨࡷࡹࡀࠠࡄࡄࡗࠤࡦࡲࡲࡦࡣࡧࡽࠥࡩࡲࡦࡣࡷࡩࡩࠨᐑ"))
            return
        self.bstack1ll11l111ll_opy_()
        bstack1l1111ll11_opy_ = datetime.now()
        req = structs.TestSessionEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11lll1ll_opy_)
        req.test_framework_name = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11l1111l_opy_)
        req.test_framework_version = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1l1ll1l1111_opy_)
        req.test_framework_state = bstack1llll1lllll_opy_[0].name
        req.test_hook_state = bstack1llll1lllll_opy_[1].name
        req.test_uuid = TestFramework.bstack1lllll1l1l1_opy_(instance, TestFramework.bstack1ll11ll1l1l_opy_)
        for bstack1l1l11lll11_opy_, driver in bstack1l1l1lll111_opy_:
            try:
                webdriver = bstack1l1l11lll11_opy_()
                if webdriver is None:
                    self.logger.debug(bstack1l11_opy_ (u"ࠢࡘࡧࡥࡈࡷ࡯ࡶࡦࡴࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࠥ࡯ࡳࠡࡐࡲࡲࡪࠦࠨࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࠣࡩࡽࡶࡩࡳࡧࡧ࠭ࠧᐒ"))
                    continue
                session = req.automation_sessions.add()
                session.provider = (
                    bstack1l11_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠢᐓ")
                    if bstack1lll11l1l1l_opy_.bstack1lllll1l1l1_opy_(driver, bstack1lll11l1l1l_opy_.bstack1l11l11l111_opy_, False)
                    else bstack1l11_opy_ (u"ࠤࡸࡲࡰࡴ࡯ࡸࡰࡢ࡫ࡷ࡯ࡤࠣᐔ")
                )
                session.ref = driver.ref()
                session.hub_url = bstack1lll11l1l1l_opy_.bstack1lllll1l1l1_opy_(driver, bstack1lll11l1l1l_opy_.bstack1l1l1111l11_opy_, bstack1l11_opy_ (u"ࠥࠦᐕ"))
                session.framework_name = driver.framework_name
                session.framework_version = driver.framework_version
                session.framework_session_id = bstack1lll11l1l1l_opy_.bstack1lllll1l1l1_opy_(driver, bstack1lll11l1l1l_opy_.bstack1l1l111lll1_opy_, bstack1l11_opy_ (u"ࠦࠧᐖ"))
                caps = None
                if hasattr(webdriver, bstack1l11_opy_ (u"ࠧࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᐗ")):
                    try:
                        caps = webdriver.capabilities
                        self.logger.debug(bstack1l11_opy_ (u"ࠨࡓࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࡤࠡࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠠࡥ࡫ࡵࡩࡨࡺ࡬ࡺࠢࡩࡶࡴࡳࠠࡥࡴ࡬ࡺࡪࡸ࠮ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᐘ"))
                    except Exception as e:
                        self.logger.debug(bstack1l11_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣ࡫ࡪࡺࠠࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠦࡦࡳࡱࡰࠤࡩࡸࡩࡷࡧࡵ࠲ࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵ࠽ࠤࠧᐙ") + str(e) + bstack1l11_opy_ (u"ࠣࠤᐚ"))
                try:
                    bstack1l11l1l111l_opy_ = json.dumps(caps).encode(bstack1l11_opy_ (u"ࠤࡸࡸ࡫࠳࠸ࠣᐛ")) if caps else bstack1l11l111lll_opy_ (u"ࠥࡿࢂࠨᐜ")
                    req.capabilities = bstack1l11l1l111l_opy_
                except Exception as e:
                    self.logger.debug(bstack1l11_opy_ (u"ࠦ࡬࡫ࡴࡠࡥࡥࡸࡤ࡫ࡶࡦࡰࡷ࠾ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡳࡦࡴ࡬ࡥࡱ࡯ࡺࡦࠢࡦࡥࡵࡹࠠࡧࡱࡵࠤࡷ࡫ࡱࡶࡧࡶࡸ࠿ࠦࠢᐝ") + str(e) + bstack1l11_opy_ (u"ࠧࠨᐞ"))
            except Exception as e:
                self.logger.error(bstack1l11_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡶࡲࡰࡥࡨࡷࡸ࡯࡮ࡨࠢࡧࡶ࡮ࡼࡥࡳࠢ࡬ࡸࡪࡳ࠺ࠡࠤᐟ") + str(str(e)) + bstack1l11_opy_ (u"ࠢࠣᐠ"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        return req
    def bstack1ll11l11lll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs
    ):
        bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l1ll1l1ll1_opy_() and len(bstack1l1l1lll111_opy_) == 0:
            bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lllll11_opy_, [])
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠣࡱࡱࡣࡧ࡫ࡦࡰࡴࡨࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࠦࡤࡳ࡫ࡹࡩࡷࡹࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦᐡ") + str(kwargs) + bstack1l11_opy_ (u"ࠤࠥᐢ"))
            return {}
        if len(bstack1l1l1lll111_opy_) > 1:
            self.logger.debug(bstack1l11_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࢁ࡬ࡦࡰࠫࡨࡷ࡯ࡶࡦࡴࡢ࡭ࡳࡹࡴࡢࡰࡦࡩࡸ࠯ࡽࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨᐣ") + str(kwargs) + bstack1l11_opy_ (u"ࠦࠧᐤ"))
            return {}
        bstack1l1l11lll11_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1lll111_opy_[0]
        driver = bstack1l1l11lll11_opy_()
        if not driver:
            self.logger.debug(bstack1l11_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠ࡯ࡱࠣࡨࡷ࡯ࡶࡦࡴࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢᐥ") + str(kwargs) + bstack1l11_opy_ (u"ࠨࠢᐦ"))
            return {}
        capabilities = f.bstack1lllll1l1l1_opy_(bstack1l1l11ll1l1_opy_, bstack1lll11l1l1l_opy_.bstack1l1l11l11l1_opy_)
        if not capabilities:
            self.logger.debug(bstack1l11_opy_ (u"ࠢࡰࡰࡢࡦࡪ࡬࡯ࡳࡧࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠤ࡫ࡵࡵ࡯ࡦࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࡿ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵࡽࠡࡣࡵ࡫ࡸࡃࡻࡢࡴࡪࡷࢂࠦ࡫ࡸࡣࡵ࡫ࡸࡃࠢᐧ") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤᐨ"))
            return {}
        return capabilities.get(bstack1l11_opy_ (u"ࠤࡤࡰࡼࡧࡹࡴࡏࡤࡸࡨ࡮ࠢᐩ"), {})
    def bstack1ll11l1l111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lll111l11l_opy_,
        bstack1llll1lllll_opy_: Tuple[bstack1ll1ll1l1ll_opy_, bstack1llll11l11l_opy_],
        *args,
        **kwargs
    ):
        bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l1ll111lll_opy_, [])
        if not bstack1l1ll1l1ll1_opy_() and len(bstack1l1l1lll111_opy_) == 0:
            bstack1l1l1lll111_opy_ = f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l1l1_opy_.bstack1l11lllll11_opy_, [])
        if not bstack1l1l1lll111_opy_:
            self.logger.debug(bstack1l11_opy_ (u"ࠥ࡫ࡪࡺ࡟ࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡩࡸࡩࡷࡧࡵ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨᐪ") + str(kwargs) + bstack1l11_opy_ (u"ࠦࠧᐫ"))
            return
        if len(bstack1l1l1lll111_opy_) > 1:
            self.logger.debug(bstack1l11_opy_ (u"ࠧ࡭ࡥࡵࡡࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡤࡳ࡫ࡹࡩࡷࡀࠠࡼ࡮ࡨࡲ࠭ࡪࡲࡪࡸࡨࡶࡤ࡯࡮ࡴࡶࡤࡲࡨ࡫ࡳࠪࡿࠣࡨࡷ࡯ࡶࡦࡴࡶࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣᐬ") + str(kwargs) + bstack1l11_opy_ (u"ࠨࠢᐭ"))
        bstack1l1l11lll11_opy_, bstack1l1l11ll1l1_opy_ = bstack1l1l1lll111_opy_[0]
        driver = bstack1l1l11lll11_opy_()
        if not driver:
            self.logger.debug(bstack1l11_opy_ (u"ࠢࡨࡧࡷࡣࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡦࡵ࡭ࡻ࡫ࡲ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᐮ") + str(kwargs) + bstack1l11_opy_ (u"ࠣࠤᐯ"))
            return
        return driver