# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import json
import os
import grpc
from browserstack_sdk import sdk_pb2 as structs
from packaging import version
import traceback
from browserstack_sdk.sdk_cli.bstack1lll1111l11_opy_ import bstack1ll1l11ll11_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
    bstack1llllll11l1_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll11l1l1l_opy_
from datetime import datetime
from typing import Tuple, Any
from bstack_utils.messages import bstack1lll11ll11_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import threading
import os
from bstack_utils.bstack1l11l1ll11_opy_ import bstack1ll1l1l11l1_opy_
class bstack1ll1ll1l11l_opy_(bstack1ll1l11ll11_opy_):
    bstack1l11l1l1ll1_opy_ = bstack1l11_opy_ (u"ࠢࡳࡧࡪ࡭ࡸࡺࡥࡳࡡ࡬ࡲ࡮ࡺࠢᎆ")
    bstack1l11l1l11ll_opy_ = bstack1l11_opy_ (u"ࠣࡴࡨ࡫࡮ࡹࡴࡦࡴࡢࡷࡹࡧࡲࡵࠤᎇ")
    bstack1l11l1ll1l1_opy_ = bstack1l11_opy_ (u"ࠤࡵࡩ࡬࡯ࡳࡵࡧࡵࡣࡸࡺ࡯ࡱࠤᎈ")
    def __init__(self, bstack1ll1lllll1l_opy_):
        super().__init__()
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1llll11lll1_opy_, bstack1llll1l1lll_opy_.PRE), self.bstack1l11ll1111l_opy_)
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_, bstack1llll1l1lll_opy_.PRE), self.bstack1l1lllllll1_opy_)
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_, bstack1llll1l1lll_opy_.POST), self.bstack1l11ll1ll1l_opy_)
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_, bstack1llll1l1lll_opy_.POST), self.bstack1l11ll11111_opy_)
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.QUIT, bstack1llll1l1lll_opy_.POST), self.bstack1l11ll11lll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l11ll1111l_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l11_opy_ (u"ࠥࡣࡤ࡯࡮ࡪࡶࡢࡣࠧᎉ"):
            return
        def wrapped(driver, init, *args, **kwargs):
            url = None
            try:
                if isinstance(kwargs.get(bstack1l11_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࡤ࡫ࡸࡦࡥࡸࡸࡴࡸࠢᎊ")), str):
                    url = kwargs.get(bstack1l11_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᎋ"))
                elif hasattr(kwargs.get(bstack1l11_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳࠤᎌ")), bstack1l11_opy_ (u"ࠧࡠࡥ࡯࡭ࡪࡴࡴࡠࡥࡲࡲ࡫࡯ࡧࠨᎍ")):
                    url = kwargs.get(bstack1l11_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦᎎ"))._client_config.remote_server_addr
                else:
                    url = kwargs.get(bstack1l11_opy_ (u"ࠤࡦࡳࡲࡳࡡ࡯ࡦࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠧᎏ"))._url
            except Exception as e:
                url = bstack1l11_opy_ (u"ࠪࠫ᎐")
                self.logger.error(bstack1l11_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡯࡬ࡦࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡹࡷࡲࠠࡧࡴࡲࡱࠥࡪࡲࡪࡸࡨࡶ࠿ࠦࡻࡾࠤ᎑").format(e))
            self.logger.info(bstack1l11_opy_ (u"ࠧࡘࡥ࡮ࡱࡷࡩ࡙ࠥࡥࡳࡸࡨࡶࠥࡇࡤࡥࡴࡨࡷࡸࠦࡢࡦ࡫ࡱ࡫ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡ࠼ࠣࡿࢂࠨ᎒").format(str(url)))
            self.bstack1l11l1lllll_opy_(instance, url, f, kwargs)
            self.logger.info(bstack1l11_opy_ (u"ࠨࡤࡳ࡫ࡹࡩࡷ࠴ࡻ࡮ࡧࡷ࡬ࡴࡪ࡟࡯ࡣࡰࡩࢂࠦࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡠ࡫ࡱࡨࡪࡾ࠽ࡼࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢ࡭ࡳࡪࡥࡹࡿ࠽ࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࡾ࡯ࡼࡧࡲࡨࡵࢀࠦ᎓").format(method_name=method_name, platform_index=f.platform_index, args=args, kwargs=kwargs))
            threading.current_thread().bstackSessionDriver = driver
            return init(driver, *args, **kwargs)
        return wrapped
    def bstack1l1lllllll1_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1l1ll1_opy_, False):
            return
        if not f.bstack1lllll1l11l_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_):
            return
        platform_index = f.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_)
        if f.bstack1ll11lll11l_opy_(method_name, *args) and len(args) > 1:
            bstack1l1111ll11_opy_ = datetime.now()
            hub_url = bstack1lll11l1l1l_opy_.hub_url(driver)
            self.logger.warning(bstack1l11_opy_ (u"ࠢࡩࡷࡥࡣࡺࡸ࡬࠾ࠤ᎔") + str(hub_url) + bstack1l11_opy_ (u"ࠣࠤ᎕"))
            bstack1l11l1l1l11_opy_ = args[1][bstack1l11_opy_ (u"ࠤࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣ᎖")] if isinstance(args[1], dict) and bstack1l11_opy_ (u"ࠥࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤ᎗") in args[1] else None
            bstack1l11l1lll11_opy_ = bstack1l11_opy_ (u"ࠦࡦࡲࡷࡢࡻࡶࡑࡦࡺࡣࡩࠤ᎘")
            if isinstance(bstack1l11l1l1l11_opy_, dict):
                bstack1l1111ll11_opy_ = datetime.now()
                r = self.bstack1l11l1l1l1l_opy_(
                    instance.ref(),
                    platform_index,
                    f.framework_name,
                    f.framework_version,
                    hub_url
                )
                instance.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠧ࡭ࡲࡱࡥ࠽ࡶࡪ࡭ࡩࡴࡶࡨࡶࡤ࡯࡮ࡪࡶࠥ᎙"), datetime.now() - bstack1l1111ll11_opy_)
                try:
                    if not r.success:
                        self.logger.info(bstack1l11_opy_ (u"ࠨࡳࡰ࡯ࡨࡸ࡭࡯࡮ࡨࠢࡺࡩࡳࡺࠠࡸࡴࡲࡲ࡬ࡀࠠࠣ᎚") + str(r) + bstack1l11_opy_ (u"ࠢࠣ᎛"))
                        return
                    if r.hub_url:
                        f.bstack1l11l1l1lll_opy_(instance, driver, r.hub_url)
                        f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1l1ll1_opy_, True)
                except Exception as e:
                    self.logger.error(bstack1l11_opy_ (u"ࠣࡧࡵࡶࡴࡸࠢ᎜"), e)
    def bstack1l11ll1ll1l_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
            session_id = bstack1lll11l1l1l_opy_.session_id(driver)
            if session_id:
                bstack1l11ll11l11_opy_ = bstack1l11_opy_ (u"ࠤࡾࢁ࠿ࡹࡴࡢࡴࡷࠦ᎝").format(session_id)
                bstack1ll1l1l11l1_opy_.mark(bstack1l11ll11l11_opy_)
    def bstack1l11ll11111_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1l11ll_opy_, False):
            return
        ref = instance.ref()
        hub_url = bstack1lll11l1l1l_opy_.hub_url(driver)
        if not hub_url:
            self.logger.warning(bstack1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡰࡢࡴࡶࡩࠥ࡮ࡵࡣࡡࡸࡶࡱࡃࠢ᎞") + str(hub_url) + bstack1l11_opy_ (u"ࠦࠧ᎟"))
            return
        framework_session_id = bstack1lll11l1l1l_opy_.session_id(driver)
        if not framework_session_id:
            self.logger.warning(bstack1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡶࡸ࡫ࠠࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡪࡹࡳࡪࡱࡱࡣ࡮ࡪ࠽ࠣᎠ") + str(framework_session_id) + bstack1l11_opy_ (u"ࠨࠢᎡ"))
            return
        if bstack1lll11l1l1l_opy_.bstack1l11l1l11l1_opy_(*args) == bstack1lll11l1l1l_opy_.bstack1l11ll1l1ll_opy_:
            bstack1l11ll1ll11_opy_ = bstack1l11_opy_ (u"ࠢࡼࡿ࠽ࡩࡳࡪࠢᎢ").format(framework_session_id)
            bstack1l11ll11l11_opy_ = bstack1l11_opy_ (u"ࠣࡽࢀ࠾ࡸࡺࡡࡳࡶࠥᎣ").format(framework_session_id)
            bstack1ll1l1l11l1_opy_.end(
                label=bstack1l11_opy_ (u"ࠤࡶࡨࡰࡀࡤࡳ࡫ࡹࡩࡷࡀࡰࡰࡵࡷ࠱࡮ࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠧᎤ"),
                start=bstack1l11ll11l11_opy_,
                end=bstack1l11ll1ll11_opy_,
                status=True,
                failure=None
            )
            bstack1l1111ll11_opy_ = datetime.now()
            r = self.bstack1l11l1ll11l_opy_(
                ref,
                f.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_, 0),
                f.framework_name,
                f.framework_version,
                framework_session_id,
                hub_url,
            )
            instance.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠥ࡫ࡷࡶࡣ࠻ࡴࡨ࡫࡮ࡹࡴࡦࡴࡢࡷࡹࡧࡲࡵࠤᎥ"), datetime.now() - bstack1l1111ll11_opy_)
            f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1l11ll_opy_, r.success)
    def bstack1l11ll11lll_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lllll1l1l1_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1ll1l1_opy_, False):
            return
        ref = instance.ref()
        framework_session_id = bstack1lll11l1l1l_opy_.session_id(driver)
        hub_url = bstack1lll11l1l1l_opy_.hub_url(driver)
        bstack1l1111ll11_opy_ = datetime.now()
        r = self.bstack1l11ll11ll1_opy_(
            ref,
            f.bstack1lllll1l1l1_opy_(instance, bstack1lll11l1l1l_opy_.bstack1ll11lll1ll_opy_, 0),
            f.framework_name,
            f.framework_version,
            framework_session_id,
            hub_url,
        )
        instance.bstack11l111l111_opy_(bstack1l11_opy_ (u"ࠦ࡬ࡸࡰࡤ࠼ࡵࡩ࡬࡯ࡳࡵࡧࡵࡣࡸࡺ࡯ࡱࠤᎦ"), datetime.now() - bstack1l1111ll11_opy_)
        f.bstack1lllll1ll11_opy_(instance, bstack1ll1ll1l11l_opy_.bstack1l11l1ll1l1_opy_, r.success)
    @measure(event_name=EVENTS.bstack11l1l1l1ll_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l1l111ll11_opy_(self, platform_index: int, url: str, ref, user_input_params: bytes):
        req = structs.DriverInitRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.user_input_params = user_input_params
        req.ref = ref
        req.hub_url = url
        self.logger.debug(bstack1l11_opy_ (u"ࠧࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡸࡧࡥࡨࡷ࡯ࡶࡦࡴࡢ࡭ࡳ࡯ࡴ࠻ࠢࠥᎧ") + str(req) + bstack1l11_opy_ (u"ࠨࠢᎨ"))
        try:
            r = self.bstack1ll1llllll1_opy_.DriverInit(req)
            if not r.success:
                self.logger.debug(bstack1l11_opy_ (u"ࠢࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡩࡶࡴࡳࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡵࡸࡧࡨ࡫ࡳࡴ࠿ࠥᎩ") + str(r.success) + bstack1l11_opy_ (u"ࠣࠤᎪ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢᎫ") + str(e) + bstack1l11_opy_ (u"ࠥࠦᎬ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11ll111ll_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l11l1l1l1l_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        hub_url: str
    ):
        self.bstack1ll11l111ll_opy_()
        req = structs.AutomationFrameworkInitRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.hub_url = hub_url
        self.logger.debug(bstack1l11_opy_ (u"ࠦࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡩ࡯࡫ࡷ࠾ࠥࠨᎭ") + str(req) + bstack1l11_opy_ (u"ࠧࠨᎮ"))
        try:
            r = self.bstack1ll1llllll1_opy_.AutomationFrameworkInit(req)
            if not r.success:
                self.logger.debug(bstack1l11_opy_ (u"ࠨࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡨࡵࡳࡲࠦࡳࡦࡴࡹࡩࡷࡀࠠࡴࡷࡦࡧࡪࡹࡳ࠾ࠤᎯ") + str(r.success) + bstack1l11_opy_ (u"ࠢࠣᎰ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠣࡴࡳࡧ࠲࡫ࡲࡳࡱࡵ࠾ࠥࠨᎱ") + str(e) + bstack1l11_opy_ (u"ࠤࠥᎲ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11ll1l11l_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l11l1ll11l_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1ll11l111ll_opy_()
        req = structs.AutomationFrameworkStartRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1l11_opy_ (u"ࠥࡶࡪ࡭ࡩࡴࡶࡨࡶࡤࡹࡴࡢࡴࡷ࠾ࠥࠨᎳ") + str(req) + bstack1l11_opy_ (u"ࠦࠧᎴ"))
        try:
            r = self.bstack1ll1llllll1_opy_.AutomationFrameworkStart(req)
            if not r.success:
                self.logger.debug(bstack1l11_opy_ (u"ࠧࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡧࡴࡲࡱࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࠢᎵ") + str(r) + bstack1l11_opy_ (u"ࠨࠢᎶ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠢࡳࡲࡦ࠱ࡪࡸࡲࡰࡴ࠽ࠤࠧᎷ") + str(e) + bstack1l11_opy_ (u"ࠣࠤᎸ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l11ll1l1l1_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l11ll11ll1_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1ll11l111ll_opy_()
        req = structs.AutomationFrameworkStopRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1l11_opy_ (u"ࠤࡵࡩ࡬࡯ࡳࡵࡧࡵࡣࡸࡺ࡯ࡱ࠼ࠣࠦᎹ") + str(req) + bstack1l11_opy_ (u"ࠥࠦᎺ"))
        try:
            r = self.bstack1ll1llllll1_opy_.AutomationFrameworkStop(req)
            if not r.success:
                self.logger.debug(bstack1l11_opy_ (u"ࠦࡷ࡫ࡣࡦ࡫ࡹࡩࡩࠦࡦࡳࡱࡰࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥࠨᎻ") + str(r) + bstack1l11_opy_ (u"ࠧࠨᎼ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠨࡲࡱࡥ࠰ࡩࡷࡸ࡯ࡳ࠼ࠣࠦᎽ") + str(e) + bstack1l11_opy_ (u"ࠢࠣᎾ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1ll1ll1111_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l11l1lllll_opy_(self, instance: bstack1llllll11l1_opy_, url: str, f: bstack1lll11l1l1l_opy_, kwargs):
        bstack1l11l1ll111_opy_ = version.parse(f.framework_version)
        bstack1l11ll11l1l_opy_ = kwargs.get(bstack1l11_opy_ (u"ࠣࡱࡳࡸ࡮ࡵ࡮ࡴࠤᎿ"))
        bstack1l11ll1l111_opy_ = kwargs.get(bstack1l11_opy_ (u"ࠤࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᏀ"))
        bstack1l1l1111lll_opy_ = {}
        bstack1l11l1lll1l_opy_ = {}
        bstack1l11l1llll1_opy_ = None
        bstack1l11l1ll1ll_opy_ = {}
        if bstack1l11ll1l111_opy_ is not None or bstack1l11ll11l1l_opy_ is not None: # check top level caps
            if bstack1l11ll1l111_opy_ is not None:
                bstack1l11l1ll1ll_opy_[bstack1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᏁ")] = bstack1l11ll1l111_opy_
            if bstack1l11ll11l1l_opy_ is not None and callable(getattr(bstack1l11ll11l1l_opy_, bstack1l11_opy_ (u"ࠦࡹࡵ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᏂ"))):
                bstack1l11l1ll1ll_opy_[bstack1l11_opy_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡸࡥࡡࡴࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨᏃ")] = bstack1l11ll11l1l_opy_.to_capabilities()
        response = self.bstack1l1l111ll11_opy_(f.platform_index, url, instance.ref(), json.dumps(bstack1l11l1ll1ll_opy_).encode(bstack1l11_opy_ (u"ࠨࡵࡵࡨ࠰࠼ࠧᏄ")))
        if response is not None and response.capabilities:
            bstack1l1l1111lll_opy_ = json.loads(response.capabilities.decode(bstack1l11_opy_ (u"ࠢࡶࡶࡩ࠱࠽ࠨᏅ")))
            if not bstack1l1l1111lll_opy_: # empty caps bstack1l1l11l111l_opy_ bstack1l1l11111l1_opy_ bstack1l1l111llll_opy_ bstack1lll1ll11ll_opy_ or error in processing
                return
            bstack1l11l1llll1_opy_ = f.bstack1lll1lll111_opy_[bstack1l11_opy_ (u"ࠣࡥࡵࡩࡦࡺࡥࡠࡱࡳࡸ࡮ࡵ࡮ࡴࡡࡩࡶࡴࡳ࡟ࡤࡣࡳࡷࠧᏆ")](bstack1l1l1111lll_opy_)
        if bstack1l11ll11l1l_opy_ is not None and bstack1l11l1ll111_opy_ >= version.parse(bstack1l11_opy_ (u"ࠩ࠶࠲࠽࠴࠰ࠨᏇ")):
            bstack1l11l1lll1l_opy_ = None
        if (
                not bstack1l11ll11l1l_opy_ and not bstack1l11ll1l111_opy_
        ) or (
                bstack1l11l1ll111_opy_ < version.parse(bstack1l11_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩᏈ"))
        ):
            bstack1l11l1lll1l_opy_ = {}
            bstack1l11l1lll1l_opy_.update(bstack1l1l1111lll_opy_)
        self.logger.info(bstack1lll11ll11_opy_)
        if os.environ.get(bstack1l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠢᏉ")).lower().__eq__(bstack1l11_opy_ (u"ࠧࡺࡲࡶࡧࠥᏊ")):
            kwargs.update(
                {
                    bstack1l11_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳࠤᏋ"): f.bstack1l11ll111l1_opy_,
                }
            )
        if bstack1l11l1ll111_opy_ >= version.parse(bstack1l11_opy_ (u"ࠧ࠵࠰࠴࠴࠳࠶ࠧᏌ")):
            if bstack1l11ll1l111_opy_ is not None:
                del kwargs[bstack1l11_opy_ (u"ࠣࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣᏍ")]
            kwargs.update(
                {
                    bstack1l11_opy_ (u"ࠤࡲࡴࡹ࡯࡯࡯ࡵࠥᏎ"): bstack1l11l1llll1_opy_,
                    bstack1l11_opy_ (u"ࠥ࡯ࡪ࡫ࡰࡠࡣ࡯࡭ࡻ࡫ࠢᏏ"): True,
                    bstack1l11_opy_ (u"ࠦ࡫࡯࡬ࡦࡡࡧࡩࡹ࡫ࡣࡵࡱࡵࠦᏐ"): None,
                }
            )
        elif bstack1l11l1ll111_opy_ >= version.parse(bstack1l11_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫᏑ")):
            kwargs.update(
                {
                    bstack1l11_opy_ (u"ࠨࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᏒ"): bstack1l11l1lll1l_opy_,
                    bstack1l11_opy_ (u"ࠢࡰࡲࡷ࡭ࡴࡴࡳࠣᏓ"): bstack1l11l1llll1_opy_,
                    bstack1l11_opy_ (u"ࠣ࡭ࡨࡩࡵࡥࡡ࡭࡫ࡹࡩࠧᏔ"): True,
                    bstack1l11_opy_ (u"ࠤࡩ࡭ࡱ࡫࡟ࡥࡧࡷࡩࡨࡺ࡯ࡳࠤᏕ"): None,
                }
            )
        elif bstack1l11l1ll111_opy_ >= version.parse(bstack1l11_opy_ (u"ࠪ࠶࠳࠻࠳࠯࠲ࠪᏖ")):
            kwargs.update(
                {
                    bstack1l11_opy_ (u"ࠦࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᏗ"): bstack1l11l1lll1l_opy_,
                    bstack1l11_opy_ (u"ࠧࡱࡥࡦࡲࡢࡥࡱ࡯ࡶࡦࠤᏘ"): True,
                    bstack1l11_opy_ (u"ࠨࡦࡪ࡮ࡨࡣࡩ࡫ࡴࡦࡥࡷࡳࡷࠨᏙ"): None,
                }
            )
        else:
            kwargs.update(
                {
                    bstack1l11_opy_ (u"ࠢࡥࡧࡶ࡭ࡷ࡫ࡤࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷ࡭ࡪࡹࠢᏚ"): bstack1l11l1lll1l_opy_,
                    bstack1l11_opy_ (u"ࠣ࡭ࡨࡩࡵࡥࡡ࡭࡫ࡹࡩࠧᏛ"): True,
                    bstack1l11_opy_ (u"ࠤࡩ࡭ࡱ࡫࡟ࡥࡧࡷࡩࡨࡺ࡯ࡳࠤᏜ"): None,
                }
            )