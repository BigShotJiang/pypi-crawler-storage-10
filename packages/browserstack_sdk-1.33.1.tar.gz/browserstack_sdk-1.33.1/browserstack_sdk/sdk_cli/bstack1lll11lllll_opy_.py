# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
from browserstack_sdk.sdk_cli.bstack1lll1111l11_opy_ import bstack1ll1l11ll11_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l11ll_opy_ import (
    bstack1lllll111ll_opy_,
    bstack1llll1l1lll_opy_,
    bstack1llllll11l1_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll11l1l1l_opy_
from typing import Tuple, Callable, Any
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1lll1111l11_opy_ import bstack1ll1l11ll11_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import traceback
import os
import time
class bstack1ll1l1ll11l_opy_(bstack1ll1l11ll11_opy_):
    bstack1ll11l11ll1_opy_ = False
    def __init__(self):
        super().__init__()
        bstack1lll11l1l1l_opy_.bstack1ll111l11ll_opy_((bstack1lllll111ll_opy_.bstack1lllll11l1l_opy_, bstack1llll1l1lll_opy_.PRE), self.bstack1l1lllllll1_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1lllllll1_opy_(
        self,
        f: bstack1lll11l1l1l_opy_,
        driver: object,
        exec: Tuple[bstack1llllll11l1_opy_, str],
        bstack1llll1lllll_opy_: Tuple[bstack1lllll111ll_opy_, bstack1llll1l1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        hub_url = f.hub_url(driver)
        if f.bstack1l1lllll1ll_opy_(hub_url):
            if not bstack1ll1l1ll11l_opy_.bstack1ll11l11ll1_opy_:
                self.logger.warning(bstack1l11_opy_ (u"ࠧࡲ࡯ࡤࡣ࡯ࠤࡸ࡫࡬ࡧ࠯࡫ࡩࡦࡲࠠࡧ࡮ࡲࡻࠥࡪࡩࡴࡣࡥࡰࡪࡪࠠࡧࡱࡵࠤࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠣ࡭ࡳ࡬ࡲࡢࠢࡶࡩࡸࡹࡩࡰࡰࡶࠤ࡭ࡻࡢࡠࡷࡵࡰࡂࠨቂ") + str(hub_url) + bstack1l11_opy_ (u"ࠨࠢቃ"))
                bstack1ll1l1ll11l_opy_.bstack1ll11l11ll1_opy_ = True
            return
        command_name = f.bstack1ll1111lll1_opy_(*args)
        bstack1l1llllll1l_opy_ = f.bstack1l1llll1ll1_opy_(*args)
        if command_name and command_name.lower() == bstack1l11_opy_ (u"ࠢࡧ࡫ࡱࡨࡪࡲࡥ࡮ࡧࡱࡸࠧቄ") and bstack1l1llllll1l_opy_:
            framework_session_id = f.session_id(driver)
            locator_type, locator_value = bstack1l1llllll1l_opy_.get(bstack1l11_opy_ (u"ࠣࡷࡶ࡭ࡳ࡭ࠢቅ"), None), bstack1l1llllll1l_opy_.get(bstack1l11_opy_ (u"ࠤࡹࡥࡱࡻࡥࠣቆ"), None)
            if not framework_session_id or not locator_type or not locator_value:
                self.logger.warning(bstack1l11_opy_ (u"ࠥࡿࡨࡵ࡭࡮ࡣࡱࡨࡤࡴࡡ࡮ࡧࢀ࠾ࠥࡳࡩࡴࡵ࡬ࡲ࡬ࠦࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࡢ࡭ࡩࠦ࡯ࡳࠢࡤࡶ࡬ࡹ࠮ࡶࡵ࡬ࡲ࡬ࡃࡻ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࢃࠠࡰࡴࠣࡥࡷ࡭ࡳ࠯ࡸࡤࡰࡺ࡫࠽ࠣቇ") + str(locator_value) + bstack1l11_opy_ (u"ࠦࠧቈ"))
                return
            def bstack1lllll1l111_opy_(driver, bstack1l1llll1l1l_opy_, *args, **kwargs):
                from selenium.common.exceptions import NoSuchElementException
                try:
                    result = bstack1l1llll1l1l_opy_(driver, *args, **kwargs)
                    response = self.bstack1l1lllll11l_opy_(
                        framework_session_id=framework_session_id,
                        is_success=True,
                        locator_type=locator_type,
                        locator_value=locator_value,
                    )
                    if response and response.execute_script:
                        driver.execute_script(response.execute_script)
                        self.logger.info(bstack1l11_opy_ (u"ࠧࡹࡵࡤࡥࡨࡷࡸ࠳ࡳࡤࡴ࡬ࡴࡹࡀࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࡃࡻ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࢃࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡸࡤࡰࡺ࡫࠽ࠣ቉") + str(locator_value) + bstack1l11_opy_ (u"ࠨࠢቊ"))
                    else:
                        self.logger.warning(bstack1l11_opy_ (u"ࠢࡴࡷࡦࡧࡪࡹࡳ࠮ࡰࡲ࠱ࡸࡩࡲࡪࡲࡷ࠾ࠥࡲ࡯ࡤࡣࡷࡳࡷࡥࡴࡺࡲࡨࡁࢀࡲ࡯ࡤࡣࡷࡳࡷࡥࡴࡺࡲࡨࢁࠥࡲ࡯ࡤࡣࡷࡳࡷࡥࡶࡢ࡮ࡸࡩࡂࢁ࡬ࡰࡥࡤࡸࡴࡸ࡟ࡷࡣ࡯ࡹࡪࢃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠥቋ") + str(response) + bstack1l11_opy_ (u"ࠣࠤቌ"))
                    return result
                except NoSuchElementException as e:
                    locator = (locator_type, locator_value)
                    return self.__1l1llllll11_opy_(
                        driver, bstack1l1llll1l1l_opy_, e, framework_session_id, locator, *args, **kwargs
                    )
            bstack1lllll1l111_opy_.__name__ = command_name
            return bstack1lllll1l111_opy_
    def __1l1llllll11_opy_(
        self,
        driver,
        bstack1l1llll1l1l_opy_: Callable,
        exception,
        framework_session_id: str,
        locator: Tuple[str, str],
        *args,
        **kwargs,
    ):
        try:
            locator_type, locator_value = locator
            response = self.bstack1l1lllll11l_opy_(
                framework_session_id=framework_session_id,
                is_success=False,
                locator_type=locator_type,
                locator_value=locator_value,
            )
            if response and response.execute_script:
                driver.execute_script(response.execute_script)
                self.logger.info(bstack1l11_opy_ (u"ࠤࡩࡥ࡮ࡲࡵࡳࡧ࠰࡬ࡪࡧ࡬ࡪࡰࡪ࠱ࡹࡸࡩࡨࡩࡨࡶࡪࡪ࠺ࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫࠽ࡼ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫ࡽࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡹࡥࡱࡻࡥ࠾ࠤቍ") + str(locator_value) + bstack1l11_opy_ (u"ࠥࠦ቎"))
                bstack1l1llll1lll_opy_ = self.bstack1l1lllll111_opy_(
                    framework_session_id=framework_session_id,
                    locator_type=locator_type,
                )
                self.logger.info(bstack1l11_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡷࡵࡩ࠲࡮ࡥࡢ࡮࡬ࡲ࡬࠳ࡲࡦࡵࡸࡰࡹࡀࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࡃࡻ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࢃࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡸࡤࡰࡺ࡫࠽ࡼ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡹࡥࡱࡻࡥࡾࠢ࡫ࡩࡦࡲࡩ࡯ࡩࡢࡶࡪࡹࡵ࡭ࡶࡀࠦ቏") + str(bstack1l1llll1lll_opy_) + bstack1l11_opy_ (u"ࠧࠨቐ"))
                if bstack1l1llll1lll_opy_.success and args and len(args) > 1:
                    args[1].update(
                        {
                            bstack1l11_opy_ (u"ࠨࡵࡴ࡫ࡱ࡫ࠧቑ"): bstack1l1llll1lll_opy_.locator_type,
                            bstack1l11_opy_ (u"ࠢࡷࡣ࡯ࡹࡪࠨቒ"): bstack1l1llll1lll_opy_.locator_value,
                        }
                    )
                    return bstack1l1llll1l1l_opy_(driver, *args, **kwargs)
                elif os.environ.get(bstack1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡂࡋࡢࡈࡊࡈࡕࡈࠤቓ"), False):
                    self.logger.info(bstack1111l111ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡵࡳࡧ࠰࡬ࡪࡧ࡬ࡪࡰࡪ࠱ࡷ࡫ࡳࡶ࡮ࡷ࠱ࡲ࡯ࡳࡴ࡫ࡱ࡫࠿ࠦࡳ࡭ࡧࡨࡴ࠭࠹࠰ࠪࠢ࡯ࡩࡹࡺࡩ࡯ࡩࠣࡽࡴࡻࠠࡪࡰࡶࡴࡪࡩࡴࠡࡶ࡫ࡩࠥࡨࡲࡰࡹࡶࡩࡷࠦࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢ࡯ࡳ࡬ࡹࠢቔ"))
                    time.sleep(300)
            else:
                self.logger.warning(bstack1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡶࡴࡨ࠱ࡳࡵ࠭ࡴࡥࡵ࡭ࡵࡺ࠺ࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫࠽ࡼ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫ࡽࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡹࡥࡱࡻࡥ࠾ࡽ࡯ࡳࡨࡧࡴࡰࡴࡢࡺࡦࡲࡵࡦࡿࠣࡶࡪࡹࡰࡰࡰࡶࡩࡂࠨቕ") + str(response) + bstack1l11_opy_ (u"ࠦࠧቖ"))
        except Exception as err:
            self.logger.warning(bstack1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡸࡶࡪ࠳ࡨࡦࡣ࡯࡭ࡳ࡭࠭ࡳࡧࡶࡹࡱࡺ࠺ࠡࡧࡵࡶࡴࡸ࠺ࠡࠤ቗") + str(err) + bstack1l11_opy_ (u"ࠨࠢቘ"))
        raise exception
    @measure(event_name=EVENTS.bstack1l1lllll1l1_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l1lllll11l_opy_(
        self,
        framework_session_id: str,
        is_success: bool,
        locator_type: str,
        locator_value: str,
        platform_index=bstack1l11_opy_ (u"ࠢ࠱ࠤ቙"),
    ):
        self.bstack1ll11l111ll_opy_()
        req = structs.AISelfHealStepRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.is_success = is_success
        req.test_name = bstack1l11_opy_ (u"ࠣࠤቚ")
        req.locator_type = locator_type
        req.locator_value = locator_value
        try:
            r = self.bstack1ll1llllll1_opy_.AISelfHealStep(req)
            self.logger.info(bstack1l11_opy_ (u"ࠤࡵࡩࡨ࡫ࡩࡷࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࠦቛ") + str(r) + bstack1l11_opy_ (u"ࠥࠦቜ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠦࡷࡶࡣ࠮ࡧࡵࡶࡴࡸ࠺ࠡࠤቝ") + str(e) + bstack1l11_opy_ (u"ࠧࠨ቞"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l1llllllll_opy_, stage=STAGE.bstack1l11l1ll_opy_)
    def bstack1l1lllll111_opy_(self, framework_session_id: str, locator_type: str, platform_index=bstack1l11_opy_ (u"ࠨ࠰ࠣ቟")):
        self.bstack1ll11l111ll_opy_()
        req = structs.AISelfHealGetRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.locator_type = locator_type
        try:
            r = self.bstack1ll1llllll1_opy_.AISelfHealGetResult(req)
            self.logger.info(bstack1l11_opy_ (u"ࠢࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡩࡶࡴࡳࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࠤበ") + str(r) + bstack1l11_opy_ (u"ࠣࠤቡ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢቢ") + str(e) + bstack1l11_opy_ (u"ࠥࠦባ"))
            traceback.print_exc()
            raise e