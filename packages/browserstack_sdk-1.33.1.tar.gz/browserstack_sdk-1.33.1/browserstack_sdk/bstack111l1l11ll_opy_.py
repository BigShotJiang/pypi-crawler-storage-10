# coding: UTF-8
import sys
bstack1lll1l1_opy_ = sys.version_info [0] == 2
bstack1l11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack1l11_opy_ (bstack11ll1l_opy_):
    global bstack1lll1ll_opy_
    bstack1111l11_opy_ = ord (bstack11ll1l_opy_ [-1])
    bstackl_opy_ = bstack11ll1l_opy_ [:-1]
    bstack1ll11_opy_ = bstack1111l11_opy_ % len (bstackl_opy_)
    bstack1ll1_opy_ = bstackl_opy_ [:bstack1ll11_opy_] + bstackl_opy_ [bstack1ll11_opy_:]
    if bstack1lll1l1_opy_:
        bstack11l11l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    else:
        bstack11l11l1_opy_ = str () .join ([chr (ord (char) - bstack1l11ll_opy_ - (bstack11l1l_opy_ + bstack1111l11_opy_) % bstack11l1ll_opy_) for bstack11l1l_opy_, char in enumerate (bstack1ll1_opy_)])
    return eval (bstack11l11l1_opy_)
import os
class RobotHandler():
    def __init__(self, args, logger, bstack11111ll1ll_opy_, bstack11111l1lll_opy_):
        self.args = args
        self.logger = logger
        self.bstack11111ll1ll_opy_ = bstack11111ll1ll_opy_
        self.bstack11111l1lll_opy_ = bstack11111l1lll_opy_
    @staticmethod
    def version():
        import robot
        return robot.__version__
    @staticmethod
    def bstack111l1l1l11_opy_(bstack1111111111_opy_):
        bstack11111111ll_opy_ = []
        if bstack1111111111_opy_:
            tokens = str(os.path.basename(bstack1111111111_opy_)).split(bstack1l11_opy_ (u"ࠥࡣࠧႣ"))
            camelcase_name = bstack1l11_opy_ (u"ࠦࠥࠨႤ").join(t.title() for t in tokens)
            suite_name, bstack11111111l1_opy_ = os.path.splitext(camelcase_name)
            bstack11111111ll_opy_.append(suite_name)
        return bstack11111111ll_opy_
    @staticmethod
    def bstack111111111l_opy_(typename):
        if bstack1l11_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࠣႥ") in typename:
            return bstack1l11_opy_ (u"ࠨࡁࡴࡵࡨࡶࡹ࡯࡯࡯ࡇࡵࡶࡴࡸࠢႦ")
        return bstack1l11_opy_ (u"ࠢࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠣႧ")