def cite() -> str:
    """Return a citation notice for the forthcoming Pharmacon paper."""
    return (
        "Pharmacon (pre-release) — "
        "A forthcoming library accompanying a scientific publication. "
        "Full functionality will be added upon manuscript acceptance."
    )
