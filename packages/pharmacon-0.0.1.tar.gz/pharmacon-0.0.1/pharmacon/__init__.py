"""
Pharmacon: Computational pharmacology tools.

This is a preliminary version reserved for an upcoming scientific release.
"""
__version__ = "0.0.1"

from .core import cite
