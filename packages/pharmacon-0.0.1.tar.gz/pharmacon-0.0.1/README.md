# Pharmacon

**Pharmacon** is a forthcoming Python library for computational pharmacology and cheminformatics.

This package currently serves as a lightweight pre-release to reserve the project name until the
corresponding manuscript is published.

Install:

```bash
pip install pharmacon
