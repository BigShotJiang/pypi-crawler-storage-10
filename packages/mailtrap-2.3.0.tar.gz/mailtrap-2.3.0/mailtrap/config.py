GENERAL_HOST = "mailtrap.io"
BULK_HOST = "bulk.api.mailtrap.io"
SANDBOX_HOST = "sandbox.api.mailtrap.io"
SENDING_HOST = "send.api.mailtrap.io"

DEFAULT_REQUEST_TIMEOUT = 30  # in seconds
