import pypdf
from dataclasses import dataclass


@dataclass
class JSONLookupObject:
    lookups: list[str]
    result: str


class PDFStringFinder:
    def __init__(self, pdf_path: str, lookup_objects: list[JSONLookupObject]):
        self.pdf_path = pdf_path
        self.lookup_objects = lookup_objects

    def get_lookup_result(self) -> str:
        with open(self.pdf_path, "rb") as f:
            reader = pypdf.PdfReader(f)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"

            for lookup_obj in self.lookup_objects:
                for lookup in lookup_obj.lookups:
                    if lookup in text:
                        result = lookup_obj.result
                        return result

            return None
    
def main():
    print("This file is a class definition for PDFStringFinder and is not intended to be run directly.")

if __name__ == "__main__":
    main()

