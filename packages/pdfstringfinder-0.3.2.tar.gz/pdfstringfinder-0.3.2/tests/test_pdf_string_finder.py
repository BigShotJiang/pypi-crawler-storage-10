import pytest
from unittest.mock import patch, MagicMock, mock_open
from pdf_string_finder.pdf_string_finder import PDFStringFinder, JSONLookupObject


def test_jsonlookupobject_dataclass():
    obj = JSONLookupObject(lookups=["a", "b"], result="res")
    assert obj.lookups == ["a", "b"]
    assert obj.result == "res"


@patch("pypdf.PdfReader")
@patch("builtins.open", new_callable=mock_open)
def test_get_lookup_result_first_match(mock_file, mock_pdf_reader):
    # Prepare mocked PDF pages
    page = MagicMock()
    page.extract_text.return_value = "This document contains apple and other stuff."
    reader = MagicMock()
    reader.pages = [page]
    mock_pdf_reader.return_value = reader

    lookup_objects = [
        JSONLookupObject(lookups=["apple"], result="fruit"),
        JSONLookupObject(lookups=["banana"], result="banana_result"),
    ]

    finder = PDFStringFinder("dummy.pdf", lookup_objects)
    result = finder.get_lookup_result()

    assert result == "fruit"
    mock_file.assert_called_once_with("dummy.pdf", "rb")


@patch("pypdf.PdfReader")
@patch("builtins.open", new_callable=mock_open)
def test_get_lookup_result_no_match(mock_file, mock_pdf_reader):
    page = MagicMock()
    page.extract_text.return_value = "Nothing relevant here."
    reader = MagicMock()
    reader.pages = [page]
    mock_pdf_reader.return_value = reader

    lookup_objects = [
        JSONLookupObject(lookups=["apple"], result="fruit"),
    ]

    finder = PDFStringFinder("dummy.pdf", lookup_objects)
    result = finder.get_lookup_result()

    assert result is None


def test_get_lookup_result_file_not_found(tmp_path):
    # Use a path that does not exist to ensure FileNotFoundError is raised
    lookup_objects = [JSONLookupObject(lookups=["x"], result="y")]
    finder = PDFStringFinder(str(tmp_path / "no_such_file.pdf"), lookup_objects)

    with pytest.raises(FileNotFoundError):
        finder.get_lookup_result()
