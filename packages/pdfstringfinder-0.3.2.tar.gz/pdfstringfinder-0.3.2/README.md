PDFStringFinder
================

Lightweight utility for scanning PDF files and returning an identifier based on a set of lookup strings.

This package provides a small class, `PDFStringFinder`, which loads a PDF, extracts text from its pages
using `pypdf`, and returns the `result` associated with the first lookup string that appears in the
document (based on the configured lookup objects).

Quick links
- Source: local workspace
- Tests: `tests/`

Installation
------------

This project uses a local virtual environment workflow managed by `uv` in this repository. Before working
on the project you should install the package into the virtual environment in editable/develop mode so
that changes to the source are immediately available to the environment.

Run the following from the repository root (PowerShell example):

```powershell
cd "c:\Projects\Python Packages\PDFStringFinder"
uv pip install -e .
```

Notes:
- The `uv pip install -e .` command installs the package in "editable" mode within the project's virtual
	environment managed by `uv` so that the source files in this repository are used directly. This is the
	recommended developer workflow so tests and quick iteration pick up your source changes without re-installing.

Usage
-----

Typical usage is simple. Create `JSONLookupObject` entries (each with a list of possible lookup strings and
an associated result key), then instantiate `PDFStringFinder` with a path to a PDF and the lookup objects.

Example:

```python
from pdf_string_finder.pdf_string_finder import PDFStringFinder, JSONLookupObject

lookups = [
		JSONLookupObject(lookups=["apple", "banana"], result="fruit"),
		JSONLookupObject(lookups=["01904 764557"], result="RM Contractors Ltd"),
]

finder = PDFStringFinder("path/to/document.pdf", lookups)
result = finder.get_lookup_result()
print(result)
```

Testing
-------

The project uses `pytest`. After installing dev dependencies into the project virtual environment (via
`uv pip install -e .`), run the tests from the repository root:

```powershell
& "C:/Projects/Python Packages/PDFStringFinder/.venv/Scripts/python.exe" -m pytest -v
```

There are both unit tests that mock PDF reading and an integration-style test that uses `tests/sample.pdf`.
The integration test is skipped automatically if the sample files are not present.

Contributing
------------

- Please keep tests fast and deterministic — prefer mocking `pypdf.PdfReader` where possible.
- Follow the repo layout and add tests under `tests/`.

