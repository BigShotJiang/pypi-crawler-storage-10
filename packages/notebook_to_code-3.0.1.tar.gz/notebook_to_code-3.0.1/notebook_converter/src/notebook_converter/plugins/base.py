"""
Plugin system for extensible notebook conversion.
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
import pluggy

from ..utils.metadata_handler import MetadataHandler


class ConversionTheme(ABC):
    """Base class for conversion themes."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Theme name."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Theme description."""
        pass
    
    @abstractmethod
    def format_code_cell(self, code: str, metadata: Dict[str, Any]) -> str:
        """Format a code cell according to theme."""
        pass
    
    @abstractmethod
    def format_markdown_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format a markdown cell according to theme."""
        pass
    
    @abstractmethod
    def format_raw_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format a raw cell according to theme."""
        pass


class ConversionHook:
    """Hook specification for conversion plugins."""
    
    @pluggy.hookspec
    def pre_convert(self, input_path: str, options: Dict[str, Any]) -> None:
        """Called before conversion starts."""
        pass
    
    @pluggy.hookspec
    def post_convert(self, output_path: str, stats: Dict[str, Any]) -> None:
        """Called after conversion completes."""
        pass
    
    @pluggy.hookspec
    def process_cell(self, cell: Dict[str, Any], cell_index: int) -> Dict[str, Any]:
        """Called to process each cell."""
        pass


class PluginManager:
    """Manages conversion plugins and themes."""
    
    def __init__(self):
        """Initialize plugin manager."""
        self.logger = logging.getLogger(self.__class__.__name__)
        self.themes: Dict[str, ConversionTheme] = {}
        self.hook_manager = pluggy.PluginManager("notebook_converter")
        self.hook_manager.add_hookspecs(ConversionHook)
        
        # Load built-in themes
        self._load_builtin_themes()
    
    def _load_builtin_themes(self):
        """Load built-in themes."""
        from .themes.default import DefaultTheme
        from .themes.minimal import MinimalTheme
        
        self.register_theme(DefaultTheme())
        self.register_theme(MinimalTheme())
    
    def register_theme(self, theme: ConversionTheme):
        """Register a conversion theme."""
        self.themes[theme.name] = theme
        self.logger.debug(f"Registered theme: {theme.name}")
    
    def get_theme(self, name: str) -> ConversionTheme:
        """Get a theme by name."""
        if name not in self.themes:
            self.logger.warning(f"Theme '{name}' not found, using default")
            name = "default"
        
        return self.themes.get(name, self.themes["default"])
    
    def list_themes(self) -> List[str]:
        """List available theme names."""
        return list(self.themes.keys())
    
    def register_plugin(self, plugin):
        """Register a plugin."""
        self.hook_manager.register(plugin)
    
    def call_hook(self, hook_name: str, **kwargs):
        """Call a plugin hook."""
        return getattr(self.hook_manager.hook, hook_name)(**kwargs)
