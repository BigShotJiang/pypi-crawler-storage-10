"""
Advanced Jupyter Notebook Converter

A comprehensive tool for converting between Jupyter notebooks and Python scripts with:
- Semantic markdown processing
- Round-trip conversion support
- Quality analysis
- Plugin system for themes
- Batch processing capabilities
"""

from .converter import (
    AdvancedNotebookConverter,
    ConversionOptions,
    ConversionStats,
    NotebookConverterError,
    InvalidNotebookError,
    ConversionError,
    RoundTripError
)
from .cli import cli

# Version of the package
__version__ = "3.0.1"
__author__ = "Your Name"
__license__ = "MIT"

# Define what gets imported with 'from package import *'
__all__ = [
    'AdvancedNotebookConverter',
    'ConversionOptions',
    'ConversionStats',
    'NotebookConverterError',
    'InvalidNotebookError',
    'ConversionError',
    'RoundTripError',
    'cli'
]

# Package-level logger
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

def get_version() -> str:
    """Get the current version of the package."""
    return __version__
