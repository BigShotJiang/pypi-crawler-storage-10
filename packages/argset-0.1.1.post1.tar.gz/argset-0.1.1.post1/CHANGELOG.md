v0.1.1.post1 (2025-10-28)
-------------------------
- Mark as no longer maintained

v0.1.1 (2024-12-01)
-------------------
- Support Python 3.10, 3.11, 3.12, and 3.13
- Drop support for Python 3.6 and 3.7
- Migrated from setuptools to hatch

v0.1.0 (2021-06-04)
-------------------
Initial release
