from setuptools import setup, find_packages
import pathlib  

HERE = pathlib.Path(__file__).parent
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name='learn_bin',
    version='0.3.3',

    long_description=README,
    long_description_content_type="text/markdown",
    
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'learn_bin=learn_bin.main:print_db',
            ],
            },
            author='Shahaan Bharucha')