# 🧮 Decimal to Binary Converter

A simple and educational Python utility that converts a **decimal number** into its **binary representation**, while showing the **step-by-step division process**.
Perfect for beginners learning how binary conversion works!

---

## 📦 Features

✅ Converts **any positive integer** to binary
✅ Displays **detailed division steps** for learning
✅ Handles **input validation** (no negative numbers)
✅ Lightweight — **no external dependencies**

---

## 🚀 Installation

You can install the package directly from [PyPI](https://pypi.org/) once published:

    pip install decimal-to-binary

---

## 🧠 Usage

Import and use it in your Python script:

    from decimal_to_binary import print_db

    print_db(100)

### Example Output

    ------------------------------------------
    Divide by 2 till 0 and note the remainders
    ------------------------------------------
    100 / 2 | 0
    50 / 2 | 0
    25 / 2 | 1
    12 / 2 | 0
    6 / 2 | 0
    3 / 2 | 1
    1 / 2 | 1
    <-------   reverse the remainders
    0011001   to get the final answer
    Decimal: (100) Base = 10 --> Binary: (1100100) Base = 2

### 📜 Function Details

`print_db(num: int) -> str`
Prints the decimal-to-binary conversion result in a readable format.

`get_binary(num: int) -> str`
Performs the actual conversion using the divide-by-2 method, returning the binary representation as a string.

### ⚠️ Error Handling

Raises `ValueError` if a negative number is passed:

    print_db(-5)
    # ValueError: Must Be Positive

### 🧰 Example CLI Run

If run as a script:

    python main.py

Output:

    Decimal: (100) Base = 10 --> Binary: (1100100) Base = 2


---

## 👨‍💻 Author

**Shahaan Bharucha**
[GitHub](https://github.com/Shahaanb)
