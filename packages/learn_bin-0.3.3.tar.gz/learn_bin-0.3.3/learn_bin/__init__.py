from .main import print_db
from .main import get_binary