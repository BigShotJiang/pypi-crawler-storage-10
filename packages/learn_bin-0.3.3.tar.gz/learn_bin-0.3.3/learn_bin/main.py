# makes that number look fine
def print_db(num: int) -> str:
    print(f"Decimal: ({num}) Base = 10 --> Binary: ({get_binary(num)}) Base = 2")


# converts dec to binary
def get_binary(num: int) -> str:
    if num < 0:
        raise ValueError("Must Be Positive")
    current = int(num)
    binary = []
    print("------------------------------------------")
    print("Divide by 2 till 0 and note the remainders")
    print("------------------------------------------")
    while True:
        rem = current % 2
        print(f"{current} / 2 | {rem}")
        current = int(current / 2)
        binary.append(rem)
        if current == 0:
            break
    print("<-------   reverse the remainders")
    print(*binary, "   to get the final answer", sep="")
    binary.reverse()
    final = int("".join([str(e) for e in binary]))
    return f"{final:04}"

if __name__ == "__main__":
    print_db(100)