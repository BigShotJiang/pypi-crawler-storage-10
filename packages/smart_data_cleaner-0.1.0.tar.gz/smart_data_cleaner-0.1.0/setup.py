from setuptools import setup, find_packages

setup(
    name='smart_data_cleaner',
    version='0.1.0',
    author='Anchal Bhondekar' 'email- anchal02409@gmail.com',
    description='Smart data cleaning and outlier detection library',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'numpy',
        'scikit-learn',
        'matplotlib',
        'seaborn'
    ]
)
