# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from untapd_strategy import UntapdStrategy, AsyncUntapdStrategy
from untapd_strategy.types import (
    StrategyGetDataResponse,
    StrategyGetNameResponse,
    StrategyGetTickersResponse,
    StrategyGetLeverageResponse,
    StrategyGetTradingDaysResponse,
)
from untapd_strategy._utils import parse_date

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestStrategy:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_data(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_data_with_all_params(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_data(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_data(self, client: UntapdStrategy) -> None:
        response = client.strategy.with_raw_response.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = response.parse()
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_data(self, client: UntapdStrategy) -> None:
        with client.strategy.with_streaming_response.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = response.parse()
            assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_leverage(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_leverage_with_all_params(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_leverage(
            max_leverage=3,
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_leverage(self, client: UntapdStrategy) -> None:
        response = client.strategy.with_raw_response.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = response.parse()
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_leverage(self, client: UntapdStrategy) -> None:
        with client.strategy.with_streaming_response.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = response.parse()
            assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_name(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_name(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_name_with_all_params(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_name(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_name(self, client: UntapdStrategy) -> None:
        response = client.strategy.with_raw_response.get_name(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = response.parse()
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_name(self, client: UntapdStrategy) -> None:
        with client.strategy.with_streaming_response.get_name(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = response.parse()
            assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_tickers(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_tickers(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_tickers_with_all_params(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_tickers(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_tickers(self, client: UntapdStrategy) -> None:
        response = client.strategy.with_raw_response.get_tickers(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = response.parse()
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_tickers(self, client: UntapdStrategy) -> None:
        with client.strategy.with_streaming_response.get_tickers(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = response.parse()
            assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_trading_days(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_trading_days_with_all_params(self, client: UntapdStrategy) -> None:
        strategy = client.strategy.get_trading_days(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_trading_days(self, client: UntapdStrategy) -> None:
        response = client.strategy.with_raw_response.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = response.parse()
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_trading_days(self, client: UntapdStrategy) -> None:
        with client.strategy.with_streaming_response.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = response.parse()
            assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncStrategy:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_data(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_data_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_data(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_data(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.with_raw_response.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = await response.parse()
        assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_data(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.with_streaming_response.get_data(
            strategy={"strategy_name": "poseidon"},
            ticker="SPY",
            trading_date=parse_date("2024-01-15"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = await response.parse()
            assert_matches_type(StrategyGetDataResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_leverage(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_leverage_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_leverage(
            max_leverage=3,
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_leverage(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.with_raw_response.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = await response.parse()
        assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_leverage(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.with_streaming_response.get_leverage(
            max_leverage=3,
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = await response.parse()
            assert_matches_type(StrategyGetLeverageResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_name(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_name(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_name_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_name(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_name(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.with_raw_response.get_name(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = await response.parse()
        assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_name(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.with_streaming_response.get_name(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = await response.parse()
            assert_matches_type(StrategyGetNameResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_tickers(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_tickers(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_tickers_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_tickers(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_tickers(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.with_raw_response.get_tickers(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = await response.parse()
        assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_tickers(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.with_streaming_response.get_tickers(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = await response.parse()
            assert_matches_type(StrategyGetTickersResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_trading_days(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_trading_days_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        strategy = await async_client.strategy.get_trading_days(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
        )
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_trading_days(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.with_raw_response.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        strategy = await response.parse()
        assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_trading_days(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.with_streaming_response.get_trading_days(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            strategy = await response.parse()
            assert_matches_type(StrategyGetTradingDaysResponse, strategy, path=["response"])

        assert cast(Any, response.is_closed) is True
