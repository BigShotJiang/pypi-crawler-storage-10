# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from untapd_strategy import UntapdStrategy, AsyncUntapdStrategy
from untapd_strategy._utils import parse_date
from untapd_strategy.types.strategy import (
    SignalGetExitSignalsResponse,
    SignalGetEntrySignalsResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSignals:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_entry_signals(self, client: UntapdStrategy) -> None:
        signal = client.strategy.signals.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_entry_signals_with_all_params(self, client: UntapdStrategy) -> None:
        signal = client.strategy.signals.get_entry_signals(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            effective_date=parse_date("2024-01-15"),
            effective_time="18:11:19.117Z",
        )
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_entry_signals(self, client: UntapdStrategy) -> None:
        response = client.strategy.signals.with_raw_response.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        signal = response.parse()
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_entry_signals(self, client: UntapdStrategy) -> None:
        with client.strategy.signals.with_streaming_response.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            signal = response.parse()
            assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_exit_signals(self, client: UntapdStrategy) -> None:
        signal = client.strategy.signals.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_exit_signals_with_all_params(self, client: UntapdStrategy) -> None:
        signal = client.strategy.signals.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            effective_date=parse_date("2024-01-15"),
            effective_time="15:30:00",
        )
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_exit_signals(self, client: UntapdStrategy) -> None:
        response = client.strategy.signals.with_raw_response.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        signal = response.parse()
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_exit_signals(self, client: UntapdStrategy) -> None:
        with client.strategy.signals.with_streaming_response.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            signal = response.parse()
            assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSignals:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_entry_signals(self, async_client: AsyncUntapdStrategy) -> None:
        signal = await async_client.strategy.signals.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_entry_signals_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        signal = await async_client.strategy.signals.get_entry_signals(
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            effective_date=parse_date("2024-01-15"),
            effective_time="18:11:19.117Z",
        )
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_entry_signals(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.signals.with_raw_response.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        signal = await response.parse()
        assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_entry_signals(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.signals.with_streaming_response.get_entry_signals(
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            signal = await response.parse()
            assert_matches_type(SignalGetEntrySignalsResponse, signal, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_exit_signals(self, async_client: AsyncUntapdStrategy) -> None:
        signal = await async_client.strategy.signals.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        )
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_exit_signals_with_all_params(self, async_client: AsyncUntapdStrategy) -> None:
        signal = await async_client.strategy.signals.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={
                "strategy_name": "poseidon",
                "config": {
                    "end_date": "bar",
                    "silent": "bar",
                    "start_date": "bar",
                    "tickers": "bar",
                },
            },
            effective_date=parse_date("2024-01-15"),
            effective_time="15:30:00",
        )
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_exit_signals(self, async_client: AsyncUntapdStrategy) -> None:
        response = await async_client.strategy.signals.with_raw_response.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        signal = await response.parse()
        assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_exit_signals(self, async_client: AsyncUntapdStrategy) -> None:
        async with async_client.strategy.signals.with_streaming_response.get_exit_signals(
            portfolio=[
                {
                    "qty": 100,
                    "side": "LONG",
                    "ticker": "SPY",
                }
            ],
            strategy={"strategy_name": "poseidon"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            signal = await response.parse()
            assert_matches_type(SignalGetExitSignalsResponse, signal, path=["response"])

        assert cast(Any, response.is_closed) is True
