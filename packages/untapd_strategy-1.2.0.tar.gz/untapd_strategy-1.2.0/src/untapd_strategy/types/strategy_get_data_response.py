# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List

from .._models import BaseModel

__all__ = ["StrategyGetDataResponse"]


class StrategyGetDataResponse(BaseModel):
    data: List[Dict[str, object]]
