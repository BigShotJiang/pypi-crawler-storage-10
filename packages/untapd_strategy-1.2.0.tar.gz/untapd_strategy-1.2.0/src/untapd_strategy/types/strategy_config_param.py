# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, TypedDict

__all__ = ["StrategyConfigParam"]


class StrategyConfigParam(TypedDict, total=False):
    strategy_name: Required[str]
    """Name of the strategy class (e.g., 'PoseidonStrategy' or 'poseidon')"""

    config: Dict[str, object]
    """Strategy initialization parameters"""
