# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from .side import Side
from ..._utils import PropertyInfo
from ..strategy_config_param import StrategyConfigParam

__all__ = ["SignalGetExitSignalsParams", "Portfolio"]


class SignalGetExitSignalsParams(TypedDict, total=False):
    portfolio: Required[Iterable[Portfolio]]

    strategy: Required[StrategyConfigParam]
    """Strategy configuration for instantiating a strategy"""

    effective_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Filter by date"""

    effective_time: Optional[str]
    """Filter by time"""


class Portfolio(TypedDict, total=False):
    qty: Required[float]
    """Quantity of shares"""

    side: Required[Side]
    """Position direction"""

    ticker: Required[str]
    """Ticker symbol"""
