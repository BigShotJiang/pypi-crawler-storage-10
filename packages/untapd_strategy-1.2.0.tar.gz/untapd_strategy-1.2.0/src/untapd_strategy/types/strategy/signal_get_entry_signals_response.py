# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import datetime
from typing import List, Optional

from .side import Side
from ..._models import BaseModel

__all__ = ["SignalGetEntrySignalsResponse", "Signal"]


class Signal(BaseModel):
    date: datetime.date
    """Date of the signal"""

    index: int
    """Index in the dataframe where signal occurred"""

    price: float
    """Price at signal time"""

    side: Side
    """Trading direction"""

    ticker: str
    """Ticker symbol"""

    time: str
    """Time of the signal"""

    condition: Optional[str] = None
    """Condition that triggered the signal"""

    noise_spread: Optional[float] = None
    """Noise spread factor"""


class SignalGetEntrySignalsResponse(BaseModel):
    signals: List[Signal]
