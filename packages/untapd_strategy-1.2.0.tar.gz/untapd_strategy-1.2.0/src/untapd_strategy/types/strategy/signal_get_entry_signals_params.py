# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo
from ..strategy_config_param import StrategyConfigParam

__all__ = ["SignalGetEntrySignalsParams"]


class SignalGetEntrySignalsParams(TypedDict, total=False):
    strategy: Required[StrategyConfigParam]
    """Strategy configuration for instantiating a strategy"""

    effective_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Filter by date"""

    effective_time: Optional[str]
    """Filter by time"""
