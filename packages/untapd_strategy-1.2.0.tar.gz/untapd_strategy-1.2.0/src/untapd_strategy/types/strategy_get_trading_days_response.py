# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import date

from .._models import BaseModel

__all__ = ["StrategyGetTradingDaysResponse"]


class StrategyGetTradingDaysResponse(BaseModel):
    trading_days: List[date]
