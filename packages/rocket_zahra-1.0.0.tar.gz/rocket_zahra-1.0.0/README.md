
# package_name

rocket is a Python library for dealing with rockets and their properties.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket`.

```bash
pip install rocket
```

```bash
pip install package_name
```

## Usage

```python
import rocket

# returns 'words'
rocket.module_name('word')

# returns 'geese'
rocket.module_name('goose')

# returns 'phenomenon'
rocket.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)