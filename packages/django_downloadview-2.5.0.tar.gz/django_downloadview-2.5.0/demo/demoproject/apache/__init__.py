"""Apache optimizations."""
