"""Nginx optimizations."""
