# This package is controlled by dongle license manager.

vendor_name = "led-inc.eu"
build_name = "dongle-build-dev"
app_name = "dongle-build"
app_key = b"""
-----BEGIN PUBLIC KEY-----
MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEF6Ewv3VSSutqNfJEAAei8Ib4dQgJwVhb
etVrsVJREthkNY85mFsE8LWrTV9kFfSpe9k0bJlx2liezyaUM7gMxh3wavJ/oMHR
MiX4x6yf7CqFO3nAHFsPrIDZOo1DAL05
-----END PUBLIC KEY-----

"""

hooks = [
    {'scope': 'api', 'use': 'dongle.optional'},
    {'scope': 'dongle', 'use': 'dongle.runtime', 'encrypted': ['dongle_build']},
]

__signature__ = "MGUCMQCLMAI8VwKFKStJ7RzNj5/+T7uSdoN4fwS64vEIBEsnsM3bUT6On1h1TkmvEDYo658CMDF5eSW0T7Yi8TSA4FqAGuKzWO8BtUSANhGRwKWE9H9mVQnxJW/TPPhcMuQn+YytcA=="
