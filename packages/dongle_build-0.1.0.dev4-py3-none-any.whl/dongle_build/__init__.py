# This module is encrypted.
import dongle


try:
    dongle.init_from(__name__)
    """
-----BEGIN ENCRYPTED MODULE-----
Module: dongle_build.__init__
Build: 944225b6-9fa7e4d7-c31e1d57
Nonce: bfChxEb9LIhzBeAJ

72bxoz5FctXqp+eHH64g/eh4bWtiorK4hvPhcvXPsN/6TZGksos0gpG/I+A03CLGS3BCO81SF+FWNZs4HRxtuPw03R9tdVTL3aOPbEfdtHqvIY6nJJV7PVp5w13qJNQmLmvcwm7Q2Zv7ZAFmggbm5GvUH625cLAUR7NzQxJxkzxcuKIFN8B1guBWhxiZiAtkGPRqC9o9FdV5VpDk3C3ep2XVqxUxuT1M3S6dORw=
-----END ENCRYPTED MODULE-----
    """

except dongle.DongleReady as e:
    e.reload()
