import os
import logging

class FileUtils:
    @staticmethod
    def cleanup_old_images(directory, max_files=500):
        """清理目录中的旧图片"""
        try:
            if not os.path.exists(directory):
                return 0
                
            files = [os.path.join(directory, f) for f in os.listdir(directory) 
                    if os.path.isfile(os.path.join(directory, f))]
            
            if len(files) > max_files:
                files.sort(key=os.path.getmtime)
                files_to_delete = len(files) - max_files
                
                for i in range(files_to_delete):
                    os.remove(files[i])
                    logging.info(f"🗑️ 删除旧文件: {os.path.basename(files[i])}")
                
                logging.info(f"🗑️ 已清理 {files_to_delete} 个文件，当前目录 {directory} 剩余 {max_files} 个文件")
                return files_to_delete
            
            return 0
        except Exception as e:
            logging.error(f"❌ 清理目录 {directory} 时发生错误: {e}")
            return 0