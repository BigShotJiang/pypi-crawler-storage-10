import torch
import logging

class DeviceUtils:
    @staticmethod
    def show_device_info():
        """显示设备信息"""
        logging.info("🔍 系统设备信息:")
        logging.info(f"  PyTorch版本: {torch.__version__}")
        logging.info(f"  CUDA可用: {torch.cuda.is_available()}")
        
        if torch.cuda.is_available():
            logging.info(f"  CUDA版本: {torch.version.cuda}")
            logging.info(f"  GPU数量: {torch.cuda.device_count()}")
            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                logging.info(f"  GPU {i}: {props.name}")
                logging.info(f"      内存: {props.total_memory / 1024**3:.1f} GB")
        else:
            if torch.backends.mkl.is_available():
                logging.info("  CPU模式: 使用Intel MKL后端")
            else:
                logging.info("  CPU模式: 标准后端")