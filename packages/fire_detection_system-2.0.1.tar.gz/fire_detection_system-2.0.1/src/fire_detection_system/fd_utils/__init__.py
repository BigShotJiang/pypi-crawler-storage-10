"""
火焰检测系统工具模块
"""

from .file_utils import FileUtils
from .device_utils import DeviceUtils

__all__ = ['FileUtils', 'DeviceUtils']
__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'

class UtilsModule:
    """工具模块主类"""
    
    @staticmethod
    def get_module_info():
        """获取模块信息"""
        return {
            'name': '工具函数模块',
            'version': __version__,
            'description': '提供文件管理、设备检测、图像处理等通用工具函数',
            'author': __author__,
            'exports': __all__
        }
    
    @staticmethod
    def get_available_utils():
        """获取可用的工具类"""
        return {
            'FileUtils': {
                'description': '文件管理工具',
                'functions': ['cleanup_old_images', 'create_directories', 'backup_files']
            },
            'DeviceUtils': {
                'description': '设备检测工具', 
                'functions': ['show_device_info', 'check_gpu_available', 'get_memory_usage']
            },
            'ImageUtils': {
                'description': '图像处理工具',
                'functions': ['resize_frame', 'draw_detections', 'apply_roi_mask']
            },
            'TimeUtils': {
                'description': '时间处理工具',
                'functions': ['get_timestamp', 'format_duration', 'calculate_interval']
            }
        }
    
    @staticmethod
    def get_system_requirements():
        """获取系统要求"""
        return {
            'python': '>=3.8',
            'opencv-python': '>=4.5.0',
            'torch': '>=1.9.0',
            'numpy': '>=1.21.0',
            'requests': '>=2.25.0',
            'psutil': '>=5.8.0'
        }
    
    @staticmethod
    def get_directory_structure():
        """获取目录结构"""
        return {
            'ready_images': '原始图像保存目录',
            'detected_images': '检测结果图像目录',
            'alarm_images': '报警图像目录（带标注）',
            'alarm_clean_images': '报警图像目录（无标注）',
            'logs': '系统日志目录',
            'models': '模型文件目录'
        }

# 模块初始化信息
MODULE_INFO = UtilsModule.get_module_info()
AVAILABLE_UTILS = UtilsModule.get_available_utils()
SYSTEM_REQUIREMENTS = UtilsModule.get_system_requirements()
DIRECTORY_STRUCTURE = UtilsModule.get_directory_structure()

# 依赖检查
try:
    import cv2
    import torch
    import numpy as np
    import requests
    import psutil
    DEPENDENCIES_LOADED = True
    DEPENDENCY_VERSIONS = {
        'opencv': cv2.__version__,
        'torch': torch.__version__,
        'numpy': np.__version__,
        'requests': requests.__version__,
        'psutil': psutil.__version__
    }
except ImportError as e:
    DEPENDENCIES_LOADED = False
    DEPENDENCY_VERSIONS = {}
    print(f"⚠️ 警告: 依赖库加载失败: {e}")

# 工具函数常量
FILE_MANAGEMENT = {
    'MAX_FILES_PER_DIRECTORY': 500,
    'CLEANUP_INTERVAL': 300,
    'BACKUP_RETENTION_DAYS': 7
}

DEVICE_INFO = {
    'AUTO_DEVICE': 'auto',
    'CPU_DEVICE': 'cpu', 
    'GPU_DEVICE': 'cuda'
}