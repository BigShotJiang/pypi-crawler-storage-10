"""
火焰检测系统
基于YOLO的实时火焰检测和报警系统
"""

__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'
__description__ = '基于YOLO的实时火焰检测和报警系统'
__license__ = 'MIT'

class FireDetectionSystem:
    """火焰检测系统主类"""
    
    def __init__(self):
        self.version = __version__
        self.author = __author__
        self.description = __description__
    
    @staticmethod
    def get_system_info():
        """获取系统信息"""
        return {
            'name': '火焰检测系统',
            'version': __version__,
            'author': __author__,
            'description': __description__,
            'license': __license__,
            'modules': {
                'config': '配置管理',
                'camera': '摄像头管理', 
                'detection': '火焰检测',
                'alert': '警报管理',
                'utils': '工具函数'
            }
        }
    
    @staticmethod
    def get_usage_examples():
        """获取使用示例"""
        return {
            'basic': 'python main.py',
            'specify_camera': 'python main.py --camera camera_1',
            'specify_config': 'python main.py --config config.json',
            'list_cameras': 'python main.py --list-cameras',
            'disable_api': 'python main.py --disable-api-check',
            'specify_device': 'python main.py --device cuda'
        }
    
    @staticmethod
    def get_system_features():
        """获取系统特性"""
        return {
            'multi_camera': '支持多摄像头同时监控',
            'real_time_detection': '实时火焰检测',
            'wechat_alerts': '企业微信报警通知',
            'api_integration': 'API点位状态检查',
            'roi_support': 'ROI区域检测',
            'auto_cleanup': '自动文件清理',
            'reconnect_mechanism': '自动重连机制',
            'gpu_acceleration': 'GPU加速推理'
        }
    
    @staticmethod
    def check_environment():
        """检查运行环境"""
        import sys
        import platform
        
        env_info = {
            'python_version': sys.version,
            'platform': platform.platform(),
            'system': platform.system(),
            'processor': platform.processor(),
            'working_directory': sys.path[0]
        }
        
        # 检查关键依赖
        try:
            import cv2
            env_info['opencv_version'] = cv2.__version__
        except ImportError:
            env_info['opencv_version'] = '未安装'
            
        try:
            import torch
            env_info['pytorch_version'] = torch.__version__
            env_info['cuda_available'] = torch.cuda.is_available()
            if torch.cuda.is_available():
                env_info['gpu_count'] = torch.cuda.device_count()
                env_info['gpu_name'] = torch.cuda.get_device_name(0)
            else:
                env_info['gpu_count'] = 0
                env_info['gpu_name'] = '无GPU'
        except ImportError:
            env_info['pytorch_version'] = '未安装'
            env_info['cuda_available'] = False
            
        return env_info
    
    @staticmethod
    def get_default_config_path():
        """获取默认配置文件路径"""
        import os
        current_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(current_dir, 'config.json')

# 系统信息
SYSTEM_INFO = FireDetectionSystem.get_system_info()
USAGE_EXAMPLES = FireDetectionSystem.get_usage_examples()
SYSTEM_FEATURES = FireDetectionSystem.get_system_features()
ENVIRONMENT_INFO = FireDetectionSystem.check_environment()
DEFAULT_CONFIG_PATH = FireDetectionSystem.get_default_config_path()

# 导出主要类
__all__ = [
    'FireDetectionSystem', 
    'SYSTEM_INFO', 
    'USAGE_EXAMPLES', 
    'SYSTEM_FEATURES',
    'ENVIRONMENT_INFO',
    'DEFAULT_CONFIG_PATH'
]

# 启动信息
def print_startup_info():
    """打印启动信息"""
    print(f"🔥 {SYSTEM_INFO['name']} v{SYSTEM_INFO['version']}")
    print(f"📝 {SYSTEM_INFO['description']}")
    print(f"👤 作者: {SYSTEM_INFO['author']}")
    print(f"📄 许可证: {SYSTEM_INFO['license']}")
    print("\n🚀 使用示例:")
    for key, value in USAGE_EXAMPLES.items():
        print(f"  💡 {key}: {value}")
    print("\n✨ 系统特性:")
    for feature, description in SYSTEM_FEATURES.items():
        print(f"  ✅ {description}")
    print("\n🖥️  运行环境:")
    print(f"  Python版本: {ENVIRONMENT_INFO['python_version'].split()[0]}")
    print(f"  操作系统: {ENVIRONMENT_INFO['system']} {ENVIRONMENT_INFO['platform']}")
    print(f"  OpenCV版本: {ENVIRONMENT_INFO.get('opencv_version', '未知')}")
    print(f"  PyTorch版本: {ENVIRONMENT_INFO.get('pytorch_version', '未知')}")
    print(f"  CUDA可用: {ENVIRONMENT_INFO.get('cuda_available', False)}")
    if ENVIRONMENT_INFO.get('cuda_available'):
        print(f"  GPU数量: {ENVIRONMENT_INFO.get('gpu_count', 0)}")
        print(f"  GPU名称: {ENVIRONMENT_INFO.get('gpu_name', '未知')}")

# 当直接运行此文件时打印启动信息
if __name__ == "__main__":
    print_startup_info()