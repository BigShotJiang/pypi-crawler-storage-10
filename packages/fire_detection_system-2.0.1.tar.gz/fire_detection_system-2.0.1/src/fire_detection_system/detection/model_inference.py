import os  # 添加这行
import torch
import cv2
import numpy as np
import logging

class ModelInference:
    def __init__(self, config, camera_name):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.camera_name = camera_name
        self.camera_config = config['cameras'][camera_name]
        self.model_config = config['model_config']
        
        self.model = None
        self.device = None
    
    def initialize_model(self):
        """初始化模型"""
        try:
            model_path = self.camera_config["model_path"]
            
            # 检查模型文件是否存在
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"模型文件不存在: {model_path}")
            
            # 设备选择
            self.device = self.select_device()
            
            # 加载模型
            self.model = torch.hub.load(
                'C:/Users/Administrator/Desktop/my_python_project/venv/yolov5', 
                'custom', path=model_path, source='local'
            )
            
            # 将模型移动到指定设备
            self.model = self.model.to(self.device)
            
            # 应用模型配置
            self.model.conf = self.model_config["confidence_threshold"]
            self.model.iou = self.model_config["iou_threshold"]
            self.model.max_det = self.model_config["max_detections"]
            self.model.imgsz = self.model_config["image_size"]
            self.model.eval()
            
            # GPU内存优化
            if self.device == 'cuda':
                torch.cuda.empty_cache()
            
            self.logger.info(f"摄像头模型加载完成: {model_path}")
            self.logger.info(f"使用设备: {self.device}")
            if self.device == 'cuda':
                self.logger.info(f"GPU名称: {torch.cuda.get_device_name(0)}")
            
        except Exception as e:
            self.logger.error(f"模型加载失败: {e}")
            raise
    
    def select_device(self):
        """选择设备"""
        device_config = self.model_config.get("device", "auto")
        
        if device_config == "auto":
            if torch.cuda.is_available():
                device = 'cuda'
                self.logger.info("检测到CUDA，使用GPU进行推理")
            else:
                device = 'cpu'
                self.logger.info("未检测到CUDA，使用CPU进行推理")
        elif device_config == "cuda":
            if torch.cuda.is_available():
                device = 'cuda'
                self.logger.info("使用GPU进行推理")
            else:
                device = 'cpu'
                self.logger.warning("配置要求GPU但CUDA不可用，回退到CPU")
        else:
            device = 'cpu'
            self.logger.info("使用CPU进行推理")
        
        return device
    
    def detect(self, frame):
        """执行检测"""
        # 转换颜色空间
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # 推理
        results = self.model(rgb_frame)
        detections = results.xyxy[0]
        
        fire_count = len(detections)
        
        return detections, fire_count
    
    def draw_detections_realtime(self, frame, detections, roi_mask=None):
        """绘制实时检测结果"""
        result_frame = frame.copy()
        confidence_threshold = self.model_config["confidence_threshold"]
        
        # 绘制ROI区域
        if roi_mask is not None:
            contours, _ = cv2.findContours(roi_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(result_frame, contours, -1, (0, 255, 0), 2)
            cv2.putText(result_frame, "ROI Area", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # 绘制检测框
        for det in detections:
            x1, y1, x2, y2, conf, cls = det.tolist()
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            
            if conf < confidence_threshold:
                color = (0, 0, 255)  # 红色 - 低置信度
                label_color = (255, 255, 255)
            else:
                color = (255, 0, 0)  # 蓝色 - 高置信度
                label_color = (255, 255, 255)
            
            line_width = 3
            cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, line_width)
            
            label = f"Fire {conf:.2f}"
            font_scale = 0.9
            thickness = 2
            (text_width, text_height), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness
            )
            
            bg_height = text_height + baseline + 8
            cv2.rectangle(result_frame, 
                         (x1, y1 - bg_height), 
                         (x1 + text_width, y1), 
                         color, -1)
            
            cv2.putText(result_frame, label, 
                       (x1, y1 - baseline - 4), 
                       cv2.FONT_HERSHEY_SIMPLEX, font_scale, label_color, thickness)
        
        return result_frame
    
    def draw_detections_for_save(self, frame, detections, roi_mask=None):
        """绘制用于保存的检测结果（蓝色框，白色字体）"""
        result_frame = frame.copy()
        confidence_threshold = self.model_config["confidence_threshold"]
        
        if roi_mask is not None:
            roi_visual = np.zeros_like(result_frame)
            roi_visual[roi_mask == 255] = [0, 255, 0]
            cv2.addWeighted(roi_visual, 0.1, result_frame, 1, 0, result_frame)
        
        for det in detections:
            x1, y1, x2, y2, conf, cls = det.tolist()
            
            if conf < confidence_threshold:
                continue
                
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            color = (255, 0, 0)  # 蓝色
            label_color = (255, 255, 255)  # 白色
            
            line_width = 2
            cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, line_width)
            
            label = f"Fire {conf:.2f}"
            font_scale = 0.7
            thickness = 2
            (text_width, text_height), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness
            )
            
            cv2.rectangle(result_frame, 
                         (x1, y1 - text_height - baseline - 5), 
                         (x1 + text_width, y1), 
                         color, -1)
            
            cv2.putText(result_frame, label, 
                       (x1, y1 - baseline - 3), 
                       cv2.FONT_HERSHEY_SIMPLEX, font_scale, label_color, thickness)
        
        return result_frame
    
    def add_status_info(self, frame, fire_count, expected_count, continuous_abnormal_time,
                       camera_name, roi_enabled, point_status):
        """添加状态信息到帧"""
        result_frame = frame.copy()
        frame_width = result_frame.shape[1]
        
        # 火焰数量
        status_text = f"Fires: {fire_count}"
        (text_width, text_height), baseline = cv2.getTextSize(
            status_text, cv2.FONT_HERSHEY_SIMPLEX, 1.2, 3
        )
        cv2.putText(result_frame, status_text, 
                   (frame_width - text_width - 10, 35), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 3)
        
        # 状态指示
        status = "NORMAL" if fire_count == expected_count else "ALERT"
        status_color = (0, 255, 0) if fire_count == expected_count else (0, 0, 255)
        (text_width, text_height), baseline = cv2.getTextSize(
            status, cv2.FONT_HERSHEY_SIMPLEX, 1.2, 3
        )
        cv2.putText(result_frame, status, 
                   (frame_width - text_width - 10, 75), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, status_color, 3)
        
        # 置信度阈值
        confidence_threshold = self.model_config["confidence_threshold"]
        threshold_text = f"Confidence: {confidence_threshold}"
        (text_width, text_height), baseline = cv2.getTextSize(
            threshold_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, threshold_text, 
                   (frame_width - text_width - 10, 115), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)
        
        # 摄像头名称
        camera_text = f"Camera: {camera_name}"
        (text_width, text_height), baseline = cv2.getTextSize(
            camera_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, camera_text, 
                   (frame_width - text_width - 10, 150), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        
        # ROI状态
        roi_status = "ON" if roi_enabled else "OFF"
        roi_color = (0, 255, 0) if roi_enabled else (0, 0, 255)
        roi_text = f"ROI: {roi_status}"
        (text_width, text_height), baseline = cv2.getTextSize(
            roi_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, roi_text, 
                   (frame_width - text_width - 10, 185), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, roi_color, 2)
        
        # API状态
        if point_status is not None:
            api_status = "API: ON" if point_status else "API: OFF"
            api_color = (0, 255, 0) if point_status else (0, 0, 255)
            (text_width, text_height), baseline = cv2.getTextSize(
                api_status, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
            )
            cv2.putText(result_frame, api_status, 
                       (frame_width - text_width - 10, 220), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, api_color, 2)
        
        # 持续异常时间
        if continuous_abnormal_time > 0:
            time_text = f"Abnormal: {continuous_abnormal_time:.1f}s"
            (text_width, text_height), baseline = cv2.getTextSize(
                time_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
            )
            cv2.putText(result_frame, time_text, 
                       (frame_width - text_width - 10, 255), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        
        # 期望火焰数量
        expected_text = f"Expected: {expected_count}"
        (text_width, text_height), baseline = cv2.getTextSize(
            expected_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, expected_text, 
                   (frame_width - text_width - 10, 290), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        
        # 颜色说明
        blue_text = "Blue: High Confidence"
        red_text = "Red: Low Confidence"
        (text_width, text_height), baseline = cv2.getTextSize(
            blue_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, blue_text, 
                   (frame_width - text_width - 10, 325), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
        (text_width, text_height), baseline = cv2.getTextSize(
            red_text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2
        )
        cv2.putText(result_frame, red_text, 
                   (frame_width - text_width - 10, 350), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        
        return result_frame