"""
火焰检测模块
负责模型推理、目标检测和ROI区域管理
"""

from .model_inference import ModelInference
from .roi_manager import ROIManager

__all__ = ['ModelInference', 'ROIManager']
__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'

class DetectionModule:
    """检测模块主类"""
    
    @staticmethod
    def get_module_info():
        """获取模块信息"""
        return {
            'name': '火焰检测模块',
            'version': __version__,
            'description': '负责YOLO模型推理、火焰检测、ROI区域管理和检测结果可视化',
            'author': __author__,
            'exports': __all__
        }
    
    @staticmethod
    def get_supported_models():
        """获取支持的模型类型"""
        return {
            'yolov5': 'YOLOv5目标检测模型',
            'yolov8': 'YOLOv8目标检测模型',
            'custom': '自定义训练模型'
        }
    
    @staticmethod
    def get_detection_classes():
        """获取检测类别"""
        return {
            0: 'fire',
            1: 'smoke',
            # 可根据实际模型输出添加更多类别
        }
    
    @staticmethod
    def get_default_parameters():
        """获取默认参数"""
        return {
            'confidence_threshold': 0.55,  # 根据配置文件调整为0.55
            'iou_threshold': 0.5,
            'max_detections': 10,
            'image_size': 640,
            'device': 'auto'
        }
    
    @staticmethod
    def get_color_schemes():
        """获取颜色方案"""
        return {
            'realtime': {
                'high_confidence': (255, 0, 0),    # 蓝色 - 高置信度
                'low_confidence': (0, 0, 255),     # 红色 - 低置信度
                'text_color': (255, 255, 255),     # 白色文字
                'roi_color': (0, 255, 0)           # 绿色 - ROI区域
            },
            'save': {
                'detection_box': (255, 0, 0),      # 蓝色检测框
                'text_color': (255, 255, 255),     # 白色文字
                'roi_color': (0, 255, 0)           # 绿色 - ROI区域
            }
        }

# 模块初始化信息
MODULE_INFO = DetectionModule.get_module_info()
SUPPORTED_MODELS = DetectionModule.get_supported_models()
DETECTION_CLASSES = DetectionModule.get_detection_classes()
DEFAULT_PARAMETERS = DetectionModule.get_default_parameters()
COLOR_SCHEMES = DetectionModule.get_color_schemes()

# 检测状态常量
DETECTION_STATUS = {
    'NORMAL': 'normal',
    'ALERT': 'alert',
    'NO_DETECTION': 'no_detection',
    'ERROR': 'error'
}

# ROI配置常量
ROI_CONFIG = {
    'ENABLED': True,
    'DEFAULT_REGIONS': [[0.0, 0.0, 1.0, 1.0]]  # 全图区域
}