import numpy as np
import cv2
import logging
import torch


class ROIManager:
    def __init__(self, config, camera_name):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.camera_name = camera_name
        self.camera_config = config['cameras'][camera_name]
        self.roi_config = config['roi_config']
        
        self.mask = None
        self.enabled = self.roi_config["enabled"]
        self.regions = self.camera_config.get("roi_regions", self.roi_config.get("regions", []))
    
    def initialize_roi(self, frame_shape):
        """初始化ROI掩码"""
        if self.enabled and frame_shape is not None:
            self.mask = self.create_roi_mask(frame_shape, self.regions)
            self.logger.info(f"✅ ROI掩码已初始化，区域数量: {len(self.regions)}")
    
    def create_roi_mask(self, frame_shape, regions):
        """创建ROI掩码"""
        height, width = frame_shape[:2]
        mask = np.zeros((height, width), dtype=np.uint8)
        
        for region in regions:
            x1 = int(region[0] * width)
            y1 = int(region[1] * height)
            x2 = int(region[2] * width)
            y2 = int(region[3] * height)
            cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)
        
        return mask
    
    def apply_roi(self, frame):
        """应用ROI掩码到帧上"""
        if self.mask is not None:
            roi_frame = frame.copy()
            roi_frame[self.mask == 0] = 0
            return roi_frame
        return frame
    
    def filter_detections_by_roi(self, detections):
        """根据ROI区域过滤检测结果"""
        if len(detections) == 0 or self.mask is None:
            return detections
        
        filtered_detections = []
        
        for det in detections:
            x1, y1, x2, y2, conf, cls = det.tolist()
            center_x = int((x1 + x2) / 2)
            center_y = int((y1 + y2) / 2)
            
            if self.mask[center_y, center_x] == 255:
                filtered_detections.append(det)
        
        return torch.stack(filtered_detections) if filtered_detections else detections.new_empty(0)
    
    def get_mask(self):
        """获取ROI掩码"""
        return self.mask
    
    def is_enabled(self):
        """检查ROI是否启用"""
        return self.enabled