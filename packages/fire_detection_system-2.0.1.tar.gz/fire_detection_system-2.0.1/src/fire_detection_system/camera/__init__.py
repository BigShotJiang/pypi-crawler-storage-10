"""
摄像头管理模块
负责RTSP连接、视频流捕获和显示管理
"""

from .camera_manager import CameraManager

__all__ = ['CameraManager']
__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'

class CameraModule:
    """摄像头模块主类"""
    
    @staticmethod
    def get_module_info():
        """获取模块信息"""
        return {
            'name': '摄像头管理模块',
            'version': __version__,
            'description': '负责RTSP连接管理、视频流捕获、重连机制和显示窗口管理',
            'author': __author__,
            'exports': __all__
        }
    
    @staticmethod
    def get_supported_formats():
        """获取支持的视频格式"""
        return {
            'rtsp': 'RTSP流媒体协议',
            'http': 'HTTP流媒体',
            'file': '本地视频文件',
            'usb': 'USB摄像头'
        }
    
    @staticmethod
    def get_optimization_settings():
        """获取优化设置"""
        return {
            'buffer_size': 1,
            'fps': 15,
            'codec': 'H264',
            'reconnect_attempts': 5,
            'reconnect_delay': 3,
            'window_width': 1280,
            'window_height': 720
        }
    
    @staticmethod
    def get_rtsp_url_template():
        """获取RTSP URL模板"""
        return {
            'default': 'rtsp://{username}:{password}@{ip}:{port}/Streaming/Channels/{channel}',
            'backup1': 'rtsp://{username}:{password}@{ip}:554/Streaming/Channels/{channel}01',
            'backup2': 'rtsp://{username}:{password}@{ip}:554/cam/realmonitor?channel=1&subtype=0',
            'backup3': 'rtsp://{username}:{password}@{ip}:554/11'
        }

# 模块初始化信息
MODULE_INFO = CameraModule.get_module_info()
SUPPORTED_FORMATS = CameraModule.get_supported_formats()
OPTIMIZATION_SETTINGS = CameraModule.get_optimization_settings()
RTSP_TEMPLATES = CameraModule.get_rtsp_url_template()

# 摄像头状态常量
CAMERA_STATUS = {
    'CONNECTED': 'connected',
    'DISCONNECTED': 'disconnected',
    'RECONNECTING': 'reconnecting',
    'ERROR': 'error'
}

# 显示模式常量
DISPLAY_MODES = {
    'NORMAL': 'normal',
    'DETECTION_DISABLED': 'detection_disabled',
    'FULLSCREEN': 'fullscreen'
}