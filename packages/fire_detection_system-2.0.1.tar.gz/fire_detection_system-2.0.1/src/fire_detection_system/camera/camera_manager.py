import cv2
import time
import logging
import numpy as np

class CameraManager:
    def __init__(self, config, camera_name):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.camera_name = camera_name
        self.camera_config = config['cameras'][camera_name]
        self.display_config = config['display_config']
        
        self.cap = None
        self.rtsp_url = None
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        self.reconnect_delay = 3
        self.window_name = f"RTSP Stream - {camera_name}"
    
    def initialize_camera(self):
        """初始化摄像头连接"""
        self.logger.info("🔄 初始化RTSP连接...")
        
        # 构建RTSP URL
        cam_config = self.camera_config
        self.rtsp_url = (
            f'rtsp://{cam_config["username"]}:{cam_config["password"]}'
            f'@{cam_config["ip"]}:{cam_config["port"]}/'
            f'Streaming/Channels/{cam_config["channel"]}'
        )
        
        self.cap = self.create_video_capture(self.rtsp_url)
        
        # 连接测试
        if not self.test_connection():
            self.try_backup_urls()
        
        # 创建显示窗口
        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.window_name, 
                        self.display_config["window_width"], 
                        self.display_config["window_height"])
    
    def create_video_capture(self, url):
        """创建优化的视频捕获对象"""
        cap = cv2.VideoCapture(url)
        
        # 设置RTSP参数优化
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        cap.set(cv2.CAP_PROP_FPS, 15)
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'H264'))
        
        # 尝试设置其他优化参数
        try:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        except:
            pass
        
        return cap
    
    def test_connection(self):
        """测试连接"""
        ret, frame = self.cap.read()
        if ret:
            self.logger.info("✅ RTSP连接测试成功")
            return True
        return False
    
    def try_backup_urls(self):
        """尝试备用URL"""
        cam_config = self.camera_config
        backup_urls = [
            f'rtsp://{cam_config["username"]}:{cam_config["password"]}@{cam_config["ip"]}:554/Streaming/Channels/{cam_config["channel"]}01',
            f'rtsp://{cam_config["username"]}:{cam_config["password"]}@{cam_config["ip"]}:554/cam/realmonitor?channel=1&subtype=0',
            f'rtsp://{cam_config["username"]}:{cam_config["password"]}@{cam_config["ip"]}:554/11'
        ]
        
        success = False
        for i, backup_url in enumerate(backup_urls, 1):
            self.logger.info(f"🔄 尝试备用URL {i}: {backup_url}")
            self.cap.release()
            self.cap = self.create_video_capture(backup_url)
            if self.test_connection():
                self.rtsp_url = backup_url
                success = True
                self.logger.info("✅ 备用URL连接成功")
                break
        
        if not success:
            raise ConnectionError("❌ 所有URL连接尝试失败，请检查摄像头配置")
    
    def read_frame(self):
        """读取帧"""
        ret, frame = self.cap.read()
        if not ret:
            self.reconnect_attempts += 1
            if self.reconnect_attempts > self.max_reconnect_attempts:
                self.logger.error("❌ 达到最大重连次数")
                return None
                
            self.logger.warning(f"❌ 无法读取帧，第 {self.reconnect_attempts}/{self.max_reconnect_attempts} 次重试中...")
            time.sleep(self.reconnect_delay)
            
            # 重新创建捕获对象
            self.cap.release()
            self.cap = self.create_video_capture(self.rtsp_url)
            return self.read_frame()
        else:
            self.reconnect_attempts = 0
            return frame
    
    def get_frame_shape(self):
        """获取帧形状"""
        ret, frame = self.cap.read()
        if ret:
            # 将帧放回捕获队列（模拟seek到前一帧）
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.cap.get(cv2.CAP_PROP_POS_FRAMES) - 1)
            return frame.shape
        return None
    
    def display_frame(self, frame):
        """显示帧"""
        resized_frame = self.resize_frame(frame, self.display_config["window_width"])
        cv2.imshow(self.window_name, resized_frame)
    
    def display_disabled_status(self, frame, point_status):
        """显示禁用状态"""
        display_frame = frame.copy()
        cv2.putText(display_frame, "DETECTION DISABLED", (50, 50), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
        cv2.putText(display_frame, f"Point Status: {point_status}", (50, 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(display_frame, "Press 'q' to exit", (50, 150), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        self.display_frame(display_frame)
    
    def resize_frame(self, frame, target_width=1280):
        """调整帧大小"""
        if frame is None:
            return None
            
        height, width = frame.shape[:2]
        
        if width <= target_width:
            return frame
        
        ratio = target_width / width
        new_height = int(height * ratio)
        resized_frame = cv2.resize(frame, (target_width, new_height), 
                                 interpolation=cv2.INTER_AREA)
        return resized_frame
    
    def check_exit(self):
        """检查退出条件"""
        if cv2.getWindowProperty(self.window_name, cv2.WND_PROP_VISIBLE) < 1:
            return True
            
        if cv2.waitKey(1) & 0xFF == ord('q'):
            return True
            
        return False
    
    def get_current_time(self):
        """获取当前时间"""
        return time.time()
    
    def cleanup(self):
        """清理资源"""
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        self.logger.info("📷 摄像头资源已释放")