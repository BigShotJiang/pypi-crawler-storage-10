import os
import json
import logging

class ConfigManager:
    def __init__(self, config_path):
        self.logger = logging.getLogger(__name__)
        self.config_path = config_path
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置文件"""
        try:
            if not os.path.exists(self.config_path):
                raise FileNotFoundError(f"配置文件不存在: {self.config_path}")
            
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            self.logger.info(f"配置文件加载成功: {self.config_path}")
            return config
        except Exception as e:
            self.logger.error(f"配置文件加载失败: {e}")
            raise
    
    def get_config(self):
        """获取配置"""
        return self.config
    
    def get_camera_config(self, camera_name):
        """获取指定摄像头的配置"""
        return self.config['cameras'].get(camera_name, {})
    
    def list_cameras(self):
        """列出所有可用的摄像头配置"""
        camera_names = list(self.config["cameras"].keys())
        print("可用的摄像头配置:")
        for i, name in enumerate(camera_names, 1):
            camera_info = self.config["cameras"][name]
            print(f"  {i}. {name} - {camera_info.get('comment', '')}")
            print(f"     模型: {camera_info.get('model_path', '未指定')}")
            print(f"     点位: {camera_info.get('pointCode', '未指定')}")
            print(f"     期望火焰数: {camera_info.get('expected_fire_count', '未指定')}")
            print()
    
    def select_camera(self, camera_name=None):
        """选择摄像头"""
        camera_names = list(self.config["cameras"].keys())
        
        if camera_name and camera_name in camera_names:
            selected_camera = camera_name
            camera_info = self.config["cameras"][selected_camera]
            print(f"使用指定摄像头: {selected_camera} - {camera_info.get('comment', '')}")
        else:
            print("可用的摄像头配置:")
            for i, name in enumerate(camera_names, 1):
                camera_info = self.config["cameras"][name]
                print(f"  {i}. {name} - {camera_info.get('comment', '')}")
            
            try:
                choice = int(input("请选择摄像头 (输入编号): ")) - 1
                if 0 <= choice < len(camera_names):
                    selected_camera = camera_names[choice]
                else:
                    selected_camera = camera_names[0]
                    print(f"输入无效，使用默认摄像头: {selected_camera}")
            except:
                selected_camera = camera_names[0]
                print(f"输入无效，使用默认摄像头: {selected_camera}")
        
        return selected_camera