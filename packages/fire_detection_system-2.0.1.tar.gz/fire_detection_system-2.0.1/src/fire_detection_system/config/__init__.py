"""
配置管理模块
负责加载和管理系统配置文件
"""

from .config_manager import ConfigManager

__all__ = ['ConfigManager']
__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'

class ConfigModule:
    """配置模块主类"""
    
    @staticmethod
    def get_module_info():
        """获取模块信息"""
        return {
            'name': '配置管理模块',
            'version': __version__,
            'description': '负责系统配置文件的加载、验证和管理',
            'author': __author__,
            'exports': __all__
        }
    
    @staticmethod
    def get_default_config():
        """获取默认配置结构"""
        return {
            'cameras': {
                'camera_1': {
                    'ip': '192.168.1.100',
                    'username': 'admin',
                    'password': 'password',
                    'port': 554,
                    'channel': 101,
                    'model_path': 'models/camera1.pt',
                    'roi_regions': [[0.0, 0.0, 1.0, 1.0]],
                    'expected_fire_count': 3,
                    'pointCode': 'point_code_001',
                    'comment': '摄像头描述'
                }
            },
            'api_config': {
                'base_url': 'http://api.example.com/endpoint',
                'check_interval': 5,
                'timeout': 10
            },
            'model_config': {
                'confidence_threshold': 0.55,
                'iou_threshold': 0.5,
                'max_detections': 10,
                'image_size': 640,
                'device': 'auto'
            },
            'wechat_config': {
                'webhook_url': 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=your_key',
                'alert_continuous_time': 20
            },
            'detection_config': {
                'save_interval': 2,
                'alert_cooldown': 30
            },
            'directory_config': {
                'images_dir': 'ready_images',
                'detected_dir': 'detected_images',
                'alarm_dir': 'alarm_images',
                'alarm_clean_dir': 'alarm_clean_images',
                'log_dir': 'logs'
            },
            'cleanup_config': {
                'max_files_per_directory': 500,
                'cleanup_interval': 300
            },
            'display_config': {
                'window_width': 1280,
                'window_height': 720,
                'status_print_interval': 10
            },
            'roi_config': {
                'enabled': True
            }
        }

# 模块初始化信息
MODULE_INFO = ConfigModule.get_module_info()
DEFAULT_CONFIG = ConfigModule.get_default_config()

# 模块版本检查
def check_module_compatibility():
    """检查模块兼容性"""
    return {
        'status': 'compatible',
        'version': __version__,
        'requirements': {
            'python': '>=3.8',
            'opencv-python': '>=4.5.0',
            'torch': '>=1.9.0'
        }
    }

COMPATIBILITY_INFO = check_module_compatibility()