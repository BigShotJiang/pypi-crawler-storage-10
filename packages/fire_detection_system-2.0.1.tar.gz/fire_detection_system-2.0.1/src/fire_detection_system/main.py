import torch
import os
import sys
import logging
import argparse
from datetime import datetime

# 添加项目根目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from config.config_manager import ConfigManager
from camera.camera_manager import CameraManager
from detection.model_inference import ModelInference
from detection.roi_manager import ROIManager
from alert.alert_manager import AlertManager
from fd_utils.device_utils import DeviceUtils

def setup_logging():
    """配置日志系统"""
    import logging
    import sys
    
    # 创建logs目录
    log_dir = 'logs'
    os.makedirs(log_dir, exist_ok=True)
    
    # 配置日志格式（避免Unicode字符）
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            # 控制台处理器
            logging.StreamHandler(sys.stdout),
            # 文件处理器，使用utf-8编码
            logging.FileHandler(os.path.join(log_dir, f'system_{datetime.now().strftime("%Y%m%d")}.log'), encoding='utf-8')
        ]
    )

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='火焰检测系统')
    parser.add_argument('--config', '-c', 
                       default='config.json',  # 修改为当前目录的config.json
                       help='配置文件路径 (默认: config.json)')
    parser.add_argument('--camera', 
                       help='指定摄像头配置名称')
    parser.add_argument('--list-cameras', action='store_true',
                       help='列出所有可用的摄像头配置')
    parser.add_argument('--disable-api-check', action='store_true',
                       help='禁用API点位检查，始终运行检测')
    parser.add_argument('--device', choices=['auto', 'cpu', 'cuda'],
                       help='强制使用指定设备 (auto/cpu/cuda)')
    return parser.parse_args()

def main():
    """主程序入口"""
    # 设置日志
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # 解析命令行参数
    args = parse_arguments()
    
    try:
        # 初始化配置管理器
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # 显示设备信息
        DeviceUtils.show_device_info()
        
        # 处理摄像头选择
        if args.list_cameras:
            config_manager.list_cameras()
            return
            
        selected_camera = config_manager.select_camera(args.camera)
        
        # 覆盖设备配置（如果命令行指定了设备）
        if args.device:
            config['model_config']['device'] = args.device
            logger.info(f"命令行指定设备: {args.device}")
        
        # 初始化各个管理器
        camera_manager = CameraManager(config, selected_camera)
        roi_manager = ROIManager(config, selected_camera)
        model_inference = ModelInference(config, selected_camera)
        alert_manager = AlertManager(config, selected_camera)
        
        # 启动摄像头和检测系统
        camera_manager.initialize_camera()
        roi_manager.initialize_roi(camera_manager.get_frame_shape())
        model_inference.initialize_model()
        alert_manager.initialize_directories()
        
        # 打印系统信息
        print_system_info(config, selected_camera, args)
        
        # 运行主循环
        run_main_loop(config, selected_camera, camera_manager, roi_manager, 
                     model_inference, alert_manager, args)
        
    except KeyboardInterrupt:
        logger.info("程序被用户中断")
    except Exception as e:
        logger.error(f"程序运行错误: {e}")
        raise
    finally:
        # 清理资源
        if 'camera_manager' in locals():
            camera_manager.cleanup()
        logger.info("程序退出")

def print_system_info(config, selected_camera, args):
    """打印系统信息"""
    camera_config = config['cameras'][selected_camera]
    model_config = config['model_config']
    
    print(f"当前摄像头: {selected_camera}")
    print(f"摄像头描述: {camera_config.get('comment', '无描述')}")
    print(f"摄像头IP: {camera_config['ip']}:{camera_config['port']}")
    print(f"使用模型: {camera_config['model_path']}")
    print(f"期望火焰数量: {camera_config.get('expected_fire_count', 3)}")
    print(f"ROI区域: {camera_config.get('roi_regions', [])}")
    print(f"点位控制: {camera_config.get('pointCode', '未指定')}")
    print(f"API检查: {'禁用' if args.disable_api_check else '启用'}")
    print(f"计算设备: {model_config.get('device', 'auto')}")
    print(f"置信度阈值: {model_config.get('confidence_threshold', 0.55)}")
    print("提示：可以拖动窗口边框调整大小，按 'q' 键退出")
    print("-" * 60)

def run_main_loop(config, selected_camera, camera_manager, roi_manager, 
                 model_inference, alert_manager, args):
    """运行主循环"""
    logger = logging.getLogger(__name__)
    
    # 主循环变量初始化
    last_save_time = 0
    last_alert_time = 0
    last_cleanup_time = 0
    last_status_print_time = 0
    last_api_check_time = 0
    
    # 状态跟踪变量
    last_fire_count = -1
    status_change_count = 0
    abnormal_start_time = 0
    continuous_abnormal_time = 0
    
    camera_config = config['cameras'][selected_camera]
    detection_config = config['detection_config']
    wechat_config = config['wechat_config']
    
    expected_count = camera_config.get('expected_fire_count', 3)
    
    print("开始火焰检测...")
    
    while True:
        # 读取帧
        frame = camera_manager.read_frame()
        if frame is None:
            continue
            
        current_time = camera_manager.get_current_time()
        
        # API点位状态检查
        point_status = alert_manager.check_point_status(current_time, last_api_check_time, args.disable_api_check)
        if point_status is not None:
            last_api_check_time = current_time
            
        # 如果点位为false，只显示视频流
        if not args.disable_api_check and camera_config.get('pointCode') and not point_status:
            camera_manager.display_disabled_status(frame, point_status)
            if camera_manager.check_exit():
                break
            continue
        
        # 以下代码只在点位为true或禁用API检查时执行
        
        # 定期清理
        if current_time - last_cleanup_time >= config['cleanup_config']['cleanup_interval']:
            alert_manager.cleanup_old_images()
            last_cleanup_time = current_time
        
        # 检测推理
        try:
            # 应用ROI
            roi_frame = roi_manager.apply_roi(frame) if roi_manager.is_enabled() else frame
            
            # 推理检测
            detections, fire_count = model_inference.detect(roi_frame)
            
            # 根据ROI过滤检测结果
            if roi_manager.is_enabled():
                detections = roi_manager.filter_detections_by_roi(detections)
                fire_count = len(detections)
            
            # 更新持续异常时间
            if fire_count != expected_count:
                if abnormal_start_time == 0:
                    abnormal_start_time = current_time
                    continuous_abnormal_time = 0
                else:
                    continuous_abnormal_time = current_time - abnormal_start_time
            else:
                abnormal_start_time = 0
                continuous_abnormal_time = 0
            
            # 绘制检测结果
            display_frame = model_inference.draw_detections_realtime(
                frame, detections, roi_manager.get_mask()
            )
            
            # 添加状态信息
            display_frame = model_inference.add_status_info(
                display_frame, fire_count, expected_count, continuous_abnormal_time,
                selected_camera, roi_manager.is_enabled(), point_status
            )
            
            # 状态变化检测和输出控制
            status_changed = (fire_count != last_fire_count)
            if status_changed:
                status_change_count += 1
                status = "NORMAL" if fire_count == expected_count else "ALERT"
                logger.info(f"状态变化: 火焰数量 {last_fire_count} -> {fire_count} - 状态: {status}")
                last_fire_count = fire_count
            
            # 定期状态输出
            if (current_time - last_status_print_time >= config['display_config']['status_print_interval'] and 
                not status_changed and fire_count == expected_count):
                logger.info(f"系统运行正常 - 火焰数量: {fire_count}")
                last_status_print_time = current_time
            
        except Exception as e:
            logger.error(f"推理错误: {e}")
            display_frame = frame
            fire_count = 0
            detections = []
        
        # 显示帧
        camera_manager.display_frame(display_frame)
        
        # 保存和警报检查
        if current_time - last_save_time >= detection_config['save_interval']:
            # 保存图像
            alert_manager.save_images(frame, detections, fire_count, 
                                    model_inference.draw_detections_for_save(
                                        frame, detections, roi_manager.get_mask()
                                    ))
            
            # 检查是否需要发送警报
            if (fire_count != expected_count and 
                continuous_abnormal_time >= wechat_config['alert_continuous_time']):
                
                if current_time - last_alert_time >= detection_config['alert_cooldown']:
                    logger.info(f"检测到持续异常! 火焰数量: {fire_count} - 持续 {continuous_abnormal_time:.1f}秒")
                    
                    # 发送警报
                    alert_success = alert_manager.send_alert(
                        frame, detections, fire_count, continuous_abnormal_time
                    )
                    if alert_success:
                        last_alert_time = current_time
                        logger.info("警报发送成功")
                    else:
                        logger.error("警报发送失败")
                else:
                    # 即使不发送警报，也保存报警图片用于记录
                    alert_manager.save_alarm_images(frame, detections, fire_count)
                    remaining_time = int(detection_config['alert_cooldown'] - (current_time - last_alert_time))
                    logger.info(f"警报发送冷却中，跳过本次发送 (剩余: {remaining_time}秒)")
            else:
                # 正常状态下只显示简化的保存确认
                if status_change_count > 0:
                    logger.info(f"状态恢复正常 - 火焰数量: {fire_count}")
                    status_change_count = 0
            
            last_save_time = current_time
            if fire_count != expected_count:  # 只在异常状态显示分隔线
                logger.info("-" * 60)
        
        # 检查退出条件
        if camera_manager.check_exit():
            break

if __name__ == "__main__":
    main()