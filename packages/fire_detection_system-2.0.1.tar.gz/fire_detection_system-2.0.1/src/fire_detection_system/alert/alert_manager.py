import os
import cv2
import time
import logging
import requests
import json
from datetime import datetime

from alert.wechat_bot import WeChatWorkBot
from fd_utils.file_utils import FileUtils

class AlertManager:
    def __init__(self, config, camera_name):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.camera_name = camera_name
        self.camera_config = config['cameras'][camera_name]
        
        self.api_config = config['api_config']
        self.wechat_config = config['wechat_config']
        self.detection_config = config['detection_config']
        self.directory_config = config['directory_config']
        self.cleanup_config = config['cleanup_config']
        
        # 初始化目录
        self.images_dir = None
        self.detected_dir = None
        self.alarm_dir = None
        self.alarm_clean_dir = None
        self.log_dir = None
        
        # 初始化企业微信机器人
        self.wechat_bot = WeChatWorkBot(self.wechat_config["webhook_url"])
        
        # 状态跟踪
        self.last_point_status = False
        self.last_api_check_time = 0
    
    def initialize_directories(self):
        """初始化目录"""
        current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        base_images_dir = os.path.join(current_dir, self.directory_config["images_dir"])
        base_detected_dir = os.path.join(current_dir, self.directory_config["detected_dir"])
        base_alarm_dir = os.path.join(current_dir, self.directory_config["alarm_dir"])
        base_alarm_clean_dir = os.path.join(current_dir, self.directory_config["alarm_clean_dir"])
        self.log_dir = os.path.join(current_dir, self.directory_config["log_dir"])
        
        # 为不同摄像头创建子目录
        self.images_dir = os.path.join(base_images_dir, self.camera_name)
        self.detected_dir = os.path.join(base_detected_dir, self.camera_name)
        self.alarm_dir = os.path.join(base_alarm_dir, self.camera_name)
        self.alarm_clean_dir = os.path.join(base_alarm_clean_dir, self.camera_name)
        
        # 创建目录
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.detected_dir, exist_ok=True)
        os.makedirs(self.alarm_dir, exist_ok=True)
        os.makedirs(self.alarm_clean_dir, exist_ok=True)
        os.makedirs(self.log_dir, exist_ok=True)
        
        self.logger.info(f"📁 目录初始化完成: {self.camera_name}")
    
    def check_point_status(self, current_time, last_api_check_time, disable_api_check):
        """检查API点位状态"""
        point_code = self.camera_config.get('pointCode')
        
        if disable_api_check or not point_code:
            return True
            
        if current_time - last_api_check_time >= self.api_config['check_interval']:
            point_status, status_msg = self._check_point_status_internal(point_code)
            
            if point_status != self.last_point_status:
                status_text = "启用" if point_status else "禁用"
                self.logger.info(f"🔄 点位状态变化: {status_text} - {status_msg}")
                self.last_point_status = point_status
            
            return point_status
        
        return self.last_point_status
    
    def _check_point_status_internal(self, point_code):
        """内部API点位状态检查"""
        try:
            url = self.api_config["base_url"]
            payload = {"pointCode": point_code}
            timeout = self.api_config.get("timeout", 10)
            
            response = requests.post(url, json=payload, timeout=timeout)
            
            if response.status_code == 200:
                result = response.json()
                if result.get("statusCode") == 200:
                    data = result.get("data", [{}])
                    if data and isinstance(data[0].get("value"), bool):
                        status = data[0]["value"]
                        return status, f"点位状态: {status}"
                    else:
                        return False, "API返回数据格式错误"
                else:
                    return False, f"API返回错误: {result.get('message', '未知错误')}"
            else:
                return False, f"HTTP请求失败: {response.status_code}"
                
        except requests.exceptions.Timeout:
            return False, "API请求超时"
        except requests.exceptions.ConnectionError:
            return False, "API连接错误"
        except Exception as e:
            return False, f"API检查异常: {str(e)}"
    
    def save_images(self, frame, detections, fire_count, annotated_frame):
        """保存图像"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ip = self.camera_config['ip']
        expected_count = self.camera_config.get('expected_fire_count', 3)
        
        # 保存原始图像
        original_filename = f"{ip}_{timestamp}.jpg"
        original_path = os.path.join(self.images_dir, original_filename)
        cv2.imwrite(original_path, frame)
        
        # 保存带有检测框的图像
        status_save = "normal" if fire_count == expected_count else "alert"
        detected_filename = f"{ip}_{status_save}_{fire_count}fires_{timestamp}.jpg"
        detected_path = os.path.join(self.detected_dir, detected_filename)
        cv2.imwrite(detected_path, annotated_frame)
        
        # 只在状态异常时显示保存信息
        if fire_count != expected_count:
            self.logger.info(f"📸 图像已保存: {original_filename} (检测状态: {status_save})")
    
    def save_alarm_images(self, frame, detections, fire_count, roi_mask=None):
        """保存报警图片"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ip = self.camera_config['ip']
            expected_count = self.camera_config.get('expected_fire_count', 3)
            alarm_type = "less" if fire_count < expected_count else "more"
            
            # 保存带标注报警图片
            alarm_frame = self._draw_detections_blue_white(frame, detections, roi_mask)
            alarm_filename = f"alarm_{ip}_{alarm_type}_{fire_count}fires_{timestamp}.jpg"
            alarm_path = os.path.join(self.alarm_dir, alarm_filename)
            cv2.imwrite(alarm_path, alarm_frame)
            
            # 保存无标注原始报警图片
            alarm_clean_filename = f"alarm_clean_{ip}_{alarm_type}_{fire_count}fires_{timestamp}.jpg"
            alarm_clean_path = os.path.join(self.alarm_clean_dir, alarm_clean_filename)
            cv2.imwrite(alarm_clean_path, frame)
            
            self.logger.info(f"🚨 报警图片已保存: {alarm_filename}")
            
            return alarm_path, alarm_clean_path
        except Exception as e:
            self.logger.error(f"保存报警图片时发生错误: {e}")
            return None, None
    
    def _draw_detections_blue_white(self, frame, detections, roi_mask=None):
        """绘制蓝色框白色字体的检测结果"""
        result_frame = frame.copy()
        confidence_threshold = self.config['model_config']["confidence_threshold"]
        
        if roi_mask is not None:
            roi_visual = np.zeros_like(result_frame)
            roi_visual[roi_mask == 255] = [0, 255, 0]
            cv2.addWeighted(roi_visual, 0.1, result_frame, 1, 0, result_frame)
        
        for det in detections:
            x1, y1, x2, y2, conf, cls = det.tolist()
            
            if conf < confidence_threshold:
                continue
                
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            color = (255, 0, 0)
            label_color = (255, 255, 255)
            line_width = 2
            
            cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, line_width)
            
            label = f"Fire {conf:.2f}"
            font_scale = 0.7
            thickness = 2
            (text_width, text_height), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness
            )
            
            cv2.rectangle(result_frame, 
                         (x1, y1 - text_height - baseline - 5), 
                         (x1 + text_width, y1), 
                         color, -1)
            
            cv2.putText(result_frame, label, 
                       (x1, y1 - baseline - 3), 
                       cv2.FONT_HERSHEY_SIMPLEX, font_scale, label_color, thickness)
        
        return result_frame
    
    def send_wechat_alert(self, fire_count, image_path, ip, continuous_time):
        """发送企业微信警报"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        alert_message = self.create_alert_message(fire_count, timestamp, ip, continuous_time)
        text_success = self.wechat_bot.send_text_message(alert_message)
        image_success = self.wechat_bot.send_image_message(image_path)
        
        self.log_alert_send(fire_count, text_success and image_success, continuous_time)
        
        return text_success and image_success

    def create_alert_message(self, fire_count, timestamp, ip, continuous_time):
        """创建企业微信警报消息"""
        expected_count = self.camera_config.get('expected_fire_count', 3)
        status = "正常" if fire_count == expected_count else "异常"
        alert_type = "火焰不足" if fire_count < expected_count else "火焰过多"
        
        message = f"火焰检测系统警报\n"
        message += f"检测时间: {timestamp}\n"
        message += f"摄像头: {self.camera_name}({ip}) \n"
        message += f"检测结果: {fire_count}个火焰\n"
        message += f"期望数量: {expected_count}个火焰\n"
        message += f"状态: {status} ({alert_type})\n"
        message += f"异常持续时间: {continuous_time}秒\n"
        
        if fire_count != expected_count:
            alert_level = '低级' if abs(fire_count-expected_count) == 1 else '高级'
            message += f"警报级别: {alert_level}\n"
        
        message += f"请及时检查现场情况！"
        
        return message

    def log_alert_send(self, fire_count, success, continuous_time):
        """记录警报发送日志"""
        log_file = os.path.join(self.log_dir, f"wechat_alerts_{datetime.now().strftime('%Y%m%d')}.txt")
        
        with open(log_file, 'a', encoding='utf-8') as f:
            status = "成功" if success else "失败"
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | ")
            f.write(f"摄像头: {self.camera_name} | ")
            f.write(f"火焰数量: {fire_count} | ")
            f.write(f"持续时间: {continuous_time}秒 | ")
            f.write(f"发送状态: {status}\n")
    
    def cleanup_old_images(self):
        """清理旧图片"""
        try:
            cleaned_ready = FileUtils.cleanup_old_images(
                self.images_dir, self.cleanup_config["max_files_per_directory"]
            )
            cleaned_detected = FileUtils.cleanup_old_images(
                self.detected_dir, self.cleanup_config["max_files_per_directory"]
            )
            cleaned_alarm = FileUtils.cleanup_old_images(
                self.alarm_dir, self.cleanup_config["max_files_per_directory"]
            )
            cleaned_alarm_clean = FileUtils.cleanup_old_images(
                self.alarm_clean_dir, self.cleanup_config["max_files_per_directory"]
            )
            
            total_cleaned = cleaned_ready + cleaned_detected + cleaned_alarm + cleaned_alarm_clean
            if total_cleaned > 0:
                self.logger.info(f"🗑️ 总计清理了 {total_cleaned} 个图片文件")
            
            return total_cleaned
        except Exception as e:
            self.logger.error(f"检查清理图片时发生错误: {e}")
            return 0