import requests
import json
import base64
import hashlib
import logging

class WeChatWorkBot:
    def __init__(self, webhook_url):
        self.logger = logging.getLogger(__name__)
        self.webhook_url = webhook_url
    
    def send_text_message(self, content):
        """发送文本消息"""
        data = {
            "msgtype": "text",
            "text": {
                "content": content
            }
        }
        try:
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.webhook_url, headers=headers, 
                                data=json.dumps(data), timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('errcode') == 0:
                    self.logger.info("✅ 文本消息发送成功")
                    return True
                else:
                    self.logger.error(f"❌ 企业微信API返回错误: {result.get('errmsg', '未知错误')}")
                    return False
            else:
                self.logger.error(f"❌ HTTP请求失败，状态码: {response.status_code}")
                return False
        except Exception as e:
            self.logger.error(f"❌ 发送文本消息时发生错误: {e}")
            return False
    
    def send_image_message(self, image_path):
        """发送图片消息"""
        try:
            with open(image_path, "rb") as f:
                image_data = f.read()
            
            if len(image_data) > 2 * 1024 * 1024:
                self.logger.error("❌ 图片文件大小超过2M限制")
                return False
            
            base64_data = base64.b64encode(image_data).decode("utf-8")
            md5_hash = hashlib.md5(image_data).hexdigest()

            data = {
                "msgtype": "image",
                "image": {
                    "base64": base64_data,
                    "md5": md5_hash
                }
            }
            
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.webhook_url, headers=headers, 
                                data=json.dumps(data), timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('errcode') == 0:
                    self.logger.info("✅ 图片发送成功")
                    return True
                else:
                    self.logger.error(f"❌ 企业微信API返回错误: {result.get('errmsg', '未知错误')}")
                    return False
            else:
                self.logger.error(f"❌ HTTP请求失败，状态码: {response.status_code}")
                return False
        except Exception as e:
            self.logger.error(f"❌ 发送图片消息时发生错误: {e}")
            return False