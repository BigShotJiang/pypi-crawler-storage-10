"""
警报管理模块
负责企业微信通知、API状态检查和报警处理
"""

from .alert_manager import AlertManager
from .wechat_bot import WeChatWorkBot

__all__ = ['AlertManager', 'WeChatWorkBot']
__version__ = '2.0.0'
__author__ = 'Fire Detection System Team'

class AlertModule:
    """警报模块主类"""
    
    @staticmethod
    def get_module_info():
        """获取模块信息"""
        return {
            'name': '警报管理模块',
            'version': __version__,
            'description': '负责企业微信通知发送、API状态检查、报警触发和日志记录',
            'author': __author__,
            'exports': __all__
        }
    
    @staticmethod
    def get_alert_levels():
        """获取警报级别"""
        return {
            'low': {
                'name': '低级警报',
                'description': '火焰数量偏差1个',
                'color': '🟡'
            },
            'high': {
                'name': '高级警报', 
                'description': '火焰数量偏差2个及以上',
                'color': '🔴'
            },
            'critical': {
                'name': '严重警报',
                'description': '系统异常或连接失败',
                'color': '💀'
            }
        }
    
    @staticmethod
    def get_message_templates():
        """获取消息模板"""
        return {
            'normal': '系统运行正常',
            'fire_less': '🔥 火焰数量不足警报',
            'fire_more': '🔥 火焰数量过多警报', 
            'system_error': '❌ 系统异常警报',
            'api_error': '🌐 API连接异常'
        }
    
    @staticmethod
    def get_api_endpoints():
        """获取API端点"""
        return {
            'status_check': {
                'url': 'http://bcapi.nisco.cn/customApi/iot/getCurrentValue',
                'method': 'POST',
                'timeout': 10
            },
            'wechat_webhook': {
                'url': 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send',
                'method': 'POST',
                'timeout': 30
            }
        }
    
    @staticmethod
    def get_alert_config():
        """获取警报配置"""
        return {
            'continuous_time': 20,  # 持续异常时间阈值（秒）
            'cooldown_time': 30,    # 警报冷却时间（秒）
            'max_retries': 3,       # 最大重试次数
            'check_interval': 5     # API检查间隔（秒）
        }

# 模块初始化信息
MODULE_INFO = AlertModule.get_module_info()
ALERT_LEVELS = AlertModule.get_alert_levels()
MESSAGE_TEMPLATES = AlertModule.get_message_templates()
API_ENDPOINTS = AlertModule.get_api_endpoints()
ALERT_CONFIG = AlertModule.get_alert_config()

# 警报状态常量
ALERT_STATUS = {
    'NORMAL': 'normal',
    'PENDING': 'pending',
    'TRIGGERED': 'triggered',
    'COOLDOWN': 'cooldown',
    'SENT': 'sent',
    'FAILED': 'failed'
}

# 企业微信消息类型
WECHAT_MESSAGE_TYPES = {
    'TEXT': 'text',
    'IMAGE': 'image',
    'MARKDOWN': 'markdown'
}