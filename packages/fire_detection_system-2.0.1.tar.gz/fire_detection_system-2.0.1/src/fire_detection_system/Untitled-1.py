#!/usr/bin/env python3
"""
检查所有模块的导入
"""

import ast
import os

def check_imports(file_path):
    """检查Python文件的导入"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    try:
        tree = ast.parse(content)
        imports = set()
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.add(node.module)
        
        return imports
    except Exception as e:
        print(f"解析文件 {file_path} 时出错: {e}")
        return set()

def check_required_imports(file_path, required_imports):
    """检查是否缺少必要的导入"""
    current_imports = check_imports(file_path)
    missing_imports = required_imports - current_imports
    
    if missing_imports:
        print(f"❌ {file_path} 缺少导入: {missing_imports}")
        return False
    else:
        print(f"✅ {file_path} 导入检查通过")
        return True

def main():
    """检查所有主要模块的导入"""
    print("🔍 检查模块导入...")
    
    # 定义每个文件应该包含的导入
    required_imports = {
        'main.py': {'os', 'sys', 'logging', 'argparse', 'datetime'},
        'config/config_manager.py': {'os', 'json', 'logging'},
        'camera/camera_manager.py': {'cv2', 'time', 'logging', 'numpy'},
        'detection/model_inference.py': {'os', 'torch', 'cv2', 'numpy', 'logging'},
        'detection/roi_manager.py': {'numpy', 'cv2', 'logging'},
        'alert/alert_manager.py': {'os', 'cv2', 'time', 'logging', 'requests', 'json', 'datetime'},
        'alert/wechat_bot.py': {'requests', 'json', 'base64', 'hashlib', 'logging'},
        'utils/file_utils.py': {'os', 'logging'},
        'utils/device_utils.py': {'torch', 'logging'}
    }
    
    all_passed = True
    for file_path, imports in required_imports.items():
        if os.path.exists(file_path):
            if not check_required_imports(file_path, imports):
                all_passed = False
        else:
            print(f"⚠️  文件不存在: {file_path}")
    
    if all_passed:
        print("\n🎉 所有模块导入检查通过！")
    else:
        print("\n⚠️  部分模块缺少导入，请修复后再运行")

if __name__ == "__main__":
    main()