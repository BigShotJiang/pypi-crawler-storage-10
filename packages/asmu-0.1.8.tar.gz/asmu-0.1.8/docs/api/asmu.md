::: asmu
