__version__ = "1.0.0"

# syntetica_sdk/__init__.py
from .core import syntetica  # classe telle que définie dans core.py

__all__ = ["syntetica"]