#
#  Copyright 2022, by the California Institute of Technology.  ALL RIGHTS
#  RESERVED. United States Government Sponsorship acknowledged. Any commercial
#  use must be negotiated with the Office of Technology Transfer at the
#  California Institute of Technology.
#
"""
======
roundup.py
======

Contains functions for enumerating recently-updated DOIs and sending the metadata as arbitrary notifications.
"""
