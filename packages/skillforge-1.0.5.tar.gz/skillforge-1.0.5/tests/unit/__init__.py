"""Unit tests for SkillForge components"""
