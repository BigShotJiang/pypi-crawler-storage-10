from setuptools import setup, find_packages

setup(
    name="soft-computing-uat",
    version="1.1.7",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scikit-fuzzy",
        "matplotlib",
        "scipy",
        "networkx"
    ],
    entry_points={
        "console_scripts": [
            "control-fan = exp_1.control_fan:main",
            "washing-machine = exp_1.washing_machine:main",
            "fan-control = exp_1.fan_control:main",
            "car-brake = exp_1.car_brake:main",
            "discrete-percep = exp_1.discrete_percep:main",
            "gen-code = exp_1.gen_code:main",
            "som-map = exp_1.som_map:main",
            "three-sin = exp_1.three_sin:main",
            "two-sin = exp_1.two_sin:main",
            "xor-code = exp_1.xor_code:main",
        ],
    },
    author="suren-sudo",
    description="Soft computing experiments collection",
    long_description=open("README.md").read() if open("README.md", "r", encoding="utf-8") else "",
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
