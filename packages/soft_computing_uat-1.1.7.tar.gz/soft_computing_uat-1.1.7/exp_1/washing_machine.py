def main():
    import numpy as np
    import skfuzzy as fuzz
    from skfuzzy import control as ctrl
    import matplotlib.pyplot as plt
    dirtiness = ctrl.Antecedent(np.arange(0, 11, 1), 'dirtiness')
    load = ctrl.Antecedent(np.arange(0, 11, 1), 'load')
    wash_time = ctrl.Consequent(np.arange(0, 61, 1), 'wash_time')
    dirtiness['low'] = fuzz.trimf(dirtiness.universe, [0, 0, 5])
    dirtiness['medium'] = fuzz.trimf(dirtiness.universe, [0, 5, 10])
    dirtiness['high'] = fuzz.trimf(dirtiness.universe, [5, 10, 10])
    load['light'] = fuzz.trimf(load.universe, [0, 0, 5])
    load['medium'] = fuzz.trimf(load.universe, [0, 5, 10])
    load['heavy'] = fuzz.trimf(load.universe, [5, 10, 10])
    wash_time['short'] = fuzz.trimf(wash_time.universe, [0, 0, 30])
    wash_time['medium'] = fuzz.trimf(wash_time.universe, [0, 30, 60])
    wash_time['long'] = fuzz.trimf(wash_time.universe, [30, 60, 60])
    rule1 = ctrl.Rule(dirtiness['low'] & load['light'], wash_time['short'])
    rule2 = ctrl.Rule(dirtiness['medium'] | load['medium'], wash_time['medium'])
    rule3 = ctrl.Rule(dirtiness['high'] | load['heavy'], wash_time['long'])
    wash_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
    wash_sim = ctrl.ControlSystemSimulation(wash_ctrl)
    wash_sim.input['dirtiness'] = 7
    wash_sim.input['load'] = 8
    wash_sim.compute()
    print("Wash Time (minutes):", wash_sim.output['wash_time'])
    dirtiness.view()
    load.view()
    wash_time.view(sim=wash_sim)
    plt.show()

if __name__ == "__main__":
    main()
