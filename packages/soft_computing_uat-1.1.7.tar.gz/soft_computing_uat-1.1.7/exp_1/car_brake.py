def main():
    import numpy as np
    import skfuzzy as fuzz
    from skfuzzy import control as ctrl
    import matplotlib.pyplot as plt
    speed = ctrl.Antecedent(np.arange(0, 121, 1), 'speed')
    distance = ctrl.Antecedent(np.arange(0, 101, 1), 'distance')
    brake = ctrl.Consequent(np.arange(0, 101, 1), 'brake')
    speed['low'] = fuzz.trimf(speed.universe, [0, 0, 60])
    speed['medium'] = fuzz.trimf(speed.universe, [0, 60, 120])
    speed['high'] = fuzz.trimf(speed.universe, [60, 120, 120])
    distance['close'] = fuzz.trimf(distance.universe, [0, 0, 50])
    distance['medium'] = fuzz.trimf(distance.universe, [0, 50, 100])
    distance['far'] = fuzz.trimf(distance.universe, [50, 100, 100])
    brake['light'] = fuzz.trimf(brake.universe, [0, 0, 50])
    brake['moderate'] = fuzz.trimf(brake.universe, [0, 50, 100])
    brake['strong'] = fuzz.trimf(brake.universe, [50, 100, 100])
    rule1 = ctrl.Rule(speed['high'] & distance['close'], brake['strong'])
    rule2 = ctrl.Rule(speed['medium'] & distance['medium'], brake['moderate'])
    rule3 = ctrl.Rule(speed['low'] | distance['far'], brake['light'])
    brake_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
    brake_sim = ctrl.ControlSystemSimulation(brake_ctrl)
    brake_sim.input['speed'] = 100
    brake_sim.input['distance'] = 20
    brake_sim.compute()
    print("Braking Force (%):", brake_sim.output['brake'])
    speed.view()
    distance.view()
    brake.view(sim=brake_sim)
    plt.show()

if __name__ == "__main__":
    main()
