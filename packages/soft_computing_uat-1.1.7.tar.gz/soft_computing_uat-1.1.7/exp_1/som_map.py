import numpy as np
import matplotlib.pyplot as plt

def train_som(data, grid_size=(10, 10), input_dim=2, learning_rate=0.2, num_epochs=100):
    # Initialize the SOM weight matrix
    weight_matrix = np.random.rand(grid_size[0], grid_size[1], input_dim)

    # Training loop
    for epoch in range(num_epochs):
        for input_vector in data:
            # Find the Best Matching Unit (BMU)
            distances = np.linalg.norm(weight_matrix - input_vector, axis=-1)
            bmu_coords = np.unravel_index(np.argmin(distances), distances.shape)

            # Update the BMU and its neighbors
            for i in range(grid_size[0]):
                for j in range(grid_size[1]):
                    distance_to_bmu = np.linalg.norm(np.array([i, j]) - np.array(bmu_coords))
                    # Adjusting the influence based on the current epoch
                    influence = np.exp(-distance_to_bmu**2 / (2 * (epoch + 1)**2))
                    weight_matrix[i, j] += influence * learning_rate * (input_vector - weight_matrix[i, j])

    return weight_matrix

def create_cluster_map(data, weight_matrix):
    grid_size = weight_matrix.shape[:2]
    cluster_map = np.zeros((grid_size[0], grid_size[1]), dtype=int)
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            distances = np.linalg.norm(data - weight_matrix[i, j], axis=-1)
            cluster_map[i, j] = np.argmin(distances)
    return cluster_map

def visualize_som(cluster_map, data, grid_size):
    plt.figure(figsize=(8, 8))
    plt.pcolormesh(cluster_map, cmap='viridis', shading='auto')
    plt.colorbar(label='Cluster')
    plt.scatter(data[:, 0] * grid_size[0], data[:, 1] * grid_size[1], color='red', s=10, label='Data points')
    plt.legend()
    plt.title('Self-Organizing Map Clustering')
    plt.show()

def main():
    # Generate some sample data (replace this with your own dataset)
    np.random.seed(42)
    data = np.random.rand(100, 2)

    # SOM parameters
    grid_size = (10, 10)
    input_dim = 2
    learning_rate = 0.2
    num_epochs = 100

    # Train the SOM
    weight_matrix = train_som(data, grid_size, input_dim, learning_rate, num_epochs)

    # Create cluster map
    cluster_map = create_cluster_map(data, weight_matrix)

    # Visualize the SOM
    visualize_som(cluster_map, data, grid_size)

# --- Entry point ---
if __name__ == "__main__":
    main()
