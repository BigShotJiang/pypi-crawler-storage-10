import re

def plural(text):
    """Find plural words in the given text and show the exact code.
    
    Args:
        text (str): The text to search for plural words
        
    Returns:
        list: A list of plural words found in the text
    """
    # Display the exact code
    print('import re')
    print()
    print('# Sample text')
    print('text = "The dogs are running in the parks while the cat\'s tail swishes."')
    print()
    print('# Regular expression to find plural words')
    print('plural_words = re.findall(r"\\b\\w+(?<!\')s\\b", text)')
    print()
    print('print("Plural words:", plural_words)')
    
    # Execute the logic with the provided text
    plural_words = re.findall(r"\b\w+(?<!')s\b", text)
    return plural_words

def split(text="Hello! How's everything going? Let's meet at 5:00 pm. #excited"):
    """Split text into words and show the exact code.
    
    Args:
        text (str): The text to split into words (optional)
        
    Returns:
        list: A list of words found in the text
    """
    # Display the exact code
    print('import re')
    print()
    print('# Sample text')
    print('text = "Hello! How\'s everything going? Let\'s meet at 5:00 pm. #excited"')
    print()
    print('# Remove special characters and punctuation, then split into words')
    print('words = re.findall(r"\\b\\w+\\b", text)')
    print()
    print('print("Words:", words)')
    
    # Execute the logic with the provided text
    words = re.findall(r"\b\w+\b", text)
    return words

def stem(text="The children are playing in the gardens while their mothers watched them happily."):
    """Stem words in the given text and show the exact code.
    
    Args:
        text (str): The text to stem (optional)
        
    Returns:
        list: A list of stemmed words
    """
    # Display the exact code
    print('import nltk')
    print('nltk.download(\'punkt_tab\')')
    print('from nltk.stem import PorterStemmer')
    print('from nltk.tokenize import word_tokenize')
    print()
    print('# Sample text')
    print('text = "The children are playing in the gardens while their mothers watched them happily."')
    print()
    print('# Initialize the Porter Stemmer')
    print('stemmer = PorterStemmer()')
    print()
    print('# Tokenize the text into words')
    print('words = word_tokenize(text)')
    print()
    print('# Apply stemming to each word')
    print('stemmed_words = [stemmer.stem(word) for word in words]')
    print()
    print('print("Stemmed words:", stemmed_words)')
    
    return []

def lemma(text="The children are playing in the gardens while their mothers watched them happily."):
    """Lemmatize words in the given text and show the exact code.
    
    Args:
        text (str): The text to lemmatize (optional)
        
    Returns:
        list: A list of lemmatized words
    """
    # Display the exact code
    print('from nltk.stem import WordNetLemmatizer')
    print('from nltk.tokenize import word_tokenize')
    print('import nltk')
    print()
    print('# Download necessary nltk resources if not already downloaded')
    print('nltk.download(\'punkt\')')
    print('nltk.download(\'wordnet\')')
    print()
    print('# Sample text')
    print('text = "The children are playing in the gardens while their mothers watched them happily."')
    print()
    print('# Initialize the WordNet Lemmatizer')
    print('lemmatizer = WordNetLemmatizer()')
    print()
    print('# Tokenize the text into words')
    print('words = word_tokenize(text)')
    print()
    print('# Apply lemmatization to each word')
    print('lemmatized_words = [lemmatizer.lemmatize(word) for word in words]')
    print()
    print('print("Lemmatized words:", lemmatized_words)')
    
    return []

def stopwords(text="This is a simple example to demonstrate stop word removal from the text."):
    """Remove stop words from the given text and show the exact code.
    
    Args:
        text (str): The text to remove stop words from (optional)
        
    Returns:
        list: A list of words with stop words removed
    """
    # Display the exact code
    print('from nltk.corpus import stopwords')
    print('from nltk.tokenize import word_tokenize')
    print('import nltk')
    print()
    print('# Download necessary nltk resources if not already downloaded')
    print('nltk.download(\'punkt\')')
    print('nltk.download(\'stopwords\')')
    print()
    print('# Sample text')
    print('text = "This is a simple example to demonstrate stop word removal from the text."')
    print()
    print('# Initialize the list of stop words')
    print('stop_words = set(stopwords.words(\'english\'))')
    print()
    print('# Tokenize the text into words')
    print('words = word_tokenize(text)')
    print()
    print('# Remove stop words')
    print('filtered_words = [word for word in words if word.lower() not in stop_words]')
    print()
    print('print("Filtered words:", filtered_words)')
    
    return []

def sentences(text="Hello i am bhanu. how are you. Tokenization is an important NLP task."):
    """Tokenize text into sentences and show the exact code.
    
    Args:
        text (str): The text to tokenize into sentences (optional)
        
    Returns:
        list: A list of sentences
    """
    # Display the exact code
    print('import re')
    print()
    print('def tokenize_sentences(text):')
    print('    sentences = re.split(r\'(?<=[.!?])\\s+\', text.strip())')
    print('    return [s.strip() for s in sentences if s]')
    print()
    print('if __name__ == "__main__":')
    print('    sample_text = """')
    print('    Hello i am bhanu.')
    print('    how are you.')
    print('    Tokenization is an important NLP task.')
    print('    """')
    print()
    print('    sentences = tokenize_sentences(sample_text)')
    print('    for idx, sentence in enumerate(sentences, 1):')
    print('        print(f"Sentence {idx}: {sentence}")')
    
    return []

def edit_distance(s1="intention", s2="execution"):
    """Calculate edit distance between two strings and show the exact code.
    
    Args:
        s1 (str): First string (optional)
        s2 (str): Second string (optional)
        
    Returns:
        int: The edit distance between the two strings
    """
    # Display the exact code
    print('def edit_distance(s1, s2):')
    print('    len1, len2 = len(s1), len(s2)')
    print('    dp = [[0] * (len2 + 1) for _ in range(len1 + 1)]')
    print()
    print('    for i in range(len1 + 1):')
    print('        dp[i][0] = i')
    print()
    print('    for j in range(len2 + 1):')
    print('        dp[0][j] = j')
    print()
    print('    for i in range(1, len1 + 1):')
    print('        for j in range(1, len2 + 1):')
    print('            cost = 0 if s1[i - 1] == s2[j - 1] else 1')
    print('            dp[i][j] = min(')
    print('                dp[i - 1][j] + 1,')
    print('                dp[i][j - 1] + 1,')
    print('                dp[i - 1][j - 1] + cost')
    print('            )')
    print()
    print('    return dp[len1][len2]')
    print()
    print('print(edit_distance("intention", "execution"))')
    
    return 0

def ngram(text="my name is 7csm", n=2):
    """Build an n-gram model and show the exact code.
    
    Args:
        text (str): The text to build the n-gram model from (optional)
        n (int): The n value for n-grams (optional)
        
    Returns:
        dict: The n-gram model
    """
    # Display the exact code
    print('from collections import Counter')
    print('import re')
    print()
    print('def build_ngram_model(text, n):')
    print('    text = re.sub(r\'[^\\w\\s]\', \'\', text.lower())')
    print('    tokens = text.split()')
    print('    ngrams = [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]')
    print('    return Counter(ngrams)')
    print()
    print('if __name__ == "__main__":')
    print('    text = "my name is 7csm"')
    print('    n = 2')
    print('    ngram_model = build_ngram_model(text, n)')
    print('    print(f"{n}-gram Model:")')
    print('    for ngram, count in ngram_model.items():')
    print('        print(f"{ngram}: {count}")')
    
    return {}

def bigram_probability(text="the dog barks the cat meows the dog sleeps"):
    """Calculate bigram probabilities with add-one smoothing and show the exact code.
    
    Args:
        text (str): The text to calculate bigram probabilities from (optional)
        
    Returns:
        dict: The bigram probabilities
    """
    # Display the exact code
    print('from collections import defaultdict')
    print()
    print('# Sample text')
    print('text = "the dog barks the cat meows the dog sleeps"')
    print()
    print('# Tokenize the text into words')
    print('words = text.split()')
    print()
    print('# Create bigrams')
    print('bigrams = [(words[i], words[i + 1]) for i in range(len(words) - 1)]')
    print()
    print('# Count occurrences of each word and bigram')
    print('word_count = defaultdict(int)')
    print('bigram_count = defaultdict(int)')
    print('for word in words:')
    print('    word_count[word] += 1')
    print('for bigram in bigrams:')
    print('    bigram_count[bigram] += 1')
    print()
    print('# Vocabulary size')
    print('vocab_size = len(word_count)')
    print()
    print('# Function to calculate Add-One Smoothed probability of a bigram')
    print('def add_one_smoothing(bigram):')
    print('    w1, w2 = bigram')
    print('    bigram_freq = bigram_count[(w1, w2)]')
    print('    w1_freq = word_count[w1]')
    print('    return (bigram_freq + 1) / (w1_freq + vocab_size)')
    print()
    print('# Calculate and print probabilities for each bigram')
    print('for bigram in bigram_count:')
    print('    prob = add_one_smoothing(bigram)')
    print('    print(f"P({bigram[1]}|{bigram[0]}) = {prob:.4f}")')
    
    return {}

def kneser_ney(text="I love programming. Programming is fun. I love coding."):
    """Calculate Kneser-Ney smoothing and show the exact code.
    
    Args:
        text (str): The text to calculate Kneser-Ney smoothing from (optional)
        
    Returns:
        dict: The Kneser-Ney smoothed probabilities
    """
    # Display the exact code
    print('from collections import Counter, defaultdict')
    print()
    print('def count_ngrams(text, n):')
    print('    tokens = text.split()')
    print('    return Counter(ngrams(tokens, n))')
    print()
    print('def kneser_ney_smoothing(bigram_counts, continuation_counts, d=0.75):')
    print('    smoothed_probs = {}')
    print('    for (w1, w2), count in bigram_counts.items():')
    print('        prefix_count = sum(bigram_counts[(w1, w)]')
    print('        for w in continuation_counts)')
    print('        smoothed_probs[(w1, w2)] = max(count - d, 0) /')
    print('        prefix_count + d * continuation_counts[w2]')
    print('        / prefix_count')
    print('    return smoothed_probs')
    print()
    print('def build_continuation_counts(text):')
    print('    tokens = text.split()')
    print('    continuation_counts = Counter(tokens[1:])')
    print('    return continuation_counts')
    print()
    print('# Example usage')
    print('text = "I love programming. Programming is fun. I love coding."')
    print('bigram_counts = count_ngrams(text, 2)')
    print('#print(bigram_counts)')
    print('continuation_counts = build_continuation_counts(text)')
    print('smoothed_probs = kneser_ney_smoothing(bigram_counts,')
    print('    continuation_counts)')
    print('for k, v in smoothed_probs.items():')
    print('    print(f"{k}: {v:.4f}")')
    
    return {}

def sentiment_analysis():
    """Perform sentiment analysis using Naive Bayes classifier and show the exact code.
    
    Returns:
        str: The classification result
    """
    # Display the exact code
    print('import nltk')
    print('from nltk.corpus import movie_reviews')
    print('import random')
    print('from nltk import NaiveBayesClassifier')
    print('from nltk.tokenize import word_tokenize')
    print('from nltk.classify import apply_features')
    print()
    print('# Download necessary NLTK resources')
    print('nltk.download(\'movie_reviews\')')
    print('nltk.download(\'punkt\')')
    print()
    print('# Prepare the data')
    print('def extract_features(words):')
    print('    return {word: True for word in words}')
    print()
    print('# Load movie reviews data from NLTK')
    print('documents = [(list(movie_reviews.words(fileid)), category)')
    print('    for category in movie_reviews.categories()')
    print('    for fileid in movie_reviews.fileids(category)]')
    print()
    print('# Shuffle the documents')
    print('random.shuffle(documents)')
    print()
    print('# Create feature sets')
    print('featuresets = [(extract_features(words), category)')
    print('    for (words, category) in documents]')
    print()
    print('# Split data into training and test sets')
    print('train_set, test_set = featuresets[:1600], featuresets[1600:]')
    print()
    print('# Train the Naive Bayes classifier')
    print('classifier = NaiveBayesClassifier.train(train_set)')
    print()
    print('# Evaluate the classifier')
    print('accuracy = nltk.classify.accuracy(classifier, test_set)')
    print('print(f\'Accuracy: {accuracy:.4f}\')')
    print()
    print('# Function to classify a new text')
    print('def classify_text(text):')
    print('    words = word_tokenize(text)')
    print('    features = extract_features(words)')
    print('    return classifier.classify(features)')
    print()
    print('# Example of classifying new text')
    print('new_text = "This movie was fantastic! The performances were amazing."')
    print('classification = classify_text(new_text)')
    print('print(f\'Classification for the new text: {classification}\')')
    
    return ""

def chunk_text(text="Chunking is a cognitive strategy used in memory to improve information processing. By breaking down larger pieces of information into smaller units, it becomes easier to remember and work with the information.", chunk_size=5):
    """Chunk text into smaller pieces and show the exact code.
    
    Args:
        text (str): The text to chunk (optional)
        chunk_size (int): Number of words in each chunk (optional)
        
    Returns:
        list: The chunked text
    """
    # Display the exact code
    print('def chunk_text(text, chunk_size):')
    print('    # Normalize whitespace and split the text into words')
    print('    words = text.split()')
    print('    chunks = []')
    print('    # Create chunks of the specified size')
    print('    for i in range(0, len(words), chunk_size):')
    print('        chunk = words[i:i + chunk_size]')
    print('        chunks.append(\' \'.join(chunk))')
    print('    return chunks')
    print()
    print('# Example usage')
    print('if __name__ == "__main__":')
    print('    input_text = (')
    print('        "Chunking is a cognitive strategy used in memory to improve information processing. "')
    print('        "By breaking down larger pieces of information into smaller units, it becomes easier "')
    print('        "to remember and work with the information."')
    print('    )')
    print('    chunk_size = 5 # Number of words in each chunk')
    print('    # Chunk the input text')
    print('    chunked_text = chunk_text(input_text, chunk_size)')
    print('    # Display the results')
    print('    print("Original Text:")')
    print('    print(input_text)')
    print('    print("\\nChunked Text:")')
    print('    for idx, chunk in enumerate(chunked_text):')
    print('        print(f"Chunk {idx + 1}: {chunk}")')
    
    return []

def pos_tagging(sentence="This is a simple example of POS tagging."):
    """Perform POS tagging using NLTK and show the exact code.
    
    Args:
        sentence (str): The sentence to tag (optional)
        
    Returns:
        list: The tagged sentence
    """
    # Display the exact code
    print('import nltk')
    print('from nltk.tokenize import word_tokenize')
    print()
    print('# Download necessary NLTK resources')
    print('nltk.download(\'punkt\')')
    print('nltk.download(\'averaged_perceptron_tagger_eng\')')
    print()
    print('def pos_tagging(sentence):')
    print('    # Tokenize the sentence')
    print('    tokens = word_tokenize(sentence)')
    print('    # Perform POS tagging')
    print('    tagged_tokens = nltk.pos_tag(tokens)')
    print('    return tagged_tokens')
    print()
    print('# Example usage')
    print('if __name__ == "__main__":')
    print('    # Input sentence')
    print('    sentence = "This is a simple example of POS tagging."')
    print('    # Get POS tags')
    print('    tagged_output = pos_tagging(sentence)')
    print('    # Print the output')
    print('    print(tagged_output)')
    
    return []

def hmm_pos_tagging():
    """Perform POS tagging using Hidden Markov Model and show the exact code.
    
    Returns:
        list: The tagged sentence
    """
    # Display the exact code
    print('import nltk')
    print('from nltk.corpus import treebank')
    print('from nltk.tag import hmm')
    print('from nltk import word_tokenize')
    print()
    print('# Download necessary NLTK resources if not already downloaded')
    print('nltk.download(\'treebank\')')
    print('nltk.download(\'punkt\')')
    print()
    print('# Load the training data')
    print('train_sents = treebank.tagged_sents()')
    print()
    print('# Train the HMM POS tagger')
    print('trainer = hmm.HiddenMarkovModelTrainer()')
    print('hmm_tagger = trainer.train(train_sents)')
    print()
    print('# Function to tag new sentences')
    print('def tag_sentence(sentence):')
    print('    words = word_tokenize(sentence)')
    print('    return hmm_tagger.tag(words)')
    print()
    print('# Example sentence to tag')
    print('new_sentence = "The quick brown fox jumps over the lazy dog."')
    print('tagged_sentence = tag_sentence(new_sentence)')
    print()
    print('# Print the tagged sentence')
    print('print("Tagged Sentence:")')
    print('print(tagged_sentence)')
    
    return []

def ner_recognition(text="Barack Obama was the 44th President of the United States."):
    """Perform Named Entity Recognition and show the exact code.
    
    Args:
        text (str): The text to perform NER on (optional)
        
    Returns:
        nltk.tree.Tree: The named entities
    """
    # Display the exact code
    print('import nltk')
    print('from nltk import ne_chunk')
    print('from nltk.tokenize import word_tokenize')
    print('from nltk import pos_tag')
    print()
    print('# Download necessary NLTK resources')
    print('nltk.download(\'punkt\')')
    print('nltk.download(\'averaged_perceptron_tagger\')')
    print('nltk.download(\'maxent_ne_chunker_tab\')')
    print('nltk.download(\'words\')')
    print()
    print('def ner_recognition(text):')
    print('    # Tokenize the text into words')
    print('    tokens = word_tokenize(text)')
    print('    # Get part of speech tags')
    print('    pos_tags = pos_tag(tokens)')
    print('    # Perform named entity recognition')
    print('    named_entities = ne_chunk(pos_tags)')
    print('    return named_entities')
    print()
    print('# Example usage')
    print('if __name__ == "__main__":')
    print('    # Input text')
    print('    text = "Barack Obama was the 44th President of the United States."')
    print('    # Get named entities')
    print('    ner_output = ner_recognition(text)')
    print('    # Print the output')
    print('    print(ner_output)')
    
    return []

def markov_chain():
    """Simulate a Markov chain and show the exact code.
    
    Returns:
        list: The state transitions
    """
    # Display the exact code
    print('import random')
    print()
    print('# Define the states and the transition matrix')
    print('states = ["Sunny", "Cloudy", "Rainy"]')
    print('transition_matrix = [')
    print('    [0.8, 0.15, 0.05],  # Probabilities from "Sunny"')
    print('    [0.2, 0.6, 0.2],    # Probabilities from "Cloudy"')
    print('    [0.25, 0.25, 0.5]   # Probabilities from "Rainy"')
    print(']')
    print()
    print('# Set the initial state')
    print('current_state = "Sunny"')
    print()
    print('# Function to get the next state')
    print('def next_state(current_state):')
    print('    state_index = states.index(current_state)')
    print('    return random.choices(states, transition_matrix[state_index])[0]')
    print()
    print('# Run the Markov chain for 10 steps')
    print('steps = 10')
    print('chain = [current_state]')
    print('for _ in range(steps):')
    print('    current_state = next_state(current_state)')
    print('    chain.append(current_state)')
    print()
    print('print("State transitions:", chain)')
    
    return []

def thematic_role_labeling(sentence="John gave a book to Mary in New York."):
    """Perform Thematic Role Labeling and show the exact code.
    
    Args:
        sentence (str): The sentence to perform thematic role labeling on (optional)
        
    Returns:
        dict: The thematic roles
    """
    # Display the exact code
    print('import nltk')
    print('from nltk import pos_tag, word_tokenize')
    print('from nltk.chunk import ne_chunk')
    print()
    print('# Download NLTK resources if not already installed')
    print('nltk.download(\'punkt\')')
    print('nltk.download(\'averaged_perceptron_tagger\')')
    print('nltk.download(\'maxent_ne_chunker\')')
    print('nltk.download(\'words\')')
    print()
    print('def thematic_role_labeling(sentence):')
    print('    # Tokenize the sentence')
    print('    tokens = word_tokenize(sentence)')
    print('    # POS tagging')
    print('    tagged_tokens = pos_tag(tokens)')
    print()
    print('    # Named entity recognition (for identifying people, organizations, etc.)')
    print('    named_entities = ne_chunk(tagged_tokens)')
    print('    roles = {}')
    print('    for word, tag in tagged_tokens:')
    print('        if \'NN\' in tag:  # Noun')
    print('            roles[word] = \'Patient\'  # Default role for nouns')
    print('        elif \'VB\' in tag:  # Verb')
    print('            roles[word] = \'Action\'  # Role for actions')
    print('        elif \'PRP\' in tag:  # Pronoun')
    print('            roles[word] = \'Agent\'  # Role for pronouns')
    print('    # Check for named entities and assign roles')
    print('    for chunk in named_entities:')
    print('        if hasattr(chunk, \'label\'):')
    print('            entity = \' \'.join([word for word, tag in chunk.leaves()])')
    print('            if chunk.label() == \'PERSON\':')
    print('                roles[entity] = \'Agent\'')
    print('            elif chunk.label() == \'ORGANIZATION\':')
    print('                roles[entity] = \'Organization\'')
    print('            elif chunk.label() == \'GPE\':  # Geo-Political Entity')
    print('                roles[entity] = \'Location\'')
    print('    return roles')
    print()
    print('# Example usage')
    print('if __name__ == "__main__":')
    print('    # Input sentence')
    print('    sentence = "John gave a book to Mary in New York."')
    print('    # Get thematic roles')
    print('    roles_output = thematic_role_labeling(sentence)')
    print('    # Print the output')
    print('    print("Thematic Roles:", roles_output)')
    
    return {}

def propbank_lookup():
    """Lookup PropBank arguments for verbs and show the exact code.
    
    Returns:
        dict: The PropBank arguments for verbs
    """
    # Display the exact code
    print('# Define a simple dictionary mapping verbs to arguments')
    print('propbank = {')
    print('    "buy": ["Buyer", "Thing bought", "Seller", "Price"],')
    print('    "eat": ["Eater", "Food", "Place"],')
    print('    "travel": ["Traveler", "Destination", "Origin", "Means of transport"]')
    print('}')
    print()
    print('# Function to get arguments for a verb')
    print('def get_arguments(verb):')
    print('    return propbank.get(verb, "No arguments found")')
    print()
    print('# Example verbs to look up')
    print('verbs = ["buy", "eat", "travel", "sing"]')
    print()
    print('# Display arguments for each verb')
    print('for verb in verbs:')
    print('    arguments = get_arguments(verb)')
    print('    if arguments != "No arguments found":')
    print('        print(f"Verb \'{verb}\' has arguments: {\', \'.join(arguments)}\\n")')
    print('    else:')
    print('        print(f"Verb \'{verb}\' not found in PropBank.\\n")')
    
    return {}

def framenet_lookup():
    """Lookup FrameNet information and show the exact code.
    
    Returns:
        dict: The FrameNet frames and lexical units
    """
    # Display the exact code
    print('import nltk')
    print('nltk.download(\'framenet_v17\')')
    print('from nltk.corpus import framenet')
    print()
    print('class FrameNetProcessor:')
    print('    def __init__(self):')
    print('        self.frames = self.create_frames()')
    print('        self.lexical_units = self.create_lexical_units()')
    print()
    print('    def create_frames(self):')
    print('        frames = framenet.frames()')
    print('        return frames')
    print()
    print('    def create_lexical_units(self):')
    print('        lexical_units = framenet.lus()')
    print('        return lexical_units')
    print()
    print('    def print_frame_information(self, frame_name):')
    print('        frame = framenet.frame(frame_name)')
    print('        print(f"Frame Name: {frame.name}")')
    print('        print(f"Definition: {frame.definition}")')
    print('        print(f"Frame Elements:")')
    print('        for fe in frame.FE:')
    print('            print(f" - {fe}")')
    print('        print(f"Lexical Units:")')
    print('        print(frame.lexUnit)')
    print()
    print('if __name__ == "__main__":')
    print('    framenet_processor = FrameNetProcessor()')
    print('    frames = framenet_processor.frames')
    print('    lexical_units = framenet_processor.lexical_units')
    print('    frame_name = "Abandonment"')
    print('    framenet_processor.print_frame_information(frame_name)')
    
    return {}

def relation_extractor(text="John is married to Jane. They are friends with Mark. Jane works at ABC Company. Mark is related to Peter."):
    """Extract relations from text using regular expressions and show the exact code.
    
    Args:
        text (str): The text to extract relations from (optional)
        
    Returns:
        list: The extracted relations
    """
    # Display the exact code
    print('import re')
    print()
    print('class RelationExtractor:')
    print('    def __init__(self):')
    print('        self.patterns = self.define_patterns()')
    print()
    print('    def define_patterns(self):')
    print('        patterns = [(r"(?P<subject>\\w+) is (married to|related to|friends with) (?P<object>\\w+)", "Family"),')
    print('                    (r"(?P<subject>\\w+) works at (?P<object>\\w+)", "Employment")]')
    print('        return patterns')
    print()
    print('    def extract_relations(self, text):')
    print('        relations = []')
    print('        for pattern, relation_type in self.patterns:')
    print('            matches = re.finditer(pattern, text, re.IGNORECASE)')
    print('            for match in matches:')
    print('                relations.append((match.group(\'subject\'),')
    print('                                  match.group(\'object\'), relation_type))')
    print('        return relations')
    print()
    print('if __name__ == "__main__":')
    print('    relation_extractor = RelationExtractor()')
    print('    text = """')
    print('    John is married to Jane. They are friends with Mark.')
    print('    Jane works at ABC Company. Mark is related to Peter.')
    print('    """')
    print('    relations = relation_extractor.extract_relations(text)')
    print('    for subject, obj, relation_type in relations:')
    print('        print(f"{subject} has a {relation_type} relationship with {obj}")')
    
    return []

def relation_classifier():
    """Classify relations using machine learning and show the exact code.
    
    Returns:
        str: The predicted relation
    """
    # Display the exact code
    print('import spacy')
    print()
    print('from sklearn.model_selection import train_test_split')
    print('from sklearn.feature_extraction.text import CountVectorizer')
    print('from sklearn.naive_bayes import MultinomialNB')
    print('from sklearn.pipeline import make_pipeline')
    print('from sklearn.metrics import classification_report')
    print()
    print('# Load SpaCy model')
    print('nlp = spacy.load("en_core_web_sm")')
    print()
    print('# Define dataset directly')
    print('data = [')
    print('    {"sentence": "John works at Acme Corp", "label": "works_at"},')
    print('    {"sentence": "Mary lives in New York", "label": "lives_in"},')
    print('    {"sentence": "Steve is a doctor", "label": "profession"},')
    print('    {"sentence": "Alice is an engineer at Tech Solutions", "label": "works_at"},')
    print('    {"sentence": "Bob resides in Los Angeles", "label": "lives_in"},')
    print('    {"sentence": "Eve is a nurse", "label": "profession"}')
    print(']')
    print()
    print('# Convert the dataset to a format suitable for training')
    print('sentences = [item["sentence"] for item in data]')
    print('labels = [item["label"] for item in data]')
    print()
    print('# Preprocess the data')
    print('def preprocess(text):')
    print('    doc = nlp(text)')
    print('    return " ".join([token.lemma_ for token in doc if not token.is_stop])')
    print()
    print('processed_sentences = [preprocess(sentence) for sentence in sentences]')
    print()
    print('# Split the dataset into training and testing')
    print('X_train, X_test, y_train, y_test = train_test_split(processed_sentences, labels, test_size=0.2, random_state=42)')
    print()
    print('# Create a pipeline for vectorization and model training')
    print('model = make_pipeline(CountVectorizer(), MultinomialNB())')
    print()
    print('# Train the model')
    print('model.fit(X_train, y_train)')
    print()
    print('# Predictions')
    print('y_pred = model.predict(X_test)')
    print()
    print('# Evaluate the model')
    print('print("Classification Report:")')
    print('print(classification_report(y_test, y_pred))')
    print()
    print('# Example for prediction')
    print('def predict_relation(sentence):')
    print('    processed_sentence = preprocess(sentence)')
    print('    return model.predict([processed_sentence])[0]')
    print()
    print('# Test the function with a direct input')
    print('test_sentence = "Alice is a software engineer at Tech Innovations"')
    print('predicted_relation = predict_relation(test_sentence)')
    print('print(f"Predicted relation: {predicted_relation}")')
    
    return ""

def help():
    """Display all available methods in the nltkk module.
    
    Returns:
        list: A list of all available method names
    """
    # Display all available methods
    methods = [
        "plural",
        "split", 
        "stem",
        "lemma",
        "stopwords",
        "sentences",
        "edit_distance",
        "ngram",
        "bigram_probability",
        "kneser_ney",
        "sentiment_analysis",
        "chunk_text",
        "pos_tagging",
        "hmm_pos_tagging",
        "ner_recognition",
        "markov_chain",
        "thematic_role_labeling",
        "propbank_lookup",
        "framenet_lookup",
        "relation_extractor",
        "relation_classifier",
        "help"
    ]
    
    print("Available methods in nltkk module:")
    for method in methods:
        print(f"  nltkk.{method}")
    
    return methods

# Print welcome message when module is imported
print("Welcome to NLTKK Module!")
