# MyModule - A Simple Demo Module

This is a simple demo module created for learning how to publish on PyPI. When imported, it prints "Welcome to MyModule!"

## Installation

To install this module, run:
```bash
pip install mymodule
```

## Usage

Simply import the module:
```python
import mymodule
```

This will automatically print:
```
Welcome to MyModule!
```

## Publishing to PyPI

### Prerequisites
1. Install the required tools:
```bash
pip install build twine
```

2. Create accounts on:
   - [PyPI](https://pypi.org/account/register/)
   - [TestPyPI](https://test.pypi.org/account/register/)

### Building the Package
```bash
python -m build
```

This creates the `dist/` folder with the source distribution and wheel.

### Uploading to TestPyPI
```bash
twine upload --repository testpypi dist/*
```

### Installing from TestPyPI
```bash
pip install -i https://test.pypi.org/simple/ mymodule
```

### Uploading to Real PyPI
After testing, upload to the real PyPI:
```bash
twine upload dist/*
```