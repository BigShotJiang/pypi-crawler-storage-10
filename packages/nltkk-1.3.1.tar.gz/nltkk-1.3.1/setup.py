from setuptools import setup, find_packages

setup(
    name="nltkk",
    version="1.3.1",
    author="M. Sai Sathvik Raj",
    description="A simple NLP toolkit with functions for plural words, text splitting, stemming, lemmatizing, stop word removal, sentence tokenization, edit distance calculation, n-gram models, bigram probability calculation, Kneser-Ney smoothing, sentiment analysis, text chunking, POS tagging, HMM POS tagging, Named Entity Recognition, Markov Chains, Thematic Role Labeling, PropBank lookup, FrameNet lookup, relation extraction, relation classification, and method listing",
    packages=find_packages(),
    python_requires=">=3.7",
)