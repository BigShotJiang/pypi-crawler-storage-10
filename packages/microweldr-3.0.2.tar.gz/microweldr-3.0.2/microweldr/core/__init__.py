"""Core functionality for SVG to G-code conversion."""
