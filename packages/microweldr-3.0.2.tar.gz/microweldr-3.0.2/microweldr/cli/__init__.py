"""Command line interface functionality."""
