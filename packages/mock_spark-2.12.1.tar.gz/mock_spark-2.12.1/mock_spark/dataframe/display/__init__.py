"""Display module for MockDataFrame operations."""

from .formatter import DataFrameFormatter

__all__ = ["DataFrameFormatter"]
