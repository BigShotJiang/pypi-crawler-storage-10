"""Schema management for DataFrame operations."""

from .schema_manager import SchemaManager

__all__ = ["SchemaManager"]
