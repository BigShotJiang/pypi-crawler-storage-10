<div align="center">

# 🚀 Ollcoder

**The AI Coding Agent That Learns**

*Autonomous · Self-Correcting · Persistent Memory*

[![CI](https://github.com/GeneticxCln/ollcoder/actions/workflows/ci.yml/badge.svg)](https://github.com/GeneticxCln/ollcoder/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/GeneticxCln/ollcoder?logo=github)](https://github.com/GeneticxCln/ollcoder/releases)
![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.11%2B-blue.svg)

[Quick Start](#-quick-start) • [Features](#-what-makes-it-different) • [Documentation](docs/) • [Examples](examples/)

</div>

---

## 🔔 Latest Release: v0.4.1 (2025-10-26)

- New: Chat Performance guide — see `docs/CHAT_PERFORMANCE.md`
- Faster streaming display and smart context fast paths in chat/CLI
- Adaptive context builder: faster defaults + optional compression bypass for chat

Update now: `pip install -U ollcoder`

## 💡 What Is Ollcoder?

**The only AI agent that remembers what it's doing across sessions.**

While other tools stop at code generation, Ollcoder runs a complete autonomous loop:

```
🧠 Observe → 📋 Plan → ⚡ Act → ✅ Verify → 🔄 Self-Correct → 💾 Learn
```

It iterates until tests pass, learns from mistakes, and gets smarter with every task.

## 🎯 Quick Start

### Installation

**Option 1: From PyPI (Recommended for most users)**

```bash
# Install with AI provider support (Ollama + Gemini)
pip install 'ollcoder[providers,ui]'

# Or just core (minimal)
pip install ollcoder
```

**Option 2: From Source (For development)**

```bash
git clone https://github.com/GeneticxCln/ollcoder.git
cd ollcoder

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install in editable mode with dependencies
pip install -e '.[providers,ui]'
```

**Setup AI Provider:**

```bash
# Install Ollama (local, private, recommended)
curl -fsSL https://ollama.com/install.sh | sh
ollama pull mistral:latest

# OR use Gemini (cloud)
export GEMINI_API_KEY="your-api-key"

# Also supported: OpenAI and Anthropic
export OPENAI_API_KEY="your-api-key"
export ANTHROPIC_API_KEY="your-api-key"
```

### Run Your First Task

**Quick Start - Interactive Chat:**

```bash
# Terminal chat interface
oc chat

# Graphical TUI (Terminal UI)
oc chat --tui

# Advanced TUI with ALL features (Context Builder, Agent, Security, Memory, etc.)
oc chat --advanced

# If installed from source:
./run_tui.sh          # Basic TUI
./run_tui.sh --advanced  # Advanced TUI
```

That's it! Ollama is auto-detected. Just talk to the AI naturally.

**Advanced - Autonomous Agent:**

```bash
# Set trust for your project
oc trust set . OWNER

# Run the autonomous agent
oc agent run \
  --task "Add error handling to API endpoints" \
  --apply
```

**What happens behind the scenes:**

1. 🧠 **Observes** your codebase and builds intelligent context
2. 📋 **Plans** steps to complete the task via LLM
3. ⚡ **Acts** by applying code changes with security enforcement
4. ✅ **Verifies** with linters, type checkers, and tests
5. 🔄 **Self-corrects** if tests fail (iterates until green)
6. 💾 **Learns** from results for future tasks

### Check What It Learned

```bash
oc memory list                    # View all sessions
oc memory show --session-id main  # See what agent remembers
```

---

---

## ✨ What Makes It Different

### 🧠 Persistent Memory

**The only agent that learns across sessions.**

```bash
# First task - agent learns from experience
oc agent run --task "Add OAuth support" --apply
# 📝 Records: "Always run security scan after auth changes"

# Later task - applies learned patterns  
oc agent run --task "Fix login timeout" --apply
# ✅ Agent remembers: automatically runs security scan
```

**Memory tracks:**
- ✅ Task history (success/failures)
- ✅ Common errors and their fixes
- ✅ File relationships and dependencies
- ✅ Successful patterns per project

### 🔄 True Autonomous Loop

**Iterates until tests pass** — no manual intervention needed.

Most agents generate code and stop. Ollcoder runs your tests, reads errors, fixes them, and repeats until everything works.

### 🎛️ Enterprise-Grade Context

- **5 compression levels** (NONE → SUMMARY) adapt to any token budget
- **4-tier priority system** ensures critical code always fits
- **Smart caching** with 24h TTL + MD5 validation
- **Multi-repo support** for microservices architectures

### 🔒 Security First

- **Trusted folders** with 4-level access control
- **Sandbox execution** in isolated Docker/Podman containers  
- **Security scanning** with Bandit, Semgrep + SARIF export
- **Blockchain signing** for code provenance (Ed25519)

### 🌍 Sustainability & Ethics

- **Carbon tracking** via CodeCarbon integration
- **Complexity analysis** detects unmaintainable code
- **Ethics scanning** finds biased language in code/docs

---

## 📦 Installation Options

**From PyPI:**

```bash
# Core only (minimal)
pip install ollcoder

# With providers (Ollama + Gemini)
pip install ollcoder[providers]

# Full installation (all features)
pip install ollcoder[providers,security,eco,crypto,ui,web,watch]
```

**From source (for development):**

```bash
git clone https://github.com/GeneticxCln/ollcoder.git
cd ollcoder

# Core + Providers (recommended)
pip install -e '.[providers]'

# Full installation (all features)
pip install -e '.[providers,security,eco,crypto,ui,web,watch]'
```

**Provider Setup:**

```bash
# Ollama (local, private)
ollama pull mistral:latest

# Gemini (cloud)
export GEMINI_API_KEY="your-api-key"

# OpenAI / Anthropic (cloud)
export OPENAI_API_KEY="your-api-key"
export ANTHROPIC_API_KEY="your-api-key"
```

---

## 🛠️ Common Commands

### Interactive Chat

```bash
# Terminal chat interface
oc chat

# Graphical TUI (Terminal UI) - recommended
oc chat --tui

# Use specific model
oc --provider ollama --model deepseek-v3.1:671b-cloud chat --tui

# Use Gemini
export GEMINI_API_KEY="your-key"
oc --provider gemini chat

# Quick launcher (if installed from source)
./run_tui.sh
```

### Autonomous Agent

```bash
# Run with self-correction
oc agent run --task "Fix all failing tests" --apply --max-steps 10

# Disable memory for one-off experiments
oc agent run --task "Try new approach" --no-memory

# Use custom session
oc agent run --task "OAuth feature" --session-id oauth --apply
```

### Memory Management

```bash
oc memory list                               # Show all sessions
oc memory show --session-id main             # View details
oc memory export --session-id main --out backup.json
oc memory cleanup --days 30                  # Clean old data
```

### Context Building (Manual)

```bash
# Generate context for ChatGPT/Claude
oc build-context --query "authentication" --paste > context.md

# JSON output for programmatic use
oc build-context --query "api routes" --json
```

### Benchmarking

```bash
# Measure memory + speed for building context
oc bench --json
```

### Fine-Tuning Helpers

```bash
# Prepare a JSONL dataset from your repo (prompt/completion pairs)
oc models prepare-dataset

# Create an OpenAI fine-tuning job (requires openai>=1.0)
oc models openai-create --dataset ./fine_tune.jsonl --base gpt-4o-mini --suffix my-repo

# Generate a starter Modelfile for Ollama adapters/LoRA
oc models modelfile > Modelfile
```

### Security & Trust

```bash
# Set project trust level
oc trust set . OWNER              # Full access
oc trust set /tmp/external LOW    # Limited access
oc trust status .                 # Check current level

# Run security scan
oc security scan --sarif-out results.sarif
```

### Sandbox Execution

```bash
# Run untrusted code in isolated container
oc sandbox run \
  --image python:3.11-slim \
  --mount "$PWD:/code:ro" \
  --cpus 1.0 --memory 512m \
  -- python untrusted_script.py
```

---

## ⚙️ Configuration

### Environment Variables

```bash
export OC_PROVIDER=ollama
export OC_MODEL=mistral:latest
export GEMINI_API_KEY=your-key  # If using Gemini
```

### Project Config (pyproject.toml)

```toml
[tool.ollcoder]
provider = "ollama"
model = "mistral:latest"
```

> ⚠️ **Security Tip**: Never use `--api-key` flags — they leak to shell history. Always use environment variables.

---

---

## 🏆 Why Choose Ollcoder?

| Feature | Ollcoder | Others |
|---------|----------|--------|
| **Persistent Memory** | ✅ Learns across sessions | ❌ |
| **Autonomous Loop** | ✅ Plan → Act → Verify → Correct | ❌ |
| **Self-Correction** | ✅ Iterates until tests pass | ❌ |
| **5-Level Compression** | ✅ Adaptive context fitting | ❌ |
| **Trusted Folders** | ✅ 4-level security model | ❌ |
| **Sandbox Execution** | ✅ Isolated containers | ❌ |
| **Security Scanning** | ✅ Bandit, Semgrep + SARIF | ❌ |
| **Carbon Tracking** | ✅ Sustainability metrics | ❌ |
| **Blockchain Signing** | ✅ Code provenance | ❌ |
| **Multi-Repo Context** | ✅ Unified across services | ❌ |

**20+ unique features not found in Aider, Cursor, or Copilot.**

---


---

---

## 🤖 CI/CD Integration

### GitHub Actions

**Automated PR review:**

```yaml
name: PR Review
on: [pull_request]
jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: GeneticxCln/ollcoder@main
        with:
          review_level: signatures
          post_comment: true
```

**Features**: Compression summaries, heuristic issue detection, auto-labeling, 100+ file support.

**Templates**: See `.github/workflows/` for PR review and issue triage.

---

---

## 📖 Documentation

- **[Memory System Guide](docs/MEMORY.md)** - How persistent learning works
- **[Quick Start](docs/QUICKSTART.md)** - Get running in 5 minutes
- **[Deep Analysis](DEEP_ANALYSIS.md)** - Complete feature breakdown vs competitors
- **[Changelog](CHANGELOG.md)** - Version history
- **[Examples](examples/)** - End-to-end workflows

---

---

## 🌟 Use Cases

### Autonomous Bug Fixing
```bash
oc agent run --task "Fix all failing tests" --apply --max-steps 10
```
*Runs tests → identifies failures → fixes → verifies → repeats until green.*

### Security Audit
```bash
oc security scan --json > audit.json
oc agent run --task "Fix all MEDIUM+ security issues" --apply
```

### Multi-Repo Context
```bash
oc multi build-context \
  --root ~/api --root ~/frontend --root ~/shared \
  --query "authentication flow" --paste
```

### Continuous Learning
```bash
# First task - agent learns patterns
oc agent run --task "Add OAuth" --apply

# Later - applies learned best practices automatically
oc agent run --task "Add SAML" --apply
```

---

## 🧪 Development

```bash
# Run tests
PYTHONPATH=. pytest -q oc_tests

# Linting + type checking
ruff check . && PYTHONPATH=. mypy oc

# Coverage
PYTHONPATH=. pytest --cov=oc --cov-report=term-missing
```

---

## 👥 Community & Support

- **[FAQ](docs/FAQ.md)** - Frequently asked questions
- **[Troubleshooting](docs/TROUBLESHOOTING.md)** - Common issues and solutions
- **[Discussions](https://github.com/GeneticxCln/ollcoder/discussions)** - Ask questions, share ideas
- **[Issues](https://github.com/GeneticxCln/ollcoder/issues)** - Report bugs, request features
- **[Security Policy](SECURITY.md)** - Responsible disclosure
- **[Code of Conduct](CODE_OF_CONDUCT.md)** - Community guidelines

---

## 📝 License

MIT © 2024 - See [LICENSE](LICENSE) for details

---

<div align="center">

**[⭐ Star on GitHub](https://github.com/GeneticxCln/ollcoder)** · **[📚 Read the Docs](docs/)** · **[🐛 Report Bug](https://github.com/GeneticxCln/ollcoder/issues)** · **[💬 Discussions](https://github.com/GeneticxCln/ollcoder/discussions)**

*Built with ❤️ for developers who want AI that learns*

</div>
