from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .context_cache import ContextCache
from .context_cache import provider_fingerprint as _provider_fp
from .context_compression import CompressionLevel, compress_content
from .context_strategy import (
    ContextFile,
    ContextStrategy,
    Priority,
)
from .context_strategy import (
    build_context as build_tiered_context,
)
from .indexer import read_file_safe


def _estimate_tokens(text: str) -> int:
    # Rough heuristic: 1 token ~ 4 chars
    return max(1, len(text) // 4)


@dataclass(frozen=True)
class AdaptiveConfig:
    root_dir: str
    current_file: Optional[str] = None
    mentioned_files: Optional[List[str]] = None
    query: str = ""
    model_max_tokens: Optional[int] = None  # Full context window if known
    reserve_for_messages: int = 4096        # Reserved for system/user/output
    max_files: int = 80
    compression_level: Optional[str] = None  # Force compression level (NONE for speed)


def estimate_capacity(cfg: AdaptiveConfig) -> int:
    if cfg.model_max_tokens is not None and cfg.model_max_tokens > cfg.reserve_for_messages:
        return cfg.model_max_tokens - cfg.reserve_for_messages
    # Fallback capacity if unknown
    return 32000 - cfg.reserve_for_messages


def build_adaptive_context(
    cfg: AdaptiveConfig,
    *,
    cache: Optional[ContextCache] = None,
    provider: Any = None,
) -> Tuple[List[ContextFile], Dict[str, Any]]:
    """Build context using multi-tier strategy, then adapt to fit capacity.

    Returns (context_files, stats)
    """
    total_budget = estimate_capacity(cfg)
    
    # Fast path: if compression is explicitly disabled, skip adaptation
    skip_adaptation = cfg.compression_level == "NONE"

    strategy = ContextStrategy(
        root_dir=cfg.root_dir,
        current_file=cfg.current_file,
        mentioned_files=cfg.mentioned_files or [],
        query=cfg.query,
        max_files=cfg.max_files,
        token_budget=total_budget,
    )

    files = build_tiered_context(strategy, provider=provider)
    used = sum(_estimate_tokens(f.content) for f in files)

    # Fast path: skip adaptation if compression is disabled
    if skip_adaptation:
        # Just truncate files if needed, don't compress
        if used > total_budget:
            # Simple truncation: keep only high priority files
            files = [f for f in files if f.priority in (Priority.CRITICAL, Priority.HIGH)][:5]
            used = sum(_estimate_tokens(f.content) for f in files)
        return files, {"used_tokens": used, "budget_tokens": total_budget, "adapted": False, "fast_path": True}

    if used <= total_budget:
        return files, {"used_tokens": used, "budget_tokens": total_budget, "adapted": False}

    adapted = _adapt_to_budget(files, total_budget, cfg.root_dir, cache=cache, provider=provider)
    used2 = sum(_estimate_tokens(f.content) for f in adapted)
    return adapted, {"used_tokens": used2, "budget_tokens": total_budget, "adapted": True}


def _adapt_to_budget(
    files: List[ContextFile],
    budget: int,
    root_dir: str,
    *,
    cache: Optional[ContextCache],
    provider: Any,
) -> List[ContextFile]:
    # Work on a copy
    ctx = list(files)

    def total_tokens() -> int:
        return sum(_estimate_tokens(f.content) for f in ctx)

    def recompress(cf: ContextFile, to_level: CompressionLevel) -> Optional[ContextFile]:
        ok, content = read_file_safe(Path(cf.path))
        if not ok:
            return None
        fp = _provider_fp(provider) if cache is not None else None
        if cache is not None:
            cached = cache.get(cf.path, to_level, provider_fingerprint=fp)
            if cached is not None:
                new_meta = dict(cached.meta)
                new_meta["level"] = cached.level.name
                return ContextFile(path=cf.path, priority=cf.priority, reason=cf.reason, content=cached.content, meta=new_meta)
        result = compress_content(cf.path, content, to_level, provider=provider)
        if cache is not None:
            cache.put(result, provider_fingerprint=fp)
        new_meta2 = dict(result.meta)
        new_meta2["level"] = result.level.name
        return ContextFile(path=cf.path, priority=cf.priority, reason=cf.reason, content=result.content, meta=new_meta2)

    def current_level(cf: ContextFile) -> CompressionLevel:
        lv = (cf.meta or {}).get("level")
        try:
            return CompressionLevel[lv] if isinstance(lv, str) else CompressionLevel.NONE
        except Exception:
            # Infer from op if level missing
            op = (cf.meta or {}).get("op")
            if op == "normalize_whitespace":
                return CompressionLevel.LITE
            if op == "strip_comments":
                return CompressionLevel.NO_COMMENTS
            if op == "signatures":
                return CompressionLevel.SIGNATURES
            if op == "summary":
                return CompressionLevel.SUMMARY
            return CompressionLevel.NONE

    def levels_for_priority(p: Priority) -> List[CompressionLevel]:
        if p == Priority.CRITICAL:
            return [CompressionLevel.NONE, CompressionLevel.LITE, CompressionLevel.NO_COMMENTS, CompressionLevel.SIGNATURES]
        if p == Priority.HIGH:
            return [CompressionLevel.LITE, CompressionLevel.NO_COMMENTS, CompressionLevel.SIGNATURES, CompressionLevel.SUMMARY]
        if p == Priority.MEDIUM:
            return [CompressionLevel.NO_COMMENTS, CompressionLevel.SIGNATURES, CompressionLevel.SUMMARY]
        return [CompressionLevel.SUMMARY]

    def next_level(p: Priority, cur: CompressionLevel) -> Optional[CompressionLevel]:
        seq = levels_for_priority(p)
        try:
            i = seq.index(cur)
        except ValueError:
            i = 0
        return seq[i + 1] if i + 1 < len(seq) else None

    # If over budget, adapt: drop lower priority first, and recompress progressively
    order = [Priority.LOW, Priority.MEDIUM, Priority.HIGH, Priority.CRITICAL]

    # Pass A: try recompressing up the ladder before dropping
    for p in order:
        for idx, cf in list(enumerate(ctx)):
            if cf.priority != p:
                continue
            if total_tokens() <= budget:
                break
            nxt = next_level(p, current_level(cf))
            if nxt is None:
                continue
            new_cf = recompress(cf, nxt)
            if new_cf is not None:
                ctx[idx] = new_cf

    if total_tokens() <= budget:
        return ctx

    # Pass B: drop files starting from LOW -> MEDIUM -> HIGH (never drop CRITICAL)
    for p in order[:-1]:  # exclude CRITICAL
        # Sort candidates within priority by size descending to drop biggest first
        while total_tokens() > budget:
            candidates = [(i, _estimate_tokens(cf.content)) for i, cf in enumerate(ctx) if cf.priority == p]
            if not candidates:
                break
            drop_idx, _ = max(candidates, key=lambda t: t[1])
            del ctx[drop_idx]

    return ctx
