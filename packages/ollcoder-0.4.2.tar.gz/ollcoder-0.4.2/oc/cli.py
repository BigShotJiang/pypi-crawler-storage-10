from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .agent import AgentConfig, run_agent
from .config import AppConfig, load_config
from .context_cache import ContextCache
from .logging_util import setup_logging
from .mcp_client import MCPClient, MCPClientConfig
from .mcp_config import load_mcp_servers
from .providers.factory import create_provider
from .sandbox import Mount, SandboxConfig, SandboxRunner
from .secrets import get_gemini_api_key, get_openai_api_key, get_anthropic_api_key
from .shortcuts import KeyBindingManager
from .trusted_folders import TrustedFoldersManager, TrustLevel


def _add_build_context(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("build-context", help="Build adaptive context and print summary, JSON, or paste")
    p.add_argument("--query", default="", help="Search query to bias related files")
    p.add_argument("--current-file", dest="current_file")
    p.add_argument("--mention", dest="mentioned", action="append", default=[])
    p.add_argument("--model-max-tokens", dest="model_max_tokens", type=int)
    p.add_argument("--json", dest="json_out", action="store_true")
    p.add_argument("--paste", dest="paste", action="store_true", help="Emit Markdown code fences for web chat paste")
    p.add_argument(
        "--mcp-resource",
        dest="mcp_resources",
        action="append",
        default=[],
        help="Include MCP resource(s) as context: format is server|uri (repeatable)",
    )


def _add_trust(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("trust", help="Manage trusted folders")
    sp = p.add_subparsers(dest="trust_cmd", required=True)

    p_set = sp.add_parser("set", help="Set trust level")
    p_set.add_argument("path")
    p_set.add_argument("level", choices=[t.name for t in TrustLevel])
    p_set.add_argument("--no-persist", dest="persist", action="store_false")
    p_set.add_argument("--config", help="Path to trusted folders config JSON")

    p_status = sp.add_parser("status", help="Show trust level")
    p_status.add_argument("path", nargs="?", default=".")
    p_status.add_argument("--config", help="Path to trusted folders config JSON")


def _add_sandbox(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("sandbox", help="Run commands in container sandbox")
    sp = p.add_subparsers(dest="sbx_cmd", required=True)

    p_pull = sp.add_parser("pull", help="Pull image")
    p_pull.add_argument("--image", required=True)
    p_pull.add_argument("--engine", choices=["docker", "podman"])  # optional

    p_run = sp.add_parser("run", help="Run a command in sandbox")
    p_run.add_argument("--image", required=True)
    p_run.add_argument("--engine", choices=["docker", "podman"])  # optional
    p_run.add_argument("--cpus", type=float, default=1.0)
    p_run.add_argument("--memory", default="1g")
    p_run.add_argument("--no-network", dest="network", action="store_false", default=True)
    p_run.add_argument("--rw", dest="read_only_root", action="store_false", default=True)
    p_run.add_argument("--mount", action="append", default=[], help="host:container:ro|rw")
    p_run.add_argument("--workdir", default="/workspace")
    p_run.add_argument("--timeout", dest="timeout", type=int, default=120)
    p_run.add_argument("--user")
    p_run.add_argument("--", dest="cmd", nargs=argparse.REMAINDER, required=True)


def _add_shortcuts(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("shortcuts", help="List or write keybindings config")
    sp = p.add_subparsers(dest="sc_cmd", required=True)

    sp.add_parser("list", help="List active keybindings")
    p_write = sp.add_parser("write-defaults", help="Write default keybindings to config path")
    p_write.add_argument("--path")


def _add_checks(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("checks", help="Run linters and tests")
    sp = p.add_subparsers(dest="checks_cmd", required=True)
    sp.add_parser("run", help="Run ruff/mypy/pytest if available")


def _add_web(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("web", help="Fetch and extract web pages")
    sp = p.add_subparsers(dest="web_cmd", required=True)
    p_fetch = sp.add_parser("fetch", help="Fetch URL and print text")
    p_fetch.add_argument("--url", required=True)


def _add_security(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("security", help="Security scanning")
    sp = p.add_subparsers(dest="sec_cmd", required=True)
    p_scan = sp.add_parser("scan", help="Scan project with bandit/semgrep or heuristics")
    p_scan.add_argument("--sarif-out", dest="sarif_out", help="Write SARIF results to this path")
    p_scan.add_argument("--json", dest="json_out", action="store_true", help="Emit JSON for issues and suggestions")
    p_scan.add_argument(
        "--json-include-sarif",
        dest="json_include_sarif",
        action="store_true",
        help="When used with --json, also embed SARIF under the 'sarif' key",
    )


def _add_models(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("models", help="Personalized models utilities")
    sp = p.add_subparsers(dest="model_cmd", required=True)
    sp.add_parser("prepare-dataset", help="Create JSONL dataset from codebase")
    sp.add_parser("modelfile", help="Print an Ollama Modelfile template")
    p_oai = sp.add_parser("openai-create", help="Create an OpenAI fine-tune job")
    p_oai.add_argument("--dataset", required=True, help="Path to JSONL dataset")
    p_oai.add_argument("--base", default="gpt-4o-mini")
    p_oai.add_argument("--suffix")


def _add_agent(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("agent", help="Agent loop: observe → plan → act → verify")
    sp = p.add_subparsers(dest="agent_cmd", required=True)
    pr = sp.add_parser("run", help="Run the loop for a task")
    pr.add_argument("--task", required=True, help="Goal, e.g., 'fix failing tests' or 'add feature'")
    pr.add_argument("--max-steps", dest="max_steps", type=int, default=6)
    pr.add_argument("--apply", dest="apply", action="store_true", help="Apply file edits (trust policy enforced)")
    pr.add_argument("--include-files", dest="include_files", type=int, default=8, help="Inline context file count")
    pr.add_argument("--model-max-tokens", dest="model_max_tokens", type=int)
    pr.add_argument("--no-memory", dest="no_memory", action="store_true", help="Disable persistent memory")
    pr.add_argument("--session-id", dest="session_id", help="Explicit session ID for memory")


def _add_eco(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("eco", help="Energy-efficient coding analysis")
    sp = p.add_subparsers(dest="eco_cmd", required=True)
    sp.add_parser("analyze", help="Analyze complexity and suggest improvements")


def _add_blockchain(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("blockchain", help="Manifest and signature for code")
    sp = p.add_subparsers(dest="bc_cmd", required=True)
    p_m = sp.add_parser("manifest", help="Build SHA256 manifest")
    p_m.add_argument("--out")
    p_g = sp.add_parser("gen-keys", help="Generate ed25519 keypair")
    p_g.add_argument("--private", required=True)
    p_g.add_argument("--public", required=True)
    p_g.add_argument("--passphrase")
    p_s = sp.add_parser("sign", help="Sign manifest (ed25519)")
    p_s.add_argument("--private", required=True)
    p_s.add_argument("--passphrase")
    p_s.add_argument("--sig", required=True)
    p_v = sp.add_parser("verify", help="Verify manifest signature")
    p_v.add_argument("--public", required=True)
    p_v.add_argument("--sig", required=True)


def _add_ar(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("ar", help="AR export")
    sp = p.add_subparsers(dest="ar_cmd", required=True)
    p_exp = sp.add_parser("export", help="Export annotations JSON")
    p_exp.add_argument("--out", required=True)


def _add_predict(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("predict", help="Predictive refactoring")
    sp = p.add_subparsers(dest="pred_cmd", required=True)
    sp.add_parser("refactor", help="Suggest refactors from git history")


def _add_ethics(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("ethics", help="Ethics and bias detection")
    sp = p.add_subparsers(dest="eth_cmd", required=True)
    sp.add_parser("scan", help="Scan for bias-related terms and patterns")


def _add_multi(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("multi", help="Multi-repo orchestration")
    sp = p.add_subparsers(dest="multi_cmd", required=True)
    p_bc = sp.add_parser("build-context", help="Build context across multiple roots")
    p_bc.add_argument("--root", action="append", required=True)
    p_bc.add_argument("--query", default="")
    p_bc.add_argument("--paste", action="store_true")
    p_share = sp.add_parser("share", help="Create or join a shared session across roots")
    p_share.add_argument("--session-id", required=True)
    p_share.add_argument("--root", action="append", required=True)


def _add_watch(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("watch", help="Watch files and run a command on change")
    p.add_argument("--cmd", default="oc checks run")


def _add_memory(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("memory", help="Manage agent memory")
    sp = p.add_subparsers(dest="mem_cmd", required=True)
    
    p_list = sp.add_parser("list", help="List all sessions")
    
    p_show = sp.add_parser("show", help="Show session details")
    p_show.add_argument("--session-id", required=True)
    
    p_export = sp.add_parser("export", help="Export session to JSON")
    p_export.add_argument("--session-id", required=True)
    p_export.add_argument("--out", required=True)
    
    p_clean = sp.add_parser("cleanup", help="Remove old sessions")
    p_clean.add_argument("--days", type=int, default=30)


def _add_chat(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("chat", help="Interactive chat session with AI about your codebase")
    p.add_argument("--tui", action="store_true", help="Use full TUI interface (requires textual)")
    p.add_argument("--advanced", action="store_true", help="Use advanced TUI with all features (context builder, agent, security, etc.)")
    p.add_argument("--no-context", action="store_true", help="Disable context loading for maximum speed (pure chat mode)")


def main(argv: List[str] | None = None) -> int:
    # Load config and initialize logging before parsing subcommands (noisy libs may log during import)
    cfg: AppConfig = load_config()
    setup_logging(cfg.log_level, cfg.log_json, cfg.log_file)

    ap = argparse.ArgumentParser(prog="oc", description="Ollcoder CLI")
    # Global logging/provider overrides
    ap.add_argument("--log-level", dest="log_level", help="Override log level (DEBUG/INFO/WARNING/ERROR)")
    ap.add_argument("--log-json", dest="log_json", action="store_true", help="Enable JSON structured logs")
    ap.add_argument("--log-file", dest="log_file", help="Write logs to this file (instead of stderr)")
    ap.add_argument(
        "--provider",
        dest="provider",
        choices=["ollama", "gemini", "openai", "anthropic"],
        help="LLM provider for summarization",
    )
    ap.add_argument("--model", dest="model", help="Model for provider (e.g., mistral:latest, gemini-1.5-pro-latest)")
    ap.add_argument(
        "--api-key",
        dest="api_key",
        help="Provider API key (not recommended; prefer env like GEMINI_API_KEY)",
    )
    ap.add_argument("--no-provider", dest="no_provider", action="store_true", help="Disable LLM provider entirely")
    sp = ap.add_subparsers(dest="cmd", required=True)

    _add_chat(sp)
    _add_build_context(sp)
    _add_agent(sp)
    _add_trust(sp)
    _add_sandbox(sp)
    _add_shortcuts(sp)
    _add_checks(sp)
    _add_web(sp)
    _add_security(sp)
    _add_models(sp)
    _add_eco(sp)
    _add_blockchain(sp)
    _add_ar(sp)
    _add_predict(sp)
    _add_ethics(sp)
    _add_multi(sp)
    _add_watch(sp)
    _add_memory(sp)
    _add_mcp(sp)
    # lightweight benchmarking
    p_bench = sp.add_parser("bench", help="Benchmark context builder")
    p_bench.add_argument("--json", dest="json_out", action="store_true")

    ns = ap.parse_args(argv)

    # Re-apply logging with CLI overrides if provided
    final_level = (ns.log_level or cfg.log_level) if hasattr(ns, "log_level") else cfg.log_level
    final_json = bool(getattr(ns, "log_json", False)) or bool(cfg.log_json)
    final_file = getattr(ns, "log_file", None) or cfg.log_file
    setup_logging(final_level, final_json, final_file)

    # Build provider instance from configuration if present
    provider = None
    prov_name = (getattr(ns, "provider", None) or (cfg.provider or "")).strip().lower() if getattr(cfg, "provider", None) or getattr(ns, "provider", None) else ""
    prov_model = getattr(ns, "model", None) or (cfg.model or None) if getattr(cfg, "model", None) or getattr(ns, "model", None) else None
    
    # Auto-detect ollama if no provider specified
    if not prov_name and not getattr(ns, "no_provider", False):
        try:
            import subprocess
            result = subprocess.run(["ollama", "list"], capture_output=True, timeout=2)
            if result.returncode == 0:
                prov_name = "ollama"
                prov_model = "mistral:latest"
        except Exception:
            pass
    
    if prov_name and not getattr(ns, "no_provider", False):
        if prov_model is None:
            if prov_name == "gemini":
                prov_model = "gemini-1.5-pro-latest"
            elif prov_name == "openai":
                prov_model = "gpt-4o-mini"
            elif prov_name == "anthropic":
                prov_model = "claude-3-5-sonnet-latest"
            else:
                prov_model = "mistral:latest"
        # API key selection per provider; CLI flag wins over env
        api_key = None
        if prov_name == "gemini":
            api_key = getattr(ns, "api_key", None) or get_gemini_api_key(optional=True)
        elif prov_name == "openai":
            api_key = getattr(ns, "api_key", None) or get_openai_api_key(optional=True)
        elif prov_name == "anthropic":
            api_key = getattr(ns, "api_key", None) or get_anthropic_api_key(optional=True)
        try:
            provider = create_provider(prov_name, prov_model, api_key=api_key)
        except Exception:
            provider = None

    if ns.cmd == "chat":
        model_name = prov_model or "mistral:latest"
        no_context = getattr(ns, "no_context", False)
        if getattr(ns, "advanced", False):
            from .tui_advanced import run_advanced_tui
            return run_advanced_tui(os.getcwd(), provider, model_name, prov_name or "ollama")
        elif getattr(ns, "tui", False):
            from .tui import run_tui
            return run_tui(os.getcwd(), provider, model_name, prov_name or "ollama")
        else:
            from .chat import run_chat
            return run_chat(os.getcwd(), provider, model_name, no_context=no_context)

    if ns.cmd == "bench":
        from .benchmark import benchmark_context, to_json as bench_to_json
        res = benchmark_context(os.getcwd(), provider=provider)
        if getattr(ns, "json_out", False):
            print(bench_to_json(res))
        else:
            print(f"Duration: {res.duration_sec:.3f}s, Peak: {res.peak_mb:.2f} MB, Files: {res.files_count}, Tokens: {res.used_tokens}")
        return 0

    if ns.cmd == "build-context":
        root = os.getcwd()
        cache = ContextCache(root, ttl_seconds=load_config().cache_ttl_seconds)
        cfg = AdaptiveConfig(
            root_dir=root,
            current_file=ns.current_file,
            mentioned_files=ns.mentioned,
            query=ns.query,
            model_max_tokens=ns.model_max_tokens,
        )
        files, stats = build_adaptive_context(cfg, cache=cache, provider=provider)
        # Optionally include MCP resources
        if getattr(ns, "mcp_resources", None):
            from .context_strategy import ContextFile, Priority
            servers = load_mcp_servers()
            for spec in ns.mcp_resources:
                if not spec or "|" not in spec:
                    continue
                server_name, uri = spec.split("|", 1)
                srv = servers.get(server_name)
                if not srv:
                    continue
                client = MCPClient(MCPClientConfig(command=tuple(srv.command), cwd=srv.cwd, env=srv.env))
                try:
                    result = client.read_resource(uri)
                finally:
                    client.close()
                # Heuristic extraction: prefer first text content
                text = ""
                try:
                    contents = result.get("contents") or []
                    for ent in contents:
                        if isinstance(ent, dict) and ent.get("text"):
                            text = ent["text"]
                            break
                except Exception:
                    text = ""
                cf = ContextFile(
                    path=f"mcp://{server_name}/{uri}",
                    priority=Priority.HIGH,
                    reason="MCP resource",
                    content=text,
                    meta={"language": "text", "level": "NONE", "mcp_server": server_name},
                )
                files.append(cf)
        if ns.paste:
            from .export import format_for_web

            print(format_for_web(files))
            return 0
        if ns.json_out:
            out = {
                "stats": stats,
                "files": [
                    {
                        "path": f.path,
                        "priority": f.priority.name,
                        "reason": f.reason,
                        "level": (f.meta or {}).get("level"),
                        "tokens": max(1, len(f.content) // 4),
                    }
                    for f in files
                ],
            }
            print(json.dumps(out, indent=2))
        else:
            print(f"Used {stats['used_tokens']}/{stats['budget_tokens']} tokens (adapted={stats['adapted']}).")
            for f in files:
                print(f"- [{f.priority.name}] {f.path} ({(f.meta or {}).get('level')}) — {f.reason}")
        return 0

    if ns.cmd == "agent":
        # Agent orchestration requires a provider
        if provider is None:
            print("Provider required for agent. Pass --provider and --model.")
            return 2
        if ns.agent_cmd == "run":
            ag_cfg = AgentConfig(
                root_dir=os.getcwd(),
                task=ns.task,
                max_steps=int(getattr(ns, "max_steps", 6) or 6),
                apply_changes=bool(getattr(ns, "apply", False)),
                model_max_tokens=getattr(ns, "model_max_tokens", None),
                include_files=int(getattr(ns, "include_files", 8) or 8),
                use_memory=not bool(getattr(ns, "no_memory", False)),
                session_id=getattr(ns, "session_id", None),
            )
            result = run_agent(ag_cfg, provider=provider)
            # Structured summary to stdout
            print(f"Agent success: {result.success}")
            for st in result.steps:
                print(f"Step {st.step}: action={st.action}")
                if st.plan:
                    print("Plan: " + "; ".join(st.plan))
                for d in st.diffs[:3]:
                    print(d)
                if st.checks:
                    print(f"Checks worst status: {st.checks_status}")
            print(result.final_message)
            return 0 if result.success else 1

    if ns.cmd == "trust":
        mgr = TrustedFoldersManager(config_path=getattr(ns, "config", None) or load_config().trust_config_path)
        if ns.trust_cmd == "set":
            lvl = TrustLevel[ns.level]
            mgr.set_level(ns.path, lvl, persist=ns.persist)
            print(f"Set {ns.path} -> {lvl.name} (persist={ns.persist})")
            return 0
        if ns.trust_cmd == "status":
            lvl = mgr.get_level(ns.path)
            print(lvl.name)
            return 0

    if ns.cmd == "sandbox":
        if ns.sbx_cmd == "pull":
            pull_cfg = SandboxConfig(image=ns.image, engine=ns.engine)
            rr = SandboxRunner(pull_cfg).pull()
            print(rr.stdout or rr.stderr)
            return 0 if rr.ok else rr.exit_code
        if ns.sbx_cmd == "run":
            mounts = []
            for m in ns.mount:
                host, cont, mode = m.split(":")
                mounts.append(Mount(host, cont, read_only=(mode != "rw")))
            sbx_cfg = SandboxConfig(
                image=ns.image,
                engine=ns.engine,
                workdir=ns.workdir,
                mounts=tuple(mounts),
                network_isolation=bool(ns.network),
                read_only_root=bool(ns.read_only_root),
                cpus=float(ns.cpus),
                memory=ns.memory,
                timeout_seconds=int(ns.timeout),
                user=ns.user,
            )
            # Strip the leading '--' if present
            cmd = [c for c in ns.cmd if c != "--"]
            rr = SandboxRunner(sbx_cfg).run(cmd)
            print(rr.stdout)
            if rr.stderr:
                print(rr.stderr, file=sys.stderr)
            return 0 if rr.ok else rr.exit_code

    if ns.cmd == "shortcuts":
        km = KeyBindingManager()
        if ns.sc_cmd == "list":
            for row in km.list_bindings():
                print(f"{row['keys']}: {row['command']} - {row['description']}")
            return 0
        if ns.sc_cmd == "write-defaults":
            km.save(ns.path)
            print("Keybindings written")
            return 0

    if ns.cmd == "checks" and ns.checks_cmd == "run":
        from .checks import ChecksConfig, run_checks

        results, worst = run_checks(ChecksConfig())
        for chk in results:
            status = "OK" if chk.ok else f"FAIL ({chk.exit_code})"
            print(f"$ {' '.join(chk.cmd)} -> {status}")
            if chk.stdout.strip():
                print(chk.stdout)
            if chk.stderr.strip():
                print(chk.stderr)
        return worst

    if ns.cmd == "web" and ns.web_cmd == "fetch":
        from .web_fetch import fetch_url

        text, title = fetch_url(ns.url)
        if title:
            print(f"# {title}\n")
        print(text)
        return 0

    if ns.cmd == "security" and ns.sec_cmd == "scan":
        from .security import scan, suggest_fixes, suggest_fixes_structured, to_sarif

        root = os.getcwd()
        sec_issues = scan(root)
        if getattr(ns, "json_out", False):
            payload = {
                "issues": [
                    {
                        "path": s.path,
                        "line": s.line,
                        "severity": s.severity,
                        "rule": s.rule,
                        "message": s.message,
                    }
                    for s in sec_issues
                ],
            }
            sugg_s, stats = suggest_fixes_structured(root, provider=provider)
            payload["suggestions"] = sugg_s
            payload["stats"] = stats
            if getattr(ns, "json_include_sarif", False):
                payload["sarif"] = to_sarif(sec_issues)
            print(json.dumps(payload, indent=2))
            # still allow SARIF output if requested
            if getattr(ns, "sarif_out", None):
                import json as _json
                sarif = to_sarif(sec_issues)
                with open(ns.sarif_out, "w", encoding="utf-8") as fh:
                    _json.dump(sarif, fh, indent=2)
                print(f"Wrote SARIF to {ns.sarif_out}")
            return 0

        for s in sec_issues:
            print(f"{s.severity}: {s.path}:{s.line or 0} {s.rule} - {s.message}")
        if getattr(ns, "sarif_out", None):
            import json as _json
            sarif = to_sarif(sec_issues)
            with open(ns.sarif_out, "w", encoding="utf-8") as fh:
                _json.dump(sarif, fh, indent=2)
            print(f"Wrote SARIF to {ns.sarif_out}")
        sugg, stats = suggest_fixes(root, provider=provider)
        print("\nSuggestions:")
        for sg in sugg:
            print(f"- {sg}")
        return 0

    if ns.cmd == "models" and ns.model_cmd == "prepare-dataset":
        from .fine_tune import collect_code_pairs, write_jsonl

        samples = collect_code_pairs(os.getcwd())
        outp = os.path.join(os.getcwd(), "fine_tune.jsonl")
        n = write_jsonl(samples, outp)
        print(f"Wrote {n} samples to {outp}")
        return 0

    if ns.cmd == "models" and ns.model_cmd == "modelfile":
        from .fine_tune import generate_modelfile

        print(generate_modelfile())
        return 0

    if ns.cmd == "models" and ns.model_cmd == "openai-create":
        # Best-effort: may fail without openai installed or network
        try:
            from .fine_tune import openai_create_fine_tune
        except Exception as e:  # pragma: no cover - graceful import failure
            print(str(e), file=sys.stderr)
            return 2
        try:
            job_id = openai_create_fine_tune(ns.dataset, base_model=ns.base, suffix=ns.suffix)
        except Exception as e:
            print(f"Failed to create job: {e}", file=sys.stderr)
            return 2
        print(job_id)
        return 0

    if ns.cmd == "eco" and ns.eco_cmd == "analyze":
        from .eco import analyze, estimate_carbon

        eco_issues = analyze(os.getcwd())
        for e in eco_issues:
            print(f"{e.path}:{e.line} {e.kind} {e.score} - {e.message}")
        # Rough estimate using context size  (optional, demonstrates API)
        print(f"Estimated carbon per 20k tokens: {estimate_carbon(20000):.6f} kg CO2e")
        return 0

    if ns.cmd == "blockchain":
        from .blockchain import (
            build_manifest,
            generate_keypair,
            read_signature,
            save_signature,
            sign_manifest,
            verify_manifest,
        )

        if ns.bc_cmd == "manifest":
            entries = build_manifest(os.getcwd())
            if ns.out:
                with open(ns.out, "w", encoding="utf-8") as fh:
                    for ent in entries:
                        fh.write(f"{ent.sha256}  {ent.path}\n")
                print(ns.out)
                return 0
            for ent in entries[:50]:
                print(f"{ent.sha256}  {ent.path}")
            print(f"Total: {len(entries)} files")
            return 0
        if ns.bc_cmd == "gen-keys":
            generate_keypair(ns.private, ns.public, passphrase=ns.passphrase)
            print(f"Wrote {ns.private} and {ns.public}")
            return 0
        if ns.bc_cmd == "sign":
            entries = build_manifest(os.getcwd())
            sig = sign_manifest(entries, ns.private, passphrase=ns.passphrase)
            save_signature(sig, ns.sig)
            print(ns.sig)
            return 0
        if ns.bc_cmd == "verify":
            entries = build_manifest(os.getcwd())
            ok = verify_manifest(entries, read_signature(ns.sig), ns.public)
            print("OK" if ok else "FAIL")
            return 0

    if ns.cmd == "ar" and ns.ar_cmd == "export":
        from .ar import export_annotations

        root = os.getcwd()
        files, _ = build_adaptive_context(AdaptiveConfig(root_dir=root), cache=ContextCache(root), provider=provider)
        outp = ns.out
        export_annotations(files, outp)
        print(outp)
        return 0

    if ns.cmd == "predict" and ns.pred_cmd == "refactor":
        from .predictor import analyze_git

        predictions = analyze_git(os.getcwd())
        for pred in predictions:
            print(f"- {pred.path}: {pred.reason}")
        return 0

    if ns.cmd == "ethics" and ns.eth_cmd == "scan":
        from .ethics import scan as ethics_scan

        eth_issues = ethics_scan(os.getcwd())
        for e2 in eth_issues[:200]:
            print(f"{e2.path}:{e2.line} {e2.kind} - {e2.message}")
        return 0

    if ns.cmd == "multi" and ns.multi_cmd == "build-context":
        from .export import format_for_web
        from .multi import build_multi_context
        roots = ns.root
        pairs = build_multi_context(roots, query=ns.query, provider=provider)
        if ns.paste:
            # Minimal combined paste: show paths only (content would duplicate)
            for root_name, pth in pairs:
                print(f"- {root_name}: {pth}")
            return 0
        for root_name, pth in pairs[:50]:
            print(f"- {root_name}: {pth}")
        return 0

    if ns.cmd == "multi" and ns.multi_cmd == "share":
        from .multi import open_shared_session
        sid = open_shared_session(ns.session_id, ns.root)
        print(f"Shared session ready: {sid}")
        return 0

    if ns.cmd == "watch":
        from .watch import WatchConfig, watch

        return watch(WatchConfig(root=os.getcwd(), command=ns.cmd))

    if ns.cmd == "memory":
        from .memory import global_memory

        mem = global_memory()
        if ns.mem_cmd == "list":
            for sid, session in mem.sessions.items():
                summary = mem.get_session_summary(sid)
                print(f"Session: {sid}")
                print(f"  Root: {summary['root_dir']}")
                print(f"  Tasks: {summary['successful_tasks']}/{summary['total_tasks']} successful")
                print(f"  Patterns learned: {summary['patterns_learned']}")
                print("")
            return 0
        if ns.mem_cmd == "show":
            summary = mem.get_session_summary(ns.session_id)
            if not summary:
                print(f"Session {ns.session_id} not found")
                return 1
            print(json.dumps(summary, indent=2))
            return 0
        if ns.mem_cmd == "export":
            mem.export_session(ns.session_id, ns.out)
            print(f"Exported session to {ns.out}")
            return 0
        if ns.mem_cmd == "cleanup":
            removed = mem.cleanup_old_sessions(ns.days)
            print(f"Removed {removed} old sessions (older than {ns.days} days)")
            return 0

    if ns.cmd == "mcp":
        from .mcp_client import MCPClient, MCPClientConfig
        from .mcp_config import load_mcp_servers
        servers = load_mcp_servers()
        if ns.mcp_cmd == "list-servers":
            for name, srv in servers.items():
                print(f"{name}: {' '.join(srv.command)}")
            return 0
        if ns.mcp_cmd == "rpc":
            server = servers.get(ns.server)
            if not server:
                print(f"Unknown MCP server: {ns.server}", file=sys.stderr)
                return 2
            params = None
            if getattr(ns, "params_json", None):
                try:
                    params = json.loads(ns.params_json)
                except Exception:
                    print("Invalid --params-json", file=sys.stderr)
                    return 2
            cfg = MCPClientConfig(command=tuple(server.command), cwd=server.cwd, env=server.env)
            client = MCPClient(cfg)
            try:
                result = client.rpc(ns.method, params)
            finally:
                client.close()
            print(json.dumps(result, indent=2))
            return 0
        if ns.mcp_cmd == "resources" and ns.mcp_res_cmd == "list":
            server = servers.get(ns.server)
            if not server:
                print(f"Unknown MCP server: {ns.server}", file=sys.stderr)
                return 2
            client = MCPClient(MCPClientConfig(command=tuple(server.command), cwd=server.cwd, env=server.env))
            try:
                res = client.list_resources()
            finally:
                client.close()
            print(json.dumps(res, indent=2))
            return 0
        if ns.mcp_cmd == "resources" and ns.mcp_res_cmd == "read":
            server = servers.get(ns.server)
            if not server:
                print(f"Unknown MCP server: {ns.server}", file=sys.stderr)
                return 2
            client = MCPClient(MCPClientConfig(command=tuple(server.command), cwd=server.cwd, env=server.env))
            try:
                res = client.read_resource(ns.uri)
            finally:
                client.close()
            print(json.dumps(res, indent=2))
            return 0
        if ns.mcp_cmd == "tools" and ns.mcp_tools_cmd == "list":
            server = servers.get(ns.server)
            if not server:
                print(f"Unknown MCP server: {ns.server}", file=sys.stderr)
                return 2
            client = MCPClient(MCPClientConfig(command=tuple(server.command), cwd=server.cwd, env=server.env))
            try:
                res = client.list_tools()
            finally:
                client.close()
            print(json.dumps(res, indent=2))
            return 0
        if ns.mcp_cmd == "tools" and ns.mcp_tools_cmd == "call":
            server = servers.get(ns.server)
            if not server:
                print(f"Unknown MCP server: {ns.server}", file=sys.stderr)
                return 2
            args = None
            if getattr(ns, "args_json", None):
                try:
                    args = json.loads(ns.args_json)
                except Exception:
                    print("Invalid --args-json", file=sys.stderr)
                    return 2
            client = MCPClient(MCPClientConfig(command=tuple(server.command), cwd=server.cwd, env=server.env))
            try:
                res = client.call_tool(ns.name, arguments=args or {})
            finally:
                client.close()
            print(json.dumps(res, indent=2))
            return 0

    return 1

def _add_mcp(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("mcp", help="Model Context Protocol client")
    sp = p.add_subparsers(dest="mcp_cmd", required=True)

    sp.add_parser("list-servers", help="List configured MCP servers")

    p_rpc = sp.add_parser("rpc", help="Generic JSON-RPC call")
    p_rpc.add_argument("--server", required=True)
    p_rpc.add_argument("--method", required=True)
    p_rpc.add_argument("--params-json")

    p_res = sp.add_parser("resources", help="Resource operations")
    sp_res = p_res.add_subparsers(dest="mcp_res_cmd", required=True)
    p_res_list = sp_res.add_parser("list", help="List resources")
    p_res_list.add_argument("--server", required=True)
    p_res_read = sp_res.add_parser("read", help="Read a resource by URI")
    p_res_read.add_argument("--server", required=True)
    p_res_read.add_argument("--uri", required=True)

    p_tools = sp.add_parser("tools", help="Tool operations")
    sp_tools = p_tools.add_subparsers(dest="mcp_tools_cmd", required=True)
    p_tools_list = sp_tools.add_parser("list", help="List tools")
    p_tools_list.add_argument("--server", required=True)
    p_tools_call = sp_tools.add_parser("call", help="Call a tool")
    p_tools_call.add_argument("--server", required=True)
    p_tools_call.add_argument("--name", required=True)
    p_tools_call.add_argument("--args-json")
