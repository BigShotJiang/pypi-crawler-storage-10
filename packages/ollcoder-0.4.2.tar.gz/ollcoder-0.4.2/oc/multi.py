from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Iterable, List, Tuple
from .memory import global_memory

from .adaptive_builder import AdaptiveConfig, build_adaptive_context


@dataclass(frozen=True)
class MultiContextResult:
    files: List[Tuple[str, str]]  # (root, path)


def build_multi_context(
    roots: Iterable[str],
    query: str = "",
    model_max_tokens: int | None = None,
    *,
    provider: Any | None = None,
) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for root in roots:
        files, _ = build_adaptive_context(
            AdaptiveConfig(root_dir=os.path.abspath(root), query=query, model_max_tokens=model_max_tokens),
            cache=None,
            provider=provider,
        )
        for f in files:
            out.append((root, f.path))
    return out


def open_shared_session(session_id: str, roots: Iterable[str]) -> str:
    """Ensure a shared memory session exists for collaborating across repos.

    Returns the session_id (created if needed). Use this ID with `oc agent run`'s
    --session-id in each repo to share memory.
    """
    mem = global_memory()
    # Create or update a neutral session bound to the first root
    roots = list(roots)
    root0 = os.path.abspath(roots[0]) if roots else os.getcwd()
    mem.get_or_create_session(root0, session_id=session_id)
    return session_id
