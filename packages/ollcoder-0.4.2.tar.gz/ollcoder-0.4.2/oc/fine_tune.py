from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional


@dataclass(frozen=True)
class Sample:
    prompt: str
    completion: str


def collect_code_pairs(root: str, max_files: int = 200) -> List[Sample]:
    out: List[Sample] = []
    count = 0
    for p in Path(root).rglob("*.py"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        # Simple heuristic: docstring/comment -> completion (code)
        prompt = f"File: {p.name}\nSummarize and propose improvements"
        out.append(Sample(prompt=prompt, completion=text[:4000]))
        count += 1
        if count >= max_files:
            break
    return out


def write_jsonl(samples: Iterable[Sample], path: str) -> int:
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for s in samples:
            f.write(json.dumps({"prompt": s.prompt, "completion": s.completion}) + "\n")
            n += 1
    return n


def generate_modelfile(base: str = "qwen2.5-coder:latest") -> str:
    return (
        f"FROM {base}\n"
        "# Add your system prompt, adapters, or LoRA here.\n"
        "PARAMETER temperature 0.2\n"
    )


# ---- Optional: OpenAI fine-tune helper ---- #
try:  # pragma: no cover - optional dependency
    from openai import OpenAI  # type: ignore
except Exception:  # pragma: no cover
    OpenAI = None  # type: ignore


def openai_create_fine_tune(
    dataset_path: str,
    base_model: str = "gpt-4o-mini",
    suffix: Optional[str] = None,
) -> str:
    """Create an OpenAI fine-tuning job for the given JSONL dataset.

    Returns the job ID. Requires OPENAI_API_KEY and openai>=1.0 installed.
    """
    if OpenAI is None:
        raise RuntimeError("openai package not installed. pip install openai>=1.0.0")
    client = OpenAI()
    # Upload file
    with open(dataset_path, "rb") as fh:
        file_obj = client.files.create(file=fh, purpose="fine-tune")
    job = client.fine_tuning.jobs.create(training_file=file_obj.id, model=base_model, suffix=suffix)
    return job.id
