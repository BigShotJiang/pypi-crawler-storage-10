from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

REDACTED = "***REDACTED***"


def redact(value: Optional[str]) -> str:
    if not value:
        return ""
    # Keep only last 4 chars for debugging uniqueness
    tail = value[-4:] if len(value) > 8 else ""
    return f"{REDACTED}{tail}"


def getenv_strict(name: str) -> str:
    v = os.environ.get(name)
    if not v:
        raise RuntimeError(f"Missing required secret: {name}")
    return v


def get_gemini_api_key(optional: bool = True) -> Optional[str]:
    # Support multiple env names commonly used
    for k in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GENAI_API_KEY"):
        v = os.environ.get(k)
        if v:
            return v
    return None if optional else getenv_strict("GEMINI_API_KEY")


def get_openai_api_key(optional: bool = True) -> Optional[str]:
    for k in ("OPENAI_API_KEY",):
        v = os.environ.get(k)
        if v:
            return v
    return None if optional else getenv_strict("OPENAI_API_KEY")


def get_anthropic_api_key(optional: bool = True) -> Optional[str]:
    for k in ("ANTHROPIC_API_KEY",):
        v = os.environ.get(k)
        if v:
            return v
    return None if optional else getenv_strict("ANTHROPIC_API_KEY")


@dataclass(frozen=True)
class ProviderSettings:
    name: str = "ollama"  # "ollama" | "gemini" | "openai" | "anthropic"
    model: str = "mistral:latest"
    api_key: Optional[str] = None  # used for providers that require it


def load_provider_settings() -> ProviderSettings:
    name = (os.environ.get("OC_PROVIDER") or "ollama").strip().lower()
    if name == "gemini":
        default_model = "gemini-1.5-pro-latest"
        api_key = get_gemini_api_key(optional=True)
    elif name == "openai":
        default_model = "gpt-4o-mini"
        api_key = get_openai_api_key(optional=True)
    elif name == "anthropic":
        default_model = "claude-3-5-sonnet-latest"
        api_key = get_anthropic_api_key(optional=True)
    else:
        default_model = "mistral:latest"
        api_key = None
    model = os.environ.get("OC_MODEL") or default_model
    return ProviderSettings(name=name, model=model, api_key=api_key)
