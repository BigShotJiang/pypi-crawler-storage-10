from __future__ import annotations

import ast
import io
import re
import tokenize
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .analysis import analyze_text


class CompressionLevel(Enum):
    """Five compression levels from no compression to LLM summary."""

    NONE = 0
    LITE = 1  # normalize whitespace only
    NO_COMMENTS = 2  # remove comments and (for Python) docstrings
    SIGNATURES = 3  # AST/regex-based signature extraction
    SUMMARY = 4  # LLM (or heuristic) summary of the file


@dataclass(frozen=True)
class CompressedResult:
    path: str
    level: CompressionLevel
    original_bytes: int
    compressed_bytes: int
    content: str
    meta: Dict[str, Any]


def compress_content(
    path: str,
    content: str,
    level: CompressionLevel,
    *,
    provider: Any | None = None,
    summary_max_chars: int = 12_000,
) -> CompressedResult:
    """Compress file content according to the selected level.

    provider: Optional chat provider implementing chat(messages: List[Dict[str, str]], stream: bool=False)
              Used only for SUMMARY level.
    summary_max_chars: Hard cap on characters included in LLM prompt to control costs.
    """
    lang = _language_from_path(path)
    original_bytes = len(content.encode("utf-8", errors="replace"))

    if level is CompressionLevel.NONE:
        out = content
        meta: Dict[str, Any] = {"language": lang}
    elif level is CompressionLevel.LITE:
        out = _normalize_whitespace(content)
        meta = {"language": lang, "op": "normalize_whitespace"}
    elif level is CompressionLevel.NO_COMMENTS:
        if lang == "python":
            out = _strip_comments_and_docstrings_py(content)
        else:
            out = _strip_comments_generic(content)
        out = _normalize_whitespace(out)
        meta = {"language": lang, "op": "strip_comments"}
    elif level is CompressionLevel.SIGNATURES:
        out, meta = _extract_signatures(path, content, lang)
    elif level is CompressionLevel.SUMMARY:
        out, meta = _summarize_file(path, content, lang, provider=provider, max_chars=summary_max_chars)
    else:  # pragma: no cover - defensive
        out = content
        meta = {"language": lang}

    compressed_bytes = len(out.encode("utf-8", errors="replace"))
    return CompressedResult(
        path=str(path),
        level=level,
        original_bytes=original_bytes,
        compressed_bytes=compressed_bytes,
        content=out,
        meta=meta,
    )


# -------- Helpers: Language detection -------- #

def _language_from_path(path: str) -> str:
    suffix = Path(path).suffix.lower()
    if suffix == ".py":
        return "python"
    if suffix in {".ts", ".tsx", ".js", ".mjs", ".cjs"}:
        return "js/ts"
    if suffix == ".go":
        return "go"
    if suffix in {".java", ".kt"}:
        return "jvm"
    return suffix.lstrip(".") or "text"


# -------- Helpers: Whitespace -------- #

def _normalize_whitespace(text: str) -> str:
    # Strip trailing spaces and collapse 3+ blank lines to at most 1
    lines = [ln.rstrip() for ln in text.splitlines()]
    out_lines: List[str] = []
    blank_run = 0
    for ln in lines:
        if ln.strip() == "":
            blank_run += 1
            if blank_run <= 1:
                out_lines.append("")
        else:
            blank_run = 0
            out_lines.append(ln)
    return "\n".join(out_lines) + ("\n" if text.endswith("\n") else "")


# -------- Helpers: Python comment + docstring stripping -------- #

def _strip_comments_and_docstrings_py(src: str) -> str:
    # 1) Remove docstrings by deleting lines for docstring Expr nodes
    docstring_spans = _find_python_docstring_spans(src)
    if docstring_spans:
        src = _remove_line_spans(src, docstring_spans)

    # 2) Remove comments using tokenize while preserving code formatting
    try:
        rl = io.StringIO(src).readline
        tokens = list(tokenize.generate_tokens(rl))
        new_tokens: List[tokenize.TokenInfo] = []
        for tok in tokens:
            if tok.type == tokenize.COMMENT:
                continue
            new_tokens.append(tok)
        out = tokenize.untokenize(new_tokens)
        return out
    except Exception:
        # Fallback to a conservative regex that removes only full-line comments
        return _strip_comments_full_line_only(src)


def _find_python_docstring_spans(src: str) -> List[Tuple[int, int]]:
    spans: List[Tuple[int, int]] = []
    try:
        tree = ast.parse(src)
    except Exception:
        return spans

    def maybe_add(node: ast.AST) -> None:
        body = getattr(node, "body", [])
        if not body:
            return
        first = body[0]
        if isinstance(first, ast.Expr):
            val = getattr(first, "value", None)
            if isinstance(val, ast.Constant) and isinstance(val.value, str):
                start = getattr(first, "lineno", None)
                end = getattr(first, "end_lineno", start)
                if start is not None and end is not None:
                    spans.append((start, end))

    maybe_add(tree)  # module docstring
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            maybe_add(n)
    # Merge overlapping/adjacent spans
    spans.sort()
    merged: List[Tuple[int, int]] = []
    for s in spans:
        if not merged:
            merged.append(s)
        else:
            last_s, last_e = merged[-1]
            if s[0] <= last_e + 1:
                merged[-1] = (last_s, max(last_e, s[1]))
            else:
                merged.append(s)
    return merged


def _remove_line_spans(src: str, spans: Iterable[Tuple[int, int]]) -> str:
    lines = src.splitlines()
    to_skip = set()
    for a, b in spans:
        for i in range(max(a, 1) - 1, min(b, len(lines))):
            to_skip.add(i)
    kept = [ln for i, ln in enumerate(lines) if i not in to_skip]
    return "\n".join(kept) + ("\n" if src.endswith("\n") else "")


def _strip_comments_full_line_only(src: str) -> str:
    out_lines: List[str] = []
    for ln in src.splitlines():
        s = ln.lstrip()
        if s.startswith("#"):
            out_lines.append("")
        else:
            out_lines.append(ln)
    return "\n".join(out_lines) + ("\n" if src.endswith("\n") else "")


# -------- Helpers: Generic (C/JS/Go-style) comment stripping -------- #

def _strip_comments_generic(src: str) -> str:
    # Remove // line comments and /* ... */ block comments while respecting strings
    out: List[str] = []
    i = 0
    n = len(src)
    in_sl_comment = False
    in_ml_comment = False
    in_str: Optional[str] = None  # one of ' " `
    esc = False

    while i < n:
        ch = src[i]
        nxt = src[i + 1] if i + 1 < n else ""

        if in_sl_comment:
            if ch == "\n":
                in_sl_comment = False
                out.append(ch)
            # else: skip
            i += 1
            continue

        if in_ml_comment:
            if ch == "*" and nxt == "/":
                in_ml_comment = False
                i += 2
                continue
            i += 1
            continue

        if in_str is not None:
            out.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == in_str:
                in_str = None
            i += 1
            continue

        # Not in string/comment
        if ch == "/" and nxt == "/":
            in_sl_comment = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            in_ml_comment = True
            i += 2
            continue
        if ch in {'\'', '"', '`'}:
            in_str = ch
            out.append(ch)
            i += 1
            continue

        out.append(ch)
        i += 1

    return "".join(out)


# -------- Helpers: Signature extraction -------- #

def _extract_signatures(path: str, src: str, lang: str) -> Tuple[str, Dict[str, Any]]:
    if lang == "python":
        text = _extract_signatures_python(src)
        return text, {"language": lang, "op": "signatures"}
    if lang == "js/ts":
        text = _extract_signatures_jsts(src)
        return text, {"language": lang, "op": "signatures"}
    if lang == "go":
        text = _extract_signatures_go(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"java", "jvm"}:
        text = _extract_signatures_java(src)
        return text, {"language": "java", "op": "signatures"}
    if lang in {"c", "cpp"}:
        text = _extract_signatures_c_cpp(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"rust"}:
        text = _extract_signatures_rust(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"swift"}:
        text = _extract_signatures_swift(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"kotlin"}:
        text = _extract_signatures_kotlin(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"csharp"}:
        text = _extract_signatures_csharp(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"php"}:
        text = _extract_signatures_php(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"ruby"}:
        text = _extract_signatures_ruby(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"scala"}:
        text = _extract_signatures_scala(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"haskell"}:
        text = _extract_signatures_hs(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"bash", "sh"}:
        text = _extract_signatures_sh(src)
        return text, {"language": "bash", "op": "signatures"}
    if lang in {"lua"}:
        text = _extract_signatures_lua(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"perl"}:
        text = _extract_signatures_pl(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"r"}:
        text = _extract_signatures_r(src)
        return text, {"language": lang, "op": "signatures"}
    if lang in {"objc"}:
        text = _extract_signatures_objc(src)
        return text, {"language": lang, "op": "signatures"}

    # Generic: list of headings + basic stats
    analysis = analyze_text(path, src)
    lines = [f"# Symbols for {Path(path).name}"]
    for k in ("functions", "classes", "imports"):
        if k in analysis and analysis[k]:
            lines.append(f"{k}: {analysis[k]}")
    return "\n".join(lines) + "\n", {"language": lang, "op": "signatures"}


def _extract_signatures_python(src: str) -> str:
    try:
        tree = ast.parse(src)
    except Exception:
        return "# Unable to parse Python file for signatures\n"

    lines: List[str] = []
    imports: List[str] = []

    class SigVisitor(ast.NodeVisitor):
        def visit_Import(self, node: ast.Import) -> None:  # type: ignore[override]
            names = ", ".join([a.asname and f"{a.name} as {a.asname}" or a.name for a in node.names])
            imports.append(f"import {names}")

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:  # type: ignore[override]
            mod = node.module or ""
            names = ", ".join([a.asname and f"{a.name} as {a.asname}" or a.name for a in node.names])
            level = node.level or 0
            dots = "." * level
            imports.append(f"from {dots}{mod} import {names}")

        def visit_ClassDef(self, node: ast.ClassDef) -> None:  # type: ignore[override]
            bases = []
            for b in node.bases:
                bases.append(_unparse_expr(b))
            base_txt = f"({', '.join(bases)})" if bases else ""
            lines.append(f"class {node.name}{base_txt}:")
            # Indent methods
            for n in node.body:
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    sig = _format_function_signature(n)
                    lines.append(f"    {sig}")
            if not any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in node.body):
                lines.append("    pass")

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:  # type: ignore[override]
            lines.append(_format_function_signature(node))

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:  # type: ignore[override]
            lines.append(_format_function_signature(node, is_async=True))

    SigVisitor().visit(tree)

    out: List[str] = []
    if imports:
        out.append("# imports")
        out.extend(imports)
        out.append("")
    if lines:
        out.append("# signatures")
        out.extend(lines)
    else:
        out.append("# no functions/classes detected")
    out.append("")
    return "\n".join(out)


def _format_function_signature(n: ast.AST, is_async: bool | None = None) -> str:
    if isinstance(n, ast.AsyncFunctionDef):
        is_async = True
    if isinstance(n, ast.FunctionDef):
        name = n.name
        args = n.args
        sig = _format_arguments(args)
        ret = getattr(n, "returns", None)
        ret_s = f" -> {_unparse_expr(ret)}" if ret is not None else ""
        prefix = "async def" if is_async else "def"
        return f"{prefix} {name}({sig}){ret_s}: ..."
    return "# unsupported node"


def _format_arguments(a: ast.arguments) -> str:
    parts: List[str] = []

    def fmt_arg(arg: ast.arg, default: Optional[ast.expr] = None) -> str:
        ann = f": {_unparse_expr(arg.annotation)}" if getattr(arg, "annotation", None) is not None else ""
        if default is not None:
            return f"{arg.arg}{ann}={_unparse_expr(default)}"
        return f"{arg.arg}{ann}"

    # pos-only
    if getattr(a, "posonlyargs", []):
        for arg in a.posonlyargs:
            parts.append(fmt_arg(arg))
        parts.append("/")

    # normal args with defaults
    num_non_default = len(a.args) - len(a.defaults)
    for i, arg in enumerate(a.args):
        d = None if i < num_non_default else a.defaults[i - num_non_default]
        parts.append(fmt_arg(arg, d))

    # vararg
    if a.vararg is not None:
        ann = f": {_unparse_expr(a.vararg.annotation)}" if a.vararg.annotation is not None else ""
        parts.append(f"*{a.vararg.arg}{ann}")
    elif a.kwonlyargs:
        parts.append("*")

    # kw-only
    for i, arg in enumerate(a.kwonlyargs):
        default = a.kw_defaults[i]
        parts.append(fmt_arg(arg, default))

    # **kwargs
    if a.kwarg is not None:
        ann = f": {_unparse_expr(a.kwarg.annotation)}" if a.kwarg.annotation is not None else ""
        parts.append(f"**{a.kwarg.arg}{ann}")

    return ", ".join([p for p in parts if p != "/" or (parts and parts[0] != "/")])




def _unparse_expr(node: Optional[ast.AST]) -> str:
    if node is None:
        return "None"
    try:  # Python 3.9+
        return ast.unparse(node)  # type: ignore[attr-defined]
    except Exception:
        # Fallback: best-effort repr
        if isinstance(node, ast.Attribute):
            return f"{_unparse_expr(node.value)}.{node.attr}"
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Constant):
            return repr(node.value)
        if isinstance(node, ast.Subscript):
            return f"{_unparse_expr(node.value)}[{_unparse_expr(node.slice)}]"
        if isinstance(node, ast.Call):
            args = ", ".join([_unparse_expr(a) for a in node.args])
            return f"{_unparse_expr(node.func)}({args})"
        return node.__class__.__name__


def _extract_signatures_jsts(src: str) -> str:
    lines: List[str] = []
    # function foo(...) { ... }
    for m in re.finditer(r"\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)", src):
        name, params = m.group(1), m.group(2)
        lines.append(f"function {name}({params}) …")
    # const foo = (...) => { ... }
    for m in re.finditer(r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\(([^)]*)\)\s*=>", src):
        name, params = m.group(1), m.group(2)
        lines.append(f"{name} = ({params}) => …")
    # class Foo { ... }
    for m in re.finditer(r"\bclass\s+([A-Za-z_$][\w$]*)\b", src):
        lines.append(f"class {m.group(1)} …")
    if not lines:
        lines.append("// no functions/classes detected")
    return "\n".join(lines) + "\n"


def _extract_signatures_go(src: str) -> str:
    out: List[str] = []
    for ln in src.splitlines():
        s = ln.strip()
        if s.startswith("func "):
            out.append(s)
    if not out:
        out.append("// no functions detected")
    return "\n".join(out) + "\n"


def _extract_signatures_java(src: str) -> str:
    lines: List[str] = []
    # class declarations
    for m in re.finditer(r"\bclass\s+([A-Za-z_][\w]*)\b", src):
        lines.append(f"class {m.group(1)} …")
    # method-like (very rough)
    for m in re.finditer(r"^(?:\s*(?:public|private|protected|static|final|abstract|synchronized)\s+)*[A-Za-z_][\w<>,\[\]\.?\s]*\s+([A-Za-z_][\w]*)\s*\([^;{]*\)\s*[{;]", src, re.M):
        lines.append(_get_line(src, m.start()).strip())
    if not lines:
        lines.append("// no classes/methods detected")
    return "\n".join(lines) + "\n"


def _extract_signatures_c_cpp(src: str) -> str:
    lines: List[str] = []
    for m in re.finditer(r"^\s*[A-Za-z_][\w\s\*:&<>~]+?\s+([A-Za-z_][\w]*)\s*\([^;]*\)\s*(?:\{|;)", src, re.M):
        lines.append(_get_line(src, m.start()).strip())
    return ("\n".join(lines) + "\n") if lines else "// no functions detected\n"


def _extract_signatures_rust(src: str) -> str:
    lines = [ln.strip() for ln in re.findall(r"^\s*fn\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\).*", src, re.M)]
    return ("\n".join(lines) + "\n") if lines else "// no functions detected\n"


def _extract_signatures_swift(src: str) -> str:
    lines = [ln.strip() for ln in re.findall(r"^\s*func\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\).*", src, re.M)]
    return ("\n".join(lines) + "\n") if lines else "// no functions detected\n"


def _extract_signatures_kotlin(src: str) -> str:
    lines = [ln.strip() for ln in re.findall(r"^\s*fun\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\).*", src, re.M)]
    return ("\n".join(lines) + "\n") if lines else "// no functions detected\n"


def _extract_signatures_csharp(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*(?:public|private|protected|internal|static|sealed|virtual|override|async|partial|new)\s+[A-Za-z_<>,\[\]\?\s]+\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\)\s*(?:\{|;)", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "// no methods detected\n"


def _extract_signatures_php(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*function\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\)", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "// no functions detected\n"


def _extract_signatures_ruby(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*def\s+[A-Za-z_][A-Za-z0-9_]*", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "# no methods detected\n"


def _extract_signatures_scala(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*def\s+[A-Za-z_][A-Za-z0-9_]*\s*\(", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "// no defs detected\n"


def _extract_signatures_hs(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*[a-z][\w']*\s*::\s*.*", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "-- no signatures detected\n"


def _extract_signatures_sh(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(\)\s*\{", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "# no functions detected\n"


def _extract_signatures_lua(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*function\s+[A-Za-z_][A-Za-z0-9_]*\s*\(", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "-- no functions detected\n"


def _extract_signatures_pl(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*sub\s+[A-Za-z_][A-Za-z0-9_]*\s*\{", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "# no subs detected\n"


def _extract_signatures_r(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*[A-Za-z_][A-Za-z0-9_]*\s*<-\s*function\s*\(", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "# no functions detected\n"


def _extract_signatures_objc(src: str) -> str:
    lines = [
        _get_line(src, m.start()).strip()
        for m in re.finditer(r"^\s*[-+]\s*\([^)]*\)\s*[A-Za-z_][A-Za-z0-9_]*\s*[:;{]", src, re.M)
    ]
    return ("\n".join(lines) + "\n") if lines else "// no methods detected\n"


def _get_line(src: str, pos: int) -> str:
    start = src.rfind("\n", 0, pos)
    end = src.find("\n", pos)
    if start == -1:
        start = 0
    else:
        start += 1
    if end == -1:
        end = len(src)
    return src[start:end]


# -------- Helpers: LLM summary -------- #

def _summarize_file(
    path: str,
    src: str,
    lang: str,
    *,
    provider: Any | None,
    max_chars: int,
) -> Tuple[str, Dict[str, Any]]:
    head = src[:max_chars]

    summary: Optional[str] = None
    if provider is not None:
        try:
            messages = [
                {
                    "role": "system",
                    "content": (
                        "You summarize source files for code review and retrieval. "
                        "Return a concise summary (6-12 bullet points) covering: purpose, main APIs, "
                        "key classes/functions, side effects, external IO, and notable patterns."
                    ),
                },
                {
                    "role": "user",
                    "content": f"Path: {path}\nLanguage: {lang}\n\n--- BEGIN FILE ---\n{head}\n--- END FILE ---",
                },
            ]
            resp = provider.chat(messages, stream=False)  # type: ignore[attr-defined]
            summary = _llm_response_text(resp, provider)
        except Exception:
            summary = None

    if not summary:
        # Heuristic fallback
        analysis = analyze_text(path, src)
        funcs = analysis.get("functions")
        classes = analysis.get("classes")
        imports = analysis.get("imports")
        parts: List[str] = [f"File {Path(path).name} ({lang})"]
        if imports:
            if isinstance(imports, list):
                if imports and isinstance(imports[0], dict):
                    imp_str = ", ".join(sorted({(i.get("module") or '') + ':' + ','.join(i.get("names", [])) for i in imports}))
                else:
                    imp_str = ", ".join(map(str, imports))
                parts.append(f"Imports: {imp_str}")
        if classes:
            cls_names = [c["name"] if isinstance(c, dict) else str(c) for c in classes]
            parts.append(f"Classes: {', '.join(cls_names)}")
        if funcs:
            if funcs and isinstance(funcs[0], dict):
                fn_names = [f["name"] for f in funcs]
            else:
                fn_names = list(map(str, funcs))
            parts.append(f"Functions: {', '.join(fn_names)}")
        summary = "\n".join(parts)

    text = (
        f"# Summary for {Path(path).name}\n\n{summary}\n\n"
        f"# Symbols (auto-extracted)\n" + _extract_signatures(path, src, lang)[0]
    )
    return text, {"language": lang, "op": "summary", "used_llm": provider is not None and summary is not None}


def _llm_response_text(resp: Any, provider: Any = None) -> Optional[str]:
    """Extract text from LLM response using centralized extraction if available."""
    if resp is None:
        return None
    
    # Use centralized extraction if provider is BaseProvider
    from .providers.base import BaseProvider
    if provider and isinstance(provider, BaseProvider):
        try:
            content = provider.extract_content(resp, stream=False)
            return content if isinstance(content, str) and content.strip() else None
        except Exception:
            pass
    
    # Fallback to manual extraction for backward compatibility
    # Gemini
    txt = getattr(resp, "text", None)
    if isinstance(txt, str) and txt.strip():
        return txt
    # Ollama-like
    if isinstance(resp, dict):
        msg = resp.get("message")
        if isinstance(msg, dict):
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
        # Some clients return a list of messages
        c = resp.get("content")
        if isinstance(c, str) and c.strip():
            return c
    return None
