from __future__ import annotations

import json
import time
import tracemalloc
from dataclasses import dataclass
from typing import Any, Dict, Tuple

from .adaptive_builder import AdaptiveConfig, build_adaptive_context
from .context_cache import ContextCache


@dataclass(frozen=True)
class BenchmarkResult:
    duration_sec: float
    peak_mb: float
    used_tokens: int
    files_count: int


def benchmark_context(root: str, *, provider: Any | None = None) -> BenchmarkResult:
    cache = ContextCache(root)
    cfg = AdaptiveConfig(root_dir=root)
    tracemalloc.start()
    t0 = time.perf_counter()
    files, stats = build_adaptive_context(cfg, cache=cache, provider=provider)
    duration = time.perf_counter() - t0
    _cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    peak_mb = peak / (1024 * 1024)
    return BenchmarkResult(
        duration_sec=duration,
        peak_mb=peak_mb,
        used_tokens=int(stats.get("used_tokens", 0)),
        files_count=len(files),
    )


def to_json(res: BenchmarkResult) -> str:
    return json.dumps(
        {
            "duration_sec": round(res.duration_sec, 4),
            "peak_mb": round(res.peak_mb, 2),
            "used_tokens": res.used_tokens,
            "files_count": res.files_count,
        },
        indent=2,
    )

