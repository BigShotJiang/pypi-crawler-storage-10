Amount = int
