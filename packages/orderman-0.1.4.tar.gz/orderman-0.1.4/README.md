
![Logo](https://lh3.googleusercontent.com/d/1yyUAsyMHsgy4rJSzxh4lJ-BZKQMMmLBR)




![PyPI - License](https://img.shields.io/pypi/l/orderman)
![PyPI - Version](https://img.shields.io/pypi/v/orderman)

# Orderman

An easy way to order and execute python functions


## Installation

Install Orderman with pip

```bash
  pip install orderman
```
    
## Usage/Examples

```python
import orderman

@orderman.task(2) # Creates a function that will be executed first
def do_something():
    print("Hello orderman world!")

@orderman.task(1) # Creates a function that will be executed second
def do_another_thing():
    print("Dogs are great!")

orderman.execute()

"""Results"""

Dogs are great
Hello orderman world!
```

## Authors

- [LadonON](https://www.github.com/LadonON)

