from typing import Dict, Callable

_TASK_REG: Dict[int, Callable] = {}

def execute():
    for id in sorted(_TASK_REG.keys()):
        _TASK_REG[id]()

def task(order: int):
    def decorator(func):
        _TASK_REG[order] = func
        def wrapper(*args, **kwargs):
            print(func.__name__)
            return func(*args, **kwargs)
        return wrapper
    return decorator
