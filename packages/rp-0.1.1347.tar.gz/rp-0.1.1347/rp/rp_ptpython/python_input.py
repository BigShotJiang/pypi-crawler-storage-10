"""
CommandLineInterface for reading Python input.
This can be used for creation of Python REPLs.

::

    cli = PythonCommandLineInterface()
    cli.run()
"""
from __future__ import unicode_literals
import rp.rp_ptpython.r_iterm_comm as ric
from rp.prompt_toolkit import AbortAction
from rp.prompt_toolkit.auto_suggest import AutoSuggestFromHistory,ConditionalAutoSuggest
from rp.prompt_toolkit.buffer import Buffer
from rp.prompt_toolkit.document import Document
from rp.prompt_toolkit.enums import DEFAULT_BUFFER,EditingMode
from rp.prompt_toolkit.filters import Condition,Always
from rp.prompt_toolkit.history import FileHistory,InMemoryHistory
from rp.prompt_toolkit.interface import CommandLineInterface,Application,AcceptAction
from rp.prompt_toolkit.key_binding.defaults import load_key_bindings_for_prompt,load_mouse_bindings
from rp.prompt_toolkit.key_binding.vi_state import InputMode
from rp.prompt_toolkit.key_binding.registry import MergedRegistry,ConditionalRegistry
from rp.prompt_toolkit.layout.lexers import PygmentsLexer
from rp.prompt_toolkit.shortcuts import create_output
from rp.prompt_toolkit.styles import DynamicStyle
from rp.prompt_toolkit.utils import is_windows
from rp.prompt_toolkit.validation import ConditionalValidator
from rp.prompt_toolkit.output import Output

from .completer import PythonCompleter
from .history_browser import create_history_application
from .key_bindings import load_python_bindings,load_sidebar_bindings,load_confirm_exit_bindings
from .layout import create_layout,CompletionVisualisation
from .prompt_style import IPythonPrompt,ClassicPrompt
from .style import get_all_code_styles,get_all_ui_styles,generate_style
from .utils import document_is_multiline_python
from .validator import PythonValidator

from functools import partial

import rp.rp_ptpython.r_iterm_comm as r_iterm_comm

import six
import __future__

# PythonLexer import moved to LazyPygmentsLexer for faster startup

__all__=(
    'PythonInput',
    'PythonCommandLineInterface',
)

import rp.rp_ptpython.r_iterm_comm as ric
def set_debug_height(height):
    ric.debug_height=height
    return height

def set_history_line_limit(number_of_lines):
    from rp.r import _globa_pyin
    _globa_pyin[0].history_number_of_lines=number_of_lines
    return number_of_lines
def get_history_line_limit():
    from rp.r import _globa_pyin
    return _globa_pyin[0].history_number_of_lines

def set_mouse_scroll_lines(number_of_lines):
    from rp.r import _globa_pyin
    _globa_pyin[0].mouse_scroll_lines=number_of_lines
    return number_of_lines
def get_mouse_scroll_lines():
    from rp.r import _globa_pyin
    return getattr(_globa_pyin[0], 'mouse_scroll_lines', 3)

class OptionCategory(object):
    def __init__(self,title,options):
        assert isinstance(title,six.text_type)
        assert isinstance(options,list)

        self.title=title
        self._options=options

    @property
    def options(self):
        return [option for option in self._options if option.is_visible()]
    

class Option(object):
    """
    Ptpython configuration option that can be shown and modified from the
    sidebar.

    :param title: Text.
    :param description: Text.
    :param get_values: Callable that returns a dictionary mapping the
            possible values to callbacks that activate these value.
    :param get_current_value: Callable that returns the current, active value.
    """
    def __init__(self,title,description,get_current_value,get_values,is_visible=lambda:True):
        assert isinstance(title,six.text_type)
        assert isinstance(description,six.text_type)
        assert callable(get_current_value)
        assert callable(get_values)

        self.title=title
        self.description=description
        self.get_current_value=get_current_value
        self.get_values=get_values
        self.is_visible=is_visible

    @property
    def values(self):
        return self.get_values()

    def activate_next(self,_previous=False):
        """
        Activate next value.
        """
        current=self.get_current_value()
        options=sorted(self.values.keys())

        # Get current index.
        try:
            index=options.index(current)
        except ValueError:
            index=0

        # Go to previous/next index.
        if _previous:
            index-=1
        else:
            index+=1

        # Call handler for this option.
        next_option=options[index % len(options)]
        self.values[next_option]()

    def activate_previous(self):
        """
        Activate previous value.
        """
        self.activate_next(_previous=True)


class PythonInput(object):
    """
    Prompt for reading Python input.

    ::

        python_input = PythonInput(...)
        application = python_input.create_application()
        cli = PythonCommandLineInterface(application=application)
        python_code = cli.run()
    """
    def __init__(self,
            get_globals=None,get_locals=None,history_filename=None,
            vi_mode=False,
            # For internal use.
            _completer=None,_validator=None,
            _lexer=None,_extra_buffers=None,_extra_buffer_processors=None,
            _on_start=None,
            _extra_layout_body=None,_extra_toolbars=None,
            _input_buffer_height=None,
            _accept_action=AcceptAction.RETURN_DOCUMENT,
            _on_exit=AbortAction.RAISE_EXCEPTION):
        self.get_globals=get_globals or (lambda:{})
        self.get_locals=get_locals or self.get_globals

        self.show_parenthesis_automator=False

        self._completer=_completer or PythonCompleter(
            self.get_globals,
            self.get_locals,
            allow_jedi_dynamic_imports=lambda: self.allow_jedi_dynamic_imports
        )
        self._validator=_validator or PythonValidator(self.get_compiler_flags)
        self.history=FileHistory(history_filename) if history_filename else InMemoryHistory()
        # Use lazy lexer creation to defer imports until needed
        if _lexer is None:
            from rp.prompt_toolkit.layout.lexers import LazyPygmentsLexer
            from rp.rp_ptpython.jedi_lexer import JediLexer
            base_lexer = LazyPygmentsLexer()
            # Wrap with Jedi semantic highlighting (uses runtime globals/locals)
            self._lexer = JediLexer(
                base_lexer,
                self.get_globals,
                self.get_locals,
                get_enabled=lambda: self.enable_semantic_highlighting
            )
        else:
            self._lexer = _lexer
        self._extra_buffers=_extra_buffers
        self._accept_action=_accept_action
        self._on_exit=_on_exit
        self._on_start=_on_start

        self._input_buffer_height=_input_buffer_height
        self._extra_layout_body=_extra_layout_body or []
        self._extra_toolbars=_extra_toolbars or []
        self._extra_buffer_processors=_extra_buffer_processors or []

        # Settings.
        # NOTE: When adding new settings here, also add them to _default_pyin_settings in r.py
        # so they can be saved/loaded with PT SAVE and PT RESET commands.
        self.show_signature=False
        self.show_docstring=False
        self.show_realtime_input=False
        self.show_vars=False
        self.show_meta_enter_message=True
        self.completion_visualisation=CompletionVisualisation.MULTI_COLUMN
        self.completion_menu_scroll_offset=1

        self.show_line_numbers=False
        self.show_status_bar=True
        self.wrap_lines=True
        self.complete_while_typing=True
        self.vi_mode=vi_mode
        self.paste_mode=False  # When True, don't insert whitespace after newline.
        self.confirm_exit=True  # Ask for confirmation when Control-D is pressed.
        self.accept_input_on_enter=2  # Accept when pressing Enter 'n' times.
        # 'None' means that meta-enter is always required.
        self.enable_open_in_editor=True
        self.enable_system_bindings=True
        self.enable_input_validation=True
        self.enable_auto_suggest=False
        self.enable_mouse_support=False
        self.allow_jedi_dynamic_imports=False  # When False, prevent Jedi from importing unloaded modules (faster on NFS)
        self.enable_semantic_highlighting=True  # When True, use Jedi to add semantic highlighting (callables, modules)
        self.indent_guides_mode='Propagate'  # 'Off', 'Regular', or 'Propagate'
        self.show_whitespace='Off'  # 'Off', 'All', or 'Leading'
        self.highlight_cursor_line=False  # Highlight the background of the cursor line
        self.highlight_cursor_column=False  # Highlight the background of the cursor column
        self.highlight_matching_words=True  # Underline all occurrences of the word under cursor
        self.enable_history_search=False  # When True, like readline, going
        # back in history will filter the
        # history on the records starting
        # with the current input.
        self.highlight_matching_parenthesis=False
        self.show_sidebar=False  # Currently show the sidebar.
        self.show_sidebar_help=True  # When the sidebar is visible, also show the help text.
        self.show_exit_confirmation=False  # Currently show 'Do you really want to exit?'
        self.terminal_title=None  # The title to be displayed in the terminal. (None or string.)
        self.exit_message='Do you really want to exit?'
        self.insert_blank_line_after_output=True  # (For the REPL.)

        # Tokens to be shown at the prompt.
        self.prompt_style='classic'  # The currently active style.

        self.all_prompt_styles={  # Styles selectable from the menu.
            'ipython':IPythonPrompt(self),
            'classic':ClassicPrompt(),
        }

        self.get_input_prompt_tokens=lambda cli: \
            self.all_prompt_styles[self.prompt_style].in_tokens(cli)

        self.get_output_prompt_tokens=lambda cli: \
            self.all_prompt_styles[self.prompt_style].out_tokens(cli)

        #: Load styles.
        self.code_styles=get_all_code_styles()
        self.ui_styles=get_all_ui_styles()
        self._current_code_style_name='default'
        self._current_ui_style_name='default'
        self.code_invert_colors=False
        self.code_invert_brightness=False
        self.ui_invert_colors=False
        self.ui_invert_brightness=False
        self.code_hue_shift=0  # Hue shift for code elements (0-355 degrees in 5-degree increments)
        self.ui_hue_shift=0    # Hue shift for UI elements (0-355 degrees in 5-degree increments)
        self.code_min_brightness=0.0  # Minimum brightness for code elements (0.0-1.0)
        self.code_max_brightness=1.0  # Maximum brightness for code elements (0.0-1.0)
        self.ui_min_brightness=0.0    # Minimum brightness for UI elements (0.0-1.0)
        self.ui_max_brightness=1.0    # Maximum brightness for UI elements (0.0-1.0)
        self.code_min_saturation=0.0  # Minimum saturation for code elements (0.0-1.0)
        self.code_max_saturation=1.0  # Maximum saturation for code elements (0.0-1.0)
        self.ui_min_saturation=0.0    # Minimum saturation for UI elements (0.0-1.0)
        self.ui_max_saturation=1.0    # Maximum saturation for UI elements (0.0-1.0)
        self.code_ui_min_brightness=None  # Minimum brightness for code UI elements (whitespace, indent guides, etc.) (0.0-1.0)
        self.code_ui_max_brightness=None  # Maximum brightness for code UI elements (whitespace, indent guides, etc.) (0.0-1.0)
        self.ui_bg_fg_contrast=0.0    # Minimum brightness difference between foreground and background (0.0-1.0)
        self.background_mode='Default'  # Background mode: "Nowhere", "Default", "Black", or "White"

        if is_windows():
            self._current_code_style_name='win32'

        self._current_style=self._generate_style()
        self.true_color=False

        # Options to be configurable from the sidebar - lazy loaded
        self._options = None
        self.selected_option_index=0

        #: Incremeting integer counting the current statement.
        self.current_statement_index=1

        # Code signatures. (This is set asynchronously after a timeout.)
        self.signatures=[]

        self.waa=True# RYAN BURGERT STUFF
        self.sand_creature='dust ball'

        # Create a Registry for the key bindings.
        self.key_bindings_registry=MergedRegistry([
            ConditionalRegistry(
                registry=load_key_bindings_for_prompt(
                    enable_abort_and_exit_bindings=True,
                    enable_search=True,
                    enable_open_in_editor=Condition(lambda cli:self.enable_open_in_editor),
                    enable_system_bindings=Condition(lambda cli:self.enable_system_bindings),
                    enable_auto_suggest_bindings=Condition(lambda cli:self.enable_auto_suggest)),
                # Disable all default key bindings when the sidebar or the exit confirmation
                # are shown.
                filter=Condition(lambda cli:not (self.show_sidebar or self.show_exit_confirmation))
            ),
            load_mouse_bindings(),
            load_python_bindings(self),
            load_sidebar_bindings(self),
            load_confirm_exit_bindings(self),
        ])

        # Boolean indicating whether we have a signatures thread running.
        # (Never run more than one at the same time.)
        self._get_signatures_thread_running=False

    @property
    def options(self):
        """Lazy-loaded options for the sidebar."""
        if self._options is None:
            self._options = self._create_options()
        return self._options

    @property
    def option_count(self):
        " Return the total amount of options. (In all categories together.) "
        return sum(len(category.options) for category in self.options)

    @property
    def selected_option(self):
        " Return the currently selected option. "
        i=0
        for category in self.options:
            for o in category.options:
                if i == self.selected_option_index:
                    return o
                else:
                    i+=1
        return category.options[-1]

    def get_compiler_flags(self):
        """
        Give the current compiler flags by looking for _Feature instances
        in the globals.
        """
        flags=0

        for value in self.get_globals().values():
            if isinstance(value,__future__._Feature):
                flags|=value.compiler_flag

        return flags

    @property
    def add_key_binding(self):
        """
        Shortcut for adding new key bindings.
        (Mostly useful for a .ptpython/config.py file, that receives
        a PythonInput/Repl instance as input.)

        ::

            @python_input.add_key_binding(Keys.ControlX, filter=...)
            def handler(event):
                ...
        """
        # Extra key bindings should not be active when the sidebar is visible.
        sidebar_visible=Condition(lambda cli:self.show_sidebar)

        def add_binding_decorator(*keys,**kw):
            # Pop default filter keyword argument.
            filter=kw.pop('filter',Always())
            assert not kw

            return self.key_bindings_registry.add_binding(*keys,filter=filter & ~sidebar_visible)
        return add_binding_decorator

    def install_code_colorscheme(self,name,style_dict):
        """
        Install a new code color scheme.
        """
        assert isinstance(name,six.text_type)
        assert isinstance(style_dict,dict)

        self.code_styles[name]=style_dict

    def use_code_colorscheme(self,name):
        """
        Apply new colorscheme. (By name.)
        """
        assert name in self.code_styles

        self._current_code_style_name=name
        self._current_style=self._generate_style()

    def install_ui_colorscheme(self,name,style_dict):
        """
        Install a new UI color scheme.
        """
        assert isinstance(name,six.text_type)
        assert isinstance(style_dict,dict)

        self.ui_styles[name]=style_dict

    def use_ui_colorscheme(self,name):
        """
        Apply new colorscheme. (By name.)
        """
        assert name in self.ui_styles

        self._current_ui_style_name=name
        self._current_style=self._generate_style()

    def _generate_style(self):
        """
        Create new Style instance.
        (We don't want to do this on every key press, because each time the
        renderer receives a new style class, he will redraw everything.)
        """
        return generate_style(self.code_styles[self._current_code_style_name],
                              self.ui_styles[self._current_ui_style_name],
                              code_invert_colors=self.code_invert_colors,
                              code_invert_brightness=self.code_invert_brightness,
                              ui_invert_colors=self.ui_invert_colors,
                              ui_invert_brightness=self.ui_invert_brightness,
                              code_hue_shift=self.code_hue_shift,
                              ui_hue_shift=self.ui_hue_shift,
                              code_min_brightness=self.code_min_brightness,
                              code_max_brightness=self.code_max_brightness,
                              ui_min_brightness=self.ui_min_brightness,
                              ui_max_brightness=self.ui_max_brightness,
                              code_min_saturation=self.code_min_saturation,
                              code_max_saturation=self.code_max_saturation,
                              ui_min_saturation=self.ui_min_saturation,
                              ui_max_saturation=self.ui_max_saturation,
                              ui_bg_fg_contrast=self.ui_bg_fg_contrast,
                              code_ui_min_brightness=self.code_ui_min_brightness,
                              code_ui_max_brightness=self.code_ui_max_brightness)
                              
    def _update_style(self):
        """
        Update the current style. Used when toggling the invert_colors option.
        """
        self._current_style = self._generate_style()
        return True
    def _create_options(self):
        """
        Create a list of `Option` instances for the options sidebar.
        """
        def enable(attribute,value=True):
            setattr(self,attribute,value)

            # Return `True`, to be able to chain this in the lambdas below.
            return True

        def disable(attribute):
            setattr(self,attribute,False)
            return True

        def simple_option(title,description,field_name,values=None,is_visible=lambda:True):
            " Create Simple on/of option. "
            values=values or ['off','on']

            def get_current_value():
                return values[bool(getattr(self,field_name,'(Broken)'))]

            def get_values():
                return {
                    values[1]:lambda:enable(field_name),
                    values[0]:lambda:disable(field_name),
                }

            return Option(title=title,description=description,
                          get_values=get_values,
                          get_current_value=get_current_value,
                          is_visible=is_visible)
        def doge(self):
            setattr(self,'sand_creature',"Option Camel")
            # This hasn't aged well :( Fuck Trump and fuck elon - they ruined a meme!
            # from doge.core import main
            # main()

        return [
            OptionCategory('Input',[
                simple_option(title='Input mode',
                              description='Vi or emacs key bindings.',
                              field_name='vi_mode',
                              values=['emacs','vi']),
                simple_option(title='Microcompletions',
                              description='When in RP-Emacs mode, should we enable microcompletions?',
                              field_name='enable_microcompletions',
                              values=[False,True]),
                simple_option(title='Paste mode',
                        # is_visible=lambda:getattr(self,'show_all_options',True),
                              description="When enabled, don't indent automatically.",
                              field_name='paste_mode'),
                Option(title='History search',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                       description='When pressing the up-arrow, filter the history on input starting '
                                   'with the current text. (Not compatible with "Complete while typing".)',
                       get_current_value=lambda:['off','on'][self.enable_history_search],
                       get_values=lambda:{
                           'on':lambda:enable('enable_history_search'),
                           'off':lambda:disable('enable_history_search'),
                       }),
                simple_option(title='Mouse support',
                              description='Respond to mouse clicks and scrolling for positioning the cursor, '
                                          'selecting text and scrolling through windows.',
                              field_name='enable_mouse_support'),
                simple_option(title='Confirm on exit',
                    is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Require confirmation when exiting.',
                              field_name='confirm_exit'),
                simple_option(title='Input validation',
                    is_visible=lambda:getattr(self,'show_all_options',True),
                              description='In case of syntax errors, move the cursor to the error '
                                          'instead of showing a traceback of a SyntaxError.',
                              field_name='enable_input_validation'),
                Option(title='Accept input on enter',
                    is_visible=lambda:getattr(self,'show_all_options',True),
                       description='Amount of ENTER presses required to execute input when the cursor '
                                   'is at the end of the input. (Note that META+ENTER will always execute.)',
                       get_current_value=lambda:str(self.accept_input_on_enter or 'meta-enter'),
                       get_values=lambda:{
                           '2':lambda:enable('accept_input_on_enter',2),
                           '3':lambda:enable('accept_input_on_enter',3),
                           '4':lambda:enable('accept_input_on_enter',4),
                           'meta-enter':lambda:enable('accept_input_on_enter',None),
                       }),
            ]),
            OptionCategory('Display',[
                #I DISABLED THIS BECAUSE IT'S DEPRECATED NOW - NOW YOU USE 'SET STYLE'
                # Option(title='Prompt',
                #         is_visible=lambda:getattr(self,'show_all_options',True),
                #        description="Visualisation of the prompt. ('>>>' or 'In [1]:')",
                #        get_current_value=lambda:self.prompt_style,
                #        get_values=lambda:dict((s,partial(enable,'prompt_style',s)) for s in self.all_prompt_styles)),
                simple_option(title='Blank line after output',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                              description='Insert a blank line after the output.',
                              field_name='insert_blank_line_after_output'),
                simple_option(title='Show line numbers',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Show line numbers when the input consists of multiple lines.',
                              field_name='show_line_numbers'),
                simple_option(title='Show Meta+Enter message',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Show the [Meta+Enter] message when this key combination is required to execute commands. ' +
                                          '(This is the case when a simple [Enter] key press will insert a newline.',
                              field_name='show_meta_enter_message'),
                simple_option(title='Wrap lines',
                              description='Wrap lines instead of scrolling horizontally.',
                              field_name='wrap_lines'),
                Option(title='Indent guides',
                       description='Display vertical indent guides. "Regular" shows guides only for existing indentation. "Propagate" also shows guides on empty lines between indented blocks.',
                       get_current_value=lambda:self.indent_guides_mode,
                       get_values=lambda:{
                           'Off': lambda:setattr(self, 'indent_guides_mode', 'Off'),
                           'Regular': lambda:setattr(self, 'indent_guides_mode', 'Regular'),
                           'Propagate': lambda:setattr(self, 'indent_guides_mode', 'Propagate'),
                       }),
                Option(title='Show whitespace',
                       description='Display spaces as middle dots (·) and tabs as arrows (→). Choose which whitespace to visualize.',
                       get_current_value=lambda:self.show_whitespace,
                       get_values=lambda:{
                           'Off': lambda:setattr(self, 'show_whitespace', 'Off'),
                           'All': lambda:setattr(self, 'show_whitespace', 'All'),
                           'Leading': lambda:setattr(self, 'show_whitespace', 'Leading'),
                           'Trailing': lambda:setattr(self, 'show_whitespace', 'Trailing'),
                           'Lead+Trail': lambda:setattr(self, 'show_whitespace', 'Lead+Trail'),
                       }),
                simple_option(title='Highlight cursor line',
                       description='Highlight the background of the line with the cursor.',
                       field_name='highlight_cursor_line'),
                simple_option(title='Highlight cursor column',
                       description='Highlight the background of the column with the cursor.',
                       field_name='highlight_cursor_column'),
                simple_option(title='Highlight matching words',
                       description='Underline all occurrences of the word under the cursor.',
                       field_name='highlight_matching_words'),
                simple_option(title='History Highlighting',
                              description='When using F3 (aka History Broswer) to select entries from history,  '
                                          'should we use syntax highlighting? Its pretty, but slow.',
                              field_name='history_syntax_highlighting'),
                Option(title='History Browser Limit',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='How many lines should we display when using F3 history? Less is faster\nMaking this smaller decreases the latency of pressing F3',
                       get_current_value=lambda:str(get_history_line_limit()).rjust(12),
                       get_values=lambda:{'asdpoa':lambda:None,
                            '           1':lambda:set_history_line_limit(1          ),
                            '           5':lambda:set_history_line_limit(5          ),
                            '          10':lambda:set_history_line_limit(10          ),
                            '          20':lambda:set_history_line_limit(20          ),
                            '          30':lambda:set_history_line_limit(30          ),
                            '          40':lambda:set_history_line_limit(40          ),
                            '          50':lambda:set_history_line_limit(50          ),
                            '         100':lambda:set_history_line_limit(100         ),
                            '         150':lambda:set_history_line_limit(150         ),
                            '         200':lambda:set_history_line_limit(200         ),
                            '         250':lambda:set_history_line_limit(250         ),
                            '         300':lambda:set_history_line_limit(300         ),
                            '         400':lambda:set_history_line_limit(400         ),
                            '         500':lambda:set_history_line_limit(500         ),
                            '         600':lambda:set_history_line_limit(600         ),
                            '         700':lambda:set_history_line_limit(700         ),
                            '         800':lambda:set_history_line_limit(800         ),
                            '         900':lambda:set_history_line_limit(900         ),
                            '        1000':lambda:set_history_line_limit(1000        ),
                            '        1500':lambda:set_history_line_limit(1500        ),
                            '        2000':lambda:set_history_line_limit(2000        ),
                            '        2500':lambda:set_history_line_limit(2500        ),
                            '        3000':lambda:set_history_line_limit(3000        ),
                            '        3500':lambda:set_history_line_limit(3500        ),
                            '        4000':lambda:set_history_line_limit(4000        ),
                            '        4500':lambda:set_history_line_limit(4500        ),
                            '        5000':lambda:set_history_line_limit(5000        ),
                            '        6000':lambda:set_history_line_limit(6000        ),
                            '        7000':lambda:set_history_line_limit(7000        ),
                            '        8000':lambda:set_history_line_limit(8000        ),
                            '        9000':lambda:set_history_line_limit(9000        ),
                            '       10000':lambda:set_history_line_limit(10000       ),
                            '       15000':lambda:set_history_line_limit(15000       ),
                            '       20000':lambda:set_history_line_limit(20000       ),
                            '       25000':lambda:set_history_line_limit(25000       ),
                            '       30000':lambda:set_history_line_limit(30000       ),
                            '       40000':lambda:set_history_line_limit(40000       ),
                            '       50000':lambda:set_history_line_limit(50000       ),
                            '      100000':lambda:set_history_line_limit(100000      ),
                            '     1000000':lambda:set_history_line_limit(1000000     ),
                            '    10000000':lambda:set_history_line_limit(10000000    ),
                            '999999999999':lambda:set_history_line_limit(999999999999),
                       }),

                Option(title='Mouse Scroll Lines',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='How many lines should the mouse wheel scroll at a time?',
                       get_current_value=lambda:str(get_mouse_scroll_lines()).rjust(12),
                       get_values=lambda:{'asdpoa':lambda:None,
                            '           1':lambda:set_mouse_scroll_lines(1),
                            '           2':lambda:set_mouse_scroll_lines(2),
                            '           3':lambda:set_mouse_scroll_lines(3),
                            '           4':lambda:set_mouse_scroll_lines(4),
                            '           5':lambda:set_mouse_scroll_lines(5),
                            '           6':lambda:set_mouse_scroll_lines(6),
                            '           7':lambda:set_mouse_scroll_lines(7),
                            '           8':lambda:set_mouse_scroll_lines(8),
                            '           9':lambda:set_mouse_scroll_lines(9),
                            '          10':lambda:set_mouse_scroll_lines(10),
                            '          15':lambda:set_mouse_scroll_lines(15),
                            '          20':lambda:set_mouse_scroll_lines(20),
                       }),

                Option(title='Prompt Height Percent',
                        # is_visible=lambda:getattr(self,'show_all_options',True),

                       description='How many rows of the terminal should the prompt be allowed to take?\n(When using control+e or control+w, this can be useful)\nThis is a hack. Doesnt yet work on Windows (see rp/prompt_toolkit/terminal/vt100_output.py)',
                       get_current_value=lambda:str(100-r_iterm_comm.options['top_space']).rjust(11)+'%',
                       get_values=lambda:{'asdpoa':lambda:None,
                            '          0%':lambda:r_iterm_comm.options.__setitem__('top_space',100-0   ),
                            '          1%':lambda:r_iterm_comm.options.__setitem__('top_space',100-1   ),
                            '          2%':lambda:r_iterm_comm.options.__setitem__('top_space',100-2   ),
                            '          3%':lambda:r_iterm_comm.options.__setitem__('top_space',100-3   ),
                            '          4%':lambda:r_iterm_comm.options.__setitem__('top_space',100-4   ),
                            '          5%':lambda:r_iterm_comm.options.__setitem__('top_space',100-5   ),
                            '         10%':lambda:r_iterm_comm.options.__setitem__('top_space',100-10  ),
                            '         15%':lambda:r_iterm_comm.options.__setitem__('top_space',100-15  ),
                            '         20%':lambda:r_iterm_comm.options.__setitem__('top_space',100-20  ),
                            '         25%':lambda:r_iterm_comm.options.__setitem__('top_space',100-25  ),
                            '         30%':lambda:r_iterm_comm.options.__setitem__('top_space',100-30  ),
                            '         35%':lambda:r_iterm_comm.options.__setitem__('top_space',100-35  ),
                            '         40%':lambda:r_iterm_comm.options.__setitem__('top_space',100-40  ),
                            '         45%':lambda:r_iterm_comm.options.__setitem__('top_space',100-45  ),
                            '         50%':lambda:r_iterm_comm.options.__setitem__('top_space',100-50  ),
                            '         55%':lambda:r_iterm_comm.options.__setitem__('top_space',100-55  ),
                            '         60%':lambda:r_iterm_comm.options.__setitem__('top_space',100-60  ),
                            '         65%':lambda:r_iterm_comm.options.__setitem__('top_space',100-65  ),
                            '         70%':lambda:r_iterm_comm.options.__setitem__('top_space',100-70  ),
                            '         75%':lambda:r_iterm_comm.options.__setitem__('top_space',100-75  ),
                            '         80%':lambda:r_iterm_comm.options.__setitem__('top_space',100-80  ),
                            '         85%':lambda:r_iterm_comm.options.__setitem__('top_space',100-85  ),
                            '         90%':lambda:r_iterm_comm.options.__setitem__('top_space',100-90  ),
                            '         95%':lambda:r_iterm_comm.options.__setitem__('top_space',100-95  ),
                            '        100%':lambda:r_iterm_comm.options.__setitem__('top_space',100-100 ),
                       }),

                # Option(title='Empty Top Space',
                #         # is_visible=lambda:getattr(self,'show_all_options',True),

                #        description='How many lines of free rows should be above the top of the prompt?\n(When using control+e or control+w, this can be useful)',
                #        get_current_value=lambda:str(r_iterm_comm.options['top_space']).rjust(12),
                #        get_values=lambda:{'asdpoa':lambda:None,
                #             '           0':lambda:r_iterm_comm.options.__setitem__('top_space',0   ),
                #             '           1':lambda:r_iterm_comm.options.__setitem__('top_space',1   ),
                #             '           2':lambda:r_iterm_comm.options.__setitem__('top_space',2   ),
                #             '           3':lambda:r_iterm_comm.options.__setitem__('top_space',3   ),
                #             '           4':lambda:r_iterm_comm.options.__setitem__('top_space',4   ),
                #             '           5':lambda:r_iterm_comm.options.__setitem__('top_space',5   ),
                #             '          10':lambda:r_iterm_comm.options.__setitem__('top_space',10  ),
                #             '          15':lambda:r_iterm_comm.options.__setitem__('top_space',15  ),
                #             '          20':lambda:r_iterm_comm.options.__setitem__('top_space',20  ),
                #             '          25':lambda:r_iterm_comm.options.__setitem__('top_space',25  ),
                #             '          30':lambda:r_iterm_comm.options.__setitem__('top_space',30  ),
                #             '          35':lambda:r_iterm_comm.options.__setitem__('top_space',35  ),
                #             '          40':lambda:r_iterm_comm.options.__setitem__('top_space',40  ),
                #             '          45':lambda:r_iterm_comm.options.__setitem__('top_space',45  ),
                #             '          50':lambda:r_iterm_comm.options.__setitem__('top_space',50  ),
                #             '          55':lambda:r_iterm_comm.options.__setitem__('top_space',55  ),
                #             '          60':lambda:r_iterm_comm.options.__setitem__('top_space',60  ),
                #             '          65':lambda:r_iterm_comm.options.__setitem__('top_space',65  ),
                #             '          70':lambda:r_iterm_comm.options.__setitem__('top_space',70  ),
                #             '          75':lambda:r_iterm_comm.options.__setitem__('top_space',75  ),
                #             '          80':lambda:r_iterm_comm.options.__setitem__('top_space',80  ),
                #             '          85':lambda:r_iterm_comm.options.__setitem__('top_space',85  ),
                #             '          90':lambda:r_iterm_comm.options.__setitem__('top_space',90  ),
                #             '          95':lambda:r_iterm_comm.options.__setitem__('top_space',95  ),
                #             '         100':lambda:r_iterm_comm.options.__setitem__('top_space',100 ),
                #             '         125':lambda:r_iterm_comm.options.__setitem__('top_space',125 ),
                #             '         150':lambda:r_iterm_comm.options.__setitem__('top_space',150 ),
                #             '         175':lambda:r_iterm_comm.options.__setitem__('top_space',175 ),
                #             '         200':lambda:r_iterm_comm.options.__setitem__('top_space',200 ),
                #             '         300':lambda:r_iterm_comm.options.__setitem__('top_space',300 ),
                #             '         400':lambda:r_iterm_comm.options.__setitem__('top_space',400 ),
                #             '         500':lambda:r_iterm_comm.options.__setitem__('top_space',500 ),
                #             '         600':lambda:r_iterm_comm.options.__setitem__('top_space',600 ),
                #             '         700':lambda:r_iterm_comm.options.__setitem__('top_space',700 ),
                #             '         800':lambda:r_iterm_comm.options.__setitem__('top_space',800 ),
                #             '         900':lambda:r_iterm_comm.options.__setitem__('top_space',900 ),
                #             '        1000':lambda:r_iterm_comm.options.__setitem__('top_space',1000),
                #        }),

                Option(title='Minimum Prompt Height',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='With respect to the "Prompt Height" option, whats the minimum height of the prompt (in #rows)?',
                       get_current_value=lambda:str(r_iterm_comm.options['min_bot_space']).rjust(12),
                       get_values=lambda:{'asdpoa':lambda:None,
                            '           0':lambda:r_iterm_comm.options.__setitem__('min_bot_space',0   ),
                            '           1':lambda:r_iterm_comm.options.__setitem__('min_bot_space',1   ),
                            '           2':lambda:r_iterm_comm.options.__setitem__('min_bot_space',2   ),
                            '           3':lambda:r_iterm_comm.options.__setitem__('min_bot_space',3   ),
                            '           4':lambda:r_iterm_comm.options.__setitem__('min_bot_space',4   ),
                            '           5':lambda:r_iterm_comm.options.__setitem__('min_bot_space',5   ),
                            '          10':lambda:r_iterm_comm.options.__setitem__('min_bot_space',10  ),
                            '          15':lambda:r_iterm_comm.options.__setitem__('min_bot_space',15  ),
                            '          20':lambda:r_iterm_comm.options.__setitem__('min_bot_space',20  ),
                            '          25':lambda:r_iterm_comm.options.__setitem__('min_bot_space',25  ),
                            '          30':lambda:r_iterm_comm.options.__setitem__('min_bot_space',30  ),
                            '          35':lambda:r_iterm_comm.options.__setitem__('min_bot_space',35  ),
                            '          40':lambda:r_iterm_comm.options.__setitem__('min_bot_space',40  ),
                            '          45':lambda:r_iterm_comm.options.__setitem__('min_bot_space',45  ),
                            '          50':lambda:r_iterm_comm.options.__setitem__('min_bot_space',50  ),
                            '          55':lambda:r_iterm_comm.options.__setitem__('min_bot_space',55  ),
                            '          60':lambda:r_iterm_comm.options.__setitem__('min_bot_space',60  ),
                            '          65':lambda:r_iterm_comm.options.__setitem__('min_bot_space',65  ),
                            '          70':lambda:r_iterm_comm.options.__setitem__('min_bot_space',70  ),
                            '          75':lambda:r_iterm_comm.options.__setitem__('min_bot_space',75  ),
                            '          80':lambda:r_iterm_comm.options.__setitem__('min_bot_space',80  ),
                            '          85':lambda:r_iterm_comm.options.__setitem__('min_bot_space',85  ),
                            '          90':lambda:r_iterm_comm.options.__setitem__('min_bot_space',90  ),
                            '          95':lambda:r_iterm_comm.options.__setitem__('min_bot_space',95  ),
                            '         100':lambda:r_iterm_comm.options.__setitem__('min_bot_space',100 ),
                            '         125':lambda:r_iterm_comm.options.__setitem__('min_bot_space',125 ),
                            '         150':lambda:r_iterm_comm.options.__setitem__('min_bot_space',150 ),
                            '         175':lambda:r_iterm_comm.options.__setitem__('min_bot_space',175 ),
                            '         200':lambda:r_iterm_comm.options.__setitem__('min_bot_space',200 ),
                            '         300':lambda:r_iterm_comm.options.__setitem__('min_bot_space',300 ),
                            '         400':lambda:r_iterm_comm.options.__setitem__('min_bot_space',400 ),
                            '         500':lambda:r_iterm_comm.options.__setitem__('min_bot_space',500 ),
                            '         600':lambda:r_iterm_comm.options.__setitem__('min_bot_space',600 ),
                            '         700':lambda:r_iterm_comm.options.__setitem__('min_bot_space',700 ),
                            '         800':lambda:r_iterm_comm.options.__setitem__('min_bot_space',800 ),
                            '         900':lambda:r_iterm_comm.options.__setitem__('min_bot_space',900 ),
                            '        1000':lambda:r_iterm_comm.options.__setitem__('min_bot_space',1000),
                       }),

                Option(title='Show Battery Life',

                        is_visible=lambda:getattr(self,'show_all_options',True),
                       description='Should we show your laptop\'s battery life?\nIt\'s shown on the bottom right of the terminal.\nWhen it\'s green, that means your laptop is plugged in. When red, it means youre on battery power.',
                       get_current_value=lambda:getattr(self,'show_battery_life','(Broken)'),
                       get_values=lambda:{
                           True:lambda:setattr(self,'show_battery_life',True),# print("Selected Llama"),
                           False:lambda:setattr(self,'show_battery_life',False),# print("Selected Donkey"),
                       }),
                simple_option(title='Show status bar',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Show the status bar at the bottom of the terminal.',
                              field_name='show_status_bar'),
                simple_option(title='Show sidebar help',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='When the sidebar is visible, also show this help text.',
                              field_name='show_sidebar_help'),
                simple_option(title='Highlight parenthesis',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Highlight matching parenthesis, when the cursor is on or right after one.',
                              field_name='highlight_matching_parenthesis'),

            ]),
            OptionCategory('Completion',[
                Option(title='Complete while typing',
                       description="Generate autocompletions automatically while typing. "
                                   'Don\'t require pressing TAB. (Not compatible with "History search".)',
                       get_current_value=lambda:['off','on'][self.complete_while_typing],
                       get_values=lambda:{
                           'on':lambda:enable('complete_while_typing'),
                           'off':lambda:disable('complete_while_typing'),
                       }),
                simple_option(title='Auto suggestion',
                    is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Auto suggest inputs by looking at the history. '
                                          'Pressing right arrow or Ctrl-E will complete the entry.',
                              field_name='enable_auto_suggest'),
                simple_option(title='Show signature',
                              description='Display function signatures.',
                              field_name='show_signature'),
                simple_option(title='Show docstring',
                        is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Display function docstrings.',
                              field_name='show_docstring'),
                simple_option(title='Jedi dynamic imports',
                    is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Allow Jedi to import unloaded modules for completions. '
                                          'Disable for faster completions on NFS.',
                              field_name='allow_jedi_dynamic_imports'),
                simple_option(title='Semantic highlighting',
                              description='Use Jedi to highlight callables and modules with semantic colors. '
                                          'Disable for slightly faster typing.',
                              field_name='enable_semantic_highlighting'),
            ]),
            OptionCategory('Ryan Python',[
                # Option(title='Sand Creature',
                #         is_visible=lambda:getattr(self,'show_all_options',True),

                #        description='This is an option selection test that should print stuff',
                #        get_current_value=lambda:getattr(self,'sand_creature','(Broken)'),
                #        get_values=lambda:{
                #            "Option Llama":lambda:setattr(self,'sand_creature',"Option Llama"),# print("Selected Llama"),
                #            "Option Donkey":lambda:setattr(self,'sand_creature',"Option Donkey"),# print("Selected Donkey"),
                #            "Option Camel":lambda:doge(self),# print("Selected Camel"),
                #        }),
                Option(title='Show Last Assignable',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='Should we show the variable in purple box on the bottom of the screen?',
                       get_current_value=lambda:getattr(self,'show_last_assignable','(Broken)'),
                       get_values=lambda:{
                           True:lambda:setattr(self,'show_last_assignable',True),# print("Selected Llama"),
                           False:lambda:setattr(self,'show_last_assignable',False),# print("Selected Donkey"),
                       }),
                Option(title='Space-Functions',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='Turning this on lets pressing the space bar autocomplete a \nfunction for you as well as adding parenthesis around it.\n(Its like pressing tab followed by the spacebar).',
                       get_current_value=lambda:"on" if ric.enable_space_autocompletions else "off",
                       get_values=lambda:{
                           "on":lambda:ric.enable_space_autocompletions.append(None),# print("Selected Llama"),
                           "off":lambda:ric.enable_space_autocompletions.clear(),# print("Selected Donkey"),
                       }),
                Option(title='Completion Type',
                       description='This option determines how autocompletion suggestions are made.\nIf set to \'good\', it will use Jedi to statically analyze your code, providing better insight.\nOtherwise, if set to \'fast\', it will perform mostly simple autocompletions, that will appear much faster.',
                       get_current_value=lambda:"fast" if ric.completion_style==['fast'] else "good",
                       get_values=lambda:{
                           "fast" :lambda:ric.completion_style.__setitem__(0,'fast'),# print("Selected Llama"),
                           "good" :lambda:ric.completion_style.__setitem__(0,'good'),# print("Selected Donkey"),
                       }),
                simple_option(title='Parenthesizer',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                              description='bla',
                              field_name='show_parenthesis_automator'),
                simple_option(title='Realtime Eval',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                              description='bla',
                              field_name='show_realtime_input'),
                simple_option(title='Show VARS',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                              description='bla',
                              field_name='show_vars'),
                Option(title='Debugger UI Height',
                        is_visible=lambda:getattr(self,'show_all_options',True),

                       description='The height of the GUI when running debug()',
                       get_current_value=lambda:str(ric.debug_height),
                       get_values=lambda:{
                            '5':lambda:set_debug_height(5),
                            '10':lambda:set_debug_height(10),
                            '15':lambda:set_debug_height(15),
                            '20':lambda:set_debug_height(20),
                            '25':lambda:set_debug_height(25),
                            '30':lambda:set_debug_height(30),
                            '35':lambda:set_debug_height(35),
                            '40':lambda:set_debug_height(40),
                            '45':lambda:set_debug_height(45),
                            '50':lambda:set_debug_height(50),
                            '55':lambda:set_debug_height(55),
                            '60':lambda:set_debug_height(60),
                            '65':lambda:set_debug_height(65),
                            '70':lambda:set_debug_height(70),
                            '75':lambda:set_debug_height(75),
                            '80':lambda:set_debug_height(80),
                            '85':lambda:set_debug_height(85),
                            '90':lambda:set_debug_height(90),
                            '95':lambda:set_debug_height(95),
                            '100':lambda:set_debug_height(100),
                       }),
            ]),
            OptionCategory('Color Themes',[
                # Code-related options
                Option(title='Code',
                       description='Color scheme to use for the Python code.',
                       get_current_value=lambda:self._current_code_style_name[:15],
                       get_values=lambda:dict(
                           (name,partial(self.use_code_colorscheme,name)) for name in self.code_styles)
                       ),
                Option(title='Invert Code Colors',
                       description='Invert foreground and background colors for code syntax highlighting.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: ['off', 'on'][self.code_invert_colors],
                       get_values=lambda:{
                           'on': lambda: setattr(self, 'code_invert_colors', True) or self._update_style(),
                           'off': lambda: setattr(self, 'code_invert_colors', False) or self._update_style(),
                       }),
                Option(title='Invert Code Brightness',
                       description='Invert brightness of code syntax highlighting while preserving color hue.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: ['off', 'on'][self.code_invert_brightness],
                       get_values=lambda:{
                           'on': lambda: setattr(self, 'code_invert_brightness', True) or self._update_style(),
                           'off': lambda: setattr(self, 'code_invert_brightness', False) or self._update_style(),
                       }),
                Option(title='Code Hue Shift',
                       description='Shift the hue of code syntax highlighting by the specified number of degrees.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:03d}'.format(self.code_hue_shift),
                       get_values=lambda: dict(
                           ('{:03d}'.format(degrees), lambda degrees=degrees: setattr(self, 'code_hue_shift', degrees) or self._update_style())
                           for degrees in range(0, 360, 5)
                       )),
                Option(title='Code Min Brightness',
                       description='Set the minimum brightness level for code elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.code_min_brightness),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_min_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='Code Max Brightness',
                       description='Set the maximum brightness level for code elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.code_max_brightness),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_max_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='Code Min Saturation',
                       description='Set the minimum saturation level for code elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.code_min_saturation),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_min_saturation', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='Code Max Saturation',
                       description='Set the maximum saturation level for code elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.code_max_saturation),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_max_saturation', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                       
                # Code UI elements brightness controls (separate from code brightness)
                Option(title='Code UI Min Brightness',
                       description='Set the minimum brightness level for code UI elements (whitespace, indent guides, row/column highlights).',
                       get_current_value=lambda: '{:0.2f}'.format(self.code_ui_min_brightness if self.code_ui_min_brightness is not None else 0.0),
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_ui_min_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='Code UI Max Brightness',
                       description='Set the maximum brightness level for code UI elements (whitespace, indent guides, row/column highlights).',
                       get_current_value=lambda: '{:0.2f}'.format(self.code_ui_max_brightness if self.code_ui_max_brightness is not None else 1.0),
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'code_ui_max_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                
                # UI-related options
                Option(title='User Interface',
                       description='Color scheme to use for the user interface.',
                       get_current_value=lambda:self._current_ui_style_name[:15],
                       get_values=lambda:dict(
                           (name,partial(self.use_ui_colorscheme,name)) for name in self.ui_styles)
                       ),
                Option(title='Invert UI Colors',
                       description='Invert foreground and background colors for UI elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: ['off', 'on'][self.ui_invert_colors],
                       get_values=lambda:{
                           'on': lambda: setattr(self, 'ui_invert_colors', True) or self._update_style(),
                           'off': lambda: setattr(self, 'ui_invert_colors', False) or self._update_style(),
                       }),
                Option(title='Invert UI Brightness',
                       description='Invert brightness of UI elements while preserving color hue.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: ['off', 'on'][self.ui_invert_brightness],
                       get_values=lambda:{
                           'on': lambda: setattr(self, 'ui_invert_brightness', True) or self._update_style(),
                           'off': lambda: setattr(self, 'ui_invert_brightness', False) or self._update_style(),
                       }),
                Option(title='UI Hue Shift',
                       description='Shift the hue of UI elements by the specified number of degrees.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:03d}'.format(self.ui_hue_shift),
                       get_values=lambda: dict(
                           ('{:03d}'.format(degrees), lambda degrees=degrees: setattr(self, 'ui_hue_shift', degrees) or self._update_style())
                           for degrees in range(0, 360, 5)
                       )),
                Option(title='UI Min Brightness',
                       description='Set the minimum brightness level for UI elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.ui_min_brightness),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'ui_min_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='UI Max Brightness',
                       description='Set the maximum brightness level for UI elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.ui_max_brightness),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'ui_max_brightness', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='UI Min Saturation',
                       description='Set the minimum saturation level for UI elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.ui_min_saturation),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'ui_min_saturation', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                Option(title='UI Max Saturation',
                       description='Set the maximum saturation level for UI elements.',
                       is_visible=lambda: getattr(self, 'show_all_options', False),
                       get_current_value=lambda: '{:0.2f}'.format(self.ui_max_saturation),
                       get_values=lambda: dict(
                           ('{:0.2f}'.format(value/50), lambda value=value: setattr(self, 'ui_max_saturation', value/50) or self._update_style())
                           for value in range(0,51)
                       )),
                       
                Option(title='BG/FG Contrast',
                       description='Set the minimum brightness difference between foreground and background. 0.0 allows identical colors, higher values increase contrast.',
                       get_current_value=lambda: '{:.2f}'.format(self.ui_bg_fg_contrast),
                       get_values=lambda: dict(
                           ('{:.2f}'.format(value/50), lambda value=value: setattr(self, 'ui_bg_fg_contrast', value/50) or self._update_style())
                           for value in range(0, 50)  # Only go up to 0.98
                       )),
                
                # General color options
                simple_option(title='True color (24 bit)',
                        # is_visible=lambda:getattr(self,'show_all_options',True),
                              description='Use 24 bit colors instead of 256 colors\nThis is only supported on some terminal apps\nSome known to support it: Ubuntu\'s default terminal, MacOS iTerm',
                              field_name='true_color'),
            ]),
            OptionCategory('This Menu',[
                                Option(title='Show All Options',
                       description='If turned on, will show more options in this menu.\nIf turned off, will try to keep this menu simple.',
                       get_current_value=lambda:getattr(self,'show_all_options',False),
                       get_values=lambda:{
                           True:lambda:setattr(self,'show_all_options',True),# print("Selected Llama"),
                           False:lambda:setattr(self,'show_all_options',False),# print("Selected Donkey"),
                       }),

            ]),
        ]

    def create_application(self):
        """
        Create an `Application` instance for use in a `CommandLineInterface`.
        """
        buffers={
            'docstring':Buffer(read_only=True),
            'realtime_display':Buffer(read_only=True),
            'vars':Buffer(read_only=True),
            'parenthesizer_buffer':Buffer(read_only=True),
        }
        for key in r_iterm_comm.python_input_buffers:
            buffers[key]=Buffer(read_only=True)
        buffers.update(self._extra_buffers or {})

        return Application(
            layout=create_layout(
                self,
                lexer=self._lexer,
                input_buffer_height=self._input_buffer_height,
                extra_buffer_processors=self._extra_buffer_processors,
                extra_body=self._extra_layout_body,
                extra_toolbars=self._extra_toolbars),
            buffer=self._create_buffer(),
            buffers=buffers,
            key_bindings_registry=self.key_bindings_registry,
            paste_mode=Condition(lambda cli:self.paste_mode),
            mouse_support=Condition(lambda cli:self.enable_mouse_support),
            on_abort=AbortAction.RETRY,
            on_exit=self._on_exit,
            style=DynamicStyle(lambda:self._current_style),
            get_title=lambda:self.terminal_title,
            reverse_vi_search_direction=True,
            on_initialize=self._on_cli_initialize,
            on_start=self._on_start,
            on_input_timeout=self._on_input_timeout)

    def _create_buffer(self):
        """
        Create the `Buffer` for the Python input.
        """
        def is_buffer_multiline():
            return (self.paste_mode or
                    self.accept_input_on_enter is None or
                    document_is_multiline_python(python_buffer.document))

        python_buffer=Buffer(
            is_multiline=Condition(is_buffer_multiline),
            complete_while_typing=Condition(lambda:self.complete_while_typing),
            enable_history_search=Condition(lambda:self.enable_history_search),
            tempfile_suffix='.py',
            history=self.history,
            completer=self._completer,
            validator=ConditionalValidator(
                self._validator,
                Condition(lambda:self.enable_input_validation)),
            auto_suggest=ConditionalAutoSuggest(
                AutoSuggestFromHistory(),
                Condition(lambda cli:self.enable_auto_suggest)),
            accept_action=self._accept_action)

        return python_buffer

    def _on_cli_initialize(self,cli):
        """
        Called when a CommandLineInterface has been created.
        """
        # Synchronize PythonInput state with the CommandLineInterface.
        def synchronize(_=None):
            if self.vi_mode:
                cli.editing_mode=EditingMode.VI
            else:
                cli.editing_mode=EditingMode.EMACS

        cli.input_processor.beforeKeyPress+=synchronize
        cli.input_processor.afterKeyPress+=synchronize
        synchronize()

    def _on_input_timeout(self,cli):
        """
        When there is no input activity,
        in another thread, get the signature of the current code.
        """
        if cli.current_buffer_name != DEFAULT_BUFFER:
            return

        # Never run multiple get-signature threads.
        if self._get_signatures_thread_running:
            return
        self._get_signatures_thread_running=True

        buffer=cli.current_buffer
        document=buffer.document

        def run():
            from .completer import get_jedi_interpreter
            try:
                # Use same backspacing logic as completions to hit the cache
                cache_info = self._completer.get_cache_key_for_document(document)

                # Try to get cached interpreter first
                jedi_info = self._completer._completion_cache.get_cached_interpreter(
                    cache_info.cache_text,
                    cache_info.cache_pos
                )

                is_cache_hit = jedi_info is not None

                # If not cached, compute it
                if jedi_info is None:
                    jedi_info = get_jedi_interpreter(
                        cache_info.cache_text,
                        cache_info.cache_pos,
                        self.get_globals(),
                        self.get_locals()
                    )

                import rp.rp_ptpython.r_iterm_comm
                rp.rp_ptpython.r_iterm_comm.script_debug = jedi_info.interpreter
                rp.rp_ptpython.r_iterm_comm.signature_cache_hit = is_cache_hit
                # Show signatures in help text.
                try:
                    signatures = jedi_info.interpreter.get_signatures(jedi_info.line, jedi_info.column)
                except ValueError:
                    # e.g. in case of an invalid \\x escape.
                    signatures=[]
                except Exception:
                    # Sometimes we still get an exception (TypeError), because
                    # of probably bugs in jedi. We can silence them.
                    # See: https://github.com/davidhalter/jedi/issues/492
                    signatures=[]
                else:
                    # Try to access the params attribute just once. For Jedi
                    # signatures containing the keyword-only argument star,
                    # this will crash when retrieving it the first time with
                    # AttributeError. Every following time it works.
                    # See: https://github.com/jonathanslenders/ptpython/issues/47
                    #      https://github.com/davidhalter/jedi/issues/598
                    try:
                        if signatures:
                            signatures[0].params
                    except AttributeError:
                        pass
            except Exception:
                signatures = []

            self._get_signatures_thread_running=False

            # Set signatures and redraw if the text didn't change in the
            # meantime. Otherwise request new signatures.
            if buffer.text == document.text:
                self.signatures=signatures

                # Set docstring in docstring buffer.
                if signatures:
                    string=signatures[0].docstring()
                    if not isinstance(string,six.text_type):
                        string=string.decode('utf-8')
                    cli.buffers['docstring'].reset(
                        initial_document=Document(string,cursor_position=0))
                else:
                    cli.buffers['docstring'].reset()

                cli.request_redraw()
            else:
                self._on_input_timeout(cli)
            import rp.rp_ptpython.r_iterm_comm as r_iterm_comm
            r_iterm_comm.current_input_text=document.text
            if self.show_realtime_input:
                cli.buffers['realtime_display'].reset(initial_document=Document(str(r_iterm_comm.rp_evaluator(document.text))[:100000],cursor_position=0))
                # cli.buffers['realtime_display'].reset(initial_document=Document(str(r_iterm_comm.rp_evaluator(document.text))[::100000],cursor_position=0))
            if self.show_vars:
                cli.buffers['vars'].reset(initial_document=Document(str(r_iterm_comm.rp_VARS_display),cursor_position=0))
            for key in r_iterm_comm.python_input_buffers:
                try:cli.buffers[key].reset(initial_document=Document(str(r_iterm_comm.python_input_buffers[key]),cursor_position=0))
                except:pass
            from rp import parenthesizer_automator
            if self.show_parenthesis_automator:
                xxxxp=str((parenthesizer_automator(document.current_line)))
                r_iterm_comm.parenthesized_line=xxxxp
                cli.buffers['parenthesizer_buffer'].reset(initial_document=Document(xxxxp[:2000],cursor_position=0))
            # cli.buffers['realtime_display'].reset(initial_document=Document(r_iterm_comm.realtime_display_string,cursor_position=0))

        cli.eventloop.run_in_executor(run)

    def on_reset(self,cli):
        self.signatures=[]

    def enter_history(self,cli):
        """
        Display the history.
        """
        cli.vi_state.input_mode=InputMode.NAVIGATION

        def done(result):
            if result is not None:
                cli.buffers[DEFAULT_BUFFER].document=result

            cli.vi_state.input_mode=InputMode.INSERT

        cli.run_sub_application(create_history_application(
            self,cli.buffers[DEFAULT_BUFFER].document),done)

class ConstrainedHeightRenderer:
    """
    Entire class written by Claude on MacX, Jul 14 2025 to solve the prompt height percent glitchiness
    Custom renderer that handles height constraints properly.
    """
    def __init__(self, original_renderer, output):
        self._original_renderer = original_renderer
        self._output = output
    
    @property 
    def height_is_known(self):
        # Always return True when we have height constraints to ensure status bar shows
        if hasattr(self._output, 'get_real_size'):
            import rp.rp_ptpython.r_iterm_comm as ric
            top_space_percent = ric.options.get('top_space', 0)
            if top_space_percent > 0:
                return True
        return self._original_renderer.height_is_known
    
    def __getattr__(self, name):
        return getattr(self._original_renderer, name)


class ConstrainedHeightOutput(Output):
    """
    Entire class written by Claude on MacX, Jul 14 2025 to solve the prompt height percent glitchiness
    Output wrapper that modifies get_size() to implement Prompt Height Percent
    without affecting actual terminal output.
    """
    def __init__(self, output):
        self._output = output
    
    def get_size(self):
        """Override get_size to apply height constraints for layout."""
        real_size = self._output.get_size()
        
        import rp.rp_ptpython.r_iterm_comm as ric
        top_space_percent = ric.options.get('top_space', 0)
        min_rows = ric.options.get('min_bot_space', 15)
        
        if top_space_percent <= 0:
            # No constraint
            return real_size
        
        # Check if this is being called for renderer height detection
        # In that case, we want to return real size for proper calculation
        import inspect
        frame = inspect.currentframe()
        try:
            for _ in range(5):  # Check a few frames up
                frame = frame.f_back
                if frame is None:
                    break
                # If called from request_absolute_cursor_position, return real size    
                if frame.f_code.co_name == 'request_absolute_cursor_position':
                    return real_size
        finally:
            del frame
        
        # Apply the same logic as the original hack for layout
        total_rows = real_size.rows
        top_space_rows = int(total_rows * top_space_percent / 100)
        constrained_rows = max(min_rows, total_rows - top_space_rows)
        
        from rp.prompt_toolkit.layout.screen import Size
        return Size(rows=constrained_rows, columns=real_size.columns)
    
    def get_real_size(self):
        """Get the actual terminal size without height constraints."""
        return self._output.get_size()
    
    # Implement all Output interface methods by delegating to wrapped output
    def fileno(self):
        return self._output.fileno()
    
    def encoding(self):
        return self._output.encoding()
    
    def write(self, data):
        return self._output.write(data)
    
    def write_raw(self, data):
        return self._output.write_raw(data)
    
    def set_title(self, title):
        return self._output.set_title(title)
    
    def clear_title(self):
        return self._output.clear_title()
    
    def flush(self):
        return self._output.flush()
    
    def erase_screen(self):
        return self._output.erase_screen()
    
    def enter_alternate_screen(self):
        return self._output.enter_alternate_screen()
    
    def quit_alternate_screen(self):
        return self._output.quit_alternate_screen()
    
    def enable_mouse_support(self):
        return self._output.enable_mouse_support()
    
    def disable_mouse_support(self):
        return self._output.disable_mouse_support()
    
    def erase_end_of_line(self):
        return self._output.erase_end_of_line()
    
    def erase_down(self):
        return self._output.erase_down()
    
    def reset_attributes(self):
        return self._output.reset_attributes()
    
    def set_attributes(self, attrs):
        return self._output.set_attributes(attrs)
    
    def disable_autowrap(self):
        return self._output.disable_autowrap()
    
    def enable_autowrap(self):
        return self._output.enable_autowrap()
    
    def cursor_goto(self, row=0, column=0):
        return self._output.cursor_goto(row, column)
    
    def cursor_up(self, amount):
        return self._output.cursor_up(amount)
    
    def cursor_down(self, amount):
        return self._output.cursor_down(amount)
    
    def cursor_forward(self, amount):
        return self._output.cursor_forward(amount)
    
    def cursor_backward(self, amount):
        return self._output.cursor_backward(amount)
    
    def hide_cursor(self):
        return self._output.hide_cursor()
    
    def show_cursor(self):
        return self._output.show_cursor()
    
    def ask_for_cpr(self):
        return self._output.ask_for_cpr()
    
    def bell(self):
        return self._output.bell()
    
    def enable_bracketed_paste(self):
        return self._output.enable_bracketed_paste()
    
    def disable_bracketed_paste(self):
        return self._output.disable_bracketed_paste()


class PythonCommandLineInterface(CommandLineInterface):
    def __init__(self,eventloop=None,python_input=None,input=None,output=None):
        assert python_input is None or isinstance(python_input,PythonInput)

        python_input=python_input or PythonInput()

        # Make sure that the rp.prompt_toolkit 'renderer' knows about the
        # 'true_color' property of PythonInput.
        if output is None:
            output=create_output(true_color=Condition(lambda:python_input.true_color))
        
        # Wrap the output to apply height constraints
        output = ConstrainedHeightOutput(output)

        super(PythonCommandLineInterface,self).__init__(
            application=python_input.create_application(),
            eventloop=eventloop,
            input=input,
            output=output)
            
        # If we're using a constrained output, wrap the renderer to fix height detection
        if isinstance(output, ConstrainedHeightOutput):
            self.renderer = ConstrainedHeightRenderer(self.renderer, output)
