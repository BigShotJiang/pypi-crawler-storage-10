"""
TroveSuite Package

A comprehensive authentication, authorization, and notification service for ERP systems.
Provides JWT token validation, user authorization, permission checking, and notification capabilities.
"""

from .auth import AuthService
from .notification import NotificationService

__version__ = "1.0.8"
__author__ = "Bright Debrah Owusu"
__email__ = "owusu.debrah@deladetech.com"

__all__ = [
    "AuthService",
    "NotificationService"
]
