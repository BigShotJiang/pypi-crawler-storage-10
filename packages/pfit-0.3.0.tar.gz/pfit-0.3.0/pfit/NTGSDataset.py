class NtgsThermalDataset:

    def __init__(self):
        pass

    def check(self):
        pass

    def to_ncdf(self):
        pass