from .app import ShortcutApp
