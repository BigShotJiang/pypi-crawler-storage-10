from .app import SpotifyApp
