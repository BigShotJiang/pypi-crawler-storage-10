#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
УРАБИ.РФ - Квантовая криптография и блокчейн технологии

Пакет содержит реализации квантовых криптографических алгоритмов
и блокчейн решений.
"""

__version__ = "1.0.0"
__author__ = "УРАБИ.РФ"
__email__ = "info@ураби.рф"

# Импорт основных модулей
from . import crypto
from . import blockchain

# Основные классы для импорта
__all__ = [
    "crypto",
    "blockchain",
    "__version__",
    "__author__",
    "__email__",
]

# Информация о пакете
PACKAGE_INFO = {
    "name": "УРАБИ Криптографические Решения",
    "description": "Квантовые криптографические и блокчейн решения",
    "version": __version__,
    "author": __author__,
    "specializations": [
        "Квантовая Криптография",
        "Блокчейн Решения",
        "Квантовые Случайные Числа",
        "Постквантовая Криптография"
    ],
    "standards": [
        "Квантовые стандарты",
        "Блокчейн стандарты"
    ],
    "compliance": [
        "Квантовые стандарты безопасности"
    ]
}

def get_package_info():
    """Получить информацию о пакете УРАБИ"""
    return PACKAGE_INFO.copy()

def get_specializations():
    """Получить список специализаций"""
    return PACKAGE_INFO["specializations"].copy()

def get_standards():
    """Получить список поддерживаемых стандартов"""
    return PACKAGE_INFO["standards"].copy()

def get_compliance():
    """Получить список соответствий"""
    return PACKAGE_INFO["compliance"].copy()