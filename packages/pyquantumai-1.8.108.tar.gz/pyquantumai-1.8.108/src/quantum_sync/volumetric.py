"""
QuantumVolumetricInterference - Объёмная интерференция внутри пирамиды

Принцип:
- Каждая грань пирамиды = модель с hidden states
- Внутри пирамиды (объём) = интерференция всех hidden states
- На каждом шаге генерации токена:
  1. Все модели вычисляют свои hidden states параллельно
  2. Hidden states проецируются в объём пирамиды
  3. Интерференция в объёме создаёт "квантовую суперпозицию"
  4. Результирующий токен = результат интерференции

Аналогия с физикой:
- Световые волны от 4 граней интерферируют
- Паттерн интерференции = выбор нейрона
- Результат = усиленное/подавленное поле

© 2025 NativeMind
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class VolumetricInterference:
    """Результат объёмной интерференции"""
    # Координаты в объёме пирамиды (0-1 в нормированных координатах)
    x: float  # Глубина пирамиды
    y: float  # Горизонтальная позиция
    z: float  # Вертикальная позиция
    
    # Интерференционная картина
    intensity: float      # Интенсивность (0.0-1.0)
    phase: float         # Фаза (0-2π)
    coherence: float     # Когерентность (0.0-1.0)
    
    # Вклад каждой грани
    face_contributions: Dict[int, float]  # {face_id: contribution}


class VolumetricInterferenceLayer(nn.Module):
    """
    Слой объёмной интерференции
    
    Преобразует hidden states от всех граней в интерференционную картину
    """
    
    def __init__(
        self,
        hidden_dim: int,
        num_faces: int = 4,
        volume_resolution: int = 10  # Разрешение объёма (10x10x10)
    ):
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.num_faces = num_faces
        self.volume_resolution = volume_resolution
        
        # Проекция каждой грани в объём
        self.face_projectors = nn.ModuleList([
            nn.Linear(hidden_dim, hidden_dim) for _ in range(num_faces)
        ])
        
        # Объёмный резонатор (3D слой)
        self.volume_processor = nn.Sequential(
            nn.Conv3d(num_faces, hidden_dim, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv3d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        )
        
        # Свёртка объёма обратно в hidden states
        self.volume_to_hidden = nn.Linear(
            hidden_dim * volume_resolution ** 3,
            hidden_dim
        )
        
    def forward(
        self,
        hidden_states: List[torch.Tensor],  # Список hidden states от каждой грани
        step: int  # Номер шага генерации
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Применение объёмной интерференции
        
        Args:
            hidden_states: List of [batch_size, seq_len, hidden_dim]
            step: Номер токена в генерации
        
        Returns:
            (interfered_hidden_states, interference_pattern)
        """
        batch_size = hidden_states[0].shape[0]
        seq_len = hidden_states[0].shape[1]
        
        # 1. Проецируем каждую грань в объём
        volume_waves = []
        for face_id, (projector, hidden) in enumerate(
            zip(self.face_projectors, hidden_states)
        ):
            # Проекция
            projected = projector(hidden)  # [batch, seq, hidden_dim]
            
            # Преобразуем в объём (expand в 3D)
            # [batch, seq, hidden_dim] -> [batch, hidden_dim, 10, 10, 10]
            volume_wave = self._hidden_to_volume(projected)
            volume_waves.append(volume_wave)
        
        # 2. Конкатенация волн от всех граней
        # [batch, num_faces, hidden_dim, 10, 10, 10]
        combined_volume = torch.stack(volume_waves, dim=1)
        
        # 3. Интерференция в объёме (3D conv)
        interfered_volume = self.volume_processor(combined_volume)
        
        # 4. Возвращаем в hidden states
        interfered_volume_flat = interfered_volume.flatten(1)  # [batch, hidden*1000]
        interfered_hidden = self.volume_to_hidden(interfered_volume_flat)
        interfered_hidden = interfered_hidden.unsqueeze(1)  # [batch, 1, hidden]
        
        # 5. Вычисляем паттерн интерференции для анализа
        interference_pattern = self._compute_interference_pattern(
            volume_waves, step
        )
        
        return interfered_hidden, interference_pattern
    
    def _hidden_to_volume(self, hidden: torch.Tensor) -> torch.Tensor:
        """Преобразование hidden states в 3D объём"""
        batch, seq, dim = hidden.shape
        
        # Инициализируем объём
        volume = torch.zeros(
            batch, dim, 
            self.volume_resolution,
            self.volume_resolution, 
            self.volume_resolution
        ).to(hidden.device)
        
        # Распределяем hidden states по объёму
        for i in range(seq):
            for d in range(min(dim, self.hidden_dim)):
                # Геометрическое распределение (как волновые фронты)
                x = int((i / seq) * self.volume_resolution)
                y = int((d / dim) * self.volume_resolution)
                z = min(d, self.volume_resolution - 1)
                
                volume[:, d, x, y, z] = hidden[:, i, d]
        
        return volume
    
    def _compute_interference_pattern(
        self,
        volume_waves: List[torch.Tensor],
        step: int
    ) -> Dict:
        """Вычисление паттерна интерференции"""
        # Извлекаем интенсивности от каждой грани
        intensities = []
        for wave in volume_waves:
            intensity = torch.abs(wave).mean().item()
            intensities.append(intensity)
        
        # Фазы
        phases = []
        for wave in volume_waves:
            phase = torch.angle(torch.fft.fftn(wave)).mean().item()
            phases.append(phase)
        
        # Когерентность (корреляция между волнами)
        coherence = 0.0
        if len(volume_waves) > 1:
            coherence = self._compute_coherence(volume_waves)
        
        return {
            'step': step,
            'intensities': intensities,
            'phases': phases,
            'coherence': coherence,
            'total_interference': sum(intensities)
        }
    
    def _compute_coherence(self, waves: List[torch.Tensor]) -> float:
        """Вычисление когерентности между волнами"""
        # Корреляция между первой и остальными волнами
        if len(waves) < 2:
            return 1.0
        
        base_wave = waves[0]
        correlations = []
        
        for wave in waves[1:]:
            # Нормализация
            base_norm = base_wave.flatten()
            wave_norm = wave.flatten()
            
            # Корреляция
            corr = torch.cosine_similarity(
                base_norm, wave_norm, dim=0
            ).item()
            
            correlations.append(abs(corr))
        
        return sum(correlations) / len(correlations)


class QuantumVolumetricInterference:
    """
    Главный класс для объёмной интерференции в пирамиде
    
    На КАЖДОМ шаге генерации токена:
    1. Все модели вычисляют hidden states
    2. Hidden states интерферируют в объёме пирамиды
    3. Выбирается следующий токен из интерференционной картины
    
    ОПТИМИЗАЦИЯ ДЛЯ PEFT:
    - Базовая модель загружается ОДИН раз
    - Все LoRA адаптеры используют ОБЩУЮ базу
    - Экономия памяти: вместо N × (base + lora) → base + N × lora
    - Скорость: параллельная интерференция адаптеров
    """
    
    def __init__(
        self,
        model_paths: List[str],  # Пути к моделям на гранях
        tokenizers: List,
        hidden_dim: int,
        resonance_freq: float = 440.0,
        base_model_name: Optional[str] = None  # Базовая модель для PEFT
    ):
        self.model_paths = model_paths
        self.tokenizers = tokenizers
        self.hidden_dim = hidden_dim
        self.resonance_freq = resonance_freq
        
        # Загружаем модели с оптимизацией для PEFT
        print("📦 Загрузка моделей для объёмной интерференции...")
        self.models = []
        from transformers import AutoModelForCausalLM
        from peft import PeftModel
        import os
        
        # Определяем базовую модель
        if base_model_name is None:
            # Пробуем определить автоматически
            try:
                from transformers import AutoConfig
                config = AutoConfig.from_pretrained(model_paths[0])
                # Проверяем наличие adapter_config.json (признак PEFT)
                if os.path.exists(os.path.join(config.name_or_path, "adapter_config.json")):
                    # Это PEFT модель, нужна базовая модель
                    base_model_name = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
                    print(f"   🔍 Обнаружены PEFT модели, базовая: {base_model_name}")
                else:
                    base_model_name = None
            except:
                base_model_name = None
        
        # Загружаем базовую модель один раз (для PEFT)
        base_model = None
        if base_model_name:
            print(f"   📥 Загрузка базовой модели: {base_model_name}")
            base_model = AutoModelForCausalLM.from_pretrained(
                base_model_name,
                torch_dtype=torch.float16,
                device_map="auto",
                trust_remote_code=True
            )
            print(f"      ✅ Базовая модель загружена")
        
        # Загружаем модели/адаптеры для каждой грани
        for i, model_path in enumerate(model_paths):
            print(f"   Грань {i}: {model_path}")
            
            try:
                if base_model is not None:
                    # Загружаем PEFT адаптер
                    model = PeftModel.from_pretrained(base_model, model_path)
                    print(f"      ✅ LoRA адаптер загружен")
                else:
                    # Загружаем полную модель
                    model = AutoModelForCausalLM.from_pretrained(
                        model_path,
                        torch_dtype=torch.float16,
                        device_map="auto",
                        trust_remote_code=True
                    )
                    print(f"      ✅ Модель загружена")
            except Exception as e:
                print(f"      ⚠️ Ошибка загрузки: {e}")
                # Fallback: пробуем загрузить без PEFT
                model = AutoModelForCausalLM.from_pretrained(
                    model_path,
                    torch_dtype=torch.float16,
                    device_map="auto",
                    trust_remote_code=True
                )
                print(f"      ✅ Модель загружена (fallback)")
            
            model.eval()
            self.models.append(model)
        
        # Интерференционный слой
        self.interference_layer = VolumetricInterferenceLayer(
            hidden_dim=hidden_dim,
            num_faces=len(model_paths),
            volume_resolution=10
        ).to(self.models[0].device)
        
        # История интерференции
        self.interference_history = []
        
        # Определяем, являются ли модели PEFT
        self.is_peft = any(isinstance(m, type) and 'PeftModel' in str(type(m)) for m in self.models)
        if base_model_name:
            self.is_peft = True
        
        print(f"✅ {len(self.models)} моделей загружено")
        print(f"🎵 Резонанс: {resonance_freq} Hz")
        print(f"🔧 Режим: {'PEFT адаптеры' if self.is_peft else 'Полные модели'}")
        print()
    
    def generate_with_interference(
        self,
        prompt: str,
        max_length: int = 100,
        temperature: float = 0.8
    ) -> Tuple[str, List[Dict]]:
        """
        Генерация с объёмной интерференцией
        
        На КАЖДОМ шаге:
        1. Все модели генерируют hidden states
        2. Hidden states интерферируют в объёме
        3. Выбирается следующий токен из интерференции
        
        Returns:
            (generated_text, interference_patterns)
        """
        print(f"\n🌊 Генерация с объёмной интерференцией")
        print("=" * 80)
        print(f"Промпт: {prompt}")
        print(f"Макс. длина: {max_length}")
        print(f"Температура: {temperature}")
        print()
        
        # Используем первый токенизатор
        tokenizer = self.tokenizers[0]
        inputs = tokenizer(prompt, return_tensors="pt").to(self.models[0].device)
        
        generated_tokens = []
        interference_patterns = []
        
        # Генерация по одному токену
        for step in range(max_length):
            print(f"Шаг {step + 1}/{max_length}...", end="\r")
            
            # 1. Получаем hidden states от всех моделей параллельно
            hidden_states_all = []
            
            with torch.no_grad():
                for model in self.models:
                    outputs = model(
                        inputs,
                        output_hidden_states=True,
                        return_dict=True
                    )
                    # Берём последний hidden state
                    hidden = outputs.hidden_states[-1]
                    hidden_states_all.append(hidden)
            
            # 2. Применяем объёмную интерференцию
            self.interference_layer.eval()
            with torch.no_grad():
                interfered_hidden, pattern = self.interference_layer(
                    hidden_states_all, 
                    step=step
                )
            
            interference_patterns.append(pattern)
            self.interference_history.append(pattern)
            
            # 3. Вычисляем logits из интерферированного hidden state
            # Используем голову первой модели
            logits = self.models[0].lm_head(interfered_hidden)
            
            # 4. Сэмплируем следующий токен
            next_token_logits = logits[:, -1, :] / temperature
            next_token = torch.softmax(next_token_logits, dim=-1)
            next_token_id = torch.multinomial(next_token, num_samples=1)
            
            # 5. Добавляем к inputs
            # Создаём новый словарь inputs
            new_input_ids = torch.cat([inputs['input_ids'], next_token_id], dim=1)
            inputs = {'input_ids': new_input_ids}
            
            generated_tokens.append(next_token_id.item())
            
            # Проверка на конец генерации
            if next_token_id.item() == tokenizer.eos_token_id:
                break
        
        # Декодирование
        generated_text = tokenizer.decode(
            generated_tokens,
            skip_special_tokens=True
        )
        
        print()
        print(f"✅ Сгенерировано {len(generated_tokens)} токенов")
        print(f"📊 Паттернов интерференции: {len(interference_patterns)}")
        
        return generated_text, interference_patterns
    
    def visualize_interference_history(self) -> str:
        """Визуализация истории интерференции"""
        if not self.interference_history:
            return "История интерференции пуста"
        
        output = []
        output.append("🌊 История объёмной интерференции")
        output.append("=" * 80)
        
        for i, pattern in enumerate(self.interference_history):
            output.append(f"\nШаг {pattern['step']}:")
            output.append(f"  Когерентность: {pattern['coherence']:.3f}")
            output.append(f"  Интенсивность: {pattern['total_interference']:.3f}")
            output.append(f"  Интенсивности по граням: {[f'{x:.3f}' for x in pattern['intensities']]}")
        
        output.append("\n" + "=" * 80)
        
        return "\n".join(output)
    
    def generate_with_lora_interference(
        self,
        prompt: str,
        max_length: int = 100,
        temperature: float = 0.8
    ) -> Tuple[str, List[Dict]]:
        """
        Генерация с интерференцией LoRA адаптеров
        
        Отличие от generate_with_interference:
        - Используется ТОЛЬКО базовая модель + её forward
        - LoRA веса применяются к hidden states ЧЕРЕЗ интерференцию
        - Каждый адаптер вносит свой вклад в общую волновую картину
        
        Это моделирует обучение адаптеров друг с другом!
        """
        if not self.is_peft:
            print("⚠️ Метод работает только с PEFT моделями. Используйте generate_with_interference")
            return self.generate_with_interference(prompt, max_length, temperature)
        
        print(f"\n🧬 Генерация с интерференцией LoRA адаптеров")
        print("=" * 80)
        print(f"Промпт: {prompt}")
        print(f"Макс. длина: {max_length}")
        print(f"Температура: {temperature}")
        print()
        
        # Используем первый токенизатор
        tokenizer = self.tokenizers[0]
        inputs = tokenizer(prompt, return_tensors="pt").to(self.models[0].device)
        
        generated_tokens = []
        interference_patterns = []
        
        # Получаем базовую модель (она у всех одна)
        base_model = self.models[0].get_base_model()
        
        # Собираем LoRA веса всех адаптеров
        lora_adapters = []
        for model in self.models:
            if hasattr(model, 'peft_config') and model.peft_config:
                lora_adapters.append(model)
        
        # Генерация по одному токену
        for step in range(max_length):
            print(f"Шаг {step + 1}/{max_length}...", end="\r")
            
            # 1. Базовый forward
            with torch.no_grad():
                base_outputs = base_model(
                    inputs['input_ids'],
                    output_hidden_states=True,
                    return_dict=True
                )
                base_hidden = base_outputs.hidden_states[-1]
            
            # 2. Применяем LoRA адаптеры к hidden states
            lora_hidden_states = []
            for adapter in lora_adapters:
                # Применяем LoRA веса к hidden states
                lora_hidden = self._apply_lora_to_hidden(base_hidden, adapter)
                lora_hidden_states.append(lora_hidden)
            
            # 3. Интерференция LoRA hidden states
            self.interference_layer.eval()
            with torch.no_grad():
                interfered_hidden, pattern = self.interference_layer(
                    lora_hidden_states,
                    step=step
                )
            
            interference_patterns.append(pattern)
            self.interference_history.append(pattern)
            
            # 4. Вычисляем logits
            logits = self.models[0].lm_head(interfered_hidden)
            
            # 5. Сэмплируем токен
            next_token_logits = logits[:, -1, :] / temperature
            next_token = torch.softmax(next_token_logits, dim=-1)
            next_token_id = torch.multinomial(next_token, num_samples=1)
            
            # 6. Обновляем inputs
            new_input_ids = torch.cat([inputs['input_ids'], next_token_id], dim=1)
            inputs = {'input_ids': new_input_ids}
            
            generated_tokens.append(next_token_id.item())
            
            if next_token_id.item() == tokenizer.eos_token_id:
                break
        
        # Декодирование
        generated_text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
        
        print()
        print(f"✅ Сгенерировано {len(generated_tokens)} токенов")
        print(f"🧬 LoRA адаптеров использовано: {len(lora_adapters)}")
        print(f"📊 Паттернов интерференции: {len(interference_patterns)}")
        
        return generated_text, interference_patterns
    
    def _apply_lora_to_hidden(self, hidden: torch.Tensor, adapter) -> torch.Tensor:
        """Применение LoRA весов к hidden states"""
        # Упрощенная версия: применяем LoRA адаптацию
        # В реальности это делается через PEFT forward pass
        
        try:
            # Пробуем применить адаптер
            if hasattr(adapter, 'forward'):
                # Используем адаптер как модуль
                output = adapter.forward(hidden)
                return output
            else:
                # Fallback: просто возвращаем hidden
                return hidden
        except:
            return hidden
