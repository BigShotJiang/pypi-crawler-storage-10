#!/usr/bin/env python3
"""
Пример использования QuantumVolumetricInterference

Тестирование объёмной интерференции на реальных моделях из NativeMind:
https://huggingface.co/nativemind/models

© 2025 NativeMind
"""

import sys
from pathlib import Path

# Добавляем путь к модулям
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from transformers import AutoTokenizer
from quantum_sync.volumetric import QuantumVolumetricInterference


def test_sphere_models():
    """Тест объёмной интерференции на сферах 073-075"""
    
    print("=" * 80)
    print("🌊 Тест объёмной интерференции на сферах NativeMind")
    print("=" * 80)
    print()
    
    # Модели разработчиков с Hugging Face
    model_paths = [
        "nativemind/sphere_073_develop_coder",      # Кодер
        "nativemind/sphere_074_developer",          # Разработчик
        "nativemind/sphere_075_develop_architect",  # Архитектор
    ]
    
    # Загружаем токенизаторы
    print("📥 Загрузка токенизаторов...")
    tokenizers = []
    for path in model_paths:
        tokenizer = AutoTokenizer.from_pretrained(path)
        tokenizers.append(tokenizer)
        print(f"   ✅ {path}")
    
    print()
    
    # Создаём интерференцию
    # Используем hidden_dim=512 для TinyLlama
    # Указываем базовую модель для PEFT оптимизации
    interference = QuantumVolumetricInterference(
        model_paths=model_paths,
        tokenizers=tokenizers,
        hidden_dim=512,  # TinyLlama размерность
        resonance_freq=440.0,
        base_model_name="TinyLlama/TinyLlama-1.1B-Chat-v1.0"  # Базовая модель для LoRA
    )
    
    # Тестовые промпты
    test_prompts = [
        "Напиши функцию на Python для сортировки массива:",
        "Объясни принцип работы REST API:",
        "Как оптимизировать запрос к базе данных:",
        "Что такое SOLID принципы программирования:",
    ]
    
    # Генерация с интерференцией
    results = []
    
    for i, prompt in enumerate(test_prompts, 1):
        print(f"\n{'=' * 80}")
        print(f"Тест {i}/{len(test_prompts)}")
        print(f"{'=' * 80}")
        print()
        
        generated_text, patterns = interference.generate_with_interference(
            prompt=prompt,
            max_length=50,
            temperature=0.7
        )
        
        # Сохраняем результат
        result = {
            'prompt': prompt,
            'generated': generated_text,
            'patterns': patterns
        }
        results.append(result)
        
        # Выводим результат
        print(f"\n📝 Промпт: {prompt}")
        print(f"💬 Ответ: {generated_text}")
        print()
        
        # Статистика интерференции
        if patterns:
            avg_coherence = sum(p['coherence'] for p in patterns) / len(patterns)
            avg_intensity = sum(p['total_interference'] for p in patterns) / len(patterns)
            
            print(f"📊 Средняя когерентность: {avg_coherence:.3f}")
            print(f"📊 Средняя интенсивность: {avg_intensity:.3f}")
        
        print()
    
    # Визуализация истории интерференции
    print("\n" + "=" * 80)
    print("📈 История интерференции")
    print("=" * 80)
    print()
    print(interference.visualize_interference_history())
    
    return results


def test_judicial_spheres():
    """Тест на юридических сферах (047-049)"""
    
    print("\n" + "=" * 80)
    print("⚖️ Тест объёмной интерференции на юридических сферах")
    print("=" * 80)
    print()
    
    # Юридические модели
    model_paths = [
        "nativemind/sphere_047_m4_overnight",  # Следователь
        "nativemind/sphere-048-prosecutor",     # Прокурор
        "nativemind/sphere-049-judge",          # Судья
    ]
    
    # Загружаем токенизаторы
    print("📥 Загрузка токенизаторов...")
    tokenizers = []
    for path in model_paths:
        tokenizer = AutoTokenizer.from_pretrained(path)
        tokenizers.append(tokenizer)
        print(f"   ✅ {path}")
    
    print()
    
    # Создаём интерференцию
    interference = QuantumVolumetricInterference(
        model_paths=model_paths,
        tokenizers=tokenizers,
        hidden_dim=512,
        resonance_freq=440.0
    )
    
    # Юридические промпты
    legal_prompts = [
        "Проанализируй доказательства дела:",
        "Какие процессуальные нарушения допущены:",
        "Определи меру наказания за преступление:",
    ]
    
    # Генерация
    for i, prompt in enumerate(legal_prompts, 1):
        print(f"\n{'=' * 80}")
        print(f"Юридический тест {i}/{len(legal_prompts)}")
        print(f"{'=' * 80}")
        print()
        
        generated_text, patterns = interference.generate_with_interference(
            prompt=prompt,
            max_length=50,
            temperature=0.6  # Ниже температура для юридических текстов
        )
        
        print(f"📝 Промпт: {prompt}")
        print(f"💬 Ответ: {generated_text}")
        print()
    
    # Визуализация
    print(interference.visualize_interference_history())


def test_support_sphere():
    """Тест на сфере поддержки (028)"""
    
    print("\n" + "=" * 80)
    print("🎧 Тест объёмной интерференции на сфере поддержки")
    print("=" * 80)
    print()
    
    # Модели поддержки и продаж
    model_paths = [
        "nativemind/sphere-028-support",            # Поддержка
        "nativemind/sphere-027-sales-engineer",     # Продажи
    ]
    
    # Загружаем токенизаторы
    print("📥 Загрузка токенизаторов...")
    tokenizers = []
    for path in model_paths:
        tokenizer = AutoTokenizer.from_pretrained(path)
        tokenizers.append(tokenizer)
        print(f"   ✅ {path}")
    
    print()
    
    # Создаём интерференцию
    interference = QuantumVolumetricInterference(
        model_paths=model_paths,
        tokenizers=tokenizers,
        hidden_dim=512,
        resonance_freq=440.0
    )
    
    # Промпты поддержки
    support_prompts = [
        "Как помочь клиенту с проблемой платежа:",
        "Объясни преимущества нашего продукта:",
        "Как обработать жалобу клиента:",
    ]
    
    # Генерация
    for i, prompt in enumerate(support_prompts, 1):
        print(f"\n{'=' * 80}")
        print(f"Поддержка тест {i}/{len(support_prompts)}")
        print(f"{'=' * 80}")
        print()
        
        generated_text, patterns = interference.generate_with_interference(
            prompt=prompt,
            max_length=50,
            temperature=0.8  # Выше температура для естественности
        )
        
        print(f"📝 Промпт: {prompt}")
        print(f"💬 Ответ: {generated_text}")
        print()
    
    # Визуализация
    print(interference.visualize_interference_history())


def main():
    """Главная функция"""
    
    print("\n" + "🔮 " * 20)
    print("QuantumVolumetricInterference - Тестирование")
    print("🔮 " * 20)
    print()
    
    try:
        # Тест 1: Сферы разработчиков
        print("\n>>> ТЕСТ 1: Сферы разработчиков (073-075)")
        test_sphere_models()
        
        # Тест 2: Юридические сферы
        print("\n>>> ТЕСТ 2: Юридические сферы (047-049)")
        test_judicial_spheres()
        
        # Тест 3: Сфера поддержки
        print("\n>>> ТЕСТ 3: Сфера поддержки (028-027)")
        test_support_sphere()
        
        print("\n" + "=" * 80)
        print("✅ Все тесты завершены!")
        print("=" * 80)
        
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
