"""Validation framework for collection composition."""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from chora_compose.core.collection_composer import CollectionOutput


class CollectionValidationError(Exception):
    """Raised when collection validation fails."""

    pass


class BaseValidator(ABC):
    """Base class for collection validators."""

    @abstractmethod
    def validate(
        self, output: "CollectionOutput", config: dict[str, Any]
    ) -> tuple[bool, str]:
        """
        Validate collection output.

        Args:
            output: CollectionOutput from generation
            config: Validator-specific configuration

        Returns:
            (is_valid, message) tuple where:
            - is_valid: True if validation passed, False otherwise
            - message: Human-readable explanation of result
        """
        pass


class AllMembersPresentValidator(BaseValidator):
    """Validator that ensures all required members generated successfully."""

    def validate(
        self, output: "CollectionOutput", config: dict[str, Any]
    ) -> tuple[bool, str]:
        """
        Validate that all required members have status 'success'.

        Args:
            output: CollectionOutput from generation
            config: Not used for this validator

        Returns:
            (is_valid, message) tuple
        """
        failed_members = [m for m in output.members if m.status == "error"]

        if failed_members:
            failed_ids = [m.member_id for m in failed_members]
            return (
                False,
                f"Members failed: {', '.join(failed_ids)}",
            )

        return True, f"All {len(output.members)} members generated successfully"


class QualityThresholdValidator(BaseValidator):
    """Validator that ensures all members meet minimum quality score."""

    def validate(
        self, output: "CollectionOutput", config: dict[str, Any]
    ) -> tuple[bool, str]:
        """
        Validate that all members have quality_score >= min_score.

        Args:
            output: CollectionOutput from generation
            config: Must contain 'min_score' key (float)

        Returns:
            (is_valid, message) tuple
        """
        min_score = config.get("min_score", 0.8)

        # Check each member's quality score
        below_threshold = []
        for member in output.members:
            if member.status != "success":
                continue  # Skip failed members (handled by all_members_present)

            # For now, members don't have quality_score in MemberOutput
            # In full implementation, this would come from artifact generation
            quality_score = getattr(member, "quality_score", None)
            if quality_score is not None and quality_score < min_score:
                below_threshold.append((member.member_id, quality_score))

        if below_threshold:
            failures = [f"{mid} (score: {score:.2f})" for mid, score in below_threshold]
            return (
                False,
                f"Members below threshold {min_score}: {', '.join(failures)}",
            )

        return True, f"All members meet quality threshold {min_score}"


class CustomValidator(BaseValidator):
    """Validator that loads and executes custom validation functions."""

    def validate(
        self, output: "CollectionOutput", config: dict[str, Any]
    ) -> tuple[bool, str]:
        """
        Load and execute custom validator function.

        Args:
            output: CollectionOutput from generation
            config: Must contain 'module' and 'function' keys

        Returns:
            (is_valid, message) tuple
        """
        import importlib

        module_name = config.get("module")
        function_name = config.get("function")

        if not module_name or not function_name:
            return (
                False,
                "Custom validator requires 'module' and 'function' in config",
            )

        try:
            # Import the module
            module = importlib.import_module(module_name)

            # Get the function
            validator_func = getattr(module, function_name)

            # Call the function with output and config
            # Custom validators receive the full output object
            is_valid, message = validator_func(output, config)

            return is_valid, message

        except ImportError as e:
            return False, f"Failed to import module '{module_name}': {str(e)}"
        except AttributeError:
            return (
                False,
                f"Function '{function_name}' not found in module '{module_name}'",
            )
        except Exception as e:
            return False, f"Custom validator raised exception: {str(e)}"


class ValidationRunner:
    """Runs validation rules on collection output."""

    def __init__(self):
        """Initialize ValidationRunner with built-in validators."""
        self.validators: dict[str, BaseValidator] = {
            "all_members_present": AllMembersPresentValidator(),
            "quality_threshold": QualityThresholdValidator(),
            "custom": CustomValidator(),
        }

    def run_validation(
        self,
        output: "CollectionOutput",
        rules: list[dict[str, Any]],
        fail_fast: bool = False,
    ) -> tuple[bool, list[dict[str, str]]]:
        """
        Run validation rules on collection output.

        Args:
            output: CollectionOutput from generation
            rules: List of validation rule dicts with 'type', 'required', 'config'
            fail_fast: Stop on first failure if True

        Returns:
            (all_passed, results) tuple where:
            - all_passed: True if all validators passed
            - results: List of result dicts with 'validator', 'passed', 'message'

        Raises:
            CollectionValidationError: If validation fails and required=True
        """
        results = []
        all_passed = True

        for rule in rules:
            rule_type = rule.get("type")
            rule_config = rule.get("config", {})
            required = rule.get("required", True)

            # Get validator
            validator = self.validators.get(rule_type)
            if not validator:
                result = {
                    "validator": rule_type,
                    "passed": False,
                    "message": f"Unknown validator type: {rule_type}",
                }
                results.append(result)
                all_passed = False

                if fail_fast:
                    break
                continue

            # Run validator
            is_valid, message = validator.validate(output, rule_config)

            result = {
                "validator": rule_type,
                "passed": is_valid,
                "message": message,
            }
            results.append(result)

            if not is_valid:
                all_passed = False
                if fail_fast:
                    break

        return all_passed, results

    def validate_or_raise(
        self,
        output: "CollectionOutput",
        rules: list[dict[str, Any]],
        fail_fast: bool = False,
    ) -> None:
        """
        Run validation and raise error if any required validators fail.

        Args:
            output: CollectionOutput from generation
            rules: List of validation rule dicts
            fail_fast: Stop on first failure if True

        Raises:
            CollectionValidationError: If validation fails
        """
        all_passed, results = self.run_validation(output, rules, fail_fast)

        if not all_passed:
            failed = [r for r in results if not r["passed"]]
            failure_messages = [f"  - {r['validator']}: {r['message']}" for r in failed]

            error_msg = f"Collection validation failed ({len(failed)} of {len(results)} validators failed)\n"
            error_msg += "\n".join(failure_messages)

            raise CollectionValidationError(error_msg)
