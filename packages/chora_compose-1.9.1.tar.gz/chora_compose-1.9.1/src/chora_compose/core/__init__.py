"""Core module for chora-compose."""

from pathlib import Path

from chora_compose.core.config_loader import ConfigLoader

__all__ = ["ConfigLoader", "get_config_loader"]

_config_loader_instance: ConfigLoader | None = None


def get_config_loader(config_root: Path | str | None = None) -> ConfigLoader:
    """Get or create config loader singleton.

    This provides a shared config loader instance across all MCP tools to ensure
    consistent configuration access and avoid multiple loader instances.

    Args:
        config_root: Root directory for configurations. Defaults to "configs"
                    resolved relative to the package installation directory.

    Returns:
        Shared ConfigLoader instance

    Example:
        >>> loader = get_config_loader()
        >>> config = loader.load_content_config("simple-readme")
    """
    global _config_loader_instance

    if _config_loader_instance is None:
        if config_root is None:
            # Resolve config_root relative to package location
            # This works regardless of current working directory
            package_dir = Path(__file__).parent.parent  # chora_compose package

            # Check if we're in an editable install (src/chora_compose structure)
            if package_dir.parent.name == "src":
                # Editable install: use project root
                project_root = package_dir.parent.parent
                config_root = project_root / "configs"
            else:
                # Regular install: fall back to relative path
                config_root = Path("configs")

        _config_loader_instance = ConfigLoader(config_root=config_root)

    return _config_loader_instance
