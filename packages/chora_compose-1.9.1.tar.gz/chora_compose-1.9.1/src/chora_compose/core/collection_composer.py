"""Collection composer for assembling multi-artifact collections."""

import asyncio
import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from chora_compose.core.composer import ArtifactComposer
from chora_compose.core.config_loader import ConfigLoader
from chora_compose.core.context_resolver import ContextResolver
from chora_compose.core.models import (
    CollectionConfig,
    CollectionMember,
    CollectionMemberType,
    CollectionValidationRules,
    ContextPropagationMode,
    GenerationDependency,
)
from chora_compose.core.validators import ValidationRunner
from chora_compose.storage.ephemeral import EphemeralStorageManager


class CollectionCompositionError(Exception):
    """Raised when collection composition fails."""

    pass


class MemberOutput:
    """Output from generating a single collection member."""

    def __init__(
        self,
        member_id: str,
        member_type: CollectionMemberType,
        status: str,
        output_path: Optional[str] = None,
        generation_time_seconds: Optional[float] = None,
        cache_used: bool = False,
        context_hash: Optional[str] = None,
        error: Optional[str] = None,
    ):
        self.member_id = member_id
        self.member_type = member_type
        self.status = status
        self.output_path = output_path
        self.generation_time_seconds = generation_time_seconds
        self.cache_used = cache_used
        self.context_hash = context_hash
        self.error = error

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for manifest."""
        return {
            "id": self.member_id,
            "type": self.member_type.value,
            "status": self.status,
            "output_path": self.output_path,
            "generation_time_seconds": self.generation_time_seconds,
            "cache_used": self.cache_used,
            "context_hash": self.context_hash,
            "error": self.error,
        }


class CollectionOutput:
    """Output from generating a collection."""

    def __init__(
        self,
        collection_id: str,
        collection_name: str,
        members: list[MemberOutput],
        manifest_path: Optional[str] = None,
        generation_time_seconds: Optional[float] = None,
    ):
        self.collection_id = collection_id
        self.collection_name = collection_name
        self.members = members
        self.manifest_path = manifest_path
        self.generation_time_seconds = generation_time_seconds

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "collection_id": self.collection_id,
            "collection_name": self.collection_name,
            "members": [m.to_dict() for m in self.members],
            "manifest_path": self.manifest_path,
            "generation_time_seconds": self.generation_time_seconds,
        }


class CollectionComposer:
    """
    Composes collections by assembling multiple artifacts.

    Week 1 Scope (Foundation):
    - Load and validate CollectionConfig
    - Resolve shared context
    - Resolve member context (MERGE mode only)
    - Generate members (artifacts only, no nested collections)
    - Basic parallel generation (no concurrency limit)
    - Generate manifest

    Week 2+ Scope (Advanced Features):
    - Context propagation modes: MERGE, OVERRIDE, ISOLATE ✅
    - Validation framework: BaseValidator, built-in validators ✅
    - Force logic / cache checking (pending)
    - Concurrency limits (pending)
    - Sequential generation (pending)
    - Nested collections (pending)
    - Additional context sources (pending)
    """

    def __init__(
        self,
        context_resolver: Optional[ContextResolver] = None,
        artifact_composer: Optional[ArtifactComposer] = None,
        storage: Optional[EphemeralStorageManager] = None,
        base_path: Optional[Path] = None,
        config_loader: Optional[ConfigLoader] = None,
    ) -> None:
        """
        Initialize CollectionComposer.

        Args:
            context_resolver: ContextResolver for resolving context inputs
            artifact_composer: ArtifactComposer for generating artifacts
            storage: EphemeralStorageManager for caching (not used in Week 1)
            base_path: Base path for resolving relative paths
            config_loader: ConfigLoader for loading configs (created if None)
        """
        self.base_path = base_path or Path.cwd()
        self.storage = storage or EphemeralStorageManager()
        self.config_loader = config_loader or ConfigLoader()
        self.context_resolver = context_resolver or ContextResolver(
            config_loader=self.config_loader,
            storage_manager=self.storage,
            base_path=self.base_path,
        )
        self.artifact_composer = artifact_composer or ArtifactComposer()
        self.validation_runner = ValidationRunner()
        self.max_nesting_depth = 10  # Week 2+: Max depth for nested collections

    async def _compose_nested(
        self,
        config: CollectionConfig,
        output_path: str,
        force: bool = False,
        force_members: Optional[list[str]] = None,
        nesting_path: Optional[list[str]] = None,
    ) -> CollectionOutput:
        """
        Internal method to compose nested collections (Week 2+).

        Args:
            config: CollectionConfig object (already loaded)
            output_path: Output base path
            force: Force regeneration
            force_members: List of member IDs to force
            nesting_path: Current nesting path for circular detection

        Returns:
            CollectionOutput with generation results
        """
        nesting_path = nesting_path or []
        start_time = time.time()

        try:
            # 1. Config already loaded

            # 2. Resolve shared context
            shared_context = await self._resolve_shared_context(config.context)

            # 3. Resolve context for each member
            member_contexts = {}
            for member in config.members:
                member_context = await self._resolve_member_context(
                    member, shared_context, config.context.propagation
                )
                member_contexts[member.id] = member_context

            # 4. Generate all members (pass nesting_path for nested collections)
            output_base = Path(output_path)
            member_outputs = await self._generate_parallel(
                config.members,
                member_contexts,
                str(output_base),
                concurrency_limit=config.generation.concurrency_limit,
                force=force,
                force_members=force_members,
                nesting_path=nesting_path,
            )

            # 5. Generate manifest
            generation_time = time.time() - start_time
            manifest_path = None
            if config.output.manifest:
                manifest_path = await self._generate_manifest(
                    config, member_outputs, output_base, generation_time
                )

            # 6. Create collection output
            output = CollectionOutput(
                collection_id=config.id,
                collection_name=config.name,
                members=member_outputs,
                manifest_path=manifest_path,
                generation_time_seconds=generation_time,
            )

            # 7. Run validation if rules specified (Week 2+)
            if config.validation and config.validation.rules:
                await self._run_validation(output, config.validation)

            return output

        except CollectionCompositionError as e:
            # Preserve must-propagate flag when re-wrapping
            if hasattr(e, "_must_propagate") and e._must_propagate:
                raise
            # Wrap other composition errors
            wrapped = CollectionCompositionError(
                f"Failed to compose nested collection {config.id}: {str(e)}"
            )
            raise wrapped from e
        except Exception as e:
            raise CollectionCompositionError(
                f"Failed to compose nested collection {config.id}: {str(e)}"
            ) from e

    async def compose(
        self,
        config_path: str,
        force: bool = False,
        force_members: Optional[list[str]] = None,
        output_path: Optional[str] = None,
    ) -> CollectionOutput:
        """
        Main entry point: assemble collection from config.

        Args:
            config_path: Path to collection config JSON file
            force: Force regeneration of entire collection (not used in Week 1)
            force_members: Force regenerate specific members (not used in Week 1)
            output_path: Override output base path (optional)

        Returns:
            CollectionOutput with generation results

        Raises:
            CollectionCompositionError: If composition fails
        """
        start_time = time.time()

        try:
            # 1. Load and validate config
            config = await self._load_config(config_path)

            # 2. Resolve shared context
            shared_context = await self._resolve_shared_context(config.context)

            # 3. Resolve context for each member
            member_contexts = {}
            for member in config.members:
                member_context = await self._resolve_member_context(
                    member, shared_context, config.context.propagation
                )
                member_contexts[member.id] = member_context

            # 4. Generate all members (parallel with concurrency limit + cache)
            output_base = Path(output_path or config.output.base_path)
            member_outputs = await self._generate_parallel(
                config.members,
                member_contexts,
                str(output_base),
                concurrency_limit=config.generation.concurrency_limit,
                force=force,
                force_members=force_members,
                nesting_path=[config.id],  # Week 2+: Start nesting path with root
            )

            # 5. Generate manifest
            generation_time = time.time() - start_time
            manifest_path = None
            if config.output.manifest:
                manifest_path = await self._generate_manifest(
                    config, member_outputs, output_base, generation_time
                )

            # 6. Create collection output
            output = CollectionOutput(
                collection_id=config.id,
                collection_name=config.name,
                members=member_outputs,
                manifest_path=manifest_path,
                generation_time_seconds=generation_time,
            )

            # 7. Run validation if rules specified (Week 2+)
            if config.validation and config.validation.rules:
                await self._run_validation(output, config.validation)

            return output

        except Exception as e:
            raise CollectionCompositionError(
                f"Failed to compose collection from {config_path}: {str(e)}"
            ) from e

    async def _run_validation(
        self, output: CollectionOutput, validation_config: CollectionValidationRules
    ) -> None:
        """
        Run validation rules on collection output (Week 2+).

        Args:
            output: CollectionOutput from generation
            validation_config: Validation configuration with rules and fail_fast

        Raises:
            CollectionValidationError: If validation fails
        """
        # Convert validation rules to dict format expected by ValidationRunner
        rules_dicts = [
            {
                "type": rule.type,
                "required": rule.required,
                "config": rule.config,
            }
            for rule in validation_config.rules
        ]

        # Run validation (will raise CollectionValidationError if validation fails)
        self.validation_runner.validate_or_raise(
            output, rules_dicts, fail_fast=validation_config.fail_fast
        )

    async def _load_config(self, path: str) -> CollectionConfig:
        """
        Load and validate CollectionConfig from JSON file.

        Args:
            path: Path to collection config file

        Returns:
            Validated CollectionConfig

        Raises:
            CollectionCompositionError: If config invalid or not found
        """
        try:
            config_file = Path(path)
            if not config_file.exists():
                raise FileNotFoundError(f"Collection config not found: {path}")

            with open(config_file) as f:
                config_data = json.load(f)

            # Validate using Pydantic
            config = CollectionConfig(**config_data)
            return config

        except Exception as e:
            raise CollectionCompositionError(
                f"Failed to load collection config: {str(e)}"
            ) from e

    async def _resolve_shared_context(self, context_config: Any) -> dict[str, Any]:
        """
        Resolve shared context from CollectionContext.

        Args:
            context_config: CollectionContext from config

        Returns:
            Resolved shared context dictionary
        """
        if not context_config.shared or not context_config.shared.sources:
            return {}

        # Resolve all sources and merge them (later sources override earlier)
        result = {}
        for source in context_config.shared.sources:
            source_data = await self._resolve_context_source(source)
            result.update(source_data)

        return result

    async def _resolve_context_source(self, source: Any) -> dict[str, Any]:
        """
        Resolve a single collection context source.

        Args:
            source: CollectionContextSource to resolve

        Returns:
            Resolved data as dictionary
        """
        from chora_compose.core.models import CollectionContextSourceType

        if source.type == CollectionContextSourceType.INLINE_DATA:
            return source.data or {}

        elif source.type == CollectionContextSourceType.EXTERNAL_FILE:
            # Load JSON file
            file_path = (
                Path(source.path)
                if not Path(source.path).is_absolute()
                else Path(source.path)
            )
            if not file_path.is_absolute():
                file_path = self.base_path / file_path

            with open(file_path) as f:
                data: dict[str, Any] = json.load(f)

            # Apply selector if provided
            if source.selector:
                # Simple JSONPath-like selector (basic support for Week 1)
                # Full JSONPath support would need jsonpath_ng library
                data = self._apply_selector(data, source.selector)

            return data

        elif source.type == CollectionContextSourceType.GIT_REFERENCE:
            # For Week 1, read file from current working tree
            git_file_path = Path(source.file) if source.file else Path(source.path)
            if not git_file_path.is_absolute():
                git_file_path = self.base_path / git_file_path

            with open(git_file_path) as f:
                git_data: dict[str, Any] = json.load(f)

            if source.selector:
                git_data = self._apply_selector(git_data, source.selector)

            return git_data

        elif source.type == CollectionContextSourceType.CONTENT_CONFIG:
            # Week 2+: Load context from content config
            config_id = source.config_id
            if not config_id:
                raise CollectionCompositionError(
                    "content_config source requires 'config_id' field"
                )

            # Load content config using config_loader
            content_config = self.config_loader.load_content_config(config_id)

            # Extract context data from content config
            # Content configs may have a 'context' or 'data' field
            if hasattr(content_config, "context"):
                context_data = content_config.context
            elif hasattr(content_config, "data"):
                context_data = content_config.data
            else:
                # Fall back to converting entire config to dict
                context_data = content_config.model_dump()

            # Apply selector if provided
            if source.selector:
                context_data = self._apply_selector(context_data, source.selector)

            return context_data

        elif source.type == CollectionContextSourceType.ARTIFACT_CONFIG:
            # Week 2+: Load context from artifact config
            config_id = source.config_id
            if not config_id:
                raise CollectionCompositionError(
                    "artifact_config source requires 'config_id' field"
                )

            # Load artifact config using config_loader
            artifact_config = self.config_loader.load_artifact_config(config_id)

            # Extract context data from artifact config
            # Artifact configs typically have a 'context' field
            if hasattr(artifact_config, "context"):
                context_data = artifact_config.context
            else:
                # Fall back to converting entire config to dict
                context_data = artifact_config.model_dump()

            # Apply selector if provided
            if source.selector:
                context_data = self._apply_selector(context_data, source.selector)

            return context_data

        elif source.type == CollectionContextSourceType.EPHEMERAL_OUTPUT:
            # Week 2+: Load context from ephemeral storage
            output_id = source.output_id
            if not output_id:
                raise CollectionCompositionError(
                    "ephemeral_output source requires 'output_id' field"
                )

            # Retrieve from ephemeral storage using retrieve method
            try:
                stored_content = self.storage.retrieve(output_id)
            except FileNotFoundError:
                raise CollectionCompositionError(
                    f"Ephemeral output '{output_id}' not found in storage"
                )

            # Parse JSON if needed (ephemeral storage returns string)
            if isinstance(stored_content, str):
                try:
                    stored_data = json.loads(stored_content)
                except json.JSONDecodeError:
                    # If not JSON, treat as raw string data
                    stored_data = {"content": stored_content}
            else:
                stored_data = stored_content

            # Apply selector if provided
            if source.selector:
                stored_data = self._apply_selector(stored_data, source.selector)

            return stored_data

        else:
            raise CollectionCompositionError(
                f"Unknown context source type: {source.type}"
            )

    def _apply_selector(self, data: dict[str, Any], selector: str) -> dict[str, Any]:
        """
        Apply a simple selector to extract data.

        Week 1: Basic support for $.key and $.key.subkey notation.

        Args:
            data: Source data
            selector: Selector string (e.g., "$.metadata" or "$.tool.poetry")

        Returns:
            Selected data
        """
        if not selector.startswith("$."):
            return data

        # Remove $. prefix
        path = selector[2:]

        # Navigate through keys
        result = data
        for key in path.split("."):
            if isinstance(result, dict) and key in result:
                result = result[key]
            else:
                return {}

        return result

    async def _resolve_member_context(
        self,
        member: CollectionMember,
        shared_context: dict[str, Any],
        propagation: ContextPropagationMode,
    ) -> dict[str, Any]:
        """
        Resolve context for a specific member.

        Week 2+: All three propagation modes supported (MERGE, OVERRIDE, ISOLATE).

        Args:
            member: CollectionMember to resolve context for
            shared_context: Shared context from collection
            propagation: Context propagation mode

        Returns:
            Resolved context for this member
        """
        if propagation == ContextPropagationMode.MERGE:
            # MERGE: Start with shared context, merge member override
            member_context = shared_context.copy()

            # Merge member-specific context override if present
            if member.context_override:
                member_context.update(member.context_override)

            return member_context

        elif propagation == ContextPropagationMode.OVERRIDE:
            # OVERRIDE: Use member override if present, otherwise use shared
            if member.context_override:
                # Member override completely replaces shared context
                return member.context_override.copy()
            else:
                # No override, use shared context
                return shared_context.copy()

        elif propagation == ContextPropagationMode.ISOLATE:
            # ISOLATE: Only use member override, shared context not propagated
            if member.context_override:
                return member.context_override.copy()
            else:
                # No override, empty context
                return {}

        else:
            raise ValueError(f"Unknown context propagation mode: {propagation}")

    async def _generate_member(
        self,
        member: CollectionMember,
        context: dict[str, Any],
        output_base_path: str,
        force: bool = False,
        nesting_path: Optional[list[str]] = None,
    ) -> MemberOutput:
        """
        Generate a single member with cache checking and nested collections.

        Args:
            member: CollectionMember to generate
            context: Resolved context for this member
            output_base_path: Base path for outputs
            force: Force regeneration (bypass cache)
            nesting_path: List of parent collection IDs for circular detection

        Returns:
            MemberOutput with generation results
        """
        # Week 2+: Check cache before generating
        cached = await self._check_cache(member, context, output_base_path, force)
        if cached:
            return cached

        start_time = time.time()
        nesting_path = nesting_path or []

        try:
            # Week 2+: Handle nested collections
            if member.type == CollectionMemberType.COLLECTION:
                # Check max nesting depth (MUST propagate)
                if len(nesting_path) >= self.max_nesting_depth:
                    error = CollectionCompositionError(
                        f"Max nesting depth ({self.max_nesting_depth}) exceeded"
                    )
                    error._must_propagate = True
                    raise error

                # Load nested collection config
                member_path = Path(member.path)
                if member_path.is_absolute():
                    nested_config_path = str(member_path)
                else:
                    nested_config_path = str(self.base_path / member.path)
                nested_config = await self._load_config(nested_config_path)

                # Check for circular reference (MUST propagate)
                if self._is_circular_reference(nested_config.id, nesting_path):
                    msg = (
                        f"Circular reference detected: {nested_config.id} "
                        f"already in nesting path {nesting_path}"
                    )
                    error = CollectionCompositionError(msg)
                    error._must_propagate = True
                    raise error

                # Generate nested collection recursively
                nested_output_path = str(Path(output_base_path) / member.id)
                nested_output = await self._compose_nested(
                    nested_config,
                    nested_output_path,
                    force=force,
                    nesting_path=nesting_path + [nested_config.id],
                )

                generation_time = time.time() - start_time

                return MemberOutput(
                    member_id=member.id,
                    member_type=member.type,
                    status="success",
                    output_path=nested_output.manifest_path or nested_output_path,
                    generation_time_seconds=generation_time,
                    cache_used=False,
                    context_hash=self._compute_context_hash(context),
                )

            # Generate artifact using ArtifactComposer
            # Note: This is simplified for Week 1
            # Full implementation will need proper artifact generation
            artifact_output_path = str(
                Path(output_base_path) / member.id / "output.txt"
            )

            # Placeholder: In real implementation, call artifact_composer.compose()
            # For Week 1, we'll create a simple output
            Path(artifact_output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(artifact_output_path, "w") as f:
                f.write(f"Generated artifact: {member.id}\n")
                f.write(f"Context: {json.dumps(context, indent=2)}\n")

            generation_time = time.time() - start_time

            return MemberOutput(
                member_id=member.id,
                member_type=member.type,
                status="success",
                output_path=artifact_output_path,
                generation_time_seconds=generation_time,
                cache_used=False,
                context_hash=self._compute_context_hash(context),
            )

        except CollectionCompositionError as e:
            # Re-raise errors marked as must-propagate (circular refs, max depth)
            if hasattr(e, "_must_propagate") and e._must_propagate:
                raise
            # Other errors (e.g., config not found) are returned as error status
            return MemberOutput(
                member_id=member.id,
                member_type=member.type,
                status="error",
                error=str(e),
            )
        except Exception as e:
            return MemberOutput(
                member_id=member.id,
                member_type=member.type,
                status="error",
                error=str(e),
            )

    async def _generate_parallel(
        self,
        members: list[CollectionMember],
        contexts: dict[str, dict[str, Any]],
        output_base_path: str,
        concurrency_limit: int = 3,
        force: bool = False,
        force_members: Optional[list[str]] = None,
        nesting_path: Optional[list[str]] = None,
    ) -> list[MemberOutput]:
        """
        Generate members in parallel with optional concurrency limit (Week 2+).

        Args:
            members: List of CollectionMembers to generate
            contexts: Dict mapping member ID to resolved context
            output_base_path: Base path for outputs
            concurrency_limit: Max concurrent generations (default: 3)
            force: Force regeneration for all members
            force_members: List of member IDs to force regenerate
            nesting_path: Current nesting path for nested collections

        Returns:
            List of MemberOutputs
        """
        # Create semaphore to limit concurrency (Week 2+)
        semaphore = asyncio.Semaphore(concurrency_limit)
        force_set = set(force_members or [])
        nesting_path = nesting_path or []

        async def generate_with_limit(member: CollectionMember) -> MemberOutput:
            """Generate member with semaphore-based concurrency control."""
            async with semaphore:
                # Check if this specific member should be forced
                member_force = force or (member.id in force_set)
                return await self._generate_member(
                    member,
                    contexts[member.id],
                    output_base_path,
                    force=member_force,
                    nesting_path=nesting_path,
                )

        # Generate all members with concurrency limit
        tasks = [generate_with_limit(member) for member in members]
        return await asyncio.gather(*tasks)

    async def _generate_sequential(
        self,
        members: list[CollectionMember],
        contexts: dict[str, dict[str, Any]],
        output_base_path: str,
        dependencies: Optional[list[GenerationDependency]] = None,
        force: bool = False,
        force_members: Optional[list[str]] = None,
        nesting_path: Optional[list[str]] = None,
    ) -> list[MemberOutput]:
        """
        Generate members sequentially using topological sort (Week 2+).

        Args:
            members: List of CollectionMembers to generate
            contexts: Dict mapping member ID to resolved context
            output_base_path: Base path for outputs
            dependencies: Optional list of dependencies between members
            force: Force regeneration for all members
            force_members: List of member IDs to force regenerate
            nesting_path: Current nesting path for nested collections

        Returns:
            List of MemberOutputs in generation order

        Raises:
            CollectionCompositionError: If cyclic dependencies detected
        """
        # Build dependency graph
        if dependencies:
            # Use explicit dependencies for topological sort
            sorted_members = self._topological_sort_by_dependencies(
                members, dependencies
            )
        else:
            # Use order field for sorting
            sorted_members = sorted(members, key=lambda m: m.order)

        # Generate members one at a time in sorted order
        force_set = set(force_members or [])
        nesting_path = nesting_path or []
        outputs = []
        for member in sorted_members:
            # Check if this specific member should be forced
            member_force = force or (member.id in force_set)
            output = await self._generate_member(
                member,
                contexts[member.id],
                output_base_path,
                force=member_force,
                nesting_path=nesting_path,
            )
            outputs.append(output)

        return outputs

    def _topological_sort_by_dependencies(
        self,
        members: list[CollectionMember],
        dependencies: list[GenerationDependency],
    ) -> list[CollectionMember]:
        """
        Perform topological sort on members based on dependencies.

        Args:
            members: List of CollectionMembers
            dependencies: List of GenerationDependency objects

        Returns:
            List of members in topologically sorted order

        Raises:
            CollectionCompositionError: If cyclic dependencies detected
        """
        # Build adjacency list and in-degree map
        member_map = {m.id: m for m in members}
        graph: dict[str, list[str]] = {m.id: [] for m in members}
        in_degree: dict[str, int] = {m.id: 0 for m in members}

        for dep in dependencies:
            # source -> target means source must complete before target
            graph[dep.source].append(dep.target)
            in_degree[dep.target] += 1

        # Kahn's algorithm for topological sort
        queue = [member_id for member_id, degree in in_degree.items() if degree == 0]
        sorted_ids = []

        while queue:
            current = queue.pop(0)
            sorted_ids.append(current)

            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Check for cycles
        if len(sorted_ids) != len(members):
            raise CollectionCompositionError(
                "Cyclic dependency detected in generation dependencies"
            )

        # Return members in sorted order
        return [member_map[member_id] for member_id in sorted_ids]

    def _is_circular_reference(
        self, collection_id: str, nesting_path: list[str]
    ) -> bool:
        """
        Check if adding a collection would create a circular reference (Week 2+).

        Args:
            collection_id: ID of collection to check
            nesting_path: List of collection IDs in current nesting path

        Returns:
            True if circular reference detected, False otherwise
        """
        return collection_id in nesting_path

    def _compute_context_hash(self, context: dict[str, Any]) -> str:
        """
        Compute deterministic hash of context for cache checking (Week 2+).

        Args:
            context: Context dictionary to hash

        Returns:
            Hash string
        """
        # Use JSON with sorted keys for deterministic hashing
        context_json = json.dumps(context, sort_keys=True)
        return str(hash(context_json))

    async def _check_cache(
        self,
        member: CollectionMember,
        context: dict[str, Any],
        output_base_path: str,
        force: bool = False,
    ) -> Optional[MemberOutput]:
        """
        Check if cached output exists and is valid (Week 2+).

        Args:
            member: CollectionMember to check cache for
            context: Resolved context for this member
            output_base_path: Base path for outputs
            force: Force regeneration (bypass cache)

        Returns:
            Cached MemberOutput if valid cache exists, None otherwise
        """
        # Force flag bypasses cache
        if force:
            return None

        # Compute current context hash
        current_hash = self._compute_context_hash(context)

        # Look for previous manifest
        manifest_path = Path(output_base_path) / "manifest.json"
        if not manifest_path.exists():
            return None

        # Load previous manifest
        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

        # Find member in manifest
        previous_member = None
        for m in manifest.get("members", []):
            if m.get("id") == member.id:
                previous_member = m
                break

        if not previous_member:
            return None

        # Check if context hash matches
        previous_hash = previous_member.get("context_hash")
        if previous_hash != current_hash:
            return None

        # Cache hit! Return cached output
        return MemberOutput(
            member_id=member.id,
            member_type=previous_member.get("type", "artifact"),
            status=previous_member.get("status", "success"),
            output_path=previous_member.get("output_path"),
            generation_time_seconds=previous_member.get("generation_time_seconds", 0.0),
            cache_used=True,  # Mark as cached
            context_hash=current_hash,
        )

    def _generate_freshness_metadata(
        self,
        config: CollectionConfig,
        member_outputs: list[MemberOutput],
        generation_timestamp: datetime,
    ) -> dict[str, Any]:
        """
        Generate freshness metadata for manifest (v1.5.0 - stigmergic context links).

        Calculates expiration timestamps and freshness thresholds for each member
        based on the collection's freshness policy.

        Args:
            config: CollectionConfig with freshness policy
            member_outputs: List of MemberOutputs with generation status
            generation_timestamp: UTC timestamp of generation

        Returns:
            Freshness metadata dict with policy, member expirations, and last check
        """
        freshness_policy = config.freshness
        member_freshness = {}

        for output in member_outputs:
            # Get max_age_days for this member (policy default or member override)
            max_age_days = freshness_policy.member_overrides.get(
                output.member_id, freshness_policy.max_age_days
            )

            # Calculate expiration timestamp
            expiration_datetime = generation_timestamp + timedelta(days=max_age_days)
            expiration_iso = expiration_datetime.isoformat().replace("+00:00", "Z")

            # Calculate stale threshold (80% of max age)
            stale_threshold_days = max_age_days * 0.8

            member_freshness[output.member_id] = {
                "generated_at": generation_timestamp.isoformat().replace("+00:00", "Z"),
                "max_age_days": max_age_days,
                "expires_at": expiration_iso,
                "stale_threshold_days": round(stale_threshold_days, 2),
            }

        return {
            "enabled": freshness_policy.enabled,
            "policy": {
                "max_age_days": freshness_policy.max_age_days,
                "member_overrides": freshness_policy.member_overrides,
            },
            "members": member_freshness,
            "last_checked_at": generation_timestamp.isoformat().replace("+00:00", "Z"),
        }

    async def _generate_manifest(
        self,
        config: CollectionConfig,
        member_outputs: list[MemberOutput],
        output_base: Path,
        generation_time_seconds: float,
    ) -> str:
        """
        Generate manifest.json with generation metadata.

        Args:
            config: CollectionConfig
            member_outputs: List of MemberOutputs
            output_base: Base output path
            generation_time_seconds: Total generation time

        Returns:
            Path to manifest file
        """
        generation_timestamp = datetime.now(timezone.utc)

        manifest = {
            "collection": {
                "id": config.id,
                "name": config.name,
                "description": config.description,
            },
            "generation": {
                "timestamp": generation_timestamp.isoformat().replace("+00:00", "Z"),
                "duration_seconds": round(generation_time_seconds, 2),
                "strategy": config.generation.strategy.value,
            },
            "members": [output.to_dict() for output in member_outputs],
            "freshness": self._generate_freshness_metadata(
                config, member_outputs, generation_timestamp
            ),
            "metadata": {
                "chora_compose_version": "1.4.0-dev",
            },
        }

        manifest_path = output_base / "manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)

        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)

        return str(manifest_path)
