"""MCP tool name transformations for protocol compliance.

Claude Desktop (and newer MCP clients) require tool names to match the
regular expression ``^[a-zA-Z0-9_-]{1,64}$``. Our existing tools use the
``choracompose:tool_name`` namespace convention, which violates this rule
because of the colon delimiter.

To preserve backwards compatibility while satisfying the new constraint,
we register FastMCP tool transformations that expose colon-free names to
clients while still accepting legacy calls that reference the original
names.
"""

from fastmcp.tools.tool_transform import ToolTransformConfig

from .instance import mcp

LEGACY_TOOL_NAME_PREFIX = "choracompose:"
SAFE_NAMESPACE_SEPARATOR = "__"


def sanitize_tool_name(tool_name: str) -> str:
    """Convert a colon-delimited tool name to an MCP-safe variant."""
    if not tool_name.startswith(LEGACY_TOOL_NAME_PREFIX):
        return tool_name.replace(":", SAFE_NAMESPACE_SEPARATOR)

    namespace, _, short_name = tool_name.partition(":")
    return SAFE_NAMESPACE_SEPARATOR.join((namespace, short_name))


_LEGACY_TOOL_NAMES: tuple[str, ...] = (
    "choracompose:hello_world",
    "choracompose:list_generators",
    "choracompose:generate_content",
    "choracompose:assemble_artifact",
    "choracompose:validate_content",
    "choracompose:regenerate_content",
    "choracompose:delete_content",
    "choracompose:preview_generation",
    "choracompose:batch_generate",
    "choracompose:trace_dependencies",
    "choracompose:list_artifacts",
    "choracompose:list_artifact_configs",
    "choracompose:list_content",
    "choracompose:list_content_configs",
    "choracompose:cleanup_ephemeral",
    "choracompose:generate_collection",
    "choracompose:validate_collection_config",
    "choracompose:list_collection_members",
    "choracompose:check_collection_cache",
    "choracompose:check_freshness",
    "choracompose:draft_config",
    "choracompose:test_config",
    "choracompose:save_config",
    "choracompose:modify_config",
)

# Mapping of legacy tool names (with colon) to the sanitized names exposed
# to MCP clients. The sanitized names are surfaced via FastMCP tool
# transformations, but the legacy colon-delimited names continue to work
# when a client invokes the tool directly.
_TOOL_NAME_TRANSFORMATIONS: dict[str, str] = {
    legacy_name: sanitize_tool_name(legacy_name) for legacy_name in _LEGACY_TOOL_NAMES
}


def get_tool_name_transformations() -> dict[str, str]:
    """Return a copy of the registered tool name transformations."""
    return dict(_TOOL_NAME_TRANSFORMATIONS)


def register_tool_name_transformations() -> None:
    """Register FastMCP tool transformations for sanitized tool names."""
    for legacy_name, sanitized_name in _TOOL_NAME_TRANSFORMATIONS.items():
        mcp.add_tool_transformation(
            legacy_name, ToolTransformConfig(name=sanitized_name)
        )


# Register transformations at import time so that server startup exposes the
# sanitized tool names automatically.
register_tool_name_transformations()
