"""Freshness checking tool implementation for stigmergic context links (v1.5.0)."""

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from chora_compose.core.collection_composer import CollectionComposer
from chora_compose.mcp.types import (
    CheckFreshnessResult,
    FreshnessStatus,
    MemberFreshnessInfo,
)

# Import MCP instance for tool registration
try:
    from .instance import mcp
except (ImportError, ModuleNotFoundError):
    # Create a no-op decorator for testing
    class MockMCP:
        """Mock MCP decorator for testing without FastMCP."""

        def tool(self, name: str | None = None, **kwargs: Any):
            """Mock tool decorator that returns the function unchanged."""

            def decorator(func):
                return func

            return decorator

    mcp: Any = MockMCP()  # type: ignore[no-redef]


def _validate_config_id(config_id: str) -> None:
    """Validate collection config ID for security (prevent path traversal)."""
    if ".." in config_id or "/" in config_id or "\\" in config_id:
        raise ValueError(
            f"Invalid collection_id '{config_id}': must not contain path separators or parent directory references"
        )


def _handle_tool_error(
    e: Exception, tool_name: str, start_time: float
) -> dict[str, Any]:
    """Handle tool errors consistently."""
    return {
        "success": False,
        "error": {
            "code": type(e).__name__,
            "message": str(e),
            "details": {},
        },
    }


@mcp.tool(name="choracompose:check_freshness")
async def check_freshness(
    collection_config_path: str,
    output_path: str | None = None,
    _composer: Any | None = None,  # For testing only
) -> dict[str, Any]:
    """Check freshness status of all members in a collection (v1.5.0 - stigmergic context links).

    Analyzes the age of each member's content against configured freshness thresholds.
    Returns classification (fresh/stale/expired) and recommendations for regeneration.
    Does NOT regenerate - only reports status.

    This tool enables AI agents to:
    1. Detect stale content without manual tracking
    2. Make informed decisions about regeneration
    3. Prioritize which collections need attention
    4. Track content freshness over time

    Args:
        collection_config_path: Path to collection configuration file
        output_path: Override the output base path (default from config)
        _composer: Internal parameter for testing dependency injection

    Returns:
        Dictionary with CheckFreshnessResult structure

    Example:
        ```python
        result = await check_freshness("sap-004-complete")
        # Returns:
        # {
        #     "success": True,
        #     "collection_id": "sap-004-complete",
        #     "freshness_enabled": True,
        #     "members": [
        #         {
        #             "member_id": "charter",
        #             "generated_at": "2025-10-23T14:00:00Z",
        #             "age_days": 7.5,
        #             "max_age_days": 30,
        #             "freshness_status": "fresh",
        #             "expires_at": "2025-11-22T14:00:00Z"
        #         },
        #         ...
        #     ],
        #     "fresh_count": 2,
        #     "stale_count": 1,
        #     "expired_count": 2,
        #     "recommendation": "regenerate_expired",
        #     "checked_at": "2025-10-30T12:00:00Z",
        #     "metadata": {"oldest_age_days": 45.2, ...}
        # }
        ```
    """
    try:
        start_time = time.time()

        # Use injected composer for testing, otherwise create new instance
        composer = _composer if _composer is not None else CollectionComposer()

        # Resolve config path
        config_path = collection_config_path

        # Only validate relative paths for security (absolute paths allowed for testing)
        if not Path(config_path).is_absolute():
            _validate_config_id(collection_config_path)
            if not config_path.endswith(".json"):
                config_path = f"{config_path}.json"
            config_path = f"configs/collection/{config_path}"
        elif not config_path.endswith(".json"):
            config_path = f"{config_path}.json"

        # Load the collection config
        config_path_obj = Path(config_path)
        if not config_path_obj.exists():
            raise FileNotFoundError(
                f"Collection config '{collection_config_path}' not found"
            )

        # Load config
        config_dict = await composer._load_config(str(config_path_obj))

        # Determine output base path
        if output_path is None:
            output_path = config_dict.get("output", {}).get(
                "base_path", "outputs/collections"
            )

        output_base = Path(output_path) / config_dict.get("id", "unknown")

        # Check if manifest exists (must have been generated at least once)
        manifest_path = output_base / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(
                f"Collection '{collection_config_path}' has not been generated yet. "
                f"Run generate_collection first to create initial manifest."
            )

        # Load manifest
        with open(manifest_path) as f:
            manifest = json.load(f)

        # Get freshness policy from manifest
        freshness_metadata = manifest.get("freshness", {})
        freshness_enabled = freshness_metadata.get("enabled", False)

        if not freshness_enabled:
            # Freshness tracking disabled - all members considered fresh
            member_freshness_list = []
            for member_data in freshness_metadata.get("members", {}).values():
                member_freshness_list.append(
                    MemberFreshnessInfo(
                        member_id=member_data.get("id", "unknown"),
                        generated_at=member_data.get("generated_at", "unknown"),
                        age_days=0.0,
                        max_age_days=999,  # Effectively infinite
                        freshness_status=FreshnessStatus.FRESH,
                        expires_at="9999-12-31T23:59:59Z",  # Far future
                    )
                )

            result = CheckFreshnessResult(
                success=True,
                collection_id=config_dict.get("id", "unknown"),
                freshness_enabled=False,
                members=member_freshness_list,
                fresh_count=len(member_freshness_list),
                stale_count=0,
                expired_count=0,
                recommendation="all_fresh",
                checked_at=datetime.now(timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
                metadata={"note": "Freshness tracking disabled for this collection"},
            )
            return result.model_dump()

        # Freshness tracking enabled - analyze each member
        now = datetime.now(timezone.utc)
        member_freshness_list = []
        age_days_list = []

        member_freshness_dict = freshness_metadata.get("members", {})

        for member_id, member_data in member_freshness_dict.items():
            # Parse generation timestamp
            generated_at_str = member_data.get("generated_at", "")
            generated_at = datetime.fromisoformat(
                generated_at_str.replace("Z", "+00:00")
            )

            # Calculate age
            age_timedelta = now - generated_at
            age_days = age_timedelta.total_seconds() / (24 * 3600)

            # Get thresholds
            max_age_days = member_data.get("max_age_days", 7)
            stale_threshold_days = member_data.get(
                "stale_threshold_days", max_age_days * 0.8
            )

            # Classify freshness
            if age_days < stale_threshold_days:
                freshness_status = FreshnessStatus.FRESH
            elif age_days < max_age_days:
                freshness_status = FreshnessStatus.STALE
            else:
                freshness_status = FreshnessStatus.EXPIRED

            # Parse expiration timestamp
            expires_at_str = member_data.get("expires_at", "")

            member_freshness_list.append(
                MemberFreshnessInfo(
                    member_id=member_id,
                    generated_at=generated_at_str,
                    age_days=round(age_days, 2),
                    max_age_days=max_age_days,
                    freshness_status=freshness_status,
                    expires_at=expires_at_str,
                )
            )
            age_days_list.append(age_days)

        # Calculate counts
        fresh_count = sum(
            1
            for m in member_freshness_list
            if m.freshness_status == FreshnessStatus.FRESH
        )
        stale_count = sum(
            1
            for m in member_freshness_list
            if m.freshness_status == FreshnessStatus.STALE
        )
        expired_count = sum(
            1
            for m in member_freshness_list
            if m.freshness_status == FreshnessStatus.EXPIRED
        )

        # Determine recommendation
        if expired_count > 0:
            recommendation = "regenerate_expired"
        elif stale_count > 0:
            recommendation = "regenerate_stale"
        else:
            recommendation = "all_fresh"

        # Calculate age statistics
        metadata = {
            "oldest_age_days": round(max(age_days_list), 2) if age_days_list else 0.0,
            "newest_age_days": round(min(age_days_list), 2) if age_days_list else 0.0,
            "average_age_days": round(sum(age_days_list) / len(age_days_list), 2)
            if age_days_list
            else 0.0,
            "manifest_path": str(manifest_path),
            "config_path": str(config_path_obj),
        }

        result = CheckFreshnessResult(
            success=True,
            collection_id=config_dict.get("id", "unknown"),
            freshness_enabled=True,
            members=member_freshness_list,
            fresh_count=fresh_count,
            stale_count=stale_count,
            expired_count=expired_count,
            recommendation=recommendation,
            checked_at=now.isoformat().replace("+00:00", "Z"),
            metadata=metadata,
        )

        return result.model_dump()

    except Exception as e:
        return _handle_tool_error(e, "check_freshness", start_time)
