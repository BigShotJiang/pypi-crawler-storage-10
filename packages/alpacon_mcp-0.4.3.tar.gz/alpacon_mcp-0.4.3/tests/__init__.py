"""
Test package for Alpacon MCP Server.

Contains unit tests and integration tests for all MCP tools and utilities.
"""