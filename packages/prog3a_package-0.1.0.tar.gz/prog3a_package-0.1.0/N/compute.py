import pygame
from tabulate import tabulate

def row(matrix):
    """
    :param matrix: Die Matrix (Liste von Listen)
    :return: Anzahl der Zeilen (int)
    """
    return len(matrix)


def col(matrix):
    """
    :param matrix: Die Matrix (Liste von Listen)
    :return: Anzahl der Spalten (int)
    """
    return len(matrix[0]) if matrix else 0


def matmul(mat1, mat2):
    """
    :param mat1: Erste Matrix (Liste von Listen mit Zahlen)
    :param mat2: Zweite Matrix (Liste von Listen mit Zahlen)
    :return: Ergebnis-Matrix (Liste von Listen)
    :raises ValueError: Wenn die Matrizen nicht multiplizierbar sind
    """
    if len(mat1[0]) != len(mat2):
        raise ValueError("Matrizen sind nicht multiplizierbar")

    result = [[0 for _ in range(col(mat2))] for _ in range(row(mat1))]

    for i in range(row(mat1)):
        for j in range(col(mat2)):
            for k in range(col(mat1)):
                result[i][j] += mat1[i][k] * mat2[k][j]

    return result


def transpose(mat: list[list[int]]) -> list[list[int]]:
    """
    :param mat: Die Matrix (Liste von Listen mit Zahlen)
    :return: Transponierte Matrix (Liste von Listen)
    :raises ValueError: Wenn die Matrix leer ist oder ungleichmäßige Zeilenlängen hat
    """
    if not mat:
        raise ValueError("Matrix ist leer")
    length = len(mat[0])
    if any(len(r) != length for r in mat):
        raise ValueError("Ungleichmäßige Zeilenlängen")
    return [[mat[j][i] for j in range(len(mat))] for i in range(length)]


def rotation_matrix(angle):
    v = pygame.math.Vector2(1, 0).rotate_rad(angle)
    cos_a = v.x
    sin_a = v.y
    return [
        [cos_a, -sin_a],
        [sin_a,  cos_a]
    ]


def rotate_point(point, angle):
    R = rotation_matrix(angle)
    p = [[point[0]], [point[1]]]
    res = matmul(R, p)
    return [res[0][0], res[1][0]]


def translate_point(point, offset):
    return [point[0] + offset[0], point[1] + offset[1]]


if __name__ == "__main__":
    matrix_a = [[3, 4, -1, 4],
                [-2, 2, 5, 1]]
    matrix_b = [[1, 3, -2],
                [2, 5, 1],
                [-1, 4, -4],
                [2, 3, 6]]
    matrix_c = matmul(matrix_a, matrix_b)
    print("Ergebnis C = A * B:")
    for r in matrix_c:
        print(r)

    matrix = [[1, 2, 3],
              [4, 5, 6]]
    print("Transpose:", transpose(matrix))

    # Rotationstest (90°)
    print("Rotation von (1,0) um 90°:")
    print(rotate_point((1, 0), 3.14159 / 2))
    print("Matrix A:")
    print(tabulate(matrix_a))
    # created by myself