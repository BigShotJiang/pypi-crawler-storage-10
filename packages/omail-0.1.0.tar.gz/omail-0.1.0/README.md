# OMail

## Description

OMail (Onion Mail) is an email system with strong security, privacy, anti-spam features in an easy-to-run system. OMail is hosted on an Onion Service, avoiding costs and complexity of the Domain Name System (DNS) and can be hosted on networks behind NAT firewalls. 

### Unique Private Addresses

OMail features Unique Private Addresses (UPA) that OMail hosts share confidentially with each of thier contacts. Since each UPA corresponds to a single user, hosts can block unwanted contacts simply by ignoring traffic on unwanted UPAs. 

#### UPA Example

`pxha45jdindxjq4a3e4s7x7746by52547p2weeljo6kwz6rqcve6spid.onion/02b4632d08485ff1df2db55b9dafd23347d1c47a457072a1e87be26896549a8737`

UPAs feature two parts: an onion address, and an Elliptic Curve Cryptography (ECC) public key. The onion address provides routing information and a public key for communication with the Onion Service that runs on the OMail host. The ECC key provides a unique identifier for a contact and is used to encrypt and sign messages sent to and from the host, respectively. This provides strong encryption of files both in motion and at rest.

#### Address exchange

Addresses can be exchanged in person using a QR code generated on the host's smartphone. Contacts can save the address in their Onion-capable web browser or in their OMail system.

![QR Code Example](docs/assets/QR_UPA_Example.png)


#### Accessign OMail Addresses

OMail contacts without their own OMail host can access messages through a webmail interface hosted at the OMail address. This makes it easy for new users to join the OMail network without having to run their own host.

OMail contacts with their own hosts can exchange messages through their own system.

