This module allows you to have a cash flow forecast. The forecast is
based on two types of date:

- Accounting entries: Due date field instead of Date
- Forecast lines: manual lines created that forecast in/out cashflow
  moves.
