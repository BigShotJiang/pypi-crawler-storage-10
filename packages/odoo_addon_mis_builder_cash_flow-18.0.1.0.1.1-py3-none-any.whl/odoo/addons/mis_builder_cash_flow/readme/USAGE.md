To use this module, you need to:

1.  Go to Accounting \> Reports \> MIS Reporting \> MIS Reports and
    choose "Cash Flow" report
2.  You can add forecast lines on Accounting \> Reports \> MIS Reporting
    \> Cash Flow Forecast Line
3.  If you select on "Target Moves" the value "All Posted Entries", you
    will get only lines for already posted invoices/entries + the
    forecast lines.
4.  Selecting "All Entries", draft invoices/entries are also included.
5.  In any case, cancelled invoices/entries are not included.
