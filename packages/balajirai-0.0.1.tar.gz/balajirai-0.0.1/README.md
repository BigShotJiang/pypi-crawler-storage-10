# balajirai

A simple Python package that greets you with a friendly message!

## Installation

You can install it from PyPI:

```bash
pip install balajirai
````

## Usage

### 1. Run from the terminal

After installation, you can run:

```bash
balajirai
```

Output:

```
Hey, how's it going?
```

### 2. Use it in Python code

You can also import and call the function directly:

```python
from balajirai import hello

hello()
```

Output:

```
Hey, how's it going?
```

## About

It includes a console script entry point as well as an importable function.

