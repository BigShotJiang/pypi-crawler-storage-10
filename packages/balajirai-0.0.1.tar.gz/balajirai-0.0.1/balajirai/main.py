def hello():
    print("Hey, how's it going?")
