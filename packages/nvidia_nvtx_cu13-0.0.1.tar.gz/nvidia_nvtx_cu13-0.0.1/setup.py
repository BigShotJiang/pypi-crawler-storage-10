import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-nvtx-cu13' IS DEPRECATED.
Please use 'nvidia-nvtx' instead.

To install the correct package, use:

    pip install nvidia-nvtx

For more information, visit: https://pypi.org/project/nvidia-nvtx/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
