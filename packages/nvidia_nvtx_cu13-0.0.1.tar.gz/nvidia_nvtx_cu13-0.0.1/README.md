⚠️ THIS PROJECT 'nvidia-nvtx-cu13' IS DEPRECATED.
Please use 'nvidia-nvtx' instead.

To install the correct package, use:

    pip install nvidia-nvtx

For more information, visit: https://pypi.org/project/nvidia-nvtx/
