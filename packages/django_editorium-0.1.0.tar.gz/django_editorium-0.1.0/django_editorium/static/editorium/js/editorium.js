function format(command) {
  document.execCommand(command, false, null);
}

function formatBlock(tag) {
  document.execCommand('formatBlock', false, tag);
}

function insertLink() {
  const url = prompt("Enter URL:");
  if (url) {
    document.execCommand("createLink", false, url);
  }
}

// Un Ordered and Ordered list inserting buttons
function formatList(type) {
  if (type === 'ul') {
    document.execCommand('insertUnorderedList', false, null);
  } else if (type === 'ol') {
    document.execCommand('insertOrderedList', false, null);
  }
}