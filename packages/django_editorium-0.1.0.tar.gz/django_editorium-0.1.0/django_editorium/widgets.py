from django import forms
from django.utils.safestring import mark_safe
from django.template.loader import render_to_string

class EditoriumWidget(forms.Widget):
    template_name = 'core/widgets/editorium.html'

    class Media:
        css = {
            'all': ['editorium/css/input.css']
        }
        js = ['editorium/js/editorium.js', 'https://cdn.jsdelivr.net/npm/alpinejs']

    def format_value(self, value):
        return value or ''

    def render(self, name, value, attrs=None, renderer=None):
        context = {
            'widget': {
                'name': name,
                'value': value,
                'attrs': self.build_attrs(attrs, {'id': 'editor'}),
            }
        }
        return mark_safe(render_to_string(self.template_name, context))

