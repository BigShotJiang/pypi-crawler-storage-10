from django.db import models
from .widgets import EditoriumWidget

class EditoriumField(models.TextField):
    def formfield(self, **kwargs):
        defaults = {'widget': EditoriumWidget}
        defaults.update(kwargs)
        return super().formfield(**defaults)