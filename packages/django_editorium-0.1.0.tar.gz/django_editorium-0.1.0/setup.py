from setuptools import setup, find_packages

setup(
    name='django-editorium',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    license='MIT',
    description='A lightweight, Tailwind-powered rich text editor widget for Django forms.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Rivindhu',
    author_email='rivindhu98@gmail.com',
    url='https://github.com/Rivindhu/django-editorium',
    classifiers=[
        'Framework :: Django',
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    install_requires=[
        'Django>=3.2',
    ],
)