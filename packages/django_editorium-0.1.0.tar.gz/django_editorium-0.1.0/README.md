# Django Editorium

Django Editorium is a lightweight, TailwindCSS-powered rich text editor widget for Django forms. It supports headings, lists, links, and inline formatting with AlpineJS interactivity.

## Features

- Bold, italic, underline
- Headings (H1–H4), paragraphs
- Ordered and unordered lists
- Link insertion modal
- TailwindCSS styling
- AlpineJS-powered interactivity

## Installation

```bash
pip install django-editorium
```

## Usage

In your forms.py:

```python
from django import forms
from django_editorium.widgets import EditoriumWidget

class ArticleForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = ['title', 'content']
        widgets = {
            'content': EditoriumWidget()
        }
```

## TailwindCSS Integration

To ensure proper styling, include TailwindCSS in your base template or build pipeline.

## CDN Option
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

## License

MIT
MIT License

Copyright (c) 2025 Rivindhu

Permission is hereby granted