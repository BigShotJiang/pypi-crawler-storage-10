class Precios:
    #para definir un metodo estatico dentro de una clase , son aquellos que no dependen de una instancia particular de la clase y no tienen acceso a los atributos o metodos
    #de la instancia ose ano pueden acceder a self
    @staticmethod
    def calcular_precio_final(precio_base,impuesto,descuento):
        return precio_base+impuesto-descuento