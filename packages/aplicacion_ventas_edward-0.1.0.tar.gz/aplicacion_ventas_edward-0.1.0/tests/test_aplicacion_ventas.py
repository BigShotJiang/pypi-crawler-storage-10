import unittest
from aplicacion_ventas.gestor_ventas import GestorVentas
from aplicacion_ventas.exceptions import ImpuestoInvalidoError,DescuentoInvalidoError

class TestGestorVentas(unittest.TestCase):
    def test_calculo_precio_final(self):
        gestor=GestorVentas(100,0.05,0.10)
        self.assertEqual(gestor.calcular_precio_final(),95.0) # usado para comprobar si dos valores son iguales
    def test_impuesto_invalido(self):
        with self.assertRaises(ImpuestoInvalidoError):#para comprobar que una determinada excepcion se genera durante la ejecucion  
            GestorVentas(100.0,1.5,0.10)
    
    def test_descuento_Invalido(self):
        with self.assertRaises(DescuentoInvalidoError) :
            GestorVentas(100.00,0.05,1.5)    
if __name__=="__main__":
    unittest.main()      
    
# Para probarlo       debemos irnos al directorio raiz aplicacion_ventas (el que contiene) en el temrinal y luego     escribir python -m unittest  discover -s tests
#(Prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> python -m unittest discover -s tests
#(Prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> py -m unittest discover -s tests