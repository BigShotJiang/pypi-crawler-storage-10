#Entramos al entorno virtual  entramos al terminal
#F:\Cursos Actualizacion\Python\prueba\scripts> .\activate
#dentro del entorno virtual instalamos setuptools
#(prueba) PS F:\Cursos Actualizacion\Python\prueba\scripts> pip install setuptools

from setuptools import setup,find_packages 
#find_package funcion utiliza busca los paquerte o directorios con archivos __init__.py dentro del proyecto en lugar de especificar manualmente todos los archivos en el setup
setup(
    name='aplicacion_ventas_edward',
    version='0.1.0',
    author='EDWARD CASTILLO',
    author_email='edeymar1989@gmail.com',
    description='Paquete para gestionar ventas,precios,impuestos y descuentos',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/tu_usuario/gestor_ventas',
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License', # Cambia esto segun sea necesario
        'Operating System :: OS Independent'
    ],
    python_requires='>=3.6'
)

#instalamos tambien twine va permitir subir mi paquete dentro PyPI (herramienta fundamental para distribuir paquetes de python
#  en el repositorio oficial de python package index) para subir de manera segura
#(prueba) PS F:\Cursos Actualizacion\Python\prueba\scripts> pip install twine   
# ahora entramos a la carpeta siguiente en el temrinal 
#(prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> 
#hacemos un pip list
#debemos instalar tambien el paquete wheel
#ahora procedemos a crear el paquete  para ello debemos estar al nivel del archivo setup
#y escribimos :(prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> python setup.py sdist bdist_wheel


#https://pypi.org/account/register/
#ahora para subir al repositorio usamos
#(prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> twine upload dist/*   
#piden el token que se creo con la cuenta  https://pypi.org/manage/account/token/

# salio error ERROR    HTTPError: 400 Bad Request from https://upload.pypi.org/legacy/
#'Lenguaje de Programacion :: Python 3.12' is not a valid classifier. See https://packaging.python.org/specifications/core-metadata for more information.
#cambiamos en nuestro archivo en la parte de setup pero debemos crear de nuevo nuestro archivo de distribucion
#por lo que eliminamos la carpeta dist
#ahora creamos de nuevo la distribucion
#(prueba) PS F:\Cursos Actualizacion\Python\aplicacion_ventas> python setup.py sdist bdist_wheel
