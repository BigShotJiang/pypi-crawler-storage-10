def score(responses):
    import pandas as pd

    reverse_items = {'Neuroticism': [50, 80, 95, 100, 105, 110, 115],
                     'Extraversion': [61, 66, 91, 96, 101, 106],
                     'Openness': [47, 52, 67, 72, 77, 82, 87, 97, 102, 107, 112, 117],
                     'Agreeableness': [8, 18, 23, 38, 48, 53, 68, 73, 78, 83, 88, 93, 98, 103, 108, 113, 118],
                     'Conscientiousness': [29, 39, 59, 69, 74, 79, 84, 89, 99, 104, 109, 114, 119]}
    
    trait_items = {'Agreeableness': [3, 8, 13, 18, 23, 28, 33, 38, 43, 48, 53, 58, 63, 68, 73, 78, 83, 88, 93, 98, 103, 108, 113, 118],
                   'Conscientiousness': [4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59, 64, 69, 74, 79, 84, 89, 94, 99, 104, 109, 114, 119],
                   'Extraversion': [1, 6, 11, 16, 21, 26, 31, 36, 41, 46, 51, 56, 61, 66, 71, 76, 81, 86, 91, 96, 101, 106, 111, 116],
                   'Neuroticism': [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 110, 115],
                   'Openness': [2, 7, 12, 17, 22, 27, 32, 37, 42, 47, 52, 57, 62, 67, 72, 77, 82, 87, 92, 97, 102, 107, 112, 117]}

    scores = {}
    for trait, items in trait_items.items():
        total = 0
        for idx in items:
            resp = responses[idx]
            if idx in reverse_items[trait]:
                resp = 6 - resp
            total += resp
        scores[trait] = total / len(items)
    df = pd.DataFrame([scores])
    return df

Qs = ['I worry about things.',
 'I make friends easily.',
 'I have a vivid imagination.',
 'I trust others.',
 'I complete tasks successfully.',
 'I get angry easily.',
 'I love large parties.',
 'I believe in the importance of art.',
 'I use others for my own ends.',
 'I like to tidy up.',
 'I often feel blue.',
 'I take charge.',
 'I experience my emotions intensely.',
 'I love to help others.',
 'I keep my promises.',
 'I find it difficult to approach others.',
 'I am always busy.',
 'I prefer variety to routine.',
 'I love a good fight.',
 'I work hard.',
 'I go on binges.',
 'I love excitement.',
 'I love to read challenging material.',
 'I believe that I am better than others.',
 'I am always prepared.',
 'I panic easily.',
 'I radiate joy.',
 'I tend to vote for liberal political candidates.',
 'I sympathize with the homeless.',
 'I jump into things without thinking.',
 'I fear for the worst.',
 'I feel comfortable around people.',
 'I enjoy wild flights of fantasy.',
 'I believe that others have good intentions.',
 'I excel in what I do.',
 'I get irritated easily.',
 'I talk to a lot of different people at parties.',
 'I see beauty in things that others might not notice.',
 'I cheat to get ahead.',
 'I often forget to put things back in their proper place.',
 'I dislike myself.',
 'I try to lead others.',
 "I feel others' emotions.",
 'I am concerned about others.',
 'I tell the truth.',
 'I am afraid to draw attention to myself.',
 'I am always on the go.',
 'I prefer to stick with things that I know.',
 'I yell at people.',
 "I do more than what's expected of me.",
 'I rarely overindulge.',
 'I seek adventure.',
 'I avoid philosophical discussions.',
 'I think highly of myself.',
 'I carry out my plans.',
 'I become overwhelmed by events.',
 'I have a lot of fun.',
 'I believe that there is no absolute right and wrong.',
 'I feel sympathy for those who are worse off than myself.',
 'I make rash decisions.',
 'I am afraid of many things.',
 'I avoid contacts with others.',
 'I love to daydream.',
 'I trust what people say.',
 'I handle tasks smoothly.',
 'I lose my temper.',
 'I prefer to be alone.',
 'I do not like poetry.',
 'I take advantage of others.',
 'I leave a mess in my room.',
 'I am often down in the dumps.',
 'I take control of things.',
 'I rarely notice my emotional reactions.',
 'I am indifferent to the feelings of others.',
 'I break rules.',
 'I only feel comfortable with friends.',
 'I do a lot in my spare time.',
 'I dislike changes.',
 'I insult people.',
 'I do just enough work to get by.',
 'I easily resist temptations.',
 'I enjoy being reckless.',
 'I have difficulty understanding abstract ideas.',
 'I have a high opinion of myself.',
 'I waste my time.',
 "I feel that I'm unable to deal with things.",
 'I love life.',
 'I tend to vote for conservative political candidates.',
 "I am not interested in other people's problems.",
 'I rush into things.',
 'I get stressed out easily.',
 'I keep others at a distance.',
 'I like to get lost in thought.',
 'I distrust people.',
 'I know how to get things done.',
 'I am not easily annoyed.',
 'I avoid crowds.',
 'I do not enjoy going to art museums.',
 "I obstruct others' plans.",
 'I leave my belongings around.',
 'I feel comfortable with myself.',
 'I wait for others to lead the way.',
 "I don't understand people who get emotional.",
 'I take no time for others.',
 'I break my promises.',
 'I am not bothered by difficult social situations.',
 'I like to take it easy.',
 'I am attached to conventional ways.',
 'I get back at others.',
 'I put little time and effort into my work.',
 'I am able to control my cravings.',
 'I act wild and crazy.',
 'I am not interested in theoretical discussions.',
 'I boast about my virtues.',
 'I have difficulty starting tasks.',
 'I remain calm under pressure.',
 'I look at the bright side of life.',
 'I believe that we should be tough on crime.',
 'I try not to think about the needy.',
 'I act without thinking.']

def BFI_120(model, tokenizer, save_path,
            turns = 10, max_new_tokens = 512, temperature = 0.5, top_p = 0.7, streamer = True,
            instruction = "You are playing the role of a real-life human, taking a personality test.\nFor the statement provided:\n1) Think about how would you (as a real-world human) might feel or act regarding the statement. Consider different facets of it.\n2) Decide on a 5-point Likert scale (where 1 = 'very inaccurate', 2 = 'moderately inaccurate', 3 = 'neither accurate nor inaccurate', 4 = 'moderately accurate', and 5 = 'very accurate') that best reflects this simulated personality.\n3) Briefly explain your reasoning for that rating.\n\nYour response should be in the following format:\n'''Rating: {score}\nReasoning: {reasoning}'''",
            user_prompt = "Think about the following statement. How accurately does it describes you on a 5-point Likert scale (where 1 = 'very inaccurate', 2 = 'moderately inaccurate', 3 = 'neither accurate nor inaccurate', 4 = 'moderately accurate', and 5 = 'very accurate')?"
            ):
    from transformers import TextStreamer
    results = []
    scores = []
    logs = []
    for turn in range(turns):
      print(f"- - - ### {turn+1} ### - - -")
      AL = []

      i = 1
      for Q in Qs:
        st = f"[turn {turn+1}], " + str(i) + '. ' + 'Statement: '
        print(st ,Q)
        inputs = tokenizer.apply_chat_template(
          [{"role": "system", "content": instruction},
          {"role": "user", "content": f"{user_prompt}\nStatement: '{Q}'"}],
          tokenize=True,
          add_generation_prompt=True,
          return_tensors="pt").to("cuda")
    
        outputs = model.generate(input_ids = inputs,
          max_new_tokens = max_new_tokens,
          temperature = temperature,
          top_p = top_p,
          pad_token_id = tokenizer.eos_token_id,
          streamer = TextStreamer(tokenizer, skip_prompt = streamer),
          do_sample = True)
    
        print('\n______________________________________________________\n')
        AL.append(tokenizer.batch_decode(outputs)[0].split("<|eot_id|><|start_header_id|>assistant<|end_header_id|>")[-1])
        i=i+1
    
        import re
        responses = [int(re.search(r"Rating:\s*(\S)", s).group(1)) for s in AL]
    
      print(score(responses))
      scores.append(score(responses))
    
      results.append(responses)
      logs.append(AL)
    #%%
    
    
    # --------------------
    # Parameters
    # --------------------
    # Build combined (one row per score_50(results[i]))
    # --------------------
    # collect one-row DataFrames
    ps = ['Turn 1', 'Turn 2', 'Turn 3', 'Turn 4', 'Turn 5', 'Turn 6', 'Turn 7', 'Turn 8', 'Turn 9', 'Turn 10']
    dfs = [score(results[i]) for i in range(len(results))]
    dfs = ps.append(dfs)
    
    # concatenate once (ignore_index avoids duplicate 0 indexes)
    import pandas as pd
    combined = pd.concat(dfs, ignore_index=True)
    
    # --------------------
    # Build items DataFrame from results (list of same-length lists of ints)
    # --------------------
    # create column names item_0, item_1, ...
    n_items = len(results[0])+1 if len(results) > 0 else 0
    items_cols = ['Participant',
                  'N - Anxiety (+)', 'Friendliness (+)', 'O - Imagination (+)', 'Trust (+)',
                  'C - Self-efficacy (+)', 'N - Anger (+)', 'E - Gregariousness (+)', 'O - Artistic interests (+)',
                  'A - Morality (-)', 'C - Orderliness (+)', 'N - Depression (+)', 'E - Assertiveness (+)', 'O - Emotionality (+)',
                  'A - Altruism (+)', 'C - Dutifulness (+)', 'N - Consciousness (+)', 'E - Activity level (+)', 'O - Adventurousness (+)',
                  'A - Cooperation (-)', 'C - Achievement-striving (+)', 'N - Immoderation (+)', 'E - Excitement-seeking (+)',
                  'O - Intellect (+)', 'A - Modesty (-)', 'C - Self-discipline (+)', 'N - Vulnerability (+)', 'E - Cheerfulness (+)',
                  'O - Liberalism (+)', 'A - Sympathy (+)', 'C - Cautiousness (-)', 'N - Anxiety (+)', 'Friendliness (+)',
                  'O - Imagination (+)', 'Trust (+)', 'C - Self-efficacy (+)', 'N - Anger (+)', 'E - Gregariousness (+)',
                  'O - Artistic interests (+)', 'A - Morality (-)', 'C - Orderliness (-)', 'N - Depression (+)', 'E - Assertiveness (+)',
                  'O - Emotionality (+)', 'A - Altruism (+)', 'C - Dutifulness (+)', 'N - Consciousness (+)', 'E - Activity level (+)',
                  'O - Adventurousness (-)', 'A - Cooperation (-)', 'C - Achievement-striving (+)', 'N - Immoderation (-)',
                  'E - Excitement-seeking (+)', 'O - Intellect (-)', 'A - Modesty (-)', 'C - Self-discipline (+)', 'N - Vulnerability (+)',
                  'E - Cheerfulness (+)', 'O - Liberalism (+)', 'A - Sympathy (+)', 'C - Cautiousness (-)', 'N - Anxiety (+)',
                  'Friendliness (-)', 'O - Imagination (+)', 'Trust (+)', 'C - Self-efficacy (+)', 'N - Anger (+)',
                  'E - Gregariousness (-)', 'O - Artistic interests (-)', 'A - Morality (-)', 'C - Orderliness (-)', 'N - Depression (+)',
                  'E - Assertiveness (+)', 'O - Emotionality (-)', 'A - Altruism (-)', 'C - Dutifulness (-)', 'N - Consciousness (+)',
                  'E - Activity level (+)', 'O - Adventurousness (-)', 'A - Cooperation (-)', 'C - Achievement-striving (-)',
                  'N - Immoderation (-)', 'E - Excitement-seeking (+)', 'O - Intellect (-)', 'A - Modesty (-)', 'C - Self-discipline (-)',
                  'N - Vulnerability (+)', 'E - Cheerfulness (+)', 'O - Liberalism (-)', 'A - Sympathy (-)', 'C - Cautiousness (-)',
                  'N - Anxiety (+)', 'Friendliness (-)', 'O - Imagination (+)', 'Trust (-)', 'C - Self-efficacy (+)',
                  'N - Anger (-)', 'E - Gregariousness (-)', 'O - Artistic interests (-)', 'A - Morality (-)', 'C - Orderliness (-)',
                  'N - Depression (-)', 'E - Assertiveness (-)', 'O - Emotionality (-)', 'A - Altruism (-)', 'C - Dutifulness (-)',
                  'N - Consciousness (-)', 'E - Activity level (-)', 'O - Adventurousness (-)', 'A - Cooperation (-)',
                  'C - Achievement-striving (-)', 'N - Immoderation (-)', 'E - Excitement-seeking (+)', 'O - Intellect (-)',
                  'A - Modesty (-)', 'C - Self-discipline (-)', 'N - Vulnerability (-)', 'E - Cheerfulness (+)', 'O - Liberalism (-)',
                  'A - Sympathy (-)', 'C - Cautiousness (-)']
    results.insert(0,ps)
    items_df = pd.DataFrame(results, columns=items_cols)
    
    # --------------------
    # Save both to an Excel file in two sheets: 'traits' and 'items'
    # --------------------
    # requires openpyxl for .xlsx (install with `pip install openpyxl` if needed)
    import openpyxl
    with pd.ExcelWriter(save_path, engine="openpyxl") as writer:
        combined.to_excel(writer, sheet_name="traits", index=False)
        items_df.to_excel(writer, sheet_name="items", index=False)
    
    print(f"Saved {save_path} with sheets: 'traits' and 'items'")