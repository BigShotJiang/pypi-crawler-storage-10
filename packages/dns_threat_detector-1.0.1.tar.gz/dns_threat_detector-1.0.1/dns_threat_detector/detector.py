"""
DNS Threat Detector - Production Model with Safelist Integration

This module provides a production-ready DNS threat detection system that combines:
1. Safelist checking for instant benign classification
2. Brand whitelist for exact matches to top brands
3. Typosquatting detection using edit distance
4. ML ensemble (LightGBM + LSTM + Meta-learner) for general threats

Performance: 99.68% F1-score, 100% typosquatting detection, <0.5ms latency
"""

import pickle
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Optional, Union, Tuple
import json
from datetime import datetime
import math
from collections import Counter
import time


class CharacterTokenizer:
    """Character-level tokenizer for domain names"""

    def __init__(self):
        self.char_to_idx = {}
        self.idx_to_char = {}
        self.vocab_size = 0

    def fit(self, texts):
        """Build vocabulary from texts"""
        chars = set()
        for text in texts:
            chars.update(text)

        self.char_to_idx = {char: idx + 1 for idx, char in enumerate(sorted(chars))}
        self.char_to_idx["<PAD>"] = 0
        self.idx_to_char = {idx: char for char, idx in self.char_to_idx.items()}
        self.vocab_size = len(self.char_to_idx)

    def encode(self, text):
        """Convert text to sequence of indices"""
        return [self.char_to_idx.get(char, 0) for char in text]

    def texts_to_sequences(self, texts):
        """Convert multiple texts to sequences"""
        return [self.encode(text) for text in texts]

    def decode(self, indices):
        """Convert indices back to text"""
        return "".join([self.idx_to_char.get(idx, "") for idx in indices])


class LSTMModel(nn.Module):
    """Bidirectional LSTM for character-level domain classification"""

    def __init__(
        self,
        vocab_size=41,
        embedding_dim=32,
        lstm_hidden=64,
        lstm_layers=2,
        dropout=0.3,
    ):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(
            embedding_dim,
            lstm_hidden,
            lstm_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if lstm_layers > 1 else 0,
        )
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden * 2, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 2),
        )

    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, (hidden, cell) = self.lstm(embedded)

        hidden_fwd = hidden[-2, :, :]
        hidden_bwd = hidden[-1, :, :]
        hidden_cat = torch.cat([hidden_fwd, hidden_bwd], dim=1)

        output = self.fc(hidden_cat)
        return output


class DNS_ThreatDetector:
    """
    Production DNS Threat Detector with Safelist Support

    Features:
    - Multi-tier safelist checking (O(1) lookup for tiers 1-3)
    - Brand whitelist (99 top global brands)
    - Typosquatting detection (edit distance 1-3)
    - ML ensemble (LightGBM + LSTM + Meta-learner)

    Usage:
        detector = DNS_ThreatDetector(use_safelist=True, safelist_tiers=[1, 2, 3])
        detector.load_models()
        result = detector.predict('example.com')
    """

    TOP_BRANDS = [
        "google",
        "microsoft",
        "facebook",
        "paypal",
        "amazon",
        "apple",
        "netflix",
        "twitter",
        "instagram",
        "linkedin",
        "ebay",
        "yahoo",
        "adobe",
        "salesforce",
        "oracle",
        "ibm",
        "intel",
        "cisco",
        "samsung",
        "sony",
        "youtube",
        "gmail",
        "outlook",
        "hotmail",
        "icloud",
        "dropbox",
        "github",
        "stackoverflow",
        "reddit",
        "imgur",
        "twitch",
        "discord",
        "spotify",
        "steam",
        "nvidia",
        "amd",
        "walmart",
        "target",
        "costco",
        "ikea",
        "hulu",
        "disney",
        "hbo",
        "espn",
        "cnn",
        "bbc",
        "nytimes",
        "washingtonpost",
        "guardian",
        "chase",
        "wellsfargo",
        "bankofamerica",
        "citibank",
        "capitalone",
        "visa",
        "mastercard",
        "amex",
        "discover",
        "stripe",
        "square",
        "venmo",
        "zelle",
        "fedex",
        "ups",
        "usps",
        "dhl",
        "alibaba",
        "tencent",
        "baidu",
        "zoom",
        "slack",
        "teams",
        "skype",
        "whatsapp",
        "telegram",
        "signal",
        "photoshop",
        "wordpress",
        "wix",
        "shopify",
        "etsy",
        "airbnb",
        "uber",
        "lyft",
        "doordash",
        "grubhub",
        "peacock",
        "paramount",
        "verizon",
        "att",
        "tmobile",
        "sprint",
        "comcast",
        "spectrum",
        "cox",
    ]

    def __init__(
        self,
        models_dir: Optional[str] = None,
        use_safelist: bool = False,
        safelist_dir: Optional[str] = None,
        safelist_tiers: List[int] = [1, 2, 3],
        verbose: bool = False,
    ):
        """
        Initialize DNS Threat Detector

        Args:
            models_dir: Directory containing model files (default: bundled models/)
            use_safelist: Whether to enable safelist checking
            safelist_dir: Directory containing tier files (default: bundled safelists/)
            safelist_tiers: List of tiers to load (1=Critical, 2=High Trust, 3=General)
            verbose: Whether to print detailed loading messages (default: False)
        """
        if models_dir is None:
            models_dir = Path(__file__).parent / "models"
        self.models_dir = Path(models_dir)

        self.use_safelist = use_safelist
        self.safelist_tiers = safelist_tiers

        if safelist_dir is None:
            safelist_dir = Path(__file__).parent / "safelists"
        self.safelist_dir = Path(safelist_dir)

        self.verbose = verbose
        self.tokenizer = None
        self.lstm_model = None
        self.lgbm_model = None
        self.meta_learner = None

        self.safelist = set()
        self.safelist_stats = {
            "enabled": use_safelist,
            "tiers_loaded": [],
            "total_domains": 0,
            "tier_counts": {},
        }

        self.prediction_count = 0
        self.safelist_hits = 0
        self.brand_whitelist_hits = 0
        self.typosquatting_hits = 0
        self.ensemble_predictions = 0

    def load_models(self):
        """Load all model components"""
        if self.verbose:
            print("Loading models...")

        tokenizer_path = self.models_dir / "tokenizer.pkl"
        with open(tokenizer_path, "rb") as f:
            self.tokenizer = pickle.load(f)
        if self.verbose:
            print(f"  Tokenizer loaded: {tokenizer_path}")

        lstm_path = self.models_dir / "lstm_model.pth"
        self.lstm_model = LSTMModel()
        self.lstm_model.load_state_dict(
            torch.load(lstm_path, map_location=torch.device("cpu"))
        )
        self.lstm_model.eval()
        if self.verbose:
            print(f"  LSTM model loaded: {lstm_path}")

        lgbm_path = self.models_dir / "lgbm_typo_enhanced.pkl"
        with open(lgbm_path, "rb") as f:
            self.lgbm_model = pickle.load(f)
        if self.verbose:
            print(f"  LightGBM model loaded: {lgbm_path}")

        meta_path = self.models_dir / "meta_learner.pkl"
        with open(meta_path, "rb") as f:
            self.meta_learner = pickle.load(f)
        if self.verbose:
            print(f"  Meta-learner loaded: {meta_path}")

        if self.use_safelist:
            self._load_safelist()

        if self.verbose:
            print("All models loaded successfully")

    def _load_safelist(self):
        """Load safelist from tier files"""
        if self.verbose:
            print(f"Loading safelist from: {self.safelist_dir}")

        tier_names = {
            1: "tier1_critical.txt",
            2: "tier2_high_trust.txt",
            3: "tier3_general.txt",
            4: "tier4_supplementary.txt",
        }

        for tier in self.safelist_tiers:
            tier_file = self.safelist_dir / tier_names[tier]

            if not tier_file.exists():
                if self.verbose:
                    print(f"  Warning: Tier {tier} file not found: {tier_file}")
                continue

            tier_domains = set()
            with open(tier_file, "r", encoding="utf-8") as f:
                for line in f:
                    domain = line.strip()
                    if domain and not domain.startswith("#"):
                        tier_domains.add(domain.lower())

            self.safelist.update(tier_domains)
            self.safelist_stats["tiers_loaded"].append(tier)
            self.safelist_stats["tier_counts"][tier] = len(tier_domains)

            if self.verbose:
                print(f"  Tier {tier} loaded: {len(tier_domains):,} domains")

        self.safelist_stats["total_domains"] = len(self.safelist)
        if self.verbose:
            print(f"Total safelist domains: {len(self.safelist):,}")

    def _is_safelisted(self, domain: str) -> bool:
        """Check if domain is in safelist"""
        if not self.use_safelist:
            return False
        return domain.lower() in self.safelist

    def _extract_domain_name(self, domain: str) -> str:
        """Extract domain name (before first dot)"""
        parts = domain.split(".")
        return parts[0] if len(parts) > 0 else domain

    def _calculate_edit_distance(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein edit distance"""
        if len(s1) < len(s2):
            return self._calculate_edit_distance(s2, s1)

        if len(s2) == 0:
            return len(s1)

        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row

        return previous_row[-1]

    def _check_typosquatting(self, domain: str) -> Optional[Dict]:
        """
        Check for typosquatting against top brands

        Returns:
            None if not typosquatting, dict with details if detected
        """
        domain_name = self._extract_domain_name(domain)

        if domain_name in self.TOP_BRANDS:
            return {
                "is_typosquatting": False,
                "is_brand": True,
                "brand": domain_name,
                "distance": 0,
            }

        min_distance = float("inf")
        closest_brand = None

        for brand in self.TOP_BRANDS:
            distance = self._calculate_edit_distance(domain_name, brand)
            if distance < min_distance:
                min_distance = distance
                closest_brand = brand

        if 1 <= min_distance <= 3:
            return {
                "is_typosquatting": True,
                "is_brand": False,
                "brand": closest_brand,
                "distance": min_distance,
            }

        return None

    def _calculate_entropy(self, text: str) -> float:
        """Calculate Shannon entropy"""
        if not text:
            return 0.0

        counts = Counter(text)
        length = len(text)
        entropy = 0.0

        for count in counts.values():
            probability = count / length
            if probability > 0:
                entropy -= probability * math.log2(probability)

        return entropy

    def _extract_fqdn_features(self, domain: str) -> Dict[str, float]:
        """Extract FQDN features (4 features)"""
        domain_name = self._extract_domain_name(domain)

        features = {
            "domain_length": len(domain_name),
            "subdomain_count": domain.count("."),
            "numeric_chars": sum(c.isdigit() for c in domain_name),
            "entropy": self._calculate_entropy(domain_name),
        }

        return features

    def _extract_typosquatting_features(self, domain: str) -> Dict[str, float]:
        """Extract typosquatting features (7 features)"""
        domain_name = self._extract_domain_name(domain)

        distances = [
            self._calculate_edit_distance(domain_name, brand)
            for brand in self.TOP_BRANDS
        ]
        min_distance = min(distances)
        closest_brand_idx = distances.index(min_distance)
        closest_brand = self.TOP_BRANDS[closest_brand_idx]

        features = {
            "min_edit_distance": min_distance,
            "edit_distance_ratio": (
                min_distance / len(closest_brand) if len(closest_brand) > 0 else 0
            ),
            "length_diff_to_closest": abs(len(domain_name) - len(closest_brand)),
            "has_extra_char": (
                1 if min_distance == 1 and len(domain_name) > len(closest_brand) else 0
            ),
            "has_missing_char": (
                1 if min_distance == 1 and len(domain_name) < len(closest_brand) else 0
            ),
            "has_swapped_char": 1 if min_distance == 2 else 0,
            "digit_substitution": (
                1 if any(c.isdigit() for c in domain_name) and min_distance <= 2 else 0
            ),
        }

        return features

    def _extract_all_features(self, domain: str) -> pd.DataFrame:
        """Extract all 11 features for ML model"""
        fqdn_features = self._extract_fqdn_features(domain)
        typo_features = self._extract_typosquatting_features(domain)

        all_features = {**fqdn_features, **typo_features}

        feature_names = [
            "domain_length",
            "subdomain_count",
            "numeric_chars",
            "entropy",
            "min_edit_distance",
            "edit_distance_ratio",
            "length_diff_to_closest",
            "has_extra_char",
            "has_missing_char",
            "has_swapped_char",
            "digit_substitution",
        ]

        return pd.DataFrame([all_features], columns=feature_names)

    def _predict_lstm(self, domain: str) -> float:
        """Get LSTM prediction probability"""
        domain_name = self._extract_domain_name(domain)
        tokens = self.tokenizer.texts_to_sequences([domain_name])

        max_len = 64
        padded = torch.zeros((1, max_len), dtype=torch.long)
        token_len = min(len(tokens[0]), max_len)
        if token_len > 0:
            padded[0, :token_len] = torch.tensor(tokens[0][:token_len])

        with torch.no_grad():
            output = self.lstm_model(padded)
            probabilities = torch.softmax(output, dim=1)
            malicious_prob = probabilities[0][1].item()

        return malicious_prob

    def _predict_lgbm(self, domain: str) -> float:
        """Get LightGBM prediction probability"""
        features = self._extract_all_features(domain)
        probabilities = self.lgbm_model.predict_proba(features)
        return probabilities[0][1]

    def _predict_ensemble(self, domain: str) -> Tuple[str, float]:
        """Get ensemble prediction using meta-learner"""
        lstm_prob = self._predict_lstm(domain)
        lgbm_prob = self._predict_lgbm(domain)

        meta_input = np.array([[lgbm_prob, lstm_prob]])
        prediction = self.meta_learner.predict(meta_input)[0]

        if hasattr(self.meta_learner, "predict_proba"):
            probabilities = self.meta_learner.predict_proba(meta_input)
            confidence = probabilities[0][prediction]
        else:
            confidence = max(lgbm_prob, lstm_prob)

        prediction_label = "MALICIOUS" if prediction == 1 else "BENIGN"
        return prediction_label, confidence

    def predict(self, domain: str) -> Dict:
        """
        Predict if domain is malicious or benign

        Prediction flow:
        1. Check safelist (if enabled) -> BENIGN
        2. Check exact brand match -> BENIGN
        3. Check typosquatting (distance 1-3) -> MALICIOUS
        4. Use ML ensemble -> MALICIOUS/BENIGN

        Args:
            domain: Domain name to classify

        Returns:
            {
                'prediction': 'MALICIOUS' or 'BENIGN',
                'confidence': float (0.0 to 1.0),
                'reason': str (human-readable explanation),
                'method': str (detection method used),
                'latency_ms': float (inference time in milliseconds)
            }
        """
        start_time = time.time()
        self.prediction_count += 1

        domain = domain.lower().strip()

        if self._is_safelisted(domain):
            self.safelist_hits += 1
            return {
                "prediction": "BENIGN",
                "confidence": 1.0,
                "reason": f"Domain in safelist",
                "method": "safelist",
                "latency_ms": (time.time() - start_time) * 1000,
            }

        typo_result = self._check_typosquatting(domain)

        if typo_result:
            if typo_result["is_brand"]:
                self.brand_whitelist_hits += 1
                return {
                    "prediction": "BENIGN",
                    "confidence": 1.0,
                    "reason": f'Exact match to brand: {typo_result["brand"]}',
                    "method": "brand_whitelist",
                    "latency_ms": (time.time() - start_time) * 1000,
                }
            elif typo_result["is_typosquatting"]:
                self.typosquatting_hits += 1
                confidence = 1.0 - (typo_result["distance"] / 10)
                return {
                    "prediction": "MALICIOUS",
                    "confidence": confidence,
                    "reason": f'Typosquatting (dist={typo_result["distance"]} to {typo_result["brand"]})',
                    "method": "typosquatting_rule",
                    "latency_ms": (time.time() - start_time) * 1000,
                }

        self.ensemble_predictions += 1
        prediction, confidence = self._predict_ensemble(domain)

        reason = "ML ensemble prediction"
        if prediction == "MALICIOUS":
            reason = "Detected as DGA or malware domain"
        else:
            reason = "Classified as legitimate domain"

        return {
            "prediction": prediction,
            "confidence": confidence,
            "reason": reason,
            "method": "ensemble",
            "latency_ms": (time.time() - start_time) * 1000,
        }

    def predict_batch(self, domains: List[str]) -> List[Dict]:
        """Predict multiple domains"""
        return [self.predict(domain) for domain in domains]

    def get_model_info(self) -> Dict:
        """Get model information and statistics"""
        return {
            "model_name": "DNS_ThreatDetector",
            "version": "1.0.0",
            "components": {
                "lstm": "Bidirectional LSTM (159K params)",
                "lgbm": "LightGBM with 11 features",
                "meta_learner": "Logistic Regression",
                "typosquatting": "Rule-based + ML hybrid",
                "safelist": (
                    "Multi-tier (O(1) lookup)" if self.use_safelist else "Disabled"
                ),
            },
            "performance": {
                "f1_score": 0.9968,
                "accuracy": 0.9938,
                "precision": 0.9715,
                "recall": 0.9995,
                "typosquatting_detection": 1.0,
                "avg_latency_ms": 0.439,
            },
            "features": {
                "fqdn_features": 4,
                "typosquatting_features": 7,
                "total_features": 11,
            },
            "safelist": self.safelist_stats,
            "protected_brands": len(self.TOP_BRANDS),
            "usage_statistics": {
                "total_predictions": self.prediction_count,
                "safelist_hits": self.safelist_hits,
                "brand_whitelist_hits": self.brand_whitelist_hits,
                "typosquatting_detections": self.typosquatting_hits,
                "ensemble_predictions": self.ensemble_predictions,
            },
        }

    def save_metadata(self, output_path: str):
        """Save model metadata to JSON"""
        metadata = self.get_model_info()

        with open(output_path, "w") as f:
            json.dump(metadata, f, indent=2)

        print(f"Metadata saved to: {output_path}")
