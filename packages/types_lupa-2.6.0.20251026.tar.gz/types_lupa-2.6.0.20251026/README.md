## Typing stubs for lupa

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`lupa`](https://github.com/scoder/lupa) package. It can be used by type checkers
to check code that uses `lupa`. This version of
`types-lupa` aims to provide accurate annotations for
`lupa==2.6.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/lupa`](https://github.com/python/typeshed/tree/main/stubs/lupa)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`a5c7752ad2eeb64327e2728ba4391371d9921cf1`](https://github.com/python/typeshed/commit/a5c7752ad2eeb64327e2728ba4391371d9921cf1).