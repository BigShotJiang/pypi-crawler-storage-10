Changelog
=========

v0.1.0
------

*2025-10-29* -- Drop python 3.9 support and add python 3.14 support

v0.0.2
------

*2025-08-05* -- Specify compile arguments in setup.py. Build for MacOS and Windows.

v0.0.1
------

*2025-07-31* -- Initial release.
