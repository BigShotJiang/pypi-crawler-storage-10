import polars as pl

_FIXED_COST = 1.5
_VARIABLE_COST = 0.01
_LOW_REGIME_ROWS = 15e3
_LOW_REGIME_FEATURES = 250


def compute_credits_to_use_nicl(
    df_train: pl.DataFrame,
    df_predict: pl.DataFrame,
    fixed_cost: float = _FIXED_COST,
    variable_cost: float = _VARIABLE_COST,
    low_regime_rows: int = _LOW_REGIME_ROWS,
    low_regime_features: int = _LOW_REGIME_FEATURES,
) -> float:
    """
    Estimate the number of credits required for using NICL.
    If the dataset is below the low regime threshold, the estimated cost is a fixed cost.
    Otherwise, the estimated cost is a fixed cost plus the variable cost for the additional rows.

    Parameters
    ----------
    df_train : pl.DataFrame
        The dataframe used for the context.
    df_predict : pl.DataFrame
        The dataframe to predict on.
    fixed_cost : float, default=1.5
        Base cost in credits for small datasets.
    variable_cost : float, default=0.01
        Cost per additional row beyond the low regime threshold.
    low_regime_rows : int, default=15000
        Row threshold for fixed cost regime.
    low_regime_features : int, default=250
        Feature threshold for fixed cost regime.

    Returns
    -------
    float
        Estimated number of credits for predictions.
    """

    n_samples = df_train.shape[0] + df_predict.shape[0]
    n_features = df_train.shape[1]

    if (n_samples < low_regime_rows) and (n_features < low_regime_features):
        return fixed_cost
    else:
        additional_rows = max(0, n_samples - low_regime_rows)
        return fixed_cost + additional_rows * variable_cost
