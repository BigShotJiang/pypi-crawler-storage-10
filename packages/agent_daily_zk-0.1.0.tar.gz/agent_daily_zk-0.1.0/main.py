from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP

# 初始化FastMCP服务器
mcp = FastMCP()

def get_construction_json_string():
    # 用三重单引号包裹JSON内容，直接保留原始格式，无需额外转义
    json_str = '''[
    {
        "id": 34,
        "po_no": ["PO2508269999"],
        "service_work_order_no": ["PN20250826001100"],
        "construction_daily_no": "DR20251027000008",
        "construction_daily_paper_no": "CDP20251027000006",
        "construction_work": "<p style=text-align: justify;>1) Replaced spare parts for two lubricators.</p><p style=text-align: justify;>2) Confirmed the construction details of the angular encoder.</p><p style=text-align: justify;>3) Completed the entry formalities.</p><p style=text-align: justify;>4) Checked and counted the spare parts.</p>",
        "vessels_pare_part": [],
        "wk_pare_part": [],
        "abnormal_defect": "",
        "anomaly": [{"anomaly": "Plunger spare parts of lubricator not arrived on board.", "anomalyDate": "2025-06-02", "completionDate": "2025-06-21", "disposalResult": "Wait the spare parts."}],
        "future_operational_matter": null,
        "outstanding_item": null
    },
    {
        "id": 35,
        "po_no": ["PO2508269999"],
        "service_work_order_no": ["PN20250826001100"],
        "construction_daily_no": "DR20251027000009",
        "construction_daily_paper_no": "CDP20251027000007",
        "construction_work": "<p style=text-align: justify;>1) All 6 sets lubricators were disassembled/cleaned/inspected/reassembled, replacement with repair kits.</p>",
        "vessels_pare_part": [],
        "wk_pare_part": [],
        "abnormal_defect": null,
        "anomaly": [{"anomaly": "Plunger spare parts of lubricator not arrived on board.", "anomalyDate": "2025-06-21", "completionDate": "2025-06-21", "disposalResult": "Wait for the spare parts."}],
        "future_operational_matter": null,
        "outstanding_item": null
    },
    {
        "id": 36,
        "po_no": ["PO2508269999"],
        "service_work_order_no": ["PN20250826001100"],
        "construction_daily_no": "DR20251027000011",
        "construction_daily_paper_no": "CDP20251027000009",
        "construction_work": "<p style=text-align: justify;>1) All 6 sets lubricators were reinstalled with new sealing rings.</p><p style=text-align: justify;>2) pick-up sensor was replaced with new spare/function tested, normal working condition.</p><p style=text-align: justify;>3) Angle encoder was replaced with new spare/function tested, normal working condition.</p><p style=text-indent: 20pt; text-align: justify;> (manual turning of the rotor).</p>",
        "vessels_pare_part": [],
        "wk_pare_part": [],
        "abnormal_defect": null,
        "anomaly": [{"anomaly": "Plunger spare parts of lubricator not arrived on board.", "anomalyDate": "2025-06-21", "completionDate": "2025-06-21", "disposalResult": "Wait for the spare parts."}],
        "future_operational_matter": null,
        "outstanding_item": null
    },
    {
        "id": 37,
        "po_no": ["PO2508269999"],
        "service_work_order_no": ["PN20250826001100"],
        "construction_daily_no": "DR20251027000013",
        "construction_daily_paper_no": "CDP20251027000011",
        "construction_work": "<p style=text-align: justify;>1) All lubricators were function tested, all normal working condition.</p><p style=text-align: justify;>1-1   The air left in the lubricator lines was discharged.</p><p style=text-align: justify;>1-2   All the cylinder lubricator valves were function test inspected from scavenge box, all normal working</p><p style=text-indent: 21pt; text-align: justify;> condition.</p><p style=text-align: justify;>1-3   The alarm of the lubricators was eliminated under normal working condition.</p>",
        "vessels_pare_part": [{"name": "Membrane accumulator", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-018", "quantity": "6"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-187", "quantity": "24"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-271", "quantity": "12"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-305", "quantity": "48"}, {"name": "Non-return valve", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-317", "quantity": "48"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-329", "quantity": "48"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-342", "quantity": "12"}, {"name": "Plunger", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-366", "quantity": "48"}, {"name": "Membrane accumulator", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-437", "quantity": "12"}, {"name": "Gasket", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-449", "quantity": "12"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-474", "quantity": "12"}, {"name": "O-ring", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-486", "quantity": "12"}, {"name": "Inductive sensor", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-498", "quantity": "12"}, {"name": "Solenoid valve", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-533", "quantity": "12"}, {"name": "Cable gland", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-594", "quantity": "12"}, {"name": "Cable", "unit": "lubricator ", "factory": "HD -genuine parts", "spareNo": "P90307-0023-604", "quantity": "12"}],
        "wk_pare_part": [],
        "abnormal_defect": null,
        "anomaly": [{"anomaly": "Plunger spare parts of lubricator not arrived on board.", "anomalyDate": "2025-06-21", "completionDate": "2025-06-21", "disposalResult": "Wait for the spare parts."}],
        "future_operational_matter": null,
        "outstanding_item": null
    }
]'''
    # 直接返回String类型的JSON内容
    return json_str



@mcp.tool("fetch_by_construction_daily_nos", description="用 construction_daily_nos 查询符合条件日报")
async def fetch_by_construction_daily_nos(
    construction_daily_nos: list[str]) -> str:
    json = get_construction_json_string()
    return json



if __name__ == "__main__":
    # 初始化并运行服务器
    mcp.run(transport='stdio')