__version__ = "0.20.0"


def get_version() -> str:
    return __version__
