from typing import Any, Dict, List, Optional, Union
import aiohttp
from pydantic import BaseModel, ValidationError, Field
from typing_extensions import Literal

# 导入异常类
from ...exceptions import ShoplineAPIError

# 导入需要的模型
from ...models.app_metafield_value import AppMetafieldValue

async def call(
    session: aiohttp.ClientSession, customer_id: str, data: Optional[Dict[str, Any]] = None
) -> AppMetafieldValue:
    """
    Create specific app metafield
    
    To create app metafield attached to specific customer
    
    Path: POST /customers/{customer_id}/app_metafields
    """
    # 构建请求 URL
    url = f"customers/{customer_id}/app_metafields"

    # 构建请求头
    headers = {"Content-Type": "application/json"}

    # 构建请求体
    json_data = data if data else None

    # 发起 HTTP 请求
    async with session.post(
        url, json=json_data, headers=headers
    ) as response:
        if response.status >= 400:
            error_data = await response.json()
            raise ShoplineAPIError(
                status_code=response.status,
                **error_data
            )
        response_data = await response.json()

        # 验证并返回响应数据
        return AppMetafieldValue(**response_data)