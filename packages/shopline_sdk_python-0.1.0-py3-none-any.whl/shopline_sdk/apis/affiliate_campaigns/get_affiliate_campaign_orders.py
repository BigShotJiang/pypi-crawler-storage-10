from typing import Any, Dict, List, Optional, Union
import aiohttp
from pydantic import BaseModel, ValidationError, Field
from typing_extensions import Literal

# 导入异常类
from ...exceptions import ShoplineAPIError

# 导入需要的模型
from ...models.affiliate_campaign_orders import AffiliateCampaignOrders
from ...models.server_error import ServerError
from ...models.unprocessable_entity_error import UnprocessableEntityError

class Request(BaseModel):
    """查询参数模型"""
    previous_id: Optional[str] = None
    """The last ID of the orders in the previous request."""
    limit: Optional[int] = None
    """Numbers of Orders
      顯示 n 筆訂單"""

async def call(
    session: aiohttp.ClientSession, id: str, request: Optional[Request] = None
) -> AffiliateCampaignOrders:
    """
    Get Affiliate Campaign Orders
    
    To get affiliate campaign order.
    獲取使用特定推薦活動代碼的訂單。
    
    Path: GET /affiliate_campaigns/{id}/orders
    """
    # 构建请求 URL
    url = f"affiliate_campaigns/{id}/orders"

    # 构建查询参数
    params = {}
    if request:
        request_dict = request.model_dump(exclude_none=True)
        for key, value in request_dict.items():
            if value is not None:
                params[key] = value

    # 构建请求头
    headers = {"Content-Type": "application/json"}

    # 发起 HTTP 请求
    async with session.get(
        url, params=params, headers=headers
    ) as response:
        if response.status >= 400:
            error_data = await response.json()
            if response.status == 422:
                error_model = UnprocessableEntityError(**error_data)
                raise ShoplineAPIError(
                    status_code=422,
                    error=error_model,
                    **error_data
                )
            if response.status == 500:
                error_model = ServerError(**error_data)
                raise ShoplineAPIError(
                    status_code=500,
                    error=error_model,
                    **error_data
                )
            # 默认错误处理
            raise ShoplineAPIError(
                status_code=response.status,
                **error_data
            )
        response_data = await response.json()

        # 验证并返回响应数据
        return AffiliateCampaignOrders(**response_data)