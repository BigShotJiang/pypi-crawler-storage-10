from typing import Any, Dict, List, Optional, Union
import aiohttp
from pydantic import BaseModel, ValidationError, Field
from typing_extensions import Literal

# 导入异常类
from ...exceptions import ShoplineAPIError

# 导入需要的模型
from ...models.not_found_error import NotFoundError
from ...models.purchase_order import PurchaseOrder
from ...models.server_error import ServerError

class Request(BaseModel):
    """请求体模型"""
    purchase_order: Optional[Dict[str, Any]] = None

async def call(
    session: aiohttp.ClientSession, request: Optional[Request] = None
) -> PurchaseOrder:
    """
    Create purchase order
    
    Create purchase order
    創建進貨單
    
    Path: POST /pos/purchase_orders
    """
    # 构建请求 URL
    url = "pos/purchase_orders"

    # 构建请求头
    headers = {"Content-Type": "application/json"}

    # 构建请求体
    json_data = request.model_dump(exclude_none=True) if request else None

    # 发起 HTTP 请求
    async with session.post(
        url, json=json_data, headers=headers
    ) as response:
        if response.status >= 400:
            error_data = await response.json()
            if response.status == 404:
                error_model = NotFoundError(**error_data)
                raise ShoplineAPIError(
                    status_code=404,
                    error=error_model,
                    **error_data
                )
            if response.status == 500:
                error_model = ServerError(**error_data)
                raise ShoplineAPIError(
                    status_code=500,
                    error=error_model,
                    **error_data
                )
            # 默认错误处理
            raise ShoplineAPIError(
                status_code=response.status,
                **error_data
            )
        response_data = await response.json()

        # 验证并返回响应数据
        return PurchaseOrder(**response_data)