from typing import Any, Dict, List, Optional, Union
import aiohttp
from pydantic import BaseModel, ValidationError, Field
from typing_extensions import Literal

# 导入异常类
from ...exceptions import ShoplineAPIError

# 导入需要的模型
from ...models.paginatable import Paginatable
from ...models.payment import Payment

class Request(BaseModel):
    """查询参数模型"""
    page: Optional[int] = None
    """Page Number
      頁數"""
    per_page: Optional[int] = None
    """Numbers of Orders per Page
      每頁顯示 n 筆資料"""
    sort_by: Optional[Literal['asc', 'desc']] = None
    """Setting sorting direction
      設定時間排序"""
    order_by: Optional[Literal['created_at', 'priority']] = None
    """Setting sorting attribute
      設定排序使用值"""
    updated_after: Optional[str] = None
    """Filter payments by those updated after specific time.
      取得 updated_at 大於指定時間的付款方式(包含指定時間)
       *Should use UTC time'"""
    updated_before: Optional[str] = None
    """Filter payments by those updated before specific time.
      取得 updated_at 小於指定時間的付款方式(包含指定時間)
       *Should use UTC time'"""
    excludes: Optional[List[str]] = None
    """Could exclude certain parameters in the response
      結果要排除哪些參數"""
    fields: Optional[List[str]] = None
    """Could only show certain parameters in the response
      結果只顯示哪些參數"""
    channel_id: Optional[str] = None
    """Filter payments by channel approved sl-payments methods.
      取得門店可用付款方式"""

class Response(BaseModel):
    """响应体模型"""
    items: Optional[List[Payment]] = None
    pagination: Optional[Paginatable] = None

async def call(
    session: aiohttp.ClientSession, request: Optional[Request] = None
) -> Response:
    """
    Get Payments
    
    To get all kinds of payment methods with open API
    透過open API獲取所有的付款方式
    
    Path: GET /payments
    """
    # 构建请求 URL
    url = "payments"

    # 构建查询参数
    params = {}
    if request:
        request_dict = request.model_dump(exclude_none=True)
        for key, value in request_dict.items():
            if value is not None:
                params[key] = value

    # 构建请求头
    headers = {"Content-Type": "application/json"}

    # 发起 HTTP 请求
    async with session.get(
        url, params=params, headers=headers
    ) as response:
        if response.status >= 400:
            error_data = await response.json()
            raise ShoplineAPIError(
                status_code=response.status,
                **error_data
            )
        response_data = await response.json()

        # 验证并返回响应数据
        return Response(**response_data)