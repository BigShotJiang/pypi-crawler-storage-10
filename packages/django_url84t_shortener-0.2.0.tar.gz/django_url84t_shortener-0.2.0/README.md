# Django URL Shortener

A reusable Django app that provides URL shortening functionality. It allows you to create short codes that redirect to longer URLs and manage them through Django's admin interface.

## Features

- Create custom codes for URLs or auto-generate random ones
- Track usage statistics for each shortened URL
- Full admin interface integration
- Simple to integrate with existing Django projects

## Requirements

- Python 3.9+
- Django 3.2+

## Installation
```pip install django-url-shortener```

## Quick start

1. Add "url84t_shortener" to your INSTALLED_APPS setting:

```
INSTALLED_APPS = [
    ...
    'url84t_shortener',
]
```

2. Include the url84t_shortener URLconf in your project urls.py:
```
from django.urls import path, include
urlpatterns = [
    ...
    path('', include('url84t_shortener.urls')),
]
```

3. Run `python manage.py migrate` to create the necessary database tables.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a short URL (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/code/yourcode to be redirected to the destination URL.

## Usage

### Creating short URLs via the admin interface

1. Navigate to the Django admin interface
2. Go to the "Short URLs" section
3. Click "Add Short URL"
4. Enter a code or leave it blank for auto-generation
5. Enter the destination URL
6. Save

### Using in templates

You can generate links to your short URLs in templates:
```<a href="{% url 'url84t_shortener:redirect' 'yourcode' %}">Your short link</a>```


Or using the model instance:
```<a href="{{ short_url.get_absolute_url }}">Your short link</a>```


## License

[![License: Coffee-1.1](https://img.shields.io/badge/License-Coffee--1.1-ff6f00?style=flat&logo=coffee)](LICENSE)
[![Buy me a coffee](https://img.shields.io/badge/%E2%98%95_Buy%20me%20a%20coffee-ff5f5f?style=flat&logo=buy-me-a-coffee)](https://ko-fi.com/url84t)
[![Send me a bitcoin](https://img.shields.io/badge/%E2%98%95_Send%20me%20a%20bitcoin-ff5f5f?style=flat&logo=bitcoin)](bitcoin:bc1qnfv6uwpu6g6t45s3ns2xrsx4m7qulshp4g07kj)

**Bitcoin address:** `bc1qnfv6uwpu6g6t45s3ns2xrsx4m7qulshp4g07kj`  

