from django.shortcuts import get_object_or_404, redirect
from django.http import HttpResponseNotFound
from django.views.decorators.http import require_GET
from .models import ShortUrl

@require_GET
def redirect_to_url(request, code):
    """
    Redirect the user to the URL associated with the given code.
    """
    shorturl = get_object_or_404(ShortUrl, code=code, is_active=True)
    shorturl.increase_hits()
    return redirect(shorturl.destination_url)