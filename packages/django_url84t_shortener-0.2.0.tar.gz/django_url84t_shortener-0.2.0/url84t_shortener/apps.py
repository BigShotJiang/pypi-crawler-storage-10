from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class UrlShortenerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'url84t_shortener'
    verbose_name = _('URL Shortener')