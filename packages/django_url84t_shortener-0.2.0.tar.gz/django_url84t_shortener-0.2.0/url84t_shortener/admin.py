from django.contrib import admin
from django.utils.html import format_html
from .models import ShortUrl

@admin.register(ShortUrl)
class ShortUrlAdmin(admin.ModelAdmin):
    list_display = ('code', 'get_destination_url', 'hits', 'created_at', 'is_active', 'get_short_url')
    list_filter = ('is_active', 'created_at')
    search_fields = ('code', 'destination_url')
    readonly_fields = ('hits', 'created_at', 'updated_at', 'get_short_url')
    fieldsets = (
        (None, {
            'fields': ('code', 'destination_url', 'is_active')
        }),
        ('Statistics', {
            'fields': ('hits', 'created_at', 'updated_at')
        }),
    )
    
    def get_destination_url(self, obj):
        if len(obj.destination_url) > 50:
            return f"{obj.destination_url[:50]}..."
        return obj.destination_url
    get_destination_url.short_description = 'Destination URL'
    
    def get_short_url(self, obj):
        url = obj.get_absolute_url()
        return format_html('<a href="{url}" target="_blank">{url}</a>', url=url)
    get_short_url.short_description = 'Short URL'