from django.urls import path
from . import views

app_name = 'url84t_shortener'

urlpatterns = [
    path('code/<str:code>', views.redirect_to_url, name='redirect'),
]