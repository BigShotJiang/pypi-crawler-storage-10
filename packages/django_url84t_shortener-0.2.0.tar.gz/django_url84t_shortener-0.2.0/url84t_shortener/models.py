from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
import random
import string

def generate_random_code(length=6):
    """Generate a random code of specified length."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

class ShortUrl(models.Model):
    """
    Model to store URL shortcuts.
    """
    code = models.CharField(
        _("Short Code"),
        max_length=50,
        unique=True,
        help_text=_("The short code that will be used in the URL")
    )
    destination_url = models.URLField(
        _("Destination URL"),
        max_length=500,
        help_text=_("The URL where users will be redirected")
    )
    created_at = models.DateTimeField(
        _("Created At"),
        auto_now_add=True
    )
    updated_at = models.DateTimeField(
        _("Updated At"),
        auto_now=True
    )
    hits = models.PositiveIntegerField(
        _("Hits"),
        default=0,
        help_text=_("Number of times this link has been accessed")
    )
    is_active = models.BooleanField(
        _("Active"),
        default=True,
        help_text=_("Whether this redirect is active")
    )
    
    class Meta:
        verbose_name = _("Short URL")
        verbose_name_plural = _("Short URLs")
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.code} -> {self.destination_url}"
    
    def save(self, *args, **kwargs):
        # If no code is provided, generate a random one
        if not self.code:
            self.code = generate_random_code()
            # Make sure it's unique
            while ShortUrl.objects.filter(code=self.code).exists():
                self.code = generate_random_code()
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        """Get the absolute URL for this shortcut."""
        return reverse('url84t_shortener:redirect', kwargs={'code': self.code})
    
    def increase_hits(self):
        """Increment the hit counter for this URL."""
        self.hits += 1
        self.save(update_fields=['hits'])