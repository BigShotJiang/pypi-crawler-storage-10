default_app_config = 'url84t_shortener.apps.Url84tShortenerConfig'

__version__ = '0.2.0'