def main() -> None:
    print("Hello from dlai-kit!")
