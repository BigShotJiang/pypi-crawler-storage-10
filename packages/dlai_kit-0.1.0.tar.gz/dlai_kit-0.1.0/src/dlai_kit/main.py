import importlib.resources as pkg_resources
import os
import tomllib
from pathlib import Path

import nbformat
import typer
from dlai_grader.io import generate_learner_file, generate_learner_version

app = typer.Typer()


@app.command()
def init():
    """Initialize a new project by creating a kit.toml file in the current directory."""
    # Get the current directory
    current_dir = Path.cwd()

    # Define the destination path for kit.toml
    dest_path = current_dir / "kit.toml"

    # Check if kit.toml already exists
    if dest_path.exists():
        overwrite = typer.confirm(
            "kit.toml already exists. Do you want to overwrite it?",
        )
        if not overwrite:
            typer.echo("Initialization canceled.")
            return

    with (
        pkg_resources.files("dlai_kit.templates")
        .joinpath("kit.toml")
        .open("rb") as src_file
    ):
        dest_path.write_bytes(src_file.read())

    typer.echo(f"Successfully created kit.toml in {current_dir}")


def main():
    app()


if __name__ == "__main__":
    main()


def clear_notebook_outputs(notebook_path: Path, output_path: Path):
    notebook = nbformat.read(notebook_path.open("r", encoding="utf-8"), as_version=4)

    for cell in notebook.cells:
        if cell.cell_type == "code":
            cell.outputs = []
            cell.execution_count = None

    with output_path.open("w", encoding="utf-8") as f:
        nbformat.write(notebook, f)

    print(f"Cleared outputs from {notebook_path} and saved to {output_path}")


@app.command()
def learner(source: str, destination: str):
    generate_learner_file(source, destination)


@app.command()
def pairs(toml_config_path: str = "./kit.toml"):
    toml_config = Path(toml_config_path)

    with toml_config.open("rb") as f:
        data = tomllib.load(f)

    pairs = data["pairs"]
    for pair in pairs:
        source = Path(pair["source"])
        destination = Path(pair["destination"])
        destination.parent.mkdir(parents=True, exist_ok=True)

        match source.suffix:
            case ".ipynb":
                generate_learner_version(source, destination)
                clear_notebook_outputs(source, destination)
            case _:
                generate_learner_file(source, destination)


@app.command()
def recursive(
    toml_config_path: str = "./kit.toml",
):
    """Recursively process files based on configuration in the TOML file."""
    toml_config = Path(toml_config_path)

    if not toml_config.exists():
        typer.echo(
            f"Error: TOML configuration file '{toml_config_path}' does not exist.",
        )
        raise typer.Exit(code=1)

    with toml_config.open("rb") as f:
        data = tomllib.load(f)

    # Process recursive configuration if defined
    if "recursive" in data:
        recursive_config = data["recursive"]
        source_dir = Path(recursive_config.get("source_dir", "."))
        destination_dir = Path(recursive_config.get("destination_dir", "learner_files"))
        suffixes = recursive_config.get(
            "suffixes",
            [".ipynb", ".yaml", ".py", ".md", ".txt"],
        )
        exclude_dirs = recursive_config.get(
            "exclude_dirs",
            [".venv", "__pycache__", ".git", ".pytest_cache", ".mypy_cache"],
        )

        if not source_dir.exists() or not source_dir.is_dir():
            typer.echo(
                f"Error: Source directory '{source_dir}' does not exist or is not a directory."
            )
            raise typer.Exit(code=1)

        # Create destination directory if it doesn't exist
        destination_dir.mkdir(parents=True, exist_ok=True)

        # Count for reporting
        processed_files = 0

        # Walk through the directory tree
        for root, dirs, files in os.walk(source_dir):
            # Remove excluded directories from dirs to prevent walking into them
            dirs[:] = [d for d in dirs if d not in exclude_dirs]

            # Process each file with matching suffix
            for file in files:
                file_path = Path(root) / file
                if any(file_path.suffix == suffix for suffix in suffixes):
                    # Calculate relative path from source to maintain structure
                    rel_path = file_path.relative_to(source_dir)
                    dest_file_path = destination_dir / rel_path

                    # Ensure destination directory exists
                    dest_file_path.parent.mkdir(parents=True, exist_ok=True)

                    # Process the file based on its type
                    if file_path.suffix == ".ipynb":
                        generate_learner_version(file_path, dest_file_path)
                        clear_notebook_outputs(file_path, dest_file_path)
                    else:
                        generate_learner_file(file_path, dest_file_path)

                    processed_files += 1
                    typer.echo(f"Processed: {rel_path}")

        typer.echo(f"Completed! Recursively processed {processed_files} files.")


if __name__ == "__main__":
    app()
