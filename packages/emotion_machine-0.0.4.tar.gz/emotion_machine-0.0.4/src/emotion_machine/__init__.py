"""Emotion Machine Python SDK."""

from importlib import metadata

from .client import EmotionMachine, APIError

try:
    __version__ = metadata.version("emotion-machine")
except metadata.PackageNotFoundError:  # pragma: no cover - local dev fallback
    __version__ = "0.0.0"

__all__ = ["EmotionMachine", "APIError", "__version__"]
