# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ModuleSearchDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'module_name': 'str',
        'module_version': 'str'
    }

    attribute_map = {
        'module_name': 'module_name',
        'module_version': 'module_version'
    }

    def __init__(self, module_name=None, module_version=None):
        r"""ModuleSearchDTO

        The model defined in huaweicloud sdk

        :param module_name: 模块名称。
        :type module_name: str
        :param module_version: 模块版本号。
        :type module_version: str
        """
        
        

        self._module_name = None
        self._module_version = None
        self.discriminator = None

        self.module_name = module_name
        self.module_version = module_version

    @property
    def module_name(self):
        r"""Gets the module_name of this ModuleSearchDTO.

        模块名称。

        :return: The module_name of this ModuleSearchDTO.
        :rtype: str
        """
        return self._module_name

    @module_name.setter
    def module_name(self, module_name):
        r"""Sets the module_name of this ModuleSearchDTO.

        模块名称。

        :param module_name: The module_name of this ModuleSearchDTO.
        :type module_name: str
        """
        self._module_name = module_name

    @property
    def module_version(self):
        r"""Gets the module_version of this ModuleSearchDTO.

        模块版本号。

        :return: The module_version of this ModuleSearchDTO.
        :rtype: str
        """
        return self._module_version

    @module_version.setter
    def module_version(self, module_version):
        r"""Sets the module_version of this ModuleSearchDTO.

        模块版本号。

        :param module_version: The module_version of this ModuleSearchDTO.
        :type module_version: str
        """
        self._module_version = module_version

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ModuleSearchDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
