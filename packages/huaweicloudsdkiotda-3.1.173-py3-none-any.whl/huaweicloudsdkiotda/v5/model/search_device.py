# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SearchDevice:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'app_id': 'str',
        'app_name': 'str',
        'device_id': 'str',
        'node_id': 'str',
        'gateway_id': 'str',
        'device_name': 'str',
        'node_type': 'str',
        'fw_version': 'str',
        'sw_version': 'str',
        'device_sdk_version': 'str',
        'product_id': 'str',
        'product_name': 'str',
        'groups': 'object',
        'status': 'str',
        'tags': 'object',
        'modules': 'list[ModuleSearchDTO]',
        'marker': 'str'
    }

    attribute_map = {
        'app_id': 'app_id',
        'app_name': 'app_name',
        'device_id': 'device_id',
        'node_id': 'node_id',
        'gateway_id': 'gateway_id',
        'device_name': 'device_name',
        'node_type': 'node_type',
        'fw_version': 'fw_version',
        'sw_version': 'sw_version',
        'device_sdk_version': 'device_sdk_version',
        'product_id': 'product_id',
        'product_name': 'product_name',
        'groups': 'groups',
        'status': 'status',
        'tags': 'tags',
        'modules': 'modules',
        'marker': 'marker'
    }

    def __init__(self, app_id=None, app_name=None, device_id=None, node_id=None, gateway_id=None, device_name=None, node_type=None, fw_version=None, sw_version=None, device_sdk_version=None, product_id=None, product_name=None, groups=None, status=None, tags=None, modules=None, marker=None):
        r"""SearchDevice

        The model defined in huaweicloud sdk

        :param app_id: 资源空间ID。
        :type app_id: str
        :param app_name: 资源空间名称。
        :type app_name: str
        :param device_id: 设备ID，用于唯一标识一个设备。在注册设备时直接指定，或者由物联网平台分配获得。由物联网平台分配时，生成规则为\&quot;product_id\&quot; + \&quot;_\&quot; + \&quot;node_id\&quot;拼接而成。
        :type device_id: str
        :param node_id: 设备标识码，通常使用IMEI、MAC地址或Serial No作为node_id。
        :type node_id: str
        :param gateway_id: 网关ID，用于标识设备所属的父设备，即父设备的设备ID。当设备是直连设备时，gateway_id与设备的device_id一致。当设备是非直连设备时，gateway_id为设备所关联的父设备的device_id。
        :type gateway_id: str
        :param device_name: 设备名称。
        :type device_name: str
        :param node_type: 设备节点类型。 - ENDPOINT：非直连设备。 - GATEWAY：直连设备或网关。 - UNKNOWN：未知。
        :type node_type: str
        :param fw_version: 设备的固件版本。
        :type fw_version: str
        :param sw_version: 设备的软件版本。
        :type sw_version: str
        :param device_sdk_version: 设备的sdk信息。
        :type device_sdk_version: str
        :param product_id: 设备关联的产品ID，用于唯一标识一个产品模型。
        :type product_id: str
        :param product_name: 设备关联的产品名称。
        :type product_name: str
        :param groups: 设备组列表。
        :type groups: object
        :param status: 设备的状态。 - ONLINE：设备在线。 - OFFLINE：设备离线。 - ABNORMAL：设备异常。 - INACTIVE：设备未激活。 - FROZEN：设备冻结。
        :type status: str
        :param tags: 设备的标签列表。
        :type tags: object
        :param modules: 设备的OTA模块列表。
        :type modules: list[:class:`huaweicloudsdkiotda.v5.ModuleSearchDTO`]
        :param marker: 搜索结果记录Id。
        :type marker: str
        """
        
        

        self._app_id = None
        self._app_name = None
        self._device_id = None
        self._node_id = None
        self._gateway_id = None
        self._device_name = None
        self._node_type = None
        self._fw_version = None
        self._sw_version = None
        self._device_sdk_version = None
        self._product_id = None
        self._product_name = None
        self._groups = None
        self._status = None
        self._tags = None
        self._modules = None
        self._marker = None
        self.discriminator = None

        if app_id is not None:
            self.app_id = app_id
        if app_name is not None:
            self.app_name = app_name
        if device_id is not None:
            self.device_id = device_id
        if node_id is not None:
            self.node_id = node_id
        if gateway_id is not None:
            self.gateway_id = gateway_id
        if device_name is not None:
            self.device_name = device_name
        if node_type is not None:
            self.node_type = node_type
        if fw_version is not None:
            self.fw_version = fw_version
        if sw_version is not None:
            self.sw_version = sw_version
        if device_sdk_version is not None:
            self.device_sdk_version = device_sdk_version
        if product_id is not None:
            self.product_id = product_id
        if product_name is not None:
            self.product_name = product_name
        if groups is not None:
            self.groups = groups
        if status is not None:
            self.status = status
        if tags is not None:
            self.tags = tags
        if modules is not None:
            self.modules = modules
        if marker is not None:
            self.marker = marker

    @property
    def app_id(self):
        r"""Gets the app_id of this SearchDevice.

        资源空间ID。

        :return: The app_id of this SearchDevice.
        :rtype: str
        """
        return self._app_id

    @app_id.setter
    def app_id(self, app_id):
        r"""Sets the app_id of this SearchDevice.

        资源空间ID。

        :param app_id: The app_id of this SearchDevice.
        :type app_id: str
        """
        self._app_id = app_id

    @property
    def app_name(self):
        r"""Gets the app_name of this SearchDevice.

        资源空间名称。

        :return: The app_name of this SearchDevice.
        :rtype: str
        """
        return self._app_name

    @app_name.setter
    def app_name(self, app_name):
        r"""Sets the app_name of this SearchDevice.

        资源空间名称。

        :param app_name: The app_name of this SearchDevice.
        :type app_name: str
        """
        self._app_name = app_name

    @property
    def device_id(self):
        r"""Gets the device_id of this SearchDevice.

        设备ID，用于唯一标识一个设备。在注册设备时直接指定，或者由物联网平台分配获得。由物联网平台分配时，生成规则为\"product_id\" + \"_\" + \"node_id\"拼接而成。

        :return: The device_id of this SearchDevice.
        :rtype: str
        """
        return self._device_id

    @device_id.setter
    def device_id(self, device_id):
        r"""Sets the device_id of this SearchDevice.

        设备ID，用于唯一标识一个设备。在注册设备时直接指定，或者由物联网平台分配获得。由物联网平台分配时，生成规则为\"product_id\" + \"_\" + \"node_id\"拼接而成。

        :param device_id: The device_id of this SearchDevice.
        :type device_id: str
        """
        self._device_id = device_id

    @property
    def node_id(self):
        r"""Gets the node_id of this SearchDevice.

        设备标识码，通常使用IMEI、MAC地址或Serial No作为node_id。

        :return: The node_id of this SearchDevice.
        :rtype: str
        """
        return self._node_id

    @node_id.setter
    def node_id(self, node_id):
        r"""Sets the node_id of this SearchDevice.

        设备标识码，通常使用IMEI、MAC地址或Serial No作为node_id。

        :param node_id: The node_id of this SearchDevice.
        :type node_id: str
        """
        self._node_id = node_id

    @property
    def gateway_id(self):
        r"""Gets the gateway_id of this SearchDevice.

        网关ID，用于标识设备所属的父设备，即父设备的设备ID。当设备是直连设备时，gateway_id与设备的device_id一致。当设备是非直连设备时，gateway_id为设备所关联的父设备的device_id。

        :return: The gateway_id of this SearchDevice.
        :rtype: str
        """
        return self._gateway_id

    @gateway_id.setter
    def gateway_id(self, gateway_id):
        r"""Sets the gateway_id of this SearchDevice.

        网关ID，用于标识设备所属的父设备，即父设备的设备ID。当设备是直连设备时，gateway_id与设备的device_id一致。当设备是非直连设备时，gateway_id为设备所关联的父设备的device_id。

        :param gateway_id: The gateway_id of this SearchDevice.
        :type gateway_id: str
        """
        self._gateway_id = gateway_id

    @property
    def device_name(self):
        r"""Gets the device_name of this SearchDevice.

        设备名称。

        :return: The device_name of this SearchDevice.
        :rtype: str
        """
        return self._device_name

    @device_name.setter
    def device_name(self, device_name):
        r"""Sets the device_name of this SearchDevice.

        设备名称。

        :param device_name: The device_name of this SearchDevice.
        :type device_name: str
        """
        self._device_name = device_name

    @property
    def node_type(self):
        r"""Gets the node_type of this SearchDevice.

        设备节点类型。 - ENDPOINT：非直连设备。 - GATEWAY：直连设备或网关。 - UNKNOWN：未知。

        :return: The node_type of this SearchDevice.
        :rtype: str
        """
        return self._node_type

    @node_type.setter
    def node_type(self, node_type):
        r"""Sets the node_type of this SearchDevice.

        设备节点类型。 - ENDPOINT：非直连设备。 - GATEWAY：直连设备或网关。 - UNKNOWN：未知。

        :param node_type: The node_type of this SearchDevice.
        :type node_type: str
        """
        self._node_type = node_type

    @property
    def fw_version(self):
        r"""Gets the fw_version of this SearchDevice.

        设备的固件版本。

        :return: The fw_version of this SearchDevice.
        :rtype: str
        """
        return self._fw_version

    @fw_version.setter
    def fw_version(self, fw_version):
        r"""Sets the fw_version of this SearchDevice.

        设备的固件版本。

        :param fw_version: The fw_version of this SearchDevice.
        :type fw_version: str
        """
        self._fw_version = fw_version

    @property
    def sw_version(self):
        r"""Gets the sw_version of this SearchDevice.

        设备的软件版本。

        :return: The sw_version of this SearchDevice.
        :rtype: str
        """
        return self._sw_version

    @sw_version.setter
    def sw_version(self, sw_version):
        r"""Sets the sw_version of this SearchDevice.

        设备的软件版本。

        :param sw_version: The sw_version of this SearchDevice.
        :type sw_version: str
        """
        self._sw_version = sw_version

    @property
    def device_sdk_version(self):
        r"""Gets the device_sdk_version of this SearchDevice.

        设备的sdk信息。

        :return: The device_sdk_version of this SearchDevice.
        :rtype: str
        """
        return self._device_sdk_version

    @device_sdk_version.setter
    def device_sdk_version(self, device_sdk_version):
        r"""Sets the device_sdk_version of this SearchDevice.

        设备的sdk信息。

        :param device_sdk_version: The device_sdk_version of this SearchDevice.
        :type device_sdk_version: str
        """
        self._device_sdk_version = device_sdk_version

    @property
    def product_id(self):
        r"""Gets the product_id of this SearchDevice.

        设备关联的产品ID，用于唯一标识一个产品模型。

        :return: The product_id of this SearchDevice.
        :rtype: str
        """
        return self._product_id

    @product_id.setter
    def product_id(self, product_id):
        r"""Sets the product_id of this SearchDevice.

        设备关联的产品ID，用于唯一标识一个产品模型。

        :param product_id: The product_id of this SearchDevice.
        :type product_id: str
        """
        self._product_id = product_id

    @property
    def product_name(self):
        r"""Gets the product_name of this SearchDevice.

        设备关联的产品名称。

        :return: The product_name of this SearchDevice.
        :rtype: str
        """
        return self._product_name

    @product_name.setter
    def product_name(self, product_name):
        r"""Sets the product_name of this SearchDevice.

        设备关联的产品名称。

        :param product_name: The product_name of this SearchDevice.
        :type product_name: str
        """
        self._product_name = product_name

    @property
    def groups(self):
        r"""Gets the groups of this SearchDevice.

        设备组列表。

        :return: The groups of this SearchDevice.
        :rtype: object
        """
        return self._groups

    @groups.setter
    def groups(self, groups):
        r"""Sets the groups of this SearchDevice.

        设备组列表。

        :param groups: The groups of this SearchDevice.
        :type groups: object
        """
        self._groups = groups

    @property
    def status(self):
        r"""Gets the status of this SearchDevice.

        设备的状态。 - ONLINE：设备在线。 - OFFLINE：设备离线。 - ABNORMAL：设备异常。 - INACTIVE：设备未激活。 - FROZEN：设备冻结。

        :return: The status of this SearchDevice.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this SearchDevice.

        设备的状态。 - ONLINE：设备在线。 - OFFLINE：设备离线。 - ABNORMAL：设备异常。 - INACTIVE：设备未激活。 - FROZEN：设备冻结。

        :param status: The status of this SearchDevice.
        :type status: str
        """
        self._status = status

    @property
    def tags(self):
        r"""Gets the tags of this SearchDevice.

        设备的标签列表。

        :return: The tags of this SearchDevice.
        :rtype: object
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this SearchDevice.

        设备的标签列表。

        :param tags: The tags of this SearchDevice.
        :type tags: object
        """
        self._tags = tags

    @property
    def modules(self):
        r"""Gets the modules of this SearchDevice.

        设备的OTA模块列表。

        :return: The modules of this SearchDevice.
        :rtype: list[:class:`huaweicloudsdkiotda.v5.ModuleSearchDTO`]
        """
        return self._modules

    @modules.setter
    def modules(self, modules):
        r"""Sets the modules of this SearchDevice.

        设备的OTA模块列表。

        :param modules: The modules of this SearchDevice.
        :type modules: list[:class:`huaweicloudsdkiotda.v5.ModuleSearchDTO`]
        """
        self._modules = modules

    @property
    def marker(self):
        r"""Gets the marker of this SearchDevice.

        搜索结果记录Id。

        :return: The marker of this SearchDevice.
        :rtype: str
        """
        return self._marker

    @marker.setter
    def marker(self, marker):
        r"""Sets the marker of this SearchDevice.

        搜索结果记录Id。

        :param marker: The marker of this SearchDevice.
        :type marker: str
        """
        self._marker = marker

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SearchDevice):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
