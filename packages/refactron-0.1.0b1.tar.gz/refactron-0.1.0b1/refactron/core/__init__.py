"""Core functionality for Refactron."""

