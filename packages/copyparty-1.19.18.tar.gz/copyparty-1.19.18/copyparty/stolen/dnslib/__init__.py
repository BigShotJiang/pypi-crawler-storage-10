# coding: utf-8

"""
L: MIT
Copyright (c) 2010 - 2017 Paul Chakravarti
https://github.com/paulc/dnslib/tree/0.9.23
"""

from .dns import *

version = "0.9.23"
