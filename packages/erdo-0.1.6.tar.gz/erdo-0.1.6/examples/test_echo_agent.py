"""
Test file for the echo agent using the Erdo test framework
"""

from erdo.types import AgentTest, TestInput, TestExpectation

# Create test for the echo agent
echo_test = AgentTest(
    name="Echo Agent Basic Test",
    description="Tests that the echo agent properly echoes messages",
    agent_name="echo test agent",
    inputs=[
        TestInput(
            message="Hello, world!"
        )
    ],
    expectations=[
        # Test that the output contains the echoed message
        TestExpectation.text_contains(
            path="$.Outputs[0].Content",
            text="Hello, world!",
            description="Output should contain the input message"
        ),
        # Test that the output starts with "Echo: "
        TestExpectation.text_contains(
            path="$.Outputs[0].Content", 
            text="Echo:",
            description="Output should start with 'Echo:'"
        ),
        # Test that the invocation succeeds
        TestExpectation.is_success(
            path="$.Status",
            description="Agent should complete successfully"
        )
    ]
)

# Export tests
tests = [echo_test]