"""Test bot permissions functionality."""

import os
import sys
sys.path.insert(0, '.')

from erdo import BotPermissions, set_bot_public, get_bot_permissions, check_bot_access

def test_bot_permissions():
    """Test bot permission functionality."""
    print("Testing bot permissions...")
    
    # Test with a mock bot ID (in real usage, you'd get this from bot creation/listing)
    test_bot_id = "test-bot-123"
    
    # Initialize permissions manager
    permissions = BotPermissions(base_url="http://127.0.0.1:4000")
    
    print(f"Testing permissions for bot: {test_bot_id}")
    
    # Test setting public access
    print("1. Setting bot to public...")
    success = permissions.set_public_access(test_bot_id, is_public=True, permission_level="view")
    print(f"   Set public access: {'✓' if success else '✗'}")
    
    # Test getting permissions
    print("2. Getting bot permissions...")
    perms = permissions.get_permissions(test_bot_id)
    print(f"   Retrieved permissions: {'✓' if perms else '✗'}")
    if perms:
        print(f"   Permissions: {perms}")
    
    # Test checking access
    print("3. Checking access...")
    has_access = permissions.check_access(test_bot_id, "view")
    print(f"   Has view access: {'✓' if has_access else '✗'}")
    
    # Test convenience functions
    print("4. Testing convenience functions...")
    success = set_bot_public(test_bot_id, True, "edit")
    print(f"   set_bot_public: {'✓' if success else '✗'}")
    
    perms = get_bot_permissions(test_bot_id)
    print(f"   get_bot_permissions: {'✓' if perms else '✗'}")
    
    has_access = check_bot_access(test_bot_id, "view")
    print(f"   check_bot_access: {'✓' if has_access else '✗'}")

if __name__ == "__main__":
    test_bot_permissions()