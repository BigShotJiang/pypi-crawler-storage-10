# Erdo Python SDK Development

This is the Python SDK for Erdo, providing the API for defining AI agents, steps, and actions.

**📚 Critical Documentation:**
- **[../SDK_DEVELOPMENT.md](../SDK_DEVELOPMENT.md)** - **READ THIS FIRST** - Virtual environment gotchas, testing changes end-to-end, debugging data flow issues

## Quick Start

### After Making Changes

**CRITICAL**: After modifying the SDK, you MUST update all virtual environments that use it:

```bash
# Update the SDK's own venv
cd erdo-python-sdk
uv pip install -e .

# Update the agents venv (used by CLI)
cd ../erdo-agents
uv pip install -e ../erdo-python-sdk

# Verify the correct version is loaded
uv run python3 -c "import erdo; print(erdo.__file__)"
# Should show: /Users/niall/work/erdo/erdo-python-sdk/erdo/__init__.py
# NOT: erdo-agents/.venv/lib/python3.XX/site-packages/erdo/__init__.py
```

**Why this matters**: The CLI uses `uv run python3` which runs in the `erdo-agents/.venv` virtual environment. If you don't update the venv, the CLI will use the old published PyPI version of the SDK, not your local changes.

### Testing Your Changes

1. **Test Python SDK directly**:
```bash
cd erdo-python-sdk
uv run python3 -c "
from erdo import Agent
from erdo.actions import utils
agent = Agent(key='test.test', name='Test', description='Test')
step = agent.step(utils.echo(data='hello'))
print(step.to_dict())
"
```

2. **Test CLI integration**:
```bash
cd ../erdo-cli
./erdo test /path/to/test_agent.py
./erdo sync-agent /path/to/test_agent.py --dry-run
```

3. **Test backend integration**:
```bash
# Sync to a running backend and check logs
./erdo sync-agent /path/to/test_agent.py
```

## Project Structure

```
erdo-python-sdk/
├── erdo/
│   ├── __init__.py          # Main exports (Agent, Step, etc.)
│   ├── types.py             # Core types (Step, Agent, StepMetadata, etc.)
│   ├── actions/             # Action modules (utils, codeexec, llm, etc.)
│   └── _generated/          # Generated types (DO NOT EDIT MANUALLY)
│       └── types.py         # Run 'erdo gen-client' to regenerate
├── tests/                   # Unit tests
└── pyproject.toml          # Package configuration
```

## Key Files

### `erdo/types.py`
Contains the core SDK types:
- `Agent` - Top-level agent definition
- `Step` - Individual workflow step
- `StepMetadata` - Base class for step configuration
- `ResultHandler` - Result handler configuration
- Enums: `OutputVisibility`, `OutputContentType`, `ParameterHydrationBehaviour`

**Important**: When adding or modifying fields:
1. Update the Pydantic model definition
2. Update the `to_dict()` method if custom serialization is needed
3. Filter out None values for optional fields with defaults

### `erdo/_generated/types.py`
Auto-generated from the OpenAPI schema. **DO NOT EDIT MANUALLY**.

To regenerate:
```bash
cd ../erdo-cli
./erdo gen-client
```

## Important Concepts

### Using step_metadata in Result Handlers

When creating steps in result handlers via `.on()`, you can configure step properties using `step_metadata`:

```python
step.on(IsSuccess(),
    utils.parse_json(
        json_data="{{output}}",
        step_metadata=StepMetadata(
            key="parse_result",
            output_behavior={"data": OutputBehaviorType.MERGE}
        )
    )
)
```

**How it works**:
1. Action param classes (EchoParams, ParseJsonParams, etc.) have a `step_metadata` field
2. When passed to an action, the metadata is stored on the action object
3. `Step.on()` extracts the metadata and merges it into the Step configuration
4. The `_extract_step_config_from_action()` helper handles the extraction

**Important**: The `step_metadata` parameter is specifically for use in action calls. It allows you to configure step properties (key, output_behavior, execution_mode, visibility, etc.) when the step is created from an action.

### Field Naming: American vs British Spelling

The Python SDK uses American spelling (`output_behavior`) but the Go backend expects British spelling (`output_behaviour`). The `Step.to_dict()` method automatically handles this conversion during serialization:

```python
# In Step.to_dict():
if "output_behavior" in result:
    result["output_behaviour"] = result.pop("output_behavior")
```

This ensures agents sync correctly to the backend.

## Common Development Tasks

### Adding a New Field to Step

Example: Adding a new optional field `my_field`:

1. **Update `types.py`**:
```python
class StepMetadata(BaseModel):
    # ... existing fields ...
    my_field: Optional[str] = None
```

2. **Update `to_dict()` method** (if the field should be omitted when None):
```python
def to_dict(self) -> Dict[str, Any]:
    result = self.model_dump(exclude={'agent', 'result_handler', 'action', 'depends_on'})

    # Filter out None optional fields
    if result.get("my_field") is None:
        result.pop("my_field", None)

    return result
```

3. **Update the backend**:
   - Add to `erdo-common/types/bot.go` - `Step` struct
   - Add to `erdo/backend/bot/db/migrations/` - Database migration
   - Run `sqlc generate` in backend

4. **Test**:
```bash
# Update venvs
cd erdo-python-sdk && uv pip install -e .
cd ../erdo-agents && uv pip install -e ../erdo-python-sdk

# Test
cd ../erdo-cli
./erdo test /path/to/test_agent.py
```

### Changing Field Types

Example: Changing from `field: SomeEnum = SomeEnum.NONE` to `field: Optional[SomeEnum] = None`:

**See [../SDK_DEVELOPMENT.md](../SDK_DEVELOPMENT.md#type-changes-checklist)** for the complete checklist.

Key steps:
1. Change Python SDK type definition
2. Update `to_dict()` to filter None values
3. Update Go common types (value → pointer)
4. Update Go backend code handling the field
5. Update CLI export/sync code
6. Update all venvs
7. Test end-to-end

## Debugging

### Virtual Environment Issues

**Problem**: Changes not appearing when testing

```bash
# Check which SDK is loaded
uv run python3 -c "import erdo; print(erdo.__file__)"

# If it shows .venv/lib/python3.XX/site-packages/erdo
# Then reinstall in editable mode:
uv pip install -e /Users/niall/work/erdo/erdo-python-sdk
```

### Field Serialization Issues

**Problem**: Field showing wrong value in database

```python
# Debug the to_dict() output
from erdo import Agent
from erdo.actions import utils
agent = Agent(key='test.test', name='Test', description='Test')
step = agent.step(utils.echo(data='hello'))

# Check attribute
print(f"step.my_field: {step.my_field}")

# Check model_dump
dump = step.model_dump(exclude={'agent', 'action'})
print(f"model_dump: {dump.get('my_field')}")

# Check to_dict
step_dict = step.to_dict()
print(f"to_dict: {'my_field' in step_dict}")
```

## Testing

```bash
# Run unit tests
cd erdo-python-sdk
uv run pytest tests/

# Run specific test
uv run pytest tests/test_types.py::test_step_creation

# Test import
uv run python3 -c "from erdo import Agent; print('OK')"
```

## Related Documentation

- [../SDK_DEVELOPMENT.md](../SDK_DEVELOPMENT.md) - Comprehensive guide for SDK development
- [../erdo/CLAUDE.md](../erdo/CLAUDE.md) - Backend development guide
- [../erdo-cli/CLAUDE.md](../erdo-cli/CLAUDE.md) - CLI development guide
