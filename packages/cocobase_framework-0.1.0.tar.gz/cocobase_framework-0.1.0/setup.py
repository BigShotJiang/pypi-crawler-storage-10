from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cocobase_framework",
    version="0.1.0",
    author="Patrick Chidera",
    author_email="lordyacey@gmail.com",
    description="A self-hosted Backend as a Service framework with FastAPI and SQLModel",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/cocobase",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "fastapi>=0.104.0",
        "uvicorn[standard]>=0.24.0",
        "sqlmodel>=0.0.14",
        "pydantic>=2.0.0",
        "jinja2>=3.1.2",
        "python-multipart>=0.0.6",
        "passlib[bcrypt]>=1.7.4",
        "pyjwt>=2.8.0",
        "python-dotenv>=1.0.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "postgresql": ["psycopg2-binary>=2.9.0"],
        "mysql": ["pymysql>=1.1.0"],
        "async": ["asyncpg>=0.29.0", "aiomysql>=0.2.0"],
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "cocobase=cocobase.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "cocobase": [
            "templates/*.html",
            "static/*.css",
            "static/*.js",
        ],
    },
)
