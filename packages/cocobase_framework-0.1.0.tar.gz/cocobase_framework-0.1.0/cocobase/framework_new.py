"""
CocoBase Framework - Traditional Database Approach
Each collection = Real database table
Each document = Row in that table
Built-in User model with password hashing
"""

from fastapi import FastAPI, HTTPException, Request, Depends, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from sqlmodel import SQLModel, create_engine, Session, Field, Column, select, text
from sqlalchemy import (
    inspect,
    MetaData,
    Table,
    Column as SQLAColumn,
    Integer,
    String,
    Float,
    Boolean,
    DateTime,
    Text,
)
from sqlalchemy.types import TypeDecorator
from pydantic import BaseModel
from passlib.context import CryptContext
from typing import Optional, Dict, List, Any
from datetime import datetime
from pathlib import Path
import json
import os

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ============================================
# Built-in User Model
# ============================================


class User(SQLModel, table=True):
    """Built-in User model with password hashing"""

    __tablename__ = "users"

    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(unique=True, index=True)
    email: str = Field(unique=True, index=True)
    password_hash: str = Field(exclude=True)  # Never expose in API
    full_name: Optional[str] = None
    is_active: bool = Field(default=True)
    is_admin: bool = Field(default=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @staticmethod
    def hash_password(password: str) -> str:
        """Hash a password"""
        return pwd_context.hash(password)

    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """Verify password"""
        return pwd_context.verify(plain_password, hashed_password)


# ============================================
# Column Definitions
# ============================================


class ColumnDefinition(BaseModel):
    """Definition for a table column"""

    name: str
    type: str  # string, integer, float, boolean, datetime, text, json
    primary_key: bool = False
    auto_increment: bool = False
    required: bool = False
    unique: bool = False
    default: Optional[Any] = None


class CollectionDefinition(BaseModel):
    """Definition for creating a collection (table)"""

    name: str
    columns: List[ColumnDefinition]


# ============================================
# CocoBase Framework
# ============================================


class CocoBase:
    """
    CocoBase - Traditional Database Backend as a Service

    - Each collection = Real database table
    - Each document = Row in that table
    - Built-in User model with password hashing
    - Dynamic table/column creation
    """

    def __init__(
        self,
        database_url: str = "sqlite:///cocobase.db",
        dev_mode: bool = True,
        enable_dashboard: bool = True,
    ):
        """Initialize CocoBase"""
        self.database_url = database_url
        self.dev_mode = dev_mode
        self.enable_dashboard = enable_dashboard
        self.collections_file = "collections.json"

        # Initialize FastAPI
        self.app = FastAPI(
            title="CocoBase API",
            description="Traditional Database Backend as a Service",
            version="2.0.0",
        )

        # Setup CORS
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Get package directory
        self.package_dir = Path(__file__).parent
        self.static_dir = self.package_dir / "static"
        self.templates_dir = self.package_dir / "templates"

        # Setup templates and static files
        self.templates = Jinja2Templates(directory=str(self.templates_dir))
        if enable_dashboard and self.static_dir.exists():
            self.app.mount(
                "/static", StaticFiles(directory=str(self.static_dir)), name="static"
            )

        # Create database engine
        self.engine = create_engine(
            database_url,
            echo=False,
            connect_args=(
                {"check_same_thread": False} if "sqlite" in database_url else {}
            ),
        )

        # Load collections config
        self.collections = self._load_collections()

        # Create User table first
        SQLModel.metadata.create_all(self.engine, tables=[User.__table__])

        # Create dynamic tables for collections
        self._init_database()

        # Setup routes
        self._setup_routes()

        # Print startup
        self._print_startup_info()

    def _load_collections(self) -> Dict:
        """Load collections configuration from JSON file"""
        if os.path.exists(self.collections_file):
            with open(self.collections_file, "r") as f:
                return json.load(f)

        # Create users collection config if it doesn't exist
        return {
            "users": {
                "columns": [
                    {
                        "name": "id",
                        "type": "integer",
                        "primary_key": True,
                        "auto_increment": True,
                    },
                    {
                        "name": "username",
                        "type": "string",
                        "required": True,
                        "unique": True,
                    },
                    {
                        "name": "email",
                        "type": "string",
                        "required": True,
                        "unique": True,
                    },
                    {"name": "password_hash", "type": "string", "required": True},
                    {"name": "full_name", "type": "string"},
                    {"name": "is_active", "type": "boolean", "default": True},
                    {"name": "is_admin", "type": "boolean", "default": False},
                    {"name": "created_at", "type": "datetime"},
                    {"name": "updated_at", "type": "datetime"},
                ]
            }
        }

    def _save_collections(self):
        """Save collections configuration to JSON file"""
        with open(self.collections_file, "w") as f:
            json.dump(self.collections, f, indent=2)

    def _get_sqlalchemy_type(self, type_name: str):
        """Map type names to SQLAlchemy types"""
        type_mapping = {
            "string": lambda: String(255),
            "integer": lambda: Integer(),
            "float": lambda: Float(),
            "boolean": lambda: Boolean(),
            "datetime": lambda: DateTime(),
            "text": lambda: Text(),
            "json": lambda: Text(),
        }
        return type_mapping.get(type_name.lower(), lambda: String(255))()

    def _create_dynamic_table(self, name: str, columns: List[ColumnDefinition]):
        """Create a dynamic database table"""
        metadata = MetaData()

        cols = []
        for col in columns:
            col_type = self._get_sqlalchemy_type(col.type)

            cols.append(
                SQLAColumn(
                    col.name,
                    col_type,
                    primary_key=col.primary_key,
                    autoincrement=col.auto_increment,
                    nullable=not col.required,
                    unique=col.unique,
                    default=col.default,
                )
            )

        table = Table(name, metadata, *cols)
        metadata.create_all(self.engine)
        return table

    def _init_database(self):
        """Initialize database with existing collections"""
        for name, config in self.collections.items():
            if name == "users":
                continue  # Skip users, it's created by SQLModel
            columns = [ColumnDefinition(**col) for col in config["columns"]]
            self._create_dynamic_table(name, columns)

    def get_session(self):
        """Get database session"""
        with Session(self.engine) as session:
            yield session

    def _print_startup_info(self):
        """Print startup information"""
        print("\n" + "=" * 60)
        print("🚀 CocoBase v2.0 - Backend as a Service")
        print("=" * 60)
        print(f"📊 Dashboard: http://localhost:8000")
        print(f"📖 API Docs: http://localhost:8000/docs")
        print(f"🗄️  Database: {self.database_url}")
        print(f"👤 Built-in User Model: Ready")
        print(f"📋 Collections: {len(self.collections)}")
        print("=" * 60 + "\n")

    def _setup_routes(self):
        """Setup all API routes"""

        # ============================================
        # Dashboard
        # ============================================

        if self.enable_dashboard:

            @self.app.get("/", response_class=HTMLResponse)
            async def dashboard(request: Request):
                """Web dashboard"""
                return self.templates.TemplateResponse(
                    "dashboard.html", {"request": request}
                )

        # ============================================
        # Health Check
        # ============================================

        @self.app.get("/api/health")
        async def health_check():
            """Health check endpoint"""
            return {
                "status": "healthy",
                "version": "2.0.0",
                "database": self.database_url,
                "collections": len(self.collections),
            }

        # ============================================
        # Collections Management
        # ============================================

        @self.app.get("/collections")
        async def list_collections():
            """List all collections (tables)"""
            result = []
            for name, config in self.collections.items():
                result.append(
                    {
                        "id": name,
                        "name": name,
                        "columns": config["columns"],
                        "row_count": self._get_row_count(name),
                    }
                )
            return result

        @self.app.post("/collections")
        async def create_collection(collection: CollectionDefinition):
            """
            Create a new collection (table)

            Example:
            ```json
            {
              "name": "posts",
              "columns": [
                {"name": "id", "type": "integer", "primary_key": true, "auto_increment": true},
                {"name": "title", "type": "string", "required": true},
                {"name": "content", "type": "text"},
                {"name": "author_id", "type": "integer"},
                {"name": "created_at", "type": "datetime"}
              ]
            }
            ```
            """
            if collection.name in self.collections:
                raise HTTPException(
                    status_code=400,
                    detail=f"Collection '{collection.name}' already exists",
                )

            # Ensure at least one primary key
            has_pk = any(col.primary_key for col in collection.columns)
            if not has_pk:
                collection.columns.insert(
                    0,
                    ColumnDefinition(
                        name="id", type="integer", primary_key=True, auto_increment=True
                    ),
                )

            # Create table
            self._create_dynamic_table(collection.name, collection.columns)

            # Save to config
            self.collections[collection.name] = {
                "columns": [col.model_dump() for col in collection.columns]
            }
            self._save_collections()

            return {
                "id": collection.name,
                "name": collection.name,
                "columns": [col.model_dump() for col in collection.columns],
                "message": "Collection created successfully",
            }

        @self.app.delete("/collections/{collection_name}")
        async def delete_collection(collection_name: str):
            """Delete a collection (drop table)"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            if collection_name == "users":
                raise HTTPException(
                    status_code=400, detail="Cannot delete built-in users collection"
                )

            # Drop table
            with self.engine.connect() as conn:
                conn.execute(text(f"DROP TABLE IF EXISTS {collection_name}"))
                conn.commit()

            # Remove from config
            del self.collections[collection_name]
            self._save_collections()

            return {"message": f"Collection '{collection_name}' deleted successfully"}

        @self.app.patch("/collections/{collection_name}/add-column")
        async def add_column(collection_name: str, column: ColumnDefinition):
            """Add a column to an existing collection"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            # Check if column already exists
            existing_cols = [
                col["name"] for col in self.collections[collection_name]["columns"]
            ]
            if column.name in existing_cols:
                raise HTTPException(
                    status_code=400, detail=f"Column '{column.name}' already exists"
                )

            # Add column to table
            col_type = self._get_sqlalchemy_type(column.type)
            with self.engine.connect() as conn:
                nullable = "NULL" if not column.required else "NOT NULL"
                default = (
                    f"DEFAULT {column.default}" if column.default is not None else ""
                )

                # SQLite doesn't support all ALTER TABLE operations
                if "sqlite" in self.database_url:
                    conn.execute(
                        text(
                            f"ALTER TABLE {collection_name} ADD COLUMN {column.name} {col_type.compile(self.engine.dialect)} {default}"
                        )
                    )
                else:
                    conn.execute(
                        text(
                            f"ALTER TABLE {collection_name} ADD COLUMN {column.name} {col_type.compile(self.engine.dialect)} {nullable} {default}"
                        )
                    )
                conn.commit()

            # Update config
            self.collections[collection_name]["columns"].append(column.model_dump())
            self._save_collections()

            return {
                "message": f"Column '{column.name}' added to collection '{collection_name}'"
            }

        # ============================================
        # Documents (Rows) Management
        # ============================================

        @self.app.get("/collections/{collection_name}/documents")
        async def list_documents(
            collection_name: str,
            limit: int = Query(50, ge=1, le=1000),
            offset: int = Query(0, ge=0),
            session: Session = Depends(self.get_session),
        ):
            """List all documents (rows) in a collection"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            # Get rows from table
            query = text(f"SELECT * FROM {collection_name} LIMIT :limit OFFSET :offset")
            result = session.exec(query, {"limit": limit, "offset": offset})

            documents = []
            for row in result:
                documents.append(dict(row._mapping))

            return {
                "documents": documents,
                "total": self._get_row_count(collection_name),
                "limit": limit,
                "offset": offset,
            }

        @self.app.post("/collections/{collection_name}/documents")
        async def create_document(
            collection_name: str,
            data: Dict[str, Any],
            session: Session = Depends(self.get_session),
        ):
            """Create a new document (row)"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            # Handle password hashing for users table
            if collection_name == "users" and "password" in data:
                data["password_hash"] = User.hash_password(data.pop("password"))
                if "created_at" not in data:
                    data["created_at"] = datetime.utcnow()
                if "updated_at" not in data:
                    data["updated_at"] = datetime.utcnow()

            # Build INSERT query
            columns = ", ".join(data.keys())
            placeholders = ", ".join(f":{key}" for key in data.keys())
            query = text(
                f"INSERT INTO {collection_name} ({columns}) VALUES ({placeholders})"
            )

            session.exec(query, data)
            session.commit()

            return {"message": "Document created successfully", "data": data}

        @self.app.get("/collections/{collection_name}/documents/{doc_id}")
        async def get_document(
            collection_name: str,
            doc_id: int,
            session: Session = Depends(self.get_session),
        ):
            """Get a single document by ID"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            # Get primary key column
            pk_col = self._get_primary_key(collection_name)

            query = text(f"SELECT * FROM {collection_name} WHERE {pk_col} = :id")
            result = session.exec(query, {"id": doc_id}).first()

            if not result:
                raise HTTPException(status_code=404, detail="Document not found")

            return dict(result._mapping)

        @self.app.patch("/collections/{collection_name}/documents/{doc_id}")
        async def update_document(
            collection_name: str,
            doc_id: int,
            data: Dict[str, Any],
            session: Session = Depends(self.get_session),
        ):
            """Update a document"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            # Handle password hashing for users table
            if collection_name == "users":
                if "password" in data:
                    data["password_hash"] = User.hash_password(data.pop("password"))
                data["updated_at"] = datetime.utcnow()

            # Get primary key
            pk_col = self._get_primary_key(collection_name)

            # Build UPDATE query
            set_clause = ", ".join(f"{key} = :{key}" for key in data.keys())
            query = text(
                f"UPDATE {collection_name} SET {set_clause} WHERE {pk_col} = :id"
            )

            data["id"] = doc_id
            session.exec(query, data)
            session.commit()

            return {"message": "Document updated successfully"}

        @self.app.delete("/collections/{collection_name}/documents/{doc_id}")
        async def delete_document(
            collection_name: str,
            doc_id: int,
            session: Session = Depends(self.get_session),
        ):
            """Delete a document"""
            if collection_name not in self.collections:
                raise HTTPException(status_code=404, detail="Collection not found")

            pk_col = self._get_primary_key(collection_name)
            query = text(f"DELETE FROM {collection_name} WHERE {pk_col} = :id")

            session.exec(query, {"id": doc_id})
            session.commit()

            return {"message": "Document deleted successfully"}

    def _get_row_count(self, collection_name: str) -> int:
        """Get row count for a collection"""
        try:
            with Session(self.engine) as session:
                result = session.exec(
                    text(f"SELECT COUNT(*) FROM {collection_name}")
                ).first()
                return result[0] if result else 0
        except:
            return 0

    def _get_primary_key(self, collection_name: str) -> str:
        """Get primary key column name"""
        for col in self.collections[collection_name]["columns"]:
            if col.get("primary_key"):
                return col["name"]
        return "id"

    def run(self, host: str = "0.0.0.0", port: int = 8000, reload: bool = False):
        """Run the CocoBase server"""
        import uvicorn

        if reload:
            print("\n⚠️  For reload mode, run:")
            print(f"   uvicorn app:app --reload --host {host} --port {port}\n")
            reload = False

        uvicorn.run(self.app, host=host, port=port, reload=reload)
