"""
Database models and Pydantic schemas for CocoBase
"""

from sqlmodel import SQLModel, Field, Relationship, Column
from sqlalchemy import JSON
from pydantic import BaseModel, ConfigDict
from typing import Optional, Dict, Any, List
from datetime import datetime
import uuid


# ============================================
# SQLModel Database Models
# ============================================


class Collection(SQLModel, table=True):
    """Collection (table) definition"""

    __tablename__ = "collections"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    name: str = Field(unique=True, index=True)
    schema_: Optional[Dict[str, Any]] = Field(
        default=None, sa_column=Column("schema", JSON)
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    documents: List["Document"] = Relationship(back_populates="collection")


class Document(SQLModel, table=True):
    """Document (record) in a collection"""

    __tablename__ = "documents"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    collection_id: str = Field(foreign_key="collections.id", index=True)
    data: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    collection: Optional[Collection] = Relationship(back_populates="documents")


# ============================================
# Pydantic Schemas for API
# ============================================


class CollectionCreateSchema(BaseModel):
    """Schema for creating a collection"""

    model_config = ConfigDict(extra="allow")

    name: str
    schema_def: Optional[Dict[str, Any]] = None


class CollectionUpdateSchema(BaseModel):
    """Schema for updating a collection"""

    model_config = ConfigDict(extra="allow")

    name: Optional[str] = None
    schema_def: Optional[Dict[str, Any]] = None


class CollectionSchema(BaseModel):
    """Schema for collection response"""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: str
    name: str
    schema_: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime


class DocumentCreateSchema(BaseModel):
    """Schema for creating a document"""

    model_config = ConfigDict(extra="allow")

    data: Dict[str, Any]


class DocumentUpdateSchema(BaseModel):
    """Schema for updating a document"""

    model_config = ConfigDict(extra="allow")

    data: Dict[str, Any]


class DocumentSchema(BaseModel):
    """Schema for document response"""

    model_config = ConfigDict(from_attributes=True)

    id: str
    collection_id: str
    data: Dict[str, Any]
    created_at: datetime
    updated_at: datetime


class BatchCreateRequest(BaseModel):
    """Schema for batch create request"""

    documents: List[Dict[str, Any]]


class BatchUpdateRequest(BaseModel):
    """Schema for batch update request"""

    updates: List[Dict[str, Any]]  # Each dict should have 'id' and 'data' keys


class BatchDeleteRequest(BaseModel):
    """Schema for batch delete request"""

    document_ids: List[str]


class HTTPValidationError(BaseModel):
    """Validation error response"""

    detail: List[Dict[str, Any]]


# ============================================
# Helper Functions
# ============================================


def collection_to_schema(collection: Collection) -> CollectionSchema:
    """Convert Collection model to schema"""
    return CollectionSchema(
        id=collection.id,
        name=collection.name,
        schema_=collection.schema_,
        created_at=collection.created_at,
        updated_at=collection.updated_at,
    )


def document_to_schema(document: Document) -> DocumentSchema:
    """Convert Document model to schema"""
    return DocumentSchema(
        id=document.id,
        collection_id=document.collection_id,
        data=document.data,
        created_at=document.created_at,
        updated_at=document.updated_at,
    )
