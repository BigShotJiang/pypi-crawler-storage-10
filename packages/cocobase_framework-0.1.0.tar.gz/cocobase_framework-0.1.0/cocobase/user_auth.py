"""
User authentication utilities for CocoBase
Provides ready-to-use user model with automatic password hashing
"""

from passlib.context import CryptContext
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import secrets

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class UserAuth:
    """User authentication helper with password hashing"""

    @staticmethod
    def hash_password(password: str) -> str:
        """
        Hash a password using bcrypt

        Args:
            password: Plain text password

        Returns:
            Hashed password string
        """
        return pwd_context.hash(password)

    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """
        Verify a password against a hash

        Args:
            plain_password: Plain text password to verify
            hashed_password: Hashed password from database

        Returns:
            True if password matches, False otherwise
        """
        return pwd_context.verify(plain_password, hashed_password)

    @staticmethod
    def create_user_document(
        email: str,
        password: str,
        name: Optional[str] = None,
        username: Optional[str] = None,
        **extra_fields,
    ) -> Dict[str, Any]:
        """
        Create a user document with hashed password

        Args:
            email: User email (required)
            password: Plain text password (will be hashed)
            name: User's full name (optional)
            username: Username (optional)
            **extra_fields: Additional fields to include

        Returns:
            Dictionary ready to be inserted into users collection

        Example:
            ```python
            user_data = UserAuth.create_user_document(
                email="john@example.com",
                password="mysecret123",
                name="John Doe",
                username="johndoe",
                role="user",
                phone="+1234567890"
            )
            ```
        """
        user_doc = {
            "email": email.lower(),  # Normalize email
            "password": pwd_context.hash(password),  # Hash password
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "is_active": True,
            "is_verified": False,
        }

        if name:
            user_doc["name"] = name
        if username:
            user_doc["username"] = username.lower()

        # Add any extra fields
        user_doc.update(extra_fields)

        return user_doc

    @staticmethod
    def update_password(
        user_document: Dict[str, Any], new_password: str
    ) -> Dict[str, Any]:
        """
        Update password in user document

        Args:
            user_document: Existing user document
            new_password: New plain text password

        Returns:
            Updated user document with new hashed password
        """
        user_document["password"] = pwd_context.hash(new_password)
        user_document["updated_at"] = datetime.utcnow().isoformat()
        return user_document

    @staticmethod
    def authenticate_user(user_document: Dict[str, Any], password: str) -> bool:
        """
        Authenticate a user by verifying password

        Args:
            user_document: User document from database
            password: Plain text password to verify

        Returns:
            True if authentication successful, False otherwise
        """
        if not user_document or "password" not in user_document:
            return False

        return pwd_context.verify(password, user_document["password"])

    @staticmethod
    def generate_verification_token() -> str:
        """Generate a secure verification token"""
        return secrets.token_urlsafe(32)

    @staticmethod
    def generate_reset_token() -> str:
        """Generate a secure password reset token"""
        return secrets.token_urlsafe(32)


# Convenience functions for direct use
def hash_password(password: str) -> str:
    """Hash a password - convenience function"""
    return UserAuth.hash_password(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password - convenience function"""
    return UserAuth.verify_password(plain_password, hashed_password)


def create_user(email: str, password: str, **kwargs) -> Dict[str, Any]:
    """Create a user document - convenience function"""
    return UserAuth.create_user_document(email, password, **kwargs)
