"""
CocoBase Events System
Allows users to register callbacks for various lifecycle events
"""

from typing import Callable, Dict, List, Any, Optional
from enum import Enum
import asyncio
import inspect


class EventType(str, Enum):
    """Available event types"""

    # Application lifecycle
    APP_START = "app_start"
    APP_SHUTDOWN = "app_shutdown"

    # Collection events
    COLLECTION_CREATED = "collection_created"
    COLLECTION_DELETED = "collection_deleted"
    COLLECTION_UPDATED = "collection_updated"

    # Document events
    BEFORE_CREATE = "before_create"
    AFTER_CREATE = "after_create"
    BEFORE_UPDATE = "before_update"
    AFTER_UPDATE = "after_update"
    BEFORE_DELETE = "before_delete"
    AFTER_DELETE = "after_delete"

    # Query events
    BEFORE_QUERY = "before_query"
    AFTER_QUERY = "after_query"

    # File events
    FILE_UPLOADED = "file_uploaded"
    FILE_DELETED = "file_deleted"

    # Custom events
    CUSTOM = "custom"


class EventContext:
    """Context passed to event handlers"""

    def __init__(
        self,
        event_type: EventType,
        collection: Optional[str] = None,
        document_id: Optional[Any] = None,
        data: Optional[Dict[str, Any]] = None,
        old_data: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.event_type = event_type
        self.collection = collection
        self.document_id = document_id
        self.data = data or {}
        self.old_data = old_data or {}
        self.metadata = metadata or {}
        self.cancelled = (
            False  # Can be set to True in "before" events to cancel operation
        )

    def cancel(self):
        """Cancel the operation (only works for 'before' events)"""
        self.cancelled = True

    def to_dict(self):
        """Convert to dictionary"""
        return {
            "event_type": self.event_type,
            "collection": self.collection,
            "document_id": self.document_id,
            "data": self.data,
            "old_data": self.old_data,
            "metadata": self.metadata,
        }


class EventManager:
    """Manages event registration and dispatching"""

    def __init__(self):
        self._handlers: Dict[EventType, List[Callable]] = {}
        self._collection_handlers: Dict[str, Dict[EventType, List[Callable]]] = {}

    def on(self, event_type: EventType, collection: Optional[str] = None):
        """
        Decorator to register an event handler

        Usage:
        ```python
        @events.on(EventType.AFTER_CREATE, collection="users")
        async def on_user_created(ctx: EventContext):
            print(f"New user created: {ctx.data}")
        ```
        """

        def decorator(func: Callable):
            self.register(event_type, func, collection)
            return func

        return decorator

    def register(
        self,
        event_type: EventType,
        handler: Callable,
        collection: Optional[str] = None,
    ):
        """Register an event handler"""
        if collection:
            # Collection-specific handler
            if collection not in self._collection_handlers:
                self._collection_handlers[collection] = {}
            if event_type not in self._collection_handlers[collection]:
                self._collection_handlers[collection][event_type] = []
            self._collection_handlers[collection][event_type].append(handler)
        else:
            # Global handler
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append(handler)

    def remove(
        self,
        event_type: EventType,
        handler: Callable,
        collection: Optional[str] = None,
    ):
        """Remove an event handler"""
        if collection:
            if collection in self._collection_handlers:
                if event_type in self._collection_handlers[collection]:
                    self._collection_handlers[collection][event_type].remove(handler)
        else:
            if event_type in self._handlers:
                self._handlers[event_type].remove(handler)

    async def emit(self, ctx: EventContext) -> EventContext:
        """
        Emit an event and call all registered handlers
        Returns the modified context (handlers can modify data)
        """
        handlers = []

        # Get global handlers
        if ctx.event_type in self._handlers:
            handlers.extend(self._handlers[ctx.event_type])

        # Get collection-specific handlers
        if ctx.collection and ctx.collection in self._collection_handlers:
            if ctx.event_type in self._collection_handlers[ctx.collection]:
                handlers.extend(
                    self._collection_handlers[ctx.collection][ctx.event_type]
                )

        # Execute handlers
        for handler in handlers:
            try:
                if inspect.iscoroutinefunction(handler):
                    await handler(ctx)
                else:
                    handler(ctx)

                # If operation is cancelled, stop executing handlers
                if ctx.cancelled:
                    break
            except Exception as e:
                print(f"Error in event handler for {ctx.event_type}: {e}")
                import traceback

                traceback.print_exc()

        return ctx

    def get_handlers(
        self, event_type: EventType, collection: Optional[str] = None
    ) -> List[Callable]:
        """Get all handlers for an event type"""
        handlers = []

        if event_type in self._handlers:
            handlers.extend(self._handlers[event_type])

        if collection and collection in self._collection_handlers:
            if event_type in self._collection_handlers[collection]:
                handlers.extend(self._collection_handlers[collection][event_type])

        return handlers

    def clear(
        self, event_type: Optional[EventType] = None, collection: Optional[str] = None
    ):
        """Clear handlers"""
        if event_type is None:
            # Clear all
            self._handlers.clear()
            self._collection_handlers.clear()
        elif collection:
            # Clear collection-specific handlers
            if collection in self._collection_handlers:
                if event_type:
                    self._collection_handlers[collection].pop(event_type, None)
                else:
                    self._collection_handlers.pop(collection)
        else:
            # Clear global handlers
            if event_type:
                self._handlers.pop(event_type, None)
