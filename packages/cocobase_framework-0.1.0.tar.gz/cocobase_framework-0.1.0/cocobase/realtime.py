"""
CocoBase Real-time WebSocket Manager
Allows clients to watch collections in real-time with filtering support
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List, Set, Any, Optional
import json
import asyncio
from datetime import datetime


class CollectionSubscription:
    """Represents a subscription to a collection"""

    def __init__(
        self,
        collection: str,
        filters: Optional[Dict[str, Any]] = None,
        events: Optional[List[str]] = None,
    ):
        self.collection = collection
        self.filters = filters or {}
        self.events = events or ["create", "update", "delete"]  # Default to all events

    def matches_event(self, event_type: str) -> bool:
        """Check if this subscription should receive this event type"""
        return event_type in self.events

    def matches_data(self, data: Dict[str, Any]) -> bool:
        """Check if data matches the filters"""
        if not self.filters:
            return True

        for key, value in self.filters.items():
            # Handle special operators
            if key.endswith("_eq"):
                field = key[:-3]
                if data.get(field) != value:
                    return False
            elif key.endswith("_ne"):
                field = key[:-3]
                if data.get(field) == value:
                    return False
            elif key.endswith("_gt"):
                field = key[:-3]
                if not (data.get(field) is not None and data.get(field) > value):
                    return False
            elif key.endswith("_gte"):
                field = key[:-4]
                if not (data.get(field) is not None and data.get(field) >= value):
                    return False
            elif key.endswith("_lt"):
                field = key[:-3]
                if not (data.get(field) is not None and data.get(field) < value):
                    return False
            elif key.endswith("_lte"):
                field = key[:-4]
                if not (data.get(field) is not None and data.get(field) <= value):
                    return False
            elif key.endswith("_contains"):
                field = key[:-9]
                if not (data.get(field) is not None and value in str(data.get(field))):
                    return False
            elif key.endswith("_in"):
                field = key[:-3]
                if data.get(field) not in value:
                    return False
            else:
                # Direct equality
                if data.get(key) != value:
                    return False

        return True


class WebSocketManager:
    """Manages WebSocket connections for real-time updates"""

    def __init__(self):
        # Map of client_id -> (websocket, subscriptions)
        self.connections: Dict[str, tuple[WebSocket, List[CollectionSubscription]]] = {}
        # Map of collection -> set of client_ids
        self.collection_subscribers: Dict[str, Set[str]] = {}
        self.client_counter = 0

    async def connect(self, websocket: WebSocket) -> str:
        """Accept a new WebSocket connection"""
        await websocket.accept()

        # Generate unique client ID
        self.client_counter += 1
        client_id = f"client_{self.client_counter}_{datetime.utcnow().timestamp()}"

        self.connections[client_id] = (websocket, [])

        # Send connection confirmation
        await websocket.send_json(
            {
                "type": "connected",
                "client_id": client_id,
                "message": "Connected to CocoBase real-time server",
            }
        )

        return client_id

    def disconnect(self, client_id: str):
        """Remove a client connection"""
        if client_id in self.connections:
            _, subscriptions = self.connections[client_id]

            # Remove from collection subscribers
            for sub in subscriptions:
                if sub.collection in self.collection_subscribers:
                    self.collection_subscribers[sub.collection].discard(client_id)
                    if not self.collection_subscribers[sub.collection]:
                        del self.collection_subscribers[sub.collection]

            del self.connections[client_id]

    async def subscribe(
        self,
        client_id: str,
        collection: str,
        filters: Optional[Dict[str, Any]] = None,
        events: Optional[List[str]] = None,
    ):
        """Subscribe a client to a collection"""
        if client_id not in self.connections:
            return

        websocket, subscriptions = self.connections[client_id]

        # Create subscription
        subscription = CollectionSubscription(collection, filters, events)
        subscriptions.append(subscription)

        # Add to collection subscribers map
        if collection not in self.collection_subscribers:
            self.collection_subscribers[collection] = set()
        self.collection_subscribers[collection].add(client_id)

        # Send confirmation
        await websocket.send_json(
            {
                "type": "subscribed",
                "collection": collection,
                "filters": filters,
                "events": events,
            }
        )

    async def unsubscribe(self, client_id: str, collection: str):
        """Unsubscribe a client from a collection"""
        if client_id not in self.connections:
            return

        websocket, subscriptions = self.connections[client_id]

        # Remove subscriptions for this collection
        subscriptions[:] = [s for s in subscriptions if s.collection != collection]

        # Remove from collection subscribers
        if collection in self.collection_subscribers:
            self.collection_subscribers[collection].discard(client_id)
            if not self.collection_subscribers[collection]:
                del self.collection_subscribers[collection]

        await websocket.send_json(
            {
                "type": "unsubscribed",
                "collection": collection,
            }
        )

    async def broadcast_to_collection(
        self,
        collection: str,
        event_type: str,
        data: Dict[str, Any],
        document_id: Optional[Any] = None,
    ):
        """Broadcast an event to all subscribers of a collection"""
        if collection not in self.collection_subscribers:
            return

        # Get all clients subscribed to this collection
        client_ids = list(self.collection_subscribers[collection])

        # Send to each matching client
        for client_id in client_ids:
            if client_id not in self.connections:
                continue

            websocket, subscriptions = self.connections[client_id]

            # Check each subscription
            for sub in subscriptions:
                if sub.collection == collection:
                    # Check if subscription matches event type
                    if not sub.matches_event(event_type):
                        continue

                    # Check if data matches filters
                    if not sub.matches_data(data):
                        continue

                    # Send event
                    try:
                        await websocket.send_json(
                            {
                                "type": "event",
                                "event": event_type,
                                "collection": collection,
                                "document_id": document_id,
                                "data": data,
                                "timestamp": datetime.utcnow().isoformat(),
                            }
                        )
                    except Exception as e:
                        print(f"Error sending to client {client_id}: {e}")
                        # Connection might be dead, will be cleaned up later

    async def send_to_client(self, client_id: str, message: Dict[str, Any]):
        """Send a message to a specific client"""
        if client_id not in self.connections:
            return

        websocket, _ = self.connections[client_id]
        try:
            await websocket.send_json(message)
        except Exception as e:
            print(f"Error sending to client {client_id}: {e}")

    def get_subscriber_count(self, collection: Optional[str] = None) -> int:
        """Get number of subscribers (total or for a specific collection)"""
        if collection:
            return len(self.collection_subscribers.get(collection, set()))
        return len(self.connections)

    def get_subscriptions(self, client_id: str) -> List[Dict[str, Any]]:
        """Get all subscriptions for a client"""
        if client_id not in self.connections:
            return []

        _, subscriptions = self.connections[client_id]
        return [
            {
                "collection": sub.collection,
                "filters": sub.filters,
                "events": sub.events,
            }
            for sub in subscriptions
        ]
