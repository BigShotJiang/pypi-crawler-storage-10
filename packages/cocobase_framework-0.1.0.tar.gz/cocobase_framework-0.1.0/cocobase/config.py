"""
Configuration management for CocoBase
"""

import os
from typing import Optional
from pydantic import BaseModel, Field


class CocoBaseConfig(BaseModel):
    """Configuration model for CocoBase framework"""

    # Database settings
    database_url: str = Field(
        default="sqlite:///baas.db", description="Database connection URL"
    )

    # Server settings
    host: str = Field(default="0.0.0.0", description="Server host")
    port: int = Field(default=8000, description="Server port")
    reload: bool = Field(default=False, description="Enable live reload")

    # Framework settings
    collections_file: str = Field(
        default="collections.json", description="Path to collections metadata file"
    )
    custom_routes_dir: str = Field(
        default="custom_routes", description="Directory for custom route modules"
    )

    # Security settings
    enable_cors: bool = Field(default=True, description="Enable CORS")
    cors_origins: list = Field(default=["*"], description="Allowed CORS origins")

    # UI settings
    dashboard_title: str = Field(
        default="CocoBase Dashboard", description="Title for the web dashboard"
    )

    # Logging
    log_level: str = Field(default="INFO", description="Logging level")
    log_file: Optional[str] = Field(default=None, description="Log file path")

    class Config:
        env_prefix = ""
        case_sensitive = False


def load_config(env_file: str = ".env") -> CocoBaseConfig:
    """
    Load configuration from environment variables and .env file

    Args:
        env_file: Path to .env file

    Returns:
        CocoBaseConfig instance
    """
    # Load .env file if it exists
    if os.path.exists(env_file):
        from dotenv import load_dotenv

        load_dotenv(env_file)

    # Create config from environment variables
    config_dict = {
        "database_url": os.getenv("DATABASE_URL", "sqlite:///baas.db"),
        "host": os.getenv("HOST", "0.0.0.0"),
        "port": int(os.getenv("PORT", "8000")),
        "reload": os.getenv("RELOAD", "false").lower() in ("true", "1", "yes"),
        "collections_file": os.getenv("COLLECTIONS_FILE", "collections.json"),
        "custom_routes_dir": os.getenv("CUSTOM_ROUTES_DIR", "custom_routes"),
        "enable_cors": os.getenv("ENABLE_CORS", "true").lower() in ("true", "1", "yes"),
        "cors_origins": os.getenv("CORS_ORIGINS", "*").split(","),
        "dashboard_title": os.getenv("DASHBOARD_TITLE", "CocoBase Dashboard"),
        "log_level": os.getenv("LOG_LEVEL", "INFO"),
        "log_file": os.getenv("LOG_FILE"),
    }

    return CocoBaseConfig(**config_dict)
