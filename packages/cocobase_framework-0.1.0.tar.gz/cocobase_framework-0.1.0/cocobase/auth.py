"""
Authentication and authorization utilities for CocoBase
"""

from typing import Optional, Callable, List
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt
import os


# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# HTTP Bearer security
security = HTTPBearer()


def hash_password(password: str) -> str:
    """Hash a password using bcrypt"""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash"""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a JWT access token

    Args:
        data: Data to encode in the token
        expires_delta: Token expiration time

    Returns:
        Encoded JWT token
    """
    to_encode = data.copy()

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

    return encoded_jwt


def decode_access_token(token: str) -> dict:
    """
    Decode and validate a JWT token

    Args:
        token: JWT token to decode

    Returns:
        Decoded token data

    Raises:
        HTTPException: If token is invalid or expired
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> dict:
    """
    Dependency to get the current authenticated user from JWT token

    Args:
        credentials: HTTP Bearer credentials

    Returns:
        User data from token

    Raises:
        HTTPException: If authentication fails
    """
    token = credentials.credentials
    return decode_access_token(token)


def require_auth(func: Callable):
    """
    Decorator to require authentication for an endpoint

    Usage:
        @app.get("/protected")
        @require_auth
        async def protected_route(user: dict = Depends(get_current_user)):
            return {"user": user}
    """
    return func


def require_roles(allowed_roles: List[str]):
    """
    Decorator factory to require specific roles

    Args:
        allowed_roles: List of allowed role names

    Usage:
        @app.get("/admin")
        @require_roles(["admin"])
        async def admin_route(user: dict = Depends(get_current_user)):
            return {"message": "Admin only"}
    """

    def decorator(func: Callable):
        async def wrapper(*args, user: dict = Depends(get_current_user), **kwargs):
            user_role = user.get("role")

            if user_role not in allowed_roles:
                raise HTTPException(
                    status_code=403,
                    detail=f"Access denied. Required roles: {', '.join(allowed_roles)}",
                )

            return await func(*args, user=user, **kwargs)

        return wrapper

    return decorator


class RateLimiter:
    """Simple in-memory rate limiter"""

    def __init__(self, calls: int, period: int):
        """
        Initialize rate limiter

        Args:
            calls: Number of allowed calls
            period: Time period in seconds
        """
        self.calls = calls
        self.period = period
        self.requests = {}

    def is_allowed(self, key: str) -> bool:
        """
        Check if a request is allowed

        Args:
            key: Unique identifier (e.g., IP address, user ID)

        Returns:
            True if request is allowed, False otherwise
        """
        now = datetime.utcnow()

        if key not in self.requests:
            self.requests[key] = []

        # Remove old requests
        self.requests[key] = [
            req_time
            for req_time in self.requests[key]
            if (now - req_time).total_seconds() < self.period
        ]

        # Check if limit exceeded
        if len(self.requests[key]) >= self.calls:
            return False

        # Add new request
        self.requests[key].append(now)
        return True

    def __call__(self, key: str):
        """Make the rate limiter callable as a dependency"""
        if not self.is_allowed(key):
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded. Max {self.calls} requests per {self.period} seconds.",
            )


def create_api_key(user_id: str, permissions: List[str] = None) -> str:
    """
    Create an API key for programmatic access

    Args:
        user_id: User identifier
        permissions: List of permissions

    Returns:
        API key token
    """
    data = {"user_id": user_id, "permissions": permissions or [], "type": "api_key"}

    # API keys don't expire by default
    return create_access_token(data, expires_delta=timedelta(days=365))


def verify_api_key(api_key: str) -> dict:
    """
    Verify and decode an API key

    Args:
        api_key: API key to verify

    Returns:
        Decoded API key data
    """
    return decode_access_token(api_key)
