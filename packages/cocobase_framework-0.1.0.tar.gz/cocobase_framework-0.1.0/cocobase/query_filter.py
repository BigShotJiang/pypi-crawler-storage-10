"""
Advanced query filter parser for CocoBase
Supports complex filtering with operators and boolean logic
"""

from typing import Dict, Any, List, Tuple
from sqlalchemy import and_, or_, not_, func, cast, String
from sqlalchemy.sql import ColumnElement
from sqlmodel import col
import re


class QueryFilter:
    """
    Parse and build complex query filters

    Supports:
    - Basic operators: eq, ne, gt, gte, lt, lte
    - String operators: contains, startswith, endswith
    - List operators: in, notin
    - Null checks: isnull
    - OR grouping: [or] prefix or [or:group_name]
    - Multi-field OR: field1__or__field2_operator
    """

    # Operator mapping
    OPERATORS = {
        "eq": lambda col, val: col == val,
        "ne": lambda col, val: col != val,
        "gt": lambda col, val: col > val,
        "gte": lambda col, val: col >= val,
        "lt": lambda col, val: col < val,
        "lte": lambda col, val: col <= val,
        "contains": lambda col, val: cast(col, String).ilike(f"%{val}%"),
        "startswith": lambda col, val: cast(col, String).ilike(f"{val}%"),
        "endswith": lambda col, val: cast(col, String).ilike(f"%{val}"),
        "in": lambda col, val: col.in_(
            val if isinstance(val, list) else val.split(",")
        ),
        "notin": lambda col, val: col.notin_(
            val if isinstance(val, list) else val.split(",")
        ),
        "isnull": lambda col, val: (
            col.is_(None)
            if str(val).lower() in ("true", "1", "yes")
            else col.isnot(None)
        ),
    }

    def __init__(self, model_class):
        """
        Initialize query filter

        Args:
            model_class: SQLModel class to filter
        """
        self.model = model_class

    def parse_filters(self, query_params: Dict[str, Any]) -> List[ColumnElement]:
        """
        Parse query parameters into SQLAlchemy filters

        Args:
            query_params: Dictionary of query parameters

        Returns:
            List of SQLAlchemy filter conditions
        """
        and_conditions = []
        or_groups = {}

        for key, value in query_params.items():
            # Skip pagination and sorting params
            if key in ("limit", "offset", "sort", "order"):
                continue

            # Handle OR groups: [or]field or [or:group]field
            or_match = re.match(r"^\[or(?::(\w+))?\](.+)$", key)
            if or_match:
                group_name = or_match.group(1) or "default"
                field_spec = or_match.group(2)

                condition = self._parse_field(field_spec, value)
                if condition is not None:
                    if group_name not in or_groups:
                        or_groups[group_name] = []
                    or_groups[group_name].append(condition)
                continue

            # Handle multi-field OR: field1__or__field2_operator=value
            if "__or__" in key:
                fields = key.split("__or__")
                or_conditions = []

                for field_spec in fields:
                    condition = self._parse_field(field_spec, value)
                    if condition is not None:
                        or_conditions.append(condition)

                if or_conditions:
                    and_conditions.append(or_(*or_conditions))
                continue

            # Regular AND condition
            condition = self._parse_field(key, value)
            if condition is not None:
                and_conditions.append(condition)

        # Add OR groups to AND conditions
        for group_conditions in or_groups.values():
            if group_conditions:
                and_conditions.append(or_(*group_conditions))

        return and_conditions

    def _parse_field(self, field_spec: str, value: Any) -> ColumnElement:
        """
        Parse a single field specification

        Args:
            field_spec: Field name with optional operator (e.g., "age_gte")
            value: Filter value

        Returns:
            SQLAlchemy filter condition or None
        """
        # Split field and operator
        parts = field_spec.rsplit("_", 1)

        if len(parts) == 2 and parts[1] in self.OPERATORS:
            field_name, operator = parts
        else:
            field_name = field_spec
            operator = "eq"

        # Handle JSON field access for Document.data
        if hasattr(self.model, "data"):
            # For Document model, filter on data field
            column = self.model.data[field_name].astext
        else:
            # For regular models
            if not hasattr(self.model, field_name):
                # Field doesn't exist, skip it
                return None
            column = getattr(self.model, field_name)

        # Apply operator
        try:
            return self.OPERATORS[operator](column, value)
        except Exception:
            # If operator fails, skip this condition
            return None

    def build_query(self, base_query, query_params: Dict[str, Any]):
        """
        Build a complete query with filters

        Args:
            base_query: Base SQLModel select query
            query_params: Query parameters

        Returns:
            Filtered query
        """
        conditions = self.parse_filters(query_params)

        if conditions:
            base_query = base_query.where(and_(*conditions))

        # Handle sorting
        sort_field = query_params.get("sort")
        sort_order = query_params.get("order", "desc").lower()

        if sort_field:
            if hasattr(self.model, "data"):
                # For Document model, sort by data field
                sort_column = self.model.data[sort_field].astext
            else:
                if hasattr(self.model, sort_field):
                    sort_column = getattr(self.model, sort_field)
                else:
                    # Default sort by created_at
                    sort_column = (
                        self.model.created_at
                        if hasattr(self.model, "created_at")
                        else None
                    )

            if sort_column is not None:
                if sort_order == "asc":
                    base_query = base_query.order_by(sort_column.asc())
                else:
                    base_query = base_query.order_by(sort_column.desc())

        # Handle pagination
        offset = query_params.get("offset", 0)
        limit = query_params.get("limit", 100)

        if isinstance(offset, str):
            offset = int(offset)
        if isinstance(limit, str):
            limit = int(limit)

        # Limit max results
        limit = min(limit, 1000)

        base_query = base_query.offset(offset).limit(limit)

        return base_query


# Helper function for easy use
def apply_filters(query, model_class, filters: Dict[str, Any]):
    """
    Apply filters to a query

    Args:
        query: Base SQLModel query
        model_class: Model class
        filters: Filter parameters

    Returns:
        Filtered query
    """
    filter_builder = QueryFilter(model_class)
    return filter_builder.build_query(query, filters)
