"""
CocoBase Storage Service
Handles file uploads with support for local storage, Cloudinary, and B2 buckets
"""

import os
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import mimetypes
from abc import ABC, abstractmethod


class StorageProvider(ABC):
    """Abstract base class for storage providers"""

    @abstractmethod
    async def upload(
        self, file_content: bytes, filename: str, content_type: str
    ) -> Dict[str, Any]:
        """Upload a file and return metadata"""
        pass

    @abstractmethod
    async def delete(self, file_id: str) -> bool:
        """Delete a file"""
        pass

    @abstractmethod
    def get_url(self, file_id: str) -> str:
        """Get the URL to access a file"""
        pass


class LocalStorageProvider(StorageProvider):
    """Local file system storage provider"""

    def __init__(self, upload_dir: str = "uploads"):
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)

        # Create subdirectories for organization
        (self.upload_dir / "images").mkdir(exist_ok=True)
        (self.upload_dir / "documents").mkdir(exist_ok=True)
        (self.upload_dir / "videos").mkdir(exist_ok=True)
        (self.upload_dir / "audio").mkdir(exist_ok=True)
        (self.upload_dir / "other").mkdir(exist_ok=True)

    def _get_category(self, content_type: str) -> str:
        """Determine file category from content type"""
        if content_type.startswith("image/"):
            return "images"
        elif content_type.startswith("video/"):
            return "videos"
        elif content_type.startswith("audio/"):
            return "audio"
        elif content_type in [
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ]:
            return "documents"
        else:
            return "other"

    async def upload(
        self, file_content: bytes, filename: str, content_type: str
    ) -> Dict[str, Any]:
        """Upload a file to local storage"""
        # Generate unique file ID
        file_id = str(uuid.uuid4())

        # Get file extension
        _, ext = os.path.splitext(filename)
        if not ext:
            ext = mimetypes.guess_extension(content_type) or ""

        # Determine category and create path
        category = self._get_category(content_type)
        stored_filename = f"{file_id}{ext}"
        file_path = self.upload_dir / category / stored_filename

        # Write file
        with open(file_path, "wb") as f:
            f.write(file_content)

        # Return metadata
        return {
            "id": file_id,
            "filename": filename,
            "stored_filename": stored_filename,
            "content_type": content_type,
            "size": len(file_content),
            "category": category,
            "path": str(file_path.relative_to(self.upload_dir)),
            "url": f"/uploads/{category}/{stored_filename}",
            "uploaded_at": datetime.utcnow().isoformat(),
            "provider": "local",
        }

    async def delete(self, file_id: str) -> bool:
        """Delete a file from local storage"""
        # Search for file in all categories
        for category in ["images", "documents", "videos", "audio", "other"]:
            category_path = self.upload_dir / category
            for file_path in category_path.glob(f"{file_id}.*"):
                file_path.unlink()
                return True
        return False

    def get_url(self, file_id: str) -> str:
        """Get URL for a file"""
        # Search for file in all categories
        for category in ["images", "documents", "videos", "audio", "other"]:
            category_path = self.upload_dir / category
            for file_path in category_path.glob(f"{file_id}.*"):
                return f"/uploads/{category}/{file_path.name}"
        return ""


class CloudinaryProvider(StorageProvider):
    """Cloudinary storage provider (to be implemented)"""

    def __init__(self, cloud_name: str, api_key: str, api_secret: str):
        self.cloud_name = cloud_name
        self.api_key = api_key
        self.api_secret = api_secret
        # TODO: Initialize Cloudinary SDK

    async def upload(
        self, file_content: bytes, filename: str, content_type: str
    ) -> Dict[str, Any]:
        """Upload to Cloudinary"""
        # TODO: Implement Cloudinary upload
        raise NotImplementedError("Cloudinary provider coming soon!")

    async def delete(self, file_id: str) -> bool:
        """Delete from Cloudinary"""
        # TODO: Implement Cloudinary delete
        raise NotImplementedError("Cloudinary provider coming soon!")

    def get_url(self, file_id: str) -> str:
        """Get Cloudinary URL"""
        # TODO: Implement Cloudinary URL generation
        raise NotImplementedError("Cloudinary provider coming soon!")


class B2Provider(StorageProvider):
    """Backblaze B2 storage provider (to be implemented)"""

    def __init__(self, account_id: str, application_key: str, bucket_name: str):
        self.account_id = account_id
        self.application_key = application_key
        self.bucket_name = bucket_name
        # TODO: Initialize B2 SDK

    async def upload(
        self, file_content: bytes, filename: str, content_type: str
    ) -> Dict[str, Any]:
        """Upload to B2"""
        # TODO: Implement B2 upload
        raise NotImplementedError("B2 provider coming soon!")

    async def delete(self, file_id: str) -> bool:
        """Delete from B2"""
        # TODO: Implement B2 delete
        raise NotImplementedError("B2 provider coming soon!")

    def get_url(self, file_id: str) -> str:
        """Get B2 URL"""
        # TODO: Implement B2 URL generation
        raise NotImplementedError("B2 provider coming soon!")


class StorageService:
    """
    Main storage service that manages file uploads
    Supports multiple providers: local, Cloudinary, B2
    """

    def __init__(self, provider: Optional[StorageProvider] = None):
        if provider is None:
            provider = LocalStorageProvider()
        self.provider = provider

    async def upload_file(
        self, file_content: bytes, filename: str, content_type: str
    ) -> Dict[str, Any]:
        """Upload a single file"""
        return await self.provider.upload(file_content, filename, content_type)

    async def upload_files(self, files: List[tuple]) -> List[Dict[str, Any]]:
        """Upload multiple files"""
        results = []
        for file_content, filename, content_type in files:
            result = await self.provider.upload(file_content, filename, content_type)
            results.append(result)
        return results

    async def delete_file(self, file_id: str) -> bool:
        """Delete a file"""
        return await self.provider.delete(file_id)

    def get_file_url(self, file_id: str) -> str:
        """Get URL to access a file"""
        return self.provider.get_url(file_id)

    def configure_cloudinary(self, cloud_name: str, api_key: str, api_secret: str):
        """Switch to Cloudinary provider"""
        self.provider = CloudinaryProvider(cloud_name, api_key, api_secret)

    def configure_b2(self, account_id: str, application_key: str, bucket_name: str):
        """Switch to B2 provider"""
        self.provider = B2Provider(account_id, application_key, bucket_name)

    def configure_local(self, upload_dir: str = "uploads"):
        """Switch to local storage provider"""
        self.provider = LocalStorageProvider(upload_dir)
