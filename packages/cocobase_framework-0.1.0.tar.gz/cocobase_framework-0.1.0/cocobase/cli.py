"""
CocoBase CLI tool for managing projects
"""

import argparse
import os
import sys
import shutil
from pathlib import Path


def create_project(name: str):
    """Create a new CocoBase project"""
    project_dir = Path(name)

    if project_dir.exists():
        print(f"❌ Error: Directory '{name}' already exists!")
        sys.exit(1)

    print(f"🚀 Creating CocoBase project: {name}")

    # Create project structure
    project_dir.mkdir(parents=True)
    (project_dir / "custom_routes").mkdir()

    # Create app.py
    app_content = '''"""
{name} - CocoBase Application
"""

from cocobase import BaaSFramework
import sys

if __name__ == "__main__":
    # Initialize CocoBase
    framework = BaaSFramework()
    
    # Check for development mode flags
    reload = "--reload" in sys.argv or "--dev" in sys.argv
    
    # Run the server
    framework.run(host="0.0.0.0", port=8000, reload=reload)

# Export for uvicorn reload mode
framework = BaaSFramework()
'''.format(
        name=name
    )

    (project_dir / "app.py").write_text(app_content)

    # Create .env file
    env_content = """# CocoBase Configuration
DATABASE_URL=sqlite:///baas.db
HOST=0.0.0.0
PORT=8000
DEBUG=True
"""
    (project_dir / ".env").write_text(env_content)

    # Create .gitignore
    gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
ENV/
env/

# Database
*.db
*.sqlite
*.sqlite3
collections.json

# IDEs
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Logs
*.log
"""
    (project_dir / ".gitignore").write_text(gitignore_content)

    # Create README
    readme_content = f"""# {name}

A CocoBase backend application.

## Setup

1. Install dependencies:
   ```bash
   pip install cocobase
   ```

2. Run the application:
   ```bash
   # Development mode (with live reload)
   python app.py --dev
   
   # Production mode
   python app.py
   ```

3. Access the dashboard at http://localhost:8000

## Features

- 📊 Web Dashboard for managing collections
- 🔌 Automatic REST API generation
- 📖 Interactive API docs at /docs
- 🗄️ SQLite database (configurable)

## Custom Routes

Add your custom API routes in the `custom_routes/` directory.

Example (`custom_routes/my_routes.py`):
```python
def register_routes(app, engine, SessionClass):
    @app.get("/api/custom/hello")
    async def hello():
        return {{"message": "Hello from {name}!"}}
```
"""
    (project_dir / "README.md").write_text(readme_content)

    # Create custom routes __init__.py
    (project_dir / "custom_routes" / "__init__.py").write_text("")

    # Create example custom route
    example_route = '''"""
Example custom routes for your CocoBase application
"""

from fastapi import APIRouter, HTTPException
from sqlmodel import text

def register_routes(app, engine, SessionClass):
    """Register custom routes with the FastAPI app"""
    
    router = APIRouter(prefix="/api/custom", tags=["custom"])
    
    @router.get("/hello")
    async def hello():
        """Example custom endpoint"""
        return {"message": "Hello from custom routes!"}
    
    @router.get("/stats/{collection}")
    async def collection_stats(collection: str):
        """Get statistics for a collection"""
        with SessionClass(engine) as session:
            try:
                count_query = text(f"SELECT COUNT(*) as count FROM {collection}")
                result = session.execute(count_query).first()
                return {"collection": collection, "total_records": result[0]}
            except Exception as e:
                raise HTTPException(status_code=404, detail=str(e))
    
    # Register the router
    app.include_router(router)
'''
    (project_dir / "custom_routes" / "example.py").write_text(example_route)

    print(f"✅ Project '{name}' created successfully!")
    print(f"\n📂 Project structure:")
    print(f"   {name}/")
    print(f"   ├── app.py                 # Main application file")
    print(f"   ├── .env                   # Configuration")
    print(f"   ├── .gitignore            # Git ignore rules")
    print(f"   ├── README.md             # Project documentation")
    print(f"   └── custom_routes/        # Your custom API routes")
    print(f"       ├── __init__.py")
    print(f"       └── example.py")
    print(f"\n🚀 Next steps:")
    print(f"   cd {name}")
    print(f"   python app.py --dev")
    print(f"\n📊 Dashboard will be available at: http://localhost:8000")


def main():
    parser = argparse.ArgumentParser(
        description="CocoBase - Self-Hosted Backend as a Service Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Create command
    create_parser = subparsers.add_parser(
        "create", help="Create a new CocoBase project"
    )
    create_parser.add_argument("name", help="Project name")

    # Version command
    subparsers.add_parser("version", help="Show CocoBase version")

    args = parser.parse_args()

    if args.command == "create":
        create_project(args.name)
    elif args.command == "version":
        from cocobase import __version__

        print(f"CocoBase v{__version__}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
