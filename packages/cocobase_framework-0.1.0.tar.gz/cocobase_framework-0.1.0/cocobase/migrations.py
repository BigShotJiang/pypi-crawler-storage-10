"""
Database migration utilities for CocoBase
"""

import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
from sqlmodel import Session, text
from pathlib import Path


class Migration:
    """Represents a database migration"""

    def __init__(self, version: str, description: str, up_sql: str, down_sql: str):
        self.version = version
        self.description = description
        self.up_sql = up_sql
        self.down_sql = down_sql
        self.timestamp = datetime.now().isoformat()


class MigrationManager:
    """Manages database migrations for CocoBase"""

    def __init__(self, engine, migrations_dir: str = "migrations"):
        self.engine = engine
        self.migrations_dir = Path(migrations_dir)
        self.migrations_dir.mkdir(exist_ok=True)
        self._init_migrations_table()

    def _init_migrations_table(self):
        """Create migrations tracking table if it doesn't exist"""
        with Session(self.engine) as session:
            session.exec(
                text(
                    """
                CREATE TABLE IF NOT EXISTS _migrations (
                    version TEXT PRIMARY KEY,
                    description TEXT,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
                )
            )
            session.commit()

    def get_applied_migrations(self) -> List[str]:
        """Get list of applied migration versions"""
        with Session(self.engine) as session:
            result = session.exec(
                text("SELECT version FROM _migrations ORDER BY version")
            )
            return [row[0] for row in result]

    def create_migration(self, description: str) -> str:
        """
        Create a new migration file

        Args:
            description: Description of the migration

        Returns:
            Path to the created migration file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        version = f"{timestamp}_{description.lower().replace(' ', '_')}"

        migration_file = self.migrations_dir / f"{version}.json"

        migration_data = {
            "version": version,
            "description": description,
            "created_at": datetime.now().isoformat(),
            "up": [
                "-- Add your SQL statements here to apply the migration",
                "-- Example: ALTER TABLE users ADD COLUMN email TEXT",
            ],
            "down": [
                "-- Add your SQL statements here to revert the migration",
                "-- Example: ALTER TABLE users DROP COLUMN email",
            ],
        }

        with open(migration_file, "w") as f:
            json.dump(migration_data, f, indent=2)

        print(f"✅ Created migration: {migration_file}")
        return str(migration_file)

    def apply_migration(self, version: str):
        """
        Apply a specific migration

        Args:
            version: Migration version to apply
        """
        migration_file = self.migrations_dir / f"{version}.json"

        if not migration_file.exists():
            raise FileNotFoundError(f"Migration file not found: {migration_file}")

        with open(migration_file, "r") as f:
            migration_data = json.load(f)

        with Session(self.engine) as session:
            try:
                # Execute UP migrations
                for sql_statement in migration_data.get("up", []):
                    if sql_statement.strip() and not sql_statement.strip().startswith(
                        "--"
                    ):
                        session.exec(text(sql_statement))

                # Record migration
                session.exec(
                    text(
                        "INSERT INTO _migrations (version, description) VALUES (:version, :description)"
                    ),
                    {"version": version, "description": migration_data["description"]},
                )

                session.commit()
                print(f"✅ Applied migration: {version}")
            except Exception as e:
                session.rollback()
                print(f"❌ Failed to apply migration {version}: {e}")
                raise

    def revert_migration(self, version: str):
        """
        Revert a specific migration

        Args:
            version: Migration version to revert
        """
        migration_file = self.migrations_dir / f"{version}.json"

        if not migration_file.exists():
            raise FileNotFoundError(f"Migration file not found: {migration_file}")

        with open(migration_file, "r") as f:
            migration_data = json.load(f)

        with Session(self.engine) as session:
            try:
                # Execute DOWN migrations
                for sql_statement in migration_data.get("down", []):
                    if sql_statement.strip() and not sql_statement.strip().startswith(
                        "--"
                    ):
                        session.exec(text(sql_statement))

                # Remove migration record
                session.exec(
                    text("DELETE FROM _migrations WHERE version = :version"),
                    {"version": version},
                )

                session.commit()
                print(f"✅ Reverted migration: {version}")
            except Exception as e:
                session.rollback()
                print(f"❌ Failed to revert migration {version}: {e}")
                raise

    def migrate(self):
        """Apply all pending migrations"""
        applied = set(self.get_applied_migrations())

        # Get all migration files
        migration_files = sorted(self.migrations_dir.glob("*.json"))

        pending = []
        for migration_file in migration_files:
            version = migration_file.stem
            if version not in applied:
                pending.append(version)

        if not pending:
            print("✅ No pending migrations")
            return

        print(f"📋 Found {len(pending)} pending migrations")

        for version in pending:
            self.apply_migration(version)

        print("✅ All migrations applied successfully")

    def rollback(self, steps: int = 1):
        """
        Rollback the last N migrations

        Args:
            steps: Number of migrations to rollback
        """
        applied = self.get_applied_migrations()

        if not applied:
            print("❌ No migrations to rollback")
            return

        to_revert = applied[-steps:]

        print(f"📋 Rolling back {len(to_revert)} migrations")

        for version in reversed(to_revert):
            self.revert_migration(version)

        print("✅ Rollback completed successfully")


def backup_collection(engine, collection: str, backup_dir: str = "backups") -> str:
    """
    Backup a collection to JSON file

    Args:
        engine: Database engine
        collection: Collection name to backup
        backup_dir: Directory to store backups

    Returns:
        Path to backup file
    """
    backup_path = Path(backup_dir)
    backup_path.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = backup_path / f"{collection}_{timestamp}.json"

    with Session(engine) as session:
        result = session.exec(text(f"SELECT * FROM {collection}"))
        rows = result.fetchall()
        columns = result.keys()

        data = [dict(zip(columns, row)) for row in rows]

        with open(backup_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    print(f"✅ Backed up {len(data)} records from '{collection}' to {backup_file}")
    return str(backup_file)


def restore_collection(engine, collection: str, backup_file: str):
    """
    Restore a collection from JSON backup

    Args:
        engine: Database engine
        collection: Collection name to restore
        backup_file: Path to backup file
    """
    with open(backup_file, "r") as f:
        data = json.load(f)

    if not data:
        print(f"⚠️  Backup file is empty")
        return

    with Session(engine) as session:
        # Clear existing data
        session.exec(text(f"DELETE FROM {collection}"))

        # Insert backup data
        for record in data:
            columns = list(record.keys())
            placeholders = [f":{col}" for col in columns]

            insert_sql = f"""
                INSERT INTO {collection} ({', '.join([f'"{col}"' for col in columns])})
                VALUES ({', '.join(placeholders)})
            """

            session.exec(text(insert_sql), record)

        session.commit()

    print(f"✅ Restored {len(data)} records to '{collection}'")
