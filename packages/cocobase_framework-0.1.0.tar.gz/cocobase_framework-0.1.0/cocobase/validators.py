"""
Data validation utilities for CocoBase
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
import re


class ValidationError(Exception):
    """Custom validation error"""

    pass


class Validator:
    """Base validator class"""

    def __init__(self, required: bool = False, nullable: bool = False):
        self.required = required
        self.nullable = nullable

    def validate(self, value: Any, field_name: str = "field") -> Any:
        """
        Validate a value

        Args:
            value: Value to validate
            field_name: Name of the field being validated

        Returns:
            Validated value

        Raises:
            ValidationError: If validation fails
        """
        if value is None:
            if self.required and not self.nullable:
                raise ValidationError(f"{field_name} is required")
            return value

        return self._validate(value, field_name)

    def _validate(self, value: Any, field_name: str) -> Any:
        """Override in subclasses"""
        return value


class StringValidator(Validator):
    """Validate string fields"""

    def __init__(
        self,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.min_length = min_length
        self.max_length = max_length
        self.pattern = pattern

    def _validate(self, value: Any, field_name: str) -> str:
        if not isinstance(value, str):
            raise ValidationError(f"{field_name} must be a string")

        if self.min_length and len(value) < self.min_length:
            raise ValidationError(
                f"{field_name} must be at least {self.min_length} characters"
            )

        if self.max_length and len(value) > self.max_length:
            raise ValidationError(
                f"{field_name} must be at most {self.max_length} characters"
            )

        if self.pattern and not re.match(self.pattern, value):
            raise ValidationError(f"{field_name} does not match required pattern")

        return value


class IntValidator(Validator):
    """Validate integer fields"""

    def __init__(
        self, min_value: Optional[int] = None, max_value: Optional[int] = None, **kwargs
    ):
        super().__init__(**kwargs)
        self.min_value = min_value
        self.max_value = max_value

    def _validate(self, value: Any, field_name: str) -> int:
        try:
            value = int(value)
        except (TypeError, ValueError):
            raise ValidationError(f"{field_name} must be an integer")

        if self.min_value is not None and value < self.min_value:
            raise ValidationError(f"{field_name} must be at least {self.min_value}")

        if self.max_value is not None and value > self.max_value:
            raise ValidationError(f"{field_name} must be at most {self.max_value}")

        return value


class FloatValidator(Validator):
    """Validate float fields"""

    def __init__(
        self,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.min_value = min_value
        self.max_value = max_value

    def _validate(self, value: Any, field_name: str) -> float:
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValidationError(f"{field_name} must be a number")

        if self.min_value is not None and value < self.min_value:
            raise ValidationError(f"{field_name} must be at least {self.min_value}")

        if self.max_value is not None and value > self.max_value:
            raise ValidationError(f"{field_name} must be at most {self.max_value}")

        return value


class BoolValidator(Validator):
    """Validate boolean fields"""

    def _validate(self, value: Any, field_name: str) -> bool:
        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            value_lower = value.lower()
            if value_lower in ("true", "1", "yes", "on"):
                return True
            if value_lower in ("false", "0", "no", "off"):
                return False

        raise ValidationError(f"{field_name} must be a boolean")


class EmailValidator(StringValidator):
    """Validate email addresses"""

    EMAIL_PATTERN = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

    def __init__(self, **kwargs):
        super().__init__(pattern=self.EMAIL_PATTERN, **kwargs)

    def _validate(self, value: Any, field_name: str) -> str:
        value = super()._validate(value, field_name)

        if not re.match(self.EMAIL_PATTERN, value):
            raise ValidationError(f"{field_name} must be a valid email address")

        return value.lower()


class URLValidator(StringValidator):
    """Validate URLs"""

    URL_PATTERN = r"^https?://[^\s/$.?#].[^\s]*$"

    def __init__(self, **kwargs):
        super().__init__(pattern=self.URL_PATTERN, **kwargs)

    def _validate(self, value: Any, field_name: str) -> str:
        value = super()._validate(value, field_name)

        if not re.match(self.URL_PATTERN, value, re.IGNORECASE):
            raise ValidationError(f"{field_name} must be a valid URL")

        return value


class DateValidator(Validator):
    """Validate date strings"""

    def __init__(self, format: str = "%Y-%m-%d", **kwargs):
        super().__init__(**kwargs)
        self.format = format

    def _validate(self, value: Any, field_name: str) -> str:
        if isinstance(value, datetime):
            return value.strftime(self.format)

        if not isinstance(value, str):
            raise ValidationError(f"{field_name} must be a date string")

        try:
            datetime.strptime(value, self.format)
            return value
        except ValueError:
            raise ValidationError(
                f"{field_name} must be a valid date in format {self.format}"
            )


class EnumValidator(Validator):
    """Validate enum values"""

    def __init__(self, allowed_values: List[Any], **kwargs):
        super().__init__(**kwargs)
        self.allowed_values = allowed_values

    def _validate(self, value: Any, field_name: str) -> Any:
        if value not in self.allowed_values:
            raise ValidationError(
                f"{field_name} must be one of: {', '.join(map(str, self.allowed_values))}"
            )

        return value


class ListValidator(Validator):
    """Validate list fields"""

    def __init__(
        self,
        item_validator: Optional[Validator] = None,
        min_items: Optional[int] = None,
        max_items: Optional[int] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.item_validator = item_validator
        self.min_items = min_items
        self.max_items = max_items

    def _validate(self, value: Any, field_name: str) -> List:
        if not isinstance(value, list):
            raise ValidationError(f"{field_name} must be a list")

        if self.min_items is not None and len(value) < self.min_items:
            raise ValidationError(
                f"{field_name} must have at least {self.min_items} items"
            )

        if self.max_items is not None and len(value) > self.max_items:
            raise ValidationError(
                f"{field_name} must have at most {self.max_items} items"
            )

        if self.item_validator:
            validated_items = []
            for i, item in enumerate(value):
                try:
                    validated_items.append(
                        self.item_validator.validate(item, f"{field_name}[{i}]")
                    )
                except ValidationError as e:
                    raise ValidationError(f"{field_name}[{i}]: {str(e)}")
            return validated_items

        return value


class DictValidator(Validator):
    """Validate dictionary fields with schema"""

    def __init__(self, schema: Dict[str, Validator], **kwargs):
        super().__init__(**kwargs)
        self.schema = schema

    def _validate(self, value: Any, field_name: str) -> Dict:
        if not isinstance(value, dict):
            raise ValidationError(f"{field_name} must be an object")

        validated = {}

        for key, validator in self.schema.items():
            field_value = value.get(key)
            try:
                validated[key] = validator.validate(field_value, key)
            except ValidationError as e:
                raise ValidationError(f"{field_name}.{key}: {str(e)}")

        return validated


def validate_data(data: Dict[str, Any], schema: Dict[str, Validator]) -> Dict[str, Any]:
    """
    Validate data against a schema

    Args:
        data: Data to validate
        schema: Validation schema

    Returns:
        Validated data

    Raises:
        ValidationError: If validation fails
    """
    validated = {}
    errors = []

    for field_name, validator in schema.items():
        try:
            value = data.get(field_name)
            validated[field_name] = validator.validate(value, field_name)
        except ValidationError as e:
            errors.append(str(e))

    if errors:
        raise ValidationError("; ".join(errors))

    return validated


# Common validation schemas
USER_SCHEMA = {
    "email": EmailValidator(required=True),
    "username": StringValidator(required=True, min_length=3, max_length=50),
    "age": IntValidator(min_value=0, max_value=150, nullable=True),
}

POST_SCHEMA = {
    "title": StringValidator(required=True, min_length=1, max_length=200),
    "content": StringValidator(required=True, min_length=1),
    "published": BoolValidator(),
    "tags": ListValidator(item_validator=StringValidator(), max_items=10),
}
