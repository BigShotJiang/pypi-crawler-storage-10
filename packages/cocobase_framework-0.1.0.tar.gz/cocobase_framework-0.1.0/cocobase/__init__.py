"""
CocoBase - Self-Hosted Backend as a Service Framework

Traditional database approach with real tables and columns.
Built-in User model with password hashing.
Zero configuration required!
"""

__version__ = "2.0.0"
__author__ = "CocoBase Team"
__license__ = "MIT"

# Import main framework
from .framework import CocoBase, User, ColumnDefinition, CollectionDefinition

# Import events system
from .events import EventManager, EventType, EventContext

# Import real-time system
from .realtime import WebSocketManager

# Import storage
from .storage import StorageService, LocalStorageProvider

__all__ = [
    "CocoBase",
    "User",
    "ColumnDefinition",
    "CollectionDefinition",
    "EventManager",
    "EventType",
    "EventContext",
    "WebSocketManager",
    "StorageService",
    "LocalStorageProvider",
]
