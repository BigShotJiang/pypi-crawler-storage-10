"""
CocoBase Client - Zero-config API client
Automatically handles API keys from environment
"""

import os
import requests
from typing import Optional, Dict, Any, List
from pathlib import Path


class CocoBaseClient:
    """
    Zero-config client for CocoBase API

    Usage:
        client = CocoBaseClient()  # Auto-loads API key from .env

        # Create collection
        client.create_collection("users", schema={...})

        # Add document
        client.create_document("users", {"name": "John", "age": 30})

        # Query documents
        users = client.list_documents("users", status="active", age_gte=18)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        auto_create_env: bool = True,
    ):
        """
        Initialize CocoBase client

        Args:
            base_url: API base URL (default: http://localhost:8000)
            api_key: API key (default: loads from COCOBASE_API_KEY env var)
            auto_create_env: Auto-create .env file with API key if missing
        """
        self.base_url = base_url or os.getenv("COCOBASE_URL", "http://localhost:8000")
        self.api_key = api_key or self._get_or_create_api_key(auto_create_env)

        if not self.api_key:
            print(
                "⚠️  Warning: No API key found. Set COCOBASE_API_KEY environment variable."
            )

    def _get_or_create_api_key(self, auto_create: bool = True) -> Optional[str]:
        """Get API key from env or create one"""
        # Try to get from environment
        api_key = os.getenv("COCOBASE_API_KEY")

        if api_key:
            return api_key

        # Try to load from .env file
        env_file = Path(".env")
        if env_file.exists():
            with open(env_file) as f:
                for line in f:
                    if line.startswith("COCOBASE_API_KEY="):
                        api_key = line.split("=", 1)[1].strip()
                        if api_key:
                            os.environ["COCOBASE_API_KEY"] = api_key
                            return api_key

        # Auto-create if enabled
        if auto_create:
            import secrets

            api_key = f"cbk_{secrets.token_urlsafe(32)}"

            # Save to .env file
            with open(env_file, "a") as f:
                f.write(f"\n# CocoBase API Key (auto-generated)\n")
                f.write(f"COCOBASE_API_KEY={api_key}\n")

            os.environ["COCOBASE_API_KEY"] = api_key
            print(f"✅ Created new API key and saved to .env")
            print(f"🔑 Your API key: {api_key}")

            return api_key

        return None

    def _headers(self) -> Dict[str, str]:
        """Get request headers with API key"""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["x-api-key"] = self.api_key
        return headers

    def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Any:
        """Make API request"""
        url = f"{self.base_url}{endpoint}"

        response = requests.request(
            method=method, url=url, headers=self._headers(), json=json, params=params
        )

        response.raise_for_status()

        if response.content:
            return response.json()
        return None

    # Collections

    def create_collection(self, name: str, schema: Dict[str, Any]) -> Dict:
        """Create a new collection"""
        return self._request("POST", "/collections", json={"name": name, **schema})

    def list_collections(self) -> List[Dict]:
        """List all collections"""
        return self._request("GET", "/collections")

    def get_collection(self, collection_id: str) -> Dict:
        """Get collection details"""
        return self._request("GET", f"/collections/{collection_id}")

    def update_collection(self, collection_id: str, updates: Dict) -> Dict:
        """Update collection"""
        return self._request("PATCH", f"/collections/{collection_id}", json=updates)

    def delete_collection(self, collection_id: str) -> None:
        """Delete collection"""
        self._request("DELETE", f"/collections/{collection_id}")

    # Documents

    def create_document(self, collection: str, data: Dict[str, Any]) -> Dict:
        """Create a document"""
        return self._request(
            "POST",
            "/collections/documents",
            params={"collection": collection},
            json=data,
        )

    def list_documents(
        self,
        collection_id: str,
        limit: int = 100,
        offset: int = 0,
        sort: Optional[str] = None,
        order: str = "desc",
        **filters,
    ) -> List[Dict]:
        """
        List documents with filtering

        Examples:
            # Basic filter
            client.list_documents("users", status="active")

            # Comparison operators
            client.list_documents("users", age_gte=18, age_lt=65)

            # String search
            client.list_documents("users", name_contains="john")

            # IN operator
            client.list_documents("users", status_in="active,pending")
        """
        params = {"limit": limit, "offset": offset, "order": order, **filters}
        if sort:
            params["sort"] = sort

        return self._request(
            "GET", f"/collections/{collection_id}/documents", params=params
        )

    def get_document(self, collection_id: str, document_id: str) -> Dict:
        """Get a single document"""
        return self._request(
            "GET", f"/collections/{collection_id}/documents/{document_id}"
        )

    def update_document(
        self, collection_id: str, document_id: str, data: Dict[str, Any]
    ) -> Dict:
        """Update a document"""
        return self._request(
            "PATCH", f"/collections/{collection_id}/documents/{document_id}", json=data
        )

    def delete_document(self, collection_id: str, document_id: str) -> None:
        """Delete a document"""
        self._request("DELETE", f"/collections/{collection_id}/documents/{document_id}")

    # Batch operations

    def batch_create(self, collection_id: str, documents: List[Dict]) -> List[Dict]:
        """Create multiple documents at once"""
        return self._request(
            "POST",
            f"/collections/{collection_id}/documents/batch-create",
            json={"documents": documents},
        )

    def batch_update(self, collection_id: str, updates: List[Dict]) -> Dict:
        """Update multiple documents at once"""
        return self._request(
            "POST",
            f"/collections/{collection_id}/documents/batch-update",
            json={"updates": updates},
        )

    def batch_delete(self, collection_id: str, document_ids: List[str]) -> Dict:
        """Delete multiple documents at once"""
        return self._request(
            "POST",
            f"/collections/{collection_id}/documents/batch-delete",
            json={"document_ids": document_ids},
        )

    # Analytics

    def count_documents(self, collection_id: str, **filters) -> int:
        """Count documents matching filters"""
        result = self._request(
            "GET", f"/collections/{collection_id}/documents/count", params=filters
        )
        return result.get("count", 0)

    def aggregate(
        self, collection_id: str, field: str, operation: str = "count", **filters
    ) -> Any:
        """Perform aggregation on a field"""
        params = {"field": field, "operation": operation, **filters}
        result = self._request(
            "GET", f"/collections/{collection_id}/documents/aggregate", params=params
        )
        return result.get("result")

    def group_by(
        self,
        collection_id: str,
        field: str,
        count_field: Optional[str] = None,
        **filters,
    ) -> List[Dict]:
        """Group documents by a field"""
        params = {"field": field, **filters}
        if count_field:
            params["count_field"] = count_field

        return self._request(
            "GET", f"/collections/{collection_id}/documents/group-by", params=params
        )

    # Utilities

    def get_schema(self, collection_id: str) -> Dict:
        """Get inferred schema for a collection"""
        return self._request("GET", f"/collections/{collection_id}/schema")

    def export_collection(
        self, collection_id: str, format: str = "json", **filters
    ) -> Any:
        """Export collection data"""
        params = {"format": format, **filters}
        return self._request(
            "GET", f"/collections/{collection_id}/export", params=params
        )

    def upload_file(self, file_path: str, directory: Optional[str] = None) -> Dict:
        """Upload a file to project storage"""
        url = f"{self.base_url}/collections/file"

        with open(file_path, "rb") as f:
            files = {"file": f}
            params = {}
            if directory:
                params["directory"] = directory

            response = requests.post(
                url,
                headers={"x-api-key": self.api_key} if self.api_key else {},
                files=files,
                params=params,
            )

            response.raise_for_status()
            return response.json()


# Convenience function for quick usage
def connect(
    base_url: Optional[str] = None, api_key: Optional[str] = None
) -> CocoBaseClient:
    """
    Quick connect to CocoBase

    Usage:
        import cocobase

        db = cocobase.connect()

        # Use it
        db.create_document("users", {"name": "John"})
    """
    return CocoBaseClient(base_url=base_url, api_key=api_key)
