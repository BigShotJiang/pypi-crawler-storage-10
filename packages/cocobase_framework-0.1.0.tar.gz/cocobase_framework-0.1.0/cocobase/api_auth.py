"""
API Key authentication middleware for CocoBase
Optional in development, required in production
"""

import os
import secrets
from pathlib import Path
from fastapi import Header, HTTPException, status
from typing import Optional


class APIKeyManager:
    """Manages API key generation and validation"""

    def __init__(self, env_file: str = ".env", dev_mode: bool = False):
        self.env_file = Path(env_file)
        self.dev_mode = dev_mode
        self._api_key: Optional[str] = None

    def get_or_create_api_key(self) -> str:
        """Get existing API key or create a new one"""
        if self._api_key:
            return self._api_key

        # Try to get from environment
        api_key = os.getenv("COCOBASE_API_KEY")

        if api_key:
            self._api_key = api_key
            return api_key

        # Try to load from .env file
        if self.env_file.exists():
            with open(self.env_file) as f:
                for line in f:
                    if line.startswith("COCOBASE_API_KEY="):
                        api_key = line.split("=", 1)[1].strip().strip('"').strip("'")
                        if api_key:
                            self._api_key = api_key
                            os.environ["COCOBASE_API_KEY"] = api_key
                            return api_key

        # Auto-create new API key
        api_key = f"cbk_{secrets.token_urlsafe(32)}"

        # Save to .env file
        with open(self.env_file, "a") as f:
            if self.env_file.stat().st_size > 0:
                f.write("\n")
            f.write(f"# CocoBase API Key (auto-generated)\n")
            f.write(f"COCOBASE_API_KEY={api_key}\n")

        self._api_key = api_key
        os.environ["COCOBASE_API_KEY"] = api_key

        print(f"\n{'='*60}")
        print(f"🔑 CocoBase API Key Created!")
        print(f"{'='*60}")
        print(f"API Key: {api_key}")
        print(f"Saved to: {self.env_file.absolute()}")
        print(f"\nThis key is required for API requests.")
        print(f"Add it to your .env file or use it in API calls:")
        print(f"  Header: x-api-key: {api_key}")
        print(f"{'='*60}\n")

        return api_key

    def validate_api_key(self, provided_key: str) -> bool:
        """Validate provided API key"""
        if self.dev_mode and not provided_key:
            # In dev mode without key, allow access
            return True

        expected_key = self.get_or_create_api_key()
        return provided_key == expected_key

    async def verify_api_key(
        self,
        x_api_key: Optional[str] = Header(
            None, description="API Key for authentication"
        ),
    ) -> str:
        """FastAPI dependency for API key verification"""
        if self.dev_mode and not x_api_key:
            # Dev mode - allow without key
            return "dev_mode"

        if not x_api_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key required. Set x-api-key header.",
            )

        if not self.validate_api_key(x_api_key):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Invalid API key"
            )

        return x_api_key
