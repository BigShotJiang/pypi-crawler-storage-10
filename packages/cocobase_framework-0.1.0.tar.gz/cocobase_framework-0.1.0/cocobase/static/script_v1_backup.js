// Global state
let collections = {};
let currentCollection = null;
let currentRecords = [];
let columnCount = 0;
let editColumnCount = 0;
let editingRecordId = null;
let settings = {
  compactView: false,
  showRowNumbers: false,
  recordsPerPage: 50,
};

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadCollections();
  loadSettings();
  loadDatabaseInfo();
  // Set first tab as active
  showTab("collections");
});

// Tab Management
function showTab(tabName) {
  // Hide all tabs
  document.querySelectorAll(".tab-content").forEach((tab) => {
    tab.classList.add("hidden");
  });
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.remove("border-primary", "text-primary", "font-semibold");
    btn.classList.add("border-transparent", "text-gray-600");
  });

  // Show selected tab
  document.getElementById(`${tabName}-tab`).classList.remove("hidden");
  const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
  if (activeBtn) {
    activeBtn.classList.remove("border-transparent", "text-gray-600");
    activeBtn.classList.add("border-primary", "text-primary", "font-semibold");
  }

  // Load data if switching to data browser
  if (tabName === "data") {
    populateCollectionSelector();
  }
}

// Settings Management
function loadSettings() {
  const saved = localStorage.getItem("baas_settings");
  if (saved) {
    settings = { ...settings, ...JSON.parse(saved) };
    document.getElementById("compact-view").checked = settings.compactView;
    document.getElementById("show-row-numbers").checked =
      settings.showRowNumbers;
    document.getElementById("records-per-page").value = settings.recordsPerPage;
  }
}

function saveSettings() {
  localStorage.setItem("baas_settings", JSON.stringify(settings));
}

function toggleCompactView() {
  settings.compactView = document.getElementById("compact-view").checked;
  saveSettings();
  if (currentCollection) {
    renderRecords();
  }
}

function toggleRowNumbers() {
  settings.showRowNumbers = document.getElementById("show-row-numbers").checked;
  saveSettings();
  if (currentCollection) {
    renderRecords();
  }
}

function updateRecordsPerPage() {
  settings.recordsPerPage = parseInt(
    document.getElementById("records-per-page").value
  );
  saveSettings();
  if (currentCollection) {
    loadRecords();
  }
}

async function loadDatabaseInfo() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    document.getElementById("db-url").textContent = data.database;
  } catch (err) {
    document.getElementById("db-url").textContent =
      "Error loading database info";
  }
}

function exportCollections() {
  const dataStr = JSON.stringify(collections, null, 2);
  const dataBlob = new Blob([dataStr], { type: "application/json" });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "collections_backup.json";
  link.click();
  URL.revokeObjectURL(url);
  showToast("Collections exported successfully", "success");
}

function openImportModal() {
  document.getElementById("import-modal").classList.remove("hidden");
  document.getElementById("import-modal").classList.add("flex");
}

async function importCollections() {
  const fileInput = document.getElementById("import-file");
  if (!fileInput.files || !fileInput.files[0]) {
    showToast("Please select a file", "error");
    return;
  }

  try {
    const file = fileInput.files[0];
    const text = await file.text();
    const importedCollections = JSON.parse(text);

    // TODO: Implement import API endpoint
    showToast("Import functionality coming soon", "info");
    closeModal("import-modal");
  } catch (err) {
    showToast("Error importing: " + err.message, "error");
  }
}

// Load Collections
async function loadCollections() {
  try {
    const response = await fetch("/api/collections");
    collections = await response.json();
    renderCollectionsList();
    populateCollectionSelector();
  } catch (err) {
    showToast("Error loading collections: " + err.message, "error");
  }
}

// Render Collections List
function renderCollectionsList() {
  const listEl = document.getElementById("collections-list");
  listEl.innerHTML = "";

  if (Object.keys(collections).length === 0) {
    listEl.innerHTML = `
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                </svg>
                <p class="mt-2 text-gray-500">No collections yet. Create one to get started!</p>
            </div>
        `;
    return;
  }

  const grid = document.createElement("div");
  grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4";

  for (const [name, config] of Object.entries(collections)) {
    const card = document.createElement("div");
    card.className =
      "border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-white";

    const isUserCollection =
      name.toLowerCase() === "users" || name.toLowerCase().endsWith("_users");
    const badge = isUserCollection
      ? '<span class="inline-block px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded-full ml-2">User Table</span>'
      : "";

    const columnsList = config.columns
      .slice(0, 3)
      .map(
        (c) =>
          `<span class="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded mr-1 mb-1">${c.name}: ${c.type}</span>`
      )
      .join("");

    const moreColumns =
      config.columns.length > 3
        ? `<span class="text-xs text-gray-500">+${
            config.columns.length - 3
          } more</span>`
        : "";

    card.innerHTML = `
            <div class="flex justify-between items-start mb-3">
                <h3 class="text-lg font-semibold text-gray-800">${name}${badge}</h3>
                <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">${config.columns.length} columns</span>
            </div>
            <div class="mb-3">
                ${columnsList}
                ${moreColumns}
            </div>
            <div class="flex gap-2 mt-4">
                <button onclick="editCollection('${name}')" class="flex-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded text-sm transition-colors">
                    ✏️ Edit
                </button>
                <button onclick="viewCollectionData('${name}')" class="flex-1 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded text-sm transition-colors">
                    📊 Data
                </button>
                <button onclick="deleteCollection('${name}')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors">
                    🗑️
                </button>
            </div>
        `;
    grid.appendChild(card);
  }

  listEl.appendChild(grid);
}

// Collection Management - Create
function openCreateCollectionModal() {
  document.getElementById("create-collection-modal").classList.remove("hidden");
  document.getElementById("create-collection-modal").classList.add("flex");
  document.getElementById("columns-container").innerHTML = "";
  document.getElementById("collection-name").value = "";
  columnCount = 0;
  addColumn(); // Add first column
}

function addColumn() {
  const container = document.getElementById("columns-container");
  const columnDiv = document.createElement("div");
  const id = columnCount;
  columnDiv.className = "border border-gray-200 rounded-lg p-4 bg-gray-50";
  columnDiv.innerHTML = `
        <div class="grid grid-cols-2 gap-3 mb-3">
            <input type="text" placeholder="Column name" id="col_name_${id}" required class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
            <select id="col_type_${id}" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                <option value="string">String</option>
                <option value="integer">Integer</option>
                <option value="float">Float</option>
                <option value="boolean">Boolean</option>
                <option value="datetime">DateTime</option>
                <option value="text">Text</option>
                <option value="json">JSON</option>
            </select>
        </div>
        <div class="flex flex-wrap gap-4 mb-3">
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="col_pk_${id}" class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Primary Key</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="col_auto_${id}" class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Auto Increment</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="col_req_${id}" class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Required</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="col_uniq_${id}" class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Unique</span>
            </label>
        </div>
        <button type="button" onclick="this.parentElement.remove()" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors">
            Remove Column
        </button>
    `;
  container.appendChild(columnDiv);
  columnCount++;
}

// Collection Management - Edit
function editCollection(name) {
  const config = collections[name];
  document.getElementById("edit-collection-modal").classList.remove("hidden");
  document.getElementById("edit-collection-modal").classList.add("flex");
  document.getElementById("edit-collection-name").value = name;
  document.getElementById("original-collection-name").value = name;

  const container = document.getElementById("edit-columns-container");
  container.innerHTML = "";
  editColumnCount = 0;

  // Add existing columns
  config.columns.forEach((col) => {
    addEditColumn(col);
  });
}

function addEditColumn(existingCol = null) {
  const container = document.getElementById("edit-columns-container");
  const columnDiv = document.createElement("div");
  const id = editColumnCount;
  columnDiv.className = "border border-gray-200 rounded-lg p-4 bg-gray-50";

  const col = existingCol || {
    name: "",
    type: "string",
    primary_key: false,
    auto_increment: false,
    required: false,
    unique: false,
  };

  columnDiv.innerHTML = `
        <div class="grid grid-cols-2 gap-3 mb-3">
            <input type="text" placeholder="Column name" id="edit_col_name_${id}" value="${
    col.name
  }" required class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
            <select id="edit_col_type_${id}" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                <option value="string" ${
                  col.type === "string" ? "selected" : ""
                }>String</option>
                <option value="integer" ${
                  col.type === "integer" ? "selected" : ""
                }>Integer</option>
                <option value="float" ${
                  col.type === "float" ? "selected" : ""
                }>Float</option>
                <option value="boolean" ${
                  col.type === "boolean" ? "selected" : ""
                }>Boolean</option>
                <option value="datetime" ${
                  col.type === "datetime" ? "selected" : ""
                }>DateTime</option>
                <option value="text" ${
                  col.type === "text" ? "selected" : ""
                }>Text</option>
                <option value="json" ${
                  col.type === "json" ? "selected" : ""
                }>JSON</option>
            </select>
        </div>
        <div class="flex flex-wrap gap-4 mb-3">
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="edit_col_pk_${id}" ${
    col.primary_key ? "checked" : ""
  } class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Primary Key</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="edit_col_auto_${id}" ${
    col.auto_increment ? "checked" : ""
  } class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Auto Increment</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="edit_col_req_${id}" ${
    col.required ? "checked" : ""
  } class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Required</span>
            </label>
            <label class="flex items-center space-x-2">
                <input type="checkbox" id="edit_col_uniq_${id}" ${
    col.unique ? "checked" : ""
  } class="rounded text-primary focus:ring-primary">
                <span class="text-sm text-gray-700">Unique</span>
            </label>
        </div>
        <button type="button" onclick="this.parentElement.remove()" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors">
            Remove Column
        </button>
    `;
  container.appendChild(columnDiv);
  editColumnCount++;
}

// Delete Collection
async function deleteCollection(name) {
  if (
    !confirm(
      `Delete collection "${name}"? This will delete all data and cannot be undone.`
    )
  )
    return;

  try {
    const response = await fetch(`/api/collections/${name}`, {
      method: "DELETE",
    });
    if (response.ok) {
      showToast(`Collection "${name}" deleted successfully`, "success");
      loadCollections();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting collection", "error");
    }
  } catch (err) {
    showToast("Error deleting collection: " + err.message, "error");
  }
}

// Form Handlers
document
  .getElementById("collection-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("collection-name").value;
    const columns = [];

    const columnBuilders = document.querySelectorAll(
      "#columns-container > div"
    );
    columnBuilders.forEach((builder, i) => {
      const nameInput = builder.querySelector('[id^="col_name_"]');
      const typeSelect = builder.querySelector('[id^="col_type_"]');
      const pkCheck = builder.querySelector('[id^="col_pk_"]');
      const autoCheck = builder.querySelector('[id^="col_auto_"]');
      const reqCheck = builder.querySelector('[id^="col_req_"]');
      const uniqCheck = builder.querySelector('[id^="col_uniq_"]');

      if (nameInput && nameInput.value) {
        columns.push({
          name: nameInput.value,
          type: typeSelect.value,
          primary_key: pkCheck.checked,
          auto_increment: autoCheck.checked,
          required: reqCheck.checked,
          unique: uniqCheck.checked,
        });
      }
    });

    if (columns.length === 0) {
      showToast("Please add at least one column", "error");
      return;
    }

    try {
      const response = await fetch("/api/collections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, columns }),
      });

      if (response.ok) {
        showToast(`Collection "${name}" created successfully`, "success");
        closeModal("create-collection-modal");
        loadCollections();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error creating collection", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

document
  .getElementById("edit-collection-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const originalName = document.getElementById(
      "original-collection-name"
    ).value;
    const newName = document.getElementById("edit-collection-name").value;
    const columns = [];

    const columnBuilders = document.querySelectorAll(
      "#edit-columns-container > div"
    );
    columnBuilders.forEach((builder) => {
      const nameInput = builder.querySelector('[id^="edit_col_name_"]');
      const typeSelect = builder.querySelector('[id^="edit_col_type_"]');
      const pkCheck = builder.querySelector('[id^="edit_col_pk_"]');
      const autoCheck = builder.querySelector('[id^="edit_col_auto_"]');
      const reqCheck = builder.querySelector('[id^="edit_col_req_"]');
      const uniqCheck = builder.querySelector('[id^="edit_col_uniq_"]');

      if (nameInput && nameInput.value) {
        columns.push({
          name: nameInput.value,
          type: typeSelect.value,
          primary_key: pkCheck.checked,
          auto_increment: autoCheck.checked,
          required: reqCheck.checked,
          unique: uniqCheck.checked,
        });
      }
    });

    if (columns.length === 0) {
      showToast("Please add at least one column", "error");
      return;
    }

    try {
      const response = await fetch(`/api/collections/${originalName}/update`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName, columns }),
      });

      if (response.ok) {
        showToast(`Collection updated successfully`, "success");
        closeModal("edit-collection-modal");
        loadCollections();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error updating collection", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

// Data Browser
function populateCollectionSelector() {
  const selector = document.getElementById("collection-selector");
  selector.innerHTML = '<option value="">Select a collection...</option>';

  for (const name of Object.keys(collections)) {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    selector.appendChild(option);
  }
}

function selectCollection() {
  const selector = document.getElementById("collection-selector");
  currentCollection = selector.value;

  if (currentCollection) {
    document.getElementById("create-record-btn").disabled = false;
    document.getElementById("refresh-records-btn").disabled = false;
    loadRecords();
  } else {
    document.getElementById("create-record-btn").disabled = true;
    document.getElementById("refresh-records-btn").disabled = true;
    document.getElementById("data-browser").innerHTML = "";
  }
}

function viewCollectionData(name) {
  showTab("data");
  document.getElementById("collection-selector").value = name;
  currentCollection = name;
  document.getElementById("create-record-btn").disabled = false;
  document.getElementById("refresh-records-btn").disabled = false;
  loadRecords();
}

async function loadRecords() {
  if (!currentCollection) return;

  const browser = document.getElementById("data-browser");
  browser.innerHTML = `
        <div class="flex justify-center items-center py-12">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <p class="ml-4 text-gray-600">Loading records...</p>
        </div>
    `;

  try {
    const response = await fetch(
      `/api/data/${currentCollection}?limit=${settings.recordsPerPage}`
    );
    currentRecords = await response.json();
    renderRecords();
  } catch (err) {
    browser.innerHTML = `<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">Error loading records: ${err.message}</div>`;
  }
}

function renderRecords() {
  const browser = document.getElementById("data-browser");

  if (currentRecords.length === 0) {
    browser.innerHTML = `
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
                <p class="mt-2 text-gray-500">No records yet. Create one to get started!</p>
            </div>
        `;
    return;
  }

  const config = collections[currentCollection];
  const columns = config.columns;
  const isUserCollection =
    currentCollection.toLowerCase() === "users" ||
    currentCollection.toLowerCase().endsWith("_users");

  let table = `<div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>`;

  if (settings.showRowNumbers) {
    table +=
      '<th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>';
  }

  columns.forEach((col) => {
    // Hide password column values for security
    if (isUserCollection && col.name === "password") {
      table += `<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${col.name} 🔒</th>`;
    } else {
      table += `<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${col.name}</th>`;
    }
  });
  table +=
    '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th></tr></thead><tbody class="bg-white divide-y divide-gray-200">';

  currentRecords.forEach((record, index) => {
    table += '<tr class="hover:bg-gray-50">';

    if (settings.showRowNumbers) {
      table += `<td class="px-3 py-4 whitespace-nowrap text-sm text-gray-500">${
        index + 1
      }</td>`;
    }

    columns.forEach((col) => {
      const value = record[col.name];
      let displayValue;

      // Hide password values
      if (isUserCollection && col.name === "password") {
        displayValue = '<span class="text-gray-400">••••••••</span>';
      } else if (value === null || value === undefined) {
        displayValue = '<span class="text-gray-400 italic">NULL</span>';
      } else if (typeof value === "boolean") {
        displayValue = value
          ? '<span class="px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">true</span>'
          : '<span class="px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">false</span>';
      } else {
        displayValue =
          String(value).length > 50
            ? String(value).substring(0, 50) + "..."
            : String(value);
      }

      const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
      table += `<td class="${cellClass} whitespace-nowrap text-sm text-gray-900" title="${String(
        value
      )}">${displayValue}</td>`;
    });

    const pk = getPrimaryKeyValue(record);
    const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
    table += `<td class="${cellClass} whitespace-nowrap text-sm font-medium">
            <div class="flex gap-2">
                <button onclick="viewRecord(${pk})" class="text-blue-600 hover:text-blue-900">View</button>
                <button onclick="openEditRecordModal(${pk})" class="text-green-600 hover:text-green-900">Edit</button>
                <button onclick="deleteRecord(${pk})" class="text-red-600 hover:text-red-900">Delete</button>
            </div>
        </td>`;
    table += "</tr>";
  });

  table += "</tbody></table></div>";

  if (currentRecords.length >= settings.recordsPerPage) {
    table += `<div class="mt-4 text-sm text-gray-500 text-center">
            Showing first ${settings.recordsPerPage} records. Adjust in settings to show more.
        </div>`;
  }

  browser.innerHTML = table;
}

function getPrimaryKey() {
  const config = collections[currentCollection];
  for (const col of config.columns) {
    if (col.primary_key) {
      return col.name;
    }
  }
  return "id";
}

function getPrimaryKeyValue(record) {
  const pk = getPrimaryKey();
  return record[pk];
}

// Record CRUD Operations
function openCreateRecordModal() {
  if (!currentCollection) return;

  editingRecordId = null;
  document.getElementById("record-modal-title").textContent = "Create Record";
  document.getElementById("record-submit-btn").textContent = "Create";
  document.getElementById("record-submit-btn").className =
    "flex-1 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";

  const config = collections[currentCollection];
  const container = document.getElementById("record-fields-container");
  const isUserCollection =
    currentCollection.toLowerCase() === "users" ||
    currentCollection.toLowerCase().endsWith("_users");
  container.innerHTML = "";

  config.columns.forEach((col) => {
    if (col.auto_increment) return; // Skip auto-increment fields

    const div = document.createElement("div");

    let input = "";
    const inputClass =
      "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent";

    switch (col.type) {
      case "boolean":
        input = `<input type="checkbox" id="field_${col.name}" class="rounded text-primary focus:ring-primary">`;
        break;
      case "integer":
        input = `<input type="number" id="field_${col.name}" ${
          col.required ? "required" : ""
        } class="${inputClass}">`;
        break;
      case "float":
        input = `<input type="number" step="any" id="field_${col.name}" ${
          col.required ? "required" : ""
        } class="${inputClass}">`;
        break;
      case "datetime":
        input = `<input type="datetime-local" id="field_${col.name}" ${
          col.required ? "required" : ""
        } class="${inputClass}">`;
        break;
      case "text":
      case "json":
        input = `<textarea id="field_${col.name}" rows="3" ${
          col.required ? "required" : ""
        } class="${inputClass}"></textarea>`;
        break;
      default:
        // Special handling for password fields
        if (isUserCollection && col.name === "password") {
          input = `<input type="password" id="field_${col.name}" ${
            col.required ? "required" : ""
          } class="${inputClass}" placeholder="Will be auto-hashed">`;
        } else {
          input = `<input type="text" id="field_${col.name}" ${
            col.required ? "required" : ""
          } class="${inputClass}">`;
        }
    }

    const requiredBadge = col.required
      ? '<span class="text-red-500">*</span>'
      : "";
    const passwordNote =
      isUserCollection && col.name === "password"
        ? '<p class="mt-1 text-xs text-green-600">🔒 Password will be automatically hashed</p>'
        : "";

    div.innerHTML = `
            <label class="block text-sm font-medium text-gray-700 mb-2">${col.name} ${requiredBadge}</label>
            ${input}
            ${passwordNote}
        `;
    container.appendChild(div);
  });

  document.getElementById("record-modal").classList.remove("hidden");
  document.getElementById("record-modal").classList.add("flex");
}

async function openEditRecordModal(recordId) {
  if (!currentCollection) return;

  editingRecordId = recordId;
  document.getElementById("record-modal-title").textContent = "Edit Record";
  document.getElementById("record-submit-btn").textContent = "Update";
  document.getElementById("record-submit-btn").className =
    "flex-1 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";

  try {
    const response = await fetch(`/api/data/${currentCollection}/${recordId}`);
    const record = await response.json();

    const config = collections[currentCollection];
    const container = document.getElementById("record-fields-container");
    const isUserCollection =
      currentCollection.toLowerCase() === "users" ||
      currentCollection.toLowerCase().endsWith("_users");
    container.innerHTML = "";

    config.columns.forEach((col) => {
      if (col.primary_key && col.auto_increment) return; // Skip PK auto-increment

      const div = document.createElement("div");
      const value = record[col.name];
      let input = "";
      const inputClass =
        "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent";

      switch (col.type) {
        case "boolean":
          input = `<input type="checkbox" id="field_${col.name}" ${
            value ? "checked" : ""
          } class="rounded text-primary focus:ring-primary">`;
          break;
        case "integer":
          input = `<input type="number" id="field_${col.name}" value="${
            value || ""
          }" ${col.required ? "required" : ""} class="${inputClass}">`;
          break;
        case "float":
          input = `<input type="number" step="any" id="field_${
            col.name
          }" value="${value || ""}" ${
            col.required ? "required" : ""
          } class="${inputClass}">`;
          break;
        case "datetime":
          const dateValue = value
            ? new Date(value).toISOString().slice(0, 16)
            : "";
          input = `<input type="datetime-local" id="field_${
            col.name
          }" value="${dateValue}" ${
            col.required ? "required" : ""
          } class="${inputClass}">`;
          break;
        case "text":
        case "json":
          input = `<textarea id="field_${col.name}" rows="3" ${
            col.required ? "required" : ""
          } class="${inputClass}">${value || ""}</textarea>`;
          break;
        default:
          // Special handling for password fields
          if (isUserCollection && col.name === "password") {
            input = `<input type="password" id="field_${col.name}" class="${inputClass}" placeholder="Leave blank to keep current password">`;
          } else {
            input = `<input type="text" id="field_${col.name}" value="${
              value || ""
            }" ${col.required ? "required" : ""} class="${inputClass}">`;
          }
      }

      const requiredBadge = col.required
        ? '<span class="text-red-500">*</span>'
        : "";
      const passwordNote =
        isUserCollection && col.name === "password"
          ? '<p class="mt-1 text-xs text-yellow-600">Leave blank to keep current password. New password will be hashed.</p>'
          : "";

      div.innerHTML = `
                <label class="block text-sm font-medium text-gray-700 mb-2">${col.name} ${requiredBadge}</label>
                ${input}
                ${passwordNote}
            `;
      container.appendChild(div);
    });

    document.getElementById("record-modal").classList.remove("hidden");
    document.getElementById("record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

document
  .getElementById("record-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const config = collections[currentCollection];
    const data = {};
    const isUserCollection =
      currentCollection.toLowerCase() === "users" ||
      currentCollection.toLowerCase().endsWith("_users");

    config.columns.forEach((col) => {
      if (col.auto_increment && !editingRecordId) return;
      if (col.primary_key && col.auto_increment) return;

      const field = document.getElementById(`field_${col.name}`);
      if (!field) return;

      if (col.type === "boolean") {
        data[col.name] = field.checked;
      } else if (col.type === "integer") {
        data[col.name] = field.value ? parseInt(field.value) : null;
      } else if (col.type === "float") {
        data[col.name] = field.value ? parseFloat(field.value) : null;
      } else if (col.type === "json") {
        try {
          data[col.name] = field.value ? JSON.parse(field.value) : null;
        } catch {
          data[col.name] = field.value;
        }
      } else {
        // For password fields in edit mode, only include if not empty
        if (
          isUserCollection &&
          col.name === "password" &&
          editingRecordId &&
          !field.value
        ) {
          return; // Skip empty password in edit mode
        }
        data[col.name] = field.value || null;
      }
    });

    try {
      let response;
      if (editingRecordId) {
        response = await fetch(
          `/api/data/${currentCollection}/${editingRecordId}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
          }
        );
      } else {
        response = await fetch(`/api/data/${currentCollection}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
      }

      if (response.ok) {
        showToast(
          `Record ${editingRecordId ? "updated" : "created"} successfully`,
          "success"
        );
        closeModal("record-modal");
        loadRecords();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error saving record", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

async function viewRecord(recordId) {
  if (!currentCollection) return;

  try {
    const response = await fetch(`/api/data/${currentCollection}/${recordId}`);
    const record = await response.json();

    const config = collections[currentCollection];
    const isUserCollection =
      currentCollection.toLowerCase() === "users" ||
      currentCollection.toLowerCase().endsWith("_users");

    let content = '<div class="space-y-3">';
    config.columns.forEach((col) => {
      const value = record[col.name];
      let displayValue;

      if (isUserCollection && col.name === "password") {
        displayValue = "••••••••";
      } else if (value === null || value === undefined) {
        displayValue = '<span class="text-gray-400 italic">NULL</span>';
      } else if (typeof value === "object") {
        displayValue =
          '<pre class="bg-gray-100 p-2 rounded text-xs overflow-auto">' +
          JSON.stringify(value, null, 2) +
          "</pre>";
      } else {
        displayValue = String(value);
      }

      content += `
                <div class="border-b border-gray-200 pb-2">
                    <div class="text-sm font-semibold text-gray-600">${col.name}</div>
                    <div class="text-gray-900">${displayValue}</div>
                </div>
            `;
    });
    content += "</div>";

    document.getElementById("view-record-content").innerHTML = content;
    document.getElementById("view-record-modal").classList.remove("hidden");
    document.getElementById("view-record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

async function deleteRecord(recordId) {
  if (!confirm("Delete this record? This cannot be undone.")) return;

  try {
    const response = await fetch(`/api/data/${currentCollection}/${recordId}`, {
      method: "DELETE",
    });
    if (response.ok) {
      showToast("Record deleted successfully", "success");
      loadRecords();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting record", "error");
    }
  } catch (err) {
    showToast("Error deleting record: " + err.message, "error");
  }
}

// Modal Management
function closeModal(modalId) {
  document.getElementById(modalId).classList.add("hidden");
  document.getElementById(modalId).classList.remove("flex");
}

// Toast Notifications
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  const bgColors = {
    success: "bg-green-500",
    error: "bg-red-500",
    info: "bg-blue-500",
  };

  toast.className = `fixed top-4 right-4 ${bgColors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}
