// Global state
let collections = [];
let collectionsMap = {}; // name -> collection object
let currentCollection = null;
let currentRecords = [];
let settings = {
  compactView: false,
  showRowNumbers: false,
  recordsPerPage: 50,
};

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadCollections();
  loadSettings();
  loadDatabaseInfo();
  showTab("collections");
});

// Tab Management
function showTab(tabName) {
  document.querySelectorAll(".tab-content").forEach((tab) => {
    tab.classList.add("hidden");
  });
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.remove("border-primary", "text-primary", "font-semibold");
    btn.classList.add("border-transparent", "text-gray-600");
  });

  document.getElementById(`${tabName}-tab`).classList.remove("hidden");
  const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
  if (activeBtn) {
    activeBtn.classList.remove("border-transparent", "text-gray-600");
    activeBtn.classList.add("border-primary", "text-primary", "font-semibold");
  }

  if (tabName === "data") {
    populateCollectionSelector();
  }
}

// Settings Management
function loadSettings() {
  const saved = localStorage.getItem("cocobase_settings");
  if (saved) {
    settings = { ...settings, ...JSON.parse(saved) };
    document.getElementById("compact-view").checked = settings.compactView;
    document.getElementById("show-row-numbers").checked =
      settings.showRowNumbers;
    document.getElementById("records-per-page").value = settings.recordsPerPage;
  }
}

function saveSettings() {
  localStorage.setItem("cocobase_settings", JSON.stringify(settings));
}

function toggleCompactView() {
  settings.compactView = document.getElementById("compact-view").checked;
  saveSettings();
  if (currentCollection) renderRecords();
}

function toggleRowNumbers() {
  settings.showRowNumbers = document.getElementById("show-row-numbers").checked;
  saveSettings();
  if (currentCollection) renderRecords();
}

function updateRecordsPerPage() {
  settings.recordsPerPage = parseInt(
    document.getElementById("records-per-page").value
  );
  saveSettings();
  if (currentCollection) loadRecords();
}

async function loadDatabaseInfo() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    document.getElementById("db-url").textContent =
      data.database || "sqlite:///cocobase.db";
  } catch (err) {
    document.getElementById("db-url").textContent =
      "Error loading database info";
  }
}

// Load Collections
async function loadCollections() {
  try {
    const response = await fetch("/collections");
    collections = await response.json();

    // Build map for easy lookup
    collectionsMap = {};
    collections.forEach((c) => {
      collectionsMap[c.name] = c;
    });

    renderCollectionsList();
    populateCollectionSelector();
  } catch (err) {
    showToast("Error loading collections: " + err.message, "error");
  }
}

// Render Collections List
function renderCollectionsList() {
  const listEl = document.getElementById("collections-list");
  listEl.innerHTML = "";

  if (collections.length === 0) {
    listEl.innerHTML = `
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
        </svg>
        <p class="mt-2 text-gray-500">No collections yet. Create one to get started!</p>
      </div>
    `;
    return;
  }

  const grid = document.createElement("div");
  grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4";

  collections.forEach((collection) => {
    const card = document.createElement("div");
    card.className =
      "border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-white";

    const columnCount = collection.columns ? collection.columns.length : 0;
    const rowCount = collection.row_count || 0;

    card.innerHTML = `
      <div class="flex justify-between items-start mb-3">
        <h3 class="text-lg font-semibold text-gray-800">${collection.name}</h3>
        <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">${columnCount} columns</span>
      </div>
      <div class="text-xs text-gray-500 mb-3">
        📊 ${rowCount} row${rowCount !== 1 ? "s" : ""}<br>
        📋 Table ID: ${collection.id || collection.name}
      </div>
      <div class="flex gap-2 mt-4">
        <button onclick="viewCollectionData('${
          collection.name
        }')" class="flex-1 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded text-sm transition-colors">
          📊 View Data
        </button>
        <button onclick="openEditColumnsModal('${
          collection.name
        }')" class="flex-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded text-sm transition-colors">
          ✏️ Edit
        </button>
        <button onclick="deleteCollection('${
          collection.name
        }')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors">
          🗑️
        </button>
      </div>
    `;
    grid.appendChild(card);
  });

  listEl.appendChild(grid);
}

// Collection Management
let columnCounter = 0;

function openCreateCollectionModal() {
  document.getElementById("create-collection-modal").classList.remove("hidden");
  document.getElementById("create-collection-modal").classList.add("flex");
  document.getElementById("collection-name").value = "";

  // Reset columns container to just have the default ID column
  const container = document.getElementById("columns-container");
  container.innerHTML = `
    <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
      <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
        <div class="md:col-span-3">
          <label class="block text-xs font-medium text-gray-600 mb-1">Column Name</label>
          <input
            type="text"
            value="id"
            readonly
            class="w-full px-3 py-2 border border-gray-300 rounded bg-white text-sm"
          />
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs font-medium text-gray-600 mb-1">Type</label>
          <select disabled class="w-full px-3 py-2 border border-gray-300 rounded bg-white text-sm">
            <option>integer</option>
          </select>
        </div>
        <div class="md:col-span-5 flex gap-2 items-end">
          <label class="flex items-center space-x-1">
            <input type="checkbox" checked disabled class="rounded text-primary">
            <span class="text-xs text-gray-600">Primary Key</span>
          </label>
          <label class="flex items-center space-x-1">
            <input type="checkbox" checked disabled class="rounded text-primary">
            <span class="text-xs text-gray-600">Auto Increment</span>
          </label>
        </div>
        <div class="md:col-span-2 flex items-end">
          <span class="text-xs text-gray-500 italic">Default ID</span>
        </div>
      </div>
    </div>
  `;
  columnCounter = 0;
}

function addColumnField(
  name = "",
  type = "string",
  required = false,
  unique = false,
  defaultValue = ""
) {
  const container = document.getElementById("columns-container");
  const colId = `col-${++columnCounter}`;

  const columnDiv = document.createElement("div");
  columnDiv.className =
    "border border-gray-200 rounded-lg p-4 bg-white column-field";
  columnDiv.id = colId;

  columnDiv.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
      <div class="md:col-span-3">
        <label class="block text-xs font-medium text-gray-600 mb-1">Column Name*</label>
        <input
          type="text"
          value="${name}"
          placeholder="e.g., title, price"
          required
          class="column-name w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-primary"
        />
      </div>
      <div class="md:col-span-2">
        <label class="block text-xs font-medium text-gray-600 mb-1">Data Type*</label>
        <select class="column-type w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-primary">
          <option value="string" ${
            type === "string" ? "selected" : ""
          }>String</option>
          <option value="text" ${
            type === "text" ? "selected" : ""
          }>Text (Long)</option>
          <option value="integer" ${
            type === "integer" ? "selected" : ""
          }>Integer</option>
          <option value="float" ${
            type === "float" ? "selected" : ""
          }>Float</option>
          <option value="boolean" ${
            type === "boolean" ? "selected" : ""
          }>Boolean</option>
          <option value="datetime" ${
            type === "datetime" ? "selected" : ""
          }>DateTime</option>
          <option value="json" ${
            type === "json" ? "selected" : ""
          }>JSON</option>
          <option value="file" ${
            type === "file" ? "selected" : ""
          }>File (Path)</option>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="block text-xs font-medium text-gray-600 mb-1">Default Value</label>
        <input
          type="text"
          value="${defaultValue}"
          placeholder="Optional"
          class="column-default w-full px-3 py-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-primary"
        />
      </div>
      <div class="md:col-span-4 flex gap-2 items-end flex-wrap">
        <label class="flex items-center space-x-1">
          <input type="checkbox" ${
            required ? "checked" : ""
          } class="column-required rounded text-primary">
          <span class="text-xs text-gray-600">Required</span>
        </label>
        <label class="flex items-center space-x-1">
          <input type="checkbox" ${
            unique ? "checked" : ""
          } class="column-unique rounded text-primary">
          <span class="text-xs text-gray-600">Unique</span>
        </label>
      </div>
      <div class="md:col-span-1 flex items-end justify-end">
        <button
          type="button"
          onclick="removeColumn('${colId}')"
          class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors"
          title="Remove column"
        >
          🗑️
        </button>
      </div>
    </div>
  `;

  container.appendChild(columnDiv);
}

function removeColumn(colId) {
  document.getElementById(colId)?.remove();
}

function clearColumns() {
  if (
    !confirm("Clear all columns? You'll start with just the default ID column.")
  )
    return;

  const container = document.getElementById("columns-container");
  const customColumns = container.querySelectorAll(".column-field");
  customColumns.forEach((col) => col.remove());
  columnCounter = 0;
}

function loadBlogTemplate() {
  clearColumns();
  document.getElementById("collection-name").value = "posts";
  addColumnField("title", "string", true, false, "");
  addColumnField("content", "text", true, false, "");
  addColumnField("author", "string", false, false, "");
  addColumnField("published", "boolean", false, false, "false");
  addColumnField("published_at", "datetime", false, false, "");
  addColumnField("tags", "json", false, false, "");
  showToast("Blog template loaded!", "success");
}

function loadProductTemplate() {
  clearColumns();
  document.getElementById("collection-name").value = "products";
  addColumnField("name", "string", true, false, "");
  addColumnField("description", "text", false, false, "");
  addColumnField("price", "float", true, false, "0.0");
  addColumnField("stock", "integer", false, false, "0");
  addColumnField("category", "string", false, false, "");
  addColumnField("is_available", "boolean", false, false, "true");
  addColumnField("images", "json", false, false, "");
  showToast("Product template loaded!", "success");
}

function loadTaskTemplate() {
  clearColumns();
  document.getElementById("collection-name").value = "tasks";
  addColumnField("title", "string", true, false, "");
  addColumnField("description", "text", false, false, "");
  addColumnField("status", "string", false, false, "pending");
  addColumnField("priority", "integer", false, false, "0");
  addColumnField("completed", "boolean", false, false, "false");
  addColumnField("due_date", "datetime", false, false, "");
  addColumnField("assigned_to", "integer", false, false, "");
  showToast("Task template loaded!", "success");
}

function getColumnsFromForm() {
  const columns = [
    {
      name: "id",
      type: "integer",
      primary_key: true,
      auto_increment: true,
      required: false,
      unique: false,
    },
  ];

  const columnFields = document.querySelectorAll(".column-field");
  columnFields.forEach((field) => {
    const name = field.querySelector(".column-name").value.trim();
    const type = field.querySelector(".column-type").value;
    const defaultValue = field.querySelector(".column-default").value.trim();
    const required = field.querySelector(".column-required").checked;
    const unique = field.querySelector(".column-unique").checked;

    if (name) {
      const column = {
        name,
        type,
        required,
        unique,
        primary_key: false,
        auto_increment: false,
      };

      if (defaultValue) {
        // Parse default value based on type
        if (type === "integer") {
          column.default = parseInt(defaultValue);
        } else if (type === "float") {
          column.default = parseFloat(defaultValue);
        } else if (type === "boolean") {
          column.default = defaultValue.toLowerCase() === "true";
        } else {
          column.default = defaultValue;
        }
      }

      columns.push(column);
    }
  });

  return columns;
}

document
  .getElementById("collection-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("collection-name").value.trim();

    if (!name) {
      showToast("Please enter a table name", "error");
      return;
    }

    const columns = getColumnsFromForm();

    if (columns.length === 1) {
      showToast("Please add at least one column besides the ID", "error");
      return;
    }

    try {
      const response = await fetch("/collections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, columns }),
      });

      if (response.ok) {
        showToast(`Table "${name}" created successfully`, "success");
        closeModal("create-collection-modal");
        loadCollections();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error creating table", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

async function deleteCollection(collectionId) {
  const collection = collections.find((c) => c.id === collectionId);
  if (
    !confirm(
      `Delete collection "${collection?.name}"? This will delete all data and cannot be undone.`
    )
  )
    return;

  try {
    const response = await fetch(`/collections/${collectionId}`, {
      method: "DELETE",
    });
    if (response.ok) {
      showToast(`Collection deleted successfully`, "success");
      loadCollections();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting collection", "error");
    }
  } catch (err) {
    showToast("Error deleting collection: " + err.message, "error");
  }
}

// Data Browser
function populateCollectionSelector() {
  const selector = document.getElementById("collection-selector");
  selector.innerHTML = '<option value="">Select a collection...</option>';

  collections.forEach((c) => {
    const option = document.createElement("option");
    option.value = c.id;
    option.textContent = c.name;
    selector.appendChild(option);
  });
}

function selectCollection() {
  const selector = document.getElementById("collection-selector");
  currentCollection = selector.value;

  if (currentCollection) {
    document.getElementById("create-record-btn").disabled = false;
    document.getElementById("refresh-records-btn").disabled = false;
    loadRecords();
  } else {
    document.getElementById("create-record-btn").disabled = true;
    document.getElementById("refresh-records-btn").disabled = true;
    document.getElementById("data-browser").innerHTML = "";
  }
}

function viewCollectionData(collectionId) {
  showTab("data");
  document.getElementById("collection-selector").value = collectionId;
  currentCollection = collectionId;
  document.getElementById("create-record-btn").disabled = false;
  document.getElementById("refresh-records-btn").disabled = false;
  loadRecords();
}

async function loadRecords() {
  if (!currentCollection) return;

  const browser = document.getElementById("data-browser");
  browser.innerHTML = `
    <div class="flex justify-center items-center py-12">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      <p class="ml-4 text-gray-600">Loading records...</p>
    </div>
  `;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents?limit=${settings.recordsPerPage}`
    );
    const data = await response.json();
    currentRecords = data.documents || [];
    renderRecords();
  } catch (err) {
    browser.innerHTML = `<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">Error loading records: ${err.message}</div>`;
  }
}

function renderRecords() {
  const browser = document.getElementById("data-browser");

  if (currentRecords.length === 0) {
    browser.innerHTML = `
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
        </svg>
        <p class="mt-2 text-gray-500">No records yet. Create one to get started!</p>
      </div>
    `;
    return;
  }

  // Get column names from the collection schema
  const collection = collectionsMap[getCurrentCollectionName()];
  const fields =
    collection && collection.columns
      ? collection.columns
          .map((col) => col.name)
          .filter((name) => name !== "id")
      : Object.keys(currentRecords[0] || {}).filter((key) => key !== "id");

  let table = `<div class="overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50"><tr>`;

  if (settings.showRowNumbers) {
    table +=
      '<th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>';
  }

  table +=
    '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>';

  fields.forEach((field) => {
    table += `<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${field}</th>`;
  });

  table +=
    '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th></tr></thead><tbody class="bg-white divide-y divide-gray-200">';

  currentRecords.forEach((record, index) => {
    table += '<tr class="hover:bg-gray-50">';

    if (settings.showRowNumbers) {
      table += `<td class="px-3 py-4 whitespace-nowrap text-sm text-gray-500">${
        index + 1
      }</td>`;
    }

    const recordId = record.id || record.ID || "";
    const displayId =
      recordId.toString().length > 8
        ? recordId.toString().substring(0, 8) + "..."
        : recordId;
    table += `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${displayId}</td>`;

    fields.forEach((field) => {
      const value = record[field];
      let displayValue;

      if (value === null || value === undefined) {
        displayValue = '<span class="text-gray-400 italic">NULL</span>';
      } else if (typeof value === "boolean") {
        displayValue = value
          ? '<span class="px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">true</span>'
          : '<span class="px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">false</span>';
      } else if (typeof value === "object") {
        displayValue = `<code class="text-xs bg-gray-100 px-1 rounded">${JSON.stringify(
          value
        ).substring(0, 30)}...</code>`;
      } else {
        const strValue = String(value);
        displayValue =
          strValue.length > 50 ? strValue.substring(0, 50) + "..." : strValue;
      }

      const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
      table += `<td class="${cellClass} whitespace-nowrap text-sm text-gray-900">${displayValue}</td>`;
    });

    const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
    table += `<td class="${cellClass} whitespace-nowrap text-sm font-medium">
      <div class="flex gap-2">
        <button onclick="viewRecord(${recordId})" class="text-blue-600 hover:text-blue-900">View</button>
        <button onclick="openEditRecordModal(${recordId})" class="text-green-600 hover:text-green-900">Edit</button>
        <button onclick="deleteRecord(${recordId})" class="text-red-600 hover:text-red-900">Delete</button>
      </div>
    </td>`;
    table += "</tr>";
  });

  table += "</tbody></table></div>";

  if (currentRecords.length >= settings.recordsPerPage) {
    table += `<div class="mt-4 text-sm text-gray-500 text-center">
      Showing first ${settings.recordsPerPage} records. Adjust in settings to show more.
    </div>`;
  }

  browser.innerHTML = table;
}

// Record CRUD Operations
function openCreateRecordModal() {
  if (!currentCollection) return;

  document.getElementById("record-modal-title").textContent = "Create Record";
  document.getElementById("record-submit-btn").textContent = "Create";
  document.getElementById("record-submit-btn").className =
    "flex-1 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";

  const collection = collectionsMap[getCurrentCollectionName()];
  if (!collection || !collection.columns) {
    showToast("Error: Collection not found", "error");
    return;
  }

  const container = document.getElementById("record-fields-container");
  container.innerHTML = "";

  // Create form fields for each column (except id)
  collection.columns.forEach((col) => {
    if (col.name === "id") return; // Skip ID field

    const fieldDiv = document.createElement("div");

    let inputHtml = "";
    const requiredAttr = col.required ? "required" : "";
    const uniqueLabel = col.unique
      ? ' <span class="text-xs text-blue-600">(unique)</span>'
      : "";
    const requiredLabel = col.required
      ? ' <span class="text-red-600">*</span>'
      : "";

    switch (col.type) {
      case "boolean":
        inputHtml = `
          <label class="flex items-center space-x-2 mt-2">
            <input type="checkbox" class="record-field rounded text-primary" data-column="${
              col.name
            }" data-type="boolean" ${col.default ? "checked" : ""}>
            <span class="text-sm text-gray-700">${
              col.name
            }${requiredLabel}${uniqueLabel}</span>
          </label>
        `;
        break;

      case "text":
        inputHtml = `
          <label class="block text-sm font-medium text-gray-700 mb-2">
            ${col.name}${requiredLabel}${uniqueLabel}
          </label>
          <textarea 
            class="record-field w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" 
            data-column="${col.name}" 
            data-type="text"
            rows="4"
            placeholder="${col.default || ""}"
            ${requiredAttr}
          ></textarea>
        `;
        break;

      case "integer":
      case "float":
        inputHtml = `
          <label class="block text-sm font-medium text-gray-700 mb-2">
            ${col.name}${requiredLabel}${uniqueLabel}
          </label>
          <input 
            type="number" 
            ${col.type === "float" ? 'step="0.01"' : ""}
            class="record-field w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" 
            data-column="${col.name}" 
            data-type="${col.type}"
            placeholder="${col.default !== undefined ? col.default : ""}"
            ${requiredAttr}
          />
        `;
        break;

      case "datetime":
        inputHtml = `
          <label class="block text-sm font-medium text-gray-700 mb-2">
            ${col.name}${requiredLabel}${uniqueLabel}
          </label>
          <input 
            type="datetime-local" 
            class="record-field w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" 
            data-column="${col.name}" 
            data-type="datetime"
            ${requiredAttr}
          />
        `;
        break;

      case "json":
        inputHtml = `
          <label class="block text-sm font-medium text-gray-700 mb-2">
            ${col.name}${requiredLabel}${uniqueLabel} <span class="text-xs text-gray-500">(JSON)</span>
          </label>
          <textarea 
            class="record-field w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm" 
            data-column="${col.name}" 
            data-type="json"
            rows="3"
            placeholder='{"key": "value"}'
            ${requiredAttr}
          ></textarea>
        `;
        break;

      default: // string
        inputHtml = `
          <label class="block text-sm font-medium text-gray-700 mb-2">
            ${col.name}${requiredLabel}${uniqueLabel}
          </label>
          <input 
            type="text" 
            class="record-field w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" 
            data-column="${col.name}" 
            data-type="string"
            placeholder="${col.default || ""}"
            ${requiredAttr}
          />
        `;
    }

    fieldDiv.innerHTML = inputHtml;
    container.appendChild(fieldDiv);
  });

  // Add a JSON mode toggle
  const jsonModeDiv = document.createElement("div");
  jsonModeDiv.className = "border-t pt-4 mt-4";
  jsonModeDiv.innerHTML = `
    <button 
      type="button" 
      onclick="toggleJSONMode()" 
      class="text-sm text-blue-600 hover:text-blue-700"
    >
      🔄 Switch to JSON mode
    </button>
  `;
  container.appendChild(jsonModeDiv);

  document.getElementById("record-modal").classList.remove("hidden");
  document.getElementById("record-modal").classList.add("flex");
}

function toggleJSONMode() {
  const container = document.getElementById("record-fields-container");

  // Check if we're in form mode or JSON mode
  if (container.querySelector(".record-field")) {
    // Currently in form mode, switch to JSON
    const data = getRecordDataFromFields();
    container.innerHTML = `
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Document Data (JSON)</label>
        <textarea id="document-data" rows="10" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm">${JSON.stringify(
          data,
          null,
          2
        )}</textarea>
        <p class="mt-1 text-xs text-gray-500">Enter valid JSON object</p>
      </div>
      <div class="border-t pt-4 mt-4">
        <button 
          type="button" 
          onclick="toggleJSONMode()" 
          class="text-sm text-blue-600 hover:text-blue-700"
        >
          🔄 Switch to form mode
        </button>
      </div>
    `;
  } else {
    // Currently in JSON mode, switch to form
    openCreateRecordModal();
  }
}

function getRecordDataFromFields() {
  const data = {};
  const fields = document.querySelectorAll(".record-field");

  fields.forEach((field) => {
    const column = field.getAttribute("data-column");
    const type = field.getAttribute("data-type");
    let value;

    switch (type) {
      case "boolean":
        value = field.checked;
        break;
      case "integer":
        value = field.value ? parseInt(field.value) : null;
        break;
      case "float":
        value = field.value ? parseFloat(field.value) : null;
        break;
      case "json":
        try {
          value = field.value ? JSON.parse(field.value) : null;
        } catch (e) {
          value = field.value;
        }
        break;
      default:
        value = field.value || null;
    }

    if (value !== null && value !== "") {
      data[column] = value;
    }
  });

  return data;
}

async function openEditRecordModal(recordId) {
  if (!currentCollection) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`
    );
    const record = await response.json();

    document.getElementById("record-modal-title").textContent = "Edit Document";
    document.getElementById("record-submit-btn").textContent = "Update";
    document.getElementById("record-submit-btn").className =
      "flex-1 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";
    document
      .getElementById("record-submit-btn")
      .setAttribute("data-record-id", recordId);

    const container = document.getElementById("record-fields-container");
    container.innerHTML = `
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Document ID</label>
        <input type="text" value="${
          record.id
        }" disabled class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 font-mono text-sm">
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Document Data (JSON)</label>
        <textarea id="document-data" rows="10" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm">${JSON.stringify(
          record.data,
          null,
          2
        )}</textarea>
        <p class="mt-1 text-xs text-gray-500">Edit the JSON object</p>
      </div>
    `;

    document.getElementById("record-modal").classList.remove("hidden");
    document.getElementById("record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

document
  .getElementById("record-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    let data;

    // Check if we're in JSON mode or form mode
    const dataField = document.getElementById("document-data");
    if (dataField) {
      // JSON mode
      try {
        data = JSON.parse(dataField.value);
      } catch (err) {
        showToast("Invalid JSON: " + err.message, "error");
        return;
      }
    } else {
      // Form mode
      data = getRecordDataFromFields();
    }

    const recordId = document
      .getElementById("record-submit-btn")
      .getAttribute("data-record-id");

    try {
      let response;
      if (recordId) {
        // Update
        response = await fetch(
          `/collections/${currentCollection}/documents/${recordId}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
          }
        );
      } else {
        // Create
        response = await fetch(`/collections/${currentCollection}/documents`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
      }

      if (response.ok) {
        showToast(
          `Document ${recordId ? "updated" : "created"} successfully`,
          "success"
        );
        closeModal("record-modal");
        document
          .getElementById("record-submit-btn")
          .removeAttribute("data-record-id");
        loadRecords();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error saving document", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

async function viewRecord(recordId) {
  if (!currentCollection) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`
    );
    const record = await response.json();

    const content = `
      <div class="space-y-3">
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">ID</div>
          <div class="text-gray-900 font-mono text-sm">${record.id}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Created</div>
          <div class="text-gray-900">${new Date(
            record.created_at
          ).toLocaleString()}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Updated</div>
          <div class="text-gray-900">${new Date(
            record.updated_at
          ).toLocaleString()}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Data</div>
          <pre class="bg-gray-100 p-3 rounded text-xs overflow-auto mt-1">${JSON.stringify(
            record.data,
            null,
            2
          )}</pre>
        </div>
      </div>
    `;

    document.getElementById("view-record-content").innerHTML = content;
    document.getElementById("view-record-modal").classList.remove("hidden");
    document.getElementById("view-record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

async function deleteRecord(recordId) {
  if (!confirm("Delete this document? This cannot be undone.")) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`,
      {
        method: "DELETE",
      }
    );
    if (response.ok) {
      showToast("Document deleted successfully", "success");
      loadRecords();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting document", "error");
    }
  } catch (err) {
    showToast("Error deleting document: " + err.message, "error");
  }
}

// Helper functions
function getCurrentCollectionName() {
  const collection = collections.find((c) => c.id === currentCollection);
  return collection ? collection.name : "";
}

function exportCollections() {
  const dataStr = JSON.stringify(collections, null, 2);
  const dataBlob = new Blob([dataStr], { type: "application/json" });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "collections_backup.json";
  link.click();
  URL.revokeObjectURL(url);
  showToast("Collections exported successfully", "success");
}

// Modal Management
function closeModal(modalId) {
  document.getElementById(modalId).classList.add("hidden");
  document.getElementById(modalId).classList.remove("flex");
}

// Toast Notifications
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  const bgColors = {
    success: "bg-green-500",
    error: "bg-red-500",
    info: "bg-blue-500",
  };

  toast.className = `fixed top-4 right-4 ${bgColors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// ============================================
// SQL Editor
// ============================================

let sqlHistory = [];

// Load SQL history from localStorage on page load
document.addEventListener("DOMContentLoaded", () => {
  const savedHistory = localStorage.getItem("sql_history");
  if (savedHistory) {
    sqlHistory = JSON.parse(savedHistory);
  }

  // Add Ctrl+Enter keyboard shortcut
  document.getElementById("sql-query")?.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      executeSQLQuery();
    }
  });
});

async function executeSQLQuery() {
  const queryInput = document.getElementById("sql-query");
  const query = queryInput.value.trim();

  if (!query) {
    showToast("Please enter a SQL query", "error");
    return;
  }

  const resultsSection = document.getElementById("sql-results");
  const resultsContent = document.getElementById("sql-results-content");

  resultsSection.classList.remove("hidden");
  resultsContent.innerHTML = `
    <div class="flex justify-center items-center py-8">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      <p class="ml-4 text-gray-600">Executing query...</p>
    </div>
  `;

  try {
    const response = await fetch("/sql/execute", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query }),
    });

    const result = await response.json();

    if (result.success) {
      // Add to history
      addToSQLHistory(query, result);

      if (result.type === "select") {
        // Display table results
        renderSQLResults(result);
        showToast(
          `Query executed successfully. ${result.row_count} rows returned.`,
          "success"
        );
      } else {
        // Display write operation result
        resultsContent.innerHTML = `
          <div class="bg-green-50 border border-green-400 text-green-800 px-4 py-3 rounded">
            <p class="font-semibold">✅ ${result.message}</p>
            <p class="text-sm mt-1">Affected rows: ${result.affected_rows}</p>
          </div>
        `;
        showToast("Query executed successfully", "success");

        // Refresh collections if table structure changed
        if (
          query.toLowerCase().includes("create") ||
          query.toLowerCase().includes("drop") ||
          query.toLowerCase().includes("alter")
        ) {
          loadCollections();
        }
      }
    } else {
      // Display error
      resultsContent.innerHTML = `
        <div class="bg-red-50 border border-red-400 text-red-800 px-4 py-3 rounded">
          <p class="font-semibold">❌ SQL Error</p>
          <pre class="text-sm mt-2 whitespace-pre-wrap font-mono">${result.error}</pre>
        </div>
      `;
      showToast("Query failed", "error");
    }
  } catch (err) {
    resultsContent.innerHTML = `
      <div class="bg-red-50 border border-red-400 text-red-800 px-4 py-3 rounded">
        <p class="font-semibold">❌ Network Error</p>
        <p class="text-sm mt-2">${err.message}</p>
      </div>
    `;
    showToast("Error executing query: " + err.message, "error");
  }
}

function renderSQLResults(result) {
  const resultsContent = document.getElementById("sql-results-content");

  if (result.rows.length === 0) {
    resultsContent.innerHTML = `
      <div class="bg-blue-50 border border-blue-400 text-blue-800 px-4 py-3 rounded">
        <p>✅ Query executed successfully. No rows returned.</p>
      </div>
    `;
    return;
  }

  let html = `
    <div class="mb-2 text-sm text-gray-600">
      ${result.row_count} row${result.row_count !== 1 ? "s" : ""} returned
    </div>
    <div class="overflow-x-auto border border-gray-300 rounded-lg">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
  `;

  // Table headers
  result.columns.forEach((col) => {
    html += `<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${col}</th>`;
  });

  html += `
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
  `;

  // Table rows
  result.rows.forEach((row, index) => {
    html += `<tr class="${
      index % 2 === 0 ? "bg-white" : "bg-gray-50"
    } hover:bg-blue-50">`;

    result.columns.forEach((col) => {
      const value = row[col];
      let displayValue;

      if (value === null || value === undefined) {
        displayValue = '<span class="text-gray-400 italic">NULL</span>';
      } else if (typeof value === "boolean") {
        displayValue = value
          ? '<span class="px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">true</span>'
          : '<span class="px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">false</span>';
      } else if (typeof value === "object") {
        displayValue = `<code class="text-xs bg-gray-100 px-1 py-0.5 rounded">${JSON.stringify(
          value
        )}</code>`;
      } else {
        const strValue = String(value);
        displayValue =
          strValue.length > 100 ? strValue.substring(0, 100) + "..." : strValue;
      }

      html += `<td class="px-4 py-3 text-sm text-gray-900">${displayValue}</td>`;
    });

    html += `</tr>`;
  });

  html += `
        </tbody>
      </table>
    </div>
  `;

  resultsContent.innerHTML = html;
}

function insertTemplate(template) {
  const queryInput = document.getElementById("sql-query");
  queryInput.value = template;
  queryInput.focus();
}

function clearSQLEditor() {
  document.getElementById("sql-query").value = "";
  document.getElementById("sql-results").classList.add("hidden");
}

function addToSQLHistory(query, result) {
  const historyItem = {
    query,
    timestamp: new Date().toISOString(),
    success: result.success,
    type: result.type,
    rowCount: result.row_count || result.affected_rows || 0,
  };

  sqlHistory.unshift(historyItem); // Add to beginning

  // Keep only last 20 queries
  if (sqlHistory.length > 20) {
    sqlHistory = sqlHistory.slice(0, 20);
  }

  // Save to localStorage
  localStorage.setItem("sql_history", JSON.stringify(sqlHistory));

  // Render history
  renderSQLHistory();
}

function renderSQLHistory() {
  const historySection = document.getElementById("sql-history-section");
  const historyContainer = document.getElementById("sql-history");

  if (sqlHistory.length === 0) {
    historySection.classList.add("hidden");
    return;
  }

  historySection.classList.remove("hidden");
  historyContainer.innerHTML = "";

  sqlHistory.forEach((item, index) => {
    const div = document.createElement("div");
    div.className =
      "border border-gray-200 rounded p-3 bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer";

    const statusIcon = item.success ? "✅" : "❌";
    const statusColor = item.success ? "text-green-600" : "text-red-600";

    div.innerHTML = `
      <div class="flex justify-between items-start mb-1">
        <span class="${statusColor} text-sm font-semibold">${statusIcon} ${item.type.toUpperCase()}</span>
        <span class="text-xs text-gray-500">${new Date(
          item.timestamp
        ).toLocaleString()}</span>
      </div>
      <code class="text-xs text-gray-700 block break-words">${item.query.substring(
        0,
        100
      )}${item.query.length > 100 ? "..." : ""}</code>
      <div class="text-xs text-gray-500 mt-1">
        ${
          item.type === "select"
            ? `${item.rowCount} rows`
            : `${item.rowCount} rows affected`
        }
      </div>
    `;

    div.onclick = () => {
      document.getElementById("sql-query").value = item.query;
      showToast("Query loaded from history", "info");
    };

    historyContainer.appendChild(div);
  });
}

function clearSQLHistory() {
  if (!confirm("Clear all SQL query history?")) return;

  sqlHistory = [];
  localStorage.removeItem("sql_history");
  renderSQLHistory();
  showToast("Query history cleared", "success");
}

// Initialize history display
document.addEventListener("DOMContentLoaded", () => {
  renderSQLHistory();
});

// ============================================
// Edit Columns Management
// ============================================

let currentEditingCollection = null;

async function openEditColumnsModal(collectionName) {
  currentEditingCollection = collectionName;

  document.getElementById("edit-collection-name").textContent = collectionName;
  document.getElementById("edit-columns-modal").classList.remove("hidden");
  document.getElementById("edit-columns-modal").classList.add("flex");

  // Load columns
  try {
    const response = await fetch(`/collections/${collectionName}/columns`);
    const data = await response.json();

    renderEditableColumns(data.columns);
  } catch (err) {
    showToast("Error loading columns: " + err.message, "error");
  }
}

function renderEditableColumns(columns) {
  const container = document.getElementById("edit-columns-list");
  container.innerHTML = "";

  columns.forEach((col, index) => {
    const colDiv = document.createElement("div");
    colDiv.className = "border border-gray-200 rounded-lg p-4 bg-white";

    const isPrimaryKey = col.primary_key;
    const isBuiltIn = currentEditingCollection === "users" || isPrimaryKey;

    colDiv.innerHTML = `
      <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
        <div class="md:col-span-3">
          <label class="block text-xs font-medium text-gray-600 mb-1">Column Name</label>
          <input
            type="text"
            value="${col.name}"
            ${isBuiltIn ? "readonly" : ""}
            data-original-name="${col.name}"
            class="column-edit-name w-full px-3 py-2 border border-gray-300 rounded text-sm ${
              isBuiltIn ? "bg-gray-50" : "focus:ring-2 focus:ring-primary"
            }"
          />
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs font-medium text-gray-600 mb-1">Type</label>
          <select ${
            isBuiltIn ? "disabled" : ""
          } class="column-edit-type w-full px-3 py-2 border border-gray-300 rounded text-sm bg-gray-50">
            <option value="string" ${
              col.type === "string" ? "selected" : ""
            }>String</option>
            <option value="text" ${
              col.type === "text" ? "selected" : ""
            }>Text</option>
            <option value="integer" ${
              col.type === "integer" ? "selected" : ""
            }>Integer</option>
            <option value="float" ${
              col.type === "float" ? "selected" : ""
            }>Float</option>
            <option value="boolean" ${
              col.type === "boolean" ? "selected" : ""
            }>Boolean</option>
            <option value="datetime" ${
              col.type === "datetime" ? "selected" : ""
            }>DateTime</option>
            <option value="json" ${
              col.type === "json" ? "selected" : ""
            }>JSON</option>
            <option value="file" ${
              col.type === "file" ? "selected" : ""
            }>File</option>
          </select>
        </div>
        <div class="md:col-span-2">
          <label class="block text-xs font-medium text-gray-600 mb-1">Default</label>
          <input
            type="text"
            value="${col.default || ""}"
            ${isBuiltIn ? "readonly" : ""}
            class="column-edit-default w-full px-3 py-2 border border-gray-300 rounded text-sm ${
              isBuiltIn ? "bg-gray-50" : "focus:ring-2 focus:ring-primary"
            }"
          />
        </div>
        <div class="md:col-span-3 flex gap-2 items-end flex-wrap">
          ${
            col.primary_key
              ? '<span class="px-2 py-1 text-xs font-semibold text-blue-700 bg-blue-100 rounded">Primary Key</span>'
              : ""
          }
          ${
            col.auto_increment
              ? '<span class="px-2 py-1 text-xs font-semibold text-purple-700 bg-purple-100 rounded">Auto Inc</span>'
              : ""
          }
          ${
            col.required
              ? '<span class="px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">Required</span>'
              : ""
          }
          ${
            col.unique
              ? '<span class="px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">Unique</span>'
              : ""
          }
        </div>
        <div class="md:col-span-2 flex items-end justify-end gap-2">
          ${
            !isBuiltIn
              ? `
            <button
              type="button"
              onclick="saveColumnEdit('${col.name}')"
              class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded text-sm transition-colors"
              title="Save changes"
            >
              💾
            </button>
            <button
              type="button"
              onclick="deleteColumnFromTable('${col.name}')"
              class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors"
              title="Delete column"
            >
              🗑️
            </button>
          `
              : `
            <span class="text-xs text-gray-500 italic">Protected</span>
          `
          }
        </div>
      </div>
    `;

    container.appendChild(colDiv);
  });
}

async function saveColumnEdit(originalName) {
  const colDiv = Array.from(document.querySelectorAll(".column-edit-name"))
    .find((input) => input.dataset.originalName === originalName)
    ?.closest(".border");

  if (!colDiv) return;

  const newName = colDiv.querySelector(".column-edit-name").value;
  const type = colDiv.querySelector(".column-edit-type").value;
  const defaultValue = colDiv.querySelector(".column-edit-default").value;

  if (!newName) {
    showToast("Column name cannot be empty", "error");
    return;
  }

  try {
    const response = await fetch(
      `/collections/${currentEditingCollection}/columns/${originalName}`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newName,
          type: type,
          default: defaultValue || null,
          primary_key: false,
          auto_increment: false,
          required: false,
          unique: false,
        }),
      }
    );

    if (response.ok) {
      showToast("Column updated successfully", "success");
      openEditColumnsModal(currentEditingCollection); // Reload
      loadCollections(); // Refresh collections list
    } else {
      const error = await response.json();
      showToast(error.detail || "Error updating column", "error");
    }
  } catch (err) {
    showToast("Error: " + err.message, "error");
  }
}

async function deleteColumnFromTable(columnName) {
  if (
    !confirm(
      `Delete column "${columnName}"? This cannot be undone and all data in this column will be lost.`
    )
  ) {
    return;
  }

  try {
    const response = await fetch(
      `/collections/${currentEditingCollection}/columns/${columnName}`,
      {
        method: "DELETE",
      }
    );

    if (response.ok) {
      showToast("Column deleted successfully", "success");
      openEditColumnsModal(currentEditingCollection); // Reload
      loadCollections(); // Refresh collections list
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting column", "error");
    }
  } catch (err) {
    showToast("Error: " + err.message, "error");
  }
}

function showAddColumnForm() {
  closeModal("edit-columns-modal");
  document.getElementById("add-column-modal").classList.remove("hidden");
  document.getElementById("add-column-modal").classList.add("flex");

  // Reset form
  document.getElementById("new-column-name").value = "";
  document.getElementById("new-column-type").value = "string";
  document.getElementById("new-column-default").value = "";
  document.getElementById("new-column-required").checked = false;
  document.getElementById("new-column-unique").checked = false;
}

document
  .getElementById("add-column-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const columnData = {
      name: document.getElementById("new-column-name").value,
      type: document.getElementById("new-column-type").value,
      default: document.getElementById("new-column-default").value || null,
      required: document.getElementById("new-column-required").checked,
      unique: document.getElementById("new-column-unique").checked,
      primary_key: false,
      auto_increment: false,
    };

    try {
      const response = await fetch(
        `/collections/${currentEditingCollection}/add-column`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(columnData),
        }
      );

      if (response.ok) {
        showToast("Column added successfully", "success");
        closeModal("add-column-modal");
        openEditColumnsModal(currentEditingCollection); // Reload edit modal
        loadCollections(); // Refresh collections list
      } else {
        const error = await response.json();
        showToast(error.detail || "Error adding column", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });
