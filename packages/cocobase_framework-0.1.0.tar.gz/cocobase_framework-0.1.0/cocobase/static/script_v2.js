// Global state
let collections = [];
let collectionsMap = {}; // name -> collection object
let currentCollection = null;
let currentRecords = [];
let settings = {
  compactView: false,
  showRowNumbers: false,
  recordsPerPage: 50,
};

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadCollections();
  loadSettings();
  loadDatabaseInfo();
  showTab("collections");
});

// Tab Management
function showTab(tabName) {
  document.querySelectorAll(".tab-content").forEach((tab) => {
    tab.classList.add("hidden");
  });
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.remove("border-primary", "text-primary", "font-semibold");
    btn.classList.add("border-transparent", "text-gray-600");
  });

  document.getElementById(`${tabName}-tab`).classList.remove("hidden");
  const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
  if (activeBtn) {
    activeBtn.classList.remove("border-transparent", "text-gray-600");
    activeBtn.classList.add("border-primary", "text-primary", "font-semibold");
  }

  if (tabName === "data") {
    populateCollectionSelector();
  }
}

// Settings Management
function loadSettings() {
  const saved = localStorage.getItem("cocobase_settings");
  if (saved) {
    settings = { ...settings, ...JSON.parse(saved) };
    document.getElementById("compact-view").checked = settings.compactView;
    document.getElementById("show-row-numbers").checked =
      settings.showRowNumbers;
    document.getElementById("records-per-page").value = settings.recordsPerPage;
  }
}

function saveSettings() {
  localStorage.setItem("cocobase_settings", JSON.stringify(settings));
}

function toggleCompactView() {
  settings.compactView = document.getElementById("compact-view").checked;
  saveSettings();
  if (currentCollection) renderRecords();
}

function toggleRowNumbers() {
  settings.showRowNumbers = document.getElementById("show-row-numbers").checked;
  saveSettings();
  if (currentCollection) renderRecords();
}

function updateRecordsPerPage() {
  settings.recordsPerPage = parseInt(
    document.getElementById("records-per-page").value
  );
  saveSettings();
  if (currentCollection) loadRecords();
}

async function loadDatabaseInfo() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    document.getElementById("db-url").textContent =
      data.database || "sqlite:///cocobase.db";
  } catch (err) {
    document.getElementById("db-url").textContent =
      "Error loading database info";
  }
}

// Load Collections
async function loadCollections() {
  try {
    const response = await fetch("/collections");
    collections = await response.json();

    // Build map for easy lookup
    collectionsMap = {};
    collections.forEach((c) => {
      collectionsMap[c.name] = c;
    });

    renderCollectionsList();
    populateCollectionSelector();
  } catch (err) {
    showToast("Error loading collections: " + err.message, "error");
  }
}

// Render Collections List
function renderCollectionsList() {
  const listEl = document.getElementById("collections-list");
  listEl.innerHTML = "";

  if (collections.length === 0) {
    listEl.innerHTML = `
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
        </svg>
        <p class="mt-2 text-gray-500">No collections yet. Create one to get started!</p>
      </div>
    `;
    return;
  }

  const grid = document.createElement("div");
  grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4";

  collections.forEach((collection) => {
    const card = document.createElement("div");
    card.className =
      "border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-white";

    const schemaFields = collection.schema_
      ? Object.keys(collection.schema_).length
      : 0;

    card.innerHTML = `
      <div class="flex justify-between items-start mb-3">
        <h3 class="text-lg font-semibold text-gray-800">${collection.name}</h3>
        <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">${schemaFields} fields</span>
      </div>
      <div class="text-xs text-gray-500 mb-3">
        ID: ${collection.id}<br>
        Created: ${new Date(collection.created_at).toLocaleDateString()}
      </div>
      <div class="flex gap-2 mt-4">
        <button onclick="viewCollectionData('${
          collection.id
        }')" class="flex-1 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded text-sm transition-colors">
          📊 View Data
        </button>
        <button onclick="deleteCollection('${
          collection.id
        }')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded text-sm transition-colors">
          🗑️
        </button>
      </div>
    `;
    grid.appendChild(card);
  });

  listEl.appendChild(grid);
}

// Collection Management
function openCreateCollectionModal() {
  document.getElementById("create-collection-modal").classList.remove("hidden");
  document.getElementById("create-collection-modal").classList.add("flex");
  document.getElementById("collection-name").value = "";
}

document
  .getElementById("collection-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("collection-name").value;

    try {
      const response = await fetch("/collections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });

      if (response.ok) {
        showToast(`Collection "${name}" created successfully`, "success");
        closeModal("create-collection-modal");
        loadCollections();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error creating collection", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

async function deleteCollection(collectionId) {
  const collection = collections.find((c) => c.id === collectionId);
  if (
    !confirm(
      `Delete collection "${collection?.name}"? This will delete all data and cannot be undone.`
    )
  )
    return;

  try {
    const response = await fetch(`/collections/${collectionId}`, {
      method: "DELETE",
    });
    if (response.ok) {
      showToast(`Collection deleted successfully`, "success");
      loadCollections();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting collection", "error");
    }
  } catch (err) {
    showToast("Error deleting collection: " + err.message, "error");
  }
}

// Data Browser
function populateCollectionSelector() {
  const selector = document.getElementById("collection-selector");
  selector.innerHTML = '<option value="">Select a collection...</option>';

  collections.forEach((c) => {
    const option = document.createElement("option");
    option.value = c.id;
    option.textContent = c.name;
    selector.appendChild(option);
  });
}

function selectCollection() {
  const selector = document.getElementById("collection-selector");
  currentCollection = selector.value;

  if (currentCollection) {
    document.getElementById("create-record-btn").disabled = false;
    document.getElementById("refresh-records-btn").disabled = false;
    loadRecords();
  } else {
    document.getElementById("create-record-btn").disabled = true;
    document.getElementById("refresh-records-btn").disabled = true;
    document.getElementById("data-browser").innerHTML = "";
  }
}

function viewCollectionData(collectionId) {
  showTab("data");
  document.getElementById("collection-selector").value = collectionId;
  currentCollection = collectionId;
  document.getElementById("create-record-btn").disabled = false;
  document.getElementById("refresh-records-btn").disabled = false;
  loadRecords();
}

async function loadRecords() {
  if (!currentCollection) return;

  const browser = document.getElementById("data-browser");
  browser.innerHTML = `
    <div class="flex justify-center items-center py-12">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      <p class="ml-4 text-gray-600">Loading records...</p>
    </div>
  `;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents?limit=${settings.recordsPerPage}`
    );
    const data = await response.json();
    currentRecords = data.documents || [];
    renderRecords();
  } catch (err) {
    browser.innerHTML = `<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">Error loading records: ${err.message}</div>`;
  }
}

function renderRecords() {
  const browser = document.getElementById("data-browser");

  if (currentRecords.length === 0) {
    browser.innerHTML = `
      <div class="text-center py-12">
        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
        </svg>
        <p class="mt-2 text-gray-500">No records yet. Create one to get started!</p>
      </div>
    `;
    return;
  }

  // Get all unique keys from documents
  const allKeys = new Set();
  currentRecords.forEach((record) => {
    Object.keys(record.data || {}).forEach((key) => allKeys.add(key));
  });
  const fields = Array.from(allKeys);

  let table = `<div class="overflow-x-auto">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50"><tr>`;

  if (settings.showRowNumbers) {
    table +=
      '<th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>';
  }

  table +=
    '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>';

  fields.forEach((field) => {
    table += `<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${field}</th>`;
  });

  table +=
    '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th></tr></thead><tbody class="bg-white divide-y divide-gray-200">';

  currentRecords.forEach((record, index) => {
    table += '<tr class="hover:bg-gray-50">';

    if (settings.showRowNumbers) {
      table += `<td class="px-3 py-4 whitespace-nowrap text-sm text-gray-500">${
        index + 1
      }</td>`;
    }

    table += `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${record.id.substring(
      0,
      8
    )}...</td>`;

    fields.forEach((field) => {
      const value = record.data?.[field];
      let displayValue;

      if (value === null || value === undefined) {
        displayValue = '<span class="text-gray-400 italic">NULL</span>';
      } else if (typeof value === "boolean") {
        displayValue = value
          ? '<span class="px-2 py-1 text-xs font-semibold text-green-700 bg-green-100 rounded">true</span>'
          : '<span class="px-2 py-1 text-xs font-semibold text-red-700 bg-red-100 rounded">false</span>';
      } else if (typeof value === "object") {
        displayValue = `<code class="text-xs">${JSON.stringify(value).substring(
          0,
          30
        )}...</code>`;
      } else {
        const strValue = String(value);
        displayValue =
          strValue.length > 50 ? strValue.substring(0, 50) + "..." : strValue;
      }

      const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
      table += `<td class="${cellClass} whitespace-nowrap text-sm text-gray-900">${displayValue}</td>`;
    });

    const cellClass = settings.compactView ? "px-3 py-2" : "px-6 py-4";
    table += `<td class="${cellClass} whitespace-nowrap text-sm font-medium">
      <div class="flex gap-2">
        <button onclick="viewRecord('${record.id}')" class="text-blue-600 hover:text-blue-900">View</button>
        <button onclick="openEditRecordModal('${record.id}')" class="text-green-600 hover:text-green-900">Edit</button>
        <button onclick="deleteRecord('${record.id}')" class="text-red-600 hover:text-red-900">Delete</button>
      </div>
    </td>`;
    table += "</tr>";
  });

  table += "</tbody></table></div>";

  if (currentRecords.length >= settings.recordsPerPage) {
    table += `<div class="mt-4 text-sm text-gray-500 text-center">
      Showing first ${settings.recordsPerPage} records. Adjust in settings to show more.
    </div>`;
  }

  browser.innerHTML = table;
}

// Record CRUD Operations
function openCreateRecordModal() {
  if (!currentCollection) return;

  document.getElementById("record-modal-title").textContent = "Create Document";
  document.getElementById("record-submit-btn").textContent = "Create";
  document.getElementById("record-submit-btn").className =
    "flex-1 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";

  const container = document.getElementById("record-fields-container");
  container.innerHTML = `
    <div>
      <label class="block text-sm font-medium text-gray-700 mb-2">Document Data (JSON)</label>
      <textarea id="document-data" rows="10" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm" placeholder='{\n  "name": "John Doe",\n  "email": "john@example.com",\n  "age": 30\n}'></textarea>
      <p class="mt-1 text-xs text-gray-500">Enter valid JSON object</p>
    </div>
  `;

  document.getElementById("record-modal").classList.remove("hidden");
  document.getElementById("record-modal").classList.add("flex");
}

async function openEditRecordModal(recordId) {
  if (!currentCollection) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`
    );
    const record = await response.json();

    document.getElementById("record-modal-title").textContent = "Edit Document";
    document.getElementById("record-submit-btn").textContent = "Update";
    document.getElementById("record-submit-btn").className =
      "flex-1 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors";
    document
      .getElementById("record-submit-btn")
      .setAttribute("data-record-id", recordId);

    const container = document.getElementById("record-fields-container");
    container.innerHTML = `
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Document ID</label>
        <input type="text" value="${
          record.id
        }" disabled class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 font-mono text-sm">
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">Document Data (JSON)</label>
        <textarea id="document-data" rows="10" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent font-mono text-sm">${JSON.stringify(
          record.data,
          null,
          2
        )}</textarea>
        <p class="mt-1 text-xs text-gray-500">Edit the JSON object</p>
      </div>
    `;

    document.getElementById("record-modal").classList.remove("hidden");
    document.getElementById("record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

document
  .getElementById("record-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const dataField = document.getElementById("document-data");
    let data;

    try {
      data = JSON.parse(dataField.value);
    } catch (err) {
      showToast("Invalid JSON: " + err.message, "error");
      return;
    }

    const recordId = document
      .getElementById("record-submit-btn")
      .getAttribute("data-record-id");

    try {
      let response;
      if (recordId) {
        // Update
        response = await fetch(
          `/collections/${currentCollection}/documents/${recordId}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ data }),
          }
        );
      } else {
        // Create
        response = await fetch(
          `/collections/documents?collection=${getCurrentCollectionName()}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ data }),
          }
        );
      }

      if (response.ok) {
        showToast(
          `Document ${recordId ? "updated" : "created"} successfully`,
          "success"
        );
        closeModal("record-modal");
        document
          .getElementById("record-submit-btn")
          .removeAttribute("data-record-id");
        loadRecords();
      } else {
        const error = await response.json();
        showToast(error.detail || "Error saving document", "error");
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
    }
  });

async function viewRecord(recordId) {
  if (!currentCollection) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`
    );
    const record = await response.json();

    const content = `
      <div class="space-y-3">
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">ID</div>
          <div class="text-gray-900 font-mono text-sm">${record.id}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Created</div>
          <div class="text-gray-900">${new Date(
            record.created_at
          ).toLocaleString()}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Updated</div>
          <div class="text-gray-900">${new Date(
            record.updated_at
          ).toLocaleString()}</div>
        </div>
        <div class="border-b border-gray-200 pb-2">
          <div class="text-sm font-semibold text-gray-600">Data</div>
          <pre class="bg-gray-100 p-3 rounded text-xs overflow-auto mt-1">${JSON.stringify(
            record.data,
            null,
            2
          )}</pre>
        </div>
      </div>
    `;

    document.getElementById("view-record-content").innerHTML = content;
    document.getElementById("view-record-modal").classList.remove("hidden");
    document.getElementById("view-record-modal").classList.add("flex");
  } catch (err) {
    showToast("Error loading record: " + err.message, "error");
  }
}

async function deleteRecord(recordId) {
  if (!confirm("Delete this document? This cannot be undone.")) return;

  try {
    const response = await fetch(
      `/collections/${currentCollection}/documents/${recordId}`,
      {
        method: "DELETE",
      }
    );
    if (response.ok) {
      showToast("Document deleted successfully", "success");
      loadRecords();
    } else {
      const error = await response.json();
      showToast(error.detail || "Error deleting document", "error");
    }
  } catch (err) {
    showToast("Error deleting document: " + err.message, "error");
  }
}

// Helper functions
function getCurrentCollectionName() {
  const collection = collections.find((c) => c.id === currentCollection);
  return collection ? collection.name : "";
}

function exportCollections() {
  const dataStr = JSON.stringify(collections, null, 2);
  const dataBlob = new Blob([dataStr], { type: "application/json" });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "collections_backup.json";
  link.click();
  URL.revokeObjectURL(url);
  showToast("Collections exported successfully", "success");
}

// Modal Management
function closeModal(modalId) {
  document.getElementById(modalId).classList.add("hidden");
  document.getElementById(modalId).classList.remove("flex");
}

// Toast Notifications
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  const bgColors = {
    success: "bg-green-500",
    error: "bg-red-500",
    info: "bg-blue-500",
  };

  toast.className = `fixed top-4 right-4 ${bgColors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}
