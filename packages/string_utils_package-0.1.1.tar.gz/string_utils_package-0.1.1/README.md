# String Utilities

A collection of useful string manipulation and validation functions.

## Installation

```bash
pip install string-utils-package
```

## Usage

```python
from string_utils import reverse_string, is_palindrome, slugify

# Reverse a string
print(reverse_string("hello"))  # Output: "olleh"

# Check if palindrome
print(is_palindrome("radar"))   # Output: True

# Create slug
print(slugify("Hello World!"))  # Output: "hello-world"
```

## Available Functions

### Core Functions
- `reverse_string(text)`: Reverse a string
- `capitalize_words(text)`: Capitalize each word
- `slugify(text)`: Convert to URL-friendly slug

### Validation Functions  
- `is_palindrome(text)`: Check if string is palindrome
- `is_strong_password(password)`: Validate password strength

## License

MIT License - see LICENSE file for details.