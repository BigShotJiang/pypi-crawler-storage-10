import pytest
from string_utils.core import reverse_string, capitalize_words, slugify


class TestCoreFunctions:
    def test_reverse_string(self):
        assert reverse_string("hello") == "olleh"
        assert reverse_string("Python") == "nohtyP"
        assert reverse_string("") == ""
        assert reverse_string("a") == "a"
        assert reverse_string("12345") == "54321"

    def test_capitalize_words(self):
        assert capitalize_words("hello world") == "Hello World"
        assert capitalize_words("python programming") == "Python Programming"
        assert capitalize_words("multiple   spaces") == "Multiple   Spaces"  # 修复这个测试
        assert capitalize_words("  leading spaces") == "  Leading Spaces"
        assert capitalize_words("trailing spaces  ") == "Trailing Spaces  "
        assert capitalize_words("") == ""
        assert capitalize_words("single") == "Single"
        assert capitalize_words("UPPERCASE") == "Uppercase"
        assert capitalize_words("lowercase") == "Lowercase"
        assert capitalize_words("MiXeD cAsE") == "Mixed Case"

    def test_slugify(self):
        assert slugify("Hello World!") == "hello-world"
        assert slugify("Python & Django") == "python-django"
        assert slugify("Test with  spaces") == "test-with-spaces"
        assert slugify("UPPERCASE") == "uppercase"
        assert slugify("--dashes--") == "dashes"  # 修复这个测试
        assert slugify("multiple---dashes") == "multiple-dashes"
        assert slugify("  leading and trailing  ") == "leading-and-trailing"
        assert slugify("") == ""
        assert slugify("--") == ""
        assert slugify("already-slug") == "already-slug"
        assert slugify("UPPER case Mixed") == "upper-case-mixed"
        assert slugify("special!@#$%chars") == "specialchars"
        assert slugify("accentéd characters") == "accented-characters"