import pytest
from string_utils.validation import is_palindrome, is_strong_password


class TestValidationFunctions:
    def test_is_palindrome(self):
        assert is_palindrome("radar") == True
        assert is_palindrome("A man a plan a canal Panama") == True
        assert is_palindrome("hello") == False
        assert is_palindrome("Racecar", case_sensitive=False) == True

    def test_is_strong_password(self):
        assert is_strong_password("Weak123") == False
        assert is_strong_password("StrongPass123!") == True
        assert is_strong_password("Short1!") == False
        assert is_strong_password("nouppercase123!") == False
        assert is_strong_password("NOLOWERCASE123!") == False