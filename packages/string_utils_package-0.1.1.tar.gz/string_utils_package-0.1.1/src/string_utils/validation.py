"""
String validation functions.
"""

import re


def is_palindrome(text: str, case_sensitive: bool = False) -> bool:
    """
    Check if a string is a palindrome.

    Args:
        text: String to check
        case_sensitive: Whether to consider case (default: False)

    Returns:
        True if the string is a palindrome

    Examples:
        >>> is_palindrome("radar")
        True
        >>> is_palindrome("A man a plan a canal Panama")
        True
        >>> is_palindrome("hello")
        False
    """
    # Remove spaces and punctuation, keep only alphanumeric
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', text)

    if not case_sensitive:
        cleaned = cleaned.lower()

    return cleaned == cleaned[::-1]


def is_strong_password(password: str, min_length: int = 8) -> bool:
    """
    Check if a password is strong.

    Criteria:
    - At least min_length characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character

    Args:
        password: Password to validate
        min_length: Minimum password length (default: 8)

    Returns:
        True if password meets all criteria

    Examples:
        >>> is_strong_password("Weak123")
        False
        >>> is_strong_password("StrongPass123!")
        True
    """
    if len(password) < min_length:
        return False

    # Check for required character types
    has_upper = re.search(r'[A-Z]', password)
    has_lower = re.search(r'[a-z]', password)
    has_digit = re.search(r'\d', password)
    has_special = re.search(r'[!@#$%^&*(),.?":{}|<>]', password)

    return all([has_upper, has_lower, has_digit, has_special])