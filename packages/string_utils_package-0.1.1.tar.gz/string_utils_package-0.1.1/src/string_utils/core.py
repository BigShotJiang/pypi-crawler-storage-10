"""
Core string manipulation functions.
"""

import re
import unicodedata

def reverse_string(text: str) -> str:
    """
    Reverse a string.

    Args:
        text: Input string to reverse

    Returns:
        Reversed string

    Examples:
        >>> reverse_string("hello")
        'olleh'
        >>> reverse_string("Python")
        'nohtyP'
    """
    return text[::-1]

def capitalize_words(text: str) -> str:
    """
    Capitalize the first letter of each word in a string.

    Args:
        text: Input string

    Returns:
        String with each word capitalized

    Examples:
        >>> capitalize_words("hello world")
        'Hello World'
        >>> capitalize_words("python programming")
        'Python Programming'
        >>> capitalize_words("multiple   spaces")
        'Multiple   Spaces'
    """
    # 修复：使用正则表达式来分割单词，保留所有空格
    words = re.split(r'(\s+)', text)  # 按空白字符分割，但保留分隔符
    result = []

    for word in words:
        if word and not word.isspace():  # 如果是非空白字符
            result.append(word.capitalize())
        else:  # 如果是空白字符（空格、制表符等）
            result.append(word)

    return ''.join(result)


def slugify(text: str, separator: str = '-') -> str:
    """
    Convert a string to a URL-friendly slug.

    Args:
        text: Input string
        separator: Word separator (default: '-')

    Returns:
        URL-friendly slug

    Examples:
        >>> slugify("Hello World!")
        'hello-world'
        >>> slugify("Python & Django")
        'python-django'
        >>> slugify("--dashes--")
        'dashes'
        >>> slugify("multiple---dashes")
        'multiple-dashes'
    """
    # Normalize unicode characters
    text = unicodedata.normalize('NFKD', text)

    # Convert to lowercase and remove special characters
    text = re.sub(r'[^\w\s-]', '', text.lower())

    # Replace whitespace and multiple dashes with single separator
    text = re.sub(r'[-\s]+', separator, text.strip())

    # 修复：去除开头和结尾的分隔符
    if text.startswith(separator):
        text = text[len(separator):]
    if text.endswith(separator):
        text = text[:-len(separator)]

    return text