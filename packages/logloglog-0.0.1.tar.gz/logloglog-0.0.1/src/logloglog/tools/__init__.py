"""Tools subpackage for logloglog utilities."""
