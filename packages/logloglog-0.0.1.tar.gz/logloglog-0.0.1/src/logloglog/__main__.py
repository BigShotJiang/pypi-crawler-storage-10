"""
Entry point for the package
"""

from .program import run_program

if __name__ == "__main__":
    run_program()
