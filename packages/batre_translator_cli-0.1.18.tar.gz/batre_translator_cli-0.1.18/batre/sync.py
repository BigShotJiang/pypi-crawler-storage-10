#!/usr/bin/env python3
import os
import sys
import json
import base64
import requests
import yaml
from batre.aggregate import aggregate
from batre.utils import update_repo
from rich import print
from rich.console import Console
from rich.traceback import install

install()
console = Console()


def _print_error_response(r):
    """Show concise, human-friendly error info instead of HTML garbage."""
    ct = (r.headers.get("content-type") or "").lower()

    console.print(
        f"[red]❌ Upload failed[/red] "
        f"([bold]{r.status_code} {r.reason}[/bold]) • "
        f"[dim]{r.request.method} {r.request.url}[/dim]"
    )

    if "application/json" in ct:
        try:
            console.print(json.dumps(r.json(), indent=2, ensure_ascii=False))
            return
        except Exception:
            pass

    if "text/html" in ct or r.text.strip().startswith("<!DOCTYPE html"):
        console.print("[dim]Server returned HTML error page — hidden.[/dim]")
        return

    text = (r.text or "").strip().replace("\n", " ")
    if text:
        snippet = text[:300] + ("…" if len(text) > 300 else "")
        console.print(f"[dim]{snippet}[/dim]")
    else:
        console.print("[dim]No response body[/dim]")


def upload_file(api_url, token, project_id, output_path, language):
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    if not os.path.exists(output_path):
        console.print(f"[red]❌ File not found:[/red] {output_path}")
        raise SystemExit(1)

    with open(output_path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode("utf-8")

    payload = {
        "project_id": project_id,
        "language": language,
        "payload_base64": encoded,
    }

    url = f"{api_url.rstrip('/')}/translations/upload"
    console.print(f"[cyan]🌍 Sending {language} translation data to {url}...[/cyan]")

    try:
        r = requests.post(url, json=payload, headers=headers, timeout=30)
    except requests.RequestException as e:
        console.print(f"[red]❌ Network error:[/red] {e}")
        raise SystemExit(1)

    if r.ok:
        console.print("[green]✅ Upload successful![/green]")
        ct = (r.headers.get("content-type") or "").lower()
        if "application/json" in ct:
            try:
                console.print(json.dumps(r.json(), indent=2, ensure_ascii=False))
            except Exception:
                pass
        return

    _print_error_response(r)
    raise SystemExit(1)


def _run_sync_for_project(cfg):
    """Run sync for one project definition from .batre.yml"""
    project_id = cfg.get("project_id")
    if not project_id:
        console.print("[red]❌ Missing 'project_id' in project config.[/red]")
        raise SystemExit(1)

    repo_path = cfg.get("repo_path")
    base_path = os.path.join(repo_path, cfg["base_path"])
    api_url = cfg["api_url"]
    token = cfg["api_token"]
    aggregator_path = cfg.get("aggregator_path")
    if not aggregator_path:
        console.print(f"[red]❌ Missing aggregator_path for project:[/red] {project_id}")
        raise SystemExit(1)

    os.makedirs(aggregator_path, exist_ok=True)
    output_path = os.path.join(aggregator_path, "aggregated.json")

    print(f"[cyan]🔄 Updating repo at {repo_path}...[/cyan]")
    update_repo(repo_path)

    print(f"[cyan]📦 Aggregating translations from {base_path}...[/cyan]")
    data = aggregate(base_path)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"[green]💾 Aggregated file saved to:[/green] {output_path}")
    print(f"[cyan]🚀 Uploading aggregated file to Batre Translator...[/cyan]")
    upload_file(api_url, token, project_id, output_path, os.path.basename(base_path))


def main():
    config_path = ".batre.yml"
    if not os.path.exists(config_path):
        console.print("[red]❌ Config file .batre.yml not found[/red]")
        raise SystemExit(1)

    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    if "projects" not in cfg:
        console.print("[red]❌ Multi-project mode requires a 'projects:' section in .batre.yml[/red]")
        raise SystemExit(1)

    projects = cfg["projects"]
    if not isinstance(projects, list) or len(projects) == 0:
        console.print("[red]❌ 'projects:' must contain at least one valid project config[/red]")
        raise SystemExit(1)

    # 🧩 Enforce explicit flag --project <id>
    if "--project" not in sys.argv:
        console.print("\n[red]❌ Missing required flag:[/red] --project <project_id>\n")
        console.print("Usage: batre sync --project <project_id>\n")
        console.print("[cyan]Available projects:[/cyan]")
        for p in projects:
            console.print(f" - [bold]{p.get('project_id', 'UNKNOWN')}[/bold]")
        raise SystemExit(1)

    try:
        idx = sys.argv.index("--project")
        project_id = sys.argv[idx + 1]
    except (ValueError, IndexError):
        console.print("[red]❌ Invalid usage. Example: batre sync --project my-app[/red]")
        raise SystemExit(1)

    project = next((p for p in projects if p["project_id"] == project_id), None)
    if not project:
        console.print(f"[red]❌ Project '{project_id}' not found in .batre.yml[/red]")
        raise SystemExit(1)

    console.print(f"[bold cyan]🔁 Starting sync for project:[/bold cyan] {project_id}")
    _run_sync_for_project(project)


if __name__ == "__main__":
    main()
