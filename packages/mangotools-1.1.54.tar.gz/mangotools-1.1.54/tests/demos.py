# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-09-28 10:48
# @Author : 毛鹏
from mangotools.method import ensure_path_sep

print(ensure_path_sep('mango_pytest/auto_test/api_ztool/test_case/test_bulletin_board/test_custom_field.py'))
