The `ublock-matches.tsv` file is [downloaded from][1] `adblock-rust`'s Github and preprocessed and compressed using `generate.py` to produce
`ublock-matches.tsv.gz`.

## License

The aforementioned file was released under terms of the Mozilla Public
License, version 2.0 (MPLv2) by Andrius Aucinas. A copy of the license may be
found in the [`LICENSE`][2] file of this directory, or on [Mozilla's website][3].

[1]: https://github.com/brave/adblock-rust/blob/master/data/ublock-matches.tsv
[2]: LICENSE
[3]: https://www.mozilla.org/en-US/MPL/2.0/
