from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='pico-editor',
    version='0.1.1',
    author='master629',
    description='A lightweight, nano-style text editor built in Python.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Master629/pico-editor",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Environment :: Console",
        "Topic :: Text Editors",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'pico = pico.__main__:main',
        ],
    },
)
