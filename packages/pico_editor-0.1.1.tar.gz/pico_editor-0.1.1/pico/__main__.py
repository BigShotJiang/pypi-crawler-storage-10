import curses
import sys
import os

class Editor:
    def __init__(self, screen, file_path):
        self.screen = screen
        self.file_path = file_path
        self.lines = []
        self.dirty = False
        self.running = True
        self.cursor_y, self.cursor_x = 0, 0
        self.desired_x = 0
        self.top_line = 0
        self.left_edge = 0
        self.height, self.width = self.screen.getmaxyx()
        self.status_message = ""
        self.last_search = ""

        self.text_win = curses.newwin(self.height - 2, self.width, 1, 0)
        self.text_win.keypad(True)

        self.screen.keypad(True)
        curses.use_default_colors()
        curses.start_color()
        curses.init_pair(1, curses.COLOR_WHITE, curses.COLOR_BLUE)
        curses.curs_set(1)

        self.load_file()

    def load_file(self):
        if self.file_path and os.path.isfile(self.file_path):
            try:
                with open(self.file_path, 'r') as f:
                    self.lines = [line.rstrip('\n') for line in f.readlines()]
            except Exception as e:
                self.status_message = f"Error loading file: {e}"
                self.lines = [""]
        else:
            self.lines = [""]
        if not self.lines:
            self.lines = [""]

    def get_input(self, prompt):
        self.bottom_bar(prompt)
        self.screen.move(self.height - 1, len(prompt) + 1)
        curses.echo()
        curses.curs_set(1)
        response = self.screen.getstr().decode('utf-8')
        curses.noecho()
        curses.curs_set(0)
        return response

    def save_file(self):
        if not self.file_path:
            new_path = self.get_input("File Name to Write: ")
            if not new_path:
                self.status_message = "Save cancelled."
                return
            self.file_path = os.path.expanduser(new_path)
        
        try:
            with open(self.file_path, 'w') as f:
                for line in self.lines:
                    f.write(line + '\n')
            self.dirty = False
            self.status_message = f"{len(self.lines)} lines written to {self.file_path}"
        except Exception as e:
            self.status_message = f"Error saving file: {e}"

    def show_help(self):
        self.screen.erase()
        self.screen.attron(curses.color_pair(1))
        self.screen.addstr(0, 0, " " * (self.width - 1))
        title = " pico Help "
        self.screen.addstr(0, (self.width - len(title)) // 2, title)
        self.screen.attroff(curses.color_pair(1))
        help_text = [
            "Ctrl+G: Display this help screen", "Ctrl+X: Exit pico",
            "Ctrl+O: Save the current file", "Ctrl+F: Find text",
            "Ctrl+W: Find next", "Ctrl+T: Go to line", "",
            "Arrow Keys: Move the cursor", "Page Up/Down: Move up or down one page",
            "Home: Jump to the beginning of the line", "End: Jump to the end of the line",
            "", "Made by master629",
            "~ol"
        ]
        for i, text in enumerate(help_text):
            self.screen.addstr(i + 2, 2, text)
        self.bottom_bar("Press any key to return to editor")
        self.screen.getch()

    def run(self):
        while self.running:
            self.draw()
            key = self.text_win.getch()
            self.handle_input(key)

    def handle_input(self, key):
        self.status_message = ""
        if self._handle_special_keys(key):
            pass
        elif self._handle_movement(key):
            pass
        elif self._handle_editing(key):
            self.dirty = True
        
        self._validate_cursor()
        self._scroll_viewport()

    def _validate_cursor(self):
        self.cursor_y = max(0, min(self.cursor_y, len(self.lines) - 1))
        
        self.cursor_x = self.desired_x
        self.cursor_x = max(0, self.cursor_x)

    def _scroll_viewport(self):
        text_height = self.height - 2 - 2
        text_width = self.width - 2

        if self.cursor_y < self.top_line:
            self.top_line = self.cursor_y
        if self.cursor_y >= self.top_line + text_height:
            self.top_line = self.cursor_y - text_height + 1
        
        if self.cursor_x < self.left_edge:
            self.left_edge = self.cursor_x
        if self.cursor_x >= self.left_edge + text_width:
            self.left_edge = self.cursor_x - text_width + 1

    def _handle_special_keys(self, key):
        if key == 7: self.show_help()
        elif key == 24: self._handle_exit()
        elif key == 15: self.save_file()
        else: return False
        return True

    def _handle_movement(self, key):
        if key == curses.KEY_UP:
            self.cursor_y -= 1
        elif key == curses.KEY_DOWN:
            self.cursor_y += 1
        elif key == curses.KEY_LEFT:
            self.cursor_x -= 1
            self.desired_x = self.cursor_x
        elif key == curses.KEY_RIGHT:
            self.cursor_x += 1
            self.desired_x = self.cursor_x
        elif key == curses.KEY_HOME:
            self.cursor_x = 0
            self.desired_x = 0
        elif key == curses.KEY_END:
            self.cursor_x = len(self.lines[self.cursor_y])
            self.desired_x = self.cursor_x
        elif key == curses.KEY_PPAGE:
            self.cursor_y -= (self.height - 4)
        elif key == curses.KEY_NPAGE:
            self.cursor_y += (self.height - 4)
        else:
            return False
        return True

    def _handle_editing(self, key):
        line = self.lines[self.cursor_y]
        line_len = len(line)

        if key == curses.KEY_BACKSPACE or key == 127:
            if self.cursor_x > 0:
                if self.cursor_x > line_len:
                    line += " " * (self.cursor_x - line_len)
                self.lines[self.cursor_y] = line[:self.cursor_x - 1] + line[self.cursor_x:]
                self.cursor_x -= 1
                self.desired_x = self.cursor_x
            elif self.cursor_y > 0:
                popped_line = self.lines.pop(self.cursor_y)
                self.cursor_y -= 1
                prev_line_len = len(self.lines[self.cursor_y])
                self.lines[self.cursor_y] += popped_line
                self.cursor_x = prev_line_len
                self.desired_x = self.cursor_x

        elif key == curses.KEY_ENTER or key == 10:
            if self.cursor_x > line_len:
                line += " " * (self.cursor_x - line_len)
            self.lines[self.cursor_y] = line[:self.cursor_x]
            self.lines.insert(self.cursor_y + 1, line[self.cursor_x:])
            self.cursor_y += 1
            self.cursor_x = 0
            self.desired_x = 0

        elif 32 <= key <= 126:
            if self.cursor_x > line_len:
                line += " " * (self.cursor_x - line_len)
            self.lines[self.cursor_y] = line[:self.cursor_x] + chr(key) + line[self.cursor_x:]
            self.cursor_x += 1
            self.desired_x = self.cursor_x
        else:
            return False
        return True

    def _handle_exit(self):
        if self.dirty:
            response = self.get_input("Save modified buffer (ANSWERING 'No' WILL DESTROY CHANGES) ? ")
            if response.lower() in ('y', 'yes'):
                self.save_file()
            elif response.lower() in ('n', 'no'):
                self.running = False
                return
            else:
                self.status_message = "Cancelled."
                return
        self.running = False

    def top_bar(self):
        self.screen.attron(curses.color_pair(1))
        self.screen.addstr(0, 0, " " * (self.width - 1))
        version_text = "pico v0.1.1"
        credit_text = "Made by master629"
        file_text = f"{self.file_path or '(New File)'}"
        self.screen.addstr(0, 1, version_text)
        self.screen.addstr(0, (self.width - len(file_text)) // 2, file_text)
        self.screen.addstr(0, self.width - len(credit_text) - 1, credit_text)
        self.screen.attroff(curses.color_pair(1))

    def bottom_bar(self, prompt=""):
        self.screen.attron(curses.color_pair(1))
        self.screen.addstr(self.height - 1, 0, " " * (self.width - 1))
        if prompt:
            line_to_draw = prompt
        else:
            line_info = f"Ln: {self.cursor_y + 1}, Col: {self.cursor_x + 1}"
            keybinds = "^G Help | ^X Exit | ^O Save"
            spacing = self.width - len(keybinds) - len(line_info) - 1
            line_to_draw = f"{keybinds}{' ' * spacing}{line_info}"
        self.screen.addstr(self.height - 1, 0, line_to_draw[:self.width-1])
        self.screen.attroff(curses.color_pair(1))

    def draw(self):
        curses.curs_set(1)
        self.screen.erase()
        self.top_bar()
        self.bottom_bar(self.status_message)
        
        self.text_win.erase()
        text_height = self.height - 2 - 2
        text_width = self.width - 2

        for i in range(text_height):
            line_num = self.top_line + i
            if line_num < len(self.lines):
                line = self.lines[line_num]
                start = self.left_edge
                end = self.left_edge + text_width
                visible_line = line[start:end]
                try:
                    self.text_win.addstr(i + 1, 1, visible_line)
                except curses.error:
                    pass

        self.text_win.box()
        self.screen.refresh()
        self.text_win.refresh()

        win_y = self.cursor_y - self.top_line + 1
        win_x = self.cursor_x - self.left_edge + 1
        
        if (1 <= win_y < self.height - 2) and (1 <= win_x < self.width - 2):
             self.text_win.move(win_y, win_x)

def main():
    def run_editor(screen):
        height, width = screen.getmaxyx()
        if height < 3 or width < 10:
            print("Terminal too small.")
            return
        file_path = sys.argv[1] if len(sys.argv) > 1 else None
        Editor(screen, file_path).run()

    curses.wrapper(run_editor)

if __name__ == '__main__':
    main()
