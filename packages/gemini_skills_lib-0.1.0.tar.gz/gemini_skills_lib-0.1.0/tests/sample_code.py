import sys

def inefficient_sum(numbers):
    # This is a very inefficient way to sum a list of numbers
    total = 0
    for number in numbers:
        total += number
    return total

def main():
    unused_variable = "hello"
    data = [1, 2, 3, 4, 5]
    result = inefficient_sum(data)
    print(f"The result is: {result}")

if __name__ == "__main__":
    main()
