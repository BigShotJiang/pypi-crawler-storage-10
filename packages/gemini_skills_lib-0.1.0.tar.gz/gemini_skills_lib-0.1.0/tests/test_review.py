
import unittest
from pathlib import Path

# This test assumes the package is installed (e.g., 'pip install -e .')
from gemini_skills_lib.skill_manager import run_skill

class TestReviewSkill(unittest.TestCase):

    def test_review_skill_on_sample_code(self):
        """Tests if the review skill identifies common issues in the sample code."""
        # Tests are run from the project root, so paths should be relative to that
        sample_file = Path('tests') / 'sample_code.py'
        self.assertTrue(sample_file.exists(), "Test sample file should exist.")

        # Run the 'review' skill on the sample code
        output = run_skill('review', target=str(sample_file))

        self.assertIsNotNone(output, "Skill should produce an output.")

        # Check for expected keywords in the review output
        output_lower = output.lower()
        self.assertIn("inefficient", output_lower, "Review should mention inefficiency.")
        self.assertIn("unused", output_lower, "Review should mention unused variables.")
        self.assertIn("total +=", output_lower, "Review should quote the inefficient line.")

if __name__ == '__main__':
    unittest.main()
