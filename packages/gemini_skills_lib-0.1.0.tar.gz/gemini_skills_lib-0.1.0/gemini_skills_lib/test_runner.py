
import unittest
from pathlib import Path
from rich.console import Console

console = Console()

def run_tests():
    """Discovers and runs all tests in the 'tests' directory."""
    # Assume the script is run from the project root or the package is installed.
    project_root = Path(__file__).parent.parent
    test_dir = project_root / 'tests'

    console.print(f"[bold cyan]Starting test discovery in {test_dir}...[/bold cyan]")
    loader = unittest.TestLoader()
    suite = loader.discover(str(test_dir))

    if suite.countTestCases() == 0:
        console.print("[yellow]No tests found.[/yellow]")
        return

    console.print(f"Found {suite.countTestCases()} tests.")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    if result.wasSuccessful():
        console.print("[bold green]All tests passed successfully![/bold green]")
    else:
        console.print("[bold red]Some tests failed.[/bold red]")

if __name__ == "__main__":
    run_tests()
