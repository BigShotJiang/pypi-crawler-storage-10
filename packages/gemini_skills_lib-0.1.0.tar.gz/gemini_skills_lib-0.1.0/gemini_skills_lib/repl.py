import readline
from .skill_manager import list_skills, run_skill, install_skill, autocomplete_skills, register_skills
from .run_workflow import run_workflow
from .test_runner import run_tests
from pathlib import Path
import subprocess

def completer(text, state):
    options = autocomplete_skills(text)
    if state < len(options):
        return options[state]
    return None

readline.set_completer(completer)
readline.parse_and_bind("tab: complete")

def gemini_repl():
    print("Gemini CLI Interactive Mode (type 'exit' to quit)")
    while True:
        try:
            cmd = input(">>> ").strip()
        except EOFError:
            break
        if cmd in ['exit', 'quit']:
            break
        if cmd.startswith('skill '):
            parts = cmd.split()
            if len(parts) < 2:
                print("Usage: skill list | run <skill_name> <target> | install <repo_url> | register")
                continue
            action = parts[1]
            if action == 'list':
                list_skills()
            elif action == 'register':
                register_skills()
            elif action == 'run' and len(parts) >= 4:
                skill_name = parts[2]
                target = " ".join(parts[3:])
                output = run_skill(skill_name, target=target)
                if output:
                    from rich.markdown import Markdown
                    from rich.console import Console
                    console = Console()
                    console.print(Markdown(output))
            elif action == 'install' and len(parts) == 3:
                install_skill(parts[2])
            else:
                print("Invalid skill command")
        elif cmd == 'workflow':
            script_dir = Path(__file__).parent
            config_file = script_dir.parent / "config.yaml"
            run_workflow(config_file)
        elif cmd == 'test':
            run_tests()
        else:
            subprocess.run(['gemini'] + cmd.split())
