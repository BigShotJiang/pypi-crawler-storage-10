# API Documentation

## Function: {{ function_name }}

**Description:**  
{{ description }}

**Parameters:**  
{{ parameters }}

**Returns:**  
{{ returns }}
