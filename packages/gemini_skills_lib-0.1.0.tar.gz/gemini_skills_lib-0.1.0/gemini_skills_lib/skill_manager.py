import os, yaml, subprocess, shutil
from pathlib import Path
from rich.console import Console
from rich.markdown import Markdown

console = Console()
# Assuming this script is in templates, the project root is one level up.
PROJECT_ROOT = Path(__file__).parent.parent
SKILL_DIR = PROJECT_ROOT / "skills"
REGISTRY = PROJECT_ROOT / "skill_registry.yaml"

def load_registry():
    if not REGISTRY.exists():
        return {"skills": {}}
    with open(REGISTRY) as f:
        return yaml.safe_load(f)

def save_registry(registry):
    with open(REGISTRY, 'w') as f:
        yaml.dump(registry, f, default_flow_style=False)

def register_skills():
    """Scans the skills directory and updates the registry."""
    if not SKILL_DIR.is_dir():
        console.print(f"[yellow]Skills directory not found at {SKILL_DIR}. Nothing to register.[/yellow]")
        return

    registry = load_registry()
    registered_skills = registry.get("skills", {})
    found_files = list(SKILL_DIR.glob("*.md")) + list(SKILL_DIR.glob("*.yaml"))
    
    console.print(f"Found {len(found_files)} potential skill files in {SKILL_DIR}")

    for skill_file in found_files:
        skill_name = skill_file.stem
        if skill_name not in registered_skills:
            description = f"A skill defined in {skill_file.name}"
            if skill_file.suffix == '.yaml':
                try:
                    with open(skill_file) as f:
                        skill_config = yaml.safe_load(f)
                        description = skill_config.get('description', skill_config.get('goal', description))
                except yaml.YAMLError:
                    console.print(f"[red]Error parsing {skill_file.name}. Using default description.[/red]")
            
            registered_skills[skill_name] = {
                'file': str(skill_file.relative_to(PROJECT_ROOT)),
                'description': description
            }
            console.print(f"[green]Registered new skill: '{skill_name}'[/green]")

    registry["skills"] = registered_skills
    save_registry(registry)
    console.print("Skill registry updated.")

def list_skills():
    registry = load_registry()
    console.print("[bold green]Available Skills:[/bold green]")
    for name, info in registry["skills"].items():
        console.print(f"- {name}: {info['description']}")

def run_skill(skill_name, target=None, input_text=None):
    registry = load_registry()
    if skill_name not in registry["skills"]:
        # Dynamic check if skill file exists but not in registry
        potential_file = SKILL_DIR / f"{skill_name}.md"
        if not potential_file.exists():
            potential_file = SKILL_DIR / f"{skill_name}.yaml"
        
        if potential_file.exists():
            console.print(f"[yellow]Skill '{skill_name}' is not in the registry. Try running 'skill register'.[/yellow]")
        else:
            console.print(f"[red]Skill '{skill_name}' not found.[/red]")
        return None

    skill_path_str = registry['skills'][skill_name]['file']
    skill_file = PROJECT_ROOT / skill_path_str

    if not skill_file.exists():
        console.print(f"[red]Skill file '{skill_file}' not found. Try running 'skill register'.[/red]")
        return None

    cmd = ['gemini', 'prompt', str(skill_file)]
    if input_text:
        cmd.extend(['--input', '-'])
        result = subprocess.run(cmd, input=input_text, capture_output=True, text=True, encoding='utf-8')
    elif target:
        cmd.extend(['--input', target])
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
    else:
        console.print("[red]Either target or input_text must be provided.[/red]")
        return None

    if result.stderr:
        console.print(f"[red]Error running skill {skill_name}:[/red]")
        console.print(result.stderr)
        return None
    
    return result.stdout

def install_skill(repo_url):
    # This needs to be adapted to the new structure, for now, it's a placeholder
    console.print("[yellow]Install skill functionality needs to be updated.[/yellow]")
    # target_dir = SKILL_DIR
    # target_dir.mkdir(parents=True, exist_ok=True)
    # subprocess.run(['git', 'clone', repo_url, str(target_dir)])
    # console.print(f"[green]Installed skills from {repo_url}[/green]")
    # register_skills() # Should be called after installation

def autocomplete_skills(text):
    registry = load_registry()
    return [name for name in registry['skills'] if name.startswith(text)]
