
from flask import Flask, request, jsonify, render_template_string
from pathlib import Path
import yaml

# Use relative imports now that this is part of a package
from .skill_manager import run_skill, register_skills, load_registry
from .run_workflow import run_workflow

app = Flask(__name__)

# Simple HTML template with some basic styling
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gemini Skills UI</title>
    <style>
        body { font-family: sans-serif; margin: 2em; background-color: #f4f4f9; color: #333; }
        h1, h2 { color: #444; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .skills-list, .workflow, .run-skill { margin-bottom: 2em; }
        select, textarea, button { width: 100%; padding: 10px; margin-top: 10px; border-radius: 4px; border: 1px solid #ddd; }
        button { background-color: #007bff; color: white; border: none; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #0056b3; }
        pre { background-color: #eee; padding: 10px; border-radius: 4px; white-space: pre-wrap; word-wrap: break-word; }
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gemini Skills UI</h1>
        
        <div class="skills-list">
            <h2>Available Skills</h2>
            <button id="registerBtn">Register Skills</button>
            <ul id="skillList">
                {% for name, info in skills.items() %}
                    <li><strong>{{ name }}</strong>: {{ info.description }}</li>
                {% endfor %}
            </ul>
        </div>

        <div class="run-skill">
            <h2>Run a Skill</h2>
            <select id="skillSelect">
                {% for name in skills.keys() %}
                    <option value="{{ name }}">{{ name }}</option>
                {% endfor %}
            </select>
            <textarea id="skillInput" rows="5" placeholder="Enter text or a file path to run the skill on..."></textarea>
            <button id="runSkillBtn">Run Skill</button>
        </div>

        <div class="workflow">
            <h2>Run Workflow</h2>
            <button id="runWorkflowBtn">Run Full Workflow</button>
        </div>

        <h2>Result</h2>
        <pre id="resultOutput">Output will be shown here...</pre>
    </div>

    <script>
        document.getElementById('registerBtn').addEventListener('click', () => {
            fetch('/register_skills', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    document.getElementById('resultOutput').textContent = data.message;
                    location.reload(); // Reload to see new skills
                });
        });

        document.getElementById('runSkillBtn').addEventListener('click', () => {
            const skillName = document.getElementById('skillSelect').value;
            const inputText = document.getElementById('skillInput').value;
            document.getElementById('resultOutput').textContent = 'Running...';
            fetch('/run_skill', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ skill_name: skillName, input: inputText })
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('resultOutput').textContent = data.output || data.error;
            });
        });

        document.getElementById('runWorkflowBtn').addEventListener('click', () => {
            document.getElementById('resultOutput').textContent = 'Running workflow...';
            fetch('/run_workflow', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                document.getElementById('resultOutput').textContent = data.output || data.error;
            });
        });
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    # The new skill_manager finds the project root automatically
    registry = load_registry()
    return render_template_string(HTML_TEMPLATE, skills=registry.get("skills", {}))

@app.route('/register_skills', methods=['POST'])
def api_register_skills():
    register_skills()
    return jsonify({"message": "Skills registered successfully. The page will now reload."})

@app.route('/run_skill', methods=['POST'])
def api_run_skill():
    data = request.json
    skill_name = data.get('skill_name')
    user_input = data.get('input')

    # Simple check if input is a file path that exists
    # Note: This check is basic and assumes the server and client have the same filesystem view
    if Path(user_input).is_file():
        output = run_skill(skill_name, target=user_input)
    else:
        output = run_skill(skill_name, input_text=user_input)
    
    return jsonify({"output": output})

@app.route('/run_workflow', methods=['POST'])
def api_run_workflow():
    # The skill_manager now finds the project root, so we can locate config.yaml
    project_root = Path(__file__).parent.parent
    config_file = project_root / "config.yaml"
    
    try:
        final_output = run_workflow(config_file)
    except Exception as e:
        final_output = f"Workflow failed: {e}"

    return jsonify({"output": final_output})

def main():
    app.run(debug=True)

if __name__ == '__main__':
    main()
