
import yaml
from pathlib import Path
from .skill_manager import run_skill

def run_workflow(config_path: Path):
    with open(config_path) as f:
        config = yaml.safe_load(f)

    steps = config.get("steps", [])
    if not steps:
        print("[yellow]No steps found in the workflow configuration.[/yellow]")
        return None

    previous_step_output = None

    for i, step in enumerate(steps):
        skill_name = step.get("prompt", "").replace("skills/", "").replace(".md", "").replace(".yaml", "")
        target = step.get("input")
        depends_on = step.get("depends_on")

        if depends_on and previous_step_output:
            current_input = previous_step_output
            target = None
        else:
            current_input = None

        output = run_skill(skill_name, target=target, input_text=current_input)

        if output:
            previous_step_output = output
        else:
            raise Exception(f"Step '{skill_name}' failed. Aborting workflow.")
    
    return previous_step_output

if __name__ == "__main__":
    script_dir = Path(__file__).parent
    config_file = script_dir.parent / "config.yaml"
    final_output = run_workflow(config_file)
    if final_output:
        print(final_output)
