import os

print("Setting up Gemini Skills Library...")
os.makedirs("skills", exist_ok=True)
os.makedirs("templates", exist_ok=True)
print("Setup complete.")
