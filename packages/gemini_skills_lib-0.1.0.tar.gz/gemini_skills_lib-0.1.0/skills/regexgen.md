# Regex Generation Skill

## Description
This skill generates a regular expression from a natural language description.

## Instructions
- Provide a description of the pattern you want to match.
- The skill will generate a regular expression.

## Prompt
Generate a regular expression for the following description:
"{{input}}"
