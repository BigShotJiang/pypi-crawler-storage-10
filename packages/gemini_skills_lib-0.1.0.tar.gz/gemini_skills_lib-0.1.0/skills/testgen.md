# Skill: Test Generator
[role: QA engineer]

Goal:
Generate Python unit tests for the provided functions.

Guidelines:
- Use pytest style
- Cover edge cases
- Include docstrings
