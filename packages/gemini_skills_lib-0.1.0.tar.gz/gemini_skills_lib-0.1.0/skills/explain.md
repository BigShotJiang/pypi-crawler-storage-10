# Code Explanation Skill

## Description
This skill explains a piece of code in plain language.

## Instructions
- Provide a code snippet as input.
- The skill will provide a clear and concise explanation of the code.

## Prompt
Explain the following code:
```
{{input}}
```
