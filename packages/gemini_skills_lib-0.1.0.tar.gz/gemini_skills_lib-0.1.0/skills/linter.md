# Code Linter Skill

## Description
This skill lints the provided code and suggests improvements.

## Instructions
- Provide a code snippet as input.
- The skill will analyze the code for style issues, potential errors, and suggest improvements.

## Prompt
Lint the following code and provide suggestions for improvement:
```
{{input}}
```
