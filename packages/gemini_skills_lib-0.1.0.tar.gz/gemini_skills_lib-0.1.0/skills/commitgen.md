# Commit Message Generation Skill

## Description
This skill generates a commit message from a code diff.

## Instructions
- Provide the output of `git diff` as input.
- The skill will generate a conventional commit message.

## Prompt
Generate a conventional commit message for the following diff:
```
{{input}}
```
