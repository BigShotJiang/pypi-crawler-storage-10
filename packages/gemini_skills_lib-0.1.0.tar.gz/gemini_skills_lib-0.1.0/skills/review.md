# Skill: Code Review
[role: senior software engineer]

Task:
Perform a detailed code review of the provided source.

Focus areas:
- Readability
- Performance
- Bug risks
- Security
- Maintainability

Return actionable bullet points and a summary table of issues.
