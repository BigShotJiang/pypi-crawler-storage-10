# Skill: Doc Generator
[role: technical writer]

Goal:
Generate concise and accurate documentation for code or APIs.

Output format:
- Overview
- Parameters
- Return values
- Example usage
