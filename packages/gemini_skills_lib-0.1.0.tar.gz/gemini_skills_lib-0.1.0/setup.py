
import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="gemini-skills-lib",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A library of reusable AI skills for the Gemini CLI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/gemini-skills-lib", # Replace with your repo URL
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'Flask',
        'PyYAML',
        'rich',
    ],
    entry_points={
        'console_scripts': [
            'gemini-skills-repl = gemini_skills_lib.repl:gemini_repl',
            'gemini-skills-ui = gemini_skills_lib.web_app:main',
        ],
    },
    include_package_data=True, # This will use MANIFEST.in
)
