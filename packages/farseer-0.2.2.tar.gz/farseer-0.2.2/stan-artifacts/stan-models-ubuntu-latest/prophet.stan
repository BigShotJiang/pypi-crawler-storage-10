functions {
  // Logistic trend functions

  vector logistic_gamma(real k, real m, vector delta, vector t_change, int S) {
    vector[S] gamma;  // adjusted offsets, for piecewise continuity
    vector[S + 1] k_s;  // actual rate in each segment
    real m_pr;

    // Compute the rate in each segment
    k_s = append_row(k, k + cumulative_sum(delta));

    // Piecewise offsets
    m_pr = m; // The offset in the previous segment
    for (i in 1:S) {
      gamma[i] = (t_change[i] - m_pr) * (1 - k_s[i] / k_s[i + 1]);
      m_pr = m_pr + gamma[i];  // update for the next segment
    }
    return gamma;
  }

  vector logistic_trend(
    real k,
    real m,
    vector delta,
    vector t,
    vector cap,
    matrix A,
    vector t_change,
    int S
  ) {
    vector[S] gamma;

    gamma = logistic_gamma(k, m, delta, t_change, S);
    return cap .* inv_logit((k + A * delta) .* (t - (m + A * gamma)));
  }

  // Linear trend function

  vector linear_trend(
    real k,
    real m,
    vector delta,
    vector t,
    matrix A,
    vector t_change
  ) {
    return (k + A * delta) .* t + (m + A * (-t_change .* delta));
  }

  // Flat trend function

  vector flat_trend(
    real m,
    int T
  ) {
    return rep_vector(m, T);
  }
}

data {
  int T;                // Number of time periods
  int<lower=0> K;       // Number of regressors (can be 0)
  vector[T] t;          // Time
  vector[T] cap;        // Capacities for logistic trend
  vector[T] y;          // Time series
  int S;                // Number of changepoints
  vector[S] t_change;   // Times of trend changepoints
  matrix[T,S] A;        // Pre-computed changepoint matrix (passed from Rust)
  matrix[T,K] X;        // Regressors
  vector<lower=0>[K] sigmas;     // Scale on seasonality prior (must be positive)
  real<lower=0> tau;    // Scale on changepoints prior
  int trend_indicator;  // 0 for linear, 1 for logistic, 2 for flat
  vector[K] s_a;        // Indicator of additive features
  vector[K] s_m;        // Indicator of multiplicative features
  vector<lower=0>[T] weights;  // Observation weights
}

transformed data {
  matrix[T, K] X_sa = X .* rep_matrix(s_a', T);
  matrix[T, K] X_sm = X .* rep_matrix(s_m', T);
  int has_weights = (max(weights) != min(weights)) || (min(weights) != 1.0);
}

parameters {
  real k;                   // Base trend growth rate
  real m;                   // Trend offset
  vector[S] delta;          // Trend rate adjustments
  real<lower=0> sigma_obs;  // Observation noise
  vector[K] beta;           // Regressor coefficients
}

transformed parameters {
  vector[T] trend;
  if (trend_indicator == 0) {
    trend = linear_trend(k, m, delta, t, A, t_change);
  } else if (trend_indicator == 1) {
    trend = logistic_trend(k, m, delta, t, cap, A, t_change, S);
  } else if (trend_indicator == 2) {
    trend = flat_trend(m, T);
  }
}

model {
  //priors
  k ~ normal(0, 5);
  m ~ normal(0, 5);
  delta ~ double_exponential(0, tau);
  sigma_obs ~ normal(0, 0.5);

  // Only apply beta prior if there are regressors
  if (K > 0) {
    for (i in 1:K) {
      // Ensure sigma is positive, use max to avoid zero scale
      beta[i] ~ normal(0, fmax(sigmas[i], 0.01));
    }
  }

  // Likelihood - use optimized approach
  // When we have weights, we need to handle them; otherwise use fast GLM
  if (has_weights) {
    // Weighted likelihood - compute mu explicitly but vectorize the likelihood
    vector[T] mu;
    if (K > 0) {
      mu = X_sa * beta + trend .* (1 + X_sm * beta);
    } else {
      mu = trend;
    }
    // Vectorized weighted likelihood (much faster than loop with target +=)
    target += weights .* normal_lpdf(y | mu, sigma_obs);
  } else {
    // No weights - use highly optimized GLM function like Prophet
    if (K > 0) {
      y ~ normal_id_glm(X_sa, trend .* (1 + X_sm * beta), beta, sigma_obs);
    } else {
      y ~ normal(trend, sigma_obs);
    }
  }
}
