## cdf 

### Improved

- Default version of the QueryKnowledgeGraph Agent tool is set to v2

## templates

No changes.