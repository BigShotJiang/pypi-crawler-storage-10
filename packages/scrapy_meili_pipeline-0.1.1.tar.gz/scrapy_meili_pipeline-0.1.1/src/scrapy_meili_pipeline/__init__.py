__all__ = ["MeiliSearchPipeline"]

from .meili_pipeline import MeiliSearchPipeline
