"""
@file slush_manager.py
File to instantiate a Slush Board, to use the same board reference in different files
"""

import Slush


slush_board = Slush.sBoard()
