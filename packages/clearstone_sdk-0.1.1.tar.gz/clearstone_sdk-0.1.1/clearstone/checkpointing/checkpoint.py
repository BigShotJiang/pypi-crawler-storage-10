# clearstone/checkpointing/checkpoint.py
