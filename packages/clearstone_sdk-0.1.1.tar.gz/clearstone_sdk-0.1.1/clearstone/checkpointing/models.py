# clearstone/checkpointing/models.py
