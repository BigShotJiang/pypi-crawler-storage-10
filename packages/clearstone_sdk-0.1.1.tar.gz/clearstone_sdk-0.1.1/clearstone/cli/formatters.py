# clearstone/cli/formatters.py
