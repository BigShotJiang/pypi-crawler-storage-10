# clearstone/utils/paths.py
