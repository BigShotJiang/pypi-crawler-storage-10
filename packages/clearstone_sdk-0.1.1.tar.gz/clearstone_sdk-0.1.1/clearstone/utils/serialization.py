# clearstone/utils/serialization.py
