# clearstone/core/exceptions.py
