
from quanti_fret.apps.gui import QtfMainWidget

from qtpy.QtWidgets import QHBoxLayout, QWidget


class QtfNapariWidget(QWidget):
    """ Entry point widget for the Napari plugin
    """
    def __init__(
            self, viewer: "napari.viewer.Viewer"  # type: ignore # noqa: F821
    ):
        super().__init__()
        self.viewer = viewer
        self.setLayout(QHBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)  # type: ignore
        self.layout().addWidget(QtfMainWidget())  # type: ignore
