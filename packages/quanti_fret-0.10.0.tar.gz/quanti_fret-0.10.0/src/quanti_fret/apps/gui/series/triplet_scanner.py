from quanti_fret.apps.gui.io_gui_manager import IOGuiManager
from quanti_fret.apps.gui.utils import PathLabel
from quanti_fret.core import TripletSequence
from quanti_fret.io import TripletScanner


from pathlib import Path

from qtpy.QtCore import Qt, QItemSelectionModel
from qtpy.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class TripletScannerWidget(QWidget):
    """ Handle the the selection of the folder on which to look for
    triplet sequences.

    The user will be ask to select a folder, and then select the sequences
    he wants to be used from the list displayed.
    """

    def __init__(self, name: str, phase: str, *args, **kwargs) -> None:
        """ Constructor

        Args:
            name (str): Name of the series of sequences to look for.
            phase (str): Phase linked with the scanner.
        """
        super().__init__(*args, **kwargs)

        # Internal setup
        self._name = name
        self._folder: Path | None = None
        self._scanner = TripletScanner()
        self._sequences: list[TripletSequence] = []

        # Gui SetUp
        self.setLayout(QVBoxLayout())
        self.layout().setAlignment(Qt.AlignmentFlag.AlignTop)  # type: ignore
        self.layout().setContentsMargins(0, 0, 0, 0)  # type: ignore
        self._buildTitle()
        self._buildFolderSelectorBox()
        self._buildResultsBox()

        # Retrieve previous config
        self._iopm = IOGuiManager().get_iopm(phase)
        self._config = self._iopm.config
        self._updateSeriesFromConfig()
        self._iopm.stateChanged.connect(self._updateSeriesFromConfig)

    def _buildTitle(self) -> None:
        """ Build the TripletSequence series title
        """
        title = QLabel(self._name.capitalize())
        self.layout().addWidget(title)  # type: ignore

    def _buildFolderSelectorBox(self) -> None:
        """ Build the selector box widget where the user will choose the
        folder containing the triplet sequences.
        """
        # Box
        fSelectBox = QGroupBox('Select Folder')
        self.layout().addWidget(fSelectBox)  # type: ignore

        # Layout inside the box
        fSelectLayout = QHBoxLayout()
        fSelectBox.setLayout(fSelectLayout)

        # Folder select label
        self._fSelectLabel = PathLabel("Path:")
        fSelectLayout.addWidget(self._fSelectLabel)

        # Folder select Button
        self._fSelectButton = QPushButton("Select")
        fSelectLayout.addWidget(self._fSelectButton)
        self._fSelectButton.setMinimumSize(50, 25)
        self._fSelectButton.setMaximumSize(100, 50)
        self._fSelectButton.clicked.connect(self._openFolder)

    def _buildResultsBox(self) -> None:
        """ Create the box that display the result of the triplet scan, and
        let the user decide which sequences to keep or remove.
        """
        # Box
        self._resultBox = QGroupBox('Results')
        self.layout().addWidget(self._resultBox)  # type: ignore

        # Layout inside the box
        resultLayout = QVBoxLayout()
        self._resultBox.setLayout(resultLayout)

        # Layout for summary information
        rSummaryLayout = QGridLayout()
        resultLayout.addLayout(rSummaryLayout)

        # TripletSequences found label
        self._seqCountLabel = QLabel()
        rSummaryLayout.addWidget(self._seqCountLabel, 0, 0)

        # TripletSequences selected label
        self._seqSelectedLabel = QLabel()
        rSummaryLayout.addWidget(self._seqSelectedLabel, 1, 0)

        # Detail button
        detailsButton = QPushButton("Details")
        rSummaryLayout.addWidget(detailsButton, 0, 1, 2, 1)
        detailsButton.setMinimumSize(50, 25)
        detailsButton.setMaximumSize(100, 50)
        detailsButton.clicked.connect(self._switchSeqTableVisibility)

        # Detail table
        self._seqTableWidget = QTableWidget()
        self._seqTableWidget.setColumnCount(2)
        self._seqTableWidget.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._seqTableWidget.setHorizontalHeaderLabels(['Subfolder', 'Frames'])
        self._seqTableWidget.setSelectionMode(
            QAbstractItemView.SelectionMode.MultiSelection)
        self._seqTableWidget.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._seqTableWidget.itemSelectionChanged.connect(
            self._selectedSeqChanged)
        self._seqTableWidget.hide()
        resultLayout.addWidget(self._seqTableWidget)

        # Hide by default
        self._resultBox.hide()

    def _openFolder(self) -> None:
        """ Let the user choose a directory with a directory selection window,
        and update the series folder
        """
        if self._folder is None:
            start_folder = ''
        else:
            start_folder = str(self._folder.parent)
        title = f"Select Folder for {self._name.capitalize()}'s Series"
        folder = QFileDialog.getExistingDirectory(self, title, start_folder)

        if folder:
            path = Path(folder)
            self._iopm.config.set('Series', self._name, path)

    def _setSeriesFolder(self, folder: Path | None, force_reset: bool) -> None:
        """ Set the folder of the series associated with this widget.

        If the folder is different from the previous one, and is not None, it:
            - scan for triplet sequences inside the folder
            - Change the button label to "Change"
            - Create the triplet sequences table widget (which emits the
                seqSelectedChanged signal)
            - Update the triplet sequences count labels
            - Display the result box widget

        Args
            folder (Path | None): Folder to set for the series
            force_reset (bool): If true, force the relead of the series even
                if folder didn't change.
        """
        if self._folder != folder or force_reset:
            self._folder = folder
            if folder is None:
                self._fSelectLabel.setText('Path')
                self._fSelectLabel.setToolTip('')
                self._fSelectButton.setText('Select')
                self._sequences = []
            else:
                self._fSelectLabel.setText(f"Path: {folder}")
                self._fSelectLabel.setToolTip(str(folder))
                self._fSelectButton.setText("Change")
                self._sequences = self._scanner.scan(folder)
            msg = f"Sequences found: {len(self._sequences)}"
            self._seqCountLabel.setText(msg)
            self._fillTripletSequencesListWidget()
            self._resultBox.show()

    def _updateSeriesFromConfig(self) -> None:
        """ Update the series using the config

        It checks if the config file changed. In this case, it will rescan the
        folders even if the path didn't change
        """
        config = self._iopm.config
        if config is self._config:
            force_reset = False
        else:
            force_reset = True
            self._config = config

        self._setSeriesFolder(
            config.get('Series', self._name),
            force_reset=force_reset
        )

    def _switchSeqTableVisibility(self) -> None:
        """ Switch the visibility of the sequences table.
        """
        self._seqTableWidget.setVisible(not self._seqTableWidget.isVisible())

    def _fillTripletSequencesListWidget(self) -> None:
        """ Fill the sequences table with all the sequencess found by the
        scanner, and select all of them.
        """
        self._seqTableWidget.blockSignals(True)
        self._seqTableWidget.clear()
        self._seqTableWidget.setRowCount(len(self._sequences))
        row = 0
        for e in self._sequences:
            subfolder = str(e.folder).replace(str(self._folder), '', 1)
            if subfolder == "":
                subfolder = "."
            self._seqTableWidget.setItem(
                row, 0, QTableWidgetItem(subfolder))
            self._seqTableWidget.setItem(
                row, 1, QTableWidgetItem(str(len(e.triplets))))
            row += 1
        self._seqTableWidget.blockSignals(False)
        self._seqTableWidget.selectAll()

    def _selectedSeqChanged(self) -> None:
        """ Create a new series using the sequences selected.
        """
        model: QItemSelectionModel = \
            self._seqTableWidget.selectionModel()  # type: ignore
        new_seq_list = [self._sequences[i.row()]
                        for i in model.selectedRows()]
        self._iopm.series.set(self._name, new_seq_list)
