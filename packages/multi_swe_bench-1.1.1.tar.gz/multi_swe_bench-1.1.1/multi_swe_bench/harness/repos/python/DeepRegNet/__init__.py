from multi_swe_bench.harness.repos.python.DeepRegNet.DeepReg_v0_1_1 import *
from multi_swe_bench.harness.repos.python.DeepRegNet.DeepReg_v0_1_0b1 import *
from multi_swe_bench.harness.repos.python.DeepRegNet.DeepReg_v0_1_0 import *
