from multi_swe_bench.harness.repos.python.BoboTiG.ebook_reader_dict_2464_to_2319 import *
from multi_swe_bench.harness.repos.python.BoboTiG.ebook_reader_dict_2148_to_1842 import *
from multi_swe_bench.harness.repos.python.BoboTiG.ebook_reader_dict_1840_to_1641 import *
