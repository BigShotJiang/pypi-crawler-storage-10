from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_5332_to_4985 import *
from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_4230_to_4027 import *
from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_3980_to_3932 import *
from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_3727_to_3200 import *
from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_3198_to_3100 import *
from multi_swe_bench.harness.repos.python.Clinical_Genomics.scout_2109_to_1937 import *
