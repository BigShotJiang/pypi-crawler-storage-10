from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.workbox_2232_to_2141 import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse_11698_to_10130 import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse_9576_to_9073 import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse_9073_to_8340 import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse_7007_to_5270 import *
from multi_swe_bench.harness.repos.javascript.GoogleChrome.lighthouse_763_to_312 import *
