from multi_swe_bench.harness.repos.javascript.scratchfoundation.scratchgui import *
