from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_1027_to_983 import *
from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_976_to_535 import *
from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_529_to_480 import *
from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_316_to_129 import *
from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_81_to_70 import *
from multi_swe_bench.harness.repos.javascript.cfpb.hmda_platform_ui_56_to_28 import *
