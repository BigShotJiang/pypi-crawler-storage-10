from multi_swe_bench.harness.repos.javascript.ManifoldScholar.manifold_3636_to_2956 import *
from multi_swe_bench.harness.repos.javascript.ManifoldScholar.manifold_2403_to_1524 import *
from multi_swe_bench.harness.repos.javascript.ManifoldScholar.manifold_1357_to_1083 import *
from multi_swe_bench.harness.repos.javascript.ManifoldScholar.manifold_1074_to_783 import *
from multi_swe_bench.harness.repos.javascript.ManifoldScholar.manifold_782_to_421 import *
