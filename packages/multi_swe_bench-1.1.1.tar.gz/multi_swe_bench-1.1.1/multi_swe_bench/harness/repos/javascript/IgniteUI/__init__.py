from multi_swe_bench.harness.repos.javascript.IgniteUI.ignite_ui_2144_to_2117 import *
from multi_swe_bench.harness.repos.javascript.IgniteUI.ignite_ui_1595_to_540 import *
from multi_swe_bench.harness.repos.javascript.IgniteUI.ignite_ui_507_to_375 import *
