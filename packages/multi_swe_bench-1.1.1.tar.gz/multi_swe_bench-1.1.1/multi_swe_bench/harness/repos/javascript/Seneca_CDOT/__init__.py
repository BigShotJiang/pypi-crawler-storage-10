from multi_swe_bench.harness.repos.javascript.Seneca_CDOT.telescope_3768_to_3431 import *
from multi_swe_bench.harness.repos.javascript.Seneca_CDOT.telescope_2200_to_2173 import *
from multi_swe_bench.harness.repos.javascript.Seneca_CDOT.telescope_1230_to_905 import *
from multi_swe_bench.harness.repos.javascript.Seneca_CDOT.telescope_905_to_345 import *
from multi_swe_bench.harness.repos.javascript.Seneca_CDOT.telescope_297_to_293 import *
