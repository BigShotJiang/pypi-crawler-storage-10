from multi_swe_bench.harness.repos.javascript.avajs.ava_2936_to_2729 import *
from multi_swe_bench.harness.repos.javascript.avajs.ava_1523_to_1262 import *
from multi_swe_bench.harness.repos.javascript.avajs.ava_1179_to_961 import *
from multi_swe_bench.harness.repos.javascript.avajs.ava_961_to_708 import *
from multi_swe_bench.harness.repos.javascript.avajs.ava_90_to_82 import *
from multi_swe_bench.harness.repos.javascript.avajs.ava_82_to_66 import *
