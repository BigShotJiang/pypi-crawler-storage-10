from multi_swe_bench.harness.repos.javascript.compasjs.compas_380_to_347 import *
