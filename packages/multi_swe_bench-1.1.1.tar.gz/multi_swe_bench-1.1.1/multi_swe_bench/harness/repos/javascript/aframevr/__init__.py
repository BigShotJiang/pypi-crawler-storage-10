from multi_swe_bench.harness.repos.javascript.aframevr.aframe_3517_to_3194 import *
from multi_swe_bench.harness.repos.javascript.aframevr.aframe_2334_to_1756 import *
from multi_swe_bench.harness.repos.javascript.aframevr.aframe_1748_to_1094 import *
from multi_swe_bench.harness.repos.javascript.aframevr.aframe_1094_to_843 import *
