from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_4261_to_3318 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_2941_to_2921 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_2921_to_2854 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_2720_to_1942 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_1807_to_1704 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_1704_to_1670 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_1628_to_990 import *
from multi_swe_bench.harness.repos.javascript.alphagov.govuk_frontend_990_to_707 import *
