from multi_swe_bench.harness.repos.golang.istio.istio import *
