from multi_swe_bench.harness.repos.golang.syncthing.syncthing import *
