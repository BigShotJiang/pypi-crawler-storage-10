def doc():
    print(r"""
p2() -> Pytesseract, Poppler
p3() -> Gradient Descent Scratch, Normal Equation
p4() -> Linear Regression (train-test, train-cv-test, regularised)
p5() -> Gaussian, Bernoulli, Multinomial
p6() -> Decision Tree (ID3 vs CART), GridSearchCV
p7() -> SVM GridSearchCV
p8() -> Perceptron (AND / OR)
p9() -> NN Scratch (XOR)
p10() -> KMeans Clustering
""")
    
def p2():
    print(r"""
#=============================CELL===========================
import matplotlib.pyplot as plt
from pdf2image import convert_from_path
import pytesseract
from PIL import Image


#=============================CELL===========================
img = Image.open('image.jpg') 
plt.imshow(img)
text = pytesseract.image_to_string(img)
print(text)

#=============================CELL===========================
img = Image.open('guj_image.png') 
plt.imshow(img)
text = pytesseract.image_to_string(img,lang='guj')
print(text)

#=============================CELL===========================
img = Image.open('hindi_image.png')
# Image.open(img)
text = pytesseract.image_to_string(img,lang='hin')
plt.imshow(img)
print(text)


#=============================CELL===========================
pages = convert_from_path('pdf.pdf', dpi=500,poppler_path="C:\\Program Files\\poppler-24.08.0\\Library\\bin")
print(pages)

for i, img in enumerate(pages):
    print(f"\n--- Page {i + 1} ---")
    
    # Show image (optional)
    plt.imshow(img)
    plt.axis('off')
    plt.show()

    text = pytesseract.image_to_string(img)
    print(text)


""")
    
def p3():
    print(r"""
#=============================CELL===========================
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

#=============================CELL===========================
x_train = [[1],[2],[3],[4],[5]]
y_train = [1,2,3,4,5]
w = [0,0,0,0,0]

#=============================CELL===========================
def calculate_gradient(x_train,y_train,w,b, lambda_):
    n = len(x_train[0])
    m = len(x_train)
    dj_dw = np.zeros((n,))
    dj_db = 0
    for i in range(m):
        error = (np.dot(x_train[i], w)+b) - y_train[i]
        for j in range(n):
            dj_dw[j]+=error*x_train[i][j]
        dj_db+=error
    dj_dw/=m
    dj_db/=m
    for i in range(n):
        dj_dw[i] += (lambda_ / m) * w[i]
    return dj_dw, dj_db

#=============================CELL===========================
def gradient_descent(x_train, y_train, w_init,b_init, epochs, learning_rate,lambda_):
    w = w_init
    b = b_init
    for i in range(epochs):
        dj_dw, dj_db = calculate_gradient(x_train, y_train, w, b,lambda_)
        w-=learning_rate*dj_dw
        b-=learning_rate*dj_db
    return w, b

#=============================CELL===========================
w_init = np.zeros_like(x_train[0], dtype=float)
b_init = 0.0
alpha = 0.01
num_iters = 10000
lambda_ = 0
w_final, b_final = gradient_descent(x_train, y_train, w_init, b_init, 100000, 0.01,lambda_)

#=============================CELL===========================
print(w_final, b_final)

#=============================CELL===========================
import plotly.graph_objects as go

# Flatten input - convert to numpy array first
x_train_array = np.array(x_train)
size = x_train_array.flatten()
price = y_train
dummy_axis = np.zeros_like(size)

# Create prediction line
x_line = np.linspace(min(size), max(size), 50)
y_line = w_final[0] * x_line + b_final
z_line = y_line
dummy_line = np.zeros_like(x_line)

# Create 3D scatter + line
fig = go.Figure()

# Training data points
fig.add_trace(go.Scatter3d(
    x=size,
    y=dummy_axis,
    z=price,
    mode='markers',
    marker=dict(size=8, color='red'),
    name='Training Data'
))

# Regression line
fig.add_trace(go.Scatter3d(
    x=x_line,
    y=dummy_line,
    z=z_line,
    mode='lines',
    line=dict(color='blue', width=1),
    name='Regression Line'
))

# Layout
fig.update_layout(
    scene=dict(
        xaxis_title='Feature (x)',
        yaxis_title='Dummy Axis',
        zaxis_title='Price (y)'
    ),
    title='1D Linear Regression - Interactive Plot',
    margin=dict(l=0, r=0, b=0, t=30)
)

fig.show()

#=============================CELL===========================
import numpy as np

def normal_equation(X, y):
    
    X = np.array(X)
    y = np.array(y)

    theta = np.linalg.inv(X.T @ X) @ X.T @ y
    return theta


if __name__ == "__main__":
    X = np.array([[1, 1],
                [1, 2],
                [1, 3],
                [1, 4]])
    y = np.array([2, 4, 6, 8])

    theta = normal_equation(X, y)
    print("Optimal parameters:", theta)


#=============================CELL===========================

x_values_3d = X[:, 1]  
y_values_3d = y        
dummy_axis = np.zeros_like(x_values_3d)

x_line_3d = np.linspace(min(x_values_3d), max(x_values_3d), 50)
X_line_3d = np.column_stack([np.ones(len(x_line_3d)), x_line_3d])
y_line_3d = X_line_3d @ theta
dummy_line = np.zeros_like(x_line_3d)

fig_3d = go.Figure()

fig_3d.add_trace(go.Scatter3d(
    x=x_values_3d,
    y=dummy_axis,
    z=y_values_3d,
    mode='markers',
    marker=dict(size=8, color='red'),
    name='Training Data'
))

fig_3d.add_trace(go.Scatter3d(
    x=x_line_3d,
    y=dummy_line,
    z=y_line_3d,
    mode='lines',
    line=dict(color='blue', width=4),
    name='Normal Equation Line'
))

fig_3d.update_layout(
    scene=dict(
        xaxis_title='Feature (x)',
        yaxis_title='Dummy Axis',
        zaxis_title='Target (y)'
    ),
    title='Normal Equation Linear Regression - 3D Interactive Plot',
    margin=dict(l=0, r=0, b=0, t=30)
)

fig_3d.show()


""")
    
def p4():
    print(r"""
#=============================CELL===========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

#=============================CELL===========================


X = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]])
y = np.array([3, 4, 2, 5, 6, 7, 8, 9, 10, 12])


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Slope (Coefficient):", model.coef_)
print("Intercept:", model.intercept_)

print("Mean Squared Error (MSE):", mean_squared_error(y_test, y_pred))
print("R² Score:", r2_score(y_test, y_pred))

plt.scatter(X, y, color='blue', label='Actual Data')
plt.plot(X, model.predict(X), color='red', label='Regression Line')
plt.xlabel("X")
plt.ylabel("y")
plt.title("Linear Regression using scikit-learn")
plt.legend()
plt.grid(True)
plt.show()


#=============================CELL===========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score


X = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]])
y = np.array([3, 4, 2, 5, 6, 7, 8, 9, 10, 12])


X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, random_state=42)
X_cv, X_test, y_cv, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

print(f"Train size: {len(X_train)}, CV size: {len(X_cv)}, Test size: {len(X_test)}")


model = LinearRegression()
model.fit(X_train, y_train)


y_cv_pred = model.predict(X_cv)
print("\n--- Validation Set Evaluation ---")
print("MSE (CV):", mean_squared_error(y_cv, y_cv_pred))
print("R² Score (CV):", r2_score(y_cv, y_cv_pred))


y_test_pred = model.predict(X_test)
print("\n--- Test Set Evaluation ---")
print("Slope (Coefficient):", model.coef_[0])
print("Intercept:", model.intercept_)
print("MSE (Test):", mean_squared_error(y_test, y_test_pred))
print("R² Score (Test):", r2_score(y_test, y_test_pred))


plt.scatter(X_train, y_train, color='blue', label='Train Data')
plt.scatter(X_cv, y_cv, color='green', label='CV Data')
plt.scatter(X_test, y_test, color='orange', label='Test Data')

plt.plot(X, model.predict(X), color='red', linewidth=2, label='Regression Line')

plt.xlabel("X")
plt.ylabel("y")
plt.title("Linear Regression (Train / CV / Test)")
plt.legend()
plt.grid(True)
plt.show()


#=============================CELL===========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.metrics import mean_squared_error, r2_score

X = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]])
y = np.array([3, 4, 2, 5, 6, 7, 8, 9, 10, 12])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


model = Ridge(alpha=1.0)

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Slope (Coefficient):", model.coef_)
print("Intercept:", model.intercept_)

print("Mean Squared Error (MSE):", mean_squared_error(y_test, y_pred))

plt.scatter(X, y, color='blue', label='Actual Data')
plt.plot(X, model.predict(X), color='red', label='Regularized Regression Line')
plt.xlabel("X")
plt.ylabel("y")
plt.title("Regularized Linear Regression (Ridge)")
plt.legend()
plt.grid(True)
plt.show()

""")
    
def p5():
    print(r"""
#=============================CELL===========================
from sklearn.datasets import load_iris
iris = load_iris()

X = iris.data
y = iris.target

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=1)

from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_pred = gnb.predict(X_test)

from sklearn import metrics
print("Gaussian Naive Bayes model accuracy(in %):", metrics.accuracy_score(y_test, y_pred)*100)

#=============================CELL===========================
from sklearn.datasets import load_iris
iris = load_iris()

X = iris.data
y = iris.target

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.4, random_state=1)

from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
gnb.fit(X_train, y_train)

y_pred = gnb.predict(X_test)

from sklearn import metrics
print("Gaussian Naive Bayes model accuracy(in %):", metrics.accuracy_score(y_test, y_pred)*100)

#=============================CELL===========================
import numpy as np
import pandas as pd
from sklearn.naive_bayes import BernoulliNB
from sklearn.feature_extraction.text import CountVectorizer

#=============================CELL===========================
df=pd.read_csv("./spam_ham_dataset.csv")
print(df.shape)
print(df.columns)
df= df.drop(['Unnamed: 0'], axis=1)

#=============================CELL===========================
x = df["text"].values
y = df["label_num"].values

cv = CountVectorizer()

x = cv.fit_transform(x)

#=============================CELL===========================
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.20, random_state=0)

#=============================CELL===========================
X_train

#=============================CELL===========================
bnb = BernoulliNB(binarize=0.0)
model = bnb.fit(X_train, y_train)
y_pred = bnb.predict(X_test)

from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))

#=============================CELL===========================
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

#=============================CELL===========================
data = {
    'text': [
        'Free money now',
        'Call now to claim your prize',
        'Meet me at the park',
        'Lets catch up later',
        'Win a new car today!',
        'Lunch plans?',
        'Congratulations! You won a lottery',
        'Can you send me the report?',
        'Exclusive offer for you',
        'Are you coming to the meeting?'
    ],
    'label': ['spam', 'spam', 'not spam', 'not spam', 'spam', 'not spam', 'spam', 'not spam', 'spam', 'not spam']
}

df = pd.DataFrame(data)

#=============================CELL===========================
df['label'] = df['label'].map({'spam': 1, 'not spam': 0})

#=============================CELL===========================
X = df['text']
y = df['label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

#=============================CELL===========================
vectorizer = CountVectorizer()
X_train_vectors = vectorizer.fit_transform(X_train)
X_test_vectors = vectorizer.transform(X_test)

#=============================CELL===========================
model = MultinomialNB()
model.fit(X_train_vectors, y_train)

#=============================CELL===========================
y_pred = model.predict(X_test_vectors)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%\n")

#=============================CELL===========================
custom_message = ["Congratulations, you've won a free vacation"]
print(custom_message)
custom_vector = vectorizer.transform(custom_message)
prediction = model.predict(custom_vector)
print("Prediction for custom message:", "Spam" if prediction[0] == 1 else "Not Spam")
""")
    
def p6():
    print(r"""
#=============================CELL===========================
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import pandas as pd



iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)


def train_and_evaluate(criterion, min_samples_split, min_samples_leaf, max_depth):
    clf = DecisionTreeClassifier(
        criterion=criterion,
        min_samples_split=min_samples_split,
        min_samples_leaf=min_samples_leaf,
        max_depth=max_depth,
        random_state=42
    )
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    return acc


results = []
for criterion in ["entropy", "gini"]:  # entropy ~ ID3, gini ~ CART
    for min_samples_split in [2, 5, 10]:
        for min_samples_leaf in [1, 2, 4]:
            for max_depth in [None, 3, 5]:
                acc = train_and_evaluate(criterion, min_samples_split, min_samples_leaf, max_depth)
                results.append({
                    "criterion": criterion,
                    "min_samples_split": min_samples_split,
                    "min_samples_leaf": min_samples_leaf,
                    "max_depth": max_depth,
                    "accuracy": acc
                })

df_results = pd.DataFrame(results)
print(df_results.sort_values(by="accuracy", ascending=False).head(10))


#=============================CELL===========================
from sklearn import tree
import matplotlib.pyplot as plt

clf = DecisionTreeClassifier(criterion='entropy', max_depth=3, random_state=42)
clf.fit(X_train, y_train)

plt.figure(figsize=(15,8))
tree.plot_tree(clf, feature_names=iris.feature_names, class_names=iris.target_names, filled=True)
plt.show()


#=============================CELL===========================
from sklearn.model_selection import GridSearchCV

param_grid = {
    'criterion': ['entropy', 'gini'],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_depth': [None, 3, 5]
}

grid = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid, cv=5)
grid.fit(X_train, y_train)

print("Best Parameters:", grid.best_params_)
print("Best Cross-Val Accuracy:", grid.best_score_)


#=============================CELL===========================



""")
    
def p7():
    print(r"""
#=============================CELL===========================
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.datasets import make_classification
import plotly.graph_objects as go


X, y = make_classification(
    n_samples=200,
    n_features=3,
    n_informative=3,
    n_redundant=0,
    n_clusters_per_class=1,
    class_sep=1.5,
    random_state=42
)


param_grid = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'rbf'],
    'gamma': ['scale', 'auto']
}

grid_search = GridSearchCV(SVC(), param_grid, cv=5)
grid_search.fit(X, y)

best_model = grid_search.best_estimator_
print("Best Parameters (Classification):", grid_search.best_params_)


if best_model.kernel == 'linear':
    w = best_model.coef_[0]
    b = best_model.intercept_[0]

    x_range = np.linspace(X[:, 0].min(), X[:, 0].max(), 20)
    y_range = np.linspace(X[:, 1].min(), X[:, 1].max(), 20)
    xx, yy = np.meshgrid(x_range, y_range)
    zz = (-w[0]*xx - w[1]*yy - b) / w[2]

    fig = go.Figure()

    fig.add_trace(go.Scatter3d(
        x=X[:, 0], y=X[:, 1], z=X[:, 2],
        mode='markers',
        marker=dict(size=5, color=y, colorscale='RdBu', opacity=0.8),
        name='Data Points'
    ))

    sv = X[best_model.support_]
    fig.add_trace(go.Scatter3d(
        x=sv[:, 0], y=sv[:, 1], z=sv[:, 2],
        mode='markers',
        marker=dict(size=8, color='green', symbol='diamond'),
        name='Support Vectors'
    ))

    fig.add_trace(go.Surface(
        x=xx, y=yy, z=zz,
        colorscale='gray',
        opacity=0.5,
        name='Hyperplane'
    ))

    fig.update_layout(
        title='SVM Classification Hyperplane (3D)',
        scene=dict(
            xaxis_title='X1',
            yaxis_title='X2',
            zaxis_title='X3'
        ),
        width=800,
        height=700
    )

    fig.show()
else:
    print("Best kernel is not linear — visualization of hyperplane only supported for linear kernel.")


#=============================CELL===========================
import numpy as np
from sklearn.svm import SVR
from sklearn.datasets import make_regression
from sklearn.model_selection import GridSearchCV
import plotly.graph_objects as go

X_reg, y_reg = make_regression(
    n_samples=200,
    n_features=2,
    noise=10,
    random_state=42
)
y_reg = y_reg + 0.5 * (X_reg[:, 0]**2)  # add non-linearity


param_grid_reg = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'rbf'],
    'gamma': ['scale', 'auto'],
    'epsilon': [0.1, 0.2, 0.5]
}

grid_search_reg = GridSearchCV(SVR(), param_grid_reg, cv=5)
grid_search_reg.fit(X_reg, y_reg)

best_model_reg = grid_search_reg.best_estimator_
print("Best Parameters (Regression):", grid_search_reg.best_params_)


x_range = np.linspace(X_reg[:, 0].min(), X_reg[:, 0].max(), 30)
y_range = np.linspace(X_reg[:, 1].min(), X_reg[:, 1].max(), 30)
xx, yy = np.meshgrid(x_range, y_range)

zz = best_model_reg.predict(np.c_[xx.ravel(), yy.ravel()])
zz = zz.reshape(xx.shape)


fig = go.Figure()

fig.add_trace(go.Scatter3d(
    x=X_reg[:, 0], y=X_reg[:, 1], z=y_reg,
    mode='markers',
    marker=dict(size=5, color='red'),
    name='Data Points'
))

fig.add_trace(go.Surface(
    x=xx, y=yy, z=zz,
    colorscale='Viridis',
    opacity=0.7,
    name='SVR Surface'
))

fig.update_layout(
    title='Support Vector Regression Surface (3D)',
    scene=dict(
        xaxis_title='X1',
        yaxis_title='X2',
        zaxis_title='Y'
    ),
    width=800,
    height=700
)

fig.show()


#=============================CELL===========================



""")
    
def p8():
    print(r"""
#=============================CELL===========================
import numpy as np

class Perceptron:
    
    def __init__(self, learning_rate=0.1, n_iters=100):
        self.lr = learning_rate
        self.n_iters = n_iters
        self.activation_func = self._step_function
        self.weights = None
        self.bias = 0

    def _step_function(self, x):
        return 1 if x >= 0 else 0

    def fit(self, X, y):
        
        n_samples, n_features = X.shape

        self.weights = np.zeros(n_features)
        self.bias = 0
        
        y_ = np.array([1 if i > 0 else 0 for i in y])

        for _ in range(self.n_iters):
            for idx, x_i in enumerate(X):
                linear_output = np.dot(x_i, self.weights) + self.bias
                
                y_predicted = self.activation_func(linear_output)

                update = self.lr * (y_[idx] - y_predicted)
                self.weights += update * x_i
                self.bias += update

    def predict(self, X):
        
        linear_output = np.dot(X, self.weights) + self.bias
        y_predicted = self.activation_func(linear_output)
        return y_predicted



X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])

print("--- AND Gate ---")
y_and = np.array([0, 0, 0, 1])

p_and = Perceptron(learning_rate=0.1, n_iters=10)
p_and.fit(X, y_and)

print(f"Final Weights: {p_and.weights}")
print(f"Final Bias: {p_and.bias:.2f}\n")

print("Testing the AND gate Perceptron:")
print(f"0 AND 0 = {p_and.predict(np.array([0, 0]))}")
print(f"0 AND 1 = {p_and.predict(np.array([0, 1]))}")
print(f"1 AND 0 = {p_and.predict(np.array([1, 0]))}")
print(f"1 AND 1 = {p_and.predict(np.array([1, 1]))}")
print("-" * 20)

print("\n--- OR Gate ---")
y_or = np.array([0, 1, 1, 1])

p_or = Perceptron(learning_rate=0.1, n_iters=10)
p_or.fit(X, y_or)

print(f"Final Weights: {p_or.weights}")
print(f"Final Bias: {p_or.bias:.2f}\n")

print("Testing the OR gate Perceptron:")
print(f"0 OR 0 = {p_or.predict(np.array([0, 0]))}")
print(f"0 OR 1 = {p_or.predict(np.array([0, 1]))}")
print(f"1 OR 0 = {p_or.predict(np.array([1, 0]))}")
print(f"1 OR 1 = {p_or.predict(np.array([1, 1]))}")
print("-" * 20)


""")
    
def p9():
    print(r"""
#=============================CELL===========================
import numpy as np

class NeuralNetwork:
    

    def __init__(self, learning_rate=0.1):
        self.learning_rate = learning_rate

        self.weights_ih = np.random.rand(2, 2) 
        self.weights_ho = np.random.rand(2, 1)

        self.bias_h = np.random.rand(1, 2)
        self.bias_o = np.random.rand(1, 1)

    def _sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def _sigmoid_derivative(self, x):
        return x * (1 - x)

    def forward(self, X):
        self.hidden_sum = np.dot(X, self.weights_ih) + self.bias_h
        self.hidden_activated = self._sigmoid(self.hidden_sum)

        self.output_sum = np.dot(self.hidden_activated, self.weights_ho) + self.bias_o
        self.output_activated = self._sigmoid(self.output_sum)
        
        return self.output_activated

    def backward(self, X, y, output):
        output_error = y - output # 1,1
        output_delta = output_error * self._sigmoid_derivative(output) # 1,1

        hidden_error = output_delta.dot(self.weights_ho.T) # 1,1 * 1,2 = 1,2
        hidden_delta = hidden_error * self._sigmoid_derivative(self.hidden_activated) # 1,2 * 
        
        self.weights_ho += self.hidden_activated.T.dot(output_delta) * self.learning_rate
        self.weights_ih += X.T.dot(hidden_delta) * self.learning_rate
        
        self.bias_o += np.sum(output_delta, axis=0, keepdims=True) * self.learning_rate
        self.bias_h += np.sum(hidden_delta, axis=0, keepdims=True) * self.learning_rate


    def train(self, X, y, epochs=10000):
        for i in range(epochs):
            output = self.forward(X)
            self.backward(X, y, output)
            
            if (i % 1000) == 0:
                loss = np.mean(np.square(y - output))
                print(f"Epoch {i}: Loss = {loss:.4f}")

    def predict(self, X):
        return self.forward(X)


X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([[0], [1], [1], [0]]) 

nn = NeuralNetwork(learning_rate=0.5)
print("--- Training XOR Gate ---")
nn.train(X, y, epochs=20000)
print("Training complete.\n" + "-"*25)

print("--- Testing the trained XOR Gate ---")
for inputs in X:
    prediction = nn.predict(inputs)
    predicted_class = 1 if prediction > 0.5 else 0
    print(f"{inputs[0]} XOR {inputs[1]} -> Raw: {prediction[0][0]:.4f}, Predicted: {predicted_class}")

#=============================CELL===========================



""")

def p10():
    print(r"""
#=============================CELL===========================
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import pandas as pd

from sklearn.datasets import load_iris

iris=load_iris()
df=pd.DataFrame(iris.data,columns=iris.feature_names)
y=iris.target

df['Target']=y
df

df.drop(['sepal width (cm)','sepal length (cm)'],axis=1,inplace=True)

plt.scatter(df['petal length (cm)'],df['petal width (cm)'])


#=============================CELL===========================
km=KMeans(n_clusters=3)
df
X=df.iloc[:,:-1]
# X
y_pred=km.fit_predict(X)
y_pred


#=============================CELL===========================
df['Cluster']=y_pred
df

df1=df[df['Cluster']==0]
df2=df[df['Cluster']==1]
df3=df[df['Cluster']==2]

print(df1.shape)
print(df2.shape)
print(df3.shape)


#=============================CELL===========================
plt.scatter(df1['petal length (cm)'], df1['petal width (cm)'],color='green')
plt.scatter(df2['petal length (cm)'], df2['petal width (cm)'],color='red')
plt.scatter(df3['petal length (cm)'], df3['petal width (cm)'],color='black')
plt.scatter(km.cluster_centers_[:,0],km.cluster_centers_[:,1],color='purple',marker='*')

#=============================CELL===========================
km.cluster_centers_

#=============================CELL===========================
from sklearn.cluster import KMeans

wcss=[]
for i in range(1,11):
    km=KMeans(n_clusters=i)
    km.fit_predict(X)
    wcss.append(km.inertia_)

wcss


#=============================CELL===========================
plt.plot(range(1,11),wcss)


""")