"""
:module_title:`Patterning`
"""