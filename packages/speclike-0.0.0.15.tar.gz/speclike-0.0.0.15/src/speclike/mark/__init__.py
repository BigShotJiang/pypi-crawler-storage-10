
from speclike.mark.mod import setup, invariant, before, after, spec

__all__ = ("setup", "invariant", "before", "after", "spec")
