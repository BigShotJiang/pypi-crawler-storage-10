
from speclike.dispatch.mod import Test, Spec

__all__ = ("Test", "Spec")
