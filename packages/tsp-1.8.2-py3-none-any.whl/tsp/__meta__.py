# Automatically created. Please do not edit.
__version__ = '1.8.2'
__author__ = 'Nick Brown'
