:tocdepth: 3

Widgets and Qt helpers
======================

.. automodule:: guidata.qthelpers

.. automodule:: guidata.widgets
