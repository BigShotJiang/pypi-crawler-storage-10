from __future__ import annotations


class ConfigurationError(Exception):
    pass
