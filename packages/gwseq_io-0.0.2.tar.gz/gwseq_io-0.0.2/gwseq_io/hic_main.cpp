#pragma once

#include "hic_headers.cpp"
#include "hic_locs.cpp"
#include "hic_matrices_metadata.cpp"
#include "hic_matrices_data.cpp"
#include "hic_reader.cpp"
