#pragma once

#include "util/main.cpp"
#include "bbi_main.cpp"
#include "hic_main.cpp"
#include "genomes.cpp"
