# 🍰 Tiramisu Framework

A powerful multi-expert RAG (Retrieval-Augmented Generation) framework for building domain-specific AI consultancy systems.

[![Python Version](https://img.shields.io/badge/python-3.11%20%7C%203.12-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/tiramisu-framework.svg)](https://badge.fury.io/py/tiramisu-framework)

## 🚀 Quick Start
```bash
pip install tiramisu-framework

# Initialize a new project
tiramisu init my-consultant

# Add your documents
tiramisu add-docs ./documents

# Build the vector index
tiramisu build-index

# Start the API server
tiramisu run
```

## ✨ Features

- **Chain-of-Thought RAG**: Advanced reasoning with step-by-step analysis
- **Multi-Expert Synthesis**: Combine multiple domain perspectives
- **Conversational Memory**: Maintain context across interactions
- **Production Ready**: FastAPI backend + Next.js frontend
- **Flexible Storage**: SQLite default, PostgreSQL ready
- **Modern Stack**: LangChain, FAISS, GPT-4o integration

## 📚 Documentation

- [Installation Guide](docs/installation.md)
- [Quick Start Tutorial](docs/quickstart.md)
- [Architecture Overview](docs/architecture.md)
- [API Reference](docs/api.md)

## 💻 Python API
```python
from tiramisu import TiramisuRAG

# Initialize with your documents
rag = TiramisuRAG(
    documents_path='./knowledge_base',
    experts=['domain_expert_1', 'domain_expert_2'],
    model='gpt-4o'
)

# Build the index
rag.build_index()

# Query the system
response = rag.chat("How can I improve my strategy?")
print(response.answer)
print(response.sources)
```

## ��️ Architecture

Tiramisu uses a modular architecture:
```
Client Request
    ↓
FastAPI Router
    ↓
Chain-of-Thought Orchestrator
    ↓
FAISS Vector Search → Document Retrieval
    ↓
GPT-4o Processing → Response Generation
    ↓
SQLite Persistence → Conversation Memory
```

## 🛠️ Development
```bash
# Clone the repository
git clone https://github.com/tiramisu-framework/tiramisu-framework
cd tiramisu-framework

# Install in development mode
pip install -e .

# Run tests
pytest tests/
```

## 📈 Roadmap

- [x] Core RAG implementation
- [x] Chain-of-Thought reasoning
- [x] REST API
- [x] CLI tools
- [ ] Web UI for document upload
- [ ] Multi-LLM support
- [ ] Plugin system
- [ ] Analytics dashboard

## 📄 Legal Notice

The Tiramisu Framework is an independent research and development project created by Jony Wolff.

It represents an original synthesis of marketing, communication, and innovation concepts structured into an artificial intelligence persona designed for strategic analysis.

This framework does not reproduce, quote, or redistribute the intellectual property of any specific author or organization. It was inspired by general schools of thought in marketing and digital transformation, not by any individual or copyrighted material.

Any resemblance to known experts or methodologies is conceptual and educational in nature, used solely to illustrate how diverse perspectives in marketing strategy can be harmonized through AI reasoning.

All intellectual property related to the system's design, code, structure, and outputs belongs exclusively to Jony Wolff.

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

Built with modern AI technologies including LangChain, FAISS, and OpenAI GPT models.

---

© 2025 Jony Wolff. All rights reserved.
