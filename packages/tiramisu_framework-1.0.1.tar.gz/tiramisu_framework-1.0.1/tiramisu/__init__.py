"""
Tiramisu Framework
Copyright (c) 2025 Jony Wolff. All rights reserved.
Licensed under MIT License.
"""

__version__ = "1.0.1"
__author__ = "Jony Wolff"
__email__ = "frameworktiramisu@gmail.com"

from tiramisu.core.tiramisu_rag import TiramisuRAG

__all__ = ["TiramisuRAG", "__version__"]
