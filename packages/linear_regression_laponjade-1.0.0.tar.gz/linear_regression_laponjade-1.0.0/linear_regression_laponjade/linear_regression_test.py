from linear_regression_laponjade import LinearRegression
import matplotlib.pyplot as plt
import numpy as np

# Set a random seed for reproducible results
np.random.seed(0)

# Create the independent variable (features)
# Reshaped to (10, 1) for a single feature
X = np.arange(1, 11)

# Create the dependent variable (targets)
# The formula is 2x + 1 + random_noise
y = 2 * X.flatten() + 1 + np.random.normal(0, 0.5, size=10)

print(X)
print(y)

regressor = LinearRegression(X, y)
regressor.fit(1000 , 0.0001) # epochs-1000 , learning_rate - 0.0001
 
#Prediciting the values
y_pred = regressor.predict(X)
 
#Plotting the results
plt.figure(figsize = (10,6))
plt.scatter(X, y , color = 'green')
plt.plot(X , y_pred , color = 'k' , lw = 3)
plt.xlabel('x' , size = 20)
plt.ylabel('y', size = 20)
plt.show()