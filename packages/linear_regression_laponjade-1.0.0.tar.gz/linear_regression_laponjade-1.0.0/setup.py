from setuptools import find_packages, setup


setup(
    name='linear_regression_laponjade',
    version='1.0.0',
    author='Mehdi Dib',
    author_email='mehdi.dib13@gmail.com',
    packages=find_packages(),
    url='http://pypi.python.org/pypi/linear_regression_laponjade/',
    license='LICENSE.txt',
    description='A simple simulation package for Linear Regression.',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    install_requires=[
        'numpy',
        'matplotlib'
    ],
    python_requires='>=3.8',
)