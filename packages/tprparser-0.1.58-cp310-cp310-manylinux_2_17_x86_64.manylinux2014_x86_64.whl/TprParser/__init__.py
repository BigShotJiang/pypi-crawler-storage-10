from .TprReader import TprReader
from .EdrReader import EdrReader
from .version import __version__

