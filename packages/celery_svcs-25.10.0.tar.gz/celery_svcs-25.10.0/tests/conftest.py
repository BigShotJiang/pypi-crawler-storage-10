pytest_plugins = ["celery.contrib.pytest"]
