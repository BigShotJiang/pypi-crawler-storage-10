"""
Модуль для управления серверами «Imagenarium»

Обеспечивает хранение и управление списком серверов с учетными данными
в соответствии с канонами каждой операционной системы.
"""

import os
import json
import keyring
from pathlib import Path
from typing import Dict, List, Optional, NamedTuple
from dataclasses import dataclass, asdict
from .config import Config


@dataclass
class ServerInfo:
    """Информация о сервере"""

    name: str
    url: str
    username: str
    description: Optional[str] = None
    is_default: bool = False

    def to_dict(self) -> Dict:
        """Преобразует в словарь"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict) -> "ServerInfo":
        """Создает из словаря"""
        return cls(**data)


class ServerManager:
    """Менеджер серверов"""

    def __init__(self):
        self.config_dir = self._get_config_dir()
        self.servers_file = self.config_dir / "servers.json"
        self._ensure_config_dir()
        self._keyring_available = self._setup_keyring()

    def _get_config_dir(self) -> Path:
        """Получает директорию конфигурации в соответствии с канонами ОС"""
        if os.name == "nt":  # Windows
            config_dir = Path(os.environ.get("APPDATA", "")) / "imgctl"
        else:  # Unix-like (Linux, macOS)
            config_dir = Path.home() / ".config" / "imgctl"

        return config_dir

    def _ensure_config_dir(self):
        """Создает директорию конфигурации если не существует с безопасными правами доступа"""
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # Устанавливаем безопасные права доступа (только для владельца)
        import stat

        if os.name != "nt":  # Не Windows
            # 0o700 = rwx------ (только владелец может читать/писать/выполнять)
            self.config_dir.chmod(stat.S_IRWXU)

    def _load_servers(self) -> Dict[str, ServerInfo]:
        """Загружает список серверов из файла"""
        if not self.servers_file.exists():
            return {}

        try:
            with open(self.servers_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {
                    name: ServerInfo.from_dict(server_data)
                    for name, server_data in data.items()
                }
        except Exception:
            return {}

    def _save_servers(self, servers: Dict[str, ServerInfo]):
        """Сохраняет список серверов в файл с безопасными правами доступа"""
        try:
            import tempfile
            import stat
            import shutil

            data = {name: server.to_dict() for name, server in servers.items()}

            # Создаем временный файл для атомарной записи
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=self.config_dir,
                delete=False,
                prefix=".servers_",
                suffix=".tmp",
            ) as temp_file:
                json.dump(data, temp_file, indent=2, ensure_ascii=False)
                temp_path = temp_file.name

            # Устанавливаем безопасные права доступа
            if os.name != "nt":  # Не Windows
                # 0o600 = rw------- (только владелец может читать/писать)
                os.chmod(temp_path, stat.S_IRUSR | stat.S_IWUSR)

            # Атомарно перемещаем временный файл в целевой
            shutil.move(temp_path, self.servers_file)

        except Exception as e:
            raise Exception(f"Ошибка сохранения серверов: {e}")

    def _setup_keyring(self) -> bool:
        """Настраивает keyring с fallback на файловый бэкенд
        
        Returns:
            bool: True если keyring доступен и не запрашивает пароль
        """
        try:
            # Сначала пытаемся использовать текущий бэкенд
            backend = keyring.get_keyring()
            backend_name = type(backend).__name__
            
            # Если используется рекомендуемый бэкенд (macOS Keychain, Windows Credential Manager, SecretService)
            # и он работает, используем его
            if not ("Fail" in backend_name or "Plaintext" in backend_name):
                # Тестируем работу бэкенда
                test_service = "__imgctl_test__"
                test_key = "__test_key__"
                test_value = "__test_value__"
                
                try:
                    keyring.set_password(test_service, test_key, test_value)
                    retrieved = keyring.get_password(test_service, test_key)
                    keyring.delete_password(test_service, test_key)
                    if retrieved == test_value:
                        # Бэкенд работает, используем его
                        return True
                except Exception:
                    pass
            
            # Если основной бэкенд не работает, ОБЯЗАТЕЛЬНО устанавливаем PlaintextKeyring
            # Пытаемся из keyring.backends.file, если недоступен - из keyrings.alt.file
            try:
                try:
                    from keyring.backends.file import PlaintextKeyring
                except ImportError:
                    # Fallback на keyrings.alt для старых версий keyring
                    from keyrings.alt.file import PlaintextKeyring
                
                keyring_file = self.config_dir / "keyring_pass.cfg"
                plaintext_keyring = PlaintextKeyring()
                plaintext_keyring.file_path = str(keyring_file)
                # ВАЖНО: устанавливаем PlaintextKeyring ДО теста
                keyring.set_keyring(plaintext_keyring)
                
                # Тестируем что PlaintextKeyring работает без запросов
                try:
                    test_service = "__imgctl_test__"
                    test_key = "__test_key__"
                    test_value = "__test_value__"
                    keyring.set_password(test_service, test_key, test_value)
                    retrieved = keyring.get_password(test_service, test_key)
                    keyring.delete_password(test_service, test_key)
                    if retrieved == test_value:
                        return True
                except Exception:
                    # Даже если тест не прошел, PlaintextKeyring уже установлен
                    # Он будет использоваться при следующих вызовах
                    return True  # Возвращаем True, т.к. бэкенд установлен
            except ImportError:
                # Если PlaintextKeyring недоступен, не используем keyring
                return False
            except Exception:
                return False
        except Exception:
            # В случае ошибки все равно пытаемся установить PlaintextKeyring
            try:
                try:
                    from keyring.backends.file import PlaintextKeyring
                except ImportError:
                    from keyrings.alt.file import PlaintextKeyring
                keyring_file = self.config_dir / "keyring_pass.cfg"
                plaintext_keyring = PlaintextKeyring()
                plaintext_keyring.file_path = str(keyring_file)
                keyring.set_keyring(plaintext_keyring)
                return True
            except Exception:
                return False
        return False

    def _get_password(self, server_name: str) -> Optional[str]:
        """Получает пароль из keyring"""
        try:
            return keyring.get_password("imgctl", server_name)
        except Exception:
            return None

    def _set_password(self, server_name: str, password: str):
        """Сохраняет пароль в keyring"""
        try:
            keyring.set_password("imgctl", server_name, password)
        except Exception as e:
            raise Exception(f"Ошибка сохранения пароля: {e}")

    def _delete_password(self, server_name: str):
        """Удаляет пароль из keyring"""
        try:
            keyring.delete_password("imgctl", server_name)
        except Exception:
            pass  # Игнорируем ошибки при удалении

    def add_server(
        self,
        name: str,
        url: str,
        username: str,
        password: str,
        description: Optional[str] = None,
        is_default: bool = False,
    ) -> None:
        """Добавляет новый сервер"""
        servers = self._load_servers()

        if name in servers:
            raise ValueError(f"Сервер с именем '{name}' уже существует")

        # Валидация URL
        if not url.startswith(("http://", "https://")):
            raise ValueError("URL должен начинаться с http:// или https://")

        server = ServerInfo(
            name=name,
            url=url.rstrip("/"),
            username=username,
            description=description,
            is_default=is_default,
        )

        # Если это новый сервер по умолчанию, снимаем флаг с остальных
        if is_default:
            for existing_server in servers.values():
                existing_server.is_default = False

        servers[name] = server
        self._save_servers(servers)
        self._set_password(name, password)

    def remove_server(self, name: str) -> None:
        """Удаляет сервер"""
        servers = self._load_servers()

        if name not in servers:
            raise ValueError(f"Сервер с именем '{name}' не найден")

        del servers[name]
        self._save_servers(servers)
        self._delete_password(name)

    def list_servers(self) -> List[ServerInfo]:
        """Возвращает список серверов"""
        servers = self._load_servers()
        return list(servers.values())

    def get_server(self, name: str) -> Optional[ServerInfo]:
        """Получает информацию о сервере"""
        servers = self._load_servers()
        return servers.get(name)

    def get_default_server(self) -> Optional[ServerInfo]:
        """Получает сервер по умолчанию"""
        servers = self._load_servers()
        for server in servers.values():
            if server.is_default:
                return server
        return None

    def set_default_server(self, name: str) -> None:
        """Устанавливает сервер по умолчанию"""
        servers = self._load_servers()

        if name not in servers:
            raise ValueError(f"Сервер с именем '{name}' не найден")

        # Снимаем флаг с остальных серверов
        for server in servers.values():
            server.is_default = False

        # Устанавливаем флаг для указанного сервера
        servers[name].is_default = True
        self._save_servers(servers)

    def get_config_for_server(self, server_name: Optional[str] = None) -> Config:
        """Получает конфигурацию для указанного сервера"""
        config = Config()

        if server_name:
            server = self.get_server(server_name)
            if not server:
                raise ValueError(f"Сервер '{server_name}' не найден")
        else:
            server = self.get_default_server()
            if not server:
                raise ValueError(
                    "Нет сервера по умолчанию. Добавьте сервер командой 'servers add'"
                )

        config.server = server.url
        config.username = server.username
        config.password = self._get_password(server.name)

        return config

    def update_server(self, name: str, **kwargs) -> None:
        """Обновляет информацию о сервере"""
        servers = self._load_servers()

        if name not in servers:
            raise ValueError(f"Сервер с именем '{name}' не найден")

        server = servers[name]

        # Обновляем поля
        for key, value in kwargs.items():
            if hasattr(server, key) and value is not None:
                setattr(server, key, value)

        # Если устанавливается как сервер по умолчанию
        if kwargs.get("is_default", False):
            for existing_server in servers.values():
                existing_server.is_default = False
            server.is_default = True

        self._save_servers(servers)

        # Обновляем пароль если указан
        if "password" in kwargs:
            self._set_password(name, kwargs["password"])
