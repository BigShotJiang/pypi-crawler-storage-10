from .wide import GlobalAncestryObject
from .local import LocalAncestryObject

__all__ = ['GlobalAncestryObject', 'LocalAncestryObject']
