"""SDK integrations."""

class SDK:
    """SDK base class."""
    pass

__all__ = ["SDK"]
