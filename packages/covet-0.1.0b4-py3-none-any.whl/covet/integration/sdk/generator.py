"""SDK generator."""

class SDKGenerator:
    """Generate SDK for API."""
    pass

__all__ = ["SDKGenerator", "GeneratorConfig", "SDKConfig", "ClientGenerator"]


# Auto-generated stubs for missing exports

class GeneratorConfig:
    """Stub class for GeneratorConfig."""

    def __init__(self, *args, **kwargs):
        pass


class SDKConfig:
    """Stub class for SDKConfig."""

    def __init__(self, *args, **kwargs):
        pass


class ClientGenerator:
    """Stub class for ClientGenerator."""

    def __init__(self, *args, **kwargs):
        pass

