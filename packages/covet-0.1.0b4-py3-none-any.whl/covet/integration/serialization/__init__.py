"""Serialization module."""

class Serializer:
    """Base serializer."""
    pass

__all__ = ["Serializer"]
