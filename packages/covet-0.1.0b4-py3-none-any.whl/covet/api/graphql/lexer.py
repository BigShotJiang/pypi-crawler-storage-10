class GraphQLLexer:
    """GraphQL lexer."""


def tokenize():
    """Tokenize a GraphQL query."""
