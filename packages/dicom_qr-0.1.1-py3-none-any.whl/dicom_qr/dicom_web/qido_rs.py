from collections import defaultdict
from collections.abc import Sequence
from typing import Final, Self

from dicomweb_client.api import DICOMwebClient
from pydicom import Dataset
from pydicom.uid import UID

from dicom_qr.database import SeriesData, StudyData
from dicom_qr.search import SearchTerms
from dicom_qr.settings import PacsConfig

STUDY_FIELDS: Final[list[str]] = [
    'StudyInstanceUID',
    'StudyDescription',
    'PatientID',
    'PatientName',
    'PatientBirthDate',
    'StudyID',
    'StudyDate',
    'StudyTime',
    'AccessionNumber',
    'BodyPartExamined',
    'ModalitiesInStudy',
]
SERIES_FIELDS: Final[list[str]] = [
    'StudyInstanceUID',
    'SeriesInstanceUID',
    'Modality',
    'SeriesNumber',
    'ProtocolName',
    'SeriesDescription'
]


def _search_filters(search_terms: SearchTerms) -> dict[str, str]:
    search_filters = {}
    if search_terms.pat_name:
        search_filters['PatientName'] = search_terms.pat_name
    if search_terms.patid:
        search_filters['PatientID'] = search_terms.patid
    if search_terms.study_uid:
        search_filters['StudyInstanceUID'] = search_terms.study_uid
    return search_filters


class QueryPacsRS:
    def __init__(self, pacs_config: PacsConfig) -> None:
        self.pacs_config = pacs_config
        if self.pacs_config.dicomweb_url is None:
            raise RuntimeError('DicomWeb URL not set')
        self.client = DICOMwebClient(self.pacs_config.dicomweb_url)

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        pass

    def get_studies(self, search_terms: SearchTerms) -> list[StudyData]:
        results = self.client.search_for_studies(search_filters=_search_filters(search_terms), fields=STUDY_FIELDS)
        datasets = [Dataset.from_json(ds) for ds in results]

        studies = []
        for ds in datasets:
            data_dict = {
                'StudyInstanceUID': ds.StudyInstanceUID,
                'StudyDescription': ds.StudyDescription,
                'PatientID': ds.PatientID,
                'PatientName': ds.PatientName.alphabetic,
                'PatientBirthDate': ds.PatientBirthDate,
                'StudyID': ds.StudyID,
                'StudyDate': ds.StudyDate,
                'StudyTime': ds.StudyTime,
                'AccessionNumber': ds.AccessionNumber,
                'BodyPartExamined': ds.StudyDescription,
                'ModalitiesInStudy': ds.ModalitiesInStudy
            }
            studies.append(StudyData(**data_dict))
        return studies

    def get_series_for_study(self, study_uid: str | UID, modalities: Sequence[str] | None = None) -> list[SeriesData]:
        if modalities is None:
            modalities = []

        results = self.client.search_for_series(
            study_instance_uid=study_uid, search_filters={'Modality': ','.join(modalities)}, fields=SERIES_FIELDS
        )
        datasets = [Dataset.from_json(ds) for ds in results]

        series = []
        for ds in datasets:
            data_dict = {
                'StudyInstanceUID': ds.StudyInstanceUID,
                'SeriesInstanceUID': ds.SeriesInstanceUID,
                'Modality': ds.Modality,
                'SeriesNumber': ds.SeriesNumber,
                'ProtocolName': ds.ProtocolName if 'ProtocolName' in ds else 'NA',
                'SeriesDescription': ds.SeriesDescription,
            }
            series.append(SeriesData(**data_dict))
        return series

    def get_modalities_for_accession_number(self, search_terms: SearchTerms) -> list[str]:
        """ Get modalities for matching the 'accession_number' in the search_terms."""
        studies = self.get_studies(search_terms)

        modalities: set[str] = set()
        for study in studies:
            modalities = modalities | set(study.ModalitiesInStudy)

        return list(modalities)

    def get_studies_for_patient(self, search_terms: SearchTerms) -> defaultdict[str, list[StudyData]]:
        """Get the series for 'study_uid', filtered by modalities (if specified)."""
        studies = self.get_studies(search_terms)

        patient_data: defaultdict[str, list[StudyData]] = defaultdict(list)
        for study_data in studies:
            assert study_data.PatientName is not None
            patient_data[study_data.PatientName].append(study_data)

        if search_terms.modalities is None or len(search_terms.modalities) == 0:
            return patient_data

        for pat_data in patient_data.values():
            for study in pat_data:
                study.series = self.get_series_for_study(study.StudyInstanceUID, modalities=search_terms.modalities)

        return patient_data
