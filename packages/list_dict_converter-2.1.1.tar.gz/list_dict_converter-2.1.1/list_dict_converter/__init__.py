from .core import convert_to_list_of_dicts as list_dict_converter

__all__ = ["list_dict_converter"]
__version__ = "2.1.0"
