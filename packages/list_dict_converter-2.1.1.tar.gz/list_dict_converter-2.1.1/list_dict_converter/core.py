
def convert_to_list_of_dicts(new_data_with_all):
    try:
        
        return [
            {
                member_id: {
                    member_id: details.get(member_id, {}),
                    "personal_information": details.get("personal_information", {}),
                    "start_end_dates": details.get("start_end_dates", {})
                }
            }
            for member_id, details in new_data_with_all.items()
        ]
    except Exception as e:
        print("Error in convert_to_list_of_dicts: "+str(e))
        return [
            {
                member_id: {
                    member_id: details.get(member_id, {}),
                    "personal_information": details.get("personal_information", {}),
                    "start_end_dates": details.get("start_end_dates", {})
                }
            }
            for member_id, details in new_data_with_all.items()
        ]
