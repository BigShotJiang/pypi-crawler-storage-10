from .htop import get_system_info


def get_cpu_mem_info():
    # Quick info
    info = get_system_info()
    print(info)
    print("System Information:")
    print(f"CPU Usage: {info['cpu']['usage_percent']}%")
    print(f"Memory Usage: {info['memory']['virtual']['percent']}%")

    # Start interactive monitor
    # start_monitor()