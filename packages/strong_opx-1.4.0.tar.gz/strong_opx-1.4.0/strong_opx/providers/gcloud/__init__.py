provider_class = "strong_opx.providers.gcloud.provider.GCloudProvider"
