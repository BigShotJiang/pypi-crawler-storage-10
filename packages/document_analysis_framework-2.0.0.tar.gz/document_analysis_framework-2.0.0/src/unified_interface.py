"""Unified interface compatibility layer for document-analysis-framework.

This module provides a consistent interface wrapper that ensures all analysis
results have the same access patterns regardless of the underlying implementation.
"""

from typing import Dict, Any, Optional, List
from analysis_framework_base import UnifiedAnalysisResult as BaseUnifiedAnalysisResult


class UnifiedAnalysisResult(BaseUnifiedAnalysisResult):
    """Wrapper to provide consistent interface for document-analysis-framework results.

    This class extends the base UnifiedAnalysisResult to provide backward compatibility
    with document-analysis-framework's analysis format.

    This class provides:
    - Dictionary-style access: result['key']
    - Attribute access: result.key
    - Consistent method interface: result.to_dict()
    """

    def __init__(self, document_analysis_result: Dict[str, Any]):
        """Initialize with a document analysis result dictionary.

        Args:
            document_analysis_result: The raw analysis result from DocumentAnalyzer.analyze_document()
        """
        # Extract standard fields from document analysis result
        document_type = self._extract_document_type(document_analysis_result)
        confidence = self._extract_confidence(document_analysis_result)
        metadata = self._extract_metadata(document_analysis_result)
        content = self._extract_content(document_analysis_result)
        ai_opportunities = self._extract_ai_opportunities(document_analysis_result)

        # Initialize base class
        super().__init__(
            document_type=document_type,
            confidence=confidence,
            framework='document-analysis-framework',
            metadata=metadata,
            content=content,
            ai_opportunities=ai_opportunities,
            raw_analysis=document_analysis_result
        )

        # Store raw analysis for backward compatibility
        self._raw = document_analysis_result
        self._dict_cache = None

    def _extract_document_type(self, raw: Dict[str, Any]) -> str:
        """Extract document type from raw result"""
        if isinstance(raw, dict) and 'document_type' in raw:
            doc_type_obj = raw['document_type']
            if hasattr(doc_type_obj, 'type_name'):
                return doc_type_obj.type_name
            elif isinstance(doc_type_obj, dict):
                return doc_type_obj.get('type_name', 'unknown')
        return 'unknown'

    def _extract_confidence(self, raw: Dict[str, Any]) -> float:
        """Extract confidence from raw result"""
        if 'confidence' in raw:
            return float(raw['confidence'])
        elif 'document_type' in raw:
            doc_type_obj = raw['document_type']
            if hasattr(doc_type_obj, 'confidence'):
                return float(doc_type_obj.confidence)
            elif isinstance(doc_type_obj, dict):
                return float(doc_type_obj.get('confidence', 1.0))
        return 1.0

    def _extract_metadata(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata from raw result"""
        metadata = {}

        # Add file metadata
        if 'file_path' in raw:
            metadata['file_path'] = raw['file_path']
        if 'file_size' in raw:
            metadata['file_size'] = raw['file_size']
        if 'mime_type' in raw:
            metadata['mime_type'] = raw['mime_type']
        if 'processing_time' in raw:
            metadata['processing_time'] = raw['processing_time']

        # Add document type metadata
        if 'document_type' in raw:
            doc_type_obj = raw['document_type']
            if hasattr(doc_type_obj, 'category'):
                metadata['category'] = doc_type_obj.category
            if hasattr(doc_type_obj, 'version') and doc_type_obj.version:
                metadata['version'] = doc_type_obj.version
            if hasattr(doc_type_obj, 'encoding') and doc_type_obj.encoding:
                metadata['encoding'] = doc_type_obj.encoding
            if hasattr(doc_type_obj, 'language') and doc_type_obj.language:
                metadata['language'] = doc_type_obj.language

        # Add analysis metadata if available
        if 'analysis' in raw:
            analysis_obj = raw['analysis']
            if hasattr(analysis_obj, 'metadata') and analysis_obj.metadata:
                metadata.update(analysis_obj.metadata)
            elif isinstance(analysis_obj, dict) and 'metadata' in analysis_obj:
                metadata.update(analysis_obj['metadata'])

        return metadata

    def _extract_content(self, raw: Dict[str, Any]) -> str:
        """Extract content from raw result"""
        content_parts = []

        if 'analysis' in raw:
            analysis_obj = raw['analysis']

            # Get key findings
            if hasattr(analysis_obj, 'key_findings') and analysis_obj.key_findings:
                findings = analysis_obj.key_findings
                if 'content' in findings:
                    return findings['content']
                # Otherwise create a summary from findings
                for key, value in findings.items():
                    if isinstance(value, str) and len(value) < 200:
                        content_parts.append(f"{key}: {value}")

            # Get structured data summary
            if hasattr(analysis_obj, 'structured_data') and analysis_obj.structured_data:
                data = analysis_obj.structured_data
                if isinstance(data, dict):
                    for key, value in list(data.items())[:5]:
                        if isinstance(value, (str, int, float, bool)):
                            content_parts.append(f"{key}: {value}")

        # If no content found, provide a basic summary
        if not content_parts and 'document_type' in raw:
            doc_type_obj = raw['document_type']
            content_parts.append(f"Document Type: {self._extract_document_type(raw)}")
            if hasattr(doc_type_obj, 'category'):
                content_parts.append(f"Category: {doc_type_obj.category}")

        return '\n'.join(content_parts) if content_parts else ''

    def _extract_ai_opportunities(self, raw: Dict[str, Any]) -> List[str]:
        """Extract AI opportunities from raw result"""
        if 'analysis' in raw:
            analysis_obj = raw['analysis']
            if hasattr(analysis_obj, 'ai_use_cases'):
                return analysis_obj.ai_use_cases
            elif isinstance(analysis_obj, dict) and 'ai_use_cases' in analysis_obj:
                return analysis_obj['ai_use_cases']
        return []

    # Override __getattr__ to proxy attributes to raw analysis for backward compatibility
    def __getattr__(self, name):
        """Proxy attribute access to the raw object for backward compatibility.

        This allows accessing any attributes from the original
        analysis result that aren't in the base class.
        """
        # Avoid infinite recursion
        if name in ('_raw', '_dict_cache'):
            raise AttributeError(f"'{name}' not found")
        try:
            # First check if it's in the raw dict
            if isinstance(object.__getattribute__(self, '_raw'), dict):
                raw = object.__getattribute__(self, '_raw')
                if name in raw:
                    return raw[name]
            # Fall back to base class behavior
            raise AttributeError(f"'{name}' not found in UnifiedAnalysisResult or raw analysis")
        except AttributeError:
            raise AttributeError(f"'{name}' not found in UnifiedAnalysisResult or raw analysis") 