"""Tests for spec-check."""
