"""Grizabella Public API.

This module exposes the main Grizabella client for programmatic interaction.
"""
from .client import Grizabella

__all__ = ["Grizabella"]
