# This file makes the 'delegates' directory a Python package.
# It will contain custom QItemDelegates for QTableViews/QListViews.
