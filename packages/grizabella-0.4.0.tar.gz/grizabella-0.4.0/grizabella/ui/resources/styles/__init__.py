# This file makes the 'styles' directory a Python package.
# It will contain QSS stylesheets.
