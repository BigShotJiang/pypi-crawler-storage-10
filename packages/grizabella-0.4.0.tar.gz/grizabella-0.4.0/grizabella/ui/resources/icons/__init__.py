# This file makes the 'icons' directory a Python package.
