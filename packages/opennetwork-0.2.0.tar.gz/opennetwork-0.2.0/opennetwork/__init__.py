from .core import init, setmodel, getmodel, ModelLoadError

__all__ = ["init", "setmodel", "getmodel", "ModelLoadError"]

__version__ = "0.1.0"
