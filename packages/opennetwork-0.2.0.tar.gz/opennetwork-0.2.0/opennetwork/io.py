from __future__ import annotations
import json
from typing import Union, Dict, Any

class InvalidModelJSON(Exception):
    pass

def load_model_json(src: Union[str, dict]) -> Dict[str, Any]:
    """
    Load model JSON from a file path or a Python dict.
    Validates minimal required keys.
    """
    if isinstance(src, str):
        with open(src, "r", encoding="utf-8") as f:
            data = json.load(f)
    elif isinstance(src, dict):
        data = src
    else:
        raise InvalidModelJSON("Expected file path or dict.")

    if "layers" not in data or not isinstance(data["layers"], list):
        raise InvalidModelJSON("Model JSON must contain a 'layers' list.")
    # Backward-compatible defaults
    data.setdefault("id", "")
    data.setdefault("name", "OpenNetwork Model")
    return data
