import json, os
import opennetwork as onn

def test_import():
    assert hasattr(onn, "getmodel")
    assert hasattr(onn, "setmodel")
    assert hasattr(onn, "init")

def test_dry_run_parsing():
    here = os.path.dirname(__file__)
    # use a small inline JSON
    graph = {
        "name": "Tiny",
        "layers": [
            {"id": "input-1", "type": "input", "params": {"input_shape": [28, 28, 1]}, "connections": ["conv-1"]},
            {"id": "conv-1", "type": "conv2d", "params": {"filters": 8, "kernel_size": [3,3]}, "connections": ["dense-1"]},
            {"id": "dense-1", "type": "dense", "params": {"units": 10}, "connections": []}
        ]
    }
    # Dry run path: return_extras True avoids TF dependency during tests
    model, extras = onn.getmodel(graph, return_extras=True)
    assert model is None
    assert "inserted" in extras
