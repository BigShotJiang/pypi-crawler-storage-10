
from speclike.dispatch.mod import TestDispatcher, TestCase, case

__all__ = ("TestDispatcher", "TestCase", "case")
