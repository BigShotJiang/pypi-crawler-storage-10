"""
herrkunft - Track configuration value origins and modification history.

From German "Herkunft" (origin, provenance) - this library provides transparent
tracking of configuration value origins and modification history through YAML
parsing with modern Python best practices.

Basic usage:
    >>> from herrkunft import load_yaml
    >>> config = load_yaml("config.yaml", category="defaults")
    >>> print(config["database"]["url"])
    >>> print(config["database"]["url"].provenance.current)

See the documentation for more advanced usage and features.

Authors:
    Paul Gierz <paul.gierz@awi.de>
    Miguel Andrés-Martínez <miguel.andres-martinez@awi.de>
"""

# Configuration
from .config import ProvenanceSettings, get_settings, reset_settings, settings
from .core.hierarchy import CategoryLevel, HierarchyConfig, HierarchyManager

# Core imports - all implemented by Expert 1
from .core.provenance import Provenance, ProvenanceStep
from .exceptions import (
    CategoryConflictError,
    ChooseConflictError,
    ConfigurationError,
    DumperError,
    LoaderError,
    ProvenanceError,
    SerializationError,
    ValidationError,
)

# Type system imports - implemented by Expert 2
from .types.base import HasProvenance
from .types.factory import TypeWrapperFactory as ProvenanceWrapperFactory
from .types.mappings import DictWithProvenance, ListWithProvenance

# Utilities
from .utils import (
    # Cleaning
    clean_provenance,
    ensure_provenance_valid,
    extract_provenance_tree,
    from_dict,
    from_json,
    from_json_file,
    strip_provenance,
    # Serialization
    to_dict,
    to_json,
    to_json_file,
    validate_provenance_history,
    # Validation
    validate_provenance_step,
    validate_provenance_tree,
)
from .version import __api_version__, __version__, __version_info__
from .yaml.dumper import ProvenanceDumper

# YAML handling imports - implemented by Expert 3
from .yaml.loader import ProvenanceLoader


# Convenience functions for common operations
def load_yaml(
    path: str,
    category: str = None,
    subcategory: str = None,
) -> DictWithProvenance:
    """
    Load YAML file with provenance tracking.

    This is a convenience function that creates a ProvenanceLoader
    and loads a single file.

    Args:
        path: Path to YAML file
        category: Configuration category for hierarchy resolution
        subcategory: Optional subcategory identifier

    Returns:
        Dictionary with provenance tracking enabled

    Example:
        >>> config = load_yaml("config.yaml", category="defaults")
        >>> print(config["key"].provenance.current.yaml_file)
    """
    loader = ProvenanceLoader(category=category, subcategory=subcategory)
    return loader.load(path)


def dump_yaml(
    data: dict,
    path: str,
    include_provenance: bool = True,
    clean: bool = False,
) -> None:
    """
    Dump dictionary to YAML file.

    This is a convenience function that creates a ProvenanceDumper
    and dumps a single file.

    Args:
        data: Dictionary to dump
        path: Output file path
        include_provenance: Add provenance as comments
        clean: Remove provenance wrappers before dumping

    Example:
        >>> dump_yaml(config, "output.yaml", include_provenance=True)
    """
    dumper = ProvenanceDumper(include_provenance_comments=include_provenance)
    dumper.dump(data, path, clean=clean)


# PyYAML drop-in replacement API - provenance tracking by default
def safe_load(stream, category: str = "default", subcategory: str = None):
    """
    PyYAML-compatible safe_load with automatic provenance tracking.

    This function serves as a drop-in replacement for yaml.safe_load that
    automatically returns DictWithProvenance with full provenance tracking.
    All values are transparently wrapped and behave like normal Python types
    while tracking their origin, line number, and modification history.

    Args:
        stream: File object, string, or path-like object containing YAML
        category: Configuration category for hierarchy resolution (default: "default")
        subcategory: Optional subcategory identifier for more granular tracking

    Returns:
        DictWithProvenance with full provenance tracking enabled

    Example:
        >>> import herrkunft as yaml
        >>> config = yaml.safe_load(open("config.yaml"))
        >>> config["database"]["url"]  # Works like normal dict
        'postgresql://localhost/mydb'
        >>> config["database"]["url"].provenance.current.yaml_file
        'config.yaml'
        >>> config["database"]["url"].provenance.current.line
        15

    Note:
        Unlike PyYAML's safe_load, this always returns objects with provenance
        tracking. Use strip_provenance() if you need plain Python types.
    """
    from io import StringIO
    from pathlib import Path

    # Handle string input
    if isinstance(stream, str):
        # Check if it's a path or YAML content
        if "\n" in stream or ":" in stream:
            # Likely YAML content
            stream = StringIO(stream)
            path = "<string>"
        else:
            # Likely a file path
            path = stream
    # Handle Path objects
    elif isinstance(stream, Path):
        path = str(stream)
    # Handle file objects
    elif hasattr(stream, "name"):
        path = stream.name
    else:
        path = "<stream>"

    # Use ProvenanceLoader for automatic tracking
    loader = ProvenanceLoader(category=category, subcategory=subcategory)

    # If we have a file object or StringIO, read it
    if hasattr(stream, "read"):
        if path == "<string>" or path == "<stream>":
            # For StringIO or unnamed streams, load from the stream directly
            content = stream.read()
            # Reset stream position if possible
            if hasattr(stream, "seek"):
                stream.seek(0)
            # Create a temporary file to load from
            temp_stream = StringIO(content)
            return loader._load_from_stream(temp_stream, path)
        else:
            # For named file objects, load by path
            return loader.load(path)
    else:
        # Path string
        return loader.load(path)


def safe_dump(
    data,
    stream=None,
    include_provenance: bool = True,
    clean: bool = False,
    **kwargs,
):
    """
    PyYAML-compatible safe_dump with optional provenance comments.

    This function serves as a drop-in replacement for yaml.safe_dump that
    automatically handles DictWithProvenance and can optionally include
    provenance information as inline comments.

    Args:
        data: Data to serialize (can be DictWithProvenance or plain dict)
        stream: File object or path to write to (None returns string)
        include_provenance: Add provenance as inline comments (default: True)
        clean: Strip provenance wrappers before dumping (default: False)
        **kwargs: Additional arguments (for PyYAML compatibility, mostly ignored)

    Returns:
        YAML string if stream is None, otherwise None

    Example:
        >>> import herrkunft as yaml
        >>> config = yaml.safe_load(open("config.yaml"))
        >>> yaml.safe_dump(config, open("output.yaml", "w"))
        # Output includes provenance comments by default:
        # database:
        #   url: postgresql://localhost/mydb  # config.yaml:15:8

    Note:
        If you don't want provenance comments, set include_provenance=False.
        If you want plain Python types, set clean=True.
    """
    from io import StringIO
    from pathlib import Path

    dumper = ProvenanceDumper(include_provenance_comments=include_provenance)

    # Handle different stream types
    if stream is None:
        # Return as string
        output = StringIO()
        dumper.dump_to_stream(data, output, clean=clean)
        return output.getvalue()
    elif isinstance(stream, (str, Path)):
        # Path provided
        dumper.dump(data, str(stream), clean=clean)
        return None
    else:
        # File object
        if hasattr(stream, "name"):
            dumper.dump(data, stream.name, clean=clean)
        else:
            dumper.dump_to_stream(data, stream, clean=clean)
        return None


def load(stream, Loader=None, category: str = "default", subcategory: str = None):
    """
    PyYAML-compatible load function (defaults to safe_load with provenance).

    For compatibility with PyYAML, this function accepts a Loader parameter
    but ignores it, always using provenance tracking.

    Args:
        stream: File object, string, or path containing YAML
        Loader: Ignored (for PyYAML compatibility)
        category: Configuration category (default: "default")
        subcategory: Optional subcategory identifier

    Returns:
        DictWithProvenance with full provenance tracking

    Example:
        >>> import herrkunft as yaml
        >>> config = yaml.load(open("config.yaml"))
        >>> config["key"].provenance.current.yaml_file
        'config.yaml'
    """
    return safe_load(stream, category=category, subcategory=subcategory)


def dump(data, stream=None, Dumper=None, include_provenance: bool = True, **kwargs):
    """
    PyYAML-compatible dump function (defaults to safe_dump with provenance).

    For compatibility with PyYAML, this function accepts a Dumper parameter
    but ignores it, always using provenance-aware dumping.

    Args:
        data: Data to serialize
        stream: File object or path (None returns string)
        Dumper: Ignored (for PyYAML compatibility)
        include_provenance: Add provenance comments (default: True)
        **kwargs: Additional arguments

    Returns:
        YAML string if stream is None, otherwise None

    Example:
        >>> import herrkunft as yaml
        >>> yaml.dump({"key": "value"}, open("output.yaml", "w"))
    """
    return safe_dump(data, stream=stream, include_provenance=include_provenance, **kwargs)


# Public API - what users should import
__all__ = [
    # Version info
    "__version__",
    "__version_info__",
    "__api_version__",
    # Core classes (from Expert 1)
    "Provenance",
    "ProvenanceStep",
    "HierarchyManager",
    "HierarchyConfig",
    "CategoryLevel",
    # Type wrappers (from Expert 2)
    "DictWithProvenance",
    "ListWithProvenance",
    "ProvenanceWrapperFactory",
    "HasProvenance",
    # YAML handling (from Expert 3)
    "ProvenanceLoader",
    "ProvenanceDumper",
    # Convenience functions
    "load_yaml",
    "dump_yaml",
    # PyYAML drop-in replacement
    "safe_load",
    "safe_dump",
    "load",
    "dump",
    # Configuration (from Expert 4)
    "ProvenanceSettings",
    "settings",
    "get_settings",
    "reset_settings",
    # Utilities (from Expert 4)
    "clean_provenance",
    "strip_provenance",
    "extract_provenance_tree",
    "validate_provenance_step",
    "validate_provenance_history",
    "validate_provenance_tree",
    "ensure_provenance_valid",
    "to_dict",
    "to_json",
    "to_json_file",
    "from_dict",
    "from_json",
    "from_json_file",
    # Exceptions
    "ProvenanceError",
    "CategoryConflictError",
    "ChooseConflictError",
    "ValidationError",
    "SerializationError",
    "ConfigurationError",
    "LoaderError",
    "DumperError",
]
