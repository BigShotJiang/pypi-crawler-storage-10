## giakiethoang — Colorful terminal text, gradients and animations

Tạo màu RGB, gradient, hiệu ứng chữ và animation trong terminal (Windows, macOS, Linux) bằng ANSI.

### Cài đặt

```bash
pip install giakiethoang
```

### Khởi tạo nhanh

```python
from giakiethoang import System, Colors as C, Colorate

System.Init()  # bật ANSI cho Windows CMD/PowerShell
print(Colorate.Color(C.cyan, "Xin chào!"))
```

### Thành phần chính
- `Colors (Col)`: Màu tĩnh RGB, nền (background), ANSI styles (bold, underline, ...), và công cụ trộn nhiều màu `DynamicMIX`/`StaticMIX`.
- `Colorate`: Áp màu cho chuỗi theo chiều ngang/dọc/chéo, gradient đa-điểm, hiệu ứng (Wave, Shimmer, Glow, Shadow), định dạng và tiện ích nền/kiểu.
- `Anime`: Animation dạng khung hình: Fade, Move, Pulse, Typewriter, Marquee, Shimmer.
- `Write`: In/nhập kiểu gõ chậm (typewriter) với phối màu.
- `Center`: Căn giữa/căn trái/căn phải theo cả trục X/Y, nhóm hoặc theo độ dài dòng.
- `Banner (Box) & Add`: Vẽ khung hộp, khối, đường viền và ghép các banner cạnh nhau.
- `System`: Tiện ích console (đặt tiêu đề, clear, chạy lệnh).

---

## Colors (màu tĩnh, nền, styles, trộn màu)

```python
from giakiethoang import Colors as C, Colorate

# Màu tĩnh
print(Colorate.Color(C.red, "Đỏ"))
print(Colorate.Color(C.green, "Xanh lá"))
print(Colorate.Color(C.blue, "Xanh dương"))

# Nền màu + chữ trắng
print(Colorate.BgColor(C.bg_blue, "  BG BLUE  ", C.white))

# ANSI styles
styled = Colorate.Style("Bold + Underline", [C.bold, C.underline])
print(styled)

# Giả lập phát sáng (Glow)
print(Colorate.Glow("Glowing text", C.cyan))

# Đổ bóng (Shadow)
print(Colorate.Shadow("Shadow", C.yellow, C.dark_gray, offset_x=2, offset_y=1))

# Trộn màu: StaticMIX (trung bình màu)
mid = C.StaticMIX([C.red, C.blue], _start=True)   # trả về "\x1b[38;2;r;g;bm"
print(Colorate.Color(mid, "Magenta-ish"))

# Trộn gradient đa-điểm: DynamicMIX
grad = C.DynamicMIX([C.magenta, C.topaz, C.lime, C.cyan, C.blue],
                    steps_per_segment=24, ease='ease_in_out')
print(Colorate.Horizontal(grad, "DynamicMIX preview"))
```

Tham số `ease` hỗ trợ: `linear`, `cosine`, `ease_in_out`.

---

## Colorate (áp màu, gradient, hiệu ứng)

### Các chế độ áp màu
```python
from giakiethoang import Colors as C, Colorate

text = "Color Modes Demo\nSecond Line"
print(Colorate.Horizontal(C.rainbow, text))
print(Colorate.Vertical(C.rainbow, text))
print(Colorate.Diagonal(C.rainbow, text))
print(Colorate.DiagonalBackwards(C.rainbow, text))
```

### Gradient đa-điểm (MultiGradient)
```python
palette = [C.red, C.yellow, C.green, C.cyan, C.blue, C.purple]
print(Colorate.MultiGradient("MultiGradient text", palette,
                             steps_per_segment=20,
                             mode=Colorate.Horizontal,
                             ease='cosine'))
```

### Định dạng và gradient theo dòng
```python
fmt = Colorate.Format("A B C D E", ['A','E'], Colorate.Horizontal, C.rainbow, C.yellow)
print(fmt)
print(Colorate.GradientText("Gradient theo dòng\nLine 2\nLine 3", C.rainbow, intensity=1.0))
```

### Hiệu ứng màu
```python
print(Colorate.Wave(C.rainbow, "Wave Effect", amplitude=4, speed=2))
print(Colorate.Shimmer(C.rainbow, "Shimmer Effect", window=6))
print(Colorate.Glow("Glow", C.neon_pink))
print(Colorate.Shadow("Shadow", C.yellow, C.dark_gray, 2, 1))
```

---

## Anime (animation khung hình ngắn)

Các hàm animation sẽ clear màn hình mỗi frame. Dùng `time` nhỏ để demo ngắn.

```python
from giakiethoang import System, Colors as C, Colorate, Anime

System.Init()
Anime.Fade("Fade demo", C.rainbow, Colorate.Horizontal, time=2, interval=0.05,
           hide_cursor=True, enter=False)
Anime.Move("Moving text", C.rainbow, time=2, interval=0.01, hide_cursor=True)
Anime.Pulse("Pulse demo", C.rainbow, time=1, interval=0.05)
Anime.Typewriter("Typewriter demo\nNew line", C.rainbow, interval=0.01)
Anime.Marquee(" Marquee scrolling demo ", C.rainbow, interval=0.03, time=30)
# Anime.Shimmer là bản động của Colorate.Shimmer
Anime.Shimmer("Shimmer Animated", C.rainbow, interval=0.05, window=8, time=30)
```

---

## Write (in/nhập kiểu gõ chậm)

```python
from giakiethoang import Colors as C, Write

Write.Print("Typing...\n", C.rainbow, interval=0.01, end=C.reset)
value = Write.Input("Type something: ", C.rainbow, interval=0.005, input_color=C.reset)
print("You typed:", value)
```

---

## Center (căn chỉnh)

```python
from giakiethoang import Center

txt = "Centered Text Example\nSecond Line"
print(Center.XCenter(txt))
print(Center.YCenter(txt))
print(Center.Center(txt))
print(Center.GroupAlign(txt, Center.right))
print(Center.TextAlign(txt, Center.center))
```

---

## Banner (Box) & Add

```python
from giakiethoang import Banner, Add, Colorate, Colors as C

box = Banner.RoundedBox("Hello\nBanner")
cube = Banner.DoubleCube("World")
print(Add.Add(box, cube, center=True))
print(Banner.Lines("Framed text with lines", color=C.rainbow, mode=Colorate.Horizontal))
print(Banner.Arrow(icon='>', size=2, number=3, direction='right'))
```

---

## System (tiện ích console)

```python
from giakiethoang import System

System.Init()                   # bật ANSI (Windows)
System.Title("My App Title")   # đặt tiêu đề cửa sổ console
System.Clear()                  # xóa màn hình
System.Command("echo hello")   # chạy lệnh hệ thống
```

---

## Chạy bản demo tương tác

Repo đã kèm sẵn script demo đầy đủ, cho phép chọn từng chức năng để test:

```bash
python test_all.py
```

Menu sẽ hiển thị các mục (System, Colors, Colorate, Anime, Write, Center, Banner/Add…). Chọn số để chạy demo; nhập 0 để thoát.

---

## Ghi chú tương thích
- Trên Windows, nên dùng Terminal/Windows Terminal/PowerShell mới. `System.Init()` đã gửi lệnh bật ANSI.
- Một số terminal cũ có thể không hỗ trợ đầy đủ 24-bit color/ANSI styles.

---

## Tài liệu & nguồn
- Mã nguồn và cập nhật: `https://github.com/giakietdev/giakiethoang`

---

- System: Init, Clear, Title, Size, Command
- Cursor: HideCursor, ShowCursor
- Colors (Col): StaticRGB, DynamicRGB, StaticMIX, DynamicMIX, bảng màu, nền, styles
- Colorate: Color, Error, Horizontal, Vertical, Diagonal, DiagonalBackwards, Format, GradientText, MultiGradient, Wave, Shimmer, Glow, Shadow, BgColor, Style
- Anime: Fade, Move, Bar, Pulse, Typewriter, Marquee, Shimmer
- Write: Print, Input
- Center: XCenter, YCenter, Center, GroupAlign, TextAlign
- Banner (Box): Box, SimpleCube, DoubleCube, RoundedBox, Lines, Arrow
- Add: Add

> Lưu ý: alias `Col = Colors`, `Box = Banner` để truy cập nhanh.

---

## System
- Signature:
  - `System.Init()`
  - `System.Clear()` → int (mã trả về lệnh hệ thống)
  - `System.Title(title: str)` → int (Windows)
  - `System.Size(x: int, y: int)` → int (Windows)
  - `System.Command(command: str)` → int

Ví dụ:
```python
from giakiethoang import System
System.Init()
System.Title("Demo Window")
System.Size(120, 30)
System.Command("echo Ready!")
System.Clear()
```

## Cursor
- `Cursor.HideCursor()` / `Cursor.ShowCursor()` dùng trong animation để ẩn/hiện con trỏ.

```python
from giakiethoang import Cursor
Cursor.HideCursor()
# ... do something ...
Cursor.ShowCursor()
```

## Colors (Col)
- Tạo mã màu tiền tố ANSI:
  - `Colors.StaticRGB(r: int, g: int, b: int) -> str`
  - `Colors.DynamicRGB(r1, g1, b1, r2, g2, b2) -> list[str]` (24 bước mặc định)
  - `Colors.StaticMIX(colors: list[str], _start: bool = True) -> str|"r;g;b"`
    - Trộn trung bình nhiều màu; nếu `_start=False` trả về chuỗi `"r;g;b"`.
  - `Colors.DynamicMIX(colors: list[str], steps_per_segment=24, ease='linear', reverse=True) -> list[str]`
    - Hỗ trợ số lượng màu bất kỳ; `ease`: `linear|cosine|ease_in_out`.

- Bảng màu tĩnh sẵn: `red, green, blue, white, black, gray, yellow, purple, cyan, orange, pink, turquoise, light_gray, dark_gray, ...` và nhiều màu khác (gold, silver, bronze, lavender, mint, salmon, crimson, orchid, plum, sienna, khaki, aqua, emerald, sapphire, ruby, amber, topaz, jade, amethyst).

- Nền (background): `bg_white, bg_black, bg_gray, bg_light_gray, bg_dark_gray, bg_red, bg_green, bg_blue, bg_yellow, bg_purple, bg_cyan, bg_orange`.

- Styles ANSI: `bold, dim, italic, underline, blink, inverse, reset_all`.

Ví dụ trộn đa màu và áp theo chiều ngang:
```python
from giakiethoang import Colors as C, Colorate
grad = C.DynamicMIX([C.red, C.yellow, C.green, C.cyan, C.blue, C.purple], steps_per_segment=16, ease='cosine')
print(Colorate.Horizontal(grad, "Rainbow blend"))
```

## Colorate
- `Color(color: str, text: str, end: bool = True) -> str`: áp một màu cho toàn chuỗi.
  ```python
  from giakiethoang import Colors as C, Colorate
  print(Colorate.Color(C.orange, "Simple colored"))
  ```

- `Error(text: str, color: str = Colors.red, end: bool = False, spaces: int = 1, enter: bool = True, wait: int|bool = False) -> str|None`
  - Hiển thị prompt lỗi hoặc in thông báo; có thể đợi nhập/phá vỡ sau `wait`.

- Áp màu theo vị trí ký tự/dòng:
  - `Horizontal(color_list: list[str], text: str, speed: int = 1, cut: int = 0) -> str`
  - `Vertical(color_list, text, speed=1, start=0, stop=0, cut=0, fill=False) -> str`
  - `Diagonal(color_list, text, speed=1, cut=0) -> str`
  - `DiagonalBackwards(color_list, text, speed=1, cut=0) -> str`

- Định dạng ký tự chọn lọc:
  - `Format(text: str, second_chars: list[str], mode, principal_col: list[str], second_col: str) -> str`

- Gradient theo dòng (sine):
  - `GradientText(text: str, color: list[str], intensity: float = 1.0) -> str`

- Gradient đa-điểm:
  - `MultiGradient(text: str, colors: list[str], steps_per_segment: int = 24, mode=None, ease: str = 'linear', cut: int = 0) -> str`

- Hiệu ứng:
  - `Wave(color: list[str], text: str, amplitude: int = 3, speed: int = 1, cut: int = 0) -> str`
  - `Shimmer(color: list[str], text: str, window: int = 8, step: int = 1, cut: int = 0) -> str`
  - `Glow(text: str, color: str, glow_strength: float = 0.5) -> str`
  - `Shadow(text: str, color: str = Colors.white, shadow_color: str = Colors.dark_gray, offset_x: int = 2, offset_y: int = 1) -> str`
  - `BgColor(bg_color: str, text: str, fg_color: str = None, end: bool = True) -> str`
  - `Style(text: str, styles: list[str]) -> str`

Ví dụ tổng hợp:
```python
from giakiethoang import Colors as C, Colorate
txt = "A B C D E"
print(Colorate.Format(txt, ['A','E'], Colorate.Horizontal, C.rainbow, C.yellow))
print(Colorate.Wave(C.rainbow, "Wave", amplitude=4, speed=2))
print(Colorate.Shimmer(C.rainbow, "Shimmer", window=6))
print(Colorate.Style(Colorate.BgColor(C.bg_blue, " BG ", C.white), [C.bold]))
print(Colorate.Glow("GLOW", C.neon_pink))
print(Colorate.Shadow("Shadow", C.yellow, C.dark_gray, 2, 1))
```

## Anime
- Các hàm animation sẽ clear màn hình mỗi frame; dùng thời lượng nhỏ để demo.
  - `Fade(text: str, color: list[str], mode, time=True|int, interval=0.05, hide_cursor=True, enter=False)`
  - `Move(text: str, color: list[str], time=True|int, interval=0.01, hide_cursor=True, enter=False)`
  - `Bar(length, carac_0='[ ]', carac_1='[0]', color=list|str=Colors.white, mode=Colorate.Horizontal, interval=0.5, hide_cursor=True, enter=False, center=False)`
  - `Pulse(text: str, color: list[str], time=True|int, interval=0.1, hide_cursor=True, enter=False)`
  - `Typewriter(text: str, color: list[str], interval: float = 0.04, hide_cursor: bool = True)`
  - `Marquee(text: str, color: list[str], width: int|None = None, interval: float = 0.05, hide_cursor: bool = True, time=True|int)`
  - `Shimmer(text: str, color: list[str], interval: float = 0.05, window: int = 8, hide_cursor: bool = True, time=True|int)`

Ví dụ:
```python
from giakiethoang import Colors as C, Colorate, Anime, System
System.Init()
Anime.Fade("Fade", C.rainbow, Colorate.Horizontal, time=2, interval=0.05)
Anime.Move("Move", C.rainbow, time=2, interval=0.01)
Anime.Pulse("Pulse", C.rainbow, time=1)
Anime.Typewriter("Typewriter\nNext", C.rainbow, interval=0.01)
Anime.Marquee("  Marquee  ", C.rainbow, interval=0.03, time=30)
Anime.Shimmer("Shimmer", C.rainbow, interval=0.05, window=8, time=30)
```

## Write
- `Print(text: str, color: list[str], interval=0.05, hide_cursor=True, end: str = Colors.reset) -> None`
- `Input(text: str, color: list[str], interval=0.05, hide_cursor=True, input_color: str = Colors.reset, end: str = Colors.reset, func=input) -> str`

```python
from giakiethoang import Colors as C, Write
Write.Print("Typing...\n", C.rainbow, interval=0.01)
name = Write.Input("Your name: ", C.rainbow)
print("Hi", name)
```

## Center
- `XCenter(text: str, spaces: int|None = None, icon: str = ' ') -> str`
- `YCenter(text: str, spaces: int|None = None, icon: str = '\n') -> str`
- `Center(text: str, xspaces: int|None = None, yspaces: int|None = None, xicon: str = ' ', yicon: str = '\n') -> str`
- `GroupAlign(text: str, align: str = Center.center) -> str` (center|left|right)
- `TextAlign(text: str, align: str = Center.center) -> str` (trên độ dài dòng lớn nhất)

```python
from giakiethoang import Center
txt = "Centered\nBlock"
print(Center.XCenter(txt))
print(Center.YCenter(txt))
print(Center.Center(txt))
print(Center.GroupAlign(txt, Center.right))
print(Center.TextAlign(txt, Center.center))
```

## Banner (Box)
- `Box(content, up_left, up_right, down_left, down_right, left_line, up_line, right_line, down_line)`
- `SimpleCube(content)`
- `DoubleCube(content)`
- `RoundedBox(content)`
- `Lines(content, color=None, mode=Colorate.Horizontal, line='═', pepite='ቐ')`
- `Arrow(icon='a', size=2, number=2, direction='right'|'left')`

```python
from giakiethoang import Banner, Colorate, Colors as C
print(Banner.RoundedBox("Hello\nBanner"))
print(Banner.DoubleCube("World"))
print(Banner.Lines("Framed", color=C.rainbow, mode=Colorate.Horizontal))
print(Banner.Arrow(icon='>', size=2, number=3, direction='right'))
```

## Add
- `Add.Add(banner1: str, banner2: str, spaces: int = 0, center: bool = False) -> str`
  - Ghép hai banner theo chiều dọc, tự cân dòng khi `center=True`.

```python
from giakiethoang import Add, Banner
print(Add.Add(Banner.RoundedBox("Left"), Banner.DoubleCube("Right"), center=True))
```