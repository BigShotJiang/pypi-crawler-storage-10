import time
from giakiethoang import System, Colors as C, Colorate, Anime, Write, Center, Banner, Add


def section(title: str):
    print("\n" + "=" * 20 + f" {title} " + "=" * 20)


def pause():
    input("\nPress Enter to continue...")

def demo_system():
    section("System")
    System.Title("giakiethoang - System Demo")
    print("Title set. Clearing in 1s...")
    time.sleep(1)
    System.Clear()
    print("Cleared. Running 'echo test'...")
    System.Command("echo test")
    pause()


def demo_colors_static():
    section("Colors - Static")
    samples = [
        (C.red, "RED"), (C.green, "GREEN"), (C.blue, "BLUE"),
        (C.yellow, "YELLOW"), (C.purple, "PURPLE"), (C.cyan, "CYAN"),
        (C.orange, "ORANGE"), (C.pink, "PINK"), (C.turquoise, "TURQUOISE"),
    ]
    print(" ".join(Colorate.Color(col, txt) for col, txt in samples))
    pause()


def demo_colors_dynamicmix():
    section("Colors - DynamicMIX (multi-color)")
    grad = C.DynamicMIX([C.magenta, C.topaz, C.lime, C.cyan, C.blue], steps_per_segment=16, ease='ease_in_out')
    print(Colorate.Horizontal(grad, "DynamicMIX preview"))
    pause()


def demo_colorate_basic():
    section("Colorate - Basic Color")
    print(Colorate.Color(C.orange, "Simple colored text"))
    print(Colorate.Error("Enter something (Error prompt demo): ", color=C.red, enter=True))
    pause()


def demo_colorate_modes():
    section("Colorate - Modes (Horizontal/Vertical/Diagonal/DiagonalBackwards)")
    grad = C.rainbow
    txt = "Color Modes Demo\nSecond Line"
    print(Colorate.Horizontal(grad, txt))
    print(Colorate.Vertical(grad, txt))
    print(Colorate.Diagonal(grad, txt))
    print(Colorate.DiagonalBackwards(grad, txt))
    pause()


def demo_colorate_format_gradient():
    section("Colorate - Format & GradientText & MultiGradient")
    txt = "A B C D E"
    formatted = Colorate.Format(txt, ['A', 'E'], Colorate.Horizontal, C.rainbow, C.yellow)
    print(formatted)
    print(Colorate.GradientText("GradientText by line\nLine 2\nLine 3", C.rainbow, intensity=1.0))
    palette = [C.red, C.yellow, C.green, C.cyan, C.blue, C.purple]
    print(Colorate.MultiGradient("MultiGradient text", palette, steps_per_segment=20, mode=Colorate.Horizontal, ease='cosine'))
    pause()


def demo_styles_and_bg():
    section("Styles & Background")
    print(Colorate.Style("Bold + Underline", [C.bold, C.underline]))
    print(Colorate.BgColor(C.bg_blue, "  BG BLUE  ", C.white))
    print(Colorate.Glow("Glow Cyan", C.cyan))
    print(Colorate.Shadow("Shadow Yellow", C.yellow, C.dark_gray, 2, 1))
    pause()


def demo_effects():
    section("Effects - Wave & Shimmer")
    rainbow = C.rainbow
    print(Colorate.Wave(rainbow, "Wave Effect Text", amplitude=4, speed=2))
    print(Colorate.Shimmer(rainbow, "Shimmer Effect Text", window=6))
    pause()


def demo_write():
    section("Write")
    Write.Print("Typing with colors...\n", C.rainbow, interval=0.01, end=C.reset)
    val = Write.Input("Type something: ", C.rainbow, interval=0.005, input_color=C.reset)
    print("You typed:", val)
    pause()


def demo_center():
    section("Center")
    txt = "Centered Text Example\nSecond Line"
    print(Center.XCenter(txt))
    print(Center.YCenter(txt))
    print(Center.Center(txt))
    print(Center.GroupAlign(txt, Center.right))
    print(Center.TextAlign(txt, Center.center))
    pause()


def demo_banner_and_add():
    section("Banner & Add")
    box = Banner.RoundedBox("Hello\nBanner")
    cube = Banner.DoubleCube("World")
    print(Add.Add(box, cube, center=True))
    print(Banner.Lines("Framed text with lines", color=C.rainbow, mode=Colorate.Horizontal))
    print(Banner.Arrow(icon='>', size=2, number=3, direction='right'))
    pause()


def demo_anime():
    section("Anime - Short Demos")
    System.Title("giakiethoang demo")
    Anime.Fade("Fade demo", C.rainbow, Colorate.Horizontal, time=2, interval=0.05, hide_cursor=True, enter=False)
    Anime.Move("Moving text", C.rainbow, time=2, interval=0.01, hide_cursor=True, enter=False)
    Anime.Pulse("Pulse demo", C.rainbow, time=1, interval=0.05, hide_cursor=True, enter=False)
    Anime.Typewriter("Typewriter demo\nNew line", C.rainbow, interval=0.01, hide_cursor=True)
    Anime.Marquee(" Marquee scrolling demo ", C.rainbow, interval=0.03, hide_cursor=True, time=30)
    # Anime.Shimmer uses Colorate.Shimmer internally
    Anime.Shimmer("Shimmer Animated", C.rainbow, interval=0.05, window=8, hide_cursor=True, time=30)
    pause()


def main():
    System.Init()
    menu = [
        ("1", "System", demo_system),
        ("2", "Colors - Static", demo_colors_static),
        ("3", "Colors - DynamicMIX", demo_colors_dynamicmix),
        ("4", "Colorate - Basic Color & Error", demo_colorate_basic),
        ("5", "Colorate - Modes (Hori/Vert/Diag/DiagBack)", demo_colorate_modes),
        ("6", "Colorate - Format/GradientText/MultiGradient", demo_colorate_format_gradient),
        ("7", "Styles & Background (BgColor/Style/Glow/Shadow)", demo_styles_and_bg),
        ("8", "Effects (Wave/Shimmer)", demo_effects),
        ("9", "Write (Print/Input)", demo_write),
        ("10", "Center (X/Y/Center/GroupAlign/TextAlign)", demo_center),
        ("11", "Banner & Add (RoundedBox/DoubleCube/Lines/Arrow/Add)", demo_banner_and_add),
        ("12", "Anime (Fade/Move/Pulse/Typewriter/Marquee/Shimmer)", demo_anime),
        ("0", "Exit", None),
    ]

    while True:
        System.Clear()
        print(Colorate.Style("Select a feature to test:", [C.bold]))
        for key, name, _ in menu:
            print(f" {key}. {name}")
        choice = input("Enter choice: ").strip()
        if choice == "0":
            print("Bye!")
            break
        mapping = {k: fn for k, _, fn in menu}
        fn = mapping.get(choice)
        if fn is None:
            print("Invalid choice.")
            time.sleep(1)
            continue
        try:
            System.Clear()
            fn()
        except Exception as e:
            print("Error during demo:", e)
            pause()


if __name__ == "__main__":
    main()


