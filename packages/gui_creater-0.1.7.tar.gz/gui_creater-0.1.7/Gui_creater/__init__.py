from gui_creater import *
from gui_easily import *
def Create_new_widget():
    import upload
