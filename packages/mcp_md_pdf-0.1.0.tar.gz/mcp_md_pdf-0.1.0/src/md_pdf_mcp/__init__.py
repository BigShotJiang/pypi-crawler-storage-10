"""
MD-PDF-MCP: Model Context Protocol server for Markdown to Word/PDF conversion
"""

__version__ = "0.1.0"
