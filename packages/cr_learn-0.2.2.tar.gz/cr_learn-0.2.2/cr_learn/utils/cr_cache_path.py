'''
just to maintain cache path i have created this
'''
import os

path = os.path.expanduser('~/.cache/crlearn')
