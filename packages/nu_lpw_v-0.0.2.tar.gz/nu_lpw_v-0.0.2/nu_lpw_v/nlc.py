def doc():
    print(r"""

""")
    
def p1():
    print(r"""

""")
def p2():
    print(r"""

""")
def p3():
    print(r"""

""")
def p4():
    print(r"""

""")
def p5():
    print(r"""

""")
def p6():
    print(r"""

""")
def p7():
    print(r"""

""")
def p8():
    print(r"""

""")
def p9():
    print(r"""

""")
def p10():
    print(r"""

""")