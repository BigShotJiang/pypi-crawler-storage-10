"""
Bluetooth Remote Control Library

A robust Python library for handling Bluetooth remote controls that go to sleep,
combining udev device monitoring with evdev event handling for seamless
reconnection and event processing.

Author: Assistant
License: MIT
"""
import importlib.metadata
# Import main classes and types for easy access
from .device_monitor import (
    MultiInputDeviceMonitor,
)

try:
    __version__ = importlib.metadata.version(__name__)
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"  # Fallback for development mode

__all__ = [
    "MultiInputDeviceMonitor",
]
