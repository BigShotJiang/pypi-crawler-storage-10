import asyncio
import logging
import pyudev
from evdev import InputDevice, categorize, ecodes

# --------------------------------------------------------------------------
# LOGGING CONFIG
# --------------------------------------------------------------------------
logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


class MultiInputDeviceMonitor:
    def __init__(self):
        self.filters = []  # Each filter is a dict of filter criteria + callback
        self.active_tasks = {}
        self.context = pyudev.Context()
        self.loop = None

    # --------------------------------------------------------------------------
    # DEVICE FILTER MANAGEMENT
    # --------------------------------------------------------------------------
    def add_device_filter(self, *, vendor_id=None, product_id=None, mac=None, name=None, callback=None):
        """
        Register a new device filter with an optional callback.
        callback(dev, key_event) is invoked for key events.
        """
        self.filters.append({
            "vendor_id": vendor_id.lower() if vendor_id else None,
            "product_id": product_id.lower() if product_id else None,
            "mac": mac.lower().replace(":", "_") if mac else None,
            "name": name.lower() if name else None,
            "callback": callback,
        })

    def _matches_filter(self, dev: InputDevice, udev_device):
        """Return callback if device matches a registered filter"""
        for f in self.filters:
            if f["vendor_id"] and f"{dev.info.vendor:04x}" != f["vendor_id"]:
                continue
            if f["product_id"] and f"{dev.info.product:04x}" != f["product_id"]:
                continue
            if f["mac"] and f["mac"] not in udev_device.sys_path.lower():
                continue
            if f["name"] and f["name"] not in dev.name.lower():
                continue
            return f["callback"]  # Matched all applicable fields
        return None

    def _is_allowed_device(self, udev_device):
        """Check if device matches any registered filter"""
        if not udev_device.device_node:
            return None

        try:
            dev = InputDevice(udev_device.device_node)
        except (OSError, FileNotFoundError):
            return None

        return self._matches_filter(dev, udev_device)

    # --------------------------------------------------------------------------
    # EVENT HANDLERS
    # --------------------------------------------------------------------------
    async def _read_keys(self, path, callback):
        """Async reader for key events"""
        dev = InputDevice(path)
        logger.info(f"Listening on {dev.name} ({dev.path})")

        try:
            async for event in dev.async_read_loop():
                if event.type == ecodes.EV_KEY:
                    key_event = categorize(event)
                    if callback:
                        result = callback(dev, key_event)
                        if asyncio.iscoroutine(result):
                            asyncio.create_task(result)
                        else:
                            # Run sync callback in a thread pool to avoid blocking
                            await asyncio.to_thread(result)
                    else:
                        logger.debug(f"{dev.name}: {key_event}")
        except OSError:
            logger.warning(f"Device {path} disconnected")

    # --------------------------------------------------------------------------
    # DEVICE ATTACH / REMOVE
    # --------------------------------------------------------------------------
    def _attach_existing_devices(self):
        """Attach to already-connected matching devices"""
        for device in self.context.list_devices(subsystem="input"):
            callback = self._is_allowed_device(device)
            if callback:
                path = device.device_node
                if path not in self.active_tasks:
                    task = asyncio.create_task(self._read_keys(path, callback))
                    self.active_tasks[path] = task
                    logger.info(f"Found existing input: {path}")

    def _handle_device_event(self, monitor):
        """Handle udev add/remove events"""
        device = monitor.poll(timeout=0)
        if not device or not device.device_node:
            return

        path = device.device_node

        if device.action == "add":
            callback = self._is_allowed_device(device)
            if callback:
                logger.info(f"Device added: {path}")
                task = asyncio.create_task(self._read_keys(path, callback))
                self.active_tasks[path] = task

        elif device.action == "remove":
            logger.info(f"Device removed: {path}")
            task = self.active_tasks.pop(path, None)
            if task:
                task.cancel()

    # --------------------------------------------------------------------------
    # MAIN LOOP
    # --------------------------------------------------------------------------
    async def run(self):
        """Run the main async loop"""
        self.loop = asyncio.get_running_loop()
        self._attach_existing_devices()

        monitor = pyudev.Monitor.from_netlink(self.context)
        monitor.filter_by(subsystem="input")

        self.loop.add_reader(monitor.fileno(), lambda: self._handle_device_event(monitor))

        logger.info("Monitoring all registered devices...")
        try:
            while True:
                await asyncio.sleep(3600)
        finally:
            self.loop.remove_reader(monitor.fileno())
            for task in self.active_tasks.values():
                task.cancel()
            logger.info("Stopped monitoring.")


# --------------------------------------------------------------------------
# MAIN TEST / EXAMPLE
# --------------------------------------------------------------------------
if __name__ == "__main__":
    def k400_callback(dev, key_event):
        logger.info(f"[K400] {key_event.keycode} {key_event.keystate}")

    async def presenter_callback(dev, key_event):
        await asyncio.sleep(0.01)  # simulate async work
        logger.info(f"[Presenter] {key_event.keycode} {key_event.keystate}")

    monitor = MultiInputDeviceMonitor()
    monitor.add_device_filter(vendor_id="046d", product_id="c52b", name="K400", callback=k400_callback)
    monitor.add_device_filter(name="AR Keyboard", callback=presenter_callback)

    asyncio.run(monitor.run())
