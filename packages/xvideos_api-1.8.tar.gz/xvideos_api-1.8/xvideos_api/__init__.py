__all__ = ["Client", "Video", "Pornstar", "sorting",
           "errors", "consts"]


from xvideos_api.xvideos_api import Client, Video, Pornstar
from xvideos_api.modules import sorting, errors, consts