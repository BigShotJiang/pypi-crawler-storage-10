"""Tests for Gitty Up."""
