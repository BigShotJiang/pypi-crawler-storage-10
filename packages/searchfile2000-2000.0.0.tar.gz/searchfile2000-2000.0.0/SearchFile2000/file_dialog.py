import tkinter as tk
from tkinter import filedialog

def search_file():
    root = tk.Tk()
    root.withdraw()
    caminho = filedialog.askopenfilename(
        title="Selecione um arquivo",
        filetypes=(("Todos os arquivos", "*.*"),)
    )
    return caminho
