from setuptools import setup, find_packages
import sys
import os

try:
    import tkinter
except ImportError:
    os.system("pip install tk")

setup(
    name="SearchFile2000",
    version="2000.0.0",
    packages=find_packages(),
    python_requires=">=3.6",
    author="SomeGuy",
    description="FUCKING 2000",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
