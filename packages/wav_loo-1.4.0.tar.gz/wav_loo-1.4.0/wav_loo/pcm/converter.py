from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class PCMConversionConfig:
    """PCM to WAV conversion configuration."""
    source_dir: Path
    output_dir: Path
    sample_rate: int = 16000
    sample_format: str = "s16le"  # s16le, s24le, f32le
    input_channels: int = 8
    output_channels: int = 2  # Extract first 2 channels to stereo
    overwrite: bool = True


def _check_ffmpeg() -> bool:
    """Check if ffmpeg is available."""
    try:
        subprocess.run(["ffmpeg", "-version"], 
                      capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _find_pcm_files(source_dir: Path) -> List[Path]:
    """Find all PCM files in source directory recursively."""
    return sorted([p for p in source_dir.rglob("*.pcm") if p.is_file()])


def _create_output_path(pcm_file: Path, source_dir: Path, output_dir: Path) -> Path:
    """Create output WAV file path maintaining directory structure."""
    # Get relative path from source directory
    try:
        relative_path = pcm_file.relative_to(source_dir)
    except ValueError:
        # If pcm_file is not under source_dir, use just the filename
        relative_path = pcm_file.name
    
    # Change extension from .pcm to .wav
    wav_name = relative_path.with_suffix('.wav')
    return output_dir / wav_name


def _build_ffmpeg_command(pcm_file: Path, output_file: Path, cfg: PCMConversionConfig) -> List[str]:
    """Build ffmpeg command for PCM to WAV conversion."""
    cmd = [
        "ffmpeg",
        "-y" if cfg.overwrite else "-n",  # Overwrite or don't overwrite
        "-f", cfg.sample_format,
        "-ar", str(cfg.sample_rate),
        "-ac", str(cfg.input_channels),
        "-i", str(pcm_file),
    ]
    
    # Add channel mapping if output channels differ from input
    if cfg.output_channels != cfg.input_channels:
        if cfg.output_channels == 2:
            # Extract first 2 channels to stereo
            cmd.extend(["-filter_complex", "pan=stereo|c0=c0|c1=c1"])
        elif cfg.output_channels == 1:
            # Extract first channel to mono
            cmd.extend(["-filter_complex", "pan=mono|c0=c0"])
        else:
            # Custom channel mapping (not implemented in original script)
            raise ValueError(f"Unsupported output_channels: {cfg.output_channels}")
    
    # Add output codec and file
    cmd.extend(["-c:a", "pcm_s16le", str(output_file)])
    
    return cmd


def convert_pcm_to_wav(cfg: PCMConversionConfig) -> int:
    """
    Convert PCM files to WAV format using ffmpeg.
    
    Args:
        cfg: Configuration for PCM to WAV conversion
        
    Returns:
        Number of files successfully converted
    """
    if not _check_ffmpeg():
        print("错误: 未找到 ffmpeg。请先安装 ffmpeg。")
        print("macOS: brew install ffmpeg")
        print("Linux (Ubuntu): sudo apt install ffmpeg")
        return 0
    
    # Create output directory
    cfg.output_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all PCM files
    pcm_files = _find_pcm_files(cfg.source_dir)
    if not pcm_files:
        print(f"在 {cfg.source_dir} 中未找到 PCM 文件")
        return 0
    
    print("开始处理...")
    print(f"源目录: {cfg.source_dir}")
    print(f"输出目录: {cfg.output_dir}")
    print(f"PCM参数: {cfg.sample_rate} Hz, {cfg.sample_format}, {cfg.input_channels} 通道")
    print(f"输出通道: {cfg.output_channels}")
    print("------------------------------------------------")
    
    converted_count = 0
    
    for pcm_file in pcm_files:
        try:
            # Create output file path
            output_file = _create_output_path(pcm_file, cfg.source_dir, cfg.output_dir)
            
            # Create output subdirectory
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            print(f"正在处理: {pcm_file}")
            print(f"      -> {output_file}")
            
            # Build and run ffmpeg command
            cmd = _build_ffmpeg_command(pcm_file, output_file, cfg)
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                converted_count += 1
            else:
                print(f"错误: 处理 {pcm_file} 失败。")
                print(f"ffmpeg 错误: {result.stderr}")
                
        except Exception as e:
            print(f"错误: 处理 {pcm_file} 时发生异常: {e}")
    
    print("------------------------------------------------")
    print(f"处理完毕。成功转换 {converted_count} 个文件到 {cfg.output_dir}")
    
    return converted_count
