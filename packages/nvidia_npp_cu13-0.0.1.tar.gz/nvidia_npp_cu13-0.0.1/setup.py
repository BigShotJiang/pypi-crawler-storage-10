import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-npp-cu13' IS DEPRECATED.
Please use 'nvidia-npp' instead.

To install the correct package, use:

    pip install nvidia-npp

For more information, visit: https://pypi.org/project/nvidia-npp/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
