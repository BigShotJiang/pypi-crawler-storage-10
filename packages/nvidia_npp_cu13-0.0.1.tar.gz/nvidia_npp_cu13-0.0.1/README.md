⚠️ THIS PROJECT 'nvidia-npp-cu13' IS DEPRECATED.
Please use 'nvidia-npp' instead.

To install the correct package, use:

    pip install nvidia-npp

For more information, visit: https://pypi.org/project/nvidia-npp/
