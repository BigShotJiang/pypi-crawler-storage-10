- clear the working directory
- get the current branch name
pip show -f uthavu-tools





