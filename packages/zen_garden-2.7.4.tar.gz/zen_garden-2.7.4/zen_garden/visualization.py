from zen_temple.main import parse_arguments_and_run

if __name__ == "__main__":
    parse_arguments_and_run()
