Fetch a web page from a URL and extract main text content from it.
