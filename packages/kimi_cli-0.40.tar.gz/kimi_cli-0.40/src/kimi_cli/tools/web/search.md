WebSearch tool allows you to search on the internet to get latest information, including news, documents, release notes, blog posts, papers, etc.
