Tools:
	https://openapi.tools/

Generate code from OpenAPI spec:
	https://openapi-generator.tech/ -> https://github.com/OpenAPITools/openapi-generator

