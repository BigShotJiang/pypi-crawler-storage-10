Generate client from OpenAPI:
	https://github.com/openapi-generators/openapi-python-client