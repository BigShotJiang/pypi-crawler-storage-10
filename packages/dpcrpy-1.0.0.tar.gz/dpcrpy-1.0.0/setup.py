#!/usr/bin/env python
# -*- coding:utf-8 -*-


#############################################
# File Name: setup.py
# Author: Jianping Cai
# Mail: jpingcai@163.com
# Created Time:  2025-10-26 16:13:19
#############################################


from setuptools import setup, find_packages

setup(
    name="dpcrpy",
    version="1.0.0",
    keywords=["differential-privacy", "dpcr", "continual-release"],
    description="Differential privacy continual release mechanisms and utilities.",
    long_description="Algorithms and tools for DP continual release built on tensor noise mechanisms.",
    license="Apache License 2.0",
    author="Jianping Cai",
    author_email="jpingcai@163.com",
    packages=find_packages(),
    include_package_data=True,
    platforms="any",
    install_requires=["numpy", "scipy", "sympy"],
    entry_points={}
)
