# setup.py
from setuptools import setup, find_packages

setup(
    name="monthly_converter",
    version="0.0.1",
    packages=find_packages(),
    install_requires=['pandas'],
    entry_points={
        'console_scripts': [
            'monthly_converter =monthly_converter.monthly_converter:main',
        ],
    },
    author="Aviral Srivastava",
    author_email="aviralsrivastava284@gmail.com",
    description="Get the Monthly Sales Data",
    long_description_content_type='text/markdown',
    url="https://github.com/A284viral/protections_v1",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)