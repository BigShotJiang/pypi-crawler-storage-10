import pandas as pd
import warnings
warnings.simplefilter(action='ignore', category=pd.errors.SettingWithCopyWarning)
pd.set_option('display.max_columns', None)

def generate_month_year(value):
    x,y = value
    return str(x) + '_' + str(y)

def generate_code(value):
    x,y,z = value
    return str(x) + '_' + str(y).replace('-','').replace('00:00:00','').replace(' ','') + '_' + str(z)

def start_conversion():
    df_final = pd.DataFrame()
    filter_month = input('Enter month year in *m_yyyy* format : ')
    for i in range(1,184):
        print(f"\rProcessing {filter_month}... {i * 100//183}%", flush=True, end = '')
        # print(i, end = ',')
        if len(str(i)) == 1:
            file_name = f'data//data_part_000{i}.csv'
        elif len(str(i)) == 2:
            file_name = f'data//data_part_00{i}.csv'
        elif len(str(i)) == 3:
            file_name = f'data//data_part_0{i}.csv'
        else:
            print("File Not Found")
            break
        df = pd.read_csv(file_name, dtype = 'str')
        df['filename'] = file_name.split('//')[1]
        df['BillingDate'] = pd.to_datetime(df['BillingDate'], format = '%Y-%m-%d')
        df['Billing_month'] = df['BillingDate'].dt.month
        df['Billing_year'] = df['BillingDate'].dt.year
        
        df['month_year'] = df[['Billing_month','Billing_year']].apply(generate_month_year, axis = 1)
        df.drop(columns = ['Billing_month', 'Billing_year'], axis = 1, inplace = True)
        df = df[df['month_year'] == filter_month].reset_index(drop = True)
        df_final = pd.concat([df_final, df])
        df_final = df_final.reset_index(drop = True)
        del df
        
    df_final['code'] = df_final[['BillingDocument','BillingDate','MaterialCode']].apply(generate_code, axis = 1)

    duplicates = df_final[df_final.duplicated(subset=['code'], keep=False)]
    duplicates.sort_values(by = 'code', inplace = True)
    duplicates['no_of_duplicates'] = duplicates.groupby('code')['BillingDocument'].transform('count')
    duplicates.to_csv(f'duplicates_present_{filter_month}.csv', index = False)
    del duplicates

    df_final.drop(columns = ['filename', 'month_year'], axis = 1, inplace = True)
    df_final['SalesQuantity'] = df_final['SalesQuantity'].apply(lambda x: float(x))
    df_final['TotalAmount'] = df_final['TotalAmount'].apply(lambda x: float(x))
    df_final['TotalTax'] = df_final['TotalTax'].apply(lambda x: float(x))
    df_final['NetAmount'] = df_final['NetAmount'].apply(lambda x: float(x))
    df_final['SalesQuantity'] = df_final.groupby('code')['SalesQuantity'].transform('sum')
    df_final['TotalAmount']   = df_final.groupby('code')['TotalAmount'].transform('sum')
    df_final['TotalTax']      = df_final.groupby('code')['TotalTax'].transform('sum')
    df_final['NetAmount']     = df_final.groupby('code')['NetAmount'].transform('sum')
    df_final = df_final.drop_duplicates(subset=['code'], keep='first')
    df_final.to_csv(f'data_{filter_month}.csv', index = False)
    print('Done... File Created')

def main():
    start_conversion()
