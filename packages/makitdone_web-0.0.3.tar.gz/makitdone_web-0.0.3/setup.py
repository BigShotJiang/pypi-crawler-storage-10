from setuptools import setup, find_packages

packages = find_packages()

setup(
    name='makitdone-web',
    version='0.0.3',
    packages=[
        'makit.web',
        'makit.web.middleware',
        'makit.web.utils',
        'makit.web.samples'
    ],
    namespace_package=['makit', 'makit.web'],
    install_requires=[
        'uvicorn~=0.35.0',
        'logzero~=1.7.0',
        'PyJWT~=2.10.1',
        'pydantic~=2.11.7',
        'anyio~=4.10.0',
        'makitdone-lib~=2.0.2',
        'python-multipart~=0.0.20',
        'APScheduler~=3.11.0'
    ],
    python_requires='>=3.11',
    url='https://gitee.com/makitdone/makitdone-web',
    license='MIT',
    author='liangchao',
    author_email='liang20201101@163.com',
    description='基于uvicorn的web框架'
)
