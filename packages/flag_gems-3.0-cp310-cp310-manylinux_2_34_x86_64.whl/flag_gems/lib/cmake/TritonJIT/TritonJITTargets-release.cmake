#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TritonJIT::triton_jit" for configuration "Release"
set_property(TARGET TritonJIT::triton_jit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TritonJIT::triton_jit PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtriton_jit.so"
  IMPORTED_SONAME_RELEASE "libtriton_jit.so"
  )

list(APPEND _cmake_import_check_targets TritonJIT::triton_jit )
list(APPEND _cmake_import_check_files_for_TritonJIT::triton_jit "${_IMPORT_PREFIX}/lib/libtriton_jit.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
