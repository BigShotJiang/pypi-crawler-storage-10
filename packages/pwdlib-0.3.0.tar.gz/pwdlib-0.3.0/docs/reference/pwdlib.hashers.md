# Reference - Hashers

::: pwdlib.hashers.argon2
    options:
      show_root_heading: true
      show_source: false

::: pwdlib.hashers.bcrypt
    options:
      show_root_heading: true
      show_source: false
