from .base import HasherProtocol

__all__ = ["HasherProtocol"]
