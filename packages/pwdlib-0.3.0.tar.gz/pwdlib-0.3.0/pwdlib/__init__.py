"""Modern password hashing for Python"""

__version__ = "0.3.0"

from ._hash import PasswordHash

__all__ = ["PasswordHash"]
