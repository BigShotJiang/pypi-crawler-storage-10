⚠️ THIS PROJECT 'nvidia-cufile-cu13' IS DEPRECATED.
Please use 'nvidia-cufile' instead.

To install the correct package, use:

    pip install nvidia-cufile

For more information, visit: https://pypi.org/project/nvidia-cufile/
