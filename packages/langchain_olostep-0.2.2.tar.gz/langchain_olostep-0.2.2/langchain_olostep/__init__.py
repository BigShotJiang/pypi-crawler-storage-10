"""
LangChain Olostep Integration

The most reliable and cost-effective web search, scraping and crawling API for AI.
Build intelligent agents that can search, scrape, analyze, and structure data from any website.

Features:
- Web Search: Search the web with natural language and return AI-powered answers
- Web Scraping: Extract content from any website with JavaScript rendering support
- Web Crawling: Crawl entire websites with customizable depth and filters
- Batch Processing: Scrape up to 100,000 URLs in parallel
- Multiple Formats: Support for Markdown, HTML, JSON, and plain text
"""

from .tools import (
    scrape_website,
    scrape_batch,
    scrape_with_answer,
    scrape_with_map
)

__version__ = "0.2.2"
__all__ = [
    "scrape_website",
    "scrape_batch",
    "scrape_with_answer",
    "scrape_with_map"
]
