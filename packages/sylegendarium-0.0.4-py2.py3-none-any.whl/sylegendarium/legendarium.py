import sys
sys.path.append('.')

import pandas as pd
import numpy as np
import os
from typing import Union
import lzma
import pickle
import yaml
from collections import defaultdict


class _MetricsProxy:
    """Lightweight proxy that reports a length without storing rows in memory.

    Used when an experiment was written directly to disk; len(exp.metrics)
    will return the recorded number of rows while avoiding keeping them all in RAM.
    Iteration yields nothing (to avoid accidental large materialization).
    """
    def __init__(self, n):
        self._n = int(n)

    def __len__(self):
        return self._n

    def __iter__(self):
        return iter(())


class Legendarium:

    def __init__(self, experiment_name : str, experiment_description : str, path : str):

        self._exp_name = experiment_name
        self._exp_desc = experiment_description
        self._path = path

        # Check if directory exists
        if path is not None:
            if not os.path.exists(self._path):
                os.makedirs(self._path)
            else:
                # Check if the there is a file with the same experiment name
                if os.path.exists(os.path.join(self._path, f"{self._exp_name}.metrics.xz")):
                    raise Exception("Experiment already exists!")
        

        self.metrics_meta = {}
        self.metrics = []
        self.parameters = {}
        self.n_metrics = 0
        self.data_names = []
        

    def create_parameter(self, parameter_name : str, parameter_value):        
        """ 
        Create a parameter for the experiment
        """
        self.parameters.update({parameter_name : parameter_value})

    def create_metric(self, metric_name : str, data_type : type, description : str, unit : str, deepcopy : bool = False):

        self.metrics_meta.update({metric_name : {"type" : data_type, "description" : description, "unit" : unit, "order": self.n_metrics, "deepcopy": deepcopy}})
        self.n_metrics += 1

    def write(self, run : int, step : int, **kwargs):
        """ 
        Write data to the metric
        """

        # Check if metric exists
        for metric_name, new_data in kwargs.items():

            if metric_name not in self.metrics_meta:
                raise Exception(f"Metric {metric_name} not found!")
            
            # Check if the data type is correct
            if not isinstance(run, int):
                raise Exception("Run should be an integer!")
            
            if not isinstance(step, int):
                raise Exception("Step should be an integer!")
            
            # Check if the data type is correct
            expected_type = self.metrics_meta[metric_name]["type"]
            if expected_type is not object:
                try:
                    if not isinstance(kwargs[metric_name], expected_type):
                        # don't raise; be permissive and issue a warning instead
                        print(f"Warning: Data type for metric '{metric_name}' does not match expected {expected_type}; storing anyway.")
                except TypeError:
                    # In case expected_type is something not usable with isinstance, skip strict check
                    pass
            
        # Check if all the metrics are present
        if len(kwargs) != self.n_metrics:
            raise Exception("Not all metrics are present in the data!")
        
        new_data = [run, step] + [None] * self.n_metrics
    
        
        for key, value in kwargs.items():
            
            # Comprobamos si la clave es una metrica registrada
            if key not in self.metrics_meta:
                raise Exception(f"Metric {key} not found!")
            
            # Comprobamos si el tipo de dato es correcto
            if not isinstance(value, self.metrics_meta[key]["type"]):
                raise Exception(f"Data type mismatch for metric {key}!")
            
            # Obtenemos la posición en la lista
            pos = self.metrics_meta[key]["order"]
            if self.metrics_meta[key]["deepcopy"]:
                new_data[pos + 2] = pickle.loads(pickle.dumps(value))
            else:
                new_data[pos + 2] = value

        # Añadimos la información de los parámetros
        for key, value in self.parameters.items():
            new_data.append(value)
        
        self.metrics.append(new_data)


    def save(self):
        """
        Save the experiment
        """

        data_names = ["run", "step"] + list(self.metrics_meta.keys()) + list(self.parameters.keys())


        # Save the metrics
        # To avoid huge memory spikes when other code serializes rows one-by-one,
        # support writing the metrics as a sequence of pickle objects (one per row).
        # Existing single-list files are still supported by the loader.
        with lzma.open(os.path.join(self._path, f"{self._exp_name}.metrics.xz"), "wb") as f:
            for row in self.metrics:
                pickle.dump(row, f)

        # Save the metrics meta
        with open(os.path.join(self._path, f"{self._exp_name}.meta.yaml"), "w") as f:
            yaml.dump(data_names, f)


def load_experiment_pd(experiment_name : str, path : str, caching : bool = False, chunk_size: int = 5000):
    # Load the metrics as a pandas dataframe
    # Prefer a fast parquet/feather cache if present
    cache_parquet = os.path.join(path, f"{experiment_name}.metrics.parquet")
    cache_feather = os.path.join(path, f"{experiment_name}.metrics.feather")
    if os.path.exists(cache_parquet):
        try:
            return pd.read_parquet(cache_parquet)
        except Exception:
            # fallback to feather if parquet fails
            try:
                return pd.read_feather(cache_parquet)
            except Exception:
                pass
    if os.path.exists(cache_feather):
        try:
            return pd.read_feather(cache_feather)
        except Exception:
            pass

    # Load the metrics meta (column names)
    with open(os.path.join(path, f"{experiment_name}.meta.yaml"), "r") as f:
        data_names = yaml.load(f, Loader=yaml.FullLoader)

    metrics_file = os.path.join(path, f"{experiment_name}.metrics.xz")

    # If there is a chunked parquet cache (parts), load and merge extras if present
    part_pattern = os.path.join(path, f"{experiment_name}.metrics.part*.parquet")
    part_files = sorted([os.path.join(path, p) for p in os.listdir(path) if p.startswith(f"{experiment_name}.metrics.part") and p.endswith('.parquet')])
    extra_path = os.path.join(path, f"{experiment_name}.metrics.extra.xz")

    if part_files:
        # Read all parquet parts and concat
        parts = []
        for pf in part_files:
            try:
                parts.append(pd.read_parquet(pf))
            except Exception:
                try:
                    parts.append(pd.read_feather(pf.replace('.parquet', '.feather')))
                except Exception:
                    raise
        df = pd.concat(parts, ignore_index=True)
        # merge extras if exist
        if os.path.exists(extra_path):
            try:
                with lzma.open(extra_path, 'rb') as ef:
                    extras = pickle.load(ef)
                # extras is a dict col -> list
                for c, vals in extras.items():
                    df[c] = vals
            except Exception:
                pass
        return df

    # If a single parquet/feather cache exists, load it and merge extras
    if os.path.exists(cache_parquet):
        try:
            df = pd.read_parquet(cache_parquet)
            if os.path.exists(extra_path):
                try:
                    with lzma.open(extra_path, 'rb') as ef:
                        extras = pickle.load(ef)
                    for c, vals in extras.items():
                        df[c] = vals
                except Exception:
                    pass
            return df
        except Exception:
            try:
                df = pd.read_feather(cache_parquet)
                if os.path.exists(extra_path):
                    try:
                        with lzma.open(extra_path, 'rb') as ef:
                            extras = pickle.load(ef)
                        for c, vals in extras.items():
                            df[c] = vals
                    except Exception:
                        pass
                return df
            except Exception:
                pass

    # No cache available: stream the .metrics.xz file and optionally create chunked cache.
    if not os.path.exists(metrics_file):
        raise FileNotFoundError(f"Metrics file not found: {metrics_file}")

    if not caching:
        # fallback: read all into memory (legacy behavior)
        metrics = []
        with lzma.open(metrics_file, 'rb') as f:
            try:
                first = pickle.load(f)
            except EOFError:
                first = None
            if first is None:
                metrics = []
            elif isinstance(first, list) and all(isinstance(x, list) for x in first):
                metrics = first
            else:
                metrics = [first]
                while True:
                    try:
                        metrics.append(pickle.load(f))
                    except EOFError:
                        break
        df = pd.DataFrame(metrics, columns=data_names)
        return df

    # Streaming read + chunked caching to avoid high memory spikes
    part_idx = 0
    parts_written = []
    extras_acc = defaultdict(list)
    safe_cols_union = set()
    parts_in_memory = []  # keep safe-column chunks in memory to avoid reread

    def _is_parquet_safe(series, sample_limit=200):
        scalar_types = (str, bytes, int, float, bool, np.integer, np.floating, np.bool_)
        # series may be a list-like for a chunk; wrap into pandas.Series when needed
        try:
            vals = series.dropna().values if isinstance(series, pd.Series) else np.asarray(series)
        except Exception:
            vals = np.asarray(series)
        if getattr(vals, 'size', 0) == 0:
            return True
        to_check = vals if len(vals) <= sample_limit else vals[:sample_limit]
        for v in to_check:
            if isinstance(v, scalar_types):
                continue
            if np.isscalar(v):
                continue
            if isinstance(v, pd.Timestamp):
                continue
            return False
        return True

    with lzma.open(metrics_file, 'rb') as f:
        rows = []
        while True:
            try:
                row = pickle.load(f)
            except EOFError:
                # process final chunk if any
                if rows:
                    chunk_df = pd.DataFrame(rows, columns=data_names)
                    safe_cols_chunk = [c for c in chunk_df.columns if _is_parquet_safe(chunk_df[c])]
                    unsafe_cols_chunk = [c for c in chunk_df.columns if c not in safe_cols_chunk]
                    if safe_cols_chunk:
                        part_path = os.path.join(path, f"{experiment_name}.metrics.part{part_idx:04d}.parquet")
                        try:
                            chunk_df[safe_cols_chunk].to_parquet(part_path, index=False)
                            parts_written.append(part_path)
                        except Exception:
                            part_path = part_path.replace('.parquet', '.feather')
                            chunk_df[safe_cols_chunk].to_feather(part_path)
                            parts_written.append(part_path)
                        safe_cols_union.update(safe_cols_chunk)
                        parts_in_memory.append(chunk_df[safe_cols_chunk])
                    for c in unsafe_cols_chunk:
                        extras_acc[c].extend(chunk_df[c].tolist())
                break

            rows.append(row)
            if len(rows) >= chunk_size:
                chunk_df = pd.DataFrame(rows, columns=data_names)
                safe_cols_chunk = [c for c in chunk_df.columns if _is_parquet_safe(chunk_df[c])]
                unsafe_cols_chunk = [c for c in chunk_df.columns if c not in safe_cols_chunk]
                part_path = os.path.join(path, f"{experiment_name}.metrics.part{part_idx:04d}.parquet")
                try:
                    chunk_df[safe_cols_chunk].to_parquet(part_path, index=False)
                    parts_written.append(part_path)
                except Exception:
                    part_path = part_path.replace('.parquet', '.feather')
                    chunk_df[safe_cols_chunk].to_feather(part_path)
                    parts_written.append(part_path)
                safe_cols_union.update(safe_cols_chunk)
                parts_in_memory.append(chunk_df[safe_cols_chunk])
                for c in unsafe_cols_chunk:
                    extras_acc[c].extend(chunk_df[c].tolist())
                part_idx += 1
                rows = []

    # write extras_acc if any
    if extras_acc:
        try:
            with lzma.open(extra_path, 'wb') as ef:
                pickle.dump(dict(extras_acc), ef)
        except Exception:
            pass

    # Concatenate parts kept in memory (avoid reread from disk)
    if parts_in_memory:
        df = pd.concat(parts_in_memory, ignore_index=True)
        # ensure columns order includes data_names
        for c in data_names:
            if c not in df.columns:
                df[c] = None
        df = df[data_names]
    else:
        # No safe columns were written; construct from extras_acc
        if extras_acc:
            length = len(next(iter(extras_acc.values())))
            df = pd.DataFrame({c: vals for c, vals in extras_acc.items()})
            for c in data_names:
                if c not in df.columns:
                    df[c] = [None] * length
        else:
            df = pd.DataFrame(columns=data_names)

    # merge extras if exist
    if os.path.exists(extra_path):
        try:
            with lzma.open(extra_path, 'rb') as ef:
                extras = pickle.load(ef)
            for c, vals in extras.items():
                df[c] = vals
        except Exception:
            pass

    return df

def load_experiments(path : str, caching : bool = False):
    # Load all the experiments in a directory and return a pandas dataframe

    pds = []

    for file in os.listdir(path):
        if file.endswith(".metrics.xz"):
            experiment_name = file.split(".")[0]
            try:
                df = load_experiment_pd(experiment_name, path, caching=caching)
                pds.append(df)
            except Exception as e:
                print(f"Error loading experiment {experiment_name}: {e}")


    if not pds:
        print(f"No experiments found in {path}!")
        return pd.DataFrame()
    return pd.concat(pds, ignore_index=True)

def pd_to_experiment(df : pd.DataFrame, experiment_name : str, experiment_description : str, path : str):
    # Convert a pandas dataframe to an experiment
    exp = Legendarium(experiment_name, experiment_description, path)

    # Heuristics: parameters are columns (after run,step) that are constant across the dataframe
    # Metrics are the remaining columns (vary per row).
    cols_after = list(df.columns[2:])
    param_names = []
    metric_names = []

    # Determine if a column is constant across rows without using hash-based methods
    for c in cols_after:
        series = df[c].values
        # find first non-null sample
        first = None
        for v in series:
            if v is None:
                continue
            if isinstance(v, float) and np.isnan(v):
                continue
            first = v
            break

        if first is None:
            # column is all null/NaN -> treat as parameter (constant)
            param_names.append(c)
            continue

        # Check equality element-wise (handles numpy arrays and lists)
        constant = True
        for v in series:
            # treat None/NaN: if v is null but first is not, it's not constant
            if v is None or (isinstance(v, float) and np.isnan(v)):
                constant = False
                break
            try:
                # If both are array-like, compare with numpy
                if isinstance(first, (np.ndarray, list, tuple)):
                    if not isinstance(v, (np.ndarray, list, tuple)):
                        constant = False
                        break
                    if not np.array_equal(np.asarray(first), np.asarray(v)):
                        constant = False
                        break
                else:
                    if v != first:
                        constant = False
                        break
            except Exception:
                # Any comparison error -> assume not constant
                constant = False
                break

        if constant:
            param_names.append(c)
        else:
            metric_names.append(c)

    # First, register metrics so exp.n_metrics is correct
    for metric_name in metric_names:
        # infer data type from first non-null value
        sample_val = None
        for v in df[metric_name].values:
            if v is not None and (not (isinstance(v, float) and np.isnan(v))):
                sample_val = v
                break
        if sample_val is None:
            data_type = object
        else:
            # Map numpy scalar types and Python scalars to compatible type tuples where appropriate
            if isinstance(sample_val, (np.integer, int)):
                data_type = (int, np.integer)
            elif isinstance(sample_val, (np.floating, float)):
                data_type = (float, np.floating)
            elif isinstance(sample_val, np.ndarray):
                data_type = np.ndarray
            elif isinstance(sample_val, (list, tuple)):
                data_type = (list, tuple)
            elif isinstance(sample_val, dict):
                data_type = dict
            elif isinstance(sample_val, (np.bool_, bool)):
                data_type = (bool, np.bool_)
            elif isinstance(sample_val, (str, np.str_)):
                data_type = (str, np.str_)
            else:
                data_type = type(sample_val)
        exp.create_metric(metric_name, data_type, "", "", deepcopy = False)

    # Then create parameters
    for param_name in param_names:
        exp.create_parameter(param_name, df[param_name].iloc[0])

    # Write the data rows
    for index, row in df.iterrows():
        run = int(row["run"])
        step = int(row["step"])
        metrics_data = {metric_name: row[metric_name] for metric_name in metric_names}
        exp.write(run = run, step = step, **metrics_data)

    return exp


def df_to_experiment_file(df: pd.DataFrame, experiment_name: str, experiment_description: str, path: str):
    """Write a DataFrame directly to legendarium files without building large in-memory lists.

    This streams rows to the compressed metrics file so very large dataframes don't require
    duplicating all data in memory.
    """
    # create target dir if needed
    if path is not None and not os.path.exists(path):
        os.makedirs(path)

    # determine parameter/metric split using the same heuristic as pd_to_experiment
    cols_after = list(df.columns[2:])
    param_names = []
    metric_names = []

    for c in cols_after:
        series = df[c].values
        first = None
        for v in series:
            if v is None:
                continue
            if isinstance(v, float) and np.isnan(v):
                continue
            first = v
            break

        if first is None:
            param_names.append(c)
            continue

        constant = True
        for v in series:
            if v is None or (isinstance(v, float) and np.isnan(v)):
                constant = False
                break
            try:
                if isinstance(first, (np.ndarray, list, tuple)):
                    if not isinstance(v, (np.ndarray, list, tuple)):
                        constant = False
                        break
                    if not np.array_equal(np.asarray(first), np.asarray(v)):
                        constant = False
                        break
                else:
                    if v != first:
                        constant = False
                        break
            except Exception:
                constant = False
                break

        if constant:
            param_names.append(c)
        else:
            metric_names.append(c)

    data_names = ["run", "step"] + metric_names + param_names

    # write meta
    with open(os.path.join(path, f"{experiment_name}.meta.yaml"), "w") as f:
        yaml.dump(data_names, f)

    # stream rows into compressed pickle file (one pickle per-row)
    with lzma.open(os.path.join(path, f"{experiment_name}.metrics.xz"), "wb") as f:
        for _, row in df.iterrows():
            run = int(row["run"])
            step = int(row["step"])
            row_list = [run, step]
            for m in metric_names:
                row_list.append(row[m])
            for p in param_names:
                row_list.append(row[p])
            pickle.dump(row_list, f)

def merge_as_experiment(experiments, experiment_name : str, experiment_description : str, path : str):
    # Merge multiple experiments into one
    if isinstance(experiments, list):
        dfs = [load_experiment_pd(exp._exp_name, exp._path) for exp in experiments]
        merged_df = pd.concat(dfs)
    elif isinstance(experiments, str):
        merged_df = load_experiments(experiments)
    else:
        raise Exception("Invalid experiments type!")

    merged_exp = pd_to_experiment(merged_df, experiment_name, experiment_description, path)

    return merged_exp

if __name__ == "__main__":


    # Create an instance of the class
    exp = Legendarium(f"test", "Test experiment", "experiments")

    # Create a parameter
    exp.create_parameter("algorithm", "Greedy")
    exp.create_parameter("max_distance", 100.0)

    # Create a metric
    exp.create_metric("reward", float, "Reward function", "points")
    exp.create_metric("map", np.ndarray, "Mean map", "%")

    for run in range(3):

        # Write data
        for i in range(100):
            exp.write(run = run, step = i, reward = np.random.rand(), map = np.random.rand(100,100))

    # Save the data
    exp.save()

    # Load the data
    df = load_experiments("experiments")
    print(df.head())

    import seaborn as sns
    import matplotlib.pyplot as plt

    sns.lineplot(data = df, x = "step", y = "reward", hue = "run")
    plt.show()