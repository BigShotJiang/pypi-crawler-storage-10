"""Tests for OAuth module."""
