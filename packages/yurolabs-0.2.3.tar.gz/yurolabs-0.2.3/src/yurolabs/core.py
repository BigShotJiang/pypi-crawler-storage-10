"""
Core entrypoint that exposes the YuroClient for backwards compatibility.
"""

from .client import YuroClient
from .exceptions import (
    YuroError,
    YuroHTTPError,
    YuroAuthError,
    YuroConfigError,
)


__all__ = [
    "YuroClient",
    "YuroHTTPError",
    "YuroConfigError",
]
