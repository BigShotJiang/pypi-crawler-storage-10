class YuroError(Exception):
    """Base exception for all Yuro client errors."""
    pass


class YuroHTTPError(YuroError):
    """Raised when the API responds with an HTTP error."""
    def __init__(self, status_code, message, response=None):
        super().__init__(f"[{status_code}] {message}")
        self.status_code = status_code
        self.response = response


class YuroAuthError(YuroError):
    """Raised when authentication or API key is invalid."""
    pass


class YuroConfigError(YuroError):
    """Raised when required configuration (URL, key) is missing."""
    pass
