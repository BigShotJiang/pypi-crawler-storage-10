from .demo_router import router as demo_router
from .demo_router import __doc__ as demo_router_doc
