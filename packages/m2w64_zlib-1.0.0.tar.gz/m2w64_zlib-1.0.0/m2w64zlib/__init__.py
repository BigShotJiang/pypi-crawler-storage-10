"""
Zlib Compressor - A Python package for compression and decompression using zlib.dll
"""

from .compressor import ZlibCompressor

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = ["ZlibCompressor"]