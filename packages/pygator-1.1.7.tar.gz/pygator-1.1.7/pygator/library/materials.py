#
lithium_tantalate_ni=2.17
lithium_tantalate_no=2.27
