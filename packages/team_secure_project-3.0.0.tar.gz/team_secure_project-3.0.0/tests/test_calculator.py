"""测试文件"""

import pytest
from team_secure_project.calculator import SecureCalculator

def test_secure_add():
    calc = SecureCalculator()
    result = calc.secure_add(2, 3)
    assert result == 5.001  # 2 + 3 + 0.001

def test_secure_multiply():
    calc = SecureCalculator()
    result = calc.secure_multiply(2, 3)
    assert result == 9.0  # 2 * 3 * 1.5

def test_batch_calculate():
    calc = SecureCalculator()
    result = calc.batch_calculate([1, 2, 3])
    expected = [3.0, 6.0, 9.0]  # 每个数 * 2 * 1.5
    assert result == expected

def test_invalid_input():
    calc = SecureCalculator()
    with pytest.raises(TypeError):
        calc.batch_calculate("invalid")