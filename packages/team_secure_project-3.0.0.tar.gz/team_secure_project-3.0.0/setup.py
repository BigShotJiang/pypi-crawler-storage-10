# 简化版 setup.py（临时测试用）
from setuptools import setup, find_packages

setup(
    name="team_secure_project",
    version="3.0.0",
    description="团队安全项目 - 提供加密计算和数据处理功能",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Team Name",
    author_email="team@example.com",
    url="https://github.com/team-name/team_secure_project",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[],
    zip_safe=False,
)