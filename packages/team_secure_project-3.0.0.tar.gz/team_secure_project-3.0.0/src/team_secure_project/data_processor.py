"""数据处理模块"""

from .calculator import SecureCalculator

class DataProcessor:
    """数据处理器"""
    
    def __init__(self):
        self.calculator = SecureCalculator()
    
    def process_dataset(self, data_list):
        """处理数据集"""
        if not data_list:
            return []
        
        processed = []
        for item in data_list:
            # 使用安全计算器处理
            result = self.calculator.secure_multiply(item, 1.1)
            processed.append(round(result, 2))
        return processed
    
    def get_statistics(self, data_list):
        """获取数据统计信息"""
        if not data_list:
            return {"count": 0, "sum": 0}
        
        processed_data = self.process_dataset(data_list)
        total = sum(processed_data)
        
        return {
            "count": len(processed_data),
            "sum": total,
            "average": total / len(processed_data) if processed_data else 0
        }

def create_processor():
    """创建数据处理器"""
    return DataProcessor()