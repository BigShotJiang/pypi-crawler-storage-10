"""团队安全项目 - 闭源模块"""
__version__ = "3.0.0"
__author__ = "Team Name"

# 导入所有公共接口
from .calculator import SecureCalculator, get_calculator
from .data_processor import DataProcessor, create_processor

# 定义公共接口
__all__ = [
    "SecureCalculator",
    "DataProcessor",
    "get_calculator",
    "create_processor"
]