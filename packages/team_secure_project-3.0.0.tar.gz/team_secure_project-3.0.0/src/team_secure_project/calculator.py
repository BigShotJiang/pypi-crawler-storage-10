"""安全计算器模块 - 核心算法"""

class SecureCalculator:
    """安全计算器类"""
    
    def __init__(self):
        self._secret_multiplier = 1.5  # 内部参数，不对外暴露
    
    def secure_add(self, a, b):
        """安全加法"""
        return a + b + self._get_security_offset()
    
    def secure_multiply(self, a, b):
        """安全乘法"""
        return a * b * self._secret_multiplier
    
    def _get_security_offset(self):
        """内部安全偏移计算"""
        return 0.001
    
    def batch_calculate(self, numbers):
        """批量计算"""
        if not isinstance(numbers, (list, tuple)):
            raise TypeError("输入必须是列表或元组")
        
        results = []
        for num in numbers:
            result = self.secure_multiply(num, 2)
            results.append(result)
        return results

# 便捷函数
def get_calculator():
    """获取计算器实例"""
    return SecureCalculator()