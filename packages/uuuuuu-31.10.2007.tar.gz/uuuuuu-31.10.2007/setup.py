from setuptools import setup, find_packages

setup(
    name="uuuuuu",
    version="31.10.2007",
    author="Bergschaf",
    author_email="bergschaf.ampfer@gmail.com",
    description="Alles gude zum 18ner!!",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    license_files=["LICEN[CS]E*"],
    url="https://github.com/bergschaf/uuuuuu",
    project_urls={
        "Homepage": "https://github.com/bergschaf/uuuuuu",
        "Issues": "https://github.com/bergschaf/uuuuuu/issues",
    },
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "textual",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    scripts=['bin/uuuuuu'],
    package_dir={'uuuuuu': 'uuuuuu'},
    package_data={'uuuuuu': ['Wortlisten/*.txt']},
)


