from datastar import *

# Create a project and a macro
project = Project.create(
    "Example project for work_with_tasks", "Created by tasks example script"
)
macro = project.add_macro("Tasks Demo Macro")

# Prepare connections used by tasks
csv = connections.DelimitedConnection(path="/My Files/Datastar/Customers.csv")
sandbox = project.get_sandbox()

# Add an Import task (CSV to sandbox)
import_task = macro.add_import_task(
    name="import_customers",
    source_connection=csv,
    destination_connection=sandbox,
    destination_table="customers_demo",
)

# Add a Run SQL task (operate on sandbox table)
sql_task = macro.add_run_sql_task(
    name="clean_cities",
    query="delete from customers_demo where city = 'london'",
    connection=sandbox,
)

# TODO: Export task not working in backend

# Add an Export task (sandbox table to a file)
# export_task = macro.add_export_task(
#    name="export_customers",
#    source_connection=sandbox,
#    source_table="customers_demo",
#    file_name="customers_out.csv",
# )

# List and fetch tasks
task_names = macro.get_tasks()
print(task_names)
assert "import_customers" in task_names
assert macro.get_task("clean_cities") is not None

# Update a task then persist changes
sql_task.description = "Remove London rows"
sql_task.name = "cleanup_cities"
sql_task.save()  # save updates existing tasks

# Add/remove dependencies by name
# export_task.add_dependency("cleanup_cities")
# deps = export_task.get_dependencies()
# assert "cleanup_cities" in deps
# export_task.remove_dependency("cleanup_cities")

# Create a task without persisting, then add via helper
preconfigured = tasks.RunPythonTask(
    macro,
    filename="script.py",
    directory_path="/My Files/Scripts",
    persist=False,
)
macro.add_task(preconfigured)

# Start a macro run and wait for completion
run_id = macro.run()
macro.wait_for_done(run_id, verbose=True)

# Cleanup
csv.delete()
project.delete()

print("Done")
