import subprocess
import re
from pathlib import Path
from tqdm import tqdm
from .utils import get_video_resolution

def parse_duration(stderr: str) -> float:
    """
    从 ffmpeg 的 stderr 中提取视频总时长（秒）
    示例匹配: Duration: 00:01:23.45
    """
    match = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", stderr)
    if match:
        h, m, s = map(float, match.groups())
        return h * 3600 + m * 60 + s
    return 0.0

def parse_time(line: str) -> float:
    """
    从 ffmpeg 的 stderr 中提取当前处理时间（秒）
    示例匹配: time=00:00:12.34
    """
    match = re.search(r"time=(\d+):(\d+):(\d+\.\d+)", line)
    if match:
        h, m, s = map(float, match.groups())
        return h * 3600 + m * 60 + s
    return 0.0

def compress_video(input_path: Path, output_path: Path, crf: int, target_res: tuple = None,
                   verbose: bool = False, use_fast: bool = False, use_gpu: bool = False):
    """
    使用 ffmpeg 压缩视频文件，支持分辨率缩放、GPU 编码、进度条显示
    """
    width, height = get_video_resolution(input_path)
    scale_args = []

    # 如果目标分辨率比原视频小，则添加缩放参数
    if target_res:
        target_w, target_h = target_res
        if width > target_w or height > target_h:
            scale_args = ["-vf", f"scale={target_w}:{target_h}"]

    preset = "fast" if use_fast else "medium"
    vcodec = "h264_nvenc" if use_gpu else "libx264"

    cmd = [
        "ffmpeg", "-y", "-i", str(input_path),
        "-vcodec", vcodec,
        "-crf", str(crf),
        "-preset", preset
    ] + scale_args + [str(output_path)]

    # 启动子进程并捕获 stderr，用于解析进度
    process = subprocess.Popen(
        cmd,
        stderr=subprocess.PIPE,
        text=True,
        encoding='utf-8',
        errors='replace'
    )

    duration = 0.0
    progress_bar = None

    try:
        for line in process.stderr:
            if verbose:
                print(line.strip())

            if duration == 0.0:
                duration = parse_duration(line)
                if duration > 0:
                    progress_bar = tqdm(total=duration, desc=f"压缩中: {input_path.name}", unit="秒", leave=False)

            if progress_bar:
                current_time = parse_time(line)
                if current_time > 0:
                    progress_bar.n = min(current_time, duration)
                    progress_bar.refresh()
        process.wait()
    finally:
        if progress_bar:
            progress_bar.n = duration
            progress_bar.refresh()
            progress_bar.close()

def process_video(file: Path, crf: int, target_res: tuple = None,
                  output_root: Path = None, verbose: bool = False, use_fast: bool = False,
                  use_gpu: bool = False, dry_run: bool = False, overwrite: bool = False,
                  original_handling: str = "none", original_target: Path = None):
    """
    单个视频处理流程：
    - 压缩视频（保留原名）
    - 根据策略处理原始文件（改名、移动）
    - 自动防止 mp4 → mp4 覆盖风险
    """
    stem = file.stem
    output_dir = output_root if output_root else file.parent
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{stem}.mp4"

    # ✅ 检查是否存在覆盖风险（原始文件是 mp4 且输出路径相同）
    temp_renamed = None
    if file.suffix.lower() == ".mp4" and file.resolve() == output_path.resolve():
        temp_renamed = file.with_name(f"_pending_original_{file.name}")
        file.rename(temp_renamed)
        file = temp_renamed
        print(f"⚠️ 原始文件临时改名为: {file.name}，防止覆盖")

    if output_path.exists() and not overwrite:
        print(f"已存在: {output_path.name}，跳过")
        return

    if dry_run:
        print(f"[DRY-RUN] 将处理: {file.name} → {output_path.name}")
        return

    compress_video(file, output_path, crf, target_res, verbose, use_fast, use_gpu)

    # ✅ 压缩完成后恢复原名（如果之前临时改名）
    if temp_renamed:
        original_path = file.with_name(file.name.replace("_pending_original_", ""))
        file.rename(original_path)
        file = original_path

    # ✅ 压缩完成后处理原始文件
    try:
        if original_handling == "rename":
            renamed = file.with_name(f"_original_{file.name}")
            file.rename(renamed)
            print(f"原始文件已改名为: {renamed.name}")

        elif original_handling == "move_local":
            local_dir = file.parent / "compressed"
            local_dir.mkdir(exist_ok=True)
            target_path = local_dir / file.name
            file.rename(target_path)
            print(f"原始文件已移动到: {target_path}")

        elif original_handling == "move_to" and original_target:
            original_target.mkdir(parents=True, exist_ok=True)
            target_path = original_target / file.name
            file.rename(target_path)
            print(f"原始文件已移动到: {target_path}")

    except Exception as e:
        print(f"⚠️ 原始文件处理失败: {e}")
