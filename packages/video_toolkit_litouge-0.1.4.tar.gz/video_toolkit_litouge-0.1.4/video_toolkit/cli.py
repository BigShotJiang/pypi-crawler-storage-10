import sys
import io

# ✅ 强制 stdout 和 stderr 使用 UTF-8 编码，避免 GBK 解码错误
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

import argparse
from pathlib import Path
from tqdm import tqdm
from .utils import find_large_videos, parse_resolution
from .compressor import process_video

def main():
    parser = argparse.ArgumentParser(description="批量压缩视频素材（支持 .mov 转码）")
    parser.add_argument("-d", "--directory", required=True, help="要处理的根目录路径")
    parser.add_argument("-s", "--size", type=int, default=100, help="大小阈值（MB），超过才处理")
    parser.add_argument("-c", "--crf", type=int, default=26, help="压缩质量（CRF），越高压缩越狠")
    # parser.add_argument("-p", "--prefix", default="_compressed_", help="（已废弃）压缩后文件名前缀，不再使用")
    parser.add_argument("-r", "--resolution", help="目标分辨率（如 1920x1080）")
    parser.add_argument("-o", "--output-dir", help="压缩文件输出目录（默认保存在源目录）")
    parser.add_argument("-v", "--verbose", action="store_true", help="显示 ffmpeg 输出信息（调试用）")
    parser.add_argument("-f", "--fast", action="store_true", help="使用快速压缩模式（preset=fast）")
    parser.add_argument("-g", "--gpu", action="store_true", help="使用 GPU 编码（h264_nvenc）")
    parser.add_argument("-n", "--dry-run", action="store_true", help="仅打印将处理的文件，不执行压缩")
    parser.add_argument("-w", "--overwrite", action="store_true", help="强制覆盖已存在的压缩文件")

    # ✅ 新增参数：原始视频处理策略
    parser.add_argument("--handle-original", choices=["none", "rename", "move_local", "move_to"], default="move_local",
                        help="压缩后如何处理原始文件：改名、移动到本地 compressed 目录，或移动到指定目录")
    parser.add_argument("--original-target", help="原始文件移动目标目录（用于 move_to 模式）")

    args = parser.parse_args()

    root = Path(args.directory).resolve()
    if not root.exists():
        print(f"❌ 目录不存在: {root}")
        return

    target_res = parse_resolution(args.resolution)
    output_root = Path(args.output_dir).resolve() if args.output_dir else None
    original_target = Path(args.original_target).resolve() if args.original_target else None

    videos = list(find_large_videos(root, args.size))
    total = len(videos)

    pbar = tqdm(total=total, unit="file", disable=True)
    try:
        for idx, video in enumerate(videos, start=1):
            tqdm.write(f'正在处理 "{video.name}" ({idx}/{total})...')
            try:
                process_video(
                    file=video,
                    crf=args.crf,
                    target_res=target_res,
                    output_root=output_root,
                    verbose=args.verbose,
                    use_fast=args.fast,
                    use_gpu=args.gpu,
                    dry_run=args.dry_run,
                    overwrite=args.overwrite,
                    original_handling=args.handle_original,
                    original_target=original_target
                )
            except Exception as e:
                safe_err = str(e).encode('utf-8', errors='replace').decode('utf-8', errors='replace')
                tqdm.write(f"❌ 处理失败: {video.name}，错误: {safe_err}")
            pbar.update(1)
    except KeyboardInterrupt:
        tqdm.write("\n🛑 用户中止了操作，已安全退出。")
    finally:
        pbar.close()

if __name__ == "__main__":
    main()
