Changes
=======

1.3.3 (2025-10-28)
------------------

- Pin upper versions of dependencies.
  [rnix]


1.3.2 (2022-12-05)
------------------

- Release wheel.
  [rnix]

- Remove empty doctest.
  [rnix]


1.3.1 (2017-11-13)
------------------

- Use ``bs_field_class`` callback for ``field.class`` property when registering
  ``array`` macro.
  [rnix]


1.3 (2017-03-01)
----------------

- Use ``yafowil.utils.entry_point`` decorator.
  [rnix]

- Cleanup macro registration.
  [rnix]


1.2 (2015-01-23)
----------------

- Use ``configure`` entry point for theme configuration.
  [rnix]

- Rename resource group ``bootstrap`` to ``bootstrap.dependencies``.
  [rnix]

- Remove bootstrap macros for yafowil and set factory defaults for common
  widgets where appropriate.
  [rnix]

- Update to bootstrap 3.2.
  [rnix]


1.1
---

- Register the bootstrap.js javascript too.
  [thet]


1.0
---

- make it work
  [rnix, jensens, thet, et al.]
