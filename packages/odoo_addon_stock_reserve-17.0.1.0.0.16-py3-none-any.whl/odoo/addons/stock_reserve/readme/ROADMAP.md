- Review multicompany. Take a look of
  \[this\](<https://github.com/OCA/stock-logistics-warehouse/pull/1346>)
  PR
