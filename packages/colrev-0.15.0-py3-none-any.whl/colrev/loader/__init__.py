"""Loaders for different data formats, including BibTex, RIS, CSV/Excel files"""

__author__ = """Gerit Wagner"""
__email__ = "gerit.wagner@uni-bamberg.de"
