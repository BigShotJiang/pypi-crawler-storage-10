# {{project_title}}

This repository is based on the [ColRev](https://github.com/CoLRev-Environment/colrev) standard.

```
# To work on this project, run
colrev clone URL

# Or to use it as a source in another project, run
colrev search -a colrev.colrev_project:"url=URL"
```
