# pylint: disable=missing-module-docstring
from importlib.metadata import version

__version__ = version("colrev")
