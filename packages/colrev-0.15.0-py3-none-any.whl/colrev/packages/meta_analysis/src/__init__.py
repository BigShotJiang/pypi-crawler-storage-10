"""Package for meta-analysis."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
