"""Package for colrev_cli_prescreen."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
