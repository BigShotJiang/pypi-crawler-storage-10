"""Package for colrev.prospero."""

__author__ = "Ammar Al-Balkhi, Phuc Tran, Olha Komashevska"
__email__ = [
    "ammar.al-balkhi@stud.uni-bamberg.de"
    "tra-thien-phuc.tran@stud.uni-bamberg.de"
    "olha.komashevska@stud.uni-bamberg.de"
]
