## Summary

## data

This package publishes the review to GitHub pages.

In the repository settings (on GitHub), the [deployment option](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) "from branch" (branch-name: ``gh-pages``) must be selected.

## Links

- Example: [literature-search-resources](https://github.com/digital-work-lab/literature-search-resources) and the [GitHub page of literature-search-resources](https://digital-work-lab.github.io/literature-search-resources/)
- [GitHub pages](https://pages.github.com/)
