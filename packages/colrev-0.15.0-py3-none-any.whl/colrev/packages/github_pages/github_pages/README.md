# {{project_title}}

These are the GitHub pages for a repository based on the [ColRev](https://github.com/CoLRev-Environment/colrev) standard.
