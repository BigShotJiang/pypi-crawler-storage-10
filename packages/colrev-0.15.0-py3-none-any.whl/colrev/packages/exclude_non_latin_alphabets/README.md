## Summary

## prep

This package excludes papers with titles which do not have a latin alphabet.
