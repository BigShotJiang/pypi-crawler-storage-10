"""Package for exclude_non_latin_alphabets."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
