"""Package for pdf_backward_search."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
