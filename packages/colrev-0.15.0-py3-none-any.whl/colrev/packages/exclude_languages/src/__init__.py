"""Package for exclude_languages."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
