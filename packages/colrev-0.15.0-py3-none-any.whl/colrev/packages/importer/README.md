# colrev.importer

Package facilitating the import of literature review data from other projects

## Installation

```bash
colrev install colrev.importer
```

## Usage

Run

```bash
colrev-importer
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
