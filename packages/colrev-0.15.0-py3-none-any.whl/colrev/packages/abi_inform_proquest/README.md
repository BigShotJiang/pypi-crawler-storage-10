## Summary

## search

### DB search

[ABI/INFORM ProQuest](https://about.proquest.com/en/products-services/abi_inform_complete/)

## Links

- [ProQuest](https://www.proquest.com/)
- [Coverage](https://tls.search.proquest.com/titlelist/jsp/list/tlsSingle.jsp?productId=10000008&_ga=2.251511554.52407821.1697371383-820984782.1697371383)
