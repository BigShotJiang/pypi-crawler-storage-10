"""Package for abi_inform_proquest."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
