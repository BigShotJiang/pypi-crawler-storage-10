## Summary

## search

### DB search

Download search results and store in `data/search/` directory. API-access not yet available.

## Links

- [JSTOR](https://www.jstor.org/)
