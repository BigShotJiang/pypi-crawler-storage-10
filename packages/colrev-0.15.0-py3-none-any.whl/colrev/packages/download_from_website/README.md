## Summary

This package supports retrieval of PDF documents from the individual websites.

Currently, the following websites are supported:

- jmir.org

## pdf-get

The download_from_website package is activated by default.
