"""Package for download_from_website."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
