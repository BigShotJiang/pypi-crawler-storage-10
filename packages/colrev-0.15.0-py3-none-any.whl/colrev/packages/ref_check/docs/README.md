## Summary

## Installation

```bash
colrev install colrev.ref_check
```

## Usage

`colrev.ref_check` can be added as a data endpoint. It ensures that records are only set to `rev_synthesized` if there are no remaining defects in the record metadata.
