"""Package for exclude_complementary_materials."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
