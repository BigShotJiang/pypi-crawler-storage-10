## Summary

## data

This package automatically generates a PRISMA flow chart based on the current state of the review.

## Links

- [PRISMA2020 app](https://estech.shinyapps.io/prisma_flowdiagram/)
- [PRISMA2020 repository](https://github.com/prisma-flowdiagram/PRISMA2020)
- [PRISMA2020 paper](https://onlinelibrary.wiley.com/doi/full/10.1002/cl2.1230)
- [Docker image](https://github.com/CoLRev-Environment/docker-prisma)
