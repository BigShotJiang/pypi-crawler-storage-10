
![PRISMA flow diagram](output/PRISMA.png){#fig:prisma width=600px}


The PRISMA flow diagram is displayed in @fig:prisma. It is based on the latest PRISMA standard [@PageMcKenzieBossuytEtAl2021] and was created with PRISMA2020 [@HaddawayPagePritchardEtAl2022].
