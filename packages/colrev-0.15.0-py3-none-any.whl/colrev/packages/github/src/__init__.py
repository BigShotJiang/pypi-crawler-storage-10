"""Package for github_search."""

__author__ = "Philipp Kasimir "
__email__ = "philipp-william.kasimir@stud.uni-bamberg.de"

__author__ = "Kolja Rinne"
__email__ = "kolja.rinne@stud.uni-bamberg.de"

__author__ = "Karl Schickmann"
__email__ = "karl.schnickmann@stud.uni-bamberg.de"


__author__ = "Chris Vierath"
__email__ = "chris-norman.vierath@stud.uni-bamberg.de"
