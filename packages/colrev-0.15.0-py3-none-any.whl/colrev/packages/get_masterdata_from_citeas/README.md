## Summary

## prep

This package retrieves metadata from [citeas](https://citeas.org/).


## Link

- [citeas.org](https://citeas.org/)
