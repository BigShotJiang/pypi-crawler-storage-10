"""Package for pdf_get_man_cli."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
