## Summary

## screen

The cli screen asks for user input, indicating for each paper whether it should be included or not. At the beginning, screening criteria can be defined.

<!--
## Links
-->
