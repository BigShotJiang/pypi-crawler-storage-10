"""Package for screen_cli."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
