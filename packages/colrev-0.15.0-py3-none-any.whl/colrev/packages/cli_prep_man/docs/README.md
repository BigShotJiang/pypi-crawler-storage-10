## Summary

Standalone call:

```
colrev_cli_prep_man
```
