# colrev.cli_prep_man

CLI package for manual meta-data preparation

## Installation

```bash
colrev install colrev.cli_prep_man
```

## Usage

```bash
colrev_cli_prep_man
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
