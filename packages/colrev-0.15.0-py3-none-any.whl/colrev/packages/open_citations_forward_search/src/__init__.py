"""Package for open_citations_forward_search."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
