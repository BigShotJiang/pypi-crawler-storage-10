## Summary

## search

### FORWARD search

```
colrev search --add colrev.open_citations_forward_search
```

## Links

- [OpenCitations](https://opencitations.net/)
