"""Package for doi_metadata_prep."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
