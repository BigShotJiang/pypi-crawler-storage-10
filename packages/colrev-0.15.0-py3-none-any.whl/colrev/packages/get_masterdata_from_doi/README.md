## Summary

## prep

This package retrieves meta data from doi.org.

<!--
## Links
-->
