"""Package for remove_last_page."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
