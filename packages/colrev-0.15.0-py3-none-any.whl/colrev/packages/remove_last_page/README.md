## Summary

This package removes pages appended by publishers or registries.

Examples are:

- CAIS
- ME Sharpe

## pdf-prep

This package is included in many default setups.
