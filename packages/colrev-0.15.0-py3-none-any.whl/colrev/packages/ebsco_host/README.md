## Summary

## search

### DB search

Export is available after adding citations to a folder ([1](https://connect.ebsco.com/s/article/How-to-Use-the-Export-Manager?language=en_US)).
Download search results and store in `data/search/` directory. API-access not yet available.

## Links

- [EBSCOHost](https://search.ebscohost.com/)
- [EBSCOHost APIs](https://developer.ebsco.com/getting-started/available-apis)
