"""Package for grobid_tei."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
