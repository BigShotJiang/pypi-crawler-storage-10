## Summary

The Open Library is a curated collection of metadata and books with a size of over 20,000,000. It provides a wide range of resources for users to explore.

## search

Searches of the OpenLibrary are not (yet) supported.

## prep

OpenLibrary linking

## Links

- [OpenLibrary](https://openlibrary.org/)
