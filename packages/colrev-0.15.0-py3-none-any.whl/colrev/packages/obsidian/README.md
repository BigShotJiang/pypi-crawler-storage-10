## Summary

## data

This package imports included records into an obsidian vault, which is useful for emergent qualitative data analysis.

## Links

- [obsidian](https://obsidian.md/)
