## Summary

## search

### DB search

Download search results and store in `data/search/` directory. No API-access available.

To retrieve search results, Publish or Perish is recommended.

## Links

- [GoogleScholar](https://scholar.google.de/)
- [Publish or Perish](https://harzing.com/resources/publish-or-perish) supports the retrieval of data from GoogleScholar.
