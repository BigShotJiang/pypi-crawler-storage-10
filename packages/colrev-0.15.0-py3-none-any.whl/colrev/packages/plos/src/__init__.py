"""Package for colrev.plos."""

__author__ = "olgagirona"
__email__ = "olga.girona-cutillas@stud.uni-bamberg.de"
