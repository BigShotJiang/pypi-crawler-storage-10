## Summary

## prep

This package adds missing ``year`` fields if the ``journal``, ``volume``, and ``number`` fields are set. Based on crossref.

<!-- ## Links -->
