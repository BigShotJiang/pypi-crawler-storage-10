"""Package for year_vol_iss_prep."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
