## Summary

## search

### DB search

Download search results and store in `data/search/` directory. No API-access available.

## Links

- [PsycInfo](https://www.apa.org/pubs/databases/psycinfo)
