"""Package for europe_pmc."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
