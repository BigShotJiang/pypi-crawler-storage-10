"""Package for gena."""

__author__ = "Julian Prester, Gerit Wagner"
__email__ = "julian.prester@sydney.edu.au, gerit.wagner@uni-bamberg.de"
