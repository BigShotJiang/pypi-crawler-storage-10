"""Package for remove_broken_ids."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
