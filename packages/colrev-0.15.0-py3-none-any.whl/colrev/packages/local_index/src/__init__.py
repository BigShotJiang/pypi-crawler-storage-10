"""Package for local_index."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
