"""Package for get_doi_from_urls."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
