"""Package for prescreen_table."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
