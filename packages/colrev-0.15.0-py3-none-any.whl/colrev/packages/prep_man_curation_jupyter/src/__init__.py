"""Package for curation_jupyter_prep_man."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
