## Summary

The *blank* ReviewType does not include any settings. It is primarily used for simulations.
