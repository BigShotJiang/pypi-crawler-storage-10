"""Package for remove_urls_with_500_errors."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
