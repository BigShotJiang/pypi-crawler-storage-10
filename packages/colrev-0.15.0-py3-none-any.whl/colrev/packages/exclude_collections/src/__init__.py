"""Package for exclude_collections."""

__author__ = "Gerit Wagner"
__email__ = "gerit.wagner@uni-bamberg.de"
