# Pylint plugin

```
pylint colrev/records.py

```

- [How to write a pylint plugin](https://pylint.readthedocs.io/en/latest/development_guide/how_tos/plugins.html)
- [Custom pylint checkers](https://github.com/oppia/oppia/wiki/Custom-Pylint-checks)
