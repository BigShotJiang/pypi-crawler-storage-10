# Architecture of CoLRev Core

![Overview of the colrev architecture](../docs/figures/architecture.svg)
