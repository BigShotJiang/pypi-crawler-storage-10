from setuptools import setup
from setuptools import find_packages

with open('README.md', 'r') as f:
    readme = f.read()

setup(
    name="kanji-to-number",
    version="0.2.1",
    py_modules=["kanji_to_number"],
    install_requires=[],

    # metadata to display on PyPI
    author="Shinya Akagi",
    description="Convert kansuji to number",
    long_description=readme,
    long_description_content_type='text/markdown',
    url="https://github.com/ShinyaAkagiI/kanji_to_number", 
    license="PSF",
)
