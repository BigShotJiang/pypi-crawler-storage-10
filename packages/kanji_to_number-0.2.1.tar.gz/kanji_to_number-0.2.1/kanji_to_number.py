# 漢数字を数字に変換する関数
# ※形態素解析を使用していないため、名前などに含まれる数字も強制的に変換される
KANJI_NUMBERS = {
    '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9,
    '十': 10, '百': 100, '千': 1000, '万': 10000, '億': 100000000
}

def kanji_to_number(kanji):
	result = 0
	temp = 0
	unit = 1
	renzoku = False

	for char in reversed(kanji):
		if char in KANJI_NUMBERS:
			num = KANJI_NUMBERS[char]
			if num >= 10 and renzoku == False:
				unit = num
				renzoku = True
			elif num >= 10 and renzoku == True:
				temp += 1 * unit
				unit = num
				renzoku = True
			else:
				temp += num * unit
				renzoku = False
		else:
			result += temp
			temp = 0
			unit = 1
	if renzoku == True:
		result += temp + 1 * unit
	else:
		result += temp

	return result

def kanji_to_number_in_text(kanji):
	kansuji_and_char = []
	flag = False
	tmp = ""
	result = []

	for char in kanji:
		if char in KANJI_NUMBERS:
			if flag:
				kansuji_and_char[-1] += char
			else:
				kansuji_and_char.append(char)
				flag = True
		else:
			kansuji_and_char.append(char)
			flag = False

	for char in kansuji_and_char:
		if char[0] in KANJI_NUMBERS:
			result.append(str(kanji_to_number(char)))
		else:
			result.append(char)

	return "".join(result)
