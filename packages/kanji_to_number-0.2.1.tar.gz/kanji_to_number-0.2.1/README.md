# 概要

漢数字を数字に変換するツールです。  
形態素解析を使用しておらず、名前などに含まれる漢数字を強制的に変換してしまうため、使用する際は注意してください。  


# セットアップ

```
pip install kanji-to-number
```


# アンインストール

```
pip uninstall kanji-to-number
```

# 使い方

```
from kanji_to_number import kanji_to_number_in_text

data = kanji_to_number_in_text("一億人、第百十五条、二百零号室")

print(data) # 100000000人、第115条、200号室 
```

# ライセンス

- kanji_to_number
	- Python Software Foundation License  
	- Copyright (C) 2025 Shinya Akagi

