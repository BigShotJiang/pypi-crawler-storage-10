## cdf 

### Removed

- [alpha] Removed the command `cdf populate`. Instead set the alpha flag
`v07 = true` and use the `cdf data upload instances` instead.
 
## templates

No changes.