// Shim for extensions/core/maskEditorLayerFilenames.ts
console.warn('[ComfyUI Notice] "extensions/core/maskEditorLayerFilenames.js" is an internal module, not part of the public API. Future updates may break this import.');
export const imageLayerFilenamesByTimestamp = window.comfyAPI.maskEditorLayerFilenames.imageLayerFilenamesByTimestamp;
export const imageLayerFilenamesIfApplicable = window.comfyAPI.maskEditorLayerFilenames.imageLayerFilenamesIfApplicable;
