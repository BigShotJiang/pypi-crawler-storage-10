"""Test package for market data pipeline."""
