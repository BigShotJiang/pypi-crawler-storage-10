'''

Copyright 2025 Arjun Singh

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

'''
# Authorization Errors:
class AuthError(Exception):
    """General error for a failed authentication"""
    pass
class UsernameNotFound(AuthError):
    """Error when a specified username isn't found"""
    pass
class IncorrectPassword(AuthError):
    """ A specific exception class to be raised when an incorrect password is supplied. For a rather more 
   general password error, use BadPassword exception class."""
    pass
class BadAdminRequest(AuthError):
    """ When a person tries to login as an Admin to your program, and he/she fails to do so, then use this exception class."""
    pass
class BadDatabaseConnection(AuthError):
    """ Exception class when a connection to a database is unstable. """
    pass
class IncorrectRecoveryCode(AuthError):
    """ Exception class for a wrong recovery code provided during a 2FA authentication procedure. """
class Failed2FAAuthentication(AuthError):
    """ Error for a failed 2FA authentication procedure. """
# End
# Miscellaneous Errors:
class BadPassword(Exception):
    pass
class BadUsername(Exception):
    pass
class PasswordTooShort(BadPassword):
    """ Error for a too short password. Use Case: Suppose you require a password which has a length atleast
    8 characters. If the user types a shorter password, then use this."""
    pass
class NotUniqueUsername(BadUsername):
    pass
class NotUniquePassword(BadPassword):
    pass
class BadType(TypeError):
    pass
class InappropriateUsername(BadUsername):
    """Use this if your program doesn't allow specific characters in the username."""
    pass
class InappropriatePassword(BadPassword):
    """Use this if your program doesn't allow specific characters in the password."""
    pass
class CorruptFile(Exception):
    """ Error when a user tries to open a corrupt file or a file which doesn't support the desired encoding. """
    pass
class InputError(Exception):
    pass
class BadPrompt(InputError):
    pass
class DataNotFoundError(BaseException):
    pass
class InvalidStateError(BaseException):
    pass
class ConfigException(FileNotFoundError):
    pass
class UnavailableResourceError(ConnectionError):
    pass
class ServiceNotAvailable(ConnectionRefusedError):
    pass
class ProcessingError(BaseException):
    pass
class TimeOutException(TimeoutError):
    pass
class NetworkError(ProcessingError):
    pass
class APIException(ProcessingError):
    pass
class InternalServerError(RuntimeError):
    pass
class MemoryExhaustedError(SystemError):
    pass
class ResourcesExhaustedError(SystemError):
    pass
class SpaceUnavailableError(SystemError):
    pass
class RetryLimitExceededError(AuthError):
    pass
class ConcurrencyException(SystemError):
    pass
class DependencyError(SystemError):
    pass
class InsufficientFundsError(BaseException):
    pass
class InventoryError(BaseException):
    pass
class LogicError(BaseException):
    pass



