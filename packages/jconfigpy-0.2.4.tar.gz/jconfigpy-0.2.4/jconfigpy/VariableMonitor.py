from os import path
import io


class Monitor:

    _SINGLE_OBJECT = None
    _FILE_WRITE_FORMAT = 'CONFIG_{var}={val}\n'

    def __new__(cls):
        if cls._SINGLE_OBJECT is None:
            cls._SINGLE_OBJECT = super(Monitor, cls).__new__(cls)
        return cls._SINGLE_OBJECT

    def __init__(self):
        # Only initialize once
        if not hasattr(self, '_initialized'):
            self._var_map = {}
            self._sub_map = {}
            self._initialized = True

    def notify_variable_change(self, var, update_val):
        if var not in self._var_map:
            self._var_map.update({var: update_val})
        else:
            self._var_map[var] = update_val
        if var in self._sub_map:
            for subsc in self._sub_map[var]:
                subsc.on_update_var(var, update_val)

    def lookup_variable(self, var):
        if var not in self._var_map:
            return None
        return self._var_map[var]

    def check_depend(self, **kwargs):
        for key, val in kwargs.items():
            cval = self._var_map.get(key, None)
            if cval is None or cval != val:
                return False
        return True

    def subscribe_variable_change(self, var, config_item):
        try:
            sub_list = self._sub_map[var]
        except KeyError:
            self._sub_map.update({var: []})
            sub_list = self._sub_map[var]
        sub_list.append(config_item)

    def unsubscribe_variable_change(self, var, config_item):
        if var not in self._sub_map:
            return
        try:
            self._sub_map[var].remove(config_item)
        except ValueError:
            # Item not in list, silently ignore
            pass

    def resolve_path(self, pth):
        if '$' not in pth:
            return pth
        head, tail = path.split(pth)
        while tail != '':
            if '$' in tail:
                key = tail.split('$')[-1]
                if key in self._var_map:
                    pth = pth.replace(tail, self._var_map[key])
            head, tail = path.split(head)
        return pth

    def get_update(self, var_map):
        if not isinstance(var_map, dict):
            return
        var_map.update(self._var_map)

    def write(self, fp, key=None):
        # Support both io.IOBase and file-like objects
        if not hasattr(fp, 'write'):
            raise TypeError('fp must be a file-like object with write() method')
        if key is not None and key in self._var_map:
            fp.write(Monitor._FILE_WRITE_FORMAT.format(var=key, val=self._var_map[key]))
            return
        for key in self._var_map:
            fp.write(Monitor._FILE_WRITE_FORMAT.format(var=key, val=self._var_map[key]))
