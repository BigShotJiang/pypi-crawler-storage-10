# final.py
import atexit
import inspect
import traceback
import textwrap
from collections import deque

class _Final:
    _queue = deque()  # FIFO 큐 (블록 코드 저장용)

    def __enter__(self):
        # 현재 실행 프레임 저장
        self._frame = inspect.currentframe().f_back
        return None  # 내부 사용 안 함

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            frame = self._frame
            filename = frame.f_code.co_filename
            lineno = frame.f_lineno

            # 소스 파일 전체 읽기
            with open(filename, "r", encoding="utf-8") as f:
                all_lines = f.readlines()

            # with Final: 블록 찾기
            start_line = lineno
            indent_level = None
            block_lines = []

            for line in all_lines[start_line:]:
                if not line.strip():
                    continue
                spaces = len(line) - len(line.lstrip())
                if indent_level is None:
                    indent_level = spaces
                    continue  # 'with Final:' 라인 스킵
                if spaces < indent_level:
                    break  # 블록 끝
                block_lines.append(line[indent_level:])

            block_code = "".join(block_lines)
            if not block_code.strip():
                return

            # 큐에 블록 코드 등록
            self._queue.append((block_code, frame.f_globals, frame.f_locals))

        except Exception:
            traceback.print_exc()

        # 블록 내부 즉시 실행 방지
        return True

    @classmethod
    def _run_all(cls):
        """프로세스 종료 시 FIFO 순서대로 실행"""
        while cls._queue:
            block_code, g, l = cls._queue.popleft()
            try:
                exec(block_code, g, l)
            except Exception:
                traceback.print_exc()

# atexit 시점에 등록 (큐 FIFO 순서로 실행)
atexit.register(_Final._run_all)

Final = _Final()
