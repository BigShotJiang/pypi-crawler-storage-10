"""hopeit_agents MCP client plugin."""
