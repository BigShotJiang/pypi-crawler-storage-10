"""Expose the public MCP client as hopeit endpoints surface."""
