# hopeit_agents MCP Client

Library that connects to HTTP MCP servers and exposes MCP endpoints as hopeit.engine HTTP endpoints for non-MCP integrations.

Check details at [hopeit.agents README](https://github.com/hopeit-git/hopeit.agents/blob/master/README.md).
