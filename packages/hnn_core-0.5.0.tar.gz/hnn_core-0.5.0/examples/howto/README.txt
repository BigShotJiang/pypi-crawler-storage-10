How to
------

These are short examples that show how to use HNN-core API to accomplish specific
tasks.
