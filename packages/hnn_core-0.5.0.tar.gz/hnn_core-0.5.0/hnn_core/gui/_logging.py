import logging

_logger_name = "hnn_gui"
logger = logging.getLogger(_logger_name)
logger.setLevel(logging.INFO)
