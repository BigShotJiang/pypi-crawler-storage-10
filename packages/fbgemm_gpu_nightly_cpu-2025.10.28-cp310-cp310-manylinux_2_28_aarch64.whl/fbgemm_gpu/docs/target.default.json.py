
{
    "version": "2025.10.28",
    "target": "default",
    "variant": "cpu"
}
