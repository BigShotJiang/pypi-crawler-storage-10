# Quick Start Guide

## For Package Maintainer

### 1. First Time Setup

```bash
# Navigate to project directory
cd C:\Users\arudani\cstuff\addsjson\mcp

# Update your information in pyproject.toml
# - Change author name and email
# - Update GitHub URLs
# - Choose a unique package name if needed

# Install build tools
pip install build twine
```

### 2. Build the Package

```bash
# Clean any previous builds
rm -rf dist/ build/ src/*.egg-info  # Linux/Mac
# Or manually delete dist/, build/ folders on Windows

# Build
python -m build
```

### 3. Test Locally (Optional)

```bash
# Install in a test environment
pip install -e .

# Try running it
python -m ad_mcp_server
```

### 4. Publish to PyPI

```bash
# First time: Create account at https://pypi.org and get API token

# Upload
python -m twine upload dist/*

# When prompted, use:
# Username: __token__
# Password: your-pypi-token-here
```

### 5. Verify

```bash
# Test installation
uvx ad-mcp-server@latest
```

## For End Users

### Installation

```bash
uvx ad-mcp-server@latest
```

### Configuration

1. **Locate config file:**
   - Windows: `%APPDATA%\Claude\claude_desktop_config.json`
   - macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - Linux: `~/.config/Claude/claude_desktop_config.json`

2. **Add this configuration:**

```json
{
  "mcpServers": {
    "active-directory": {
      "command": "uvx",
      "args": ["ad-mcp-server@latest"],
      "env": {
        "AD_JSON_PATH": "C:\\path\\to\\your\\ad.json"
      }
    }
  }
}
```

3. **Restart Claude Desktop**

### Usage

Ask Claude things like:
- "Search for user John Doe in Active Directory"
- "Get details for user jdoe"
- "Who are the members of Domain Admins group?"
- "List all groups with 'finance' in the name"
- "Show me AD statistics"

## Package Structure

```
ad-mcp-server/
├── src/
│   └── ad_mcp_server/
│       ├── __init__.py         # Package initialization
│       └── server.py           # Main MCP server code
├── pyproject.toml              # Package configuration
├── DISTRIBUTION_README.md      # Full documentation
├── PUBLISHING_GUIDE.md         # Detailed publishing steps
├── LICENSE                     # MIT License
├── MANIFEST.in                 # Package manifest
├── .gitignore                  # Git ignore rules
└── claude_desktop_config_example.json  # Config example
```

## Updating for New Releases

1. Update version in `pyproject.toml`
2. Clean old builds: `rm -rf dist/ build/`
3. Build: `python -m build`
4. Upload: `python -m twine upload dist/*`

## Troubleshooting

**"Could not find ad.json"**
- Set `AD_JSON_PATH` environment variable in config

**"Package name already exists"**
- Choose different name in `pyproject.toml`

**"Authentication failed"**
- Use API token, not password
- Format: `Username: __token__`, `Password: pypi-...`

## Need Help?

- Read [DISTRIBUTION_README.md](DISTRIBUTION_README.md) - Full documentation
- Read [PUBLISHING_GUIDE.md](PUBLISHING_GUIDE.md) - Detailed publishing steps
- PyPI Help: https://pypi.org/help/
