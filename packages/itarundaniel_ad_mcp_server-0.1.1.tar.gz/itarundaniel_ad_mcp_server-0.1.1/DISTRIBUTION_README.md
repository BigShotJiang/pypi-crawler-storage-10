# Active Directory MCP Server

An MCP (Model Context Protocol) server that enables AI assistants like Claude to query Active Directory data from JSON exports. Perfect for security investigations, user lookups, group membership analysis, and AD auditing.

## Features

- **Search AD Objects**: Find users, groups, computers, and OUs by name, email, or username
- **User Details**: Get comprehensive user information including group memberships, last logon, and account status
- **Group Management**: List groups and retrieve all members of specific groups
- **AD Statistics**: View domain overview and object type counts
- **Offline Queries**: Works with exported AD data (no live AD connection required)

## Prerequisites

- Python 3.10 or higher
- Active Directory data exported to JSON format (see [Exporting AD Data](#exporting-ad-data))
- Claude Desktop app or compatible MCP client

## Installation

### Option 1: Install from PyPI (Recommended)

Once published, users can install with:

```bash
uvx ad-mcp-server@latest
```

### Option 2: Install from GitHub

```bash
pip install git+https://github.com/yourusername/ad-mcp-server.git
```

### Option 3: Local Development

```bash
git clone https://github.com/yourusername/ad-mcp-server.git
cd ad-mcp-server
pip install -e .
```

## Configuration

### Claude Desktop

Add this to your `claude_desktop_config.json`:

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Linux**: `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "active-directory": {
      "command": "uvx",
      "args": ["ad-mcp-server@latest"],
      "env": {
        "AD_JSON_PATH": "/path/to/your/ad.json"
      }
    }
  }
}
```

### Alternative: Local Python Installation

If you prefer using a local Python installation:

```json
{
  "mcpServers": {
    "active-directory": {
      "command": "python",
      "args": ["-m", "ad_mcp_server"],
      "env": {
        "AD_JSON_PATH": "/path/to/your/ad.json"
      }
    }
  }
}
```

### Configuration Options

- **AD_JSON_PATH**: (Optional) Path to your ad.json file. If not set, the server looks in:
  1. Current working directory
  2. Same directory as the script
  3. Parent directories (up to 2 levels)

## Exporting AD Data

To use this MCP server, you need to export your Active Directory data to JSON format.

### Using PowerShell (Recommended)

Create an export script (`export-ad.ps1`):

```powershell
Import-Module ActiveDirectory

$domain = Get-ADDomain
$objects = Get-ADObject -Filter * -Properties *

$export = @{
    domain = $domain.DNSRoot
    base_dn = $domain.DistinguishedName
    extracted_at = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
    total_objects = $objects.Count
    root_objects = @()
}

# Convert AD objects to hierarchical structure
foreach ($obj in $objects) {
    $objData = @{
        dn = $obj.DistinguishedName
        attributes = @{}
        children = @()
    }

    # Add all properties
    $obj.PSObject.Properties | ForEach-Object {
        if ($null -ne $_.Value) {
            $objData.attributes[$_.Name] = $_.Value
        }
    }

    $export.root_objects += $objData
}

$export | ConvertTo-Json -Depth 10 | Out-File "ad.json" -Encoding UTF8
```

Run with:
```powershell
.\export-ad.ps1
```

**Note**: Ensure you have appropriate permissions to query Active Directory.

## Available Tools

Once configured, Claude can use these tools:

### 1. search_ad
Search for AD objects by name, email, username, etc.

**Example prompts:**
- "Search for users named John"
- "Find all computers starting with DESK"
- "Look up john.doe@company.com"

### 2. get_user_details
Get comprehensive information about a specific user.

**Example prompts:**
- "Get details for user jdoe"
- "Show me information about john.doe@company.com"
- "What groups is Jane Smith a member of?"

### 3. get_group_members
List all members of an AD group.

**Example prompts:**
- "Who are the members of Domain Admins?"
- "List everyone in the Finance group"

### 4. list_groups
List all AD groups, with optional filtering.

**Example prompts:**
- "List all groups"
- "Show me groups with 'admin' in the name"

### 5. get_ad_statistics
Get domain statistics and overview.

**Example prompts:**
- "Show me AD statistics"
- "How many users are in the directory?"

## Usage Examples

After installation and configuration, restart Claude Desktop and try:

```
You: "Search for users with the last name Smith"

Claude: [Uses search_ad tool to find all users named Smith]

You: "Get details for the first user"

Claude: [Uses get_user_details to show comprehensive user information]

You: "What groups is this user a member of?"

Claude: [Displays group memberships from the user details]
```

## Security Considerations

- **Data Privacy**: The AD JSON export contains sensitive organizational data. Store it securely.
- **Access Control**: Limit access to the JSON file using appropriate file system permissions
- **No Live Connection**: This server works with exported data only - it doesn't connect to live AD
- **Audit Trail**: Consider logging when and how AD data is accessed

## Publishing to PyPI

For maintainers who want to publish this package:

### 1. Prepare for Publishing

```bash
# Install build tools
pip install build twine

# Update version in pyproject.toml
# Update your author information in pyproject.toml
```

### 2. Build the Package

```bash
python -m build
```

This creates files in `dist/`:
- `ad_mcp_server-0.1.0-py3-none-any.whl`
- `ad_mcp_server-0.1.0.tar.gz`

### 3. Test on TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Test installation
uvx --index-url https://test.pypi.org/simple/ ad-mcp-server@latest
```

### 4. Publish to PyPI

```bash
python -m twine upload dist/*
```

### 5. Verify Installation

```bash
uvx ad-mcp-server@latest
```

## Troubleshooting

### "Could not find ad.json file"

Set the `AD_JSON_PATH` environment variable in your config:

```json
"env": {
  "AD_JSON_PATH": "C:\\path\\to\\ad.json"
}
```

### "Module not found: mcp"

Ensure dependencies are installed:

```bash
pip install mcp
```

### Claude Desktop doesn't show the tools

1. Ensure `claude_desktop_config.json` has correct syntax
2. Restart Claude Desktop completely
3. Check Claude Desktop logs for errors

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - See LICENSE file for details

## Support

- Report issues: https://github.com/yourusername/ad-mcp-server/issues
- Documentation: https://github.com/yourusername/ad-mcp-server

## Acknowledgments

- Built with [Model Context Protocol (MCP)](https://modelcontextprotocol.io/)
- Inspired by [AWS Labs MCP Servers](https://github.com/awslabs/mcp-servers)
