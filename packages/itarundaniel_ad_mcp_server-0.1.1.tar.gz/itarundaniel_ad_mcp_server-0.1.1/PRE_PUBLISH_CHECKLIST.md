# Pre-Publishing Checklist

Use this checklist before publishing your Active Directory MCP Server to PyPI.

## 📋 Required Steps

### 1. Update Package Metadata
- [ ] Open `pyproject.toml`
- [ ] Update `name` (line 6) - ensure it's unique on PyPI
  - Current: `"ad-mcp-server"`
  - Check availability: https://pypi.org/project/ad-mcp-server/
  - If taken, use: `"yourorg-ad-mcp-server"` or `"yourusername-ad-mcp-server"`
- [ ] Update `authors` (line 10-12)
  - Change `"Your Name"` to your actual name
  - Change `"your.email@example.com"` to your email
- [ ] Update `Homepage` URL (line 25)
  - Change to your GitHub repository URL
- [ ] Update `Repository` URL (line 27)
  - Change to your GitHub repository URL
- [ ] Update `Issues` URL (line 28)
  - Change to your GitHub issues URL

### 2. Create PyPI Account
- [ ] Create account at https://pypi.org/account/register/
- [ ] Verify email address
- [ ] Generate API token at https://pypi.org/manage/account/token/
- [ ] Save token securely (you'll need it for upload)

### 3. Optional: Create TestPyPI Account (Recommended)
- [ ] Create account at https://test.pypi.org/account/register/
- [ ] Generate API token
- [ ] Test publish there first

### 4. Install Build Tools
```bash
pip install build twine
```
- [ ] Run the command above
- [ ] Verify no errors

### 5. Test Locally (Recommended)
```bash
cd C:\Users\arudani\cstuff\addsjson\mcp
pip install -e .
python -m ad_mcp_server
```
- [ ] Run installation in development mode
- [ ] Test that server starts without errors
- [ ] Verify it finds ad.json file

## 🔧 Optional Customizations

### Update Documentation
- [ ] Review `DISTRIBUTION_README.md`
- [ ] Add organization-specific examples
- [ ] Update any company-specific information

### Update Examples
- [ ] Review `claude_desktop_config_example.json`
- [ ] Ensure paths match your environment

### Add More Details
- [ ] Update version in `pyproject.toml` if needed (default: 0.1.0)
- [ ] Add more keywords for better discoverability
- [ ] Enhance package description

## 🚀 Publishing Steps

### Test Build (Do This First!)
```bash
# Clean any previous builds
rm -rf dist/ build/ src/*.egg-info

# Build the package
python -m build
```

- [ ] Run build command
- [ ] Check that `dist/` directory contains:
  - [ ] `.whl` file (wheel package)
  - [ ] `.tar.gz` file (source distribution)
- [ ] Verify no errors in build output

### Test on TestPyPI (Highly Recommended)
```bash
python -m twine upload --repository testpypi dist/*
# Username: __token__
# Password: your-testpypi-token

# Test installation
uvx --index-url https://test.pypi.org/simple/ ad-mcp-server@latest
```

- [ ] Upload to TestPyPI
- [ ] Test installation from TestPyPI
- [ ] Verify it works correctly

### Publish to PyPI (Production)
```bash
python -m twine upload dist/*
# Username: __token__
# Password: your-pypi-token
```

- [ ] Upload to PyPI
- [ ] Wait a few minutes for indexing
- [ ] Verify package appears at https://pypi.org/project/ad-mcp-server/

### Verify Installation
```bash
uvx ad-mcp-server@latest
```

- [ ] Test installation from PyPI
- [ ] Verify server starts correctly
- [ ] Test with Claude Desktop

## 📖 Post-Publishing

### Update Configuration
- [ ] Update your own `claude_desktop_config.json` to use `uvx` method
- [ ] Test the new configuration
- [ ] Remove old hard-coded path configuration

### Documentation
- [ ] Create GitHub repository (if not exists)
- [ ] Push code to GitHub
- [ ] Create first release tag: `git tag v0.1.0 && git push --tags`
- [ ] Add README to GitHub repo (use DISTRIBUTION_README.md)

### Share with Team
- [ ] Send installation instructions to team
- [ ] Provide configuration example
- [ ] Document where to put ad.json file

## ⚠️ Common Issues & Solutions

### "Package name already taken"
**Solution:** Choose a different name in `pyproject.toml`:
```toml
name = "yourorg-ad-mcp-server"
```

### "Authentication failed"
**Solution:**
- Use `__token__` as username (not your PyPI username)
- Use API token as password (starts with `pypi-`)
- Generate new token if needed

### "File already exists"
**Solution:**
- Can't re-upload same version
- Increment version number in `pyproject.toml`
- Rebuild and re-upload

### "Module not found: mcp"
**Solution:**
```bash
pip install mcp
```

### Build fails
**Solution:**
```bash
pip install --upgrade build setuptools wheel
python -m build
```

## 🎯 Success Criteria

You're ready to publish when:

- [x] Package builds without errors
- [x] `pyproject.toml` has your information
- [x] Local test works (`pip install -e .`)
- [x] You have PyPI account and API token
- [ ] (Optional but recommended) TestPyPI test succeeded

## 📝 Version Management

For future updates:

1. **Bug fixes:** 0.1.0 → 0.1.1
2. **New features:** 0.1.0 → 0.2.0
3. **Breaking changes:** 0.1.0 → 1.0.0

Update version in `pyproject.toml`, rebuild, and re-upload.

## 🔐 Security Checklist

- [ ] API tokens stored securely (not in git)
- [ ] `ad.json` excluded from git (check `.gitignore`)
- [ ] No sensitive data in package
- [ ] `.env` files excluded
- [ ] Virtual environment excluded

## 📞 Need Help?

- **Build issues:** See [QUICK_START.md](QUICK_START.md)
- **Publishing issues:** See [PUBLISHING_GUIDE.md](PUBLISHING_GUIDE.md)
- **PyPI help:** https://pypi.org/help/
- **Packaging guide:** https://packaging.python.org/

---

## Quick Reference Commands

```bash
# Install tools
pip install build twine

# Build package
python -m build

# Test on TestPyPI
python -m twine upload --repository testpypi dist/*

# Publish to PyPI
python -m twine upload dist/*

# Test installation
uvx ad-mcp-server@latest
```

---

**Ready?** Check all boxes above, then run the publishing commands! 🚀
