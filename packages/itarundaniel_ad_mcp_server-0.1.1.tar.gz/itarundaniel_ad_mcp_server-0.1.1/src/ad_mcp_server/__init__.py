"""
Active Directory MCP Server
Provides tools to query Active Directory data from JSON exports
"""

__version__ = "0.1.0"

from .server import main

__all__ = ["main"]
