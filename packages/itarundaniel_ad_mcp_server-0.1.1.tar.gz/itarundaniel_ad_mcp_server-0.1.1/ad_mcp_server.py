#!/usr/bin/env python3
"""
Active Directory MCP Server
Provides tools to query Active Directory data from ad.json file
"""

import json
import asyncio
import os
from pathlib import Path
from typing import Any
from mcp.server.models import InitializationOptions
import mcp.types as types
from mcp.server import NotificationOptions, Server
import mcp.server.stdio

# Global variable to store AD data
ad_data = None

# Get the directory where this script is located
SCRIPT_DIR = Path(__file__).parent.absolute()


def load_ad_data(file_path: str = "ad.json"):
    """Load AD data from JSON file"""
    global ad_data
    with open(file_path, 'r', encoding='utf-8') as f:
        ad_data = json.load(f)
    return ad_data


def search_objects(query: str, object_type: str = None, max_results: int = 50):
    """
    Search AD objects by name, email, or other attributes
    """
    if not ad_data:
        return {"error": "AD data not loaded"}

    results = []
    query_lower = query.lower()

    def search_recursive(objects, depth=0):
        if depth > 20:  # Prevent infinite recursion
            return

        for obj in objects:
            attrs = obj.get('attributes', {})

            # Filter by object type if specified
            if object_type:
                obj_classes = attrs.get('objectClass', [])
                if object_type.lower() not in [oc.lower() for oc in obj_classes]:
                    if 'children' in obj and obj['children']:
                        search_recursive(obj['children'], depth + 1)
                    continue

            # Search in various attributes
            searchable_fields = [
                attrs.get('cn', ''),
                attrs.get('sAMAccountName', ''),
                attrs.get('displayName', ''),
                attrs.get('mail', ''),
                attrs.get('userPrincipalName', ''),
                attrs.get('name', ''),
                obj.get('dn', '')
            ]

            # Check if query matches any field
            if any(query_lower in str(field).lower() for field in searchable_fields if field):
                result = {
                    'dn': obj.get('dn'),
                    'type': attrs.get('objectClass', [])[-1] if attrs.get('objectClass') else 'unknown',
                    'name': attrs.get('cn') or attrs.get('name', 'N/A'),
                    'displayName': attrs.get('displayName', 'N/A'),
                    'email': attrs.get('mail', 'N/A'),
                    'sAMAccountName': attrs.get('sAMAccountName', 'N/A'),
                }
                results.append(result)

                if len(results) >= max_results:
                    return

            # Search in children
            if 'children' in obj and obj['children']:
                search_recursive(obj['children'], depth + 1)

    search_recursive(ad_data.get('root_objects', []))

    return {
        'total_found': len(results),
        'results': results[:max_results]
    }


def get_user_details(identifier: str):
    """
    Get detailed information about a specific user
    identifier can be: sAMAccountName, email, or CN
    """
    if not ad_data:
        return {"error": "AD data not loaded"}

    identifier_lower = identifier.lower()

    def find_user_recursive(objects, depth=0):
        if depth > 20:
            return None

        for obj in objects:
            attrs = obj.get('attributes', {})

            # Check if this is a user object
            obj_classes = attrs.get('objectClass', [])
            if 'user' not in [oc.lower() for oc in obj_classes]:
                if 'children' in obj and obj['children']:
                    result = find_user_recursive(obj['children'], depth + 1)
                    if result:
                        return result
                continue

            # Check if identifier matches
            if (identifier_lower == str(attrs.get('sAMAccountName', '')).lower() or
                identifier_lower == str(attrs.get('mail', '')).lower() or
                identifier_lower == str(attrs.get('userPrincipalName', '')).lower() or
                identifier_lower in str(attrs.get('cn', '')).lower()):

                return {
                    'dn': obj.get('dn'),
                    'cn': attrs.get('cn'),
                    'displayName': attrs.get('displayName'),
                    'givenName': attrs.get('givenName'),
                    'sn': attrs.get('sn'),
                    'sAMAccountName': attrs.get('sAMAccountName'),
                    'mail': attrs.get('mail'),
                    'userPrincipalName': attrs.get('userPrincipalName'),
                    'description': attrs.get('description'),
                    'memberOf': attrs.get('memberOf', []),
                    'whenCreated': attrs.get('whenCreated'),
                    'whenChanged': attrs.get('whenChanged'),
                    'lastLogon': attrs.get('lastLogon'),
                    'lastLogonTimestamp': attrs.get('lastLogonTimestamp'),
                    'accountExpires': attrs.get('accountExpires'),
                    'userAccountControl': attrs.get('userAccountControl'),
                }

            if 'children' in obj and obj['children']:
                result = find_user_recursive(obj['children'], depth + 1)
                if result:
                    return result

        return None

    user = find_user_recursive(ad_data.get('root_objects', []))

    if user:
        return user
    else:
        return {"error": f"User '{identifier}' not found"}


def get_group_members(group_name: str):
    """
    Get all members of a specific group
    """
    if not ad_data:
        return {"error": "AD data not loaded"}

    # First find the group's DN
    group_dn = None
    group_name_lower = group_name.lower()

    def find_group_dn(objects, depth=0):
        nonlocal group_dn
        if depth > 20 or group_dn:
            return

        for obj in objects:
            attrs = obj.get('attributes', {})
            obj_classes = attrs.get('objectClass', [])

            if 'group' in [oc.lower() for oc in obj_classes]:
                cn = attrs.get('cn', '')
                if group_name_lower in cn.lower():
                    group_dn = obj.get('dn')
                    return

            if 'children' in obj and obj['children']:
                find_group_dn(obj['children'], depth + 1)

    find_group_dn(ad_data.get('root_objects', []))

    if not group_dn:
        return {"error": f"Group '{group_name}' not found"}

    # Now find all users who are members of this group
    members = []

    def find_members(objects, depth=0):
        if depth > 20:
            return

        for obj in objects:
            attrs = obj.get('attributes', {})
            member_of = attrs.get('memberOf', [])

            if group_dn in member_of:
                members.append({
                    'dn': obj.get('dn'),
                    'name': attrs.get('cn') or attrs.get('name', 'N/A'),
                    'displayName': attrs.get('displayName', 'N/A'),
                    'type': attrs.get('objectClass', [])[-1] if attrs.get('objectClass') else 'unknown',
                    'sAMAccountName': attrs.get('sAMAccountName', 'N/A'),
                    'mail': attrs.get('mail', 'N/A'),
                })

            if 'children' in obj and obj['children']:
                find_members(obj['children'], depth + 1)

    find_members(ad_data.get('root_objects', []))

    return {
        'group_name': group_name,
        'group_dn': group_dn,
        'total_members': len(members),
        'members': members
    }


def list_groups(search_term: str = "", max_results: int = 100):
    """
    List all groups, optionally filtered by search term
    """
    if not ad_data:
        return {"error": "AD data not loaded"}

    groups = []
    search_lower = search_term.lower()

    def find_groups(objects, depth=0):
        if depth > 20:
            return

        for obj in objects:
            attrs = obj.get('attributes', {})
            obj_classes = attrs.get('objectClass', [])

            if 'group' in [oc.lower() for oc in obj_classes]:
                cn = attrs.get('cn', '')

                if not search_term or search_lower in cn.lower():
                    groups.append({
                        'cn': cn,
                        'dn': obj.get('dn'),
                        'description': attrs.get('description', 'N/A'),
                        'sAMAccountName': attrs.get('sAMAccountName', 'N/A'),
                    })

                if len(groups) >= max_results:
                    return

            if 'children' in obj and obj['children']:
                find_groups(obj['children'], depth + 1)

    find_groups(ad_data.get('root_objects', []))

    return {
        'total_found': len(groups),
        'groups': groups[:max_results]
    }


def get_ad_statistics():
    """
    Get statistics about the AD data
    """
    if not ad_data:
        return {"error": "AD data not loaded"}

    stats = {
        'domain': ad_data.get('domain'),
        'base_dn': ad_data.get('base_dn'),
        'extracted_at': ad_data.get('extracted_at'),
        'total_objects': ad_data.get('total_objects'),
    }

    # Count object types
    object_counts = {}

    def count_objects(objects, depth=0):
        if depth > 20:
            return

        for obj in objects:
            attrs = obj.get('attributes', {})
            obj_classes = attrs.get('objectClass', [])

            if obj_classes:
                obj_type = obj_classes[-1]
                object_counts[obj_type] = object_counts.get(obj_type, 0) + 1

            if 'children' in obj and obj['children']:
                count_objects(obj['children'], depth + 1)

    count_objects(ad_data.get('root_objects', []))
    stats['object_type_counts'] = object_counts

    return stats


# Create MCP server instance
server = Server("ad-query-server")


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """
    List available tools.
    """
    return [
        types.Tool(
            name="search_ad",
            description="Search Active Directory objects by name, email, or other attributes. Returns matching users, groups, computers, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (name, email, username, etc.)",
                    },
                    "object_type": {
                        "type": "string",
                        "description": "Optional: filter by object type (user, group, computer, organizationalUnit)",
                    },
                    "max_results": {
                        "type": "number",
                        "description": "Maximum number of results to return (default: 50)",
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="get_user_details",
            description="Get detailed information about a specific user including group memberships, last logon, account status, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "identifier": {
                        "type": "string",
                        "description": "User identifier: username (sAMAccountName), email, or common name (CN)",
                    },
                },
                "required": ["identifier"],
            },
        ),
        types.Tool(
            name="get_group_members",
            description="Get all members of a specific Active Directory group",
            inputSchema={
                "type": "object",
                "properties": {
                    "group_name": {
                        "type": "string",
                        "description": "Name of the group",
                    },
                },
                "required": ["group_name"],
            },
        ),
        types.Tool(
            name="list_groups",
            description="List all Active Directory groups, optionally filtered by search term",
            inputSchema={
                "type": "object",
                "properties": {
                    "search_term": {
                        "type": "string",
                        "description": "Optional: filter groups by name",
                    },
                    "max_results": {
                        "type": "number",
                        "description": "Maximum number of results (default: 100)",
                    },
                },
            },
        ),
        types.Tool(
            name="get_ad_statistics",
            description="Get statistics and overview information about the Active Directory data (domain info, total objects, object type counts)",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """
    Handle tool execution requests.
    """
    if not arguments:
        arguments = {}

    if name == "search_ad":
        query = arguments.get("query", "")
        object_type = arguments.get("object_type")
        max_results = arguments.get("max_results", 50)
        result = search_objects(query, object_type, max_results)

    elif name == "get_user_details":
        identifier = arguments.get("identifier", "")
        result = get_user_details(identifier)

    elif name == "get_group_members":
        group_name = arguments.get("group_name", "")
        result = get_group_members(group_name)

    elif name == "list_groups":
        search_term = arguments.get("search_term", "")
        max_results = arguments.get("max_results", 100)
        result = list_groups(search_term, max_results)

    elif name == "get_ad_statistics":
        result = get_ad_statistics()

    else:
        raise ValueError(f"Unknown tool: {name}")

    return [
        types.TextContent(
            type="text",
            text=json.dumps(result, indent=2)
        )
    ]


async def main():
    """Main entry point"""
    # Load AD data on startup
    import sys
    ad_json_path = SCRIPT_DIR / "ad.json"
    print(f"Loading AD data from {ad_json_path}...", file=sys.stderr, flush=True)
    load_ad_data(str(ad_json_path))
    print(f"Loaded {ad_data.get('total_objects', 0)} objects from {ad_data.get('domain', 'unknown')} domain", file=sys.stderr, flush=True)

    # Run the server using stdin/stdout streams
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="ad-query-server",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
