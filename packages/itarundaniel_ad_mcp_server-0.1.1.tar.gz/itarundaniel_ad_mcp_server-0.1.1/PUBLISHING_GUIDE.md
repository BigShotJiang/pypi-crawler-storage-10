# Publishing Guide for AD MCP Server

This guide walks you through publishing the Active Directory MCP Server to PyPI so others can easily install it with `uvx ad-mcp-server@latest`.

## Prerequisites

1. **PyPI Account**
   - Create account at https://pypi.org/account/register/
   - Create account at https://test.pypi.org/account/register/ (for testing)

2. **API Tokens**
   - Generate PyPI API token: https://pypi.org/manage/account/token/
   - Generate TestPyPI token: https://test.pypi.org/manage/account/token/
   - Save these securely!

3. **Install Publishing Tools**
   ```bash
   pip install build twine
   ```

## Pre-Publishing Checklist

### 1. Update Package Metadata

Edit `pyproject.toml`:

```toml
[project]
name = "ad-mcp-server"  # Choose a unique name
version = "0.1.0"  # Update version for each release
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]

[project.urls]
Homepage = "https://github.com/yourusername/ad-mcp-server"
Repository = "https://github.com/yourusername/ad-mcp-server"
```

### 2. Verify Package Structure

Ensure your directory looks like this:

```
ad-mcp-server/
├── src/
│   └── ad_mcp_server/
│       ├── __init__.py
│       └── server.py
├── pyproject.toml
├── README.md
├── LICENSE
├── MANIFEST.in
└── .gitignore
```

### 3. Test Locally

```bash
# Create a test virtual environment
python -m venv test_env
test_env\Scripts\activate  # Windows
# source test_env/bin/activate  # Linux/Mac

# Install in development mode
pip install -e .

# Test the command
ad-mcp-server --help  # Should not error

# Deactivate when done
deactivate
```

## Publishing Steps

### Step 1: Build the Package

```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info  # Linux/Mac
# rmdir /s /q dist build  # Windows (if exists)

# Build the package
python -m build
```

This creates:
- `dist/ad_mcp_server-0.1.0-py3-none-any.whl`
- `dist/ad_mcp_server-0.1.0.tar.gz`

### Step 2: Test on TestPyPI

**Configure TestPyPI credentials:**

Create/edit `~/.pypirc`:

```ini
[testpypi]
  username = __token__
  password = pypi-YOUR-TESTPYPI-TOKEN-HERE
```

**Upload to TestPyPI:**

```bash
python -m twine upload --repository testpypi dist/*
```

**Test Installation:**

```bash
# Test with pip
pip install --index-url https://test.pypi.org/simple/ --no-deps ad-mcp-server

# Test with uvx
uvx --index-url https://test.pypi.org/simple/ ad-mcp-server@latest
```

### Step 3: Publish to PyPI

**Configure PyPI credentials:**

Add to `~/.pypirc`:

```ini
[pypi]
  username = __token__
  password = pypi-YOUR-PYPI-TOKEN-HERE
```

**Upload to PyPI:**

```bash
python -m twine upload dist/*
```

### Step 4: Verify Publication

```bash
# Wait a few minutes for PyPI to index

# Test installation
uvx ad-mcp-server@latest

# Check on PyPI
# Visit: https://pypi.org/project/ad-mcp-server/
```

## Updating for New Releases

### 1. Update Version Number

Edit `pyproject.toml`:

```toml
version = "0.1.1"  # Increment version
```

Follow [Semantic Versioning](https://semver.org/):
- **0.1.0 → 0.1.1**: Bug fixes
- **0.1.0 → 0.2.0**: New features (backward compatible)
- **0.1.0 → 1.0.0**: Breaking changes

### 2. Update Changelog

Create `CHANGELOG.md`:

```markdown
# Changelog

## [0.1.1] - 2025-01-15
### Fixed
- Fixed bug with group member lookup

### Added
- Added support for nested groups

## [0.1.0] - 2025-01-01
### Added
- Initial release
```

### 3. Rebuild and Republish

```bash
# Clean old builds
rm -rf dist/ build/ *.egg-info

# Build
python -m build

# Upload
python -m twine upload dist/*
```

## Distribution Channels

### 1. PyPI (Primary)
- Users install with: `uvx ad-mcp-server@latest`
- Automatic updates when new versions published

### 2. GitHub Releases
- Tag releases: `git tag v0.1.0 && git push --tags`
- Create release notes on GitHub
- Users can install with: `pip install git+https://github.com/yourusername/ad-mcp-server.git`

### 3. Docker (Optional)

Create `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY . .
RUN pip install .

ENTRYPOINT ["ad-mcp-server"]
```

Build and publish:

```bash
docker build -t yourusername/ad-mcp-server:latest .
docker push yourusername/ad-mcp-server:latest
```

## User Configuration Examples

Once published, users add to their `claude_desktop_config.json`:

### Using UVX (Recommended)

```json
{
  "mcpServers": {
    "active-directory": {
      "command": "uvx",
      "args": ["ad-mcp-server@latest"],
      "env": {
        "AD_JSON_PATH": "C:\\path\\to\\ad.json"
      }
    }
  }
}
```

### Using Pip Install

```json
{
  "mcpServers": {
    "active-directory": {
      "command": "python",
      "args": ["-m", "ad_mcp_server"],
      "env": {
        "AD_JSON_PATH": "C:\\path\\to\\ad.json"
      }
    }
  }
}
```

## Troubleshooting

### "Package name already taken"

Choose a different name in `pyproject.toml`:
```toml
name = "your-org-ad-mcp-server"
```

### "Invalid authentication credentials"

Check your API token:
```bash
python -m twine upload --repository testpypi dist/* --verbose
```

### "File already exists"

You can't reupload the same version. Either:
- Increment version number
- Delete the release on PyPI (if needed)

### Build Errors

```bash
# Install build dependencies
pip install --upgrade build setuptools wheel

# Try building again
python -m build
```

## Security Best Practices

1. **Never commit tokens**: Keep API tokens in `~/.pypirc`, not in git
2. **Use API tokens**: Not username/password
3. **Rotate tokens**: Periodically regenerate API tokens
4. **Review distributions**: Check what files are included:
   ```bash
   tar -tzf dist/ad_mcp_server-0.1.0.tar.gz
   ```

## Monitoring

After publishing:

1. **Check PyPI stats**: https://pypi.org/project/ad-mcp-server/
2. **Monitor downloads**: Use pypistats
   ```bash
   pip install pypistats
   pypistats overall ad-mcp-server
   ```
3. **Watch issues**: Monitor GitHub issues for bug reports

## Resources

- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)
- [Semantic Versioning](https://semver.org/)
- [Twine Documentation](https://twine.readthedocs.io/)

## Questions?

- PyPI Support: https://pypi.org/help/
- Packaging Discussions: https://discuss.python.org/c/packaging/
