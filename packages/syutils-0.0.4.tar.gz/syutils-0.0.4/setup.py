from setuptools import setup, find_packages
setup(
    name="syutils",
    version="0.0.4",
    description="High frequency functions and class",
    long_description="",
    long_description_content_type="text/markdown",
    url="https://gitee.com/wdy0401/syutils",
    author="wangdeyang",
    author_email="wdy0401@gmail.com",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "trade_date",
        "py7zr",
    ],
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    zip_safe=False
)