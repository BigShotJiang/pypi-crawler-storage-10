Executors
===================

.. currentmodule:: xm_slurm

.. autosummary::

    Slurm

Slurm
~~~~~

.. autoclass:: SlurmSpec

.. autoclass:: Slurm
