import numpy as np


def main():
    print("Hello world!")
    print(f"numpy version: {np.__version__}")


if __name__ == "__main__":
    main()
