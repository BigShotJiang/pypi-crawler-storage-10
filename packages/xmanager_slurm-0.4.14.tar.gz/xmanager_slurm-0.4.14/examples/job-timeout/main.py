import sys
import time


def main():
    print("Starting job...")
    time.sleep(int(sys.argv[1]))


if __name__ == "__main__":
    main()
