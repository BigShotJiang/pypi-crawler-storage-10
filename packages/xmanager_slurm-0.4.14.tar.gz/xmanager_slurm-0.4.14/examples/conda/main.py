def main():
    print("Hello!")
    print("World!")


if __name__ == "__main__":
    main()
