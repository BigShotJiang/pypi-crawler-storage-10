DEFAULT_ENV = {
    "mainnet": {
        "base_url": "https://apilist.tronscanapi.com/api",
    },
    "nile": {
        "base_url": "https://nileapi.tronscan.org/api",
    },
    "shasta": {
        "base_url": "https://shastapi.tronscan.org/api",
    },
}
