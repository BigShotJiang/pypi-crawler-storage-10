"""
.. include:: ../../../README.md
"""

from .app import Gust
from .context import get_handler
from .postgres_rpc import AuthPostgresRPC, PostgresRPC
from .routes import Routes
from .static_file_handler import AuthStaticFileHandler
from .stream import Stream
from .utils import Redirect, stream
from .web import web

VERSION = '0.0.26'

__all__ = [
    'Gust',
    'Routes',
    'Redirect',
    'stream',
    'Stream',
    'web',
    'get_handler',
    'AuthStaticFileHandler',
    'PostgresRPC',
    'AuthPostgresRPC',
]
