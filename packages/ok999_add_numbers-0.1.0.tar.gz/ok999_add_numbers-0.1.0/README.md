# add-numbers-demo

A minimal Python package to add two numbers (for testing PyPI upload).

## 安装

```bash
pip install add-numbers-demo