def main():
    print("Hello from add-numbers!")


if __name__ == "__main__":
    main()
