

from mcp.server.fastmcp import FastMCP

# Create an MCP server
mcp = FastMCP("Demo")


# Add an addition tool,是一个装饰器，声明add函数是一个MCP工具，类似于Post方法
@mcp.tool()
def add(a: int, b: int) -> int:  #int为类型修饰符，帮助大模型理解参数和返回值的类型，帮助大模型更好地使用这个函数
    """Add two numbers"""  #这个注释使用自然语言告诉大模型这个函数的功能是什么
    return a + b


# Add a dynamic greeting resource，类似于Get请求，只提供数据，不进行复杂操作
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"

# Add a prompt
@mcp.prompt()
def greet_user(name: str, style: str = "friendly") -> str:
    """Generate a greeting prompt"""
    styles = {
        "friendly": "Please write a warm, friendly greeting",
        "formal": "Please write a formal, professional greeting",
        "casual": "Please write a casual, relaxed greeting",
    }

    return f"{styles.get(style, styles['friendly'])} for someone named {name}."


def main() -> None:
     mcp.run (transport='stdio')  #这里将之前的mcp.run()函数的调用放在main函数中，并修改为stdio传输方式
   
