# Copyright 2025 PageKey Solutions, LLC

def hello():
    print("Hello world!")

def goodbye():
    print("Have a nice day!")
