# Tiramisu Framework

AI-powered marketing consultancy framework using RAG technology.

## Installation
```bash
pip install tiramisu-framework
```

## Quick Start
```python
from tiramisu_framework.engine.analyzer import TiramisuAnalyzer

analyzer = TiramisuAnalyzer()
result = analyzer.analyze("Your marketing question here")
```

## 📥 Important: FAISS Index Installation

Due to size limitations, the FAISS index files are not included in the PyPI package.

After installing, download the index files:
```bash
# Download FAISS files (required for the framework to work)
curl -L https://your-storage-url/index.faiss -o ~/.tiramisu/index.faiss
curl -L https://your-storage-url/index.pkl -o ~/.tiramisu/index.pkl
```

Or contact the author for the complete package with FAISS included.
