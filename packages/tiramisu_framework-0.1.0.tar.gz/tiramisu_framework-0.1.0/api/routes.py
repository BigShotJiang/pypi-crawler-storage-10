"""
Rotas da API Tiramisu
"""
from fastapi import APIRouter, HTTPException
from tiramisu.models.schemas import AnalysisRequest, AnalysisResponse, AvailableTypesResponse
from tiramisu.engine.tiramisu import get_tiramisu

router = APIRouter()


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_content(request: AnalysisRequest):
    """
    Analisa conteúdo de marketing/vendas
    
    Args:
        request: AnalysisRequest com type, content, context
        
    Returns:
        AnalysisResponse: Análise completa da Tiramisu
    """
    try:
        tiramisu = get_tiramisu()
        response = tiramisu.analyze(request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/types", response_model=dict)
async def get_analysis_types():
    """
    Retorna tipos de análise disponíveis
    
    Returns:
        dict: Lista de tipos com descrições
    """
    try:
        tiramisu = get_tiramisu()
        return tiramisu.get_available_types()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def health_check():
    """
    Health check do serviço
    """
    return {
        "status": "healthy",
        "service": "Tiramisu API",
        "version": "1.0.0"
    }
