"""
Tiramisu - Classe principal da consultora
Orquestra todo o processo de análise
"""
from tiramisu.models.schemas import AnalysisType, AnalysisRequest, AnalysisResponse
from tiramisu.engine.analyzer import TiramisuAnalyzer


class Tiramisu:
    """
    🍰 TIRAMISU - Consultora de Marketing & Vendas
    
    Fusão de Kotler + Gary Vee + Martha Gabriel
    """
    
    def __init__(self):
        """Inicializa a Tiramisu"""
        print("\n" + "="*70)
        print("🍰 Iniciando TIRAMISU - Consultora de Marketing & Vendas")
        print("   Fusão de Kotler × Gary Vee × Martha Gabriel")
        print("="*70 + "\n")
        
        self.analyzer = TiramisuAnalyzer()
        
        print("✅ Tiramisu pronta para análises!\n")
    
    def analyze(self, request: AnalysisRequest) -> AnalysisResponse:
        """
        Analisa uma ação de marketing/vendas
        
        Args:
            request: AnalysisRequest com type, content, context
            
        Returns:
            AnalysisResponse: Análise completa estruturada
        """
        print(f"\n{'='*70}")
        print(f"🍰 TIRAMISU ANALISANDO: {request.type.value.upper()}")
        print(f"{'='*70}\n")
        
        # Delegar para o analyzer
        response = self.analyzer.analyze(
            analysis_type=request.type,
            content=request.content,
            context=request.context
        )
        
        print(f"\n{'='*70}")
        print("✅ ANÁLISE CONCLUÍDA!")
        print(f"{'='*70}\n")
        
        return response
    
    def get_available_types(self) -> dict:
        """
        Retorna tipos de análise disponíveis
        
        Returns:
            dict: Informações sobre tipos disponíveis
        """
        return {
            "types": [
                {
                    "id": "post_social",
                    "name": "Post Redes Sociais",
                    "description": "Análise de posts para LinkedIn, Instagram, Twitter/X, Facebook",
                    "icon": "📱"
                },
                {
                    "id": "email_marketing",
                    "name": "Email Marketing",
                    "description": "Análise de campanhas de email, newsletters, cold emails",
                    "icon": "📧"
                },
                {
                    "id": "landing_page",
                    "name": "Landing Page",
                    "description": "Análise de páginas de conversão, copy, estrutura, UX",
                    "icon": "🌐"
                },
                {
                    "id": "ad_copy",
                    "name": "Copy de Anúncio",
                    "description": "Análise de anúncios (Google Ads, Meta Ads, etc)",
                    "icon": "��"
                },
                {
                    "id": "strategy",
                    "name": "Estratégia de Marketing",
                    "description": "Análise de planejamento estratégico completo",
                    "icon": "🎯"
                },
                {
                    "id": "pitch",
                    "name": "Pitch / Apresentação",
                    "description": "Análise de pitches, apresentações, decks",
                    "icon": "🎤"
                },
                {
                    "id": "video_script",
                    "name": "Script de Vídeo",
                    "description": "Análise de roteiros para vídeos marketing",
                    "icon": "🎬"
                },
                {
                    "id": "other",
                    "name": "Outro",
                    "description": "Análise genérica de marketing/vendas",
                    "icon": "📝"
                }
            ]
        }


# Singleton instance
_tiramisu_instance = None


def get_tiramisu() -> Tiramisu:
    """
    Retorna instância singleton da Tiramisu
    """
    global _tiramisu_instance
    
    if _tiramisu_instance is None:
        _tiramisu_instance = Tiramisu()
    
    return _tiramisu_instance
