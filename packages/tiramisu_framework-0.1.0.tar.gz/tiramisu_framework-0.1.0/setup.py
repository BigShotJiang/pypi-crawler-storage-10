from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

# Função para encontrar todos os arquivos de dados
def find_data_files():
    data_files = []
    for root, dirs, files in os.walk("data"):
        for file in files:
            if not file.startswith('.'):
                data_files.append(os.path.join(root, file))
    return data_files

setup(
    name="tiramisu-framework",
    version="0.1.0",
    author="Jony Wolff",
    author_email="your.email@example.com",
    description="AI-powered marketing consultancy framework using RAG technology",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/tiramisu-framework",
    packages=find_packages(),
    package_dir={'tiramisu_framework': '.'},
    package_data={
        '': ['data/**/*', 'config/*'],
    },
    include_package_data=True,
    data_files=[
        ('tiramisu_framework/data/faiss_index', ['data/faiss_index/index.faiss', 'data/faiss_index/index.pkl']),
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
)
