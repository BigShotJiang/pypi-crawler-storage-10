"""Singer Tap Tests."""
