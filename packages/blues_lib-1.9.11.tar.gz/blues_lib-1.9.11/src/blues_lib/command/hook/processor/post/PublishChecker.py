from datetime import datetime
from blues_lib.command.hook.processor.post.AbsPostProc import AbsPostProc

class PublishChecker(AbsPostProc):
  
  def execute(self)->None:
    '''
    @description: check the login status
    @return: None
    '''
    data = self._output.data
    entities = data if isinstance(data,list) else [data]
    for entity in entities:
      # entity contains a mat_id filed
      self._check_one(entity)
      
  def _check_one(self,entity:dict)->None:
    # check one published status
    entity['pub_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mat_status = 'success' if entity.get('published') else 'failure'
    entity['pub_stat'] = mat_status
    del entity['published']
      