from blues_lib.command.hook.processor.prev.AbsPrevProc import AbsPrevProc
from blues_lib.util.NestedDataReader import NestedDataReader
from blues_lib.command.hook.mapping.Mapper import Mapper
from blues_lib.type.exception.FlowSkipException import FlowSkipException

class Skipper(AbsPrevProc):
  # if source data value is True, skip this command and return 200
  
  def execute(self)->bool:
    '''
    @description: Convert the text to ai query, change the bizdata and refresh the Model
    @return: None
    '''
    if source_path:=self._proc_conf.get('source'):
      mapper = Mapper(self._context,self._input,self._proc_conf)
      source_data,source_attr_chain = mapper.get_source()
      should_skip:bool = NestedDataReader.read_by_path(source_data,source_attr_chain)
      if should_skip:
        raise FlowSkipException(f'Skipper: {source_path} is True')
