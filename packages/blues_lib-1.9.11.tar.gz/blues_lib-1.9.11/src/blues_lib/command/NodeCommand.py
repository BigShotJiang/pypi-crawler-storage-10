from abc import abstractmethod
from typing import final

from blues_lib.type.executor.Command import Command
from blues_lib.namespace.CommandName import CommandName
from blues_lib.namespace.CrawlerName import CrawlerName
from blues_lib.type.output.STDOut import STDOut
from blues_lib.type.model.Model import Model
from blues_lib.type.exception.FlowSkipException import FlowSkipException
from blues_lib.command.hook.mapping.PrevMapping import PrevMapping
from blues_lib.command.hook.mapping.PostMapping import PostMapping
from blues_lib.command.hook.processor.PrevProcessor import PrevProcessor
from blues_lib.command.hook.processor.PostProcessor import PostProcessor

class NodeCommand(Command):

  NAME = CommandName.Exception.UNSET # should be rewrite by the subclass
  TYPE = CommandName.Type.ACTION

  INPUT = CommandName.IO.INPUT
  OUTPUT = CommandName.IO.OUTPUT 
  
  def __init__(self,context:dict,input:list[dict]|Model,task_id:str) -> None:
    '''
    Args:
      context (dict): the flow's context, the client pass a empty dict
      input (list[dict]|Model): when it's a sub flow command it's a list, otherwise it's a Model
      id (str, optional): the command id, default is empty. Defaults to ''.
    '''
    super().__init__(context)
    self._output:STDOut = None # context.output
    self._node_input:dict|Model = input # node's input
    self._is_flow:bool = not isinstance(input,Model)
    self._task_id:str = task_id # command id
    
    if not self._task_id:
      raise Exception(f'[{self.NAME}] task_id is None')

  @property
  def task_id(self)->str:
    return self._task_id

  @final
  def execute(self):

    # prev hook
    if not self._is_flow:
      PrevMapping(self._context,self._node_input,self.NAME).execute()
      try:
        PrevProcessor(self._context,self._node_input,self.NAME).execute()
      except FlowSkipException as e:
        message = f'[{self.__class__.__name__}] Skip the current flow - {e}'
        node_output = STDOut(200,message)
        self._export(node_output)
        self._log(node_output)
        return

    # check and init fields
    self._setup()

    # execute the action and return the init stdout
    node_output:STDOut = self._invoke()

    # post process by factory
    if not self._is_flow:
      PostMapping(self._context,self._node_input,self.NAME).execute()
      PostProcessor(self._context,self._node_input,node_output,self.NAME).execute()

    self._export(node_output)
    self._raise(node_output)
    self._log(node_output)
    
  def _setup(self):
    if not self._node_input:
      raise Exception(f'[{self.NAME}] node input is None')

    # lazy to get the flow's output
    self._output = self._context.get(self.OUTPUT.value)

    # flow kind command's node input is a dict
    if not self._is_flow:
      self._node_conf:dict = self._node_input.config
      self._node_meta:dict = self._node_input.meta
      self._node_bizdata:dict = self._node_input.bizdata
      self._summary:dict = self._node_conf.get(CrawlerName.Field.SUMMARY.value) or {}
      self._onerror:str = self._summary.get('onerror',CommandName.Exception.ABORT.value)
    else:
      # flow command don't abort the flow
      self._onerror:str = CommandName.Exception.IGNORE.value

  @abstractmethod
  def _invoke(self):
    pass

  def _export(self,stdout:STDOut):
    '''
    receive the task's output dict and add to the task_id namespace
    '''
    # use the unique task_id to store the output
    
    # the standard output dict as the command's default return_value
    self._xcom_update(stdout.to_dict())
    
  def _xcom_update(self,kvs:dict):
    for k,v in kvs.items():
      self._xcom_push(k,v)
    
  def _xcom_push(self,key:str,value:any):
    # 将数据添加到task_id空间下
    if not self._context.get(self._task_id):
      self._context[self._task_id] = {}
      
    self._context[self._task_id][key] = value
      
  def _raise(self,stdout:STDOut):
    if stdout.code !=200 and self._onerror==CommandName.Exception.ABORT.value:
      raise Exception(stdout.message)

  def _log(self,stdout:STDOut):
    if stdout.code == 200:
      self._logger.info(stdout.message)
    else:
      self._logger.error(stdout.message)
