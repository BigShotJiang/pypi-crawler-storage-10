from typing import List
from pydantic import BaseModel

class AuditEntry(BaseModel):
    rule: str
    detail: str
    severity: str

class AuditReport(BaseModel):
    ok: bool
    entries: List[AuditEntry]
