# Placeholder for plugins
from typing import Dict, Any

class BasePlugin:
    def extend_fields(self, evidence: Dict[str, Any]) -> Dict[str, Any]:
        return evidence
