# __main__.py
import argparse
import sys

def main():
    parser = argparse.ArgumentParser(
        prog="ai-language-filter",
        description="AI Language Filter - text analysis and filtering tool"
    )
    parser.add_argument("text", nargs="*", help="Text to analyze")
    parser.add_argument("--version", action="store_true", help="Show version and exit")
    args = parser.parse_args()

    if args.version:
        from ai_language_filter import __version__
        print(f"ai-language-filter {__version__}")
        sys.exit(0)

    if not args.text:
        print("No input text provided.")
        sys.exit(1)

    text = " ".join(args.text)
    # 简单示例：过滤掉敏感词
    filtered = text.replace("badword", "***")
    print(f"Filtered text: {filtered}")

if __name__ == "__main__":
    main()
