from typing import Any, Dict, Protocol

class AuthoritySource(Protocol):
    name: str
    def fetch(self, request: Dict[str, Any]) -> Dict[str, Any]:
        ...
