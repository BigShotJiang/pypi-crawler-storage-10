from typing import Optional
import pathlib
import shutil

def mount_rules_fs(target_dir: str, overwrite: bool = False) -> None:
    base = pathlib.Path(__file__).resolve().parent.parent
    src_policies = base / "policies"
    dst = pathlib.Path(target_dir).resolve()
    dst.mkdir(parents=True, exist_ok=True)
    dst_policies = dst / "policies"
    if dst_policies.exists() and overwrite:
        shutil.rmtree(dst_policies)
    if not dst_policies.exists():
        shutil.copytree(src_policies, dst_policies)
    audit_dir = dst / "audit"
    audit_dir.mkdir(exist_ok=True)
    (audit_dir / "README.txt").write_text("drop audit reports here", encoding="utf-8")
