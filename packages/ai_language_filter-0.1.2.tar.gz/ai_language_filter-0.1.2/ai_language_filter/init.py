__version__ = "0.2.0"
__author__ = "nankezhou"
__copyright__ = "© 2025 nankezhou, Shanxi, China"
