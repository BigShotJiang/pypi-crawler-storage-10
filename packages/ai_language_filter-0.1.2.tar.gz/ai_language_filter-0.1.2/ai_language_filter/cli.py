import argparse
from .policy_enforcer import enforce_policy
from .fs.provider import mount_rules_fs

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ai-language-filter",
        description="Strict data filter with 2+ authoritative-source crosschecks and full audit."
    )
    parser.add_argument("text", nargs="*", help="Raw text or JSON snippet to validate/filter")
    parser.add_argument("--rules", default=None, help="Path to rules.yaml (default: built-in)")
    parser.add_argument("--mount", default=None, help="Mount built-in FS to this directory (copies rules/audit skeleton)")
    parser.add_argument("--audit-out", default="audit_report.json", help="Audit report output path")
    parser.add_argument("--fail-on-violation", action="store_true", help="Return nonzero exit on any violation")
    parser.add_argument("--version", action="store_true", help="Show version and exit")
    args = parser.parse_args()

    if args.version:
        from . import __version__
        print(f"ai-language-filter {__version__}")
        return

    if args.mount:
        mount_rules_fs(args.mount)
        print(f"mounted templates to: {args.mount}")
        return

    text = " ".join(args.text).strip()
    if not text:
        print("no input text provided")
        raise SystemExit(2)

    verdict = enforce_policy(
        payload=text,
        rules_path=args.rules,
        audit_out=args.audit_out,
        strict_fail=args.fail_on_violation,
    )
    print(verdict.summary)
    if args.fail_on_violation and not verdict.ok:
        raise SystemExit(1)
