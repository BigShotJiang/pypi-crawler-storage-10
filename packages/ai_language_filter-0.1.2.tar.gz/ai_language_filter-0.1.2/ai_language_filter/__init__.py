# 说明文字用的 # 轻量 __init__ 与延迟导入及关于信息访问器

__all__ = [
    "FilterPipeline",
    "enforce_policy",
    "evaluate",
    "version",
    "about_texts",
    "about_json",
    "about_json_all",
]

from importlib import import_module as _imp


def _about_texts():
    # 说明文字用的 # 统一从 __about__ 取九种语言文本
    ab = _imp(".__about__", __name__)
    return {
        "zh": (ab.__purpose_cn__, ab.__legal_notice_zh__),
        "en": (ab.__purpose_en__, ab.__legal_notice_en__),
        "fr": (ab.__purpose_fr__, ab.__legal_notice_fr__),
        "de": (ab.__purpose_de__, ab.__legal_notice_de__),
        "nl": (ab.__purpose_nl__, ab.__legal_notice_nl__),
        "el": (ab.__purpose_el__, ab.__legal_notice_el__),
        "la": (ab.__purpose_la__, ab.__legal_notice_la__),
        "ja": (ab.__purpose_ja__, ab.__legal_notice_ja__),
        "ko": (ab.__purpose_ko__, ab.__legal_notice_ko__),
    }


def __getattr__(name):
    if name == "FilterPipeline":
        return getattr(_imp(".core", __name__), "FilterPipeline")
    if name == "enforce_policy":
        return getattr(_imp(".policy_enforcer", __name__), "enforce_policy")
    if name == "evaluate":
        return getattr(_imp(".core", __name__), "evaluate")
    if name == "version":
        return "0.1.0-src"
    if name == "about_texts":
        return _about_texts()
    if name == "about_json":
        def _one(lang: str):
            ab = _imp(".__about__", __name__)
            purpose, legal = _about_texts()[lang]
            return {
                "title": "AI Language Filter — LICENSE-NKZ",
                "version": getattr(ab, "__version__", "0.1.0-src"),
                "language": lang,
                "author": {
                    "name_cn": getattr(ab, "__author_name_cn__", "南柯舟"),
                    "name_en": getattr(ab, "__author_name_en__", "Nanke Zhou"),
                    "email": getattr(ab, "__author_email__", "dong@nankezhou.net"),
                    "website": getattr(ab, "__author_website__", "https://nankezhou.net"),
                    "birthdate": getattr(ab, "__author_birth__", "1975-07-17"),
                    "roles_cn": getattr(ab, "__author_roles_cn__", ""),
                    "roles_en": getattr(ab, "__author_roles_en__", ""),
                },
                "statements": {
                    "purpose": purpose,
                    "legal_notice": legal,
                },
                "support": {
                    "paypal": getattr(ab, "__paypal__", "goodluck3658848@gmail.com"),
                },
            }
        return _one
    if name == "about_json_all":
        def _all():
            ab = _imp(".__about__", __name__)
            texts = _about_texts()
            out = {}
            for lang, pair in texts.items():
                purpose, legal = pair
                out[lang] = {
                    "title": "AI Language Filter — LICENSE-NKZ",
                    "version": getattr(ab, "__version__", "0.1.0-src"),
                    "language": lang,
                    "author": {
                        "name_cn": getattr(ab, "__author_name_cn__", "南柯舟"),
                        "name_en": getattr(ab, "__author_name_en__", "Nanke Zhou"),
                        "email": getattr(ab, "__author_email__", "dong@nankezhou.net"),
                        "website": getattr(ab, "__author_website__", "https://nankezhou.net"),
                        "birthdate": getattr(ab, "__author_birth__", "1975-07-17"),
                        "roles_cn": getattr(ab, "__author_roles_cn__", ""),
                        "roles_en": getattr(ab, "__author_roles_en__", ""),
                    },
                    "statements": {
                        "purpose": purpose,
                        "legal_notice": legal,
                    },
                    "support": {
                        "paypal": getattr(ab, "__paypal__", "goodluck3658848@gmail.com"),
                    },
                }
            return out
        return _all
    raise AttributeError(name)
