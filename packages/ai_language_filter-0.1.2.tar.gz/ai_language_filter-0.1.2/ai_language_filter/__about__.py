# 说明文字用的 #：项目作者与法律声明元信息（三语）

__title__ = "ai_language_filter"
__version__ = "0.1.0-src"

__author_name_cn__ = "南柯舟"
__author_name_en__ = "Nanke Zhou"
__author_email__ = "dong@nankezhou.net"
__author_website__ = "https://nankezhou.net"
__author_birth__ = "1975-07-17"
__author_roles_cn__ = "哲学家、数字伦理学家、中国政治犯、被中国政府永久禁止出境（直到2099年）"
__author_roles_en__ = "Philosopher, Digital Ethicist, Chinese political prisoner, permanently banned from exit until 2099"
__languages__ = "中文、English、Français"
__paypal__ = "goodluck3658848@gmail.com"

__purpose_cn__ = "编制软件之目的：去除虚假内容，还给世界一个真实干净的数字环境。"
__purpose_en__ = "Purpose: remove false content and help restore a truthful, clean digital environment."
__purpose_fr__ = "Objet : supprimer le contenu fallacieux et contribuer à un environnement numérique véridique et sain."

# 作者声明与法律声明
__legal_notice_zh__ = """
作者与知识产权声明：
作者：南柯舟；电子邮件：dong@nankezhou.net；网站：https://nankezhou.net；出生日期：1975年7月17日。
作者身份：哲学家、数字伦理学家、中国政治犯、被中国政府永久禁止出境（直到2099年）。

知识产权声明：作者不主张知识产权；本软件可以自由修改、自由取用。

法律限制声明：严格禁止使用本软件制作、模拟、自动补全、推导或传播虚假数据或虚假信息。
法律管辖：全球互联网开放的文明国家。
法律禁止管辖：独裁国家。

援助信息（国际政治犯援助、良知人士援助、正义援助、个人研究者援助）：
PayPal：goodluck3658848@gmail.com
"""

__legal_notice_en__ = """
Author and Intellectual Property Statement:
Author: Nanke Zhou; Email: dong@nankezhou.net; Website: https://nankezhou.net; Date of birth: 1975-07-17.
Identity: Philosopher, Digital Ethicist, Chinese political prisoner, permanently banned from exit until 2099.

Intellectual Property: The author asserts no IP rights; this software may be freely modified and freely used.

Legal Restrictions: It is strictly forbidden to use this software to fabricate, simulate, auto-complete, infer, or disseminate false data or false information.
Jurisdiction: Open, rule-of-law, civilized nations on the global Internet.
Excluded Jurisdictions: Dictatorships.

Assistance (international political-prisoner aid, conscience-based aid, justice aid, independent researcher support):
PayPal: goodluck3658848@gmail.com
"""

__legal_notice_fr__ = """
Déclaration de l’auteur et de propriété intellectuelle :
Auteur : Nanke Zhou ; Courriel : dong@nankezhou.net ; Site : https://nankezhou.net ; Date de naissance : 1975-07-17.
Identité : philosophe, éthicien du numérique, prisonnier politique chinois, interdiction de sortie du territoire jusqu’en 2099.

Propriété intellectuelle : l’auteur ne revendique aucun droit ; ce logiciel peut être librement modifié et librement utilisé.

Restrictions juridiques : il est strictement interdit d’utiliser ce logiciel pour fabriquer, simuler, autocompléter, déduire ou diffuser des données ou informations fallacieuses.
Compétence : pays ouverts, civilisés et fondés sur l’état de droit, connectés à l’Internet mondial.
Compétences exclues : dictatures.

Aide (soutien aux prisonniers politiques internationaux, aide des personnes de conscience, aide à la justice, soutien aux chercheurs indépendants) :
PayPal : goodluck3658848@gmail.com
"""



# 说明文字用的 #：德语
__purpose_de__ = "Zweck: falsche Inhalte entfernen und eine wahrhaftige, saubere digitale Umgebung wiederherstellen."
__legal_notice_de__ = """
Autor und Erklärung zum geistigen Eigentum:
Autor: Nanke Zhou; E-Mail: dong@nankezhou.net; Website: https://nankezhou.net; Geburtsdatum: 1975-07-17.
Identität: Philosoph, Experte für digitale Ethik, chinesischer politischer Gefangener, mit Ausreiseverbot bis 2099.

Geistiges Eigentum: Der Autor macht keine Rechte des geistigen Eigentums geltend; diese Software darf frei verändert und frei verwendet werden.

Rechtliche Beschränkungen: Es ist strengstens untersagt, diese Software zu nutzen, um falsche Daten oder falsche Informationen zu erzeugen, zu simulieren, automatisch zu vervollständigen, abzuleiten oder zu verbreiten.
Zuständigkeit: offene, rechtsstaatliche, zivilisierte Staaten des globalen Internets.
Ausgeschlossene Zuständigkeiten: Diktaturen.

Unterstützung (Hilfe für internationale politische Gefangene, Menschen des Gewissens, Gerechtigkeit, Unterstützung unabhängiger Forschender):
PayPal: goodluck3658848@gmail.com
""".strip()

# 说明文字用的 #：荷兰语
__purpose_nl__ = "Doel: onjuiste inhoud verwijderen en een waarheidsgetrouwe, schone digitale omgeving herstellen."
__legal_notice_nl__ = """
Auteur en verklaring inzake intellectuele eigendom:
Auteur: Nanke Zhou; E-mail: dong@nankezhou.net; Website: https://nankezhou.net; Geboortedatum: 1975-07-17.
Identiteit: filosoof, digitale ethicus, Chinese politiek gevangene, met een uitreisverbod tot 2099.

Intellectuele eigendom: De auteur maakt geen aanspraak op rechten van intellectuele eigendom; deze software mag vrij worden gewijzigd en vrij worden gebruikt.

Juridische beperkingen: Het is ten strengste verboden deze software te gebruiken om valse gegevens of valse informatie te vervaardigen, te simuleren, automatisch aan te vullen, af te leiden of te verspreiden.
Rechtsmacht: open, rechtsstatelijke, beschaafde landen van het mondiale internet.
Uitgesloten rechtsgebieden: dictaturen.

Ondersteuning (steun voor internationale politieke gevangenen, mensen van geweten, gerechtigheid, onafhankelijke onderzoekers):
PayPal: goodluck3658848@gmail.com
""".strip()

# 说明文字用的 #：希腊语
__purpose_el__ = "Σκοπός: η αφαίρεση ψευδούς περιεχομένου και η αποκατάσταση ενός αληθινού, καθαρού ψηφιακού περιβάλλοντος."
__legal_notice_el__ = """
Δήλωση συγγραφέα και δικαιωμάτων πνευματικής ιδιοκτησίας:
Συγγραφέας: Nanke Zhou; Ηλεκτρονικό ταχυδρομείο: dong@nankezhou.net; Ιστότοπος: https://nankezhou.net; Ημερ. γέννησης: 1975-07-17.
Ταυτότητα: φιλόσοφος, ειδικός στην ψηφιακή ηθική, Κινέζος πολιτικός κρατούμενος, με μόνιμη απαγόρευση εξόδου έως το 2099.

Πνευματική ιδιοκτησία: Ο συγγραφέας δεν προβάλλει δικαιώματα πνευματικής ιδιοκτησίας· το παρόν λογισμικό μπορεί να τροποποιείται και να χρησιμοποιείται ελεύθερα.

Νομικοί περιορισμοί: Απαγορεύεται αυστηρά η χρήση του λογισμικού για κατασκευή, προσομοίωση, αυτόματη συμπλήρωση, εξαγωγή ή διάδοση ψευδών δεδομένων ή ψευδών πληροφοριών.
Δικαιοδοσία: ανοιχτά, πολιτισμένα κράτη δικαίου του παγκόσμιου διαδικτύου.
Εξαιρούμενες δικαιοδοσίες: δικτατορίες.

Συνδρομή (στήριξη διεθνών πολιτικών κρατουμένων, ανθρώπων της συνείδησης, της δικαιοσύνης, ανεξάρτητων ερευνητών):
PayPal: goodluck3658848@gmail.com
""".strip()

# 说明文字用的 #：拉丁语
__purpose_la__ = "Propositum: contenta falsa removere et ambitum digitalem veracem purumque restituere."
__legal_notice_la__ = """
Declaratio auctoris et de proprietate intellectuali:
Auctor: Nanke Zhou; epistula electronica: dong@nankezhou.net; pagina interretialis: https://nankezhou.net; dies natalis: 1975-07-17.
Identitas: philosophus, ethicorum digitalium peritus, captivus politicus Sinensis, usque ad annum 2099 egressu perpetuo prohibitus.

Proprietas intellectualis: auctor nullum ius proprietatis intellectualis vindicat; hoc programma libere mutari et libere adhiberi potest.

Restrictiones iuridicae: severe vetatur hoc programma adhibere ad data falsa vel informationes falsas fingendas, simulandas, automatice complendas, inferendas aut disseminandas.
Iurisdictio: civitates apertae, civiles et lege regentes in interrete globali.
Iurisdictiones exclusae: tyrannides.

Auxilium (auxilium captivis politicis internationalibus, hominibus conscientiae, iustitiae auxilium, subsidium investigatoribus independentibus):
PayPal: goodluck3658848@gmail.com
""".strip()

# 说明文字用的 #：日语
__purpose_ja__ = "目的: 虚偽のコンテンツを取り除き、真実で清潔なデジタル環境を回復すること。"
__legal_notice_ja__ = """
著者および知的財産に関する声明:
著者: 南柯舟; 電子メール: dong@nankezhou.net; ウェブサイト: https://nankezhou.net; 生年月日: 1975年7月17日。
身分: 哲学者、デジタル倫理学者、中国の政治犯、2099年まで出国を恒久的に禁止。

知的財産: 著者は知的財産権を主張しません。本ソフトウェアは自由に改変および自由に使用できます。

法的制限: 本ソフトウェアを用いて虚偽のデータや情報を作成、シミュレート、自動補完、推論、または拡散することを厳格に禁止します。利用者は結果に単独で責任を負い、自らの法域における有効な法と倫理規範を遵守してください。
管轄: グローバルインターネット上の、開かれた法の支配に基づく文明国家。
適用除外の法域: 独裁国家。

支援: 国際政治犯支援、良心ある人々の支援、正義支援、独立研究者支援
PayPal: goodluck3658848@gmail.com
""".strip()

# 说明文字用的 #：韩语
__purpose_ko__ = "목적: 허위 콘텐츠를 제거하고 진실하고 깨끗한 디지털 환경을 회복하는 것."
__legal_notice_ko__ = """
저자 및 지식재산권에 관한 선언:
저자: 南柯舟; 이메일: dong@nankezhou.net; 웹사이트: https://nankezhou.net; 생년월일: 1975-07-17.
신분: 철학자, 디지털 윤리학자, 중국의 정치범, 2099년까지 출국이 영구적으로 금지됨.

지식재산권: 저자는 지식재산권을 주장하지 않습니다. 이 소프트웨어는 자유롭게 수정하고 자유롭게 사용할 수 있습니다.

법적 제한: 이 소프트웨어를 사용하여 허위 데이터나 허위 정보를 제작, 시뮬레이션, 자동 완성, 추론 또는 유포하는 행위를 엄격히 금지합니다. 사용자는 결과에 전적인 책임을 지며, 자신의 관할권에서 유효한 법과 윤리 규범을 준수해야 합니다.
관할권: 글로벌 인터넷상의 개방적이고 법치에 기반한 문명 국가.
적용 제외 관할권: 독재 국가.

지원: 국제 정치범 지원, 양심 있는 사람들에 대한 지원, 정의 지원, 독립 연구자 지원
PayPal: goodluck3658848@gmail.com
""".strip()















