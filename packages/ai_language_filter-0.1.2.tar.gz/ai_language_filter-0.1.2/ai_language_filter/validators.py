from typing import Any, Dict, List
import regex as re

PLACEHOLDER_DEFAULTS = [
    r"\bTBD\b",
    r"\bN/A\b",
    r"\bnull\b",
    r"\bplaceholder\b",
    r"\bauto[- ]?complete\b",
]

SYNTHETIC_HINTS = [
    r"\bsimulated\b",
    r"\bfake\b",
    r"\bsynthetic\b",
    r"\bmock(ed)?\b",
    r"\bdummy\b",
]

INFERRED_VIRTUAL_HINTS = [
    r"\binfer(red)?\b",
    r"\bestimate(d)?\b",
    r"\bderived\b",
    r"\bvirtual\b",
]

def detect_placeholder_tokens(payload: str, rules: Dict[str, Any]) -> List[str]:
    pats = rules.get("placeholder_patterns", PLACEHOLDER_DEFAULTS)
    hits: List[str] = []
    for p in pats:
        if re.search(p, payload, flags=re.I):
            hits.append(p)
    return hits

def detect_synthetic_markers(payload: str, rules: Dict[str, Any]) -> List[str]:
    pats = rules.get("synthetic_patterns", SYNTHETIC_HINTS)
    hits: List[str] = []
    for p in pats:
        if re.search(p, payload, flags=re.I):
            hits.append(p)
    return hits

def detect_inferred_virtual_signals(payload: str, rules: Dict[str, Any]) -> List[str]:
    pats = rules.get("inferred_virtual_patterns", INFERRED_VIRTUAL_HINTS)
    hits: List[str] = []
    for p in pats:
        if re.search(p, payload, flags=re.I):
            hits.append(p)
    return hits
