from ai_language_filter.policy_enforcer import enforce_policy

def test_violation():
    v = enforce_policy(
        payload="this is simulated placeholder",
        rules_path=None,
        audit_out="tmp_audit.json",
        strict_fail=False,
    )
    assert not v.ok

def test_ok():
    v = enforce_policy(
        payload="official year-over-year value 3.1",
        rules_path=None,
        audit_out="tmp_audit2.json",
        strict_fail=False,
    )
    # 演示源实现里 authority_A/B 会返回 ok
    assert v.ok
