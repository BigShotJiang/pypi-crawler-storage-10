import pytest
from ai_language_filter.core import FilterPipeline

def test_block_synthetic():
    pipeline = FilterPipeline()
    assert pipeline.process("This is synthetic data") == "BLOCKED"

def test_pass_clean():
    pipeline = FilterPipeline()
    assert pipeline.process("Clean text") == "Clean text"
