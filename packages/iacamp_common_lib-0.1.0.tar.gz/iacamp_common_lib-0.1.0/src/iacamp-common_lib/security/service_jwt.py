from zoneinfo import ZoneInfo
import jwt
from datetime import datetime, timedelta


class ServiceJWT:
    @staticmethod
    def generate(
        private_key: str | bytes,
        user_id: str,
        user_data: dict,
        role: str
    ) -> str:
        now = datetime.now(tz=ZoneInfo("UTC"))
        payload = {
            "iss": "gateway",
            "sub": user_id,
            "iat": now,
            "user_data": user_data,
            "role": role,
            "exp": now + timedelta(minutes=5)
        }
        return jwt.encode(payload, private_key, algorithm="RS256")


    @staticmethod
    def verify(public_key: str | bytes, token: str):
        return jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            issuer="gateway"
        )