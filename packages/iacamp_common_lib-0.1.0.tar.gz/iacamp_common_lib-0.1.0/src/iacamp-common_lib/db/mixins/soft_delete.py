from datetime import datetime
from zoneinfo import ZoneInfo
from sqlalchemy import DateTime, event
from sqlalchemy.orm import Mapped, mapped_column, with_loader_criteria, Session

class SoftDeleteMixin:
    deleted_at: Mapped[datetime] = mapped_column(DateTime, nullable=True, default=None)
    
    def soft_delete(self):
        self.deleted_at = datetime.now(tz=ZoneInfo("UTC"))

@event.listens_for(Session, "do_orm_execute")
def _add_soft_delete_criteria(execute_state):
    """Intercepta execuções ORM para aplicar automaticamente o filtro de soft delete.
    
        Para recuperar deletados inclusos:
        session.execute(select(<model>).execution_options(include_deleted=True))
    """
    if (
        execute_state.is_select
        and not execute_state.execution_options.get("include_deleted", False)
    ):
        execute_state.statement = execute_state.statement.options(
            with_loader_criteria(
                SoftDeleteMixin,
                lambda cls: cls.deleted_at.is_(None),
                include_aliases=True
            )
        )
