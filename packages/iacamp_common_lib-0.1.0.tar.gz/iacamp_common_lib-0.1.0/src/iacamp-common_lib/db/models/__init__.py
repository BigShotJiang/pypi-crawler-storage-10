from .base import BaseSoftDeleteModel

__all__ = ["BaseSoftDeleteModel"]