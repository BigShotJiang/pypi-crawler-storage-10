from datetime import datetime
import uuid
from zoneinfo import ZoneInfo
from sqlalchemy import Uuid
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from uuid import UUID

from common_lib.db.mixins.soft_delete import SoftDeleteMixin

class BaseSoftDeleteModel(DeclarativeBase, SoftDeleteMixin):
    __abstract__ = True

    id: Mapped[UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    created_at: Mapped[datetime] = mapped_column(default=lambda: datetime.now(tz=ZoneInfo("UTC")))
    updated_at: Mapped[datetime] = mapped_column(onupdate=lambda: datetime.now(tz=ZoneInfo("UTC")))
