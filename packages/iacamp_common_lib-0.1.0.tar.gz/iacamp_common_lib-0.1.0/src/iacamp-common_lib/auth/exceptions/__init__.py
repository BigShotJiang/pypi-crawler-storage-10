from .base import RoleNotFoundError, PermissionNotFoundError

__all__ = ["RoleNotFoundError", "PermissionNotFoundError"]