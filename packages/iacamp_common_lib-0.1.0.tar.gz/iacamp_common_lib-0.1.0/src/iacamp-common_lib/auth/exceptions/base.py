from common_lib.exceptions.base import NotFoundError


class RoleNotFoundError(NotFoundError):
    def __init__(self, message="Role não encontrada."):
        super().__init__(message)

class PermissionNotFoundError(NotFoundError):
    def __init__(self, message="Permissão não encontrada."):
        super().__init__(message)