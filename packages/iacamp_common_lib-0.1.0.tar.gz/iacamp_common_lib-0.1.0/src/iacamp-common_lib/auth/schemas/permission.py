from typing import Optional

from common_lib.auth.models.permission import PermissionActionType
from common_lib.schemas.base import BaseSchema


class PermissionRead(BaseSchema):
    id: int
    resource: str
    action: PermissionActionType

class PermissionCreate(BaseSchema):
    resource: str
    action: Optional[PermissionActionType] = PermissionActionType.READ

class PermissionUpdate(BaseSchema):
    resource: Optional[str] = None
    action: Optional[PermissionActionType] = None