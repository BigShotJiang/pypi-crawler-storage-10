from typing import Optional
from uuid import UUID
from common_lib.schemas.base import BaseSchema


class RoleRead(BaseSchema):
    id: UUID
    name: str
    app_id: Optional[UUID] = None

class RoleCreate(BaseSchema):
    name: str
    parent_role_id: Optional[UUID] = None
    app_id: Optional[UUID] = None

class RoleUpdate(BaseSchema):
    name: Optional[str] = None
    parent_role_id: Optional[UUID] = None
    app_id: Optional[UUID] = None