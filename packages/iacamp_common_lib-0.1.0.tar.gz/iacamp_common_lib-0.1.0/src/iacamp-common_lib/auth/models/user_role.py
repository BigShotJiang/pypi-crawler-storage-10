from uuid import UUID
from sqlalchemy import ForeignKey, Mapped, String, Uuid, mapped_column
from sqlalchemy.orm import DeclarativeBase, relationship

class BaseUserRole(DeclarativeBase):
    __abstract__ = True
    __tablename__ = "user_roles"

    user_id: Mapped[UUID] = mapped_column(Uuid, ForeignKey("users.id"), primary_key=True)
    role_id: Mapped[UUID] = mapped_column(Uuid, ForeignKey("roles.id"), primary_key=True)
    domain: Mapped[str] = mapped_column(String(60), nullable=False)

    user = relationship("BaseUser", back_populates="roles")
    role = relationship("BaseRole", back_populates="users")