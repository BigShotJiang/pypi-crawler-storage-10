from uuid import UUID
from sqlalchemy import ForeignKey, Mapped, Uuid, mapped_column
from sqlalchemy.orm import DeclarativeBase

class BaseRolePermission(DeclarativeBase):
    __abstract__ = True
    __tablename__ = "role_permissions"

    role_id: Mapped[UUID] = mapped_column(Uuid, ForeignKey("roles.id"), primary_key=True)
    permission_id: Mapped[UUID] = mapped_column(Uuid, ForeignKey("permissions.id"), primary_key=True)