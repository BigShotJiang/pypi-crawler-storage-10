from enum import Enum
import uuid
from uuid import UUID
from sqlalchemy import Enum as SQLEnum, Mapped, Uuid, mapped_column, String, Index
from sqlalchemy.orm import relationship

from common_lib.db.models.base import BaseSoftDeleteModel

class PermissionActionType(str, Enum):
    READ = "read"
    CREATE = "create"
    EDIT = "edit"
    DELETE = "delete"

class BasePermission(BaseSoftDeleteModel):
    """Classe base genérica para Permission, que pode ser herdada.
    
    Atributos comuns:
        id: UUID único.
        resource: Recurso (ex: "agent", "menu").
        action: Enum para ação (read, create, etc.).
    
    Herança: Serviços podem adicionar fields específicos.
    """
    __abstract__ = True
    __tablename__ = "permissions"
    
    id: Mapped[UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    resource: Mapped[str] = mapped_column(String(60), nullable=False)
    action: Mapped[PermissionActionType] = mapped_column(
        SQLEnum(PermissionActionType, name="permissionactiontype"), nullable=False
    )

    roles = relationship(
        "BaseRole",
        secondary="role_permissions",
        back_populates="permissions",
    )

    __table_args__ = (Index('idx_permission_resource_action', "resource", "action", unique=True),)