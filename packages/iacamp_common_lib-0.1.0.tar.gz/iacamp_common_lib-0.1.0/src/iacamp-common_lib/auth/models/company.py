import uuid
from sqlalchemy import Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from uuid import UUID

from common_lib.db.models.base import BaseSoftDeleteModel


class BaseCompany(BaseSoftDeleteModel):
    __abstract__ = True
    __tablename__ = "companies"

    id: Mapped[UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)

    users = relationship(back_populates="company")