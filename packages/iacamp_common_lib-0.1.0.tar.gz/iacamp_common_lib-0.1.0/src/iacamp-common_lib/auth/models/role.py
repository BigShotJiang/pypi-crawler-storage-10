from typing import Optional
from uuid import UUID
import uuid
from sqlalchemy import Mapped, mapped_column, relationship, String, Uuid, Index
from sqlalchemy.orm import relationship

from common_lib.db.models.base import BaseSoftDeleteModel

class BaseRole(BaseSoftDeleteModel):
    """Classe base genérica para Role, que pode ser herdada em serviços específicos.
    
    Atributos comuns:
        id: UUID único.
        name: Nome da role.
        parent_role_id: Para herança de roles.
    
    Herança: Serviços podem adicionar fields/relationships específicos (ex: menus, users).
    """
    __abstract__ = True
    __tablename__ = "roles"
    
    id: Mapped[UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(120), nullable=False, unique=True)

    parent_role_id: Mapped[Optional[UUID]] = mapped_column(Uuid, nullable=True)

    parent_role = relationship("BaseRole", remote_side=[id], back_populates="children_roles")
    children_roles = relationship("BaseRole", back_populates="parent_role")

    users = relationship("BaseUserRole", back_populates="role")
    permissions = relationship(
        "BasePermission",
        secondary="role_permissions",
        back_populates="roles",
    )

    __table_args__ = (Index('idx_role_parent_id', "parent_role_id"),)

