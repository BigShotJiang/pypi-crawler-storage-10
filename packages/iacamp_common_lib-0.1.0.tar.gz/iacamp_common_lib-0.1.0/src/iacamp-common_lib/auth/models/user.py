import uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Uuid
from uuid import UUID

from common_lib.db.models.base import BaseSoftDeleteModel

class BaseUser(BaseSoftDeleteModel):
    __abstract__ = True
    __tablename__ = "users"

    id: Mapped[UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    company_id: Mapped[UUID] = mapped_column(Uuid, ForeignKey("companies.id"))

    company = relationship(back_populates="users")
    roles = relationship("BaseUserRole", back_populates="user")