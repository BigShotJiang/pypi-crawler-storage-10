from typing import List, Optional
from uuid import UUID

from sqlalchemy import delete, insert, select
from sqlalchemy.orm import Session
from common_lib.auth.models import BasePermission, BaseRolePermission
from common_lib.auth.repositories import BasePermissionRepository
from common_lib.auth.repositories.role import RoleRepository


class PermissionRepository(BasePermissionRepository):
    def __init__(self, session: Session):
        super().__init__(session)

    def get_permission_by_id(self, permission_id: UUID) -> Optional[BasePermission]:
        stmt = select(BasePermission).where(BasePermission.id == permission_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def get_all_permissions(self) -> List[BasePermission]:
        stmt = select(BasePermission)
        return self.session.execute(stmt).scalars().all()

    def create_permission(self, permission: BasePermission) -> BasePermission:
        self.session.add(permission)
        self.session.flush()
        return permission

    def update_permission(self, permission: BasePermission) -> BasePermission:
        self.session.merge(permission)
        return permission

    def delete_permission(self, permission: BasePermission) -> None:
        self.session.delete(permission)

    def add_permission_to_role(self, role_id: UUID, permission_id: UUID) -> None:
        stmt = insert(BaseRolePermission).values(
            role_id=role_id,
            permission_id=permission_id,
        )
        self.session.execute(stmt)
        self.session.flush()

    def remove_permission_from_role(self, role_id: UUID, permission_id: UUID) -> None:
        stmt = (
            delete(BaseRolePermission)
            .where(BaseRolePermission.role_id == role_id)
            .where(BaseRolePermission.permission_id == permission_id)
        )
        self.session.execute(stmt)
        self.session.flush()

    def get_permissions_for_role(
        self,
        role_id: UUID,
        include_inherited: bool = True,
    ) -> List[BasePermission]:
        roles_ids = [role_id]

        if include_inherited:
            role_repo = RoleRepository(self.session)
            inherited_roles = role_repo.get_inherited_roles(role_id)
            roles_ids.extend([r.id for r in inherited_roles])

        stmt = (
            select(BasePermission)
            .join(BaseRolePermission, BasePermission.id == BaseRolePermission.permission_id)
            .where(BaseRolePermission.role_id.in_(roles_ids))
        )

        result = self.session.execute(stmt)
        permissions = list(result.scalars().unique().all())
        return permissions