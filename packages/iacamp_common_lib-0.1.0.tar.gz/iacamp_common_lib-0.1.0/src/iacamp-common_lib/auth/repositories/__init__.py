from .base import BaseRoleRepository, BasePermissionRepository
from .permission import PermissionRepository
from .role import RoleRepository

__all__ = [
    "BaseRoleRepository", "BasePermissionRepository",
    "RoleRepository", "PermissionRepository"
]