from typing import List, Optional
from uuid import UUID

from sqlalchemy import delete, select
from sqlalchemy.orm import Session, aliased
from common_lib.auth.models.role import BaseRole
from common_lib.auth.models.user_role import BaseUserRole
from common_lib.auth.repositories.base import BaseRoleRepository


class RoleRepository(BaseRoleRepository):
    def __init__(self, session: Session):
        super().__init__(session)

    def get_role_by_id(self, role_id: UUID) -> Optional[BaseRole]:
        stmt = select(BaseRole).where(BaseRole.id == role_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def get_role_by_name(self, role_name: str) -> Optional[BaseRole]:
        stmt = select(BaseRole).where(BaseRole == role_name)
        return self.session.execute(stmt).scalar_one_or_none()

    def get_all_roles(self) -> List[BaseRole]:
        stmt = select(BaseRole)
        return self.session.execute(stmt).scalars().all()

    def create_role(self, role: BaseRole) -> BaseRole:
        self.session.add(role)
        self.session.flush()
        return role

    def update_role(self, role: BaseRole) -> BaseRole:
        self.session.merge(role)
        return role

    def delete_role(self, role: BaseRole) -> None:
        self.session.delete(role)

    def get_inherited_roles(self, role_id: UUID) -> List[BaseRole]:
        parent = aliased(BaseRole)
        child = aliased(BaseRole)

        base = select(child).where(child.id == role_id)
        recursive = select(parent).join(child, parent.id == child.parent_role_id)
        cte = base.union_all(recursive).cte(recursive=True)

        stmt = select(BaseRole).from_statement(select(cte))
        roles = self.session.execute(stmt).scalars().all()

        return roles[1:]
    
    def get_user_roles(self, user_id: UUID, domain: Optional[str] = None) -> List[BaseRole]:
        stmt = (
            select(BaseRole)
            .join(BaseUserRole, BaseRole.id == BaseUserRole.role_id)
            .where(BaseUserRole.user_id == user_id)
        )
        if domain:
            stmt = stmt.where(BaseUserRole.domain == domain)
        
        return self.session.execute(stmt).scalars().all()
    
    def add_role_to_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        user_role = BaseUserRole(user_id=user_id, role_id=role_id, domain=domain)
        self.session.add(user_role)
        self.session.flush()

    def remove_role_from_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        stmt = delete(BaseUserRole).where(
            BaseUserRole.user_id == user_id,
            BaseUserRole.role_id == role_id
        )
        if domain:
            stmt = stmt.where(BaseUserRole.domain == domain)
        
        self.session.execute(stmt)
        self.session.flush()