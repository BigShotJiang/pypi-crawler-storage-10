from abc import ABC, abstractmethod
from uuid import UUID
from typing import List, Optional
from auth.models import BaseRole, BasePermission
from sqlalchemy.orm import Session

class BaseRoleRepository(ABC):
    def __init__(self, session: Session) -> None:
        self.session = session

    @abstractmethod
    def get_role_by_id(self, role_id: UUID) -> Optional[BaseRole]:
        pass

    @abstractmethod
    def get_role_by_name(self, role_name: str) -> Optional[BaseRole]:
        pass

    @abstractmethod
    def get_all_roles(self) -> List[BaseRole]:
        pass

    @abstractmethod
    def create_role(self, role: BaseRole) -> BaseRole:
        pass

    @abstractmethod
    def update_role(self, role: BaseRole) -> BaseRole:
        pass

    @abstractmethod
    def delete_role(self, role: BaseRole) -> None:
        pass

    @abstractmethod
    def get_inherited_roles(self, role_id: UUID) -> List[BaseRole]:
        pass

    @abstractmethod
    def get_user_roles(self, user_id: UUID, domain: Optional[str] = None) -> List[BaseRole]:
        pass

    @abstractmethod
    def add_role_to_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        pass

    @abstractmethod
    def remove_role_from_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        pass

class BasePermissionRepository(ABC):
    def __init__(self, session: Session) -> None:
        self.session = session

    @abstractmethod
    def get_permission_by_id(self, permission_id: UUID) -> Optional[BasePermission]:
        pass

    @abstractmethod
    def get_all_permissions(self) -> List[BasePermission]:
        pass

    @abstractmethod
    def create_permission(self, permission: BasePermission) -> BasePermission:
        pass

    @abstractmethod
    def update_permission(self, permission: BasePermission) -> BasePermission:
        pass

    @abstractmethod
    def delete_permission(self, permission: BasePermission) -> None:
        pass

    @abstractmethod
    async def add_permission_to_role(self, role_id: UUID, permission_id: UUID) -> None:
        pass

    @abstractmethod
    async def remove_permission_from_role(self, role_id: UUID, permission_id: UUID) -> None:
        pass

    @abstractmethod
    async def get_permissions_for_role(self, role_id: UUID, include_inherited: bool = True) -> List[BasePermission]:
        pass