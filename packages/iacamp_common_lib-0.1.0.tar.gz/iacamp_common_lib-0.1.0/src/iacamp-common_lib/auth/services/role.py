from uuid import UUID
from typing import List, Optional

from common_lib.auth.exceptions.base import RoleNotFoundError
from common_lib.auth.models.role import BaseRole
from common_lib.auth.repositories import BaseRoleRepository
from common_lib.auth.schemas import RoleCreate, RoleUpdate

class RoleService:
    def __init__(self, repo: BaseRoleRepository):
        self.repo = repo

    def get_role_by_id(self, role_id: UUID) -> BaseRole:
        role = self.repo.get_role_by_id(role_id)
        if not role:
            raise RoleNotFoundError
        return role
    
    def get_role_by_name(self, role_name: str) -> BaseRole:
        role = self.repo.get_role_by_name(role_name)
        if not role:
            raise RoleNotFoundError
        return role
    
    def create_role(self, role_create: RoleCreate) -> BaseRole:
        role = self.repo.create_role(
            BaseRole(**role_create.model_dump(exclude_unset=True))
        )
        self.repo.session.commit()
        self.repo.session.refresh(role)
        return role
    
    def update_role(self, role_id: UUID, role_update: RoleUpdate) -> BaseRole:
        role = self.get_role_by_id(role_id)
        
        for field, value in role_update.model_dump(exclude_unset=True).items():
            setattr(role, field, value)
        
        role = self.repo.update_role(role)
        self.repo.session.commit()
        self.repo.session.refresh(role)
        return role
    
    def delete_role(self, role_id: UUID) -> None:
        role = self.get_role_by_id(role_id)  
        self.repo.delete_role(role)
        self.repo.session.commit()
    
    def get_inherited_roles(self, role_id: UUID) -> List[BaseRole]:
        return self.repo.get_inherited_roles(role_id)
    
    def get_user_roles(self, user_id: UUID, domain: Optional[str] = None) -> List[BaseRole]:
        return self.repo.get_user_roles(user_id, domain)
    
    def add_role_to_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        self.get_role_by_id(role_id)  
        self.repo.add_role_to_user(user_id, role_id, domain)
        self.repo.session.commit()

    def remove_role_from_user(self, user_id: UUID, role_id: UUID, domain: Optional[str] = None) -> None:
        self.get_role_by_id(role_id)        
        self.repo.remove_role_from_user(user_id, role_id, domain)
        self.repo.session.commit()