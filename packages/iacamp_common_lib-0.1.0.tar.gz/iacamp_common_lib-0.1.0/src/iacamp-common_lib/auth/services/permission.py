from uuid import UUID
from typing import List

from common_lib.auth.exceptions.base import PermissionNotFoundError
from common_lib.auth.models import BasePermission
from common_lib.auth.repositories import BasePermissionRepository
from common_lib.auth.schemas import PermissionCreate, PermissionUpdate

class PermissionService:
    def __init__(self, repo: BasePermissionRepository):
        self.repo = repo

    def get_permission_by_id(self, permission_id: UUID) -> BasePermission:
        permission = self.repo.get_permission_by_id(permission_id)
        if not permission:
            raise PermissionNotFoundError
        return permission
    
    def get_all_permissions(self) -> List[BasePermission]:
        return self.repo.get_all_permissions()
    
    def create_permission(self, permission_create: PermissionCreate) -> BasePermission:
        permission = self.repo.create_permission(
            BasePermission(**permission_create.model_dump())
        )
        self.repo.session.commit()
        self.repo.session.refresh(permission)
        return permission
    
    def update_permission(self, permission_id: UUID, permission_update: PermissionUpdate) -> BasePermission:
        permission = self.get_permission_by_id(permission_id)

        for field, value in permission_update.model_dump(exclude_unset=True).items():
            setattr(permission, field, value)
        
        permission = self.repo.update_permission(permission)
        self.repo.session.commit()
        self.repo.session.refresh(permission)
        return permission
    
    def delete_permission(self, permission_id: UUID) -> None:
        permission = self.get_permission_by_id(permission_id)
        self.repo.delete_permission(permission)
        self.repo.session.commit()
    
    def add_permission_to_role(self, role_id: UUID, permission_id: UUID) -> None:
        self.repo.add_permission_to_role(role_id, permission_id)
        self.repo.session.commit()
    
    def remove_permission_from_role(self, role_id: UUID, permission_id: UUID) -> None:
        self.repo.remove_permission_from_role(role_id, permission_id)
        self.repo.session.commit()
    
    def get_permissions_for_role(self, role_id: UUID, include_inherited: bool = True) -> List[BasePermission]:
        return self.repo.get_permissions_for_role(role_id, include_inherited)