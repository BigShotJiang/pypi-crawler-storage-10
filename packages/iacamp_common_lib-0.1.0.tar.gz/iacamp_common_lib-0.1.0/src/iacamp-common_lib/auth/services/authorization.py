from typing import Dict
from uuid import UUID

from common_lib.auth.models.permission import PermissionActionType
from common_lib.auth.services.permission import PermissionService
from common_lib.auth.services.role import RoleService


class AuthorizationService:
    def __init__(
        self,
        role_service: RoleService,
        permission_service: PermissionService
    ) -> None:
        self.role_service = role_service
        self.permission_service = permission_service

    def check_permission(
        self,
        user_id: UUID,
        resource: str,
        action: PermissionActionType,
        domain: str = "*",
        attributes: Dict[str, any] = None
    ) -> bool:
        """Método para verificar se usuário possui permissão necessária.

        Args:
            domain (str, optional): geralmente o ID da company ou "*".
            attributes (Dict[str, any], optional): para controle fine-grained.

        Returns:
            bool: True se possuir permissão.
        """
        roles = self.role_service.get_user_roles(user_id, domain)
        if not roles and domain != "*":
            roles = self.role_service.get_user_roles(user_id, "*")

        if not roles:
            return False

        all_perms = set()
        for role in roles:
            perms = self.permission_service.get_permissions_for_role(role.id, include_inherited=True)
            for perm in perms:
                all_perms.add((perm.resource, perm.action))

        if (resource, action) not in all_perms:
            return False

        if attributes:
            return self._check_attributes(attributes, domain, resource, action)

        return True

    def _check_attributes(
        self,
        attributes: Dict,
        domain: str,
        resource: str,
        action: PermissionActionType
    ) -> bool:
        """Método protegido para verificação fine-grained de atributos.
        
        Default: Sempre True (sem restrições). Override em subclasses para lógica custom por serviço.
        
        Args:
            attributes: Dict com attrs dinâmicos (ex: {'user_id': uuid, 'owner_id': uuid}).
            domain, resource, action: Contexto da perm para decisões condicionais.
        
        Returns:
            bool: True se permitido.
        """
        
        return True