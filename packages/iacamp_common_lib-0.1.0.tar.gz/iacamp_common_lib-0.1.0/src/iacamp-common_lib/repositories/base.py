from typing import Generic, TypeVar, Type, List, Optional
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import select

T = TypeVar("T")

class SQLAlchemyRepository(Generic[T]):
    def __init__(self, session: Session, model: Type[T]) -> None:
        self.session = session
        self.model = model

    def get_by_id(self, id_: UUID) -> Optional[T]:
        stmt = select(self.model).where(self.model.id == id_)
        return self.session.execute(stmt).scalar_one_or_none()

    def get_all(self) -> List[T]:
        stmt = select(self.model)
        return self.session.execute(stmt).scalars().all()

    def create(self, entity: T) -> T:
        self.session.add(entity)
        self.session.flush()
        return entity

    def update(self, entity: T) -> T:
        self.session.merge(entity)
        return entity

    def delete(self, id_: UUID) -> None:
        entity = self.get_by_id(id_)
        if entity:
            self.session.delete(entity)
