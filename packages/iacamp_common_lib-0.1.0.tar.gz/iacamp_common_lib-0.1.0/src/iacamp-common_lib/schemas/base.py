from datetime import date, datetime, time, timedelta, timezone
from typing import Generic, TypeVar
from pydantic import BaseModel, field_serializer

gmt3 = timezone(timedelta(hours=-3))

class BaseSchema(BaseModel):
    @field_serializer("*")
    def serialize_dates_and_times(self, value, _info):
        if isinstance(value, datetime):
            if value.tzinfo is None:
                value = value.replace(tzinfo=timezone.utc)
            value_local = value.astimezone(gmt3)
            return value_local.isoformat()
        
        elif isinstance(value, date):
            dt = datetime.combine(value, time.min, tzinfo=gmt3)
            return dt.isoformat()
        
        elif isinstance(value, time):
            return value.strftime("%H:%M:%S")
        
        return value

    class Config:
        from_attributes = True


T = TypeVar("T")
 
class PaginatedResponse(BaseModel, Generic[T]):
    total: int
    items: list[T]