# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: operation-init.j2

"""Auto-generated package that contains models used by the AccelByte Gaming Services Leaderboard Service."""

__author__ = "AccelByte"
__email__ = "dev@accelbyte.net"

# pylint: disable=line-too-long

from .create_leaderboard_conf_663810 import CreateLeaderboardConfigurationAdminV1
from .create_leaderboard_conf_8287f9 import CreateLeaderboardConfigurationPublicV1
from .delete_bulk_leaderboard_94414e import DeleteBulkLeaderboardConfigurationAdminV1
from .delete_leaderboard_conf_e6fbfe import DeleteLeaderboardConfigurationAdminV1
from .get_leaderboard_configu_dfbf1e import GetLeaderboardConfigurationAdminV1
from .get_leaderboard_configu_3c85d9 import GetLeaderboardConfigurationsAdminV1
from .get_leaderboard_configu_e27832 import GetLeaderboardConfigurationsPublicV1
from .get_leaderboard_configu_d8a38d import GetLeaderboardConfigurationsPublicV2
from .hard_delete_leaderboard_e07e01 import HardDeleteLeaderboardAdminV1
from .update_leaderboard_conf_ca626e import UpdateLeaderboardConfigurationAdminV1
