# flexivrdk/__init__.py

"""
Robotic Development Kit (RDK) for Flexiv robots.

- Main website: https://www.flexiv.com/software/rdk
- User Manual: https://www.flexiv.com/software/rdk/manual
- API Doc: https://www.flexiv.com/software/rdk/api
- GitHub: https://github.com/flexivrobotics/flexiv_rdk

"""

__version__ = "1.8.0"
__author__ = "Flexiv Ltd."

from .flexivrdk import *
