from __future__ import annotations

import re
import unicodedata
import warnings
from collections import defaultdict
from dataclasses import dataclass

import bs4


class TocEntry:
    """One entry of the table of contents"""

    def __init__(
            self,
            displayText: str,
            indent: str,
            style: str,
    ) -> None:
        self.displayText = displayText
        self.indent = indent
        self.style = style
        self.anchorLinkText: str = self._calcAnchorLinkText()

    def render(self) -> str:
        """Render the current entry as a bullet point"""
        text = self.removePoundChar(self.displayText)
        text = self.mdLinkToText(text)
        return self.indent + f'- [{text}]({self.anchorLinkText})'

    def _calcAnchorLinkText(self) -> str:
        text = self.removePoundChar(self.displayText)

        # remove HTML tags
        with warnings.catch_warnings():
            warnings.filterwarnings(
                action='ignore', category=bs4.MarkupResemblesLocatorWarning
            )
            soup = bs4.BeautifulSoup(text, 'html.parser')
            text = soup.get_text()

        return self.convertToAnchorLink(text=text, style=self.style)

    @classmethod
    def removePoundChar(cls, string: str) -> str:
        """Remove '#' characters from the start of the header"""
        return re.sub(r'^#+\s', '', string)

    @classmethod
    def mdLinkToText(cls, string: str) -> str:
        """
        Replace markdown links with their display text. E.g., [my
        site](mysite.com) -> my site
        """
        return re.sub(r'\[(.*?)]\(.*?\)', '\\1', string)

    @classmethod
    def convertToAnchorLink(
            cls,
            text: str,
            style: str,
    ) -> str:
        """Convert the given text to a markdown anchor link"""
        if style == 'gitlab':
            # remove emojis represented as :emoji_name:
            text = re.sub(r':[\w\d_]+:', '', text)

        text = text.lower()
        text = cls.mdLinkToText(text)
        text = _strip_markdown_underscore_emphasis(text)

        listOfCharGroups: list[_CharGroup] = _buildListOfCharGroups(text)
        anchorLink: str = _constructAnchorLink(listOfCharGroups)

        if style == 'gitlab':
            anchorLink = re.sub(r'-+', '-', anchorLink)

        # check last character
        anchorLink = anchorLink[:-1] if anchorLink[-1] == '-' else anchorLink

        # prepend '#' to create a URL anchor
        return '#' + anchorLink


def deduplicateAnchorLinkText(tocEntries: list[TocEntry]) -> None:
    """Duplicate the text in the anchor link, for each ToC entry"""
    allAnchorLinkTexts: list[str] = [_.anchorLinkText for _ in tocEntries]

    seen: set[str] = set()
    duplicated: set[str] = set()

    for text in allAnchorLinkTexts:
        if text not in seen:
            seen.add(text)
        else:
            duplicated.add(text)

    if len(duplicated) == 0:
        return

    counter: defaultdict[str, int] = defaultdict(int)

    which_occurrence_to_start_fixing_anchor_link: int = 2

    for entry in tocEntries:
        if entry.anchorLinkText in duplicated:
            counter[entry.anchorLinkText] += 1
            count: int = counter[entry.anchorLinkText]
            if count >= which_occurrence_to_start_fixing_anchor_link:
                entry.anchorLinkText += f'-{count - 1}'


@dataclass
class _CharGroup:
    chars: list[str]
    insideBacktickPairs: bool

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _CharGroup):
            return False

        return (
            self.chars == other.chars
            and self.insideBacktickPairs == other.insideBacktickPairs
        )

    def __hash__(self) -> int:
        return hash((tuple(self.chars), self.insideBacktickPairs))

    def reduceToOnlyOneLeadingNonAlphaNumericChars(self) -> None:
        """Reduce to only 1 leading non-alphanumeric characters"""
        flag: bool = False
        leadingNonAlphaNumericChars: list[str] = []
        otherChars: list[str] = []

        for i, char in enumerate(self.chars):
            if flag:
                break

            if _isWordChar(char):
                flag = True
                otherChars.extend(self.chars[i:])
                continue

            leadingNonAlphaNumericChars.append(char)

        self.chars = leadingNonAlphaNumericChars[-1:] + otherChars


def _isWordChar(char: str) -> bool:
    """
    Check if a char is a word character (alphanumeric, emoji, characters of
    other languages).
    """
    if char.isalnum():
        return True

    if unicodedata.category(char) == 'So':  # "Symbol, other", i.e., emoji
        return True

    return unicodedata.category(char).startswith('L')  # letters of any script


def _buildListOfCharGroups(string: str) -> list[_CharGroup]:
    result: list[_CharGroup]
    if string[0] == '`':
        result = [_CharGroup(chars=[], insideBacktickPairs=True)]
    else:
        result = [_CharGroup(chars=[string[0]], insideBacktickPairs=False)]

    isWithinBacktickPair: bool = False
    for char in string[1:]:
        if char == '`':
            isWithinBacktickPair = not isWithinBacktickPair
            result.append(
                _CharGroup(chars=[], insideBacktickPairs=isWithinBacktickPair)
            )
        else:
            result[-1].chars.append(char)

    if result[-1].chars == []:
        return result[:-1]

    return result


def _constructAnchorLink(listOfCharGroups: list[_CharGroup]) -> str:
    temp: list[str] = []
    for charGroup in listOfCharGroups:
        if not charGroup.insideBacktickPairs:
            # This is fine for both GitHub and Gitlab styles
            charGroup.reduceToOnlyOneLeadingNonAlphaNumericChars()

            # We put `strip()` before replacing " " to "-" to prevent
            # double dashes
            temp.append(''.join(charGroup.chars).strip().replace(' ', '-'))
        else:
            temp.append(''.join(charGroup.chars).strip().replace(' ', '-'))

    return re.sub(
        r'[^\w\s-]+',
        '',
        '-'.join(temp),
    )


def _strip_markdown_underscore_emphasis(text: str) -> str:
    """Remove underscore emphasis markers while keeping literal underscores."""

    def _strip(pattern: re.Pattern[str], source: str) -> str:
        previous = None
        result = source
        while previous != result:
            previous = result
            result = pattern.sub(r'\1', result)

        return result

    # Remove double underscores first to handle bold markers, then single.
    patterns = [
        re.compile(r'(?<!\w)__(?=\S)(.+?)(?<=\S)__(?!\w)'),
        re.compile(r'(?<!\w)_(?=\S)(.+?)(?<=\S)_(?!\w)'),
    ]
    for pattern in patterns:
        text = _strip(pattern, text)

    return text
