# Django Blog Package Migrations
# Initial migration file for the blog package
