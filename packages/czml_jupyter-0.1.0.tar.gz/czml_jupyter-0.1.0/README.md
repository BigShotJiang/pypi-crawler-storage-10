# czml-jupyter

This library wraps [czml3](https://pypi.org/project/czml3/) to allow rendering a czml `Document` inside a Jupyter notebook cell.

## Usage

See [the example notebook](example.ipynb).