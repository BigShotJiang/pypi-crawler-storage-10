import base64
import http.server
import os
import threading
import time
from importlib.metadata import version
from urllib.parse import parse_qs, urlparse

import czml3

__version__ = version("czml_jupyter")

_http_server_thread: threading.Thread | None = None
_http_server_port: int | None = None
_http_server_token = os.urandom(16).hex()
_ion_token: str | None = None
_cesium_host = "https://cesium.com/downloads/cesiumjs/releases/1.134"
_html_stub = """
<html>
<head>
    <script>
        window.addEventListener('message', (event) => {
            document.open();
            document.write(atob(event.data));
            document.close();
        });
    </script>
</head>
</html>
"""
_html_cesium = """
<script src="{cesium_host}/Build/Cesium/Cesium.js"></script>
<link href="{cesium_host}/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
<div id="{div_id}" style="width: 100%; height: 100%;"></div>
<script type="module">{js}</script>
"""
_html_loader = """
<div id="czmlJupyterContainer_{div_id}" style="width: 100%; height: {height};"></div>
<script>
    (function() {{
        let b64html = "{b64_html}";
        if (document.location.protocol.startsWith("http")) {{
            let container = document.getElementById("czmlJupyterContainer_{div_id}");
            container.innerHTML = atob(b64html);
            let scripts = Array.from(container.querySelectorAll('script'));
            let promises = [];
            // Replace only external scripts first
            scripts.filter(function(s) {{ return s.src; }}).forEach(function(oldEl) {{
                let newEl = document.createElement('script');
                if (oldEl.type) newEl.type = oldEl.type;
                newEl.src = oldEl.src;
                promises.push(new Promise(function(resolve) {{
                    newEl.onload = resolve;
                    newEl.onerror = resolve;
                }}));
                oldEl.parentNode.replaceChild(newEl, oldEl);
            }});
            Promise.all(promises).then(function() {{
                // Now execute inline scripts
                let inlineScripts = Array.from(container.querySelectorAll('script')).filter(function(s) {{ return !s.src; }});
                inlineScripts.forEach(function(script) {{
                    let newScript = document.createElement('script');
                    if (script.type) newScript.type = script.type;
                    newScript.textContent = script.textContent;
                    script.parentNode.replaceChild(newScript, script);
                }});
            }});
        }} else {{
            const iframe = document.createElement("iframe");
            iframe.style.border = "none";
            iframe.style.width = "100%";
            iframe.style.height = "100%";
            iframe.src = "http://localhost:{port}/?token={token}";
            document.getElementById("czmlJupyterContainer_{div_id}").appendChild(iframe);
            iframe.onload = function() {{
                iframe.contentWindow.postMessage(b64html, "*");
            }}
        }}
    }})();
</script>
"""
_js_ion_token = 'Cesium.Ion.defaultAccessToken = "{token}";'
_js_load_czml = "viewer.dataSources.add(Cesium.CzmlDataSource.load({czml}));"
_js_default_init = "const viewer = new Cesium.Viewer('{div_id}');"


def set_ion_token(token: str):
    """
    Set the Cesium Ion token to be used in all Document instances.

    :param token: The Cesium Ion token.
    """
    global _ion_token
    _ion_token = token


def set_cesium_host(host: str):
    """
    Set the CesiumJS host URL from where CesiumJS is loaded.

    :param host: The CesiumJS host URL.
    """
    global _cesium_host
    _cesium_host = host.rstrip("/")


class _StubRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):

        token = parse_qs(urlparse(self.path).query).get("token", [None])[0]

        if token != _http_server_token:
            self.send_response(403)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Forbidden")
            return

        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(_html_stub.encode())

    def log_message(self, *args, **kwargs) -> None:
        pass


def _http_server():
    """A simple HTTP server that only serves the HTML stub."""
    global _http_server_port
    server = http.server.HTTPServer(("localhost", 0), _StubRequestHandler)
    _http_server_port = server.server_address[1]
    server.serve_forever()


def _start_http_server():
    """Start a simple HTTP server in a background thread that only serves the HTML stub."""
    global _http_server_thread
    if _http_server_thread is not None:
        return

    _http_server_thread = threading.Thread(target=_http_server)
    _http_server_thread.start()

    while _http_server_port is None:
        time.sleep(0.1)


class Document(czml3.Document):
    _init_js: str | None = None

    def setup_cesium(self, init_js: str | None = None):
        """
        Set up cesium with custom settings.

        :param init_js: Custom JavaScript code to initialize the Cesium viewer.
            Use the placeholder `{div_id}` to refer to the div ID where the
            viewer should be initialized. Since .format() is used, double curly
            braces `{{` and `}}` must be used to emit single curly braces in
            the final JavaScript code.
        """
        self._init_js = init_js

    def _repr_html_(self) -> str:
        _start_http_server()

        div_id = os.urandom(8).hex()

        js = "(function() {"
        if _ion_token is not None:
            js += _js_ion_token.format(token=_ion_token) + "\n"
        js += (self._init_js or _js_default_init).format(div_id=div_id)
        js += "\n"
        js += _js_load_czml.format(czml=self.dumps())
        js += "})()"

        html = _html_cesium.format(cesium_host=_cesium_host, js=js, div_id=div_id)

        return _html_loader.format(
            b64_html=base64.b64encode(html.encode()).decode(),
            port=_http_server_port,
            token=_http_server_token,
            div_id=div_id,
            height="600px",
        )
