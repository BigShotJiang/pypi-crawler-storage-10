import os
import sys

CURRENT_DIR = os.path.dirname(__file__)
SRC_DIR = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from unieai_mcp_bookingroom.server import run_http

if __name__ == "__main__":
    print("Starting meeting-room-api HTTP server... Open Swagger at http://127.0.0.1:8000/docs")
    run_http("127.0.0.1", 8000)
