"""
    ha_services
    Helpers to send periodic information via MQTT to Home Assistant
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '2.15.1'
__author__ = 'Jens Diemer <github@jensdiemer.de>'
