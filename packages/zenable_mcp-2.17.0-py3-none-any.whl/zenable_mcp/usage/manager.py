"""Usage data management for zenable_mcp commands."""

import json
import os
import sys
from datetime import datetime, timezone
from http.client import HTTPException

import click
import requests

from zenable_mcp import __version__
from zenable_mcp.constants import OAUTH_TOKEN_CACHE_DIR
from zenable_mcp.logging.logged_echo import echo
from zenable_mcp.logging.persona import Persona
from zenable_mcp.usage.fingerprint import get_system_fingerprint
from zenable_mcp.usage.models import (
    UsageEventData,
    ZenableMcpUsagePayload,
)
from zenable_mcp.usage.sender import send_usage_data
from zenable_mcp.utils.install_status import InstallResult

# Base Zenable URL (override with ZENABLE_URL env var)
_zenable_url = os.environ.get("ZENABLE_URL", "https://www.zenable.app").rstrip("/")

# Private usage API endpoint
_usage_api = f"{_zenable_url}/api/data/usage"

# Timeout for authenticated usage requests (in seconds)
AUTH_REQUEST_TIMEOUT = 5


def is_usage_enabled() -> bool:
    """
    Check if usage data collection is enabled.

    Returns:
        True if usage data collection is enabled, False if disabled via environment variable
    """
    return os.environ.get("ZENABLE_DISABLE_USAGE_TRACKING", "").lower() not in (
        "1",
        "true",
        "yes",
    )


def get_jwt_token_from_cache() -> str | None:
    """
    Extract JWT token from OAuth cache if available.

    Returns:
        JWT token string if available, None otherwise
    """
    try:
        # Check OAuth cache directory
        if not OAUTH_TOKEN_CACHE_DIR.exists():
            return None

        # Look for token file (FastMCP naming convention)
        # FastMCP stores tokens in files like "mcp_zenable_app.json"
        token_files = list(OAUTH_TOKEN_CACHE_DIR.glob("*.json"))

        for token_file in token_files:
            try:
                with open(token_file, encoding="utf-8") as f:
                    token_data = json.load(f)
                    # FastMCP stores tokens in nested structure: data.token_payload.access_token
                    if "data" in token_data and "token_payload" in token_data["data"]:
                        payload = token_data["data"]["token_payload"]
                        token = payload.get("access_token") or payload.get("id_token")
                        if token:
                            return token
                    # Fallback to top-level keys for compatibility
                    token = token_data.get("access_token") or token_data.get("id_token")
                    if token:
                        return token
            except Exception:
                continue

        return None

    except Exception:
        return None


def send_authenticated_usage(
    command_name: str,  # "check" or "hook"
    usage_data: dict,
    jwt_token: str | None,
) -> None:
    """
    Send usage data to authenticated data_api endpoint.

    Args:
        command_name: Command name ("check" or "hook")
        usage_data: Usage data dictionary
        jwt_token: JWT token from OAuth flow (if available)
    """
    if not jwt_token:
        return

    try:
        # Determine integration identifier
        integration = f"zenable_mcp/{command_name}"

        # Build request body
        request_body = {
            "integration": integration,
            "usage_data": usage_data,
        }

        # Send with JWT authentication
        response = requests.post(
            _usage_api,
            json=request_body,
            headers={
                "Authorization": f"Bearer {jwt_token}",
                "Content-Type": "application/json",
            },
            timeout=AUTH_REQUEST_TIMEOUT,
        )

        # Log response (2xx = success)
        if 200 <= response.status_code < 300:
            echo(
                f"Authenticated usage data sent successfully (HTTP {response.status_code})",
                persona=Persona.DEVELOPER,
            )
        else:
            echo(
                f"Authenticated usage tracking failed: HTTP {response.status_code}",
                err=True,
                persona=Persona.DEVELOPER,
            )

    except (
        requests.exceptions.Timeout,
        requests.exceptions.ConnectionError,
        HTTPException,
        json.JSONDecodeError,
        Exception,
    ):
        pass


def extract_command_info(ctx: click.Context) -> tuple[str, list[str]]:
    """
    Extract command name and arguments from click context.

    Args:
        ctx: Click context from command execution

    Returns:
        Tuple of (command_string, command_args_list)
        command_args_list is CLI-style args like ["--dry-run", "--global"]
    """
    # Build command string from context
    command_parts = []
    current_ctx = ctx

    # Walk up the context chain to build full command
    while current_ctx:
        if current_ctx.info_name:
            command_parts.insert(0, current_ctx.info_name)
        current_ctx = current_ctx.parent

    command_string = " ".join(command_parts)

    # Extract command arguments from sys.argv
    # Parse sys.argv directly to capture all flags regardless of position
    # This is more reliable than Click context after subcommands finish
    command_args = []

    # Build set of command names we know about
    command_names = set(command_parts)
    if ctx.invoked_subcommand:
        command_names.add(ctx.invoked_subcommand)

    # Parse all of sys.argv, collecting flags and their values
    # Skip: program name (index 0) and command names
    skip_next = False

    for i, arg in enumerate(sys.argv):
        # Skip program name
        if i == 0:
            continue

        # Skip if this arg is a value we already processed
        if skip_next:
            skip_next = False
            continue

        # Check if this is a flag
        if arg.startswith("-"):
            # This is a flag - add it
            command_args.append(arg)

            # Check if next arg is a value (not a flag and not a command)
            if i + 1 < len(sys.argv):
                next_arg = sys.argv[i + 1]
                # Normalize next_arg to check if it's a command
                normalized_next = next_arg.split("/")[-1]

                # If next is not a flag and not a command name, it's a value
                if (
                    not next_arg.startswith("-")
                    and normalized_next not in command_names
                ):
                    command_args.append(next_arg)
                    skip_next = True

    return command_string, command_args


def _map_command_to_activity_type(command_name: str) -> str:
    """Map command name to activity_type."""
    mapping = {
        "check": "check",
        "hook": "hook",
        "install": "install_mcp",  # will be more specific in the future
    }
    return mapping.get(command_name, command_name)


def record_command_usage(
    ctx: click.Context,
    results: list[InstallResult] | None = None,
    duration_ms: int | None = None,
    error: Exception | None = None,
    **kwargs,
) -> None:
    """
    Record usage data for a zenable_mcp command.

    Sends usage data to the appropriate API endpoint:
    - check/hook commands → /api/data/usage (authenticated, requires JWT)
    - install commands with results → /api/public/usage (with IDE operations)
    - all other commands → /api/public/usage (with duration tracking)

    Args:
        ctx: Click context from command execution
        results: Optional list of InstallResult objects from IDE operations
        duration_ms: Command execution duration in milliseconds
        error: Optional exception if command failed
        **kwargs: Additional data to include (e.g., loc, finding_suggestion, conformance metrics)
    """
    # Check if usage data collection is disabled
    if not is_usage_enabled():
        return

    try:
        # Get system fingerprint
        system_info, system_hash = get_system_fingerprint()

        # Extract command info
        command_string, command_args = extract_command_info(ctx)

        # Determine command name and activity type
        command_name = ctx.info_name  # "check", "hook", "install"
        activity_type = _map_command_to_activity_type(command_name)

        # Determine event type and outcome
        if error:
            event = "completed"  # still completed, just with error
            error_message = str(error)
        else:
            event = "completed"
            error_message = None

        # Default duration if not provided
        if duration_ms is None:
            duration_ms = 0

        # Determine which endpoint to use based on command type
        is_check_or_hook = command_name in ["check", "hook"]

        # Get JWT token for authenticated endpoints
        jwt_token = get_jwt_token_from_cache()

        # 1. Send to authenticated data_api endpoint (for check/hook only)
        if is_check_or_hook:
            # Check/hook always use data API if token is available
            if jwt_token:
                # Build legacy format for authenticated endpoint
                usage_data = {
                    "command": command_string,
                    "command_args": command_args,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "success": error is None,
                    "error_message": error_message,
                    "zenable_mcp_version": __version__,
                    "duration_ms": duration_ms,
                    "loc": kwargs.get("loc", 0),
                    "finding_suggestion": kwargs.get("finding_suggestion", 0),
                }

                # Add metrics
                for metric in [
                    "passed_checks",
                    "failed_checks",
                    "warning_checks",
                    "total_checks_run",
                    "total_files_checked",
                ]:
                    if metric in kwargs:
                        usage_data[metric] = kwargs[metric]

                send_authenticated_usage(command_name, usage_data, jwt_token)

        # 2. Send to public API (for all non-check/hook commands)
        else:
            # For install commands, we don't have detailed structured data yet
            # Send None for data field until proper install tracking is implemented
            # The server has strict schemas for each event type's data field
            usage_event = UsageEventData(
                activity_type=activity_type,
                event=event,
                timestamp=datetime.now(timezone.utc),
                duration_ms=duration_ms,
                command_args=command_args,
                zenable_mcp_version=__version__,
                data=None,
            )

            payload = ZenableMcpUsagePayload(
                system_info=system_info,
                system_hash=system_hash,
                usage_data=usage_event,
            )

            send_usage_data(payload)

    except Exception as e:
        # Never fail the main command due to usage data errors
        echo(
            f"Failed to record usage data: {type(e).__name__}: {e}",
            err=True,
            persona=Persona.DEVELOPER,
        )
