# InnerLoop

Python SDK for invoking the [OpenCode](https://opencode.ai/) coding CLI in a headless, non-interactive manner.

Supports:

- Synchronous and Asynchronous modes
- Structured outputs using Pydantic models
- Sessions for multiple invocations with shared context
- Permission configuration for reading, writing, web, and bash tools
- Configurable working directory per loop, session, or call


## Installation

You can install `innerloop` using `uv` (recommended) or `pip`.

```bash
# Using uv
uv pip install innerloop

# Using pip
pip install innerloop
```

## Prerequisites

**InnerLoop requires the OpenCode CLI.** Install it and ensure `opencode` is on your PATH:

```bash
opencode --version
```

If the command fails, install OpenCode from [opencode.ai](https://opencode.ai/) and add it to your PATH.

See the [OpenCode documentation](https://opencode.ai/docs/) for installation instructions.

## Usage

<!-- BEGIN USAGE -->
### Basic Invoke

```python
from innerloop import Loop

loop = Loop(model="anthropic/claude-haiku-4-5")
response = loop.run("Say hello, one short line.")
print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92d7dddffebyAbR3zJ7Fu0bb",
    "input": "Say hello, one short line.",
    "output": "Hello! How can I help you with your code today?",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856358761,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856358762,
            "type": "text",
            "text": "Hello! How can I help you with your code today?"
        },
        {
            "seq": 3,
            "timestamp": 1761856358793,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856356669,
        "end": 1761856360212
    },
    "event_count": 3
}
```
</details>

### Tool Use

```python
from innerloop import Loop, allow

loop = Loop(
    model="anthropic/claude-haiku-4-5",
    perms=allow("bash"),
)
response = loop.run("Use bash: ls -1")
print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92d6fffffeWEGDeM5oQZUscp",
    "input": "Use bash: ls -1",
    "output": "Here's the directory listing:\n\n```\nAGENTS.md\nCLAUDE.md\nLICENSE\nMakefile\nREADME.md\ncoverage.xml\ndocs\nhtmlcov\nmkdocs.yml\nopencode.json\nplan.md\npyproject.toml\nscripts\nsdlc\nsite\nsrc\ntests\nuv.lock\nvendor\n```",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856363079,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856363081,
            "type": "tool_use",
            "output": "AGENTS.md\nCLAUDE.md\nLICENSE\nMakefile\nREADME.md\ncoverage.xml\ndocs\nhtmlcov\nmkdocs.yml\nopencode.json\npl… (truncated)",
            "status": "completed",
            "tool": "bash"
        },
        {
            "seq": 3,
            "timestamp": 1761856363108,
            "type": "step_finish"
        },
        {
            "seq": 4,
            "timestamp": 1761856365234,
            "type": "step_start"
        },
        {
            "seq": 5,
            "timestamp": 1761856365237,
            "type": "text",
            "text": "Here's the directory listing:\n\n```\nAGENTS.md\nCLAUDE.md\nLICENSE\nMakefile\nREADME.md\ncoverage.xml\ndocs\nhtmlcov\nmkdocs.yml\nopencode.json\nplan.md\npyproject.toml\nscripts\nsdlc\nsite\nsrc\ntests\nuv.lock\nvendor\n```"
        },
        {
            "seq": 6,
            "timestamp": 1761856365289,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856360213,
        "end": 1761856369226
    },
    "event_count": 6
}
```
</details>

### Working Directory

```python
from innerloop import Loop, allow

loop = Loop(
    model="anthropic/claude-haiku-4-5",
    perms=allow("bash"),
)
loop.default_workdir = "src/innerloop"
with loop.session() as s:
    r = s("Use bash: ls -1")
    print(r.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92d4cccffeDWjoNUt3A5gVJK",
    "input": "Summarize this folder: count *.py, sum lines, and report the\nlargest file by lines and by bytes. Use wc/rg/stat as needed.\nKeep output short as monospaced text.",
    "output": "```\nPython Files Summary\n═══════════════════════════════════════════════════════════\nCount:            16 files\nTotal Lines:      1,957 lines\nLargest (lines):  proc.py (1,957 lines)\nLargest (bytes):  proc.py (12,031 bytes)\n```",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856371649,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856371651,
            "type": "text",
            "text": "I'll analyze the Python files in this folder using command-line tools."
        },
        {
            "seq": 3,
            "timestamp": 1761856372089,
            "type": "tool_use",
            "output": "      16\n",
            "status": "completed",
            "tool": "bash"
        },
        {
            "seq": 4,
            "timestamp": 1761856372151,
            "type": "tool_use",
            "output": "    1957 total\n",
            "status": "completed",
            "tool": "bash"
        },
        {
            "seq": 5,
            "timestamp": 1761856372656,
            "type": "tool_use",
            "output": "    1957 total\n",
            "status": "completed",
            "tool": "bash"
        },
        {
            "seq": 6,
            "timestamp": 1761856373103,
            "type": "tool_use",
            "output": "12031 /Users/ian/jarvis/innerloop/src/innerloop/proc.py\n",
            "status": "completed",
            "tool": "bash"
        },
        {
            "seq": 7,
            "timestamp": 1761856373144,
            "type": "step_finish"
        },
        {
            "seq": 8,
            "timestamp": 1761856374904,
            "type": "step_start"
        },
        {
            "seq": 9,
            "timestamp": 1761856375331,
            "type": "text",
            "text": "```\nPython Files Summary\n═══════════════════════════════════════════════════════════\nCount:            16 files\nTotal Lines:      1,957 lines\nLargest (lines):  proc.py (1,957 lines)\nLargest (bytes):  proc.py (12,031 bytes)\n```"
        },
        {
            "seq": 10,
            "timestamp": 1761856375470,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856369227,
        "end": 1761856376672
    },
    "event_count": 10
}
```
</details>

### Asynchronous

```python
import asyncio
from innerloop import Loop

async def main():
    loop = Loop(model="anthropic/claude-haiku-4-5")
    async with loop.asession() as s:
        await s("Remember this number: 42")
        response = await s("What was the number?")
        print(response.model_dump_json(indent=4))

asyncio.run(main())
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92d2fb6ffeTnY0FwL7YXf7kF",
    "input": "What was the number?",
    "output": "The number you asked me to remember was **42**.",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856382077,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856382248,
            "type": "text",
            "text": "The number you asked me to remember was **42**."
        },
        {
            "seq": 3,
            "timestamp": 1761856382310,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856380329,
        "end": 1761856383159
    },
    "event_count": 3
}
```
</details>

### Sessions

```python
from innerloop import Loop

loop = Loop(model="anthropic/claude-haiku-4-5")
with loop.session() as s:
    s("Please remember this word for me: avocado")
    response = s("What was the word I asked you to remember?")
    print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92d165cffemz0drFtoTO6G6z",
    "input": "What was the word I asked you to remember?",
    "output": "The word you asked me to remember was **avocado**.",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856389940,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856390113,
            "type": "text",
            "text": "The word you asked me to remember was **avocado**."
        },
        {
            "seq": 3,
            "timestamp": 1761856390191,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856388036,
        "end": 1761856391235
    },
    "event_count": 3
}
```
</details>

### Structured Output

```python
from innerloop import Loop, allow
from pydantic import BaseModel

class HNStory(BaseModel):
    title: str
    url: str
    points: int
    comments: int

class HNTop(BaseModel):
    stories: list[HNStory]

loop = Loop(
    model="anthropic/claude-haiku-4-5",
    perms=allow(webfetch=True),
)

prompt = (
    "Using web search, find the current top 5 stories on Hacker News.\n"
    "Prefer news.ycombinator.com (front page or item pages). For each,\n"
    "return: title, url, points (int), comments (int). Output JSON with\n"
    "a 'stories' array. If counts are missing, open the item page and\n"
    "extract them. Keep titles unmodified.\n"
)
response = loop.run(prompt, response_format=HNTop)
print(response.model_dump_json(indent=4))
```

Note: This example uses webfetch and external sites; output may vary.


<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92cf6cbffeIjWxdsFlMnn0S5",
    "input": "Using web search, find the current top 5 stories on Hacker News.\nPrefer news.ycombinator.com (front page or item pages). For each,\nreturn: title, url, points (int), comments (int). Output JSON with\na 'stories' array. If counts are missing, open the item page and\nextract them. Keep titles unmodified.\n",
    "output": {
        "stories": [
            {
                "title": "Affinity Studio now free",
                "url": "https://www.affinity.studio/get-affinity",
                "points": 498,
                "comments": 392
            },
            {
                "title": "The ear does not do a Fourier transform",
                "url": "https://www.dissonances.blog/p/the-ear-does-not-do-a-fourier-transform",
                "points": 197,
                "comments": 71
            },
            {
                "title": "Jujutsu at Google [video]",
                "url": "https://www.youtube.com/watch?v=v9Ob5yPpC0A",
                "points": 45,
                "comments": 10
            },
            {
                "title": "Minecraft HDL, an HDL for Redstone",
                "url": "https://github.com/itsfrank/MinecraftHDL",
                "points": 45,
                "comments": 4
            },
            {
                "title": "TruthWave – A platform for corporate whistleblowers",
                "url": "https://www.truthwave.com",
                "points": 28,
                "comments": 9
            }
        ]
    },
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856393572,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856393573,
            "type": "text",
            "text": "I'll fetch the top stories from Hacker News for you."
        },
        {
            "seq": 3,
            "timestamp": 1761856393844,
            "type": "tool_use",
            "output": "<html lang=\"en\" op=\"news\"><head><meta name=\"referrer\" content=\"origin\"><meta name=\"viewport\" content… (truncated)",
            "status": "completed",
            "tool": "webfetch"
        },
        {
            "seq": 4,
            "timestamp": 1761856393876,
            "type": "step_finish"
        },
        {
            "seq": 5,
            "timestamp": 1761856395187,
            "type": "step_start"
        },
        {
            "seq": 6,
            "timestamp": 1761856398848,
            "type": "text",
            "text": "I have the data from the Hacker News front page. All the top 5 stories have their points and comments counts already visible. Let me extract the top 5:\n\n1. \"Affinity Studio now free\" - 498 points, 392 comments\n2. \"The ear does not do a Fourier transform\" - 197 points, 71 comments\n3. \"Jujutsu at Google [video]\" - 45 points, 10 comments\n4. \"Minecraft HDL, an HDL for Redstone\" - 45 points, 4 comments\n5. \"TruthWave – A platform for corporate whistleblowers\" - 28 points, 9 comments\n\n```json\n{\n  \"stories\": [\n    {\n      \"title\": \"Affinity Studio now free\",\n      \"url\": \"https://www.affinity.studio/get-affinity\",\n      \"points\": 498,\n      \"comments\": 392\n    },\n    {\n      \"title\": \"The ear does not do a Fourier transform\",\n      \"url\": \"https://www.dissonances.blog/p/the-ear-does-not-do-a-fourier-transform\",\n      \"points\": 197,\n      \"comments\": 71\n    },\n    {\n      \"title\": \"Jujutsu at Google [video]\",\n      \"url\": \"https://www.youtube.com/watch?v=v9Ob5yPpC0A\",\n      \"points\": 45,\n      \"comments\": 10\n    },\n    {\n      \"title\": \"Minecraft HDL, an HDL for Redstone\",\n      \"url\": \"https://github.com/itsfrank/MinecraftHDL\",\n      \"points\": 45,\n      \"comments\": 4\n    },\n    {\n      \"title\": \"TruthWave – A platform for corporate whistleblowers\",\n      \"url\": \"https://www.truthwave.com\",\n      \"points\": 28,\n      \"comments\": 9\n    }\n  ]\n}\n```"
        },
        {
            "seq": 7,
            "timestamp": 1761856398904,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856391237,
        "end": 1761856400815
    },
    "event_count": 7
}
```
</details>

### Providers — LM Studio (local)

```python
from innerloop import Loop

loop = Loop(
    model="lmstudio/google/gemma-3n-e4b",
    providers={
        "lmstudio": {
            "options": {"baseURL": "http://127.0.0.1:1234/v1"}
        },
    },
)

response = loop.run("hi")
print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92cd165ffeCd13TmoI9psWhG",
    "input": "hi",
    "output": "Okay, I understand the environment and project structure. I'm ready to assist with questions or code explanations related to this project, keeping in mind the guidelines and security considerations outlined.\n\nPlease feel free to ask your question. I will do my best to provide a helpful and safe response, adhering to the principles of not assisting with potentially malicious code.",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856404631,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856406235,
            "type": "text",
            "text": "Okay, I understand the environment and project structure. I'm ready to assist with questions or code explanations related to this project, keeping in mind the guidelines and security considerations outlined.\n\nPlease feel free to ask your question. I will do my best to provide a helpful and safe response, adhering to the principles of not assisting with potentially malicious code."
        },
        {
            "seq": 3,
            "timestamp": 1761856406267,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856400816,
        "end": 1761856406862
    },
    "event_count": 3
}
```
</details>

### MCP — Remote server (Context7)

```python
from innerloop import Loop, mcp

loop = Loop(
    model="anthropic/claude-sonnet-4-5",
    mcp=mcp(context7="https://mcp.context7.com/mcp"),
)
prompt = (
    "Use the context7 MCP server to search for FastAPI's latest "
    "async database patterns. Summarize in 2-3 sentences."
)
response = loop.run(prompt)
print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92cb9c6ffew63JGemYgS85FM",
    "input": "Use the context7 MCP server to search for FastAPI's latest async database patterns. Summarize in 2-3 sentences.",
    "output": "Based on FastAPI's latest documentation, async database patterns center around dependency injection with `yield` for resource management. The recommended pattern uses `async def get_session()` with `try/yield/finally` blocks to ensure database sessions are properly created before requests and closed afterward, even if exceptions occur. FastAPI integrates seamlessly with SQLModel/SQLAlchemy async sessions through `Annotated` dependencies (e.g., `SessionDep = Annotated[Session, Depends(get_session)]`), enabling clean separation of concerns while maintaining connection safety across async endpoints.",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856410054,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856410628,
            "type": "text",
            "text": "I'll search for FastAPI's latest async database patterns using the Context7 MCP server."
        },
        {
            "seq": 3,
            "timestamp": 1761856411079,
            "type": "tool_use",
            "output": "Available Libraries (top matches):\n\nEach result includes:\n- Library ID: Context7-compatible identifi… (truncated)",
            "status": "completed",
            "tool": "context7_resolve_library_id"
        },
        {
            "seq": 4,
            "timestamp": 1761856411109,
            "type": "step_finish"
        },
        {
            "seq": 5,
            "timestamp": 1761856414585,
            "type": "step_start"
        },
        {
            "seq": 6,
            "timestamp": 1761856415816,
            "type": "tool_use",
            "output": "### FastAPI Dependency with `yield` and `async with` (Python)\n\nSource: https://github.com/fastapi/fa… (truncated)",
            "status": "completed",
            "tool": "context7_get_library_docs"
        },
        {
            "seq": 7,
            "timestamp": 1761856415845,
            "type": "step_finish"
        },
        {
            "seq": 8,
            "timestamp": 1761856418066,
            "type": "step_start"
        },
        {
            "seq": 9,
            "timestamp": 1761856421451,
            "type": "text",
            "text": "Based on FastAPI's latest documentation, async database patterns center around dependency injection with `yield` for resource management. The recommended pattern uses `async def get_session()` with `try/yield/finally` blocks to ensure database sessions are properly created before requests and closed afterward, even if exceptions occur. FastAPI integrates seamlessly with SQLModel/SQLAlchemy async sessions through `Annotated` dependencies (e.g., `SessionDep = Annotated[Session, Depends(get_session)]`), enabling clean separation of concerns while maintaining connection safety across async endpoints."
        },
        {
            "seq": 10,
            "timestamp": 1761856421618,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856406863,
        "end": 1761856423008
    },
    "event_count": 10
}
```
</details>

### MCP — Local server (BioMCP)

```python
from innerloop import Loop, mcp

loop = Loop(
    model="anthropic/claude-sonnet-4-5",
    mcp=mcp(biomcp="uvx --from biomcp-python biomcp run"),
)
prompt = (
    "Use the biomcp MCP server to search for information about the "
    "BRAF V600E mutation. Summarize therapies in 3-4 sentences."
)
response = loop.run(prompt)
print(response.model_dump_json(indent=4))
```

<details>
  <summary>JSON Output</summary>

```json
{
    "session_id": "ses_5c92c7a90ffenVGK0dvM6xjBik",
    "input": "Use the biomcp MCP server to search for information about the BRAF V600E mutation. Tell me what cancer types it's associated with and what drug therapies target it. Keep response to 3-4 sentences.",
    "output": "I don't have access to the biomcp MCP server in this environment. MCP (Model Context Protocol) servers need to be configured and installed separately for the OpenCode CLI to use them.\n\nTo use biomcp, you would need to:\n1. Install the biomcp MCP server\n2. Configure it in your OpenCode settings (typically in `opencode.json` or via environment configuration)\n3. Then the server's tools would become available during sessions\n\nIf you'd like help setting up MCP servers with OpenCode, I can guide you through that process, or you can refer to the OpenCode documentation on providers and MCP integration.",
    "attempts": 1,
    "events": [
        {
            "seq": 1,
            "timestamp": 1761856426764,
            "type": "step_start"
        },
        {
            "seq": 2,
            "timestamp": 1761856430143,
            "type": "text",
            "text": "I don't have access to the biomcp MCP server in this environment. MCP (Model Context Protocol) servers need to be configured and installed separately for the OpenCode CLI to use them.\n\nTo use biomcp, you would need to:\n1. Install the biomcp MCP server\n2. Configure it in your OpenCode settings (typically in `opencode.json` or via environment configuration)\n3. Then the server's tools would become available during sessions\n\nIf you'd like help setting up MCP servers with OpenCode, I can guide you through that process, or you can refer to the OpenCode documentation on providers and MCP integration."
        },
        {
            "seq": 3,
            "timestamp": 1761856430226,
            "type": "step_finish"
        }
    ],
    "time": {
        "start": 1761856423008,
        "end": 1761856431635
    },
    "event_count": 3
}
```
</details>
<!-- END USAGE -->
