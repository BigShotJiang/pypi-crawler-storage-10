from he_kit.core.conf import DefaultSettings


class Settings(DefaultSettings):
    DEBUG: bool = True


settings = Settings()
