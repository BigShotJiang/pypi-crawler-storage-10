# -*- coding: utf-8 -*-
# File: CliSelf/SBself/core/core_cmds.py
# -*- coding: utf-8 -*-
# File: CliSelf/SBself/core/core_cmds.py
"""
Ultra-Status v7 — نسخه فارسی، فقط وضعیت کلی و قابلیت‌ها

✅ کاملاً فارسی
✅ حذف سیستم و شبکه
✅ نمایش جزئیات کامل قابلیت‌ها
"""

import os, sys, time, json, asyncio, locale, socket, platform
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple

try:
    import psutil  # type: ignore
except Exception:
    psutil = None  # type: ignore

try:
    from pyrogram import Client
except Exception:
    Client = None  # type: ignore

from ..config import AllConfig, _reset_state_to_defaults

START_TIME = time.time()
# =============================
# 🧰 Core commands
# =============================

async def ping(client: Optional[Client]=None, chat_id: Optional[int]=None) -> str:
    t0=time.perf_counter()
    api_ms=None
    try:
        if client: 
            await client.get_me()
            api_ms=(time.perf_counter()-t0)*1000
    except Exception: pass
    parts=["PONG"]
    if api_ms: parts.append(f"\n• API: {api_ms:.0f} ms")
    return "".join(parts)

async def uptime() -> str:
    return f"⏱ Uptime: {_human_dt(time.time()-START_TIME)}"

async def restart() -> str:
    try: return _reset_state_to_defaults()
    except Exception as e: return f"⚠️ Restart error: {e}"

async def shutdown() -> str:
    os._exit(0)


# =============================
# 🔧 ابزارهای کمکی
# =============================

def _human_dt(seconds: float) -> str:
    if seconds < 0: seconds = 0
    d, rem = divmod(int(seconds), 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    return f"{d}d {h:02}h {m:02}m {s:02}s" if d else f"{h:02}h {m:02}m {s:02}s"

def _fmt_bool(x): return "✅ فعال" if bool(x) else "❌ غیرفعال"

def _fmt_bytes(n: Optional[float]) -> str:
    if n is None: return "—"
    for u in ["B","KB","MB","GB","TB"]:
        if n < 1024: return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"

def _safe_get(d, k, default=None):
    try: return d.get(k, default)
    except Exception: return default

def _truncate_list(items: List[Any], limit=5) -> str:
    if not items: return "—"
    items=list(items)
    return ", ".join(map(str, items[:limit])) + (f" و {len(items)-limit} مورد دیگر" if len(items)>limit else "")

# =============================
# 🧠 اطلاعات پایه
# =============================

def _collect_environment() -> List[Tuple[str,str]]: 
    sys_ver = f"{platform.system()} {platform.release()}"
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    return [ 
        ("سیستم‌عامل", sys_ver),
        ("نسخه پایتون", py_ver),
        ("زمان اجرا", _human_dt(time.time() - START_TIME)),
    ]

# =============================
# ⚙️ قابلیت‌ها
# =============================

def _collect_features(cfg: Dict[str, Any]) -> List[Tuple[str, str]]:
    spammer = cfg.get("spammer", {})
    spam_msg = cfg.get("spammer_msg", {})
    timer = cfg.get("timer", {})
    enemy = cfg.get("enemy", {})
    rename = cfg.get("rename_scheduler", {})
    backup = cfg.get("backup", {})
    media = cfg.get("media", {})
    rate = cfg.get("rate_limit", {})

    rows: List[Tuple[str,str]] = []

    # 🎯 اسپمر کلی
    rows.append(("اسپمر کلی", _fmt_bool(spammer.get("enabled", False))))
    rows.append(("صف اسپمر", str(len(spammer.get("queue", []) or []))))
    rows.append(("تعداد ارسال موفق", str(spammer.get("sent_count", 0))))
    rows.append(("تعداد خطا", str(spammer.get("error_count", 0))))
    rows.append(("سرعت ارسال", f"{spammer.get('rate_per_sec', 0)} پیام/ثانیه"))
    rows.append(("زمان پایان صف", f"{_human_dt(spammer.get('eta', 0))}" if spammer.get("eta") else "—"))

    # 💬 اسپمر پیام
    rows.append(("اسپمر پیام", _fmt_bool(spam_msg.get("enabled", False))))
    rows.append(("حالت تایپ در اسپمر پیام", _fmt_bool(spam_msg.get("typing_on", False))))

    # ⏰ تایمر
    rows.append(("تایمر کلی", _fmt_bool(timer.get("enabled", False))))
    rows.append(("هدف‌ها", _truncate_list(timer.get("targets", []))))
    rows.append(("اجرای بعدی", str(timer.get("next_run", "—"))))

    # ⚔️ دشمن و دشمن ویژه
    rows.append(("دشمن خودکار", _fmt_bool(enemy.get("enabled", False))))
    rows.append(("تعداد مسدودشده‌ها", str(len(enemy.get("blocked", [])))))
    rows.append(("دشمن ویژه", _fmt_bool(enemy.get("special_enabled", False))))

    # 🔄 تغییر نام زمان‌بندی‌شده
    rows.append(("تغییر نام زمان‌بندی‌شده", _fmt_bool(rename.get("enabled", False))))
    rows.append(("زمان اجرای بعدی تغییر نام", str(rename.get("next_run", "—"))))

    # 💾 بک‌آپ
    rows.append(("پشتیبان‌گیری", _fmt_bool(backup.get("enabled", False))))
    rows.append(("محل ذخیره پشتیبان", backup.get("dir", "—")))

    # 🖼 رسانه
    rows.append(("مدیریت رسانه", _fmt_bool(media.get("enabled", False))))
    rows.append(("مسیر رسانه‌ها", _truncate_list(media.get("paths", []))))

    # 🚦 محدودیت سرعت
    rows.append(("محدودیت سرعت فعال", _fmt_bool(rate.get("enabled", False))))
    rows.append(("بازه زمانی محدودیت", str(rate.get("window", "—"))))
    rows.append(("تعداد باقیمانده", str(rate.get("remaining", "—"))))
    rows.append(("بازنشانی بعد از", f"{_human_dt(rate.get('reset_in', 0))}" if rate.get("reset_in") else "—"))

    return rows

# =============================
# 🎨 خروجی کاربر پسند (فقط فارسی)
# =============================

def _pair(k, v): return f"• {k}: {v}"

def _render_human(cfg: Dict[str,Any]) -> str:
    env = _collect_environment()
    feats = _collect_features(cfg)

    parts = ["# وضعیت کلی برنامه\n"]
    parts += [_pair(k,v) for k,v in env]
    parts.append("\n# قابلیت‌ها\n")
    parts += [_pair(k,v) for k,v in feats]

    return "\n".join(parts).strip()

# =============================
# 🧾 STATUS
# =============================

async def status(audience: str = "human") -> str:
    cfg = AllConfig
    if audience == "human":
        return _render_human(cfg)
    else:
        return json.dumps({
            "Environment": dict(_collect_environment()),
            "Features": dict(_collect_features(cfg))
        }, ensure_ascii=False, indent=2)

# =============================
# 📖 HELP
# =============================

async def help_text() -> str:
    return (
        "📖 راهنمای دستورات:\n"
        "- status → نمایش وضعیت کلی و قابلیت‌ها\n"
        "- ping → تست اتصال\n"
        "- uptime → زمان اجرای برنامه\n"
        "- restart → بازنشانی وضعیت\n"
        "- shutdown → خاموش کردن برنامه\n"
    )
