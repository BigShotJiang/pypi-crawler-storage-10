from setuptools import setup

# Tutta la configurazione è gestita da pyproject.toml
setup()