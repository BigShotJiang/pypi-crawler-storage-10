from setuptools import setup, find_packages

with open("README.md", "r") as file:
    description = file.read()

setup(
    name='flowscript-lang',
    version='0.1.2',
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.14",
        "Operating System :: OS Independent"
    ],
    url='https://github.com/qdyg-vn/FlowScript',
    author_email='flowscript.lang@gmail.com',
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'fscc = FlowScript.cli:main'
        ]
    },
    description='FlowScript - The Concise Calculus Programming Language',
    long_description=description,
    long_description_content_type="text/markdown",
    python_requires='>=3.8'
)