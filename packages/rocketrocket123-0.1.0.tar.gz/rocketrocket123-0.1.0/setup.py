from setuptools import setup, find_packages

setup(
    name="rocketrocket123",                  
    version="0.1.0",               
    packages=find_packages(),        
    install_requires=[],            
    author="Ton Nom",               
    author_email="ton.email@example.com",  
    description="Un package contenant le module Rocket et CircleRocket",
    license="MIT",
    keywords="rocket circle python module",
    url="https://github.com/tonnom/rocket", 
)