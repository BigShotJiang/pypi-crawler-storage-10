from dahitiapi.DAHITI import DAHITI

# Initialize Class
dahiti = DAHITI(debug=1)

dahiti_id=10146

# Download Water Level Time Series

#~ ret = dahiti.download_water_level_ascii(dahiti_id)
#~ ret = dahiti.download_water_level_ascii_to_file(dahiti_id, '/tmp/'+str(dahiti_id)+'_wse.txt')

#~ ret = dahiti.download_water_level_json(dahiti_id)
#~ ret = dahiti.download_water_level_json_to_file(dahiti_id,'/tmp/'+str(dahiti_id)+'_wse.json')

#~ ret = dahiti.download_water_level_csv(dahiti_id)
#~ ret = dahiti.download_water_level_csv_to_file(dahiti_id, '/tmp/'+str(dahiti_id)+'_wse.csv')

#~ ret = dahiti.download_water_level_netcdf(dahiti_id, '/tmp/'+str(dahiti_id)+'_wse.nc')

import pprint
pprint.pprint(ret)