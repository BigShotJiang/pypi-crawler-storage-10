from dahitiapi.DAHITI import DAHITI

# Initialize Class
dahiti = DAHITI(debug=0, api_key="1F2E692B071769F7C210B8CDB56CF516E077724021C1CC082D04B76FD31324DA") # username: user
#~ dahiti = DAHITI(debug=1)

dahiti_id=10146 # lake
dahiti_id=46208 # river
#~ dahiti_id=13030 # discharge
dahiti_id=11355 # discharge

# Get Target Info
ret = dahiti.get_target_info(dahiti_id)

import pprint
pprint.pprint(ret)
