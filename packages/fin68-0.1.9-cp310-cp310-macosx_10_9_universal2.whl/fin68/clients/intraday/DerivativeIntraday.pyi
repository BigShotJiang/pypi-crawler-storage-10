from __future__ import annotations

"""
fin68.clients.intraday.derivative
=================================

Type stubs cho module `fin68.clients.intraday.derivative`.

Cung cấp lớp `DerivativeIntraday` — tập trung các endpoint Intraday dành cho **hợp đồng tương lai**
(VN30F*, VN100F*). Bao gồm dữ liệu OHLCV (Open, High, Low, Close, Volume) và hỗ trợ các khoảng
thời gian khác nhau (1 phút, 5 phút, 15 phút, 30 phút, 1 giờ, 4 giờ).

Notes
-----
- Tất cả kết quả được trả về dưới dạng `pandas.DataFrame`.
- Tự động kiểm tra và chuẩn hóa ngày bắt đầu/kết thúc, validate interval.
"""

from typing import Literal
from pandas import DataFrame
from private_core.cache_mixin import BaseCacheMixin
from private_core.http_core import HttpSession
from ..base import BaseClient
from .helper import DateStr, Interval, _IntradayMixin


DerivativeArg = Literal[
    "VN30F1M",
    "VN30F2M",
    "VN30F1Q",
    "VN30F2Q",
    "VN100F1M",
    "VN100F2M",
    "VN100F1Q",
    "VN100F2Q",
]


class DerivativeIntraday(BaseCacheMixin, BaseClient, _IntradayMixin):
    """
    Cung cấp các endpoint intraday cho **hợp đồng tương lai (derivatives/futures)**.

    Lớp này cho phép truy vấn dữ liệu giá, khối lượng và biến động intraday
    của các mã hợp đồng tương lai chuẩn (VN30F*, VN100F*).

    Parameters
    ----------
    session : HttpSession
        Phiên HTTP đã xác thực, dùng để gửi yêu cầu tới backend Fin68.
    """

    def __init__(self, session: HttpSession) -> None:
        """
        Khởi tạo lớp `DerivativeIntraday` với session HTTP đã được xác thực.

        Parameters
        ----------
        session : HttpSession
            Phiên HTTP đã xác thực.

        Notes
        -----
        - `super().__init__(session=session)` khởi tạo base `BaseClient` để lưu trữ session.
        """
        ...

    def ohlcv(
        self,
        symbol: DerivativeArg,
        start: DateStr | None = ...,
        end: DateStr | None = ...,
        interval: Interval = ...,
    ) -> DataFrame:
        """
        Lấy dữ liệu OHLCV (Open, High, Low, Close, Volume) cho **hợp đồng tương lai**.

        Parameters
        ----------
        symbol : DerivativeArg
            Mã hợp đồng tương lai cần lấy dữ liệu:

            - ``"VN30F1M"``, ``"VN30F2M"``, ``"VN30F1Q"``, ``"VN30F2Q"``
            - ``"VN100F1M"``, ``"VN100F2M"``, ``"VN100F1Q"``, ``"VN100F2Q"``

        start : str, optional
            Ngày bắt đầu, định dạng ``"YYYY-MM-DD"``.
            Nếu không truyền, hệ thống sẽ tự động lấy ngược về theo khoảng mặc định.

        end : str, optional
            Ngày kết thúc, định dạng ``"YYYY-MM-DD"``.
            Nếu không truyền, mặc định là ngày hiện tại.

        interval : Interval, default "1m"
            Khung thời gian dữ liệu cần lấy:

            - ``"1m"``: theo 1 phút
            - ``"5m"``: theo 5 phút
            - ``"15m"``: theo 15 phút
            - ``"30m"``: theo 30 phút
            - ``"1H"``: theo giờ
            - ``"4H"``: theo 4 giờ

        Returns
        -------
        DataFrame
            Bảng dữ liệu gồm các cột cơ bản:
            - ``symbol``: mã hợp đồng tương lai
            - ``date``: thời điểm giao dịch
            - ``open``, ``high``, ``low``, ``close``, ``volume``

            (Tuỳ backend, có thể kèm thêm các cột mở rộng như ``oi`` – open interest.)

        Raises
        ------
        ValueError
            Khi tham số ``start`` > ``end``, hoặc ``interval`` không hợp lệ.
        ApiRequestError
            Khi backend trả lỗi trong quá trình gọi API.

        Examples
        --------
        >>> from fin68 import client
        >>> cli = client(api_key="sk_live_...")
        >>> df = cli.intraday.derivative.ohlcv("VN30F1M", start="2024-01-01", end="2024-06-30")
        >>> df.head()
        >>> # Output (ví dụ)
        >>> #     symbol               date   open   high    low  close     volume
        >>> # 0  VN30F1M  2024-01-02 09:15:00  1110   1116   1105   1114     12345

        Notes
        -----
        - Tự động validate khoảng thời gian (``start <= end``).
        - Dữ liệu này phản ánh biến động intraday của các hợp đồng tương lai.
        """
        ...
    def orderbook(
        self,
        symbol: DerivativeArg,
        target_date: DateStr = None,
    ) -> "DataFrame":
        """
        Lấy dữ liệu Orderbook cho hợp đồng phái sinh.

        Parameters
        ----------
        symbol : str
            Mã hợp đồng phái sinh cần lấy dữ liệu (VD: `"VN30F1M"`).
        target_date : str, optional
            Ngày giao dịch, định dạng `"YYYY-MM-DD"`.  
            Nếu không truyền, hệ thống sẽ tự động lấy ngày làm việc gần nhất (trong tuần).
        Returns
        -------
        DataFrame
            Bảng dữ liệu gồm các cột:
            - `symbol`: mã hợp đồng phái sinh  
            - `date`: ngày giao dịch  
            - `close`: giá đóng cửa
            - `volume`: khối lượng giao dịch
            - `type`: loại lệnh (B: Mua chủ động, S: Bán chủ động, N: Không xác định)

        Raises
        ------
        ValueError
            Khi tham số `target_date` không hợp lệ.
        ApiRequestError
            Khi backend trả lỗi trong quá trình gọi API.

        Examples
        --------
        ```python
        from fin68 import client
        cli = client(api_key="sk_live_...")
        df = cli.intraday.derivative.orderbook("VN30F1M", target_date="2024-01-01")
        df.head()
        ```
        
        >>> # Output
            symbol               date    close    volume     type   
        0      VN30F1M  2024-01-02 09:15:00  27200       1500         B

        """
        ...
    def net_active_value(
        self,
        symbol: DerivativeArg,
        target_date: DateStr = ...,
        interval: Interval = ...,
    ) -> DataFrame:
        """
        Tính Net Active Value (NAV = B - S) cho hợp đồng tương lai.

        Giá trị mỗi record được xác định `value = close * volume`. Lệnh bán
        (`type = "S"`) được đổi dấu để phản ánh dòng tiền âm, đồng thời loại bỏ
        các bản ghi trung lập (`type = "N"`).

        Parameters
        ----------
        symbol : DerivativeArg
            Mã hợp đồng phái sinh cần tính toán.
        target_date : str, optional
            Ngày giao dịch, mặc định là ngày làm việc gần nhất.
        interval : Interval, default "1m"
            Khoảng thời gian gom nhóm trước khi tính tổng giá trị thuần.

        Returns
        -------
        DataFrame
            Bảng gồm `symbol`, `date`, `value` (B - S) và `value_cumsum` (lũy kế).
        """
        ...
