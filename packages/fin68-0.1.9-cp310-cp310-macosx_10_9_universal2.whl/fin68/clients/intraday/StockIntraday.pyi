from __future__ import annotations

"""
fin68.clients.intraday.stock
============================

Type stubs cho module `fin68.clients.intraday.stock`.

Cung cấp lớp `StockIntraday` — tập trung các endpoint Intraday dành cho từng mã cổ phiếu riêng lẻ.  
Bao gồm dữ liệu OHLCV (Open, High, Low, Close, Volume) và hỗ trợ các khoảng thời gian khác nhau
(1 phút, 5 phút, 15 phút, 30 phút, 1 giờ, 4 giờ).

Notes
-----
- Tất cả kết quả được trả về dưới dạng `pandas.DataFrame`.
- Tự động kiểm tra và chuẩn hóa ngày bắt đầu/kết thúc, validate interval.
"""

from pandas import DataFrame
from private_core.cache_mixin import BaseCacheMixin
from private_core.http_core import HttpSession
from ..base import BaseClient
from .helper import DateStr, Interval, _IntradayMixin


class StockIntraday(BaseCacheMixin, BaseClient, _IntradayMixin):
    """
    Cung cấp các endpoint intraday cho từng mã cổ phiếu (equity symbol).

    Lớp này cho phép truy vấn dữ liệu giá, khối lượng và chỉ báo kỹ thuật
    ở cấp mã cổ phiếu.

    Parameters
    ----------
    session : HttpSession
        Phiên HTTP đã xác thực, dùng để gửi yêu cầu tới backend Fin68.
    """

    def __init__(self, session: HttpSession) -> None:
        """
        Khởi tạo lớp `StockIntraday` với session HTTP đã được xác thực.

        Parameters
        ----------
        session : HttpSession
            Phiên HTTP đã xác thực.

        """
        ...

    def ohlcv(
        self,
        symbol: str,
        start: DateStr | None = ...,
        end: DateStr | None = ...,
        interval: Interval = ...,
    ) -> DataFrame:
        """
        Lấy dữ liệu OHLCV (Open, High, Low, Close, Volume) cho một mã cổ phiếu.

        Parameters
        ----------
        symbol : str
            Mã cổ phiếu cần lấy dữ liệu (VD: `"HPG"`).
        start : str, optional
            Ngày bắt đầu, định dạng `"YYYY-MM-DD"`.  
            Nếu không truyền, hệ thống sẽ tự động lấy ngược về theo khoảng mặc định.
        end : str, optional
            Ngày kết thúc, định dạng `"YYYY-MM-DD"`.  
            Nếu không truyền, mặc định là ngày hiện tại.
        interval : Interval, default "1m"
            Khoảng thời gian dữ liệu cần lấy:
            
            - `"1m"`: theo 1 phút  
            - `"5m"`: theo 5 phút  
            - `"15m"`: theo 15 phút  
            - `"30m"`: theo 30 phút  
            - `"1H"`: theo giờ  
            - `"4H"`: theo 4 giờ  

        Returns
        -------
        DataFrame
            Bảng dữ liệu gồm các cột:
            - `symbol`: mã cổ phiếu  
            - `date`: ngày giao dịch  
            - `open`, `high`, `low`, `close`, `volume`  

        Raises
        ------
        ValueError
            Khi tham số `start` > `end`, hoặc `interval` không hợp lệ.
        ApiRequestError
            Khi backend trả lỗi trong quá trình gọi API.

        Examples
        --------
        ```python
        from fin68 import client
        cli = client(api_key="sk_live_...")
        df = cli.intraday.stock.ohlcv("HPG", start="2024-01-01", end="2024-06-30")
        df.head()
        ```


        >>> # Output
        >>> #   symbol               date    open    high     low   close    volume
        >>> # 0   HPG  2024-01-02 09:15:00  27200  27500  26900  27400  15300000

        Notes
        -----
        - Tự động validate khoảng thời gian (`start <= end`).
        """
        ...
    def orderbook(
        self,
        symbol: str,
        target_date: DateStr = None,
    ) -> "DataFrame":
        """
        Lấy dữ liệu Orderbook cho một mã cổ phiếu.

        Parameters
        ----------
        symbol : str
            Mã cổ phiếu cần lấy dữ liệu (VD: `"HPG"`).
        target_date : str, optional
            Ngày giao dịch, định dạng `"YYYY-MM-DD"`.  
            Nếu không truyền, hệ thống sẽ tự động lấy ngày làm việc gần nhất (trong tuần).
        Returns
        -------
        DataFrame
            Bảng dữ liệu gồm các cột:
            - `symbol`: mã cổ phiếu  
            - `date`: ngày giao dịch  
            - `close`: giá đóng cửa
            - `volume`: khối lượng giao dịch
            - `type`: loại lệnh (B: Mua chủ động, S: Bán chủ động, N: Không xác định)

        Raises
        ------
        ValueError
            Khi tham số `target_date` không hợp lệ.
        ApiRequestError
            Khi backend trả lỗi trong quá trình gọi API.

        Examples
        --------
        ```python
        from fin68 import client
        cli = client(api_key="sk_live_...")
        df = cli.intraday.stock.orderbook("HPG", target_date="2024-01-01")
        df.head()
        ```
        
        >>> # Output
            symbol               date    close    volume     type   
        0      HPG  2024-01-02 09:15:00  27200       1500         B

        """
        ...
    def net_active_value(
        self,
        symbol: str,
        target_date: DateStr = None,
        interval: Interval = "1m",
    ) -> "DataFrame":
        """
        Tính Net Active Value (B - S) theo từng khoảng thời gian.

        Giá trị mỗi lệnh được xác định bằng công thức `value = close * volume`.
        Các lệnh bán chủ động (`type = "S"`) bị đổi dấu để phản ánh dòng tiền âm.

        Parameters
        ----------
        symbol : str
            Mã cổ phiếu cần tính toán (VD: `"HPG"`).
        target_date : str, optional
            Ngày giao dịch (`"YYYY-MM-DD"`). Nếu không truyền sẽ là ngày làm việc gần nhất.
        interval : Interval, default "1m"
            Khoảng thời gian gom nhóm trước khi tính tổng giá trị thuần.

        Returns
        -------
        DataFrame
            Bảng gồm các cột:
            - `symbol`
            - `date`: mốc thời gian đã gom theo interval
            - `value`: tổng giá trị thuần trong interval (B - S) (đvt: Tỷ đồng)
            - `value_cumsum`: lũy kế giá trị thuần theo thời gian (đvt: Tỷ đồng)
        """
        ...
