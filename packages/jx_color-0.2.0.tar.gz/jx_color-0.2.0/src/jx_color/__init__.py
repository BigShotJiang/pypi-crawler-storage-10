from .color_operations import I

__version__ = "0.1.0"
__author__ = "Mr. Inosuke"

# I class কে directly available করুন
__all__ = ['I']