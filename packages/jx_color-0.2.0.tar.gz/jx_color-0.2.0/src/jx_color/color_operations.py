class I:
    """Color class for terminal text styling with 50+ colors"""
    
    # Basic Colors
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BLACK = '\033[90m'
    
    # Bright Colors
    B_RED = '\033[91;1m'
    B_GREEN = '\033[92;1m'
    B_YELLOW = '\033[93;1m'
    B_BLUE = '\033[94;1m'
    B_MAGENTA = '\033[95;1m'
    B_CYAN = '\033[96;1m'
    B_WHITE = '\033[97;1m'
    
    # Dark Colors
    D_RED = '\033[31m'
    D_GREEN = '\033[32m'
    D_YELLOW = '\033[33m'
    D_BLUE = '\033[34m'
    D_MAGENTA = '\033[35m'
    D_CYAN = '\033[36m'
    D_GRAY = '\033[90m'
    
    # RGB Colors (8-bit)
    ORANGE = '\033[38;5;214m'
    PINK = '\033[38;5;205m'
    PURPLE = '\033[38;5;129m'
    LIME = '\033[38;5;118m'
    TEAL = '\033[38;5;51m'
    LAVENDER = '\033[38;5;183m'
    BROWN = '\033[38;5;130m'
    GOLD = '\033[38;5;220m'
    SILVER = '\033[38;5;7m'
    MAROON = '\033[38;5;88m'
    OLIVE = '\033[38;5;58m'
    NAVY = '\033[38;5;17m'
    CORAL = '\033[38;5;209m'
    SALMON = '\033[38;5;210m'
    PEACH = '\033[38;5;223m'
    MINT = '\033[38;5;121m'
    SKY_BLUE = '\033[38;5;117m'
    ROYAL_BLUE = '\033[38;5;63m'
    INDIGO = '\033[38;5;54m'
    VIOLET = '\033[38;5;127m'
    PLUM = '\033[38;5;219m'
    BEIGE = '\033[38;5;230m'
    CHOCOLATE = '\033[38;5;94m'
    TURQUOISE = '\033[38;5;80m'
    EMERALD = '\033[38;5;46m'
    RUBY = '\033[38;5;160m'
    AMBER = '\033[38;5;214m'
    CRIMSON = '\033[38;5;196m'
    FOREST_GREEN = '\033[38;5;28m'
    MIDNIGHT_BLUE = '\033[38;5;18m'
    HOT_PINK = '\033[38;5;198m'
    LIGHT_BLUE = '\033[38;5;117m'
    DARK_ORANGE = '\033[38;5;202m'
    LIGHT_GREEN = '\033[38;5;120m'
    DARK_PURPLE = '\033[38;5;90m'
    LIGHT_PINK = '\033[38;5;218m'
    STEEL_BLUE = '\033[38;5;67m'
    SAND = '\033[38;5;180m'
    BRICK = '\033[38;5;124m'
    GRASS = '\033[38;5;70m'
    OCEAN = '\033[38;5;27m'
    SUNSET = '\033[38;5;209m'
    LAVENDER_BLUSH = '\033[38;5;225m'
    
    # Background Colors
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_BLUE = '\033[44m'
    BG_YELLOW = '\033[43m'
    BG_MAGENTA = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'
    BG_BLACK = '\033[40m'
    BG_ORANGE = '\033[48;5;214m'
    BG_PINK = '\033[48;5;205m'
    BG_PURPLE = '\033[48;5;129m'
    BG_GOLD = '\033[48;5;220m'
    BG_SILVER = '\033[48;5;7m'
    
    # Bright Background Colors
    BG_B_RED = '\033[101m'
    BG_B_GREEN = '\033[102m'
    BG_B_YELLOW = '\033[103m'
    BG_B_BLUE = '\033[104m'
    BG_B_MAGENTA = '\033[105m'
    BG_B_CYAN = '\033[106m'
    BG_B_WHITE = '\033[107m'
    
    # Styles
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    ITALIC = '\033[3m'
    REVERSE = '\033[7m'
    STRIKETHROUGH = '\033[9m'
    BLINK = '\033[5m'
    DIM = '\033[2m'
    
    # Reset
    RESET = '\033[0m'
    
    # Static Methods for all colors
    @staticmethod
    def red(text): return f"{I.RED}{text}{I.RESET}"
    @staticmethod
    def green(text): return f"{I.GREEN}{text}{I.RESET}"
    @staticmethod
    def yellow(text): return f"{I.YELLOW}{text}{I.RESET}"
    @staticmethod
    def blue(text): return f"{I.BLUE}{text}{I.RESET}"
    @staticmethod
    def magenta(text): return f"{I.MAGENTA}{text}{I.RESET}"
    @staticmethod
    def cyan(text): return f"{I.CYAN}{text}{I.RESET}"
    @staticmethod
    def white(text): return f"{I.WHITE}{text}{I.RESET}"
    @staticmethod
    def black(text): return f"{I.BLACK}{text}{I.RESET}"
    @staticmethod
    def orange(text): return f"{I.ORANGE}{text}{I.RESET}"
    @staticmethod
    def pink(text): return f"{I.PINK}{text}{I.RESET}"
    @staticmethod
    def purple(text): return f"{I.PURPLE}{text}{I.RESET}"
    @staticmethod
    def gold(text): return f"{I.GOLD}{text}{I.RESET}"
    @staticmethod
    def silver(text): return f"{I.SILVER}{text}{I.RESET}"
    @staticmethod
    def brown(text): return f"{I.BROWN}{text}{I.RESET}"
    @staticmethod
    def coral(text): return f"{I.CORAL}{text}{I.RESET}"
    @staticmethod
    def lime(text): return f"{I.LIME}{text}{I.RESET}"
    @staticmethod
    def teal(text): return f"{I.TEAL}{text}{I.RESET}"
    @staticmethod
    def lavender(text): return f"{I.LAVENDER}{text}{I.RESET}"
    
    @staticmethod
    def bold(text): return f"{I.BOLD}{text}{I.RESET}"
    @staticmethod
    def underline(text): return f"{I.UNDERLINE}{text}{I.RESET}"
    @staticmethod
    def italic(text): return f"{I.ITALIC}{text}{I.RESET}"
    @staticmethod
    def reverse(text): return f"{I.REVERSE}{text}{I.RESET}"
    @staticmethod
    def strikethrough(text): return f"{I.STRIKETHROUGH}{text}{I.RESET}"