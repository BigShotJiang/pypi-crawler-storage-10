# MCP Dynamic Proxy

A dynamic MCP (Model Context Protocol) proxy server that provides progressive discovery and lazy loading of MCP servers, dramatically reducing initial context size from 20-300 tools to just 3 core tools.

## Features

- **Progressive Discovery**: Discover MCP servers by tags, category, or search term without loading them
- **Lazy Loading**: Load MCP servers only when needed
- **Minimal Context**: Only 3 core discovery/execution tools exposed initially instead of hundreds
- **Full MCP Protocol**: Uses official MCP SDK for end-to-end protocol support

## Architecture

```
Assistant (Cursor) -MCP-> MCP Dynamic Proxy -MCP-> MCP Servers (AWS, PostgreSQL, etc.)
```

The proxy exposes only 3 core tools:
1. `mcp_discover_servers` - Discover available MCP servers
2. `mcp_list_tools` - List tools from a specific MCP server
3. `mcp_execute_tool` - Execute a tool on an MCP server

## Installation

### Prerequisites

- Python 3.12+

### Setup

Install dependencies (requires Python 3.12 available on PATH):

```bash
python3.12 -m pip install -e .
```

For development:

```bash
python3.12 -m pip install -e ".[dev]"
```

## Configuration

Create a `config/mcp.json` file with your MCP server configurations:

```json
{
  "version": "1.0",
  "mcpServers": {
    "aws-knowledge-mcp-server": {
      "description": "AWS knowledge base with documentation, best practices, and service information",
      "tags": ["aws", "documentation", "cloud", "knowledge"],
      "category": "documentation",
      "command": "uvx",
      "args": ["fastmcp", "run", "https://knowledge-mcp.global.api.aws"]
    },
    "microsoft.docs.mcp": {
      "description": "Microsoft Learn documentation and Azure documentation access",
      "tags": ["microsoft", "azure", "documentation", "learn"],
      "category": "documentation",
      "command": "uvx",
      "args": ["fastmcp", "run", "https://learn.microsoft.com/api/mcp"]
    }
  }
}
```

### Configuration Fields

- `description`: Human-readable description of the server
- `tags`: List of tags for filtering (e.g., `["aws", "database"]`)
- `category`: Server category (e.g., `"database"`, `"documentation"`)
- `command`: Command to start the MCP server
- `args`: Arguments for the command
- `env`: Optional environment variables (supports `${VAR_NAME}` expansion)

## Usage

### Running the Server

Run the MCP proxy server:

```bash
uvx mcp-dynamic-proxy
```

Or with custom config path:

```bash
MCP_CONFIG_PATH=/path/to/config.json uvx mcp-dynamic-proxy
```

### Configuration for Cursor

Add to your Cursor MCP configuration:

```json
{
  "mcpServers": {
    "mcp-dynamic-proxy": {
      "command": "uvx",
      "args": ["mcp-dynamic-proxy"],
      "env": {
        "MCP_CONFIG_PATH": "/path/to/config/mcp.json"
      }
    }
  }
}
```

### Example Workflow

1. **Discover servers**:
   ```
   User: "Show me database servers"
   
   Assistant calls: mcp_discover_servers(tags=["database"])
   
   Response: List of database MCP servers
   ```

2. **List tools**:
   ```
   Assistant calls: mcp_list_tools(server_id="aws-dynamodb")
   
   Response: List of available tools (query, scan, put_item, etc.)
   ```

3. **Execute tool**:
   ```
   Assistant calls: mcp_execute_tool(
     server_id="aws-dynamodb",
     tool_name="query",
     arguments={"table": "users", "key": {"id": "123"}}
   )
   
   Response: Tool execution result
   ```

## License

MIT