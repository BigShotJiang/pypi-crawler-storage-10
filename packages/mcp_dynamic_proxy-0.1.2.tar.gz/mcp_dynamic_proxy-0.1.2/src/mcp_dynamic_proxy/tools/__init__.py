"""Core tools for MCP Dynamic Proxy."""

from .list_servers import execute as discover_servers
from .list_tools import execute as list_tools
from .call_tool import execute as execute_tool

__all__ = [
    "discover_servers",
    "list_tools",
    "execute_tool",
]

