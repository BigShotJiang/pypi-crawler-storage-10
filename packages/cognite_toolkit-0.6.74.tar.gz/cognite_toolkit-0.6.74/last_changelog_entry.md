## cdf 

### Fixed

- [alpha] The command `cdf profile assets` no longer fails with `ERROR
(ToolkitValueError): Profile row limit must be between 1 and 10000, got
False.`.

## templates

No changes.