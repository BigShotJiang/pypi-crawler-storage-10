import asyncio
import logging
import contextlib
from typing import Optional

from collections.abc import AsyncIterator
from surrealdb import AsyncSurreal, AsyncWsSurrealConnection, AsyncHttpSurrealConnection


logger = logging.getLogger(__name__)


class Engine:
    """
    SurrealDB connection pool engine, similar to SQLAlchemy's engine.

    This class manages a pool of authenticated SurrealDB connections that can be
    reused across async operations. It provides a clean API for connection management
    with context managers.

    The Engine should be created with `create_engine()` and manages its own lifecycle.

    Attributes:
        url: SurrealDB connection URL
        auth_payload: Authentication credentials dictionary
        pool_size: Number of connections to maintain in the pool
        connect_timeout: Timeout for connection attempts in seconds

    Example:
        >>> # Create and start engine
        >>> engine = create_engine(
        ...     url="ws://localhost:8000/rpc",
        ...     auth_payload={"username": "root", "password": "root"},
        ...     pool_size=5
        ... )
        >>> await engine.start()
        >>>
        >>> # Use connections via context manager
        >>> async with engine.connect() as db:
        ...     await db.use("mydb", "myns")
        ...     results = await db.select("person")
        >>>
        >>> # Close when done
        >>> await engine.close()

        Or use with lifecycle context manager:
        >>> async with create_engine_context(url, auth_payload) as engine:
        ...     async with engine.connect() as db:
        ...         # use db
        ...         pass
    """

    def __init__(
        self,
        url: str,
        auth_payload: dict,
        pool_size: int = 4,
        connect_timeout: float = 5.0,
    ):
        """
        Initialize the engine.

        Note: The engine is not started automatically. Call await engine.start()
        or use create_engine_context() for automatic lifecycle management.

        Args:
            url: SurrealDB connection URL (ws:// or http://)
            auth_payload: Dictionary with authentication credentials
            pool_size: Number of connections to maintain (default: 4)
            connect_timeout: Connection timeout in seconds (default: 5.0)
        """
        self.url = url
        self.auth_payload = auth_payload
        self.pool_size = pool_size
        self.connect_timeout = connect_timeout
        self._queue: Optional[asyncio.Queue] = None
        self._clients: list = []
        self._closed = False
        self._started = False

    async def _make_client(self) -> AsyncSurreal:
        """
        Create and authenticate a single SurrealDB client.

        Returns:
            An authenticated AsyncSurreal client ready for use

        Raises:
            Exception: If connection or authentication fails
        """
        client = AsyncSurreal(self.url)
        await client.signin(self.auth_payload)
        return client

    async def start(self) -> "Engine":
        """
        Initialize the connection pool with authenticated clients.

        Creates the specified number of clients, authenticates them,
        and adds them to the pool queue for reuse.

        Returns:
            self: Returns the engine instance for chaining

        Raises:
            RuntimeError: If the engine is already started or closed
            Exception: If unable to create the required number of clients
        """
        if self._started:
            raise RuntimeError("Engine already started")
        if self._closed:
            raise RuntimeError("Engine is closed")

        self._queue = asyncio.Queue()

        for i in range(self.pool_size):
            try:
                client = await self._make_client()
            except Exception as e:
                logger.exception("Failed to create surreal client #%d: %s", i, e)
                # Retry once with backoff before giving up
                await asyncio.sleep(0.5)
                client = await self._make_client()

            self._clients.append(client)
            self._queue.put_nowait(client)

        self._started = True
        logger.info("SurrealDB engine started with %d connections", len(self._clients))
        return self

    async def close(self) -> None:
        """
        Close all connections and shut down the engine.

        Drains the queue and closes all client connections gracefully.
        This should be called when the application shuts down.
        """
        if self._closed:
            return

        self._closed = True

        # Drain queue
        if self._queue is not None:
            while not self._queue.empty():
                try:
                    _ = self._queue.get_nowait()
                    self._queue.task_done()
                except asyncio.QueueEmpty:
                    break

        # Close all clients
        for client in self._clients:
            try:
                await client.close()
            except Exception:
                logger.exception("Error closing surreal client")

        self._clients.clear()
        self._started = False
        logger.info("SurrealDB engine closed")

    @contextlib.asynccontextmanager
    async def connect(self) -> AsyncIterator[AsyncWsSurrealConnection | AsyncHttpSurrealConnection]:
        """
        Acquire a connection from the pool as a context manager.

        This is the primary way to get a database connection from the engine.
        The connection is automatically returned to the pool when the context exits.

        Yields:
            AsyncWsSurrealConnection | AsyncHttpSurrealConnection: An authenticated client

        Example:
            >>> async with engine.connect() as db:
            ...     await db.use("mydb", "myns")
            ...     results = await db.select("person")

        Raises:
            RuntimeError: If the engine is not started or is closed
            Exception: If the acquired client encounters a fatal error
        """
        if self._closed:
            raise RuntimeError("Engine is closed")
        if not self._started:
            raise RuntimeError("Engine not started. Call await engine.start() first")

        client = await self._queue.get()
        try:
            yield client
        except Exception as exc:
            # If the client had a fatal error, replace it
            if self._is_fatal_client_error(exc):
                logger.warning("Client had fatal error, replacing: %s", exc)
                await self._replace_client(client)
            raise
        finally:
            # Return to pool if not closed
            if not self._closed and self._queue is not None:
                self._queue.put_nowait(client)

    # Alias for SQLAlchemy-like API
    acquire = connect

    async def execute(self, query: str, *args, retries: int = 1, backoff: float = 0.2, **kwargs):
        """
        Execute a query using a pooled connection with automatic retry.

        Acquires a client from the pool, executes the query, and handles
        retries for transient failures.

        Args:
            query: The query string to execute
            *args: Arguments to pass to the query method
            retries: Number of retry attempts for transient errors (default: 1)
            backoff: Base backoff time in seconds between retries (default: 0.2)
            **kwargs: Keyword arguments to pass to the query method

        Returns:
            Query results from SurrealDB

        Raises:
            RuntimeError: If the engine is not started
            Exception: If the query fails after all retry attempts
        """
        if self._closed:
            raise RuntimeError("Engine is closed")
        if not self._started:
            raise RuntimeError("Engine not started. Call await engine.start() first")

        for attempt in range(retries + 1):
            async with self.connect() as client:
                try:
                    return await client.query(query, *args, **kwargs)
                except Exception as exc:
                    logger.exception("Query failed on attempt %d: %s", attempt, exc)
                    if attempt < retries and self._is_retryable_error(exc):
                        await asyncio.sleep(backoff * (2 ** attempt))
                        continue
                    raise

    async def _replace_client(self, dead_client: AsyncSurreal) -> None:
        """
        Replace a failed client with a new authenticated connection.

        Closes the dead client, creates a new one, and adds it back to the pool
        to maintain the pool size.

        Args:
            dead_client: The client connection that failed
        """
        try:
            await dead_client.close()
        except Exception:
            pass

        try:
            new_client = await self._make_client()
        except Exception as e:
            logger.exception("Failed to create replacement client: %s", e)
            # If we can't create a replacement, put back the old one to avoid pool starvation
            if self._queue is not None and not self._closed:
                self._queue.put_nowait(dead_client)
            return

        # Replace in internal list
        try:
            idx = self._clients.index(dead_client)
            self._clients[idx] = new_client
        except ValueError:
            self._clients.append(new_client)

        if self._queue is not None and not self._closed:
            self._queue.put_nowait(new_client)

    def _is_retryable_error(self, exc: Exception) -> bool:
        """
        Determine if an exception is retryable.

        Args:
            exc: The exception to check

        Returns:
            bool: True if the error is transient and worth retrying
        """
        return isinstance(exc, (asyncio.TimeoutError, ConnectionError))

    def _is_fatal_client_error(self, exc: Exception) -> bool:
        """
        Determine if an exception indicates a broken client connection.

        Args:
            exc: The exception to check

        Returns:
            bool: True if the client connection is likely broken and needs replacement
        """
        return isinstance(exc, (ConnectionError, RuntimeError))


def create_engine(
    url: str,
    auth_payload: dict,
    pool_size: int = 4,
    connect_timeout: float = 5.0,
) -> Engine:
    """
    Create a connection pool engine for SurrealDB.

    This function creates an Engine instance that manages a pool of authenticated
    SurrealDB connections. The engine must be started with await engine.start()
    before use.

    Args:
        url: SurrealDB connection URL (e.g., "ws://localhost:8000/rpc")
        auth_payload: Dictionary with authentication credentials
            Example: {"username": "root", "password": "root"}
        pool_size: Number of connections to maintain in the pool (default: 4)
        connect_timeout: Timeout for connection attempts in seconds (default: 5.0)

    Returns:
        Engine: An engine instance (not yet started)

    Example:
        >>> # Create and manually manage lifecycle
        >>> engine = create_engine(
        ...     "ws://localhost:8000/rpc",
        ...     {"username": "root", "password": "root"},
        ...     pool_size=5
        ... )
        >>> await engine.start()
        >>>
        >>> async with engine.connect() as db:
        ...     await db.use("mydatabase", "mynamespace")
        ...     people = await Person.insert(db, [
        ...         Person(name="Alice"),
        ...         Person(name="Bob")
        ...     ])
        >>>
        >>> await engine.close()

    See Also:
        - create_engine_context(): For automatic lifecycle management
        - Engine.connect(): Get a connection from the pool
        - Engine.execute(): Execute a query with automatic retry
    """
    return Engine(url, auth_payload, pool_size, connect_timeout)


@contextlib.asynccontextmanager
async def create_engine_context(
    url: str,
    auth_payload: dict,
    pool_size: int = 4,
    connect_timeout: float = 5.0,
) -> AsyncIterator[Engine]:
    """
    Create a connection pool engine with automatic lifecycle management.

    This context manager creates an engine, starts it, yields it for use,
    and automatically closes it when the context exits. This is the recommended
    way to use the engine as it ensures proper cleanup.

    Args:
        url: SurrealDB connection URL (e.g., "ws://localhost:8000/rpc")
        auth_payload: Dictionary with authentication credentials
            Example: {"username": "root", "password": "root"}
        pool_size: Number of connections to maintain in the pool (default: 4)
        connect_timeout: Timeout for connection attempts in seconds (default: 5.0)

    Yields:
        Engine: A started engine instance

    Example:
        >>> async with create_engine_context(
        ...     "ws://localhost:8000/rpc",
        ...     {"username": "root", "password": "root"},
        ...     pool_size=5
        ... ) as engine:
        ...     async with engine.connect() as db:
        ...         await db.use("mydatabase", "mynamespace")
        ...         people = await Person.insert(db, [
        ...             Person(name="Alice"),
        ...             Person(name="Bob")
        ...         ])
        ...     # Engine is automatically closed here

    See Also:
        - create_engine(): For manual lifecycle management
        - Engine.connect(): Get a connection from the pool
    """
    engine = Engine(url, auth_payload, pool_size, connect_timeout)
    await engine.start()
    try:
        yield engine
    finally:
        await engine.close()
