"""In-memory Agent Queries Package."""
