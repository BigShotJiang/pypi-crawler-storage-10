/* empty css              */import{cO as r}from"./index-DAuB1RBy.js";const e=r("v-spacer","div","VSpacer");export{e as V};
