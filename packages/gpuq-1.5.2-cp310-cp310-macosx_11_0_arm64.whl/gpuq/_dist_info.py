version = '1.5.2'
repo = 'https://github.com/makodevai/gpuq'
commit = '324de0339c03318f99b5d9115aac6663d19a097a (+2 untracked)'
has_repo = True
