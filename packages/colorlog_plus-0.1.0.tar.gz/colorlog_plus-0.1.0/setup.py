from setuptools import setup, find_packages

setup(
    name="colorlog-plus",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Beautiful colored logging made simple",
    long_description="Beautiful colored logging made simple for Python",
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)