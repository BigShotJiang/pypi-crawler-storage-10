﻿import logging
from colorlog_plus import get_logger

def test_get_logger_returns_logger():
    logger = get_logger("test.module")
    assert isinstance(logger, logging.Logger)

def test_multiple_calls_do_not_add_handlers():
    name = "test.unique"
    logger = get_logger(name)
    count1 = len(logger.handlers)
    logger2 = get_logger(name)
    count2 = len(logger2.handlers)
    # calling again should not add duplicate handlers
    assert count1 == count2
