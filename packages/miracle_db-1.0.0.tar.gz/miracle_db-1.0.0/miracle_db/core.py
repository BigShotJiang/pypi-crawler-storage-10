def insert(data):
    return None

def get_data():
    return None
 