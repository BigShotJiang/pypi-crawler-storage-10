

class CodecError(Exception):
    """Base class for all codec errors."""
    pass
