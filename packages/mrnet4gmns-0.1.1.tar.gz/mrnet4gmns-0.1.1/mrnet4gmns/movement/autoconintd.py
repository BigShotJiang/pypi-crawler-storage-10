from ..utils.util_geo import getLineAngle


class CAutoConnectorIntD:
    default_right_most_lanes = 1
    default_left_most_lanes = 1

    ib_link = None
    ob_link_list = []
    ob_link_list_sorted = []
    connection_list = []

    @classmethod
    def getSequence(cls):
        angle_list = []
        for ob_link in cls.ob_link_list:
            angle = getLineAngle(cls.ib_link.geometry_xy, ob_link.geometry_xy)
            angle_list.append(angle)
        cls.ob_link_list_sorted = sorted(cls.ob_link_list, key=lambda x: angle_list[cls.ob_link_list.index(x)], reverse=True)

    @classmethod
    def getLaneConnection(cls):
        cls.connection_list = [[] for _ in range(len(cls.ob_link_list_sorted))]
        ib_lanes = cls.ib_link.outgoing_lanes

        if ib_lanes == 1:
            left_ob_link = cls.ob_link_list_sorted[0]
            cls.connection_list[cls.ob_link_list.index(left_ob_link)] = [(0, 0),(0, 0)]
            for ob_link in cls.ob_link_list_sorted[1:]:
                cls.connection_list[cls.ob_link_list.index(ob_link)] = [(0, 0), (ob_link.incoming_lanes-1, ob_link.incoming_lanes-1)]
            return

        if len(cls.ob_link_list_sorted) == 1:
            ob_link = cls.ob_link_list_sorted[0]
            connection_lanes = min(ib_lanes, ob_link.incoming_lanes)
            cls.connection_list[cls.ob_link_list.index(ob_link)] = [(0, connection_lanes - 1), (0, connection_lanes - 1)]

        elif len(cls.ob_link_list_sorted) == 2:
            left_ob_link = cls.ob_link_list_sorted[0]
            lanes_ib_link_left = ib_lanes - cls.default_left_most_lanes
            lanes_ob_has = left_ob_link.incoming_lanes
            connection_lanes = min(lanes_ib_link_left,lanes_ob_has)
            cls.connection_list[cls.ob_link_list.index(left_ob_link)] = [(0, connection_lanes - 1), (0, connection_lanes - 1)]

            right_ob_link = cls.ob_link_list_sorted[-1]
            cls.connection_list[cls.ob_link_list.index(right_ob_link)] = [
                (ib_lanes - cls.default_right_most_lanes, ib_lanes - 1),
                (right_ob_link.incoming_lanes - cls.default_right_most_lanes, right_ob_link.incoming_lanes - 1)]

        else:
            left_ob_link = cls.ob_link_list_sorted[0]
            cls.connection_list[cls.ob_link_list.index(left_ob_link)] = [(0,cls.default_left_most_lanes-1), (0,cls.default_left_most_lanes-1)]

            mid_ob_link_list = cls.ob_link_list_sorted[1:-1]
            lanes_assgined_to_each_mid_ob_link = [0] * len(mid_ob_link_list)
            lanes_each_mid_ob_link_left = [link.incoming_lanes for link in mid_ob_link_list]

            if ib_lanes - cls.default_left_most_lanes - cls.default_right_most_lanes >= len(mid_ob_link_list):
                lanes_ib_link_left = ib_lanes - cls.default_left_most_lanes - cls.default_right_most_lanes
                start_lane_no = cls.default_left_most_lanes
                while (lanes_ib_link_left > 0) and (sum(lanes_each_mid_ob_link_left) > 0):
                    for ob_link_no, ob_link in enumerate(mid_ob_link_list):
                        if lanes_each_mid_ob_link_left[ob_link_no] == 0: continue
                        if lanes_ib_link_left == 0: break
                        lanes_each_mid_ob_link_left[ob_link_no] -= 1
                        lanes_assgined_to_each_mid_ob_link[ob_link_no] += 1
                        lanes_ib_link_left -= 1
                for ob_link_no, ob_link in enumerate(mid_ob_link_list):
                    cls.connection_list[cls.ob_link_list.index(ob_link)] = [
                        (start_lane_no, start_lane_no + lanes_assgined_to_each_mid_ob_link[ob_link_no] - 1),
                        (ob_link.incoming_lanes - lanes_assgined_to_each_mid_ob_link[ob_link_no], ob_link.incoming_lanes - 1)]
                    start_lane_no += lanes_assgined_to_each_mid_ob_link[ob_link_no]
            elif ib_lanes < len(mid_ob_link_list):
                lane_no, link_no = -1, -1
                for lane_no in range(ib_lanes-1):
                    link_no = lane_no
                    ob_link = mid_ob_link_list[link_no]
                    cls.connection_list[cls.ob_link_list.index(ob_link)] = [(lane_no, lane_no), (ob_link.incoming_lanes - 1, ob_link.incoming_lanes - 1)]
                lane_no += 1
                start_link_no = link_no + 1
                for link_no in range(start_link_no, len(mid_ob_link_list)):
                    ob_link = mid_ob_link_list[link_no]
                    cls.connection_list[cls.ob_link_list.index(ob_link)] = [(lane_no, lane_no), (ob_link.incoming_lanes - 1, ob_link.incoming_lanes - 1)]
            else:
                if ib_lanes - cls.default_left_most_lanes == len(mid_ob_link_list):
                    start_lane_no = cls.default_left_most_lanes
                else:
                    start_lane_no = 0
                for ob_link in mid_ob_link_list:
                    cls.connection_list[cls.ob_link_list.index(ob_link)] = [(start_lane_no, start_lane_no), (ob_link.incoming_lanes - 1, ob_link.incoming_lanes - 1)]
                    start_lane_no += 1

            right_ob_link = cls.ob_link_list_sorted[-1]
            cls.connection_list[cls.ob_link_list.index(right_ob_link)] = [
                (ib_lanes - cls.default_right_most_lanes, ib_lanes - 1),
                (right_ob_link.incoming_lanes - cls.default_right_most_lanes, right_ob_link.incoming_lanes - 1)]

    @classmethod
    def buildConnector(cls):
        cls.getSequence()
        cls.getLaneConnection()
        return cls.connection_list



