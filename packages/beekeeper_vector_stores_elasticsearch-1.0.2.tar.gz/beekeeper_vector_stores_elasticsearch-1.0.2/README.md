# Beekeeper vector_stores extension - Elasticsearch

## Installation 

```bash
pip install beekeeper-vector-stores-elasticsearch
```
