Base schema: http://purl.allotrope.org/json-schemas/adm/solution-analyzer/BENCHLING/2024/09/solution-analyzer.schema

Changes:

* Added Kilo Pascal unit to some attributes of document/measurement document
  * pO2
  * pCO2
