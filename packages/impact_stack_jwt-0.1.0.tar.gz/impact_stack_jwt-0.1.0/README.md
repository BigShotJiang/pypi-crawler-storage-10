### Impact Stack JWT

This module extends flask-jwt-extended with some Impact Stack specific functionality to make access and permission checks simpler in our apps.
