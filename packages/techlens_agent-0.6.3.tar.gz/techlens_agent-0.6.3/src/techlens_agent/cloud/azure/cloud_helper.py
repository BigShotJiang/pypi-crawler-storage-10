import subprocess
import json

from azure.identity import AzureAuthorityHosts

cloud_to_settings = {
    "AzureCloud": (AzureAuthorityHosts.AZURE_PUBLIC_CLOUD, "management.azure.com"),
    "AzureUSGovernment": (
        AzureAuthorityHosts.AZURE_GOVERNMENT,
        "management.usgovcloudapi.net",
    ),
}


def detect_cloud(subscription_id: str) -> str:
    try:
        result = subprocess.run(
            f"az account show --subscription {subscription_id} --output json",
            capture_output=True,
            text=True,
            check=True,
        )
        account_info = json.loads(result.stdout)
        return account_info.get("cloudName", "AzureCloud")

    except Exception as e:
        return "AzureCloud"


def get_cloud_settings(cloud_name):
    return cloud_to_settings[cloud_name]
