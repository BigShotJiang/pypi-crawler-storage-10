"""gbp-ps tests"""
