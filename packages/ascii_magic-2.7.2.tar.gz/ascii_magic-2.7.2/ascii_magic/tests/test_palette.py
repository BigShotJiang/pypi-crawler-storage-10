from ascii_magic import AsciiArt


def test_palette():
    AsciiArt.print_palette()
