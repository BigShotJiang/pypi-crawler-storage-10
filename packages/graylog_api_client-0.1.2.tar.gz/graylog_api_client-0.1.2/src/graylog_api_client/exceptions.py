class GraylogApiException(Exception):
    pass
