from __future__ import annotations
from pydantic import BaseModel, Field, conlist, field_validator, FieldValidationInfo
from typing import Literal, Tuple, Union, List, Optional, Any

__all__ = ["_PolygonValidator"]

###########################################################################
EndPointType = conlist(float, min_length=2, max_length=4)
CenterPointType = conlist(float, min_length=2, max_length=2)
###########################################################################
CircularArcTuple = Tuple[
    EndPointType,
    CenterPointType,
    Literal[0, 1],  # Minor/Major flag
    Literal[0, 1],  # Clockwise flag
]
###########################################################################
EllipticArcTuple = Tuple[
    EndPointType,
    CenterPointType,
    Literal[0, 1],  # Minor/Major flag
    Literal[0, 1],  # Clockwise flag
    float,  # Rotation (radians)
    float,  # Semi-major axis length
    float,  # Minor/Major axis ratio
]
###########################################################################
# Type for a single point (coordinates)
PointType = conlist(float | None, min_length=2, max_length=4)


###########################################################################
class OpenCircularArc(BaseModel):
    """
    Represents an Open Circular Arc, strictly defined by a two-element 'c'
    property array. Uses conlist for precise length validation of the points.
    """

    # Define 'c' as a Tuple to enforce the exact structure and order of the 2 elements.
    c: Tuple[
        # 1. End point: [<x>, <y>, <z>, <m>] (min 2, max 4 elements)
        conlist(float, min_length=2, max_length=4),
        # 2. Interior point: [<interior_x>, <interior_y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
    ] = Field(
        ...,
        description="The array representing the end point and interior point in order.",
    )

    # --- Properties for easier access ---

    @property
    def end_point(self) -> conlist(float, min_length=2, max_length=4):
        return self.c[0]

    @property
    def interior_point(self) -> conlist(float, min_length=2, max_length=2):
        return self.c[1]


###########################################################################
class BezierCurve(BaseModel):
    """
    Represents a Cubic Bézier Curve, strictly defined by a three-element 'b'
    property array. Uses conlist for precise length validation of the points.
    """

    # Define 'b' as a Tuple to enforce the exact structure and order of the 3 elements.
    b: Tuple[
        # 1. End point: [<x>, <y>, <z>, <m>] (min 2, max 4 elements)
        conlist(float, min_length=2, max_length=4),
        # 2. Control point 1: [<x>, <y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
        # 3. Control point 2: [<x>, <y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
    ] = Field(
        ...,
        description="The array representing the three cubic Bezier curve properties in order.",
    )

    # --- Properties for easier access ---

    @property
    def end_point(self) -> conlist(float, min_length=2, max_length=4):
        return self.b[0]

    @property
    def control_point_1(self) -> conlist(float, min_length=2, max_length=2):
        return self.b[1]

    @property
    def control_point_2(self) -> conlist(float, min_length=2, max_length=2):
        return self.b[2]


###########################################################################
class Arc(BaseModel):
    """
    Represents either a Circular Arc (4-element array) or an Elliptic Arc
    (7-element array) using the 'a' property, with strict list length validation.
    """

    # Pydantic will attempt to match the data against EllipticArcTuple first (since it's longer)
    # and then fall back to CircularArcTuple.
    a: Union[EllipticArcTuple, CircularArcTuple] = Field(
        ...,
        description="The array representing the arc properties. Length 4 for Circular, Length 7 for Elliptic.",
    )

    @property
    def arc_type(self) -> Literal["Elliptic", "Circular"]:
        """Identifies the type of arc based on the array length."""
        return "Elliptic" if len(self.a) == 7 else "Circular"

    @property
    def end_point(self) -> EndPointType:
        return self.a[0]

    @property
    def center_point(self) -> CenterPointType:
        return self.a[1]

    @property
    def is_minor(self) -> bool:
        """True if the arc is minor (1)."""
        return self.a[2] == 1

    @property
    def is_clockwise(self) -> bool:
        """True if the arc is oriented clockwise (1)."""
        return self.a[3] == 1

    @property
    def rotation_radians(self) -> Union[float, None]:
        """Major axis rotation angle (radians). Only available for Elliptic Arc."""
        # This field is only safe to access if the length is 7
        return self.a[4] if self.arc_type == "Elliptic" else None

    @property
    def semi_major_axis(self) -> Union[float, None]:
        """Length of the semi-major axis. Only available for Elliptic Arc."""
        return self.a[5] if self.arc_type == "Elliptic" else None

    @property
    def axis_ratio(self) -> Union[float, None]:
        """Ratio of the minor axis to major axis. Only available for Elliptic Arc."""
        return self.a[6] if self.arc_type == "Elliptic" else None


###########################################################################
# A segment within a curved ring is either a straight point or a curve definition
CurvedRingSegment = Union[PointType, OpenCircularArc, BezierCurve, Arc]
###########################################################################
# A curved ring is a list of segments
CurvedRing = List[CurvedRingSegment]
###########################################################################
# A standard ring is a list of points
StandardRing = List[PointType]
###########################################################################
# A list of point IDs for a single ring
RingIDs = List[Union[int, str]]  # Assuming IDs can be integers or strings


###########################################################################
class _PolygonValidator(BaseModel):
    """
    Represents a Polygon object that supports both standard and curved rings
    (with Arc and Bezier segments).
    """

    # Flags for Z and M presence
    hasZ: bool = Field(
        False, description="Indicates if the coordinates include a Z value."
    )
    hasM: bool = Field(
        False, description="Indicates if the coordinates include an M value."
    )

    # Curved Rings (outer boundary and holes)
    curvedRings: Optional[List[CurvedRing]] = Field(
        None,
        alias="curvedRings",
        description="List of rings that can contain straight line segments (PointType) or curve objects (Arc, OpenCircularArc, BezierCurve).",
    )

    # Standard Rings (outer boundary and holes, ONLY straight segments)
    rings: Optional[List[StandardRing]] = Field(
        None,
        alias="rings",
        description="List of rings that contain only straight line segments (PointType).",
    )

    # Optional list of IDs corresponding to the points/segments in the rings
    ids: Optional[List[RingIDs]] = Field(
        None, description="Optional list of point/segment IDs for each ring."
    )

    # Optional spatial reference system definition
    spatialReference: Optional[dict[str, Any]] = Field(
        None, description="The spatial reference of the geometry."
    )

    @field_validator("curvedRings", "rings", mode="after")
    @classmethod
    def check_at_least_one_ring_type_is_present(
        cls, v: Any, info: FieldValidationInfo
    ) -> Any:
        """Ensure either 'curvedRings' or 'rings' is present."""
        # 'info.data' contains validated fields up to this point
        if (
            info.data.get("curvedRings") is None
            and info.data.get("rings") is None
            and v is None
        ):
            # Need to check both 'curvedRings' and 'rings' as this validator runs for both
            if info.field_name == "curvedRings" or info.field_name == "rings":
                # Check for the *other* field as well if the current one is None
                if (
                    info.data.get("curvedRings") is None
                    and info.data.get("rings") is None
                ):
                    raise ValueError(
                        "Polygon must contain at least one of 'curvedRings' or 'rings'."
                    )
        return v

    @field_validator("ids", mode="after")
    @classmethod
    def check_ids_length_matches_rings(
        cls, v: Optional[List[RingIDs]], info: FieldValidationInfo
    ) -> Optional[List[RingIDs]]:
        """Ensure the number of ID lists matches the number of total rings."""
        if v is None:
            return v

        data = info.data
        num_rings = 0
        if data.get("curvedRings"):
            num_rings += len(data["curvedRings"])
        if data.get("rings"):
            num_rings += len(data["rings"])

        if len(v) != num_rings:
            raise ValueError(
                f"The number of lists in 'ids' ({len(v)}) must match the total number of rings ({num_rings})."
            )

        # The full validation check for each ring's segment count is omitted as per original note,
        # but the check for the number of ID lists is crucial and is maintained.
        return v
