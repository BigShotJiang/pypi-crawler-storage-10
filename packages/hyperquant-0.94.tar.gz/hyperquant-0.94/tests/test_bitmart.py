import pybotters

from hyperquant.broker.lighter import Lighter
import asyncio
from logging import Logger
import time
from dataclasses import dataclass
from typing import Any, Literal
from hyperquant.logkit import get_logger
from hyperquant.broker.bitmart import Bitmart



async def test_update():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client) as broker:
            # print(broker.store.detail.find()[0])
            await broker.update('balances')
            print(broker.store.balances.find())
            # await broker.update('history_orders')
            # print(broker.store.orders.find())

async def test_place():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client) as broker:
            order = await broker.place_order(
                symbol='TRXUSDT',
                way='buy',
                category='market',
                price=0.0296,
                qty=1,
            )
            print(order)

async def test_sub_book():
    async with pybotters.Client() as client:
        async with Bitmart(client=client) as broker:
            broker.store.book.limit = 1
            await broker.sub_orderbook(["TRXUSDT", 'XRPUSDT', 'DOTUSDT'])
            while True:
                # await broker.store.book.wait()
                # print(broker.store.book.find())
                asks = broker.store.book.find({"S": "a", 's': 'TRXUSDT'})
                bids = broker.store.book.find({"S": "b", 's': 'TRXUSDT'})
                # 订单薄format化输出
                print("Asks:")
                for ask in asks:
                    print(f"Price: {ask['p']}, Quantity: {ask['q']}")
                print("Bids:")
                for bid in bids:
                    print(f"Price: {bid['p']}, Quantity: {bid['q']}")
                print("-" * 30)
                await asyncio.sleep(1)


            # with broker.store.book.watch() as stream:
            #     async for change in stream:
            #         print(change)

async def test_auto_refresh():
    async with pybotters.Client(apis='./apis.json') as client:
        async with Bitmart(client=client, apis='./apis.json') as broker:
            await broker.auto_refresh(0, test=True)
            await asyncio.sleep(2)

if __name__ == "__main__":
    asyncio.run(test_sub_book())
