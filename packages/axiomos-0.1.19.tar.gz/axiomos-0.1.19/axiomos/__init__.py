﻿
# --- version marker ---
try:
    from importlib.metadata import version
    __version__ = version('axiomos')
except Exception:
    __version__ = '0+unknown'
