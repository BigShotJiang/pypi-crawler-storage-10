# UnieAI Meeting Room MCP Client

一個基於 Model Context Protocol (MCP) 的會議室預約管理系統客戶端。

## 功能特色

- 🏢 查詢所有可用會議室
- 📅 預約會議室
- 📋 查看會議室預約記錄
- 🔌 基於 FastAPI 的 RESTful API
- 🐳 Docker 容器化支援
- 📦 PyPI 套件發布

## 快速開始

### 方法一：使用 Docker (推薦)

1. 克隆專案：
```bash
git clone https://github.com/unieai/unieai_mcp_meetingroom.git
cd unieai_mcp_meetingroom
```

2. 使用 Docker Compose 啟動：
```bash
docker-compose up -d
```

3. 訪問 API 文檔：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

### 方法二：本地安裝

1. 安裝依賴：
```bash
pip install -r requirements.txt
```

2. 啟動服務：
```bash
uvicorn meeting_room_mcp:app --host 0.0.0.0 --port 8000 --reload
```

### 方法三：使用 PyPI 套件

```bash
pip install unieai-meeting-room-mcp
```

## API 端點

### 查詢會議室
```http
GET /rooms
```

### 預約會議室
```http
POST /reservations
Content-Type: application/json

{
  "room_id": 1,
  "start_time": "2025-01-21T09:00:00",
  "end_time": "2025-01-21T10:00:00",
  "reserved_by": "張三"
}
```

### 查詢會議室預約記錄
```http
GET /rooms/{room_id}/reservations
```

## 配置

### 環境變數

- `BASE_URL`: 遠端會議室 API 的基礎 URL (預設: `http://0.tcp.jp.ngrok.io:14868`)

### 修改配置

編輯 `app/config.py` 文件來修改 API 端點：

```python
BASE_URL = "http://your-api-server.com"
```

## 開發

### 設置開發環境

1. 克隆專案：
```bash
git clone https://github.com/unieai/unieai_mcp_meetingroom.git
cd unieai_mcp_meetingroom
```

2. 創建虛擬環境：
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

3. 安裝開發依賴：
```bash
pip install -r requirements.txt
pip install -e .
```

### 運行測試

```bash
pytest
```

### 代碼格式檢查

```bash
# 安裝開發工具
pip install black flake8 isort

# 格式化代碼
black .
isort .

# 檢查代碼風格
flake8 .
```

## 部署

### Docker 部署

1. 構建映像：
```bash
docker build -t unieai-meeting-room-mcp .
```

2. 運行容器：
```bash
docker run -p 8000:8000 unieai-meeting-room-mcp
```

### 雲端部署

#### Heroku

1. 創建 `Procfile`：
```
web: uvicorn meeting_room_mcp:app --host 0.0.0.0 --port $PORT
```

2. 部署：
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

#### Railway

1. 連接 GitHub 倉庫
2. 自動部署

#### Google Cloud Run

1. 構建並推送映像：
```bash
gcloud builds submit --tag gcr.io/PROJECT-ID/meeting-room-mcp
```

2. 部署：
```bash
gcloud run deploy --image gcr.io/PROJECT-ID/meeting-room-mcp --platform managed
```

## 發布到 PyPI

1. 安裝構建工具：
```bash
pip install build twine
```

2. 構建套件：
```bash
python -m build
```

3. 上傳到 PyPI：
```bash
twine upload dist/*
```

## 貢獻

歡迎提交 Issue 和 Pull Request！

1. Fork 專案
2. 創建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 開啟 Pull Request

## 授權

本專案採用 MIT 授權 - 查看 [LICENSE](LICENSE) 文件了解詳情。

## 聯絡我們

- 專案連結: [https://github.com/unieai/unieai_mcp_meetingroom](https://github.com/unieai/unieai_mcp_meetingroom)
- 問題回報: [https://github.com/unieai/unieai_mcp_meetingroom/issues](https://github.com/unieai/unieai_mcp_meetingroom/issues)
