from fastapi import FastAPI
from app.routes import rooms, reservations

app = FastAPI(title="Meeting Room MCP", version="1.0.0")

app.include_router(rooms.router)
app.include_router(reservations.router)

@app.get("/")
def root():
    return {"message": "Meeting Room MCP Client API"}
