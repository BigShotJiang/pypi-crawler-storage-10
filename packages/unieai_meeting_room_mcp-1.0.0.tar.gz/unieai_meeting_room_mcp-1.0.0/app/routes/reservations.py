from fastapi import APIRouter
from app.models import ReservationRequest, ReservationResponse, RoomReservation
from app.client import MeetingRoomClient

router = APIRouter()
client = MeetingRoomClient()

@router.post("/reservations", response_model=ReservationResponse)
async def create_reservation(req: ReservationRequest):
    return await client.create_reservation(req.dict())

@router.get("/rooms/{room_id}/reservations", response_model=list[RoomReservation])
async def list_room_reservations(room_id: int):
    return await client.get_room_reservations(room_id)
