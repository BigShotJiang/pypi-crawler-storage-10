from fastapi import APIRouter
from app.client import MeetingRoomClient
from app.models import Room

router = APIRouter()
client = MeetingRoomClient()

@router.get("/rooms", response_model=list[Room])
async def list_rooms():
    return await client.get_rooms()
