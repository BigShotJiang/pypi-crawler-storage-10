from pydantic import BaseModel, Field
from typing import Optional, List

class Room(BaseModel):
    id: int
    name: str
    capacity: int

class ReservationRequest(BaseModel):
    room_id: int = Field(..., description="會議室 ID")
    start_time: str
    end_time: str
    reserved_by: str

class ReservationResponse(BaseModel):
    reservation_id: Optional[int]
    status: str

class RoomReservation(BaseModel):
    id: int
    room_id: int
    start_time: str
    end_time: str
    reserved_by: str
