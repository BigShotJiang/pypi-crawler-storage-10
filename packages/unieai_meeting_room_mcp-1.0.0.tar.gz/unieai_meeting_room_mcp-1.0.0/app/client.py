import httpx
from fastapi import HTTPException
from app.config import BASE_URL

class MeetingRoomClient:
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=10.0)
        self.base_url = BASE_URL.rstrip("/")

    async def get_rooms(self):
        """查詢所有會議室"""
        try:
            resp = await self.client.get(f"{self.base_url}/rooms")
            resp.raise_for_status()
            return resp.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"連線錯誤：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)

    async def create_reservation(self, data: dict):
        """預約會議室"""
        try:
            resp = await self.client.post(f"{self.base_url}/reservations", json=data)
            resp.raise_for_status()
            return resp.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線伺服器：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)

    async def get_room_reservations(self, room_id: int):
        """查詢會議室預約紀錄"""
        try:
            resp = await self.client.get(f"{self.base_url}/rooms/{room_id}/reservations")
            resp.raise_for_status()
            return resp.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線伺服器：{e}")
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=e.response.text)

    async def close(self):
        await self.client.aclose()
