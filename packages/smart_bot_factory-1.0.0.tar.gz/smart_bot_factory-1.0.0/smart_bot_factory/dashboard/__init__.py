from ..core.decorators import prepare_dashboard_info

__all__ = ["prepare_dashboard_info"]
