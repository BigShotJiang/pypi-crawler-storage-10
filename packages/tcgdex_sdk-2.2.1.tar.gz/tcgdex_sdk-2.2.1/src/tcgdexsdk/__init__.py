# Do no edit, set automatically on build (Also on top so it can be used by the code)
__version__ = "2.2.1"

from tcgdexsdk.endpoints.Endpoint import Endpoint
from tcgdexsdk.enums import Language
from tcgdexsdk.models.Card import Card
from tcgdexsdk.models.CardResume import CardResume
from tcgdexsdk.models.Serie import Serie
from tcgdexsdk.models.SerieResume import SerieResume
from tcgdexsdk.models.Set import Set
from tcgdexsdk.models.SetResume import SetResume
from tcgdexsdk.models.StringEndpoint import StringEndpoint
from tcgdexsdk.query import Query
from tcgdexsdk.tcgdex import TCGdex

__all__ = [
    "TCGdex",
    "Endpoint",
    "Language",
    "CardResume",
    "Card",
    "Serie",
    "SerieResume",
    "Set",
    "SetResume",
    "StringEndpoint",
    "Query",
]
