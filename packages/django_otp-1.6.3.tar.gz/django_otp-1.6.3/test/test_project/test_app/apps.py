from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = 'test_project.test_app'
    default_auto_field = 'django.db.models.AutoField'
