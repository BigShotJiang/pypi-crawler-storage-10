(contributing)=

```{include} ../CONTRIBUTING.md

```
