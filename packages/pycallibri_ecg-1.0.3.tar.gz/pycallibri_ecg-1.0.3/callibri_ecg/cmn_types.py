from enum import Enum


class NetworkFrequency(Enum):
    Hz50 = 1
    Hz60 = 2