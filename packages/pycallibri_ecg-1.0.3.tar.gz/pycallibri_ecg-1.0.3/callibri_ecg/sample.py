from callibri_ecg.cmn_types import NetworkFrequency
from callibri_ecg_lib import CallibriMath


def main():
    callibri_math = CallibriMath(250, 127, 30)
    callibri_math.set_network_frequency(NetworkFrequency.Hz50)

    rawData = [float(x) for x in range(25)]
    callibri_math.push_and_process_data(rawData)

    is_corrupted = callibri_math.initial_signal_corrupted()
    print("Is Corrupted: " + str(is_corrupted))

    if callibri_math.rr_detected():
        hr = callibri_math.get_hr()
        print("hr: " + str(hr))
        callibri_math.set_rr_checked()




if __name__ == '__main__':
    main()
