# Evaluation Report: wikipedia_extraction

            Evaluation Summary: _wrapper            
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┓
┃ Case ID           ┃ Scores            ┃ Duration ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━┩
│ simple_extraction │ Evaluator1: 0.800 │    14.8s │
├───────────────────┼───────────────────┼──────────┤
│ Averages          │ Evaluator1: 0.800 │    14.8s │
└───────────────────┴───────────────────┴──────────┘
