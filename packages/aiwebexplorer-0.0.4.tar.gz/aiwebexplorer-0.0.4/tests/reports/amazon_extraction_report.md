# Evaluation Report: amazon_extraction

            Evaluation Summary: _wrapper            
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┓
┃ Case ID           ┃ Scores            ┃ Duration ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━┩
│ amazon_extraction │ Evaluator2: 0.420 │    46.6s │
├───────────────────┼───────────────────┼──────────┤
│ Averages          │ Evaluator2: 0.420 │    46.6s │
└───────────────────┴───────────────────┴──────────┘
