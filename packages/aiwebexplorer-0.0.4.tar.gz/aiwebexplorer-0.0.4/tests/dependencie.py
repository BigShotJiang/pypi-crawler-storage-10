from typing import Any
from unittest.mock import Mock

from aiwebexplorer.interfaces import IAgent


def get_agent_mock(*args: Any, **kwargs: Any) -> IAgent[Any]:
    """Get a mock agent for testing."""
    return Mock(spec=IAgent[Any])
