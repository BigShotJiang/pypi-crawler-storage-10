# WebExplorer Test Suite

This directory contains comprehensive tests for the AI Web Explorer package.

## Test Structure

### Core Test Files

- **`test_webexplorer.py`** - Main test suite for WebExplorer class
- **`test_interfaces.py`** - Tests for IAgent and IResponse interfaces
- **`conftest.py`** - Shared fixtures and pytest configuration

### Test Categories

#### Unit Tests
- Interface compliance testing
- Initialization and configuration
- Prompt parsing functionality
- Site detection logic
- Confidence extraction
- Caching behavior

#### Integration Tests
- End-to-end WebExplorer functionality
- Agent polymorphism
- Error handling
- Cleanup operations

#### Mock Tests
- Browser interaction mocking
- HTTP request mocking
- Agent response mocking

## Running Tests

### Prerequisites

#### 1. Install test dependencies:
```bash
pip install pytest pytest-asyncio pytest-mock
```

#### 2. Configure environment variables:

For integration tests that use real LLM providers, you need to set the required environment variables:

```bash
# Required for real API calls (not needed for mocked unit tests)
export AWE_LLM_PROVIDER=openai
export AWE_LLM_MODEL=gpt-4
export AWE_LLM_API_KEY=your-api-key-here
```

Or create a `.env` file in the WebExplorer directory:

```env
AWE_LLM_PROVIDER=openai
AWE_LLM_MODEL=gpt-4
AWE_LLM_API_KEY=your-api-key-here
```

**Note**: Most tests use dependency injection to mock agents, so API keys are only needed for integration/evaluation tests.

### Basic Test Execution

```bash
# Run all tests
pytest

# Run with verbose output
pytest -v

# Run specific test file
pytest tests/test_webexplorer.py

# Run specific test class
pytest tests/test_webexplorer.py::TestWebExplorerInterface

# Run specific test method
pytest tests/test_webexplorer.py::TestWebExplorerInterface::test_webexplorer_implements_iagent
```

### Test Markers

```bash
# Run only unit tests
pytest -m unit

# Run integration tests
pytest -m integration

# Skip slow tests
pytest -m "not slow"

# Skip web-dependent tests
pytest -m "not web"
```

### Coverage (Optional)

```bash
# Install coverage tools
pip install pytest-cov

# Run with coverage
pytest --cov=aiwebexplorer --cov-report=html

# View coverage report
open htmlcov/index.html
```

## Dependency Injection System

This test suite uses a custom dependency injection system for mocking and testing. The system allows you to override dependencies at runtime without modifying the core code.

### How It Works

The `Dependency` class (from `aiwebexplorer.dependencies`) provides a context manager for overriding dependencies:

```python
from aiwebexplorer.agent_factory import get_agent_dependency

# Create a mock agent
def mock_agent_factory(*args, **kwargs):
    return MockAgent()

# Override the dependency in a test
with get_agent_dependency.override(mock_agent_factory):
    # Code here will use the mock instead of the real agent factory
    result = some_function_that_uses_agents()
```

### Using Dependency Injection in Tests

#### Basic Override Pattern

```python
import pytest
from aiwebexplorer.agent_factory import get_agent_dependency

@pytest.mark.asyncio
async def test_with_mock_agent():
    """Test using a mock agent via dependency injection."""
    
    def get_agent_mock(*args, **kwargs):
        mock = AsyncMock()
        mock.arun.return_value = "Mocked response"
        return mock
    
    with get_agent_dependency.override(get_agent_mock):
        # Your test code here
        explorer = WebExplorer()
        result = await explorer.arun("test query")
        assert "Mocked" in result
```

#### Benefits

1. **No monkey patching**: Clean, explicit dependency replacement
2. **Context-based**: Automatically restores original after the context
3. **Type-safe**: Maintains function signatures
4. **Thread-safe**: Each override is isolated to its context

### Available Dependencies

- **`get_agent_dependency`**: Main agent factory used throughout the codebase
  - Override this to inject mock agents in tests
  - Automatically used by `get_evaluate_request_agent()`, `get_extraction_agent()`, `get_finalizer_agent()`

### Real-World Examples

#### Example 1: Testing Site Detection with Mocked Agents

From `test_site_detection.py`:

```python
@pytest.mark.asyncio
async def test_amazon_product_extraction():
    """Test extraction from Amazon product page."""
    
    def get_agent_mock(*args, **kwargs):
        mock = AsyncMock()
        if kwargs.get("name") == "evaluate_request_agent":
            mock.arun.return_value = """
            [QUESTION]: What is the product title and price?
            [URL]: https://www.amazon.com/dp/B08N5WRWNW
            [KEYWORDS]: product, title, price
            [RESULT]: OK
            """
        elif kwargs.get("name") == "extraction_agent":
            mock.arun.return_value = """
            Apple AirPods Max
            $549.00
            [CONFIDENCE]: HIGH
            """
        return mock
    
    with get_agent_dependency.override(get_agent_mock):
        explorer = WebExplorer()
        result = await explorer.arun(
            "Get product info from https://www.amazon.com/dp/B08N5WRWNW"
        )
        assert "AirPods" in result
```

#### Example 2: Testing Text Parsing with Keyword Highlighting

From `test_text_parsing.py`:

```python
@pytest.mark.asyncio
async def test_keyword_extraction():
    """Test that relevant content is extracted based on keywords."""
    
    def get_agent_mock(*args, **kwargs):
        mock = AsyncMock()
        mock.arun.return_value = """
        [QUESTION]: What are the specs?
        [URL]: https://example.com
        [KEYWORDS]: specifications, memory, processor
        [RESULT]: OK
        """
        return mock
    
    with get_agent_dependency.override(get_agent_mock):
        explorer = WebExplorer()
        # Test implementation here
```

## Test Fixtures

### Available Fixtures

- **`webexplorer`** - Basic WebExplorer instance
- **`webexplorer_with_custom_config`** - WebExplorer with custom settings
- **`mock_html_content`** - Sample HTML for testing
- **`mock_amazon_html`** - Amazon-style HTML
- **`mock_ebay_html`** - eBay-style HTML
- **`mock_agent_response`** - Mock agent response
- **`mock_browser`** - Mock browser for testing

### Using Fixtures

```python
def test_with_fixture(webexplorer, mock_html_content):
    # Use the fixtures in your test
    assert webexplorer.max_content_length == 5000
    assert "Test Product Store" in mock_html_content
```

## Test Patterns

### Async Testing

```python
@pytest.mark.asyncio
async def test_async_functionality():
    explorer = WebExplorer()
    response = await explorer.arun("test prompt")
    assert response.content is not None
```

### Mocking with Dependency Injection

The preferred way to mock agents is using the dependency injection system:

```python
from aiwebexplorer.agent_factory import get_agent_dependency
from unittest.mock import AsyncMock

@pytest.mark.asyncio
async def test_with_dependency_injection():
    """Test using dependency injection to mock agents."""
    
    def get_agent_mock(*args, **kwargs):
        mock_agent = AsyncMock()
        mock_agent.arun.return_value = """
        [QUESTION]: What is the price?
        [URL]: https://example.com
        [KEYWORDS]: price, cost
        [RESULT]: OK
        """
        return mock_agent
    
    # Override the dependency
    with get_agent_dependency.override(get_agent_mock):
        explorer = WebExplorer()
        result = await explorer.arun("test prompt")
        assert "example.com" in result

### Traditional Mocking (for internal methods)

For internal methods that don't use dependency injection:

```python
from unittest.mock import patch

@patch.object(WebExplorer, '_explore_fast')
async def test_with_mock(mock_explore):
    mock_explore.return_value = "mocked result"
    explorer = WebExplorer()
    response = await explorer.arun("test")
    assert response.content == "mocked result"
```

### Parametrized Tests

```python
@pytest.mark.parametrize("url,expected_site", [
    ("https://amazon.com/product", "amazon"),
    ("https://ebay.com/item", "ebay"),
    ("https://unknown.com", None),
])
def test_site_detection(url, expected_site):
    explorer = WebExplorer()
    assert explorer._detect_site_type(url) == expected_site
```

## Test Data

### Mock HTML Content

Tests use realistic HTML content to simulate real web pages:

- Product pages with titles, prices, descriptions
- E-commerce site structures (Amazon, eBay)
- Various HTML elements and CSS selectors

### Mock Responses

- Agent responses with confidence indicators
- Error responses for failure scenarios
- Structured data responses

## Continuous Integration

### GitHub Actions Example

```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.12
    - name: Install dependencies
      run: |
        pip install -e .
        pip install pytest pytest-asyncio
    - name: Run tests
      run: pytest
```

## Best Practices

### Test Organization

1. **One test class per main class/functionality**
2. **Descriptive test method names**
3. **Arrange-Act-Assert pattern**
4. **Independent tests (no dependencies between tests)**

### Mocking Strategy

1. **Mock external dependencies** (HTTP requests, browser)
2. **Use fixtures for common test data**
3. **Mock at the right level** (not too high, not too low)
4. **Verify mock interactions when important**

### Async Testing

1. **Use `@pytest.mark.asyncio` for async tests**
2. **Mock async functions with `AsyncMock`**
3. **Use `asyncio.run()` for simple async operations**

### Error Testing

1. **Test both success and failure scenarios**
2. **Verify error messages and types**
3. **Test edge cases and boundary conditions**

## Troubleshooting

### Common Issues

1. **Import errors**: Ensure the package is installed in development mode
2. **Async test failures**: Check `@pytest.mark.asyncio` decorator
3. **Mock not working**: Verify mock is applied before the code under test runs
4. **Fixture not found**: Check fixture is defined in `conftest.py` or same file

### Debug Mode

```bash
# Run with debug output
pytest -v -s --tb=long

# Run single test with debug
pytest -v -s tests/test_webexplorer.py::TestWebExplorerInterface::test_webexplorer_implements_iagent
```

## Contributing

When adding new tests:

1. **Follow existing naming conventions**
2. **Add appropriate docstrings**
3. **Use existing fixtures when possible**
4. **Add new fixtures to `conftest.py` if reusable**
5. **Update this README if adding new test categories**
