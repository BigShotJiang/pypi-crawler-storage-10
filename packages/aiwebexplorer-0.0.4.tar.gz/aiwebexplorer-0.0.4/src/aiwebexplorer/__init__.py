"""AI Web Explorer - An agent for agents to explore the web."""

try:
    from ._version import version as __version__
except ImportError:
    # Fallback for development
    __version__ = "0.0.0+dev"

from .agents import get_evaluate_request_agent as get_evaluate_request_agent
from .agents import get_extraction_agent as get_extraction_agent
from .agents import get_finalizer_agent as get_finalizer_agent
from .webexplorer import WebExplorer as WebExplorer
