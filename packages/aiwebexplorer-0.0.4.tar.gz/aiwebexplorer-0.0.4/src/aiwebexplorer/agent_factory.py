from typing import Any, Literal, NewType, TypeVar

from agno.agent import Agent
from agno.models.deepseek import DeepSeek
from agno.models.openai import OpenAIChat
from agno.models.together import Together

from aiwebexplorer.dependencies import Dependency
from aiwebexplorer.interfaces import IAgent

from .config import get_provider_config

T = TypeVar("T")

ModelProvider = Literal[
    "openai",
    "togetherai",
    "deepseek",
]

ModelIdMap: NewType = dict[ModelProvider, str]

TOGETHERAI_APIKEY = "TOGETHERAI_APIKEY", "togetherai"
DEEPSEEK_APIKEY = "DEEPSEEK_APIKEY", "deepseek"
OPENAI_APIKEY = "OPENAI_APIKEY", "openai"

SupportedModelProvider = Together | DeepSeek | OpenAIChat


def _get_model(
    model_id: str | None = None,
    provider: ModelProvider | None = None,
    api_key: str | None = None,
) -> SupportedModelProvider:
    provider_config = get_provider_config()
    provider = provider or provider_config.AWE_LLM_PROVIDER
    model_id = model_id or provider_config.AWE_LLM_MODEL
    api_key = api_key or provider_config.AWE_LLM_API_KEY

    if not provider:
        raise RuntimeError("Specify a provider either in the configuration or as env variable AWE_LLM_PROVIDER")

    if not model_id:
        raise RuntimeError("Specify a model id either in the configuration or as env variable AWE_LLM_MODEL")

    if not api_key:
        raise RuntimeError("Specify an api key either in the configuration or as env variable AWE_LLM_API_KEY")

    if provider == "togetherai":
        return Together(id=model_id, api_key=api_key)
    elif provider == "deepseek":
        return DeepSeek(id=model_id, api_key=api_key)
    elif provider == "openai":
        return OpenAIChat(id=model_id, api_key=api_key)

    raise ValueError(f"Invalid provider: {provider}")


def get_agent(
    name: str,
    instructions: list[str],
    *,
    model_id: str | None = None,
    api_key: str | None = None,
    provider: ModelProvider | None = None,
    **kwargs: Any,
) -> IAgent[Any]:
    """Get an agent with the given name, instructions, content type, model, and other kwargs.

    See Agent constructor for Agno agent details.
    """
    model = _get_model(model_id, provider, api_key)
    return Agent(
        name=name,
        instructions=instructions,
        model=model,
        **kwargs,
    )


get_agent_dependency = Dependency(get_agent)
