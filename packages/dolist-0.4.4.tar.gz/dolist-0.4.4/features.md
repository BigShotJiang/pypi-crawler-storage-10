# Dolist

Task Management (To-Do) on terminal

## Features

- TUI
- CLI
- Reminder Service
- import/export
- bulk operations
- Shell
