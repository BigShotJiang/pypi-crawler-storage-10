"""Tests for dopy package."""
