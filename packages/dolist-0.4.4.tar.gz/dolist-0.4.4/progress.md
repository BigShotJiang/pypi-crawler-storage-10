# DoList Implementation Progress

## Overview
This document tracks the implementation of features and fixes requested in `.prompt.md`.

## Status Legend
- 🔴 Not Started
- 🟡 In Progress
- 🟢 Completed

## Summary
**Completed:** 14/17 features (82%)

### Phase 1: TUI Improvements ✅ COMPLETE
All 5 TUI improvement tasks have been implemented and tested.

### Phase 2: Auditing & Logging ✅ COMPLETE
TaskHistory table created and integrated. Both TUI and CLI history viewing implemented.

### Phase 3: Priorities and Sizes ✅ COMPLETE
Priority and size fields added with full CLI/TUI support and database migration.

### Phase 4: Recurring Tasks ✅ COMPLETE
Recurring reminder support with "repeat" keyword fully implemented.

### Phase 5: Task Dependencies ✅ COMPLETE
Task dependency tracking through note markers with full visual indicators and navigation.

### Phase 6: Multi-Database Service ✅ COMPLETE
Reminder service can now monitor multiple databases simultaneously.

### Phase 7: Remaining Work
- Reminder service: Notification actions (delay/activate buttons)
- Reporting features (2 features)

---

## TUI Improvements

### 1. Search State Display
**Status:** 🟢 Completed
**Description:** Show current applied search filter at the top of the screen before filter toggles
**Example:** `3 results for '/tag=work'`
**Implementation:** Added Static widget with ID `search_status` that displays search results count and filter description

### 2. Deselect with Space
**Status:** 🟢 Completed
**Description:** Fix ValueError when pressing space to deselect a task
**Error:** `ValueError: invalid literal for int() with base 10: 'cyan]'`
**Implementation:** Fixed by using `row_key.value` instead of parsing displayed text with Rich markup

### 3. Select with Space - Auto-move Cursor
**Status:** 🟢 Completed
**Description:** After selecting/deselecting with space, move cursor to next/previous task
**Implementation:** After selecting, cursor moves down; after deselecting, cursor moves up

### 4. Database Path Display
**Status:** 🟢 Completed
**Description:** Show current database path at top status: `/path/to/tasks.db`
**Implementation:** Added Static widget with ID `db_path` that displays the database file path

### 5. Database Selection with 'u' Key
**Status:** 🟢 Completed
**Description:** Press 'u' to open popup for switching databases
**Implementation:** Created DatabaseSwitchScreen modal that shows all .db files in config directory, allows selecting existing databases or creating new ones

---

## Reminder Service

### 6. Multiple Databases Support
**Status:** 🟢 Completed
**Description:** Allow reminder service to watch multiple databases with verbose debugging
**Details:**
- ✅ Added `--databases` parameter to service command
- ✅ Added `--verbose` flag for detailed debugging output
- ✅ Added `--interval N` parameter for custom check intervals (default: 30)
- ✅ Support config file setting: `[reminder]` `databases = ["db1", "db2"]`
- ✅ CLI parameter overrides config file
- ✅ Service loops through all databases each cycle
- ✅ Displays database name in logs and notifications
- ✅ Verbose mode shows cycle info, task counts, and due reminders
- ✅ All tests passing (107 tests - added 8 new service tests)
- ✅ README documentation updated with all features

**Implementation:**
- Modified `service()` command in do.py to accept `--databases`, `--verbose`, and `--interval` parameters
- Parses colon-separated database list (e.g., "tasks.db:work.db")
- Supports absolute paths (e.g., "/tmp/foo.db:/tmp/bar.db")
- Falls back to config file setting if CLI not provided
- Created `run_multi_db_service_loop()` in service.py
- Initializes all databases before starting loop
- Processes reminders from each database sequentially per cycle
- Includes database name in task_data for notifications
- Verbose mode displays cycle number, timestamp, task counts, and processing details
- Custom interval allows faster/slower reminder checking
- Created comprehensive test suite in `tests/test_service.py` with 8 tests covering:
  - Service command parameter acceptance (databases, verbose, interval)
  - Trigger reminder functionality (default notify-send, custom commands, database names)
  - Service loop function signatures and defaults
- Fixed database path display to use parentheses instead of brackets to avoid Rich markup errors

### 7. Notification Actions
**Status:** 🔴 Not Started
**Description:** Add delay and activate buttons to notifications
**Details:**
- Use notify2 library
- Add "Snooze" action to delay task
- Add "Activate" action to open shell with `dolist ID edit`
- Handle action callbacks

### 8. Recurring Tasks
**Status:** 🟢 Completed
**Description:** Support recurring reminders with "repeat" keyword
**Details:**
- ✅ Parse `--remind 2 hours repeat` syntax
- ✅ After triggering reminder, reschedule instead of cleaning up
- ✅ Store repeat configuration in database (`reminder_repeat` field)
- ✅ Service handles rescheduling logic automatically
- ✅ Updated Task model, CLI, and TUI to support recurring reminders
- ✅ Created migration v2 for adding `reminder_repeat` field
- ✅ All tests passing (99 tests)
- ✅ README documentation updated

**Implementation:**
- Added `reminder_repeat` column to `dolist_tasks` and `dolist_task_history` tables
- Updated `parse_reminder()` to return 3 values: (datetime, error, repeat_interval)
- Modified service to check for `reminder_repeat` and reschedule instead of clearing
- CLI supports: `dolist add "Task" --reminder "2 hours repeat"`
- TUI supports repeat syntax in add/edit screens
- Migration system updated to v2 for backward compatibility

---

## Auditing & Logging

### 9. TaskHistory Table
**Status:** 🟢 Completed
**Description:** Create database table to track all task changes
**Implementation:**
- Created `dolist_task_history` table with fields: `changed_at, task_id, name, tag, status, reminder, notes, created_on, deleted`
- Added `record_task_history()` function to record snapshots after every task modification
- Integrated history recording in both CLI and TUI for all task update operations
- **Fix:** Renamed `when` column to `changed_at` to avoid SQL reserved keyword conflict

### 10. TUI History View
**Status:** 🟢 Completed
**Description:** Press 'h' on task to view change history
**Implementation:** Created TaskHistoryScreen modal that displays all historical changes for a task in a table format

### 11. CLI History Command
**Status:** 🟢 Completed
**Description:** `dolist 1 history` to show task history
**Implementation:** Added 'history' action to task command that queries and displays task history in table format

---

## Reports

### 12. TUI Reports with Charts
**Status:** 🔴 Not Started
**Description:** Press 'p' to show pie/bar charts for metrics
**Details:**
- Metrics: total tasks by period, tasks per status, tasks per tag
- Support periods: day, week, month, year
- Use pie charts and bar charts
- Allow changing period dynamically with live replot
- Apply to currently filtered/searched tasks

### 13. CLI Report JSON Output
**Status:** 🔴 Not Started
**Description:** `dolist ls --report` outputs JSON metrics
**Details:**
- Output JSON format with all metrics
- Respect filters applied to `ls` command
- Same metrics as TUI reports

---

## Priorities and Sizes

### 14. Priority and Size Fields
**Status:** 🟢 Completed
**Description:** Add priority and size fields to Task model
**Details:**
- ✅ Add `priority: int` field (default: 0)
- ✅ Add `size: str` field (values: U, S, M, L - default: U)
- ✅ Update both `dolist_task` and `dolist_task_history` tables
- ✅ Implement DB migration for existing databases
- ✅ CLI: `--priority N`, `--size S|Small` (case insensitive)
- ✅ TUI: Add priority and size to add/edit modals
- ✅ TUI: Add priority and size columns (clickable for sorting)
- ✅ TUI: Default sort by `priority,created`
- ✅ TUI: History table includes priority and size
- ✅ All tests updated and passing

**Implementation:**
- Created migration system in `dolist/migrations.py` to handle schema changes
- Migration v1 adds priority and size columns to existing databases
- Updated Task model with validators for size field
- CLI add command supports `--priority` and `--size` flags
- TUI add/edit screens include priority and size inputs
- TUI table displays priority and size columns
- Default sort changed to priority (desc) with created_on as secondary sort
- Sorting by priority and size fully functional
- **Configurable column ordering**: Users can customize which columns to display and in what order via config file
- Default columns: `["id", "name", "tag", "status", "reminder", "notes", "created", "priority", "size"]`
- Priority and size positioned as last columns by default
- ID column is always required and must be first
- Both CLI and TUI respect column configuration

---

## Task Dependency

### 15. Task Dependencies
**Status:** 🟢 Completed
**Description:** Implement task dependency tracking via notes
**Details:**
- ✅ Parse notes for `depends #N` and `under #N` markers
- ✅ Tasks with dependencies show status `blocked` (auto-computed)
- ✅ Blocked tasks: display as `2! name` with red-ish color
- ✅ Under tasks: display as `3> name` with yellowish color
- ✅ TUI: `p` key to navigate to parent task
- ✅ TUI: `c` key to search children (apply `under=N` filter)
- ✅ Parent tasks show child count: `Turn on the oven (1)`
- ✅ CLI: `--under N` filter support
- ✅ Blocked task status is immutable (cannot be manually changed)
- ✅ All other fields remain editable on blocked tasks
- ✅ `depends` takes precedence over `under` for visual style
- ✅ All tests passing (99 tests)
- ✅ README documentation updated

**Implementation:**
- Created `dolist/dependency.py` module with parsing and display logic
- `parse_dependencies()` extracts `depends #N` and `under #N` from notes
- `get_dependency_display_info()` computes display prefix and colors
- `count_children()` counts how many tasks depend on a parent
- Updated CLI `ls` command to show dependency indicators and support `--under` filter
- Updated TUI to display dependency indicators with appropriate colors
- Added TUI key bindings: `p` for goto_parent, `c` for show_children
- Prevented status changes on blocked tasks in both CLI and TUI
- Task model includes dependency helper methods

---

## Notes
- All changes will be committed incrementally
- Each feature will be tested before moving to the next
