"""Setup script for openrainflow package."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()

