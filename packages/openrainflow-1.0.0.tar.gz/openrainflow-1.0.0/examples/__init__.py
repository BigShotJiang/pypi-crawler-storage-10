"""Examples for openrainflow package."""

