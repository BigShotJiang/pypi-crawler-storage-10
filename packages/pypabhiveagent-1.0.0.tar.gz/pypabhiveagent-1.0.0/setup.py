"""
Setup configuration for pypabhiveagent package.
"""

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read version from __init__.py
version = {}
with open(os.path.join(this_directory, 'pypabhiveagent', '__init__.py'), encoding='utf-8') as f:
    for line in f:
        if line.startswith('__version__'):
            exec(line, version)
            break

setup(
    name='pypabhiveagent',
    version=version.get('__version__', '0.1.0'),
    author='pypabhiveagent',
    author_email='kerwinchou@yeah.net',
    description='A Python package for querying Hive data and processing with AIGC applications',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/Nevernamed/pypabhiveagent',
    packages=find_packages(exclude=['tests', 'tests.*', 'examples', 'docs']),
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.7',
    install_requires=[
        'pandas>=1.3.0,<3.0.0',
        'requests>=2.26.0,<3.0.0',
        'openpyxl>=3.0.9,<4.0.0',
    ],
    extras_require={
        'hive': [
            'pyspark>=3.0.0,<4.0.0',
            'pyhive>=0.6.0',
        ],
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=3.0.0',
            'requests-mock>=1.9.3',
            'black>=22.0.0',
            'flake8>=4.0.0',
            'mypy>=0.950',
        ],
    },

    keywords='hive aigc data-processing llm',
    project_urls={
        'Bug Reports': 'https://github.com/Nevernamed/pypabhiveagent/issues',
        'Source': 'https://github.com/Nevernamed/pypabhiveagent',
        'Documentation': 'https://github.com/Nevernamed/pypabhiveagent#readme',
        'Changelog': 'https://github.com/Nevernamed/pypabhiveagent/blob/main/CHANGELOG.md',
    },
)
