# 🧠 Trade Manager

A **production-grade Intraday Auto Trading Manager** with full trade persistence, rule-based risk management, and daily performance tracking.

---

## 📘 Overview

`TradeManager.py` is a Python-based **automated trade manager** that combines professional **risk control, performance logging, and capital discipline**.  
Designed for **intraday traders, investors, and quantitative analysts**, it helps manage trades with strict loss/profit limits, ensuring capital protection and consistency.

---

## ⚙️ Core Features

### 💼 Portfolio & Risk Management
- **Capital Tracking**                  – Auto carry-forward of daily closing balance.
- **Position Sizing**                   – Based on risk % of total capital.
- **Max Daily Drawdown / Profit Cap**   – Automatically halts trading when daily limits are reached.
- **Capital Update Menu**               – Modify default capital interactively and persist across sessions.

### 📊 Trade Rules
- Limit simultaneous open trades: `max_open_trades`
- Restrict total daily loss and profit trades:
  - `max_loss_trades`
  - `max_target_trades`
- Auto-block further entries after hitting limits.
- **Hardcoded Startup Trades** – Useful for testing and demo environments.

### 🧾 Database Persistence (SQLite)
All trade and performance data are stored locally in `trade_manager.db`:
- **open_trades**       – Current running trades
- **trade_log**         – Historical closed trade performance
- **daily_stats**       – Day-wise P&L and metrics

### 📈 Reports
Generate and review analytics directly in the terminal:
- **Intraday Stock-wise Report** (Today or custom date)
- **Weekly Summary** (Last 4 weeks)
- **Monthly Performance Summary**

### 🧠 Intelligent Auto-Stop Logic
Automatically pauses the system if:
- Daily drawdown limit exceeded
- Profit target achieved
- Too many loss trades occurred

---

## 🧩 Configuration Parameters

| Parameter | Type | Description | Default |
|------------|------|-------------|----------|
| `db_file` | str | SQLite database filename | `trade_manager.db` |
| `default_capital` | float | Starting capital | `10000.0` |
| `default_risk_pct` | float | Risk % per trade | `1.0` |
| `max_drawdown_pct` | float | Daily drawdown stop | `3.0` |
| `max_profit_pct` | float | Daily profit stop | `5.0` |
| `max_open_trades` | int | Concurrent open positions | `3` |
| `max_loss_trades` | int | Max allowed loss trades per day | `1` |
| `max_target_trades` | int | Max allowed target hits per day | `2` |
| `HARD_CODED_MODE_ON_START` | bool | Enable/disable startup trades | `False` |

---

### Example Workflow
1. Start the manager → initializes database
2. Add new trade with stop loss and target
3. Manager auto-adjusts available capital
4. Logs results upon close
5. Displays P&L and risk compliance report

---

## 📂 Database Schema

### `open_trades`
| Field | Type | Description |
|--------|------|-------------|
| id | INTEGER | Auto ID |
| symbol | TEXT | Stock/Instrument |
| entry_price | REAL | Entry level |
| stop_loss | REAL | SL value |
| target | REAL | Target price |
| qty | INTEGER | Quantity |
| status | TEXT | Active/Closed |

### `trade_log`
| Field | Type | Description |
|--------|------|-------------|
| id | INTEGER | Auto ID |
| symbol | TEXT | Stock |
| pnl | REAL | Profit/Loss |
| exit_reason | TEXT | Target/SL/Manual |
| date | TEXT | Trade date |

### `daily_stats`
| Field | Type | Description |
|--------|------|-------------|
| date | TEXT | Trading date |
| capital | REAL | End-of-day capital |
| daily_gain | REAL | Day P&L |
| drawdown | REAL | Daily drawdown % |

---

## 🧰 Key Modules Used

- **sqlite3**   – Data persistence  
- **pandas**    – Data manipulation and reporting  
- **rich**      – Colored and formatted terminal output  
- **datetime**  – Trade and report timestamps  

---

## 🧑‍💼 Example Output (Terminal View)

```
📋 ORDER REVIEW
────────────────────────────────────
💰 Available Capital: ₹10000.00
💸 Risk per Trade: ₹100.00 (1%)
📈 Symbol: RELIANCE
🎯 Target: ₹2800.00
🛑 Stop Loss: ₹2700.00
✔️ Quantity: 10
────────────────────────────────────
✅ Trade Added Successfully!
```

---

## 🧠 Future Enhancements

- 🔮 ML-based profit probability prediction  
- 📡 Live market data integration  
- 💬 Telegram / Discord alerts  
- 🧾 CSV export of reports  
- 🕹️ GUI dashboard (Tkinter / Streamlit)

---

## ⚠️ Disclaimer

> This tool is built for **educational and analytical use**.  
> It does not execute real trades.  
> Always verify decisions manually before executing orders in live markets.

---