"""Shared tools for agents."""
