"""Tests for hfdol"""
