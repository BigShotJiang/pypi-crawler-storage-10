# MIT License - Copyright (c) 2025 Sermet Pekin

# pytest-cream Package

__version__ = "0.1.6"
