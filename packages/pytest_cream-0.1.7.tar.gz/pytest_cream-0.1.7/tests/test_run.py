import os
import subprocess
from unittest.mock import MagicMock, patch
from pytest_cream.run import run_tests


def test_run_tests(tmp_path):
    output_file = tmp_path / "test_durations.log"

    with patch('subprocess.run') as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        run_tests(output_file=str(output_file), use_uv=False)

    assert output_file.exists()
