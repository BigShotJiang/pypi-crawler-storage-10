from setuptools import setup, find_packages

setup(
    name="myownmoduleshow",
    version="0.1.0",
    author="sathish",
    author_email="sathishdhuda25@gmail.com",
    description="jefrehw4bgt3",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
