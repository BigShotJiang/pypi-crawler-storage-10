# myownmoduleshow

jefrehw4bgt3

## Installation

```
pip install myownmoduleshow
```

## Usage

```python
import myownmoduleshow

# Your code here
```
