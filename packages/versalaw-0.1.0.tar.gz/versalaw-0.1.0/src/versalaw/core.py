"""
Core functionality for VersaLaw legal document processing
"""

class LegalDocument:
    """Represents a legal document with analysis capabilities"""
    
    def __init__(self, text: str, doc_type: str = "contract"):
        self.text = text
        self.doc_type = doc_type
        self.clauses = []
        self.metadata = {}
    
    def analyze(self) -> dict:
        """Analyze the legal document and return insights"""
        return {
            "word_count": len(self.text.split()),
            "clause_count": self._extract_clause_count(),
            "complexity_score": self._calculate_complexity(),
            "risk_factors": self._identify_risk_factors()
        }
    
    def _extract_clause_count(self) -> int:
        """Extract approximate clause count"""
        clause_indicators = ['shall', 'must', 'will', 'agree', 'warrant', 'indemnify']
        return sum(1 for indicator in clause_indicators if indicator in self.text.lower())
    
    def _calculate_complexity(self) -> float:
        """Calculate document complexity score"""
        words = self.text.split()
        if not words:
            return 0.0
        
        long_words = sum(1 for word in words if len(word) > 6)
        return min(10.0, (long_words / len(words)) * 20)
    
    def _identify_risk_factors(self) -> list:
        """Identify potential risk factors in document"""
        risk_keywords = ['liable', 'damages', 'terminate', 'breach', 'penalty']
        return [keyword for keyword in risk_keywords if keyword in self.text.lower()]


def analyze_contract(contract_text: str) -> dict:
    """Quick analysis of contract text"""
    doc = LegalDocument(contract_text, "contract")
    return doc.analyze()


def extract_clauses(document_text: str, clause_types: list = None) -> list:
    """Extract specific clause types from document"""
    if clause_types is None:
        clause_types = ['confidentiality', 'termination', 'payment']
    
    clauses = []
    for clause_type in clause_types:
        if clause_type in document_text.lower():
            clauses.append({
                'type': clause_type,
                'present': True,
                'context': f"Contains {clause_type} clause"
            })
    
    return clauses
