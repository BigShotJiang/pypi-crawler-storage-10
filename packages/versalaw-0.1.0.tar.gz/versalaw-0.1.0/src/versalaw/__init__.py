"""
VersaLaw - Comprehensive Legal Document Processing Library
"""

__version__ = "0.1.0"
__author__ = "Creator Source"

from .core import LegalDocument, analyze_contract, extract_clauses
from .utils import normalize_text, validate_legal_format

__all__ = [
    "LegalDocument",
    "analyze_contract", 
    "extract_clauses",
    "normalize_text",
    "validate_legal_format",
]
