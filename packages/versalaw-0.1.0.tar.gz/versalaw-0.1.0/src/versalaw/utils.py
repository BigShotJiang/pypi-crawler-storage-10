"""
Utility functions for VersaLaw
"""

import re
from typing import Dict, Any


def normalize_text(text: str) -> str:
    """Normalize legal text for processing"""
    if not text:
        return ""
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Basic normalization
    text = text.strip()
    
    return text


def validate_legal_format(text: str) -> Dict[str, Any]:
    """Validate if text appears to be legal document"""
    validation = {
        "is_legal_like": False,
        "confidence": 0.0,
        "issues": []
    }
    
    if not text:
        validation["issues"].append("Empty text")
        return validation
    
    legal_indicators = [
        'agreement', 'contract', 'shall', 'party', 'hereinafter',
        'whereas', 'therefore', 'witnesseth'
    ]
    
    text_lower = text.lower()
    indicator_count = sum(1 for indicator in legal_indicators if indicator in text_lower)
    
    # Calculate confidence score
    word_count = len(text.split())
    if word_count > 0:
        confidence = min(1.0, indicator_count / (word_count / 100))
        validation["confidence"] = round(confidence, 2)
        validation["is_legal_like"] = confidence > 0.1
    
    if word_count < 50:
        validation["issues"].append("Document too short for proper legal analysis")
    
    return validation


def safe_analyze(document_text: str) -> Dict[str, Any]:
    """Safely analyze document with error handling"""
    try:
        from .core import analyze_contract
        return analyze_contract(document_text)
    except Exception as e:
        return {
            "error": str(e),
            "word_count": 0,
            "clause_count": 0,
            "complexity_score": 0.0,
            "risk_factors": []
        }
