#!/usr/bin/env python3
"""
Basic test script for VersaLaw
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from versalaw import UniversalAnalyzer
from versalaw.jurisdictions.indonesia import IndonesiaAnalyzer

def test_indonesia_analyzer():
    """Test Indonesia-specific analyzer"""
    print("🧪 Testing IndonesiaAnalyzer...")
    
    analyzer = IndonesiaAnalyzer()
    
    # Test contract dengan masalah
    test_contract = """
    Perjanjian antara PT ABC dan PT XYZ.
    Masa berlaku perjanjian adalah 10 tahun dengan perpanjangan otomatis.
    Keterlambatan pembayaran dikenakan sanksi 100% dari nilai kontrak.
    """
    
    result = analyzer.analyze(test_contract)
    
    print(f"✅ Jurisdiction: {result['jurisdiction']}")
    print(f"✅ Risk Level: {result['risk_level']}")
    print(f"✅ Issues Found: {len(result['issues'])}")
    
    for issue in result['issues']:
        print(f"   - {issue}")
    
    print(f"✅ Confidence: {result['confidence']}")
    print("🎯 Indonesia Analyzer TEST PASSED!\n")

def test_universal_analyzer():
    """Test universal analyzer with auto-detection"""
    print("🌍 Testing UniversalAnalyzer...")
    
    analyzer = UniversalAnalyzer()
    
    # Test Indonesian contract
    id_contract = """
    Para pihak setuju bahwa perjanjian ini dibuat menurut hukum Indonesia.
    Masa berlaku 5 tahun dengan perpanjangan otomatis.
    """
    
    result = analyzer.analyze(id_contract)
    
    print(f"✅ Auto-detected Jurisdiction: {result['jurisdiction']}")
    print(f"✅ Risk Level: {result['risk_level']}")
    print(f"✅ Recommendations: {len(result['recommendations'])}")
    print("🎯 Universal Analyzer TEST PASSED!\n")

def test_jurisdiction_comparison():
    """Test jurisdiction comparison"""
    print("🔄 Testing Jurisdiction Comparison...")
    
    analyzer = UniversalAnalyzer()
    
    contract = """
    This agreement shall be governed by Indonesian law.
    Term is 3 years with automatic renewal.
    """
    
    results = analyzer.compare_jurisdictions(contract, ['indonesia'])
    
    for jurisdiction, result in results.items():
        print(f"✅ {jurisdiction}: {result['risk_level']} risk")
    
    print("🎯 Jurisdiction Comparison TEST PASSED!\n")

if __name__ == "__main__":
    print("🚀 STARTING VERSALAW TESTS...\n")
    
    try:
        test_indonesia_analyzer()
        test_universal_analyzer() 
        test_jurisdiction_comparison()
        
        print("🎉 ALL TESTS PASSED! VersaLaw is working correctly!")
        print("\n📦 Ready for PyPI deployment and GitHub repository!")
        
    except Exception as e:
        print(f"❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
