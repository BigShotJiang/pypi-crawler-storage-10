from setuptools import setup, find_packages

setup(
    name="versalaw",
    version="0.1.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    py_modules=["versalaw"],  # Tambah ini
    include_package_data=True,
    python_requires=">=3.8",
    license="AGPL-3.0-or-later",
    description="A comprehensive legal document processing and analysis library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Creator Source",
    author_email="creator@source.com",
    url="https://github.com/CreatorOss/versalaw",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Legal Industry",
        "License :: OSI Approved :: GNU Affero General Public License v3 or later (AGPLv3+)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
