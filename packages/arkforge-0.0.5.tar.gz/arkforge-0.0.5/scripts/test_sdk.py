#!/usr/bin/env python3
"""Interactive SDK test script for ArkForge API.

This script provides comprehensive testing of the ArkForge SDK functionality
against a local or remote API instance. It includes tests for:
- Basic portfolio optimization
- Advanced optimization parameters
- Backtesting with historical data
- API key management
- Error handling

Usage:
    python scripts/test_sdk.py                    # Interactive mode
    python scripts/test_sdk.py --run-all         # Run all tests
    python scripts/test_sdk.py --optimization    # Test optimization params only
"""

import argparse
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

# Add parent directory to path for local imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from arkforge import ArkForgeClient, KeyManagementClient
from arkforge.config import ArkForgeConfig
from arkforge.errors import ArkForgeError, ValidationError
from arkforge.models import (
    Constraints,
    OptimizationConfig,
    OptimizePortfolioRequest,
    Options,
)


class Colors:
    """ANSI color codes for terminal output."""

    HEADER = "\033[95m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"


def print_header(text: str) -> None:
    """Print colored header."""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'=' * 60}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{text}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{'=' * 60}{Colors.ENDC}\n")


def print_success(text: str) -> None:
    """Print success message."""
    print(f"{Colors.GREEN}✓ {text}{Colors.ENDC}")


def print_error(text: str) -> None:
    """Print error message."""
    print(f"{Colors.RED}✗ {text}{Colors.ENDC}")


def print_info(text: str) -> None:
    """Print info message."""
    print(f"{Colors.CYAN}ℹ {text}{Colors.ENDC}")


def print_warning(text: str) -> None:
    """Print warning message."""
    print(f"{Colors.YELLOW}⚠ {text}{Colors.ENDC}")


def load_config() -> Dict[str, str]:
    """Load configuration from environment or .env file.

    Returns:
        Dict with api_key and base_url
    """
    config = {}

    # Try to load from .env file
    env_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
    if os.path.exists(env_file):
        print_info(f"Loading configuration from {env_file}")
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    if "=" in line:
                        key, value = line.split("=", 1)
                        config[key.strip()] = value.strip().strip('"').strip("'")

    # Override with environment variables
    if os.getenv("ARKFORGE_API_KEY"):
        config["ARKFORGE_API_KEY"] = os.getenv("ARKFORGE_API_KEY")
    if os.getenv("ARKFORGE_BASE_URL"):
        config["ARKFORGE_BASE_URL"] = os.getenv("ARKFORGE_BASE_URL")

    # Get from user if not found
    if "ARKFORGE_API_KEY" not in config:
        api_key = input("Enter your ArkForge API key: ").strip()
        config["ARKFORGE_API_KEY"] = api_key

    if "ARKFORGE_BASE_URL" not in config:
        default_url = "http://localhost:3000"
        base_url = input(f"Enter API base URL [{default_url}]: ").strip()
        config["ARKFORGE_BASE_URL"] = base_url or default_url

    return config


def test_basic_optimization(client: ArkForgeClient) -> bool:
    """Test basic portfolio optimization.

    Args:
        client: ArkForge client instance

    Returns:
        True if test passed, False otherwise
    """
    print_header("Test 1: Basic Portfolio Optimization")

    try:
        request = OptimizePortfolioRequest(
            assets=["BTC", "ETH", "SOL"], risk_profile="moderate", horizon_days=7
        )

        print_info("Request:")
        print(json.dumps(request.model_dump(by_alias=True, exclude_none=True), indent=2))

        print_info("Sending request to API...")
        result = client.optimize_portfolio(request)

        print_success("Request successful!")
        print(f"\n{Colors.BOLD}Portfolio Recommendation:{Colors.ENDC}")
        print(f"  Allocation: {dict(result.allocation)}")
        print(f"  Expected Return: {result.expected_return * 100:.2f}%")
        print(f"  Expected Volatility: {result.expected_volatility * 100:.2f}%")
        print(f"  Sharpe Ratio: {result.sharpe_ratio:.2f}")
        print(f"  Confidence: {result.confidence * 100:.0f}%")

        if result.actions:
            print(f"\n{Colors.BOLD}Recommended Actions:{Colors.ENDC}")
            for action in result.actions:
                print(f"  {action.action.upper()} {action.symbol}: {action.change:+.1f}%")

        return True

    except ArkForgeError as e:
        print_error(f"API Error: {e}")
        if hasattr(e, "details") and e.details:
            print(f"  Details: {e.details}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        import traceback

        traceback.print_exc()
        return False


def test_advanced_optimization(client: ArkForgeClient) -> bool:
    """Test advanced optimization with all parameters.

    Args:
        client: ArkForge client instance

    Returns:
        True if test passed, False otherwise
    """
    print_header("Test 2: Advanced Optimization Parameters")

    try:
        # Create request with ALL optimization parameters
        request = OptimizePortfolioRequest(
            assets=["BTC", "ETH", "SOL"],
            risk_profile="moderate",
            horizon_days=30,
            optimization=OptimizationConfig(
                target_sharpe_ratio=1.5,
                max_volatility=0.30,
                min_expected_return=0.15,
                goal="sharpe",
                sentiment_weight=0.7,
                ignore_sentiment=False,
                optimistic_bias=False,
            ),
            constraints=Constraints(max_position_size=40.0, min_diversification=3),
        )

        print_info("Request with optimization parameters:")
        serialized = request.model_dump(by_alias=True, exclude_none=True)
        print(json.dumps(serialized, indent=2))

        print_info("\nVerifying serialization...")
        assert "optimization" in serialized, "Missing optimization object"
        opt = serialized["optimization"]
        assert opt["targetSharpeRatio"] == 1.5, "targetSharpeRatio mismatch"
        assert opt["maxVolatility"] == 0.30, "maxVolatility mismatch"
        assert opt["minExpectedReturn"] == 0.15, "minExpectedReturn mismatch"
        assert opt["goal"] == "sharpe", "goal mismatch"
        assert opt["sentimentWeight"] == 0.7, "sentimentWeight mismatch"
        assert opt["ignoreSentiment"] is False, "ignoreSentiment mismatch"
        assert opt["optimisticBias"] is False, "optimisticBias mismatch"
        print_success("Serialization validation passed!")

        print_info("\nSending request to API...")
        result = client.optimize_portfolio(request)

        print_success("Request successful!")
        print(f"\n{Colors.BOLD}Portfolio Recommendation:{Colors.ENDC}")
        print(f"  Allocation: {dict(result.allocation)}")
        print(f"  Expected Return: {result.expected_return * 100:.2f}%")
        print(f"  Expected Volatility: {result.expected_volatility * 100:.2f}%")
        print(f"  Sharpe Ratio: {result.sharpe_ratio:.2f}")
        print(f"  Confidence: {result.confidence * 100:.0f}%")

        # Verify optimization goals were applied
        print_info("\nValidating optimization constraints...")
        if result.sharpe_ratio >= 1.5:
            print_success(f"Sharpe ratio {result.sharpe_ratio:.2f} meets target >= 1.5")
        else:
            print_warning(f"Sharpe ratio {result.sharpe_ratio:.2f} below target 1.5")

        if result.expected_volatility <= 0.30:
            print_success(f"Volatility {result.expected_volatility:.2%} within max 30%")
        else:
            print_warning(f"Volatility {result.expected_volatility:.2%} exceeds max 30%")

        if result.expected_return >= 0.15:
            print_success(f"Return {result.expected_return:.2%} meets min 15%")
        else:
            print_warning(f"Return {result.expected_return:.2%} below min 15%")

        return True

    except ArkForgeError as e:
        print_error(f"API Error: {e}")
        if hasattr(e, "details") and e.details:
            print(f"  Details: {e.details}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        import traceback

        traceback.print_exc()
        return False


def test_with_options(client: ArkForgeClient) -> bool:
    """Test optimization with LLM provider options.

    Args:
        client: ArkForge client instance

    Returns:
        True if test passed, False otherwise
    """
    print_header("Test 3: Optimization with LLM Options")

    try:
        request = OptimizePortfolioRequest(
            assets=["BTC", "ETH"],
            risk_profile="aggressive",
            horizon_days=7,
            options=Options(llm_provider="claude"),
        )

        print_info("Request with LLM options:")
        print(json.dumps(request.model_dump(by_alias=True, exclude_none=True), indent=2))

        print_info("Sending request to API...")
        result = client.optimize_portfolio(request)

        print_success("Request successful!")
        print(f"  Expected Return: {result.expected_return * 100:.2f}%")
        print(f"  Sharpe Ratio: {result.sharpe_ratio:.2f}")

        return True

    except ArkForgeError as e:
        print_error(f"API Error: {e}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        return False


def test_error_handling(client: ArkForgeClient) -> bool:
    """Test error handling with invalid requests.

    Args:
        client: ArkForge client instance

    Returns:
        True if test passed, False otherwise
    """
    print_header("Test 4: Error Handling")

    try:
        # Test 1: Invalid risk profile
        print_info("Testing invalid risk profile...")
        try:
            request = OptimizePortfolioRequest(
                assets=["BTC"], risk_profile="invalid_profile"  # type: ignore
            )
            print_error("Should have raised ValidationError for invalid risk profile")
            return False
        except Exception:
            print_success("Correctly rejected invalid risk profile")

        # Test 2: Empty assets
        print_info("Testing empty assets list...")
        try:
            request = OptimizePortfolioRequest(assets=[], risk_profile="moderate")
            print_error("Should have raised ValidationError for empty assets")
            return False
        except Exception:
            print_success("Correctly rejected empty assets")

        # Test 3: Invalid volatility range
        print_info("Testing invalid volatility range...")
        try:
            config = OptimizationConfig(max_volatility=1.5)  # > 1.0
            print_error("Should have raised ValidationError for volatility > 1.0")
            return False
        except Exception:
            print_success("Correctly rejected volatility > 1.0")

        print_success("\nAll error handling tests passed!")
        return True

    except Exception as e:
        print_error(f"Unexpected error in error handling test: {e}")
        return False


def test_health_check(client: ArkForgeClient) -> bool:
    """Test API health check endpoint.

    Args:
        client: ArkForge client instance

    Returns:
        True if test passed, False otherwise
    """
    print_header("Test 5: API Health Check")

    try:
        print_info("Checking API health...")
        health = client.health()

        print_success("Health check successful!")
        print(f"  Status: {health.status}")
        print(f"  Version: {health.version}")
        print(f"  Timestamp: {health.timestamp}")

        if health.services:
            print(f"\n{Colors.BOLD}Services:{Colors.ENDC}")
            for service, status in health.services.items():
                color = Colors.GREEN if status == "ok" else Colors.RED
                print(f"  {service}: {color}{status}{Colors.ENDC}")

        return True

    except ArkForgeError as e:
        print_error(f"Health check failed: {e}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        return False


def interactive_menu(client: ArkForgeClient) -> None:
    """Display interactive test menu.

    Args:
        client: ArkForge client instance
    """
    while True:
        print_header("ArkForge SDK Test Suite")
        print("1. Basic Portfolio Optimization")
        print("2. Advanced Optimization Parameters")
        print("3. Optimization with LLM Options")
        print("4. Error Handling Tests")
        print("5. API Health Check")
        print("6. Run All Tests")
        print("0. Exit")
        print()

        choice = input("Select test to run (0-6): ").strip()

        if choice == "0":
            print_info("Exiting...")
            break
        elif choice == "1":
            test_basic_optimization(client)
        elif choice == "2":
            test_advanced_optimization(client)
        elif choice == "3":
            test_with_options(client)
        elif choice == "4":
            test_error_handling(client)
        elif choice == "5":
            test_health_check(client)
        elif choice == "6":
            run_all_tests(client)
        else:
            print_error("Invalid choice. Please select 0-6.")

        input("\nPress Enter to continue...")


def run_all_tests(client: ArkForgeClient) -> None:
    """Run all test cases.

    Args:
        client: ArkForge client instance
    """
    print_header("Running All Tests")

    results = []
    tests = [
        ("Basic Optimization", test_basic_optimization),
        ("Advanced Optimization", test_advanced_optimization),
        ("LLM Options", test_with_options),
        ("Error Handling", test_error_handling),
        ("Health Check", test_health_check),
    ]

    for name, test_func in tests:
        try:
            passed = test_func(client)
            results.append((name, passed))
        except Exception as e:
            print_error(f"Test '{name}' crashed: {e}")
            results.append((name, False))

    # Print summary
    print_header("Test Summary")
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)

    for name, passed in results:
        if passed:
            print_success(f"{name}: PASSED")
        else:
            print_error(f"{name}: FAILED")

    print()
    if passed_count == total_count:
        print_success(f"All {total_count} tests PASSED! 🎉")
    else:
        print_warning(f"{passed_count}/{total_count} tests passed")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="ArkForge SDK Test Suite")
    parser.add_argument("--run-all", action="store_true", help="Run all tests")
    parser.add_argument(
        "--optimization", action="store_true", help="Run optimization parameter tests only"
    )
    parser.add_argument("--api-key", help="API key (overrides .env)")
    parser.add_argument("--base-url", help="Base URL (overrides .env)")
    args = parser.parse_args()

    print_header("ArkForge SDK Test Suite")

    # Load configuration
    config = load_config()

    # Override with command line args
    if args.api_key:
        config["ARKFORGE_API_KEY"] = args.api_key
    if args.base_url:
        config["ARKFORGE_BASE_URL"] = args.base_url

    # Display configuration
    print_info(f"API Key: {config['ARKFORGE_API_KEY'][:20]}...")
    print_info(f"Base URL: {config['ARKFORGE_BASE_URL']}")
    print()

    # Initialize client
    try:
        client = ArkForgeClient(
            api_key=config["ARKFORGE_API_KEY"], base_url=config["ARKFORGE_BASE_URL"]
        )
        print_success("Client initialized successfully")
    except Exception as e:
        print_error(f"Failed to initialize client: {e}")
        return 1

    try:
        # Run tests based on arguments
        if args.run_all:
            run_all_tests(client)
        elif args.optimization:
            test_advanced_optimization(client)
        else:
            interactive_menu(client)

        return 0

    finally:
        client.close()
        print_info("\nClient closed")


if __name__ == "__main__":
    sys.exit(main())
