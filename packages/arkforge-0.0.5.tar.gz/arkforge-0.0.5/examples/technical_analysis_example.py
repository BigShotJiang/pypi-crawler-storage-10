"""Example: Portfolio optimization with Technical Analysis.

This example demonstrates how to use the ArkForge SDK with Technical Analysis
integration for enhanced portfolio optimization.
"""

import os

from arkforge import ArkForgeClient
from arkforge.models import (
    OptimizePortfolioRequest,
    TechnicalAnalysisConfig,
    TechnicalAnalysisIndicatorConfig,
)


def basic_ta_example() -> None:
    """Basic Technical Analysis enablement with default settings."""
    print("\n" + "=" * 80)
    print("EXAMPLE 1: Basic TA Enablement")
    print("=" * 80)

    api_key = os.getenv("ARKFORGE_API_KEY")
    if not api_key:
        raise ValueError("ARKFORGE_API_KEY not set")

    client = ArkForgeClient(api_key=api_key)

    # Enable TA with default settings
    request = OptimizePortfolioRequest(
        assets=["BTC", "ETH", "SOL", "LINK"],
        risk_profile="moderate",  # type: ignore[call-arg]
        current_balances={"USDC": 10000},  # type: ignore[call-arg]
        current_drawdown=0,  # type: ignore[call-arg]
        projected_vol=0.20,  # type: ignore[call-arg]
        budget=10000,  # type: ignore[call-arg]
        technical_analysis=TechnicalAnalysisConfig(  # type: ignore[call-arg]
            enabled=True,
            weight=0.3,  # 30% TA influence
        ),
    )

    result = client.optimize_portfolio(request)

    print("\n📊 Portfolio Allocation:")
    for asset, percentage in result.allocation.items():
        print(f"  {asset}: {percentage:.1f}%")

    # Access TA-specific insights
    if result.rationale and result.rationale.ta_insights:
        print("\n🔍 TA Insights:")
        print(f"  {result.rationale.ta_insights}")

    # Check TA metadata
    if result.metadata and result.metadata.ta_enabled:
        print(f"\n⏱️  TA Processing Time: {result.metadata.ta_processing_time}ms")

    # Review actions with stop-loss and take-profit
    print("\n💼 Recommended Actions:")
    for action in result.actions:
        print(f"  {action.action.upper()} {action.symbol}: {action.change:+.1f}%")
        if action.reason:
            print(f"    Reason: {action.reason}")
        if action.sl:
            print(f"    Stop-loss: {action.sl * 100:.1f}%")
        if action.tp:
            print(f"    Take-profit: {action.tp}")


def custom_ta_configuration() -> None:
    """Custom TA indicator configuration."""
    print("\n" + "=" * 80)
    print("EXAMPLE 2: Custom TA Configuration")
    print("=" * 80)

    api_key = os.getenv("ARKFORGE_API_KEY")
    if not api_key:
        raise ValueError("ARKFORGE_API_KEY not set")

    client = ArkForgeClient(api_key=api_key)

    # Configure custom TA indicators
    request = OptimizePortfolioRequest(
        assets=["BTC", "ETH", "SOL"],
        risk_profile="aggressive",  # type: ignore[call-arg]
        current_balances={"USDC": 25000},  # type: ignore[call-arg]
        current_drawdown=0,  # type: ignore[call-arg]
        projected_vol=0.30,  # type: ignore[call-arg]
        budget=25000,  # type: ignore[call-arg]
        technical_analysis=TechnicalAnalysisConfig(  # type: ignore[call-arg]
            enabled=True,
            weight=0.35,  # 35% TA influence
            config=TechnicalAnalysisIndicatorConfig(  # type: ignore[call-arg]
                rsi_period=21,  # type: ignore[call-arg]  # Longer RSI period
                macd_fast=8,  # type: ignore[call-arg]  # Faster MACD
                macd_slow=21,  # type: ignore[call-arg]
                macd_signal=5,  # type: ignore[call-arg]
                sma_periods=[10, 30, 100],  # type: ignore[call-arg]  # Custom SMA periods
                bb_period=30,  # type: ignore[call-arg]  # Wider Bollinger Bands
                bb_std_dev=2.5,  # type: ignore[call-arg]
            ),
        ),
    )

    result = client.optimize_portfolio(request)

    print("\n📊 Portfolio Allocation:")
    for asset, percentage in result.allocation.items():
        print(f"  {asset}: {percentage:.1f}%")

    print("\n📈 Performance Metrics:")
    print(f"  Expected Return: {result.expected_return * 100:.2f}%")
    print(f"  Expected Volatility: {result.expected_volatility * 100:.2f}%")
    print(f"  Sharpe Ratio: {result.sharpe_ratio:.2f}")


def ta_with_risk_controls() -> None:
    """Technical Analysis with Risk Control parameters."""
    print("\n" + "=" * 80)
    print("EXAMPLE 3: TA + Risk Controls")
    print("=" * 80)

    api_key = os.getenv("ARKFORGE_API_KEY")
    if not api_key:
        raise ValueError("ARKFORGE_API_KEY not set")

    client = ArkForgeClient(api_key=api_key)

    request = OptimizePortfolioRequest(
        assets=["BTC", "ETH", "SOL", "LINK", "AVAX"],
        risk_profile="moderate",  # type: ignore[call-arg]
        current_balances={  # type: ignore[call-arg]
            "BTC": 0.3,
            "ETH": 2.5,
            "SOL": 50.0,
            "USDC": 20000,
        },
        # Risk control parameters
        current_drawdown=-0.12,  # type: ignore[call-arg]  # -12% drawdown
        projected_vol=0.22,  # type: ignore[call-arg]  # 22% projected volatility
        budget=50000,  # type: ignore[call-arg]
        # Technical Analysis
        technical_analysis=TechnicalAnalysisConfig(  # type: ignore[call-arg]
            enabled=True,
            weight=0.3,
        ),
    )

    result = client.optimize_portfolio(request)

    print("\n📊 Portfolio Allocation:")
    for asset, percentage in result.allocation.items():
        print(f"  {asset}: {percentage:.1f}%")

    # Check risk control enforcement
    if result.rationale and result.rationale.enforce_summary:
        print("\n⚠️  Risk Controls Applied:")
        print(f"  {result.rationale.enforce_summary}")

    # TA insights
    if result.rationale and result.rationale.ta_insights:
        print("\n🔍 TA Insights:")
        print(f"  {result.rationale.ta_insights}")


def backtesting_with_ta() -> None:
    """Backtesting with Technical Analysis (example structure)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 4: Backtesting with TA")
    print("=" * 80)

    api_key = os.getenv("ARKFORGE_API_KEY")
    if not api_key:
        raise ValueError("ARKFORGE_API_KEY not set")

    # client = ArkForgeClient(api_key=api_key)  # noqa: ERA001

    # Historical OHLCV data (minimum 90 days per asset)
    # In practice, you'd load this from a file or API
    historical_data = [
        {
            "asset": "BTC",
            "timestamp": "2024-01-01T00:00:00Z",
            "price": 42000,
            "high": 42500,
            "low": 41500,
            "volume": 1000000,
        },
        {
            "asset": "BTC",
            "timestamp": "2024-01-02T00:00:00Z",
            "price": 43000,
            "high": 43200,
            "low": 42800,
            "volume": 1100000,
        },
        # ... 90+ days of data per asset
    ]

    # Example request structure (uncomment to use)
    _ = historical_data  # Keep reference for documentation
    # request = OptimizePortfolioRequest(  # noqa: ERA001
    #     assets=["BTC", "ETH"],  # noqa: ERA001
    #     risk_profile="moderate",  # type: ignore[call-arg]  # noqa: ERA001
    #     budget=10000,  # noqa: ERA001
    #     historical_data=historical_data,  # type: ignore[call-arg]  # noqa: ERA001
    #     technical_analysis=TechnicalAnalysisConfig(  # type: ignore[call-arg]  # noqa: ERA001
    #         enabled=True,  # noqa: ERA001
    #         weight=0.3,  # noqa: ERA001
    #         disable_cache=True,  # type: ignore[call-arg]  # Important!  # noqa: ERA001
    #     ),  # noqa: ERA001
    # )  # noqa: ERA001

    print("⚠️  Note: This example requires 90+ days of historical data.")
    print("    Run backtesting_example.py for a complete backtesting demonstration.")

    # Uncomment to execute:
    # result = client.optimize_portfolio(request)
    # print(f"\n📊 Backtest Results:")
    # for asset, percentage in result.allocation.items():
    #     print(f"  {asset}: {percentage:.1f}%")


def main() -> None:
    """Run all Technical Analysis examples."""
    print("\n" + "=" * 80)
    print("ArkForge SDK - Technical Analysis Examples")
    print("=" * 80)

    api_key = os.getenv("ARKFORGE_API_KEY")
    if not api_key:
        print("\n❌ Error: ARKFORGE_API_KEY environment variable not set")
        print("   Set it with: export ARKFORGE_API_KEY=sk-arkforge-...")
        return

    try:
        # Run examples
        basic_ta_example()
        custom_ta_configuration()
        ta_with_risk_controls()
        backtesting_with_ta()

        print("\n" + "=" * 80)
        print("✅ All examples completed successfully!")
        print("=" * 80)

    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        raise


if __name__ == "__main__":
    main()
