"""Basic usage example for ArkForge SDK."""

from arkforge import ArkForgeClient
from arkforge.models import OptimizePortfolioRequest


def main():
    """Basic portfolio optimization example."""
    # Initialize client with API key
    client = ArkForgeClient(api_key="sk-arkforge-your-key-here")

    # Create optimization request
    request = OptimizePortfolioRequest(
        assets=["BTC", "ETH", "SOL"],
        risk_profile="moderate",  # type: ignore[call-arg]
        current_balances={"USDC": 10000},  # type: ignore[call-arg]  # Starting with $10k USDC
        current_drawdown=0,  # type: ignore[call-arg]  # New portfolio, no drawdown
        projected_vol=0.20,  # type: ignore[call-arg]  # Expecting 20% volatility
        horizon_days=7,  # type: ignore[call-arg]
    )

    # Optimize portfolio
    print("Optimizing portfolio...")
    result = client.optimize_portfolio(request)

    # Print results
    print("\n=== Portfolio Recommendation ===")
    print("\nAllocation:")
    for symbol, percentage in result.allocation.items():
        print(f"  {symbol}: {percentage:.1f}%")

    print("\nMetrics:")
    print(f"  Expected Return: {result.expected_return * 100:.2f}%")
    print(f"  Expected Volatility: {result.expected_volatility * 100:.2f}%")
    print(f"  Sharpe Ratio: {result.sharpe_ratio:.2f}")
    print(f"  Confidence: {result.confidence * 100:.0f}%")

    # Print actions
    if result.actions:
        print("\nRecommended Actions:")
        for action in result.actions:
            print(f"  {action.action.upper()} {action.symbol}: {action.change:+.1f}%")

    # Clean up
    client.close()


if __name__ == "__main__":
    main()
