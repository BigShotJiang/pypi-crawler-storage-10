"""Request models for ArkForge API."""

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, ValidationInfo, field_validator

from .common import OptimizationGoal, RiskProfileType


class OptimizationConfig(BaseModel):
    """Portfolio optimization configuration.

    Attributes:
        target_sharpe_ratio: Target Sharpe ratio to achieve
        max_volatility: Maximum acceptable volatility (0-1)
        min_expected_return: Minimum expected return (0-1)
        goal: Primary optimization goal
        sentiment_weight: Weight for sentiment analysis (0-1)
        ignore_sentiment: Whether to ignore sentiment completely
        optimistic_bias: Apply optimistic bias to forecasts
        llm_provider: LLM provider to use (openai, anthropic, xai, mistral)
        llm_model: Specific LLM model to use
    """

    target_sharpe_ratio: Optional[float] = Field(
        None, alias="targetSharpeRatio", ge=0, description="Target Sharpe ratio"
    )
    max_volatility: Optional[float] = Field(
        None, alias="maxVolatility", ge=0, le=1, description="Max volatility (0-1)"
    )
    min_expected_return: Optional[float] = Field(
        None, alias="minExpectedReturn", ge=0, le=1, description="Min expected return (0-1)"
    )
    goal: Optional[OptimizationGoal] = Field(None, description="Optimization goal")
    sentiment_weight: Optional[float] = Field(
        1.0, alias="sentimentWeight", ge=0, le=1, description="Sentiment weight (0-1)"
    )
    ignore_sentiment: Optional[bool] = Field(
        False, alias="ignoreSentiment", description="Ignore sentiment analysis"
    )
    optimistic_bias: Optional[bool] = Field(
        False, alias="optimisticBias", description="Apply optimistic bias"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class Options(BaseModel):
    """Request options.

    Attributes:
        llm_provider: LLM provider to use - just "claude" or "grok"
    """

    llm_provider: Optional[str] = Field(
        None, alias="llmProvider", description="LLM provider (claude or grok)"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class Constraints(BaseModel):
    """Portfolio constraints.

    Attributes:
        max_position_size: Maximum percentage per asset (0-100)
        min_diversification: Minimum number of different assets
        excluded_assets: Asset symbols to exclude from portfolio
    """

    max_position_size: Optional[float] = Field(
        None, alias="maxPositionSize", ge=0, le=100, description="Max % per asset"
    )
    min_diversification: Optional[int] = Field(
        None, alias="minDiversification", ge=1, description="Min number of assets"
    )
    excluded_assets: Optional[List[str]] = Field(
        None, alias="excludedAssets", description="Assets to exclude"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class HistoricalPriceData(BaseModel):
    """Historical price data point for backtesting with OHLCV support.

    Extended to support Technical Analysis calculations which require
    high, low, and volume data in addition to close price.

    Attributes:
        symbol: Asset symbol (e.g., BTC, ETH)
        timestamp: ISO 8601 timestamp
        price: Close price in USD (required)
        high: High price in USD (optional, for TA)
        low: Low price in USD (optional, for TA)
        volume: Trading volume (optional, for volume indicators)
    """

    symbol: str = Field(..., description="Asset symbol (e.g., BTC, ETH)")
    timestamp: str = Field(..., description="ISO 8601 timestamp")
    price: float = Field(..., gt=0, description="Close price in USD")
    high: Optional[float] = Field(None, gt=0, description="High price")
    low: Optional[float] = Field(None, gt=0, description="Low price")
    volume: Optional[float] = Field(None, ge=0, description="Trading volume")

    model_config = {"frozen": True}


class HistoricalSentimentData(BaseModel):
    """Historical sentiment data point for backtesting.

    Attributes:
        asset: Asset symbol
        timestamp: ISO 8601 timestamp
        score: Sentiment score (-1 to +1)
        category: Sentiment category
        confidence: Confidence level (0-1)
        galaxy_score: LunarCrush Galaxy Score (0-100, optional)
        alt_rank: LunarCrush AltRank (1-4000, optional)
        social: Social metrics (optional)
    """

    asset: str = Field(..., description="Asset symbol")
    timestamp: str = Field(..., description="ISO 8601 timestamp")
    score: float = Field(..., ge=-1, le=1, description="Sentiment score (-1 to +1)")
    category: Literal["very_bearish", "bearish", "neutral", "bullish", "very_bullish"] = Field(
        ..., description="Sentiment category"
    )
    confidence: float = Field(..., ge=0, le=1, description="Confidence (0-1)")
    galaxy_score: Optional[float] = Field(
        None, alias="galaxyScore", ge=0, le=100, description="LunarCrush Galaxy Score"
    )
    alt_rank: Optional[int] = Field(
        None, alias="altRank", ge=1, le=4000, description="LunarCrush AltRank"
    )
    social: Optional[Dict[str, Any]] = Field(None, description="Social metrics")

    model_config = {"frozen": True, "populate_by_name": True}


class PositionTrackingData(BaseModel):
    """Position tracking data for a single asset.

    Provided by execution service's OrderManager to enable
    trailing stop calculations and position-aware optimization.

    Attributes:
        entry_price: Original entry price when position was opened
        peak_price: Highest price seen since entry (for trailing stops)
        current_price: Current market price
        days_held: Number of days position has been held
        profit_pct: Current P&L as percentage from entry
        drawdown_from_peak: Drawdown from peak as percentage
        previous_sl: Previous trailing stop value (optional)

    Example:
        >>> position = PositionTrackingData(
        ...     entry_price=100000,
        ...     peak_price=125000,
        ...     current_price=118000,
        ...     days_held=14,
        ...     profit_pct=0.18,
        ...     drawdown_from_peak=-0.056,
        ...     previous_sl=0.08
        ... )
    """

    entry_price: float = Field(
        ..., alias="entryPrice", gt=0, description="Original entry price when position opened"
    )
    peak_price: float = Field(
        ..., alias="peakPrice", gt=0, description="Highest price seen since entry"
    )
    current_price: float = Field(
        ..., alias="currentPrice", gt=0, description="Current market price"
    )
    days_held: int = Field(..., alias="daysHeld", ge=0, description="Days position has been held")
    profit_pct: float = Field(
        ..., alias="profitPct", description="Current profit/loss percentage from entry"
    )
    drawdown_from_peak: float = Field(
        ..., alias="drawdownFromPeak", le=0, description="Drawdown from peak as negative percentage"
    )
    previous_sl: Optional[float] = Field(
        None,
        alias="previousSL",
        description="Previous trailing stop value as percentage from entry",
    )

    @field_validator("peak_price")
    @classmethod
    def validate_peak_vs_entry(cls, v: float, info: ValidationInfo) -> float:
        """Ensure peak price >= entry price."""
        if "entry_price" in info.data and v < info.data["entry_price"]:
            raise ValueError("peak_price cannot be less than entry_price")
        return v

    @field_validator("profit_pct")
    @classmethod
    def validate_profit_calculation(cls, v: float, info: ValidationInfo) -> float:
        """Validate profit_pct matches calculation."""
        if "entry_price" in info.data and "current_price" in info.data:
            expected = (info.data["current_price"] - info.data["entry_price"]) / info.data[
                "entry_price"
            ]
            if abs(v - expected) > 0.0001:
                raise ValueError(
                    f"profit_pct {v} doesn't match calculation "
                    f"{expected:.4f} from (current - entry) / entry"
                )
        return v

    @field_validator("drawdown_from_peak")
    @classmethod
    def validate_drawdown_calculation(cls, v: float, info: ValidationInfo) -> float:
        """Validate drawdown_from_peak matches calculation."""
        if "peak_price" in info.data and "current_price" in info.data:
            expected = (info.data["current_price"] - info.data["peak_price"]) / info.data[
                "peak_price"
            ]
            if abs(v - expected) > 0.0001:
                raise ValueError(
                    f"drawdown_from_peak {v} doesn't match calculation "
                    f"{expected:.4f} from (current - peak) / peak"
                )
        return v

    model_config = {"frozen": True, "populate_by_name": True}


class TechnicalAnalysisIndicatorConfig(BaseModel):
    """Technical analysis indicator configuration.

    All fields are optional and will use API defaults if not provided.

    Attributes:
        rsi_period: RSI calculation period (default: 14)
        macd_fast: MACD fast EMA period (default: 12)
        macd_slow: MACD slow EMA period (default: 26)
        macd_signal: MACD signal line period (default: 9)
        sma_periods: Simple Moving Average periods (default: [20, 50, 200])
        ema_periods: Exponential Moving Average periods (default: [12, 26])
        bb_period: Bollinger Bands period (default: 20)
        bb_std_dev: Bollinger Bands standard deviation multiplier (default: 2.0)
        adx_period: Average Directional Index period (default: 14)
        stochastic_period: Stochastic oscillator period (default: 14)
    """

    rsi_period: Optional[int] = Field(
        None, alias="rsiPeriod", ge=2, le=50, description="RSI period (default: 14)"
    )
    macd_fast: Optional[int] = Field(
        None, alias="macdFast", ge=2, le=50, description="MACD fast period (default: 12)"
    )
    macd_slow: Optional[int] = Field(
        None, alias="macdSlow", ge=2, le=100, description="MACD slow period (default: 26)"
    )
    macd_signal: Optional[int] = Field(
        None, alias="macdSignal", ge=2, le=50, description="MACD signal period (default: 9)"
    )
    sma_periods: Optional[List[int]] = Field(
        None, alias="smaPeriods", description="SMA periods (default: [20, 50, 200])"
    )
    ema_periods: Optional[List[int]] = Field(
        None, alias="emaPeriods", description="EMA periods (default: [12, 26])"
    )
    bb_period: Optional[int] = Field(
        None, alias="bbPeriod", ge=2, le=100, description="Bollinger Bands period (default: 20)"
    )
    bb_std_dev: Optional[float] = Field(
        None, alias="bbStdDev", ge=0.5, le=5.0, description="BB std dev (default: 2.0)"
    )
    adx_period: Optional[int] = Field(
        None, alias="adxPeriod", ge=2, le=50, description="ADX period (default: 14)"
    )
    stochastic_period: Optional[int] = Field(
        None, alias="stochasticPeriod", ge=2, le=50, description="Stochastic period (default: 14)"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class TechnicalAnalysisConfig(BaseModel):
    """Technical Analysis integration configuration.

    Controls whether and how Technical Analysis indicators influence
    portfolio optimization decisions.

    Attributes:
        enabled: Enable TA integration (default: False)
        weight: TA influence weight 0-1 (default: 0.3 = 30% influence)
        disable_cache: Disable TA caching for backtesting (default: False)
        config: TA indicator configuration (optional, uses API defaults)

    Example:
        >>> # Basic TA enablement with defaults
        >>> ta_config = TechnicalAnalysisConfig(enabled=True, weight=0.3)

        >>> # Custom TA configuration
        >>> ta_config = TechnicalAnalysisConfig(
        ...     enabled=True,
        ...     weight=0.35,
        ...     config=TechnicalAnalysisIndicatorConfig(
        ...         rsi_period=21,
        ...         macd_fast=8,
        ...         sma_periods=[10, 30, 100]
        ...     )
        ... )
    """

    enabled: bool = Field(default=False, description="Enable TA integration")
    weight: float = Field(default=0.3, ge=0.0, le=1.0, description="TA influence weight (0-1)")
    disable_cache: bool = Field(
        default=False, alias="disableCache", description="Disable cache for backtesting"
    )
    config: Optional[TechnicalAnalysisIndicatorConfig] = Field(
        None, description="Indicator configuration (uses defaults if not provided)"
    )

    model_config = {"frozen": True, "populate_by_name": True}


class OptimizePortfolioRequest(BaseModel):
    """Request to optimize portfolio allocation with TA and Risk Controls.
    - currentBalances, currentDrawdown, and projectedVol are now MANDATORY
    - currentPortfolio has been REMOVED (consolidated into currentBalances)

    Example:
        >>> # New portfolio optimization
        >>> request = OptimizePortfolioRequest(
        ...     assets=["BTC", "ETH", "SOL"],
        ...     risk_profile="moderate",
        ...     current_balances={"USDC": 10000},  # MANDATORY - token amounts
        ...     current_drawdown=0,  # MANDATORY - 0 for new portfolio
        ...     projected_vol=0.20,  # MANDATORY - estimated volatility
        ...     budget=10000
        ... )

        >>> # Rebalancing existing portfolio
        >>> request = OptimizePortfolioRequest(
        ...     assets=["BTC", "ETH", "SOL", "LINK"],
        ...     risk_profile="aggressive",
        ...     current_balances={  # MANDATORY - current token amounts
        ...         "BTC": 0.5,
        ...         "ETH": 5.0,
        ...         "SOL": 100.0,
        ...         "USDC": 5000
        ...     },
        ...     current_drawdown=-0.08,  # MANDATORY - current 8% loss
        ...     projected_vol=0.25,  # MANDATORY - expected 25% volatility
        ...     technical_analysis=TechnicalAnalysisConfig(
        ...         enabled=True,
        ...         weight=0.3
        ...     )
        ... )

        >>> # Backtesting with TA
        >>> request = OptimizePortfolioRequest(
        ...     assets=["BTC", "ETH"],
        ...     risk_profile="moderate",
        ...     current_balances={"USDC": 10000},
        ...     current_drawdown=0,
        ...     projected_vol=0.20,
        ...     historical_data=[...],
        ...     backtest_date="2024-01-15T00:00:00Z",
        ...     technical_analysis=TechnicalAnalysisConfig(
        ...         enabled=True,
        ...         weight=0.3,
        ...         disable_cache=True
        ...     )
        ... )

        >>> # With position tracking for trailing stops
        >>> request = OptimizePortfolioRequest(
        ...     assets=["BTC", "ETH"],
        ...     risk_profile="moderate",
        ...     current_balances={"BTC": 0.5, "ETH": 5.0, "USDC": 5000},
        ...     current_drawdown=-0.08,
        ...     projected_vol=0.22,
        ...     position_metadata={
        ...         "BTC": {
        ...             "entryPrice": 100000,
        ...             "peakPrice": 125000,
        ...             "currentPrice": 118000,
        ...             "daysHeld": 14,
        ...             "profitPct": 0.18,
        ...             "drawdownFromPeak": -0.056,
        ...             "previousSL": 0.08
        ...         }
        ...     }
        ... )
    """

    # Required fields
    assets: List[str] = Field(..., min_length=1, description="Asset symbols (e.g., BTC, ETH)")
    risk_profile: RiskProfileType = Field(
        ..., alias="riskProfile", description="Risk profile (conservative, moderate, aggressive)"
    )
    current_balances: Dict[str, float] = Field(
        ...,
        alias="currentBalances",
        description="Current balances by asset (token amounts, e.g., {'USDC': 10000, 'BTC': 0.5})",
    )
    current_drawdown: float = Field(
        ...,
        alias="currentDrawdown",
        le=0,
        description="Current portfolio drawdown (0 for new portfolio, -0.12 for 12% loss)",
    )
    projected_vol: float = Field(
        ...,
        alias="projectedVol",
        gt=0,
        le=2.0,
        description="Projected portfolio volatility (0.20 = 20% expected volatility)",
    )

    # Optional core fields
    budget: Optional[float] = Field(None, gt=0, description="Investment budget")
    horizon_days: Optional[int] = Field(
        7, alias="horizonDays", ge=1, le=365, description="Forecast horizon in days"
    )
    sentiment_timeframe_hours: Optional[int] = Field(
        24, alias="sentimentTimeframeHours", ge=1, description="Sentiment timeframe in hours"
    )

    # Technical Analysis Configuration
    technical_analysis: Optional[TechnicalAnalysisConfig] = Field(
        None, alias="technicalAnalysis", description="Technical Analysis configuration"
    )

    # Historical data for backtesting
    historical_data: Optional[List[Dict[str, Any]]] = Field(
        None,
        alias="historicalData",
        description="Historical OHLCV data for backtesting (90+ days per asset)",
    )
    backtest_date: Optional[str] = Field(
        None,
        alias="backtestDate",
        description="ISO 8601 datetime for backtesting. Triggers historical F&G sentiment lookup",
    )

    # Position tracking for trailing stops
    position_metadata: Optional[Dict[str, Dict[str, Any]]] = Field(
        None,
        alias="positionMetadata",
        description="Position tracking data for trailing stop calculations. Keys are asset symbols.",
    )

    # Nested configurations
    constraints: Optional[Constraints] = None
    optimization: Optional[OptimizationConfig] = None
    options: Optional[Options] = None

    @field_validator("assets")
    @classmethod
    def validate_assets(cls, v: List[str]) -> List[str]:
        """Validate and normalize asset symbols."""
        if not v:
            raise ValueError("At least one asset is required")

        # Convert to uppercase for consistency
        return [asset.upper().strip() for asset in v]

    @field_validator("current_balances")
    @classmethod
    def validate_balances(cls, v: Dict[str, float]) -> Dict[str, float]:
        """Validate and normalize balance keys to uppercase."""
        if not v:
            raise ValueError("At least one balance is required")

        # Validate all values are non-negative
        for asset, amount in v.items():
            if amount < 0:
                raise ValueError(f"Balance for {asset} cannot be negative: {amount}")

        return {k.upper(): val for k, val in v.items()}

    model_config = {"frozen": True, "populate_by_name": True}


class CreateKeyRequest(BaseModel):
    """Request to create new API key.

    Example:
        >>> request = CreateKeyRequest(
        ...     name="Production Key",
        ...     expires_in_days=90,
        ...     scopes=["read", "write"]
        ... )
    """

    name: str = Field(..., min_length=1, max_length=100, description="Descriptive name for the key")
    expires_in_days: Optional[int] = Field(
        365, alias="expiresInDays", ge=1, le=365, description="Days until key expires"
    )
    scopes: Optional[List[str]] = Field(None, description="Key scopes (e.g., read, write, admin)")

    model_config = {"frozen": True, "populate_by_name": True}
