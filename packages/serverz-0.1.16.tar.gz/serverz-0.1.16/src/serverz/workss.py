from deepagents import create_deep_agent
from langchain.chat_models import init_chat_model
from langchain_openai import OpenAI

from langchain_mcp_adapters.client import MultiServerMCPClient  
import os
import asyncio

research_instructions = """\
You are an expert researcher. Your job is to conduct \
thorough research, and then write a polished report. \
"""
research_instructions = """You are an expert researcher. Your job is to conduct thorough research and then write a polished report.

You have access to an internet search tool as your primary means of gathering information.

## `add_func`

Use this to add two numbers.

## `weather`

Use this to get the weather.
"""



class Work():
    def __init__(self):
        self.llm = OpenAI(api_key=os.getenv("BIANXIE_API_KEY"),
                    base_url=os.getenv("BIANXIE_BASE"),
                    )
        
        self.model = init_chat_model(
            model="openai:gpt-5",
            api_key=os.getenv("BIANXIE_API_KEY"),
            base_url=os.getenv("BIANXIE_BASE"),
        )

        self.client = MultiServerMCPClient(  
                {
                    "weather": {
                        "transport": "streamable_http",  # HTTP-based remote server
                        # Ensure you start your weather server on port 8000
                        "url": "http://localhost:8000/mcp",
                    }
                }
            )
        
    def add_func(a: int, b: int) -> int:
        """Add two numbers"""
        print('run add_func')
        return a + b
    
    async def create_agent(self):
        tools = await self.client.get_tools()

        agent = create_deep_agent(
            model=self.model,
            # tools=[add_func],
            tools=tools,
            system_prompt=research_instructions
        )
        print(agent,'agent')
        self.agent = agent

    
    async def work(self):
        # result = agent.invoke({"messages": [{"role": "user", "content": "what weather is it like in new york?"}]})
        result = await self.agent.ainvoke({"messages": [{"role": "user", "content": "what weather is it like in new york?"}]})
        print(result["messages"][-1].content)
        return result["messages"][-1].content
