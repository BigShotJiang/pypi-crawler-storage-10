
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from serverz.log import Log
import argparse
import uvicorn
from serverz.server.models import *
from serverz.server.routers import chat_router, read_router
from contextlib import asynccontextmanager, AsyncExitStack
from serverz.server.scheduler_task import perform_shutdown_tasks, perform_startup_tasks
from serverz.server.mcp import llmada_mcp
from serverz import logger


coding_log = logger.info

default=8008


@asynccontextmanager
async def lifespan(app: FastAPI):
    """_summary_

    Args:
        app (FastAPI): _description_
    """
    # mcp 服务
    async with AsyncExitStack() as stack:
        # await stack.enter_async_context(fm_math.session_manager.run())
        await stack.enter_async_context(llmada_mcp.session_manager.run())
    await perform_startup_tasks()
    yield
    await perform_shutdown_tasks()


app = FastAPI(
    title="LLM Service",
    description="Provides an OpenAI-compatible API for custom large language models.",
    version="1.0.1",
    lifespan=lifespan,
    # docs_url="/api-docs",
    # debug=True,
)

# --- Configure CORS ---
origins = [
    "*", # Allows all origins (convenient for development, insecure for production)
    # Add the specific origin of your "别的调度" tool/frontend if known
    # e.g., "http://localhost:5173" for a typical Vite frontend dev server
    # e.g., "http://127.0.0.1:5173"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Specifies the allowed origins
    allow_credentials=True, # Allows cookies/authorization headers
    allow_methods=["*"],    # Allows all methods (GET, POST, OPTIONS, etc.)
    allow_headers=["*"],    # Allows all headers (Content-Type, Authorization, etc.)
)
# --- End CORS Configuration ---

app.include_router(read_router,prefix="/reader")
app.include_router(chat_router,prefix="/v1")
app.mount("/llmada", llmada_mcp.streamable_http_app()) 


@app.get("/")
async def root():
    """ x """
    return {"message": "LLM Service is running."}

@app.get("/update_topic")
async def update_topic(text: str):
    """ x """
    with open("topic.txt",'w') as f:
        f.write(text)
    
    with open("topic.txt",'r') as f:
        new_text = f.read()
    return {"message": "success.", "text": new_text}


@app.get("/update_chat_prompt")
async def update_chat_prompt(text: str):
    """ x """
    with open("chat_system_prompt.txt",'w') as f:
        f.write(text)
    
    with open("chat_system_prompt.txt",'r') as f:
        new_text = f.read()
    return {"message": "success.", "text": new_text}

@app.get("/get_chat_prompt")
async def get_chat_prompt():
    """ x """

    with open("chat_system_prompt.txt",'r') as f:
        new_text = f.read()

    
    return {"message": "success.", "text": new_text}



if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(
        description="Start a simple HTTP server similar to http.server."
    )
    parser.add_argument(
        'port',
        metavar='PORT',
        type=int,
        nargs='?', # 端口是可选的
        default=default,
        help=f'Specify alternate port [default: {default}]'
    )
    # 创建一个互斥组用于环境选择
    group = parser.add_mutually_exclusive_group()

    # 添加 --dev 选项
    group.add_argument(
        '--dev',
        action='store_true', # 当存在 --dev 时，该值为 True
        help='Run in development mode (default).'
    )

    # 添加 --prod 选项
    group.add_argument(
        '--prod',
        action='store_true', # 当存在 --prod 时，该值为 True
        help='Run in production mode.'
    )
    args = parser.parse_args()

    if args.prod:
        env = "prod"
    else:
        # 如果 --prod 不存在，默认就是 dev
        env = "dev"

    port = args.port
    if env == "dev":
        port += 100
        reload = True
        app_import_string = f"{__package__}.__main__:app" # <--- 关键修改：传递导入字符串
    elif env == "prod":
        reload = False
        app_import_string = app
    else:
        reload = False
        app_import_string = app
    

    # 使用 uvicorn.run() 来启动服务器
    # 参数对应于命令行选项
    uvicorn.run(
        app_import_string,
        host="0.0.0.0",
        port=port,
        reload=reload  # 启用热重载
    )


