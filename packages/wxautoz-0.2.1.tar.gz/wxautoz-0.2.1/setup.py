# setup.py
from setuptools import setup, find_packages

setup(
    name="wxautoz",
    version="0.2.1",          
    packages=find_packages(), # 自动包含包
    python_requires=">=3.8",
)