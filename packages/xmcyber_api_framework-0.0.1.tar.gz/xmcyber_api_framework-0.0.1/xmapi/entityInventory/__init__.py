import xmapi
from xmapi.util import default_on_error

def entityTypes(on_error=None):
    """Return a list of all entity types in the current system.

    Argument:
    on_error -- Call this method if the XM API returns an error
"""
    if on_error:
        return xmapi.api_get(("", ""), on_error=on_error)
    else:
        return xmapi.api_get(("entityInventory", "entityTypes"))
    

def entities(typeIds=None, page=1, pageSize=100, search=None, filter=None, sort=None, on_error=default_on_error):
    """Return a page of all entities matching the type ID, search and filter arguments.

    Arguments:
    typeIds -- A list of all type IDs to search for. Can be seen by calling #entityTypes()
    page    -- Page (1-index) of the results to return
    pageSize -- Number of entities to return per page
    search   -- Search string to use for finding entities
    filter   -- Filter string to use for finding entities
    sort     -- Attribute to use for sorting the results
    on_error -- Method to call if the XM API returns an error

    """
    params = {}
    if typeIds:
        if not type(typeIds) == str:
            typeIds=",".join(typeIds)

        params["entityTypeIds[]"] = typeIds

    params["page"] = page
    params["pageSize"] = pageSize
    if sort:
        params["sort"] = sort

    if search: #search={"$regex":"/eks-/i"}
        params["search"]=f'{{"$regex":"/{search}/"}}'

    if filter:
        raise Exception("filter not yet implemented")
    
    result = xmapi.api_get(("entityInventory","entities"),params=params)
    if result.status_code < 200 or result.status_code > 299:
        on_error(result)

    return result