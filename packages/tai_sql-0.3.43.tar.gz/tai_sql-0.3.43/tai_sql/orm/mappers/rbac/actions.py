from enum import Enum

class APIAction(Enum):
    # BASE ACTIONS
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    NONE = "none"
    # SHORTCUTS
    ADMIN = "admin"  # All actions
    MAINTAIN = "maintainer"  # SELECT, INSERT, UPDATE
    READER = "reader"  # SELECT only

class AppAction(Enum):
    """
    Acciones específicas para componentes.
    Estas acciones se aplican solo a componentes individuales.
    """
    SEE = "see"  # Puede acceder/ver el componente
    MANTAIN = "maintain"  # Puede modificar la configuración del componente
    FULL = "full"  # Puede interactuar con el componente (clics, entradas, etc.)
