from __future__ import annotations
from pydantic import BaseModel, Field
from typing import (
    List, Type, Optional,
    TYPE_CHECKING, NewType,
    Literal, Dict, Union
)

from ..table import Table

if TYPE_CHECKING:
    from .actions import APIAction, AppAction
    from .front import App, Screen, Component, AppElement

AllTables = NewType('AllTables', type)
    

class APIPermission(BaseModel):
    """
    Definición de permiso para un recurso específico.
    Un permiso asocia un recurso (tabla) con una acción (operación).
    """
    resource: Type[Table] = Field(..., description="Recurso de base de datos (tabla)")
    action: APIAction = Field(..., description="Acción permitida en el recurso")

    @property
    def value(self) -> str:
        return f"api:{self.resource.tablename}:{self.action.value}"


class AppPermission(BaseModel):
    element: App | Screen | Component = Field(..., description="Elemento de la aplicación (App, Screen, Component)")
    action: AppAction = Field(..., description="Acción permitida en el elemento")

    @property
    def value(self) -> str:
        return f"app:{self.element.path}:{self.action.value}"

Permission = APIPermission | AppPermission

class PermSet:
    def __init__(self, see_perms: Optional[List[Permission]] = None):
        self._see_perms = see_perms or []

    def __add__(self, other: PermSet) -> PermSet:
        return PermSet(self._see_perms + other._see_perms)

    def __sub__(self, other: PermSet) -> PermSet:
        return PermSet([p for p in self._see_perms if p not in other._see_perms])

    def __iter__(self):
        return iter(self._see_perms)

    def __repr__(self):
        return f"PermSet({self._see_perms})"

    def to_list(self) -> List[Permission]:
        return list(self._see_perms)


AppScopes = Literal['see', 'mantain', 'full']

class PermissionManager:

    def __init__(self, element: AppElement):
        self.element = element
        self._permissions: Dict[AppScopes, List[Permission]] = {}

    def add_permission(self, scope: AppScopes, permission: Permission):
        if permission not in self._permissions:
            self._permissions.setdefault(scope, []).append(permission)
    
    def add_see_permission(self, permission: Permission):
        self.add_permission('see', permission)
    
    def add_maintain_permission(self, permission: Permission):
        self.add_permission('mantain', permission)
    
    def add_full_permission(self, permission: Permission):
        self.add_permission('full', permission)

    def remove_permission(self, scope: AppScopes, permission: Permission):
        if permission in self._permissions.setdefault(scope, []):
            self._permissions[scope].remove(permission)

    def list_permissions(self) -> Dict[AppScopes, List[Permission]]:
        return self._permissions
    
    def list_see_permissions(self) -> List[Permission]:
        return self._permissions.get('see', [])
    
    def list_maintain_permissions(self) -> List[Permission]:
        return self._permissions.get('mantain', [])
    
    def list_full_permissions(self) -> List[Permission]:
        return self._permissions.get('full', [])
    
    def generate_permissions(self) -> None:
        """Retorna los permisos de lectura para este elemento"""

        from .actions import APIAction, AppAction

        see_perms = [AppPermission(element=self.element, action=AppAction.SEE)]

        for table in self.element._tables:
            see_perms.extend(unpack_api_permissions(resource=table, action=APIAction.READER))

        for perm in see_perms:
            self.add_see_permission(perm)
        
        maintain_perms = [AppPermission(element=self.element, action=AppAction.MANTAIN)]

        for table in self.element._tables:
            maintain_perms.extend(unpack_api_permissions(resource=table, action=APIAction.MAINTAIN))
        
        for perm in maintain_perms:
            self.add_maintain_permission(perm)
        
        full_perms = [AppPermission(element=self.element, action=AppAction.FULL)]

        for table in self.element._tables:
            full_perms.extend(unpack_api_permissions(resource=table, action=APIAction.ADMIN))
        
        for perm in full_perms:
            self.add_full_permission(perm)

def unpack_api_permissions(resource: Type[Table], action: APIAction) -> List[APIPermission]:
    """
    Convierte acciones de alto nivel en una lista de permisos específicos.
    Args:
        resource: Clase de tabla específica
        action: Acción o conjunto de acciones a asignar
        priority: Prioridad del conjunto de permisos
    Returns:
        Lista de permisos específicos y su prioridad
    """
    if not isinstance(action, APIAction):
        raise ValueError("La action debe ser una instancia de APIAction")
    
    if not issubclass(resource, Table):
        raise ValueError("El resource debe ser una subclase de Table")
    
    if action == APIAction.ADMIN:
        return [
                APIPermission(resource=resource, action=APIAction.SELECT),
                APIPermission(resource=resource, action=APIAction.INSERT),
                APIPermission(resource=resource, action=APIAction.UPDATE),
                APIPermission(resource=resource, action=APIAction.DELETE),
            ]
    elif action == APIAction.MAINTAIN:
        return [
                APIPermission(resource=resource, action=APIAction.SELECT),
                APIPermission(resource=resource, action=APIAction.INSERT),
                APIPermission(resource=resource, action=APIAction.UPDATE),
            ]
    
    elif action == APIAction.READER:
        return [APIPermission(resource=resource, action=APIAction.SELECT)]
    else:
        return [APIPermission(resource=resource, action=action)]

def perms(resource: Type[Union[Table, AllTables]], action: APIAction) -> PermSet:
    """
    Generador de combinaciones de permisos.
    Convierte acciones de bajo o alto nivel en una lista de permisos específicos.
    Args:
        resource: Clase de tabla específica o AllTables para todas las tablas
        action: Acción o conjunto de acciones a asignar
    Returns:
        Lista de permisos específicos
    """
    
    if resource == AllTables:
        # Handle AllTables case - apply to all registered tables
        return PermSet([
            perm
            for table in Table.get_registered_tables()
            for perm in unpack_api_permissions(resource=table, action=action)
        ])
    elif issubclass(resource, Table):
        return PermSet(unpack_api_permissions(resource, action))
