from __future__ import annotations
from enum import Enum
from typing import List, Dict, Optional, Type, TYPE_CHECKING
from pydantic import BaseModel, Field, PrivateAttr

from .permissions import (
    PermissionManager,
    AllTables,
    PermSet,
    AppPermission,
    unpack_api_permissions
)
from .actions import APIAction, AppAction

if TYPE_CHECKING:
    from tai_sql.orm import Table

class ComponentType(Enum):
    """
    Tipos de componentes que pueden existir en una aplicación.
    Esto ayuda a categorizar los componentes y aplicar reglas específicas.
    """
    FORM = "form"
    TABLE = "table"
    BUTTON = "button"
    MENU = "menu"
    MODAL = "modal"
    CARD = "card"
    CHART = "chart"
    INPUT = "input"
    SELECT = "select"
    CUSTOM = "custom"

class AppElement(BaseModel):
    """
    Clase base para todos los elementos de la aplicación.
    Define el comportamiento común para App, Screen y Component.
    """
    id: str = Field(..., description="Identificador único del elemento")
    name: Optional[str] = Field(default=None, description="Nombre descriptivo del elemento")
    description: Optional[str] = Field(default=None, description="Descripción del elemento")
    enabled: Optional[bool] = Field(default=True, description="Si el elemento está habilitado")
    tables: List[Type[Table]] | AllTables = Field(default=AllTables, description="Tablas de base de datos asociadas")
    
    # Metadatos para el control de acceso
    tags: List[str] = Field(default_factory=list, description="Etiquetas para categorización")
    metadata: Dict[str, str] = Field(default_factory=dict, description="Metadatos adicionales")

    _loaded: bool = PrivateAttr(default=False)
    _manager: PermissionManager = PrivateAttr()

    def model_post_init(self, __context):
        
        if self.tables is AllTables:
            self._tables = Table.get_registered_tables()
        else:
            self._tables = self.tables

        self._manager = PermissionManager(self)
    
    def load_permissions(self) -> None:
        """Genera y carga los permisos para este elemento"""
        if not self._loaded:
            self._manager.generate_permissions()
            self._loaded = True
    
    @property
    def SEE(self) -> PermSet:
        """Permisos necesarios para ver el elemento"""
        see_perms = [AppPermission(element=self, action=AppAction.SEE)]

        for table in self._tables:
            see_perms.extend(unpack_api_permissions(resource=table, action=APIAction.READER))
        
        return PermSet(see_perms)
    
    @property
    def MAINTAIN(self) -> PermSet:
        """Permisos necesarios para mantener/modificar el elemento"""
        self.load_permissions()
        return PermSet(self._manager.list_maintain_permissions())
    
    @property
    def FULL(self) -> PermSet:
        """Permisos necesarios para interactuar completamente con el elemento"""
        self.load_permissions()
        return PermSet(self._manager.list_full_permissions())
    
class Component(AppElement):
    """
    Componente: elemento más básico de la aplicación.
    Representa cualquier elemento interactivo o visual.
    """
    type: ComponentType = Field(default=ComponentType.CUSTOM)
    app: Optional[App] = Field(default=None, description="Aplicación padre")
    screen: Optional[Screen] = Field(default=None, description="Pantalla padre")
    
    # Configuración específica del componente
    props: Dict[str, str] = Field(default_factory=dict, description="Propiedades del componente")

    @property
    def path(self) -> str:
        return f"{self.app.id}.{self.screen.id}.{self.id}"

class Screen(AppElement):
    """
    Pantalla: contiene múltiples componentes.
    Representa una vista o página de la aplicación.
    """
    app: Optional[App] = Field(default=None, description="Aplicación padre")
    components: List[Component] = Field(default_factory=list)

    @property
    def path(self) -> str:
        return f"{self.app.id}.{self.id}"
    
    def add_component(self, component: Component) -> Screen:
        """Añade un componente a la pantalla"""
        component.screen = self
        component.app = self.app
        self.components.append(component)

        return self
    
    def add_components(self, *components: List[Component]) -> Screen:
        """Añade múltiples componentes a la pantalla"""
        for component in components:
            self.add_component(component)

        return self
    
    def get_component(self, component_id: str) -> Optional[Component]:
        """Obtiene un componente por su ID"""
        return next((c for c in self.components if c.id == component_id), None)
    
    def get_components_by_type(self, component_type: ComponentType) -> List[Component]:
        """Obtiene todos los componentes de un tipo específico"""
        return [c for c in self.components if c.type == component_type]


class App(AppElement):
    """
    Aplicación: nivel superior que contiene pantallas.
    Representa toda la aplicación o un módulo principal.
    """
    screens: List[Screen] = Field(default_factory=list)
    
    @property
    def path(self) -> str:
        return self.id
    
    def add_screen(self, screen: Screen) -> App:
        """Añade una pantalla a la aplicación"""
        screen.app = self
        self.screens.append(screen)

        return self
    
    def add_screens(self, *screens: List[Screen]) -> App:
        """Añade múltiples pantallas a la aplicación"""
        for screen in screens:
            self.add_screen(screen)

        return self
    
    def get_screen(self, screen_id: str) -> Optional[Screen]:
        """Obtiene una pantalla por su ID"""
        return next((s for s in self.screens if s.id == screen_id), None)
    
    def get_component(self, screen_id: str, component_id: str) -> Optional[Component]:
        """Obtiene un componente específico de una pantalla"""
        screen = self.get_screen(screen_id)
        return screen.get_component(component_id) if screen else None
    
    def get_all_elements(self) -> List[AppElement]:
        """Retorna todos los elementos de la aplicación en una lista plana"""
        elements: List[AppElement] = [self]
        
        for screen in self.screens:
            elements.append(screen)
            elements.extend(screen.components)
            
        return elements


# Funciones helper para crear la estructura de forma más fluida

def app(id: str, name: Optional[str] = None, description: Optional[str] = None, **kwargs) -> App:
    """Helper para crear una aplicación"""
    return App(id=id, name=name, description=description, **kwargs)

def screen(id: str, name: Optional[str] = None, description: Optional[str] = None, route: str = None, **kwargs) -> Screen:
    """Helper para crear una pantalla"""
    return Screen(id=id, name=name, description=description, route=route, **kwargs)

def component(id: str, name: Optional[str] = None, type: ComponentType = ComponentType.CUSTOM, 
              description: Optional[str] = None, **kwargs) -> Component:
    """Helper para crear un componente"""
    return Component(id=id, name=name, type=type, description=description, **kwargs)

from tai_sql.orm import Table
# --- Resolver referencias adelantadas ---
AppPermission.model_rebuild()