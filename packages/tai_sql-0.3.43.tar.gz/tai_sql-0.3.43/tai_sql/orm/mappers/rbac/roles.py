from __future__ import annotations
from pydantic import BaseModel, Field
from typing import (
    List, Union, Dict
)

from tai_sql import pm
from .permissions import PermSet

    
class Role(BaseModel):
    name: str
    description: str = Field(default="")
    permissions: PermSet = Field(default_factory=PermSet)

    def info(self) -> Dict[str, Union[str, List[Dict]]]:
        """Información del rol"""
        return {
            'name': self.name,
            'description': self.description,
            'permissions': [perm.model_dump() for perm in self.permissions]
        }
    
    model_config = {
        'arbitrary_types_allowed': True
    }

def role(
    name: str,
    permissions: PermSet,
    description: str = "") -> Role:
    """Helper para crear roles"""
            
    role = Role(
        name=name,
        description=description,
        permissions=permissions,
    )

    pm.roles.register(role)

    return role