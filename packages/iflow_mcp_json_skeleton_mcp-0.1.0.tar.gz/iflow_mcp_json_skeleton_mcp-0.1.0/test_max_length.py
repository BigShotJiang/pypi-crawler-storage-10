#!/usr/bin/env python3
"""Test script for JSON Skeleton with different max_length values."""

import json
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
from json_skeleton.skeleton_generator import SkeletonGenerator


def test_with_max_lengths():
    """Test the skeleton generator with different max_length values."""
    generator = SkeletonGenerator()
    
    print("Testing with different max_length values:")
    print("=" * 60)
    
    # Test with different max_length values
    for max_len in [50, 100, 200, 500]:
        print(f"\n\nMax Length: {max_len}")
        print("-" * 30)
        result = generator.process_file("test_data.json", max_length=max_len)
        skeleton = result['skeleton']
        
        # Just show a sample of the skeleton to see truncation
        sample = json.dumps(skeleton, indent=2, ensure_ascii=False)
        lines = sample.split('\n')
        
        # Show first 20 lines
        for line in lines[:20]:
            print(line)
        
        if len(lines) > 20:
            print("... (output truncated for display)")


if __name__ == "__main__":
    test_with_max_lengths()