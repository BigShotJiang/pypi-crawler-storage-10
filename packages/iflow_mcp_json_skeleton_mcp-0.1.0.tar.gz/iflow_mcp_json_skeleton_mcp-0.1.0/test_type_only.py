#!/usr/bin/env python3
"""Test script for JSON Skeleton type_only mode."""

import json
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
from json_skeleton.skeleton_generator import SkeletonGenerator


def test_type_only_mode():
    """Test the skeleton generator with type_only mode."""
    generator = SkeletonGenerator()
    
    print("Testing type_only mode:")
    print("=" * 60)
    
    # Normal mode
    print("\n\nNormal mode (with values):")
    print("-" * 30)
    result = generator.process_file("test_data.json", max_length=100)
    output = json.dumps(result['skeleton'], indent=2, ensure_ascii=False)
    lines = output.split('\n')
    for line in lines[:30]:
        print(line)
    print("... (output truncated for display)")
    
    # Type only mode
    print("\n\nType-only mode (most compact):")
    print("-" * 30)
    result = generator.process_file("test_data.json", type_only=True)
    output = json.dumps(result['skeleton'], indent=2, ensure_ascii=False)
    lines = output.split('\n')
    for line in lines[:30]:
        print(line)
    print("... (output truncated for display)")


if __name__ == "__main__":
    test_type_only_mode()