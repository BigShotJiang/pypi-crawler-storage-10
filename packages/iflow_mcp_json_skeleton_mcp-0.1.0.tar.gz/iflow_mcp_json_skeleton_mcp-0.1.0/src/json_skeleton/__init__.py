"""JSON Skeleton MCP Tool - Create lightweight skeletons from large JSON files."""

from .skeleton_generator import SkeletonGenerator

__version__ = "0.1.0"
__all__ = ["SkeletonGenerator"]

# Only import server if running as MCP server
try:
    from .server import server
    __all__.append("server")
except ImportError:
    pass
