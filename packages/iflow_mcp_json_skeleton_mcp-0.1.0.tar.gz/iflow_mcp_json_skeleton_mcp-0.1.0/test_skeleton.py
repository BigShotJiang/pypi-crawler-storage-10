#!/usr/bin/env python3
"""Test script for JSON Skeleton functionality."""

import json
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
from json_skeleton.skeleton_generator import SkeletonGenerator


def test_skeleton_generator():
    """Test the skeleton generator with sample data."""
    generator = SkeletonGenerator()
    
    # Test with the test data file
    result = generator.process_file("test_data.json")
    
    # Format output exactly like MCP server - just the skeleton
    output = json.dumps(result['skeleton'], indent=2, ensure_ascii=False)
    
    print(output)


if __name__ == "__main__":
    test_skeleton_generator()