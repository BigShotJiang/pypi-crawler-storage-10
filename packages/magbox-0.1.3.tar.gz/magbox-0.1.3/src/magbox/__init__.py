__version__="0.1.0"
__author__="Yutian Wang"

from .llg import llg
from .heff import heff
from .spin import spin
from .boxlib import get_data_type
