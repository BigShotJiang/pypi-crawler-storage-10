# SyncResultOfClockPresalesSupplyLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**maximum_sequence_number** | **int** |  | 
**results** | [**list[ClockPresalesSupplyLine]**](ClockPresalesSupplyLine.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

