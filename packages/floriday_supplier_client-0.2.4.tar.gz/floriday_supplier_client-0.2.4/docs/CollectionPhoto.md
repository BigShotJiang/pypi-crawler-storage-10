# CollectionPhoto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**photo_id** | **str** |  | 
**sort_index** | **int** |  | 
**last_modified** | **datetime** |  | [optional] 
**is_deleted** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

