# FulfillmentRequestCreateAuctionTradeItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fulfillment_request_id** | **str** |  | 
**trade_item_id** | **str** |  | 
**new_batch_id** | **str** |  | 
**packing_configuration** | [**AddBatchPackingConfiguration**](AddBatchPackingConfiguration.md) |  | 
**image_url** | **str** | Image URLs posted as Floriday media must conform with the following format https://image.floriday.io/. | [optional] 
**number_of_packages** | **int** |  | 
**clock_pre_sales_price** | **float** |  | [optional] 
**clock_minimum_price** | **float** |  | 
**delivery_remark** | **str** | Used as delivery remarks when creating a FulfillmentOrder. | [optional] 
**auction_remark** | **str** | Used as a remark for the auctioneer. | [optional] 
**service_code** | **int** |  | [optional] 
**packing_agent_organization_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

