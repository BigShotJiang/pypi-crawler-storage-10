"""Defense strategy modules."""

__all__ = []
