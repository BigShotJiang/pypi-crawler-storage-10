"""Model configurations and utilities."""

__all__ = []
