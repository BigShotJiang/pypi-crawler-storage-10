"""Cryptographic utilities for enterprise audit logging."""
