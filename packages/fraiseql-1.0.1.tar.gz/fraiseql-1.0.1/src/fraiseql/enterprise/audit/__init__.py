"""FraiseQL Enterprise Audit Logging module."""
