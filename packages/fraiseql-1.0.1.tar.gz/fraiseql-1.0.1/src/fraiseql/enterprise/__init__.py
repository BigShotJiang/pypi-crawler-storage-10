"""FraiseQL Enterprise Edition modules."""
