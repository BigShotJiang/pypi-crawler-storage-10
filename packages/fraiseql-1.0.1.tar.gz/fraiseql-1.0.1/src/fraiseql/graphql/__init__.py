"""FraiseQL GraphQL execution with unified Rust-first architecture."""

from .execute import execute_graphql

__all__ = [
    "execute_graphql",
]
