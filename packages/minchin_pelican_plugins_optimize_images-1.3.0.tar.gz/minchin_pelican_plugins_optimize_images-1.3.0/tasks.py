try:
    from minchin.releaser import make_release
except ImportError:
    print("[WARN] minchin.releaser not installed.")
