from datetime import datetime
from io import BytesIO
from typing import Optional

import pandas as pd
from brynq_sdk_functions import Functions


class Reports:
    def __init__(self, bob):
        self.bob = bob

    def get(self) -> pd.DataFrame:
        resp = self.bob.session.get(url=f"{self.bob.base_url}company/reports", timeout=self.bob.timeout)
        resp.raise_for_status()
        data = resp.json()
        df = pd.json_normalize(
            data,
            record_path='views'
        )
        # df = self.bob.rename_camel_columns_to_snake_case(df)
        # valid_documents, invalid_documents = Functions.validate_data(df=df, schema=DocumentsSchema, debug=True)

        return df

    def download(self, report_id: Optional[str] = None, report_name: Optional[str] = None) -> dict:
        if report_id:
            url = f"{self.bob.base_url}company/reports/{report_id}"
        elif report_name:
            url = f"{self.bob.base_url}company/reports/download/{report_name}"
        else:
            raise ValueError("Either report_id or report_name must be provided")

        resp = self.bob.session.get(url=url, timeout=self.bob.timeout)
        resp.raise_for_status()
        data = resp.json()

        return data
