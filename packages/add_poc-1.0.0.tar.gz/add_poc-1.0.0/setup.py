from setuptools import setup, Extension

module = Extension(
    "response_handler",              # Name of your compiled module
    sources=["src/response_handler.c"],
)

setup(
    name="add_poc",
    version="1.0.0",
    author="Secuodsoft Dev",
    author_email="dev@secuodsoft.com",
    description="A CPython C extension demo (response_handler)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    ext_modules=[module],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: C",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
    python_requires=">=3.7",
)
