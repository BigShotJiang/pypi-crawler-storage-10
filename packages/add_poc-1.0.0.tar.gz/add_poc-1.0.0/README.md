# add-poc

A minimal **CPython C extension** that adds two integers.

## Installation

```bash
pip install add-poc
