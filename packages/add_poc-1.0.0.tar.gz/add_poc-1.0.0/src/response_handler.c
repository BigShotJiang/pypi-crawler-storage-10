#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <datetime.h>

static PyObject* prepare_and_share_response(PyObject* self, PyObject* args) {
    PyObject* response_original;
    
    // Parse the input argument
    if (!PyArg_ParseTuple(args, "O", &response_original)) {
        return NULL;
    }

    // Check if response_original is a dictionary
    if (!PyDict_Check(response_original)) {
        PyErr_SetString(PyExc_TypeError, "Argument must be a dictionary");
        return NULL;
    }

    // Get transaction_id and reference
    PyObject* transaction_id = PyDict_GetItemString(response_original, "transactionId");
    PyObject* reference = PyDict_GetItemString(response_original, "reference");

    if (transaction_id == Py_None || reference == Py_None) {
        // Create final response dictionary with default values
        PyObject* final_response = PyDict_New();
        if (!final_response) return NULL;

        PyDict_SetItemString(final_response, "success", Py_False);
        PyDict_SetItemString(final_response, "errors", PyList_New(0));
        PyDict_SetItemString(final_response, "msg", PyUnicode_FromString(""));
        PyDict_SetItemString(final_response, "responsetime", PyFloat_FromDouble(0.0));
        PyDict_SetItemString(final_response, "receiptId", PyUnicode_FromString(""));

        // Import json module
        PyObject* json_module = PyImport_ImportModule("json");
        if (!json_module) return NULL;

        // Get json.dumps function
        PyObject* json_dumps = PyObject_GetAttrString(json_module, "dumps");
        if (!json_dumps) return NULL;

        // Convert dictionary to JSON string
        PyObject* json_str = PyObject_CallFunctionObjArgs(json_dumps, final_response, NULL);
        if (!json_str) return NULL;

        // Import django.http
        PyObject* http_module = PyImport_ImportModule("django.http");
        if (!http_module) return NULL;

        // Create HttpResponse
        PyObject* http_response_class = PyObject_GetAttrString(http_module, "HttpResponse");
        if (!http_response_class) return NULL;

        // Create content_type dictionary
        PyObject* kwargs = PyDict_New();
        PyDict_SetItemString(kwargs, "content_type", PyUnicode_FromString("application/json"));

        // Create HttpResponse object
        PyObject* http_response = PyObject_Call(http_response_class, 
                                              PyTuple_Pack(1, json_str), 
                                              kwargs);

        // Cleanup
        Py_DECREF(final_response);
        Py_DECREF(json_module);
        Py_DECREF(json_dumps);
        Py_DECREF(json_str);
        Py_DECREF(http_module);
        Py_DECREF(http_response_class);
        Py_DECREF(kwargs);

        return http_response;
    }

    // Get values from reference dictionary
    PyObject* ref_dict = PyDict_GetItemString(response_original, "reference");
    PyObject* ack_number = PyDict_GetItemString(ref_dict, "acknowledgementNumber");
    PyObject* request_type = PyDict_GetItemString(ref_dict, "requestType");
    PyObject* service_id = PyDict_GetItemString(ref_dict, "serviceId");
    PyObject* department_id = PyDict_GetItemString(ref_dict, "departmentId");

    // Create receipt_id
    PyObject* trans_str = PyObject_Str(transaction_id);
    const char* trans_cstr = PyUnicode_AsUTF8(trans_str);
    char* receipt_id = PyMem_Malloc(strlen(trans_cstr) * 2 + 2);  // Extra space for 'R' and null terminator
    strcpy(receipt_id, trans_cstr);
    strcat(receipt_id, "R");
    char* t_pos = strrchr(trans_cstr, 'T');
    if (t_pos) {
        strcat(receipt_id, t_pos + 1);
    }

    // Get success value
    PyObject* success = PyDict_GetItemString(response_original, "success");
    const char* status = (PyObject_IsTrue(success)) ? "success" : "failed";

    // Import django.utils.timezone
    PyObject* timezone_module = PyImport_ImportModule("django.utils.timezone");
    if (!timezone_module) return NULL;

    // Get current timestamp
    PyObject* now_func = PyObject_GetAttrString(timezone_module, "now");
    PyObject* timestamp = PyObject_CallObject(now_func, NULL);

    // Create RequestLog object and save it
    // Note: This part would need to be implemented based on your Django model structure
    // and database configuration. Here's a placeholder that shows the concept:

    PyObject* final_response = PyDict_New();
    if (!final_response) return NULL;

    // Set values in final_response
    PyDict_SetItemString(final_response, "success", 
                        PyDict_GetItemString(response_original, "success"));
    PyDict_SetItemString(final_response, "errors", 
                        PyDict_GetItemString(response_original, "errors") ? 
                        PyDict_GetItemString(response_original, "errors") : PyList_New(0));
    PyDict_SetItemString(final_response, "msg", 
                        PyDict_GetItemString(response_original, "msg") ? 
                        PyDict_GetItemString(response_original, "msg") : PyUnicode_FromString(""));
    
    // Calculate response time
    PyObject* start_time = PyDict_GetItemString(response_original, "responsetime");
    PyObject* time_module = PyImport_ImportModule("time");
    PyObject* time_func = PyObject_GetAttrString(time_module, "time");
    PyObject* current_time = PyObject_CallObject(time_func, NULL);
    double response_time = PyFloat_AsDouble(current_time) - PyFloat_AsDouble(start_time);
    
    Py_DECREF(time_module);
    Py_DECREF(time_func);
    Py_DECREF(current_time);
    
    PyDict_SetItemString(final_response, "responsetime", PyFloat_FromDouble(response_time));
    PyDict_SetItemString(final_response, "receiptId", PyUnicode_FromString(receipt_id));

    // Import json module
    PyObject* json_module = PyImport_ImportModule("json");
    if (!json_module) return NULL;

    // Get json.dumps function
    PyObject* json_dumps = PyObject_GetAttrString(json_module, "dumps");
    if (!json_dumps) return NULL;

    // Convert dictionary to JSON string
    PyObject* json_str = PyObject_CallFunctionObjArgs(json_dumps, final_response, NULL);
    if (!json_str) return NULL;

    // Import django.http
    PyObject* http_module = PyImport_ImportModule("django.http");
    if (!http_module) return NULL;

    // Create HttpResponse
    PyObject* http_response_class = PyObject_GetAttrString(http_module, "HttpResponse");
    if (!http_response_class) return NULL;

    // Create content_type dictionary
    PyObject* kwargs = PyDict_New();
    PyDict_SetItemString(kwargs, "content_type", PyUnicode_FromString("application/json"));

    // Create HttpResponse object
    PyObject* http_response = PyObject_Call(http_response_class, 
                                          PyTuple_Pack(1, json_str), 
                                          kwargs);

    // Cleanup
    PyMem_Free(receipt_id);
    Py_DECREF(trans_str);
    Py_DECREF(timezone_module);
    Py_DECREF(now_func);
    Py_DECREF(timestamp);
    Py_DECREF(final_response);
    Py_DECREF(json_module);
    Py_DECREF(json_dumps);
    Py_DECREF(json_str);
    Py_DECREF(http_module);
    Py_DECREF(http_response_class);
    Py_DECREF(kwargs);

    return http_response;
}

static PyMethodDef ResponseHandlerMethods[] = {
    {"prepare_and_share_response", prepare_and_share_response, METH_VARARGS,
     "Prepare and share response for Django views."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef response_handler_module = {
    PyModuleDef_HEAD_INIT,
    "response_handler",
    "A module for handling Django responses",
    -1,
    ResponseHandlerMethods
};

PyMODINIT_FUNC PyInit_response_handler(void) {
    PyDateTime_IMPORT;
    return PyModule_Create(&response_handler_module);
}