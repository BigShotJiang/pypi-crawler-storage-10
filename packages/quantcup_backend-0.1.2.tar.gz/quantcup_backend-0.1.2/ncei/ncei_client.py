from __future__ import annotations

import datetime as dt
from typing import Iterable, Optional, Dict, Any
import requests
import pandas as pd


BASE = "https://www.ncei.noaa.gov/access/services/data/v1"
SEARCH_BASE = "https://www.ncei.noaa.gov/access/services/search/v1"


class NCEIClient:
    """
    Thin wrapper for the NCEI Access Data Service (v1).
    Returns pandas DataFrames for common datasets useful in a forecasting context.
    """

    def __init__(self, session: Optional[requests.Session] = None, timeout: int = 60):
        self.s = session or requests.Session()
        self.timeout = timeout

    # -------- core request helper --------
    def _get(self, dataset: str, params: Dict[str, Any]) -> pd.DataFrame:
        qp = dict(params)
        qp["dataset"] = dataset
        qp.setdefault("format", "json")
        qp.setdefault("includeStationName", "true")
        qp.setdefault("includeStationLocation", "true")
        qp.setdefault("units", "standard")

        # Debug: log the actual request being made
        if dataset == "normals-daily":
            print(f"DEBUG: Normals API request URL: {BASE}")
            print(f"DEBUG: Normals API params: {qp}")

        r = self.s.get(BASE, params=qp, timeout=self.timeout)
        
        # Debug: log response details
        if dataset == "normals-daily":
            print(f"DEBUG: Response status: {r.status_code}")
            print(f"DEBUG: Response length: {len(r.text)}")
            print(f"DEBUG: Response preview: {r.text[:200]}...")
        
        try:
            r.raise_for_status()
        except requests.HTTPError as e:
            # Surface server message to help debugging (NCEI returns JSON/plain text on 400)
            msg = r.text.strip()
            raise requests.HTTPError(f"{e} | payload: {msg[:500]}") from None

        if not r.text.strip():
            return pd.DataFrame()
        return pd.read_json(r.text)

    # -------- daily summaries (observed) --------
    def daily_summaries(
        self,
        stations: Iterable[str],
        start_date: str | dt.date,
        end_date: str | dt.date,
        *,
        data_types: Iterable[str] = ("TMAX", "TMIN", "PRCP", "SNOW", "AWND"),
        units: str = "standard",
    ) -> pd.DataFrame:
        """
        GHCND DAILY SUMMARY observations. Useful for backfills and verifying model outputs.
        """
        sd = start_date if isinstance(start_date, str) else start_date.isoformat()
        ed = end_date if isinstance(end_date, str) else end_date.isoformat()

        params = {
            "stations": ",".join(stations),
            "startDate": sd,
            "endDate": ed,
            "dataTypes": ",".join(data_types),
            "units": units,
        }
        df = self._get("daily-summaries", params)
        # Optional: tidy common numeric columns
        for col in ("TMIN", "TMAX", "PRCP", "SNOW", "AWND"):
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        if "DATE" in df.columns:
            df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")
        return df

    # -------- Search Service v1 station discovery helper --------
    def _discover_normals_stations_by_bbox(
        self,
        lat: float,
        lon: float,
        *,
        max_expansions: int = 3,
        initial_deg: float = 0.2,
        limit: int = 50,
    ) -> list[str]:
        """
        Use NCEI Search Service v1 to discover stations with normals data in a geographic area.
        Returns a list of GHCND station IDs (e.g., ['GHCND:USC00311923', ...]).
        Progressively expands search radius until stations are found.
        No token required.
        """
        import math
        
        deg = initial_deg
        for expansion in range(max_expansions):
            # Search Service wants bbox as N,W,S,E
            bbox = f"{lat + deg},{lon - deg},{lat - deg},{lon + deg}"
            
            # Search specifically in the normals-daily dataset
            params = {
                "dataset": "normals-daily",
                "bbox": bbox,
                "startDate": "1991-01-01",  # Normals period
                "endDate": "2020-12-31",
                "limit": str(limit)
            }
            
            try:
                r = self.s.get(f"{SEARCH_BASE}/data", params=params, timeout=self.timeout)
                r.raise_for_status()
                data = r.json()
                results = data.get("results", []) or []
                
                print(f"DEBUG: Normals search expansion {expansion + 1}, bbox deg={deg:.2f}, found {len(results)} results")
                
                # Extract station identifiers correctly from the Search API response
                stations = []
                for row in results:
                    if "stations" in row and isinstance(row["stations"], list):
                        for st in row["stations"]:
                            sid = None
                            if isinstance(st, dict) and "id" in st and isinstance(st["id"], str):
                                sid = st["id"].strip()
                            elif isinstance(st, str):
                                sid = st.strip()

                            if sid:
                                # More permissive validation for station IDs
                                import re
                                if re.match(r'^[A-Z]{2,4}\d{6,8}$', sid):
                                    stations.append(sid)
                
                # De-dup and normalize
                normalized = []
                seen = set()
                for s in stations:
                    s = str(s).strip()
                    if not s:
                        continue
                    if s not in seen:
                        seen.add(s)
                        normalized.append(s)
                
                # Prefer COOP/USC stations (best normals coverage)
                usc = [s for s in normalized if s.startswith("USC")]
                other = [s for s in normalized if not s.startswith("USC")]
                candidates = usc + other
                
                if candidates:
                    print(f"DEBUG: Found {len(candidates)} normals stations: {candidates[:5]}...")
                    return candidates
                
                # Expand search radius and try again
                deg *= 1.8
                
            except Exception as e:
                print(f"DEBUG: Search expansion {expansion + 1} failed: {e}")
                deg *= 1.8
                continue
        
        print("DEBUG: No normals stations found after all expansions")
        return []

    # -------- normals (climatology) for daily values --------
    def normals_daily(
        self,
        stations: Iterable[str] | None = None,
        *,
        data_types: Iterable[str] = (
            "DLY-TMAX-NORMAL",
            "DLY-TMIN-NORMAL",
            "DLY-PRCP-NORMAL",
        ),
        units: str = "standard",
        start_date: str = "2000-01-01",
        end_date: str   = "2000-12-31",
    ) -> pd.DataFrame:
        """
        Daily climatology normals (e.g., 1991–2020). Some datasets require:
          - GHCND namespace on station ids (e.g., 'GHCND:USW00013881')
          - a start/end date window (any full-year range works)
        """
        params = {
            "dataTypes": ",".join(data_types),
            "units": units,
            "startDate": start_date,
            "endDate": end_date,
        }
        if stations:
            def _ghcnd(s: str) -> str:
                s = s.strip()
                return s if s.startswith("GHCND:") else f"GHCND:{s}"
            params["stations"] = ",".join(_ghcnd(s) for s in stations)
        else:
            return pd.DataFrame()

        df = self._get("normals-daily", params)

        if "DATE" in df.columns:
            # Normals daily usually returns YYYY-MM-DD (year may be a placeholder)
            df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")
            df["DOY"] = df["DATE"].dt.dayofyear

        for col in data_types:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        return df

    # ---- helper: find a normals-capable station near a point ----
    def find_normals_station_near(
        self, 
        lat: float, 
        lon: float, 
        *, 
        box_km: float = 25.0
    ) -> Optional[str]:
        """
        Find a nearby station that HAS normals using Search Service v1 for discovery.
        Prefers COOP/USC stations which typically have better normals coverage.
        Returns a 'GHCND:*' id or None.
        
        Args:
            lat: Latitude of search center
            lon: Longitude of search center  
            box_km: Search radius in kilometers
        """
        # Use Search Service v1 to discover normals stations directly
        candidates = self._discover_normals_stations_by_bbox(lat, lon)
        
        if not candidates:
            return None
            
        # Test each candidate to ensure it actually has normals data
        for station_id in candidates:
            print(f"DEBUG: Testing normals for station: {station_id}")
            df = self.normals_daily([station_id])
            if df is not None and not df.empty:
                # Add GHCND prefix if not present
                ghcnd_id = station_id if station_id.startswith("GHCND:") else f"GHCND:{station_id}"
                print(f"DEBUG: Found working normals station: {ghcnd_id}")
                return ghcnd_id
                
        return None

    # -------- hourly observations (for wind/pressure features) --------
    def global_hourly(
        self,
        stations: Iterable[str],
        start_datetime: str | dt.datetime,
        end_datetime: str | dt.datetime,
        *,
        data_types: Iterable[str] = ("TMP", "WND", "PRES", "AA1"),  # temp, wind, pressure, precip obs
        units: str = "standard",
    ) -> pd.DataFrame:
        """
        Hourly observations from the 'global-hourly' dataset (formerly ISD).
        Good for detailed wind features or matching past kickoff hours.
        """
        sd = (
            start_datetime
            if isinstance(start_datetime, str)
            else start_datetime.isoformat()
        )
        ed = end_datetime if isinstance(end_datetime, str) else end_datetime.isoformat()

        params = {
            "stations": ",".join(stations),
            "startDate": sd,
            "endDate": ed,
            "dataTypes": ",".join(data_types),
            "units": units,
        }
        df = self._get("global-hourly", params)
        if "DATE" in df.columns:
            df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce", utc=True)
        # A few helpful parses
        # TMP, WND often encoded strings (e.g., "018.0,1") depending on sub-code; keep as string or parse as needed here.
        return df

    # -------- convenience: get “expected” (climo) for a target date --------
    def normals_for_date(
        self,
        station: str,
        target_date: str | dt.date,
        *,
        cache_normals: Optional[pd.DataFrame] = None,
    ) -> pd.Series | None:
        """
        Returns a one-row Series with climatological 'expected' values for a station on the given calendar date.
        Use this in your pipeline as a pre-forecast fallback (e.g., >7 days out).
        """
        date = target_date if isinstance(target_date, str) else target_date.isoformat()
        date = pd.to_datetime(date, errors="coerce")
        if pd.isna(date):
            return None
        doy = int(date.strftime("%j"))

        if cache_normals is None:
            normals = self.normals_daily([station])
        else:
            normals = cache_normals
        if normals is None or normals.empty or "STATION" not in normals.columns:
            return None
        def _core_id(s: str) -> str:
            return str(s).replace("GHCND:", "")
        core = _core_id(station)
        st = normals[normals["STATION"].map(lambda x: _core_id(x) == core)].copy()
        if st.empty or "DOY" not in st.columns:
            return None
        row = st.loc[st["DOY"] == doy]
        if row.empty:
            return None
        # return first match as a neat Series with friendlier names
        r = row.iloc[0]
        out = pd.Series(
            {
                "station": station,
                "name": r.get("NAME"),
                "lat": r.get("LATITUDE"),
                "lon": r.get("LONGITUDE"),
                "elev_m": r.get("ELEVATION"),
                "date": date.date(),
                "tmax_normal": r.get("DLY-TMAX-NORMAL"),
                "tmin_normal": r.get("DLY-TMIN-NORMAL"),
                "prcp_normal": r.get("DLY-PRCP-NORMAL"),
            }
        )
        return out


# -------------------------
# Example usage (commented)
# -------------------------
if __name__ == "__main__":
    STATION = "USW00013881"   # Charlotte Douglas
    client = NCEIClient()

    # 1) Observations
    obs = client.daily_summaries([STATION], "2025-08-01", "2025-08-19")
    print(obs.head())

    # 2) Normals: airport may be empty → auto-discover nearby normals station
    normals = client.normals_daily([STATION])
    ghcnd_near = None
    if normals.empty:
        # use airport lat/lon from your obs frame if present
        lat = float(obs.get("LATITUDE", pd.Series([None])).iloc[0]) if not obs.empty else 35.2225
        lon = float(obs.get("LONGITUDE", pd.Series([None])).iloc[0]) if not obs.empty else -80.9543
        
        # Use Search Service v1 to discover nearby normals stations (no token required)
        ghcnd_near = client.find_normals_station_near(lat, lon)
        print("Nearest normals-capable station:", ghcnd_near)
        if ghcnd_near:
            normals = client.normals_daily([ghcnd_near.replace("GHCND:", "")])
    print(normals.head())

    # 3) Hourly observations for a training window (wind features, etc.)
    hourly = client.global_hourly(
        stations=[STATION],
        start_datetime="2025-08-01T00:00:00Z",
        end_datetime="2025-08-05T00:00:00Z",
    )
    print(hourly.head())

    # 4) Get "expected" values for a future game date (climatology fallback)
    prefer_station = (
        ghcnd_near.replace("GHCND:", "") if ghcnd_near else STATION
    )
    expected = client.normals_for_date(prefer_station, "2025-09-07", cache_normals=normals)
    print(expected)
