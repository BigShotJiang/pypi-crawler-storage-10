# parse_normals.py
import re
import sys
import pandas as pd
from pathlib import Path

# -------- helpers --------

STAT_KEYS = {
    "NORMAL": "normal",
    "10PCTL": "p10",
    "25PCTL": "p25",
    "50PCTL": "p50",
    "75PCTL": "p75",
    "90PCTL": "p90",
    "STDDEV": "stddev",
    "HIGH": "high",
    "LOW": "low",
    "PRB10": "prb10",
    "PRB90": "prb90",
}

ELEMENT_LABEL = {
    "TMAX": "tmax",
    "TMIN": "tmin",
    "TAVG": "tavg",
    "PRCP": "prcp",
    "SNOW": "snow",
    "SNWD": "snwd",
    "TOBS": "tobs",
}

PATTERN = re.compile(
    r"^(?:DLY|MLY)[\-_]([A-Z0-9]+)[\-_]([A-Z0-9]+)$"  # e.g. DLY-TMAX-NORMAL
)

def parse_column(col: str):
    """Return (element, stat) if the column looks like a normals/stat column; else None."""
    m = PATTERN.match(col.strip().upper())
    if not m:
        return None
    el_raw, stat_raw = m.groups()
    el = ELEMENT_LABEL.get(el_raw, el_raw.lower())
    stat = STAT_KEYS.get(stat_raw, stat_raw.lower())
    return el, stat

def group_columns(columns):
    """Split columns into (meta, mapped, unknown)."""
    meta = []
    mapped = {}  # (element, stat) -> original column name
    unknown = []
    for c in columns:
        if c.upper() in {"DATE", "STATION", "STATION_ID", "NAME", "LATITUDE", "LONGITUDE", "ELEVATION"}:
            meta.append(c)
            continue
        parsed = parse_column(c)
        if parsed:
            mapped[parsed] = c
        else:
            unknown.append(c)
    return meta, mapped, unknown

def melt_stats(df, mapped):
    """
    Build a long/tidy frame: one row per DATE x element with columns:
    element, normal, p10, p25, p50, p75, p90, stddev, high, low, etc.
    """
    # Build a nested dict: element -> stat -> column
    by_element = {}
    for (el, stat), col in mapped.items():
        by_element.setdefault(el, {})[stat] = col

    out = []
    for el, statmap in by_element.items():
        subset_cols = ["DATE"] + list(statmap.values())
        sub = df[subset_cols].copy()
        # rename stat columns to friendly names
        rename_map = {orig: stat for stat, orig in {k: v for k, v in statmap.items()}.items()}
        sub = sub.rename(columns=rename_map)
        sub.insert(1, "element", el)  # keep element as a column
        out.append(sub)

    if not out:
        return pd.DataFrame()

    # union of all possible stat columns
    all_cols = set(["DATE", "element"])
    for frag in out:
        all_cols |= set(frag.columns)

    # align and concat
    out = [frag.reindex(columns=sorted(all_cols)) for frag in out]
    long_df = pd.concat(out, ignore_index=True).sort_values(["element", "DATE"])
    return long_df

# -------- main build --------

def _check_duplicates(df, section_name):
    """Optional sanity check to detect duplicate (DATE, element) pairs for debugging."""
    dupes = df.duplicated(subset=["DATE", "element"], keep=False)
    if dupes.any():
        print(f"DEBUG: Found duplicate (DATE, element) rows in {section_name}:")
        print(df.loc[dupes].head(10))
        return True
    return False

def build_views(df):
    meta, mapped, unknown = group_columns(df.columns)

    # Tidy: one row per DATE x element with all stats in columns
    tidy = melt_stats(df, mapped)

    # Core normals table
    core_cols = ["DATE", "tmax", "tmin", "tavg", "prcp"]
    core = pd.DataFrame()
    if not tidy.empty:
        # pivot normal only
        normals = tidy[["DATE", "element", "normal"]].dropna()
        
        # 1) remove exact duplicates on (DATE, element)
        before = len(normals)
        normals = normals.drop_duplicates(subset=["DATE", "element"], keep="last")
        after = len(normals)
        if after != before:
            print(f"DEBUG: dropped {before - after} duplicate (DATE, element) rows in core normals")
        
        # 2) pivot with aggregation (first) to avoid ValueError on any remaining dupes
        core = (
            normals.pivot_table(index="DATE", columns="element", values="normal", aggfunc="first")
                   .reset_index()
        )
        
        # add precip if present
        for need in ["tmax", "tmin", "tavg", "prcp"]:
            if need not in core.columns:
                core[need] = pd.NA
        core = core[core_cols]

    # Percentiles view (wide per element)
    pct_wide = pd.DataFrame()
    if not tidy.empty:
        keep = ["DATE", "element", "p10", "p25", "p50", "p75", "p90"]
        pct = tidy[[c for c in keep if c in tidy.columns]].copy()
        if not pct.empty:
            # 1) remove exact duplicates on (DATE, element)
            before = len(pct)
            pct = pct.drop_duplicates(subset=["DATE", "element"], keep="last")
            after = len(pct)
            if after != before:
                print(f"DEBUG: dropped {before - after} duplicate (DATE, element) rows in percentiles")
            
            # 2) pivot with aggregation (first) to avoid ValueError on any remaining dupes
            pct_wide = (
                pct.pivot_table(index="DATE", columns="element", aggfunc="first")
                   .sort_index()
                   .reset_index()
            )
            # flatten MultiIndex columns
            pct_wide.columns = ["{}_{}".format(a, b) for a, b in pct_wide.columns]

    # Stddev/extremes view
    spread_cols = ["stddev", "high", "low"]
    spread = pd.DataFrame()
    if not tidy.empty and any(c in tidy.columns for c in spread_cols):
        cols = ["DATE", "element"] + [c for c in spread_cols if c in tidy.columns]
        sp = tidy[cols].copy()
        
        # 1) remove exact duplicates on (DATE, element)
        before = len(sp)
        sp = sp.drop_duplicates(subset=["DATE", "element"], keep="last")
        after = len(sp)
        if after != before:
            print(f"DEBUG: dropped {before - after} duplicate (DATE, element) rows in spread/extremes")
        
        # 2) pivot with aggregation (first) to avoid ValueError on any remaining dupes
        spread = (
            sp.pivot_table(index="DATE", columns="element", aggfunc="first")
              .sort_index()
              .reset_index()
        )
        spread.columns = ["{}_{}".format(a, b) for a, b in spread.columns]

    groups = {
        "meta_cols": meta,
        "unknown_cols": unknown,
        "tidy": tidy,
        "core_normals": core,
        "percentiles_wide": pct_wide,
        "spread_extremes": spread,
    }
    return groups

def read_normals_csv(path):
    # many NCEI normals CSVs have uppercase headers; keep them as-is
    df = pd.read_csv(path)
    # Normalize DATE to datetime (leave year as-is; normals files often use year 2000)
    if "DATE" in df.columns:
        df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")
    return df

def main():
    if len(sys.argv) < 2:
        print("Usage: python parse_normals.py /path/to/USW00013881.csv")
        sys.exit(1)

    path = Path(sys.argv[1])
    df = read_normals_csv(path)
    views = build_views(df)

    print("\n=== Meta columns ===")
    print(views["meta_cols"])

    print("\n=== Unknown/raw columns (didn't match DLY-*-* pattern) ===")
    print(views["unknown_cols"][:20])  # show a sample

    print("\n=== CORE NORMALS (DATE, tmax, tmin, tavg, prcp) ===")
    print(views["core_normals"].head(10))

    print("\n=== PERCENTILES (wide; columns like p50_tmax, p90_prcp, etc.) ===")
    print(views["percentiles_wide"].head(10))

    print("\n=== SPREAD/EXTREMES (stddev/high/low, wide) ===")
    print(views["spread_extremes"].head(10))

    # If you want to save:
    outdir = path.parent / "parsed_normals_out"
    outdir.mkdir(parents=True, exist_ok=True)
    views["core_normals"].to_csv(outdir / "core_normals.csv", index=False)
    views["percentiles_wide"].to_csv(outdir / "percentiles_wide.csv", index=False)
    views["spread_extremes"].to_csv(outdir / "spread_extremes.csv", index=False)

if __name__ == "__main__":
    main()
