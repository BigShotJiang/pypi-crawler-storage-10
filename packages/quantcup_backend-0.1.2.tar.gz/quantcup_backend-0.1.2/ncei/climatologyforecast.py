import pandas as pd
from datetime import datetime

# Load your distilled CSVs
temperature = pd.read_csv("distilled/temperature.csv")
precipitation = pd.read_csv("distilled/precipitation.csv")
snow = pd.read_csv("distilled/snow.csv")

# Ensure DATE column is parsed consistently
for df in [temperature, precipitation, snow]:
    if not pd.api.types.is_datetime64_any_dtype(df["DATE"]):
        df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")

def climatology_forecast(date_str, temperature, precipitation, snow):
    """
    Return a baseline climatology forecast for a given date (MM-DD or YYYY-MM-DD).
    Uses NOAA Daily Normals (1991–2020) distilled datasets.
    """
    # Normalize input date to match "day-of-year"
    date = pd.to_datetime(date_str)
    doy = date.dayofyear
    
    # Handle leap year alignment: use Feb 28 data for Feb 29
    if doy == 60 and len(temperature[temperature["DOY"] == 60]) == 0:
        doy = 59

    # Look up rows
    t_row = temperature.loc[temperature["DOY"] == doy].iloc[0]
    p_row = precipitation.loc[precipitation["DOY"] == doy].iloc[0]
    s_row = snow.loc[snow["DOY"] == doy].iloc[0]

    forecast = {
        "date": date.strftime("%Y-%m-%d"),
        # 🌡 Temperature
        "high_temp": f"{t_row['DLY-TMAX-NORMAL']:.1f}°F ±{t_row['DLY-TMAX-STDDEV']:.1f}",
        "low_temp": f"{t_row['DLY-TMIN-NORMAL']:.1f}°F ±{t_row['DLY-TMIN-STDDEV']:.1f}",
        # 🌧 Rain
        "rain_chance": f"{p_row['DLY-PRCP-PCTALL-GE001HI']:.0f}%",  # probability of ≥0.01"
        "rain_median_if_wet": f"{p_row['DLY-PRCP-50PCTL']:.2f}\"",
        "rain_daily_normal": f"{p_row['DLY-PRCP-NORMAL']:.2f}\"",
        # ❄️ Snow
        "snow_chance": f"{s_row['DLY-SNOW-PCTALL-GE001TI']:.0f}%",
        "snow_median_if_snow": f"{s_row['DLY-SNOW-50PCTL']:.2f}\"",
    }

    return forecast

# --- Example usage ---
print(climatology_forecast("2025-01-15", temperature, precipitation, snow))
print(climatology_forecast("2025-07-10", temperature, precipitation, snow))
