#!/usr/bin/env python3
"""
noaa_normals_distill.py
Distill NOAA Daily Climate Normals (1991–2020) into focused DataFrames for:
- Temperature (TMAX/TMIN/TAVG/DUTR + STDDEV)
- Degree Days (HTDD/CLDD/GRDD, incl. bases)
- Precipitation (probs, percentiles, MTD/YTD; derive daily PRCP normal)
- Snow (SNOW probabilities/percentiles; SNWD probabilities; MTD/YTD)

Outputs: one file per category (wide) + optional "long/tidy" versions.
"""

import argparse
import re
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd


# ------------------------------- helpers ------------------------------------ #

def _coalesce_date_columns(df: pd.DataFrame) -> pd.Series:
    """
    Make a single DATE column as pandas datetime and add useful keys.
    Accepts either 'DATE' like 'MM-DD' (common in normals) or 'YYYY-MM-DD'.
    We pin to a dummy leap year (e.g., 2000) so Feb-29 is valid.
    """
    if "DATE" in df.columns:
        raw = df["DATE"].astype(str)
        # Try YYYY-MM-DD
        if raw.str.match(r"\d{4}-\d{2}-\d{2}$").all():
            dt = pd.to_datetime(raw, errors="coerce")
        else:
            # Assume MM-DD; prepend 2000-
            dt = pd.to_datetime("2000-" + raw.str.replace("^", "", regex=True), errors="coerce")
    else:
        # Try to infer from known columns (rare)
        raise ValueError("No DATE column found. Expected a 'DATE' field in normals CSV.")

    if dt.isna().any():
        bad = df.loc[dt.isna(), :].head(3)
        raise ValueError(f"Could not parse some DATE values. Examples:\n{bad}")

    return dt


def _add_calendar_keys(df: pd.DataFrame) -> pd.DataFrame:
    """Add day-of-year (1–366), month, and day to DF (does not drop originals)."""
    dt = _coalesce_date_columns(df)
    df = df.copy()
    df["__DATE"] = dt
    df["DOY"] = df["__DATE"].dt.dayofyear  # 1..366
    df["MONTH"] = df["__DATE"].dt.month
    df["DAY"] = df["__DATE"].dt.day
    return df


def _grep_columns(cols: List[str], patterns: List[str]) -> List[str]:
    """Regex OR-match columns against a list of patterns; case-insensitive."""
    rx = re.compile("|".join(patterns), flags=re.IGNORECASE)
    return [c for c in cols if rx.search(c)]


def _save(df: pd.DataFrame, outpath: Path, fmt: str = "csv") -> None:
    outpath.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "csv":
        df.to_csv(outpath, index=False)
    elif fmt == "parquet":
        df.to_parquet(outpath, index=False)
    else:
        raise ValueError("format must be 'csv' or 'parquet'")


def _make_long(df: pd.DataFrame, id_vars: List[str]) -> pd.DataFrame:
    """Wide → long/tidy; keeps id_vars and melts everything else."""
    value_vars = [c for c in df.columns if c not in id_vars]
    return df.melt(id_vars=id_vars, value_vars=value_vars, var_name="variable", value_name="value")


# --------------------------- category builders ------------------------------- #

def build_temperature(df: pd.DataFrame) -> pd.DataFrame:
    """
    Temperature normals & variability:
      - TMAX/TMIN/TAVG normals + STDDEV
      - DUTR (diurnal range) if present
    """
    cols = df.columns.tolist()
    keep = _grep_columns(cols, [
        r"\bTMAX\b", r"\bTMIN\b", r"\bTAVG\b", r"\bDUTR\b", r"STDDEV"
    ])
    base = ["DATE", "DOY", "MONTH", "DAY"]
    uniq = base + sorted(set(keep))
    return df.loc[:, [c for c in uniq if c in df.columns]]


def build_degree_days(df: pd.DataFrame) -> pd.DataFrame:
    """
    Degree days:
      - HTDD (heating), CLDD (cooling), GRDD (growing) — across bases
    """
    cols = df.columns.tolist()
    keep = _grep_columns(cols, [r"\bHTDD\b", r"\bCLDD\b", r"\bGRDD\b"])
    base = ["DATE", "DOY", "MONTH", "DAY"]
    uniq = base + sorted(set(keep))
    return df.loc[:, [c for c in uniq if c in df.columns]]


def _derive_daily_prcp_from_ytd(df: pd.DataFrame) -> pd.Series:
    """
    Derive a 'DLY-PRCP-NORMAL' by differencing YTD-PRCP-NORMAL.
    Falls back gracefully if the YTD column is missing.
    """
    ytd_col = next((c for c in df.columns if re.search(r"^YTD-PRCP-NORMAL$", c, re.I)), None)
    if not ytd_col:
        return pd.Series([pd.NA] * len(df), name="DLY-PRCP-NORMAL")
    dly = df[ytd_col].astype(float).diff()
    # First row: assume equal to YTD on that day
    dly.iloc[0] = df[ytd_col].iloc[0]
    return dly.rename("DLY-PRCP-NORMAL")


def build_precip(df: pd.DataFrame) -> pd.DataFrame:
    """
    Precipitation stats:
      - Probability columns: DLY-PRCP-PCTALL-GE***HI
      - Percentiles on wet days: DLY-PRCP-25PCTL / 50PCTL / 75PCTL
      - MTD-PRCP-NORMAL, YTD-PRCP-NORMAL
      - Derived DLY-PRCP-NORMAL from YTD differencing
    """
    cols = df.columns.tolist()
    keep = _grep_columns(cols, [
        r"\bPRCP\b", r"PCTALL", r"PCTL", r"\bMTD-PRCP-NORMAL\b", r"\bYTD-PRCP-NORMAL\b"
    ])
    base = ["DATE", "DOY", "MONTH", "DAY"]
    uniq = base + sorted(set(keep))
    out = df.loc[:, [c for c in uniq if c in df.columns]].copy()
    # Add derived daily normal precip
    out["DLY-PRCP-NORMAL"] = _derive_daily_prcp_from_ytd(out)
    return out


def build_snow(df: pd.DataFrame) -> pd.DataFrame:
    """
    Snowfall & snow depth:
      - SNOW probabilities/percentiles, MTD/YTD snowfall normals
      - SNWD (snow depth) presence probabilities
    """
    cols = df.columns.tolist()
    keep = _grep_columns(cols, [r"\bSNOW\b", r"\bSNWD\b"])
    base = ["DATE", "DOY", "MONTH", "DAY"]
    uniq = base + sorted(set(keep))
    return df.loc[:, [c for c in uniq if c in df.columns]]


# ----------------------------------- main ----------------------------------- #

def main():
    ap = argparse.ArgumentParser(description="Distill NOAA Daily Normals CSV into focused DataFrames.")
    ap.add_argument("--in", dest="infile", required=True, help="Path to NOAA Daily Normals CSV (e.g., USW00013881.csv)")
    ap.add_argument("--outdir", required=True, help="Output directory for distilled files")
    ap.add_argument("--format", choices=["csv", "parquet"], default="csv", help="Output format")
    ap.add_argument("--make-long", action="store_true", help="Also write tidy/long versions for each category")
    args = ap.parse_args()

    infile = Path(args.infile)
    outdir = Path(args.outdir)
    fmt = args.format

    # Load
    df = pd.read_csv(infile)
    # Add calendar keys
    df = _add_calendar_keys(df)

    # Build categories
    products: Dict[str, pd.DataFrame] = {
        "temperature": build_temperature(df),
        "degree_days": build_degree_days(df),
        "precipitation": build_precip(df),
        "snow": build_snow(df),
    }

    # Save wide tables
    for name, dfx in products.items():
        _save(dfx, outdir / f"{name}.{fmt}", fmt=fmt)

    # Optionally save long/tidy versions
    if args.make_long:
        id_vars_common = ["DATE", "DOY", "MONTH", "DAY"]
        for name, dfx in products.items():
            long_df = _make_long(dfx, id_vars=id_vars_common)
            _save(long_df, outdir / f"{name}_long.{fmt}", fmt=fmt)

    # Summary printout
    print("\n== Distillation complete ==")
    for name, dfx in products.items():
        print(f"{name:14s}: {dfx.shape[0]} rows x {dfx.shape[1]} cols → {outdir/(name + '.' + fmt)}")
        if args.make_long:
            print(f"{name+'_long':14s}: tidy version written")


if __name__ == "__main__":
    main()
