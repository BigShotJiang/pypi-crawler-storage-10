#!/usr/bin/env python3
"""
Comprehensive Data Exploration Script for Multi-Source Data Analysis

This script provides comprehensive data exploration capabilities across multiple data sources
including SQL databases, NoSQL databases, cloud storage buckets, and file-based systems.
It automatically detects connection types, establishes secure connections, and provides
robust querying and analysis capabilities.

Features:
- Multi-database connection management (PostgreSQL, MySQL, SQLite, etc.)
- Cloud storage integration (S3, Azure Blob, GCS)
- NoSQL database support (MongoDB, Redis)
- Automatic schema discovery and analysis
- Data profiling and quality assessment
- Query execution with timeout and error handling
- Export capabilities (JSON, CSV, Excel, reports)
- Metadata extraction and lineage tracking
- Memory-efficient processing for large datasets
- Comprehensive logging and monitoring

Usage:
    python data_explorer.py --config config.json
    python data_explorer.py --discover-all
    python data_explorer.py --profile-table users --database main_db
    python data_explorer.py --query "SELECT * FROM users LIMIT 100" --export csv
"""

import os
import sys
import json
import csv
import logging
import argparse
import traceback
import warnings
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field, asdict
from contextlib import contextmanager
from pathlib import Path
import time
import hashlib
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import signal

# Core data processing
import pandas as pd
import numpy as np

# Database connections
import sqlalchemy as sa
from sqlalchemy import create_engine, text, MetaData, Table, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

# Cloud storage
try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

# NoSQL databases
try:
    import pymongo
    from pymongo import MongoClient
    PYMONGO_AVAILABLE = True
except ImportError:
    PYMONGO_AVAILABLE = False

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

# Additional utilities
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Import existing infrastructure if available
try:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from commonv2._data.database import create_db_engine_from_env
    from commonv2._data.adapters import DatabaseAdapter, DataCleaningService
    from commonv2._data.schema_detector import SchemaDetector
    from commonv2.core.config import DatabasePrefixes
    from commonv2.core.logging import get_logger
    EXISTING_INFRA_AVAILABLE = True
except ImportError:
    EXISTING_INFRA_AVAILABLE = False

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)


@dataclass
class ConnectionConfig:
    """Configuration for a data source connection."""
    name: str
    type: str  # 'postgresql', 'mysql', 'sqlite', 's3', 'mongodb', 'redis', 'file'
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    connection_string: Optional[str] = None
    additional_params: Dict[str, Any] = field(default_factory=dict)
    timeout: int = 30
    max_retries: int = 3
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, masking sensitive information."""
        result = asdict(self)
        if result.get('password'):
            result['password'] = '****'
        if result.get('connection_string') and 'password' in result['connection_string'].lower():
            # Mask password in connection string
            conn_str = result['connection_string']
            if '://' in conn_str and '@' in conn_str:
                parts = conn_str.split('://')
                if len(parts) == 2:
                    protocol = parts[0]
                    rest = parts[1]
                    if '@' in rest:
                        auth_part, host_part = rest.split('@', 1)
                        if ':' in auth_part:
                            user, _ = auth_part.split(':', 1)
                            result['connection_string'] = f"{protocol}://{user}:****@{host_part}"
        return result


@dataclass
class TableInfo:
    """Information about a database table or collection."""
    name: str
    schema: Optional[str] = None
    type: str = 'table'  # 'table', 'view', 'collection', 'file'
    row_count: Optional[int] = None
    size_bytes: Optional[int] = None
    columns: List[Dict[str, Any]] = field(default_factory=list)
    indexes: List[Dict[str, Any]] = field(default_factory=list)
    constraints: List[Dict[str, Any]] = field(default_factory=list)
    last_modified: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataProfile:
    """Data profiling results for a table or dataset."""
    table_name: str
    total_rows: int
    total_columns: int
    null_percentages: Dict[str, float] = field(default_factory=dict)
    unique_counts: Dict[str, int] = field(default_factory=dict)
    data_types: Dict[str, str] = field(default_factory=dict)
    min_values: Dict[str, Any] = field(default_factory=dict)
    max_values: Dict[str, Any] = field(default_factory=dict)
    mean_values: Dict[str, float] = field(default_factory=dict)
    std_values: Dict[str, float] = field(default_factory=dict)
    sample_data: Optional[pd.DataFrame] = None
    quality_issues: List[str] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)


class DataExplorer:
    """
    Comprehensive data exploration tool for multiple data sources.
    
    This class provides a unified interface for connecting to and exploring
    various types of data sources including SQL databases, NoSQL databases,
    cloud storage, and file systems.
    """
    
    def __init__(self, config_file: Optional[str] = None, log_level: str = 'INFO'):
        """
        Initialize the DataExplorer.
        
        Args:
            config_file: Path to configuration file
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        """
        self.connections: Dict[str, Any] = {}
        self.connection_configs: Dict[str, ConnectionConfig] = {}
        self.discovered_sources: Dict[str, List[TableInfo]] = {}
        self.profiles: Dict[str, DataProfile] = {}
        
        # Setup logging
        self.logger = self._setup_logging(log_level)
        
        # Load configuration
        if config_file and os.path.exists(config_file):
            self.load_config(config_file)
        else:
            self.logger.info("No config file provided, will use environment variables and auto-discovery")
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.logger.info("DataExplorer initialized successfully")
    
    def _setup_logging(self, log_level: str) -> logging.Logger:
        """Setup comprehensive logging."""
        # Use existing logger if available
        if EXISTING_INFRA_AVAILABLE:
            return get_logger('data_explorer')
        
        # Create custom logger
        logger = logging.getLogger('data_explorer')
        logger.setLevel(getattr(logging, log_level.upper()))
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # File handler
        log_dir = Path('logs')
        log_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = log_dir / f'data_explorer_{timestamp}.log'
        
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        return logger
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully."""
        self.logger.info(f"Received signal {signum}, shutting down gracefully...")
        self.close_all_connections()
        sys.exit(0)
    
    def load_config(self, config_file: str):
        """
        Load configuration from JSON file.
        
        Args:
            config_file: Path to configuration file
        """
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            # Load connection configurations
            for conn_config in config.get('connections', []):
                connection = ConnectionConfig(**conn_config)
                self.connection_configs[connection.name] = connection
            
            self.logger.info(f"Loaded configuration for {len(self.connection_configs)} connections")
            
        except Exception as e:
            self.logger.error(f"Failed to load config file {config_file}: {e}")
            raise
    
    def auto_discover_connections(self) -> Dict[str, ConnectionConfig]:
        """
        Automatically discover available data sources from environment variables.
        
        Returns:
            Dictionary of discovered connection configurations
        """
        self.logger.info("Auto-discovering data source connections...")
        discovered = {}
        
        # Check for existing infrastructure connections
        if EXISTING_INFRA_AVAILABLE:
            try:
                # Import the proper config class
                from commonv2.core.config import DatabaseConfig
                
                # Try to discover known database prefixes
                for prefix in DatabasePrefixes.get_all():
                    try:
                        # Use the proper config method to get database configuration
                        db_config = DatabaseConfig._from_env_internal(prefix)
                        
                        config = ConnectionConfig(
                            name=prefix.lower(),
                            type='postgresql',
                            host=db_config.host,
                            port=db_config.port,
                            database=db_config.database,
                            username=db_config.user,
                            password=db_config.password
                        )
                        discovered[config.name] = config
                        self.logger.info(f"Discovered existing infrastructure connection: {config.name}")
                    except Exception as e:
                        self.logger.debug(f"Could not get config for {prefix}: {e}")
            except Exception as e:
                self.logger.debug(f"Error discovering existing infrastructure: {e}")
        
        # Discover PostgreSQL connections
        pg_patterns = [
            ('POSTGRES_', 'postgresql'),
            ('POSTGRESQL_', 'postgresql'),
            ('PG_', 'postgresql'),
            ('DATABASE_', 'postgresql'),
            ('DB_', 'postgresql')
        ]
        
        for prefix, db_type in pg_patterns:
            host = os.getenv(f'{prefix}HOST') or os.getenv(f'{prefix}HOSTNAME')
            if host:
                config = ConnectionConfig(
                    name=f"{prefix.lower().rstrip('_')}_auto",
                    type=db_type,
                    host=host,
                    port=int(os.getenv(f'{prefix}PORT', 5432)),
                    database=os.getenv(f'{prefix}DATABASE') or os.getenv(f'{prefix}DB') or os.getenv(f'{prefix}NAME'),
                    username=os.getenv(f'{prefix}USER') or os.getenv(f'{prefix}USERNAME'),
                    password=os.getenv(f'{prefix}PASSWORD') or os.getenv(f'{prefix}PASS')
                )
                if config.database and config.username and config.password:
                    discovered[config.name] = config
                    self.logger.info(f"Auto-discovered {db_type} connection: {config.name}")
        
        # Discover MySQL connections
        mysql_patterns = [
            ('MYSQL_', 'mysql'),
            ('MARIADB_', 'mysql')
        ]
        
        for prefix, db_type in mysql_patterns:
            host = os.getenv(f'{prefix}HOST') or os.getenv(f'{prefix}HOSTNAME')
            if host:
                config = ConnectionConfig(
                    name=f"{prefix.lower().rstrip('_')}_auto",
                    type=db_type,
                    host=host,
                    port=int(os.getenv(f'{prefix}PORT', 3306)),
                    database=os.getenv(f'{prefix}DATABASE') or os.getenv(f'{prefix}DB'),
                    username=os.getenv(f'{prefix}USER') or os.getenv(f'{prefix}USERNAME'),
                    password=os.getenv(f'{prefix}PASSWORD') or os.getenv(f'{prefix}PASS')
                )
                if config.database and config.username and config.password:
                    discovered[config.name] = config
                    self.logger.info(f"Auto-discovered {db_type} connection: {config.name}")
        
        # Discover MongoDB connections
        if PYMONGO_AVAILABLE:
            mongo_uri = os.getenv('MONGODB_URI') or os.getenv('MONGO_URI')
            if mongo_uri:
                config = ConnectionConfig(
                    name='mongodb_auto',
                    type='mongodb',
                    connection_string=mongo_uri
                )
                discovered[config.name] = config
                self.logger.info("Auto-discovered MongoDB connection")
        
        # Discover Redis connections
        if REDIS_AVAILABLE:
            redis_host = os.getenv('REDIS_HOST')
            if redis_host:
                config = ConnectionConfig(
                    name='redis_auto',
                    type='redis',
                    host=redis_host,
                    port=int(os.getenv('REDIS_PORT', 6379)),
                    password=os.getenv('REDIS_PASSWORD')
                )
                discovered[config.name] = config
                self.logger.info("Auto-discovered Redis connection")
        
        # Discover S3 connections
        if BOTO3_AVAILABLE:
            aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
            if aws_access_key:
                config = ConnectionConfig(
                    name='s3_auto',
                    type='s3',
                    additional_params={
                        'aws_access_key_id': aws_access_key,
                        'aws_secret_access_key': os.getenv('AWS_SECRET_ACCESS_KEY'),
                        'region_name': os.getenv('AWS_DEFAULT_REGION', 'us-east-1')
                    }
                )
                discovered[config.name] = config
                self.logger.info("Auto-discovered S3 connection")
        
        # Add discovered connections to our configs
        self.connection_configs.update(discovered)
        
        self.logger.info(f"Auto-discovery complete. Found {len(discovered)} connections.")
        return discovered
    
    def connect(self, connection_name: str) -> bool:
        """
        Establish connection to a data source.
        
        Args:
            connection_name: Name of the connection to establish
            
        Returns:
            True if connection successful, False otherwise
        """
        if connection_name not in self.connection_configs:
            self.logger.error(f"Connection config not found: {connection_name}")
            return False
        
        config = self.connection_configs[connection_name]
        self.logger.info(f"Connecting to {config.type} data source: {connection_name}")
        
        try:
            if config.type in ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']:
                return self._connect_sql_database(connection_name, config)
            elif config.type == 'mongodb':
                return self._connect_mongodb(connection_name, config)
            elif config.type == 'redis':
                return self._connect_redis(connection_name, config)
            elif config.type == 's3':
                return self._connect_s3(connection_name, config)
            else:
                self.logger.error(f"Unsupported connection type: {config.type}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to connect to {connection_name}: {e}")
            self.logger.debug(traceback.format_exc())
            return False
    
    def _connect_sql_database(self, name: str, config: ConnectionConfig) -> bool:
        """Connect to SQL database with timeout handling."""
        try:
            if config.connection_string:
                # Add connection timeout parameters
                engine = create_engine(
                    config.connection_string,
                    pool_pre_ping=True,
                    pool_timeout=config.timeout,
                    connect_args={
                        'connect_timeout': config.timeout,
                        'application_name': 'data_explorer'
                    }
                )
            else:
                # Build connection string
                if config.type == 'postgresql':
                    conn_str = f"postgresql+psycopg2://{config.username}:{config.password}@{config.host}:{config.port}/{config.database}"
                elif config.type == 'mysql':
                    conn_str = f"mysql+pymysql://{config.username}:{config.password}@{config.host}:{config.port}/{config.database}"
                elif config.type == 'sqlite':
                    conn_str = f"sqlite:///{config.database}"
                else:
                    self.logger.error(f"Unsupported SQL database type: {config.type}")
                    return False
                
                # Add connection timeout parameters
                connect_args = {}
                if config.type == 'postgresql':
                    connect_args = {
                        'connect_timeout': config.timeout,
                        'application_name': 'data_explorer'
                    }
                elif config.type == 'mysql':
                    connect_args = {
                        'connect_timeout': config.timeout
                    }
                
                engine = create_engine(
                    conn_str,
                    pool_pre_ping=True,
                    pool_timeout=config.timeout,
                    connect_args=connect_args
                )
            
            # Test connection with threading-based timeout
            self.logger.debug(f"Testing connection to {name} (timeout: {config.timeout}s)...")
            
            import threading
            connection_result = {'success': False, 'error': None}
            
            def test_connection():
                try:
                    with engine.connect() as conn:
                        conn.execute(text("SELECT 1"))
                    connection_result['success'] = True
                except Exception as e:
                    connection_result['error'] = e
            
            # Run connection test in thread with timeout
            test_thread = threading.Thread(target=test_connection)
            test_thread.daemon = True
            test_thread.start()
            test_thread.join(timeout=config.timeout)
            
            if test_thread.is_alive():
                self.logger.error(f"Connection test timed out after {config.timeout}s for {name}")
                return False
            
            if not connection_result['success']:
                error = connection_result['error'] or "Unknown connection error"
                self.logger.error(f"Connection test failed for {name}: {error}")
                return False
            
            self.connections[name] = engine
            self.logger.info(f"✓ Connected to {config.type} database: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to SQL database {name}: {e}")
            return False
    
    def _connect_mongodb(self, name: str, config: ConnectionConfig) -> bool:
        """Connect to MongoDB."""
        if not PYMONGO_AVAILABLE:
            self.logger.error("pymongo not available for MongoDB connections")
            return False
        
        try:
            if config.connection_string:
                client = MongoClient(config.connection_string, serverSelectionTimeoutMS=config.timeout * 1000)
            else:
                client = MongoClient(
                    host=config.host,
                    port=config.port,
                    username=config.username,
                    password=config.password,
                    serverSelectionTimeoutMS=config.timeout * 1000
                )
            
            # Test connection
            client.admin.command('ping')
            
            self.connections[name] = client
            self.logger.info(f"✓ Connected to MongoDB: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to MongoDB {name}: {e}")
            return False
    
    def _connect_redis(self, name: str, config: ConnectionConfig) -> bool:
        """Connect to Redis."""
        if not REDIS_AVAILABLE:
            self.logger.error("redis not available for Redis connections")
            return False
        
        try:
            client = redis.Redis(
                host=config.host,
                port=config.port,
                password=config.password,
                socket_timeout=config.timeout,
                decode_responses=True
            )
            
            # Test connection
            client.ping()
            
            self.connections[name] = client
            self.logger.info(f"✓ Connected to Redis: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to Redis {name}: {e}")
            return False
    
    def _connect_s3(self, name: str, config: ConnectionConfig) -> bool:
        """Connect to S3."""
        if not BOTO3_AVAILABLE:
            self.logger.error("boto3 not available for S3 connections")
            return False
        
        try:
            session = boto3.Session(
                aws_access_key_id=config.additional_params.get('aws_access_key_id'),
                aws_secret_access_key=config.additional_params.get('aws_secret_access_key'),
                region_name=config.additional_params.get('region_name', 'us-east-1')
            )
            
            s3_client = session.client('s3')
            
            # Test connection by listing buckets
            s3_client.list_buckets()
            
            self.connections[name] = s3_client
            self.logger.info(f"✓ Connected to S3: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to connect to S3 {name}: {e}")
            return False
    
    def connect_all(self) -> Dict[str, bool]:
        """
        Connect to all configured data sources.
        
        Returns:
            Dictionary mapping connection names to success status
        """
        results = {}
        
        for connection_name in self.connection_configs:
            results[connection_name] = self.connect(connection_name)
        
        successful = sum(1 for success in results.values() if success)
        total = len(results)
        
        self.logger.info(f"Connected to {successful}/{total} data sources")
        return results
    
    def discover_schema(self, connection_name: str) -> List[TableInfo]:
        """
        Discover all tables/collections in a data source.
        
        Args:
            connection_name: Name of the connection to explore
            
        Returns:
            List of TableInfo objects
        """
        if connection_name not in self.connections:
            self.logger.error(f"Not connected to: {connection_name}")
            return []
        
        config = self.connection_configs[connection_name]
        connection = self.connections[connection_name]
        
        self.logger.info(f"Discovering schema for {connection_name} ({config.type})")
        
        try:
            if config.type in ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']:
                tables = self._discover_sql_schema(connection_name, connection)
            elif config.type == 'mongodb':
                tables = self._discover_mongodb_schema(connection_name, connection)
            elif config.type == 'redis':
                tables = self._discover_redis_schema(connection_name, connection)
            elif config.type == 's3':
                tables = self._discover_s3_schema(connection_name, connection)
            else:
                self.logger.error(f"Schema discovery not implemented for {config.type}")
                return []
            
            self.discovered_sources[connection_name] = tables
            self.logger.info(f"Discovered {len(tables)} tables/collections in {connection_name}")
            return tables
            
        except Exception as e:
            self.logger.error(f"Failed to discover schema for {connection_name}: {e}")
            self.logger.debug(traceback.format_exc())
            return []
    
    def _discover_sql_schema(self, connection_name: str, engine: Engine) -> List[TableInfo]:
        """Discover SQL database schema."""
        tables = []
        
        try:
            inspector = inspect(engine)
            
            # Get all schemas
            schemas = inspector.get_schema_names()
            
            for schema in schemas:
                # Skip system schemas
                if schema.lower() in ['information_schema', 'pg_catalog', 'mysql', 'performance_schema', 'sys']:
                    continue
                
                # Get tables in schema
                table_names = inspector.get_table_names(schema=schema)
                
                for table_name in table_names:
                    try:
                        # Get table info
                        columns = inspector.get_columns(table_name, schema=schema)
                        indexes = inspector.get_indexes(table_name, schema=schema)
                        foreign_keys = inspector.get_foreign_keys(table_name, schema=schema)
                        # Get primary key columns
                        pk_constraint = inspector.get_pk_constraint(table_name, schema=schema)
                        primary_keys = pk_constraint.get('constrained_columns', [])
                        
                        # Get row count
                        try:
                            with engine.connect() as conn:
                                result = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table_name}"'))
                                row_count = result.scalar()
                        except:
                            row_count = None
                        
                        # Create table info
                        table_info = TableInfo(
                            name=table_name,
                            schema=schema,
                            type='table',
                            row_count=row_count,
                            columns=[{
                                'name': col['name'],
                                'type': str(col['type']),
                                'nullable': col.get('nullable', True),
                                'default': col.get('default'),
                                'primary_key': col['name'] in primary_keys
                            } for col in columns],
                            indexes=[{
                                'name': idx['name'],
                                'columns': idx['column_names'],
                                'unique': idx.get('unique', False)
                            } for idx in indexes],
                            constraints=[{
                                'type': 'foreign_key',
                                'columns': fk['constrained_columns'],
                                'referenced_table': fk['referred_table'],
                                'referenced_columns': fk['referred_columns']
                            } for fk in foreign_keys]
                        )
                        
                        tables.append(table_info)
                        
                    except Exception as e:
                        self.logger.warning(f"Failed to get info for table {schema}.{table_name}: {e}")
                        continue
        
        except Exception as e:
            self.logger.error(f"Failed to discover SQL schema: {e}")
        
        return tables
    
    def _discover_mongodb_schema(self, connection_name: str, client) -> List[TableInfo]:
        """Discover MongoDB schema."""
        tables = []
        
        try:
            # Get all databases
            db_names = client.list_database_names()
            
            for db_name in db_names:
                # Skip system databases
                if db_name in ['admin', 'config', 'local']:
                    continue
                
                db = client[db_name]
                collection_names = db.list_collection_names()
                
                for collection_name in collection_names:
                    try:
                        collection = db[collection_name]
                        
                        # Get document count
                        doc_count = collection.count_documents({})
                        
                        # Sample documents to infer schema
                        sample_docs = list(collection.find().limit(100))
                        
                        # Infer columns from sample documents
                        columns = []
                        if sample_docs:
                            all_keys = set()
                            for doc in sample_docs:
                                all_keys.update(doc.keys())
                            
                            for key in all_keys:
                                # Determine type from sample values
                                sample_values = [doc.get(key) for doc in sample_docs if key in doc]
                                if sample_values:
                                    value_types = set(type(v).__name__ for v in sample_values if v is not None)
                                    inferred_type = ', '.join(value_types) if value_types else 'unknown'
                                else:
                                    inferred_type = 'unknown'
                                
                                columns.append({
                                    'name': key,
                                    'type': inferred_type,
                                    'nullable': any(doc.get(key) is None for doc in sample_docs)
                                })
                        
                        table_info = TableInfo(
                            name=collection_name,
                            schema=db_name,
                            type='collection',
                            row_count=doc_count,
                            columns=columns
                        )
                        
                        tables.append(table_info)
                        
                    except Exception as e:
                        self.logger.warning(f"Failed to get info for collection {db_name}.{collection_name}: {e}")
                        continue
        
        except Exception as e:
            self.logger.error(f"Failed to discover MongoDB schema: {e}")
        
        return tables
    
    def _discover_redis_schema(self, connection_name: str, client) -> List[TableInfo]:
        """Discover Redis schema."""
        tables = []
        
        try:
            # Get database info
            info = client.info()
            db_count = info.get('databases', 0)
            
            # Get key patterns
            keys = client.keys('*')
            
            # Group keys by pattern
            patterns = {}
            for key in keys[:1000]:  # Limit to first 1000 keys
                key_type = client.type(key)
                pattern = self._extract_key_pattern(key)
                
                if pattern not in patterns:
                    patterns[pattern] = {
                        'count': 0,
                        'types': set(),
                        'sample_keys': []
                    }
                
                patterns[pattern]['count'] += 1
                patterns[pattern]['types'].add(key_type)
                if len(patterns[pattern]['sample_keys']) < 10:
                    patterns[pattern]['sample_keys'].append(key)
            
            # Create table info for each pattern
            for pattern, info in patterns.items():
                table_info = TableInfo(
                    name=pattern,
                    type='key_pattern',
                    row_count=info['count'],
                    metadata={
                        'redis_types': list(info['types']),
                        'sample_keys': info['sample_keys']
                    }
                )
                tables.append(table_info)
        
        except Exception as e:
            self.logger.error(f"Failed to discover Redis schema: {e}")
        
        return tables
    
    def _discover_s3_schema(self, connection_name: str, s3_client) -> List[TableInfo]:
        """Discover S3 schema."""
        tables = []
        
        try:
            # List all buckets
            response = s3_client.list_buckets()
            
            for bucket in response['Buckets']:
                bucket_name = bucket['Name']
                
                try:
                    # List objects in bucket (limited sample)
                    objects_response = s3_client.list_objects_v2(
                        Bucket=bucket_name,
                        MaxKeys=1000
                    )
                    
                    if 'Contents' not in objects_response:
                        continue
                    
                    # Group objects by prefix/folder
                    prefixes = {}
                    for obj in objects_response['Contents']:
                        key = obj['Key']
                        prefix = '/'.join(key.split('/')[:-1]) if '/' in key else 'root'
                        
                        if prefix not in prefixes:
                            prefixes[prefix] = {
                                'count': 0,
                                'total_size': 0,
                                'file_types': set(),
                                'last_modified': None
                            }
                        
                        prefixes[prefix]['count'] += 1
                        prefixes[prefix]['total_size'] += obj['Size']
                        
                        # Extract file extension
                        if '.' in key:
                            ext = key.split('.')[-1].lower()
                            prefixes[prefix]['file_types'].add(ext)
                        
                        # Track latest modification
                        if (prefixes[prefix]['last_modified'] is None or 
                            obj['LastModified'] > prefixes[prefix]['last_modified']):
                            prefixes[prefix]['last_modified'] = obj['LastModified']
                    
                    # Create table info for each prefix
                    for prefix, info in prefixes.items():
                        table_info = TableInfo(
                            name=f"{bucket_name}/{prefix}",
                            schema=bucket_name,
                            type='s3_prefix',
                            row_count=info['count'],
                            size_bytes=info['total_size'],
                            last_modified=info['last_modified'],
                            metadata={
                                'file_types': list(info['file_types']),
                                'prefix': prefix
                            }
                        )
                        tables.append(table_info)
                
                except Exception as e:
                    self.logger.warning(f"Failed to list objects in bucket {bucket_name}: {e}")
                    continue
        
        except Exception as e:
            self.logger.error(f"Failed to discover S3 schema: {e}")
        
        return tables
    
    def _extract_key_pattern(self, key: str) -> str:
        """Extract pattern from Redis key."""
        # Simple pattern extraction - replace numbers with wildcards
        import re
        pattern = re.sub(r'\d+', '*', key)
        return pattern
    
    def profile_table(self, connection_name: str, table_name: str, 
                     schema: Optional[str] = None, sample_size: int = 10000) -> Optional[DataProfile]:
        """
        Generate comprehensive data profile for a table.
        
        Args:
            connection_name: Name of the connection
            table_name: Name of the table to profile
            schema: Schema name (for SQL databases)
            sample_size: Number of rows to sample for analysis
            
        Returns:
            DataProfile object or None if failed
        """
        if connection_name not in self.connections:
            self.logger.error(f"Not connected to: {connection_name}")
            return None
        
        config = self.connection_configs[connection_name]
        connection = self.connections[connection_name]
        
        self.logger.info(f"Profiling table {table_name} in {connection_name}")
        
        try:
            if config.type in ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']:
                return self._profile_sql_table(connection, table_name, schema, sample_size)
            elif config.type == 'mongodb':
                return self._profile_mongodb_collection(connection, table_name, schema, sample_size)
            else:
                self.logger.error(f"Table profiling not implemented for {config.type}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to profile table {table_name}: {e}")
            self.logger.debug(traceback.format_exc())
            return None
    
    def _profile_sql_table(self, engine: Engine, table_name: str, 
                          schema: Optional[str], sample_size: int) -> DataProfile:
        """Profile SQL table."""
        # Build table reference
        if schema:
            full_table_name = f'"{schema}"."{table_name}"'
        else:
            full_table_name = f'"{table_name}"'
        
        with engine.connect() as conn:
            # Get total row count
            total_rows_result = conn.execute(text(f"SELECT COUNT(*) FROM {full_table_name}"))
            total_rows = total_rows_result.scalar()
            
            # Get sample data
            if total_rows > sample_size:
                # Use random sampling for large tables
                if 'postgresql' in str(engine.url):
                    sample_query = f"SELECT * FROM {full_table_name} TABLESAMPLE SYSTEM(10) LIMIT {sample_size}"
                else:
                    sample_query = f"SELECT * FROM {full_table_name} ORDER BY RANDOM() LIMIT {sample_size}"
            else:
                sample_query = f"SELECT * FROM {full_table_name}"
            
            df = pd.read_sql(sample_query, conn)
        
        # Generate profile
        profile = DataProfile(
            table_name=table_name,
            total_rows=total_rows,
            total_columns=len(df.columns),
            sample_data=df.head(100)  # Keep only first 100 rows for sample
        )
        
        # Calculate statistics for each column
        for col in df.columns:
            try:
                # Null percentage
                null_count = df[col].isnull().sum()
                profile.null_percentages[col] = (null_count / len(df)) * 100
                
                # Unique count
                profile.unique_counts[col] = df[col].nunique()
                
                # Data type
                profile.data_types[col] = str(df[col].dtype)
                
                # For numeric columns
                if pd.api.types.is_numeric_dtype(df[col]):
                    profile.min_values[col] = float(df[col].min()) if not df[col].isnull().all() else None
                    profile.max_values[col] = float(df[col].max()) if not df[col].isnull().all() else None
                    profile.mean_values[col] = float(df[col].mean()) if not df[col].isnull().all() else None
                    profile.std_values[col] = float(df[col].std()) if not df[col].isnull().all() else None
                
                # For string columns
                elif pd.api.types.is_string_dtype(df[col]) or df[col].dtype == 'object':
                    non_null_values = df[col].dropna()
                    if len(non_null_values) > 0:
                        profile.min_values[col] = str(non_null_values.astype(str).str.len().min())
                        profile.max_values[col] = str(non_null_values.astype(str).str.len().max())
                
            except Exception as e:
                self.logger.warning(f"Failed to calculate statistics for column {col}: {e}")
                continue
        
        # Quality checks
        quality_issues = []
        
        # Check for high null percentages
        for col, null_pct in profile.null_percentages.items():
            if null_pct > 50:
                quality_issues.append(f"Column '{col}' has {null_pct:.1f}% null values")
        
        # Check for low cardinality in large tables
        if total_rows > 1000:
            for col, unique_count in profile.unique_counts.items():
                if unique_count == 1:
                    quality_issues.append(f"Column '{col}' has only one unique value")
                elif unique_count < 5 and profile.null_percentages[col] < 90:
                    quality_issues.append(f"Column '{col}' has very low cardinality ({unique_count} unique values)")
        
        profile.quality_issues = quality_issues
        
        # Store profile
        profile_key = f"{schema}.{table_name}" if schema else table_name
        self.profiles[profile_key] = profile
        
        return profile
    
    def _profile_mongodb_collection(self, client, collection_name: str,
                                   database_name: str, sample_size: int) -> DataProfile:
        """Profile MongoDB collection."""
        db = client[database_name]
        collection = db[collection_name]
        
        # Get total document count
        total_docs = collection.count_documents({})
        
        # Get sample documents
        if total_docs > sample_size:
            # Use aggregation pipeline for random sampling
            sample_docs = list(collection.aggregate([
                {"$sample": {"size": sample_size}}
            ]))
        else:
            sample_docs = list(collection.find())
        
        if not sample_docs:
            return DataProfile(
                table_name=collection_name,
                total_rows=total_docs,
                total_columns=0
            )
        
        # Convert to DataFrame for analysis
        df = pd.DataFrame(sample_docs)
        
        # Generate profile similar to SQL
        profile = DataProfile(
            table_name=collection_name,
            total_rows=total_docs,
            total_columns=len(df.columns),
            sample_data=df.head(100)
        )
        
        # Calculate statistics
        for col in df.columns:
            try:
                # Null percentage
                null_count = df[col].isnull().sum()
                profile.null_percentages[col] = (null_count / len(df)) * 100
                
                # Unique count
                profile.unique_counts[col] = df[col].nunique()
                
                # Data type
                profile.data_types[col] = str(df[col].dtype)
                
                # For numeric columns
                if pd.api.types.is_numeric_dtype(df[col]):
                    profile.min_values[col] = float(df[col].min()) if not df[col].isnull().all() else None
                    profile.max_values[col] = float(df[col].max()) if not df[col].isnull().all() else None
                    profile.mean_values[col] = float(df[col].mean()) if not df[col].isnull().all() else None
                    profile.std_values[col] = float(df[col].std()) if not df[col].isnull().all() else None
                
            except Exception as e:
                self.logger.warning(f"Failed to calculate statistics for field {col}: {e}")
                continue
        
        # Store profile
        profile_key = f"{database_name}.{collection_name}"
        self.profiles[profile_key] = profile
        
        return profile
    
    def execute_query(self, connection_name: str, query: str, 
                     timeout: Optional[int] = None, limit: Optional[int] = None) -> Optional[pd.DataFrame]:
        """
        Execute a query against a data source.
        
        Args:
            connection_name: Name of the connection
            query: Query to execute
            timeout: Query timeout in seconds
            limit: Maximum number of rows to return
            
        Returns:
            DataFrame with results or None if failed
        """
        if connection_name not in self.connections:
            self.logger.error(f"Not connected to: {connection_name}")
            return None
        
        config = self.connection_configs[connection_name]
        connection = self.connections[connection_name]
        
        self.logger.info(f"Executing query on {connection_name}: {query[:100]}...")
        
        try:
            if config.type in ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']:
                return self._execute_sql_query(connection, query, timeout, limit)
            elif config.type == 'mongodb':
                return self._execute_mongodb_query(connection, query, timeout, limit)
            else:
                self.logger.error(f"Query execution not implemented for {config.type}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to execute query: {e}")
            self.logger.debug(traceback.format_exc())
            return None
    
    def _execute_sql_query(self, engine: Engine, query: str, 
                          timeout: Optional[int], limit: Optional[int]) -> pd.DataFrame:
        """Execute SQL query."""
        # Add LIMIT clause if specified
        if limit and 'LIMIT' not in query.upper():
            query = f"{query.rstrip(';')} LIMIT {limit}"
        
        start_time = time.time()
        
        with engine.connect() as conn:
            if timeout:
                # Set statement timeout
                if 'postgresql' in str(engine.url):
                    conn.execute(text(f"SET statement_timeout = {timeout * 1000}"))
                elif 'mysql' in str(engine.url):
                    conn.execute(text(f"SET SESSION max_execution_time = {timeout * 1000}"))
            
            df = pd.read_sql(query, conn)
        
        execution_time = time.time() - start_time
        self.logger.info(f"Query executed in {execution_time:.2f}s, returned {len(df)} rows")
        
        return df
    
    def _execute_mongodb_query(self, client, query: str,
                              timeout: Optional[int], limit: Optional[int]) -> pd.DataFrame:
        """Execute MongoDB query (simplified - expects JSON query)."""
        try:
            # Parse query as JSON
            query_dict = json.loads(query)
            
            # Extract database and collection
            database_name = query_dict.get('database')
            collection_name = query_dict.get('collection')
            find_query = query_dict.get('query', {})
            projection = query_dict.get('projection')
            
            if not database_name or not collection_name:
                raise ValueError("MongoDB query must specify 'database' and 'collection'")
            
            db = client[database_name]
            collection = db[collection_name]
            
            # Execute query
            cursor = collection.find(find_query, projection)
            
            if limit:
                cursor = cursor.limit(limit)
            
            if timeout:
                cursor = cursor.max_time_ms(timeout * 1000)
            
            # Convert to DataFrame
            docs = list(cursor)
            df = pd.DataFrame(docs)
            
            self.logger.info(f"MongoDB query returned {len(df)} documents")
            return df
            
        except json.JSONDecodeError:
            self.logger.error("MongoDB query must be valid JSON")
            return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Failed to execute MongoDB query: {e}")
            return pd.DataFrame()
    
    def export_results(self, data: pd.DataFrame, filename: str, format: str = 'csv') -> bool:
        """
        Export query results to file.
        
        Args:
            data: DataFrame to export
            filename: Output filename
            format: Export format ('csv', 'json', 'excel', 'parquet')
            
        Returns:
            True if export successful, False otherwise
        """
        try:
            # Ensure data directory exists
            data_dir = Path('data')
            data_dir.mkdir(exist_ok=True)
            
            # If filename doesn't include path, put it in data folder
            output_path = Path(filename)
            if not output_path.parent or output_path.parent == Path('.'):
                output_path = data_dir / filename
            
            if format.lower() == 'csv':
                data.to_csv(output_path, index=False)
            elif format.lower() == 'json':
                data.to_json(output_path, orient='records', indent=2)
            elif format.lower() == 'excel':
                data.to_excel(output_path, index=False)
            elif format.lower() == 'parquet':
                data.to_parquet(output_path, index=False)
            else:
                self.logger.error(f"Unsupported export format: {format}")
                return False
            
            self.logger.info(f"Exported {len(data)} rows to {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export data: {e}")
            return False
    
    def generate_report(self, output_file: Optional[str] = None) -> str:
        """
        Generate comprehensive exploration report.
        
        Args:
            output_file: Optional file to save report
            
        Returns:
            Report content as string
        """
        report_lines = []
        
        # Header
        report_lines.extend([
            "=" * 80,
            "COMPREHENSIVE DATA EXPLORATION REPORT",
            "=" * 80,
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Explorer Version: 1.0.0",
            ""
        ])
        
        # Connection Summary
        report_lines.extend([
            "📊 CONNECTION SUMMARY",
            "-" * 40,
            f"Total Configured Connections: {len(self.connection_configs)}",
            f"Active Connections: {len(self.connections)}",
            ""
        ])
        
        # List connections
        for name, config in self.connection_configs.items():
            status = "✓ Connected" if name in self.connections else "✗ Not Connected"
            report_lines.append(f"  {name} ({config.type}): {status}")
        
        report_lines.append("")
        
        # Schema Discovery Summary
        if self.discovered_sources:
            report_lines.extend([
                "🔍 SCHEMA DISCOVERY SUMMARY",
                "-" * 40
            ])
            
            total_tables = sum(len(tables) for tables in self.discovered_sources.values())
            report_lines.append(f"Total Tables/Collections Discovered: {total_tables}")
            report_lines.append("")
            
            for connection_name, tables in self.discovered_sources.items():
                report_lines.append(f"  {connection_name}: {len(tables)} tables/collections")
                
                # Group by schema/database
                schemas = {}
                for table in tables:
                    schema = table.schema or 'default'
                    if schema not in schemas:
                        schemas[schema] = []
                    schemas[schema].append(table)
                
                for schema, schema_tables in schemas.items():
                    report_lines.append(f"    {schema}: {len(schema_tables)} tables")
                    for table in schema_tables[:5]:  # Show first 5 tables
                        row_info = f" ({table.row_count:,} rows)" if table.row_count else ""
                        report_lines.append(f"      • {table.name}{row_info}")
                    if len(schema_tables) > 5:
                        report_lines.append(f"      ... and {len(schema_tables) - 5} more")
                
                report_lines.append("")
        
        # Data Profiles Summary
        if self.profiles:
            report_lines.extend([
                "📈 DATA PROFILING SUMMARY",
                "-" * 40,
                f"Tables Profiled: {len(self.profiles)}",
                ""
            ])
            
            for profile_key, profile in self.profiles.items():
                report_lines.extend([
                    f"Table: {profile_key}",
                    f"  Rows: {profile.total_rows:,}",
                    f"  Columns: {profile.total_columns}",
                    f"  Quality Issues: {len(profile.quality_issues)}"
                ])
                
                # Show top quality issues
                for issue in profile.quality_issues[:3]:
                    report_lines.append(f"    ⚠️  {issue}")
                
                # Show columns with high null percentages
                high_null_cols = [(col, pct) for col, pct in profile.null_percentages.items() if pct > 25]
                if high_null_cols:
                    report_lines.append("  High Null Columns:")
                    for col, pct in sorted(high_null_cols, key=lambda x: x[1], reverse=True)[:5]:
                        report_lines.append(f"    • {col}: {pct:.1f}% null")
                
                report_lines.append("")
        
        # Recommendations
        report_lines.extend([
            "💡 RECOMMENDATIONS",
            "-" * 40
        ])
        
        recommendations = []
        
        # Connection recommendations
        failed_connections = [name for name in self.connection_configs if name not in self.connections]
        if failed_connections:
            recommendations.append(f"Fix connection issues for: {', '.join(failed_connections)}")
        
        # Schema discovery recommendations
        unscanned_connections = [name for name in self.connections if name not in self.discovered_sources]
        if unscanned_connections:
            recommendations.append(f"Run schema discovery for: {', '.join(unscanned_connections)}")
        
        # Data quality recommendations
        if self.profiles:
            tables_with_issues = [key for key, profile in self.profiles.items() if profile.quality_issues]
            if tables_with_issues:
                recommendations.append(f"Address data quality issues in {len(tables_with_issues)} tables")
        
        if not recommendations:
            recommendations.append("🎉 All systems look good! Consider profiling more tables for deeper insights.")
        
        for i, rec in enumerate(recommendations, 1):
            report_lines.append(f"{i}. {rec}")
        
        report_lines.append("")
        report_lines.append("=" * 80)
        
        report_content = "\n".join(report_lines)
        
        # Save to file if requested
        if output_file:
            try:
                # Ensure reports directory exists
                reports_dir = Path('reports')
                reports_dir.mkdir(exist_ok=True)
                
                # If output_file doesn't include path, put it in reports folder
                output_path = Path(output_file)
                if not output_path.parent or output_path.parent == Path('.'):
                    output_path = reports_dir / output_file
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(report_content)
                self.logger.info(f"Report saved to: {output_path}")
            except Exception as e:
                self.logger.error(f"Failed to save report: {e}")
        
        return report_content
    
    def close_connection(self, connection_name: str):
        """Close a specific connection."""
        if connection_name in self.connections:
            try:
                connection = self.connections[connection_name]
                config = self.connection_configs[connection_name]
                
                if config.type in ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']:
                    connection.dispose()
                elif config.type == 'mongodb':
                    connection.close()
                elif config.type == 'redis':
                    connection.close()
                # S3 connections don't need explicit closing
                
                del self.connections[connection_name]
                self.logger.info(f"Closed connection: {connection_name}")
                
            except Exception as e:
                self.logger.warning(f"Error closing connection {connection_name}: {e}")
    
    def close_all_connections(self):
        """Close all active connections."""
        connection_names = list(self.connections.keys())
        for name in connection_names:
            self.close_connection(name)
        
        self.logger.info("All connections closed")


def create_sample_config() -> Dict[str, Any]:
    """Create a sample configuration file."""
    return {
        "connections": [
            {
                "name": "main_postgres",
                "type": "postgresql",
                "host": "localhost",
                "port": 5432,
                "database": "mydb",
                "username": "user",
                "password": "password",
                "timeout": 30
            },
            {
                "name": "analytics_mysql",
                "type": "mysql",
                "host": "mysql.example.com",
                "port": 3306,
                "database": "analytics",
                "username": "analyst",
                "password": "secret",
                "timeout": 60
            },
            {
                "name": "document_store",
                "type": "mongodb",
                "connection_string": "mongodb://user:pass@localhost:27017/mydb"
            },
            {
                "name": "cache_store",
                "type": "redis",
                "host": "localhost",
                "port": 6379,
                "password": "redis_pass"
            },
            {
                "name": "data_lake",
                "type": "s3",
                "additional_params": {
                    "aws_access_key_id": "YOUR_ACCESS_KEY",
                    "aws_secret_access_key": "YOUR_SECRET_KEY",
                    "region_name": "us-east-1"
                }
            }
        ]
    }


def main():
    """Main function to run the data explorer."""
    parser = argparse.ArgumentParser(
        description="Comprehensive Data Exploration Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --discover-all                    # Auto-discover and explore all sources
  %(prog)s --config config.json              # Use specific configuration file
  %(prog)s --profile-table users             # Profile a specific table
  %(prog)s --query "SELECT * FROM users"     # Execute a query
  %(prog)s --create-sample-config            # Create sample configuration file
        """
    )
    
    parser.add_argument('--config', '-c', help='Configuration file path')
    parser.add_argument('--discover-all', action='store_true', help='Auto-discover all data sources')
    parser.add_argument('--profile-table', help='Profile a specific table')
    parser.add_argument('--database', help='Database/connection name for table profiling')
    parser.add_argument('--schema', help='Schema name for table profiling')
    parser.add_argument('--query', '-q', help='SQL query to execute')
    parser.add_argument('--connection', help='Connection name for query execution')
    parser.add_argument('--export', help='Export format (csv, json, excel, parquet)')
    parser.add_argument('--output', '-o', help='Output filename')
    parser.add_argument('--limit', type=int, help='Limit number of rows returned')
    parser.add_argument('--timeout', type=int, default=300, help='Query timeout in seconds')
    parser.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'])
    parser.add_argument('--create-sample-config', action='store_true', help='Create sample configuration file')
    parser.add_argument('--report', help='Generate exploration report to file')
    
    args = parser.parse_args()
    
    # Create sample config if requested
    if args.create_sample_config:
        config = create_sample_config()
        filename = 'data_explorer_config.json'
        with open(filename, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"Sample configuration created: {filename}")
        return
    
    try:
        # Initialize explorer
        explorer = DataExplorer(config_file=args.config, log_level=args.log_level)
        
        # Auto-discover connections if no config provided or if explicitly requested
        if not args.config or args.discover_all:
            explorer.auto_discover_connections()
        
        # Connect to all sources
        if explorer.connection_configs:
            print("🔌 Connecting to data sources...")
            results = explorer.connect_all()
            
            successful_connections = [name for name, success in results.items() if success]
            if not successful_connections:
                print("X No successful connections established")
                return
            
            print(f"✓ Connected to {len(successful_connections)} data sources")
        else:
            print("X No data source configurations found")
            return
        
        # Discover schemas for all connected sources
        if args.discover_all:
            print("\n🔍 Discovering schemas...")
            for connection_name in successful_connections:
                tables = explorer.discover_schema(connection_name)
                if tables:
                    print(f"  {connection_name}: {len(tables)} tables/collections")
        
        # Profile specific table
        if args.profile_table:
            connection_name = args.database or successful_connections[0]
            print(f"\n📊 Profiling table '{args.profile_table}' in '{connection_name}'...")
            
            profile = explorer.profile_table(
                connection_name=connection_name,
                table_name=args.profile_table,
                schema=args.schema
            )
            
            if profile:
                print(f"✅ Profile generated:")
                print(f"  Rows: {profile.total_rows:,}")
                print(f"  Columns: {profile.total_columns}")
                print(f"  Quality Issues: {len(profile.quality_issues)}")
                
                if profile.quality_issues:
                    print("  Issues:")
                    for issue in profile.quality_issues[:5]:
                        print(f"    ⚠️  {issue}")
        
        # Execute query
        if args.query:
            connection_name = args.connection or successful_connections[0]
            print(f"\n🔍 Executing query on '{connection_name}'...")
            
            result = explorer.execute_query(
                connection_name=connection_name,
                query=args.query,
                timeout=args.timeout,
                limit=args.limit
            )
            
            if result is not None and not result.empty:
                print(f"✓ Query returned {len(result)} rows, {len(result.columns)} columns")
                
                # Show sample of results
                print("\nSample results:")
                print(result.head().to_string())
                
                # Export if requested
                if args.export and args.output:
                    success = explorer.export_results(result, args.output, args.export)
                    if success:
                        print(f"✓ Results exported to {args.output}")
            else:
                print("X Query returned no results")
        
        # Generate report
        if args.report or args.discover_all:
            print("\n📋 Generating exploration report...")
            # Ensure reports directory exists
            reports_dir = Path('reports')
            reports_dir.mkdir(exist_ok=True)
            
            report_file = args.report or f"reports/data_exploration_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            report = explorer.generate_report(report_file)
            print(f"✓ Report saved to: {report_file}")
            
            # Show summary
            print("\nReport Summary:")
            lines = report.split('\n')
            summary_lines = [line for line in lines if line.startswith(('Total Configured', 'Active Connections', 'Total Tables'))]
            for line in summary_lines:
                print(f"  {line}")
        
        # Interactive mode if no specific action requested
        if not any([args.discover_all, args.profile_table, args.query, args.report]):
            print("\n🎯 Interactive Mode")
            print("Available connections:", ', '.join(successful_connections))
            print("Use --help for available commands")
        
    except KeyboardInterrupt:
        print("\n\n⏹️  Exploration cancelled by user")
    except Exception as e:
        print(f"\nX Exploration failed: {e}")
        if args.log_level == 'DEBUG':
            traceback.print_exc()
    finally:
        # Clean up connections
        try:
            explorer.close_all_connections()
        except:
            pass


if __name__ == "__main__":
    main()