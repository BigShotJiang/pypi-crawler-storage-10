#!/usr/bin/env python3
"""
Line Counter Script for Python Projects

This script counts lines of code in Python files, organized by module/directory.
Replicates the functionality of the bash command for counting lines by module.
"""

import os
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple


def count_lines_in_file(file_path: str) -> int:
    """Count lines in a single file using wc -l command."""
    try:
        result = subprocess.run(['wc', '-l', file_path], 
                              capture_output=True, text=True, check=True)
        return int(result.stdout.strip().split()[0])
    except (subprocess.CalledProcessError, ValueError, IndexError):
        # Fallback to Python implementation if wc fails
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for _ in f)
        except Exception:
            return 0


def find_python_files_in_module(module_path: str) -> List[Tuple[str, int]]:
    """Find all Python files in a module and count their lines."""
    files_with_lines = []
    
    if not os.path.exists(module_path):
        return files_with_lines
    
    for root, dirs, files in os.walk(module_path):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                line_count = count_lines_in_file(file_path)
                # Convert to relative path with forward slashes for consistency
                rel_path = os.path.relpath(file_path).replace('\\', '/')
                files_with_lines.append((rel_path, line_count))
    
    # Sort by line count
    files_with_lines.sort(key=lambda x: x[1])
    return files_with_lines


def get_project_modules() -> List[str]:
    """Automatically detect Python modules in the current directory."""
    modules = []
    current_dir = Path('.')
    
    for item in current_dir.iterdir():
        if item.is_dir() and not item.name.startswith('.'):
            # Check if directory contains Python files
            python_files = list(item.rglob('*.py'))
            if python_files:
                modules.append(item.name)
    
    return sorted(modules)


def format_module_output(module_name: str, files_with_lines: List[Tuple[str, int]]) -> str:
    """Format the output for a single module."""
    if not files_with_lines:
        return f"{module_name.upper()} MODULE:\nNo Python files found\n"
    
    output = f"{module_name.upper()} MODULE:\n"
    
    total_lines = 0
    for file_path, line_count in files_with_lines:
        output += f"{line_count:5d} ./{file_path}\n"
        total_lines += line_count
    
    output += f"{total_lines:5d} total\n"
    return output


def main():
    """Main function to count lines across all modules."""
    print("=== Lines of Code by Module ===")
    print()
    
    # Get all modules in the project
    modules = get_project_modules()
    
    if not modules:
        print("No Python modules found in the current directory.")
        return
    
    grand_total = 0
    
    for module in modules:
        files_with_lines = find_python_files_in_module(module)
        module_output = format_module_output(module, files_with_lines)
        print(module_output)
        
        # Calculate module total for grand total
        module_total = sum(line_count for _, line_count in files_with_lines)
        grand_total += module_total
    
    print(f"TOTAL PROJECT LINES: {grand_total}")


if __name__ == "__main__":
    main()
