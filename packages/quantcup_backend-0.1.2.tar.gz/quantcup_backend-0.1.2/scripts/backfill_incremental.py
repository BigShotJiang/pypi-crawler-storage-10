"""
Comprehensive Backfill Script for Incremental Strategy Tables

Pattern: Minimum Viable Decoupling (2 complexity points)
Complexity: 4 points total (DI + business logic + orchestration + validation + memory tracking)
Depth: 3 layers (Script → Services → Infrastructure)

Four-Stage Pipeline:
1. Data Comparison: R data vs local database vs cloud bucket
2. Eligibility Filtering: <90% completeness identification
3. Lightweight Processing: Streamlined cleaning operations
4. Intelligent Loading: Bucket-first routing to appropriate destinations

Following REFACTORING_SPECS.md standards with emphasis on:
- Minimal complexity and maximum functionality
- Comprehensive error handling and progress tracking
- Super straightforward execution - just run the script
- Data consistency across all storage layers
- Memory tracking for large incremental tables
- Simplified year-by-year processing without checkpoint overhead
"""

import os
import sys
import gc
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime
import pandas as pd

# Add project root to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Memory monitoring (with fallback if psutil not available)
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

from commonv2 import get_logger
from commonv2.core.logging import get_session_output_dir
from commonv2._data.database import (
    create_db_engine_from_env, get_table_row_count,
    get_all_table_row_counts, table_exists
)
from commonv2.utils.validation import apply_cleaning, DataQualityError
from nflfastRv3.shared.r_integration import execute_real_r_call, get_r_service
from nflfastRv3.shared.bucket_adapter import BucketAdapter
from nflfastRv3.shared.database_router import DatabaseRouter
from nflfastRv3.shared.database import NFLfastRDatabase
from nflfastRv3.shared.progress_tracker import ProgressTracker
from nflfastRv3.features.data_pipeline.config.data_sources import (
    get_sources_by_strategy, DATA_SOURCE_GROUPS, DataSourceConfig
)


@dataclass
class DataComparisonResult:
    """Results from data comparison stage."""
    table_name: str
    r_data_count: int
    local_db_count: int
    bucket_count: int
    completeness_percentage: float
    needs_backfill: bool
    comparison_timestamp: datetime


@dataclass
class BackfillSummary:
    """Summary of backfill operation results."""
    total_tables_analyzed: int
    eligible_tables: int
    successfully_backfilled: int
    failed_tables: List[str]
    total_rows_processed: int
    execution_time_seconds: float


class SimpleMemoryMonitor:
    """
    Lightweight memory tracking utility for data pipeline operations.
    
    Pattern: Simple utility class (1 complexity point)
    Following existing codebase patterns from warehouse_utils.py and test_r_calls.py
    """
    
    def __init__(self, logger=None):
        """Initialize memory monitor with optional logger."""
        self.logger = logger
        self.baseline_memory_mb = None
        self.process = None
        
        if HAS_PSUTIL:
            try:
                import psutil as ps
                self.process = ps.Process()
            except Exception:
                pass
        
        # Set baseline memory
        self._set_baseline()
    
    def _set_baseline(self):
        """Set baseline memory usage."""
        if self.process:
            self.baseline_memory_mb = self.process.memory_info().rss / 1024 / 1024
            if self.logger:
                self.logger.debug(f"🧠 Memory baseline: {self.baseline_memory_mb:.1f} MB")
    
    def get_memory_info(self) -> Dict[str, float]:
        """Get current memory usage information."""
        if not self.process or not HAS_PSUTIL:
            return {'current_mb': 0, 'system_percent': 0, 'available_mb': 0}
        
        try:
            memory_info = self.process.memory_info()
            available_mb = 0
            
            if HAS_PSUTIL:
                try:
                    import psutil as ps
                    system_memory = ps.virtual_memory()
                    available_mb = system_memory.available / 1024 / 1024
                except Exception:
                    pass
            
            return {
                'current_mb': memory_info.rss / 1024 / 1024,
                'system_percent': self.process.memory_percent(),
                'available_mb': available_mb
            }
        except Exception:
            return {'current_mb': 0, 'system_percent': 0, 'available_mb': 0}
    
    def log_memory_usage(self, stage: str, table_name: Optional[str] = None, df: Optional[pd.DataFrame] = None):
        """Log memory usage at specific pipeline stage."""
        if not self.logger:
            return
        
        memory_info = self.get_memory_info()
        current_mb = memory_info['current_mb']
        system_percent = memory_info['system_percent']
        
        # Create context string
        context = f"{stage}"
        if table_name:
            context += f" ({table_name})"
        
        # Add DataFrame memory info if provided
        df_memory_str = ""
        if df is not None and not df.empty:
            df_memory_mb = df.memory_usage(deep=True).sum() / 1024 / 1024
            df_memory_str = f", DataFrame: {df_memory_mb:.1f} MB"
        
        # Log with appropriate level based on memory usage
        if system_percent > 80:
            self.logger.warning(f"🧠 HIGH MEMORY: {context} - Process: {current_mb:.1f} MB ({system_percent:.1f}%){df_memory_str}")
        elif system_percent > 60:
            self.logger.info(f"🧠 Memory: {context} - Process: {current_mb:.1f} MB ({system_percent:.1f}%){df_memory_str}")
        else:
            self.logger.debug(f"🧠 Memory: {context} - Process: {current_mb:.1f} MB ({system_percent:.1f}%){df_memory_str}")
    
    def check_memory_threshold(self, threshold: float = 0.8) -> bool:
        """
        Check if memory usage is below threshold.
        
        Args:
            threshold: Memory threshold (0.8 = 80%)
            
        Returns:
            True if memory is safe, False if exceeds threshold
        """
        if not self.process:
            return True  # Assume safe if can't monitor
        
        memory_info = self.get_memory_info()
        system_percent = memory_info['system_percent'] / 100
        
        return system_percent < threshold
    
    def estimate_dataframe_memory(self, rows: int, cols: int) -> float:
        """
        Estimate DataFrame memory usage in MB.
        
        Uses pattern from test_r_calls.py for memory estimation.
        
        Args:
            rows: Number of rows
            cols: Number of columns
            
        Returns:
            Estimated memory usage in MB
        """
        # Rough estimate: 8 bytes per cell (from test_r_calls.py pattern)
        return (rows * cols * 8) / (1024 * 1024)
    
    def cleanup_memory(self):
        """Force garbage collection and memory cleanup."""
        memory_before = 0
        if self.logger:
            memory_before = self.get_memory_info()['current_mb']
        
        # Force garbage collection
        gc.collect()
        
        if self.logger and memory_before > 0:
            memory_after = self.get_memory_info()['current_mb']
            memory_freed = memory_before - memory_after
            if memory_freed > 1:  # Only log if significant cleanup
                self.logger.info(f"🧹 Memory cleanup: Freed {memory_freed:.1f} MB")


def _shrink_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggressively shrink DataFrame dtypes to reduce memory usage.
    
    Args:
        df: DataFrame to shrink
        
    Returns:
        DataFrame with optimized dtypes
    """
    df_shrunk = df.copy()
    
    # Downcast float64 to float32
    for col in df_shrunk.select_dtypes(include=['float64']).columns:
        df_shrunk[col] = df_shrunk[col].astype('float32')
    
    # Downcast int64 to int32 where safe
    for col in df_shrunk.select_dtypes(include=['int64']).columns:
        col_max = df_shrunk[col].max()
        col_min = df_shrunk[col].min()
        
        # Check if values fit in int32 range
        if col_max <= 2_147_483_647 and col_min >= -2_147_483_648:
            df_shrunk[col] = df_shrunk[col].astype('int32')
    
    # Keep strings as object; categories can sometimes bloat on write
    return df_shrunk


class BackfillIncrementalPipeline:
    """
    Comprehensive backfill pipeline for incremental strategy tables.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 4 points (DI + business logic + orchestration + validation + memory tracking)
    Depth: 3 layers (Pipeline → Services → Infrastructure)
    
    Four-stage pipeline implementation following REFACTORING_SPECS.md standards.
    Targets large incremental tables that need historical data backfill.
    Simplified approach without checkpoint overhead for maximum reliability.
    """
    
    def __init__(self, db_service=None, bucket_adapter=None, database_router=None, logger=None):
        """
        Initialize backfill pipeline with dependency injection.
        
        Args:
            db_service: Optional database service (uses singleton if not provided)
            bucket_adapter: Optional bucket adapter (creates default if not provided)
            database_router: Optional database router (creates default if not provided)
            logger: Optional logger instance (uses module logger if not provided)
        """
        # Simple DI with fallback (1 complexity point)
        self.logger = logger or get_logger('nflfastRv3.backfill_incremental')
        self.db_service = db_service or NFLfastRDatabase.get_instance()
        self.bucket_adapter = bucket_adapter or BucketAdapter(logger=self.logger)
        self.database_router = database_router or DatabaseRouter(self.db_service, self.logger)
        
        # Business logic initialization (1 complexity point)
        self.r_service = get_r_service()
        self.comparison_results: List[DataComparisonResult] = []
        self.eligible_tables: List[str] = []
        
        # Memory tracking initialization
        self.memory_monitor = SimpleMemoryMonitor(logger=self.logger)
        
        # Validation and configuration
        self._validate_dependencies()
    
    def execute_backfill(self) -> BackfillSummary:
        """
        Execute complete four-stage backfill pipeline for incremental tables.
        
        Super straightforward - processes all incremental tables with 90% threshold.
        
        Returns:
            BackfillSummary with execution results
        """
        start_time = datetime.now()
        self.logger.info("🚀 Starting incremental backfill pipeline")
        
        # Log initial memory state
        self.memory_monitor.log_memory_usage("Pipeline Start")
        
        try:
            # Stage 1: Data Comparison
            self.logger.info("📊 Stage 1: Data Comparison")
            self.memory_monitor.log_memory_usage("Before Data Comparison")
            comparison_results = self._execute_data_comparison_stage()
            self.memory_monitor.log_memory_usage("After Data Comparison")
            
            # Stage 2: Eligibility Filtering  
            self.logger.info("🔍 Stage 2: Eligibility Filtering")
            eligible_tables = self._execute_eligibility_filtering_stage(comparison_results)
            
            # Stage 3 & 4: Processing and Loading (combined for efficiency)
            self.logger.info("⚙️ Stage 3-4: Processing and Loading")
            self.memory_monitor.log_memory_usage("Before Processing and Loading")
            success_count, failed_tables, total_rows = self._execute_processing_and_loading_stages(
                eligible_tables
            )
            self.memory_monitor.log_memory_usage("After Processing and Loading")
            
            # Generate summary
            summary = self._create_summary(
                comparison_results, eligible_tables, success_count, failed_tables, start_time
            )
            
            self.logger.info(f"✅ Incremental backfill pipeline completed: {summary.successfully_backfilled}/{summary.eligible_tables} tables")
            return summary
            
        except Exception as e:
            self.logger.error(f"❌ Incremental backfill pipeline failed: {e}", exc_info=True)
            raise
    
    def _execute_data_comparison_stage(self) -> List[DataComparisonResult]:
        """
        Stage 1: Compare record counts between R data source, local database, and cloud bucket.
        
        Returns:
            List of DataComparisonResult objects
        """
        # Get incremental strategy tables (the large ones that need backfill)
        incremental_sources = get_sources_by_strategy('incremental')
        
        self.logger.info(f"Analyzing {len(incremental_sources)} incremental tables")
        
        comparison_results = []
        progress = ProgressTracker(
            total_expected=len(incremental_sources),
            table_name="data_comparison",
            tracking_unit="tables",
            logger=self.logger
        )
        progress.start()
        
        for table_name, config in incremental_sources.items():
            try:
                self.logger.info(f"🔍 Comparing data for table: {table_name}")
                
                # Get R data count (with memory-safe chunked loading)
                r_count = self._get_r_data_count(config)
                
                # Get local database count
                local_count = self._get_local_database_count(config)
                
                # Get bucket count
                bucket_count = self._get_bucket_count(config)
                
                # Calculate completeness (using R data as authoritative source)
                completeness = (max(local_count, bucket_count) / r_count * 100) if r_count > 0 else 100.0
                needs_backfill = completeness < 90.0  # Default threshold
                
                result = DataComparisonResult(
                    table_name=table_name,
                    r_data_count=r_count,
                    local_db_count=local_count,
                    bucket_count=bucket_count,
                    completeness_percentage=completeness,
                    needs_backfill=needs_backfill,
                    comparison_timestamp=datetime.now()
                )
                
                comparison_results.append(result)
                
                self.logger.info(
                    f"📊 {table_name}: R={r_count:,}, DB={local_count:,}, "
                    f"Bucket={bucket_count:,}, Completeness={completeness:.1f}%"
                )
                
                progress.update(1, force_report=True, step_name=table_name)
                
            except Exception as e:
                self.logger.error(f"Failed to compare data for {table_name}: {e}")
                progress.update(1, force_report=True, step_name=f"{table_name} (failed)")
                continue
        
        progress.finish()
        self.comparison_results = comparison_results
        return comparison_results
    
    def _execute_eligibility_filtering_stage(self, comparison_results: List[DataComparisonResult]) -> List[str]:
        """
        Stage 2: Filter tables with less than 90% completeness threshold.
        
        Args:
            comparison_results: Results from data comparison stage
            
        Returns:
            List of table names eligible for backfill
        """
        threshold_percentage = 90.0  # Fixed 90% threshold
        eligible_tables = []
        
        self.logger.info(f"Filtering incremental tables with <{threshold_percentage:.0f}% completeness")
        
        for result in comparison_results:
            if result.completeness_percentage < threshold_percentage:
                eligible_tables.append(result.table_name)
                self.logger.info(
                    f"✓ {result.table_name} eligible: {result.completeness_percentage:.1f}% < {threshold_percentage:.0f}%"
                )
            else:
                self.logger.debug(
                    f"⏭️ {result.table_name} skipped: {result.completeness_percentage:.1f}% >= {threshold_percentage:.0f}%"
                )
        
        self.logger.info(f"🎯 {len(eligible_tables)} incremental tables eligible for backfill")
        self.eligible_tables = eligible_tables
        return eligible_tables
    
    def _execute_processing_and_loading_stages(self, eligible_tables: List[str]) -> Tuple[int, List[str], int]:
        """
        Stages 3-4: Lightweight processing and intelligent loading combined for efficiency.
        
        Args:
            eligible_tables: List of table names to process
            
        Returns:
            Tuple of (success_count, failed_tables, total_rows_processed)
        """
        if not eligible_tables:
            self.logger.info("No incremental tables eligible for backfill")
            return 0, [], 0
        
        success_count = 0
        failed_tables = []
        total_rows = 0
        
        progress = ProgressTracker(
            total_expected=len(eligible_tables),
            table_name="backfill_processing",
            tracking_unit="tables",
            logger=self.logger
        )
        progress.start()
        
        for table_name in eligible_tables:
            try:
                self.logger.info(f"🔄 Processing incremental table: {table_name}")
                
                # Memory check before processing each table
                self.memory_monitor.log_memory_usage("Table Start", table_name)
                
                # Check if we should skip this table due to memory constraints (lowered threshold)
                if not self.memory_monitor.check_memory_threshold(0.60):
                    self.logger.warning(f"⚠️ HIGH MEMORY: Skipping {table_name} due to memory constraints")
                    failed_tables.append(table_name)
                    progress.update(1, force_report=True, step_name=f"{table_name} (skipped - memory)")
                    continue
                
                # Get table configuration
                config = self._get_table_config(table_name)
                if not config:
                    self.logger.error(f"Configuration not found for {table_name}")
                    failed_tables.append(table_name)
                    continue
                
                # Stage 3: Lightweight Data Processing
                df = self._execute_lightweight_processing(config)
                if df.empty:
                    self.logger.warning(f"No data retrieved for {table_name}")
                    failed_tables.append(table_name)
                    continue
                
                # Log memory usage after data processing
                self.memory_monitor.log_memory_usage("After Data Processing", table_name, df)
                
                # Stage 4: Intelligent Data Loading
                rows_written = self._execute_intelligent_loading(df, config)
                if rows_written > 0:
                    success_count += 1
                    total_rows += rows_written
                    self.logger.info(f"✅ {table_name}: {rows_written:,} rows backfilled")
                else:
                    failed_tables.append(table_name)
                    self.logger.error(f"❌ {table_name}: Failed to write data")
                
                # Memory cleanup between tables
                self.memory_monitor.cleanup_memory()
                self.memory_monitor.log_memory_usage("After Cleanup", table_name)
                
                progress.update(1, force_report=True, step_name=table_name)
                
            except Exception as e:
                self.logger.error(f"Failed to process {table_name}: {e}")
                failed_tables.append(table_name)
                progress.update(1, force_report=True, step_name=f"{table_name} (failed)")
                
                # Emergency memory cleanup on failure
                self.memory_monitor.cleanup_memory()
                continue
        
        progress.finish()
        return success_count, failed_tables, total_rows
    
    def _execute_lightweight_processing(self, config: DataSourceConfig) -> pd.DataFrame:
        """
        Stage 3: Stream backfill year-by-year to avoid memory issues.
        
        For incremental tables, this streams historical data in small chunks
        starting from the table's minimum year. Simplified approach without
        checkpoint overhead for maximum reliability.
        
        Args:
            config: Data source configuration
            
        Returns:
            Empty DataFrame (data written chunk-by-chunk) or sentinel with row count
        """
        table = config.table
        self.logger.debug(f"Streaming historical data for incremental table: {table}")
        
        # Get year range for streaming
        min_year = getattr(config, 'min_year', 1999)
        current_year = 2024
        chunk_span = int(os.getenv('MAX_CHUNK_YEARS', '1'))  # default 1 year
        
        # Start from minimum year (no checkpoint resume)
        start_year = min_year
        
        total_rows = 0
        
        for start in range(start_year, current_year + 1, chunk_span):
            end = min(start + (chunk_span - 1), current_year)
            
            # Memory guard before fetch (lowered threshold for play_by_play)
            if not self.memory_monitor.check_memory_threshold(0.60):
                self.logger.warning(f"⚠️ MEMORY HIGH: skipping {table} {start}-{end}")
                continue
            
            try:
                # Fetch just this chunk
                chunk_call = self._create_chunked_r_call(table, start, end)
                self.logger.info(f"🔄 Processing {table} chunk {start}-{end}")
                
                df = execute_real_r_call(chunk_call, f"{table}_chunk_{start}_{end}")
                if df.empty:
                    self.logger.debug(f"Empty chunk for {table} {start}-{end}")
                    continue
                
                # Clean small chunk
                self.memory_monitor.log_memory_usage("Before Cleaning", f"{table} {start}-{end}", df)
                cfg = {
                    'table': table,
                    'schema': config.schema,
                    'numeric_cols': getattr(config, 'numeric_cols', []),
                    'non_numeric_cols': getattr(config, 'non_numeric_cols', []),
                    'unique_keys': config.unique_keys
                }
                try:
                    df = apply_cleaning(df, table, cfg, self.logger)
                    self.logger.info(f"📊 CLEANING: {table} {start}-{end} - {len(df):,} rows after cleaning")
                except Exception as e:
                    self.logger.warning(f"Cleaning failed for {table} {start}-{end}: {e}")
                
                # Write this chunk immediately (bucket first, then DB)
                rows_written = self._execute_intelligent_loading(df, config)
                total_rows += rows_written
                
                self.logger.info(f"✅ {table} chunk {start}-{end}: {rows_written:,} rows written")
                
                # Drop from memory
                del df
                self.memory_monitor.cleanup_memory()
                
            except Exception as e:
                self.logger.error(f"Failed to process {table} chunk {start}-{end}: {e}")
                continue
        
        # We wrote everything chunk-by-chunk; return sentinel so caller doesn't try to re-write
        if total_rows == 0:
            self.logger.warning(f"No data processed for {table}")
            return pd.DataFrame()
        
        self.logger.info(f"✅ Streaming complete for {table}: {total_rows:,} total rows written")
        return pd.DataFrame({"_rows_written": [total_rows]})
    
    def _create_backfill_r_call(self, table_name: str) -> str:
        """
        Create backfill-specific R calls that load ALL historical data.
        
        This bypasses the data_sources.py configuration and creates proper
        historical R calls specifically for backfill operations.
        
        Args:
            table_name: Name of the table to create R call for
            
        Returns:
            R call string to load all historical data
        """
        # Create backfill-specific R calls that always load all historical data
        backfill_r_calls = {
            'play_by_play': 'load_pbp(seasons = 1999:2025, file_type = "parquet")',
            'rosters': 'load_rosters(seasons = 1999:2025, file_type = "parquet")',
            'player_stats': 'load_player_stats(seasons = 1999:2025, stat_type = c("offense", "defense", "kicking"), file_type = "parquet")',
            'participation': 'load_participation(seasons = 2016:2025, file_type = "parquet")',
            'nextgen': 'load_nextgen_stats(seasons = 2016:2025, stat_type = c("passing", "receiving", "rushing"), file_type = "parquet")',
            'snap_counts': 'load_snap_counts(seasons = 2012:2025, file_type = "parquet")',
            'pfr_adv_stats': 'load_pfr_advstats(seasons = 2018:2025)',
            'ftn_chart': 'load_ftn_charting(seasons = 2022:2025)',
            'wkly_rosters': 'load_rosters_weekly(seasons = 2002:2025, file_type = "parquet")'
        }
        
        if table_name in backfill_r_calls:
            return backfill_r_calls[table_name]
        else:
            # Fallback: try to modify the config R call
            return self._prepare_historical_r_call_fallback(table_name)
    
    def _prepare_historical_r_call_fallback(self, table_name: str) -> str:
        """
        Fallback method to modify existing R call for historical data.
        Only used if table not in predefined backfill calls.
        """
        # Get the config for fallback
        config = self._get_table_config(table_name)
        if not config:
            raise ValueError(f"No configuration found for table: {table_name}")
        
        r_call = config.r_call
        
        # For incremental tables, modify R call to load all seasons with explicit year ranges
        if 'load_pbp(' in r_call:
            r_call = r_call.replace('load_pbp(', 'load_pbp(seasons = 1999:2025, ')
        elif 'load_rosters(' in r_call:
            r_call = r_call.replace('load_rosters(', 'load_rosters(seasons = 1999:2025, ')
        elif 'load_player_stats(' in r_call:
            r_call = r_call.replace('load_player_stats(', 'load_player_stats(seasons = 1999:2025, ')
        elif 'load_participation(' in r_call:
            r_call = r_call.replace('load_participation(', 'load_participation(seasons = 2016:2025, ')
        elif 'load_nextgen_stats(' in r_call:
            r_call = r_call.replace('load_nextgen_stats(', 'load_nextgen_stats(seasons = 2016:2025, ')
        elif 'load_snap_counts(' in r_call:
            r_call = r_call.replace('load_snap_counts(', 'load_snap_counts(seasons = 2012:2025, ')
        elif 'load_pfr_advstats(' in r_call:
            r_call = r_call.replace('load_pfr_advstats(', 'load_pfr_advstats(seasons = 2018:2025, ')
        elif 'load_ftn_charting(' in r_call:
            r_call = r_call.replace('load_ftn_charting(', 'load_ftn_charting(seasons = 2022:2025, ')
        elif 'load_rosters_weekly(' in r_call:
            r_call = r_call.replace('load_rosters_weekly(', 'load_rosters_weekly(seasons = 2002:2025, ')
        
        return r_call
    
    def _execute_intelligent_loading(self, df: pd.DataFrame, config: DataSourceConfig) -> int:
        """
        Stage 4: Intelligent data loading with streaming writes to avoid memory spikes.
        
        Args:
            df: Processed DataFrame
            config: Data source configuration
            
        Returns:
            Number of rows written
        """
        if df.empty:
            return 0
        
        self.logger.info(f"🗄️ Loading {len(df):,} rows for incremental table: {config.table}")
        
        # Pre-emptive memory check before writing
        if not self.memory_monitor.check_memory_threshold(0.60):
            self.logger.warning(f"⚠️ Memory high; pausing GC for {config.table}")
            self.memory_monitor.cleanup_memory()
            if not self.memory_monitor.check_memory_threshold(0.60):
                self.logger.error(f"❌ Aborting {config.table} due to memory")
                return 0
        
        # Downcast dtypes before writing to reduce memory usage
        df_optimized = _shrink_dtypes(df)
        
        # Streaming bucket storage (primary)
        bucket_rows = 0
        if config.bucket:
            self.logger.info(f"☁️ Storing to bucket: {config.table}")
            bucket_rows = self._write_parquet_streaming(df_optimized, config.table, config.schema)
            
            if bucket_rows == 0:
                self.logger.error(f"❌ Bucket storage failed for {config.table}")
                return 0
        
        # Streaming database write (secondary)
        try:
            self.logger.info(f"🗄️ Routing to databases: {config.databases}")
            db_rows = self._write_db_streaming(df_optimized, f"{config.schema}.{config.table}", config.unique_keys)
            
            if bucket_rows > 0 and db_rows > 0:
                self.logger.info(f"✅ Complete storage success for {config.table}")
                return min(bucket_rows, db_rows)
            elif bucket_rows > 0:
                self.logger.warning(f"⚠️ Partial success: bucket stored, database write failed for {config.table}")
                return bucket_rows  # Data is safe in bucket
            else:
                self.logger.error(f"❌ Complete storage failure for {config.table}")
                return 0
                
        except Exception as e:
            self.logger.error(f"Database streaming failed for {config.table}: {e}")
            if bucket_rows > 0:
                self.logger.info(f"💡 Data safely stored in bucket for {config.table}")
                return bucket_rows
            return 0

    def _write_parquet_streaming(self, df: pd.DataFrame, table: str, schema: str, rows_per_group: int = 100_000) -> int:
        """
        Stream DataFrame to bucket using parquet row groups to avoid memory spikes.
        
        Args:
            df: DataFrame to write
            table: Table name
            schema: Schema name
            rows_per_group: Number of rows per parquet row group
            
        Returns:
            Number of rows written
        """
        try:
            return self.bucket_adapter.store_data_streaming(
                df, table, schema, rows_per_group=rows_per_group
            )
        except Exception as e:
            self.logger.error(f"Failed to stream parquet for {table}: {e}")
            return 0

    def _write_db_streaming(self, df: pd.DataFrame, table_fq: str, pk_cols: list, chunk_rows: int = 50_000) -> int:
        """
        Stream DataFrame to database using chunked upserts to avoid memory spikes.
        
        Args:
            df: DataFrame to write
            table_fq: Fully qualified table name (schema.table)
            pk_cols: Primary key columns for upsert conflict resolution
            chunk_rows: Number of rows per chunk
            
        Returns:
            Number of rows written
        """
        try:
            # Determine conflict strategy based on table completeness
            table_name = table_fq.split('.')[1]
            conflict_strategy = self._get_conflict_strategy(table_name)
            
            return self.database_router.write_streaming(
                df, table_fq, pk_cols, chunk_rows=chunk_rows,
                memory_monitor=self.memory_monitor, conflict_strategy=conflict_strategy
            )
        except Exception as e:
            self.logger.error(f"Failed to stream database write for {table_fq}: {e}")
            return 0

    def _get_conflict_strategy(self, table_name: str) -> str:
        """
        Determine conflict resolution strategy based on table completeness.
        
        Tables with >100% completeness (like player_stats: 100.6%, snap_counts: 107.7%)
        need deduplication, so we use "do_update" strategy.
        
        Args:
            table_name: Name of the table
            
        Returns:
            Conflict strategy: "do_update" for >100% tables, "do_nothing" for others
        """
        # Find the table's completeness from comparison results
        for result in self.comparison_results:
            if result.table_name == table_name:
                if result.completeness_percentage > 100.0:
                    self.logger.info(f"🔄 Using dedupe strategy for {table_name} ({result.completeness_percentage:.1f}% completeness)")
                    return "do_update"
                break
        
        # Default strategy for normal backfill
        return "do_nothing"
    
    def _get_r_data_count(self, config: DataSourceConfig) -> int:
        """Get record count from R data source with memory-safe chunked loading."""
        try:
            # Memory check before R call for count
            self.memory_monitor.log_memory_usage("Before R Count", config.table)
            
            # Use chunked R count for play_by_play to avoid OOM but keep authoritative baseline
            # This ensures we get the true R baseline count (millions of rows) instead of
            # falling back to existing DB/bucket counts (which were only ~18K rows)
            if config.table == "play_by_play":
                return self._get_r_data_count_chunked(config)
            
            # Check if this is a known large table that needs special handling
            if self._is_large_table(config.table):
                return self._get_r_data_count_chunked(config)
            
            # For normal incremental tables, use R nrow() for accurate count without materialization
            historical_r_call = self._create_backfill_r_call(config.table)
            row_count = self._r_count_rows(historical_r_call)
            
            # Log count info without loading data
            if row_count > 100000:  # Log for large tables
                self.logger.info(f"📊 {config.table}: {row_count:,} rows (counted via nrow)")
                
                # Warn if this table might cause memory issues during processing
                if row_count > 500000:  # 500K+ rows threshold
                    self.logger.warning(f"⚠️ LARGE TABLE: {config.table} has {row_count:,} rows - will use streaming")
            
            return row_count
        except Exception as e:
            self.logger.warning(f"Failed to get R data count for {config.table}: {e}")
            return 0
    
    def _is_large_table(self, table_name: str) -> bool:
        """Check if table is known to be large and memory-intensive."""
        # Known large incremental tables from data_sources.py
        large_tables = {
            'participation',  # 433K rows, 86MB - the problematic one
            'play_by_play',   # Large table with 372 columns
            'player_stats',   # Large multi-stat table
            'wkly_rosters'    # Weekly rosters across all seasons
        }
        return table_name in large_tables
    
    def _get_r_data_count_chunked(self, config: DataSourceConfig) -> int:
        """
        Get R data count for large tables using chunked year-range loading.
        
        For very large tables like play_by_play, load data in year chunks to avoid
        memory issues while still getting accurate authoritative counts.
        """
        table_name = config.table
        self.logger.info(f"🔍 Getting chunked count for large table: {table_name}")
        
        # Strategy 1: Try chunked counting by year ranges
        try:
            total_count = self._get_chunked_count_by_years(table_name, config)
            if total_count > 0:
                self.logger.info(f"📊 Chunked count for {table_name}: {total_count:,} rows")
                return total_count
        except Exception as e:
            self.logger.warning(f"Chunked counting failed for {table_name}: {e}")
        
        # Strategy 2: Fall back to existing counts only if chunked counting failed
        self.logger.warning(f"⚠️ Chunked counting failed, falling back to existing counts for {table_name}")
        db_count = self._get_local_database_count(config)
        bucket_count = self._get_bucket_count(config)
        
        if db_count > 0 or bucket_count > 0:
            existing_count = max(db_count, bucket_count)
            self.logger.warning(f"📊 Using existing count for {table_name}: {existing_count:,} rows (chunked counting failed)")
            return existing_count
        
        # Strategy 3: Last resort - return 0 to indicate failure
        self.logger.error(f"❌ Could not get count for {table_name} - no chunked data, no existing data")
        return 0
    
    def _get_chunked_count_by_years(self, table_name: str, config: DataSourceConfig) -> int:
        """
        Get count using R nrow() calls to avoid materializing data in Python.
        
        Args:
            table_name: Name of the table
            config: Data source configuration
            
        Returns:
            Total row count across all year chunks
        """
        # Define year ranges for chunked counting based on table's min_year
        min_year = getattr(config, 'min_year', 1999)
        current_year = 2025  # Updated for current season
        
        # Create 1-year chunks for counting to avoid OOM (was 5-year)
        chunk_span = int(os.getenv("COUNT_CHUNK_YEARS", "1"))  # safety default
        year_chunks = []
        for start_year in range(min_year, current_year + 1, chunk_span):
            end_year = min(start_year + chunk_span - 1, current_year)
            year_chunks.append((start_year, end_year))
        
        self.logger.info(f"🔄 Chunked counting for {table_name}: {len(year_chunks)} chunks from {min_year} to {current_year}")
        
        total_count = 0
        successful_chunks = 0
        
        for start_year, end_year in year_chunks:
            try:
                # Create year-specific R call
                chunk_r_call = self._create_chunked_r_call(table_name, start_year, end_year)
                self.logger.debug(f"Chunk R call ({start_year}-{end_year}): {chunk_r_call}")
                
                # Use nrow() to count without materializing data
                chunk_count = self._r_count_rows(chunk_r_call)
                total_count += chunk_count
                successful_chunks += 1
                
                self.logger.info(f"📊 Chunk {start_year}-{end_year}: {chunk_count:,} rows")
                
            except Exception as e:
                self.logger.warning(f"Failed to count chunk {start_year}-{end_year} for {table_name}: {e}")
                # Continue with other chunks rather than failing completely
                continue
        
        if successful_chunks == 0:
            raise ValueError(f"No chunks successfully counted for {table_name}")
        
        self.logger.info(f"📊 Chunked counting complete for {table_name}: {total_count:,} rows from {successful_chunks}/{len(year_chunks)} chunks")
        return total_count
    
    def _r_count_rows(self, r_call_expression: str) -> int:
        """
        Ask R to return a scalar count (nrow) so we never materialize full data.
        
        Args:
            r_call_expression: R expression to count rows for
            
        Returns:
            Row count as integer
        """
        # Clear nflreadr cache before each chunk to prevent multi-year cached parquet blobs
        prelude = 'try({options(nflreadr.verbose=FALSE); nflreadr::.clear_cache()}, silent=TRUE); '
        nrow_call = prelude + f'nrow({r_call_expression})'
        self.logger.debug(f"R count call: {nrow_call}")
        result_df = execute_real_r_call(nrow_call, 'scalar_count')
        
        # Extract the scalar value from the DataFrame
        if isinstance(result_df, pd.DataFrame) and not result_df.empty:
            # Get the first value from the DataFrame and convert to Python int
            scalar_value = result_df.iloc[0, 0]
            
            # Robust type conversion for various pandas scalar types
            try:
                # Try direct conversion first
                if isinstance(scalar_value, (int, float)):
                    return int(scalar_value)
                # Handle pandas scalar types with item() method
                elif hasattr(scalar_value, 'item') and callable(getattr(scalar_value, 'item')):
                    return int(scalar_value.item())  # type: ignore
                # Handle string representations
                elif isinstance(scalar_value, str):
                    return int(float(scalar_value))
                # Last resort: convert to string then int
                else:
                    return int(str(scalar_value))
            except (ValueError, TypeError) as e:
                raise ValueError(f"Could not convert R result to integer: {scalar_value} (type: {type(scalar_value)})") from e
        else:
            raise ValueError(f"Failed to get row count from R call: {nrow_call}")
    
    def _create_chunked_r_call(self, table_name: str, start_year: int, end_year: int) -> str:
        """
        Create R call for a specific year range chunk.
        
        Args:
            table_name: Name of the table
            start_year: Start year for the chunk
            end_year: End year for the chunk
            
        Returns:
            R call string for the year range
        """
        # Create year range for R call
        if start_year == end_year:
            seasons_param = str(start_year)
        else:
            seasons_param = f"{start_year}:{end_year}"
        
        # Create chunked R calls for specific year ranges
        chunked_r_calls = {
            'play_by_play': f'load_pbp(seasons = {seasons_param}, file_type = "parquet")',
            'rosters': f'load_rosters(seasons = {seasons_param}, file_type = "parquet")',
            'player_stats': f'load_player_stats(seasons = {seasons_param}, stat_type = c("offense", "defense", "kicking"), file_type = "parquet")',
            'participation': f'load_participation(seasons = {seasons_param}, file_type = "parquet")',
            'nextgen': f'load_nextgen_stats(seasons = {seasons_param}, stat_type = c("passing", "receiving", "rushing"), file_type = "parquet")',
            'snap_counts': f'load_snap_counts(seasons = {seasons_param}, file_type = "parquet")',
            'pfr_adv_stats': f'load_pfr_advstats(seasons = {seasons_param})',
            'ftn_chart': f'load_ftn_charting(seasons = {seasons_param})',
            'wkly_rosters': f'load_rosters_weekly(seasons = {seasons_param}, file_type = "parquet")'
        }
        
        if table_name in chunked_r_calls:
            return chunked_r_calls[table_name]
        else:
            # Fallback for unknown tables
            return f'load_{table_name}(seasons = {seasons_param}, file_type = "parquet")'
    
    def _get_local_database_count(self, config: DataSourceConfig) -> int:
        """Get record count from local database."""
        try:
            if table_exists(self.db_service.engine, config.table, config.schema):
                return get_table_row_count(self.db_service.engine, config.table, config.schema)
            return 0
        except Exception as e:
            self.logger.warning(f"Failed to get local DB count for {config.table}: {e}")
            return 0
    
    def _get_bucket_count(self, config: DataSourceConfig) -> int:
        """Get record count from bucket storage."""
        try:
            if self.bucket_adapter.table_exists(config.table, config.schema):
                df = self.bucket_adapter.read_data(config.table, config.schema)
                return len(df)
            return 0
        except Exception as e:
            self.logger.warning(f"Failed to get bucket count for {config.table}: {e}")
            return 0
    
    def _get_table_config(self, table_name: str) -> Optional[DataSourceConfig]:
        """Get configuration for a specific table."""
        for group in DATA_SOURCE_GROUPS.values():
            if table_name in group:
                return group[table_name]
        return None
    
    def _validate_dependencies(self):
        """Validate that all required dependencies are available."""
        if not self.r_service.is_healthy:
            self.logger.warning("R service not healthy - some operations may fail")
        
        if not self.bucket_adapter._is_available():
            self.logger.warning("Bucket adapter not available - bucket operations will be skipped")
        
        try:
            # Test database connection
            with self.db_service.engine.connect():
                pass
        except Exception as e:
            self.logger.error(f"Database connection failed: {e}")
            raise
    
    def _create_summary(self,
                       comparison_results: List[DataComparisonResult],
                       eligible_tables: List[str],
                       success_count: int,
                       failed_tables: List[str],
                       start_time: datetime) -> BackfillSummary:
        """Create execution summary."""
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # Calculate total rows processed
        total_rows = 0
        for result in comparison_results:
            if result.table_name in eligible_tables and result.table_name not in failed_tables:
                total_rows += result.r_data_count
        
        return BackfillSummary(
            total_tables_analyzed=len(comparison_results),
            eligible_tables=len(eligible_tables),
            successfully_backfilled=success_count,
            failed_tables=failed_tables,
            total_rows_processed=total_rows,
            execution_time_seconds=execution_time
        )


def main():
    """
    Main entry point for incremental backfill script.
    
    Super straightforward - just run the script and it does its thing.
    """
    # Setup logging
    logger = get_logger('nflfastRv3.backfill_incremental_script')
    
    try:
        # Create and execute pipeline with default settings
        pipeline = BackfillIncrementalPipeline(logger=logger)
        
        # Execute backfill with sensible defaults:
        # - All incremental tables (the large ones that need historical backfill)
        # - 90% completeness threshold
        # - Actually perform backfill (not dry run)
        summary = pipeline.execute_backfill()
        
        # Print summary
        logger.info("=" * 60)
        logger.info("INCREMENTAL BACKFILL SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Tables Analyzed: {summary.total_tables_analyzed}")
        logger.info(f"Eligible for Backfill: {summary.eligible_tables}")
        logger.info(f"Successfully Backfilled: {summary.successfully_backfilled}")
        logger.info(f"Failed Tables: {len(summary.failed_tables)}")
        if summary.failed_tables:
            logger.info(f"Failed Table Names: {', '.join(summary.failed_tables)}")
        logger.info(f"Total Rows Processed: {summary.total_rows_processed:,}")
        logger.info(f"Execution Time: {summary.execution_time_seconds:.1f} seconds")
        logger.info("=" * 60)
        
        # Exit with appropriate code
        sys.exit(0 if len(summary.failed_tables) == 0 else 1)
        
    except Exception as e:
        logger.error(f"Incremental backfill script failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == '__main__':
    main()