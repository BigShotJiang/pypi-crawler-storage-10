"""
Bucket Adapter for S3/Sevalla Object Storage

Provides clean interface for bucket operations following V3 architecture constraints:
- Maximum 2 complexity points (DI + business logic)
- Simple dependency injection with fallbacks
- Supports both AWS S3 and Sevalla (S3-compatible)

Pattern: Minimum Viable Decoupling (2 complexity points)
Layer: 3 (Infrastructure)
"""

import os
import io
import tempfile
from typing import Optional, Dict, Any, Union
import pandas as pd
import boto3
from botocore.client import Config, BaseClient
from botocore.exceptions import ClientError, NoCredentialsError
from commonv2 import get_logger

# Import for streaming parquet writes
try:
    import pyarrow as pa
    import pyarrow.parquet as pq
    HAS_PYARROW = True
except ImportError:
    HAS_PYARROW = False

# Module-level logger following refactoring specs
_logger = get_logger('nflfastRv3.bucket')


class BucketAdapter:
    """
    S3/Sevalla bucket operations adapter.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    - DI with fallback (1 point)
    - Business logic (1 point)
    
    Supports both standard AWS S3 and Sevalla object storage.
    """
    
    def __init__(self, config=None, logger=None):
        """
        Initialize bucket adapter with optional configuration.
        
        Args:
            config: Optional bucket configuration dict
            logger: Optional logger instance (uses module logger if not provided)
        """
        # Simple DI with fallback (1 complexity point)
        self.config = config or self._get_bucket_config()
        self.logger = logger or _logger  # DI with module-level fallback
        
        # Business logic (1 complexity point)
        self.s3_client: Optional[BaseClient] = self._create_s3_client()
        self.bucket_name: Optional[str] = self.config.get('bucket_name')
        
        if not self.bucket_name:
            self.logger.warning("No bucket name configured - bucket operations will be disabled")
    
    def _get_env_with_fallbacks(self, *var_names: str) -> Optional[str]:
        """
        Get environment variable value checking multiple names in priority order.
        
        Args:
            *var_names: Variable names to check in priority order
            
        Returns:
            First non-None value found, or None if all are empty
        """
        for var_name in var_names:
            value = os.getenv(var_name)
            if value and value.strip():
                return value.strip()
        return None

    def _get_bucket_config(self) -> Dict[str, Any]:
        """
        Get bucket configuration from environment variables.
        
        Supports multiple naming conventions with fallbacks:
        1. Standard BUCKET_* variables
        2. SEVALLA_* variables 
        3. AWS_* variables (for access keys)
        
        Returns:
            Dict with bucket configuration
        """
        config = {
            'bucket_name': self._get_env_with_fallbacks(
                'BUCKET_NAME', 
                'SEVALLA_BUCKET_NAME'
            ),
            'endpoint_url': self._get_env_with_fallbacks(
                'BUCKET_ENDPOINT_URL', 
                'SEVALLA_BUCKET_ENDPOINT'
            ),
            'access_key': self._get_env_with_fallbacks(
                'BUCKET_ACCESS_KEY', 
                'AWS_ACCESS_KEY_ID',
                'SEVALLA_BUCKET_ACCESS_KEY_ID'
            ),
            'secret_key': self._get_env_with_fallbacks(
                'BUCKET_SECRET_KEY', 
                'AWS_SECRET_ACCESS_KEY',
                'SEVALLA_BUCKET_SECRET_ACCESS_KEY'
            ),
            'region': self._get_env_with_fallbacks(
                'BUCKET_REGION', 
                'SEVALLA_BUCKET_REGION'
            ) or 'us-east-1'
        }
        
        # Log which configuration source is being used (using module-level logger)
        if config['bucket_name']:
            if os.getenv('SEVALLA_BUCKET_NAME'):
                _logger.debug("Using SEVALLA bucket configuration")
            else:
                _logger.debug("Using standard BUCKET configuration")
        
        return config
    
    def _create_s3_client(self) -> Optional[BaseClient]:
        """
        Create S3 client for AWS S3 or Sevalla.
        
        Returns:
            boto3 S3 client configured for the target service, or None if creation fails
        """
        try:
            # Check if this is Sevalla (has custom endpoint)
            if self.config.get('endpoint_url'):
                self.logger.info(f"Using Sevalla object storage: {self.config['endpoint_url']}")
                return boto3.client(
                    's3',
                    endpoint_url=self.config['endpoint_url'],
                    aws_access_key_id=self.config['access_key'],
                    aws_secret_access_key=self.config['secret_key'],
                    config=Config(signature_version='s3v4'),
                    region_name=self.config.get('region', 'us-east-1')
                )
            else:
                # Standard AWS S3
                self.logger.info("Using AWS S3")
                client_kwargs = {
                    'service_name': 's3'
                }
                
                if self.config.get('access_key') and self.config.get('secret_key'):
                    client_kwargs.update({
                        'aws_access_key_id': self.config['access_key'],
                        'aws_secret_access_key': self.config['secret_key']
                    })
                
                if self.config.get('region'):
                    client_kwargs['region_name'] = self.config['region']
                
                return boto3.client(**client_kwargs)
                
        except Exception as e:
            self.logger.error(f"Failed to create S3 client: {e}")
            return None
    
    def store_data(self, df: pd.DataFrame, table_name: str, schema: str = 'raw_nflfastr') -> bool:
        """
        Store DataFrame in bucket (primary storage).
        
        Args:
            df: DataFrame to store
            table_name: Name of the table
            schema: Schema name for organization
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self._is_available():
            self.logger.warning(f"Bucket not available - skipping storage for {table_name}")
            return False
        
        try:
            # Create key path: schema/table_name/data.parquet
            key = f"{schema}/{table_name}/data.parquet"
            
            self.logger.debug(f"Storing {len(df):,} rows to bucket: {key}")
            
            # Convert DataFrame to parquet buffer
            parquet_buffer = df.to_parquet(index=False, engine='pyarrow')
            
            # Upload to bucket (s3_client guaranteed not None by _is_available check)
            assert self.s3_client is not None and self.bucket_name is not None
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=key,
                Body=parquet_buffer,
                ContentType='application/octet-stream'
            )
            
            self.logger.debug(f"Bucket storage completed: {len(df):,} rows → {key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to store {table_name} in bucket: {e}")
            return False
    
    def store_data_streaming(self, df: pd.DataFrame, table_name: str, schema: str = 'raw_nflfastr',
                           year: Optional[int] = None, rows_per_group: int = 100_000) -> int:
        """
        Store DataFrame in bucket using streaming parquet writes with row groups.
        
        This method writes data in smaller chunks to avoid memory spikes during large DataFrame operations.
        
        Args:
            df: DataFrame to store
            table_name: Name of the table
            schema: Schema name for organization
            year: Optional year for partitioned storage
            rows_per_group: Number of rows per parquet row group
            
        Returns:
            int: Number of rows written, 0 if failed
        """
        if not self._is_available():
            self.logger.warning(f"Bucket not available - skipping streaming storage for {table_name}")
            return 0
        
        if not HAS_PYARROW:
            self.logger.warning(f"PyArrow not available - falling back to regular storage for {table_name}")
            return len(df) if self.store_data(df, table_name, schema) else 0
        
        try:
            # Import pyarrow within the method to handle import errors gracefully
            import pyarrow as pa
            import pyarrow.parquet as pq
            
            # Create key path with optional year partitioning
            if year:
                key = f"{schema}/{table_name}/season={year}/{table_name}_{year}.parquet"
            else:
                key = f"{schema}/{table_name}/data.parquet"
            
            self.logger.debug(f"Streaming {len(df):,} rows to bucket: {key} (row groups: {rows_per_group:,})")
            
            # Create temporary file for streaming parquet write
            with tempfile.NamedTemporaryFile(delete=False, suffix='.parquet') as temp_file:
                temp_path = temp_file.name
            
            try:
                # Write parquet file with streaming row groups
                total_rows = len(df)
                written_rows = 0
                
                # Convert pandas schema to pyarrow schema once
                pa_schema = pa.Schema.from_pandas(df, preserve_index=False)
                
                with pq.ParquetWriter(temp_path, pa_schema) as writer:
                    for start in range(0, total_rows, rows_per_group):
                        end = min(start + rows_per_group, total_rows)
                        batch_df = df.iloc[start:end].copy()
                        
                        # Convert batch to pyarrow table
                        batch_table = pa.Table.from_pandas(batch_df, preserve_index=False)
                        writer.write_table(batch_table)
                        
                        written_rows += len(batch_df)
                        
                        # Clean up batch from memory
                        del batch_df, batch_table
                
                # Upload the completed parquet file to bucket
                assert self.s3_client is not None and self.bucket_name is not None
                with open(temp_path, 'rb') as f:
                    self.s3_client.put_object(
                        Bucket=self.bucket_name,
                        Key=key,
                        Body=f,
                        ContentType='application/octet-stream'
                    )
                
                self.logger.debug(f"Streaming bucket storage completed: {written_rows:,} rows → {key}")
                return written_rows
                
            finally:
                # Clean up temporary file
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass
            
        except Exception as e:
            self.logger.error(f"Failed to stream {table_name} to bucket: {e}")
            return 0
    
    def get_temp_local_path(self, table_name: str, year: Optional[int] = None) -> str:
        """
        Get temporary local path for staging parquet files.
        
        Args:
            table_name: Name of the table
            year: Optional year for naming
            
        Returns:
            str: Temporary file path
        """
        suffix = f"_{year}" if year else ""
        return tempfile.mktemp(suffix=f"_{table_name}{suffix}.parquet")
    
    def upload_file(self, local_path: str, bucket_key: str) -> bool:
        """
        Upload a local file to bucket.
        
        Args:
            local_path: Path to local file
            bucket_key: Key path in bucket
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self._is_available():
            self.logger.warning(f"Bucket not available - skipping upload for {bucket_key}")
            return False
        
        try:
            assert self.s3_client is not None and self.bucket_name is not None
            with open(local_path, 'rb') as f:
                self.s3_client.put_object(
                    Bucket=self.bucket_name,
                    Key=bucket_key,
                    Body=f,
                    ContentType='application/octet-stream'
                )
            
            self.logger.debug(f"File upload completed: {local_path} → {bucket_key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to upload file {local_path} to {bucket_key}: {e}")
            return False
    
    def read_data(self, table_name: str, schema: str = 'raw_nflfastr') -> pd.DataFrame:
        """
        Read DataFrame from bucket.
        
        Args:
            table_name: Name of the table
            schema: Schema name for organization
            
        Returns:
            DataFrame: Data from bucket, empty DataFrame if not found
        """
        if not self._is_available():
            self.logger.warning(f"Bucket not available - returning empty DataFrame for {table_name}")
            return pd.DataFrame()
        
        try:
            # Create key path: schema/table_name/data.parquet
            key = f"{schema}/{table_name}/data.parquet"
            
            self.logger.debug(f"Reading from bucket: {key}")
            
            # Download from bucket (s3_client guaranteed not None by _is_available check)
            assert self.s3_client is not None and self.bucket_name is not None
            response = self.s3_client.get_object(
                Bucket=self.bucket_name,
                Key=key
            )
            
            # Read parquet data from streaming body
            parquet_bytes = response['Body'].read()
            df = pd.read_parquet(io.BytesIO(parquet_bytes), engine='pyarrow')
            
            self.logger.debug(f"Bucket read completed: {len(df):,} rows ← {key}")
            return df
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'NoSuchKey':
                self.logger.info(f"No data found in bucket for {table_name}")
            else:
                self.logger.error(f"Failed to read {table_name} from bucket: {e}")
            return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Failed to read {table_name} from bucket: {e}")
            return pd.DataFrame()
    
    def list_tables(self, schema: str = 'raw_nflfastr') -> list:
        """
        List tables available in bucket for given schema.
        
        Args:
            schema: Schema name to list
            
        Returns:
            List of table names
        """
        if not self._is_available():
            return []
        
        try:
            # List objects with schema prefix (s3_client guaranteed not None by _is_available check)
            assert self.s3_client is not None and self.bucket_name is not None
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=f"{schema}/",
                Delimiter='/'
            )
            
            tables = []
            if 'CommonPrefixes' in response:
                for prefix in response['CommonPrefixes']:
                    # Extract table name from prefix like "schema/table_name/"
                    prefix_path = prefix['Prefix'].rstrip('/')
                    table_name = prefix_path.split('/')[-1]
                    tables.append(table_name)
            
            self.logger.debug(f"Found {len(tables)} tables in bucket schema '{schema}': {tables}")
            return tables
            
        except Exception as e:
            self.logger.error(f"Failed to list tables in bucket: {e}")
            return []
    
    def table_exists(self, table_name: str, schema: str = 'raw_nflfastr') -> bool:
        """
        Check if table exists in bucket.
        
        Args:
            table_name: Name of the table
            schema: Schema name
            
        Returns:
            bool: True if table exists, False otherwise
        """
        if not self._is_available():
            return False
        
        try:
            key = f"{schema}/{table_name}/data.parquet"
            # s3_client guaranteed not None by _is_available check
            assert self.s3_client is not None and self.bucket_name is not None
            self.s3_client.head_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError:
            return False
        except Exception as e:
            self.logger.error(f"Error checking if table {table_name} exists: {e}")
            return False
    
    def _is_available(self) -> bool:
        """
        Check if bucket operations are available.
        
        Returns:
            bool: True if bucket is configured and accessible
        """
        return (
            self.s3_client is not None and 
            self.bucket_name is not None and
            self.bucket_name.strip() != ""
        )
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get bucket adapter status for debugging.
        
        Returns:
            Dict with status information
        """
        status = {
            'available': self._is_available(),
            'bucket_name': self.bucket_name,
            'endpoint_url': self.config.get('endpoint_url'),
            'has_credentials': bool(self.config.get('access_key')),
            'client_created': self.s3_client is not None
        }
        
        if self._is_available():
            try:
                # Test bucket access (s3_client guaranteed not None by _is_available check)
                assert self.s3_client is not None and self.bucket_name is not None
                self.s3_client.head_bucket(Bucket=self.bucket_name)
                status['bucket_accessible'] = True
            except Exception as e:
                status['bucket_accessible'] = False
                status['bucket_error'] = str(e)
        
        return status


def get_bucket_adapter(config=None, logger=None) -> BucketAdapter:
    """
    Factory function to create bucket adapter with optional overrides.
    
    Args:
        config: Optional bucket configuration
        logger: Optional logger instance
        
    Returns:
        BucketAdapter instance
    """
    return BucketAdapter(config=config, logger=logger)


__all__ = ['BucketAdapter', 'get_bucket_adapter']
