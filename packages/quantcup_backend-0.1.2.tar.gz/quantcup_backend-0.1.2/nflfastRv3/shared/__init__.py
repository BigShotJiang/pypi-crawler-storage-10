"""
NFLfastRv3 Shared Infrastructure

Layer 3: Infrastructure components
- Database singleton with DI support
- R integration service
- Validation utilities

Pattern: Module-level singletons with DI override capability
Complexity: 1 point each (simple resource management)
"""

from .database import NFLfastRDatabase
from .r_integration import RIntegrationService

__all__ = [
    'NFLfastRDatabase',
    'RIntegrationService'
]
