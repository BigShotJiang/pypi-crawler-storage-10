"""
Database Router for Table-Driven Routing

Simplified router following REFACTORING_SPECS.md constraints:
- Maximum 2 complexity points (DI + routing logic)
- Simple dependency injection with fallbacks
- Clean separation of concerns

Pattern: Minimum Viable Decoupling (2 complexity points)
Layer: 3 (Infrastructure)

Refactored from complex implementation to meet specs compliance.
"""

import os
import time
from typing import List, Dict, Any, Optional
import pandas as pd
from sqlalchemy import create_engine, Table, MetaData
from sqlalchemy.dialects.postgresql import insert as pg_insert
import sqlalchemy as sa
from commonv2 import get_logger
from commonv2.core.errors import DataValidationError
from .database import NFLfastRDatabase


class DatabaseRouter:
    """
    Simplified table-driven database routing.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    - DI with fallback (1 point)
    - Routing logic (1 point)
    
    Refactored to comply with REFACTORING_SPECS.md constraints.
    """
    
    def __init__(self, db_service=None, logger=None):
        """
        Initialize database router with optional dependencies.
        
        Args:
            db_service: Optional database service (uses singleton if not provided)
            logger: Optional logger instance (uses module logger if not provided)
        """
        # Simple DI with fallback (1 complexity point)
        self.db_service = db_service or NFLfastRDatabase.get_instance()
        self.logger = logger or get_logger('nflfastRv3.router')
        self._engines = {}  # Cache for database engines

    def route_to_databases(self, df: pd.DataFrame, config) -> bool:
        """
        Route DataFrame to configured databases with simplified logic.
        
        Simplified approach following REFACTORING_SPECS.md:
        1. Direct orchestration (no intermediary layers)
        2. Simple if/else logic (no complex strategy pattern)
        3. Maximum 2 layers depth
        
        Args:
            df: DataFrame to route
            config: DataSourceConfig with routing information and strategy
            
        Returns:
            bool: True if at least one database succeeded, False otherwise
        """
        if df.empty:
            self.logger.info(f"Skipping routing for {config.table} - no data")
            return True
        
        target_databases = config.databases or ['NFLFASTR_DB']
        success_count = 0
        
        self.logger.info(f"Routing {config.table} with strategy '{config.strategy}' to {len(target_databases)} databases: {target_databases}")
        
        for database in target_databases:
            try:
                # Apply simple transforms
                transformed_df = self._apply_simple_transforms(df, config, database)
                
                # Get engine
                engine = self._get_engine_for_database(database)
                if engine is None:
                    self.logger.warning(f"Skipping {database} - engine unavailable")
                    continue
                
                # Simple strategy selection (2 options only)
                rows_written = 0
                if config.strategy == 'incremental':
                    rows_written = self._execute_incremental_load(transformed_df, config, engine)
                elif config.strategy == 'full_refresh':
                    rows_written = self._execute_full_refresh(transformed_df, config, engine)
                else:
                    self.logger.error(f"Unknown strategy '{config.strategy}' for {config.table}")
                    continue
                
                if rows_written > 0:
                    self.logger.info(f"✓ Routed {rows_written:,} rows to {database}: {config.table}")
                    success_count += 1
                else:
                    self.logger.warning(f"No rows written to {database} for {config.table}")
                
            except Exception as e:
                self.logger.error(f"Failed to route {config.table} to {database}: {e}")
                continue
        
        if success_count == 0:
            self.logger.error(f"Failed to route {config.table} to any database")
            return False
        elif success_count < len(target_databases):
            self.logger.warning(f"Partial routing success for {config.table}: {success_count}/{len(target_databases)}")
        
        return success_count > 0

    def _execute_incremental_load(self, df: pd.DataFrame, config, engine) -> int:
        """Execute incremental load using CommonV2."""
        try:
            from commonv2._data.database import execute_incremental_load
            
            table_config = {
                'table': config.table,
                'schema': config.schema,
                'unique_keys': config.unique_keys,
                'chunksize': getattr(config, 'chunksize', None) or 1000
            }
            
            success = execute_incremental_load(
                df=df,
                engine=engine,
                table_name=config.table,
                schema=config.schema,
                table_config=table_config,
                logger=self.logger
            )
            return len(df) if success else 0
            
        except Exception as e:
            self.logger.warning(f"CommonV2 incremental load failed: {e}")
            # Fallback to db_service for local database
            if engine == self.db_service.engine:
                return self.db_service.upsert_dataframe(
                    df, config.table, config.schema, strategy='incremental'
                )
            raise

    def _execute_full_refresh(self, df: pd.DataFrame, config, engine) -> int:
        """Execute full refresh using CommonV2."""
        try:
            from commonv2._data.database import execute_full_refresh
            
            table_config = {
                'table': config.table,
                'schema': config.schema,
                'unique_keys': config.unique_keys,
                'chunksize': getattr(config, 'chunksize', None) or 10000
            }
            
            success = execute_full_refresh(
                df=df,
                engine=engine,
                table_name=config.table,
                schema=config.schema,
                table_config=table_config,
                schema_changes=None,  # Let CommonV2 handle schema detection
                logger=self.logger
            )
            return len(df) if success else 0
            
        except Exception as e:
            self.logger.warning(f"CommonV2 full refresh failed: {e}")
            # Fallback to db_service for local database
            if engine == self.db_service.engine:
                return self.db_service.upsert_dataframe(
                    df, config.table, config.schema, strategy='full_refresh'
                )
            raise

    def write_streaming(self, df: pd.DataFrame, table_fq: str, pk_cols: List[str],
                       chunk_rows: int = 50_000, memory_monitor=None,
                       conflict_strategy: str = "do_nothing") -> int:
        """
        Write DataFrame to database in chunks with UPSERT (dedupe guard).
        
        This method chunks the DataFrame and uses PostgreSQL upsert to handle duplicates,
        preventing memory spikes from large DataFrame operations.
        
        Args:
            df: DataFrame to write
            table_fq: Fully qualified table name (schema.table)
            pk_cols: Primary key columns for upsert conflict resolution
            chunk_rows: Number of rows per chunk
            memory_monitor: Optional memory monitor for cleanup
            conflict_strategy: Strategy for handling conflicts ("do_nothing" or "do_update")
            
        Returns:
            int: Number of rows written
        """
        if df.empty:
            return 0
        
        try:
            schema, table = table_fq.split('.', 1)
        except ValueError:
            raise ValueError(f"Invalid table format '{table_fq}'. Expected 'schema.table'")
        
        # Use the primary database engine (NFLFASTR_DB)
        engine = self.db_service.engine
        
        try:
            # Get table metadata for upsert
            meta = MetaData()
            table_obj = Table(table, meta, schema=schema, autoload_with=engine)
            
            total_rows = len(df)
            written_rows = 0
            
            self.logger.debug(f"Streaming {total_rows:,} rows to {table_fq} in chunks of {chunk_rows:,}")
            
            with engine.begin() as conn:
                for start in range(0, total_rows, chunk_rows):
                    end = min(start + chunk_rows, total_rows)
                    chunk_df = df.iloc[start:end].copy()
                    
                    # Downcast numeric types before shipping to database
                    chunk_df = self._downcast_dtypes(chunk_df)
                    
                    # Convert to records for bulk insert
                    rows = chunk_df.to_dict(orient='records')
                    
                    # Create upsert statement
                    stmt = pg_insert(table_obj).values(rows)
                    
                    # Handle conflicts based on strategy
                    if conflict_strategy == "do_update":
                        # "Last write wins" - update existing records
                        update_dict = {c.name: stmt.excluded[c.name] for c in table_obj.columns if c.name not in pk_cols}
                        stmt = stmt.on_conflict_do_update(
                            index_elements=pk_cols,
                            set_=update_dict
                        )
                    else:
                        # Default: do nothing on conflict (pure backfill mode)
                        stmt = stmt.on_conflict_do_nothing(index_elements=pk_cols)
                    
                    # Execute the chunk
                    conn.execute(stmt)
                    written_rows += len(rows)
                    
                    # Clean up chunk from memory
                    del chunk_df, rows
                    
                    # Optional memory cleanup
                    if memory_monitor:
                        memory_monitor.cleanup_memory()
                    
                    self.logger.debug(f"Written chunk {start:,}-{end:,} to {table_fq}")
            
            self.logger.info(f"Streaming write completed: {written_rows:,} rows → {table_fq}")
            return written_rows
            
        except Exception as e:
            self.logger.error(f"Failed to stream write to {table_fq}: {e}")
            return 0

    def _downcast_dtypes(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Downcast DataFrame dtypes to reduce memory usage before database write.
        
        Args:
            df: DataFrame to downcast
            
        Returns:
            DataFrame with downcasted dtypes
        """
        df_downcasted = df.copy()
        
        # Downcast float64 to float32
        for col in df_downcasted.select_dtypes(include=['float64']).columns:
            df_downcasted[col] = df_downcasted[col].astype('float32')
        
        # Downcast int64 to int32 where safe
        for col in df_downcasted.select_dtypes(include=['int64']).columns:
            col_max = df_downcasted[col].max()
            col_min = df_downcasted[col].min()
            
            # Check if values fit in int32 range
            if col_max <= 2_147_483_647 and col_min >= -2_147_483_648:
                df_downcasted[col] = df_downcasted[col].astype('int32')
        
        return df_downcasted

    def _get_engine_for_database(self, database_prefix: str):
        """
        Get database engine with lazy connection pattern.
        
        Simple mapping following REFACTORING_SPECS.md principles:
        - 1 complexity point (simple method)
        - Direct environment variable mapping
        
        Args:
            database_prefix: Database prefix (NFLFASTR_DB or SEVALLA_QUANTCUP_DB)
            
        Returns:
            SQLAlchemy engine for the specified database
        """
        # Check cache first
        if database_prefix in self._engines:
            return self._engines[database_prefix]
        
        # Create engine based on database type
        if database_prefix == "NFLFASTR_DB":
            engine = self.db_service.engine
        elif database_prefix == "SEVALLA_QUANTCUP_DB":
            engine = self._create_sevalla_engine()
            if engine is None:
                self.logger.warning(f"Failed to create engine for {database_prefix}")
                return None
        else:
            raise ValueError(f"Unknown database prefix: {database_prefix}")
        
        # Cache the engine only if successfully created
        if engine is not None:
            self._engines[database_prefix] = engine
        return engine

    def _create_sevalla_engine(self):
        """
        Create SQLAlchemy engine for SEVALLA database with simple retry logic.
        
        Simplified version with basic retry logic.
        
        Returns:
            SQLAlchemy engine if connection successful, None if failed
        """
        host = os.getenv('SEVALLA_QUANTCUP_DB_HOST', 'localhost')
        port = os.getenv('SEVALLA_QUANTCUP_DB_PORT', '5432')
        user = os.getenv('SEVALLA_QUANTCUP_DB_USER', 'postgres')
        password = os.getenv('SEVALLA_QUANTCUP_DB_PASSWORD', '')
        database = os.getenv('SEVALLA_QUANTCUP_DB_NAME', 'quantcup')
        
        connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        
        try:
            engine = create_engine(
                connection_string,
                connect_args={'connect_timeout': 10},
                pool_pre_ping=True,
                pool_recycle=3600
            )
            
            # Test connection
            with engine.connect() as conn:
                conn.execute(sa.text("SELECT 1"))
            
            self.logger.info(f"✓ SEVALLA database connection successful: {host}:{port}/{database}")
            return engine
            
        except Exception as e:
            self.logger.warning(f"⚠️ SEVALLA database connection failed: {host}:{port}/{database} - {e}")
            return None

    def _apply_simple_transforms(self, df: pd.DataFrame, config, database: str) -> pd.DataFrame:
        """
        Apply simple database-specific transforms.
        
        Simplified transform logic with basic if/else instead of complex patterns.
        
        Args:
            df: Source DataFrame
            config: DataSourceConfig with transform information
            database: Target database identifier
            
        Returns:
            DataFrame: Transformed DataFrame
        """
        transforms = config.transforms.get(database, [])
        
        if not transforms:
            return df.copy()
        
        self.logger.debug(f"Applying {len(transforms)} transforms to {config.table} -> {database}")
        
        transformed_df = df.copy()
        
        for transform_name in transforms:
            try:
                # Simple transform logic
                if transform_name in ['STANDARDIZE_TEAMS', 'standardize_team_names', 'STANDARDIZE_TEAM_NAMES']:
                    transformed_df = self._standardize_teams_simple(transformed_df)
                elif transform_name in ['PARSE_DATES', 'parse_dates']:
                    transformed_df = self._parse_dates_simple(transformed_df)
                elif transform_name in ['ADD_METADATA', 'add_metadata']:
                    transformed_df = self._add_metadata_simple(transformed_df)
                else:
                    self.logger.warning(f"Unknown transform: {transform_name}")
                    
            except Exception as e:
                self.logger.error(f"Failed to apply transform '{transform_name}': {e}")
                continue
        
        return transformed_df

    def _standardize_teams_simple(self, df: pd.DataFrame) -> pd.DataFrame:
        """Simple team name standardization."""
        try:
            from commonv2.domain.adapters import TeamNameStandardizer
            standardizer = TeamNameStandardizer()
            df_transformed = df.copy()
            
            team_columns = ['home_team', 'away_team', 'team', 'team_abbr', 'posteam', 'defteam']
            for col in team_columns:
                if col in df_transformed.columns:
                    df_transformed = standardizer.standardize_dataframe_column(
                        df_transformed, col, output_format='abbr'
                    )
            return df_transformed
            
        except ImportError:
            self.logger.warning("CommonV2 TeamNameStandardizer not available")
            return df

    def _parse_dates_simple(self, df: pd.DataFrame) -> pd.DataFrame:
        """Simple date parsing."""
        df_transformed = df.copy()
        date_columns = ['game_date', 'gameday', 'date', 'birth_date', 'loaded_at']
        
        for col in date_columns:
            if col in df_transformed.columns:
                try:
                    df_transformed[col] = pd.to_datetime(df_transformed[col], errors='coerce')
                except Exception as e:
                    self.logger.warning(f"Failed to parse dates in column {col}: {e}")
        
        return df_transformed

    def _add_metadata_simple(self, df: pd.DataFrame) -> pd.DataFrame:
        """Simple metadata addition."""
        from datetime import datetime
        df_transformed = df.copy()
        
        if 'loaded_at' not in df_transformed.columns:
            df_transformed['loaded_at'] = datetime.now()
        if 'processed_by' not in df_transformed.columns:
            df_transformed['processed_by'] = 'nflfastRv3'
        
        return df_transformed


def get_database_router(db_service=None, logger=None) -> DatabaseRouter:
    """
    Factory function to create database router with optional overrides.
    
    Args:
        db_service: Optional database service
        logger: Optional logger instance
        
    Returns:
        DatabaseRouter instance
    """
    return DatabaseRouter(db_service=db_service, logger=logger)


__all__ = ['DatabaseRouter', 'get_database_router']
