"""
NFLfastR Database Infrastructure

Pattern: Module-level singleton with DI support
Complexity: 1 point (simple resource management)
Layer: 3 (Infrastructure - no further calls)

Provides clean database interface with dependency injection
support for testing while maintaining singleton behavior.

Performance optimized using CommonV2 database utilities.
"""

import os
from sqlalchemy import inspect
from commonv2 import get_logger
from commonv2._data.database import upsert_dataframe as commonv2_upsert, get_table_row_count, table_exists, create_db_engine_from_env
import pandas as pd


class NFLfastRDatabase:
    """
    Infrastructure layer - database interface.
    
    Pattern: Module-level singleton with DI override for testing
    Complexity: 1 point
    Depth: 0 layers (direct infrastructure calls)
    
    Features:
    - Singleton with DI override capability
    - Simple upsert operations
    - Connection management
    - No complex patterns or abstractions
    """
    
    _instance = None
    
    @classmethod
    def get_instance(cls, engine=None):
        """
        Get singleton instance with DI override for testing.
        
        Args:
            engine: Optional SQLAlchemy engine override for testing
            
        Returns:
            NFLfastRDatabase: Singleton instance
        """
        if cls._instance is None or engine is not None:
            cls._instance = cls(engine)
        return cls._instance
    
    def __init__(self, engine=None):
        """
        Initialize database service.
        
        Args:
            engine: Optional SQLAlchemy engine (for testing)
        """
        self.logger = get_logger('nflfastRv3.database')
        self.engine = engine or self._create_engine()
    
    def _create_engine(self):
        """Create database engine using commonv2 centralized configuration."""
        return create_db_engine_from_env('NFLFASTR_DB', logger=self.logger)
    
    def upsert_dataframe(self, df, table_name, schema='raw_nflfastr', strategy=None):
        """
        Intelligent upsert operation using CommonV2 database utilities.
        
        Strategy:
        - If strategy='incremental': Use CommonV2's execute_incremental_load
        - If strategy='full_refresh': Use CommonV2's execute_full_refresh
        - If strategy=None: Use original heuristic logic (large datasets, constraints, etc.)
        
        Args:
            df: Pandas DataFrame to upsert
            table_name: Target table name
            schema: Target schema (default: 'raw_nflfastr')
            strategy: Optional strategy override ('incremental' or 'full_refresh')
            
        Returns:
            int: Number of rows processed
        """
        if df.empty:
            self.logger.warning(f"Empty DataFrame for {schema}.{table_name}")
            return 0
        
        row_count = len(df)
        
        # NEW: Config-driven strategy override
        if strategy == 'incremental':
            self.logger.info(f"Using incremental strategy for {schema}.{table_name} ({row_count:,} rows)")
            from commonv2._data.database import execute_incremental_load
            
            table_config = {
                'table': table_name,
                'schema': schema,
                'unique_keys': [],  # Will be auto-detected
                'chunksize': 1000
            }
            
            success = execute_incremental_load(
                df=df,
                engine=self.engine,
                table_name=table_name,
                schema=schema,
                table_config=table_config,
                logger=self.logger
            )
            return row_count if success else 0
            
        elif strategy == 'full_refresh':
            self.logger.info(f"Using full_refresh strategy for {schema}.{table_name} ({row_count:,} rows)")
            from commonv2._data.database import execute_full_refresh
            
            table_config = {
                'table': table_name,
                'schema': schema,
                'unique_keys': [],  # Will be auto-detected
                'chunksize': 10000
            }
            
            success = execute_full_refresh(
                df=df,
                engine=self.engine,
                table_name=table_name,
                schema=schema,
                table_config=table_config,
                logger=self.logger
            )
            return row_count if success else 0
        
        # Original heuristic logic when no strategy specified
        table = table_exists(
            engine=self.engine,
            table_name=table_name,
            schema=schema,
            logger=self.logger
        )
        
        # Strategy 1: Large datasets - use CommonV2's bulk loading with connection recovery
        if row_count >= 5000:
            self.logger.info(f"Large dataset detected ({row_count:,} rows), using CommonV2 bulk loading strategy...")
            try:
                from commonv2._data.database import execute_full_refresh
                success = execute_full_refresh(
                    df=df,
                    engine=self.engine,
                    table_name=table_name,
                    schema=schema,
                    chunk_size=1000,
                    logger=self.logger
                )
                if success:
                    self.logger.info(f"✓ CommonV2 bulk loading complete: {row_count:,} rows processed in {schema}.{table_name}")
                    return row_count
                else:
                    raise Exception("CommonV2 bulk loading returned False")
            except Exception as e:
                self.logger.warning(f"CommonV2 bulk loading failed: {e}")
                # Ensure clean connection state after failure
                try:
                    self.engine.dispose()
                    self.logger.debug("Connection pool disposed after CommonV2 failure")
                except:
                    pass
                # Fall through to Strategy 2
        
        # Strategy 2: Try true upsert for existing tables with constraints
        if table:
            try:
                rows_affected = commonv2_upsert(
                    df=df,
                    engine=self.engine,
                    table_name=table_name,
                    schema=schema,
                    chunk_size=1000,
                    logger=self.logger
                )
                self.logger.info(f"✓ CommonV2 upsert complete: {rows_affected:,} rows affected in {schema}.{table_name}")
                return rows_affected
            except Exception as e:
                if "no PRIMARY KEY or UNIQUE constraints" in str(e):
                    self.logger.debug(f"Table has no constraints, using bulk replacement strategy: {e}")
                    # Fall through to Strategy 3
                else:
                    self.logger.warning(f"CommonV2 upsert failed: {e}")
                    # Fall through to Strategy 3
        
        # Strategy 3: Optimized pandas bulk insert/replace
        self.logger.info(f"Using optimized pandas strategy for {row_count:,} rows...")
        try:
            # Use chunked approach for better performance
            chunk_size = 5000 if row_count > 10000 else 1000
            
            if row_count <= chunk_size:
                # Single chunk
                df.to_sql(
                    table_name, 
                    self.engine, 
                    schema=schema,
                    if_exists='replace', 
                    index=False,
                    chunksize=chunk_size
                )
            else:
                # Multi-chunk processing
                self.logger.info(f"Processing in {chunk_size:,} row chunks...")
                for i in range(0, len(df), chunk_size):
                    chunk = df.iloc[i:i + chunk_size]
                    method = 'replace' if i == 0 else 'append'
                    chunk.to_sql(
                        table_name, 
                        self.engine, 
                        schema=schema,
                        if_exists=method, 
                        index=False,
                        chunksize=1000
                    )
                    chunk_num = (i // chunk_size) + 1
                    total_chunks = (len(df) - 1) // chunk_size + 1
                    self.logger.debug(f"Processed chunk {chunk_num}/{total_chunks}")
            
            self.logger.info(f"✓ Optimized pandas strategy complete: {row_count:,} rows written to {schema}.{table_name}")
            return row_count
            
        except Exception as e:
            self.logger.error(f"All strategies failed for {schema}.{table_name}: {e}")
            raise
    
    def query_dataframe(self, query, params=None):
        """
        Simple query operation.
        
        Args:
            query: SQL query string
            params: Optional query parameters
            
        Returns:
            pd.DataFrame: Query results
        """
        try:
            df = pd.read_sql(query, self.engine, params=params)
            self.logger.debug(f"Query returned {len(df):,} rows")
            return df
        except Exception as e:
            self.logger.error(f"Query failed: {e}")
            raise
    
    def get_table_names(self, schema='raw_nflfastr'):
        """
        Get list of tables in schema.
        
        Args:
            schema: Schema name to inspect
            
        Returns:
            list: Table names in schema
        """
        inspector = inspect(self.engine)
        tables = inspector.get_table_names(schema=schema)
        self.logger.debug(f"Found {len(tables)} tables in {schema}")
        return tables
    
    def get_row_count(self, table_name, schema='raw_nflfastr'):
        """
        Get row count for table using CommonV2 optimized method.
        
        Args:
            table_name: Table name
            schema: Schema name
            
        Returns:
            int: Number of rows in table
        """
        try:
            # Use CommonV2's optimized row count method
            return get_table_row_count(
                engine=self.engine,
                table_name=table_name,
                schema=schema,
                logger=self.logger
            )
        except Exception as e:
            self.logger.warning(f"CommonV2 get_table_row_count failed, using fallback: {e}")
            # Fallback method
            if not table_exists(
                engine=self.engine,
                table_name=table_name,
                schema=schema,
                logger=self.logger
            ):
                return 0
            
            query = f"SELECT COUNT(*) as count FROM {schema}.{table_name}"
            result = self.query_dataframe(query)
            return result.iloc[0]['count']


# Module-level convenience function for simple usage
def get_database(engine=None):
    """
    Get database instance - convenience function.
    
    Args:
        engine: Optional engine override for testing
        
    Returns:
        NFLfastRDatabase: Database service instance
    """
    return NFLfastRDatabase.get_instance(engine)
