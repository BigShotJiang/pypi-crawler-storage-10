"""
Simplified Data Source Configuration for nflfastRv3

Following REFACTORING_SPECS.md:
- Simple data structures (no complex patterns)
- Maximum 5 complexity points per module
- Easy to understand and maintain

Migrated from nflfastRv2 with architectural simplification.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field

from commonv2 import get_logger
from commonv2.core.config import DatabasePrefixes, TransformNames, SchemaNames

# Module-level logger following REFACTORING_SPECS.md pattern
_logger = get_logger('nflfastRv3.features.data_pipeline.config.data_sources')


@dataclass
class DataSourceConfig:
    """
    Enhanced data source configuration with V2 bucket-first + routing parity.
    
    Pattern: Enhanced dataclass (3 complexity points)
    Provides complete V2 functional equivalence with bucket-first architecture.
    
    Bucket-First Architecture:
    - bucket: All tables go to S3/Sevalla bucket FIRST (primary storage)
    - databases: List of target databases (secondary storage)
    - transforms: Per-database transforms for production data
    """
    r_call: str
    table: str
    schema: str = SchemaNames.RAW_NFLFASTR
    unique_keys: List[str] = field(default_factory=list)
    strategy: str = 'incremental'  # 'incremental' or 'full_refresh'
    
    # V2 parity fields for complete functional equivalence
    min_year: Optional[int] = None
    numeric_cols: List[str] = field(default_factory=list)
    non_numeric_cols: List[str] = field(default_factory=list)
    history_table: Optional[str] = None
    chunksize: Optional[int] = None
    
    # NEW: Bucket-first + table-driven routing (from V2)
    databases: List[str] = field(default_factory=lambda: [DatabasePrefixes.LOCAL_DEV])
    bucket: bool = True  # All data goes to bucket FIRST
    transforms: Dict[str, List[str]] = field(default_factory=dict)  # Per-database transforms
    
    def __post_init__(self):
        """Simple validation on creation."""
        if not self.r_call or not self.table:
            raise ValueError("r_call and table are required")


# Core NFL data sources with V2 parity fields
NFL_DATA_SOURCES = {
    'play_by_play': DataSourceConfig(
        r_call='load_pbp(file_type = "parquet")',
        table='play_by_play',
        unique_keys=['game_id', 'play_id'],
        strategy='incremental',
        min_year=1999,
        history_table='nflfastr_pbp_hist',
        chunksize=1000,  # Large table with 372 columns
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={},
        # Key numeric columns only (subset of V2 for simplicity)
        numeric_cols=[
            'play_id', 'week', 'yardline_100', 'quarter_seconds_remaining',
            'down', 'ydstogo', 'yards_gained', 'air_yards', 'yards_after_catch',
            'total_home_score', 'total_away_score', 'ep', 'epa', 'wp', 'wpa',
            'season', 'passing_yards', 'receiving_yards', 'rushing_yards'
        ]
    ),
    'rosters': DataSourceConfig(
        r_call='load_rosters(file_type = "parquet")',
        table='rosters',
        unique_keys=[],  # V2 has empty unique_keys due to near-duplicates
        strategy='incremental',
        min_year=1999,
        history_table='nflfastr_rosters_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={},
        numeric_cols=['height', 'weight', 'years_exp', 'draft_number', 'jersey_number']
    ),
    'players': DataSourceConfig(
        r_call='load_players(file_type = "parquet")',
        table='players',
        unique_keys=['gsis_id'],
        strategy='full_refresh',
        history_table='nflfastr_players_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'player_stats': DataSourceConfig(
        r_call='load_player_stats(stat_type = c("offense", "defense", "kicking"), file_type = "parquet")',
        table='player_stats',
        unique_keys=['player_id', 'season', 'week'],
        strategy='incremental',
        min_year=1999,
        history_table='nflfastr_player_stats_hist',
        chunksize=5000,
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={},
        non_numeric_cols=[
            'player_id', 'player_name', 'player_display_name', 'position',
            'position_group', 'recent_team', 'season', 'week', 'season_type'
        ]
    ),
    
    # Missing NFL sources from V2 - Batch 1: Advanced Analytics
    'participation': DataSourceConfig(
        # NOTE: PARTICIPATION DATA LOADING ISSUE (2025-10-25)
        # - R call works fine in isolation: load_participation(seasons = TRUE, file_type = "parquet")
        #   * Test results: 433,805 rows in 4.13 seconds, 86.1 MB memory
        #   * All individual year calls work: 2024 (45,919 rows), 2023 (46,168 rows), etc.
        # - Pipeline process gets killed when loading through data pipeline
        # - Root cause investigation completed:
        #   * Removed Universal List-Column Sanitizer from R integration (memory optimization)
        #   * Optimized data cleaning for large datasets (>200K rows)
        #   * Added chunked processing for quality checks
        #   * Strategy='full_refresh' works correctly (doesn't add seasons = 2025)
        # - Use test_r_calls.py to verify R call functionality
        # - Pipeline optimizations implemented but may need further memory tuning
        # - Consider loading participation data in smaller year ranges if issues persist
        r_call='load_participation(seasons = TRUE, file_type = "parquet")',
        table='participation',
        unique_keys=['nflverse_game_id', 'play_id', 'gsis_id'],
        strategy='incremental',
        min_year=2016,
        history_table='nflfastr_participation_hist',
        chunksize=5000,
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'nextgen': DataSourceConfig(
        r_call='load_nextgen_stats(stat_type = c("passing", "receiving", "rushing"), file_type = "parquet")',
        table='nextgen',
        unique_keys=['player_gsis_id', 'season', 'week'],
        strategy='incremental',
        min_year=2016,
        history_table='nflfastr_nextgen_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'snap_counts': DataSourceConfig(
        r_call='load_snap_counts(file_type = "parquet")',
        table='snap_counts',
        unique_keys=['pfr_game_id', 'pfr_player_id'],
        strategy='incremental',
        min_year=2012,
        history_table='nflfastr_snap_counts_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'pfr_adv_stats': DataSourceConfig(
        r_call='load_pfr_advstats()',
        table='pfr_adv_stats',
        unique_keys=['pfr_game_id', 'pfr_player_id'],
        strategy='incremental',
        min_year=2018,
        history_table='nflfastr_pfr_adv_stats_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={},
        non_numeric_cols=[
            'game_id', 'pfr_game_id', 'game_type', 'team',
            'opponent', 'pfr_player_name', 'pfr_player_id'
        ]
    ),
    'officials': DataSourceConfig(
        r_call='load_officials(seasons = TRUE, file_type = "parquet")',
        table='officials',
        unique_keys=['game_id', 'official_id'],
        strategy='full_refresh',
        history_table='nflfastr_officials_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'trades': DataSourceConfig(
        r_call='load_trades(seasons = TRUE)',
        table='trades',
        unique_keys=[],  # V2 has empty unique_keys
        strategy='full_refresh',
        history_table='nflfastr_trades_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'ftn_chart': DataSourceConfig(
        r_call='load_ftn_charting()',
        table='ftn_chart',
        unique_keys=['nflverse_game_id', 'nflverse_play_id'],
        strategy='incremental',
        min_year=2022,
        history_table='nflfastr_ftn_chart_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'espn_qbr_season': DataSourceConfig(
        # NOTE: ESPN QBR functions REQUIRE explicit 'seasons' parameter
        # - Without 'seasons = TRUE': returns 0 rows (tested 2025-10-25)
        # - With 'seasons = TRUE': returns 1,363 rows (all seasons 2006-2023)
        # - Must use 'full_refresh' strategy to preserve explicit seasons parameter
        r_call='load_espn_qbr(seasons = TRUE, summary_type = "season")',
        table='espn_qbr_season',
        unique_keys=['player_id', 'season', 'season_type'],
        strategy='full_refresh',
        min_year=2006,
        history_table='nflfastr_espn_qbr_season_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'espn_qbr_wk': DataSourceConfig(
        # NOTE: ESPN QBR functions REQUIRE explicit 'seasons' parameter
        # - Without 'seasons = TRUE': returns 0 rows (tested 2025-10-25)
        # - With 'seasons = TRUE': returns 9,570 rows (all seasons 2006-2023)
        # - Must use 'full_refresh' strategy to preserve explicit seasons parameter
        r_call='load_espn_qbr(seasons = TRUE, summary_type = "weekly")',
        table='espn_qbr_wk',
        unique_keys=['player_id', 'season', 'game_week', 'season_type'],
        strategy='full_refresh',
        min_year=2006,
        history_table='nflfastr_espn_qbr_wk_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'wkly_rosters': DataSourceConfig(
        r_call='load_rosters_weekly(file_type = "parquet")',
        table='wkly_rosters',
        unique_keys=['season', 'week', 'team', 'gsis_id'],
        strategy='incremental',
        min_year=2002,
        history_table='nflfastr_wkly_rosters_hist',
        chunksize=5000,
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={},
        numeric_cols=['height', 'weight', 'years_exp', 'draft_number', 'jersey_number']
    )
}

# Fantasy football data sources with V2 parity fields
FANTASY_DATA_SOURCES = {
    'ff_playerids': DataSourceConfig(
        r_call='load_ff_playerids()',
        table='ff_playerids',
        unique_keys=['mfl_id'],
        strategy='full_refresh',
        history_table='nflfastr_ff_playerids_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'ff_opportunity': DataSourceConfig(
        r_call='load_ff_opportunity(seasons = TRUE, stat_type = c("weekly", "pbp_pass", "pbp_rush"), model_version = c("latest", "v1.0.0"))',
        table='ff_opportunity',
        unique_keys=['player_id', 'full_name', 'season', 'week'],  # V2 uses full_name too
        strategy='full_refresh',
        history_table='nflfastr_ff_opportunity_hist',
        chunksize=2000,
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    
    # Missing Fantasy source from V2 - Batch 2
    'ff_rankings': DataSourceConfig(
        r_call='load_ff_rankings(type = c("draft", "week", "all"))',
        table='ff_rankings',
        unique_keys=['id', 'pos', 'ecr_type', 'page_type'],
        strategy='full_refresh',
        history_table='nflfastr_ff_rankings_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    )
}

# Draft and combine data with V2 parity fields
DRAFT_DATA_SOURCES = {
    'draft_picks': DataSourceConfig(
        r_call='load_draft_picks(seasons = TRUE, file_type = "parquet")',
        table='draft_picks',
        unique_keys=['season', 'round', 'pick'],
        strategy='full_refresh',
        history_table='nflfastr_draft_picks_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'combine': DataSourceConfig(
        r_call='load_combine(seasons = TRUE)',
        table='combine',
        unique_keys=['season', 'player_name', 'pos', 'school'],
        strategy='full_refresh',
        history_table='nflfastr_combine_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    )
}

# Health and injury data with V2 parity fields
HEALTH_DATA_SOURCES = {
    'injuries': DataSourceConfig(
        # NOTE: Critical R call configuration for injury data
        # - MUST use 'seasons = TRUE' to load all historical data (2009-2024)
        # - DO NOT use 'file_type = "parquet"' as it causes 0 rows (current season parquet files may not exist)
        # - This loads ~84k rows of historical injury data from nflreadr package
        # - Tested 2025-10-25: 'seasons = TRUE' returns 84,684 rows vs 'file_type = "parquet"' returns 0 rows
        r_call='load_injuries(seasons = TRUE)',
        table='injuries',
        unique_keys=['season', 'week', 'team', 'full_name'],
        strategy='full_refresh',
        min_year=2009,
        history_table='nflfastr_injuries_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    )
}

# Teams data sources with V2 parity fields - Batch 3: Missing Teams Sources
TEAMS_DATA_SOURCES = {
    'contracts': DataSourceConfig(
        r_call='nflreadr::load_contracts()',
        table='contracts',
        unique_keys=['player', 'team', 'year_signed', 'value', 'years'],
        strategy='full_refresh',
        history_table='nflfastr_contracts_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    ),
    'schedules': DataSourceConfig(
        r_call='nflfastR::fast_scraper_schedules()',
        table='schedules',
        unique_keys=['game_id'],
        strategy='full_refresh',
        history_table='nflfastr_schedules_hist',
        databases=[DatabasePrefixes.LOCAL_DEV, DatabasePrefixes.API_PRODUCTION],  # V2 API table - both databases
        bucket=True,
        transforms={DatabasePrefixes.API_PRODUCTION: [TransformNames.STANDARDIZE_TEAMS, TransformNames.PARSE_DATES]},
        numeric_cols=[
            'season', 'week', 'away_score', 'home_score', 'total', 'overtime',
            'away_rest', 'home_rest', 'away_moneyline', 'home_moneyline',
            'spread_line', 'away_spread_odds', 'home_spread_odds', 'total_line',
            'under_odds', 'over_odds', 'div_game', 'temp', 'wind'
        ]
    ),
    'teams': DataSourceConfig(
        r_call='nflreadr::load_teams()',
        table='teams',
        unique_keys=['team_abbr'],
        strategy='full_refresh',
        history_table='nflfastr_teams_hist',
        databases=[DatabasePrefixes.LOCAL_DEV, DatabasePrefixes.API_PRODUCTION],  # V2 API table - both databases
        bucket=True,
        transforms={DatabasePrefixes.API_PRODUCTION: [TransformNames.STANDARDIZE_TEAMS]}
    ),
    'depth_chart': DataSourceConfig(
        r_call='nflreadr::load_depth_charts()',
        table='depth_chart',
        unique_keys=[],  # V2 has empty unique_keys due to schema changes and duplicates
        strategy='full_refresh',  # V2 changed from incremental due to schema incompatibility
        min_year=2001,
        history_table='nflfastr_depth_chart_hist',
        databases=[DatabasePrefixes.LOCAL_DEV],
        bucket=True,
        transforms={}
    )
}

# Grouped data sources - Complete V2 parity with 26 total sources
DATA_SOURCE_GROUPS = {
    'nfl_data': NFL_DATA_SOURCES,
    'fantasy': FANTASY_DATA_SOURCES,
    'draft': DRAFT_DATA_SOURCES,
    'health': HEALTH_DATA_SOURCES,
    'teams': TEAMS_DATA_SOURCES
}


def get_data_source(group_name: str, source_name: str) -> DataSourceConfig:
    """
    Get a specific data source configuration.
    
    Args:
        group_name: Name of the data source group
        source_name: Name of the data source
        
    Returns:
        DataSourceConfig for the specified source
        
    Raises:
        KeyError: If group or source not found
    """
    if group_name not in DATA_SOURCE_GROUPS:
        raise KeyError(f"Unknown data source group: {group_name}")
    
    group = DATA_SOURCE_GROUPS[group_name]
    if source_name not in group:
        raise KeyError(f"Unknown data source '{source_name}' in group '{group_name}'")
    
    return group[source_name]


def list_all_sources() -> List[str]:
    """
    List all available data sources across all groups.
    
    Returns:
        List of all data source names
    """
    all_sources = []
    for group in DATA_SOURCE_GROUPS.values():
        all_sources.extend(group.keys())
    return all_sources


def get_sources_by_strategy(strategy: str) -> Dict[str, DataSourceConfig]:
    """
    Get all data sources using a specific loading strategy.
    
    Args:
        strategy: Loading strategy ('incremental' or 'full_refresh')
        
    Returns:
        Dictionary of source names to configurations
    """
    matching_sources = {}
    for group in DATA_SOURCE_GROUPS.values():
        for source_name, config in group.items():
            if config.strategy == strategy:
                matching_sources[source_name] = config
    return matching_sources


def validate_data_source_config(config_dict: Dict[str, Dict[str, DataSourceConfig]], logger=None) -> None:
    """
    V2-style validation with fail-fast approach.
    
    Pattern: Simple validation function (1 complexity point)
    Validates all data sources have required configuration fields.
    
    Args:
        config_dict: Dictionary of data source groups and their configurations
        logger: Optional logger instance (uses module logger as fallback)
        
    Raises:
        ValueError: If any data source is missing required configuration fields
    """
    logger = logger or _logger  # DI with sensible fallback
    required_fields = ['r_call', 'schema', 'table', 'unique_keys', 'strategy']
    
    for group_name, sources in config_dict.items():
        for source_name, config in sources.items():
            # Validate required fields are present and not None/empty
            missing = []
            for field in required_fields:
                if not hasattr(config, field) or getattr(config, field) is None:
                    missing.append(field)
                elif field == 'r_call' and not getattr(config, field):
                    missing.append(field)
            
            if missing:
                raise ValueError(
                    f"Data source '{source_name}' in group '{group_name}' "
                    f"missing required fields: {missing}. "
                    f"Required fields are: {required_fields}"
                )
    
    # Count total sources for summary
    total_sources = sum(len(sources) for sources in config_dict.values())
    logger.info(f"✓ Data source configuration validation passed: {total_sources} sources validated")


# Validate configuration at import time to fail fast (V2 approach)
validate_data_source_config(DATA_SOURCE_GROUPS)


__all__ = [
    'DataSourceConfig',
    'DATA_SOURCE_GROUPS',
    'NFL_DATA_SOURCES',
    'FANTASY_DATA_SOURCES', 
    'DRAFT_DATA_SOURCES',
    'HEALTH_DATA_SOURCES',
    'TEAMS_DATA_SOURCES',
    'get_data_source',
    'list_all_sources',
    'get_sources_by_strategy',
    'validate_data_source_config'
]
