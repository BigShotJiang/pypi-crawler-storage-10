"""
Data Pipeline Implementation for nflfastRv3

Migrates proven DataLoader business logic from nflfastRv2 into clean architecture.
Following REFACTORING_SPECS.md: Maximum 5 complexity points, 3 layers depth.

Pattern: Minimum Viable Decoupling (2 complexity points)
Layer: 2 (Implementation - calls infrastructure directly)
"""

from typing import Dict, List, Any, Optional
import pandas as pd
from commonv2 import get_logger
from ...shared.database import NFLfastRDatabase
from ...shared.r_integration import get_r_service, execute_real_r_call, current_nfl_season
from ...shared.models import ValidationResult
from ...shared.bucket_adapter import BucketAdapter
from ...shared.database_router import DatabaseRouter
from .config.data_sources import DATA_SOURCE_GROUPS, DataSourceConfig
from commonv2 import apply_cleaning, DataQualityError
from commonv2._data.schema_detector import SchemaDetector
from .schedule_integration import ScheduleDataProvider
from ...shared.progress_tracker import ProgressTracker


class DataPipeline:
    """
    Core data pipeline business logic.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + business logic)
    Depth: 1 layer (calls infrastructure directly)
    
    Migrated from nflfastRv2.DataLoader with architectural simplification.
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
        
        # NEW: Initialize bucket-first architecture services (Layer 3)
        self.bucket_adapter = BucketAdapter(logger=logger)
        self.database_router = DatabaseRouter(db_service, logger)
    
    def process(self, groups=None, tables=None, seasons=None):
        """
        Execute data pipeline workflow.

        V1-style processing: either groups OR tables (mutually exclusive)
        1. Load data from R (Layer 3 call)
        2. Process each data source group (Layer 3 calls)
        3. Return summary

        Args:
            groups: Data source groups to load (mutually exclusive with tables)
            tables: Specific tables to load with auto-discovery (mutually exclusive with groups)
            seasons: Seasons to load

        Returns:
            dict: Processing summary
        """
        # V1-style: Default to nfl_data if nothing specified
        if not groups and not tables:
            groups = ['nfl_data']
        
        self.logger.info(f"Starting data pipeline: groups={groups}, tables={tables}, seasons={seasons}")
        
        try:
            # V1-style processing: either groups OR tables
            groups_to_process = self._get_groups_to_process(groups, tables)
            
            if not groups_to_process:
                return {
                    'status': 'warning',
                    'message': 'No valid groups specified',
                    'tables': [],
                    'total_rows': 0
                }
            
            # Process each group
            total_rows = 0
            all_tables = []
            group_results = {}
            
            for group_name, data_sources in groups_to_process.items():
                self.logger.info(f"Processing group: {group_name}")
                
                try:
                    rows_processed = self._process_group(group_name, data_sources, seasons)
                    group_results[group_name] = {
                        'status': 'success',
                        'rows': rows_processed
                    }
                    total_rows += rows_processed
                    all_tables.extend(data_sources.keys())
                    
                except Exception as e:
                    self.logger.error(f"Group {group_name} failed: {e}")
                    group_results[group_name] = {
                        'status': 'failed',
                        'error': str(e)
                    }
                    continue
            
            self.logger.info(f"Pipeline complete: {total_rows:,} total rows processed")
            
            return {
                'status': 'success',
                'tables': all_tables,
                'total_rows': total_rows,
                'group_results': group_results
            }
            
        except Exception as e:
            self.logger.error(f"Data pipeline failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'tables': [],
                'total_rows': 0
            }
    
    def _get_groups_to_process(self, groups: Optional[List[str]] = None, tables: Optional[List[str]] = None) -> Dict[str, Dict[str, DataSourceConfig]]:
        """
        V1-style processing: either groups OR tables, not both.
        
        Args:
            groups: List of group names (mutually exclusive with tables)
            tables: List of table names with auto-discovery (mutually exclusive with groups)
            
        Returns:
            Dictionary of valid groups with their data sources
        """
        
        if tables:
            # V1-style table auto-discovery
            groups_to_process = {}
            for table_name in tables:
                # Find which group contains this table
                found_group = None
                for group_name, sources in DATA_SOURCE_GROUPS.items():
                    if table_name in sources:
                        found_group = group_name
                        break
                
                if not found_group:
                    available_tables = [t for sources in DATA_SOURCE_GROUPS.values() for t in sources.keys()]
                    raise ValueError(f"Unknown table: {table_name}. Available: {available_tables}")
                
                # Add to single_tables group (v1 pattern)
                if "single_tables" not in groups_to_process:
                    groups_to_process["single_tables"] = {}
                groups_to_process["single_tables"][table_name] = DATA_SOURCE_GROUPS[found_group][table_name]
            
            self.logger.info(f"📊 Auto-discovered tables: {list(tables)}")
            return groups_to_process
        
        elif groups:
            # Standard group processing
            groups_to_process = {}
            for group_name in groups:
                if group_name not in DATA_SOURCE_GROUPS:
                    raise ValueError(f"Unknown group: {group_name}. Available: {list(DATA_SOURCE_GROUPS.keys())}")
                groups_to_process[group_name] = DATA_SOURCE_GROUPS[group_name]
            
            self.logger.info(f"📊 Processing groups: {list(groups)}")
            return groups_to_process
        
        else:
            # Default: nfl_data group
            self.logger.info("📊 Processing default group: nfl_data")
            return {"nfl_data": DATA_SOURCE_GROUPS["nfl_data"]}
    
    def _process_group(self, group_name: str, data_sources: Dict[str, DataSourceConfig], seasons: Optional[List[int]]) -> int:
        """
        Process all data sources in a group.
        
        V1-style: No default seasons - each data source determines its own seasons
        based on loading strategy (incremental vs full refresh).
        
        Args:
            group_name: Name of the data source group
            data_sources: Dictionary of data source configs
            seasons: Seasons to load (None = let each source determine its own)
            
        Returns:
            Total number of rows processed
        """
        total_processed = 0
        total_sources = len(data_sources)
        
        # 1. Pipeline-level progress tracking (tracking data sources, not rows)
        pipeline_progress = ProgressTracker(
            total_expected=total_sources,
            table_name=f"{group_name}_sources",
            tracking_unit="sources",
            logger=self.logger
        )
        pipeline_progress.start()
        
        for idx, (source_name, config) in enumerate(data_sources.items(), 1):
            self.logger.info(f"🔄 Processing {idx}/{total_sources} data sources: {source_name}")
            
            try:
                rows_processed = self._process_source(source_name, config, seasons)
                total_processed += rows_processed
                
                # Update pipeline progress (1 source completed)
                pipeline_progress.update(1, force_report=True, step_name=source_name)
                self.logger.info(f"✅ {source_name}: {rows_processed:,} rows processed")
                
            except Exception as e:
                self.logger.error(f"Failed to process {source_name}: {e}")
                pipeline_progress.update(1, force_report=True, step_name=f"{source_name} (failed)")
                continue
        
        # Finish pipeline progress
        pipeline_progress.finish()
        return total_processed
    
    def _process_source(self, source_name: str, config: DataSourceConfig, seasons: Optional[List[int]]) -> int:
        """
        Process single data source: fetch → clean → store.
        
        V1-style: Each source determines its own seasons based on strategy.
        
        Args:
            source_name: Name of the data source
            config: Data source configuration
            seasons: Seasons to load (None = let source determine based on strategy)
            
        Returns:
            Number of rows processed
        """
        self.logger.debug(f"Processing data source: {source_name}")
        
        # Step 1: Fetch data from R (Layer 3 call)
        df = self._fetch_data(config, seasons)
        if df.empty:
            self.logger.info(f"No data for {source_name}")
            return 0

        # BUG-004 FIX: Enhanced data loss logging - Track cleaning impact
        pre_cleaning_count = len(df)
        self.logger.info(f"📊 DATA CLEANING: {source_name} - Before cleaning: {pre_cleaning_count:,} rows")

        # Step 2: Clean data with schema matching (Layer 3 call)
        # Get engine for schema matching (use local database engine)
        try:
            engine = self.db_service.engine
        except:
            engine = None
        df = self._clean_data(df, config, engine)

        # BUG-004 FIX: Calculate and log data loss from cleaning
        post_cleaning_count = len(df)
        rows_lost = pre_cleaning_count - post_cleaning_count
        if rows_lost > 0:
            loss_percentage = (rows_lost / pre_cleaning_count) * 100
            self.logger.warning(f"⚠️  DATA LOSS: {source_name} - Lost {rows_lost:,} rows during cleaning ({loss_percentage:.1f}%)")
            self.logger.info(f"📊 DATA CLEANING: {source_name} - After cleaning: {post_cleaning_count:,} rows")
        else:
            self.logger.info(f"📊 DATA CLEANING: {source_name} - After cleaning: {post_cleaning_count:,} rows (no loss)")

        # Step 3: Store in database (Layer 3 call)
        rows_written = self._store_data(df, config)

        return rows_written
    
    def _fetch_data(self, config: DataSourceConfig, seasons: Optional[List[int]]) -> pd.DataFrame:
        """
        Fetch data using strategy-based temporal control.

        Strategy-based season handling:
        - Incremental tables: Load current season data only
        - Full refresh tables: Load all available historical data
        - No manual season parameter substitution needed

        Args:
            config: Data source configuration with R call specification
            seasons: Seasons to load (ignored - strategy determines temporal scope)

        Returns:
            DataFrame with fetched data

        Raises:
            RuntimeError: If R integration fails or data cannot be loaded
        """
        # 2. Data fetching progress tracking (tracking rows)
        fetch_progress = ProgressTracker(
            table_name=f"fetching_{config.table}",
            tracking_unit="rows",
            logger=self.logger
        )
        fetch_progress.start()

        # Strategy-based R call preparation
        r_call = self._prepare_strategy_based_r_call(config)

        self.logger.info(f"📡 Fetching {config.table} data using R call: {r_call}")
        self.logger.info(f"Using strategy: {config.strategy}")

        try:
            # Get the enhanced R service
            r_service = get_r_service()

            if not r_service.is_healthy:
                self.logger.warning("R service not healthy, attempting to continue")

            # Execute using the working string approach
            df = execute_real_r_call(r_call, config.table)

            if df.empty:
                self.logger.warning(f"No data returned for {config.table}")
                fetch_progress.finish()
                return pd.DataFrame()

            # BUG-004 FIX: Enhanced data loss logging - Log initial fetch count
            initial_row_count = len(df)
            self.logger.info(f"📊 DATA FETCH: {config.table} - Initial R fetch: {initial_row_count:,} rows")

            # Update progress with fetched data
            fetch_progress.update(len(df), force_report=True)

            # Validate the fetched data
            validation = self._validate_fetched_data(df, config)
            if not validation.is_valid:
                self.logger.warning(f"Data validation issues for {config.table}: {validation.errors}")

            # Finish fetch progress
            fetch_progress.finish()
            return df

        except Exception as e:
            self.logger.error(f"Failed to fetch data for {config.table}: {e}")
            fetch_progress.finish()

            # PHASE 1 ENHANCEMENT: Enhanced fallback approach for critical data sources
            if self._is_critical_source(config):
                self.logger.info(f"🔄 FALLBACK: Attempting fallback data fetch for critical source {config.table}")
                fallback_df = self._fetch_data_fallback(config, [])
                if not fallback_df.empty:
                    self.logger.info(f"✅ FALLBACK_SUCCESS: Retrieved {len(fallback_df):,} rows for {config.table}")
                    return fallback_df
                else:
                    self.logger.error(f"❌ FALLBACK_FAILED: No fallback data available for {config.table}")
            
            # Circuit breaker pattern - track failures
            self._record_fetch_failure(config.table, str(e))
            return pd.DataFrame()
    
    def _validate_fetched_data(self, df: pd.DataFrame, config: DataSourceConfig) -> ValidationResult:
        """
        Validate fetched data against configuration expectations.
        
        Args:
            df: Fetched DataFrame
            config: Data source configuration
            
        Returns:
            ValidationResult with validation status and issues
        """
        validation = ValidationResult(True)
        validation.record_count = len(df)
        
        # Check if data is empty
        if df.empty:
            validation.add_error("No data fetched")
            return validation
        
        # Check for expected columns based on unique keys
        if config.unique_keys:
            missing_keys = [key for key in config.unique_keys if key not in df.columns]
            if missing_keys:
                validation.add_error(f"Missing expected columns: {missing_keys}")
        
        # Check for reasonable data volume
        if len(df) < 10 and config.table not in ['teams', 'officials']:  # Some tables are naturally small
            validation.add_warning(f"Low row count: {len(df)} rows")
        
        # Check data types for numeric columns if specified
        if hasattr(config, 'numeric_cols') and config.numeric_cols:
            for col in config.numeric_cols:
                if col in df.columns:
                    if not pd.api.types.is_numeric_dtype(df[col]):
                        validation.add_warning(f"Column {col} expected to be numeric but isn't")
        
        return validation
    
    def _prepare_strategy_based_r_call(self, config: DataSourceConfig) -> str:
        """
        Prepare R call based on loading strategy without parameter substitution.

        Strategy-based approach:
        - Incremental tables: Add current season parameter to R call
        - Full refresh tables: Use R call as-is (loads all available data)

        Args:
            config: Data source configuration

        Returns:
            str: Prepared R call string
        """
        r_call = config.r_call
        
        if config.strategy == 'incremental':
            # For incremental tables, add current season parameter
            current_season = current_nfl_season()
            
            # Add season parameter based on function signature
            if 'load_pbp(' in r_call:
                r_call = r_call.replace('load_pbp(', f'load_pbp(seasons = {current_season}, ')
            elif 'load_rosters(' in r_call:
                r_call = r_call.replace('load_rosters(', f'load_rosters(seasons = {current_season}, ')
            elif 'load_player_stats(' in r_call:
                r_call = r_call.replace('load_player_stats(', f'load_player_stats(seasons = {current_season}, ')
            elif 'load_participation(' in r_call:
                r_call = r_call.replace('load_participation(', f'load_participation(seasons = {current_season}, ')
            elif 'load_nextgen_stats(' in r_call:
                r_call = r_call.replace('load_nextgen_stats(', f'load_nextgen_stats({current_season}, ')
            elif 'load_snap_counts(' in r_call:
                r_call = r_call.replace('load_snap_counts(', f'load_snap_counts({current_season}, ')
            elif 'load_pfr_advstats(' in r_call:
                r_call = r_call.replace('load_pfr_advstats(', f'load_pfr_advstats({current_season}, ')
            elif 'load_ftn_charting(' in r_call:
                r_call = r_call.replace('load_ftn_charting(', f'load_ftn_charting(seasons = {current_season}')
            elif 'load_espn_qbr(' in r_call:
                r_call = r_call.replace('load_espn_qbr(', f'load_espn_qbr(seasons = {current_season}, ')
            elif 'load_rosters_weekly(' in r_call:
                r_call = r_call.replace('load_rosters_weekly(', f'load_rosters_weekly({current_season}, ')
            
            self.logger.info(f"Incremental strategy: Added current season {current_season} to R call")
        else:
            # For full refresh tables, use R call as-is
            self.logger.info(f"Full refresh strategy: Using R call as-is to load all available data")
        
        return r_call

    def _is_critical_source(self, config: DataSourceConfig) -> bool:
        """
        Check if a data source is critical and should have fallback handling.

        Args:
            config: Data source configuration

        Returns:
            bool: True if this is a critical data source
        """
        critical_sources = ['play_by_play', 'schedules', 'rosters', 'teams']
        return config.table in critical_sources
    
    def _fetch_data_fallback(self, config: DataSourceConfig, seasons: Optional[List[int]]) -> pd.DataFrame:
        """
        Fallback data fetching for critical sources when R integration fails.
        
        Args:
            config: Data source configuration
            seasons: Seasons to load
            
        Returns:
            DataFrame with fallback data (may be empty)
        """
        self.logger.info(f"Attempting fallback data fetch for {config.table}")
        
        try:
            # For schedules, try using the schedule integration
            if config.table == 'schedules':
                schedule_provider = ScheduleDataProvider()
                # Handle None seasons for fallback
                fallback_seasons = seasons or [current_nfl_season()]
                games = schedule_provider.load_schedule(fallback_seasons)
                
                if games:
                    # Convert GameSchedule objects to DataFrame
                    data = []
                    for game in games:
                        data.append({
                            'game_id': game.game_id,
                            'season': game.season,
                            'week': game.week,
                            'home_team': game.home_team,
                            'away_team': game.away_team,
                            'gameday': game.game_date.strftime('%Y-%m-%d'),
                            'gametime': game.game_date.strftime('%H:%M'),
                            'stadium': game.stadium
                        })
                    
                    fallback_df = pd.DataFrame(data)
                    self.logger.info(f"Fallback fetch successful for {config.table}: {len(fallback_df)} rows")
                    return fallback_df
            
            # For other critical sources, could implement additional fallback methods
            # For now, return empty DataFrame
            self.logger.warning(f"No fallback available for {config.table}")
            return pd.DataFrame()
            
        except Exception as e:
            self.logger.error(f"Fallback fetch failed for {config.table}: {e}")
            return pd.DataFrame()
    
    def _record_fetch_failure(self, table_name: str, error_message: str):
        """
        Record data fetch failure for circuit breaker pattern.
        
        PHASE 1 ENHANCEMENT: Circuit breaker pattern implementation
        
        Args:
            table_name: Table that failed to fetch
            error_message: Error message from the failure
        """
        # Simple failure tracking - could be enhanced with persistent storage
        if not hasattr(self, '_fetch_failures'):
            self._fetch_failures = {}
        
        if table_name not in self._fetch_failures:
            self._fetch_failures[table_name] = []
        
        from datetime import datetime
        self._fetch_failures[table_name].append({
            'timestamp': datetime.now(),
            'error': error_message
        })
        
        # Keep only last 10 failures per table
        self._fetch_failures[table_name] = self._fetch_failures[table_name][-10:]
        
        # Check if we should trigger circuit breaker
        recent_failures = len(self._fetch_failures[table_name])
        if recent_failures >= 3:
            self.logger.error(f"🚨 CIRCUIT_BREAKER: {table_name} has {recent_failures} recent failures - consider manual intervention")
    
    def _clean_data(self, df: Any, config: DataSourceConfig, engine=None) -> Any:
        """
        Clean data using quality checks with enhanced schema matching.
        
        ENHANCED: Phase 1 - Schema change detection integration
        
        Args:
            df: Raw DataFrame
            config: Data source configuration
            engine: Optional SQLAlchemy engine for schema matching
            
        Returns:
            Cleaned DataFrame
        """
        # ENHANCED: Detect schema changes before cleaning using real SchemaDetector
        if engine:
            schema_detector = SchemaDetector(self.logger)
            schema_analysis = schema_detector.detect_schema_changes(df, config.table, config.schema, engine)
            
            if schema_analysis['requires_drop']:
                self.logger.warning(f"🚨 SCHEMA_DRIFT_DETECTED: {config.table} requires drop/recreate")
                
                if schema_analysis['breaking_changes']:
                    for change in schema_analysis['breaking_changes']:
                        self.logger.warning(f"⚠️ BREAKING_CHANGE: {change}")
                
                if schema_analysis['missing_columns']:
                    self.logger.error(f"❌ CRITICAL: Missing columns will cause failures: {schema_analysis['missing_columns']}")
        
        # Convert config to dict for apply_cleaning with engine for schema matching
        config_dict = {
            'table': config.table,
            'schema': config.schema,
            'numeric_cols': config.numeric_cols,
            'non_numeric_cols': config.non_numeric_cols,
            'unique_keys': config.unique_keys,
            'engine': engine  # Pass engine for schema matching
        }
        
        # Layer 3 call to quality checks with enhanced schema matching
        return apply_cleaning(df, config.table, config_dict, self.logger)
    
    def _store_data(self, df: Any, config: DataSourceConfig) -> int:
        """
        Store data using bucket-first architecture.
        
        NEW BUCKET-FIRST FLOW (from V2):
        1. Store in bucket FIRST (primary storage)  
        2. Route to databases (secondary storage)
        
        Args:
            df: Cleaned DataFrame
            config: Data source configuration
            
        Returns:
            Number of rows written
        """
        if df.empty:
            self.logger.info(f"No data to store for {config.table}")
            return 0
        
        # 3. Storage progress tracking (tracking rows)
        storage_progress = ProgressTracker(
            total_expected=len(df),
            table_name=f"storing_{config.table}",
            tracking_unit="rows",
            logger=self.logger
        )
        storage_progress.start()
        
        # Step 1: Store in bucket FIRST (primary storage)
        bucket_success = False
        if config.bucket:
            self.logger.info(f"☁️  Storing {len(df):,} rows in bucket: {config.table}")
            bucket_success = self.bucket_adapter.store_data(df, config.table, config.schema)
            
            if not bucket_success:
                # BUG-009 FIX: Standardized storage reporting - Complete failure
                self.logger.error(f"❌ STORAGE FAILED: {config.table} - {len(df):,} rows → Bucket: ✗ Database: ✗")
                storage_progress.finish()
                return 0
            
            # Update progress for bucket storage
            storage_progress.update(len(df), force_report=True)
        else:
            self.logger.debug(f"Bucket storage disabled for {config.table}")
            storage_progress.update(len(df), force_report=True)
            bucket_success = True  # Consider it successful if disabled
        
        # Step 2: Route to databases (secondary storage)
        try:
            self.logger.info(f"🗄️  Routing {len(df):,} rows to {len(config.databases)} database(s): {config.databases}")
            database_success = self.database_router.route_to_databases(df, config)
            
            # BUG-009 FIX: Standardized storage reporting - Single consolidated message
            if bucket_success and database_success:
                self.logger.info(f"✅ STORAGE SUCCESS: {config.table} - {len(df):,} rows → Bucket: ✓ Database: ✓")
            elif bucket_success and not database_success:
                self.logger.warning(f"⚠️ STORAGE PARTIAL: {config.table} - {len(df):,} rows → Bucket: ✓ Database: ✗ (data safe in bucket)")
            else:
                self.logger.error(f"❌ STORAGE FAILED: {config.table} - {len(df):,} rows → Bucket: ✗ Database: ✗")
            
            # Finish storage progress
            storage_progress.finish()
            return len(df)  # Return original row count
            
        except Exception as e:
            self.logger.error(f"Failed to route {config.table} to databases: {e}")
            
            # PHASE 1 ENHANCEMENT: Enhanced error recovery with detailed logging
            if bucket_success:
                self.logger.warning(f"⚠️ STORAGE_PARTIAL: {config.table} - {len(df):,} rows → Bucket: ✓ Database: ✗ (data safe in bucket)")
                self.logger.info(f"💡 RECOVERY_SUGGESTION: Data for {config.table} is safely stored in bucket and can be reprocessed to database")
            else:
                self.logger.error(f"❌ STORAGE_FAILED: {config.table} - {len(df):,} rows → Bucket: ✗ Database: ✗")
                self.logger.error(f"🚨 DATA_LOSS_RISK: {config.table} data may be lost - manual intervention required")
            
            # Record storage failure for monitoring
            self._record_storage_failure(config.table, str(e), bucket_success)
            
            storage_progress.finish()
            return len(df) if bucket_success else 0
    
    def _record_storage_failure(self, table_name: str, error_message: str, bucket_success: bool):
        """
        Record storage failure for monitoring and recovery planning.
        
        PHASE 1 ENHANCEMENT: Storage failure tracking
        
        Args:
            table_name: Table that failed to store
            error_message: Error message from the failure
            bucket_success: Whether bucket storage succeeded
        """
        if not hasattr(self, '_storage_failures'):
            self._storage_failures = {}
        
        if table_name not in self._storage_failures:
            self._storage_failures[table_name] = []
        
        from datetime import datetime
        self._storage_failures[table_name].append({
            'timestamp': datetime.now(),
            'error': error_message,
            'bucket_success': bucket_success,
            'recovery_needed': not bucket_success
        })
        
        # Keep only last 5 storage failures per table
        self._storage_failures[table_name] = self._storage_failures[table_name][-5:]
        
        # Alert on repeated storage failures
        recent_failures = len(self._storage_failures[table_name])
        if recent_failures >= 2:
            self.logger.error(f"🚨 REPEATED_STORAGE_FAILURES: {table_name} has {recent_failures} recent storage failures")


def create_data_pipeline(db_service=None, logger=None):
    """
    Create data pipeline with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        DataPipeline: Configured data pipeline
    """
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.data_pipeline')
    
    return DataPipeline(db_service, logger)


__all__ = ['DataPipeline', 'create_data_pipeline']
