"""
Fact Play Table Builder for nflfastRv3

Implements chunked processing for large play-by-play datasets preserving V2's
sophisticated business logic and performance optimizations.

Pattern: Enhanced simple functions with optional dependency injection
Complexity: 4 points (chunked processing + business logic)
Layer: 3 (uses SQL templates, cleaning functions, and warehouse utils)
"""

import pandas as pd
from typing import Dict, Any, Optional, List
from sqlalchemy import text
from commonv2 import get_logger

from .sql_templates_facts import get_fact_play_sql
from .cleaning_facts import clean_fact_play_data
from .warehouse_utils import save_table_to_analytics, validate_table_data, create_table_summary


def build_fact_play(db_service: Any, seasons: Optional[List[str]] = None, 
                   chunk_size: int = 5000, logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_play table with chunked processing for large datasets.
    
    V2 Features Preserved:
    - Iterator-based chunked processing (5000 rows default)
    - Sophisticated play analysis and derived metrics
    - Memory-efficient handling of multi-season datasets
    - Data quality validation at chunk level
    
    Args:
        db_service: Database service instance
        seasons: List of seasons to process (default: current season)
        chunk_size: Number of rows per chunk (default: 5000)
        logger: Optional logger instance
        
    Returns:
        Dict with build summary including row counts and performance metrics
        
    Complexity: Chunked processing with business logic (4 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_play')
    assert logger is not None
    logger.info("Starting fact_play table build with chunked processing")
    
    # Initialize summary tracking early to avoid unbound variable
    build_summary = {
        'status': 'success',
        'total_rows_processed': 0,
        'total_rows_saved': 0,
        'chunks_processed': 0,
        'seasons_processed': 0,
        'performance_metrics': {},
        'validation_results': {}
    }
    
    try:
        # 1. Determine seasons to process
        if not seasons:
            from datetime import datetime
            current_year = datetime.now().year
            seasons = [str(current_year)]
        
        logger.info(f"Processing seasons: {seasons}")
        build_summary['seasons_processed'] = len(seasons)
        
        # 2. Get adaptive SQL query (V2's column detection)
        sql_query = get_fact_play_sql(db_service.engine)
        logger.info("Generated adaptive fact_play SQL query")
        
        # 3. Add season filtering to the query
        if seasons:
            season_list = "', '".join(seasons)
            # Modify the query to include season filter
            sql_query = sql_query.text.replace(
                "WHERE play_id IS NOT NULL AND game_id IS NOT NULL",
                f"WHERE play_id IS NOT NULL AND game_id IS NOT NULL AND season IN ('{season_list}')"
            )
            sql_query = text(sql_query)
        
        # 4. Process data in chunks (V2's iterator approach)
        total_processed = 0
        chunk_number = 0
        
        # Read data in chunks using pandas chunksize
        logger.info(f"Reading data in chunks of {chunk_size:,} rows")
        chunk_iterator = pd.read_sql(sql_query, db_service.engine, chunksize=chunk_size)
        
        for chunk_df in chunk_iterator:
            chunk_number += 1
            chunk_start_rows = len(chunk_df)
            
            logger.info(f"Processing chunk {chunk_number}: {chunk_start_rows:,} rows")
            
            # 5. Clean chunk data using V2 business logic
            cleaned_chunk = clean_fact_play_data(chunk_df, logger)
            
            # 6. Validate chunk data quality
            validation_result = validate_table_data(cleaned_chunk, 'fact_play')
            if validation_result['status'] != 'success':
                logger.warning(f"Chunk {chunk_number} validation issues: {validation_result}")
            
            # 7. Save chunk to analytics schema
            if chunk_number == 1:
                # First chunk - replace table
                save_result = save_table_to_analytics(cleaned_chunk, 'fact_play', db_service.engine, logger)
            else:
                # Subsequent chunks - append data
                with db_service.engine.begin() as conn:
                    cleaned_chunk.to_sql(
                        name='fact_play',
                        con=conn,
                        schema='analytics',
                        if_exists='append',
                        index=False,
                        method='multi'
                    )
                save_result = True
            
            # 8. Update summary metrics
            total_processed += chunk_start_rows
            build_summary['total_rows_processed'] += chunk_start_rows
            build_summary['total_rows_saved'] += len(cleaned_chunk)
            build_summary['chunks_processed'] = chunk_number
            
            # Store validation results for this chunk
            build_summary['validation_results'][f'chunk_{chunk_number}'] = validation_result
            
            logger.info(f"Chunk {chunk_number} complete: {len(cleaned_chunk):,} rows saved")
        
        # 9. Final validation and summary
        logger.info(f"Chunked processing complete: {total_processed:,} total rows processed")
        
        # Create table summary for final validation
        final_validation_query = "SELECT COUNT(*) as row_count FROM analytics.fact_play"
        final_count = pd.read_sql(final_validation_query, db_service.engine).iloc[0]['row_count']
        
        build_summary['final_table_count'] = final_count
        build_summary['performance_metrics'] = {
            'avg_chunk_size': total_processed / chunk_number if chunk_number > 0 else 0,
            'total_chunks': chunk_number,
            'processing_efficiency': build_summary['total_rows_saved'] / build_summary['total_rows_processed'] if build_summary['total_rows_processed'] > 0 else 0
        }
        
        logger.info(f"✅ fact_play build complete: {final_count:,} rows in final table")
        return build_summary
        
    except Exception as e:
        logger.error(f"❌ fact_play build failed: {e}", exc_info=True)
        build_summary['status'] = 'error'
        build_summary['message'] = str(e)
        return build_summary


def build_fact_play_incremental(db_service: Any, season: str, week: Optional[int] = None,
                              logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_play table incrementally for specific season/week.
    
    Optimized for real-time updates during season (V2's incremental logic).
    
    Args:
        db_service: Database service instance
        season: Season to process (e.g., '2024')
        week: Optional specific week (default: all weeks in season)
        logger: Optional logger instance
        
    Returns:
        Dict with incremental build summary
        
    Complexity: Incremental processing logic (3 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_play')
    assert logger is not None
    logger.info(f"Starting incremental fact_play build for season {season}")
    
    try:
        # 1. Build where clause for incremental processing
        where_conditions = [f"season = '{season}'"]
        if week is not None:
            where_conditions.append(f"week = {week}")
        
        where_clause = " AND ".join(where_conditions)
        logger.info(f"Incremental conditions: {where_clause}")
        
        # 2. Delete existing data for this season/week
        delete_query = f"DELETE FROM analytics.fact_play WHERE {where_clause}"
        db_service.engine.execute(delete_query)
        logger.info(f"Deleted existing data for {where_clause}")
        
        # 3. Get SQL for specific season/week
        sql_query = get_fact_play_sql(db_service.engine)
        
        # Add season and week filtering
        base_where = "WHERE play_id IS NOT NULL AND game_id IS NOT NULL"
        full_where = f"{base_where} AND {where_clause}"
        sql_query = sql_query.text.replace(base_where, full_where)
        sql_query = text(sql_query)
        
        # 4. Process incremental data (smaller dataset, no chunking needed)
        df = pd.read_sql(sql_query, db_service.engine)
        logger.info(f"Retrieved {len(df):,} rows for incremental processing")
        
        if df.empty:
            logger.info("No data found for incremental build")
            return {
                'status': 'success',
                'rows_processed': 0,
                'rows_saved': 0,
                'incremental_type': f"season_{season}" + (f"_week_{week}" if week else "")
            }
        
        # 5. Clean and validate data
        cleaned_df = clean_fact_play_data(df, logger)
        validation_result = validate_table_data(cleaned_df, 'fact_play')
        
        # 6. Save incremental data
        with db_service.engine.begin() as conn:
            cleaned_df.to_sql(
                name='fact_play',
                con=conn,
                schema='analytics',
                if_exists='append',
                index=False,
                method='multi'
            )
        save_result = True
        
        # 7. Return summary
        return {
            'status': 'success',
            'rows_processed': len(df),
            'rows_saved': len(cleaned_df),
            'incremental_type': f"season_{season}" + (f"_week_{week}" if week else ""),
            'validation_result': validation_result,
            'season': season,
            'week': week
        }
        
    except Exception as e:
        logger.error(f"❌ Incremental fact_play build failed: {e}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'season': season,
            'week': week
        }


def get_fact_play_summary(db_service: Any, logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Get comprehensive summary of fact_play table for monitoring.
    
    V2 Monitoring Features:
    - Row counts by season/week
    - Data quality metrics
    - Coverage analysis
    
    Args:
        db_service: Database service instance
        logger: Optional logger instance
        
    Returns:
        Dict with comprehensive table summary
        
    Complexity: Simple aggregation function (2 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_play')
    assert logger is not None
    
    try:
        # Basic table summary
        # Get a sample of the table for summary
        sample_query = "SELECT * FROM analytics.fact_play LIMIT 1000"
        sample_df = pd.read_sql(sample_query, db_service.engine)
        summary = create_table_summary(sample_df, 'fact_play')
        
        # Season/week breakdown
        coverage_query = """
        SELECT 
            season,
            COUNT(DISTINCT week) as weeks_covered,
            COUNT(*) as total_plays,
            COUNT(DISTINCT game_id) as games_covered
        FROM analytics.fact_play 
        GROUP BY season 
        ORDER BY season DESC
        """
        
        coverage_df = pd.read_sql(coverage_query, db_service.engine)
        summary['coverage_by_season'] = coverage_df.to_dict('records')
        
        # Data quality metrics
        quality_query = """
        SELECT 
            COUNT(*) as total_rows,
            COUNT(CASE WHEN epa IS NOT NULL THEN 1 END) as rows_with_epa,
            COUNT(CASE WHEN success IS NOT NULL THEN 1 END) as rows_with_success,
            AVG(CASE WHEN epa IS NOT NULL THEN epa END) as avg_epa,
            COUNT(DISTINCT play_type) as unique_play_types
        FROM analytics.fact_play
        """
        
        quality_df = pd.read_sql(quality_query, db_service.engine)
        summary['data_quality'] = quality_df.to_dict('records')[0]
        
        logger.info("Generated fact_play table summary")
        return summary
        
    except Exception as e:
        logger.error(f"Failed to generate fact_play summary: {e}", exc_info=True)
        return {'status': 'error', 'message': str(e)}
