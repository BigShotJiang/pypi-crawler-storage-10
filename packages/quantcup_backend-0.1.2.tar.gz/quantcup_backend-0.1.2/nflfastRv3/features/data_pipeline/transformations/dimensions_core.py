"""
Core dimensional table builders for nflfastRv3.

Pattern: Enhanced simple function (3 complexity points)
- Base function: 1 point
- Optional DI support: +1 point  
- Business logic coordination: +1 point

Preserves V2 sophistication:
- Adaptive SQL with column detection
- Weather categorization
- Venue standardization
- Game type indicators
- Betting data integration
"""

import pandas as pd
from commonv2 import get_logger
from .sql_templates_dimensions import get_game_data_sql
from .cleaning_dimensions import clean_game_data, categorize_weather
from .warehouse_utils import validate_table_data, log_transformation_progress


def build_dim_game(engine, logger=None) -> pd.DataFrame:
    """
    Build game dimension with comprehensive game-level attributes.
    
    Pattern: Enhanced function (3 complexity points)
    - Base function: 1 point
    - Optional DI: +1 point
    - Business logic coordination: +1 point
    
    Preserves V2 sophistication:
    - Adaptive column detection
    - Weather categorization  
    - Venue standardization
    - Game type indicators
    - Betting data integration
    
    Args:
        engine: SQLAlchemy database engine (Layer 3)
        logger: Optional logger override (Layer 3)
        
    Returns:
        pd.DataFrame: Complete game dimension
    """
    logger = logger or get_logger('nflfastRv3.transformations.dimensions')
    logger.info("Building dim_game with V2 sophistication...")
    
    try:
        # Step 1: Extract with adaptive SQL (V2 capability preserved)
        log_transformation_progress("Extracting game data with adaptive column detection", "dim_game", logger=logger)
        sql = get_game_data_sql(engine)
        raw_data = pd.read_sql(sql, engine)
        
        if raw_data.empty:
            logger.warning("No game data found in play_by_play table")
            return pd.DataFrame()
        
        log_transformation_progress("Extracted raw game data", "dim_game", len(raw_data), logger)
        
        # Step 2: Clean and standardize (V2 business logic preserved)  
        log_transformation_progress("Cleaning and standardizing game data", "dim_game", logger=logger)
        clean_data = clean_game_data(raw_data)
        
        # Step 3: Add sophisticated categorizations (V2 features preserved)
        log_transformation_progress("Adding weather categorization and game indicators", "dim_game", logger=logger)
        final_data = categorize_weather(clean_data)
        
        # Step 4: Validate data quality
        validation_result = validate_table_data(
            final_data, 
            'dim_game',
            required_columns=['game_id', 'season', 'game_date', 'home_team', 'away_team'],
            logger=logger
        )
        
        if validation_result['status'] == 'error':
            logger.error(f"dim_game validation failed: {validation_result['issues']}")
            return pd.DataFrame()
        
        logger.info(f"✓ Built dim_game: {len(final_data):,} games with {len(final_data.columns)} attributes")
        return final_data
        
    except Exception as e:
        logger.error(f"Failed to build dim_game: {e}", exc_info=True)
        return pd.DataFrame()


def create_dim_game_builder(engine=None, logger=None):
    """
    Create dim_game builder with default dependencies.
    
    Args:
        engine: Optional database engine override
        logger: Optional logger override
        
    Returns:
        function: Configured dim_game builder function
    """
    def _build_dim_game():
        return build_dim_game(engine, logger)
    
    return _build_dim_game
