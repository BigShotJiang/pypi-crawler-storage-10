"""
Warehouse transformation modules for nflfastRv3.

Clean architecture implementation following REFACTORING_SPECS.md:
- Maximum 5 complexity points per module
- Maximum 3 layers call depth
- Minimum Viable Decoupling pattern

Imports all transformation builders for warehouse construction.
"""

# Dimensional table builders
from .dimensions_core import build_dim_game
from .dimensions_team import build_dim_team
from .dimensions_player import build_dim_player
from .dimensions_calendar import build_dim_date, build_dim_drive

# Fact table builders  
from .facts_play import build_fact_play, build_fact_play_incremental, get_fact_play_summary
from .facts_player import build_fact_player_stats, build_fact_player_stats_incremental, get_fact_player_stats_summary, get_player_usage_analysis
from .facts_granular import build_fact_player_play, build_fact_player_play_incremental, get_fact_player_play_summary, get_player_contribution_analysis

# Utility functions
from .warehouse_utils import save_table_to_analytics, validate_table_data

__all__ = [
    # Dimension builders
    'build_dim_game',
    'build_dim_team', 
    'build_dim_player',
    'build_dim_date',
    'build_dim_drive',
    
    # Fact builders
    'build_fact_play',
    'build_fact_play_incremental', 
    'get_fact_play_summary',
    'build_fact_player_stats',
    'build_fact_player_stats_incremental',
    'get_fact_player_stats_summary',
    'get_player_usage_analysis',
    'build_fact_player_play',
    'build_fact_player_play_incremental',
    'get_fact_player_play_summary',
    'get_player_contribution_analysis',
    
    # Utilities
    'save_table_to_analytics',
    'validate_table_data'
]
