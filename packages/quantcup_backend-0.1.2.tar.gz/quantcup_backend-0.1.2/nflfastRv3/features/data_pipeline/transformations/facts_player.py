"""
Fact Player Stats Table Builder for nflfastRv3

Implements player statistics fact table with snap counts integration,
preserving V2's sophisticated player performance analytics.

Pattern: Enhanced simple functions with optional dependency injection
Complexity: 3 points (player stats integration + business logic)
Layer: 3 (uses SQL templates, cleaning functions, and warehouse utils)
"""

import pandas as pd
from typing import Dict, Any, Optional, List
from commonv2 import get_logger

from .sql_templates_facts import get_fact_player_stats_sql
from .cleaning_facts import clean_fact_player_stats_data
from .warehouse_utils import save_table_to_analytics, validate_table_data, create_table_summary


def build_fact_player_stats(db_service: Any, seasons: Optional[List[str]] = None,
                           logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_player_stats table with snap counts integration.
    
    V2 Features Preserved:
    - Multi-table joins (player_stats + snap_counts)
    - Comprehensive performance metrics
    - Fantasy scoring calculations
    - Efficiency metrics (catch rate, yards per carry, etc.)
    
    Args:
        db_service: Database service instance
        seasons: List of seasons to process (default: current season)
        logger: Optional logger instance
        
    Returns:
        Dict with build summary including row counts and validation results
        
    Complexity: Player stats integration with business logic (3 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_player')
    assert logger is not None
    logger.info("Starting fact_player_stats table build")
    
    try:
        # 1. Determine seasons to process
        if not seasons:
            from datetime import datetime
            current_year = datetime.now().year
            seasons = [str(current_year)]
        
        logger.info(f"Processing seasons: {seasons}")
        
        # 2. Get SQL query for player stats with snap counts
        sql_query = get_fact_player_stats_sql()
        
        # 3. Add season filtering if specified
        if seasons:
            season_list = "', '".join(seasons)
            # Add WHERE clause for seasons
            season_filter = f" AND ps.season IN ('{season_list}')"
            sql_query = sql_query.text.replace(
                "WHERE ps.player_id IS NOT NULL",
                f"WHERE ps.player_id IS NOT NULL{season_filter}"
            )
            from sqlalchemy import text
            sql_query = text(sql_query)
        
        logger.info("Generated player stats SQL query with snap counts integration")
        
        # 4. Execute query and retrieve data
        df = pd.read_sql(sql_query, db_service.engine)
        logger.info(f"Retrieved {len(df):,} player stat records")
        
        if df.empty:
            logger.warning("No player stats data found")
            return {
                'status': 'success',
                'rows_processed': 0,
                'rows_saved': 0,
                'message': 'No data found for specified seasons'
            }
        
        # 5. Clean and enhance data using V2 business logic
        cleaned_df = clean_fact_player_stats_data(df, logger)
        logger.info(f"Cleaned data: {len(cleaned_df):,} rows")
        
        # 6. Validate data quality
        validation_result = validate_table_data(cleaned_df, 'fact_player_stats')
        if validation_result['status'] != 'success':
            logger.warning(f"Data validation issues: {validation_result}")
        
        # 7. Save to analytics schema
        save_result = save_table_to_analytics(cleaned_df, 'fact_player_stats', db_service.engine, logger)
        
        if not save_result:
            raise Exception("Failed to save fact_player_stats table")
        
        # 8. Generate summary statistics
        summary = create_table_summary(cleaned_df, 'fact_player_stats')
        
        logger.info(f"✅ fact_player_stats build complete: {len(cleaned_df):,} rows")
        return {
            'status': 'success',
            'rows_processed': len(df),
            'rows_saved': len(cleaned_df),
            'seasons_processed': seasons,
            'validation_result': validation_result,
            'table_summary': summary
        }
        
    except Exception as e:
        logger.error(f"❌ fact_player_stats build failed: {e}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'seasons': seasons
        }


def build_fact_player_stats_incremental(db_service: Any, season: str, week: Optional[int] = None,
                                       logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_player_stats table incrementally for specific season/week.
    
    Optimized for real-time updates during season.
    
    Args:
        db_service: Database service instance
        season: Season to process (e.g., '2024')
        week: Optional specific week (default: all weeks in season)
        logger: Optional logger instance
        
    Returns:
        Dict with incremental build summary
        
    Complexity: Incremental processing logic (2 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_player')
    assert logger is not None
    logger.info(f"Starting incremental fact_player_stats build for season {season}")
    
    try:
        # 1. Build where conditions
        where_conditions = [f"ps.season = '{season}'"]
        if week is not None:
            where_conditions.append(f"ps.week = {week}")
        
        incremental_filter = " AND " + " AND ".join(where_conditions)
        logger.info(f"Incremental conditions: {incremental_filter}")
        
        # 2. Delete existing data for this season/week
        delete_conditions = [f"season = '{season}'"]
        if week is not None:
            delete_conditions.append(f"week = {week}")
        delete_where = " AND ".join(delete_conditions)
        
        delete_query = f"DELETE FROM analytics.fact_player_stats WHERE {delete_where}"
        db_service.engine.execute(delete_query)
        logger.info(f"Deleted existing data for {delete_where}")
        
        # 3. Get SQL with incremental filtering
        sql_query = get_fact_player_stats_sql()
        sql_query = sql_query.text.replace(
            "WHERE ps.player_id IS NOT NULL",
            f"WHERE ps.player_id IS NOT NULL{incremental_filter}"
        )
        from sqlalchemy import text
        sql_query = text(sql_query)
        
        # 4. Process incremental data
        df = pd.read_sql(sql_query, db_service.engine)
        logger.info(f"Retrieved {len(df):,} rows for incremental processing")
        
        if df.empty:
            logger.info("No data found for incremental build")
            return {
                'status': 'success',
                'rows_processed': 0,
                'rows_saved': 0,
                'incremental_type': f"season_{season}" + (f"_week_{week}" if week else ""),
                'season': season,
                'week': week
            }
        
        # 5. Clean and validate data
        cleaned_df = clean_fact_player_stats_data(df, logger)
        validation_result = validate_table_data(cleaned_df, 'fact_player_stats')
        
        # 6. Save incremental data
        with db_service.engine.begin() as conn:
            cleaned_df.to_sql(
                name='fact_player_stats',
                con=conn,
                schema='analytics',
                if_exists='append',
                index=False,
                method='multi'
            )
        
        # 7. Return summary
        return {
            'status': 'success',
            'rows_processed': len(df),
            'rows_saved': len(cleaned_df),
            'incremental_type': f"season_{season}" + (f"_week_{week}" if week else ""),
            'validation_result': validation_result,
            'season': season,
            'week': week
        }
        
    except Exception as e:
        logger.error(f"❌ Incremental fact_player_stats build failed: {e}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'season': season,
            'week': week
        }


def get_fact_player_stats_summary(db_service: Any, logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Get comprehensive summary of fact_player_stats table for monitoring.
    
    V2 Monitoring Features:
    - Player counts by position and team
    - Performance metrics distribution
    - Snap count coverage analysis
    
    Args:
        db_service: Database service instance
        logger: Optional logger instance
        
    Returns:
        Dict with comprehensive table summary
        
    Complexity: Simple aggregation function (2 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_player')
    assert logger is not None
    
    try:
        # Basic table summary
        sample_query = "SELECT * FROM analytics.fact_player_stats LIMIT 1000"
        sample_df = pd.read_sql(sample_query, db_service.engine)
        summary = create_table_summary(sample_df, 'fact_player_stats')
        
        # Position breakdown
        position_query = """
        SELECT 
            position_group,
            COUNT(DISTINCT player_id) as unique_players,
            COUNT(*) as total_records,
            AVG(fantasy_points_ppr) as avg_fantasy_points
        FROM analytics.fact_player_stats
        WHERE position_group IS NOT NULL
        GROUP BY position_group
        ORDER BY total_records DESC
        """
        
        position_df = pd.read_sql(position_query, db_service.engine)
        summary['position_breakdown'] = position_df.to_dict('records')
        
        # Season/team coverage
        coverage_query = """
        SELECT 
            season,
            COUNT(DISTINCT recent_team) as teams_covered,
            COUNT(DISTINCT player_id) as unique_players,
            COUNT(*) as total_records
        FROM analytics.fact_player_stats
        GROUP BY season
        ORDER BY season DESC
        """
        
        coverage_df = pd.read_sql(coverage_query, db_service.engine)
        summary['coverage_by_season'] = coverage_df.to_dict('records')
        
        # Data quality metrics
        quality_query = """
        SELECT 
            COUNT(*) as total_rows,
            COUNT(CASE WHEN offense_snaps IS NOT NULL THEN 1 END) as rows_with_snap_counts,
            COUNT(CASE WHEN fantasy_points_ppr > 0 THEN 1 END) as rows_with_fantasy_points,
            AVG(CASE WHEN targets > 0 THEN targets END) as avg_targets_when_targeted,
            COUNT(DISTINCT position) as unique_positions
        FROM analytics.fact_player_stats
        """
        
        quality_df = pd.read_sql(quality_query, db_service.engine)
        summary['data_quality'] = quality_df.to_dict('records')[0]
        
        # Top performers by position
        top_performers_query = """
        SELECT 
            position_group,
            player_name,
            recent_team,
            SUM(fantasy_points_ppr) as total_fantasy_points,
            SUM(targets) as total_targets,
            SUM(receptions) as total_receptions
        FROM analytics.fact_player_stats
        WHERE season = (SELECT MAX(season) FROM analytics.fact_player_stats)
            AND position_group IN ('QB', 'RB', 'WR', 'TE')
        GROUP BY position_group, player_name, recent_team
        HAVING SUM(fantasy_points_ppr) > 50
        ORDER BY position_group, total_fantasy_points DESC
        """
        
        top_performers_df = pd.read_sql(top_performers_query, db_service.engine)
        summary['top_performers'] = top_performers_df.to_dict('records')
        
        logger.info("Generated fact_player_stats table summary")
        return summary
        
    except Exception as e:
        logger.error(f"Failed to generate fact_player_stats summary: {e}", exc_info=True)
        return {'status': 'error', 'message': str(e)}


def get_player_usage_analysis(db_service: Any, season: str, position_group: Optional[str] = None,
                             logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Analyze player usage patterns for coaching insights.
    
    V2 Analytics Feature: Advanced usage pattern analysis
    
    Args:
        db_service: Database service instance
        season: Season to analyze
        position_group: Optional position filter (QB, RB, WR, TE)
        logger: Optional logger instance
        
    Returns:
        Dict with usage analysis results
        
    Complexity: Enhanced analytics function (3 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_player')
    assert logger is not None
    
    try:
        # Build position filter
        position_filter = ""
        if position_group:
            position_filter = f"AND position_group = '{position_group}'"
        
        # Usage patterns query
        usage_query = f"""
        SELECT 
            player_name,
            recent_team,
            position_group,
            COUNT(*) as games_played,
            AVG(offense_pct) as avg_snap_share,
            SUM(targets) as total_targets,
            SUM(carries) as total_carries,
            SUM(fantasy_points_ppr) as total_fantasy_points,
            
            -- Usage consistency (V2 metric)
            STDDEV(offense_pct) as snap_share_volatility,
            
            -- Opportunity metrics
            CASE 
                WHEN SUM(targets + carries) > 0 
                THEN SUM(fantasy_points_ppr) / SUM(targets + carries)
                ELSE 0 
            END as points_per_opportunity
            
        FROM analytics.fact_player_stats
        WHERE season = '{season}'
            AND offense_snaps > 0
            {position_filter}
        GROUP BY player_name, recent_team, position_group
        HAVING COUNT(*) >= 4  -- At least 4 games
        ORDER BY total_fantasy_points DESC
        LIMIT 100
        """
        
        usage_df = pd.read_sql(usage_query, db_service.engine)
        
        # Calculate usage tiers
        if not usage_df.empty:
            usage_df['usage_tier'] = pd.cut(
                usage_df['avg_snap_share'], 
                bins=[0, 0.3, 0.6, 1.0], 
                labels=['Limited', 'Rotational', 'Workhorse']
            )
        
        return {
            'status': 'success',
            'season': season,
            'position_group': position_group or 'All',
            'players_analyzed': len(usage_df),
            'usage_patterns': usage_df.to_dict('records')
        }
        
    except Exception as e:
        logger.error(f"Failed to generate usage analysis: {e}", exc_info=True)
        return {'status': 'error', 'message': str(e)}
