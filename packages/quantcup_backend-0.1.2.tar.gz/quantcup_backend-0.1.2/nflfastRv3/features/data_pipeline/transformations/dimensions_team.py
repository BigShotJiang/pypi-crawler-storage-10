"""
Team dimension builder for nflfastRv3.

Pattern: Enhanced simple function (3 complexity points)
- Base function: 1 point
- Multi-source integration: +1 point  
- Business logic coordination: +1 point

Preserves V2 sophistication:
- Multi-source data integration (teams + schedules)
- Adaptive schema detection for stadium data
- Stadium/venue categorization
- Team standardization
"""

import pandas as pd
from commonv2 import get_logger
from .sql_templates_dimensions import get_team_base_sql, get_team_stadium_sql
from .cleaning_dimensions import clean_team_data, standardize_stadium_data
from .warehouse_utils import validate_table_data, log_transformation_progress


def build_dim_team(engine, logger=None) -> pd.DataFrame:
    """
    Build team dimension with comprehensive team and stadium information.
    
    Preserves V2 features:
    - Teams table + stadium data from schedules
    - Adaptive column detection for stadium fields
    - Stadium categorization (dome, surface types)
    - Conference/division standardization
    
    Args:
        engine: SQLAlchemy database engine (Layer 3)
        logger: Optional logger override (Layer 3)
        
    Returns:
        pd.DataFrame: Complete team dimension
    """
    logger = logger or get_logger('nflfastRv3.transformations.team')
    logger.info("Building dim_team with V2 multi-source integration...")
    
    try:
        # Step 1: Get base team data
        log_transformation_progress("Extracting base team data", "dim_team", logger=logger)
        team_sql = get_team_base_sql()
        df_teams = pd.read_sql(team_sql, engine)
        log_transformation_progress("Extracted base team data", "dim_team", len(df_teams), logger)
        
        # Step 2: Get stadium data with adaptive schema detection (V2 feature)
        try:
            log_transformation_progress("Extracting stadium data with adaptive schema detection", "dim_team", logger=logger)
            stadium_sql = get_team_stadium_sql(engine)
            df_stadium = pd.read_sql(stadium_sql, engine)
            log_transformation_progress("Extracted stadium data", "dim_team", len(df_stadium), logger)
            
            # Merge team data with stadium info
            df = df_teams.merge(df_stadium, on='team_abbr', how='left')
            log_transformation_progress("Merged team and stadium data", "dim_team", len(df), logger)
            
        except Exception as e:
            logger.warning(f"Failed to get stadium data: {e}, using defaults")
            df = df_teams
            # Add default stadium columns
            df['stadium'] = 'Unknown'
            df['roof'] = 'Unknown'
            df['surface'] = 'Unknown'
            log_transformation_progress("Used default stadium values", "dim_team", logger=logger)
        
        # Step 3: Clean and standardize (V2 business logic preserved)
        log_transformation_progress("Cleaning and standardizing team data", "dim_team", logger=logger)
        df = clean_team_data(df)
        df = standardize_stadium_data(df)
        
        # Step 4: Validate data quality
        validation_result = validate_table_data(
            df, 
            'dim_team',
            required_columns=['team_abbr', 'team_name', 'conference', 'division'],
            logger=logger
        )
        
        if validation_result['status'] == 'error':
            logger.error(f"dim_team validation failed: {validation_result['issues']}")
            return pd.DataFrame()
        
        logger.info(f"✓ Built dim_team: {len(df)} teams with stadium data")
        return df
        
    except Exception as e:
        logger.error(f"Failed to build dim_team: {e}", exc_info=True)
        return pd.DataFrame()


def create_dim_team_builder(engine=None, logger=None):
    """
    Create dim_team builder with default dependencies.
    
    Args:
        engine: Optional database engine override
        logger: Optional logger override
        
    Returns:
        function: Configured dim_team builder function
    """
    def _build_dim_team():
        return build_dim_team(engine, logger)
    
    return _build_dim_team
