"""
Player dimension builder for nflfastRv3.

Pattern: Enhanced simple function (3 complexity points)
- Base function: 1 point
- Multi-source consolidation: +1 point
- Complex data enrichment: +1 point

Preserves V2 sophistication:
- 4-table data consolidation (players, rosters, ff_playerids, roster_ids)
- 15+ fantasy platform ID mappings
- Current team assignment logic
- Age calculations and position standardization
"""

import pandas as pd
from commonv2 import get_logger
from .sql_templates_dimensions import (
    get_player_base_sql, 
    get_player_current_team_sql, 
    get_player_fantasy_ids_sql
)
from .cleaning_dimensions import (
    clean_player_data, 
    calculate_player_age, 
    standardize_positions
)
from .warehouse_utils import validate_table_data, log_transformation_progress


def build_dim_player(engine, logger=None) -> pd.DataFrame:
    """
    Build player dimension with consolidated multi-source player data.
    
    Preserves V2 features:
    - Multi-source consolidation (players, rosters, fantasy IDs)
    - Comprehensive ID mapping for fantasy platforms
    - Current team assignment with recency logic
    - Age calculations and position standardization
    
    Args:
        engine: SQLAlchemy database engine (Layer 3)
        logger: Optional logger override (Layer 3)
        
    Returns:
        pd.DataFrame: Complete player dimension
    """
    logger = logger or get_logger('nflfastRv3.transformations.player')
    logger.info("Building dim_player with V2 multi-source consolidation...")
    
    try:
        # Step 1: Load base player data
        log_transformation_progress("Extracting base player data", "dim_player", logger=logger)
        base_sql = get_player_base_sql()
        df = pd.read_sql(base_sql, engine)
        log_transformation_progress("Extracted base player data", "dim_player", len(df), logger)
        
        if df.empty:
            logger.warning("No player data found in players table")
            return pd.DataFrame()
        
        # Step 2: Add current team assignments (V2 logic preserved)
        try:
            log_transformation_progress("Adding current team assignments", "dim_player", logger=logger)
            team_sql = get_player_current_team_sql()
            df_teams = pd.read_sql(team_sql, engine)
            df = df.merge(df_teams, on='gsis_id', how='left')
            log_transformation_progress("Added current team data", "dim_player", len(df_teams), logger)
        except Exception as e:
            logger.warning(f"Failed to get current team data: {e}")
            # Add default columns
            df['current_team'] = None
            df['current_season'] = None
            df['current_week'] = None
        
        # Step 3: Add fantasy platform IDs (V2 feature preserved)
        try:
            log_transformation_progress("Adding fantasy platform IDs", "dim_player", logger=logger)
            fantasy_sql = get_player_fantasy_ids_sql()
            df_fantasy = pd.read_sql(fantasy_sql, engine)
            
            # Merge fantasy IDs (handle duplicate columns)
            fantasy_merge_cols = [col for col in df_fantasy.columns 
                                if col not in df.columns or col == 'gsis_id']
            df = df.merge(df_fantasy[fantasy_merge_cols], on='gsis_id', how='left')
            log_transformation_progress("Added fantasy IDs", "dim_player", len(df_fantasy), logger)
        except Exception as e:
            logger.warning(f"Failed to get fantasy ID data: {e}")
            # Fantasy IDs are optional - continue without them
        
        # Step 4: Clean and enrich data (V2 business logic preserved)
        log_transformation_progress("Cleaning and standardizing player data", "dim_player", logger=logger)
        df = clean_player_data(df)
        df = calculate_player_age(df)
        df = standardize_positions(df)
        
        # Step 5: Validate data quality
        validation_result = validate_table_data(
            df, 
            'dim_player',
            required_columns=['gsis_id', 'player_name', 'position'],
            logger=logger
        )
        
        if validation_result['status'] == 'error':
            logger.error(f"dim_player validation failed: {validation_result['issues']}")
            return pd.DataFrame()
        
        logger.info(f"✓ Built dim_player: {len(df):,} players with complete ID mapping")
        return df
        
    except Exception as e:
        logger.error(f"Failed to build dim_player: {e}", exc_info=True)
        return pd.DataFrame()


def create_dim_player_builder(engine=None, logger=None):
    """
    Create dim_player builder with default dependencies.
    
    Args:
        engine: Optional database engine override
        logger: Optional logger override
        
    Returns:
        function: Configured dim_player builder function
    """
    def _build_dim_player():
        return build_dim_player(engine, logger)
    
    return _build_dim_player
