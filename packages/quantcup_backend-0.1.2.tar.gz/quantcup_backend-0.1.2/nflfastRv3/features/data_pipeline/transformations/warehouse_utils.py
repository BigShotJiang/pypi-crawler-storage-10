"""
Shared utilities for warehouse transformations.

Pattern: Simple utility functions (2 complexity points)
- Table save function: 1 point
- Validation function: 1 point

Following REFACTORING_SPECS.md: Stay within complexity budget while providing essential utilities.
"""

import pandas as pd
from commonv2 import get_logger
from typing import Dict, Any, Optional


def save_table_to_analytics(df: pd.DataFrame, table_name: str, engine, logger=None) -> bool:
    """
    Save DataFrame to analytics schema with error handling.
    
    Pattern: Simple save function (1 complexity point)
    
    Args:
        df: DataFrame to save
        table_name: Target table name in analytics schema
        engine: SQLAlchemy database engine
        logger: Optional logger instance
        
    Returns:
        bool: True if successful, False otherwise
    """
    logger = logger or get_logger('nflfastRv3.warehouse_utils')
    
    try:
        if df.empty:
            logger.warning(f"Cannot save empty DataFrame to {table_name}")
            return False
        
        logger.info(f"Saving {len(df):,} rows to analytics.{table_name}...")
        
        with engine.begin() as conn:
            df.to_sql(
                name=table_name,
                con=conn,
                schema='analytics',
                if_exists='replace',
                index=False,
                method='multi'
            )
        
        logger.info(f"✓ Successfully saved analytics.{table_name}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to save {table_name}: {e}")
        return False


def validate_table_data(df: pd.DataFrame, table_name: str, 
                       required_columns: Optional[list] = None, logger=None) -> Dict[str, Any]:
    """
    Validate DataFrame meets basic quality requirements.
    
    Pattern: Simple validation function (1 complexity point)
    
    Args:
        df: DataFrame to validate
        table_name: Table name for logging
        required_columns: List of required column names
        logger: Optional logger instance
        
    Returns:
        Dict: Validation results with status and details
    """
    logger = logger or get_logger('nflfastRv3.warehouse_utils')
    required_columns = required_columns or []
    
    validation_result = {
        'table_name': table_name,
        'status': 'success',
        'row_count': len(df),
        'column_count': len(df.columns),
        'issues': []
    }
    
    # Check if DataFrame is empty
    if df.empty:
        validation_result['status'] = 'warning'
        validation_result['issues'].append('DataFrame is empty')
        logger.warning(f"{table_name}: DataFrame is empty")
        return validation_result
    
    # Check for required columns
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        validation_result['status'] = 'error'
        validation_result['issues'].append(f'Missing required columns: {missing_columns}')
        logger.error(f"{table_name}: Missing required columns: {missing_columns}")
    
    # Check for completely null columns
    null_columns = [col for col in df.columns if df[col].isnull().all()]
    if null_columns:
        validation_result['status'] = 'warning'
        validation_result['issues'].append(f'Completely null columns: {null_columns}')
        logger.warning(f"{table_name}: Completely null columns: {null_columns}")
    
    # Check for duplicate rows
    duplicate_count = df.duplicated().sum()
    if duplicate_count > 0:
        validation_result['status'] = 'warning'
        validation_result['issues'].append(f'Found {duplicate_count} duplicate rows')
        logger.warning(f"{table_name}: Found {duplicate_count} duplicate rows")
    
    logger.info(f"{table_name}: Validation complete - {validation_result['status']}")
    return validation_result


def create_table_summary(df: pd.DataFrame, table_name: str) -> Dict[str, Any]:
    """
    Create summary statistics for a warehouse table.
    
    Args:
        df: DataFrame to summarize
        table_name: Table name for reference
        
    Returns:
        Dict: Summary statistics
    """
    if df.empty:
        return {
            'table_name': table_name,
            'row_count': 0,
            'column_count': 0,
            'memory_usage_mb': 0
        }
    
    return {
        'table_name': table_name,
        'row_count': len(df),
        'column_count': len(df.columns),
        'memory_usage_mb': round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
        'data_types': df.dtypes.value_counts().to_dict(),
        'null_percentages': (df.isnull().sum() / len(df) * 100).round(2).to_dict()
    }


def log_transformation_progress(step: str, table_name: str, row_count: Optional[int] = None, logger=None):
    """
    Log transformation progress in a consistent format.
    
    Args:
        step: Description of the transformation step
        table_name: Table being processed
        row_count: Optional row count for context
        logger: Optional logger instance
    """
    logger = logger or get_logger('nflfastRv3.warehouse_utils')
    
    if row_count is not None:
        logger.info(f"{table_name}: {step} ({row_count:,} rows)")
    else:
        logger.info(f"{table_name}: {step}")
