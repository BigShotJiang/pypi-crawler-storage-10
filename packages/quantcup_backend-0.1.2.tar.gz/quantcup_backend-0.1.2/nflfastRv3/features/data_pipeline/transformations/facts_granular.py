"""
Fact Player Play Table Builder for nflfastRv3

Implements granular player-play attribution fact table, preserving V2's
sophisticated individual performance attribution logic.

Pattern: Enhanced simple functions with optional dependency injection
Complexity: 4 points (complex attribution + business logic + data processing)
Layer: 3 (uses SQL templates, cleaning functions, and warehouse utils)
"""

import pandas as pd
from typing import Dict, Any, Optional, List
from commonv2 import get_logger

from .sql_templates_facts import get_fact_player_play_sql
from .cleaning_facts import clean_fact_player_play_data
from .warehouse_utils import save_table_to_analytics, validate_table_data, create_table_summary


def build_fact_player_play(db_service: Any, seasons: Optional[List[str]] = None,
                          chunk_size: int = 10000, logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_player_play table with individual performance attribution.
    
    V2 Features Preserved:
    - Player involvement detection and classification
    - EPA attribution to individual players
    - Usage rate and opportunity calculations
    - Position-specific performance metrics
    - Chunked processing for large datasets
    
    Args:
        db_service: Database service instance
        seasons: List of seasons to process (default: current season)
        chunk_size: Number of rows per chunk (default: 10000)
        logger: Optional logger instance
        
    Returns:
        Dict with build summary including row counts and performance metrics
        
    Complexity: Complex attribution with chunked processing (4 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_granular')
    assert logger is not None
    logger.info("Starting fact_player_play table build with individual attribution")
    
    # Initialize summary tracking
    build_summary = {
        'status': 'success',
        'total_rows_processed': 0,
        'total_rows_saved': 0,
        'chunks_processed': 0,
        'seasons_processed': 0,
        'performance_metrics': {},
        'validation_results': {}
    }
    
    try:
        # 1. Determine seasons to process
        if not seasons:
            from datetime import datetime
            current_year = datetime.now().year
            seasons = [str(current_year)]
        
        logger.info(f"Processing seasons: {seasons}")
        build_summary['seasons_processed'] = len(seasons)
        
        # 2. Get SQL query for player-play attribution
        sql_query = get_fact_player_play_sql()
        
        # 3. Add season filtering if specified
        if seasons:
            season_list = "', '".join(seasons)
            # Add season filter to the WHERE clause in each UNION part
            season_filter = f" AND EXTRACT(YEAR FROM p.game_date) IN ('{season_list}')"
            sql_query_text = sql_query.text
            
            # Apply filter to each UNION section
            sql_query_text = sql_query_text.replace(
                "WHERE p.passer_id IS NOT NULL",
                f"WHERE p.passer_id IS NOT NULL{season_filter}"
            ).replace(
                "WHERE p.rusher_id IS NOT NULL", 
                f"WHERE p.rusher_id IS NOT NULL{season_filter}"
            ).replace(
                "WHERE p.receiver_id IS NOT NULL",
                f"WHERE p.receiver_id IS NOT NULL{season_filter}"
            )
            
            from sqlalchemy import text
            sql_query = text(sql_query_text)
        
        logger.info("Generated player-play attribution SQL query")
        
        # 4. Process data in chunks (large dataset expected)
        total_processed = 0
        chunk_number = 0
        
        logger.info(f"Reading data in chunks of {chunk_size:,} rows")
        chunk_iterator = pd.read_sql(sql_query, db_service.engine, chunksize=chunk_size)
        
        for chunk_df in chunk_iterator:
            chunk_number += 1
            chunk_start_rows = len(chunk_df)
            
            logger.info(f"Processing chunk {chunk_number}: {chunk_start_rows:,} rows")
            
            # 5. Clean chunk data using V2 business logic
            cleaned_chunk = clean_fact_player_play_data(chunk_df, logger)
            
            # 6. Validate chunk data quality
            validation_result = validate_table_data(cleaned_chunk, 'fact_player_play')
            if validation_result['status'] != 'success':
                logger.warning(f"Chunk {chunk_number} validation issues: {validation_result}")
            
            # 7. Save chunk to analytics schema
            if chunk_number == 1:
                # First chunk - replace table
                save_result = save_table_to_analytics(cleaned_chunk, 'fact_player_play', db_service.engine, logger)
            else:
                # Subsequent chunks - append data
                with db_service.engine.begin() as conn:
                    cleaned_chunk.to_sql(
                        name='fact_player_play',
                        con=conn,
                        schema='analytics',
                        if_exists='append',
                        index=False,
                        method='multi'
                    )
                save_result = True
            
            # 8. Update summary metrics
            total_processed += chunk_start_rows
            build_summary['total_rows_processed'] += chunk_start_rows
            build_summary['total_rows_saved'] += len(cleaned_chunk)
            build_summary['chunks_processed'] = chunk_number
            
            # Store validation results for this chunk
            build_summary['validation_results'][f'chunk_{chunk_number}'] = validation_result
            
            logger.info(f"Chunk {chunk_number} complete: {len(cleaned_chunk):,} rows saved")
        
        # 9. Final validation and summary
        logger.info(f"Chunked processing complete: {total_processed:,} total rows processed")
        
        # Create table summary for final validation
        final_validation_query = "SELECT COUNT(*) as row_count FROM analytics.fact_player_play"
        final_count = pd.read_sql(final_validation_query, db_service.engine).iloc[0]['row_count']
        
        build_summary['final_table_count'] = final_count
        build_summary['performance_metrics'] = {
            'avg_chunk_size': total_processed / chunk_number if chunk_number > 0 else 0,
            'total_chunks': chunk_number,
            'processing_efficiency': build_summary['total_rows_saved'] / build_summary['total_rows_processed'] if build_summary['total_rows_processed'] > 0 else 0
        }
        
        logger.info(f"✅ fact_player_play build complete: {final_count:,} rows in final table")
        return build_summary
        
    except Exception as e:
        logger.error(f"❌ fact_player_play build failed: {e}", exc_info=True)
        build_summary['status'] = 'error'
        build_summary['message'] = str(e)
        return build_summary


def build_fact_player_play_incremental(db_service: Any, season: str, week: Optional[int] = None,
                                     logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Build fact_player_play table incrementally for specific season/week.
    
    Optimized for real-time updates during season.
    
    Args:
        db_service: Database service instance
        season: Season to process (e.g., '2024')
        week: Optional specific week (default: all weeks in season)
        logger: Optional logger instance
        
    Returns:
        Dict with incremental build summary
        
    Complexity: Incremental processing with attribution logic (3 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_granular')
    assert logger is not None
    logger.info(f"Starting incremental fact_player_play build for season {season}")
    
    try:
        # 1. Build incremental conditions
        incremental_conditions = [f"EXTRACT(YEAR FROM p.game_date) = {season}"]
        if week is not None:
            incremental_conditions.append(f"p.week = {week}")
        
        incremental_filter = " AND " + " AND ".join(incremental_conditions)
        logger.info(f"Incremental conditions: {incremental_filter}")
        
        # 2. Delete existing data for this season/week
        delete_conditions = [f"EXTRACT(YEAR FROM game_date) = {season}"]
        if week is not None:
            delete_conditions.append(f"week = {week}")
        delete_where = " AND ".join(delete_conditions)
        
        delete_query = f"DELETE FROM analytics.fact_player_play WHERE {delete_where}"
        db_service.engine.execute(delete_query)
        logger.info(f"Deleted existing data for {delete_where}")
        
        # 3. Get SQL with incremental filtering
        sql_query = get_fact_player_play_sql()
        sql_query_text = sql_query.text
        
        # Apply incremental filter to each UNION section
        sql_query_text = sql_query_text.replace(
            "WHERE p.passer_id IS NOT NULL",
            f"WHERE p.passer_id IS NOT NULL{incremental_filter}"
        ).replace(
            "WHERE p.rusher_id IS NOT NULL",
            f"WHERE p.rusher_id IS NOT NULL{incremental_filter}"
        ).replace(
            "WHERE p.receiver_id IS NOT NULL",
            f"WHERE p.receiver_id IS NOT NULL{incremental_filter}"
        )
        
        from sqlalchemy import text
        sql_query = text(sql_query_text)
        
        # 4. Process incremental data
        df = pd.read_sql(sql_query, db_service.engine)
        logger.info(f"Retrieved {len(df):,} rows for incremental processing")
        
        if df.empty:
            logger.info("No data found for incremental build")
            return {
                'status': 'success',
                'rows_processed': 0,
                'rows_saved': 0,
                'incremental_type': f"season_{season}" + (f"_week_{week}" if week else ""),
                'season': season,
                'week': week
            }
        
        # 5. Clean and validate data
        cleaned_df = clean_fact_player_play_data(df, logger)
        validation_result = validate_table_data(cleaned_df, 'fact_player_play')
        
        # 6. Save incremental data
        with db_service.engine.begin() as conn:
            cleaned_df.to_sql(
                name='fact_player_play',
                con=conn,
                schema='analytics',
                if_exists='append',
                index=False,
                method='multi'
            )
        
        # 7. Return summary
        return {
            'status': 'success',
            'rows_processed': len(df),
            'rows_saved': len(cleaned_df),
            'incremental_type': f"season_{season}" + (f"_week_{week}" if week else ""),
            'validation_result': validation_result,
            'season': season,
            'week': week
        }
        
    except Exception as e:
        logger.error(f"❌ Incremental fact_player_play build failed: {e}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'season': season,
            'week': week
        }


def get_fact_player_play_summary(db_service: Any, logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Get comprehensive summary of fact_player_play table for monitoring.
    
    V2 Monitoring Features:
    - Player involvement breakdown by type
    - EPA attribution analysis
    - Usage pattern metrics
    
    Args:
        db_service: Database service instance
        logger: Optional logger instance
        
    Returns:
        Dict with comprehensive table summary
        
    Complexity: Simple aggregation function (2 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_granular')
    assert logger is not None
    
    try:
        # Basic table summary
        sample_query = "SELECT * FROM analytics.fact_player_play LIMIT 1000"
        sample_df = pd.read_sql(sample_query, db_service.engine)
        summary = create_table_summary(sample_df, 'fact_player_play')
        
        # Involvement type breakdown
        involvement_query = """
        SELECT 
            involvement_type,
            side_of_ball,
            COUNT(*) as total_plays,
            COUNT(DISTINCT player_id) as unique_players,
            AVG(attributed_epa) as avg_epa_attributed,
            SUM(opportunity_count) as total_opportunities
        FROM analytics.fact_player_play
        GROUP BY involvement_type, side_of_ball
        ORDER BY total_plays DESC
        """
        
        involvement_df = pd.read_sql(involvement_query, db_service.engine)
        summary['involvement_breakdown'] = involvement_df.to_dict('records')
        
        # Top EPA contributors
        top_epa_query = """
        SELECT 
            player_name,
            involvement_type,
            COUNT(*) as total_plays,
            SUM(attributed_epa) as total_epa_attributed,
            AVG(attributed_epa) as avg_epa_per_play,
            SUM(stat_value) as total_stat_value
        FROM analytics.fact_player_play
        WHERE attributed_epa IS NOT NULL
        GROUP BY player_name, involvement_type
        HAVING COUNT(*) >= 20  -- At least 20 plays
        ORDER BY total_epa_attributed DESC
        LIMIT 50
        """
        
        top_epa_df = pd.read_sql(top_epa_query, db_service.engine)
        summary['top_epa_contributors'] = top_epa_df.to_dict('records')
        
        # Data quality metrics
        quality_query = """
        SELECT 
            COUNT(*) as total_rows,
            COUNT(CASE WHEN attributed_epa IS NOT NULL THEN 1 END) as rows_with_epa,
            COUNT(CASE WHEN stat_value > 0 THEN 1 END) as rows_with_positive_stats,
            COUNT(DISTINCT player_id) as unique_players,
            COUNT(DISTINCT game_id) as unique_games,
            AVG(opportunity_count) as avg_opportunities_per_play
        FROM analytics.fact_player_play
        """
        
        quality_df = pd.read_sql(quality_query, db_service.engine)
        summary['data_quality'] = quality_df.to_dict('records')[0]
        
        logger.info("Generated fact_player_play table summary")
        return summary
        
    except Exception as e:
        logger.error(f"Failed to generate fact_player_play summary: {e}", exc_info=True)
        return {'status': 'error', 'message': str(e)}


def get_player_contribution_analysis(db_service: Any, season: str, position_type: str = 'QB',
                                    logger: Optional[Any] = None) -> Dict[str, Any]:
    """
    Analyze individual player contributions to team success.
    
    V2 Analytics Feature: Advanced player contribution metrics
    
    Args:
        db_service: Database service instance
        season: Season to analyze
        position_type: Position involvement type ('QB', 'RB', 'WR', etc.)
        logger: Optional logger instance
        
    Returns:
        Dict with contribution analysis results
        
    Complexity: Enhanced analytics function (3 points)
    """
    logger = logger or get_logger('nflfastRv3.facts_granular')
    assert logger is not None
    
    try:
        # Player contribution analysis query
        contribution_query = f"""
        SELECT 
            player_name,
            posteam as team,
            COUNT(*) as total_plays,
            SUM(attributed_epa) as total_epa_contribution,
            AVG(attributed_epa) as avg_epa_per_play,
            SUM(stat_value) as total_production,
            SUM(opportunity_count) as total_opportunities,
            
            -- Efficiency metrics
            CASE 
                WHEN SUM(opportunity_count) > 0 
                THEN SUM(attributed_epa) / SUM(opportunity_count)
                ELSE 0 
            END as epa_per_opportunity,
            
            -- Situational performance
            AVG(CASE WHEN down >= 3 THEN attributed_epa END) as third_down_epa,
            AVG(CASE WHEN yardline_100 <= 20 THEN attributed_epa END) as red_zone_epa,
            
            -- Consistency metrics
            STDDEV(attributed_epa) as epa_volatility
            
        FROM analytics.fact_player_play
        WHERE EXTRACT(YEAR FROM game_date) = {season}
            AND involvement_type = '{position_type}'
            AND attributed_epa IS NOT NULL
        GROUP BY player_name, posteam
        HAVING COUNT(*) >= 20  -- Minimum play threshold
        ORDER BY total_epa_contribution DESC
        LIMIT 50
        """
        
        contribution_df = pd.read_sql(contribution_query, db_service.engine)
        
        # Calculate percentile rankings
        if not contribution_df.empty:
            contribution_df['epa_percentile'] = contribution_df['total_epa_contribution'].rank(pct=True)
            contribution_df['efficiency_percentile'] = contribution_df['epa_per_opportunity'].rank(pct=True)
        
        return {
            'status': 'success',
            'season': season,
            'position_type': position_type,
            'players_analyzed': len(contribution_df),
            'contribution_analysis': contribution_df.to_dict('records')
        }
        
    except Exception as e:
        logger.error(f"Failed to generate contribution analysis: {e}", exc_info=True)
        return {'status': 'error', 'message': str(e)}
