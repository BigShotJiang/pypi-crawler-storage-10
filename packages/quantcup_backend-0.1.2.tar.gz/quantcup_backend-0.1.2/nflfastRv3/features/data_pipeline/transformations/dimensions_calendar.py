"""
Calendar dimension builders for nflfastRv3.

Pattern: Enhanced simple functions (3 complexity points)
- Date dimension builder: 1 point
- Drive dimension builder: 1 point  
- NFL calendar logic: +1 point

Preserves V2 sophistication:
- NFL season calendar logic
- Drive situation analysis
- Temporal pattern support
"""

import pandas as pd
from datetime import datetime, timedelta
from commonv2 import get_logger
from .warehouse_utils import validate_table_data, log_transformation_progress


def build_dim_date(start_year=1999, end_year=None, logger=None) -> pd.DataFrame:
    """
    Build date dimension with NFL season calendar logic.
    
    Preserves V2 features:
    - NFL season boundaries (September - February)
    - Week type classification (preseason/regular/playoffs)
    - Holiday and scheduling context
    
    Args:
        start_year: First NFL season to include
        end_year: Last NFL season to include (default: current + 1)
        logger: Optional logger override
        
    Returns:
        pd.DataFrame: Complete date dimension
    """
    logger = logger or get_logger('nflfastRv3.transformations.calendar')
    
    # Default to current season + 1 for future scheduling
    if end_year is None:
        current_year = datetime.now().year
        end_year = current_year + 1
    
    logger.info(f"Building dim_date for NFL seasons {start_year}-{end_year}...")
    
    # Generate date range covering all NFL seasons
    start_date = datetime(start_year - 1, 3, 1)  # Start before season for offseason
    end_date = datetime(end_year + 1, 2, 28)     # End after season for playoffs
    
    date_range = pd.date_range(start=start_date, end=end_date, freq='D')
    
    df = pd.DataFrame({'date': date_range})
    
    # Basic date components
    df['year'] = df['date'].dt.year
    df['month'] = df['date'].dt.month
    df['day'] = df['date'].dt.day
    df['day_of_week'] = df['date'].dt.day_name()
    df['day_of_year'] = df['date'].dt.dayofyear
    df['week_of_year'] = df['date'].dt.isocalendar().week
    df['quarter'] = df['date'].dt.quarter
    
    # NFL season logic (key V2 feature)
    df['nfl_season'] = df.apply(_calculate_nfl_season, axis=1)
    df['season_type'] = df.apply(_classify_season_type, axis=1)
    
    # Game scheduling context
    df['is_weekend'] = df['date'].dt.dayofweek.isin([5, 6])  # Saturday, Sunday
    df['is_weekday'] = ~df['is_weekend']
    df['is_thursday'] = df['date'].dt.dayofweek == 3
    df['is_monday'] = df['date'].dt.dayofweek == 0
    
    # Holiday detection (affects scheduling)
    df['is_holiday'] = df['date'].apply(_is_nfl_relevant_holiday)
    
    # Validation
    validation_result = validate_table_data(
        df, 
        'dim_date',
        required_columns=['date', 'nfl_season', 'season_type'],
        logger=logger
    )
    
    logger.info(f"✓ Built dim_date: {len(df):,} dates for {end_year - start_year + 1} NFL seasons")
    return df


def build_dim_drive(engine, logger=None) -> pd.DataFrame:
    """
    Build drive dimension with situational context.
    
    Preserves V2 features:
    - Drive outcome classification
    - Field position analysis
    - Scoring context
    
    Args:
        engine: SQLAlchemy database engine
        logger: Optional logger override
        
    Returns:
        pd.DataFrame: Complete drive dimension
    """
    logger = logger or get_logger('nflfastRv3.transformations.calendar')
    logger.info("Building dim_drive with situational analysis...")
    
    # Extract drive-level data from play_by_play
    drive_sql = """
    SELECT DISTINCT
        CONCAT(game_id, '-', COALESCE(drive, 0)) as drive_key,
        game_id,
        drive,
        posteam as drive_team,
        defteam as defense_team,
        
        -- Drive boundaries
        MIN(play_id) as first_play_id,
        MAX(play_id) as last_play_id,
        COUNT(*) as drive_plays,
        
        -- Field position
        MAX(yardline_100) as drive_start_yardline,
        MIN(yardline_100) as drive_end_yardline,
        
        -- Drive outcome
        MAX(CASE WHEN touchdown = true THEN 1 ELSE 0 END) as drive_touchdown,
        MAX(CASE WHEN field_goal_attempt = true AND field_goal_result = 'made' THEN 1 ELSE 0 END) as drive_field_goal,
        MAX(CASE WHEN punt_attempt = true THEN 1 ELSE 0 END) as drive_punt,
        
        -- Drive efficiency
        SUM(COALESCE(epa, 0)) as drive_total_epa,
        SUM(yards_gained) as drive_total_yards
        
    FROM raw_nflfastr.play_by_play
    WHERE game_id IS NOT NULL 
        AND drive IS NOT NULL
        AND posteam IS NOT NULL
    GROUP BY game_id, drive, posteam, defteam
    """
    
    try:
        log_transformation_progress("Extracting drive data from play_by_play", "dim_drive", logger=logger)
        df = pd.read_sql(drive_sql, engine)
        log_transformation_progress("Extracted drive data", "dim_drive", len(df), logger)
        
        if df.empty:
            logger.warning("No drive data found")
            return pd.DataFrame()
        
        # Calculate derived drive metrics
        log_transformation_progress("Calculating derived drive metrics", "dim_drive", logger=logger)
        df['drive_net_yards'] = df['drive_start_yardline'] - df['drive_end_yardline']
        df['drive_avg_epa'] = df['drive_total_epa'] / df['drive_plays']
        
        # Classify drive outcomes
        df['drive_outcome'] = df.apply(_classify_drive_outcome, axis=1)
        df['drive_success'] = df['drive_outcome'].isin(['Touchdown', 'Field Goal'])
        
        # Field position categories
        df['drive_start_field_position'] = pd.cut(
            df['drive_start_yardline'], 
            bins=[0, 20, 50, 80, 100], 
            labels=['Red Zone', 'Short Field', 'Mid Field', 'Long Field']
        )
        
        # Validation
        validation_result = validate_table_data(
            df, 
            'dim_drive',
            required_columns=['drive_key', 'game_id', 'drive_team'],
            logger=logger
        )
        
        logger.info(f"✓ Built dim_drive: {len(df):,} drives with outcome analysis")
        return df
        
    except Exception as e:
        logger.error(f"Failed to build dim_drive: {e}", exc_info=True)
        return pd.DataFrame()


# Helper functions (simple, 1 complexity point each)
def _calculate_nfl_season(row):
    """Calculate NFL season from date (V2 logic)."""
    date = row['date']
    if date.month >= 3:  # March onwards = same year season
        return date.year
    else:  # Jan-Feb = previous year season  
        return date.year - 1


def _classify_season_type(row):
    """Classify date into season type (V2 logic)."""
    month = row['date'].month
    if month in [8]:  # August
        return 'PRE'
    elif month in [9, 10, 11, 12]:  # Sep-Dec
        return 'REG'  
    elif month in [1, 2]:  # Jan-Feb
        return 'POST'
    else:
        return 'OFF'  # Offseason


def _is_nfl_relevant_holiday(date):
    """Check if date is a relevant holiday for NFL scheduling."""
    # Thanksgiving (affects Thursday games)
    thanksgiving = datetime(date.year, 11, 1)
    while thanksgiving.weekday() != 3:  # Find 4th Thursday
        thanksgiving += timedelta(days=1)
    if thanksgiving.day > 21:
        thanksgiving += timedelta(days=7)
    
    if date.date() == thanksgiving.date():
        return True
    
    # Christmas, New Year's (affect scheduling)
    holidays = [
        datetime(date.year, 12, 25).date(),  # Christmas
        datetime(date.year, 1, 1).date(),    # New Year's
    ]
    
    return date.date() in holidays


def _classify_drive_outcome(row):
    """Classify drive outcome based on result flags."""
    if row['drive_touchdown']:
        return 'Touchdown'
    elif row['drive_field_goal']:
        return 'Field Goal'
    elif row['drive_punt']:
        return 'Punt'
    else:
        return 'Other'
