"""
Analytics Suite - NFL Data Analysis Capabilities

Pattern: Minimum Viable Decoupling
Complexity: 2 points average across modules
Layer: 2 (Implementation - calls infrastructure directly)

This module provides comprehensive analytics capabilities for NFL data including:
- Exploratory data analysis
- Feature analysis and quality assessment  
- Multicollinearity detection
- Team performance analysis
- Seasonal trend analysis

All components follow the V3 clean architecture patterns with:
- Maximum 3 layers depth
- 5 complexity points budget per module
- Dependency injection throughout
- Direct infrastructure calls (no complex patterns)

Example Usage:
    from nflfastRv3.features.analytics_suite import create_analytics_suite
    
    analytics = create_analytics_suite()
    
    # Run exploratory analysis
    results = analytics.process('exploratory')
    
    # Run feature analysis
    results = analytics.process('feature_analysis')
"""

from .main import AnalyticsImpl, create_analytics_suite
from .exploratory import ExploratoryAnalysisImpl, create_exploratory_analysis
from .feature_analysis import FeatureAnalysisImpl, create_feature_analysis


def validate_analytics_architecture():
    """
    Validate analytics suite architecture constraints.
    
    Returns:
        dict: Validation results for all components
    """
    validation_results = {
        'overall_status': 'success',
        'components': {},
        'architecture_summary': {
            'max_layers': 3,
            'complexity_budget': 5,
            'pattern': 'Minimum Viable Decoupling'
        }
    }
    
    try:
        # Test main analytics orchestration
        from commonv2 import get_logger
        from ...shared.database import NFLfastRDatabase
        
        # Create mock services for validation
        db_service = None  # Will use default
        logger = get_logger('validation')
        
        # Validate main analytics component
        analytics = AnalyticsImpl(db_service, logger)
        main_validation = analytics.validate_call_depth()
        validation_results['components']['main'] = main_validation
        
        # Validate exploratory analysis component
        exploratory = ExploratoryAnalysisImpl(db_service, logger)
        exploratory_validation = exploratory.validate_call_depth()
        validation_results['components']['exploratory'] = exploratory_validation
        
        # Validate feature analysis component
        feature_analysis = FeatureAnalysisImpl(db_service, logger)
        feature_validation = feature_analysis.validate_call_depth()
        validation_results['components']['feature_analysis'] = feature_validation
        
        # Check overall compliance
        all_within_limits = all(
            comp['within_limits'] for comp in validation_results['components'].values()
        )
        
        all_correct_pattern = all(
            comp['pattern'] == 'Minimum Viable Decoupling' 
            for comp in validation_results['components'].values()
        )
        
        all_correct_complexity = all(
            comp['complexity_points'] <= 5 
            for comp in validation_results['components'].values()
        )
        
        if not (all_within_limits and all_correct_pattern and all_correct_complexity):
            validation_results['overall_status'] = 'failed'
            validation_results['issues'] = []
            
            if not all_within_limits:
                validation_results['issues'].append('Some components exceed layer depth limits')
            if not all_correct_pattern:
                validation_results['issues'].append('Some components use incorrect patterns')
            if not all_correct_complexity:
                validation_results['issues'].append('Some components exceed complexity budget')
        
    except Exception as e:
        validation_results['overall_status'] = 'error'
        validation_results['error'] = str(e)
    
    return validation_results


def run_integration_test():
    """
    Run integration test for analytics suite.
    
    Returns:
        dict: Integration test results
    """
    test_results = {
        'status': 'success',
        'tests_run': [],
        'tests_passed': 0,
        'tests_failed': 0
    }
    
    try:
        # Test 1: Architecture validation
        test_results['tests_run'].append('architecture_validation')
        arch_results = validate_analytics_architecture()
        if arch_results['overall_status'] == 'success':
            test_results['tests_passed'] += 1
        else:
            test_results['tests_failed'] += 1
            test_results['architecture_validation_error'] = arch_results.get('error', 'Failed validation')
        
        # Test 2: Component creation
        test_results['tests_run'].append('component_creation')
        try:
            analytics = create_analytics_suite()
            exploratory = create_exploratory_analysis()
            feature_analysis = create_feature_analysis()
            test_results['tests_passed'] += 1
        except Exception as e:
            test_results['tests_failed'] += 1
            test_results['component_creation_error'] = str(e)
        
        # Test 3: Analytics orchestration
        test_results['tests_run'].append('analytics_orchestration')
        try:
            analytics = create_analytics_suite()
            # Test with mock data (won't actually connect to DB)
            test_results['tests_passed'] += 1
        except Exception as e:
            test_results['tests_failed'] += 1
            test_results['orchestration_error'] = str(e)
        
        # Update overall status
        if test_results['tests_failed'] > 0:
            test_results['status'] = 'failed'
        
        test_results['summary'] = f"{test_results['tests_passed']}/{len(test_results['tests_run'])} tests passed"
        
    except Exception as e:
        test_results['status'] = 'error'
        test_results['error'] = str(e)
    
    return test_results


__all__ = [
    'AnalyticsImpl',
    'ExploratoryAnalysisImpl', 
    'FeatureAnalysisImpl',
    'create_analytics_suite',
    'create_exploratory_analysis',
    'create_feature_analysis',
    'validate_analytics_architecture',
    'run_integration_test'
]
