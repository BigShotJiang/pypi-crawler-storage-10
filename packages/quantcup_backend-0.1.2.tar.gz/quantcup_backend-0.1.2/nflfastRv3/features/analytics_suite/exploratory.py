"""
Exploratory Analysis Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Follows clean architecture with maximum 3 layers:
Layer 1: Public API (nflfastRv3/__init__.py)
Layer 2: This implementation
Layer 3: Infrastructure (database, validation)

Migrated from nflfastRv2/features/analytics_suite/exploratory.py
with V3 clean architecture patterns applied.
"""

import pandas as pd
from typing import Dict, Any, List, Optional
from sqlalchemy import text


class ExploratoryAnalysisImpl:
    """
    Core exploratory analysis business logic.
    
    Pattern: Minimum Viable Decoupling (⭐ RECOMMENDED START)
    Complexity: 2 points
    Depth: 1 layer (calls infrastructure directly)
    
    Responsibilities:
    - Run comprehensive exploratory analysis on NFL data
    - Generate data overview and insights
    - Analyze team performance metrics
    - Examine seasonal trends and game factors
    - No complex patterns or abstractions
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
    
    def run_exploratory_analysis(self, **kwargs) -> Dict[str, Any]:
        """
        Run comprehensive exploratory analysis on NFL data.
        
        Simple analysis flow:
        1. Get data overview (Layer 3 call)
        2. Analyze team performance (Layer 3 call)
        3. Examine seasonal trends (Layer 3 call)
        4. Study game factors (Layer 3 call)
        5. Return combined results
        
        Args:
            **kwargs: Additional analysis options
            
        Returns:
            Dictionary with exploratory analysis results
        """
        self.logger.info("Starting exploratory data analysis")
        
        try:
            analysis_results = {
                'status': 'success',
                'data_overview': self._get_data_overview(),
                'team_performance': self._analyze_team_performance(),
                'seasonal_trends': self._analyze_seasonal_trends(),
                'game_factors': self._analyze_game_factors()
            }
            
            self.logger.info("Exploratory analysis completed successfully")
            return analysis_results
            
        except Exception as e:
            self.logger.error(f"Exploratory analysis failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def analyze_team_performance(self, season: int = 2024, **kwargs) -> Dict[str, Any]:
        """
        Analyze team performance metrics for a given season.
        
        Args:
            season: NFL season to analyze
            **kwargs: Additional analysis options
            
        Returns:
            Dictionary with team performance insights
        """
        self.logger.info(f"Analyzing team performance for {season} season")
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Team performance query for specific season
                team_query = text("""
                    SELECT 
                        posteam as team,
                        COUNT(*) as total_plays,
                        AVG(yards_gained) as avg_yards_per_play,
                        SUM(CASE WHEN touchdown = 1 THEN 1 ELSE 0 END) as touchdowns,
                        SUM(CASE WHEN interception = 1 THEN 1 ELSE 0 END) as interceptions,
                        SUM(CASE WHEN fumble_lost = 1 THEN 1 ELSE 0 END) as fumbles_lost
                    FROM raw_nflfastr.play_by_play 
                    WHERE posteam IS NOT NULL 
                    AND season = :season
                    GROUP BY posteam
                    ORDER BY avg_yards_per_play DESC
                """)
                
                result = conn.execute(team_query, {"season": season}).fetchall()
                
                team_stats = []
                for row in result:
                    team_stats.append({
                        'team': row[0],
                        'total_plays': row[1],
                        'avg_yards_per_play': round(float(row[2]) if row[2] else 0, 2),
                        'touchdowns': row[3],
                        'interceptions': row[4],
                        'fumbles_lost': row[5],
                        'efficiency_score': round(float(row[2]) if row[2] else 0, 2) - (row[4] + row[5]) * 0.5
                    })
                
                analysis_results = {
                    "season": season,
                    "teams_analyzed": len(team_stats),
                    "team_performance": team_stats,
                    "insights": self._generate_team_insights(team_stats)
                }
                
                self.logger.info(f"Team performance analysis complete for {season}")
                return analysis_results
                
        except Exception as e:
            self.logger.error(f"Team performance analysis failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'season': season
            }
    
    def _get_data_overview(self) -> Dict[str, Any]:
        """
        Get overview of available data.
        
        Direct database calls (Layer 3) - no complex patterns
        
        Returns:
            dict: Data overview results
        """
        self.logger.info("Generating data overview")
        
        overview = {
            'schemas': {},
            'total_records': 0,
            'date_range': {}
        }
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Check raw data schema
                try:
                    raw_tables_query = text("""
                        SELECT table_name, 
                               (xpath('/row/cnt/text()', xml_count))[1]::text::int as row_count
                        FROM (
                            SELECT table_name, 
                                   query_to_xml(format('select count(*) as cnt from raw_nflfastr.%I', table_name), false, true, '') as xml_count
                            FROM information_schema.tables 
                            WHERE table_schema = 'raw_nflfastr' 
                            AND table_type = 'BASE TABLE'
                        ) t
                    """)
                    
                    raw_result = conn.execute(raw_tables_query).fetchall()
                    overview['schemas']['raw_nflfastr'] = {
                        row[0]: row[1] for row in raw_result
                    }
                except Exception:
                    # Fallback to simple table list if count query fails
                    simple_query = text("""
                        SELECT table_name 
                        FROM information_schema.tables 
                        WHERE table_schema = 'raw_nflfastr' 
                        AND table_type = 'BASE TABLE'
                    """)
                    tables = conn.execute(simple_query).fetchall()
                    overview['schemas']['raw_nflfastr'] = {
                        row[0]: 'unknown' for row in tables
                    }
                
                # Check analytics schema
                analytics_query = text("""
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'analytics' 
                    AND table_type = 'BASE TABLE'
                """)
                analytics_tables = conn.execute(analytics_query).fetchall()
                overview['schemas']['analytics'] = [row[0] for row in analytics_tables]
                
                # Get date range from play_by_play if available
                try:
                    date_range_query = text("""
                        SELECT MIN(game_date) as min_date, MAX(game_date) as max_date, COUNT(*) as total_plays
                        FROM raw_nflfastr.play_by_play
                    """)
                    date_result = conn.execute(date_range_query).fetchone()
                    if date_result:
                        overview['date_range'] = {
                            'min_date': str(date_result[0]) if date_result[0] else None,
                            'max_date': str(date_result[1]) if date_result[1] else None,
                            'total_plays': date_result[2]
                        }
                except Exception:
                    overview['date_range'] = {'status': 'unavailable'}
            
            self.logger.info("Data overview generated successfully")
            
        except Exception as e:
            self.logger.warning(f"Could not generate complete data overview: {e}")
            overview['error'] = str(e)
        
        return overview
    
    def _analyze_team_performance(self) -> Dict[str, Any]:
        """
        Analyze basic team performance metrics.
        
        Direct database calls (Layer 3) - no complex patterns
        
        Returns:
            dict: Team performance analysis results
        """
        self.logger.info("Analyzing team performance")
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Basic team stats from play_by_play
                team_query = text("""
                    SELECT 
                        posteam as team,
                        COUNT(*) as total_plays,
                        AVG(yards_gained) as avg_yards_per_play,
                        SUM(CASE WHEN touchdown = 1 THEN 1 ELSE 0 END) as touchdowns,
                        SUM(CASE WHEN interception = 1 THEN 1 ELSE 0 END) as interceptions,
                        SUM(CASE WHEN fumble_lost = 1 THEN 1 ELSE 0 END) as fumbles_lost
                    FROM raw_nflfastr.play_by_play 
                    WHERE posteam IS NOT NULL 
                    AND season = (SELECT MAX(season) FROM raw_nflfastr.play_by_play)
                    GROUP BY posteam
                    ORDER BY avg_yards_per_play DESC
                    LIMIT 10
                """)
                
                result = conn.execute(team_query).fetchall()
                
                team_stats = []
                for row in result:
                    team_stats.append({
                        'team': row[0],
                        'total_plays': row[1],
                        'avg_yards_per_play': round(float(row[2]) if row[2] else 0, 2),
                        'touchdowns': row[3],
                        'interceptions': row[4],
                        'fumbles_lost': row[5]
                    })
                
                return {
                    'top_teams_by_efficiency': team_stats,
                    'analysis_note': 'Based on yards per play for most recent season'
                }
                
        except Exception as e:
            self.logger.warning(f"Could not analyze team performance: {e}")
            return {'error': str(e)}
    
    def _analyze_seasonal_trends(self) -> Dict[str, Any]:
        """
        Analyze trends across seasons.
        
        Direct database calls (Layer 3) - no complex patterns
        
        Returns:
            dict: Seasonal trends analysis results
        """
        self.logger.info("Analyzing seasonal trends")
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Scoring trends by season
                trends_query = text("""
                    SELECT 
                        season,
                        COUNT(DISTINCT game_id) as total_games,
                        AVG(CASE WHEN touchdown = 1 THEN 1 ELSE 0 END) * 100 as td_rate,
                        AVG(yards_gained) as avg_yards_per_play,
                        COUNT(*) as total_plays
                    FROM raw_nflfastr.play_by_play 
                    WHERE season IS NOT NULL 
                    GROUP BY season
                    ORDER BY season DESC
                    LIMIT 5
                """)
                
                result = conn.execute(trends_query).fetchall()
                
                trends = []
                for row in result:
                    trends.append({
                        'season': row[0],
                        'total_games': row[1],
                        'touchdown_rate_percent': round(float(row[2]) if row[2] else 0, 2),
                        'avg_yards_per_play': round(float(row[3]) if row[3] else 0, 2),
                        'total_plays': row[4]
                    })
                
                return {
                    'recent_seasons': trends,
                    'analysis_note': 'Trends for last 5 seasons'
                }
                
        except Exception as e:
            self.logger.warning(f"Could not analyze seasonal trends: {e}")
            return {'error': str(e)}
    
    def _analyze_game_factors(self) -> Dict[str, Any]:
        """
        Analyze factors that influence games.
        
        Direct database calls (Layer 3) - no complex patterns
        
        Returns:
            dict: Game factors analysis results
        """
        self.logger.info("Analyzing game factors")
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Home field advantage analysis
                home_advantage_query = text("""
                    SELECT 
                        'home_field_advantage' as factor,
                        COUNT(*) as total_plays,
                        AVG(CASE WHEN touchdown = 1 THEN 1 ELSE 0 END) * 100 as td_rate_home,
                        AVG(yards_gained) as avg_yards_home
                    FROM raw_nflfastr.play_by_play 
                    WHERE posteam = home_team
                    AND season = (SELECT MAX(season) FROM raw_nflfastr.play_by_play)
                    
                    UNION ALL
                    
                    SELECT 
                        'away_performance' as factor,
                        COUNT(*) as total_plays,
                        AVG(CASE WHEN touchdown = 1 THEN 1 ELSE 0 END) * 100 as td_rate_away,
                        AVG(yards_gained) as avg_yards_away
                    FROM raw_nflfastr.play_by_play 
                    WHERE posteam = away_team
                    AND season = (SELECT MAX(season) FROM raw_nflfastr.play_by_play)
                """)
                
                result = conn.execute(home_advantage_query).fetchall()
                
                factors = []
                for row in result:
                    factors.append({
                        'factor': row[0],
                        'total_plays': row[1],
                        'touchdown_rate': round(float(row[2]) if row[2] else 0, 2),
                        'avg_yards_per_play': round(float(row[3]) if row[3] else 0, 2)
                    })
                
                return {
                    'home_vs_away': factors,
                    'analysis_note': 'Home vs away performance for most recent season'
                }
                
        except Exception as e:
            self.logger.warning(f"Could not analyze game factors: {e}")
            return {'error': str(e)}
    
    def _generate_team_insights(self, team_stats: List[Dict[str, Any]]) -> List[str]:
        """
        Generate insights from team performance analysis.
        
        Args:
            team_stats: List of team performance statistics
            
        Returns:
            List of insight strings
        """
        if not team_stats:
            return ["No team data available for analysis"]
        
        insights = []
        
        # Top performer insight
        top_team = team_stats[0]
        insights.append(f"Most efficient team: {top_team['team']} ({top_team['avg_yards_per_play']} yards/play)")
        
        # Efficiency range insight
        if len(team_stats) > 1:
            bottom_team = team_stats[-1]
            efficiency_gap = top_team['avg_yards_per_play'] - bottom_team['avg_yards_per_play']
            insights.append(f"Efficiency gap between top and bottom teams: {efficiency_gap:.2f} yards/play")
        
        # Turnover analysis
        high_turnover_teams = [team for team in team_stats if (team['interceptions'] + team['fumbles_lost']) > 15]
        if high_turnover_teams:
            insights.append(f"{len(high_turnover_teams)} teams with high turnover rates (>15 per season)")
        
        # Touchdown production
        avg_touchdowns = sum(team['touchdowns'] for team in team_stats) / len(team_stats)
        insights.append(f"Average touchdowns per team: {avg_touchdowns:.1f}")
        
        return insights
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → run_exploratory_analysis() [Layer 1]
             → ExploratoryAnalysisImpl.run_exploratory_analysis() [Layer 2]
             → Database service calls [Layer 3]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 3,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → Exploratory Analysis → Database (3 layers)'
        }


# Convenience function for direct usage
def create_exploratory_analysis(db_service=None, logger=None):
    """
    Create exploratory analysis service with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        ExploratoryAnalysisImpl: Configured exploratory analysis service
    """
    from ...shared.database import NFLfastRDatabase
    from commonv2 import get_logger
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.analytics.exploratory')
    
    return ExploratoryAnalysisImpl(db_service, logger)


__all__ = [
    'ExploratoryAnalysisImpl',
    'create_exploratory_analysis'
]
