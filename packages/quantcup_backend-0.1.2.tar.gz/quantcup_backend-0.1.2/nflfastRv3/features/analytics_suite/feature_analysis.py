"""
Feature Analysis Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Follows clean architecture with maximum 3 layers:
Layer 1: Public API (nflfastRv3/__init__.py)
Layer 2: This implementation
Layer 3: Infrastructure (database, validation)

Migrated from nflfastRv2/features/analytics_suite/feature_analysis.py
with V3 clean architecture patterns applied.
"""

import pandas as pd
from typing import Dict, Any, List, Tuple, Optional
from sqlalchemy import text


class FeatureAnalysisImpl:
    """
    Core feature analysis business logic.
    
    Pattern: Minimum Viable Decoupling (⭐ RECOMMENDED START)
    Complexity: 2 points
    Depth: 1 layer (calls infrastructure directly)
    
    Responsibilities:
    - Run comprehensive feature analysis on NFL data
    - Analyze feature distributions and quality
    - Detect multicollinearity between features
    - Validate feature quality for ML models
    - No complex patterns or abstractions
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
    
    def run_feature_analysis(self, **kwargs) -> Dict[str, Any]:
        """
        Run comprehensive feature analysis on NFL data.
        
        Simple analysis flow:
        1. Load feature data (Layer 3 call)
        2. Analyze distributions (Layer 3 call)
        3. Validate quality (Layer 3 call)
        4. Check correlations (Layer 3 call)
        5. Return combined results
        
        Args:
            **kwargs: Additional analysis options
            
        Returns:
            Dictionary with feature analysis results
        """
        self.logger.info("Starting feature analysis")
        
        try:
            # Load feature data from analytics schema
            feature_data = self._load_feature_data()
            
            if feature_data.empty:
                return {
                    'status': 'error',
                    'message': 'No feature data available for analysis'
                }
            
            analysis_results = {
                'status': 'success',
                'dataset_info': self._get_dataset_info(feature_data),
                'distribution_analysis': self._analyze_feature_distributions(feature_data),
                'quality_assessment': self._validate_feature_quality(feature_data),
                'correlation_analysis': self._analyze_correlations(feature_data)
            }
            
            self.logger.info("Feature analysis completed successfully")
            return analysis_results
            
        except Exception as e:
            self.logger.error(f"Feature analysis failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def analyze_feature_distributions(self, df: pd.DataFrame, **kwargs) -> Dict[str, Any]:
        """
        Analyze the distribution of features in the dataset.
        
        Args:
            df: DataFrame with features to analyze
            **kwargs: Additional analysis options
            
        Returns:
            Dictionary with distribution analysis results
        """
        self.logger.info(f"Analyzing feature distributions for {df.shape[1]} features")
        return self._analyze_feature_distributions(df)
    
    def detect_multicollinearity(self, df: pd.DataFrame, threshold: float = 0.8, **kwargs) -> List[Tuple[str, str, float]]:
        """
        Detect multicollinearity between features.
        
        Args:
            df: DataFrame with numeric features
            threshold: Correlation threshold for flagging multicollinearity
            **kwargs: Additional analysis options
            
        Returns:
            List of tuples (feature1, feature2, correlation) for highly correlated pairs
        """
        self.logger.info(f"Detecting multicollinearity with threshold {threshold}")
        
        # Select only numeric columns
        numeric_df = df.select_dtypes(include=['int64', 'float64', 'Int64', 'Float64'])
        
        if numeric_df.empty:
            self.logger.warning("No numeric features found for multicollinearity analysis")
            return []
        
        # Calculate correlation matrix
        corr_matrix = numeric_df.corr()
        
        # Find highly correlated pairs
        high_corr_pairs = []
        
        for i in range(len(corr_matrix.columns)):
            for j in range(i + 1, len(corr_matrix.columns)):
                feature1 = corr_matrix.columns[i]
                feature2 = corr_matrix.columns[j]
                correlation_value = corr_matrix.iloc[i, j]
                
                if pd.isna(correlation_value):
                    continue
                
                try:
                    if (pd.notna(correlation_value) and 
                        not isinstance(correlation_value, (complex, str, bytes)) and
                        isinstance(correlation_value, (int, float))):
                        correlation = abs(float(correlation_value))
                        if correlation >= threshold:
                            high_corr_pairs.append((feature1, feature2, correlation))
                except (TypeError, ValueError, OverflowError):
                    continue
        
        # Sort by correlation strength
        high_corr_pairs.sort(key=lambda x: x[2], reverse=True)
        
        self.logger.info(f"Found {len(high_corr_pairs)} highly correlated feature pairs")
        return high_corr_pairs
    
    def validate_feature_quality(self, df: pd.DataFrame, **kwargs) -> Dict[str, Any]:
        """
        Validate overall feature quality and identify potential issues.
        
        Args:
            df: DataFrame with features to validate
            **kwargs: Additional analysis options
            
        Returns:
            Dictionary with quality assessment results
        """
        self.logger.info("Validating feature quality")
        return self._validate_feature_quality(df)
    
    def _load_feature_data(self) -> pd.DataFrame:
        """
        Load feature data from the analytics schema.
        
        Direct database calls (Layer 3) - no complex patterns
        
        Returns:
            pd.DataFrame: Loaded feature data
        """
        self.logger.info("Loading feature data from analytics schema")
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                # Try to load from fact_play table if available
                query = text("""
                    SELECT 
                        game_id,
                        season,
                        week,
                        yards_gained,
                        touchdown,
                        interception,
                        fumble_lost,
                        first_down,
                        penalty,
                        down,
                        ydstogo,
                        yardline_100,
                        score_differential,
                        ep,
                        epa,
                        wp,
                        wpa
                    FROM analytics.fact_play 
                    WHERE season IS NOT NULL 
                    LIMIT 10000
                """)
                
                df = pd.read_sql(query, conn)
                self.logger.info(f"Loaded {len(df)} records for feature analysis")
                return df
                
        except Exception as e:
            self.logger.warning(f"Could not load from analytics schema: {e}")
            
            # Fallback to raw data
            try:
                engine = self.db_service.get_engine()
                with engine.connect() as conn:
                    fallback_query = text("""
                        SELECT 
                            game_id,
                            season,
                            week,
                            yards_gained,
                            touchdown,
                            interception,
                            fumble_lost,
                            first_down,
                            penalty,
                            down,
                            ydstogo,
                            yardline_100
                        FROM raw_nflfastr.play_by_play 
                        WHERE season IS NOT NULL 
                        LIMIT 10000
                    """)
                    
                    df = pd.read_sql(fallback_query, conn)
                    self.logger.info(f"Loaded {len(df)} records from raw data as fallback")
                    return df
                    
            except Exception as e2:
                self.logger.error(f"Could not load feature data: {e2}")
                return pd.DataFrame()
    
    def _get_dataset_info(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Get basic information about the dataset.
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            dict: Dataset information
        """
        return {
            'shape': df.shape,
            'memory_usage_mb': round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
            'columns': list(df.columns),
            'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()}
        }
    
    def _analyze_feature_distributions(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze the distribution of features in the dataset.
        
        Direct statistical analysis (Layer 3) - no complex patterns
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            dict: Distribution analysis results
        """
        self.logger.info(f"Analyzing feature distributions for {df.shape[1]} features")
        
        analysis = {
            "total_features": df.shape[1],
            "total_records": len(df),
            "numeric_features": [],
            "categorical_features": [],
            "missing_data": {},
            "basic_stats": {}
        }
        
        for column in df.columns:
            missing_pct = df[column].isnull().sum() / len(df) * 100
            analysis["missing_data"][column] = round(missing_pct, 2)
            
            if df[column].dtype in ['int64', 'float64', 'Int64', 'Float64']:
                analysis["numeric_features"].append(column)
                
                # Basic statistics for numeric features
                try:
                    stats = df[column].describe()
                    analysis["basic_stats"][column] = {
                        'mean': round(float(stats['mean']), 3) if pd.notna(stats['mean']) else None,
                        'std': round(float(stats['std']), 3) if pd.notna(stats['std']) else None,
                        'min': float(stats['min']) if pd.notna(stats['min']) else None,
                        'max': float(stats['max']) if pd.notna(stats['max']) else None,
                        'unique_values': int(df[column].nunique())
                    }
                except Exception:
                    analysis["basic_stats"][column] = {'error': 'Could not calculate stats'}
            else:
                analysis["categorical_features"].append(column)
                analysis["basic_stats"][column] = {
                    'unique_values': int(df[column].nunique()),
                    'most_common': str(df[column].mode().iloc[0]) if not df[column].mode().empty else None
                }
        
        self.logger.info("Feature distribution analysis complete")
        return analysis
    
    def _validate_feature_quality(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Validate overall feature quality and identify potential issues.
        
        Direct quality checks (Layer 3) - no complex patterns
        
        Args:
            df: DataFrame to validate
            
        Returns:
            dict: Quality assessment results
        """
        self.logger.info("Validating feature quality")
        
        quality_report = {
            "total_features": df.shape[1],
            "total_records": len(df),
            "quality_issues": [],
            "recommendations": [],
            "overall_score": 0.0
        }
        
        # Check for common quality issues
        
        # 1. High missing data
        missing_data = df.isnull().sum() / len(df)
        high_missing = missing_data[missing_data > 0.5]
        if not high_missing.empty:
            quality_report["quality_issues"].append(
                f"High missing data: {list(high_missing.index)} (>50% missing)"
            )
            quality_report["recommendations"].append(
                "Consider removing features with >50% missing data or implement imputation"
            )
        
        # 2. Zero variance features
        numeric_df = df.select_dtypes(include=['int64', 'float64', 'Int64', 'Float64'])
        zero_var_features = []
        for col in numeric_df.columns:
            try:
                if numeric_df[col].var() == 0:
                    zero_var_features.append(col)
            except Exception:
                continue
        
        if zero_var_features:
            quality_report["quality_issues"].append(
                f"Zero variance features: {zero_var_features}"
            )
            quality_report["recommendations"].append(
                "Remove zero variance features as they provide no predictive value"
            )
        
        # 3. Features with single unique value
        single_value_features = []
        for col in df.columns:
            if df[col].nunique() <= 1:
                single_value_features.append(col)
        
        if single_value_features:
            quality_report["quality_issues"].append(
                f"Single value features: {single_value_features}"
            )
            quality_report["recommendations"].append(
                "Remove features with only one unique value"
            )
        
        # 4. Features with extreme outliers (IQR method)
        outlier_features = []
        for col in numeric_df.columns:
            try:
                Q1 = numeric_df[col].quantile(0.25)
                Q3 = numeric_df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = numeric_df[(numeric_df[col] < lower_bound) | (numeric_df[col] > upper_bound)]
                outlier_pct = len(outliers) / len(numeric_df) * 100
                
                if outlier_pct > 10:  # More than 10% outliers
                    outlier_features.append((col, round(outlier_pct, 2)))
            except Exception:
                continue
        
        if outlier_features:
            outlier_list = [f"{col} ({pct}%)" for col, pct in outlier_features]
            quality_report["quality_issues"].append(
                f"High outlier features: {outlier_list} (>10% outliers)"
            )
            quality_report["recommendations"].append(
                "Consider outlier treatment for features with high outlier rates"
            )
        
        # Calculate overall quality score
        issues_count = len(quality_report["quality_issues"])
        max_possible_issues = 10  # Adjust based on number of checks
        quality_report["overall_score"] = max(0, (max_possible_issues - issues_count) / max_possible_issues)
        
        self.logger.info(f"Feature quality validation complete. Score: {quality_report['overall_score']:.2f}")
        return quality_report
    
    def _analyze_correlations(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze correlations between features.
        
        Direct correlation analysis (Layer 3) - no complex patterns
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            dict: Correlation analysis results
        """
        self.logger.info("Analyzing feature correlations")
        
        try:
            # Select only numeric columns for correlation analysis
            numeric_df = df.select_dtypes(include=['int64', 'float64', 'Int64', 'Float64'])
            
            if numeric_df.empty:
                return {'error': 'No numeric features found for correlation analysis'}
            
            # Calculate correlation matrix
            corr_matrix = numeric_df.corr()
            
            # Find highly correlated pairs (threshold = 0.8)
            high_corr_pairs = []
            threshold = 0.8
            
            for i in range(len(corr_matrix.columns)):
                for j in range(i + 1, len(corr_matrix.columns)):
                    feature1 = corr_matrix.columns[i]
                    feature2 = corr_matrix.columns[j]
                    correlation_value = corr_matrix.iloc[i, j]
                    
                    if pd.isna(correlation_value):
                        continue
                    
                    try:
                        if (pd.notna(correlation_value) and 
                            not isinstance(correlation_value, (complex, str, bytes)) and
                            isinstance(correlation_value, (int, float))):
                            correlation = abs(float(correlation_value))
                            if correlation >= threshold:
                                high_corr_pairs.append({
                                    'feature1': feature1,
                                    'feature2': feature2,
                                    'correlation': round(correlation, 3)
                                })
                    except (TypeError, ValueError, OverflowError):
                        continue
            
            # Sort by correlation strength
            high_corr_pairs.sort(key=lambda x: x['correlation'], reverse=True)
            
            # Calculate feature importance based on average correlation
            feature_importance = {}
            for col in numeric_df.columns:
                try:
                    # Average absolute correlation with other features
                    col_corrs = corr_matrix[col].drop(col).abs()
                    avg_corr = col_corrs.mean()
                    if (pd.notna(avg_corr) and 
                        not isinstance(avg_corr, (complex, str, bytes)) and
                        isinstance(avg_corr, (int, float))):
                        feature_importance[col] = round(float(avg_corr), 3)
                    else:
                        feature_importance[col] = 0.0
                except (TypeError, ValueError, OverflowError):
                    feature_importance[col] = 0.0
            
            # Sort features by importance
            sorted_importance = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
            
            return {
                'numeric_features_analyzed': len(numeric_df.columns),
                'high_correlations': high_corr_pairs[:10],  # Top 10
                'multicollinearity_warning': len(high_corr_pairs) > 0,
                'threshold_used': threshold,
                'feature_importance_by_correlation': dict(sorted_importance[:10]),
                'correlation_summary': {
                    'total_pairs': len(corr_matrix.columns) * (len(corr_matrix.columns) - 1) // 2,
                    'high_correlation_pairs': len(high_corr_pairs),
                    'avg_correlation': round(float(corr_matrix.abs().mean().mean()), 3)
                }
            }
            
        except Exception as e:
            self.logger.warning(f"Could not complete correlation analysis: {e}")
            return {'error': str(e)}
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → run_feature_analysis() [Layer 1]
             → FeatureAnalysisImpl.run_feature_analysis() [Layer 2]
             → Database service calls [Layer 3]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 3,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → Feature Analysis → Database (3 layers)'
        }


# Convenience function for direct usage
def create_feature_analysis(db_service=None, logger=None):
    """
    Create feature analysis service with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        FeatureAnalysisImpl: Configured feature analysis service
    """
    from ...shared.database import NFLfastRDatabase
    from commonv2 import get_logger
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.analytics.feature_analysis')
    
    return FeatureAnalysisImpl(db_service, logger)


__all__ = [
    'FeatureAnalysisImpl',
    'create_feature_analysis'
]
