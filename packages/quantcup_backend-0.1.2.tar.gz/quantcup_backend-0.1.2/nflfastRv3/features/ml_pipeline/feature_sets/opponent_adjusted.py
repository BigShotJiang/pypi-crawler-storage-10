"""
Opponent Adjusted Features - V3 Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Migrated from nflfastRv2 with V3 clean architecture patterns:
- Strength-of-schedule adjustments preserved
- Opponent quality metrics preserved
- Context-aware performance analysis preserved
- Clean dependency injection
- REFACTORING_SPECS.md compliant

"Can I Trace This?" test:
User → OpponentAdjustedFeatures.build_features() → Database queries
✅ 3 layers maximum, easily traceable

V2 Business Logic Preserved:
- Strength-of-schedule calculations
- Opponent quality adjustments
- Context-weighted performance metrics
- Division/conference strength analysis
- Quality of wins/losses tracking
"""

import pandas as pd
from sqlalchemy import text
from typing import Dict, Any, List, Optional

from commonv2 import get_logger
from nflfastRv3.features.data_pipeline.schedule_integration import ScheduleDataProvider
from nflfastRv3.shared.models import ValidationResult


class OpponentAdjustedFeatures:
    """
    Opponent-adjusted feature engineering service.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + strength-of-schedule calculations)
    Depth: 1 layer (calls database directly)
    
    V2 Capabilities Preserved:
    - Strength of schedule metrics
    - Opponent quality adjustments
    - Context-weighted team performance
    - Division and conference strength
    - Quality of wins and losses
    """
    
    def __init__(self, db_service, logger, schedule_provider=None):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
            schedule_provider: Optional CommonV2 schedule provider
        """
        self.db_service = db_service
        self.logger = logger
        self.schedule_provider = schedule_provider or ScheduleDataProvider()
    
    def build_features(self, seasons=None, save_to_db=True) -> Dict[str, Any]:
        """
        Build comprehensive opponent-adjusted features with CommonV2 integration.
        
        Enhanced feature engineering flow:
        1. Validate seasons using CommonV2 schedule data
        2. Calculate base team strength metrics (Layer 3 call)
        3. Calculate opponent quality for each game (Layer 3 call)
        4. Adjust team performance by opponent strength (Layer 3 call)
        5. Calculate strength-of-schedule metrics (Layer 3 call)
        6. Integrate with CommonV2 schedule context
        7. Save to features schema (Layer 3 call)
        
        Args:
            seasons: List of seasons to process (default: all available)
            save_to_db: Whether to save results to features schema
            
        Returns:
            Dictionary with feature build results
        """
        self.logger.info(f"Building opponent-adjusted features for seasons: {seasons or 'all'}")
        
        try:
            # Step 0: Validate seasons with CommonV2 schedule data
            validated_seasons = self._validate_seasons_with_schedule_data(seasons)
            if not validated_seasons:
                self.logger.warning("No valid seasons found in schedule data")
                return {
                    'status': 'warning',
                    'message': 'No valid seasons with schedule data',
                    'features_built': 0,
                    'seasons_processed': 0
                }
            
            # Step 1: Calculate base team strength metrics
            team_strength_df = self._calculate_team_strength(validated_seasons)
            
            if team_strength_df.empty:
                self.logger.warning("No team strength data found")
                return {
                    'status': 'warning',
                    'message': 'No data available',
                    'features_built': 0,
                    'seasons_processed': 0
                }
            
            # Step 2: Calculate game-level opponent adjustments
            game_adjustments_df = self._calculate_game_adjustments(validated_seasons, team_strength_df)
            
            # Step 3: Aggregate to team-season level with opponent adjustments
            df = self._aggregate_opponent_adjusted_metrics(game_adjustments_df)
            
            # Step 4: Add strength-of-schedule calculations
            df = self._add_strength_of_schedule_metrics(df, team_strength_df)
            
            # Step 5: Enhance with CommonV2 schedule context
            df = self._add_schedule_context_features(df, validated_seasons)
            
            # Step 6: Validate feature quality
            validation = self._validate_opponent_features(df)
            if not validation.is_valid:
                self.logger.warning(f"Feature validation issues: {validation.errors}")
            
            # Step 7: Save to database if requested
            if save_to_db:
                save_result = self._save_features_to_db(df)
                if not save_result['success']:
                    return {
                        'status': 'error',
                        'message': f"Failed to save features: {save_result['error']}",
                        'features_built': len(df),
                        'data': df
                    }
            
            # Step 8: Return comprehensive results
            seasons_processed = df['season'].nunique() if 'season' in df.columns else 0
            teams_processed = df['team'].nunique() if 'team' in df.columns else 0
            
            self.logger.info(f"✓ Built opponent-adjusted features: {len(df)} team-seasons")
            
            return {
                'status': 'success',
                'features_built': len(df),
                'seasons_processed': seasons_processed,
                'teams_processed': teams_processed,
                'feature_columns': len(df.columns),
                'data': df,
                'saved_to_db': save_to_db,
                'validation': validation,
                'seasons_validated': validated_seasons
            }
            
        except Exception as e:
            self.logger.error(f"Failed to build opponent-adjusted features: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'features_built': 0
            }
    
    def _calculate_team_strength(self, seasons=None) -> pd.DataFrame:
        """
        Calculate base team strength metrics using V2's logic.
        
        Direct database calls (Layer 3) - preserves V2 business logic
        
        Args:
            seasons: List of seasons to process
            
        Returns:
            DataFrame with team strength metrics by season
        """
        # Build season filter
        season_filter = ""
        if seasons:
            if isinstance(seasons, (list, tuple)):
                season_list = ','.join(str(s) for s in seasons)
                season_filter = f"AND g.season IN ({season_list})"
            else:
                season_filter = f"AND g.season = {seasons}"
        
        # V2's team strength calculation query (preserved exactly)
        query = text(f"""
        WITH team_season_stats AS (
            SELECT 
                p.posteam as team,
                g.season,
                
                -- Basic performance metrics
                COUNT(*) as total_plays,
                AVG(p.epa) as avg_epa_offense,
                AVG(CASE WHEN p.defteam = p.posteam THEN NULL ELSE p.epa END) as avg_epa_defense_allowed,
                
                -- Game-level aggregation
                COUNT(DISTINCT p.game_id) as games_played,
                AVG(g.home_score + g.away_score) as avg_total_points_in_games,
                
                -- Situational performance
                AVG(CASE WHEN p.down <= 2 THEN p.epa END) as early_down_epa,
                AVG(CASE WHEN p.down >= 3 THEN p.epa END) as late_down_epa,
                AVG(CASE WHEN p.yardline_100 <= 20 THEN p.epa END) as red_zone_epa,
                AVG(CASE WHEN p.score_differential BETWEEN -7 AND 7 THEN p.epa END) as close_game_epa,
                
                -- Advanced metrics
                SUM(CASE WHEN p.touchdown = true THEN 1 ELSE 0 END) as touchdowns,
                SUM(CASE WHEN p.interception = true OR p.fumble_lost = true THEN 1 ELSE 0 END) as turnovers,
                AVG(CASE WHEN p.pass_attempt = true THEN p.epa END) as pass_epa,
                AVG(CASE WHEN p.rush_attempt = true THEN p.epa END) as rush_epa
                
            FROM analytics.fact_play p
            JOIN analytics.dim_game g ON p.game_id = g.game_id
            WHERE p.posteam IS NOT NULL 
                AND p.play_type IN ('pass', 'run')
                AND p.epa IS NOT NULL
                {season_filter}
            GROUP BY p.posteam, g.season
        ),
        team_records AS (
            SELECT 
                team,
                season,
                SUM(wins) as wins,
                SUM(losses) as losses,
                SUM(wins) / NULLIF(SUM(wins) + SUM(losses), 0) as win_percentage
            FROM (
                -- Home games
                SELECT 
                    home_team as team,
                    season,
                    SUM(CASE WHEN home_score > away_score THEN 1 ELSE 0 END) as wins,
                    SUM(CASE WHEN home_score < away_score THEN 1 ELSE 0 END) as losses
                FROM analytics.dim_game
                WHERE season IS NOT NULL {season_filter}
                GROUP BY home_team, season
                
                UNION ALL
                
                -- Away games
                SELECT 
                    away_team as team,
                    season,
                    SUM(CASE WHEN away_score > home_score THEN 1 ELSE 0 END) as wins,
                    SUM(CASE WHEN away_score < home_score THEN 1 ELSE 0 END) as losses
                FROM analytics.dim_game
                WHERE season IS NOT NULL {season_filter}
                GROUP BY away_team, season
            ) team_games
            GROUP BY team, season
        )
        SELECT 
            COALESCE(s.team, r.team) as team,
            COALESCE(s.season, r.season) as season,
            
            -- Strength metrics (V2 sophistication preserved)
            ROUND(s.avg_epa_offense::numeric, 4) as team_strength_offense,
            ROUND(s.avg_epa_defense_allowed::numeric, 4) as team_strength_defense,
            ROUND((s.avg_epa_offense - s.avg_epa_defense_allowed)::numeric, 4) as team_strength_overall,
            
            -- Record-based strength
            ROUND(r.win_percentage::numeric, 4) as win_percentage,
            r.wins,
            r.losses,
            s.games_played,
            
            -- Situational strength (V2 sophistication preserved)
            ROUND(s.early_down_epa::numeric, 4) as early_down_strength,
            ROUND(s.late_down_epa::numeric, 4) as late_down_strength,
            ROUND(s.red_zone_epa::numeric, 4) as red_zone_strength,
            ROUND(s.close_game_epa::numeric, 4) as close_game_strength,
            
            -- Component strengths
            ROUND(s.pass_epa::numeric, 4) as pass_strength,
            ROUND(s.rush_epa::numeric, 4) as rush_strength,
            
            -- Efficiency metrics
            ROUND((s.touchdowns::float / NULLIF(s.games_played, 0))::numeric, 2) as touchdowns_per_game,
            ROUND((s.turnovers::float / NULLIF(s.games_played, 0))::numeric, 2) as turnovers_per_game
            
        FROM team_season_stats s
        FULL OUTER JOIN team_records r ON s.team = r.team AND s.season = r.season
        WHERE COALESCE(s.team, r.team) IS NOT NULL
        ORDER BY season DESC, team_strength_overall DESC
        """)
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                df = pd.read_sql(query, conn)
            
            # Validate the team strength data
            required_columns = ['team', 'season', 'team_strength_offense', 'team_strength_defense']
            missing_cols = [col for col in required_columns if col not in df.columns]
            if missing_cols:
                self.logger.error(f"Missing required columns in team strength data: {missing_cols}")
                return pd.DataFrame()
            
            self.logger.debug(f"Calculated team strength: {len(df)} team-seasons")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to calculate team strength: {e}")
            return pd.DataFrame()
    
    def _calculate_game_adjustments(self, seasons, team_strength_df) -> pd.DataFrame:
        """
        Calculate game-level opponent adjustments using V2's logic.
        
        Args:
            seasons: List of seasons to process
            team_strength_df: DataFrame with team strength metrics
            
        Returns:
            DataFrame with game-level opponent adjustments
        """
        # Build season filter
        season_filter = ""
        if seasons:
            if isinstance(seasons, (list, tuple)):
                season_list = ','.join(str(s) for s in seasons)
                season_filter = f"AND g.season IN ({season_list})"
            else:
                season_filter = f"AND g.season = {seasons}"
        
        # V2's game-level performance with opponent context (preserved exactly)
        query = text(f"""
        WITH game_performance AS (
            SELECT 
                g.game_id,
                g.season,
                g.week,
                
                -- Team performance
                team_stats.team,
                team_stats.opponent,
                team_stats.venue,
                team_stats.win,
                team_stats.points_for,
                team_stats.points_against,
                team_stats.point_differential,
                
                -- Team EPA performance
                team_stats.offensive_epa,
                team_stats.defensive_epa,
                team_stats.total_plays,
                team_stats.epa_per_play,
                
                -- Opponent identification for strength lookup
                team_stats.opponent as opponent_team
                
            FROM analytics.dim_game g
            
            -- Get team performance in each game
            CROSS JOIN (
                -- Home team perspective
                SELECT 
                    g.game_id,
                    g.home_team as team,
                    g.away_team as opponent,
                    'home' as venue,
                    CASE WHEN g.home_score > g.away_score THEN 1 ELSE 0 END as win,
                    g.home_score as points_for,
                    g.away_score as points_against,
                    g.home_score - g.away_score as point_differential,
                    
                    -- Aggregate team performance from plays
                    SUM(CASE WHEN p.posteam = g.home_team THEN p.epa ELSE 0 END) as offensive_epa,
                    SUM(CASE WHEN p.defteam = g.home_team THEN p.epa ELSE 0 END) as defensive_epa,
                    COUNT(CASE WHEN p.posteam = g.home_team THEN 1 END) as total_plays,
                    AVG(CASE WHEN p.posteam = g.home_team THEN p.epa END) as epa_per_play
                    
                FROM analytics.dim_game g
                LEFT JOIN analytics.fact_play p ON g.game_id = p.game_id
                WHERE p.play_type IN ('pass', 'run') AND p.epa IS NOT NULL
                    {season_filter}
                GROUP BY g.game_id, g.home_team, g.away_team, g.home_score, g.away_score
                
                UNION ALL
                
                -- Away team perspective
                SELECT 
                    g.game_id,
                    g.away_team as team,
                    g.home_team as opponent,
                    'away' as venue,
                    CASE WHEN g.away_score > g.home_score THEN 1 ELSE 0 END as win,
                    g.away_score as points_for,
                    g.home_score as points_against,
                    g.away_score - g.home_score as point_differential,
                    
                    -- Aggregate team performance from plays
                    SUM(CASE WHEN p.posteam = g.away_team THEN p.epa ELSE 0 END) as offensive_epa,
                    SUM(CASE WHEN p.defteam = g.away_team THEN p.epa ELSE 0 END) as defensive_epa,
                    COUNT(CASE WHEN p.posteam = g.away_team THEN 1 END) as total_plays,
                    AVG(CASE WHEN p.posteam = g.away_team THEN p.epa END) as epa_per_play
                    
                FROM analytics.dim_game g
                LEFT JOIN analytics.fact_play p ON g.game_id = p.game_id
                WHERE p.play_type IN ('pass', 'run') AND p.epa IS NOT NULL
                    {season_filter}
                GROUP BY g.game_id, g.away_team, g.home_team, g.away_score, g.home_score
            ) team_stats ON g.game_id = team_stats.game_id
            
            WHERE g.season IS NOT NULL {season_filter}
        )
        SELECT 
            game_id,
            season,
            week,
            team,
            opponent as opponent_team,
            venue,
            win,
            points_for,
            points_against,
            point_differential,
            
            -- Performance metrics
            ROUND(offensive_epa::numeric, 4) as offensive_epa,
            ROUND(defensive_epa::numeric, 4) as defensive_epa,
            total_plays,
            ROUND(epa_per_play::numeric, 4) as epa_per_play
            
        FROM game_performance
        WHERE team IS NOT NULL
        ORDER BY team, season, week
        """)
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                game_df = pd.read_sql(query, conn)
            
            # Merge with opponent strength data (V2 logic preserved)
            opponent_strength = team_strength_df[['team', 'season', 'team_strength_overall', 'team_strength_defense']].copy()
            opponent_strength.columns = ['opponent_team', 'season', 'opponent_strength', 'opponent_defense_strength']
            
            # Join game performance with opponent strength
            df = game_df.merge(
                opponent_strength,
                on=['opponent_team', 'season'],
                how='left'
            )
            
            # Calculate opponent adjustments (V2 sophistication preserved)
            df['strength_adjusted_epa'] = df['epa_per_play'] - df['opponent_defense_strength']
            df['strength_adjusted_points'] = df['point_differential'] / (1 + abs(df['opponent_strength']))
            
            # Quality of opponent indicators
            df['opponent_quality_tier'] = pd.cut(
                df['opponent_strength'], 
                bins=[-float('inf'), -0.1, 0.1, float('inf')], 
                labels=['weak', 'average', 'strong']
            )
            
            self.logger.debug(f"Calculated game adjustments: {len(df)} games")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to calculate game adjustments: {e}")
            return pd.DataFrame()
    
    def _aggregate_opponent_adjusted_metrics(self, game_adjustments_df) -> pd.DataFrame:
        """
        Aggregate game-level adjustments to team-season metrics.
        
        Args:
            game_adjustments_df: DataFrame with game-level adjustments
            
        Returns:
            DataFrame with team-season opponent-adjusted metrics
        """
        if game_adjustments_df.empty:
            return pd.DataFrame()
        
        self.logger.debug("Aggregating opponent-adjusted metrics")
        
        # Aggregate by team and season (V2 logic preserved)
        agg_functions = {
            'win': ['sum', 'count', 'mean'],
            'points_for': 'mean',
            'points_against': 'mean',
            'point_differential': 'mean',
            'epa_per_play': 'mean',
            'strength_adjusted_epa': 'mean',
            'strength_adjusted_points': 'mean',
            'opponent_strength': 'mean',
            'opponent_defense_strength': 'mean'
        }
        
        df = game_adjustments_df.groupby(['team', 'season']).agg(agg_functions).reset_index()
        
        # Flatten column names
        df.columns = [f"{col[0]}_{col[1]}" if col[1] else col[0] for col in df.columns]
        df.columns = ['team', 'season'] + [col for col in df.columns if col not in ['team', 'season']]
        
        # Rename and clean columns
        df = df.rename(columns={
            'win_sum': 'wins',
            'win_count': 'games_played', 
            'win_mean': 'win_percentage',
            'points_for_mean': 'avg_points_for',
            'points_against_mean': 'avg_points_against',
            'point_differential_mean': 'avg_point_differential',
            'epa_per_play_mean': 'avg_epa_per_play',
            'strength_adjusted_epa_mean': 'strength_adjusted_epa_avg',
            'strength_adjusted_points_mean': 'strength_adjusted_points_avg',
            'opponent_strength_mean': 'avg_opponent_strength',
            'opponent_defense_strength_mean': 'avg_opponent_defense_strength'
        })
        
        # Calculate quality of wins/losses (V2 sophistication preserved)
        quality_wins = game_adjustments_df[game_adjustments_df['win'] == 1].groupby(['team', 'season']).agg({
            'opponent_strength': ['mean', 'count']
        }).reset_index()
        quality_wins.columns = ['team', 'season', 'quality_wins_avg_opponent', 'total_wins']
        
        quality_losses = game_adjustments_df[game_adjustments_df['win'] == 0].groupby(['team', 'season']).agg({
            'opponent_strength': ['mean', 'count']
        }).reset_index()
        quality_losses.columns = ['team', 'season', 'quality_losses_avg_opponent', 'total_losses']
        
        # Merge quality metrics
        df = df.merge(quality_wins, on=['team', 'season'], how='left')
        df = df.merge(quality_losses, on=['team', 'season'], how='left')
        
        # Performance vs opponent quality tiers
        tier_performance = game_adjustments_df.groupby(['team', 'season', 'opponent_quality_tier']).agg({
            'win': 'mean',
            'epa_per_play': 'mean',
            'point_differential': 'mean'
        }).reset_index()
        
        # Pivot to get performance vs each tier
        for tier in ['weak', 'average', 'strong']:
            tier_data = tier_performance[tier_performance['opponent_quality_tier'] == tier]
            tier_data = tier_data.drop('opponent_quality_tier', axis=1)
            tier_data.columns = ['team', 'season'] + [f'{col}_vs_{tier}' for col in tier_data.columns if col not in ['team', 'season']]
            df = df.merge(tier_data, on=['team', 'season'], how='left')
        
        self.logger.debug(f"Aggregated opponent-adjusted metrics: {len(df)} team-seasons")
        return df
    
    def _add_strength_of_schedule_metrics(self, df, team_strength_df) -> pd.DataFrame:
        """
        Add comprehensive strength-of-schedule metrics (V2 logic preserved).
        
        Args:
            df: DataFrame with opponent-adjusted metrics
            team_strength_df: DataFrame with team strength data
            
        Returns:
            DataFrame with strength-of-schedule metrics added
        """
        if df.empty:
            return df
        
        self.logger.debug("Adding strength-of-schedule metrics")
        
        # Calculate league averages by season for normalization
        league_averages = team_strength_df.groupby('season').agg({
            'team_strength_overall': 'mean',
            'team_strength_offense': 'mean', 
            'team_strength_defense': 'mean'
        }).reset_index()
        
        league_averages.columns = ['season', 'league_avg_strength', 'league_avg_offense', 'league_avg_defense']
        
        # Merge league averages
        df = df.merge(league_averages, on='season', how='left')
        
        # Strength of schedule calculations (V2 sophistication preserved)
        df['strength_of_schedule'] = df['avg_opponent_strength'] - df['league_avg_strength']
        df['strength_of_schedule_defense'] = df['avg_opponent_defense_strength'] - df['league_avg_defense']
        
        # Performance relative to schedule difficulty
        df['performance_vs_schedule'] = df['strength_adjusted_epa_avg'] / (1 + abs(df['strength_of_schedule']))
        df['wins_vs_schedule_difficulty'] = df['win_percentage'] - (0.5 + df['strength_of_schedule'])
        
        # Schedule-adjusted efficiency rankings would require comparing across all teams
        # For now, add relative schedule strength metrics
        df['schedule_difficulty_percentile'] = df.groupby('season')['strength_of_schedule'].rank(pct=True)
        df['opponent_defense_difficulty_percentile'] = df.groupby('season')['strength_of_schedule_defense'].rank(pct=True)
        
        # Clean up temporary columns
        df = df.drop(['league_avg_strength', 'league_avg_offense', 'league_avg_defense'], axis=1)
        
        self.logger.debug(f"Added strength-of-schedule metrics: {len(df.columns)} total columns")
        return df
    
    def _save_features_to_db(self, df: pd.DataFrame, table_name='opponent_adjusted_features') -> Dict[str, Any]:
        """
        Save opponent-adjusted features to features schema.
        
        Args:
            df: DataFrame to save
            table_name: Target table name
            
        Returns:
            Dictionary with save results
        """
        try:
            self.logger.info(f"Saving {len(df)} rows to features.{table_name}")
            
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.begin() as conn:
                df.to_sql(
                    name=table_name,
                    con=conn,
                    schema='features',
                    if_exists='replace',
                    index=False,
                    method='multi'
                )
            
            self.logger.info(f"✓ Opponent-adjusted features saved to features.{table_name}")
            return {'success': True, 'table_name': table_name, 'rows_saved': len(df)}
            
        except Exception as e:
            self.logger.error(f"Failed to save opponent-adjusted features: {e}")
            return {'success': False, 'error': str(e)}
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → OpponentAdjustedFeatures.build_features() [Layer 1]
             → Database queries [Layer 2]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 2,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → OpponentAdjustedFeatures → Database (2 layers)'
        }


    def _validate_seasons_with_schedule_data(self, seasons=None) -> List[int]:
        """
        Validate seasons against available CommonV2 schedule data.
        
        Args:
            seasons: List of seasons to validate
            
        Returns:
            List of validated seasons with available schedule data
        """
        try:
            if not seasons:
                # If no seasons specified, get available seasons from schedule provider
                # For now, default to current season
                from datetime import datetime
                current_year = datetime.now().year
                seasons = [current_year if datetime.now().month >= 9 else current_year - 1]
            
            if not isinstance(seasons, (list, tuple)):
                seasons = [seasons]
            
            validated_seasons = []
            for season in seasons:
                try:
                    # Test if schedule data is available for this season
                    games = self.schedule_provider.get_games_for_week(season, 1)
                    if games:  # If we get games for week 1, season has data
                        validated_seasons.append(season)
                        self.logger.debug(f"Season {season} validated with schedule data")
                    else:
                        self.logger.warning(f"No schedule data available for season {season}")
                except Exception as e:
                    self.logger.warning(f"Failed to validate season {season}: {e}")
            
            self.logger.info(f"Validated {len(validated_seasons)} seasons: {validated_seasons}")
            return validated_seasons
            
        except Exception as e:
            self.logger.error(f"Failed to validate seasons: {e}")
            return []
    
    def _add_schedule_context_features(self, df: pd.DataFrame, seasons: List[int]) -> pd.DataFrame:
        """
        Add schedule context features using CommonV2 integration.
        
        Args:
            df: DataFrame with opponent-adjusted features
            seasons: List of validated seasons
            
        Returns:
            DataFrame with enhanced schedule context features
        """
        if df.empty:
            return df
        
        try:
            self.logger.debug("Adding schedule context features")
            
            # Get schedule data for all validated seasons
            all_games = []
            for season in seasons:
                try:
                    season_games = self.schedule_provider.load_schedule([season])
                    all_games.extend(season_games)
                except Exception as e:
                    self.logger.warning(f"Failed to load schedule for season {season}: {e}")
            
            if not all_games:
                self.logger.warning("No schedule data available for context features")
                return df
            
            # Convert schedule games to DataFrame for analysis
            schedule_data = []
            for game in all_games:
                schedule_data.append({
                    'game_id': game.game_id,
                    'season': game.season,
                    'week': game.week,
                    'home_team': game.home_team,
                    'away_team': game.away_team,
                    'stadium': game.stadium
                })
            
            schedule_df = pd.DataFrame(schedule_data)
            
            if schedule_df.empty:
                return df
            
            # Calculate schedule context metrics
            for season in seasons:
                season_schedule = schedule_df[schedule_df['season'] == season]
                
                if season_schedule.empty:
                    continue
                
                # Calculate division game frequency
                division_game_counts = self._calculate_division_game_frequency(season_schedule)
                
                # Calculate venue diversity
                venue_diversity = self._calculate_venue_diversity(season_schedule)
                
                # Merge schedule context back to main DataFrame
                season_mask = df['season'] == season
                
                for team in df[season_mask]['team'].unique():
                    team_mask = season_mask & (df['team'] == team)
                    
                    # Add division game frequency
                    if team in division_game_counts:
                        df.loc[team_mask, 'division_game_frequency'] = division_game_counts[team]
                    
                    # Add venue diversity
                    if team in venue_diversity:
                        df.loc[team_mask, 'venue_diversity'] = venue_diversity[team]
            
            # Fill missing values with defaults
            df['division_game_frequency'] = df['division_game_frequency'].fillna(0.0)
            df['venue_diversity'] = df['venue_diversity'].fillna(0.5)
            
            self.logger.debug(f"Added schedule context features: {len(df.columns)} total columns")
            return df
            
        except Exception as e:
            self.logger.warning(f"Failed to add schedule context features: {e}")
            return df
    
    def _calculate_division_game_frequency(self, schedule_df: pd.DataFrame) -> Dict[str, float]:
        """Calculate division game frequency for each team."""
        # This is a simplified calculation - would need actual division data
        return {}
    
    def _calculate_venue_diversity(self, schedule_df: pd.DataFrame) -> Dict[str, float]:
        """Calculate venue diversity for each team."""
        venue_counts = {}
        
        for team in pd.concat([schedule_df['home_team'], schedule_df['away_team']]).unique():
            team_games = schedule_df[
                (schedule_df['home_team'] == team) | (schedule_df['away_team'] == team)
            ]
            
            unique_venues = team_games['stadium'].nunique()
            total_games = len(team_games)
            
            venue_counts[team] = unique_venues / max(total_games, 1)
        
        return venue_counts
    
    def _validate_opponent_features(self, df: pd.DataFrame) -> ValidationResult:
        """
        Validate the quality of opponent-adjusted features.
        
        Args:
            df: DataFrame with opponent-adjusted features
            
        Returns:
            ValidationResult with validation status
        """
        validation = ValidationResult(is_valid=True, record_count=len(df))
        
        if df.empty:
            validation.add_error("No opponent-adjusted features generated")
            return validation
        
        # Check required columns
        required_columns = ['team', 'season', 'strength_adjusted_epa_avg', 'avg_opponent_strength']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            validation.add_error(f"Missing required columns: {missing_columns}")
        
        # Check for reasonable value ranges
        if 'win_percentage' in df.columns:
            invalid_win_pct = df[(df['win_percentage'] < 0) | (df['win_percentage'] > 1)]
            if not invalid_win_pct.empty:
                validation.add_error(f"Invalid win percentage values: {len(invalid_win_pct)} rows")
        
        # Check for null values in key metrics
        key_metrics = ['strength_adjusted_epa_avg', 'avg_opponent_strength', 'strength_of_schedule']
        for metric in key_metrics:
            if metric in df.columns:
                null_count = df[metric].isnull().sum()
                if null_count > 0:
                    validation.add_warning(f"Null values in {metric}: {null_count} rows")
        
        # Check team count per season
        teams_per_season = df.groupby('season')['team'].nunique()
        for season, team_count in teams_per_season.items():
            if team_count < 30:  # NFL should have 32 teams
                validation.add_warning(f"Season {season} has only {team_count} teams")
        
        return validation

    def build_opponent_adjusted_features(self, game_id: str, historical_data: Dict[str, pd.DataFrame]) -> Dict[str, float]:
        """
        Build opponent-adjusted features for a specific game.
        
        This method integrates with the real feature builder to provide
        opponent-adjusted metrics for individual game prediction.
        
        Args:
            game_id: Specific game identifier
            historical_data: Historical data context
            
        Returns:
            Dictionary of opponent-adjusted features for the game
        """
        try:
            # Extract game information
            if 'schedules' not in historical_data:
                self.logger.warning("No schedule data available for opponent adjustment")
                return self._get_default_opponent_features()
            
            schedules = historical_data['schedules']
            game_row = schedules[schedules['game_id'] == game_id]
            
            if game_row.empty:
                self.logger.warning(f"Game {game_id} not found in schedule data")
                return self._get_default_opponent_features()
            
            game = game_row.iloc[0]
            home_team = game.get('home_team')
            away_team = game.get('away_team')
            season = game.get('season')
            
            # Get team strength data for the season
            team_strength_df = self._calculate_team_strength([season])
            
            # Calculate opponent-adjusted features for both teams
            features = {}
            
            # Home team opponent adjustments
            home_strength = team_strength_df[team_strength_df['team'] == home_team]
            away_strength = team_strength_df[team_strength_df['team'] == away_team]
            
            if not home_strength.empty and not away_strength.empty:
                home_stats = home_strength.iloc[0]
                away_stats = away_strength.iloc[0]
                
                # Opponent-adjusted metrics
                features['home_strength_vs_away_defense'] = home_stats.get('team_strength_offense', 0.0) - away_stats.get('team_strength_defense', 0.0)
                features['away_strength_vs_home_defense'] = away_stats.get('team_strength_offense', 0.0) - home_stats.get('team_strength_defense', 0.0)
                features['overall_strength_differential'] = home_stats.get('team_strength_overall', 0.0) - away_stats.get('team_strength_overall', 0.0)
                
                # Strength-of-schedule adjustments
                features['home_sos_adjusted_strength'] = home_stats.get('team_strength_overall', 0.0)
                features['away_sos_adjusted_strength'] = away_stats.get('team_strength_overall', 0.0)
            else:
                # Default values if team strength data not available
                features.update(self._get_default_opponent_features())
            
            return features
            
        except Exception as e:
            self.logger.error(f"Failed to build opponent-adjusted features for game {game_id}: {e}")
            return self._get_default_opponent_features()
    
    def _get_default_opponent_features(self) -> Dict[str, float]:
        """Get default opponent-adjusted feature values."""
        return {
            'home_strength_vs_away_defense': 0.0,
            'away_strength_vs_home_defense': 0.0,
            'overall_strength_differential': 0.0,
            'home_sos_adjusted_strength': 0.0,
            'away_sos_adjusted_strength': 0.0
        }


# Convenience function for direct usage
def create_opponent_adjusted_features(db_service=None, logger=None, schedule_provider=None):
    """
    Create opponent-adjusted features service with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        schedule_provider: Optional CommonV2 schedule provider override
        
    Returns:
        OpponentAdjustedFeatures: Configured opponent-adjusted features service
    """
    from nflfastRv3.shared.database import NFLfastRDatabase
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.ml_pipeline.opponent_adjusted')
    
    return OpponentAdjustedFeatures(db_service, logger, schedule_provider)


__all__ = ['OpponentAdjustedFeatures', 'create_opponent_adjusted_features']
