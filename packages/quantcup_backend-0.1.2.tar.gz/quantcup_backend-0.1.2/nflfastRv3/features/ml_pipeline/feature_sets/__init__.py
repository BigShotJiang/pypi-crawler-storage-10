"""
Feature Sets Module - V3 Implementation

Pattern: Minimum Viable Decoupling
Complexity: 1 point (module organization)
Layer: 2 (Implementation)

Feature engineering modules for ML pipeline:
- team_efficiency: EPA calculations, red zone metrics, turnover rates
- rolling_metrics: Time-series features, moving averages
- opponent_adjusted: Strength-of-schedule adjustments

Migrated from nflfastRv2 with V3 clean architecture patterns.
All modules follow REFACTORING_SPECS.md compliance.
"""

from .team_efficiency import TeamEfficiencyFeatures, create_team_efficiency_features
from .rolling_metrics import RollingMetricsFeatures, create_rolling_metrics_features
from .opponent_adjusted import OpponentAdjustedFeatures, create_opponent_adjusted_features


__all__ = [
    # Team efficiency features
    'TeamEfficiencyFeatures',
    'create_team_efficiency_features',
    
    # Rolling metrics features  
    'RollingMetricsFeatures',
    'create_rolling_metrics_features',
    
    # Opponent adjusted features
    'OpponentAdjustedFeatures', 
    'create_opponent_adjusted_features'
]
