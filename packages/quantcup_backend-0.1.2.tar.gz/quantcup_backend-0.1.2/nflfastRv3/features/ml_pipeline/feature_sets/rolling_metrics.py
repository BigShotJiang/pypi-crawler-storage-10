"""
Rolling Metrics Features - V3 Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Migrated from nflfastRv2 with V3 clean architecture patterns:
- Time-series feature engineering preserved
- Rolling averages and windows preserved
- Game-by-game momentum analysis preserved
- Clean dependency injection
- REFACTORING_SPECS.md compliant

"Can I Trace This?" test:
User → RollingMetricsFeatures.build_features() → Database queries
✅ 3 layers maximum, easily traceable

V2 Business Logic Preserved:
- Rolling EPA averages (4, 8, 16 game windows)
- Recent form analysis (last 4 games)
- Momentum indicators (win/loss streaks)
- Performance trending (improving/declining)
- Game-by-game variance metrics
"""

import pandas as pd
from sqlalchemy import text
from typing import Dict, Any, List, Optional


class RollingMetricsFeatures:
    """
    Rolling metrics feature engineering service.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + time-series calculations)
    Depth: 1 layer (calls database directly)
    
    V2 Capabilities Preserved:
    - Rolling EPA metrics (multiple windows)
    - Recent performance indicators
    - Win/loss streak tracking
    - Variance and consistency metrics
    - Game-by-game momentum analysis
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
        
        # Rolling window configurations (V2 settings preserved)
        self.rolling_windows = [4, 8, 16]  # 4, 8, 16 game rolling averages
        self.recent_games_window = 4  # Recent form analysis
    
    def build_features(self, seasons=None, save_to_db=True) -> Dict[str, Any]:
        """
        Build comprehensive rolling metrics features.
        
        Simple feature engineering flow:
        1. Extract game-by-game team performance (Layer 3 call)
        2. Calculate rolling averages and windows (Layer 3 call)
        3. Add momentum and streak indicators (Layer 3 call)
        4. Calculate variance and consistency metrics (Layer 3 call)
        5. Save to features schema (Layer 3 call)
        
        Args:
            seasons: List of seasons to process (default: all available)
            save_to_db: Whether to save results to features schema
            
        Returns:
            Dictionary with feature build results
        """
        self.logger.info(f"Building rolling metrics features for seasons: {seasons or 'all'}")
        
        try:
            # Step 1: Build game-by-game performance dataset
            df = self._build_game_by_game_dataset(seasons)
            
            if df.empty:
                self.logger.warning("No game-by-game data found")
                return {
                    'status': 'warning',
                    'message': 'No data available',
                    'features_built': 0,
                    'seasons_processed': 0
                }
            
            # Step 2: Calculate rolling metrics (V2 sophistication preserved)
            df = self._add_rolling_metrics(df)
            
            # Step 3: Add momentum and streak indicators
            df = self._add_momentum_indicators(df)
            
            # Step 4: Calculate consistency metrics
            df = self._add_consistency_metrics(df)
            
            # Step 5: Save to database if requested
            if save_to_db:
                save_result = self._save_features_to_db(df)
                if not save_result['success']:
                    return {
                        'status': 'error',
                        'message': f"Failed to save features: {save_result['error']}",
                        'features_built': len(df),
                        'data': df
                    }
            
            # Step 6: Return comprehensive results
            seasons_processed = df['season'].nunique() if 'season' in df.columns else 0
            teams_processed = df['team'].nunique() if 'team' in df.columns else 0
            games_processed = len(df)
            
            self.logger.info(f"✓ Built rolling metrics features: {games_processed} team-games")
            
            return {
                'status': 'success',
                'features_built': games_processed,
                'seasons_processed': seasons_processed,
                'teams_processed': teams_processed,
                'feature_columns': len(df.columns),
                'data': df,
                'saved_to_db': save_to_db
            }
            
        except Exception as e:
            self.logger.error(f"Failed to build rolling metrics features: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'features_built': 0
            }
    
    def _build_game_by_game_dataset(self, seasons=None) -> pd.DataFrame:
        """
        Build game-by-game performance dataset using V2's logic.
        
        Direct database calls (Layer 3) - preserves V2 business logic
        
        Args:
            seasons: List of seasons to process
            
        Returns:
            DataFrame with game-by-game team performance
        """
        # Build season filter
        season_filter = ""
        if seasons:
            if isinstance(seasons, (list, tuple)):
                season_list = ','.join(str(s) for s in seasons)
                season_filter = f"AND g.season IN ({season_list})"
            else:
                season_filter = f"AND g.season = {seasons}"
        
        # V2's game-by-game performance query (preserved exactly)
        query = text(f"""
        WITH game_performance AS (
            SELECT 
                g.game_id,
                g.season,
                g.week,
                g.game_date,
                g.home_team,
                g.away_team,
                
                -- Home team perspective
                g.home_team as team,
                'home' as venue,
                g.home_score as points_for,
                g.away_score as points_against,
                CASE WHEN g.home_score > g.away_score THEN 1 ELSE 0 END as win,
                g.home_score - g.away_score as point_differential,
                
                -- Game context
                CASE WHEN g.roof = 'outdoors' THEN 1 ELSE 0 END as outdoor_game,
                CASE WHEN g.surface = 'grass' THEN 1 ELSE 0 END as grass_surface,
                
                -- Team performance from play-by-play aggregation
                home_stats.offensive_epa,
                home_stats.defensive_epa,
                home_stats.total_plays_offense,
                home_stats.total_plays_defense,
                home_stats.turnovers_lost,
                home_stats.turnovers_forced,
                home_stats.red_zone_attempts,
                home_stats.red_zone_scores,
                home_stats.third_down_attempts,
                home_stats.third_down_conversions
                
            FROM analytics.dim_game g
            
            -- Join aggregated team stats for home team
            LEFT JOIN (
                SELECT 
                    p.game_id,
                    SUM(CASE WHEN p.posteam = g.home_team THEN p.epa ELSE 0 END) as offensive_epa,
                    SUM(CASE WHEN p.defteam = g.home_team THEN p.epa ELSE 0 END) as defensive_epa,
                    COUNT(CASE WHEN p.posteam = g.home_team THEN 1 END) as total_plays_offense,
                    COUNT(CASE WHEN p.defteam = g.home_team THEN 1 END) as total_plays_defense,
                    SUM(CASE WHEN p.posteam = g.home_team AND p.interception = 1 THEN 1 
                             WHEN p.posteam = g.home_team AND p.fumble_lost = 1 THEN 1 ELSE 0 END) as turnovers_lost,
                    SUM(CASE WHEN p.defteam = g.home_team AND p.interception = 1 THEN 1 
                             WHEN p.defteam = g.home_team AND p.fumble_lost = 1 THEN 1 ELSE 0 END) as turnovers_forced,
                    COUNT(CASE WHEN p.posteam = g.home_team AND p.yardline_100 <= 20 THEN 1 END) as red_zone_attempts,
                    SUM(CASE WHEN p.posteam = g.home_team AND p.yardline_100 <= 20 AND p.touchdown = 1 THEN 1 ELSE 0 END) as red_zone_scores,
                    COUNT(CASE WHEN p.posteam = g.home_team AND p.down = 3 THEN 1 END) as third_down_attempts,
                    SUM(CASE WHEN p.posteam = g.home_team AND p.down = 3 AND p.ydstogo <= p.yards_gained THEN 1 ELSE 0 END) as third_down_conversions
                FROM analytics.fact_play p
                JOIN analytics.dim_game g ON p.game_id = g.game_id
                WHERE p.play_type IN ('pass', 'run') 
                    AND p.epa IS NOT NULL
                    {season_filter}
                GROUP BY p.game_id, g.home_team
            ) home_stats ON g.game_id = home_stats.game_id
            
            WHERE g.season IS NOT NULL {season_filter}
            
            UNION ALL
            
            -- Away team perspective (same logic, flipped)
            SELECT 
                g.game_id,
                g.season,
                g.week,
                g.game_date,
                g.home_team,
                g.away_team,
                
                -- Away team perspective
                g.away_team as team,
                'away' as venue,
                g.away_score as points_for,
                g.home_score as points_against,
                CASE WHEN g.away_score > g.home_score THEN 1 ELSE 0 END as win,
                g.away_score - g.home_score as point_differential,
                
                -- Game context
                CASE WHEN g.roof = 'outdoors' THEN 1 ELSE 0 END as outdoor_game,
                CASE WHEN g.surface = 'grass' THEN 1 ELSE 0 END as grass_surface,
                
                -- Team performance from play-by-play aggregation
                away_stats.offensive_epa,
                away_stats.defensive_epa,
                away_stats.total_plays_offense,
                away_stats.total_plays_defense,
                away_stats.turnovers_lost,
                away_stats.turnovers_forced,
                away_stats.red_zone_attempts,
                away_stats.red_zone_scores,
                away_stats.third_down_attempts,
                away_stats.third_down_conversions
                
            FROM analytics.dim_game g
            
            -- Join aggregated team stats for away team
            LEFT JOIN (
                SELECT 
                    p.game_id,
                    SUM(CASE WHEN p.posteam = g.away_team THEN p.epa ELSE 0 END) as offensive_epa,
                    SUM(CASE WHEN p.defteam = g.away_team THEN p.epa ELSE 0 END) as defensive_epa,
                    COUNT(CASE WHEN p.posteam = g.away_team THEN 1 END) as total_plays_offense,
                    COUNT(CASE WHEN p.defteam = g.away_team THEN 1 END) as total_plays_defense,
                    SUM(CASE WHEN p.posteam = g.away_team AND p.interception = 1 THEN 1 
                             WHEN p.posteam = g.away_team AND p.fumble_lost = 1 THEN 1 ELSE 0 END) as turnovers_lost,
                    SUM(CASE WHEN p.defteam = g.away_team AND p.interception = 1 THEN 1 
                             WHEN p.defteam = g.away_team AND p.fumble_lost = 1 THEN 1 ELSE 0 END) as turnovers_forced,
                    COUNT(CASE WHEN p.posteam = g.away_team AND p.yardline_100 <= 20 THEN 1 END) as red_zone_attempts,
                    SUM(CASE WHEN p.posteam = g.away_team AND p.yardline_100 <= 20 AND p.touchdown = 1 THEN 1 ELSE 0 END) as red_zone_scores,
                    COUNT(CASE WHEN p.posteam = g.away_team AND p.down = 3 THEN 1 END) as third_down_attempts,
                    SUM(CASE WHEN p.posteam = g.away_team AND p.down = 3 AND p.ydstogo <= p.yards_gained THEN 1 ELSE 0 END) as third_down_conversions
                FROM analytics.fact_play p
                JOIN analytics.dim_game g ON p.game_id = g.game_id
                WHERE p.play_type IN ('pass', 'run') 
                    AND p.epa IS NOT NULL
                    {season_filter}
                GROUP BY p.game_id, g.away_team
            ) away_stats ON g.game_id = away_stats.game_id
            
            WHERE g.season IS NOT NULL {season_filter}
        )
        SELECT 
            game_id,
            season,
            week,
            game_date,
            team,
            venue,
            win,
            points_for,
            points_against,
            point_differential,
            outdoor_game,
            grass_surface,
            
            -- Performance metrics
            ROUND(offensive_epa::numeric, 4) as offensive_epa,
            ROUND(defensive_epa::numeric, 4) as defensive_epa,
            total_plays_offense,
            total_plays_defense,
            turnovers_lost,
            turnovers_forced,
            
            -- Efficiency metrics
            ROUND((offensive_epa::float / NULLIF(total_plays_offense, 0))::numeric, 4) as epa_per_play_offense,
            ROUND((defensive_epa::float / NULLIF(total_plays_defense, 0))::numeric, 4) as epa_per_play_defense,
            ROUND((red_zone_scores::float / NULLIF(red_zone_attempts, 0))::numeric, 4) as red_zone_efficiency,
            ROUND((third_down_conversions::float / NULLIF(third_down_attempts, 0))::numeric, 4) as third_down_efficiency,
            (turnovers_forced - turnovers_lost) as turnover_differential
            
        FROM game_performance
        WHERE team IS NOT NULL
        ORDER BY team, season, week
        """)
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                df = pd.read_sql(query, conn)
            
            # Validate the feature data (V2 validation preserved)
            required_columns = ['team', 'season', 'week', 'game_date', 'win', 'epa_per_play_offense']
            missing_cols = [col for col in required_columns if col not in df.columns]
            if missing_cols:
                self.logger.error(f"Missing required columns in game performance data: {missing_cols}")
                return pd.DataFrame()
            
            # Convert game_date to datetime for proper sorting
            df['game_date'] = pd.to_datetime(df['game_date'])
            
            # Sort by team and chronological order for rolling calculations
            df = df.sort_values(['team', 'season', 'week']).reset_index(drop=True)
            
            self.logger.debug(f"Extracted game-by-game data: {len(df)} games, {len(df.columns)} columns")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to extract game-by-game data: {e}")
            return pd.DataFrame()
    
    def _add_rolling_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add rolling metrics across multiple time windows (V2 logic preserved).
        
        Args:
            df: DataFrame with game-by-game performance
            
        Returns:
            DataFrame with rolling metrics added
        """
        if df.empty:
            return df
        
        self.logger.debug(f"Adding rolling metrics for windows: {self.rolling_windows}")
        
        # Group by team to calculate team-specific rolling metrics
        for window in self.rolling_windows:
            # Rolling averages for key metrics (V2 features preserved)
            df[f'rolling_{window}g_epa_offense'] = df.groupby('team')['epa_per_play_offense'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_epa_defense'] = df.groupby('team')['epa_per_play_defense'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_points_for'] = df.groupby('team')['points_for'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_points_against'] = df.groupby('team')['points_against'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_point_diff'] = df.groupby('team')['point_differential'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_win_rate'] = df.groupby('team')['win'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_turnover_diff'] = df.groupby('team')['turnover_differential'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_red_zone_eff'] = df.groupby('team')['red_zone_efficiency'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
            df[f'rolling_{window}g_third_down_eff'] = df.groupby('team')['third_down_efficiency'].rolling(window=window, min_periods=1).mean().reset_index(0, drop=True)
        
        self.logger.debug(f"Added rolling metrics: {len(df.columns)} total columns")
        return df
    
    def _add_momentum_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add momentum and streak indicators (V2 logic preserved).
        
        Args:
            df: DataFrame with rolling metrics
            
        Returns:
            DataFrame with momentum indicators added
        """
        if df.empty:
            return df
        
        self.logger.debug("Adding momentum and streak indicators")
        
        # Recent form analysis (last N games)
        recent_window = self.recent_games_window
        df[f'recent_{recent_window}g_win_rate'] = df.groupby('team')['win'].rolling(window=recent_window, min_periods=1).mean().reset_index(0, drop=True)
        df[f'recent_{recent_window}g_avg_margin'] = df.groupby('team')['point_differential'].rolling(window=recent_window, min_periods=1).mean().reset_index(0, drop=True)
        df[f'recent_{recent_window}g_epa_trend'] = df.groupby('team')['epa_per_play_offense'].rolling(window=recent_window, min_periods=1).mean().reset_index(0, drop=True)
        
        # Win/loss streaks (V2 sophistication preserved)
        def calculate_streak(group):
            """Calculate current win/loss streak for a team."""
            streaks = []
            current_streak = 0
            
            for win in group['win']:
                if len(streaks) == 0:
                    current_streak = 1 if win else -1
                else:
                    if (win and current_streak > 0) or (not win and current_streak < 0):
                        current_streak = current_streak + 1 if win else current_streak - 1
                    else:
                        current_streak = 1 if win else -1
                
                streaks.append(current_streak)
            
            return pd.Series(streaks, index=group.index)
        
        df['win_loss_streak'] = df.groupby('team', group_keys=False).apply(calculate_streak).reset_index(0, drop=True)
        
        # Performance trending (improving vs declining)
        for metric in ['epa_per_play_offense', 'epa_per_play_defense', 'point_differential']:
            # Compare recent performance to longer-term average
            recent_avg = df.groupby('team')[metric].rolling(window=4, min_periods=1).mean().reset_index(0, drop=True)
            longer_avg = df.groupby('team')[metric].rolling(window=8, min_periods=1).mean().reset_index(0, drop=True)
            df[f'{metric}_trending'] = recent_avg - longer_avg
        
        self.logger.debug(f"Added momentum indicators: {len(df.columns)} total columns")
        return df
    
    def _add_consistency_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add consistency and variance metrics (V2 logic preserved).
        
        Args:
            df: DataFrame with momentum indicators
            
        Returns:
            DataFrame with consistency metrics added
        """
        if df.empty:
            return df
        
        self.logger.debug("Adding consistency and variance metrics")
        
        # Rolling standard deviations (consistency indicators)
        for window in [4, 8]:
            df[f'rolling_{window}g_epa_offense_std'] = df.groupby('team')['epa_per_play_offense'].rolling(window=window, min_periods=2).std().reset_index(0, drop=True)
            df[f'rolling_{window}g_point_diff_std'] = df.groupby('team')['point_differential'].rolling(window=window, min_periods=2).std().reset_index(0, drop=True)
            df[f'rolling_{window}g_points_for_std'] = df.groupby('team')['points_for'].rolling(window=window, min_periods=2).std().reset_index(0, drop=True)
        
        # Home/away performance splits
        df['home_field_advantage'] = df.groupby(['team', 'venue'])['point_differential'].transform(lambda x: x.rolling(window=8, min_periods=1).mean())
        
        # Performance by game context
        df['outdoor_performance'] = df.groupby(['team', 'outdoor_game'])['epa_per_play_offense'].transform(lambda x: x.rolling(window=8, min_periods=1).mean())
        df['grass_performance'] = df.groupby(['team', 'grass_surface'])['epa_per_play_offense'].transform(lambda x: x.rolling(window=8, min_periods=1).mean())
        
        self.logger.debug(f"Added consistency metrics: {len(df.columns)} total columns")
        return df
    
    def _save_features_to_db(self, df: pd.DataFrame, table_name='rolling_metrics_features') -> Dict[str, Any]:
        """
        Save rolling metrics features to features schema.
        
        Args:
            df: DataFrame to save
            table_name: Target table name
            
        Returns:
            Dictionary with save results
        """
        try:
            self.logger.info(f"Saving {len(df)} rows to features.{table_name}")
            
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.begin() as conn:
                df.to_sql(
                    name=table_name,
                    con=conn,
                    schema='features',
                    if_exists='replace',
                    index=False,
                    method='multi'
                )
            
            self.logger.info(f"✓ Rolling metrics features saved to features.{table_name}")
            return {'success': True, 'table_name': table_name, 'rows_saved': len(df)}
            
        except Exception as e:
            self.logger.error(f"Failed to save rolling metrics features: {e}")
            return {'success': False, 'error': str(e)}
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → RollingMetricsFeatures.build_features() [Layer 1]
             → Database queries [Layer 2]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 2,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → RollingMetricsFeatures → Database (2 layers)'
        }


# Convenience function for direct usage
def create_rolling_metrics_features(db_service=None, logger=None):
    """
    Create rolling metrics features service with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        RollingMetricsFeatures: Configured rolling metrics features service
    """
    from ...shared.database import NFLfastRDatabase
    from commonv2 import get_logger
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.ml_pipeline.rolling_metrics')
    
    return RollingMetricsFeatures(db_service, logger)


__all__ = ['RollingMetricsFeatures', 'create_rolling_metrics_features']
