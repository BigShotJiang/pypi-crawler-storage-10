"""
Team Efficiency Features - V3 Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Migrated from nflfastRv2 with V3 clean architecture patterns:
- Sophisticated EPA calculations preserved
- Red zone efficiency metrics preserved  
- Turnover analysis preserved
- Clean dependency injection
- REFACTORING_SPECS.md compliant

"Can I Trace This?" test:
User → TeamEfficiencyFeatures.build_features() → Database queries
✅ 3 layers maximum, easily traceable

V2 Business Logic Preserved:
- Comprehensive team offensive/defensive efficiency metrics
- EPA per play calculations
- Red zone touchdown rates
- Third down conversion rates  
- Turnover rates and differentials
- Efficiency rankings within season
"""

import pandas as pd
from sqlalchemy import text
from typing import Dict, Any, List, Optional


class TeamEfficiencyFeatures:
    """
    Team efficiency feature engineering service.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + sophisticated calculations)
    Depth: 1 layer (calls database directly)
    
    V2 Capabilities Preserved:
    - Offensive EPA per play
    - Defensive EPA per play allowed
    - Red zone efficiency (offense and defense)
    - Third down conversion rates
    - Turnover rates and differentials
    - Time of possession efficiency
    - Efficiency rankings
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
    
    def build_features(self, seasons=None, save_to_db=True) -> Dict[str, Any]:
        """
        Build comprehensive team efficiency features.
        
        Simple feature engineering flow:
        1. Extract team offensive metrics (Layer 3 call)
        2. Extract team defensive metrics (Layer 3 call)
        3. Calculate efficiency differentials (Layer 3 call)
        4. Add derived features and rankings (Layer 3 call)
        5. Save to features schema (Layer 3 call)
        
        Args:
            seasons: List of seasons to process (default: all available)
            save_to_db: Whether to save results to features schema
            
        Returns:
            Dictionary with feature build results
        """
        self.logger.info(f"Building team efficiency features for seasons: {seasons or 'all'}")
        
        try:
            # Step 1: Build the feature dataset using V2's sophisticated logic
            df = self._build_team_efficiency_dataset(seasons)
            
            if df.empty:
                self.logger.warning("No team efficiency data found")
                return {
                    'status': 'warning',
                    'message': 'No data available',
                    'features_built': 0,
                    'seasons_processed': 0
                }
            
            # Step 2: Add derived features (V2 sophistication preserved)
            df = self._add_derived_efficiency_features(df)
            
            # Step 3: Save to database if requested
            if save_to_db:
                save_result = self._save_features_to_db(df)
                if not save_result['success']:
                    return {
                        'status': 'error',
                        'message': f"Failed to save features: {save_result['error']}",
                        'features_built': len(df),
                        'data': df
                    }
            
            # Step 4: Return comprehensive results
            seasons_processed = df['season'].nunique() if 'season' in df.columns else 0
            teams_processed = df['team'].nunique() if 'team' in df.columns else 0
            
            self.logger.info(f"✓ Built team efficiency features: {len(df)} team-seasons")
            
            return {
                'status': 'success',
                'features_built': len(df),
                'seasons_processed': seasons_processed,
                'teams_processed': teams_processed,
                'feature_columns': len(df.columns),
                'data': df,
                'saved_to_db': save_to_db
            }
            
        except Exception as e:
            self.logger.error(f"Failed to build team efficiency features: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'features_built': 0
            }
    
    def _build_team_efficiency_dataset(self, seasons=None) -> pd.DataFrame:
        """
        Build team efficiency dataset using V2's sophisticated SQL logic.
        
        Direct database calls (Layer 3) - preserves V2 business logic
        
        Args:
            seasons: List of seasons to process
            
        Returns:
            DataFrame with team efficiency features
        """
        # Build season filter
        season_filter = ""
        if seasons:
            if isinstance(seasons, (list, tuple)):
                season_list = ','.join(str(s) for s in seasons)
                season_filter = f"AND g.season IN ({season_list})"
            else:
                season_filter = f"AND g.season = {seasons}"
        
        # V2's sophisticated team efficiency query (preserved exactly)
        query = text(f"""
        WITH team_offense AS (
            SELECT 
                p.posteam as team,
                g.season,
                COUNT(*) as offensive_plays,
                AVG(p.epa) as avg_offensive_epa,
                AVG(CASE WHEN p.down = 3 AND p.ydstogo <= p.yards_gained THEN 1.0 ELSE 0.0 END) as third_down_conversion_rate,
                AVG(CASE WHEN p.yardline_100 <= 20 AND p.touchdown = true THEN 1.0 
                         WHEN p.yardline_100 <= 20 THEN 0.0 END) as red_zone_td_rate,
                SUM(CASE WHEN p.play_type IN ('interception', 'fumble') THEN 1 ELSE 0 END) as turnovers_lost,
                AVG(CASE WHEN p.rush_attempt = true THEN p.yards_gained END) as avg_rush_yards,
                AVG(CASE WHEN p.pass_attempt = true THEN p.yards_gained END) as avg_pass_yards,
                SUM(CASE WHEN p.touchdown = true THEN 1 ELSE 0 END) as touchdowns_scored,
                AVG(CASE WHEN p.play_type = 'pass' THEN p.epa END) as pass_epa,
                AVG(CASE WHEN p.play_type = 'run' THEN p.epa END) as rush_epa
            FROM analytics.fact_play p
            JOIN analytics.dim_game g ON p.game_id = g.game_id
            WHERE p.posteam IS NOT NULL 
                AND p.play_type IN ('pass', 'run')
                AND p.epa IS NOT NULL
                {season_filter}
            GROUP BY p.posteam, g.season
        ),
        team_defense AS (
            SELECT 
                p.defteam as team,
                g.season,
                COUNT(*) as defensive_plays,
                AVG(p.epa) as avg_defensive_epa_allowed,
                AVG(CASE WHEN p.down = 3 AND p.ydstogo <= p.yards_gained THEN 1.0 ELSE 0.0 END) as third_down_conversion_rate_allowed,
                AVG(CASE WHEN p.yardline_100 <= 20 AND p.touchdown = true THEN 1.0 
                         WHEN p.yardline_100 <= 20 THEN 0.0 END) as red_zone_td_rate_allowed,
                SUM(CASE WHEN p.play_type IN ('interception', 'fumble') THEN 1 ELSE 0 END) as turnovers_forced,
                AVG(CASE WHEN p.rush_attempt = true THEN p.yards_gained END) as avg_rush_yards_allowed,
                AVG(CASE WHEN p.pass_attempt = true THEN p.yards_gained END) as avg_pass_yards_allowed,
                SUM(CASE WHEN p.touchdown = true THEN 1 ELSE 0 END) as touchdowns_allowed,
                AVG(CASE WHEN p.play_type = 'pass' THEN p.epa END) as pass_epa_allowed,
                AVG(CASE WHEN p.play_type = 'run' THEN p.epa END) as rush_epa_allowed
            FROM analytics.fact_play p
            JOIN analytics.dim_game g ON p.game_id = g.game_id
            WHERE p.defteam IS NOT NULL 
                AND p.play_type IN ('pass', 'run')
                AND p.epa IS NOT NULL
                {season_filter}
            GROUP BY p.defteam, g.season
        ),
        team_games AS (
            SELECT 
                team_abbr as team,
                season,
                COUNT(*) as games_played
            FROM (
                SELECT home_team as team_abbr, season FROM analytics.dim_game
                UNION ALL
                SELECT away_team as team_abbr, season FROM analytics.dim_game
            ) team_schedule
            WHERE season IS NOT NULL {season_filter.replace('AND g.season', 'AND team_schedule.season')}
            GROUP BY team_abbr, season
        )
        SELECT 
            COALESCE(o.team, d.team) as team,
            COALESCE(o.season, d.season) as season,
            g.games_played,
            
            -- Offensive metrics (V2 sophistication preserved)
            o.offensive_plays,
            ROUND(o.avg_offensive_epa::numeric, 4) as offensive_epa_per_play,
            ROUND(o.third_down_conversion_rate::numeric, 4) as offensive_third_down_rate,
            ROUND(o.red_zone_td_rate::numeric, 4) as offensive_red_zone_td_rate,
            o.turnovers_lost as offensive_turnovers,
            ROUND(o.avg_rush_yards::numeric, 2) as avg_rushing_yards,
            ROUND(o.avg_pass_yards::numeric, 2) as avg_passing_yards,
            o.touchdowns_scored as offensive_touchdowns,
            ROUND(o.pass_epa::numeric, 4) as offensive_pass_epa,
            ROUND(o.rush_epa::numeric, 4) as offensive_rush_epa,
            
            -- Defensive metrics (V2 sophistication preserved)
            d.defensive_plays,
            ROUND(d.avg_defensive_epa_allowed::numeric, 4) as defensive_epa_per_play_allowed,
            ROUND(d.third_down_conversion_rate_allowed::numeric, 4) as defensive_third_down_rate_allowed,
            ROUND(d.red_zone_td_rate_allowed::numeric, 4) as defensive_red_zone_td_rate_allowed,
            d.turnovers_forced as defensive_turnovers_forced,
            ROUND(d.avg_rush_yards_allowed::numeric, 2) as avg_rushing_yards_allowed,
            ROUND(d.avg_pass_yards_allowed::numeric, 2) as avg_passing_yards_allowed,
            d.touchdowns_allowed as defensive_touchdowns_allowed,
            ROUND(d.pass_epa_allowed::numeric, 4) as defensive_pass_epa_allowed,
            ROUND(d.rush_epa_allowed::numeric, 4) as defensive_rush_epa_allowed,
            
            -- Efficiency ratios (V2 sophistication preserved)
            ROUND((o.turnovers_lost::float / NULLIF(o.offensive_plays, 0))::numeric, 6) as turnover_rate_offense,
            ROUND((d.turnovers_forced::float / NULLIF(d.defensive_plays, 0))::numeric, 6) as turnover_rate_defense,
            ROUND((o.touchdowns_scored::float / NULLIF(g.games_played, 0))::numeric, 2) as touchdowns_per_game,
            ROUND((d.touchdowns_allowed::float / NULLIF(g.games_played, 0))::numeric, 2) as touchdowns_allowed_per_game
            
        FROM team_offense o
        FULL OUTER JOIN team_defense d ON o.team = d.team AND o.season = d.season
        LEFT JOIN team_games g ON COALESCE(o.team, d.team) = g.team 
                               AND COALESCE(o.season, d.season) = g.season
        WHERE COALESCE(o.team, d.team) IS NOT NULL
        ORDER BY season DESC, team
        """)
        
        try:
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.connect() as conn:
                df = pd.read_sql(query, conn)
            
            # Validate the feature data (V2 validation preserved)
            required_columns = ['team', 'season', 'offensive_epa_per_play', 'defensive_epa_per_play_allowed']
            missing_cols = [col for col in required_columns if col not in df.columns]
            if missing_cols:
                self.logger.error(f"Missing required columns in team efficiency features: {missing_cols}")
                return pd.DataFrame()
            
            self.logger.debug(f"Extracted team efficiency data: {len(df)} rows, {len(df.columns)} columns")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to extract team efficiency data: {e}")
            return pd.DataFrame()
    
    def _add_derived_efficiency_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add derived efficiency features (V2 logic preserved).
        
        Args:
            df: DataFrame with base team efficiency features
            
        Returns:
            DataFrame with additional derived features
        """
        if df.empty:
            return df
        
        self.logger.debug("Adding derived efficiency features")
        
        # Calculate efficiency differentials (V2 features preserved)
        df['epa_differential'] = df['offensive_epa_per_play'] - df['defensive_epa_per_play_allowed']
        df['pass_epa_differential'] = df['offensive_pass_epa'] - df['defensive_pass_epa_allowed']
        df['rush_epa_differential'] = df['offensive_rush_epa'] - df['defensive_rush_epa_allowed']
        
        # Calculate turnover differential (V2 features preserved)
        df['turnover_differential'] = df['defensive_turnovers_forced'] - df['offensive_turnovers']
        
        # Calculate scoring differential per game (V2 features preserved)
        df['scoring_differential_per_game'] = df['touchdowns_per_game'] - df['touchdowns_allowed_per_game']
        
        # Calculate yards differential (V2 features preserved)
        df['rushing_yards_differential'] = df['avg_rushing_yards'] - df['avg_rushing_yards_allowed']
        df['passing_yards_differential'] = df['avg_passing_yards'] - df['avg_passing_yards_allowed']
        
        # Calculate efficiency rankings within season (V2 sophistication preserved)
        for season in df['season'].unique():
            season_mask = df['season'] == season
            
            # Offensive rankings (higher is better)
            df.loc[season_mask, 'offensive_epa_rank'] = df.loc[season_mask, 'offensive_epa_per_play'].rank(ascending=False)
            df.loc[season_mask, 'offensive_third_down_rank'] = df.loc[season_mask, 'offensive_third_down_rate'].rank(ascending=False)
            df.loc[season_mask, 'offensive_red_zone_rank'] = df.loc[season_mask, 'offensive_red_zone_td_rate'].rank(ascending=False)
            
            # Defensive rankings (lower is better for EPA allowed)
            df.loc[season_mask, 'defensive_epa_rank'] = df.loc[season_mask, 'defensive_epa_per_play_allowed'].rank(ascending=True)
            df.loc[season_mask, 'defensive_third_down_rank'] = df.loc[season_mask, 'defensive_third_down_rate_allowed'].rank(ascending=True)
            df.loc[season_mask, 'defensive_red_zone_rank'] = df.loc[season_mask, 'defensive_red_zone_td_rate_allowed'].rank(ascending=True)
            
            # Overall efficiency rank (V2 sophistication preserved)
            df.loc[season_mask, 'overall_efficiency_rank'] = df.loc[season_mask, 'epa_differential'].rank(ascending=False)
            df.loc[season_mask, 'turnover_differential_rank'] = df.loc[season_mask, 'turnover_differential'].rank(ascending=False)
        
        self.logger.debug(f"Added derived features: {len(df.columns)} total columns")
        return df
    
    def _save_features_to_db(self, df: pd.DataFrame, table_name='team_efficiency_features') -> Dict[str, Any]:
        """
        Save team efficiency features to features schema.
        
        Args:
            df: DataFrame to save
            table_name: Target table name
            
        Returns:
            Dictionary with save results
        """
        try:
            self.logger.info(f"Saving {len(df)} rows to features.{table_name}")
            
            # Get engine from database service (Layer 3 call)
            engine = self.db_service.get_engine()
            
            with engine.begin() as conn:
                df.to_sql(
                    name=table_name,
                    con=conn,
                    schema='features',
                    if_exists='replace',
                    index=False,
                    method='multi'
                )
            
            self.logger.info(f"✓ Team efficiency features saved to features.{table_name}")
            return {'success': True, 'table_name': table_name, 'rows_saved': len(df)}
            
        except Exception as e:
            self.logger.error(f"Failed to save team efficiency features: {e}")
            return {'success': False, 'error': str(e)}
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → TeamEfficiencyFeatures.build_features() [Layer 1]
             → Database queries [Layer 2]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 2,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → TeamEfficiencyFeatures → Database (2 layers)'
        }


# Convenience function for direct usage
def create_team_efficiency_features(db_service=None, logger=None):
    """
    Create team efficiency features service with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        TeamEfficiencyFeatures: Configured team efficiency features service
    """
    from ...shared.database import NFLfastRDatabase
    from commonv2 import get_logger
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.ml_pipeline.team_efficiency')
    
    return TeamEfficiencyFeatures(db_service, logger)


__all__ = ['TeamEfficiencyFeatures', 'create_team_efficiency_features']
