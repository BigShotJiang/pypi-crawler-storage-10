"""
Model Storage and Persistence Module - V3 Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Migrated from nflfastRv2 with V3 clean architecture patterns:
- Clean dependency injection
- Simplified interface with V2 functionality
- Backward compatibility preserved
- REFACTORING_SPECS.md compliant

"Can I Trace This?" test:
User → ModelStore.save_model() → Filesystem operations
✅ 3 layers maximum, easily traceable
"""

import joblib
from pathlib import Path
from datetime import datetime
from typing import Any, Optional, Dict, List


class ModelStore:
    """
    Model persistence and management service.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + file operations)
    Depth: 1 layer (calls filesystem directly)
    
    Migrated capabilities from V2:
    - Model versioning with timestamps
    - Automatic cleanup of old models
    - Model metadata tracking (size, creation date)
    - Backward compatibility with V1 paths
    - Support for multiple model types
    """
    
    def __init__(self, model_dir=None, logger=None):
        """
        Initialize model store with injected dependencies.
        
        Args:
            model_dir: Custom model directory (default: backward compatible path)
            logger: Logger instance (Layer 3)
        """
        self.logger = logger
        
        # CRITICAL: Preserve exact same paths as V1/V2 for backward compatibility
        if model_dir is None:
            # This resolves to: nflfastR/ml/models/ (same as V1/V2)
            self.model_dir = Path(__file__).parent.parent.parent.parent / "nflfastR" / "ml" / "models"
        else:
            self.model_dir = Path(model_dir)
        
        # Model configurations (migrated from V2)
        self.model_configs = {
            "game_outcome": {
                "description": "Binary classifier for game winners",
                "model_type": "classification",
                "target": "home_team_wins",
                "metrics": ["accuracy", "precision", "recall", "f1", "auc"]
            },
            "point_spread": {
                "description": "Regression model for point spreads",
                "model_type": "regression", 
                "target": "point_differential",
                "metrics": ["mae", "rmse", "r2"]
            },
            "total_points": {
                "description": "Regression model for total game points",
                "model_type": "regression",
                "target": "total_points",
                "metrics": ["mae", "rmse", "r2"]
            }
        }
        
        self._ensure_model_dir()
    
    def save_model(self, model: Any, model_name: str = "current_model") -> Dict[str, Any]:
        """
        Save a trained model to disk with versioning.
        
        Direct filesystem calls (Layer 3) - no complex patterns
        
        Args:
            model: Trained scikit-learn model or any joblib-serializable object
            model_name: Name for the model file (without extension)
            
        Returns:
            Dictionary with save results and metadata
        """
        try:
            # Create timestamped filename for versioning (V2 feature preserved)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            versioned_path = self.model_dir / f"{model_name}_{timestamp}.joblib"
            current_path = self.model_dir / f"{model_name}.joblib"
            
            # Save versioned model
            joblib.dump(model, versioned_path)
            
            # Also save as "current" for easy loading (V2 feature preserved)
            joblib.dump(model, current_path)
            
            if self.logger:
                self.logger.info(f"Model saved: {versioned_path}")
                self.logger.info(f"Current model updated: {current_path}")
            
            return {
                'status': 'success',
                'versioned_path': str(versioned_path),
                'current_path': str(current_path),
                'model_name': model_name,
                'timestamp': timestamp,
                'size_mb': round(versioned_path.stat().st_size / (1024 * 1024), 2)
            }
            
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to save model {model_name}: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'model_name': model_name
            }
    
    def load_model(self, model_name: str = "current_model") -> Dict[str, Any]:
        """
        Load a trained model from disk.
        
        Direct filesystem calls (Layer 3) - no complex patterns
        
        Args:
            model_name: Name of the model file to load (without extension)
            
        Returns:
            Dictionary with loaded model and metadata
        """
        try:
            model_path = self.model_dir / f"{model_name}.joblib"
            
            if not model_path.exists():
                available_models = self.list_available_models()
                return {
                    'status': 'error',
                    'message': f"Model '{model_name}' not found at {model_path}",
                    'available_models': available_models,
                    'model_name': model_name
                }
            
            model = joblib.load(model_path)
            metadata = self.get_model_info(model_name)
            
            if self.logger:
                self.logger.info(f"Model loaded: {model_path}")
            
            return {
                'status': 'success',
                'model': model,
                'model_name': model_name,
                'metadata': metadata
            }
            
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to load model {model_name}: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'model_name': model_name
            }
    
    def list_available_models(self) -> List[str]:
        """
        List all available model files.
        
        Direct filesystem calls (Layer 3) - no complex patterns
        
        Returns:
            List of available model names (without extensions)
        """
        try:
            self._ensure_model_dir()
            model_files = self.model_dir.glob("*.joblib")
            models = [f.stem for f in model_files]
            
            if self.logger:
                self.logger.debug(f"Available models: {models}")
            
            return models
            
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to list models: {e}")
            return []
    
    def get_model_info(self, model_name: str = "current_model") -> Dict[str, Any]:
        """
        Get information about a saved model (V2 feature preserved).
        
        Args:
            model_name: Name of the model file
            
        Returns:
            Dictionary with model metadata
        """
        try:
            model_path = self.model_dir / f"{model_name}.joblib"
            
            if not model_path.exists():
                return {"exists": False, "model_name": model_name}
            
            stat = model_path.stat()
            
            # Get model configuration if available
            base_name = model_name.split('_')[0] if '_' in model_name else model_name
            config = self.model_configs.get(base_name, {})
            
            return {
                "exists": True,
                "model_name": model_name,
                "path": str(model_path),
                "size_mb": round(stat.st_size / (1024 * 1024), 2),
                "created": datetime.fromtimestamp(stat.st_ctime),
                "modified": datetime.fromtimestamp(stat.st_mtime),
                "config": config
            }
            
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to get model info for {model_name}: {e}")
            return {"exists": False, "error": str(e), "model_name": model_name}
    
    def cleanup_old_models(self, keep_count: int = 5) -> Dict[str, Any]:
        """
        Clean up old model versions (V2 feature preserved).
        
        Args:
            keep_count: Number of recent models to keep for each model type
            
        Returns:
            Dictionary with cleanup results
        """
        try:
            self._ensure_model_dir()
            
            # Group models by base name (without timestamp)
            model_groups = {}
            for model_file in self.model_dir.glob("*_[0-9]*_[0-9]*.joblib"):
                # Extract base name (everything before the timestamp)
                base_name = "_".join(model_file.stem.split("_")[:-2])
                if base_name not in model_groups:
                    model_groups[base_name] = []
                model_groups[base_name].append(model_file)
            
            deleted_count = 0
            deleted_files = []
            
            for base_name, files in model_groups.items():
                # Sort by modification time (newest first)
                files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
                
                # Delete old files beyond keep_count
                for old_file in files[keep_count:]:
                    old_file.unlink()
                    deleted_files.append(str(old_file))
                    deleted_count += 1
                    
                    if self.logger:
                        self.logger.info(f"Deleted old model: {old_file}")
            
            return {
                'status': 'success',
                'deleted_count': deleted_count,
                'deleted_files': deleted_files,
                'model_groups_processed': len(model_groups)
            }
            
        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to cleanup models: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'deleted_count': 0
            }
    
    def get_model_config(self, model_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific model type (V2 feature preserved).
        
        Args:
            model_name: Name of the model configuration
            
        Returns:
            Model configuration dictionary
        """
        base_name = model_name.split('_')[0] if '_' in model_name else model_name
        config = self.model_configs.get(base_name, {})
        
        if not config and self.logger:
            self.logger.warning(f"No configuration found for model: {model_name}")
        
        return config
    
    def _ensure_model_dir(self):
        """Ensure the models directory exists."""
        self.model_dir.mkdir(parents=True, exist_ok=True)
        
        if self.logger:
            self.logger.debug(f"Model directory ensured: {self.model_dir}")
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → ModelStore.save_model() [Layer 1]
             → File operations [Layer 2]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 2,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → ModelStore → Filesystem (2 layers)'
        }


# Convenience function for direct usage
def create_model_store(model_dir=None, logger=None):
    """
    Create model store with default dependencies.
    
    Args:
        model_dir: Optional custom model directory
        logger: Optional logger override
        
    Returns:
        ModelStore: Configured model store
    """
    from commonv2 import get_logger
    
    logger = logger or get_logger('nflfastRv3.ml_pipeline.model_store')
    
    return ModelStore(model_dir, logger)


__all__ = ['ModelStore', 'create_model_store']
