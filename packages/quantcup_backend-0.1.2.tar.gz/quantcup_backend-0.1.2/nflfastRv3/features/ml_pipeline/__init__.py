"""
ML Pipeline Feature

Phase 2: High priority feature (depends on data pipeline)
Pattern: Minimum Viable Decoupling (2 points, 2 layers)
Complexity: 5 points total

Architecture:
- main.py: Entry point and facade (1 point, 1 layer)
- implementation.py: ML workflow logic (2 points, 1 layer)
- feature_builder.py: Feature engineering (2 points, 1 layer)
- models.py: ML models and results (0 points)

Call Chain: 
Public API → MLPipelineImpl → Infrastructure
"""

from .main import MLPipelineImpl


def validate_ml_architecture():
    """
    Validate ML pipeline architecture constraints.
    
    Returns:
        dict: Validation results for all components
    """
    validation_results = {
        'overall_status': 'success',
        'components': {},
        'architecture_summary': {
            'max_layers': 3,
            'complexity_budget': 5,
            'pattern': 'Minimum Viable Decoupling'
        }
    }
    
    try:
        # Test main ML pipeline orchestration
        from commonv2 import get_logger
        from ...shared.database import NFLfastRDatabase
        
        # Create mock services for validation
        db_service = None  # Will use default
        logger = get_logger('validation')
        
        # Validate main ML pipeline component
        ml_pipeline = MLPipelineImpl(db_service, logger)
        main_validation = ml_pipeline.validate_call_depth()
        validation_results['components']['main'] = main_validation
        
        # Check overall compliance
        all_within_limits = all(
            comp['within_limits'] for comp in validation_results['components'].values()
        )
        
        all_correct_pattern = all(
            comp['pattern'] == 'Minimum Viable Decoupling' 
            for comp in validation_results['components'].values()
        )
        
        all_correct_complexity = all(
            comp['complexity_points'] <= 5 
            for comp in validation_results['components'].values()
        )
        
        if not (all_within_limits and all_correct_pattern and all_correct_complexity):
            validation_results['overall_status'] = 'failed'
            validation_results['issues'] = []
            
            if not all_within_limits:
                validation_results['issues'].append('Some components exceed layer depth limits')
            if not all_correct_pattern:
                validation_results['issues'].append('Some components use incorrect patterns')
            if not all_correct_complexity:
                validation_results['issues'].append('Some components exceed complexity budget')
        
    except Exception as e:
        validation_results['overall_status'] = 'error'
        validation_results['error'] = str(e)
    
    return validation_results


__all__ = [
    'MLPipelineImpl',
    'validate_ml_architecture'
]
