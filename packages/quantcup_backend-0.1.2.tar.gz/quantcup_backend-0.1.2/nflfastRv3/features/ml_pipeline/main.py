"""
ML Pipeline Implementation

Pattern: Minimum Viable Decoupling
Complexity: 2 points (DI + business logic)
Layer: 2 (Implementation - calls infrastructure directly)

Follows clean architecture with maximum 3 layers:
Layer 1: Public API (nflfastRv3/__init__.py)
Layer 2: This implementation 
Layer 3: Infrastructure (database, model storage)

"Can I Trace This?" test: 
User calls run_ml_pipeline() → MLPipelineImpl.process() → Database/Model services
✅ 3 layers, easily traceable
"""

from datetime import datetime
from ...shared.database import NFLfastRDatabase
from .feature_engineer import create_feature_engineer
from .model_trainer import create_model_trainer
from .predictor import create_predictor


class MLPipelineImpl:
    """
    Core ML pipeline business logic.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + orchestration)
    Depth: 1 layer (calls implementation components)
    
    Migrated from nflfastRv2 ML pipeline with clean architecture integration.
    Now uses real FeatureEngineer, ModelTrainer, and Predictor implementations.
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
        
        # Initialize ML components (Layer 2 - Implementation components)
        self.feature_engineer = create_feature_engineer(db_service, logger)
        self.model_trainer = create_model_trainer(db_service, logger)
        self.predictor = create_predictor(db_service, logger)
    
    def process(self, train_seasons='2020-2023', feature_sets=None, 
               generate_predictions=True, prediction_week=None, prediction_season=None):
        """
        Execute complete ML pipeline workflow.
        
        Real ML flow (migrated from V2):
        1. Engineer features (FeatureEngineer)
        2. Train models (ModelTrainer) 
        3. Generate predictions (Predictor)
        4. Return comprehensive summary
        
        Args:
            train_seasons: Seasons for training (e.g., '2020-2023')
            feature_sets: Feature sets to build ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
            generate_predictions: Whether to generate predictions after training
            prediction_week: Week to predict (default: current week)
            prediction_season: Season to predict (default: current season)
            
        Returns:
            dict: Complete ML pipeline summary
        """
        feature_sets = feature_sets or ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
        
        self.logger.info(f"Starting ML pipeline: seasons={train_seasons}, features={feature_sets}")
        
        try:
            total_start_time = datetime.now()
            
            # Step 1: Feature Engineering (Layer 2 call)
            self.logger.info("Step 1: Building ML features")
            features_result = self.feature_engineer.build_features(
                feature_sets=feature_sets,
                seasons=self._parse_seasons(train_seasons)
            )
            
            if features_result['status'] != 'success':
                return {
                    'status': 'error',
                    'message': f"Feature engineering failed: {features_result.get('message', 'Unknown error')}",
                    'pipeline_stage': 'feature_engineering'
                }
            
            # Step 2: Model Training (Layer 2 call)
            self.logger.info("Step 2: Training ML models")
            training_result = self.model_trainer.train_game_outcome_model(
                train_seasons=train_seasons,
                save_model=True
            )
            
            if training_result['status'] != 'success':
                return {
                    'status': 'error', 
                    'message': f"Model training failed: {training_result.get('message', 'Unknown error')}",
                    'pipeline_stage': 'model_training',
                    'features_result': features_result
                }
            
            # Step 3: Generate Predictions (Layer 2 call - optional)
            prediction_result = None
            if generate_predictions:
                self.logger.info("Step 3: Generating predictions")
                
                # Default to current week/season if not specified
                import datetime as dt
                current_date = dt.datetime.now()
                pred_season = prediction_season or current_date.year
                pred_week = prediction_week or min(18, max(1, current_date.isocalendar()[1] - 35))
                
                prediction_result = self.predictor.generate_predictions(
                    model_name='game_outcome',
                    week=pred_week,
                    season=pred_season,
                    save_predictions=True
                )
                
                if prediction_result['status'] != 'success':
                    self.logger.warning(f"Prediction generation failed: {prediction_result.get('message')}")
            
            # Step 4: Calculate pipeline summary
            total_duration = datetime.now() - total_start_time
            
            self.logger.info("✅ ML pipeline completed successfully")
            
            return {
                'status': 'success',
                'pipeline_duration': str(total_duration),
                'model_path': training_result.get('model_path'),
                'features_built': features_result.get('features_built', 0),
                'total_features_rows': features_result.get('total_rows', 0),
                'training_accuracy': training_result.get('metrics', {}).get('accuracy'),
                'training_auc': training_result.get('metrics', {}).get('auc'),
                'predictions_generated': prediction_result.get('num_predictions', 0) if prediction_result else 0,
                'results': {
                    'feature_engineering': features_result,
                    'model_training': training_result,
                    'predictions': prediction_result
                }
            }
            
        except Exception as e:
            self.logger.error(f"ML pipeline failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'pipeline_stage': 'orchestration'
            }
    
    def build_features_only(self, feature_sets=None, seasons=None):
        """
        Run only feature engineering step.
        
        Args:
            feature_sets: Feature sets to build
            seasons: Seasons to build for
            
        Returns:
            dict: Feature engineering results
        """
        self.logger.info("Running feature engineering only")
        return self.feature_engineer.build_features(feature_sets, seasons)
    
    def train_model_only(self, train_seasons='2020-2023', test_seasons=None):
        """
        Run only model training step.
        
        Args:
            train_seasons: Training seasons
            test_seasons: Test seasons
            
        Returns:
            dict: Model training results
        """
        self.logger.info("Running model training only")
        return self.model_trainer.train_game_outcome_model(train_seasons, test_seasons)
    
    def predict_only(self, model_name='game_outcome', week=1, season=2024):
        """
        Run only prediction generation step.
        
        Args:
            model_name: Model to use for predictions
            week: Week to predict
            season: Season to predict
            
        Returns:
            dict: Prediction results
        """
        self.logger.info("Running prediction generation only")
        return self.predictor.generate_predictions(model_name, week, season)
    
    def _parse_seasons(self, seasons_str):
        """
        Parse season string to list of integers.
        
        Args:
            seasons_str: Season string (e.g., '2020-2023' or '2020,2021,2022,2023')
            
        Returns:
            list: List of season integers
        """
        if isinstance(seasons_str, list):
            return seasons_str
        
        if '-' in seasons_str:
            start, end = seasons_str.split('-')
            return list(range(int(start), int(end) + 1))
        else:
            return [int(s.strip()) for s in seasons_str.split(',')]
    
    def validate_call_depth(self):
        """
        Development helper: Validate architecture constraints.
        
        Call depth check:
        User → run_ml_pipeline() [Layer 1]
             → MLPipelineImpl.process() [Layer 2]
             → Model/Database services [Layer 3]
        
        Returns:
            dict: Validation results
        """
        return {
            'max_depth': 3,
            'current_depth': 3,
            'within_limits': True,
            'pattern': 'Minimum Viable Decoupling',
            'complexity_points': 2,
            'traceable': True,
            'explanation': 'User → ML Pipeline → Infrastructure (3 layers)'
        }


# Convenience function for direct usage
def create_ml_pipeline(db_service=None, logger=None):
    """
    Create ML pipeline with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        MLPipelineImpl: Configured ML pipeline
    """
    from commonv2 import get_logger
    
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.ml_pipeline')
    
    return MLPipelineImpl(db_service, logger)
