"""
Feature Engineering Implementation for nflfastRv3

Migrates proven FeatureEngineer business logic from nflfastRv2 into clean architecture.
Following REFACTORING_SPECS.md: Maximum 5 complexity points, 3 layers depth.

Pattern: Minimum Viable Decoupling (2 complexity points)
Layer: 2 (Implementation - calls infrastructure directly)

Integrates with sophisticated V2 feature sets:
- TeamEfficiencyFeatures: EPA calculations, red zone metrics, rankings
- RollingMetricsFeatures: Time-series analysis, momentum indicators  
- OpponentAdjustedFeatures: Strength-of-schedule adjustments
"""

from typing import List, Dict, Any, Optional
import pandas as pd
from commonv2 import get_logger
from ...shared.database import NFLfastRDatabase
from .feature_sets import (
    create_team_efficiency_features,
    create_rolling_metrics_features, 
    create_opponent_adjusted_features
)


class FeatureEngineerImplementation:
    """
    Core feature engineering business logic.
    
    Pattern: Minimum Viable Decoupling (2 complexity points)
    Complexity: 2 points (DI + business logic)
    Depth: 1 layer (calls infrastructure directly)
    
    Migrated from nflfastRv2.FeatureEngineer with architectural simplification.
    """
    
    def __init__(self, db_service, logger):
        """
        Initialize with injected dependencies.
        
        Args:
            db_service: Database service (Layer 3)
            logger: Logger instance (Layer 3)
        """
        self.db_service = db_service
        self.logger = logger
        self.engine = db_service.engine
    
    def build_features(self, feature_sets=None, seasons=None):
        """
        Execute feature engineering workflow.
        
        Simple feature building flow (migrated from V2):
        1. Validate inputs (inline)
        2. Build features in dependency order (Layer 3 calls)
        3. Return summary
        
        Args:
            feature_sets: Feature sets to build ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
            seasons: Seasons to build features for
            
        Returns:
            dict: Feature building summary
        """
        feature_sets = feature_sets or ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
        seasons = seasons or [2020, 2021, 2022, 2023, 2024]
        
        self.logger.info(f"Starting feature engineering: sets={feature_sets}, seasons={seasons}")
        
        try:
            # Validate feature sets
            valid_sets = ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
            invalid_sets = [fs for fs in feature_sets if fs not in valid_sets]
            if invalid_sets:
                return {
                    'status': 'error',
                    'message': f"Invalid feature sets: {invalid_sets}. Valid: {valid_sets}",
                    'features_built': 0
                }
            
            # Build features in dependency order
            build_order = ['team_efficiency', 'rolling_metrics', 'opponent_adjusted']
            results = {}
            total_rows = 0
            
            for feature_set in build_order:
                if feature_set not in feature_sets:
                    continue
                
                self.logger.info(f"Building feature set: {feature_set}")
                
                try:
                    rows_built = self._build_feature_set(feature_set, seasons)
                    results[feature_set] = {
                        'status': 'success',
                        'rows_built': rows_built
                    }
                    total_rows += rows_built
                    self.logger.info(f"✓ {feature_set}: {rows_built:,} rows built")
                    
                except Exception as e:
                    self.logger.error(f"Failed to build {feature_set}: {e}")
                    results[feature_set] = {
                        'status': 'failed',
                        'error': str(e)
                    }
                    continue
            
            successful = sum(1 for r in results.values() if r['status'] == 'success')
            total = len(results)
            
            self.logger.info(f"Feature engineering complete: {successful}/{total} feature sets built")
            
            return {
                'status': 'success' if successful == total else 'partial',
                'features_built': successful,
                'total_features': total,
                'total_rows': total_rows,
                'results': results
            }
            
        except Exception as e:
            self.logger.error(f"Feature engineering failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': str(e),
                'features_built': 0,
                'total_rows': 0
            }
    
    def get_ml_features(self, train_seasons, test_seasons, include_raw_features=True):
        """
        Get ML-ready features for training/testing.
        
        Migrated from V2's sophisticated ml_features.py with V3 architecture constraints.
        
        Args:
            train_seasons: List of training seasons
            test_seasons: List of test seasons  
            include_raw_features: Whether to include raw home/away features
            
        Returns:
            Tuple of (X_train, X_test, y_train, y_test)
        """
        self.logger.info(f"Preparing ML features - Train: {train_seasons}, Test: {test_seasons}")
        
        try:
            # Load all required data (Layer 3 calls)
            all_seasons = train_seasons + test_seasons
            features_df = self._load_opponent_adjusted_features(all_seasons)
            results_df = self._load_game_results(all_seasons)
            
            if features_df.empty or results_df.empty:
                raise ValueError("Failed to load required feature data")
            
            # Create game-level dataset (V2 business logic)
            game_df = self._create_game_level_dataset(features_df, results_df)
            
            # Engineer differential features (V2 sophistication)
            game_df = self._engineer_differential_features(game_df)
            
            # Select model features (V2 feature selection)
            model_df = self._select_model_features(game_df, include_raw_features)
            
            # Create time-series aware train/test split
            X_train, X_test, y_train, y_test = self._create_train_test_split(
                model_df, train_seasons, test_seasons
            )
            
            self.logger.info(f"✓ ML features prepared: Train {len(X_train)} games, Test {len(X_test)} games")
            return X_train, X_test, y_train, y_test
            
        except Exception as e:
            self.logger.error(f"ML feature preparation failed: {e}", exc_info=True)
            # Return empty datasets rather than failing completely
            empty_df = pd.DataFrame()
            empty_series = pd.Series(dtype=int)
            return empty_df, empty_df, empty_series, empty_series
    
    def _load_opponent_adjusted_features(self, seasons):
        """
        Load opponent-adjusted features from database.
        
        Migrated from V2's load_opponent_adjusted_features() function.
        
        Args:
            seasons: List of seasons to load
            
        Returns:
            DataFrame: Opponent-adjusted features
        """
        from sqlalchemy import text
        
        self.logger.info(f"Loading opponent-adjusted features for seasons: {seasons}")
        
        season_clause = f"WHERE season IN ({','.join(map(str, seasons))})" if seasons else ""
        
        query = text(f"""
        SELECT 
            season, week, game_date, game_id, team, opponent,
            
            -- Rolling adjusted metrics (crown jewels from V2)
            offensive_epa_4game_adj, defensive_epa_4game_adj, epa_differential_4game_adj,
            offensive_epa_8game_adj, defensive_epa_8game_adj, epa_differential_8game_adj,
            
            -- Strength of schedule metrics
            sos_defensive_4game, sos_offensive_4game, sos_defensive_8game, sos_offensive_8game,
            
            -- Momentum indicators
            offensive_momentum_adj, defensive_momentum_adj, overall_momentum_adj,
            sos_trend_defensive, sos_trend_offensive,
            
            -- Rolling window counts (for data quality)
            rolling_window_4game_count, rolling_window_8game_count,
            
            -- Current game context
            offensive_epa_adj, defensive_epa_allowed_adj,
            opponent_defensive_strength, opponent_offensive_strength
            
        FROM features.team_opponent_adjusted_v1
        {season_clause}
        ORDER BY game_date, game_id, team
        """)
        
        try:
            with self.engine.connect() as conn:
                df = pd.read_sql(query, conn)
            
            if df.empty:
                self.logger.warning("No opponent-adjusted features found")
            else:
                self.logger.info(f"✓ Loaded {len(df)} team-game records")
            
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to load opponent-adjusted features: {e}")
            return pd.DataFrame()
    
    def _load_game_results(self, seasons):
        """
        Load game results for target variable creation.
        
        Migrated from V2's get_game_results() function.
        
        Args:
            seasons: List of seasons to load
            
        Returns:
            DataFrame: Game results with targets
        """
        from sqlalchemy import text
        
        self.logger.info("Loading game results for target variable creation")
        
        season_clause = f"WHERE season IN ({','.join(map(str, seasons))})" if seasons else ""
        
        query = text(f"""
        SELECT 
            game_id, season, week, game_date, home_team, away_team,
            result, total,
            CASE WHEN result > 0 THEN 1 ELSE 0 END as home_team_won,
            result as point_differential,
            total as total_points
        FROM analytics.dim_game
        {season_clause}
        AND result IS NOT NULL 
        AND total IS NOT NULL
        ORDER BY game_date, game_id
        """)
        
        try:
            with self.engine.connect() as conn:
                df = pd.read_sql(query, conn)
            
            self.logger.info(f"✓ Loaded {len(df)} game results")
            return df
            
        except Exception as e:
            self.logger.error(f"Failed to load game results: {e}")
            return pd.DataFrame()
    
    def _create_game_level_dataset(self, features_df, results_df):
        """
        Transform team-level features into game-level dataset.
        
        Migrated from V2's create_game_level_dataset() function.
        
        Args:
            features_df: Team-level features
            results_df: Game results
            
        Returns:
            DataFrame: Game-level dataset with home/away structure
        """

        self.logger.info("Creating game-level dataset from team-level features")
        
        # Separate home and away team features
        home_features = features_df.copy()
        away_features = features_df.copy()
        
        # Add home/away prefixes to feature columns
        feature_cols = [col for col in features_df.columns 
                       if col not in ['season', 'week', 'game_date', 'game_id', 'team', 'opponent']]
        
        home_feature_mapping = {col: f'home_{col}' for col in feature_cols}
        away_feature_mapping = {col: f'away_{col}' for col in feature_cols}
        
        home_features = home_features.rename(columns=home_feature_mapping)
        away_features = away_features.rename(columns=away_feature_mapping)
        
        # Drop metadata columns to prevent merge conflicts
        cols_to_drop = ['season', 'week', 'game_date', 'opponent']
        home_features = home_features.drop(columns=cols_to_drop, errors='ignore')
        away_features = away_features.drop(columns=cols_to_drop, errors='ignore')
        
        # Merge with game results
        home_games = results_df.merge(
            home_features, 
            left_on=['game_id', 'home_team'], 
            right_on=['game_id', 'team'],
            how='inner'
        ).drop(columns=['team'])
        
        away_games = results_df.merge(
            away_features,
            left_on=['game_id', 'away_team'],
            right_on=['game_id', 'team'], 
            how='inner'
        ).drop(columns=['team'])
        
        # Combine home and away features
        merge_cols = ['game_id', 'season', 'week', 'game_date', 'home_team', 'away_team', 
                      'result', 'total', 'home_team_won', 'point_differential', 'total_points']
        
        game_level = home_games.merge(away_games, on=merge_cols, how='inner')
        
        self.logger.info(f"✓ Created game-level dataset: {len(game_level)} games")
        return game_level
    
    def _engineer_differential_features(self, df):
        """
        Engineer differential features (home - away).
        
        Migrated from V2's engineer_differential_features() function.
        
        Args:
            df: Game-level dataset
            
        Returns:
            DataFrame: Dataset with differential features
        """

        self.logger.info("Engineering differential features")
        
        # Base features for differentials (V2's sophisticated feature set)
        base_features = [
            'offensive_epa_4game_adj', 'defensive_epa_4game_adj', 'epa_differential_4game_adj',
            'offensive_epa_8game_adj', 'defensive_epa_8game_adj', 'epa_differential_8game_adj',
            'sos_defensive_4game', 'sos_offensive_4game', 'sos_defensive_8game', 'sos_offensive_8game',
            'offensive_momentum_adj', 'defensive_momentum_adj', 'overall_momentum_adj',
            'sos_trend_defensive', 'sos_trend_offensive'
        ]
        
        # Create differential features (V2 business logic)
        for feature in base_features:
            home_col = f'home_{feature}'
            away_col = f'away_{feature}'
            diff_col = f'{feature}_diff'
            
            if home_col in df.columns and away_col in df.columns:
                df[diff_col] = df[home_col] - df[away_col]
        
        # Advanced composite features (V2 sophistication)
        df['epa_advantage_4game'] = (df['home_offensive_epa_4game_adj'] - df['home_defensive_epa_4game_adj']) - \
                                   (df['away_offensive_epa_4game_adj'] - df['away_defensive_epa_4game_adj'])
        
        df['sos_advantage_4game'] = (df['home_sos_defensive_4game'] + df['home_sos_offensive_4game']) - \
                                   (df['away_sos_defensive_4game'] + df['away_sos_offensive_4game'])
        
        df['momentum_advantage'] = df['home_overall_momentum_adj'] - df['away_overall_momentum_adj']
        
        self.logger.info("✓ Engineered differential features")
        return df
    
    def _select_model_features(self, df, include_raw_features=True):
        """
        Select features for ML model training.
        
        Migrated from V2's select_model_features() function.
        
        Args:
            df: Game-level dataset
            include_raw_features: Include raw home/away features
            
        Returns:
            DataFrame: Selected features for modeling
        """

        self.logger.info("Selecting features for ML model")
        
        # Core differential features (most predictive from V2)
        differential_features = [
            'offensive_epa_4game_adj_diff', 'defensive_epa_4game_adj_diff', 'epa_differential_4game_adj_diff',
            'offensive_epa_8game_adj_diff', 'defensive_epa_8game_adj_diff', 'epa_differential_8game_adj_diff',
            'sos_defensive_4game_diff', 'sos_offensive_4game_diff', 'sos_defensive_8game_diff', 'sos_offensive_8game_diff',
            'offensive_momentum_adj_diff', 'defensive_momentum_adj_diff', 'overall_momentum_adj_diff',
            'sos_trend_defensive_diff', 'sos_trend_offensive_diff',
            'epa_advantage_4game', 'sos_advantage_4game', 'momentum_advantage'
        ]
        
        # Optional raw features
        raw_features = []
        if include_raw_features:
            base_features = [
                'offensive_epa_4game_adj', 'defensive_epa_4game_adj', 'epa_differential_4game_adj',
                'sos_defensive_4game', 'sos_offensive_4game', 'overall_momentum_adj'
            ]
            
            for feature in base_features:
                raw_features.extend([f'home_{feature}', f'away_{feature}'])
        
        # Combine feature sets
        selected_features = differential_features + raw_features
        available_features = [col for col in selected_features if col in df.columns]
        
        # Add metadata and target columns
        metadata_cols = ['game_id', 'season', 'week', 'game_date', 'home_team', 'away_team']
        target_cols = ['home_team_won', 'point_differential', 'total_points']
        
        final_columns = metadata_cols + available_features + target_cols
        result_df = df[final_columns].copy()
        
        # Filter for sufficient historical data (V2 quality control)
        min_games_filter = (
            (df['home_rolling_window_4game_count'] >= 3) & 
            (df['away_rolling_window_4game_count'] >= 3)
        )
        result_df = result_df[min_games_filter].copy()
        
        self.logger.info(f"✓ Selected {len(available_features)} features for {len(result_df)} games")
        return result_df
    
    def _create_train_test_split(self, model_df, train_seasons, test_seasons):
        """
        Create time-series aware train/test split.
        
        Migrated from V2's prepare_training_data() logic.
        
        Args:
            model_df: Model-ready dataset
            train_seasons: Training seasons
            test_seasons: Test seasons
            
        Returns:
            Tuple: (X_train, X_test, y_train, y_test)
        """

        # Create time-series split
        train_mask = model_df['season'].isin(train_seasons)
        test_mask = model_df['season'].isin(test_seasons)
        
        train_df = model_df[train_mask].copy()
        test_df = model_df[test_mask].copy()
        
        # Separate features and targets
        feature_cols = [col for col in model_df.columns 
                       if col not in ['game_id', 'season', 'week', 'game_date', 'home_team', 'away_team',
                                     'home_team_won', 'point_differential', 'total_points']]
        
        X_train = train_df[feature_cols].fillna(0)
        X_test = test_df[feature_cols].fillna(0)
        y_train = train_df['home_team_won']
        y_test = test_df['home_team_won']
        
        self.logger.info(f"✓ Train/test split: {len(X_train)} train, {len(X_test)} test games")
        return X_train, X_test, y_train, y_test
    
    def validate_feature_data(self, feature_set_name):
        """
        Validate that a feature set has been built and contains data.
        
        Args:
            feature_set_name: Name of the feature set to validate
            
        Returns:
            bool: True if feature set is valid
        """
        valid_sets = {
            'team_efficiency': 'features.team_efficiency_v1',
            'rolling_metrics': 'features.rolling_metrics_v1', 
            'opponent_adjusted': 'features.team_opponent_adjusted_v1'
        }
        
        if feature_set_name not in valid_sets:
            self.logger.error(f"Unknown feature set: {feature_set_name}")
            return False
        
        table_name = valid_sets[feature_set_name]
        
        try:
            # Layer 3 call - direct database query
            query = f"SELECT COUNT(*) as count FROM {table_name}"
            with self.engine.connect() as conn:
                result = conn.execute(query).fetchone()
                row_count = result[0] if result else 0
            
            if row_count == 0:
                self.logger.warning(f"Feature set {feature_set_name} has no data")
                return False
            
            self.logger.info(f"✓ Feature set {feature_set_name} validated: {row_count:,} rows")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to validate {feature_set_name}: {e}")
            return False
    
    def _build_feature_set(self, feature_set_name, seasons):
        """
        Build a specific feature set using real V2 sophistication.
        
        Args:
            feature_set_name: Name of feature set to build
            seasons: Seasons to build for
            
        Returns:
            int: Number of rows built
        """
        # Route to sophisticated V2 implementations
        if feature_set_name == 'team_efficiency':
            return self._build_team_efficiency(seasons)
        elif feature_set_name == 'rolling_metrics':
            return self._build_rolling_metrics(seasons)
        elif feature_set_name == 'opponent_adjusted':
            return self._build_opponent_adjusted(seasons)
        else:
            raise ValueError(f"Unknown feature set: {feature_set_name}")
    
    def _build_team_efficiency(self, seasons):
        """
        Build team efficiency features using V2's sophisticated implementation.
        
        Args:
            seasons: Seasons to build for
            
        Returns:
            int: Number of rows built
        """
        self.logger.info("Building team efficiency features with V2 sophistication")
        
        # Use the sophisticated TeamEfficiencyFeatures implementation
        team_efficiency_service = create_team_efficiency_features(self.db_service, self.logger)
        result = team_efficiency_service.build_features(seasons=seasons, save_to_db=True)
        
        if result['status'] != 'success':
            raise RuntimeError(f"Team efficiency build failed: {result.get('message', 'Unknown error')}")
        
        rows_built = result['features_built']
        self.logger.info(f"✓ Team efficiency features built: {rows_built} team-seasons")
        
        return rows_built
    
    def _build_rolling_metrics(self, seasons):
        """
        Build rolling metrics features using V2's sophisticated implementation.
        
        Args:
            seasons: Seasons to build for
            
        Returns:
            int: Number of rows built
        """
        self.logger.info("Building rolling metrics features with V2 sophistication")
        
        # Use the sophisticated RollingMetricsFeatures implementation
        rolling_metrics_service = create_rolling_metrics_features(self.db_service, self.logger)
        result = rolling_metrics_service.build_features(seasons=seasons, save_to_db=True)
        
        if result['status'] != 'success':
            raise RuntimeError(f"Rolling metrics build failed: {result.get('message', 'Unknown error')}")
        
        rows_built = result['features_built']
        self.logger.info(f"✓ Rolling metrics features built: {rows_built} team-games")
        
        return rows_built
    
    def _build_opponent_adjusted(self, seasons):
        """
        Build opponent-adjusted features using V2's sophisticated implementation.
        
        Args:
            seasons: Seasons to build for
            
        Returns:
            int: Number of rows built
        """
        self.logger.info("Building opponent-adjusted features with V2 sophistication")
        
        # Use the sophisticated OpponentAdjustedFeatures implementation
        opponent_adjusted_service = create_opponent_adjusted_features(self.db_service, self.logger)
        result = opponent_adjusted_service.build_features(seasons=seasons, save_to_db=True)
        
        if result['status'] != 'success':
            raise RuntimeError(f"Opponent-adjusted build failed: {result.get('message', 'Unknown error')}")
        
        rows_built = result['features_built']
        self.logger.info(f"✓ Opponent-adjusted features built: {rows_built} team-seasons")
        
        return rows_built


def create_feature_engineer(db_service=None, logger=None):
    """
    Create feature engineer with default dependencies.
    
    Args:
        db_service: Optional database service override
        logger: Optional logger override
        
    Returns:
        FeatureEngineerImplementation: Configured feature engineer
    """
    db_service = db_service or NFLfastRDatabase.get_instance()
    logger = logger or get_logger('nflfastRv3.feature_engineer')
    
    return FeatureEngineerImplementation(db_service, logger)


__all__ = ['FeatureEngineerImplementation', 'create_feature_engineer']
