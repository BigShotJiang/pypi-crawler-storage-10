#!/usr/bin/env python3
"""
Performance benchmark and testing validation for nflfastRv3.

This script validates the implementation progress and runs performance benchmarks
to ensure architectural compliance and functional completeness.
"""

import time
import sys
import os
from datetime import datetime
from typing import Dict, Any, List, Optional
import pandas as pd

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Module-level logger following REFACTORING_SPECS.md pattern
from commonv2 import get_logger
_logger = get_logger('nflfastRv3.performance_benchmark')

def validate_architecture_compliance(logger=None) -> Dict[str, bool]:
    """
    Validate architecture compliance according to REFACTORING_SPECS.md.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        Dict[str, bool]: Compliance results for each requirement
    """
    logger = logger or _logger  # DI with sensible fallback
    compliance = {}
    
    # Test 1: Maximum 3-layer depth
    logger.info("Testing 3-layer depth compliance...")
    test_modules = [
        'nflfastRv3.shared.models',
        'nflfastRv3.shared.r_integration',
        'nflfastRv3.features.data_pipeline.implementation',
        'nflfastRv3.features.ml_pipeline.real_feature_builder',
        'nflfastRv3.features.analytics_suite.main',
    ]
    
    layer_depth_compliant = True
    for module_path in test_modules:
        layers = len(module_path.split('.')) - 1  # Subtract 1 for root
        if layers > 3:
            logger.error(f"  ❌ {module_path} exceeds 3-layer depth: {layers} layers")
            layer_depth_compliant = False
        else:
            logger.info(f"  ✅ {module_path}: {layers} layers")
    
    compliance['3_layer_depth'] = layer_depth_compliant
    
    # Test 2: Dependency injection pattern
    logger.info("\nTesting dependency injection pattern...")
    try:
        from nflfastRv3.features.data_pipeline.implementation import DataPipeline
        from nflfastRv3.features.analytics_suite.main import AnalyticsImpl
        
        # Mock dependencies
        from unittest.mock import Mock
        mock_db = Mock()
        
        # Test DI acceptance
        from commonv2 import get_logger
        test_logger = get_logger('test')
        pipeline = DataPipeline(db_service=mock_db, logger=test_logger)
        analytics = AnalyticsImpl(db_service=mock_db, logger=test_logger)
        
        logger.info("  ✅ Dependency injection pattern working")
        compliance['dependency_injection'] = True
        
    except Exception as e:
        logger.error(f"  ❌ Dependency injection test failed: {e}")
        compliance['dependency_injection'] = False
    
    # Test 3: Complexity budget tracking
    logger.info("\nTesting complexity budget tracking...")
    complexity_compliant = True
    try:
        import nflfastRv3.shared.models as models
        import nflfastRv3.shared.r_integration as r_integration
        
        # Complexity tracker classes have been removed - complexity is now tracked via inline comments
        # This provides better maintainability without empty classes
        logger.info("  ✅ Complexity tracking via inline comments (tracker classes removed)")
        compliance['complexity_tracking'] = True  # Always true since we use comment-based tracking
        
    except Exception as e:
        logger.error(f"  ❌ Complexity tracking test failed: {e}")
        compliance['complexity_tracking'] = False
    
    # Test 4: "Can I Trace This?" compliance
    logger.info("\nTesting 'Can I Trace This?' compliance...")
    try:
        from nflfastRv3.features.data_pipeline.implementation import DataPipeline
        from unittest.mock import Mock
        from commonv2 import get_logger
        
        mock_db = Mock()
        test_logger = get_logger('test')
        pipeline = DataPipeline(db_service=mock_db, logger=test_logger)
        
        # Check for clear method names
        has_clear_methods = (
            hasattr(pipeline, '_fetch_data') or 
            hasattr(pipeline, 'load_data') or
            hasattr(pipeline, 'process_data')
        )
        
        if has_clear_methods:
            logger.info("  ✅ Clear method names for traceability")
            compliance['traceability'] = True
        else:
            logger.error("  ❌ Method names not clearly traceable")
            compliance['traceability'] = False
            
    except Exception as e:
        logger.error(f"  ❌ Traceability test failed: {e}")
        compliance['traceability'] = False
    
    return compliance


def validate_shared_models(logger=None) -> bool:
    """
    Validate shared models are working correctly.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        bool: Whether shared models are functional
    """
    logger = logger or _logger  # DI with sensible fallback
    logger.info("Testing shared models...")
    try:
        from nflfastRv3.shared.models import (
            GameSchedule, FeatureVector, MLPrediction, 
            ValidationResult, AnalyticsResult, PredictionOutcome
        )

        # Test GameSchedule
        schedule = GameSchedule(
            game_id="2023_01_BUF_MIA",
            home_team="MIA",
            away_team="BUF",
            game_date=datetime(2023, 9, 10, 13, 0),
            week=1,
            season=2023
        )
        logger.info("  ✅ GameSchedule creation successful")
        
        # Test FeatureVector
        features = {
            'team_efficiency': 0.65,
            'recent_form': 0.72
        }
        feature_names = list(features.keys())
        
        vector = FeatureVector(
            game_id="2023_01_BUF_MIA",
            features=features,
            feature_names=feature_names,
            created_at=datetime.now()
        )
        logger.info("  ✅ FeatureVector creation successful")
        
        # Test MLPrediction
        prediction = MLPrediction(
            game_id="2023_01_BUF_MIA",
            home_team="MIA",
            away_team="BUF",
            predicted_outcome=PredictionOutcome.AWAY_WIN,
            confidence=0.68,
            feature_importance={'team_efficiency': 0.6, 'recent_form': 0.4},
            model_version="test_v1.0"
        )
        logger.info("  ✅ MLPrediction creation successful")
        
        # Test ValidationResult
        validation = ValidationResult(is_valid=True, record_count=100)
        validation.add_warning("Test warning")
        logger.info("  ✅ ValidationResult working correctly")
        
        return True
        
    except Exception as e:
        logger.error(f"  ❌ Shared models test failed: {e}")
        return False


def validate_r_integration(logger=None) -> bool:
    """
    Validate R integration service is available.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        bool: Whether R integration is functional
    """
    logger = logger or _logger  # DI with sensible fallback
    logger.info("Testing R integration...")
    try:
        from nflfastRv3.shared.r_integration import RIntegrationService, get_r_service
        
        # Test singleton pattern
        service1 = RIntegrationService.get_instance()
        service2 = get_r_service()
        
        logger.info(f"  ✅ R integration service available: r_available={service1.r_available}")
        logger.info(f"  ✅ Singleton pattern working: {service1 is service2}")
        
        return True
        
    except Exception as e:
        logger.error(f"  ❌ R integration test failed: {e}")
        return False


def run_performance_benchmarks(logger=None) -> Dict[str, float]:
    """
    Run performance benchmarks for key operations.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        Dict[str, float]: Performance results in seconds
    """
    logger = logger or _logger  # DI with sensible fallback
    logger.info("Running performance benchmarks...")
    
    benchmarks = {}
    
    # Benchmark 1: Model creation performance
    logger.info("  Testing model creation performance...")
    try:
        from nflfastRv3.shared.models import GameSchedule, FeatureVector
        
        start = time.time()
        for i in range(1000):
            schedule = GameSchedule(
                game_id=f"2023_01_BUF_MIA_{i}",
                home_team="MIA",
                away_team="BUF",
                game_date=datetime(2023, 9, 10, 13, 0),
                week=1,
                season=2023
            )
        end = time.time()
        
        model_creation_time = end - start
        benchmarks['model_creation_1000'] = model_creation_time
        logger.info(f"    1000 GameSchedule creations: {model_creation_time:.3f}s")
        
    except Exception as e:
        logger.error(f"    ❌ Model creation benchmark failed: {e}")
        benchmarks['model_creation_1000'] = float('inf')
    
    # Benchmark 2: Feature vector operations
    logger.info("  Testing feature vector performance...")
    try:
        from nflfastRv3.shared.models import FeatureVector
        
        # Create feature vector with many features
        features = {f'feature_{i}': float(i) for i in range(100)}
        feature_names = list(features.keys())
        
        start = time.time()
        for i in range(100):
            vector = FeatureVector(
                game_id=f"2023_01_BUF_MIA_{i}",
                features=features,
                feature_names=feature_names,
                created_at=datetime.now()
            )
            # Test feature array conversion
            array = vector.get_feature_array()
        end = time.time()
        
        feature_vector_time = end - start
        benchmarks['feature_vector_100'] = feature_vector_time
        logger.info(f"    100 FeatureVector ops (100 features each): {feature_vector_time:.3f}s")
        
    except Exception as e:
        logger.error(f"    ❌ Feature vector benchmark failed: {e}")
        benchmarks['feature_vector_100'] = float('inf')
    
    # Benchmark 3: R service initialization
    logger.info("  Testing R service performance...")
    try:
        from nflfastRv3.shared.r_integration import RIntegrationService
        
        start = time.time()
        for i in range(100):
            service = RIntegrationService.get_instance()
        end = time.time()
        
        r_service_time = end - start
        benchmarks['r_service_singleton_100'] = r_service_time
        logger.info(f"    100 R service singleton calls: {r_service_time:.3f}s")
        
    except Exception as e:
        logger.error(f"    ❌ R service benchmark failed: {e}")
        benchmarks['r_service_singleton_100'] = float('inf')
    
    return benchmarks


def validate_implementation_completeness(logger=None) -> Dict[str, bool]:
    """
    Validate implementation completeness across all modules.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        Dict[str, bool]: Completeness status for each component
    """
    logger = logger or _logger  # DI with sensible fallback
    logger.info("Validating implementation completeness...")
    
    completeness = {}
    
    # Test shared layer
    logger.info("  Checking shared layer...")
    try:
        import nflfastRv3.shared.models
        import nflfastRv3.shared.r_integration
        import nflfastRv3.shared.database
        logger.info("    ✅ Shared layer modules available")
        completeness['shared_layer'] = True
    except Exception as e:
        logger.error(f"    ❌ Shared layer incomplete: {e}")
        completeness['shared_layer'] = False
    
    # Test data pipeline
    logger.info("  Checking data pipeline...")
    try:
        import nflfastRv3.features.data_pipeline.implementation
        import nflfastRv3.features.data_pipeline.schedule_integration
        logger.info("    ✅ Data pipeline modules available")
        completeness['data_pipeline'] = True
    except Exception as e:
        logger.error(f"    ❌ Data pipeline incomplete: {e}")
        completeness['data_pipeline'] = False
    
    # Test ML pipeline
    logger.info("  Checking ML pipeline...")
    try:
        import nflfastRv3.features.ml_pipeline.real_feature_builder
        import nflfastRv3.features.ml_pipeline.model_trainer
        import nflfastRv3.features.ml_pipeline.predictor
        logger.info("    ✅ ML pipeline modules available")
        completeness['ml_pipeline'] = True
    except Exception as e:
        logger.error(f"    ❌ ML pipeline incomplete: {e}")
        completeness['ml_pipeline'] = False
    
    # Test analytics suite
    logger.info("  Checking analytics suite...")
    try:
        import nflfastRv3.features.analytics_suite.main
        logger.info("    ✅ Analytics suite modules available")
        completeness['analytics_suite'] = True
    except Exception as e:
        logger.error(f"    ❌ Analytics suite incomplete: {e}")
        completeness['analytics_suite'] = False
    
    # Test CLI
    logger.info("  Checking CLI...")
    try:
        import nflfastRv3.cli.main
        import nflfastRv3.cli.data_commands
        logger.info("    ✅ CLI modules available")
        completeness['cli'] = True
    except Exception as e:
        logger.error(f"    ❌ CLI incomplete: {e}")
        completeness['cli'] = False
    
    return completeness


def run_test_suite(logger=None) -> Dict[str, bool]:
    """
    Run the basic test suite to validate functionality.
    
    Args:
        logger: Optional logger instance (uses module logger as fallback)
    
    Returns:
        Dict[str, bool]: Test results
    """
    logger = logger or _logger  # DI with sensible fallback
    logger.info("Running basic test suite...")
    
    test_results = {}
    
    # Test 1: Import all key modules
    logger.info("  Testing module imports...")
    try:
        from nflfastRv3.shared.models import GameSchedule
        from nflfastRv3.shared.r_integration import get_r_service
        test_results['imports'] = True
        logger.info("    ✅ Key module imports successful")
    except Exception as e:
        test_results['imports'] = False
        logger.error(f"    ❌ Import test failed: {e}")
    
    # Test 2: Basic model operations
    logger.info("  Testing basic model operations...")
    try:
        from nflfastRv3.shared.models import GameSchedule, FeatureVector, PredictionOutcome
        
        # Create and validate models
        schedule = GameSchedule(
            game_id="test_game",
            home_team="MIA",
            away_team="BUF", 
            game_date=datetime.now(),
            week=1,
            season=2023
        )
        
        features = FeatureVector(
            game_id="test_game",
            features={'test': 1.0},
            feature_names=['test'],
            created_at=datetime.now()
        )
        
        assert schedule.game_id == "test_game"
        assert features.feature_count == 1
        
        test_results['basic_models'] = True
        logger.info("    ✅ Basic model operations successful")
        
    except Exception as e:
        test_results['basic_models'] = False
        logger.error(f"    ❌ Basic model test failed: {e}")
    
    # Test 3: Architecture patterns
    logger.info("  Testing architecture patterns...")
    try:
        # Test singleton pattern
        from nflfastRv3.shared.r_integration import get_r_service
        service1 = get_r_service()
        service2 = get_r_service()
        assert service1 is service2
        
        test_results['architecture_patterns'] = True
        logger.info("    ✅ Architecture patterns working")
        
    except Exception as e:
        test_results['architecture_patterns'] = False
        logger.error(f"    ❌ Architecture pattern test failed: {e}")
    
    return test_results


def generate_report(compliance: Dict[str, bool], 
                   completeness: Dict[str, bool],
                   test_results: Dict[str, bool],
                   benchmarks: Dict[str, float]) -> str:
    """
    Generate comprehensive implementation report.
    
    Args:
        compliance: Architecture compliance results
        completeness: Implementation completeness results
        test_results: Test suite results
        benchmarks: Performance benchmark results
        
    Returns:
        str: Formatted report
    """
    report = f"""
# nflfastRv3 Implementation Validation Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Architecture Compliance
"""
    
    for check, result in compliance.items():
        status = "✅ PASS" if result else "❌ FAIL"
        report += f"- {check.replace('_', ' ').title()}: {status}\n"
    
    compliance_score = sum(compliance.values()) / len(compliance) * 100
    report += f"\n**Compliance Score: {compliance_score:.1f}%**\n"
    
    report += "\n## Implementation Completeness\n"
    
    for component, result in completeness.items():
        status = "✅ COMPLETE" if result else "❌ INCOMPLETE"
        report += f"- {component.replace('_', ' ').title()}: {status}\n"
    
    completeness_score = sum(completeness.values()) / len(completeness) * 100
    report += f"\n**Completeness Score: {completeness_score:.1f}%**\n"
    
    report += "\n## Test Results\n"
    
    for test, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        report += f"- {test.replace('_', ' ').title()}: {status}\n"
    
    test_score = sum(test_results.values()) / len(test_results) * 100
    report += f"\n**Test Score: {test_score:.1f}%**\n"
    
    report += "\n## Performance Benchmarks\n"
    
    for benchmark, time_taken in benchmarks.items():
        if time_taken != float('inf'):
            status = "✅ GOOD" if time_taken < 1.0 else "⚠️ SLOW"
            report += f"- {benchmark.replace('_', ' ').title()}: {time_taken:.3f}s {status}\n"
        else:
            report += f"- {benchmark.replace('_', ' ').title()}: ❌ FAILED\n"
    
    overall_score = (compliance_score + completeness_score + test_score) / 3
    report += f"\n## Overall Implementation Score: {overall_score:.1f}%\n"
    
    if overall_score >= 90:
        report += "\n🎉 **EXCELLENT**: Implementation is production-ready!\n"
    elif overall_score >= 75:
        report += "\n✅ **GOOD**: Implementation is largely complete with minor issues.\n"
    elif overall_score >= 50:
        report += "\n⚠️ **FAIR**: Implementation has significant gaps that need addressing.\n"
    else:
        report += "\n❌ **POOR**: Implementation requires major work before production use.\n"
    
    return report


def main(logger=None):
    """Main execution function."""
    logger = logger or _logger  # DI with sensible fallback
    logger.info("=" * 60)
    logger.info("nflfastRv3 Implementation Validation & Performance Benchmark")
    logger.info("=" * 60)
    
    # Run all validations
    compliance = validate_architecture_compliance(logger)
    logger.info("")
    
    models_ok = validate_shared_models(logger)
    logger.info("")
    
    r_integration_ok = validate_r_integration(logger)
    logger.info("")
    
    completeness = validate_implementation_completeness(logger)
    logger.info("")
    
    test_results = run_test_suite(logger)
    logger.info("")
    
    benchmarks = run_performance_benchmarks(logger)
    logger.info("")
    
    # Generate and display report
    report = generate_report(compliance, completeness, test_results, benchmarks)
    logger.info(report)
    
    # Save report to session output directory (organized with logs)
    try:
        from commonv2.core.logging import get_session_output_dir
        output_dir = get_session_output_dir()
        report_file = output_dir / f"nflfastRv3_validation_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
    except ImportError:
        # Fallback for backward compatibility
        report_file = f"nflfastRv3_validation_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
    
    with open(report_file, 'w') as f:
        f.write(report)
    
    logger.info(f"\nReport saved to: {report_file}")
    
    # Return success/failure based on overall score
    overall_score = (
        sum(compliance.values()) / len(compliance) +
        sum(completeness.values()) / len(completeness) +
        sum(test_results.values()) / len(test_results)
    ) / 3 * 100
    
    return 0 if overall_score >= 75 else 1


if __name__ == "__main__":
    sys.exit(main())
