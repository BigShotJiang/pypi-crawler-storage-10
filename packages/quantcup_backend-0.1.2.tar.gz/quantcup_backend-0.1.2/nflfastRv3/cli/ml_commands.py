"""
ML Pipeline CLI Commands

Command-line interface for machine learning operations.

Pattern: Simple command handlers
Complexity: 1 point (basic command routing)
Layer: 1 (Public interface)
"""

import argparse
from typing import Any

from commonv2 import get_logger

# Module-level logger following proper singleton pattern
_logger = get_logger('nflfastRv3.cli.ml')


class MLCommands:
    """ML pipeline command handlers."""
    
    @staticmethod
    def setup_parser(parser: argparse.ArgumentParser) -> None:
        """Setup ML command arguments."""
        subparsers = parser.add_subparsers(dest='ml_command', help='ML operations')
        
        # Feature engineering command
        features_parser = subparsers.add_parser(
            'features',
            help='Engineer features for ML'
        )
        features_parser.add_argument(
            '--season',
            type=int,
            default=2024,
            help='Season to engineer features for'
        )
        features_parser.add_argument(
            '--output-format',
            choices=['console', 'json', 'file'],
            default='console',
            help='Output format'
        )
        
        # Model training command
        train_parser = subparsers.add_parser(
            'train',
            help='Train ML model'
        )
        train_parser.add_argument(
            '--model',
            choices=['xgboost', 'random_forest', 'logistic'],
            default='xgboost',
            help='Model type to train'
        )
        train_parser.add_argument(
            '--season',
            type=int,
            default=2024,
            help='Season to train on'
        )
        train_parser.add_argument(
            '--save-model',
            action='store_true',
            help='Save trained model'
        )
        
        # Prediction command
        predict_parser = subparsers.add_parser(
            'predict',
            help='Generate predictions'
        )
        predict_parser.add_argument(
            '--model-path',
            help='Path to trained model'
        )
        predict_parser.add_argument(
            '--games',
            help='Games to predict (comma-separated game IDs)'
        )
        predict_parser.add_argument(
            '--output-format',
            choices=['console', 'json', 'file'],
            default='console',
            help='Output format'
        )
    
    @staticmethod
    def handle(args: Any, logger=None) -> int:
        """Handle ML commands."""
        logger = logger or _logger
        
        if args.ml_command == 'features':
            return MLCommands._handle_features(args, logger)
        elif args.ml_command == 'train':
            return MLCommands._handle_train(args, logger)
        elif args.ml_command == 'predict':
            return MLCommands._handle_predict(args, logger)
        else:
            logger.error("No ML command specified. Use --help for options.")
            return 1
    
    @staticmethod
    def _handle_features(args: Any, logger=None) -> int:
        """Handle feature engineering command."""
        logger = logger or _logger
        
        logger.info(f"🔧 Engineering features for {args.season} season...")
        
        try:
            from ..features.ml_pipeline import MLPipelineImpl
            from ..shared.database import NFLfastRDatabase
            
            # Create ML pipeline and run feature engineering
            db_service = NFLfastRDatabase.get_instance()
            ml_pipeline = MLPipelineImpl(db_service, logger)
            
            result = ml_pipeline.build_features_only(
                seasons=[args.season]
            )
            
            if result.get('status') == 'success':
                logger.info("✅ Feature engineering complete")
                features_created = result.get('features_created', 0)
                logger.info(f"Features created: {features_created}")
            else:
                logger.error(f"❌ Feature engineering failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Feature engineering failed: {e}")
            return 1
    
    @staticmethod
    def _handle_train(args: Any, logger=None) -> int:
        """Handle model training command."""
        logger = logger or _logger
        
        logger.info(f"🤖 Training {args.model} model for {args.season} season...")
        
        try:
            from ..features.ml_pipeline import MLPipelineImpl
            from ..shared.database import NFLfastRDatabase
            
            # Create ML pipeline and run model training
            db_service = NFLfastRDatabase.get_instance()
            ml_pipeline = MLPipelineImpl(db_service, logger)
            
            result = ml_pipeline.train_model_only(
                train_seasons=str(args.season)
            )
            
            if result.get('status') == 'success':
                logger.info("✅ Model training complete")
                accuracy = result.get('accuracy', 0)
                logger.info(f"Model accuracy: {accuracy:.3f}")
                
                if args.save_model:
                    model_path = result.get('model_path', 'model.pkl')
                    logger.info(f"Model saved to: {model_path}")
            else:
                logger.error(f"❌ Model training failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Model training failed: {e}")
            return 1
    
    @staticmethod
    def _handle_predict(args: Any, logger=None) -> int:
        """Handle prediction command."""
        logger = logger or _logger
        
        logger.info("🔮 Generating predictions...")
        
        try:
            from ..features.ml_pipeline import MLPipelineImpl
            from ..shared.database import NFLfastRDatabase
            
            # Create ML pipeline and run predictions
            db_service = NFLfastRDatabase.get_instance()
            ml_pipeline = MLPipelineImpl(db_service, logger)
            
            # Parse games if provided
            game_ids = []
            if args.games:
                game_ids = [g.strip() for g in args.games.split(',')]
            
            # Use current week and season if not specified
            import datetime as dt
            current_date = dt.datetime.now()
            current_season = current_date.year
            current_week = min(18, max(1, current_date.isocalendar()[1] - 35))
            
            result = ml_pipeline.predict_only(
                model_name=args.model_path or 'game_outcome',
                week=current_week,
                season=current_season
            )
            
            if result.get('status') == 'success':
                logger.info("✅ Predictions generated")
                predictions_count = result.get('predictions_count', 0)
                logger.info(f"Predictions made: {predictions_count}")
                
                # Show sample predictions
                predictions = result.get('predictions', [])
                if predictions:
                    logger.info("Sample predictions:")
                    for i, pred in enumerate(predictions[:3]):
                        game_id = pred.get('game_id', f'Game {i+1}')
                        probability = pred.get('probability', 0)
                        logger.info(f"  {game_id}: {probability:.3f}")
            else:
                logger.error(f"❌ Prediction failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Prediction failed: {e}")
            return 1
