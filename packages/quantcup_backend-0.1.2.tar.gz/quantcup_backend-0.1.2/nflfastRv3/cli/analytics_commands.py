"""
Analytics CLI Commands

Command-line interface for analytics operations.

Pattern: Simple command handlers
Complexity: 1 point (basic command routing)
Layer: 1 (Public interface)
"""

import argparse
from typing import Any

from commonv2 import get_logger

# Module-level logger following proper singleton pattern
_logger = get_logger('nflfastRv3.cli.analytics')


class AnalyticsCommands:
    """Analytics command handlers."""
    
    @staticmethod
    def setup_parser(parser: argparse.ArgumentParser) -> None:
        """Setup analytics command arguments."""
        subparsers = parser.add_subparsers(dest='analytics_command', help='Analytics operations')
        
        # Exploratory analysis command
        exploratory_parser = subparsers.add_parser(
            'exploratory',
            help='Run exploratory data analysis'
        )
        exploratory_parser.add_argument(
            '--season',
            type=int,
            help='Season to analyze (optional)'
        )
        exploratory_parser.add_argument(
            '--output-format',
            choices=['console', 'json', 'file'],
            default='console',
            help='Output format'
        )
        
        # Feature analysis command
        feature_parser = subparsers.add_parser(
            'feature-analysis',
            help='Run feature analysis'
        )
        feature_parser.add_argument(
            '--output-format',
            choices=['console', 'json', 'file'],
            default='console',
            help='Output format'
        )
        feature_parser.add_argument(
            '--correlation-threshold',
            type=float,
            default=0.8,
            help='Correlation threshold for multicollinearity detection'
        )
        
        # Team performance command
        team_parser = subparsers.add_parser(
            'team-performance',
            help='Analyze team performance'
        )
        team_parser.add_argument(
            '--season',
            type=int,
            default=2024,
            help='Season to analyze'
        )
        team_parser.add_argument(
            '--team',
            help='Specific team to analyze (optional)'
        )
        team_parser.add_argument(
            '--output-format',
            choices=['console', 'json', 'file'],
            default='console',
            help='Output format'
        )
    
    @staticmethod
    def handle(args: Any, logger=None) -> int:
        """Handle analytics commands."""
        logger = logger or _logger
        
        if args.analytics_command == 'exploratory':
            return AnalyticsCommands._handle_exploratory(args, logger)
        elif args.analytics_command == 'feature-analysis':
            return AnalyticsCommands._handle_feature_analysis(args, logger)
        elif args.analytics_command == 'team-performance':
            return AnalyticsCommands._handle_team_performance(args, logger)
        else:
            logger.error("No analytics command specified. Use --help for options.")
            return 1
    
    @staticmethod
    def _handle_exploratory(args: Any, logger=None) -> int:
        """Handle exploratory analysis command."""
        logger = logger or _logger
        
        logger.info("📊 Running exploratory data analysis...")
        
        try:
            from ..features.analytics_suite import create_analytics_suite
            
            # Create and run analytics
            analytics = create_analytics_suite()
            
            kwargs = {'output_format': args.output_format}
            if args.season:
                kwargs['season'] = args.season
            
            result = analytics.process('exploratory', **kwargs)
            
            if result.get('status') == 'success':
                logger.info("✅ Exploratory analysis complete")
                
                # Display key insights
                analysis_result = result.get('result', {})
                data_overview = analysis_result.get('data_overview', {})
                
                if 'date_range' in data_overview:
                    date_range = data_overview['date_range']
                    logger.info(f"Data range: {date_range.get('min_date')} to {date_range.get('max_date')}")
                    logger.info(f"Total plays: {date_range.get('total_plays', 0):,}")
                
                # Show team performance insights
                team_perf = analysis_result.get('team_performance', {})
                top_teams = team_perf.get('top_teams_by_efficiency', [])
                if top_teams:
                    logger.info("Top performing teams:")
                    for i, team in enumerate(top_teams[:3]):
                        logger.info(f"  {i+1}. {team['team']}: {team['avg_yards_per_play']} yards/play")
                
            else:
                logger.error(f"❌ Exploratory analysis failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Exploratory analysis failed: {e}")
            return 1
    
    @staticmethod
    def _handle_feature_analysis(args: Any, logger=None) -> int:
        """Handle feature analysis command."""
        logger = logger or _logger
        
        logger.info("🔍 Running feature analysis...")
        
        try:
            from ..features.analytics_suite import create_analytics_suite
            
            # Create and run analytics
            analytics = create_analytics_suite()
            
            result = analytics.process(
                'feature_analysis',
                output_format=args.output_format,
                correlation_threshold=args.correlation_threshold
            )
            
            if result.get('status') == 'success':
                logger.info("✅ Feature analysis complete")
                
                # Display key results
                analysis_result = result.get('result', {})
                dataset_info = analysis_result.get('dataset_info', {})
                
                if 'shape' in dataset_info:
                    rows, cols = dataset_info['shape']
                    logger.info(f"Dataset: {rows:,} rows, {cols} features")
                
                # Show quality assessment
                quality = analysis_result.get('quality_assessment', {})
                if 'overall_score' in quality:
                    score = quality['overall_score']
                    logger.info(f"Quality score: {score:.2f}")
                
                # Show correlation insights
                correlation = analysis_result.get('correlation_analysis', {})
                if 'high_correlations' in correlation:
                    high_corr = correlation['high_correlations']
                    if high_corr:
                        logger.info(f"Found {len(high_corr)} highly correlated feature pairs")
                        for i, pair in enumerate(high_corr[:3]):
                            logger.info(f"  {pair['feature1']} ↔ {pair['feature2']}: {pair['correlation']:.3f}")
                
            else:
                logger.error(f"❌ Feature analysis failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Feature analysis failed: {e}")
            return 1
    
    @staticmethod
    def _handle_team_performance(args: Any, logger=None) -> int:
        """Handle team performance analysis command."""
        logger = logger or _logger
        
        logger.info(f"🏈 Analyzing team performance for {args.season} season...")
        
        try:
            from ..features.analytics_suite import create_exploratory_analysis
            
            # Create exploratory analysis service
            exploratory = create_exploratory_analysis()
            
            result = exploratory.analyze_team_performance(
                season=args.season,
                output_format=args.output_format
            )
            
            if result.get('status') == 'success':
                logger.info("✅ Team performance analysis complete")
                
                teams = result.get('team_performance', [])
                insights = result.get('insights', [])
                
                logger.info(f"Teams analyzed: {result.get('teams_analyzed', 0)}")
                
                if teams:
                    logger.info("Top performing teams:")
                    for i, team in enumerate(teams[:5]):
                        eff_score = team.get('efficiency_score', team.get('avg_yards_per_play', 0))
                        logger.info(f"  {i+1}. {team['team']}: {eff_score:.2f} efficiency")
                
                if insights:
                    logger.info("Key insights:")
                    for insight in insights:
                        logger.info(f"  • {insight}")
                
                # Filter by specific team if requested
                if args.team:
                    team_data = next((t for t in teams if t['team'].upper() == args.team.upper()), None)
                    if team_data:
                        logger.info(f"{args.team} Performance:")
                        logger.info(f"  Total plays: {team_data.get('total_plays', 0):,}")
                        logger.info(f"  Yards/play: {team_data.get('avg_yards_per_play', 0):.2f}")
                        logger.info(f"  Touchdowns: {team_data.get('touchdowns', 0)}")
                        logger.info(f"  Turnovers: {team_data.get('interceptions', 0) + team_data.get('fumbles_lost', 0)}")
                    else:
                        logger.warning(f"⚠️  Team '{args.team}' not found in data")
                
            else:
                logger.error(f"❌ Team performance analysis failed: {result.get('message', 'Unknown error')}")
                return 1
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Team performance analysis failed: {e}")
            return 1
