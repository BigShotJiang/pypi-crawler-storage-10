"""
Main CLI Entry Point for nflfastRv3

Simple command-line interface for accessing all nflfastRv3 capabilities.

Pattern: Basic CLI routing
Complexity: 1 point (simple command dispatch)
Layer: 1 (Public interface)
"""

import argparse
import sys
from typing import List, Optional

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # dotenv not available, continue without it
    pass

from commonv2 import get_logger
from .data_commands import DataCommands
from .ml_commands import MLCommands
from .analytics_commands import AnalyticsCommands

# Module-level logger following proper singleton pattern
_logger = get_logger('nflfastRv3.cli.main')


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser with subcommands."""
    parser = argparse.ArgumentParser(
        prog='nflfastRv3',
        description='NFL Data Analysis Pipeline - Clean Architecture v3',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  nflfastRv3 data process --source play_by_play
  nflfastRv3 ml train --model xgboost
  nflfastRv3 analytics exploratory --season 2024
  nflfastRv3 analytics feature-analysis --output console
        '''
    )
    
    # Add version info
    parser.add_argument('--version', action='version', version='nflfastRv3 1.0.0')
    
    # Create subparsers for main command groups
    subparsers = parser.add_subparsers(
        dest='command',
        help='Available commands',
        metavar='COMMAND'
    )
    
    # Data pipeline commands
    data_parser = subparsers.add_parser(
        'data',
        help='Data pipeline operations',
        description='Run data pipeline workflows'
    )
    DataCommands.setup_parser(data_parser)
    
    # ML pipeline commands
    ml_parser = subparsers.add_parser(
        'ml',
        help='Machine learning workflows',
        description='Run ML training and prediction workflows'
    )
    MLCommands.setup_parser(ml_parser)
    
    # Analytics commands
    analytics_parser = subparsers.add_parser(
        'analytics',
        help='Analytics and reporting',
        description='Run analytics and generate reports'
    )
    AnalyticsCommands.setup_parser(analytics_parser)
    
    # System utilities
    system_parser = subparsers.add_parser(
        'system',
        help='System utilities',
        description='System validation and utilities'
    )
    setup_system_commands(system_parser)
    
    return parser


def setup_system_commands(parser: argparse.ArgumentParser) -> None:
    """Setup system utility commands."""
    subparsers = parser.add_subparsers(dest='system_command', help='System commands')
    
    # Architecture validation
    validate_parser = subparsers.add_parser(
        'validate',
        help='Validate system architecture'
    )
    validate_parser.add_argument(
        '--component',
        choices=['all', 'data', 'ml', 'analytics'],
        default='all',
        help='Component to validate'
    )
    
    # System info
    info_parser = subparsers.add_parser(
        'info',
        help='Display system information'
    )
    info_parser.add_argument(
        '--detailed',
        action='store_true',
        help='Show detailed information'
    )


def handle_system_commands(args, logger=None) -> int:
    """Handle system utility commands."""
    logger = logger or _logger
    
    if args.system_command == 'validate':
        return validate_architecture(args.component, logger)
    elif args.system_command == 'info':
        return show_system_info(args.detailed, logger)
    else:
        logger.error("No system command specified. Use --help for options.")
        return 1


def validate_architecture(component: str, logger=None) -> int:
    """Validate system architecture."""
    logger = logger or _logger
    logger.info(f"🔍 Validating {component} architecture...")
    
    try:
        if component in ['all', 'data']:
            from ..features.data_pipeline import validate_data_architecture
            data_result = validate_data_architecture()
            logger.info(f"Data Pipeline: {data_result['overall_status']}")
        
        if component in ['all', 'ml']:
            from ..features.ml_pipeline import validate_ml_architecture
            ml_result = validate_ml_architecture()
            logger.info(f"ML Pipeline: {ml_result['overall_status']}")
        
        if component in ['all', 'analytics']:
            from ..features.analytics_suite import validate_analytics_architecture
            analytics_result = validate_analytics_architecture()
            logger.info(f"Analytics Suite: {analytics_result['overall_status']}")
        
        logger.info("✅ Architecture validation complete")
        return 0
        
    except Exception as e:
        logger.error(f"❌ Validation failed: {e}")
        return 1


def show_system_info(detailed: bool, logger=None) -> int:
    """Show system information."""
    logger = logger or _logger
    
    logger.info("🏗️ nflfastRv3 System Information")
    logger.info("=" * 40)
    logger.info("Version: 1.0.0")
    logger.info("Architecture: Clean Architecture with Minimum Viable Decoupling")
    logger.info("Components: Data Pipeline, ML Pipeline, Analytics Suite")
    
    if detailed:
        logger.info("Component Details:")
        logger.info("- Data Pipeline: ETL workflows with quality checks")
        logger.info("- ML Pipeline: XGBoost training and prediction")
        logger.info("- Analytics Suite: Exploratory and feature analysis")
        logger.info("Architecture Constraints:")
        logger.info("- Maximum 3 layers depth")
        logger.info("- 5 complexity points budget per module")
        logger.info("- Dependency injection throughout")
    
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """
    Main CLI entry point.
    
    Args:
        argv: Command line arguments (defaults to sys.argv)
        
    Returns:
        Exit code (0 for success, non-zero for error)
    """
    if argv is None:
        argv = sys.argv[1:]
    
    parser = create_parser()
    
    # Handle no arguments
    if not argv:
        parser.print_help()
        return 1
    
    try:
        args = parser.parse_args(argv)
        
        # Create logger for CLI session
        logger = get_logger('nflfastRv3.cli')
        
        # Dispatch to appropriate command handler
        if args.command == 'data':
            return DataCommands.handle(args, logger)
        elif args.command == 'ml':
            return MLCommands.handle(args, logger)
        elif args.command == 'analytics':
            return AnalyticsCommands.handle(args, logger)
        elif args.command == 'system':
            return handle_system_commands(args, logger)
        else:
            parser.print_help()
            return 1
            
    except KeyboardInterrupt:
        logger = get_logger('nflfastRv3.cli')
        logger.info("Operation cancelled by user")
        return 130
    except Exception as e:
        logger = get_logger('nflfastRv3.cli')
        logger.error(f"Error: {e}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
