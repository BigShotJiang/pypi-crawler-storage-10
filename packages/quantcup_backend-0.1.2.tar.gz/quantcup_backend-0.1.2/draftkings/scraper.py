"""
DraftKings Scraper for QuantCup Data Sources

A comprehensive scraper for DraftKings NFL odds data with database integration.

Migrated from: sports-books/Dev_DKScraper_PRD.py
"""

import asyncio
import logging
from logging.handlers import RotatingFileHandler
import random
from datetime import datetime, timedelta
import re
import uuid
from dotenv import load_dotenv
import os
from contextlib import contextmanager, asynccontextmanager
from pathlib import Path 
from typing import Dict, List, Optional, Any

import agentql
import pandas as pd
import yaml
from playwright.async_api import Geolocation, ProxySettings, async_playwright
import pytz
from sqlalchemy import create_engine
from sqlalchemy.types import BigInteger, Text, Date, Time, Numeric, TIMESTAMP, String
import calendar

# Import from QuantCup common utilities
from ...common.config import get_config
from ...common.database import get_database_connection

class DraftKingsScraper:
    """
    DraftKings NFL odds scraper with database integration.
    
    Features:
    - Async web scraping with Playwright and AgentQL
    - Configurable browser settings and proxies
    - Data validation and processing
    - PostgreSQL database integration
    - Comprehensive logging and error handling
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the DraftKings scraper.
        
        Args:
            config_path: Optional path to configuration file
        """
        self.config = self._load_configurations(config_path)
        self.logger = self._setup_logging()
        self.data_pull_id = str(uuid.uuid4())
        
        # Initialize scraping parameters
        self._setup_scraping_params()
        
    def _load_configurations(self, config_path: Optional[str] = None) -> Dict[str, Any]:
        """Load and validate configurations from config files and environment."""
        
        # Load from QuantCup common config if available, otherwise use legacy config
        try:
            config = get_config()
            if 'draftkings' in config:
                return config['draftkings']
        except:
            pass
            
        # Fallback to legacy config.yaml
        config_file = config_path or "config.yaml"
        if os.path.exists(config_file):
            with open(config_file, "r") as file:
                config = yaml.safe_load(file)
                return config.get('scraper', {})
        
        # Default configuration
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration for DraftKings scraper."""
        return {
            'browser_args': [
                '--no-sandbox',
                '--disable-blink-features=AutomationControlled',
                '--disable-dev-shm-usage'
            ],
            'browser_ignored_args': ['--enable-automation'],
            'user_agents': [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ],
            'locations': [
                {
                    'timezone': 'America/New_York',
                    'longitude': -74.0060,
                    'latitude': 40.7128
                }
            ],
            'referers': ['https://www.google.com/'],
            'accept_languages': ['en-US,en;q=0.9'],
            'proxies': [],
            'gameline_query': '''
            {
                games[] {
                    header
                    date
                    time
                    teams[] {
                        name
                        spread
                        spread_odds
                        moneyline
                    }
                    total_over
                    total_over_odds
                    total_under
                    total_under_odds
                    event_url
                }
            }
            '''
        }
    
    def _setup_logging(self) -> logging.Logger:
        """Set up logging configuration."""
        logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        
        if not logger.handlers:
            # Create formatter
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            
            # Console handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
            
            # File handler
            log_file = Path("logs") / "draftkings_scraper.log"
            log_file.parent.mkdir(exist_ok=True)
            
            file_handler = RotatingFileHandler(
                log_file, maxBytes=5*1024*1024, backupCount=5
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
            logger.setLevel(logging.INFO)
        
        return logger
    
    def _setup_scraping_params(self):
        """Set up randomized scraping parameters."""
        # Randomly select configurations for this session
        self.user_agent = random.choice(self.config.get('user_agents', ['Mozilla/5.0']))
        self.header_dnt = random.choice(["0", "1"])
        
        # Location setup
        locations = self.config.get('locations', [])
        if locations:
            location_config = random.choice(locations)
            self.location = (
                location_config.get('timezone', 'America/New_York'),
                Geolocation(
                    longitude=location_config.get('longitude', -74.0060),
                    latitude=location_config.get('latitude', 40.7128)
                )
            )
        else:
            self.location = ('America/New_York', Geolocation(longitude=-74.0060, latitude=40.7128))
        
        self.referer = random.choice(self.config.get('referers', ['https://www.google.com/']))
        self.accept_language = random.choice(self.config.get('accept_languages', ['en-US,en;q=0.9']))
        
        # Proxy setup
        proxies = self.config.get('proxies', [])
        if proxies:
            proxy_config = random.choice(proxies)
            self.proxy = ProxySettings(
                server=proxy_config.get('server'),
                username=proxy_config.get('username'),
                password=proxy_config.get('password')
            )
        else:
            self.proxy = None
    
    async def scrape_nfl_odds(self, max_retries: int = 3) -> Optional[pd.DataFrame]:
        """
        Scrape NFL odds from DraftKings with retry logic.
        
        Args:
            max_retries: Maximum number of retry attempts
            
        Returns:
            DataFrame with scraped odds data or None if failed
        """
        self.logger.info(f"Starting DraftKings NFL odds scraping (ID: {self.data_pull_id})")
        
        for attempt in range(max_retries):
            try:
                self.logger.info(f"Scraping attempt {attempt + 1}/{max_retries}")
                
                async with self._create_browser_context() as page:
                    # Navigate to DraftKings NFL page
                    self.logger.info("Navigating to DraftKings NFL page")
                    await page.goto(
                        "https://sportsbook.draftkings.com/leagues/football/nfl",
                        referer=self.referer
                    )
                    await page.wait_for_timeout(2000)  # Wait for page load
                    
                    # Scrape data
                    start_time = datetime.now().isoformat()
                    data = await self._query_odds_data(page)
                    end_time = datetime.now().isoformat()
                    
                    if not data:
                        self.logger.warning(f"No data returned on attempt {attempt + 1}")
                        continue
                    
                    # Process and validate data
                    df = self._process_odds_data(data, start_time, end_time)
                    
                    if df is not None and not df.empty:
                        self.logger.info(f"Successfully scraped {len(df)} records")
                        return df
                    else:
                        self.logger.warning(f"Data processing failed on attempt {attempt + 1}")
                        
            except Exception as e:
                self.logger.error(f"Scraping attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    self.logger.error("All scraping attempts failed")
                    return None
                
                # Wait before retry
                await asyncio.sleep(random.uniform(2, 5))
        
        return None
    
    @asynccontextmanager
    async def _create_browser_context(self):
        """Create and manage browser context for scraping."""
        browser = None
        context = None
        
        try:
            async with async_playwright() as playwright:
                # Launch browser
                browser = await playwright.chromium.launch(
                    headless=True,  # Set to False for debugging
                    args=self.config.get('browser_args', []),
                    ignore_default_args=self.config.get('browser_ignored_args', [])
                )
                
                # Create context
                context = await browser.new_context(
                    proxy=self.proxy,
                    locale="en-US,en,ru",
                    timezone_id=self.location[0],
                    extra_http_headers={
                        "Accept-Language": self.accept_language,
                        "Referer": self.referer,
                        "DNT": self.header_dnt,
                        "Connection": "keep-alive",
                        "Accept-Encoding": "gzip, deflate, br",
                    },
                    geolocation=self.location[1],
                    user_agent=self.user_agent,
                    permissions=["notifications"],
                    viewport={
                        "width": 1920 + random.randint(-50, 50),
                        "height": 1080 + random.randint(-50, 50),
                    },
                )
                
                # Create page with AgentQL
                page = await agentql.wrap_async(context.new_page())
                await page.enable_stealth_mode(nav_user_agent=self.user_agent)
                
                yield page
                
        except Exception as e:
            self.logger.error(f"Browser context error: {e}")
            raise
        finally:
            if context:
                await context.close()
            if browser:
                await browser.close()
    
    async def _query_odds_data(self, page) -> Optional[Dict]:
        """Query odds data from the page using AgentQL."""
        try:
            query = self.config.get('gameline_query', '{}')
            self.logger.debug("Executing AgentQL query")
            data = await page.query_data(query)
            self.logger.debug(f"Query returned: {len(data.get('games', []))} games")
            return data
        except Exception as e:
            self.logger.error(f"AgentQL query failed: {e}")
            return None
    
    def _process_odds_data(self, data: Dict, start_time: str, end_time: str) -> Optional[pd.DataFrame]:
        """Process raw odds data into structured DataFrame."""
        try:
            games = data.get("games", [])
            if not games:
                self.logger.warning("No games found in scraped data")
                return None
            
            rows = []
            
            for game in games:
                header = game.get('header', '')
                date_str = game.get("date", "")
                time_str = game.get("time", "")
                
                # Parse and convert date/time
                standardized_date = self._parse_date_string(date_str)
                if standardized_date:
                    converted = self._convert_time_to_eastern(standardized_date, time_str)
                    if converted:
                        date_converted, time_converted = converted
                    else:
                        date_converted, time_converted = date_str, time_str
                else:
                    date_converted, time_converted = date_str, time_str
                
                # Process teams
                teams = game.get("teams", [])
                for team in teams:
                    team_name = team.get("name", "")
                    if not team_name:
                        continue
                    
                    row = {
                        "Event ID": self._extract_event_id(game.get("event_url", "")),
                        "Header": header,
                        "Date": date_converted,
                        "Time (EST)": time_converted,
                        "Team": team_name,
                        "Spread": team.get("spread", ""),
                        "Spread Odds": team.get("spread_odds", ""),
                        "Moneyline": team.get("moneyline", ""),
                        "Total Over": game.get("total_over", ""),
                        "Total Over Odds": game.get("total_over_odds", ""),
                        "Total Under": game.get("total_under", ""),
                        "Total Under Odds": game.get("total_under_odds", ""),
                        "Event URL": game.get("event_url", ""),
                        "Bookmaker": "DraftKings",
                        "Odds Format": "American",
                        "Data Pull Start Time": start_time,
                        "Data Pull End Time": end_time,
                        "Data Pull ID": self.data_pull_id,
                    }
                    rows.append(row)
            
            if not rows:
                self.logger.warning("No valid team data found")
                return None
            
            # Create DataFrame
            df = pd.DataFrame(rows)
            
            # Convert numeric columns
            numeric_columns = [
                "Spread", "Spread Odds", "Moneyline", 
                "Total Over", "Total Over Odds", "Total Under", "Total Under Odds"
            ]
            for col in numeric_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Validate data
            if self._validate_dataframe(df):
                return df
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Data processing error: {e}")
            return None
    
    def _parse_date_string(self, date_str: str) -> Optional[str]:
        """Parse various date string formats to standardized YYYY-MM-DD."""
        if not date_str:
            return None
        
        date_str_clean = date_str.strip().upper()
        # Remove ordinal suffixes
        date_str_clean = re.sub(r'(\d+)(TH|RD|ND|ST)', r'\1', date_str_clean)
        
        # Handle relative dates
        relative_days = {'TODAY': 0, 'TOMORROW': 1, 'YESTERDAY': -1}
        if date_str_clean in relative_days:
            target_date = datetime.now() + timedelta(days=relative_days[date_str_clean])
            return target_date.strftime('%Y-%m-%d')
        
        # Try ISO format
        try:
            dt = datetime.strptime(date_str, '%Y-%m-%d')
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            pass
        
        # Try 'FRI NOV 15' format
        try:
            dt = datetime.strptime(date_str_clean, '%a %b %d')
            dt = dt.replace(year=datetime.now().year)
            return dt.strftime('%Y-%m-%d')
        except ValueError:
            pass
        
        self.logger.warning(f"Unable to parse date string: '{date_str}'")
        return None
    
    def _convert_time_to_eastern(self, date_str: str, time_str: str) -> Optional[tuple]:
        """Convert time to Eastern timezone."""
        if not date_str or not time_str:
            return None
        
        try:
            datetime_str = f"{date_str} {time_str}"
            naive_datetime = datetime.strptime(datetime_str, "%Y-%m-%d %I:%M%p")
            
            # Assume GMT and convert to Eastern
            gmt_timezone = pytz.timezone('GMT')
            gmt_datetime = gmt_timezone.localize(naive_datetime)
            eastern_timezone = pytz.timezone('America/New_York')
            eastern_datetime = gmt_datetime.astimezone(eastern_timezone)
            
            converted_date = eastern_datetime.strftime("%m/%d/%Y")
            converted_time = eastern_datetime.strftime("%I:%M%p")
            
            return converted_date, converted_time
        except Exception as e:
            self.logger.error(f"Time conversion error: {e}")
            return None
    
    def _extract_event_id(self, event_url: str) -> Optional[int]:
        """Extract event ID from URL."""
        if not event_url:
            return None
        
        match = re.search(r'/([^/]+)$', event_url)
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                pass
        return None
    
    def _validate_dataframe(self, df: pd.DataFrame) -> bool:
        """Validate the processed DataFrame."""
        try:
            required_columns = [
                "Event ID", "Header", "Date", "Time (EST)", "Team",
                "Spread", "Spread Odds", "Moneyline", "Total Over",
                "Total Over Odds", "Total Under", "Total Under Odds",
                "Event URL", "Bookmaker", "Odds Format",
                "Data Pull Start Time", "Data Pull End Time", "Data Pull ID"
            ]
            
            # Check for required columns
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                self.logger.error(f"Missing required columns: {missing_columns}")
                return False
            
            # Check for empty DataFrame
            if df.empty:
                self.logger.error("DataFrame is empty")
                return False
            
            # Basic data validation
            if df['Team'].isnull().all():
                self.logger.error("No valid team names found")
                return False
            
            self.logger.info("Data validation passed")
            return True
            
        except Exception as e:
            self.logger.error(f"Validation error: {e}")
            return False
    
    def save_to_csv(self, df: pd.DataFrame, export_dir: str = "exports") -> Optional[Path]:
        """Save DataFrame to CSV file."""
        try:
            export_path = Path(export_dir)
            export_path.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = export_path / f"draftkings_odds_{timestamp}.csv"
            
            df.to_csv(filename, index=False)
            self.logger.info(f"Data saved to {filename}")
            return filename
            
        except Exception as e:
            self.logger.error(f"CSV save error: {e}")
            return None
    
    def save_to_database(self, df: pd.DataFrame, table_name: str = "dk_gamelines") -> bool:
        """Save DataFrame to PostgreSQL database."""
        try:
            # Get database connection
            engine = get_database_connection()
            
            # Prepare DataFrame for database
            df_db = df.copy()
            
            # Rename columns for database
            column_mapping = {
                'Event ID': 'event_id',
                'Header': 'header',
                'Date': 'date',
                'Time (EST)': 'time',
                'Team': 'team',
                'Spread': 'spread',
                'Spread Odds': 'spread_odds',
                'Moneyline': 'moneyline',
                'Total Over': 'total_over',
                'Total Over Odds': 'total_over_odds',
                'Total Under': 'total_under',
                'Total Under Odds': 'total_under_odds',
                'Event URL': 'event_url',
                'Bookmaker': 'bookmaker',
                'Odds Format': 'odds_format',
                'Data Pull Start Time': 'data_pull_start_time',
                'Data Pull End Time': 'data_pull_end_time',
                'Data Pull ID': 'data_pull_id'
            }
            df_db.rename(columns=column_mapping, inplace=True)
            
            # Convert data types
            df_db['date'] = pd.to_datetime(df_db['date']).dt.date
            df_db['time'] = pd.to_datetime(df_db['time'], format='%I:%M%p').dt.time
            df_db['data_pull_start_time'] = pd.to_datetime(df_db['data_pull_start_time'])
            df_db['data_pull_end_time'] = pd.to_datetime(df_db['data_pull_end_time'])
            
            # Define data types for database
            dtype_mapping = {
                'event_id': BigInteger(),
                'header': Text(),
                'date': Date(),
                'time': Time(),
                'team': Text(),
                'spread': Numeric(),
                'spread_odds': Numeric(),
                'moneyline': Numeric(),
                'total_over': Numeric(),
                'total_over_odds': Numeric(),
                'total_under': Numeric(),
                'total_under_odds': Numeric(),
                'event_url': Text(),
                'bookmaker': Text(),
                'odds_format': Text(),
                'data_pull_start_time': TIMESTAMP(),
                'data_pull_end_time': TIMESTAMP(),
                'data_pull_id': String(),
            }
            
            # Save to database
            df_db.to_sql(
                table_name,
                con=engine,
                schema='public',
                if_exists='append',
                index=False,
                dtype=dtype_mapping
            )
            
            self.logger.info(f"Successfully saved {len(df_db)} records to database table '{table_name}'")
            return True
            
        except Exception as e:
            self.logger.error(f"Database save error: {e}")
            return False


# Convenience functions for backward compatibility
async def scrape_draftkings_odds(config_path: Optional[str] = None) -> Optional[pd.DataFrame]:
    """
    Convenience function to scrape DraftKings odds.
    
    Args:
        config_path: Optional path to configuration file
        
    Returns:
        DataFrame with odds data or None if failed
    """
    scraper = DraftKingsScraper(config_path)
    return await scraper.scrape_nfl_odds()


def test_draftkings_scraper():
    """Test the DraftKings scraper."""
    async def run_test():
        scraper = DraftKingsScraper()
        df = await scraper.scrape_nfl_odds()
        
        if df is not None:
            print(f"Successfully scraped {len(df)} records")
            print("\nSample data:")
            print(df.head())
            
            # Save to CSV
            csv_file = scraper.save_to_csv(df)
            if csv_file:
                print(f"Data saved to: {csv_file}")
            
            # Optionally save to database
            # success = scraper.save_to_database(df)
            # if success:
            #     print("Data saved to database")
        else:
            print("Scraping failed")
    
    asyncio.run(run_test())


if __name__ == "__main__":
    test_draftkings_scraper()
