"""
DraftKings Data Source Module

Provides scraping and data collection functionality for DraftKings sportsbook.

Migrated from: sports-books/Dev_DKScraper_PRD.py
"""

from .scraper import DraftKingsScraper

__all__ = ['DraftKingsScraper']
