"""
QuantCup Unified CLI

Provides a single front door for all QuantCup ecosystem modules with
production-ready orchestration capabilities.
"""

from __future__ import annotations

import os
import sys
import shlex
import uuid
import time
from typing import Optional
from pathlib import Path

import typer
from . import __version__

# Ensure project root is in Python path for module imports
project_root = Path(__file__).parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Context settings for pass-through commands
FORWARD_CTX = {
    "allow_extra_args": True,
    "ignore_unknown_options": True,
    "help_option_names": [],  # disable Typer's --help so we can forward it
}

app = typer.Typer(help="QuantCup unified CLI for sports analytics ecosystem")

def version_callback(value: bool):
    """Print version and exit."""
    if value:
        typer.echo(f"quantcup {__version__}")
        raise typer.Exit()

@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", callback=version_callback, is_eager=True,
        help="Show version and exit"
    )
):
    """QuantCup unified CLI for sports analytics ecosystem."""
    pass


# ---- Odds API ----------------------------------------------------------------
from odds_api.cli import app as odds_app
app.add_typer(odds_app, name="odds", help="Sports betting data pipeline")

# ---- Weather API -------------------------------------------------------------
from noaa.cli import app as weather_app
app.add_typer(weather_app, name="noaa", help="NOAA Weather API integration for NFL games")


# ---- NFLfastRv3 (Clean Architecture version) ------------------------------
try:
    from nflfastRv3.cli.main import main as nflfastrv3_main
    
    nflfastrv3 = typer.Typer(help="NFLfastRv3 - Clean Architecture pipeline (Preview)")
    app.add_typer(nflfastrv3, name="nflfastrv3")
    
    @nflfastrv3.command(context_settings=FORWARD_CTX)
    def data(ctx: typer.Context):
        """Data pipeline operations"""
        try:
            exit_code = nflfastrv3_main(["data"] + ctx.args)
            if exit_code != 0:
                raise typer.Exit(exit_code)
        except Exception as e:
            typer.echo(f"Error executing nflfastrv3 data command: {e}", err=True)
            raise typer.Exit(1)
    
    @nflfastrv3.command(context_settings=FORWARD_CTX)
    def ml(ctx: typer.Context):
        """Machine learning workflows"""
        try:
            exit_code = nflfastrv3_main(["ml"] + ctx.args)
            if exit_code != 0:
                raise typer.Exit(exit_code)
        except Exception as e:
            typer.echo(f"Error executing nflfastrv3 ml command: {e}", err=True)
            raise typer.Exit(1)
    
    @nflfastrv3.command(context_settings=FORWARD_CTX)
    def analytics(ctx: typer.Context):
        """Analytics and reporting"""
        try:
            exit_code = nflfastrv3_main(["analytics"] + ctx.args)
            if exit_code != 0:
                raise typer.Exit(exit_code)
        except Exception as e:
            typer.echo(f"Error executing nflfastrv3 analytics command: {e}", err=True)
            raise typer.Exit(1)
    
    @nflfastrv3.command(context_settings=FORWARD_CTX)
    def system(ctx: typer.Context):
        """System utilities and validation"""
        try:
            exit_code = nflfastrv3_main(["system"] + ctx.args)
            if exit_code != 0:
                raise typer.Exit(exit_code)
        except Exception as e:
            typer.echo(f"Error executing nflfastrv3 system command: {e}", err=True)
            raise typer.Exit(1)
    
    @nflfastrv3.command(help="Check nflfastRv3 implementation status")
    def status():
        """Check implementation completeness and readiness."""
        try:
            exit_code = nflfastrv3_main(["system", "validate", "--component", "all"])
            if exit_code == 0:
                typer.echo("✅ NFLfastRv3 is ready for production use")
            else:
                typer.echo("⚠️ NFLfastRv3 has incomplete implementations", err=True)
                typer.echo("Run 'quantcup nflfastrv3 system validate --help' for details")
        except Exception as e:
            typer.echo(f"❌ NFLfastRv3 status check failed: {e}", err=True)
            raise typer.Exit(1)

except ImportError as e:
    # Graceful degradation if nflfastRv3 is not ready
    nflfastrv3 = typer.Typer(help="NFLfastRv3 - Not available (incomplete implementation)")
    app.add_typer(nflfastrv3, name="nflfastrv3")
    
    @nflfastrv3.callback()
    def unavailable():
        typer.echo("❌ NFLfastRv3 is not yet fully implemented.", err=True)
        typer.echo("Please use 'quantcup nflfastr' instead.")
        typer.echo(f"Import error: {e}")
        raise typer.Exit(1)

# ---- Future expansion placeholders -------------------------------------------
# Uncomment and implement when these modules have CLIs

# @app.command(help="API Sports integration")
# def api_sports(ctx: typer.Context):
#     """Multi-sport data access via API Sports."""
#     raise typer.Exit(_forward("api_sports", ctx.args))

# @app.command(help="NFL data wrapper utilities")
# def nfl_wrapper(ctx: typer.Context):
#     """Enhanced NFL data access wrapper."""
#     raise typer.Exit(_forward("nfl_wrapper", ctx.args))

if __name__ == "__main__":
    app()
