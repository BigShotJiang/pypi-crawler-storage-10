"""
ETL (Extract, Transform, Load) package for odds data pipeline.
"""
