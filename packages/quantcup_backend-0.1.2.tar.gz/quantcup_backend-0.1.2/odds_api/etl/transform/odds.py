"""
Odds data transformation functions.
Handles fetching, normalizing, and processing betting odds data.
"""

import logging
import pandas as pd
import json
import os

from .core import enrich_odds_metrics, fix_commence_time, output_dir
from ..extract.api import fetch_odds_data

logger = logging.getLogger(__name__)

def normalize_odds_df(df):
    """Optimized normalization using vectorized operations instead of nested loops"""
    
    def _safe_bookmakers(obj):
        # Already a list → OK.  A JSON string → parse.
        return obj if isinstance(obj, list) else json.loads(obj)
    
    # Fix the bookmakers column to handle both list and string cases
    df = df.copy()
    df["bookmakers"] = df["bookmakers"].apply(_safe_bookmakers)
    
    # Pre-flatten the nested JSON structure using pd.json_normalize
    flattened_rows = []
    
    for _, row in df.iterrows():
        # Extract base game info once per game
        base_info = {
            'game_id': row['id'],
            'sport_key': row['sport_key'],
            'sport_title': row['sport_title'],
            'commence_time': row['commence_time'],
            'home_team': row['home_team'],
            'away_team': row['away_team']
        }
        
        # Flatten bookmakers and markets in one pass
        for bookmaker in row['bookmakers']:
            bookmaker_info = {
                'bookmaker_key': bookmaker['key'],
                'bookmaker_title': bookmaker['title'],
                'bookmaker_last_update': bookmaker['last_update']
            }
            
            for market in bookmaker['markets']:
                # Create base row with all info
                market_row = {**base_info, **bookmaker_info, 'market_key': market['key']}
                
                # Pre-create outcome lookup for this market
                outcome_lookup = {outcome['name']: outcome for outcome in market['outcomes']}
                
                # Initialize all odds columns
                market_row.update({
                    'home_team_odds': None, 'away_team_odds': None,
                    'home_team_spread': None, 'away_team_spread': None,
                    'home_team_spread_odds': None, 'away_team_spread_odds': None,
                    'over_odds': None, 'under_odds': None, 'total_points': None
                })
                
                # Vectorized market processing using lookup
                if market['key'] == 'h2h':
                    if row['home_team'] in outcome_lookup:
                        market_row['home_team_odds'] = outcome_lookup[row['home_team']]['price']
                    if row['away_team'] in outcome_lookup:
                        market_row['away_team_odds'] = outcome_lookup[row['away_team']]['price']
                
                elif market['key'] == 'spreads':
                    if row['home_team'] in outcome_lookup:
                        outcome = outcome_lookup[row['home_team']]
                        market_row['home_team_spread_odds'] = outcome['price']
                        market_row['home_team_spread'] = outcome.get('point', 0)
                    if row['away_team'] in outcome_lookup:
                        outcome = outcome_lookup[row['away_team']]
                        market_row['away_team_spread_odds'] = outcome['price']
                        market_row['away_team_spread'] = outcome.get('point', 0)
                
                elif market['key'] == 'totals':
                    if 'Over' in outcome_lookup:
                        outcome = outcome_lookup['Over']
                        market_row['over_odds'] = outcome['price']
                        market_row['total_points'] = outcome.get('point', 0)
                    if 'Under' in outcome_lookup:
                        market_row['under_odds'] = outcome_lookup['Under']['price']
                
                flattened_rows.append(market_row)
    
    return pd.DataFrame(flattened_rows)

def write_market_csvs(detailed_df):
    """Write lean, market-specific CSV files with only relevant columns"""
    markets = ["h2h", "spreads", "totals"]

    BASE = [
        "game_id", "commence_time", "home_team", "away_team",
        "bookmaker_key", "bookmaker_title", "bookmaker_last_update"
    ]

    COLS_BY_MARKET = {
        "h2h": BASE + [
            "home_team_odds", "away_team_odds",
            "home_team_payout", "away_team_payout",
            "home_team_profit", "away_team_profit",
            "home_implied_prob_pct", "away_implied_prob_pct",
            "moneyline_juice_pct"
        ],
        "spreads": BASE + [
            "home_team_spread", "away_team_spread",
            "home_team_spread_odds", "away_team_spread_odds",
            "home_spread_payout", "away_spread_payout",
            "home_spread_profit", "away_spread_profit",
            "home_spread_implied_prob_pct", "away_spread_implied_prob_pct",
            "spread_juice_pct"
        ],
        "totals": BASE + [
            "total_points",
            "over_odds", "under_odds",
            "over_payout", "under_payout",
            "over_profit", "under_profit",
            "over_implied_prob_pct", "under_implied_prob_pct",
            "totals_juice_pct"
        ],
    }

    for m in markets:
        out_df = detailed_df.loc[detailed_df["market_key"] == m, COLS_BY_MARKET[m]]
        csv_path = os.path.join(output_dir, f"odds_{m}.csv")
        out_df.to_csv(csv_path, index=False, float_format="%.4f")
        logger.info(f"✅ odds_{m}.csv → {out_df.shape[0]} rows / {out_df.shape[1]} cols")

def get_odds(api_key=None, sport_key='americanfootball_nfl', markets=None):
    """Main function to fetch and process odds data, return clean DataFrame ready for database insert"""
    
    if markets is None:
        markets = ['h2h', 'spreads', 'totals']
    
    # Fetch data with retry logic
    data = fetch_odds_data(sport_key=sport_key, markets=markets)
    
    # Create initial DataFrame
    df = pd.DataFrame(data)
    
    # Process pipeline with unified odds enrichment (Phase 5 optimization)
    return (df
            .pipe(normalize_odds_df)
            .pipe(fix_commence_time)           # Handle timezone properly
            .pipe(enrich_odds_metrics, stake=100)  # Single-pass odds processing
            .drop_duplicates(subset=['game_id', 'bookmaker_key', 'market_key', 'home_team_odds', 'away_team_odds']))
