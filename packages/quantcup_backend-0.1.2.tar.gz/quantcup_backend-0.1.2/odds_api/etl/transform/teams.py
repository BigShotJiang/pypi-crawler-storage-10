"""
Teams data transformation functions.
Handles fetching and processing teams/participants data.
"""

import logging
import pandas as pd

from ..extract.api import fetch_participants_data

logger = logging.getLogger(__name__)

def get_teams_data(sport_key='americanfootball_nfl'):
    """Fetch and transform teams/participants data"""
    
    logger.info(f"Fetching teams/participants data for {sport_key}...")
    data = fetch_participants_data(sport_key)
    
    # Debug: log the structure of the first participant
    if data and len(data) > 0:
        logger.info(f"Sample participant structure: {data[0]}")
    
    # Transform to match teams table schema
    records = []
    for participant in data:
        # Handle different possible field names for participant name
        name = participant.get('name') or participant.get('title') or participant.get('full_name') or str(participant.get('id', 'Unknown'))
        
        record = {
            'participant_id': participant['id'],
            'sport_key': sport_key,
            'full_name': name
        }
        records.append(record)
    
    df = pd.DataFrame(records)
    logger.info(f"Processed {len(df)} teams/participants for {sport_key}")
    return df
