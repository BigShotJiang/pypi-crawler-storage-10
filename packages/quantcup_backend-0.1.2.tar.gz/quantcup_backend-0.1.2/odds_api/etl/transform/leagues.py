"""
Leagues data transformation functions.
Handles fetching and processing sports/leagues data.
"""

import logging
import pandas as pd

from ..extract.api import fetch_sports_data

logger = logging.getLogger(__name__)

def get_leagues_data():
    """Fetch and transform sports/leagues data"""
    
    logger.info("Fetching sports/leagues data...")
    data = fetch_sports_data()
    
    # Transform to match leagues table schema
    records = []
    for sport in data:
        record = {
            'sport_key': sport['key'],
            'group_name': sport['group'],
            'title': sport['title'],
            'description': sport.get('description', ''),
            'active': sport['active'],
            'has_outrights': sport.get('has_outrights', False)
        }
        records.append(record)
    
    df = pd.DataFrame(records)
    logger.info(f"Processed {len(df)} sports/leagues")
    return df
