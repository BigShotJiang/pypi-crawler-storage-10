"""
Results data transformation functions.
Handles fetching and processing scores/results data.
"""

import logging
import pandas as pd

from .core import fix_commence_time
from ..extract.api import fetch_scores_data

logger = logging.getLogger(__name__)

def get_results_data(sport_key='americanfootball_nfl', days_from=None):
    """Fetch and transform scores/results data"""
    
    logger.info(f"Fetching results data for {sport_key}...")
    data = fetch_scores_data(sport_key, days_from)
    
    # Transform to match results table schema
    records = []
    for event in data:
        # Extract scores from nested structure
        home_score = None
        away_score = None
        if 'scores' in event and event['scores']:
            for score in event['scores']:
                if score['name'] == event['home_team']:
                    home_score = score.get('score')
                elif score['name'] == event['away_team']:
                    away_score = score.get('score')
        
        record = {
            'event_id': event['id'],
            'sport_key': event['sport_key'],
            'sport_title': event['sport_title'],
            'commence_time': event['commence_time'],
            'completed': event.get('completed', False),
            'home_team': event['home_team'],
            'away_team': event['away_team'],
            'home_score': home_score,
            'away_score': away_score,
            'last_update': event.get('last_update')
        }
        records.append(record)
    
    df = pd.DataFrame(records)
    df = fix_commence_time(df)  # Apply timezone conversion
    
    # Convert last_update to datetime if present
    if 'last_update' in df.columns and not df['last_update'].isna().all():
        df['last_update'] = pd.to_datetime(df['last_update'], utc=True).dt.tz_convert('America/New_York')
    
    logger.info(f"Processed {len(df)} results for {sport_key}")
    return df
