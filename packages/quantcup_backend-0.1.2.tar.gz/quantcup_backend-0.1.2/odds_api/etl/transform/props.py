"""
Props data transformation functions.
Handles fetching and processing event-specific odds/props data.
"""

import logging
import pandas as pd
import json

from ..extract.api import fetch_event_odds_data

logger = logging.getLogger(__name__)

def get_props_data(sport_key='americanfootball_nfl', event_id=None, markets=None):
    """Fetch and transform event-specific odds/props data"""
    
    if event_id is None:
        logger.warning("No event_id provided for props data")
        return pd.DataFrame()
    
    logger.info(f"Fetching props data for event {event_id}...")
    data = fetch_event_odds_data(sport_key, event_id, markets)
    
    # Transform to match props table schema
    records = []
    
    # Handle both single event and list of events
    events = data if isinstance(data, list) else [data]
    
    for event in events:
        if 'bookmakers' not in event:
            continue
            
        for bookmaker in event['bookmakers']:
            for market in bookmaker['markets']:
                record = {
                    'event_id': event['id'],
                    'sport_key': event['sport_key'],
                    'bookmaker_key': bookmaker['key'],
                    'market_key': market['key'],
                    'market_data': json.dumps(market),  # Store full market as JSON
                    'last_update': market.get('last_update')  # Get last_update from market, not bookmaker
                }
                records.append(record)
    
    df = pd.DataFrame(records)
    
    # Convert last_update to datetime if present and not all null
    if 'last_update' in df.columns and not df['last_update'].isna().all():
        df['last_update'] = pd.to_datetime(df['last_update'], utc=True).dt.tz_convert('America/New_York')
    
    logger.info(f"Processed {len(df)} prop markets for event {event_id}")
    return df
