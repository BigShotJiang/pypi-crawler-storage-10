"""
Schedule data transformation functions.
Handles fetching and processing events/schedule data.
"""

import logging
import pandas as pd

from .core import fix_commence_time
from ..extract.api import fetch_events_data

logger = logging.getLogger(__name__)

def get_schedule_data(sport_key='americanfootball_nfl'):
    """Fetch and transform events/schedule data"""
    
    logger.info(f"Fetching schedule data for {sport_key}...")
    data = fetch_events_data(sport_key)
    
    # Transform to match schedule table schema
    records = []
    for event in data:
        record = {
            'event_id': event['id'],
            'sport_key': event['sport_key'],
            'sport_title': event['sport_title'],
            'commence_time': event['commence_time'],
            'home_team': event['home_team'],
            'away_team': event['away_team']
        }
        records.append(record)
    
    df = pd.DataFrame(records)
    df = fix_commence_time(df)  # Apply timezone conversion
    logger.info(f"Processed {len(df)} events for {sport_key}")
    return df
