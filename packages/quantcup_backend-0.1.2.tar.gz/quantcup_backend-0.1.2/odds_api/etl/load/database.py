"""
Database utilities for odds API data pipeline.
Handles database connections, data loading, and deduplication.
Adapted from nflfastR patterns for odds data.
"""

from sqlalchemy import create_engine, text
import pandas as pd
import logging

# Import shared database utilities
from commonv2 import upsert_dataframe, get_table_row_count, get_all_table_row_counts, db_session
from commonv2 import apply_cleaning

# Import configuration
from ...infra.config import MARKET_MAP, get_market_ddl, get_market_indexes, get_market_columns
from ...infra.settings import get_settings

__all__ = [
    'db_session',
    'get_db_engine',
    'create_odds_schema_and_tables',
    'upsert_market_data',
    'upsert_all_market_data',
    'prepare_market_dataframe_for_db',
    'get_table_row_count',
    'get_all_table_row_counts',
    'upsert_endpoint_data',
    'prepare_endpoint_dataframe_for_db'
]


def get_db_engine():
    """Create a SQLAlchemy engine for PostgreSQL using pydantic-settings."""
    logging.debug("Initializing database engine...")
    
    settings = get_settings()
    
    engine_url = (
        f"postgresql+psycopg2://{settings.odds_db_user}:{settings.odds_db_password}"
        f"@{settings.odds_db_host}:{settings.odds_db_port}/{settings.odds_db_name}"
    )
    
    try:
        return create_engine(engine_url, pool_pre_ping=True)
    except Exception as e:
        logging.error(f"Failed to create database engine: {e}")
        raise

def create_odds_schema_and_tables(engine, schemas=None, tables=None):
    """Create schemas and tables dynamically from MARKET_MAP."""
    if tables is None:
        tables = list(MARKET_MAP.keys())
    
    # Group tables by schema
    schema_tables = {}
    for table_type in tables:
        if table_type not in MARKET_MAP:
            logging.warning(f"Unknown table type: {table_type}, skipping...")
            continue
        
        table_schema = MARKET_MAP[table_type].get("schema", "markets")
        if table_schema not in schema_tables:
            schema_tables[table_schema] = []
        schema_tables[table_schema].append(table_type)
    
    # If specific schemas provided, filter to those
    if schemas:
        schema_tables = {s: tables for s, tables in schema_tables.items() if s in schemas}
    
    with engine.connect() as conn:
        total_tables = 0
        
        # Create each schema and its tables
        for schema_name, table_list in schema_tables.items():
            # Create schema
            schema_sql = f'CREATE SCHEMA IF NOT EXISTS "{schema_name}";'
            conn.execute(text(schema_sql))
            
            # Create tables and indexes for this schema
            for table_type in table_list:
                # Create table
                table_ddl = get_market_ddl(table_type)  # Uses schema from config
                conn.execute(text(table_ddl))
                
                # Create indexes
                index_ddls = get_market_indexes(table_type)  # Uses schema from config
                for index_ddl in index_ddls:
                    conn.execute(text(index_ddl))
                
                total_tables += 1
        
        conn.commit()
        
        # Log results
        logging.info(f"✓ Database schemas and {total_tables} tables created/verified")
        for schema_name, table_list in schema_tables.items():
            logging.info(f"  Schema '{schema_name}':")
            for table_type in table_list:
                description = MARKET_MAP[table_type]["description"]
                logging.info(f"    - {schema_name}.{table_type} ({description})")


def upsert_any(df, engine, table_key, data_type='endpoint'):
    """Unified upsert function for both market and endpoint data.
    
    Args:
        df: DataFrame to upsert
        engine: SQLAlchemy engine
        table_key: Table name/key
        data_type: 'market' or 'endpoint' to determine processing logic
    
    Returns:
        int: Number of rows affected
    """
    if df.empty:
        logging.info(f"No {table_key} data to insert")
        return 0
    
    # Handle market vs endpoint differences
    if data_type == 'market':
        # Market-specific logic
        market_df = df[df['market_key'] == table_key].copy()
        if market_df.empty:
            logging.info(f"No {table_key} data found in DataFrame")
            return 0
        df_clean = prepare_market_dataframe_for_db(market_df, table_key)
        schema = 'markets'
        
        # Type safety check for odds columns
        odds_cols = [col for col in df_clean.columns if col.endswith('_odds')]
        for col in odds_cols:
            if col in df_clean.columns and df_clean[col].dtype != "Int64":
                raise TypeError(f"{col} is {df_clean[col].dtype}, expected Int64 American odds.")
    else:
        # Endpoint-specific logic
        if table_key not in MARKET_MAP:
            raise ValueError(f"Unknown endpoint type: {table_key}")
        config = MARKET_MAP[table_key]
        schema = config.get("schema", "markets")
        df_clean = prepare_endpoint_dataframe_for_db(df, table_key)
    
    # Unified upsert logic
    logging.info(f"Upserting {len(df_clean)} rows into {schema}.{table_key}...")
    rows_affected = upsert_dataframe(df_clean, engine, table_key, schema)
    
    with engine.connect() as conn:
        row_count = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table_key}"')).scalar()
    
    logging.info(f"✓ {table_key} data upsert complete. {rows_affected} rows affected, {row_count:,} total rows in table")
    return rows_affected

def upsert_market_data(df, engine, market_type, schema='markets'):
    """Insert market-specific odds data with conflict resolution (upsert)."""
    return upsert_any(df, engine, market_type, data_type='market')

def upsert_all_market_data(df, engine, markets=None, schema='markets'):
    """Insert specified market types to their respective tables."""
    if markets is None:
        markets = ['h2h', 'spreads', 'totals']
    
    total_rows = 0
    for market in markets:
        rows_affected = upsert_market_data(df, engine, market, schema)
        total_rows += rows_affected
    
    return total_rows


def prepare_market_dataframe_for_db(df, market_type):
    """Clean and prepare market-specific DataFrame for database insertion using schema map."""
    df_clean = df.copy()
    
    # Get required columns from schema map
    required_columns = get_market_columns(market_type)
    
    # Keep only columns that exist in the DataFrame and are needed for this market
    available_columns = [col for col in required_columns if col in df_clean.columns]
    df_clean = df_clean[available_columns]
    
    # Use centralized cleaning with market-specific configuration
    config = {
        'unique_keys': [],  # Will be determined by table schema
        'type_hints': {
            'commence_time': 'datetime64[ns]',
            'bookmaker_last_update': 'datetime64[ns]'
        }
    }
    return apply_cleaning(df_clean, market_type, config)


def upsert_endpoint_data(df, engine, endpoint_type):
    """Insert endpoint-specific data (leagues, teams, schedule, results, props)."""
    return upsert_any(df, engine, endpoint_type, data_type='endpoint')

def prepare_endpoint_dataframe_for_db(df, endpoint_type):
    """Clean and prepare endpoint-specific DataFrame for database insertion."""
    df_clean = df.copy()
    
    # Get required columns from schema map
    required_columns = get_market_columns(endpoint_type)
    
    # Keep only columns that exist in the DataFrame and are needed for this endpoint
    available_columns = [col for col in required_columns if col in df_clean.columns]
    df_clean = df_clean[available_columns]
    
    # Use centralized cleaning with endpoint-specific configuration
    config = {
        'unique_keys': [],  # Will be determined by table schema
        'type_hints': {
            'commence_time': 'datetime64[ns]',
            'last_update': 'datetime64[ns]',
            'created_at': 'datetime64[ns]',
            'active': 'boolean',
            'has_outrights': 'boolean',
            'completed': 'boolean',
            'home_score': 'Int64',
            'away_score': 'Int64'
        }
    }
    return apply_cleaning(df_clean, endpoint_type, config)
