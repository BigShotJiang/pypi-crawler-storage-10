"""
Shared HTTP utilities for The Odds API.

Centralizes retry logic, rate‑limit handling, quota logging,
and connection‑pooled session usage so the rest of the codebase can
make clean one‑line calls.

Usage example in api.py:
    from .api_core import _api_get
    def fetch_sports_data():
        return _api_get('/v4/sports')
"""

from __future__ import annotations

import logging
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from ...infra.settings import get_settings

logger = logging.getLogger(__name__)

__all__ = [
    'BASE_URL',
    'get_session',
    'close_session',
    '_api_get'
]

# Base URL for all API endpoints
BASE_URL = "https://api.the-odds-api.com"

# Global session for connection pooling
_session = None

def get_session():
    """Get or create a persistent requests session for connection pooling"""
    global _session
    if _session is None:
        _session = requests.Session()
        # Configure session for better performance
        _session.headers.update({
            'User-Agent': 'odds-api-client/1.0',
            'Accept': 'application/json',
            'Connection': 'keep-alive'
        })
        # Connection pooling settings
        adapter = HTTPAdapter(
            pool_connections=10,
            pool_maxsize=20,
            max_retries=0  # We handle retries with tenacity
        )
        _session.mount('https://', adapter)
        _session.mount('http://', adapter)
        logger.debug("Created new HTTP session with connection pooling")
    return _session

def close_session():
    """Close the global session (useful for cleanup)"""
    global _session
    if _session:
        _session.close()
        _session = None
        logger.debug("Closed HTTP session")

# Exceptions worth retrying
_RETRYABLE_EXCEPTIONS = (
    requests.exceptions.RequestException,
    requests.exceptions.Timeout,
)


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type(_RETRYABLE_EXCEPTIONS),
    reraise=True,
)
def _api_get(path: str, **params) -> Any:  # noqa: D401, N802  (private helper is fine)
    """GET *path* from The Odds API and return JSON payload.

    All parameters common to every endpoint (``apiKey`` and ``dateFormat``) are
    applied automatically so the caller only needs to pass what is unique.

    Args:
        path: Endpoint path that follows ``BASE_URL`` – e.g. ``"/v4/sports"``.
        **params: Additional query‑string parameters for the request.

    Returns
    -------
    Any
        Parsed JSON (dict or list) from the response.
    """

    settings = get_settings()
    session = get_session()

    default_params = {
        "apiKey": settings.odds_api_key,
        "dateFormat": "iso",
    }

    url = f"{BASE_URL}{path}"
    response = session.get(url, params={**default_params, **params}, timeout=30)

    if response.status_code == 429:
        logger.warning("Rate limit hit (429). Check API quota and retry later.")
        # Raise so *tenacity* retry kicks in
        raise requests.exceptions.RequestException("Rate limit exceeded")

    response.raise_for_status()

    # Surface remaining‑quota header when present
    if "x-requests-remaining" in response.headers:
        logger.info("API requests remaining: %s", response.headers["x-requests-remaining"])

    return response.json()
