"""
API interaction module for odds data fetching.
Handles HTTP requests, retry logic, and rate limiting.
"""

import logging
from .api_core import _api_get, get_session, close_session, BASE_URL

logger = logging.getLogger(__name__)

__all__ = [
    'fetch_odds_data',
    'fetch_sports_data', 
    'fetch_events_data',
    'fetch_scores_data',
    'fetch_participants_data',
    'fetch_event_odds_data'
]


def fetch_odds_data(sport_key='americanfootball_nfl', markets=None):
    """Fetch odds data with retry logic and rate limit handling"""
    if markets is None:
        markets = ['h2h', 'spreads', 'totals']
    return _api_get(
        f"/v4/sports/{sport_key}/odds",
        regions="us",
        markets=",".join(markets),
        oddsFormat="american"
    )


def fetch_sports_data():
    """Fetch sports list - GET /v4/sports (no quota cost)"""
    return _api_get("/v4/sports")


def fetch_events_data(sport_key='americanfootball_nfl'):
    """Fetch events list - GET /v4/sports/{sport}/events (no quota cost)"""
    return _api_get(f"/v4/sports/{sport_key}/events")


def fetch_scores_data(sport_key='americanfootball_nfl', days_from=None):
    """Fetch scores - GET /v4/sports/{sport}/scores"""
    params = {}
    # Only add daysFrom if it's a valid integer 1-3
    if days_from and isinstance(days_from, int) and 1 <= days_from <= 3:
        params['daysFrom'] = str(days_from)
    return _api_get(f"/v4/sports/{sport_key}/scores", **params)


def fetch_participants_data(sport_key='americanfootball_nfl'):
    """Fetch participants - GET /v4/sports/{sport}/participants"""
    return _api_get(f"/v4/sports/{sport_key}/participants")


def fetch_event_odds_data(sport_key, event_id, markets=None):
    """Fetch event-specific odds - GET /v4/sports/{sport}/events/{eventId}/odds"""
    params = {
        'regions': 'us',
        'oddsFormat': 'american'
    }
    if markets:
        params['markets'] = ','.join(markets) if isinstance(markets, list) else markets
    return _api_get(f"/v4/sports/{sport_key}/events/{event_id}/odds", **params)
