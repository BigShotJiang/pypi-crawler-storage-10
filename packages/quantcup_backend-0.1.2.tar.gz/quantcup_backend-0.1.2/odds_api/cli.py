"""
CLI interface for odds API operations.

Provides a modern Typer-based CLI that wraps the existing pipeline
functionality without changing the underlying business logic.
"""

from typing import List, Optional
import typer
from pathlib import Path

# Import shared CLI utilities
from commonv2 import (
    opt_verbose, opt_dry_run, opt_config, opt_workers, opt_season, opt_force, opt_no_cache,
    parse_seasons_or_none, echo_success, echo_error, echo_info, echo_warning, ExitCodes
)
from commonv2 import NFLfastRError, handle_cli_error

# Import existing pipeline components
from .infra.config import SUPPORTED_SPORTS, MARKET_MAP, validate_sport_and_markets
from .pipeline import (
    load_odds_to_database,
    load_leagues_to_database,
    load_teams_to_database,
    load_schedule_to_database,
    load_results_to_database,
    load_props_to_database
)

app = typer.Typer(help="Sports betting odds and market data operations")


@app.command("list-sports")
def list_sports_cmd():
    """List available sports and their keys."""
    try:
        echo_info("Available sports:")
        for sport_key, sport_name in SUPPORTED_SPORTS.items():
            echo_info(f"  {sport_key}: {sport_name}")
        
        echo_info(f"\nTotal: {len(SUPPORTED_SPORTS)} sports available")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=False)
        raise typer.Exit(exit_code)


@app.command("list-markets")
def list_markets_cmd():
    """List available market types and endpoints."""
    try:
        echo_info("Available markets and endpoints:")
        
        # Group by schema for better organization
        by_schema = {}
        for market_key, config in MARKET_MAP.items():
            schema = config.get('schema', 'unknown')
            if schema not in by_schema:
                by_schema[schema] = []
            by_schema[schema].append((market_key, config))
        
        for schema, items in by_schema.items():
            echo_info(f"\n{schema.upper()} Schema:")
            for market_key, config in items:
                description = config.get('description', 'No description')
                uses_quota = config.get('uses_quota', False)
                quota_str = " (uses quota)" if uses_quota else " (no quota)"
                echo_info(f"  {market_key}: {description}{quota_str}")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=False)
        raise typer.Exit(exit_code)


@app.command("run")
def run_cmd(
    # Sport and market selection
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key (use list-sports to see options)"),
    markets: str = typer.Option("h2h,spreads,totals", "--markets", help="Comma-separated market types"),
    
    # Output options
    csv: bool = typer.Option(False, "--csv", help="Also write CSV files"),
    
    # Standard options
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
    config: Optional[str] = opt_config(),
):
    """
    Load odds data for specified sport and markets.
    
    This is the main command for loading betting odds data.
    
    Examples:
        # Load NFL odds for all markets
        quantcup odds run --sport americanfootball_nfl
        
        # Load NBA moneyline odds only
        quantcup odds run --sport basketball_nba --markets h2h
        
        # Load with CSV export
        quantcup odds run --sport americanfootball_nfl --csv
    """
    try:
        # Validate sport and markets
        markets_list = validate_sport_and_markets(sport, markets)
        sport_name = SUPPORTED_SPORTS[sport]
        
        if dry_run:
            echo_info("DRY RUN - Would load odds data:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            echo_info(f"  Markets: {', '.join(markets_list)}")
            if csv:
                echo_info("  Output: Database + CSV files")
            else:
                echo_info("  Output: Database only")
            echo_success("Dry run completed")
            return
        
        echo_info(f"Loading {sport_name} odds for markets: {', '.join(markets_list)}")
        
        # Load odds data using existing pipeline
        rows_processed = load_odds_to_database(
            write_csv=csv,
            sport_key=sport,
            markets=markets_list
        )
        
        echo_success(f"Odds loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("leagues")
def leagues_cmd(
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
):
    """
    Load sports/leagues reference data.
    
    This endpoint provides information about available sports and leagues.
    Does not use API quota.
    """
    try:
        if dry_run:
            echo_info("DRY RUN - Would load leagues data:")
            echo_info("  Endpoint: sports/leagues")
            echo_info("  Quota usage: None")
            echo_success("Dry run completed")
            return
        
        echo_info("Loading sports/leagues data...")
        rows_processed = load_leagues_to_database()
        echo_success(f"Leagues loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("teams")
def teams_cmd(
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key"),
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
):
    """
    Load teams/participants data for a specific sport.
    
    Does not use API quota.
    """
    try:
        # Validate sport
        if sport not in SUPPORTED_SPORTS:
            raise NFLfastRError(f"Unknown sport: {sport}. Use 'list-sports' to see available options.")
        
        sport_name = SUPPORTED_SPORTS[sport]
        
        if dry_run:
            echo_info("DRY RUN - Would load teams data:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            echo_info("  Quota usage: None")
            echo_success("Dry run completed")
            return
        
        echo_info(f"Loading teams data for {sport_name}...")
        rows_processed = load_teams_to_database(sport_key=sport)
        echo_success(f"Teams loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("schedule")
def schedule_cmd(
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key"),
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
):
    """
    Load schedule/events data for a specific sport.
    
    Does not use API quota.
    """
    try:
        # Validate sport
        if sport not in SUPPORTED_SPORTS:
            raise NFLfastRError(f"Unknown sport: {sport}. Use 'list-sports' to see available options.")
        
        sport_name = SUPPORTED_SPORTS[sport]
        
        if dry_run:
            echo_info("DRY RUN - Would load schedule data:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            echo_info("  Quota usage: None")
            echo_success("Dry run completed")
            return
        
        echo_info(f"Loading schedule data for {sport_name}...")
        rows_processed = load_schedule_to_database(sport_key=sport)
        echo_success(f"Schedule loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("results")
def results_cmd(
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key"),
    days_from: int = typer.Option(3, "--days-from", help="Number of days back to fetch results"),
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
):
    """
    Load results/scores data for a specific sport.
    
    Uses API quota.
    """
    try:
        # Validate sport
        if sport not in SUPPORTED_SPORTS:
            raise NFLfastRError(f"Unknown sport: {sport}. Use 'list-sports' to see available options.")
        
        sport_name = SUPPORTED_SPORTS[sport]
        
        if dry_run:
            echo_info("DRY RUN - Would load results data:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            echo_info(f"  Days back: {days_from}")
            echo_warning("  Quota usage: Yes")
            echo_success("Dry run completed")
            return
        
        echo_info(f"Loading results data for {sport_name} (last {days_from} days)...")
        echo_warning("This operation uses API quota")
        rows_processed = load_results_to_database(sport_key=sport, days_from=days_from)
        echo_success(f"Results loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("props")
def props_cmd(
    event_id: str = typer.Argument(..., help="Event ID to fetch props for"),
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key"),
    markets: Optional[str] = typer.Option(None, "--markets", help="Comma-separated prop market types"),
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
):
    """
    Load props/event-specific odds data for a specific event.
    
    Uses API quota.
    """
    try:
        # Validate sport
        if sport not in SUPPORTED_SPORTS:
            raise NFLfastRError(f"Unknown sport: {sport}. Use 'list-sports' to see available options.")
        
        sport_name = SUPPORTED_SPORTS[sport]
        markets_list = markets.split(',') if markets else None
        
        if dry_run:
            echo_info("DRY RUN - Would load props data:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            echo_info(f"  Event ID: {event_id}")
            if markets_list:
                echo_info(f"  Markets: {', '.join(markets_list)}")
            echo_warning("  Quota usage: Yes")
            echo_success("Dry run completed")
            return
        
        echo_info(f"Loading props data for event {event_id} in {sport_name}...")
        echo_warning("This operation uses API quota")
        rows_processed = load_props_to_database(
            sport_key=sport,
            event_id=event_id,
            markets=markets_list
        )
        echo_success(f"Props loading completed - {rows_processed:,} rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("pipeline")
def pipeline_cmd(
    sport: str = typer.Option("americanfootball_nfl", "--sport", help="Sport key"),
    all_data: bool = typer.Option(False, "--all", help="Load all data types (odds + reference data)"),
    reference_only: bool = typer.Option(False, "--reference-only", help="Load only reference data (no quota)"),
    
    # Individual flags for reference data
    leagues: bool = typer.Option(False, "--leagues", help="Include leagues data"),
    teams: bool = typer.Option(False, "--teams", help="Include teams data"),
    schedule: bool = typer.Option(False, "--schedule", help="Include schedule data"),
    results: bool = typer.Option(False, "--results", help="Include results data (uses quota)"),
    
    # Options for quota-using operations
    markets: str = typer.Option("h2h,spreads,totals", "--markets", help="Markets for odds data"),
    days_from: int = typer.Option(3, "--days-from", help="Days back for results"),
    csv: bool = typer.Option(False, "--csv", help="Also write CSV files for odds"),
    
    # Standard options
    verbose: bool = opt_verbose(),
    dry_run: bool = opt_dry_run(),
    config: Optional[str] = opt_config(),
):
    """
    Run bulk data loading operations.
    
    Examples:
        # Load all data for NFL
        quantcup odds pipeline --sport americanfootball_nfl --all
        
        # Load only reference data (no quota usage)
        quantcup odds pipeline --sport americanfootball_nfl --reference-only
        
        # Load specific data types
        quantcup odds pipeline --sport americanfootball_nfl --leagues --teams --schedule
    """
    try:
        # Validate sport
        if sport not in SUPPORTED_SPORTS:
            raise NFLfastRError(f"Unknown sport: {sport}. Use 'list-sports' to see available options.")
        
        sport_name = SUPPORTED_SPORTS[sport]
        
        # Validate mutually exclusive options
        if all_data and reference_only:
            raise NFLfastRError("Cannot specify both --all and --reference-only")
        
        # Determine what to load
        load_plan = []
        quota_operations = []
        
        if reference_only:
            # Default to all reference data if none specified
            if not any([leagues, teams, schedule]):
                leagues = teams = schedule = True
            
            if leagues:
                load_plan.append(("leagues", "Load leagues data", False))
            if teams:
                load_plan.append(("teams", f"Load teams data for {sport_name}", False))
            if schedule:
                load_plan.append(("schedule", f"Load schedule data for {sport_name}", False))
                
        elif all_data:
            # Load everything
            load_plan = [
                ("leagues", "Load leagues data", False),
                ("teams", f"Load teams data for {sport_name}", False),
                ("schedule", f"Load schedule data for {sport_name}", False),
                ("results", f"Load results data for {sport_name}", True),
                ("odds", f"Load odds data for {sport_name}", True),
            ]
            quota_operations = ["results", "odds"]
            
        else:
            # Load based on individual flags
            if leagues:
                load_plan.append(("leagues", "Load leagues data", False))
            if teams:
                load_plan.append(("teams", f"Load teams data for {sport_name}", False))
            if schedule:
                load_plan.append(("schedule", f"Load schedule data for {sport_name}", False))
            if results:
                load_plan.append(("results", f"Load results data for {sport_name}", True))
                quota_operations.append("results")
            
            # Default to odds if no specific operations requested
            if not load_plan:
                markets_list = validate_sport_and_markets(sport, markets)
                load_plan.append(("odds", f"Load odds data for {sport_name}", True))
                quota_operations.append("odds")
        
        if not load_plan:
            raise NFLfastRError("No operations specified. Use --all, --reference-only, or specific flags.")
        
        if dry_run:
            echo_info("DRY RUN - Would execute pipeline:")
            echo_info(f"  Sport: {sport} ({sport_name})")
            for operation, description, uses_quota in load_plan:
                quota_str = " (uses quota)" if uses_quota else " (no quota)"
                echo_info(f"  - {description}{quota_str}")
            if quota_operations:
                echo_warning(f"  Quota-using operations: {', '.join(quota_operations)}")
            echo_success("Dry run completed")
            return
        
        # Execute the pipeline
        echo_info(f"Starting pipeline for {sport_name}...")
        if quota_operations:
            echo_warning(f"This pipeline includes quota-using operations: {', '.join(quota_operations)}")
        
        total_rows = 0
        
        for operation, description, uses_quota in load_plan:
            echo_info(f"\n▶ {description}...")
            
            try:
                if operation == "leagues":
                    rows = load_leagues_to_database()
                elif operation == "teams":
                    rows = load_teams_to_database(sport_key=sport)
                elif operation == "schedule":
                    rows = load_schedule_to_database(sport_key=sport)
                elif operation == "results":
                    rows = load_results_to_database(sport_key=sport, days_from=days_from)
                elif operation == "odds":
                    markets_list = validate_sport_and_markets(sport, markets)
                    rows = load_odds_to_database(
                        write_csv=csv,
                        sport_key=sport,
                        markets=markets_list
                    )
                else:
                    raise NFLfastRError(f"Unknown operation: {operation}")
                
                total_rows += rows
                echo_success(f"✓ {operation}: {rows:,} rows processed")
                
            except Exception as e:
                echo_error(f"✗ {operation} failed: {e}")
                raise
        
        echo_success(f"\nPipeline completed successfully - {total_rows:,} total rows processed")
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=verbose)
        raise typer.Exit(exit_code)


@app.command("status")
def status_cmd():
    """Show odds API status and configuration."""
    try:
        echo_info("Odds API Status:")
        echo_info(f"  Supported sports: {len(SUPPORTED_SPORTS)}")
        echo_info(f"  Available markets: {len(MARKET_MAP)}")
        
        # Show quota vs non-quota operations
        quota_ops = [k for k, v in MARKET_MAP.items() if v.get('uses_quota', False)]
        no_quota_ops = [k for k, v in MARKET_MAP.items() if not v.get('uses_quota', False)]
        
        echo_info(f"  Quota operations: {len(quota_ops)} ({', '.join(quota_ops)})")
        echo_info(f"  No-quota operations: {len(no_quota_ops)} ({', '.join(no_quota_ops)})")
        
        # Here we could add database connection status, last run info, etc.
        
    except Exception as e:
        exit_code = handle_cli_error(e, verbose=False)
        raise typer.Exit(exit_code)


@app.callback()
def main():
    """
    Sports betting odds and market data operations.
    
    Use subcommands for specific operations:
    - list-sports: Show available sports
    - list-markets: Show available markets and endpoints
    - run: Load odds data (main operation)
    - leagues: Load sports/leagues reference data
    - teams: Load teams/participants data
    - schedule: Load schedule/events data
    - results: Load results/scores data
    - props: Load props/event-specific odds
    - pipeline: Bulk operations
    - status: Show API status
    """
    pass


if __name__ == "__main__":
    app()
