"""
Pipeline orchestration - handles ETL workflows without CLI dependencies.
Decoupled from command-line interface for reusability in other contexts.
"""

import logging

from odds_api.etl.transform.odds import get_odds
from odds_api.etl.transform.leagues import get_leagues_data
from odds_api.etl.transform.teams import get_teams_data
from odds_api.etl.transform.schedule import get_schedule_data
from odds_api.etl.transform.results import get_results_data
from odds_api.etl.transform.props import get_props_data
from odds_api.etl.load.database import (
    get_db_engine,
    create_odds_schema_and_tables,
    upsert_all_market_data,
    get_all_table_row_counts,
    upsert_endpoint_data
)
from odds_api.infra.common import log_execution_time, validate_dataframe

logger = logging.getLogger(__name__)

# Pipeline registry - maps endpoint keys to their configuration
PIPELINES = {
    'leagues': {
        'fetch_fn': lambda: get_leagues_data(),
        'required_cols': ['sport_key', 'title', 'active'],
        'table': 'leagues',
        'uses_quota': False,
        'description': 'sports/leagues data'
    },
    'teams': {
        'fetch_fn': lambda sport_key: get_teams_data(sport_key),
        'required_cols': ['participant_id', 'sport_key', 'full_name'],
        'table': 'teams',
        'uses_quota': False,
        'description': 'teams/participants data'
    },
    'schedule': {
        'fetch_fn': lambda sport_key: get_schedule_data(sport_key),
        'required_cols': ['event_id', 'sport_key', 'commence_time', 'home_team', 'away_team'],
        'table': 'schedule',
        'uses_quota': False,
        'description': 'schedule/events data'
    },
    'results': {
        'fetch_fn': lambda sport_key, **kwargs: get_results_data(sport_key, kwargs.get('days_from')),
        'required_cols': ['event_id', 'sport_key', 'commence_time', 'home_team', 'away_team'],
        'table': 'results',
        'uses_quota': True,
        'description': 'results/scores data'
    },
    'props': {
        'fetch_fn': lambda sport_key, **kwargs: get_props_data(sport_key, kwargs.get('event_id'), kwargs.get('markets')),
        'required_cols': ['event_id', 'sport_key', 'bookmaker_key', 'market_key'],
        'table': 'props',
        'uses_quota': True,
        'description': 'props/event-specific odds data'
    }
}

@log_execution_time
def run_pipeline(pipeline_key, **kwargs):
    """Generic pipeline orchestrator that handles any endpoint.
    
    Args:
        pipeline_key: Key from PIPELINES registry (e.g., 'teams', 'results')
        **kwargs: Arguments to pass to the fetch function (sport_key, event_id, etc.)
    
    Returns:
        int: Number of rows inserted/updated
    """
    if pipeline_key not in PIPELINES:
        raise ValueError(f"Unknown pipeline: {pipeline_key}. Available: {list(PIPELINES.keys())}")
    
    config = PIPELINES[pipeline_key]
    description = config['description']
    
    logger.info(f"Starting {description} pipeline...")
    
    try:
        # Step 1: Fetch data using configured function
        logger.info(f"Fetching {description} from API...")
        
        # Handle different function signatures
        if pipeline_key == 'leagues':
            df = config['fetch_fn']()
        elif pipeline_key in ['props']:
            # Props needs special handling for event_id and markets
            sport_key = kwargs.get('sport_key', 'americanfootball_nfl')
            df = config['fetch_fn'](sport_key, **{k: v for k, v in kwargs.items() if k != 'sport_key'})
        else:
            # Teams, schedule, results need sport_key
            sport_key = kwargs.get('sport_key', 'americanfootball_nfl')
            df = config['fetch_fn'](sport_key, **{k: v for k, v in kwargs.items() if k != 'sport_key'})
        
        # Handle empty props data
        if pipeline_key == 'props' and df.empty:
            logger.warning(f"No {description} returned")
            return 0
        
        # Step 2: Validate the data
        validate_dataframe(df, config['required_cols'])
        logger.info(f"Processed {len(df)} {pipeline_key} records")
        
        # Step 3: Set up database connection
        logger.info("Connecting to database...")
        engine = get_db_engine()
        
        # Step 4: Create schema and tables if needed
        create_odds_schema_and_tables(engine, tables=[config['table']])
        
        # Step 5: Insert/update data
        rows_affected = upsert_endpoint_data(df, engine, config['table'])
        
        logger.info(f"✅ {description.title()} pipeline completed successfully")
        return rows_affected
        
    except Exception as e:
        logger.error(f"❌ {description.title()} pipeline failed: {str(e)}")
        raise

@log_execution_time
def load_odds_to_database(write_csv=False, sport_key='americanfootball_nfl', markets=None):
    """
    Main function to fetch odds data and load it into the database.
    
    Args:
        write_csv: Whether to also write CSV files (default: False)
        sport_key: Sport to fetch odds for (default: americanfootball_nfl)
        markets: List of markets to process (default: ['h2h', 'spreads', 'totals'])
    
    Returns:
        int: Number of rows inserted/updated
    """
    if markets is None:
        markets = ['h2h', 'spreads', 'totals']
    logger.info("Starting odds data pipeline...")
    
    try:
        # Step 1: Fetch and process odds data
        logger.info("Fetching odds data from API...")
        df = get_odds(sport_key=sport_key, markets=markets)
        
        # Step 2: Validate the data
        required_columns = ['game_id', 'bookmaker_key', 'market_key', 'commence_time']
        validate_dataframe(df, required_columns)
        
        logger.info(f"Processed {len(df)} odds records")
        
        # Step 3: Set up database connection
        logger.info("Connecting to database...")
        engine = get_db_engine()
        
        # Step 4: Create schema and tables if needed
        create_odds_schema_and_tables(engine, tables=markets)
        
        # Step 5: Get current row counts for comparison
        initial_counts = get_all_table_row_counts(engine)
        total_initial = sum(initial_counts.values())
        logger.info(f"Current database rows: {total_initial:,}")
        for table, count in initial_counts.items():
            logger.info(f"  - {table}: {count:,}")
        
        # Step 6: Insert/update data to specified markets
        rows_affected = upsert_all_market_data(df, engine, markets=markets)
        
        # Step 7: Get final row counts
        final_counts = get_all_table_row_counts(engine)
        total_final = sum(final_counts.values())
        logger.info(f"Final database rows: {total_final:,}")
        for table, count in final_counts.items():
            logger.info(f"  - {table}: {count:,}")
        
        # Step 8: Optionally write CSV files
        if write_csv:
            from .etl.transform.odds import write_market_csvs
            logger.info("Writing CSV files...")
            write_market_csvs(df)
        
        logger.info("✅ Odds data pipeline completed successfully")
        return rows_affected
        
    except Exception as e:
        logger.error(f"❌ Odds data pipeline failed: {str(e)}")
        raise

# Simplified loader functions using the generic pipeline orchestrator
def load_leagues_to_database():
    """Load sports/leagues data to database."""
    return run_pipeline('leagues')

def load_teams_to_database(sport_key='americanfootball_nfl'):
    """Load teams/participants data to database."""
    return run_pipeline('teams', sport_key=sport_key)

def load_schedule_to_database(sport_key='americanfootball_nfl'):
    """Load schedule/events data to database."""
    return run_pipeline('schedule', sport_key=sport_key)

def load_results_to_database(sport_key='americanfootball_nfl', days_from=None):
    """Load results/scores data to database."""
    return run_pipeline('results', sport_key=sport_key, days_from=days_from)

def load_props_to_database(sport_key='americanfootball_nfl', event_id=None, markets=None):
    """Load props/event-specific odds data to database."""
    return run_pipeline('props', sport_key=sport_key, event_id=event_id, markets=markets)
