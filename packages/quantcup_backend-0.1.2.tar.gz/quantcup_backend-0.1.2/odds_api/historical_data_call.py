import requests, time, pandas as pd
from datetime import datetime, timedelta, timezone

API_KEY   = "YOUR_API_KEY"
SPORT     = "americanfootball_nfl"
REGIONS   = "us"
MARKETS   = "h2h,spreads,totals"
BASE_URL  = "https://api.the-odds-api.com/v4/historical/sports"

# choose a start / end ISO-8601 timestamp
start_ts  = datetime(2021, 11, 25, 12, 0, tzinfo=timezone.utc)
end_ts    = datetime(2021, 11, 26, 12, 0, tzinfo=timezone.utc)

snap_delta = timedelta(minutes=10)          # or 5 after 2022-09-18
rows = []

ts = start_ts
while ts <= end_ts:
    url = (f"{BASE_URL}/{SPORT}/odds"
           f"?regions={REGIONS}&markets={MARKETS}"
           f"&date={ts.isoformat()}&apiKey={API_KEY}")
    r = requests.get(url, timeout=30)
    r.raise_for_status()                    # ← will raise if 429/other error
    snap = r.json()
    
    # store header info if you want to monitor credits
    credits_left  = int(r.headers.get("x-requests-remaining", -1))
    cost_this_req = int(r.headers.get("x-requests-last", -1))
    
    # flatten each event into a row (quick-and-dirty)
    for event in snap["data"]:
        for bm in event["bookmakers"]:
            for mkt in bm["markets"]:
                for out in mkt["outcomes"]:
                    rows.append({
                        "snapshot_ts": snap["timestamp"],
                        "event_id":    event["id"],
                        "commence":    event["commence_time"],
                        "home":        event["home_team"],
                        "away":        event["away_team"],
                        "bookmaker":   bm["key"],
                        "market":      mkt["key"],
                        "selection":   out.get("name"),
                        "point":       out.get("point"),
                        "price":       out["price"]
                    })
    
    # simple throttling: stay well below 30 req/s
    time.sleep(0.1)
    ts += snap_delta

df = pd.DataFrame(rows)
print(df.head())
