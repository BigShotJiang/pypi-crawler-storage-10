"""
Common utilities for odds API data pipeline.
Shared helper functions and error handling.
"""

import logging
import functools
from typing import Any, Callable
__all__ = [
    'log_execution_time',
    'validate_dataframe'
]


def log_execution_time(func: Callable) -> Callable:
    """
    Decorator to log function execution time.
    
    Args:
        func: Function to decorate
    
    Returns:
        Decorated function
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        import time
        start_time = time.time()
        logging.info(f"Starting {func.__name__}...")
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logging.info(f"✓ {func.__name__} completed in {execution_time:.2f} seconds")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logging.error(f"✗ {func.__name__} failed after {execution_time:.2f} seconds: {str(e)}")
            raise
    
    return wrapper

def validate_dataframe(df, required_columns=None):
    """
    Validate DataFrame structure and content.
    
    Args:
        df: pandas DataFrame to validate
        required_columns: List of required column names
    
    Returns:
        bool: True if validation passes
    
    Raises:
        ValueError: If validation fails
    """
    if df is None or df.empty:
        raise ValueError("DataFrame is None or empty")
    
    if required_columns:
        missing_columns = set(required_columns) - set(df.columns)
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
    
    logging.debug(f"DataFrame validation passed: {df.shape[0]} rows, {df.shape[1]} columns")
    return True
