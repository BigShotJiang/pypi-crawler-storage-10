"""
Application settings using pydantic-settings.
Centralizes environment variable handling with type safety.
"""

from pydantic_settings import BaseSettings
from typing import Optional

__all__ = ['Settings', 'get_settings']


class Settings(BaseSettings):
    """Application settings with environment variable support."""
    
    # Odds API settings
    odds_api_key: str = ""
    
    # Database settings
    odds_db_host: str = "localhost"
    odds_db_port: int = 5432
    odds_db_user: str = ""
    odds_db_password: str = ""
    odds_db_name: str = ""
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
        "extra": "ignore"  # Allow stray env vars (like nflfastr_* variables)
    }


# Global settings instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton pattern)."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
