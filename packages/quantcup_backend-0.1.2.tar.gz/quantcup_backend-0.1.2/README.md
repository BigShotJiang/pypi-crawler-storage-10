# QuantCup Simple: Comprehensive Sports Analytics Ecosystem

A production-ready, modular sports analytics platform built with the "skinny-but-useful" philosophy. Combines NFL data analytics, machine learning, and sports betting data into a unified ecosystem for research, modeling, and production applications.

## 🎯 Overview

QuantCup Simple is a comprehensive sports analytics ecosystem that transforms raw sports data into sophisticated insights through a multi-stage pipeline. Built for both researchers and production environments, it provides enterprise-grade reliability with minimal complexity.

**Core Philosophy**: "Skinny-but-useful" - Maximum functionality with minimal dependencies and complexity.

**Key Capabilities:**
- ✅ **Complete NFL Analytics Pipeline** - Raw data → Analytics → Features → ML Predictions
- ✅ **Sports Betting Integration** - Real-time odds, lines, and market analysis
- ✅ **NFL Data API Wrapper** - 25+ functions for comprehensive NFL data access
- ✅ **Shared Infrastructure** - Unified database, logging, and configuration management
- ✅ **Machine Learning Ready** - XGBoost models with sophisticated feature engineering
- ✅ **Production Grade** - Robust error handling, logging, and scalability
- ✅ **Modular Design** - Use individual components or the complete system

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           QuantCup Simple Ecosystem                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │   NFL Data  │    │  Odds API   │    │   Common    │    │ API Sports  │  │
│  │   Wrapper   │    │  Pipeline   │    │ Infrastructure │    │   (Future)  │  │
│  │             │    │             │    │             │    │             │  │
│  │ 25+ NFL     │    │ Real-time   │    │ Database    │    │ Multi-sport │  │
│  │ Functions   │    │ Betting     │    │ Logging     │    │ Expansion   │  │
│  │             │    │ Data        │    │ Config      │    │             │  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘  │
│         │                   │                   │                   │       │
│         └───────────────────┼───────────────────┼───────────────────┘       │
│                             │                   │                           │
│  ┌─────────────────────────────────────────────────────────────────────────┐  │
│  │                        NFLfastR Analytics                              │  │
│  │                                                                         │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │  │
│  │  │   Loading   │─▶│  Warehouse  │─▶│  Features   │─▶│     ML      │    │  │
│  │  │             │  │             │  │             │  │             │    │  │
│  │  │ Raw NFL     │  │ Analytics   │  │ Feature     │  │ Predictive  │    │  │
│  │  │ Data        │  │ Schema      │  │ Engineering │  │ Models      │    │  │
│  │  │ (24 tables) │  │ (8 tables)  │  │ (3 sets)    │  │ (XGBoost)   │    │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘    │  │
│  └─────────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────┐  │
│  │                         Data Storage Layer                             │  │
│  │                                                                         │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │  │
│  │  │ PostgreSQL  │  │ PostgreSQL  │  │ PostgreSQL  │  │   Shared    │    │  │
│  │  │             │  │             │  │             │  │             │    │  │
│  │  │ nflreadr    │  │ odds_api    │  │nfl_data_py  │  │ Utilities   │    │  │
│  │  │ Database    │  │ Database    │  │ Database    │  │ & Logging   │    │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘    │  │
│  └─────────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Flow

```
Raw Sources → Extraction → Transformation → Analytics → Features → Predictions
     ↓             ↓            ↓            ↓          ↓           ↓
NFL Data API   nfl_data_py   Warehouse   Analytics   Features    ML Models
Odds API    →  odds_api   →  Schema   →  Tables   →  Engine   →  XGBoost
Team Data      common        Facts       Dims        Rolling     Outcomes
```

## 🎯 Unified CLI

**NEW**: QuantCup Simple now provides a unified command-line interface that serves as a single entry point for the entire ecosystem.

### Command Structure

```bash
# Unified CLI entry point
python -m quantcup [module] [command] [options]

# NFLfastR Analytics Pipeline
python -m quantcup nflfastr loader [args]      # Data loading
python -m quantcup nflfastr warehouse [args]   # Analytics warehouse
python -m quantcup nflfastr features [args]    # Feature engineering
python -m quantcup nflfastr ml [args]          # Machine learning
python -m quantcup nflfastr pipeline [options] # Complete pipeline

# Sports Betting Data
python -m quantcup odds [args]                 # Odds API pipeline

# Future expansion ready
# python -m quantcup api-sports [args]         # Multi-sport data (planned)
```

### Pipeline Command - Production Ready

The `pipeline` command provides enterprise-grade orchestration with advanced features:

```bash
# Complete end-to-end pipeline
python -m quantcup nflfastr pipeline

# Season-specific processing
python -m quantcup nflfastr pipeline --season 2024

# Selective phase execution
python -m quantcup nflfastr pipeline --only features
python -m quantcup nflfastr pipeline --skip-loader

# Production features
python -m quantcup nflfastr pipeline \
  --season 2024 \
  --lock /var/lock/quantcup.lock \
  --run-id "daily-$(date +%Y%m%d)" \
  --continue-on-error

# Advanced argument forwarding
python -m quantcup nflfastr pipeline \
  --loader-args "--group fantasy --strategy incremental" \
  --features-args "--feature-set experimental" \
  --ml-args "--model xgb_v2 --hyperopt"
```

### Pipeline Features

✅ **Smart Argument Forwarding**: Pass specific arguments to individual phases  
✅ **Production Locking**: Prevent overlapping runs with file-based locks  
✅ **Run ID Correlation**: Track operations across phases with `QUANTCUP_RUN_ID`  
✅ **Flexible Execution**: Skip phases, run only specific phases, continue on error  
✅ **Season Intelligence**: Automatically forwards `--season` to compatible phases  
✅ **Real-time Streaming**: Live output from all phases  
✅ **Comprehensive Reporting**: Detailed success/failure summaries  

### CLI Features

**Shell Completion**: The unified CLI supports auto-completion for commands and options:

```bash
# Install completion for your shell
python -m quantcup --install-completion

# Or show completion script to customize
python -m quantcup --show-completion
```

**Cross-Platform Argument Quoting**: When using argument forwarding, quote properly for your shell:

```bash
# Bash/Linux/macOS
python -m quantcup nflfastr pipeline --loader-args "--group fantasy --strategy incremental"

# PowerShell/Windows
python -m quantcup nflfastr pipeline --loader-args "--group fantasy --strategy incremental"

# Command Prompt/Windows (escape quotes)
python -m quantcup nflfastr pipeline --loader-args """--group fantasy --strategy incremental"""
```

**Version Information**:

```bash
# Check version
python -m quantcup --version
quantcup --version  # If installed via pip
```

## 🚀 Quick Start

### Prerequisites

1. **Python 3.8+** with pip
2. **R 4.0+** with nflfastR and nflreadr packages
3. **PostgreSQL 12+** database server
4. **API Keys** (optional):
   - The Odds API key for betting data
   - API Sports key for additional sports data

### Installation

```bash
# 1. Clone the repository
git clone <repository-url>
cd quantcup-simple

# 2. Install Python dependencies for each module
pip install -r nflfastR/requirements.txt
pip install -r odds_api/requirements.txt
# nfl_data_py uses standard packages (pandas, nfl_data_py)

# 3. Install R packages
R -e "install.packages(c('nflfastR', 'nflreadr'))"

# 4. Configure environment
cp .env.example .env
# Edit .env with your database credentials and API keys
```

### Environment Configuration

Create a `.env` file in the root directory:

```bash
# =============================================================================
# QuantCup Simple Configuration
# =============================================================================

# -----------------------------------------------------------------------------
# API Keys (Optional - for specific modules)
# -----------------------------------------------------------------------------
ODDS_API_KEY=your_odds_api_key_here
API_SPORTS_API_KEY=your_api_sports_key_here

# -----------------------------------------------------------------------------
# NFLfastR Database Configuration
# -----------------------------------------------------------------------------
NFLFASTR_DB_HOST=localhost
NFLFASTR_DB_PORT=5432
NFLFASTR_DB_USER=postgres
NFLFASTR_DB_PASSWORD=your_password
NFLFASTR_DB_NAME=nflreadr

# -----------------------------------------------------------------------------
# Odds API Database Configuration
# -----------------------------------------------------------------------------
ODDS_API_DB_HOST=localhost
ODDS_API_DB_PORT=5432
ODDS_API_DB_USER=postgres
ODDS_API_DB_PASSWORD=your_password
ODDS_API_DB_NAME=odds_api

# -----------------------------------------------------------------------------
# NFL Data Python Database Configuration
# -----------------------------------------------------------------------------
NFL_DATA_PY_DB_HOST=localhost
NFL_DATA_PY_DB_PORT=5432
NFL_DATA_PY_DB_USER=postgres
NFL_DATA_PY_DB_PASSWORD=your_password
NFL_DATA_PY_DB_NAME=nfl_data_py

# -----------------------------------------------------------------------------
# Global Settings
# -----------------------------------------------------------------------------
NFLFASTR_VERBOSE=1
ODDS_API_VERBOSE=1
NFL_DATA_PY_VERBOSE=1
QUANTCUP_VERBOSE=1
```

### Database Setup

```bash
# Create databases for each module
createdb nflreadr
createdb odds_api
createdb nfl_data_py

# Test connections
python -c "from common.database import create_db_engine_from_env; print('✅ Database connections OK')"
```

### Quick Test Run

```bash
# Test each module
python -c "import nfl_data_py; print('✅ NFL Data Py OK')"  # Test NFL data access
python -m quantcup odds --help                             # Test odds API
python -m quantcup nflfastr loader --help                  # Test NFLfastR

# Run a complete pipeline (if you have data)
python -m quantcup nflfastr loader     # Load NFL data
python -m quantcup nflfastr warehouse  # Build analytics
python -m quantcup nflfastr features   # Engineer features
python -m quantcup nflfastr ml pipeline # Train and predict
```

## 📊 Module Directory

### 🏈 [NFLfastR Analytics & ML Pipeline](nflfastR/README.md)
**The core analytics engine** - Transforms raw NFL data into sophisticated predictive models.

- **Purpose**: Complete NFL analytics pipeline from raw data to ML predictions
- **Components**: Loading (24 tables) → Warehouse (8 tables) → Features (3 sets) → ML (XGBoost)
- **Output**: Game predictions, player analytics, team efficiency metrics
- **Use Cases**: Game prediction, player evaluation, team analysis, research

```bash
# Complete pipeline
python -m nflfastR.run_loader     # Load 24 NFL datasets
python -m nflfastR.run_warehouse  # Build dimensional model
python -m nflfastR.run_features   # Engineer ML features
python -m nflfastR.run_ml pipeline # Train models & predict
```

### 💰 [Odds API Data Pipeline](odds_api/README.md)
**Sports betting data integration** - Real-time odds, lines, and market analysis.

- **Purpose**: Comprehensive sports betting data pipeline
- **Data Types**: Odds, spreads, totals, props, schedules, results, teams
- **Sports**: NFL, NBA, MLB, NHL, NCAA Football/Basketball
- **Output**: Multi-schema database with market analysis and CSV exports

```bash
# Load betting data
python -m odds_api --sport americanfootball_nfl --markets h2h,spreads,totals
python -m odds_api --all --sport basketball_nba
```

### 📊 [NFL Data Python Wrapper](nfl_data_py/README.md)
**Robust NFL data access** - Production-ready wrapper for nfl_data_py library.

- **Purpose**: Enhanced NFL data access with enterprise features
- **Functions**: 25+ NFL data functions with retry logic and caching
- **Features**: Session management, memory optimization, error handling
- **Integration**: Seamless integration with other quantcup-simple modules

```python
import nfl_data_py as nfl_api
pbp_data = nfl_api.import_pbp_data([2023, 2024])
teams = nfl_api.import_team_desc()
```

### 🏛️ [Common Infrastructure](common/README.md)
**Shared foundation** - Database utilities, logging, configuration, and team mapping.

- **Purpose**: Unified infrastructure for all quantcup-simple modules
- **Components**: Database operations, logging setup, configuration validation, data cleaning
- **Benefits**: Consistency, reduced duplication, centralized management
- **Integration**: Used by all other modules for core operations

```python
from common.database import create_db_engine_from_env, upsert_dataframe
from common.logging import setup_nflfastr_logger
```

### 🚀 [API Sports Integration](api_sports/) *(Future Expansion)*
**Multi-sport data access** - Planned expansion for comprehensive sports coverage.

- **Purpose**: Extend beyond NFL to NBA, MLB, NHL, and international sports
- **Status**: Framework in place, ready for development
- **Integration**: Will leverage common infrastructure and patterns

## 📈 Example Workflows

### Complete NFL Analytics Pipeline

```bash
# NEW: Unified CLI approach (recommended)
# Complete pipeline in one command
python -m quantcup nflfastr pipeline --season 2024

# Or step-by-step with unified CLI
python -m quantcup nflfastr loader --season 2024
python -m quantcup nflfastr warehouse
python -m quantcup nflfastr features --season 2024
python -m quantcup nflfastr ml pipeline

# Production workflow with advanced features
python -m quantcup nflfastr pipeline \
  --season 2024 \
  --lock /var/lock/quantcup.lock \
  --run-id "daily-$(date +%Y%m%d)" \
  --loader-args "--group nfl_data" \
  --ml-args "--model xgb_ensemble"

# Legacy approach (still works)
python -m nflfastR.run_loader
python -m nflfastR.run_warehouse
python -m nflfastR.run_features
python -m nflfastR.run_ml pipeline

# View results
python -c "
from common.database import create_db_engine_from_env
import pandas as pd
engine = create_db_engine_from_env('NFLFASTR_DB')
predictions = pd.read_sql('SELECT * FROM ml_predictions ORDER BY prediction_date DESC LIMIT 10', engine)
print(predictions)
"
```

### Sports Betting Analysis

```bash
# NEW: Unified CLI approach (recommended)
# 1. Load current NFL odds and schedules
python -m quantcup odds --sport americanfootball_nfl --markets h2h,spreads,totals
python -m quantcup odds --schedule --sport americanfootball_nfl

# 2. Load historical results for analysis
python -m quantcup odds --results --sport americanfootball_nfl

# 3. Export for analysis
python -m quantcup odds --sport americanfootball_nfl --csv

# 4. Complete data loading in one command
python -m quantcup odds --all --sport americanfootball_nfl

# Legacy approach (still works)
python -m odds_api --sport americanfootball_nfl --markets h2h,spreads,totals
python -m odds_api --schedule --sport americanfootball_nfl

# 5. Combine with NFL analytics
python -c "
from common.database import create_db_engine_from_env
import pandas as pd

# Load odds data
odds_engine = create_db_engine_from_env('ODDS_API_DB')
odds = pd.read_sql('SELECT * FROM markets.h2h WHERE sport_key = \"americanfootball_nfl\"', odds_engine)

# Load NFL predictions
nfl_engine = create_db_engine_from_env('NFLFASTR_DB')
predictions = pd.read_sql('SELECT * FROM ml_predictions', nfl_engine)

# Merge for comprehensive analysis
combined = odds.merge(predictions, on=['home_team', 'away_team', 'game_date'])
print(f'Combined dataset: {len(combined)} records')
"
```

### Research & Development

```python
# Custom analysis combining all data sources
import pandas as pd
import nfl_data_py as nfl_api
from common.database import create_db_engine_from_env

# 1. Load NFL data using wrapper
pbp_data = nfl_api.import_pbp_data([2023, 2024])
weekly_stats = nfl_api.import_weekly_data([2023, 2024])

# 2. Access analytics warehouse
engine = create_db_engine_from_env('NFLFASTR_DB')
team_efficiency = pd.read_sql('SELECT * FROM features.team_efficiency', engine)

# 3. Load betting market data
odds_engine = create_db_engine_from_env('ODDS_API_DB')
market_data = pd.read_sql('SELECT * FROM markets.spreads', odds_engine)

# 4. Combine for comprehensive analysis
# Your custom research code here
```

## 🛠️ Development & Extension

### Adding New Sports

The system is designed for easy expansion to new sports:

```python
# 1. Add sport configuration to odds_api
# 2. Extend common.team_mapping for new sport
# 3. Create sport-specific analytics in nflfastR pattern
# 4. Leverage shared infrastructure
```

### Custom Feature Engineering

```python
# Extend NFLfastR features
def build_custom_features(engine, season=None):
    """Add your custom feature engineering"""
    # Access analytics warehouse
    # Create new features
    # Store in features schema
    pass
```

### Integration with External Systems

```python
# Example: Airflow integration
from odds_api.pipeline import load_odds_to_database
from nflfastR.run_ml import run_ml_pipeline

def daily_sports_pipeline():
    # Load fresh odds data
    load_odds_to_database(['americanfootball_nfl'])
    
    # Update ML predictions
    run_ml_pipeline()
    
    # Your custom logic here
```

## 🔧 Configuration Management

### Environment Variables

The system uses project-specific prefixes for clean separation:

- **NFLFASTR_DB_*** - NFLfastR database configuration
- **ODDS_API_DB_*** - Odds API database configuration  
- **NFL_DATA_PY_DB_*** - NFL Data Python database configuration
- **QUANTCUP_*** - Global settings

### Database Architecture

- **Same PostgreSQL Server**: All projects can share infrastructure
- **Separate Databases**: Each module maintains isolation
- **Shared Utilities**: Common database operations across all modules
- **Consistent Patterns**: Standardized schema and table management

### Logging System

Centralized logging with module-specific files:

```
logs/
├── nflfastr_loading.log     # Data loading operations
├── warehouse.log            # Analytics warehouse building
├── features.log             # Feature engineering
├── ml_training.log          # Model training
├── ml_predictions.log       # Prediction generation
├── odds_api.log            # Odds API operations
└── test.log                # Development and testing
```

## 📚 Documentation

### Module-Specific Documentation
- **[NFLfastR README](nflfastR/README.md)** - Complete analytics pipeline
- **[Odds API README](odds_api/README.md)** - Sports betting data
- **[NFL Data Py README](nfl_data_py/README.md)** - NFL data wrapper
- **[Common README](common/README.md)** - Shared infrastructure

### Detailed Component Documentation
- **[NFLfastR Loading](nflfastR/loading/README.md)** - Data loading details
- **[NFLfastR Warehouse](nflfastR/warehouse/README.md)** - Analytics schema
- **[NFLfastR Features](nflfastR/features/README.md)** - Feature engineering
- **[NFLfastR ML](nflfastR/ml/README.md)** - Machine learning pipeline

### Technical Documentation
- **[Pipeline Overview](nflfastR/docs/pipeline_overview.md)** - System architecture
- **[Data Dictionary](nflfastR/docs/data_dictionary.md)** - Schema reference
- **[Feature Documentation](nflfastR/docs/features/)** - Feature specifications

## 🔍 Troubleshooting

### Common Issues

#### Database Connection Problems
```bash
# Test all database connections
python -c "
from common.database import create_db_engine_from_env
for prefix in ['NFLFASTR_DB', 'ODDS_API_DB', 'NFL_DATA_PY_DB']:
    try:
        engine = create_db_engine_from_env(prefix)
        print(f'✅ {prefix} connection OK')
    except Exception as e:
        print(f'❌ {prefix} connection failed: {e}')
"
```

#### Module Import Issues
```bash
# Verify module installations
python -c "import pandas, sqlalchemy, psycopg2; print('✅ Core packages OK')"
python -c "import nfl_data_py; print('✅ NFL Data Py OK')"
python -c "import xgboost; print('✅ XGBoost OK')"
```

#### R Package Issues
```bash
# Test R packages
R -e "library(nflfastR); library(nflreadr); print('✅ R packages OK')"
```

### Getting Help

1. **Check module-specific READMEs** for detailed troubleshooting
2. **Review log files** in the `logs/` directory
3. **Verify environment configuration** in `.env` file
4. **Test individual components** before running complete pipelines

## 📊 Performance & Scalability

### System Requirements

- **Memory**: 8GB+ recommended for full NFL dataset processing
- **Storage**: 10GB+ for complete historical data
- **CPU**: Multi-core recommended for ML training
- **Database**: PostgreSQL with sufficient storage for multiple schemas

### Performance Optimization

- **Chunked Processing**: Large datasets processed in manageable chunks
- **Connection Pooling**: Efficient database connection management
- **Caching**: Strategic caching for frequently accessed data
- **Vectorized Operations**: Pandas/NumPy optimizations throughout

### Scalability Features

- **Modular Architecture**: Scale individual components independently
- **Database Separation**: Isolate workloads across databases
- **Incremental Processing**: Load only new/updated data
- **Parallel Execution**: Multiple modules can run simultaneously

## 🤝 Contributing

### Development Setup

1. **Fork the repository** and create a feature branch
2. **Install development dependencies** for relevant modules
3. **Follow existing patterns** and architectural principles
4. **Add comprehensive tests** for new functionality
5. **Update documentation** including READMEs and docstrings

### Code Style Guidelines

- **Python**: Follow PEP 8, use type hints, comprehensive docstrings
- **SQL**: Clear, readable queries with proper formatting
- **Documentation**: Update both module and root-level documentation
- **Logging**: Use centralized logging system consistently

### Adding New Modules

1. **Follow established patterns** from existing modules
2. **Integrate with common infrastructure** for consistency
3. **Add comprehensive README** following existing format
4. **Update root README** to include new module
5. **Ensure database isolation** with appropriate prefixes

## 📄 License

This project is designed for educational and research purposes. Please ensure compliance with data source terms of service and applicable regulations.

## 🙏 Acknowledgments

- **nflfastR Team**: For comprehensive NFL data and R packages
- **nfl_data_py**: For Python NFL data access
- **The Odds API**: For sports betting data access
- **Open Source Community**: For the tools and libraries that make this possible

---

**QuantCup Simple** - A comprehensive sports analytics ecosystem built with the "skinny-but-useful" philosophy. Maximum functionality, minimal complexity, production-ready reliability.

*Transform raw sports data into sophisticated insights with enterprise-grade infrastructure and modular design.*
