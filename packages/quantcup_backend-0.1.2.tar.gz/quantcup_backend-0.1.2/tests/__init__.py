"""
Test package for QuantCup.
"""
