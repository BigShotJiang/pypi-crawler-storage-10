"""
Configuration validation utilities for quantcup-simple projects.

This module provides validation for environment variables and system configuration
to ensure applications fail fast with clear error messages if misconfigured.
"""

import os
from dataclasses import dataclass
from dotenv import load_dotenv
from sqlalchemy.engine.url import make_url
from .logging import get_logger

# Module-level logger for simple utilities (following database.py pattern)
_logger = get_logger('commonv2.core.config')


class ConfigError(Exception):
    """Configuration validation error."""
    pass


@dataclass(frozen=True)
class DatabaseConfig:
    """Value object for database configuration with validation."""
    host: str
    port: int
    user: str
    password: str
    database: str
    
    @classmethod
    def from_env(cls, database_name: str) -> "DatabaseConfig":
        """
        DEPRECATED: Create config from environment variables with explicit database name.
        
        This method is deprecated. Use table-aware functions for parameter-free configuration.
        
        Args:
            database_name: Database name (e.g., 'NFLFASTR_DB', 'SEVALLA_QUANTCUP_DB')
        
        Returns:
            DatabaseConfig instance
            
        Raises:
            ConfigError: If required variables are missing or invalid
        """
        import warnings
        warnings.warn(
            "DatabaseConfig.from_env() is deprecated. Use table-aware functions for parameter-free configuration.",
            DeprecationWarning,
            stacklevel=2
        )
        
        return cls._from_env_internal(database_name)
    
    @classmethod
    def _from_env_internal(cls, database_name: str) -> "DatabaseConfig":
        """
        Internal method: Create config from environment variables with explicit database name.
        
        This is the internal implementation that still takes database parameters.
        Use table-aware functions for parameter-free configuration.
        
        Args:
            database_name: Database name (e.g., 'NFLFASTR_DB', 'SEVALLA_QUANTCUP_DB')
        
        Returns:
            DatabaseConfig instance
            
        Raises:
            ConfigError: If required variables are missing or invalid
        """
        load_dotenv()
        
        # Support full URL override
        url_env = os.getenv(f"{database_name}_URL")
        if url_env:
            try:
                url = make_url(url_env)
                if not all([url.host, url.username, url.password, url.database]):
                    raise ConfigError(f"Invalid database URL format: {database_name}_URL")
                
                return cls(
                    host=str(url.host),
                    port=url.port or 5432,
                    user=str(url.username),
                    password=str(url.password),
                    database=str(url.database)
                )
            except Exception as e:
                raise ConfigError(f"Failed to parse {database_name}_URL: {e}")
        
        # Individual environment variables
        config_map = {
            'host': f'{database_name}_HOST',
            'port': f'{database_name}_PORT', 
            'user': f'{database_name}_USER',
            'password': f'{database_name}_PASSWORD',
            'database': f'{database_name}_NAME'
        }
        
        values = {}
        missing = []
        
        for key, env_var in config_map.items():
            value = os.getenv(env_var)
            if value is None:
                missing.append(env_var)
            else:
                values[key] = int(value) if key == 'port' else value
        
        if missing:
            raise ConfigError(f"Missing database environment variables: {missing}")
        
        return cls(**values)
    
    @property
    def connection_url(self) -> str:
        """Get SQLAlchemy connection URL."""
        return f"postgresql+psycopg2://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
    
    @property
    def masked_url(self) -> str:
        """Get connection URL with masked password for logging."""
        return f"postgresql+psycopg2://{self.user}:****@{self.host}:{self.port}/{self.database}"


class DatabasePrefixes:
    """Database prefix constants for table routing."""
    LOCAL_DEV = "NFLFASTR_DB"
    API_PRODUCTION = "SEVALLA_QUANTCUP_DB" 
    ANALYTICS = "ANALYTICS_DB"
    
    @classmethod
    def get_all(cls):
        return [cls.LOCAL_DEV, cls.API_PRODUCTION, cls.ANALYTICS]


class TransformNames:
    """Transform function names for table routing."""
    STANDARDIZE_TEAMS = "standardize_team_names"
    PARSE_DATES = "parse_dates"
    ADD_METADATA = "add_metadata"
    
    @classmethod
    def get_all(cls):
        return [cls.STANDARDIZE_TEAMS, cls.PARSE_DATES, cls.ADD_METADATA]


class SchemaNames:
    """Schema name constants."""
    RAW_NFLFASTR = "raw_nflfastr"
    ANALYTICS = "analytics"
    STAGING = "staging"


class ConfigValidator:
    """
    Validates system configuration and environment variables.
    
    Follows the "fail-fast" principle to catch configuration issues
    at startup rather than deep in the execution flow.
    """
    
    # Project-specific required variables
    PROJECT_CONFIGS = {
        'NFLFASTR': [
            'NFLFASTR_DB_HOST',
            'NFLFASTR_DB_PORT', 
            'NFLFASTR_DB_USER',
            'NFLFASTR_DB_PASSWORD',
            'NFLFASTR_DB_NAME'
        ],
        'ODDS_API': [
            'ODDS_API_DB_HOST',
            'ODDS_API_DB_PORT',
            'ODDS_API_DB_USER', 
            'ODDS_API_DB_PASSWORD',
            'ODDS_API_DB_NAME',
            'ODDS_API_KEY'
        ],
        'NFL_DATA_PY': [
            'NFL_DATA_PY_DB_HOST',
            'NFL_DATA_PY_DB_PORT',
            'NFL_DATA_PY_DB_USER',
            'NFL_DATA_PY_DB_PASSWORD', 
            'NFL_DATA_PY_DB_NAME'
        ]
    }
    
    @classmethod
    def validate_environment(cls, project='NFLFASTR', logger=None):
        """
        Validate all required environment variables are present for a project.
        
        Args:
            project (str): Project name ('NFLFASTR', 'ODDS_API', 'NFL_DATA_PY')
            logger: Logger instance (optional, for dependency injection)
            
        Raises:
            ConfigError: If any required environment variables are missing
        """
        logger = logger or _logger
        
        # Load environment variables from .env file first
        load_dotenv()
        
        if project not in cls.PROJECT_CONFIGS:
            raise ConfigError(f"Unknown project: {project}. Valid projects: {list(cls.PROJECT_CONFIGS.keys())}")
        
        required_vars = cls.PROJECT_CONFIGS[project]
        missing = [var for var in required_vars if not os.getenv(var)]
        
        if missing:
            raise ConfigError(
                f"Missing required environment variables for {project}: {missing}. "
                f"Please check your .env file and ensure all required variables are set."
            )
        
        logger.debug(f"{project} environment validation passed: all {len(required_vars)} required variables present")
    
    @classmethod
    def validate_optional_config(cls, project='NFLFASTR', logger=None):
        """
        Validate optional configuration and log warnings for missing values.
        
        Args:
            project (str): Project name for project-specific optional variables
            logger: Logger instance (optional, for dependency injection)
        """
        logger = logger or _logger
        
        optional_vars = {
            f'{project}_VERBOSE': f'Verbose logging disabled (set {project}_VERBOSE=1 to enable)',
            'QUANTCUP_VERBOSE': 'Global verbose logging disabled (set QUANTCUP_VERBOSE=1 to enable)',
        }
        
        for var, warning_msg in optional_vars.items():
            if not os.getenv(var):
                logger.debug(warning_msg)
    
    @classmethod
    def validate_all(cls, project='NFLFASTR', logger=None):
        """
        Run all configuration validations for a project.
        
        Args:
            project (str): Project name to validate
            logger: Logger instance (optional, for dependency injection)
            
        Convenience method to run both required and optional validations.
        """
        logger = logger or _logger
       
        cls.validate_environment(project, logger)
        cls.validate_optional_config(project, logger)
        logger.info(f"{project} configuration validation completed successfully")
