"""
Domain-Specific DataFrame validation utilities for commonv2.

This module contains only commonv2 domain-specific validation logic.
General validation functionality is now in .core module.

Consolidates domain-specific validation logic for teams and schedules.
"""

import pandas as pd
from typing import List, Optional, Dict, Any
from ...core.logging import get_logger
from .core import UnifiedDataValidator

# Module-level logger
_logger = get_logger('commonv2.utils.validation.domain')


class DataFrameValidator:
    """
    Domain-specific DataFrame validation for commonv2.
    
    This class now contains only commonv2 domain-specific validation logic.
    General validation methods are available in the UnifiedDataValidator.
    """
    
    def __init__(self, logger=None):
        """Initialize validator with logger dependency injection."""
        self._logger = logger or _logger
    
    def validate_team_dataframe(self, df: pd.DataFrame) -> bool:
        """
        Team-specific validation rules.
        
        Consolidates validation logic from teams.py validate_team_data().
        
        Args:
            df: Team DataFrame to validate
            
        Returns:
            True if valid, False otherwise
        """
        context = "team data"
        
        # Use shared validation for basic checks
        validator = UnifiedDataValidator(self._logger)
        
        # Required columns check
        if not validator.validate_required_columns(df, ['team_abbr', 'team_name'], context):
            return False
        
        # Expected team count check
        validator.validate_row_count(df, expected=32, context=context)
        
        self._logger.info(f"Team validation passed: {len(df)} teams with required columns")
        return True
    
    def validate_schedule_dataframe(self, df: pd.DataFrame) -> bool:
        """
        Schedule-specific validation rules.
        
        Consolidates validation logic from schedules.py validate_schedule_data().
        
        Args:
            df: Schedule DataFrame to validate
            
        Returns:
            True if valid, False otherwise
        """
        context = "schedule data"
        
        # Use shared validation for basic checks
        validator = UnifiedDataValidator(self._logger)
        
        # Required columns check
        if not validator.validate_required_columns(df, ['home_team', 'away_team'], context):
            return False
        
        self._logger.info(f"Schedule validation passed: {len(df)} games")
        return True
    
    def validate_for_database_insertion(
        self, 
        df: pd.DataFrame, 
        required_columns: Optional[List[str]] = None,
        max_rows: Optional[int] = None,
        context: str = "database insertion"
    ) -> bool:
        """
        Comprehensive validation for database insertion.
        
        Provides comprehensive validation for database insertion operations.
        
        Args:
            df: DataFrame to validate
            required_columns: List of columns that must be present
            max_rows: Maximum number of rows allowed
            context: Context string for error messages
            
        Returns:
            True if valid, raises exception if not
            
        Raises:
            ValueError: If validation fails
        """
        # Use shared validation for comprehensive checks
        validator = UnifiedDataValidator(self._logger)
        
        # Check if DataFrame is empty
        if df.empty:
            self._logger.warning(f"{context} DataFrame is empty")
            return True
        
        # Required columns check
        if required_columns:
            if not validator.validate_required_columns(df, required_columns, context):
                raise ValueError(f"DataFrame validation failed for {context}")
        
        # Row count check (raises exception for max_rows violation)
        validator.validate_row_count(df, max_rows=max_rows, context=context)
        
        self._logger.debug(f"Database insertion validation passed for {context}: {len(df)} rows, {len(df.columns)} columns")
        return True
    
    def validate_team_names_in_columns(
        self, 
        df: pd.DataFrame, 
        team_columns: List[str],
        standardizer=None
    ) -> Dict[str, Any]:
        """
        Validate team names in specified columns using standardizer.
        
        Consolidates validation logic from teams.py validate_team_names().
        
        Args:
            df: DataFrame to validate
            team_columns: List of column names containing team data
            standardizer: Team name standardizer (optional)
            
        Returns:
            Dictionary with validation results
        """
        # Create standardizer if not provided
        if standardizer is None:
            from ...domain.adapters import TeamNameStandardizer
            standardizer = TeamNameStandardizer()
        
        results = {
            'valid': True,
            'unknown_teams': set(),
            'columns_checked': team_columns
        }
        
        for col in team_columns:
            if col in df.columns:
                unique_teams = df[col].dropna().unique()
                for team in unique_teams:
                    # Use standardizer to check if team is known
                    standardized = standardizer.standardize_team_name(team)
                    if standardized == team and team not in standardizer.TEAM_NAME_ALIASES:
                        results['unknown_teams'].add(team)
                        results['valid'] = False
            else:
                self._logger.warning(f"Column '{col}' not found in DataFrame")
        
        if not results['valid']:
            self._logger.warning(f"Found unknown team names: {results['unknown_teams']}")
        
        return results
    
    def validate_table_routing_config(self, config: Dict[str, Any], table_name: str = "") -> List[str]:
        """Validate table routing configuration using constants."""
        from ...core.config import DatabasePrefixes, TransformNames
        
        errors = []
        
        # Validate databases field
        databases = config.get('databases', [])
        valid_database_names = DatabasePrefixes.get_all()
        for db in databases:
            if db not in valid_database_names:
                errors.append(f"Invalid database name '{db}' in {table_name}")
        
        # Validate transforms field
        transforms = config.get('transforms', {})
        valid_transforms = TransformNames.get_all()
        for database_name, transform_list in transforms.items():
            if database_name not in valid_database_names:
                errors.append(f"Invalid database name '{database_name}' in transforms for {table_name}")
            for transform in transform_list:
                if transform not in valid_transforms:
                    errors.append(f"Invalid transform '{transform}' for {database_name} in {table_name}")
        
        return errors