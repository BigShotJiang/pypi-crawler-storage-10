from textforge.export import render_to_ansi
from textforge.templates.showcase import Showcase
from textforge.utils.testing import snapshot_assert


def test_showcase_full_snapshot():
    renderable = Showcase.render_full(width=60)
    out = render_to_ansi(renderable)
    assert "TEXTFORGE SHOWCASE" in out
    snapshot_assert("templates_showcase_full", out)
