﻿from textforge.export import render_to_ansi
from textforge.utils.testing import snapshot_assert


def test_simple_components_snapshot():
    text = render_to_ansi('[cyan]Hello[reset]\n[bold]World[reset]')
    snapshot_assert('hello_world', text)
