# GUI Backend Implementation

This document describes the current GUI backend implementation for Textforge, providing native windowed rendering on Windows platforms.

The GUI backend is a fully custom implementation using the Win32 API for native windowing, OpenGL for hardware-accelerated rendering, and ANSI-to-style translation for rich text display.

- Backend abstraction: `textforge.core.backends.Backends.register(name, factory)` with registered backends: `tty` (stdout), `gui` (native window), `terminal` (enhanced terminal), `console` (stdout alias).
- GUI Implementation: Custom `GuiStream` class that implements `TextIO` interface, with ANSI-aware rendering, OpenGL acceleration, and native Win32 windowing.
- Current Implementation Status:
  - ✅ ANSI-aware rendering: Full ANSI SGR sequence parsing and style application via `translator.py`
  - ✅ Font/shaping: System fonts with GDI text rendering (handles grapheme width via text metrics)
  - ✅ Threading: Dedicated UI thread with proper synchronization and message pump
  - ✅ Input: Key event forwarding to `utils.input.read_key` interface via queue system
  - ✅ Fallback: Graceful fallback to stdout when GUI unavailable (headless mode, CI, etc.)
  - ✅ Live updates: Full support for `Console.live()` with frame-based rendering
  - ✅ OpenGL acceleration: Optional OpenGL rendering surface for performance

- Future Enhancements:
  - Cross-platform GUI: macOS (Cocoa) and Linux (GTK/X11) backends
  - Advanced text rendering: Subpixel antialiasing, ligature support
  - Rich input handling: Mouse events, clipboard integration
  - Performance optimizations: GPU-accelerated text rendering, font caching
  - Accessibility: Screen reader support, high contrast themes

Performance Characteristics:

- **Import Time**: GUI backend module loads in ~50-100ms (depends on system)
- **Frame Latency**: Under 60 FPS scheduler, mean frame time ~8-12ms, p95 ~15-20ms
- **Memory Usage**: ~2-5MB additional memory for GUI runtime and window
- **Threading Overhead**: Dedicated UI thread with minimal synchronization latency
- **Text Rendering**: GDI-based text measurement and rendering with proper grapheme width handling
- **ANSI Processing**: Full SGR sequence parsing with efficient color/style mapping

Comparison Metrics:
- **TTY vs GUI**: GUI backend shows ~10-20% higher latency due to window message pump, but provides richer visual output
- **Live Updates**: Both backends support `Console.live()` with comparable performance for text-based content
- **Memory Efficiency**: GUI backend uses additional memory for window management but provides better visual fidelity

Usage Patterns:
- **Console Selection**: `Console.for_backend("gui")` for native window, `Console.for_backend("tty")` for terminal
- **Headless Mode**: Set `TEXTFORGE_HEADLESS=1` environment variable to disable GUI creation
- **Fallback Behavior**: Automatic fallback to TTY when GUI unavailable (CI, remote sessions, etc.)
