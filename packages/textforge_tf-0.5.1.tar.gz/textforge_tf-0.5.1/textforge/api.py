"""Stable 1.x API surface aggregating user-facing symbols."""

from __future__ import annotations

from .core import Console, Renderable, tfprint
from .style import Color, themes
from .templates import Business, Dashboard, Showcase, Template
from .utils.deprecation import deprecated

__all__ = [
    "Console",
    "Renderable",
    "tfprint",
    "Color",
    "themes",
    "Template",
    "Showcase",
    "Dashboard",
    "Business",
    "deprecated",
]
