"""Effects (animations, transitions) exports."""

from __future__ import annotations

from .animation import Animation

__all__ = ["Animation"]
