"""Markup utilities."""

from __future__ import annotations

from .engine import MarkupEngine

__all__ = ["MarkupEngine"]
