from __future__ import annotations

"""GUI component placeholders mapping CLI components to GUI counterparts.

Future work: implement concrete widgets that render spans to a paint surface.
"""

__all__ = []
