"""Command registrations for Textforge CLI."""

from __future__ import annotations

# Re-export submodules so main can import symbols directly
from . import bench_cmd, demo, dsl_cmd, export_cmd, list_cmd, live_cmd, markup_cmd, new, plugins_cmd, preview, theme, typewriter_cmd

__all__ = [
    "bench_cmd",
    "demo",
    "dsl_cmd",
    "export_cmd",
    "list_cmd",
    "live_cmd",
    "markup_cmd",
    "new",
    "plugins_cmd",
    "preview",
    "theme",
    "typewriter_cmd",
]
