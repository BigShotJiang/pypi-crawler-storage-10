from textforge.templates.dashboard import Dashboard


def main() -> None:
    Dashboard.system_overview()


if __name__ == "__main__":
    main()
