from textforge.templates.game import Template


def main() -> None:
    Template.game_header("Textforge", "Modular terminal UI toolkit", width=70)
    Template.combat_status(37, 100, "Goblin Chief", 58, 100, width=70)
    Template.inventory_screen(
        [
            {"name": "Iron Sword", "quantity": 1, "rarity": "common"},
            {"name": "Elixir of Insight", "quantity": 2, "rarity": "rare"},
            {"name": "Phoenix Feather", "quantity": 1, "rarity": "epic"},
        ],
        width=70,
    )


if __name__ == "__main__":
    main()
