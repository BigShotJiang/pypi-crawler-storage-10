from textforge import components as C
from textforge import tfprint


def main() -> None:
    choice = C.Menu.run("Main Menu", ["Start", "Settings", "Quit"], timeout=0.1)
    tfprint(f"You chose: {choice}")


if __name__ == "__main__":
    main()
