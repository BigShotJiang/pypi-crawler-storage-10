"""Tests for AI adapters."""
