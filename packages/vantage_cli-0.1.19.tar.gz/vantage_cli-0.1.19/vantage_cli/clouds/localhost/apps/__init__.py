"""Localhost deployment applications package."""
