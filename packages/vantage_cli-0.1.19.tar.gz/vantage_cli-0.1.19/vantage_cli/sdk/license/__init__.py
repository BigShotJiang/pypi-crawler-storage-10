# Copyright (C) 2025 Vantage Compute Corporation
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.
"""License SDK module for Vantage CLI."""

from .crud import (
    license_booking_sdk,
    license_configuration_sdk,
    license_feature_sdk,
    license_product_sdk,
    license_server_sdk,
)
from .schema import (
    LicenseBooking,
    LicenseConfiguration,
    LicenseDeployment,
    LicenseFeature,
    LicenseProduct,
    LicenseServer,
)

__all__ = [
    # Schemas
    "LicenseServer",
    "LicenseFeature",
    "LicenseProduct",
    "LicenseConfiguration",
    "LicenseBooking",
    "LicenseDeployment",
    # CRUD SDK instances
    "license_server_sdk",
    "license_feature_sdk",
    "license_product_sdk",
    "license_configuration_sdk",
    "license_booking_sdk",
]
