from novelmaster import NovelMaster
__all__ = "NovelMaster"