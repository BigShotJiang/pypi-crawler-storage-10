# Aplicacion de Ventas

Este Paquete proporciona funcionalidades para gestinar ventas, incluyendo cálculos de precios, impuestos y descuentos.

## Instalacion

Puede Instalar el Paquete usando:

bash
pip install .
"