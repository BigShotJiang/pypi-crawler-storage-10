import requests
class gist_save():
    GITHUB_TOKEN = ""
    GIST_ID = ""
    GIST_FILE = "data.json"
    def gist_save(self,GIST_ID1,GITHUB_TOKEN1):
        self.GIST_ID = GIST_ID1
        self.GITHUB_TOKEN =GITHUB_TOKEN1
    def load_from_gist(self):

        url = f"https://api.github.com/gists/{self.GIST_ID}"
        headers = {"Authorization": f"token {self.GITHUB_TOKEN}"}
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            files = r.json().get("files", {})
            if GIST_FILE in files:
                import json
                return json.loads(files[self.GIST_FILE]["content"])


    def save_to_gist(self,data):
        url = f"https://api.github.com/gists/{self.GIST_ID}"
        headers = {"Authorization": f"token {self.GITHUB_TOKEN}"}
        import json
        data = {
            "files": {
                self.GIST_FILE: {
                    "content": json.dumps(data, indent=2)
                }
            }
        }
        r = requests.patch(url, headers=headers, json=data)
        if r.status_code not in (200, 201):
            raise Exception(f"Не удалось сохранить в Gist: {r.text}")
