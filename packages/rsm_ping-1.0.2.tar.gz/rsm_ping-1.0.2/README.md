﻿
# RSM-Ping (Open Edition)
**Resonant Stillness Monitor â€” Open Source (Apache-2.0)**

RSM-Ping meri *mirnost* (stillness) omreĹľja/sistema iz RTT jitterja in izraÄŤuna 4 metrike:
- **S** (Stillness): odziv na jitter varianco (veÄŤje je bolje)
- **H** (Spectral entropy): razprĹˇenost frekvenc (niĹľja je bolje)
- **D** (Autocorr decay): hitrost razpada korelacije (niĹľja je bolje)
- **R** (Resonant score): harmoniÄŤna kompozicija SÂ·(1â’H)Â·(1â’D)

## Namestitev (pip)
```
pip install rsm_ping
```

Alternativa (lokalno iz klona):
```
pip install -r requirements.txt
python rsm_ping.py --host 8.8.8.8 --count 150 --threshold 0.01 --plot 1
```

## Primeri
Realni ping z grafom:
```
rsm-ping --host 8.8.8.8 --count 150 --threshold 0.01 --adaptive 1 --plot 1
```

SintetiÄŤni test (resonant mode):
```
rsm-ping --mode synthetic --simulate resonant --count 150 --threshold 0.01 --plot 1
```

## Izhodi
- `results/*.csv` â€” RTT in povzetek metrik
- `results/*.png` â€” 4-panel graf (RTT, jitter var, entropy/decay, R)

## Licenca
Apache-2.0 Â© Freedom (Damjan), 2025

## Harmonic Signature Protocol
```json
{
  "omega": 6.0,
  "phi": 1.047,
  "gamma": 0.0,
  "intent": "resonant_network_stillness",
  "author": "Freedom (Damjan)"
}
```
