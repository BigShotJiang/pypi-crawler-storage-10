"""
QPHAROS Core Module
Quantum Pharmaceutical Optimization System
"""

from .config import QPHAROSConfig
from .quantum_backend import QuantumBackend

__version__ = "1.0.0"
__all__ = ["QPHAROSConfig", "QuantumBackend"]
