# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`uptick-observability` is a Python library that provides OpenTelemetry instrumentation for Django and FastAPI applications. It wraps OpenTelemetry's auto-instrumentation with custom configuration suitable for pre-forking applications (like Daphne, Dramatiq, and Celery workers).

**Key architectural decision**: This library does NOT use `opentelemetry-instrument` auto-instrumentation because it's incompatible with pre-forking applications. Instead, it provides manual instrumentation functions that configure OpenTelemetry after process forking.

## Common Development Commands

### Setup and Installation
```bash
mise run install  # Install dependencies and setup pre-commit hooks
```

### Code Quality
```bash
mise run format      # Format code with ruff
mise run ruff-check  # Run ruff linter with auto-fix
mise run mypy        # Type check with mypy
mise run lint        # Run all linters (format + ruff-check + mypy)
mise run ci          # Run full CI suite (lint + test)
```

### Testing and Development Servers
```bash
# Django test servers
mise run django_otel    # Run Django test server with Daphne
mise run dramatiq_otel  # Run Dramatiq worker
mise run celery_otel    # Run Celery worker
mise run django:migrate # Run Django migrations

# FastAPI test server
mise run fastapi_otel   # Run FastAPI test server with uvicorn
```

### Building and Publishing
```bash
mise run build    # Build package with uv
mise run publish  # Publish to PyPI with twine
```

## Architecture and Code Structure

### Package Organization

The library is organized by framework:
- `src/uptick_observability/logging.py` - Core logging configuration and custom OTEL log handler
- `src/uptick_observability/django/` - Django instrumentation
- `src/uptick_observability/fastapi/` - FastAPI instrumentation
- `src/uptick_observability/dramatiq/` - Dramatiq middleware
- `src/uptick_observability/celery/` - Celery instrumentation

### Core Instrumentation Pattern

All frameworks follow a similar manual instrumentation pattern:

1. Check if OTEL is disabled via `OTEL_SDK_DISABLED` environment variable
2. Check if provider is already configured (avoid double instrumentation)
3. Create and configure provider (TracerProvider or LoggerProvider)
4. Configure exporter based on environment variables (`OTEL_LOGS_EXPORTER`, `OTEL_TRACES_EXPORTER`)
5. Add processors/instrumentors for framework-specific libraries

### Django-Specific Architecture

**Custom Span Processor** (`UptickBatchSpanProcessor` in `django/__init__.py:68-103`):
- Filters out spans for external analytics services (Sentry, LaunchDarkly, Mixpanel)
- Filters SQL spans without parent traces (too noisy)
- Filters SQL spans shorter than `SQL_MINIMUM_SPAN_DURATION` (configurable via Django settings)

**Response Hook** (`custom_django_response_hook` in `django/__init__.py:41-66`):
- Adds custom attributes: `user_id`, `sql_count`, `workspace` (tenant), `view` name
- Tracks `error_count` for 500+ status codes
- Captures `uptick.user.email` from session

**Middleware**:
- `AccessLoggingMiddleware` - Alternative to Daphne's access logger, logs requests with SQL count, duration, user info
- `UptickSqlCounterDjangoMiddleware` - Counts SQL queries per request and injects controller name as SQL comment

### Logging Architecture

**Custom Log Handler** (`OTELLoggingHandler` in `logging.py:65-98`):
- Handles ProxyLoggerProvider gracefully during forking
- Auto-configures when logger provider becomes available
- Prevents log emission until OTEL is fully configured (critical for Dramatiq/Celery)

**Access Log Filtering** (`ExcludeAccessLogsFilter` in `logging.py:101-113`):
- Excludes health check endpoints from access logs: `/healthz`, `/livez`, `/readyz`, `/pingz`, `/favicon.ico`

### Configuration via Django Settings

The library reads custom thresholds from Django settings (see `django/settings.py`):
- `UPTICK_OBSERVABILITY_SQL_MINIMUM_SPAN_DURATION` (default: 100ms)
- `UPTICK_OBSERVABILITY_REQUEST_DURATION_SLOW` (default: 0.5s)
- `UPTICK_OBSERVABILITY_REQUEST_DURATION_VER_SLOW` (default: 10s)
- `UPTICK_OBSERVABILITY_SQL_COUNT_SLOW` (default: 25 queries)
- `UPTICK_OBSERVABILITY_SQL_COUNT_VERY_SLOW` (default: 100 queries)
- `UPTICK_OBSERVABILITY_PATHS_WITHOUT_INSTRUMENTATION` (list of paths to exclude)

## Environment Variables

Required OTEL environment variables (configured in `.mise.toml` for local dev):
```bash
OTEL_PYTHON_LOG_CORRELATION=true
OTEL_PYTHON_LOGGING_AUTO_INSTRUMENTATION_ENABLED=true
OTEL_METRICS_EXPORTER=none
OTEL_EXPORTER_OTLP_TIMEOUT=1
OTEL_EXPORTER_OTLP_ENDPOINT=https://quickwit-otel.onuptick.com/
OTEL_LOGS_EXPORTER=otlp  # or "console" for local debugging
OTEL_TRACES_EXPORTER=otlp  # or "console" for local debugging
OTEL_SERVICE_NAME=your-service-name  # e.g., "workforce-fg", "logbooks-fg"
OTEL_RESOURCE_ATTRIBUTES=release=your-release,environment=production
```

## Workspace Structure

This is a uv workspace with test applications:
- `tests/django_tests/` - Django test application
- `tests/fastapi_tests/` - FastAPI test application

Both are workspace members defined in `pyproject.toml`.

## Linting and Code Standards

Ruff configuration enforces strict linting rules including:
- Pyflakes, Pycodestyle, flake8-bugbear
- pyupgrade (Python 3.12+)
- Bandit security checks
- isort import sorting
- No debugger statements in commits
- Banned unsafe caching functions (must use multitenant-safe alternatives)

Key ignored rules (documented in `pyproject.toml:74-91`):
- `S101` - `assert` statements allowed
- `E501` - Line length handled by formatter
- Several B-series rules with TODOs for future cleanup
