from .main import *
from .detector import *
from .result_aggregator import *
from .wasserstein_changepoint_detector import *

__all__ = ["main"]
__version__ = "0.1.0"