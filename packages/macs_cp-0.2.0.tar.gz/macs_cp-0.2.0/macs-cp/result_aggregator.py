class ResultsAggregator:
    def __init__(self, change_points_dict, tol=2):
        """
        change_points_dict: {window_size: [cp1, cp2, ...], ...}
        tol: max index gap to cluster CPs into one segment
        """
        self.change_points_dict = change_points_dict
        self.tol = tol

    def num_windows(self):
        return len(self.change_points_dict)

    def compute_cp_to_windows(self):
        cp_to_windows = {}
        for w, cps in self.change_points_dict.items():
            for cp in cps:
                cp_to_windows.setdefault(cp, []).append(w)
        return cp_to_windows

    def compute_change_points_with_votes(self):
        """
        Returns:
          {
            'segment_1': {
                'change_points': [...],
                'votes': {cp: count, ...},
                'segment_vote': sum of votes
            }, ...
          }
        """
        cp_to_windows = self.compute_cp_to_windows()
        all_cps = sorted(cp_to_windows.keys())
        if not all_cps:
            return {}

        # cluster by proximity
        segments = []
        cur = [all_cps[0]]
        for cp in all_cps[1:]:
            if cp - cur[-1] <= self.tol:
                cur.append(cp)
            else:
                segments.append(cur)
                cur = [cp]
        segments.append(cur)

        out = {}
        for i, seg in enumerate(segments, start=1):
            votes = {c: len(cp_to_windows[c]) for c in seg}
            out[f"segment_{i}"] = {
                "change_points": seg,
                "votes": votes,
                "segment_vote": int(sum(votes.values()))
            }
        return out

    def leaders_from_segments(self, seg_results):
        """
        Map most common CP in each segment -> segment_vote.
        Tie-break deterministically by smallest CP.
        """
        leaders = {}
        for _, info in seg_results.items():
            votes = info["votes"]
            best_cp = max(votes.items(), key=lambda kv: (kv[1], -kv[0]))[0]
            seg_vote = info.get("segment_vote", sum(votes.values()))
            leaders[best_cp] = seg_vote
        return leaders

    def cdf_from_segment_votes(self, seg_results):
        """
        1) leaders: {best_cp -> segment_vote}
        2) divide by number_of_windows
        3) normalize to sum=1
        4) CDF over CPs (ascending)
        """
        M = self.num_windows()
        if M <= 0:
            raise ValueError("Number of windows must be positive.")

        leader_map = self.leaders_from_segments(seg_results)
        leader_scores = {cp: min(1.0, max(0.0, v / float(M))) for cp, v in leader_map.items()}

        total = sum(leader_scores.values())
        if total <= 0:
            K = len(leader_scores)
            leader_probs = {cp: (1.0 / K) for cp in leader_scores} if K > 0 else {}
        else:
            leader_probs = {cp: s / total for cp, s in leader_scores.items()}

        cps_sorted = sorted(leader_probs.keys())
        cdf = []
        cum = 0.0
        for cp in cps_sorted:
            cum += leader_probs[cp]
            cdf.append((cp, cum))

        return {
            "leaders_segment_votes": leader_map,
            "leaders_scores": leader_scores,
            "leaders_probs": leader_probs,
            "cdf": cdf,
        }