from .result_aggregator import ResultsAggregator
from .wasserstein_changepoint_detector import WAChangePointDetector
from typing import List, Optional, Dict, Any, Iterable, Literal
import numpy as np

def macs_detector(
    series: Iterable[float],
    window_sizes: Optional[List[int]] = None,
    n_perm: int = 300,
    alpha_q: float = 1.0,        # two-sided tail; accepts prob (<=1) or percent (>1)
    seed: int = 123,
    tol: int = 2,
    workers: Optional[int] = None,   # e.g., os.cpu_count()
    backend: str = "process",        # "process" (scripts) or "thread" (notebooks)
    change_type: Literal["mean", "var", "meanvar"] = "mean",
    eps: float = 1e-12,
) -> Dict[str, Any]:
    """
    Runs change point detection pipeline in parallel, aggregates results, and returns outputs.

    Parameters
    ----------
    series : Iterable[float]
        The input univariate time series.
    window_sizes : list[int] or None
        Window sizes to use (default = range(10, 21)).
    n_perm : int
        Number of permutations for null distribution.
    alpha_q : float
        Two-sided tail amount. If <=1 it's treated as probability (e.g., 0.01 = 1%);
        if >1 it's treated as percent (e.g., 1.0 = 1%).
    seed : int
        RNG seed.
    tol : int
        Clustering tolerance for CP segments.
    workers : int or None
        Degree of parallelism. None -> library default.
    backend : {"process","thread"}
        Executor backend. Use "process" for scripts; "thread" for notebooks.
    change_type : {"mean","var","meanvar"}
        Refinement used after a screening exceedance:
          - "mean":    CUSUM refinement (mean-shift; default)
          - "var":     pooled-mean variance-change refinement
          - "meanvar": joint mean+variance refinement
    eps : float
        Small guard for log(0) inside variance-based costs.

    Returns
    -------
    dict with keys:
        - "cp_dict"   : Dict[window_size, List[int]]
        - "timings"   : Dict[window_size, float]
        - "total_time": float
        - "segments"  : aggregated segments from vote clustering
        - "out"       : CDF-style output from segment votes
    """
    # Coerce to ndarray once here for consistency
    series = np.asarray(series, dtype=float)

    if window_sizes is None:
        window_sizes = list(range(10, 21))

    # Normalize alpha to PERCENT (detector expects percent)
    alpha_percent = 100.0 * alpha_q if alpha_q <= 1.0 else float(alpha_q)

    # Bonferroni across the number of window sizes
    alpha_percent_corrected = alpha_percent / max(1, len(window_sizes))

    # Detect change points (in parallel)
    detector = WAChangePointDetector(
        univariate_input_series=series,
        window_sizes=window_sizes
    )
    cp_dict, timings, total_time = detector.detect_changepoints(
        n_perm=n_perm,
        alpha_q=alpha_percent_corrected,
        seed=seed,
        workers=workers,
        backend=backend,
        change_type=change_type,
        eps=eps,
    )

    # Aggregate votes across window sizes
    agg = ResultsAggregator(change_points_dict=cp_dict, tol=tol)
    seg_results = agg.compute_change_points_with_votes()
    out = agg.cdf_from_segment_votes(seg_results)

    return {
        "cp_dict": cp_dict,
        "timings": timings,
        "total_time": total_time,
        "segments": seg_results,
        "out": out,
    }