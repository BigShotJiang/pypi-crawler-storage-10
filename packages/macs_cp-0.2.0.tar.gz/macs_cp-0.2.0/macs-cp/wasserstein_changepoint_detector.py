from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Iterable, Literal
import math
import time
import numpy as np
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from scipy.stats import wasserstein_distance


def refine_var(y: np.ndarray, eps: float = 1e-12) -> tuple[int, np.ndarray]:
    """
    Single change in *variance* under a Gaussian with a *common, unknown mean*.
    Returns the k in [1, n-1] that minimizes the negative log-likelihood.
    """
    S  = np.cumsum(y)
    S2 = np.cumsum(y * y)
    n  = len(y)
    mu = S[-1] / n

    ks = np.arange(1, n)
    n1 = ks
    n2 = n - ks

    sum1   = S[ks - 1]
    sum2   = S[-1] - S[ks - 1]
    sumsq1 = S2[ks - 1]
    sumsq2 = S2[-1] - S[ks - 1]

    # SSE around pooled mean
    sse1 = np.maximum(sumsq1 - 2.0 * mu * sum1 + n1 * mu * mu, 0.0)
    sse2 = np.maximum(sumsq2 - 2.0 * mu * sum2 + n2 * mu * mu, 0.0)

    costs = n1 * np.log(sse1 / n1 + eps) + n2 * np.log(sse2 / n2 + eps)
    k_star = int(ks[np.argmin(costs)])
    return k_star, costs

def refine_meanvar(y: np.ndarray, eps: float = 1e-12) -> tuple[int, np.ndarray]:
    """
    Single change allowing BOTH mean and variance to differ.
    Returns k in [1, n-1] minimizing the negative log-likelihood.
    """
    y = np.asarray(y, dtype=float).ravel()
    n = y.size
    if n < 3:
        raise ValueError("Need at least 3 points.")

    S  = np.cumsum(y)
    S2 = np.cumsum(y * y)

    ks = np.arange(1, n)
    n1 = ks
    n2 = n - ks

    sum1 = S[ks - 1]
    sum2 = S[-1] - S[ks - 1]
    s2_1 = S2[ks - 1]
    s2_2 = S2[-1] - S[ks - 1]

    # SSE around segment means
    sse1 = np.maximum(s2_1 - (sum1**2) / n1, 0.0)
    sse2 = np.maximum(s2_2 - (sum2**2) / n2, 0.0)

    costs = n1 * np.log(sse1 / n1 + eps) + n2 * np.log(sse2 / n2 + eps)
    k_star = int(ks[np.argmin(costs)])
    return k_star, costs

def refine_cp_cusum(y: np.ndarray) -> int:
    """
    Approximate change-point within a block using CUSUM (mean-shift).
    Returns an index in [1, len(y)-1].
    """
    y = np.asarray(y, dtype=float)
    S = np.cumsum(y.mean() - y)
    return int(np.argmax(np.abs(S[:-1])) + 1)


def _compute_bounds(series: np.ndarray,
                    start: int,
                    w: int,
                    delta: int,
                    n_perm: int,
                    rng: np.random.Generator,
                    q_percent: float) -> Tuple[float, float]:
    """
    Permutation null for Wasserstein distance between two adjacent blocks.
    Returns (lower, upper) as q/2 and (100-q/2) percentiles where q is in PERCENT.
    """
    window   = series[start : start + w]
    new_data = series[start + w : start + w + delta]
    pool     = np.concatenate([window, new_data])

    dists = np.empty(n_perm, dtype=float)
    for b in range(n_perm):
        perm = rng.permutation(pool)
        dists[b] = wasserstein_distance(perm[:w], perm[w:])
    return np.percentile(dists, [q_percent / 2.0, 100.0 - q_percent / 2.0])


def _detect_for_window(series: np.ndarray,
                       w: int,
                       n_perm: int,
                       alpha_q_percent: float,
                       seed: int,
                       change_type: Literal["mean", "var", "meanvar"] = "mean",
                       eps: float = 1e-12) -> Tuple[int, List[int], float]:
    """
    Worker function that runs the detect loop for a single window size w.

    Parameters
    ----------
    change_type : "mean" | "var" | "meanvar"
        - "mean"    -> use CUSUM refinement (refine_cp_cusum)
        - "var"     -> use refine_var (pooled mean, variance change)
        - "meanvar" -> use refine_meanvar (both mean and variance change)
    eps : float
        Small guard for log in variance-based refinements.

    Returns
    -------
    (w, change_points_for_w, elapsed_seconds)
    """
    series = np.asarray(series, dtype=float)
    N = len(series)
    delta_w = w  # step size equals window size

    approx_n_tests = max(1, (N - 2 * w) // w + 1)
    corrected_q = alpha_q_percent / float(approx_n_tests)

    t0 = time.perf_counter()
    cps: List[int] = []
    rng = np.random.default_rng(seed + int(w))

    start = 0
    if start + w + delta_w <= N:
        lower, upper = _compute_bounds(series, start, w, delta_w, n_perm, rng, q_percent=corrected_q)
    else:
        lower, upper = -np.inf, np.inf

    while start + w + delta_w <= N:
        window   = series[start : start + w]
        new_data = series[start + w : start + w + delta_w]
        x = wasserstein_distance(window, new_data)

        if (x > upper) or (x < lower):
            block = series[start : start + w + delta_w]

            # --- refinement switch ---
            if change_type == "mean":
                k_loc = refine_cp_cusum(block)
            elif change_type == "var":
                k_loc, _ = refine_var(block, eps=eps)
            elif change_type == "meanvar":
                k_loc, _ = refine_meanvar(block, eps=eps)
            else:
                raise ValueError(f"Unknown change_type: {change_type!r}")

            cp = start + int(k_loc)
            if cp <= start:
                cp = start + 1  # ensure forward progress
            cps.append(int(cp))

            # jump ahead to avoid re-detecting the same change in the next block
            start = start + w + delta_w
            if start + w + delta_w <= N:
                lower, upper = _compute_bounds(series, start, w, delta_w, n_perm, rng, q_percent=corrected_q)
        else:
            start += delta_w

    elapsed = time.perf_counter() - t0
    return w, cps, elapsed


@dataclass
class WAChangePointDetector:
    univariate_input_series: Iterable[float]
    window_sizes: List[int]

    def detect_changepoints(
        self,
        n_perm: int = 1000,
        alpha_q: float = 1.0,   # tail percent, e.g. 1.0 -> 0.5% & 99.5% bounds
        seed: int = 1234,
        workers: Optional[int] = None,
        backend: str = "process",
        change_type: Literal["mean", "var", "meanvar"] = "mean",
        eps: float = 1e-12,
    ) -> Tuple[Dict[int, List[int]], Dict[int, float], float]:
        """
        Detect change-points using Wasserstein screening + refinement.

        Parameters
        ----------
        change_type : "mean" | "var" | "meanvar"
            Refinement used when a screening exceedance occurs:
              - "mean":    CUSUM refinement (default; mean-shift)
              - "var":     pooled-mean variance change refinement
              - "meanvar": joint mean+variance refinement
        eps : float
            Small guard for log(0) inside variance-based costs.

        Returns
        -------
        change_points_dict : Dict[window_size, List[int]]
        timings            : Dict[window_size, float]
        total_time         : float
        """
        ct = str(change_type).lower()
        if ct not in {"mean", "var", "meanvar"}:
            raise ValueError("change_type must be one of {'mean','var','meanvar'}")

        series = np.asarray(self.univariate_input_series, dtype=float)
        t0_all = time.perf_counter()
        change_points_dict: Dict[int, List[int]] = {}
        timings: Dict[int, float] = {}

        if backend == "process":
            ctx = mp.get_context("spawn")
            def _make_executor():
                return ProcessPoolExecutor(max_workers=workers, mp_context=ctx)
        elif backend == "thread":
            def _make_executor():
                return ThreadPoolExecutor(max_workers=workers)
        else:
            raise ValueError("backend must be 'process' or 'thread'")

        with _make_executor() as ex:
            futures = {
                ex.submit(
                    _detect_for_window,
                    series,
                    w,
                    n_perm,
                    alpha_q,
                    seed,
                    ct,
                    eps,
                ): w
                for w in self.window_sizes
            }
            for fut in as_completed(futures):
                w, cps, elapsed = fut.result()
                change_points_dict[w] = cps
                timings[w] = elapsed

        total_time = time.perf_counter() - t0_all
        return change_points_dict, timings, total_time