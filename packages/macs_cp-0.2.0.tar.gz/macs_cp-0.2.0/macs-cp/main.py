from .detector import macs_detector

import time
from typing import List, Optional, Tuple
import numpy as np


def _macs_cpd_base(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    change_type: str = "mean",   # "mean" | "var" | "meanvar"
    eps: float = 1e-12,
) -> Tuple[List[int], float]:
    """
    Core MACS CPD wrapper that screens with Wasserstein and refines by `change_type`,
    then filters by leader scores >= threshold.

    Returns 1-based indices of accepted change points and elapsed seconds.
    """
    if tol is None:
        tol = int(min(window_sizes))

    t0 = time.perf_counter()
    res = macs_detector(
        series=np.asarray(series, dtype=float),
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        change_type=change_type,
        eps=eps,
    )

    # Till this point of the algorithm, we have been working with indices, but time series index starts at t=1
    cpts = [k + 1 for k, v in res["out"]["leaders_scores"].items() if v >= threshold]
    elapsed = time.perf_counter() - t0
    return cpts, elapsed


def macs_cpd_mean(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Mean-shift refinement via CUSUM (default path).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="mean",
        eps=eps,
    )


def macs_cpd_var(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Variance-change refinement (pooled mean; NLL-based).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="var",
        eps=eps,
    )


def macs_cpd_meanvar(
    series,
    window_sizes: List[int],
    n_perm: int = 300,
    alpha_q: float = 1.0,
    seed: int = 123,
    tol: Optional[int] = None,
    workers: Optional[int] = 8,
    backend: str = "thread",
    threshold: float = 0.5,
    eps: float = 1e-12,
):
    """
    Joint mean+variance-change refinement (segment-mean SSE; NLL-based).
    """
    return _macs_cpd_base(
        series=series,
        window_sizes=window_sizes,
        n_perm=n_perm,
        alpha_q=alpha_q,
        seed=seed,
        tol=tol,
        workers=workers,
        backend=backend,
        threshold=threshold,
        change_type="meanvar",
        eps=eps,
    )