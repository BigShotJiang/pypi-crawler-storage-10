# Change Point Detection using Wasserstein Distance

macs-cp is a change point detection method based on 1-wasserstein distance and permutation test to detect changes in mean, variance, and both mean and variance. 
For more information see the paper .................

# 🧭 MACS — Wasserstein-Adaptive Change-Point Detection

**MACS** is a fast, non-parametric change-point detection framework that uses  
Wasserstein distances for screening and statistical refinement for mean, variance,  
or joint mean + variance shifts.

---

## 📦 Installation

```bash
pip install macs-cpd
```

(If the name `macs` is taken on PyPI, your package should be published under a unique
name such as `macs-cpd`.)

---

## 🔍 Overview

MACS detects change points in univariate time series using three refinement modes:

| Function | Detects | Refinement method |
|-----------|----------|------------------|
| `macs_cpd_mean()` | Mean shifts | CUSUM |
| `macs_cpd_var()` | Variance shifts | Pooled-mean NLL |
| `macs_cpd_meanvar()` | Mean + variance shifts | Segment-specific NLL |

Each function combines:
1. **Wasserstein screening** – compares adjacent windows via permutation bounds.  
2. **Refinement** – localizes the change point using CUSUM or NLL minimization.  
3. **Voting / aggregation** – merges results across window sizes and reports the
most significant (“leader”) change points.

---

## 🚀 Quick Start Example

Detect a **mean shift** in a univariate time series using `macs_cpd_mean()`.

```python
import numpy as np
from macs import macs_cpd_mean

# Generate synthetic data with a mean shift at t = 300
rng = np.random.default_rng(123)
n = 500
x = np.r_[rng.normal(0.0, 1.0, 300), rng.normal(2.0, 1.0, 200)]

# Run MACS Change Point Detection
cpts, elapsed = macs_cpd_mean(
    series=x,
    window_sizes=[30, 40, 50],
    n_perm=400,
    alpha_q=1.0,    # 1% two-sided tail (as percent)
    seed=7,
    threshold=0.5
)

print("Detected change points (1-based):", cpts)
print(f"Elapsed time: {elapsed:.3f} seconds")
```

**Output (approximate):**
```
Detected change points (1-based): [301]
Elapsed time: 0.82 seconds
```