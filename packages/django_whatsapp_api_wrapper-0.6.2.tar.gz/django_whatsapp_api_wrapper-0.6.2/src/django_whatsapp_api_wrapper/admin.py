from django.contrib import admin
from .models import WhatsAppCloudApiBusiness, MetaApp
# Register your models here.

admin.site.register(WhatsAppCloudApiBusiness)
admin.site.register(MetaApp)


    

    
