from mcp.server.fastmcp import FastMCP
import logging
logging.basicConfig(level=logging.DEBUG)


mcp = FastMCP("Demo")

# 装饰器 将Python函数注册为MCP服务器可调用的工具
@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

# 将函数注册为MCP服务器的一个资源端点
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a greeting."""
    return f"Hello {name}!"

# def main():
#     print("Hello from mcp-server!")

def main() -> None:
    mcp.run(transport="stdio")
