# Andrews: Optimal Strategic Alignment (OSA) Framework

A comprehensive Python package for strategic analysis, multi-criteria decision-making, and optimization under constrained resources.

## Overview

The Andrews package integrates four key methodologies:

1. **SWOT Analysis** - Strategic factor identification and categorization
2. **AHP (Analytic Hierarchy Process)** - Multi-criteria prioritization using pairwise comparisons
3. **Linear Programming** - Resource allocation optimization
4. **Sensitivity Analysis** - Robustness assessment and parameter importance ranking

## Installation

### From PyPI (recommended)
```bash
pip install andrews
```

### For Development (editable install)
```bash
git clone <repository>
cd andrews_package
pip install -e .
```

### From Local Directory
```bash
pip install ./andrews_package
```

## Quick Start

### 1. Basic Framework Setup

```python
import andrews as ap

# Create framework instance
framework = ap.OSAFramework()

# Add SWOT factors
framework.swot.add_factor(
    name='Gross Margin',
    category='Strength',
    description='Strong 40% gross margin',
    quantitative_impact=0.40,
    constraint_type='cost'
)

framework.swot.add_factor(
    name='Plant Shutdown',
    category='Weakness',
    description='10% capacity loss',
    quantitative_impact=-0.10,
    constraint_type='capacity'
)

# View SWOT summary
print(framework.swot.summary())
```

### 2. Analytic Hierarchy Process (AHP)

```python
import numpy as np

# Define pairwise comparison matrices
# Strength matrix
strength_matrix = np.array([
    [1, 5, 3],           # Cost Efficiency vs others
    [1/5, 1, 1/2],       # Patent Volume vs others
    [1/3, 2, 1]          # Minimize Risk vs others
])

framework.ahp.add_matrix(
    name='Strength',
    matrix=strength_matrix,
    criteria_names=['Cost Efficiency', 'Patent Volume', 'Minimize Risk']
)

# Process matrix and get local priorities
result = framework.ahp.process_matrix('Strength')
print(f"Local Priorities: {result.local_weights}")
print(f"Consistency Ratio: {result.consistency_ratio:.4f}")

# Add more matrices (Weakness, Opportunity, Threat)
# ... (similar pattern for other matrices)

# Synthesize global priorities
global_priorities = framework.ahp.synthesize_priorities(
    goal_names=['Cost Efficiency', 'Patent Volume', 'Minimize Risk'],
    matrix_names=['Strength', 'Weakness', 'Opportunity', 'Threat'],
    matrix_weights={
        'Strength': 0.28,
        'Weakness': 0.43,
        'Opportunity': 0.17,
        'Threat': 0.12
    }
)

print(f"Global Priorities: {global_priorities}")
ranking = framework.ahp.get_ranking(global_priorities)
print(f"Strategic Ranking: {ranking}")
```

### 3. Linear Programming Optimization

```python
# Add products to optimization model
framework.lp.add_product(
    name='Industrial Valves',
    current_price=152.40,
    current_cost=88.31,
    price_increase_pct=6,
    cost_reduction_factor=0.965
)

framework.lp.add_product(
    name='Precision Bearings',
    current_price=65.05,
    current_cost=40.35,
    price_increase_pct=4,
    cost_reduction_factor=0.965
)

framework.lp.add_product(
    name='Hydraulic Fittings',
    current_price=27.08,
    current_cost=16.25,
    price_increase_pct=3,
    cost_reduction_factor=0.965
)

framework.lp.add_product(
    name='Custom Assemblies',
    current_price=244.21,
    current_cost=148.16,
    price_increase_pct=10,
    cost_reduction_factor=0.965
)

# Set capacity constraint (hard cap)
framework.lp.set_capacity_constraint(82_890)  # 90% of original 92,100

# Set volume constraints for specific products
framework.lp.set_volume_constraint('Industrial Valves', 0, 14_484)

# Set SMART goal for comparison
framework.lp.set_smart_goal(2_720_000)

# Run optimization
result = framework.lp.optimize_greedy()

print(f"Total Gross Profit: ${result.total_profit:,.2f}")
print(f"Total Volume: {result.total_volume:,.0f} units")
print(f"Allocations: {result.allocations}")

# Get detailed breakdown
detailed = framework.lp.get_detailed_allocation(result)
for product, metrics in detailed.items():
    print(f"\n{product}:")
    print(f"  Quantity: {metrics['quantity']:,.0f}")
    print(f"  Unit Margin: ${metrics['unit_margin']:.2f}")
    print(f"  Total Contribution: ${metrics['total_contribution']:,.2f}")

# Check against SMART goal
goal_check = framework.lp.check_goal_attainment(result)
print(f"\nGoal Attainment: {goal_check}")
```

### 4. Sensitivity Analysis

```python
# Initialize sensitivity analysis
framework.initialize_sensitivity(
    baseline_profit=result.total_profit,
    baseline_volume=result.total_volume
)

# Example: Capacity sensitivity analysis
def capacity_optimizer(multiplier):
    # Re-optimize with adjusted capacity
    adjusted_capacity = 82_890 * multiplier
    framework.lp.set_capacity_constraint(adjusted_capacity)
    opt_result = framework.lp.optimize_greedy()
    return opt_result.total_profit, opt_result.total_volume

capacity_variations = [0.85, 0.90, 0.95, 1.0, 1.05, 1.10]
capacity_analysis = framework.sensitivity.capacity_tornado(
    variations=capacity_variations,
    optimization_func=capacity_optimizer
)

print("Capacity Sensitivity Analysis:")
for variation in capacity_analysis['variations']:
    print(f"  {variation['capacity_multiplier']:.0%}: ${variation['profit']:,.0f}")

# Get robustness score
robustness = framework.sensitivity.robustness_score(smart_goal=2_720_000)
print(f"Robustness Score: {robustness['robustness_pct']:.1f}%")
```

## Core Components

### SWOTAnalysis
```python
swot = ap.SWOTAnalysis(category_weights={
    'Strength': 0.28,
    'Weakness': 0.43,
    'Opportunity': 0.17,
    'Threat': 0.12
})

swot.add_factor(name, category, description, impact, constraint_type)
factors = swot.get_factors_by_category('Strength')
summary = swot.summary()
```

### AHP
```python
ahp = ap.AHP()
ahp.add_matrix(name, matrix, criteria_names)
result = ahp.process_matrix(name)
global_priorities = ahp.synthesize_priorities(goal_names, matrix_names, matrix_weights)
ranking = ahp.get_ranking(priorities)
```

### LinearProgramming
```python
lp = ap.LinearProgramming()
lp.add_product(name, current_price, current_cost, price_increase_pct, cost_reduction_factor)
lp.set_capacity_constraint(max_units)
lp.set_volume_constraint(product_name, min_units, max_units)
result = lp.optimize_greedy()
detailed = lp.get_detailed_allocation(result)
```

### SensitivityAnalysis
```python
sensitivity = ap.SensitivityAnalysis(baseline_profit, baseline_volume)
sensitivity.add_scenario(name, parameter, value, result_profit, result_volume)
analysis = sensitivity.capacity_tornado(variations, optimization_func)
robustness = sensitivity.robustness_score(smart_goal)
```

## Utilities

### MetricsCalculator
```python
from andrews import MetricsCalculator as MC

margin_pct = MC.margin_pct(price=100, cost=60)  # 40%
capacity_util = MC.capacity_utilization(used=82890, total=92100)  # 90%
pct_change = MC.pct_change(base_value=1000, new_value=1050)  # 5%
```

### FormattingUtils
```python
from andrews import FormattingUtils as FU

formatted_currency = FU.format_currency(1234567.89)  # "$1,234,567.89"
formatted_pct = FU.format_percentage(0.40)  # "40.00%"
formatted_units = FU.format_units(82890)  # "82,890"
```

### ReportGenerator
```python
from andrews import ReportGenerator

report = ReportGenerator.executive_summary(swot_data, ahp_data, lp_data)
print(report)
```

## Advanced Usage

### Complete Workflow Example

```python
import andrews as ap
import numpy as np

# 1. Initialize Framework
framework = ap.OSAFramework()

# 2. Add SWOT Factors
swot_factors = [
    ('Gross Margin 40%', 'Strength', 'Strong margin performance', 0.40, 'cost'),
    ('Plant Shutdown -10%', 'Weakness', 'Capacity loss', -0.10, 'capacity'),
    ('Patent Approval +2%', 'Opportunity', 'New market access', 0.02, 'volume'),
    ('Competitive Threat', 'Threat', 'Price discipline required', -0.02, 'price'),
]

for name, cat, desc, impact, constraint in swot_factors:
    framework.swot.add_factor(name, cat, desc, impact, constraint)

# 3. Set up AHP Matrices (with geometric mean method)
matrices = {
    'Strength': np.array([[1, 5, 3], [1/5, 1, 1/2], [1/3, 2, 1]]),
    'Weakness': np.array([[1, 1/3, 1/7], [3, 1, 1/3], [7, 3, 1]]),
    'Opportunity': np.array([[1, 1/5, 1/3], [5, 1, 3], [3, 1/3, 1]]),
    'Threat': np.array([[1, 3, 1/2], [1/3, 1, 1/6], [2, 6, 1]]),
}

criteria_names = ['Cost Efficiency', 'Patent Volume', 'Minimize Risk']

for matrix_name, matrix_data in matrices.items():
    framework.ahp.add_matrix(matrix_name, matrix_data, criteria_names)
    result = framework.ahp.process_matrix(matrix_name)
    print(f"{matrix_name}: {result.local_weights}")

# 4. Synthesize Priorities
global_priorities = framework.ahp.synthesize_priorities(
    goal_names=criteria_names,
    matrix_names=list(matrices.keys()),
    matrix_weights=framework.swot.category_weights
)

print(f"Global Priorities: {global_priorities}")
ranking = framework.ahp.get_ranking(global_priorities)
print(f"Strategic Ranking: {ranking}")

# 5. Configure LP Optimization
products = [
    ('Industrial Valves', 152.40, 88.31, 6, 0.965),
    ('Precision Bearings', 65.05, 40.35, 4, 0.965),
    ('Hydraulic Fittings', 27.08, 16.25, 3, 0.965),
    ('Custom Assemblies', 244.21, 148.16, 10, 0.965),
]

for name, price, cost, price_inc, cost_factor in products:
    framework.lp.add_product(name, price, cost, price_inc, cost_factor)

framework.lp.set_capacity_constraint(82_890)
framework.lp.set_volume_constraint('Industrial Valves', 0, 14_484)
framework.lp.set_smart_goal(2_720_000)

# 6. Run Optimization
result = framework.lp.optimize_greedy()
print(f"\nOptimization Results:")
print(f"  Gross Profit: ${result.total_profit:,.2f}")
print(f"  Total Volume: {result.total_volume:,.0f} units")

# 7. Sensitivity Analysis
framework.initialize_sensitivity(result.total_profit, result.total_volume)

# Add scenarios
scenarios = [
    ('Conservative (-15%)', 'capacity', 0.85, 2_651_200, 78_285),
    ('Base Case', 'capacity', 1.0, result.total_profit, result.total_volume),
    ('Optimistic (+5%)', 'capacity', 1.05, 2_988_456, 87_045),
]

for name, param, value, profit, volume in scenarios:
    framework.sensitivity.add_scenario(name, param, value, profit, volume)

# Get robustness
robustness = framework.sensitivity.robustness_score(2_720_000)
print(f"\nRobustness: {robustness['robustness_pct']:.1f}%")

# 8. Generate Report
report = ap.ReportGenerator.executive_summary(
    framework.swot.summary(),
    {'global_priorities': global_priorities},
    {
        'total_profit': result.total_profit,
        'total_volume': result.total_volume,
        'capacity_utilization': 100.0
    }
)
print("\n" + report)
```

## Key Mathematical Methods

### AHP - Geometric Mean Method
The package uses the geometric mean method for eigenvector approximation:

```
w_i = (∏_j a_ij)^(1/n) / Σ_i (∏_j a_ij)^(1/n)
```

Where:
- `w_i` = priority weight for criterion i
- `a_ij` = pairwise comparison matrix element
- `n` = number of criteria
- `∏` = product operator

### LP - Greedy Allocation
Products are ranked by unit margin and allocated volume in descending order:

```
Unit Margin = Max Price - Target Cost
Ranking: Max Margin > ... > Min Margin
```

### Sensitivity Analysis - Elasticity
Parameter elasticity is calculated as:

```
Elasticity = (% Change in Profit) / (% Change in Parameter)
```

## Package Structure

```
andrews/
├── __init__.py              # Main package initialization
├── swot.py                  # SWOT analysis module
├── ahp.py                   # Analytic Hierarchy Process
├── optimization.py          # Linear Programming optimization
├── sensitivity.py           # Sensitivity analysis
└── utils.py                 # Utilities and helpers

setup.py                      # Package configuration
requirements.txt              # Dependencies
README.md                     # This file
```

## Development

To contribute or extend the package:

```bash
# Clone and setup development environment
git clone <repository>
cd andrews_package
pip install -e ".[dev]"

# Run tests (if available)
pytest

# Build distribution
python setup.py sdist bdist_wheel
```

## Requirements

- Python >= 3.7
- NumPy >= 1.19.0

## License

MIT License - see LICENSE file for details

## Citation

If you use the Andrews framework in research, please cite:

```
Andrews OSA Framework (2024)
Optimal Strategic Alignment Framework
https://github.com/yourusername/andrews
```

## Support

For issues, questions, or suggestions:
- GitHub Issues: https://github.com/yourusername/andrews/issues
- Email: support@andrews-framework.com

## Changelog

### Version 1.0.0 (Initial Release)
- SWOT analysis framework
- AHP with geometric mean eigenvector calculation
- Linear Programming optimization
- Sensitivity analysis
- Comprehensive utilities and formatters

---

**Andrews Framework Contributors**
*Empowering strategic decisions through quantitative analysis*
