from setuptools import setup, find_packages

setup(
    name="andrews",
    version="1.0.0",
    author="Andrews Framework",
    description="Optimal Strategic Alignment (OSA) Framework",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "numpy>=1.19.0",
    ],
)