"""
Linear Programming Optimization Module for OSA Framework
Solves manufacturing optimization problems with strategic constraints
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class Product:
    """Represents a product with pricing and cost parameters"""
    name: str
    current_price: float
    current_cost: float
    price_increase_pct: float = 0.0
    cost_reduction_factor: float = 1.0
    
    @property
    def max_price(self) -> float:
        """Maximum allowed price after adjustment"""
        return self.current_price * (1 + self.price_increase_pct / 100.0)
    
    @property
    def target_cost(self) -> float:
        """Target maximum cost after reduction"""
        return self.current_cost * self.cost_reduction_factor
    
    @property
    def unit_margin(self) -> float:
        """Unit margin (max price - target cost)"""
        return self.max_price - self.target_cost


@dataclass
class OptimizationResult:
    """Result from LP optimization"""
    total_profit: float
    allocations: Dict[str, float]  # Product -> Quantity
    total_volume: float
    unit_margins: Dict[str, float]
    ranking: List[Tuple[str, float]]
    constraints_met: Dict[str, bool]
    summary: Dict


class LinearProgramming:
    """
    Linear Programming optimizer for manufacturing resource allocation.
    Maximizes gross profit subject to capacity, pricing, and cost constraints
    informed by AHP priorities.
    """
    
    def __init__(self):
        """Initialize LP optimizer"""
        self.products: Dict[str, Product] = {}
        self.capacity_constraint: float = None
        self.volume_constraints: Dict[str, Tuple[float, float]] = {}  # product -> (min, max)
        self.smart_goal: float = None
    
    def add_product(self, name: str, current_price: float, current_cost: float,
                   price_increase_pct: float = 0.0, 
                   cost_reduction_factor: float = 1.0) -> None:
        """
        Add a product to the optimization model
        
        Args:
            name: Product identifier
            current_price: Current selling price per unit
            current_cost: Current COGS per unit
            price_increase_pct: Maximum price increase percentage
            cost_reduction_factor: Cost reduction factor (e.g., 0.965 for 3.5% reduction)
        """
        product = Product(
            name=name,
            current_price=current_price,
            current_cost=current_cost,
            price_increase_pct=price_increase_pct,
            cost_reduction_factor=cost_reduction_factor
        )
        self.products[name] = product
    
    def set_capacity_constraint(self, max_units: float) -> None:
        """
        Set total production capacity constraint
        
        Args:
            max_units: Maximum total units producible
        """
        self.capacity_constraint = max_units
    
    def set_volume_constraint(self, product_name: str, min_units: float, 
                            max_units: float) -> None:
        """
        Set volume constraints for a specific product
        
        Args:
            product_name: Product identifier
            min_units: Minimum units to produce
            max_units: Maximum units to produce
        """
        self.volume_constraints[product_name] = (min_units, max_units)
    
    def set_smart_goal(self, goal_profit: float) -> None:
        """
        Set target profit goal for sensitivity comparison
        
        Args:
            goal_profit: Target gross profit
        """
        self.smart_goal = goal_profit
    
    def optimize_greedy(self) -> OptimizationResult:
        """
        Greedy optimization: allocate volume to highest-margin products first,
        respecting capacity and volume constraints.
        
        Returns:
            OptimizationResult with allocations and profit
        """
        if not self.products:
            raise ValueError("No products defined")
        if self.capacity_constraint is None:
            raise ValueError("Capacity constraint not set")
        
        # Step 1: Calculate unit margins and rank products
        margins = {name: product.unit_margin 
                  for name, product in self.products.items()}
        ranked = sorted(margins.items(), key=lambda x: x[1], reverse=True)
        
        # Step 2: Allocate volume greedily
        allocations = {}
        remaining_capacity = self.capacity_constraint
        total_profit = 0.0
        
        for product_name, margin in ranked:
            product = self.products[product_name]
            
            # Determine max volume for this product
            max_volume = remaining_capacity
            
            # Apply product-specific volume constraint if exists
            if product_name in self.volume_constraints:
                _, constraint_max = self.volume_constraints[product_name]
                max_volume = min(max_volume, constraint_max)
            
            # Allocate volume
            allocated_volume = max_volume
            allocations[product_name] = allocated_volume
            
            # Update capacity and profit
            remaining_capacity -= allocated_volume
            total_profit += allocated_volume * margin
        
        # Calculate constraints met
        constraints_met = {
            'total_capacity': sum(allocations.values()) <= self.capacity_constraint,
            'volume_constraints': all(
                self.volume_constraints[prod][0] <= allocations.get(prod, 0) <= 
                self.volume_constraints[prod][1]
                for prod in self.volume_constraints
            ) if self.volume_constraints else True
        }
        
        # Prepare summary
        summary = {
            'total_volume': sum(allocations.values()),
            'capacity_utilized': sum(allocations.values()) / self.capacity_constraint * 100,
            'vs_smart_goal': total_profit - self.smart_goal if self.smart_goal else None
        }
        
        return OptimizationResult(
            total_profit=total_profit,
            allocations=allocations,
            total_volume=sum(allocations.values()),
            unit_margins=margins,
            ranking=ranked,
            constraints_met=constraints_met,
            summary=summary
        )
    
    def get_detailed_allocation(self, result: OptimizationResult) -> Dict:
        """
        Get detailed breakdown of allocation with pricing and costs
        
        Args:
            result: OptimizationResult from optimize_greedy
            
        Returns:
            Detailed allocation dictionary with financials
        """
        detailed = {}
        
        for product_name, quantity in result.allocations.items():
            product = self.products[product_name]
            
            revenue = quantity * product.max_price
            cogs = quantity * product.target_cost
            contribution = quantity * product.unit_margin
            
            detailed[product_name] = {
                'quantity': quantity,
                'max_price': product.max_price,
                'target_cost': product.target_cost,
                'unit_margin': product.unit_margin,
                'total_revenue': revenue,
                'total_cogs': cogs,
                'total_contribution': contribution,
                'margin_pct': (product.unit_margin / product.max_price * 100) if product.max_price > 0 else 0
            }
        
        return detailed
    
    def check_goal_attainment(self, result: OptimizationResult) -> Dict:
        """
        Check if optimization result meets SMART goal
        
        Args:
            result: OptimizationResult
            
        Returns:
            Dictionary with goal attainment metrics
        """
        if not self.smart_goal:
            return {'goal_set': False}
        
        vs_goal = result.total_profit - self.smart_goal
        pct_of_goal = (result.total_profit / self.smart_goal) * 100 if self.smart_goal > 0 else 0
        
        return {
            'goal_set': True,
            'smart_goal': self.smart_goal,
            'actual_profit': result.total_profit,
            'vs_goal': vs_goal,
            'pct_of_goal': pct_of_goal,
            'goal_met': result.total_profit >= self.smart_goal
        }
    
    def summary(self) -> Dict:
        """Return summary of LP model"""
        return {
            'products': {name: {
                'current_price': prod.current_price,
                'current_cost': prod.current_cost,
                'max_price': prod.max_price,
                'target_cost': prod.target_cost,
                'unit_margin': prod.unit_margin,
                'price_increase_pct': prod.price_increase_pct,
                'cost_reduction_factor': prod.cost_reduction_factor
            } for name, prod in self.products.items()},
            'capacity_constraint': self.capacity_constraint,
            'volume_constraints': self.volume_constraints,
            'smart_goal': self.smart_goal
        }
