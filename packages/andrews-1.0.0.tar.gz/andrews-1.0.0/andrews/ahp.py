"""
Analytic Hierarchy Process (AHP) Module for OSA Framework
Implements pairwise comparison matrices and eigenvector calculation via geometric mean method
"""

import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass


@dataclass
class AHPResult:
    """Result from AHP priority calculation"""
    priorities: np.ndarray
    criteria_names: List[str]
    local_weights: Dict[str, float]
    consistency_ratio: float = None
    

class AHP:
    """
    Analytic Hierarchy Process implementation using geometric mean method
    for eigenvector approximation.
    
    References: Saaty, T. L. (1980). The Analytic Hierarchy Process
    
    Saaty Scale:
    - 1: Equal importance
    - 3: Moderate dominance
    - 5: Strong dominance
    - 7: Very strong dominance
    - 9: Extreme dominance
    - Reciprocals for inverse comparisons
    """
    
    # Saaty's random consistency indices for n criteria
    RI = {
        1: 0.00,
        2: 0.00,
        3: 0.58,
        4: 0.90,
        5: 1.12,
        6: 1.24,
        7: 1.32,
        8: 1.41,
        9: 1.45,
        10: 1.49
    }
    
    def __init__(self):
        """Initialize AHP processor"""
        self.matrices: Dict[str, np.ndarray] = {}
        self.criteria_names: Dict[str, List[str]] = {}
        self.local_priorities: Dict[str, np.ndarray] = {}
    
    def add_matrix(self, name: str, matrix: np.ndarray, 
                   criteria_names: List[str]) -> None:
        """
        Add a pairwise comparison matrix
        
        Args:
            name: Identifier for this matrix (e.g., 'Strength', 'Weakness')
            matrix: n×n pairwise comparison matrix
            criteria_names: List of n criteria names
        """
        n = len(criteria_names)
        if matrix.shape != (n, n):
            raise ValueError(f"Matrix shape {matrix.shape} doesn't match criteria count {n}")
        
        self.matrices[name] = np.array(matrix, dtype=float)
        self.criteria_names[name] = criteria_names
    
    def geometric_mean_method(self, matrix: np.ndarray) -> np.ndarray:
        """
        Calculate priority vector using geometric mean method.
        
        Formula: w_i = (∏_j a_ij)^(1/n) / Σ_i (∏_j a_ij)^(1/n)
        
        Args:
            matrix: n×n pairwise comparison matrix
            
        Returns:
            Priority vector (normalized weights)
        """
        n = matrix.shape[0]
        
        # Step 1: Calculate geometric mean for each row
        geometric_means = np.zeros(n)
        for i in range(n):
            product = np.prod(matrix[i, :])
            geometric_means[i] = product ** (1.0 / n)
        
        # Step 2: Normalize to obtain priority vector
        priority_vector = geometric_means / np.sum(geometric_means)
        
        return priority_vector
    
    def consistency_index(self, matrix: np.ndarray, 
                         priority_vector: np.ndarray) -> Tuple[float, float]:
        """
        Calculate Consistency Index (CI) and Consistency Ratio (CR)
        
        Args:
            matrix: Pairwise comparison matrix
            priority_vector: Priority vector from geometric mean method
            
        Returns:
            Tuple of (CI, CR)
        """
        n = matrix.shape[0]
        
        # Calculate λ_max (maximum eigenvalue approximation)
        weighted_sum = np.dot(matrix, priority_vector)
        lambda_max = np.mean(weighted_sum / priority_vector)
        
        # Consistency Index: CI = (λ_max - n) / (n - 1)
        ci = (lambda_max - n) / (n - 1) if n > 1 else 0
        
        # Consistency Ratio: CR = CI / RI
        ri = self.RI.get(n, 1.45)
        cr = ci / ri if ri > 0 else 0
        
        return ci, cr
    
    def process_matrix(self, name: str, check_consistency: bool = True) -> AHPResult:
        """
        Process a pairwise comparison matrix and calculate priorities
        
        Args:
            name: Matrix identifier
            check_consistency: Whether to calculate consistency ratio
            
        Returns:
            AHPResult with priorities and metrics
        """
        if name not in self.matrices:
            raise ValueError(f"Matrix '{name}' not found")
        
        matrix = self.matrices[name]
        criteria = self.criteria_names[name]
        
        # Calculate priorities using geometric mean method
        priorities = self.geometric_mean_method(matrix)
        self.local_priorities[name] = priorities
        
        # Calculate consistency
        cr = None
        if check_consistency:
            _, cr = self.consistency_index(matrix, priorities)
            if cr > 0.10:
                print(f"⚠ Warning: CR={cr:.4f} exceeds 0.10 for matrix '{name}'")
        
        # Create local weights dictionary
        local_weights = {criteria[i]: priorities[i] for i in range(len(criteria))}
        
        return AHPResult(
            priorities=priorities,
            criteria_names=criteria,
            local_weights=local_weights,
            consistency_ratio=cr
        )
    
    def synthesize_priorities(self, goal_names: List[str],
                            matrix_names: List[str],
                            matrix_weights: Dict[str, float]) -> Dict[str, float]:
        """
        Synthesize local priorities into global priorities across multiple matrices.
        
        Global Priority(G_k) = Σ(Local Priority of G_k under Matrix i) × (Matrix Weight i)
        
        Args:
            goal_names: Names of the goals being prioritized
            matrix_names: Names of the matrices to synthesize
            matrix_weights: Dictionary mapping matrix names to their weights
            
        Returns:
            Dictionary mapping goal names to global priorities
        """
        # Validate matrix weights sum to 1.0
        total_weight = sum(matrix_weights.values())
        if not abs(total_weight - 1.0) < 0.001:
            raise ValueError(f"Matrix weights must sum to 1.0, got {total_weight}")
        
        global_priorities = {goal: 0.0 for goal in goal_names}
        
        for matrix_name, weight in matrix_weights.items():
            if matrix_name not in self.local_priorities:
                raise ValueError(f"Matrix '{matrix_name}' not processed")
            
            priorities = self.local_priorities[matrix_name]
            criteria = self.criteria_names[matrix_name]
            
            for i, goal in enumerate(criteria):
                if goal in global_priorities:
                    global_priorities[goal] += priorities[i] * weight
        
        return global_priorities
    
    def get_ranking(self, priorities: Dict[str, float]) -> List[Tuple[str, float]]:
        """
        Get ranking of goals by priority
        
        Args:
            priorities: Dictionary of goal names to priorities
            
        Returns:
            List of (goal, priority) tuples sorted by priority descending
        """
        return sorted(priorities.items(), key=lambda x: x[1], reverse=True)
    
    def summary(self) -> Dict:
        """Return summary of all processed matrices"""
        summary = {}
        for name in self.matrices.keys():
            if name in self.local_priorities:
                criteria = self.criteria_names[name]
                priorities = self.local_priorities[name]
                summary[name] = {
                    'criteria': criteria,
                    'priorities': priorities.tolist(),
                    'local_weights': {criteria[i]: float(priorities[i]) 
                                    for i in range(len(criteria))}
                }
        return summary
