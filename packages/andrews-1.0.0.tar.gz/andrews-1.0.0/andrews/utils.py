"""
Utilities module for OSA Framework
Helper functions and data structures
"""

from typing import Dict, List, Tuple
import json


class OSAConfig:
    """Configuration for OSA Framework"""
    
    DEFAULT_SWOT_WEIGHTS = {
        'Strength': 0.28,
        'Weakness': 0.43,
        'Opportunity': 0.17,
        'Threat': 0.12
    }
    
    DEFAULT_COST_REDUCTION = 0.965  # 3.5% reduction
    DEFAULT_CONSISTENCY_THRESHOLD = 0.10  # 10% CR threshold
    
    @staticmethod
    def validate_weights(weights: Dict[str, float]) -> bool:
        """Validate that weights sum to 1.0"""
        total = sum(weights.values())
        return abs(total - 1.0) < 0.001


class MetricsCalculator:
    """Calculate common business metrics"""
    
    @staticmethod
    def gross_margin_pct(revenue: float, cogs: float) -> float:
        """Calculate gross margin percentage"""
        if revenue == 0:
            return 0
        return ((revenue - cogs) / revenue) * 100
    
    @staticmethod
    def contribution_margin(price: float, cost: float) -> float:
        """Calculate contribution margin per unit"""
        return price - cost
    
    @staticmethod
    def margin_pct(price: float, cost: float) -> float:
        """Calculate margin percentage"""
        if price == 0:
            return 0
        return ((price - cost) / price) * 100
    
    @staticmethod
    def capacity_utilization(used: float, total: float) -> float:
        """Calculate capacity utilization percentage"""
        if total == 0:
            return 0
        return (used / total) * 100
    
    @staticmethod
    def pct_change(base_value: float, new_value: float) -> float:
        """Calculate percentage change"""
        if base_value == 0:
            return 0
        return ((new_value - base_value) / base_value) * 100


class FormattingUtils:
    """Formatting utilities for output"""
    
    @staticmethod
    def format_currency(value: float, decimals: int = 2) -> str:
        """Format value as currency"""
        return f"${value:,.{decimals}f}"
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 2) -> str:
        """Format value as percentage"""
        return f"{value:.{decimals}f}%"
    
    @staticmethod
    def format_units(value: float, decimals: int = 0) -> str:
        """Format value as units with thousands separator"""
        return f"{value:,.{int(decimals)}f}"
    
    @staticmethod
    def format_table(data: List[Dict], headers: List[str] = None) -> str:
        """Format list of dictionaries as table"""
        if not data:
            return "No data"
        
        if headers is None:
            headers = list(data[0].keys())
        
        # Calculate column widths
        col_widths = {h: len(h) for h in headers}
        for row in data:
            for h in headers:
                col_widths[h] = max(col_widths[h], len(str(row.get(h, ""))))
        
        # Build table
        lines = []
        header_line = " | ".join(h.ljust(col_widths[h]) for h in headers)
        lines.append(header_line)
        lines.append("-" * len(header_line))
        
        for row in data:
            row_line = " | ".join(str(row.get(h, "")).ljust(col_widths[h]) 
                                 for h in headers)
            lines.append(row_line)
        
        return "\n".join(lines)


class ReportGenerator:
    """Generate reports from OSA results"""
    
    @staticmethod
    def executive_summary(swot: Dict, ahp: Dict, lp: Dict, 
                         sensitivity: Dict = None) -> str:
        """Generate executive summary report"""
        report = []
        report.append("=" * 80)
        report.append("OPTIMAL STRATEGIC ALIGNMENT (OSA) FRAMEWORK - EXECUTIVE SUMMARY")
        report.append("=" * 80)
        report.append("")
        
        # SWOT Summary
        report.append("STRATEGIC CONTEXT (SWOT Analysis)")
        report.append("-" * 80)
        for category, factors in swot.items():
            if factors:
                report.append(f"\n{category}:")
                for factor in factors:
                    report.append(f"  • {factor['name']}: {factor['description']}")
        report.append("")
        
        # AHP Results
        report.append("STRATEGIC PRIORITIES (AHP Analysis)")
        report.append("-" * 80)
        if 'global_priorities' in ahp:
            for goal, priority in sorted(ahp['global_priorities'].items(), 
                                        key=lambda x: x[1], reverse=True):
                report.append(f"  {goal}: {priority:.1%}")
        report.append("")
        
        # LP Results
        report.append("OPTIMIZATION RESULTS (Linear Programming)")
        report.append("-" * 80)
        if 'total_profit' in lp:
            report.append(f"  Gross Profit: {FormattingUtils.format_currency(lp['total_profit'])}")
            report.append(f"  Total Volume: {FormattingUtils.format_units(lp['total_volume'])} units")
            if 'capacity_utilization' in lp:
                report.append(f"  Capacity Utilization: {lp['capacity_utilization']:.1f}%")
        
        return "\n".join(report)
    
    @staticmethod
    def detailed_report(framework_data: Dict) -> str:
        """Generate detailed analysis report"""
        report = []
        report.append("=" * 80)
        report.append("OPTIMAL STRATEGIC ALIGNMENT (OSA) FRAMEWORK - DETAILED REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Add sections from framework data
        for section, content in framework_data.items():
            report.append(f"\n{section.upper()}")
            report.append("-" * 80)
            if isinstance(content, dict):
                for key, value in content.items():
                    report.append(f"{key}: {value}")
            elif isinstance(content, list):
                for item in content:
                    report.append(f"  • {item}")
            else:
                report.append(str(content))
        
        return "\n".join(report)


class DataExporter:
    """Export OSA results to various formats"""
    
    @staticmethod
    def to_json(data: Dict, filepath: str = None) -> str:
        """Export data to JSON format"""
        json_str = json.dumps(data, indent=2, default=str)
        if filepath:
            with open(filepath, 'w') as f:
                f.write(json_str)
        return json_str
    
    @staticmethod
    def to_dict(obj) -> Dict:
        """Convert object to dictionary"""
        if hasattr(obj, '__dict__'):
            return {k: DataExporter.to_dict(v) for k, v in obj.__dict__.items()}
        elif isinstance(obj, dict):
            return {k: DataExporter.to_dict(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [DataExporter.to_dict(item) for item in obj]
        else:
            return obj
