"""
Andrews: Optimal Strategic Alignment (OSA) Framework
A Python package for strategic analysis, multi-criteria decision-making, and optimization.

Author: Andrews Framework Contributors
Version: 1.0.0
License: MIT

This package integrates:
- SWOT Analysis: Strategic factor identification
- AHP (Analytic Hierarchy Process): Multi-criteria prioritization
- Linear Programming: Resource optimization
- Sensitivity Analysis: Robustness assessment
"""

__version__ = "1.0.0"
__author__ = "Andrews Framework Contributors"
__license__ = "MIT"

# Import main modules
from typing import Dict
from .swot import SWOTAnalysis, SWOTFactor
from .ahp import AHP, AHPResult
from .optimization import LinearProgramming, Product, OptimizationResult
from .sensitivity import SensitivityAnalysis, ParameterImportanceRanking
from .utils import (
    OSAConfig,
    MetricsCalculator,
    FormattingUtils,
    ReportGenerator,
    DataExporter
)

# Define public API
__all__ = [
    # SWOT
    'SWOTAnalysis',
    'SWOTFactor',
    
    # AHP
    'AHP',
    'AHPResult',
    
    # Optimization
    'LinearProgramming',
    'Product',
    'OptimizationResult',
    
    # Sensitivity
    'SensitivityAnalysis',
    'ParameterImportanceRanking',
    
    # Utilities
    'OSAConfig',
    'MetricsCalculator',
    'FormattingUtils',
    'ReportGenerator',
    'DataExporter',
]


# Framework class that ties everything together
class OSAFramework:
    """
    Optimal Strategic Alignment (OSA) Framework
    
    Integrates SWOT analysis, AHP prioritization, and LP optimization
    for comprehensive strategic decision-making under constraints.
    
    Example:
        >>> import andrews as ap
        >>> framework = ap.OSAFramework()
        >>> framework.swot.add_factor('Market Growth', 'Opportunity', '2% growth', 0.02, 'volume')
        >>> # ... add more factors, run AHP, optimize
    """
    
    def __init__(self):
        """Initialize OSA Framework with all components"""
        self.swot = SWOTAnalysis()
        self.ahp = AHP()
        self.lp = LinearProgramming()
        self.sensitivity = None
        self.results = {}
    
    def initialize_sensitivity(self, baseline_profit: float, 
                              baseline_volume: float) -> None:
        """
        Initialize sensitivity analysis with baseline metrics
        
        Args:
            baseline_profit: Baseline gross profit from optimization
            baseline_volume: Baseline total volume from optimization
        """
        self.sensitivity = SensitivityAnalysis(baseline_profit, baseline_volume)
    
    def get_summary(self) -> Dict:
        """
        Get summary of all OSA components
        
        Returns:
            Dictionary with summaries of SWOT, AHP, LP, and Sensitivity
        """
        summary = {
            'swot': self.swot.to_dict(),
            'ahp': self.ahp.summary(),
            'lp': self.lp.summary(),
        }
        
        if self.sensitivity:
            summary['sensitivity'] = self.sensitivity.summary()
        
        return summary


# Import for convenience

print(__doc__)
