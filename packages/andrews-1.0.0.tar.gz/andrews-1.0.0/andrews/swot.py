"""
SWOT Analysis Module for OSA Framework
Converts qualitative business factors into quantifiable constraints
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class SWOTFactor:
    """Represents a single SWOT factor with its quantitative impact"""
    name: str
    category: str  # 'Strength', 'Weakness', 'Opportunity', 'Threat'
    description: str
    quantitative_impact: float
    constraint_type: str


class SWOTAnalysis:
    """
    SWOT Analysis framework for translating qualitative factors into
    quantifiable optimization constraints.
    
    Attributes:
        factors (Dict): Dictionary of SWOT factors
        category_weights (Dict): Relative importance weights for each SWOT category
    """
    
    def __init__(self, category_weights: Dict[str, float] = None):
        """
        Initialize SWOT Analysis
        
        Args:
            category_weights: Dictionary mapping category to weight
                            Default: S=0.28, W=0.43, O=0.17, T=0.12
        """
        self.factors: Dict[str, SWOTFactor] = {}
        self.category_weights = category_weights or {
            'Strength': 0.28,
            'Weakness': 0.43,
            'Opportunity': 0.17,
            'Threat': 0.12
        }
        
        # Validate weights sum to 1.0
        total_weight = sum(self.category_weights.values())
        if not abs(total_weight - 1.0) < 0.001:
            raise ValueError(f"Category weights must sum to 1.0, got {total_weight}")
    
    def add_factor(self, name: str, category: str, description: str,
                   quantitative_impact: float, constraint_type: str) -> None:
        """
        Add a SWOT factor to the analysis
        
        Args:
            name: Factor identifier
            category: 'Strength', 'Weakness', 'Opportunity', or 'Threat'
            description: Text description of the factor
            quantitative_impact: Numerical impact (e.g., -0.10 for -10% impact)
            constraint_type: Type of constraint (e.g., 'capacity', 'cost', 'price')
        """
        if category not in self.category_weights:
            raise ValueError(f"Invalid category: {category}")
        
        factor = SWOTFactor(
            name=name,
            category=category,
            description=description,
            quantitative_impact=quantitative_impact,
            constraint_type=constraint_type
        )
        self.factors[name] = factor
    
    def get_factors_by_category(self, category: str) -> List[SWOTFactor]:
        """Get all factors in a specific SWOT category"""
        return [f for f in self.factors.values() if f.category == category]
    
    def get_category_weight(self, category: str) -> float:
        """Get the weight for a SWOT category"""
        return self.category_weights.get(category, 0.0)
    
    def summary(self) -> Dict:
        """Return a summary of the SWOT analysis"""
        summary_dict = {
            'Strength': [],
            'Weakness': [],
            'Opportunity': [],
            'Threat': []
        }
        
        for factor in self.factors.values():
            summary_dict[factor.category].append({
                'name': factor.name,
                'description': factor.description,
                'impact': factor.quantitative_impact,
                'constraint_type': factor.constraint_type,
                'weight': self.get_category_weight(factor.category)
            })
        
        return summary_dict
    
    def to_dict(self) -> Dict:
        """Convert SWOT analysis to dictionary representation"""
        return {
            'factors': {name: {
                'name': f.name,
                'category': f.category,
                'description': f.description,
                'quantitative_impact': f.quantitative_impact,
                'constraint_type': f.constraint_type
            } for name, f in self.factors.items()},
            'category_weights': self.category_weights
        }
