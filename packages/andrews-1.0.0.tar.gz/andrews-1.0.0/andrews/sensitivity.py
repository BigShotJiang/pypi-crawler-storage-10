"""
Sensitivity Analysis Module for OSA Framework
Assesses robustness of optimization results to parameter variations
"""

from typing import Dict, List, Tuple
from dataclasses import dataclass
import numpy as np


@dataclass
class SensitivityScenario:
    """Represents a sensitivity analysis scenario"""
    name: str
    parameter: str
    value: float
    result_profit: float
    result_volume: float
    vs_baseline: float
    pct_change_profit: float


class SensitivityAnalysis:
    """
    Sensitivity analysis to assess impact of parameter variations
    on optimal solution robustness.
    """
    
    def __init__(self, baseline_profit: float, baseline_volume: float):
        """
        Initialize sensitivity analysis
        
        Args:
            baseline_profit: Baseline gross profit (base case)
            baseline_volume: Baseline total volume (base case)
        """
        self.baseline_profit = baseline_profit
        self.baseline_volume = baseline_volume
        self.scenarios: List[SensitivityScenario] = []
    
    def add_scenario(self, name: str, parameter: str, value: float,
                    result_profit: float, result_volume: float) -> None:
        """
        Add a sensitivity scenario
        
        Args:
            name: Scenario identifier
            parameter: Parameter being varied (e.g., 'capacity', 'cost_reduction')
            value: Value of the parameter in this scenario
            result_profit: Resulting gross profit
            result_volume: Resulting total volume
        """
        vs_baseline = result_profit - self.baseline_profit
        pct_change_profit = (result_profit - self.baseline_profit) / self.baseline_profit * 100
        
        scenario = SensitivityScenario(
            name=name,
            parameter=parameter,
            value=value,
            result_profit=result_profit,
            result_volume=result_volume,
            vs_baseline=vs_baseline,
            pct_change_profit=pct_change_profit
        )
        self.scenarios.append(scenario)
    
    def capacity_tornado(self, variations: List[float],
                        optimization_func) -> Dict:
        """
        Tornado analysis for capacity constraint variations
        
        Args:
            variations: List of capacity multipliers (e.g., [0.85, 0.95, 1.0, 1.05])
            optimization_func: Function that takes capacity and returns profit
            
        Returns:
            Dictionary with tornado analysis results
        """
        base_capacity = optimization_func(1.0)[0]
        results = []
        
        for multiplier in sorted(variations):
            profit, volume = optimization_func(multiplier)
            results.append({
                'multiplier': multiplier,
                'capacity_multiplier': multiplier,
                'profit': profit,
                'volume': volume,
                'vs_baseline': profit - self.baseline_profit,
                'pct_change': (profit - self.baseline_profit) / self.baseline_profit * 100
            })
        
        return {
            'parameter': 'capacity',
            'variations': results,
            'min_impact': min([r['vs_baseline'] for r in results]),
            'max_impact': max([r['vs_baseline'] for r in results])
        }
    
    def price_increase_sensitivity(self, variations: List[float],
                                  optimization_func) -> Dict:
        """
        Sensitivity analysis for price increase tolerance
        
        Args:
            variations: List of price increase multipliers
            optimization_func: Function that takes price multiplier and returns profit
            
        Returns:
            Dictionary with results
        """
        results = []
        
        for multiplier in sorted(variations):
            profit, volume = optimization_func(multiplier)
            results.append({
                'price_multiplier': multiplier,
                'price_increase_pct': (multiplier - 1.0) * 100,
                'profit': profit,
                'volume': volume,
                'vs_baseline': profit - self.baseline_profit,
                'pct_change': (profit - self.baseline_profit) / self.baseline_profit * 100
            })
        
        return {
            'parameter': 'price_increase',
            'variations': results,
            'min_profit': min([r['profit'] for r in results]),
            'max_profit': max([r['profit'] for r in results])
        }
    
    def cost_reduction_sensitivity(self, variations: List[float],
                                  optimization_func) -> Dict:
        """
        Sensitivity analysis for cost reduction achievability
        
        Args:
            variations: List of cost reduction factors (e.g., [0.95, 0.965, 0.98])
            optimization_func: Function that takes cost factor and returns profit
            
        Returns:
            Dictionary with results
        """
        results = []
        
        for cost_factor in sorted(variations, reverse=True):
            profit, volume = optimization_func(cost_factor)
            reduction_pct = (1 - cost_factor) * 100
            
            results.append({
                'cost_reduction_factor': cost_factor,
                'cost_reduction_pct': reduction_pct,
                'profit': profit,
                'volume': volume,
                'vs_baseline': profit - self.baseline_profit,
                'pct_change': (profit - self.baseline_profit) / self.baseline_profit * 100
            })
        
        return {
            'parameter': 'cost_reduction',
            'variations': results,
            'best_case': max([r['profit'] for r in results]),
            'worst_case': min([r['profit'] for r in results])
        }
    
    def get_elasticity(self, parameter: str, base_value: float,
                      test_value: float, result_change: float) -> float:
        """
        Calculate elasticity of profit with respect to parameter change
        
        Elasticity = (% change in profit) / (% change in parameter)
        
        Args:
            parameter: Parameter name
            base_value: Base parameter value
            test_value: Test parameter value
            result_change: Resulting profit change
            
        Returns:
            Elasticity coefficient
        """
        pct_param_change = (test_value - base_value) / base_value * 100
        pct_profit_change = (result_change / self.baseline_profit) * 100
        
        if pct_param_change == 0:
            return 0
        
        elasticity = pct_profit_change / pct_param_change
        return elasticity
    
    def robustness_score(self, smart_goal: float) -> Dict:
        """
        Calculate robustness score based on how many scenarios meet SMART goal
        
        Args:
            smart_goal: Target profit goal
            
        Returns:
            Dictionary with robustness metrics
        """
        if not self.scenarios:
            return {'message': 'No scenarios added'}
        
        scenarios_meeting_goal = sum(1 for s in self.scenarios if s.result_profit >= smart_goal)
        total_scenarios = len(self.scenarios)
        robustness = (scenarios_meeting_goal / total_scenarios) * 100 if total_scenarios > 0 else 0
        
        return {
            'scenarios_meeting_goal': scenarios_meeting_goal,
            'total_scenarios': total_scenarios,
            'robustness_pct': robustness,
            'is_robust': robustness >= 80  # Robust if 80%+ scenarios meet goal
        }
    
    def summary(self) -> Dict:
        """Return summary of all sensitivity scenarios"""
        return {
            'baseline': {
                'profit': self.baseline_profit,
                'volume': self.baseline_volume
            },
            'scenarios': [{
                'name': s.name,
                'parameter': s.parameter,
                'value': s.value,
                'result_profit': s.result_profit,
                'result_volume': s.result_volume,
                'vs_baseline': s.vs_baseline,
                'pct_change_profit': s.pct_change_profit
            } for s in self.scenarios]
        }


class ParameterImportanceRanking:
    """
    Ranks parameters by importance (sensitivity) to optimization results
    """
    
    def __init__(self):
        """Initialize parameter importance ranker"""
        self.elasticities: Dict[str, float] = {}
    
    def add_elasticity(self, parameter: str, elasticity: float) -> None:
        """
        Add elasticity coefficient for a parameter
        
        Args:
            parameter: Parameter name
            elasticity: Elasticity coefficient (absolute value)
        """
        self.elasticities[parameter] = abs(elasticity)
    
    def get_ranking(self) -> List[Tuple[str, float]]:
        """
        Get parameters ranked by importance (elasticity)
        
        Returns:
            List of (parameter, elasticity) tuples sorted by importance
        """
        return sorted(self.elasticities.items(), key=lambda x: x[1], reverse=True)
    
    def summary(self) -> Dict:
        """Return summary of parameter importance"""
        ranking = self.get_ranking()
        return {
            'ranked_parameters': ranking,
            'most_important': ranking[0] if ranking else None,
            'least_important': ranking[-1] if ranking else None
        }
