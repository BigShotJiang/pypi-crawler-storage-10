from .ProxiFlat import ProxiFlat
from .ProxiKNN import ProxiKNN
from .ProxiPCA import ProxiPCA
