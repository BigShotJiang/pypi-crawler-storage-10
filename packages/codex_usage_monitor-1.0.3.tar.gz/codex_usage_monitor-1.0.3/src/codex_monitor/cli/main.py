"""Main CLI entry point for Codex Usage Monitor."""

import os
import sys
import time
from datetime import datetime

import requests

from codex_monitor.core.api import CodexUsageAPI
from codex_monitor.core.auth import CodexTokenExtractor
from codex_monitor.core.sessions import SessionAnalyzer
from codex_monitor.ui.display import display_usage
import argparse
from importlib.metadata import version, PackageNotFoundError


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="codex-usage-monitor",
        description="Monitor Codex CLI token usage in real time from your terminal.",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=10,
        help="Refresh interval in seconds (default: 10)",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="Fetch and display once, then exit",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output raw JSON usage to stdout and exit",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print version and exit",
    )
    return parser.parse_args(argv)


def _print_version():
    try:
        print(version("codex-usage-monitor"))
    except PackageNotFoundError:
        print("unknown")


def main(argv=None):
    """Main entry point."""

    args = _parse_args(argv)
    if args.version:
        _print_version()
        return 0

    print("\n🚀 Codex Usage Monitor")
    print("─" * 60)

    try:
        # Initialize components
        print("🔑 Reading token from ~/.codex/auth.json...")
        token_extractor = CodexTokenExtractor()
        api = CodexUsageAPI(token_extractor)
        analyzer = SessionAnalyzer()

        print("✓ Token loaded")
        print("📊 Fetching usage data...")

        # Main loop
        while True:
            try:
                # Fetch current usage
                data = api.get_usage()

                if args.json:
                    import json as _json
                    print(_json.dumps(data, indent=2))
                    return 0

                # Clear screen
                os.system("clear" if os.name == "posix" else "cls")

                # Display enhanced view
                display_usage(data, analyzer)

                # Footer
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                print(f"Last updated: {now}")
                print("💡 Press Ctrl+C to exit")

                if args.once:
                    return 0

                # Wait for next refresh
                time.sleep(max(1, args.interval))

            except requests.exceptions.HTTPError as e:
                print(f"\n❌ API Error: {e}")
                print("Retrying in 30 seconds...")
                time.sleep(30)

            except KeyboardInterrupt:
                print("\n\n👋 Monitoring stopped")
                return 0

    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
