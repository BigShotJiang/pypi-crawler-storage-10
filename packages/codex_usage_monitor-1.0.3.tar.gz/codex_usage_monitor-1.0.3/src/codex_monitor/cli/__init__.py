"""CLI interface for Codex Usage Monitor."""

from codex_monitor.cli.main import main

__all__ = ["main"]
