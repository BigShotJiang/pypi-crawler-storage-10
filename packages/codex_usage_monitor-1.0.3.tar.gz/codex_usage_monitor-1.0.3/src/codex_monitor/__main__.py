"""Entry point for python -m codex_monitor."""

import sys

from codex_monitor.cli.main import main

if __name__ == "__main__":
    sys.exit(main())
