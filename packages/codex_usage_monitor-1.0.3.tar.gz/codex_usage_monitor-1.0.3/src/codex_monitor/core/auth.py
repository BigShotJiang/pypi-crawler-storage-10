"""Authentication and token management for Codex CLI."""

import base64
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests


class CodexTokenExtractor:
    """Extract and refresh access token from Codex CLI auth file."""

    def __init__(self):
        self.auth_file = Path.home() / ".codex" / "auth.json"
        self._auth_data: Optional[dict] = None

    def get_token(self) -> str:
        """Read access token from ~/.codex/auth.json"""
        if not self.auth_file.exists():
            raise FileNotFoundError(
                f"Codex auth file not found at {self.auth_file}\n"
                "Please login to Codex CLI first using: codex"
            )

        try:
            with open(self.auth_file) as f:
                self._auth_data = json.load(f)

            # Check if token needs refresh
            if self._should_refresh():
                print("🔄 Access token expired, refreshing...")
                return self._refresh_token()

            token = self._auth_data.get("tokens", {}).get("access_token")
            if not token:
                raise ValueError("No access_token found in auth.json")

            return token

        except Exception as e:
            raise Exception(f"Failed to read auth file: {e}")

    def _should_refresh(self) -> bool:
        """Check if token needs refresh based on expiration."""
        try:
            token = self._auth_data.get("tokens", {}).get("access_token", "")

            parts = token.split(".")
            if len(parts) != 3:
                return False

            payload = parts[1]
            payload += "=" * (4 - len(payload) % 4)
            decoded = base64.urlsafe_b64decode(payload)
            payload_data = json.loads(decoded)

            exp = payload_data.get("exp", 0)
            now = int(time.time())

            return (exp - now) < 300

        except:
            return False

    def _refresh_token(self) -> str:
        """Refresh access token using refresh token."""
        try:
            refresh_token = self._auth_data.get("tokens", {}).get("refresh_token")
            if not refresh_token:
                raise ValueError("No refresh_token found")

            response = requests.post(
                "https://auth.openai.com/oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": "app_EMoamEEZ73f0CkXaXp7hrann",
                },
                headers={"Content-Type": "application/json"},
            )

            if response.status_code != 200:
                raise Exception(f"Token refresh failed: {response.status_code}")

            new_tokens = response.json()

            self._auth_data["tokens"]["access_token"] = new_tokens["access_token"]
            if "refresh_token" in new_tokens:
                self._auth_data["tokens"]["refresh_token"] = new_tokens[
                    "refresh_token"
                ]
            self._auth_data["last_refresh"] = datetime.utcnow().isoformat() + "Z"

            with open(self.auth_file, "w") as f:
                json.dump(self._auth_data, f, indent=2)

            print("✓ Token refreshed successfully")
            return new_tokens["access_token"]

        except Exception as e:
            raise Exception(
                f"Failed to refresh token: {e}\n"
                "Please login to Codex CLI again: codex"
            )
