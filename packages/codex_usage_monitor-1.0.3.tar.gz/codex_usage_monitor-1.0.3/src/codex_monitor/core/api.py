"""API client for ChatGPT usage endpoint."""

from typing import Dict

import requests

from codex_monitor.core.auth import CodexTokenExtractor


class CodexUsageAPI:
    """Call ChatGPT usage API with automatic token refresh."""

    USAGE_ENDPOINT = "https://chatgpt.com/backend-api/wham/usage"

    def __init__(self, token_extractor: CodexTokenExtractor):
        self.token_extractor = token_extractor
        self.access_token: str = None
        self._refresh_token()

    def _refresh_token(self):
        """Get fresh access token."""
        self.access_token = self.token_extractor.get_token()

    def get_usage(self) -> Dict:
        """Fetch current usage data with auto-retry on 401."""
        try:
            return self._make_request()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                print("🔄 Token expired, refreshing...")
                self._refresh_token()
                return self._make_request()
            raise

    def _make_request(self) -> Dict:
        """Make API request to usage endpoint."""
        headers = {
            "accept": "*/*",
            "authorization": f"Bearer {self.access_token}",
            "cache-control": "no-cache",
        }
        response = requests.get(self.USAGE_ENDPOINT, headers=headers)
        response.raise_for_status()
        return response.json()
