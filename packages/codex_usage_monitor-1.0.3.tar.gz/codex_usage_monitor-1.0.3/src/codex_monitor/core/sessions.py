"""Session file analysis for usage patterns."""

import json
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class SessionAnalyzer:
    """Analyze local session files for usage patterns."""

    def __init__(self):
        self.sessions_dir = Path.home() / ".codex" / "sessions"

    def get_recent_sessions(self, hours: int = 2) -> List[Tuple[datetime, Path]]:
        """Get session files modified in last N hours."""
        cutoff = datetime.now() - timedelta(hours=hours)
        sessions = []

        if not self.sessions_dir.exists():
            return sessions

        for session_file in self.sessions_dir.rglob("*.jsonl"):
            try:
                mtime = datetime.fromtimestamp(session_file.stat().st_mtime)
                if mtime >= cutoff:
                    sessions.append((mtime, session_file))
            except:
                continue

        sessions.sort(reverse=True)
        return sessions

    def parse_session_data(self, session_file: Path) -> Dict:
        """Extract token usage and rate limit data from session file."""
        token_events = []
        session_meta = {}

        try:
            with open(session_file) as f:
                for line in f:
                    try:
                        data = json.loads(line)

                        # Get session metadata
                        if data.get("type") == "session_meta" and not session_meta:
                            session_meta = {
                                "cwd": data["payload"].get("cwd", "Unknown"),
                                "cli_version": data["payload"].get(
                                    "cli_version", "Unknown"
                                ),
                                "session_id": data["payload"].get("id", "Unknown"),
                            }

                        # Get token count events
                        if (
                            data.get("type") == "event_msg"
                            and data.get("payload", {}).get("type") == "token_count"
                        ):

                            timestamp = datetime.fromisoformat(
                                data["timestamp"].replace("Z", "+00:00")
                            )

                            token_events.append(
                                {
                                    "timestamp": timestamp,
                                    "total_tokens": data["payload"]["info"][
                                        "total_token_usage"
                                    ]["total_tokens"],
                                    "last_tokens": data["payload"]["info"][
                                        "last_token_usage"
                                    ]["total_tokens"],
                                    "rate_limits": data["payload"]["rate_limits"],
                                }
                            )
                    except:
                        continue
        except:
            return {}

        if not token_events:
            return {}

        # Get first and last events
        first_event = token_events[0]
        last_event = token_events[-1]

        result = {
            "file": session_file,
            "start_time": first_event["timestamp"],
            "last_time": last_event["timestamp"],
            "total_tokens": last_event["total_tokens"],
            "event_count": len(token_events),
            "last_rate_limits": last_event["rate_limits"],
            "events": token_events,
        }

        # Add session metadata
        result.update(session_meta)

        # Get git branch if in git repo
        if session_meta.get("cwd"):
            result["git_branch"] = self._get_git_branch(Path(session_meta["cwd"]))

        return result

    def _get_git_branch(self, directory: Path) -> Optional[str]:
        """Get git branch name for a directory."""
        try:
            if not directory.exists():
                return None

            result = subprocess.run(
                ["git", "-C", str(directory), "branch", "--show-current"],
                capture_output=True,
                text=True,
                timeout=1,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except:
            pass
        return None

    def calculate_usage_rate(self) -> Optional[Dict]:
        """Calculate current usage rate from recent sessions."""
        recent_sessions = self.get_recent_sessions(hours=1)

        all_events = []
        for _, session_file in recent_sessions:
            session_data = self.parse_session_data(session_file)
            if session_data:
                all_events.extend(session_data["events"])

        if len(all_events) < 2:
            return None

        # Sort by timestamp
        all_events.sort(key=lambda x: x["timestamp"])

        # Calculate rate from first to last event in last hour
        time_diff = (
            all_events[-1]["timestamp"] - all_events[0]["timestamp"]
        ).total_seconds() / 60

        if time_diff == 0:
            return None

        # Get rate limit percentage change
        first_percent = all_events[0]["rate_limits"]["primary"]["used_percent"]
        last_percent = all_events[-1]["rate_limits"]["primary"]["used_percent"]

        percent_per_minute = (
            (last_percent - first_percent) / time_diff if time_diff > 0 else 0
        )

        return {
            "percent_per_minute": percent_per_minute,
            "time_span_minutes": time_diff,
            "current_percent": last_percent,
            "events_analyzed": len(all_events),
        }

    def predict_limit_time(
        self, current_percent: float, reset_seconds: int
    ) -> Optional[str]:
        """Predict when 5-hour limit will be hit, considering reset time."""
        usage_rate = self.calculate_usage_rate()

        if not usage_rate or usage_rate["percent_per_minute"] <= 0:
            return None

        remaining_percent = 100 - current_percent
        minutes_to_limit = remaining_percent / usage_rate["percent_per_minute"]

        if minutes_to_limit < 0:
            return "Already at limit"

        # Convert reset time to minutes
        minutes_to_reset = reset_seconds / 60

        # If we'll hit the limit before reset
        if minutes_to_limit < minutes_to_reset:
            hours = int(minutes_to_limit // 60)
            minutes = int(minutes_to_limit % 60)

            if hours > 24:
                return "Safe (>24h)"

            return f"{hours}h {minutes}m"
        else:
            # Will reset before hitting limit
            return "Will reset before limit"
