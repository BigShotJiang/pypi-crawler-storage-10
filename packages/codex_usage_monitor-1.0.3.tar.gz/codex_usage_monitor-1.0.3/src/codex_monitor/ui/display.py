"""Display functions for usage information."""

from datetime import datetime, timedelta
from typing import Dict

from codex_monitor.core.sessions import SessionAnalyzer


def display_usage(data: Dict, analyzer: SessionAnalyzer):
    """Display enhanced usage with session data and predictions."""

    plan = data.get("plan_type", "unknown")
    plan_upper = plan.upper()
    rate_limit = data.get("rate_limit", {})
    primary = rate_limit.get("primary_window", {})
    secondary = rate_limit.get("secondary_window", {})

    # Header
    print("\n" + "═" * 70)
    print(f"  CODEX USAGE MONITOR - Plan: {plan_upper}")
    print("═" * 70 + "\n")

    # 5-Hour Window
    print("📊 5-Hour Window:")
    primary_percent = primary.get("used_percent", 0)
    _print_progress_bar("  Usage", primary_percent)
    _print_reset_time("  Resets", primary.get("reset_after_seconds", 0))
    print()

    # Weekly Window
    print("📅 Weekly Window:")
    secondary_percent = secondary.get("used_percent", 0)
    _print_progress_bar("  Usage", secondary_percent)
    _print_reset_time("  Resets", secondary.get("reset_after_seconds", 0))
    print()

    # Active Sessions
    recent_sessions = analyzer.get_recent_sessions(hours=2)
    if recent_sessions:
        print("🔥 Recent Sessions (last 2 hours):")
        for mtime, session_file in recent_sessions[:3]:
            session_data = analyzer.parse_session_data(session_file)
            if session_data:
                age_minutes = int((datetime.now() - mtime).total_seconds() / 60)

                # Format directory path (shorten if too long)
                cwd = session_data.get("cwd", "Unknown")
                if len(cwd) > 50:
                    cwd = "..." + cwd[-47:]

                # Session info line
                print(
                    f"  • {age_minutes}m ago: {session_data['total_tokens']:,} tokens ({session_data['event_count']} messages)"
                )
                print(f"    Dir:    {cwd}")

                # Git branch if available
                if session_data.get("git_branch"):
                    print(f"    Branch: {session_data['git_branch']}")
                print()

    # Usage Prediction
    prediction = analyzer.predict_limit_time(
        primary.get("used_percent", 0), primary.get("reset_after_seconds", 0)
    )
    usage_rate = analyzer.calculate_usage_rate()

    # Only show predictions section if there's meaningful data
    if prediction or (usage_rate and usage_rate["percent_per_minute"] > 0):
        print("🔮 Predictions:")
        # Only show usage rate if positive (active consumption)
        if usage_rate and usage_rate["percent_per_minute"] > 0:
            print(f"  Usage rate:    {usage_rate['percent_per_minute']:.2f}%/min")
        if prediction:
            print(f"  5h limit in:   {prediction}")
        print()


def _print_progress_bar(label: str, percent: int):
    """Print colored progress bar."""
    filled = int(percent / 10)
    bar = "█" * filled + "░" * (10 - filled)

    if percent < 70:
        color = "\033[92m"  # Green
    elif percent < 90:
        color = "\033[93m"  # Yellow
    else:
        color = "\033[91m"  # Red

    reset = "\033[0m"
    print(f"{label}: {color}[{bar}] {percent}%{reset}")


def _print_reset_time(label: str, seconds: int):
    """Print time remaining and absolute reset time."""
    # Calculate relative time
    td = timedelta(seconds=seconds)
    hours = td.seconds // 3600
    minutes = (td.seconds % 3600) // 60

    # Calculate absolute time
    reset_time = datetime.now() + timedelta(seconds=seconds)
    reset_time_str = reset_time.strftime("%H:%M:%S")

    print(f"  {label}:     in {hours}h {minutes}m (at {reset_time_str})")
