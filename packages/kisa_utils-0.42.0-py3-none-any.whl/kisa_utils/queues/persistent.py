from kisa_utils.db import Handle
from kisa_utils.queues.callables import queueCallsInThreads
from kisa_utils.response import Response, Error, Ok
from kisa_utils.dataStructures import KDict
from kisa_utils.storage import Path

class __PersistentQueueSingleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if not args:
            raise Exception(f'invalid instantiation of {cls}')
        id = args[0]

        if not id.isalnum():
            raise ValueError('persistent queue ID should be an alphanumeric value ie a-zA-Z0-9 with no special characters or spaces')

        if id not in cls._instances:
            cls._instances[id] = super().__call__(*args, **kwargs)

        return cls._instances[id]


class PersistentQueue(metaclass=__PersistentQueueSingleton):
    __openedQueues:dict = {} # name: PersistentQueue

    __allowedDataTypes = str|int|float|dict|KDict|list|tuple|set

    __defaultDirectoryName:str = '.kisaPersistentQueues'
    __defaultStorageLocation:str = Path.join(Path.HOME, __defaultDirectoryName)

    def __init__(self, id:str, /, *, storageLocation:str=''):
        '''
        create a new thread-safe PersistentQueue
        Args:
            id(str): the Queue ID. queue sharing an ID will all reference the same underwlying queue
            storageLocation(str): if provided, the location to store the queue. if not provided, data is stored in the default location. use `obj.defaultStorageLocation` to get the default storage directory
        '''

        if storageLocation:
            if not Path.exists(storageLocation):
                raise Exception(f'could not find storage directory: `{storageLocation}`')
        else:
            storageLocation = self.__defaultStorageLocation
            if not Path.exists(storageLocation) and not Path.createDirectory(storageLocation):
                raise Exception(f'failed to create storage directory: `{storageLocation}`')

        self.__length:int = 0
        self.id = id

        # ensure thread safety throughout the running program
        self.append = queueCallsInThreads(self.append, group=self.id)
        self.peek = queueCallsInThreads(self.peek, group=self.id)
        self.pop = queueCallsInThreads(self.pop, group=self.id)


    @property
    def defaultStorageLocation(self):
        '''
        get the default storage location
        '''
        return self.__defaultStorageLocation

    @property
    def allowedDataTypes(self):
        '''
        get data types allowed in the queue
        '''
        return self.__allowedDataTypes

    @property
    def length(self) -> int:
        '''
        get number of items in the queue
        '''
        return self.__length

    def append(self, data:__allowedDataTypes, /) -> Response:
        '''
        append to the queue
        Args:
            data(__allowedDataTypes): the data to insert, use `obj.allowedDataTypes` to get the list of allowed data types
        '''
        ...

    def peek(self, index:int, /) -> Response:
        '''
        get data at `index` without popping it from the queue
        '''
        ...

    def pop(self, /, *, index:int = 0) -> Response:
        '''
        get data at `index` and remove it from the queue
        '''
        ...
