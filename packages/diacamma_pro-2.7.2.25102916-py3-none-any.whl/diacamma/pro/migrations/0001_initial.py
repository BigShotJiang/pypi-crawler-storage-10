# -*- coding: utf-8 -*-
'''
Initial django functions

@author: Laurent GAY
@organization: sd-libre.fr
@contact: info@sd-libre.fr
@copyright: 2015 sd-libre.fr
@license: This file is part of Lucterios.

Lucterios is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Lucterios is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Lucterios.  If not, see <http://www.gnu.org/licenses/>.
'''

from __future__ import unicode_literals

from django.db import migrations
from django.utils.translation import gettext_lazy as _

from lucterios.contacts.models import Function, StructureType


def initial_values(*args):
    Function.objects.create(name=_('president'))
    Function.objects.create(name=_('vice-president'))
    Function.objects.create(name=_('manager'))
    Function.objects.create(name=_('director'))
    Function.objects.create(name=_('partner'))
    StructureType.objects.create(name=_('enterprise'))
    StructureType.objects.create(name=_('association'))


class Migration(migrations.Migration):

    dependencies = [
        ('CORE', '0001_initial'),
        ('contacts', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(initial_values),
    ]
