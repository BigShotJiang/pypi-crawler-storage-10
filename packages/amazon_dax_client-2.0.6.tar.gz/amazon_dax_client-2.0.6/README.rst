============================
Amazon DAX Client for Python
============================

The Amazon DAX Client for Python is used to access `Amazon DAX`_ clusters from
Python. It is nearly source-compatible with Boto3, with only a small change
needed to the client initialization to use DAX instead of DynamoDB.
Creating a connection to your DAX cluster requires using the cluster discovery endpoint URL returned
in the DescribeClusters response as the endpoint.

.. _`Amazon DAX`: https://aws.amazon.com/dynamodb/dax/

Installation
------------
Install Amazon DAX Client using pip:

.. code-block:: sh

    $ pip install amazon-dax-client

Quick Start
-----------
Boto3 has two different interfaces, the *resource interface* and the botocore
*client interface*. Both are supported by the Amazon DAX client, with slightly
different client initialization.

For the resource API, change from:

.. code-block:: python

    ddb = boto3.resource('dynamodb')

to

.. code-block:: python

    dax = AmazonDaxClient.resource(
        endpoint_url=<cluster_discovery_endpoint_url>)

All other ``boto3.resource()`` arguments are accepted.

For the botocore client API, change from:

.. code-block:: python

    session = botocore.session.get_session()
    ddb = session.create_client('dynamodb', ...)

to

.. code-block:: python

    session = botocore.session.get_session()
    dax = AmazonDaxClient(session, ...)

For Boto3 client API, change from:

.. code-block:: python

    ddb = boto3.client('dynamodb')

to

.. code-block:: python

    dax = AmazonDaxClient(endpoint_url=<cluster_discovery_endpoint_url>)

The Boto3 and botocore client APIs are exactly the same.

Hostname Verification for TLS connections is enabled by default when making requests from the client to the cluster
and has no effect for unencrypted clusters. This can be turned off using the client API, be sure you understand the
implication of turning it off, which is the inability to authenticate the cluster that you are connecting to.

Unsupported Features
--------------------
The Amazon DAX client does not support table operations. Any table manipulation
operations must use the regular Boto3 or botocore DynamoDB client.

Paginators are not currently supported for DAX.

Documentation
-------------
Once created, the interface is the same as the Boto3/botocore DynamoDB clients.

* `Boto3 DynamoDB resource API <http://boto3.readthedocs.io/en/latest/reference/services/dynamodb.html>`__
* `botocore DynamoDB client API <http://botocore.readthedocs.io/en/latest/reference/services/dynamodb.html>`__


For acomplete example, follow the guide to `create a sample app`_.

.. _`create a sample app`: https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DAX.client.sample-app.html

Getting Help
------------
Please use these community resources for getting help.

* Ask a question on `StackOverflow <https://stackoverflow.com/>`__ and tag it with `amazon-dynamodb-dax <https://stackoverflow.com/questions/tagged/amazon-dynamodb-dax>`__
* Ask a question on `the AWS DynamoDB forum <https://forums.aws.amazon.com/forum.jspa?forumID=131&start=0>`__
* Open a support ticket with `AWS Support <https://console.aws.amazon.com/support/home#/>`__


Changes
-------
**v2.0.6**

 * Update antlr requirement to 4.13.2 

**v2.0.5**
 
 * Add support for IPv6 and Dual Stack DAX Clusters.

**v2.0.4**

 * Add support for Python 3.9, 3.10, 3.11, 3.12, 3.13
 * Drop support for python versions below 3.8

**v2.0.3**

 * Fixes strict antlr4-python3-runtime dependency

**v2.0.1**

 * Retry on NoMoreData error
 * Fixes erroneous validation error on duplicate attribute name values in ExpressionAttributeNames
 * Fixes botocore dependency

**v2.0.0**

* Encryption in transit feature
* Drop support for python versions below 3.6

**v1.1.8**

* Retry logic bug fixes

**v1.1.7**

* Minor bug fixes

**v1.1.6**

* Linting fixes
* Updated logging to log on Logger objects

**v1.1.5**

* Add jitter and backoff for retryable exceptions

**v1.1.4**

* Fixes bug starting with clusters of less than 3 nodes.

**v1.1.3**

* Fixes and improvements to service discovery logic.
* Add support for Python 3.8.
* Fix ``'RetryHandler' object has no attribute '_cluster': AttributeError``
  problem reported in the AWS Forums.
* Fix problems found by static analysis.

**v1.1.2**

* Fixes a bug that can result in a failure to update the roster when it
  changes, which can later result in a ``NoRouteException``.

**v1.1.1**

* Fixes a bug that can result in an infinite loop on node failure.
* Update TransactWriteItem test item limit to 25.

**v1.1.0**

* Adds support for transact-get-items and transact-write-items APIs for DyanamoDB transactions.
* Improved efficiency of connection pooling.

**v1.0.7**

* Fix scheduling of background tasks.

**v1.0.6**

* Properly de-anonymize UnprocessedItems results from BatchWrite.
* Raise a proper error if no backends are available.

**v1.0.5**

* Fix UpdateItem result parsing with a subset of attributes changed

**v1.0.4**

* Use user-specified timeouts
* Fix issue with update response if the item is not changed
* Fix error decoding BatchWrite UnprocessedItems.

**v1.0.3**

* Fix AmazonDaxClient.resource() when using batch_get_items or batch_write_items.

**v1.0.2**

* Fix Python 2 encoding issues
* Fix decoding of ConsumedCapacity, ItemCollectionMetrics in batch operations

**v1.0.1**

* Initial release
