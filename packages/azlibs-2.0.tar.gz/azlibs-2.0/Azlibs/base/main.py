# AzBase.py
# AkzDev Base Encoding (Base16–91)
# Azlibs Project © 2025 - Licensed under AOSpL v1.0

import base64
import string

# === Base91 Alphabet ===
_B91_ALPHABET = (
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    '!#$%&()*+,./:;<=>?@[]^_`{|}~"'
)
_B91_DEC_TABLE = {c: i for i, c in enumerate(_B91_ALPHABET)}


# === BASE 16 ===
def b16enc(text: str) -> str:
    return base64.b16encode(text.encode()).decode()

def b16dec(encoded: str) -> str:
    return base64.b16decode(encoded).decode(errors='replace')


# === BASE 32 ===
def b32enc(text: str) -> str:
    return base64.b32encode(text.encode()).decode()

def b32dec(encoded: str) -> str:
    return base64.b32decode(encoded).decode(errors='replace')


# === BASE 58 ===
def b58enc(text: str) -> str:
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    num = int.from_bytes(text.encode(), "big")
    res = ""
    while num > 0:
        num, r = divmod(num, 58)
        res = alphabet[r] + res
    return res or "1"

def b58dec(encoded: str) -> str:
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    num = 0
    for c in encoded:
        num = num * 58 + alphabet.index(c)
    return num.to_bytes((num.bit_length() + 7) // 8, "big").decode(errors="replace")


# === BASE 62 ===
def b62enc(text: str) -> str:
    alphabet = string.digits + string.ascii_letters
    num = int.from_bytes(text.encode(), "big")
    res = ""
    while num > 0:
        num, r = divmod(num, 62)
        res = alphabet[r] + res
    return res or "0"

def b62dec(encoded: str) -> str:
    alphabet = string.digits + string.ascii_letters
    num = 0
    for c in encoded:
        num = num * 62 + alphabet.index(c)
    return num.to_bytes((num.bit_length() + 7) // 8, "big").decode(errors="replace")


# === BASE 64 ===
def b64enc(text: str) -> str:
    return base64.b64encode(text.encode()).decode()

def b64dec(encoded: str) -> str:
    return base64.b64decode(encoded).decode(errors='replace')


# === BASE 91 ===
def b91enc(text: str) -> str:
    data = text.encode()
    b, n, o = 0, 0, ''
    for byte in data:
        b |= byte << n
        n += 8
        if n > 13:
            v = b & 8191
            if v > 88:
                b >>= 13
                n -= 13
            else:
                v = b & 16383
                b >>= 14
                n -= 14
            o += _B91_ALPHABET[v % 91] + _B91_ALPHABET[v // 91]
    if n:
        o += _B91_ALPHABET[b % 91]
        if n > 7 or b > 90:
            o += _B91_ALPHABET[b // 91]
    return o

def b91dec(encoded: str) -> str:
    v, b, n, out = -1, 0, 0, bytearray()
    for c in encoded:
        if c not in _B91_DEC_TABLE:
            continue
        if v == -1:
            v = _B91_DEC_TABLE[c]
        else:
            v += _B91_DEC_TABLE[c] * 91
            b |= v << n
            n += 13 if v & 8191 > 88 else 14
            while n >= 8:
                out.append(b & 255)
                b >>= 8
                n -= 8
            v = -1
    if v != -1:
        out.append((b | v << n) & 255)
    return out.decode(errors="replace")
