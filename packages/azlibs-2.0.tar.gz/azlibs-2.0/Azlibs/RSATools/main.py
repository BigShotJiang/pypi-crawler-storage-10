import secrets
import math
import hashlib
from typing import Tuple, Optional

# === Utility Dasar RSA ===

def egcd(a: int, b: int) -> Tuple[int, int, int]:
    """Extended Euclidean Algorithm untuk mencari GCD dan koefisien Bezout"""
    if b == 0:
        return a, 1, 0
    g, x1, y1 = egcd(b, a % b)
    return g, y1, x1 - (a // b) * y1


def modinv(a: int, m: int) -> int:
    """Menghitung modular inverse dari a mod m"""
    g, x, _ = egcd(a, m)
    if g != 1:
        raise ValueError("Modular inverse tidak ada")
    return x % m


def is_probable_prime(n: int, k: int = 10) -> bool:
    """
    Miller-Rabin primality test
    Args:
        n: Angka yang akan ditest
        k: Jumlah iterasi (semakin besar = semakin akurat)
    """
    if n < 2:
        return False
    if n in (2, 3):
        return True
    if n % 2 == 0:
        return False
    
    # Test dengan prime kecil untuk optimasi
    small_primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    for p in small_primes:
        if n % p == 0:
            return n == p
    
    # Tulis n-1 sebagai 2^s * d
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    
    # Miller-Rabin test
    for _ in range(k):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def gen_prime(bits: int) -> int:
    """Generate bilangan prima dengan jumlah bit tertentu"""
    while True:
        # Generate angka random dengan bit yang tepat
        p = secrets.randbits(bits)
        # Set MSB dan LSB (agar ganjil dan panjang bit tepat)
        p |= (1 << (bits - 1)) | 1
        if is_probable_prime(p):
            return p


def genkey(bits: int = 2048) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    """
    Generate RSA keypair
    Args:
        bits: Ukuran modulus dalam bits (default 2048 untuk keamanan modern)
    Returns:
        ((e, n), (d, n)): Public key dan private key
    """
    # Generate dua prime berbeda
    p = gen_prime(bits // 2)
    q = gen_prime(bits // 2)
    while q == p:
        q = gen_prime(bits // 2)
    
    n = p * q
    phi = (p - 1) * (q - 1)
    
    # Gunakan e = 65537 (standar industri)
    e = 65537
    if math.gcd(e, phi) != 1:
        # Fallback jika 65537 tidak coprime dengan phi
        e = 3
        while math.gcd(e, phi) != 1:
            e += 2
    
    d = modinv(e, phi)
    return (e, n), (d, n)


# === OAEP Utilities ===

def mgf1(seed: bytes, length: int, hash_func=hashlib.sha256) -> bytes:
    """
    Mask Generation Function 1 (MGF1) sesuai PKCS#1 v2.1
    Args:
        seed: Seed bytes
        length: Panjang output yang diinginkan
        hash_func: Hash function yang digunakan
    """
    hlen = hash_func().digest_size
    if length > (2**32) * hlen:
        raise ValueError("Mask terlalu panjang")
    
    output = b""
    counter = 0
    while len(output) < length:
        C = counter.to_bytes(4, 'big')
        output += hash_func(seed + C).digest()
        counter += 1
    return output[:length]


def oaep_pad(message: bytes, k: int, label: bytes = b"", 
             hash_func=hashlib.sha256) -> bytes:
    """
    OAEP Padding sesuai PKCS#1 v2.1
    Args:
        message: Pesan yang akan di-pad
        k: Panjang modulus dalam bytes
        label: Label opsional (biasanya empty string)
        hash_func: Hash function yang digunakan
    """
    hlen = hash_func().digest_size
    mlen = len(message)
    
    if mlen > k - 2 * hlen - 2:
        raise ValueError("Pesan terlalu panjang untuk ukuran key")
    
    # Construct DB = lHash || PS || 0x01 || M
    lhash = hash_func(label).digest()
    ps = b"\x00" * (k - mlen - 2 * hlen - 2)
    db = lhash + ps + b"\x01" + message
    
    # Generate random seed
    seed = secrets.token_bytes(hlen)
    
    # Mask DB dan seed
    db_mask = mgf1(seed, k - hlen - 1, hash_func)
    masked_db = bytes(a ^ b for a, b in zip(db, db_mask))
    
    seed_mask = mgf1(masked_db, hlen, hash_func)
    masked_seed = bytes(a ^ b for a, b in zip(seed, seed_mask))
    
    # EM = 0x00 || maskedSeed || maskedDB
    return b"\x00" + masked_seed + masked_db


def oaep_unpad(em: bytes, label: bytes = b"", 
               hash_func=hashlib.sha256) -> bytes:
    """
    OAEP Unpadding sesuai PKCS#1 v2.1
    Args:
        em: Encoded message
        label: Label yang sama dengan saat padding
        hash_func: Hash function yang digunakan
    """
    hlen = hash_func().digest_size
    
    if len(em) < 2 * hlen + 2:
        raise ValueError("Error dekripsi: encoded message terlalu pendek")
    
    # Parse EM
    y = em[0]
    if y != 0:
        raise ValueError("Error dekripsi: byte pertama harus 0x00")
    
    masked_seed = em[1:1 + hlen]
    masked_db = em[1 + hlen:]
    
    # Unmask seed dan DB
    seed_mask = mgf1(masked_db, hlen, hash_func)
    seed = bytes(a ^ b for a, b in zip(masked_seed, seed_mask))
    
    db_mask = mgf1(seed, len(masked_db), hash_func)
    db = bytes(a ^ b for a, b in zip(masked_db, db_mask))
    
    # Verifikasi lHash
    lhash = hash_func(label).digest()
    if db[:hlen] != lhash:
        raise ValueError("Error dekripsi: label hash tidak cocok")
    
    # Cari separator 0x01
    i = db.find(b'\x01', hlen)
    if i == -1:
        raise ValueError("Error dekripsi: separator tidak ditemukan")
    
    # Verifikasi padding zeros
    if db[hlen:i] != b'\x00' * (i - hlen):
        raise ValueError("Error dekripsi: padding tidak valid")
    
    return db[i + 1:]


# === RSA-OAEP Encryption/Decryption ===

def encrypt_text(text: str, pubkey: Tuple[int, int]) -> int:
    """
    Enkripsi teks menggunakan RSA-OAEP
    Args:
        text: Teks plaintext
        pubkey: Public key (e, n)
    Returns:
        Ciphertext sebagai integer
    """
    e, n = pubkey
    msg_bytes = text.encode('utf-8')
    k = (n.bit_length() + 7) // 8
    
    padded = oaep_pad(msg_bytes, k)
    m = int.from_bytes(padded, 'big')
    
    if m >= n:
        raise ValueError("Pesan terlalu panjang untuk modulus")
    
    return pow(m, e, n)


def decrypt_text(cipher: int, privkey: Tuple[int, int]) -> str:
    """
    Dekripsi ciphertext menggunakan RSA-OAEP
    Args:
        cipher: Ciphertext sebagai integer
        privkey: Private key (d, n)
    Returns:
        Plaintext string
    """
    d, n = privkey
    k = (n.bit_length() + 7) // 8
    
    m = pow(cipher, d, n)
    em = m.to_bytes(k, 'big')
    
    msg_bytes = oaep_unpad(em)
    return msg_bytes.decode('utf-8', errors='replace')


# === Fungsi Helper untuk Signing (Opsional) ===

def sign_message(message: str, privkey: Tuple[int, int], 
                 hash_func=hashlib.sha256) -> int:
    """
    Sign pesan dengan RSA (untuk verifikasi integritas)
    Args:
        message: Pesan yang akan ditandatangani
        privkey: Private key (d, n)
        hash_func: Hash function untuk digest
    Returns:
        Signature sebagai integer
    """
    d, n = privkey
    digest = hash_func(message.encode('utf-8')).digest()
    m = int.from_bytes(digest, 'big')
    return pow(m, d, n)


def verify_signature(message: str, signature: int, pubkey: Tuple[int, int],
                     hash_func=hashlib.sha256) -> bool:
    """
    Verifikasi signature RSA
    Args:
        message: Pesan original
        signature: Signature sebagai integer
        pubkey: Public key (e, n)
        hash_func: Hash function yang sama dengan saat signing
    Returns:
        True jika valid, False jika tidak
    """
    e, n = pubkey
    digest = hash_func(message.encode('utf-8')).digest()
    expected = int.from_bytes(digest, 'big')
    decrypted = pow(signature, e, n)
    return decrypted == expected