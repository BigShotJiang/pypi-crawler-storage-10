# Azlibs V1.0.0
**A Family Dev Project**

## in Package
- RSA & OAEP PROJECT
- base 16 to 91

### Features on RSA & OAEP
- RSA key generation (512–4096 bits)
- OAEP secure padding (SHA-256)
- Text encryption & decryption
- Digital signature support (sign & verify)
- Pure Python - no external dependencies

### Features on our base
- Base enc/dec: base16, base32, base85, base62, base64, base91
- Pure Python script - no external dependencies

## Installation Azlibs
```
pip install azlibs
```

## Usage of RSA

### Generate RSA Keypair
```python
from Azlibs.RSATools import genkey

# Generate a 2048-bit RSA keypair
public_key, private_key = genkey(2048)

print("Public Key:", public_key)
print("Private Key:", private_key)
```

### Encrypt and Decrypt Text
```python
from Azlibs.RSATools import encrypt_text, decrypt_text

message = "Hello from AkzDev!"
cipher = encrypt_text(message, public_key)
print("Encrypted:", cipher)

decrypted = decrypt_text(cipher, private_key)
print("Decrypted:", decrypted)
```

Output (contoh):
```
Encrypted: 592031591054735219...
Decrypted: Hello from AkzDev!
```

### Sign and Verify Messages
```python
from Azlibs.RSATools import sign_message, verify_signature

msg = "This is an important message"
signature = sign_message(msg, private_key)
print("Signature:", signature)

# Verification
is_valid = verify_signature(msg, signature, public_key)
print("Valid:", is_valid)
```

Output (contoh):
```
Signature: 38475018274018247...
Valid: True
```

## Usage base

### Encryption (base64 example)
```python
from Azlibs.base import b64enc

a = "Hallo World"
b = b64enc(a)
print("encrypted text :", b)
```

### Decryption (base64 example)
```python
from Azlibs.base import b64dec

a = "SGFsbG8gV29ybGQ="  # Hello World
b = b64dec(a)
print("plaintext from decrypt :", b)
```

---
## License
This project is licensed under the MIT License — see LICENSE for details.  
Made with love by AkzDev Team  
A project proudly part of the Akuzz Open Source Ecosystem.

### Note
Azlibs is still in Version 1.0.0

“Azlibs: simple, powerful, and open for every developer.”