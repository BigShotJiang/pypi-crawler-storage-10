# About noctua-mcp

MCP server for Barista to control Noctua editing
