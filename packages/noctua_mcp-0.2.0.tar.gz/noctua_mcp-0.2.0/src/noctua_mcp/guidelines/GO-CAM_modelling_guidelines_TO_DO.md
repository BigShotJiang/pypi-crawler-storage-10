Moved here.

https://docs.google.com/document/d/13MWyxdfcS78dYz9hg61R4ZS4ydp3OY8Y16LAb3xD3Ug/edit#
