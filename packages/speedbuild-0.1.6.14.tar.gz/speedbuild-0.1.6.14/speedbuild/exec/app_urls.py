from django.urls import path

# speedbuild_app 

urlpatterns = [

]
