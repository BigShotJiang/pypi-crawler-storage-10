from .base.cleanup_stale_radacct import BaseCleanupRadacctCommand


class Command(BaseCleanupRadacctCommand):
    pass
