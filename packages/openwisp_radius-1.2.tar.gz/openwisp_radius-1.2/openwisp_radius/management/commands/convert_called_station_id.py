from .base.convert_called_station_id import BaseConvertCalledStationIdCommand


class Command(BaseConvertCalledStationIdCommand):
    pass
