from .base.delete_old_radiusbatch_users import BaseDeleteOldRadiusBatchUsersCommand


class Command(BaseDeleteOldRadiusBatchUsersCommand):
    pass
