from .base.delete_old_postauth import BaseDeleteOldPostauthCommand


class Command(BaseDeleteOldPostauthCommand):
    pass
