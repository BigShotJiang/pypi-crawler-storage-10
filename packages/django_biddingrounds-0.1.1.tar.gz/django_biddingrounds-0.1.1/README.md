# django-biddingrounds

A reusable Django app for organizing bidding rounds.

## Installation

```bash
pip install django-biddingrounds
```

## Use Case

See the [example project](https://git.hack-hro.de/alexgorji/django-biddingrounds/-/tree/main/example) for a possible test case using **Juntagrico**.
