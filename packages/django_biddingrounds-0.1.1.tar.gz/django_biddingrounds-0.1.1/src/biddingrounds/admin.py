from django.contrib import admin
from .models import Bid, BiddingRound, BiddingRoundTarget

admin.site.register(BiddingRound)
admin.site.register(Bid)


@admin.register(BiddingRoundTarget)
class BiddinRoundTargetAdmin(admin.ModelAdmin):
    list_display = ("biddinground", "target", "content_type")
