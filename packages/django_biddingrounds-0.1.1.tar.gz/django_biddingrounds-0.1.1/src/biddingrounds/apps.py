from django.apps import AppConfig


class BiddingRoundsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "biddingrounds"
    verbose_name = "Bidding Rounds"
