from django.apps import AppConfig


class DummyTestappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dummy_testapp"
