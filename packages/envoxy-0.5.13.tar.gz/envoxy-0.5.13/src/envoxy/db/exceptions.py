class DatabaseException(Exception):
    pass
