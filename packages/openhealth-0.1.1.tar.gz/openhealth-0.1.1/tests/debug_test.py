"""
Minimal health checker demo script.
This script demonstrates the core health checking functionality.
"""

import json
import time
from openHealth import HealthChecker


def create_test_config():
    """Create a test configuration file with Slack notifications."""
    config = {
        "services": [
            {
                "name": "Base Model (bodh-x0) Test Service",
                "url": "http://34.31.180.53:2306",
                "health_endpoint": "/health",
                "interval": 15,
                "timeout": 10,
                "max_retries": 2,
                "expected_status_code": 200,
                "web_interface": {"enabled": True},
                "slack_integration": {
                    "enabled": True,
                    "webhook_url": "https://hooks.slack.com/services/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",
                    "channel": "#health-alerts",
                    "message_template": "🚨 Service {name} is {status} at {timestamp}\nURL: {url}\nError: {error}"
                }
            },
        ]
    }

    with open("debug_config.json", "w") as f:
        json.dump(config, f, indent=2)

    return "debug_config.json"


def main():
    print("=== Health Checker Core Demo ===\n")

    # Create test configuration
    config_file = create_test_config()
    print(f"Created test configuration: {config_file}")

    # Create simple status callback
    def status_callback(result):
        status_icon = "[OK]" if result.is_healthy() else "[ERROR]"
        error_info = f" - Error: {result.error_message}" if result.error_message else ""
        print(f"{status_icon} {result.service_name}: {result.status} ({result.response_time * 1000:.1f}ms){error_info}")

    # Initialize health checker
    print("\nInitializing health checker...")
    checker = HealthChecker(
        config_path=config_file,
        log_level="INFO"
    )

    # Add status callback
    checker.add_status_callback(status_callback)

    try:
        print("\nStarting health checker...")
        checker.start()

        print("Health checker started successfully!")
        print("Press Ctrl+C to stop.")

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nTest interrupted by user. Stopping...")

    finally:
        print("\nStopping health checker...")
        checker.stop()
        print("Health checker stopped.")


if __name__ == "__main__":
    main()
