"""TUI (Text User Interface) components for InstructionKit."""

from instructionkit.tui.installer import show_installer_tui

__all__ = ["show_installer_tui"]
