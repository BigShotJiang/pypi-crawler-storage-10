"""Entry point for running instructionkit as a module."""

from instructionkit.cli.main import app

if __name__ == "__main__":
    app()
