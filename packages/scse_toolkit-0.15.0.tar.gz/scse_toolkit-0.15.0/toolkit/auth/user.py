from pydantic import BaseModel


class ServiceAccount(BaseModel):
    username: str
    is_staff: bool = False
    is_superuser: bool = False
    is_verified: bool = False
    is_authenticated: bool = True


class User(BaseModel):
    id: int
    username: str
    email: str
    is_staff: bool = False
    is_superuser: bool = False
    is_verified: bool = False
    is_authenticated: bool = True
    groups: list[int]

    def __str__(self) -> str:
        return f"<User id={self.id} username={self.username}>"
