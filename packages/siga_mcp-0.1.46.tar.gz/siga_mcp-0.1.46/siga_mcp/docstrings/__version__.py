from siga_mcp.utils import get_package_version


def docs() -> str:
    return get_package_version()
