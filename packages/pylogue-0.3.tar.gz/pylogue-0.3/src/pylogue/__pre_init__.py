"""Console script for pylogue."""
import typer

cli = typer.Typer(name="pylogue", help="A Chatbot UI build for Pydantic-AI agents", no_args_is_help=True)