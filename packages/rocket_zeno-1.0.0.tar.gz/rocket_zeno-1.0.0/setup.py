from setuptools import setup

setup(
   name='rocket-zeno', 
   version='1.0.0',
   author='Abderrahim Zineddine',
   author_email='z.abderrahim@esi-sba.dz',
   packages=['rocket'],               
   url='https://pypi.org/project/rocket-zeno/',
   license='LICENSE.txt',
   description='An awesome package about rockets',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=[]               
)