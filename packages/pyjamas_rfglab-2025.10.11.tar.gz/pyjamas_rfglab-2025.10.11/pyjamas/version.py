import os
import tomlkit

pyproject_file = os.path.join(os.path.dirname(__file__), "..", "pyproject.toml")
with open(pyproject_file, "r", encoding="utf-8") as f:
    pyproject_data = tomlkit.load(f)

__version__ = pyproject_data["project"]["version"]