"""Version information for Dinnovos Agent"""

__version__ = "0.5.3"