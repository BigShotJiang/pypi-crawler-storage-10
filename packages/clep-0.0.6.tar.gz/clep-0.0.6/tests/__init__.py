# -*- coding: utf-8 -*-

"""CLEP tests."""
