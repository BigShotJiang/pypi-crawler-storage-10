.. _cli:

Command Line Interface
======================
CLEP commands.

.. click:: clep.cli:main
   :prog: clep
   :show-nested:
