# -*- coding: utf-8 -*-

"""Wrap Machine-Learning Classifiers for clep."""

from .hpo import do_classification

__all__ = ['do_classification']
