# -*- coding: utf-8 -*-

"""A Python package for generating Hybrid Data- and Knowledge- Driven Patient Representations."""
