"""
Django management commands for the jobs system.
"""
