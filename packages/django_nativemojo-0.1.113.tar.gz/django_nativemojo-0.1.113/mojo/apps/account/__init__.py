default_app_config = 'account.apps.AppConfig'
