# -*- coding: utf-8 -*-
"""optimg"""
__copyright__ = "Copyright (c) 2025 https://github.com/davidohnee"
