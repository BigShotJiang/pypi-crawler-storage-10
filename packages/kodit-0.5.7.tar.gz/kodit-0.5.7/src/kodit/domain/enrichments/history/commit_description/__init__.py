"""Commit description enrichments."""
