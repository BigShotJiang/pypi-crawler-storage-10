# Bragg

## Development

```bash
# Create and activate virtual environment
uv sync
. .venv/bin/activate

# Install pre-commit hooks
pre-commit install
```
