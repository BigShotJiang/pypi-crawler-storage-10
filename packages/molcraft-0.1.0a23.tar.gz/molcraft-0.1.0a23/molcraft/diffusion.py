import warnings
import keras 
import tensorflow as tf
import numpy as np

from molcraft import ops
from molcraft import tensors 
from molcraft import layers 
from molcraft import models 


# smiles = pd.read_csv('../../data/rt/RIKEN.csv')['smiles'].values


# graph = featurizers.MolGraphFeaturizer3D(super_node=False)(smiles)
# graph.node['coordinate']


# encoder = molcraft.models.GraphModel.from_layers(
#     [
#         diffusion.CoordinateNoise(),
#         molcraft.layers.NodeEmbedding(128),
#         molcraft.layers.EdgeEmbedding(128),
#         molcraft.layers.AddContext('position'),
#         molcraft.layers.MPConv(128),
#         molcraft.layers.AddContext('position'),
#         molcraft.layers.MPConv(128),
#         molcraft.layers.AddContext('position'),
#     ]
# )

# decoder = keras.Sequential([
#     keras.layers.Dense(128, activation='relu'),
#     keras.layers.Dense(3),
# ])

# model = diffusion.CoordinateNoisePredictor(encoder, decoder)

# model(graph)

# model.save('/tmp/model.keras')
# model = molcraft.models.load_model('/tmp/model.keras')

# model.compile(keras.optimizers.Adam(1e-3), 'mse')
# model.fit(graph, epochs=100)


# from rdkit.Geometry import Point3D

# def energy(smiles, coordinate):
#     m = chem.Mol.from_encoding(smiles)
#     m = chem.embed_conformers(m, 1)
#     conf = m.GetConformer()
#     for i in range(m.GetNumAtoms()):
#         x, y, z = coordinate[i]
#         conf.SetAtomPosition(i, Point3D(float(x), float(y), float(z)))
#     return m, chem.conformer_energies(m)[0]

# def denoise(
#     graph: tensors.GraphTensor,
#     model,
# ):

#     print("----")
#     print(energy(smiles[0], graph[0].node['coordinate'])[-1])
#     print("----")
    
#     beta = keras.ops.linspace(1e-4, 1e-2, 100)
#     alpha = 1 - beta
#     alpha_bar = keras.ops.cumprod(alpha)
#     sigma = keras.ops.sqrt(beta[1:] * (1.0 - alpha_bar[:-1]) / (1.0 - alpha_bar[1:]))
    
#     graph = graph.update(
#         {
#             'context': {
#                 'position': keras.ops.ones_like(graph.context['size']) * 99
#             },
#             'node': {
#                 'coordinate': keras.random.normal(graph.node['coordinate'].shape)
#             }
#         }
#     )

#     for t in reversed(range(100)):
#         alpha_t = alpha[t]
#         alpha_bar_t = alpha_bar[t]

#         a = 1 / keras.ops.sqrt(alpha_t)

#         b = (1 - alpha_t) / keras.ops.sqrt(1 - alpha_bar_t)

#         if t > 0:
#             z = keras.random.normal(()) * sigma[t-1]
#         else:
#             z = 0.0

#         graph = graph.update({
#             'node': {
#                 'coordinate': (
#                     a * (graph.node['coordinate'] - b * model(graph)) + z
#                 ) 
#             } 
#         }) 
        
        
#         print(energy(smiles[0], graph[0].node['coordinate'])[-1])

#     return graph
        
# graph_updated = denoise(graph[:1], model)x
# mol, e = energy(smiles[0], graph_updated[0].node['coordinate'])
# print(e)
# Chem.Mol(mol)

@keras.saving.register_keras_serializable(package='molcraft')
class CoordinateNoisePredictor(models.GraphModel):

    def __init__(self, encoder, decoder, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.encoder = encoder 
        self.decoder = decoder 

    def propagate(self, tensor):
        return self.decoder(self.encoder(tensor).node['feature'])
    
    def train_step(self, tensor: tensors.GraphTensor) -> dict[str, float]:
        with tf.GradientTape() as tape:
            tensor = self.encoder(tensor)
            feature = tensor.node['feature']
            noise_true = tensor.node['label']
            noise_pred = self.decoder(feature)
            loss = self.compute_loss(tensor, noise_true, noise_pred)
            loss = self.optimizer.scale_loss(loss)
        trainable_weights = self.trainable_weights 
        gradients = tape.gradient(loss, trainable_weights)
        self.optimizer.apply_gradients(zip(gradients, trainable_weights))
        return self.compute_metrics(tensor, noise_true, noise_pred)
    
    def test_step(self, tensor: tensors.GraphTensor) -> dict[str, float]:
        tensor = self.encoder(tensor)
        feature = tensor.node['feature']
        noise_true = tensor.node['label']
        noise_pred = self.decoder(feature)
        return self.compute_metrics(tensor, noise_true, noise_pred)
    
    def get_config(self) -> dict:
        config = super().get_config()
        config['encoder'] = keras.saving.serialize_keras_object(self.encoder)
        config['decoder'] = keras.saving.serialize_keras_object(self.decoder)
        return config 
    
    @classmethod
    def from_config(cls, config: dict):
        config['encoder'] = keras.saving.deserialize_keras_object(config['encoder'])
        config['decoder'] = keras.saving.deserialize_keras_object(config['decoder'])
        return super().from_config(config)


@keras.saving.register_keras_serializable(package='molcraft')
class CoordinateNoise(layers.GraphLayer):

    def __init__(
        self, 
        beta: tuple[float, float] = (1e-4, 1e-2),
        position_dim: int = 128,
        max_timesteps: int = 100,
        **kwargs
    ) -> None:
        super().__init__(**kwargs)
        self._beta = beta 
        self._max_timesteps = max_timesteps
        beta = keras.ops.linspace(*self._beta, self._max_timesteps)
        alpha = 1 - beta
        alpha_cumprod = keras.ops.cumprod(alpha)
        alpha_cumprod = keras.ops.expand_dims(alpha_cumprod, -1)
        self._alpha_cumprod = alpha_cumprod
        self._timestep_embedding = TimestepEmbedding(dim=position_dim)

    def propagate(self, graph: tensors.GraphTensor) -> tensors.GraphTensor:
        if 'position' in graph.context:
            return graph.update({'context': {'position': self._timestep_embedding(graph.context['position'])}})
        
        timestep = keras.random.randint(
            shape=(graph.num_subgraphs,), minval=0, maxval=self._max_timesteps
        )
        alpha_cumprod = ops.gather(
            ops.gather(self._alpha_cumprod, timestep), graph.graph_indicator
        )
        epsilon = keras.random.normal(
            shape=keras.ops.shape(graph.node['coordinate']), mean=0, stddev=1
        )
        noisy_coordinate = (
            keras.ops.sqrt(alpha_cumprod) * graph.node['coordinate'] + 
            keras.ops.sqrt(1 - alpha_cumprod) * epsilon
        )
        timestep = self._timestep_embedding(timestep)
        return graph.update(
            {
                'context': {
                    'position': timestep,
                },
                'node': {
                    'coordinate': noisy_coordinate, 
                    'label': epsilon
                },
            }
        )

    def get_config(self) -> dict:
        config = super().get_config()
        config['beta'] = self._beta 
        config['max_timesteps'] = self._max_timesteps
        return config 
    

class TimestepEmbedding(keras.layers.Layer):
    
    def __init__(self, dim: int, max_wavelength: int = 10000, **kwargs) -> None:
        super().__init__(**kwargs)
        self._dim = dim
        self._max_wavelength = max_wavelength

    def call(self, inputs: tf.Tensor) -> tf.Tensor:
        timestep = keras.ops.cast(inputs, 'float32')
        embedding = keras.ops.log(self._max_wavelength) / (self._dim // 2 - 1)
        embedding = keras.ops.exp(
            -embedding * keras.ops.arange(self._dim // 2, dtype='float32')
        )
        embedding = timestep[:, None] * embedding[None, :]
        embedding = keras.ops.concatenate(
            [keras.ops.sin(embedding), keras.ops.cos(embedding)], axis=-1
        )
        return embedding


    def get_config(self) -> dict:
        config = super().get_config()
        config['dim'] = self._dim
        config['max_wavelength'] = self._max_wavelength
        return config 
    
