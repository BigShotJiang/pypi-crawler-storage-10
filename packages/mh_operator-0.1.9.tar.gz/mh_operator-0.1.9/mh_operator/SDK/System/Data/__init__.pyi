from . import SqlServerCe
