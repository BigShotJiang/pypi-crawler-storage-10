from setuptools import setup

setup(
   name='linear_regression_from_scratch',
   version='1.0.0',
   author='Abderrahmane bendaia',
   author_email='abdoubendaia7@gmail.com',
   packages=['linear_regression_from_scratch'],
   url='http://pypi.python.org/pypi/linear_regression_from_scratch/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['linear_regression_from_scratch']
)