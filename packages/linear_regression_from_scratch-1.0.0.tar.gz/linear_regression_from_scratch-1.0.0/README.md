# linear_regression_from_scratch

`linear_regression_from_scratch` is a Python library for ..........

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `linear_regression_from_scratch`.

```bash
pip install linear_regression_from_scratch
```

## Usage

```python
import linear_regression_from_scratch

# returns 'words'
linear_regression_from_scratch.module_name('word')

# returns 'geese'
linear_regression_from_scratch.module_name('goose')

# returns 'phenomenon'
linear_regression_from_scratch.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)