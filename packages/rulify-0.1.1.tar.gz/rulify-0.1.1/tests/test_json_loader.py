"""
Tests for JSON rule loader using sample.json schema.
"""
import json
import os
import unittest

from rulify import RuleEngine, load_rules_from_json, rules_from_dict


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


class TestJsonLoader(unittest.TestCase):
    def test_rules_from_sample_json(self):
        sample_path = os.path.join(ROOT, "sample.json")
        rules = load_rules_from_json(sample_path)
        engine = RuleEngine()
        for r in rules:
            engine.add_rule(r)

        ctx = {
            "weekdays": 3,
            "weekends": 2,
            "base_rate_weekday": 100,
            "base_rate_weekend": 150,
            "stay_days": 7,
            "start_day": "Monday",
            "children": [4, 7, 13],
            "adults": 5,
            "flight_price_adult": 200,
            "has_flight": True,
            "has_transfer": True,
            "transfer_price": 50,
            "total_package": 1000,
        }

        result = engine.run(ctx)

        # Hotel price
        expected_hotel = (3 * 100) + (2 * 150)
        expected_hotel *= 0.9  # weekly discount
        self.assertAlmostEqual(result["hotel_total"], expected_hotel, places=5)

        # Child discounts
        # last computed child_price will correspond to last item (13)
        self.assertEqual(result["child_price"], 100)

        # Flight discount
        expected_flight = 5 * 200
        expected_flight *= 0.95
        self.assertAlmostEqual(result["flight_total"], expected_flight, places=5)

        # Transfer discount
        self.assertAlmostEqual(result["transfer_total"], 25)  # 50 * 0.5

        # Package bonus
        self.assertAlmostEqual(result["total_package"], 1000 * 0.93, places=5)

    def test_rules_from_dict_minimal(self):
        data = {
            "rules": [
                {
                    "name": "set flag",
                    "actions": [{"type": "compute", "expression": "flag = True"}],
                }
            ]
        }
        rules = rules_from_dict(data)
        engine = RuleEngine()
        for r in rules:
            engine.add_rule(r)
        res = engine.run({})
        self.assertTrue(res["flag"])


if __name__ == "__main__":
    unittest.main()