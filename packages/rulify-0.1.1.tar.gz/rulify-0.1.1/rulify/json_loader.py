"""
Utilities to load rules from a JSON schema compatible with sample.json.

Schema highlights supported:
- Rule fields: id, name, description, priority, conditions, actions, foreach
- Conditions: logical groups {"all": [..]}, {"any": [..]}; leaf comparator with {"var": name, OP: value}
- Supported comparators: ==, !=, >, >=, <, <= (with bools/numbers/strings)
- Actions:
  - {"type": "compute", "expression": "python_expression"}
  - {"type": "if", "condition": "python_condition", "then": "python_expression"}

Security note: This loader uses a restricted eval/exec environment with only the context dictionary
available. It is intended for trusted rule definitions. Do not use with untrusted input.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from .rule import Rule


ComparatorFunction = Callable[[Any, Any], bool]


def _get_comparator(op: str) -> ComparatorFunction:
    if op == "==":
        return lambda a, b: a == b
    if op == "!=":
        return lambda a, b: a != b
    if op == ">":
        return lambda a, b: a > b
    if op == ">=":
        return lambda a, b: a >= b
    if op == "<":
        return lambda a, b: a < b
    if op == "<=":
        return lambda a, b: a <= b
    raise ValueError(f"Unsupported comparator: {op}")


def _eval_condition_leaf(cond: Dict[str, Any], ctx: Dict[str, Any]) -> bool:
    if "var" not in cond:
        raise ValueError("Condition leaf must include 'var'")
    var_name = cond["var"]
    # the remaining key should be the operator
    op_keys = [k for k in cond.keys() if k != "var"]
    if len(op_keys) != 1:
        raise ValueError("Condition leaf must include exactly one comparator")
    op = op_keys[0]
    value = cond[op]
    comparator = _get_comparator(op)
    return comparator(_safe_get(ctx, var_name), value)


def _safe_get(ctx: Dict[str, Any], path: str) -> Any:
    """Get nested value from ctx using dot notation, e.g., 'user.age'."""
    parts = path.split(".")
    current: Any = ctx
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _eval_conditions(conditions: Optional[Dict[str, Any]], ctx: Dict[str, Any]) -> bool:
    if not conditions:
        return True
    if "all" in conditions:
        return all(_eval_condition_leaf(c, ctx) for c in conditions["all"])
    if "any" in conditions:
        return any(_eval_condition_leaf(c, ctx) for c in conditions["any"])
    # Single leaf condition
    return _eval_condition_leaf(conditions, ctx)


def _make_action_callable(actions: List[Dict[str, Any]]) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """Create an action function that executes action list sequentially."""

    def action(ctx: Dict[str, Any]) -> Dict[str, Any]:
        # Restricted globals: expose only the context mapping
        restricted_globals: Dict[str, Any] = {"__builtins__": {}}
        # locals proxy to mutate ctx directly
        local_vars = ctx

        for act in actions:
            act_type = act.get("type")
            if act_type == "compute":
                expr = act.get("expression")
                if not expr:
                    continue
                exec(expr, restricted_globals, local_vars)
            elif act_type == "if":
                cond_expr = act.get("condition")
                then_expr = act.get("then")
                if not cond_expr or not then_expr:
                    continue
                if eval(cond_expr, restricted_globals, local_vars):
                    exec(then_expr, restricted_globals, local_vars)
            else:
                raise ValueError(f"Unsupported action type: {act_type}")
        return ctx

    return action


def _make_condition_callable(conditions: Optional[Dict[str, Any]]) -> Callable[[Dict[str, Any]], bool]:
    return lambda ctx: _eval_conditions(conditions, ctx)


def _expand_foreach(rule_def: Dict[str, Any]) -> List[Rule]:
    """
    Expand a rule with a 'foreach' field into a rule that iterates items.
    The iterator variable is 'item' (as used by sample.json actions) and will be
    bound into the context for each iteration.
    """
    foreach_key = rule_def.get("foreach")
    if not foreach_key:
        return [_build_rule(rule_def)]

    # For foreach, we build a wrapper rule that loops items and applies actions per item
    base_conditions = rule_def.get("conditions")
    actions = rule_def.get("actions", [])
    name = rule_def.get("name") or rule_def.get("id") or "Rule"
    priority = int(rule_def.get("priority", 0))

    def condition(ctx: Dict[str, Any]) -> bool:
        # Only run if iterable exists; conditions are evaluated per item in action
        return _safe_get(ctx, foreach_key) is not None

    def loop_action(ctx: Dict[str, Any]) -> Dict[str, Any]:
        items = _safe_get(ctx, foreach_key) or []
        for itm in items:
            # Provide 'item' in the same context mapping for expressions
            ctx["item"] = itm
            # Evaluate optional base conditions per item if provided
            if _eval_conditions(base_conditions, ctx):
                _make_action_callable(actions)(ctx)
        # cleanup leaked iterator variable
        if "item" in ctx:
            del ctx["item"]
        return ctx

    return [Rule(name=name, condition=condition, action=loop_action, priority=priority)]


def _build_rule(rule_def: Dict[str, Any]) -> Rule:
    name = rule_def.get("name") or rule_def.get("id") or "Rule"
    priority = int(rule_def.get("priority", 0))
    conditions = rule_def.get("conditions")
    actions = rule_def.get("actions", [])
    condition_fn = _make_condition_callable(conditions)
    action_fn = _make_action_callable(actions)
    return Rule(name=name, condition=condition_fn, action=action_fn, priority=priority)


def rules_from_dict(data: Dict[str, Any]) -> List[Rule]:
    rules: List[Rule] = []
    for rd in data.get("rules", []):
        rules.extend(_expand_foreach(rd))
    # sort by priority descending to match engine's behavior
    rules.sort(key=lambda r: r.priority, reverse=True)
    return rules


def load_rules_from_json(path: str) -> List[Rule]:
    import json
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return rules_from_dict(data)