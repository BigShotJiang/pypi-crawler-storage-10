from svtplay_dl.service.aftonbladet import Aftonbladet
from svtplay_dl.service.aftonbladet import Aftonbladettv
from svtplay_dl.service.angelstudios import Angelstudios
from svtplay_dl.service.barnkanalen import Barnkanalen
from svtplay_dl.service.bigbrother import Bigbrother
from svtplay_dl.service.cmore import Cmore
from svtplay_dl.service.disney import Disney
from svtplay_dl.service.dplay import Discoveryplus
from svtplay_dl.service.dr import Dr
from svtplay_dl.service.efn import Efn
from svtplay_dl.service.eurosport import Eurosport
from svtplay_dl.service.expressen import Expressen
from svtplay_dl.service.facebook import Facebook
from svtplay_dl.service.filmarkivet import Filmarkivet
from svtplay_dl.service.flowonline import Flowonline
from svtplay_dl.service.koket import Koket
from svtplay_dl.service.lemonwhale import Lemonwhale
from svtplay_dl.service.mtvnn import Mtvnn
from svtplay_dl.service.mtvservices import Mtvservices
from svtplay_dl.service.nhl import NHL
from svtplay_dl.service.nrk import Nrk
from svtplay_dl.service.oppetarkiv import OppetArkiv
from svtplay_dl.service.picsearch import Picsearch
from svtplay_dl.service.plutotv import Plutotv
from svtplay_dl.service.pokemon import Pokemon
from svtplay_dl.service.radioplay import Radioplay
from svtplay_dl.service.raw import Raw
from svtplay_dl.service.regeringen import Regeringen
from svtplay_dl.service.riksdagen import Riksdagen
from svtplay_dl.service.ruv import Ruv
from svtplay_dl.service.solidtango import Solidtango
from svtplay_dl.service.sportlib import Sportlib
from svtplay_dl.service.sr import Sr
from svtplay_dl.service.svt import Svt
from svtplay_dl.service.svtbarn import Svtbarn
from svtplay_dl.service.svtplay import Svtplay
from svtplay_dl.service.tv4play import Tv4
from svtplay_dl.service.tv4play import Tv4play
from svtplay_dl.service.twitch import Twitch
from svtplay_dl.service.urplay import Urplay
from svtplay_dl.service.vasaloppet import Vasaloppet
from svtplay_dl.service.vg import Vg
from svtplay_dl.service.viaplay import Viafree
from svtplay_dl.service.viasatsport import Viasatsport
from svtplay_dl.service.vimeo import Vimeo
from svtplay_dl.service.youplay import Youplay

sites = [
    Aftonbladet,
    Aftonbladettv,
    Angelstudios,
    Barnkanalen,
    Bigbrother,
    Cmore,
    Disney,
    Discoveryplus,
    Dr,
    Efn,
    Eurosport,
    Expressen,
    Facebook,
    Filmarkivet,
    Flowonline,
    Koket,
    Twitch,
    Lemonwhale,
    Mtvservices,
    Mtvnn,
    NHL,
    Nrk,
    Picsearch,
    Plutotv,
    Pokemon,
    Ruv,
    Radioplay,
    Solidtango,
    Sportlib,
    Sr,
    Svt,
    Svtbarn,
    Svtplay,
    OppetArkiv,
    Tv4,
    Tv4play,
    Urplay,
    Vasaloppet,
    Viafree,
    Viasatsport,
    Vimeo,
    Vg,
    Youplay,
    Regeringen,
    Riksdagen,
    Raw,
]
