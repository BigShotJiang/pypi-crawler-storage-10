# ex:ts=4:sw=4:sts=4:et
# -*- tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*-
import logging
import sys

log = logging.getLogger("svtplay_dl")
progress_stream = sys.stderr
