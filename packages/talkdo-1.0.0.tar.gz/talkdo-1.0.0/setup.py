"""
Setup script for the CLI Task Manager.

This script provides backward compatibility with setuptools
while using the modern pyproject.toml configuration.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
