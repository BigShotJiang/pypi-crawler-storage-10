"""
Trello CLI - Official Python command-line interface for Trello
"""

__version__ = "2.1.3"
__author__ = "Bernard Uriza Orozco"
