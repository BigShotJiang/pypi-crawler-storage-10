from django.apps import AppConfig


class SecurityLoggerAppConfig(AppConfig):

    name = 'security'
    verbose_name = 'Security'
