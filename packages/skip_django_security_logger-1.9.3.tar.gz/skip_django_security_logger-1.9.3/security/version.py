VERSION = (1, 9, 3)


def get_version():
    return '.'.join(map(str, VERSION))
