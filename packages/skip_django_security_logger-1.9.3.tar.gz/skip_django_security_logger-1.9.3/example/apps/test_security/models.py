from django.contrib.auth.models import User

__all__ = [
    "User",
]
