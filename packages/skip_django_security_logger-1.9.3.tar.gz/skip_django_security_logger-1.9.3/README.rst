Prolog
======

Django-security-logger is library for logging input and output request. The library provides throttling security mechanism.

Installation
------------

.. code:: bash

    pip install skip-django-security-logger


Docs
----

For more details see [docs](http://django-security-logger.readthedocs.org/)
