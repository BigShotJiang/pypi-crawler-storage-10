import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.templates.check_component_and_layout_file_placement import (
    check_component_and_layout_file_placement,
)


class TestComponentLayoutEmplacement(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.app_name = "myapp"
        self.app_path = self.project_root / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_component_wrong_location(self):
        errors = []
        self.create_file(
            "templates/myapp/pages/page.html",
            "<div> {% include 'myapp/pages/offer/components/header.html' %} <div>",
        )
        self.create_file(
            "templates/myapp/pages/offer/components/header.html", "<div>Header</div>"
        )

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertTrue(any("Fichier mal placé" in error for error in errors))

    def test_component_in_multiple_files(self):
        errors = []
        self.create_file(
            "templates/myapp/pages/offer/page.html",
            "<div> {% include 'myapp/pages/offer/components/offer.html' %} <div>",
        )
        self.create_file(
            "templates/myapp/pages/offer/other/page.html",
            "<div> {% include 'myapp/pages/offer/components/offer.html' %} <div>",
        )
        self.create_file(
            "templates/myapp/pages/offer/details/page.html",
            "<div> {% include 'myapp/pages/offer/components/offer.html' %} <div>",
        )
        self.create_file(
            "templates/myapp/pages/offer/components/offer.html", "<div>offer</div>"
        )

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_component_in_layout_base(self):
        errors = []
        self.create_file(
            "templates/myapp/layout/base.html",
            "{% include 'myapp/components/header.html' %}",
        )
        self.create_file("templates/myapp/components/header.html", "<div>Header</div>")

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertFalse(errors)

    def test_duplicate_component_files(self):
        errors = []
        self.create_file(
            "templates/myapp/pages/page.html",
            "{% include 'myapp/components/header.html' %}\n{% include 'myapp/partials/components/header.html' %}",
        )
        self.create_file("templates/myapp/components/header.html", "<div>Header</div>")
        self.create_file(
            "templates/myapp/partials/components/header.html",
            "<div>Header Duplicate</div>",
        )

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertTrue(
            any("Problème de fichiers en double" in error for error in errors)
        )

    def test_section_wrong_location(self):
        errors = []
        self.create_file(
            "templates/myapp/pages/page.html",
            "{% include 'myapp/sections/offer/footer.html' %}",
        )
        self.create_file(
            "templates/myapp/pages/offer/sections/footer.html", "<div>Footer</div>"
        )

        check_component_and_layout_file_placement(self.app_path, errors)

        self.assertTrue(any("Fichier mal placé" in error for error in errors))

    def test_layout_wrong_location(self):
        errors = []
        self.create_file(
            "templates/myapp/pages/page.html",
            "{% extends 'myapp/offer/layout/main.html' %}",
        )
        self.create_file(
            "templates/myapp/pages/offer/layout/main.html", "<div>Main Layout</div>"
        )

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertTrue(any("Fichier mal placé" in error for error in errors))

    def test_layout_base_correct_location(self):
        errors = []
        self.create_file("templates/myapp/layout/base.html", "<div>Base Layout</div>")

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertFalse(errors)

    def test_correct_architecture(self):
        errors = []
        self.create_file(
            "templates/myapp/layout/base.html",
            "<div>Base Layout</div>\n{% include 'myapp/components/header.html' %}\n",
        )
        self.create_file("templates/myapp/components/header.html", "<div>Header</div>")
        self.create_file(
            "templates/myapp/pages/sections/footer.html", "<div>Footer</div>"
        )
        self.create_file(
            "templates/myapp/pages/page.html",
            "{% extends 'layout/base.html' %}\n{% include 'myapp/sections/footer.html' %}",
        )

        check_component_and_layout_file_placement(self.app_path, errors)
        self.assertFalse(errors)
