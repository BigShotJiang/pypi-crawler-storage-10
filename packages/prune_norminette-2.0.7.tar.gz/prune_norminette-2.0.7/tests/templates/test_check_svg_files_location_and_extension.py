import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.templates.check_svg_files_location_and_extension import (
    check_svg_files_location_and_extension,
)


class TestSvg(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.app_name = "myapp"
        self.app_path = self.project_root / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_svg_misplaced(self):
        self.create_file("templates/myapp/pages/bad.html", "<svg></svg>")

        errors = []
        check_svg_files_location_and_extension(self.app_path, errors)

        self.assertTrue(len(errors), 1)
        self.assertIn("Fichiers SVG mal placés", errors[0])

    def test_svg_bad_extension(self):
        self.create_file("templates/myapp/svg/wrong.svg", "<svg></svg>")

        errors = []
        check_svg_files_location_and_extension(self.app_path, errors)

        self.assertTrue(len(errors), 1)
        self.assertIn("Fichiers SVG mal nommés", errors[0])

    def test_svg_misplaced_bad_extension(self):
        self.create_file("templates/myapp/pages/bad.svg", "<svg></svg>")

        errors = []
        check_svg_files_location_and_extension(self.app_path, errors)

        self.assertTrue(len(errors), 2)
        self.assertIn("Fichiers SVG mal placés", errors[0])
        self.assertIn("Fichiers SVG mal nommés", errors[1])

    def test_svg_correct(self):
        self.create_file("templates/myapp/svg/correct.html", "<svg></svg>")

        errors = []
        check_svg_files_location_and_extension(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_svg_correct_subdir(self):
        self.create_file("templates/myapp/svg/features/correct.html", "<svg></svg>")

        errors = []
        check_svg_files_location_and_extension(self.app_path, errors)

        self.assertEqual(len(errors), 0)
