import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.templates.check_svg_inclusion_paths import (
    check_svg_inclusion_paths,
)


class TestIncludeSvg(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.app_name = "myapp"
        self.app_path = self.project_root / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_error_bad_path(self):
        self.create_file(
            "templates/myapp/pages/page.html",
            r'<div class="logo"><a href="{% url website:home %}" aria-label="home page">{% include "../website/svg/logo.html" %}</a></div>',
        )
        errors = []
        check_svg_inclusion_paths(self.app_path, errors)
        self.assertEqual(len(errors), 1)
        self.assertIn("Problèmes d'inclusion des fichiers SVG", errors[0])

    def test_error_other_bad_path(self):
        self.create_file(
            "templates/myapp/pages/page.html",
            r'<div class="logo"><a href="{% url website:home %}" aria-label="home page">{% include "./website/svg/logo.html" %}</a></div>',
        )
        errors = []
        check_svg_inclusion_paths(self.app_path, errors)
        self.assertEqual(len(errors), 1)
        self.assertIn("Problèmes d'inclusion des fichiers SVG", errors[0])

    def test_good_path(self):
        self.create_file(
            "templates/myapp/pages/page.html", r"{% include '/svg/logo.html' %}"
        )
        errors = []
        check_svg_inclusion_paths(self.app_path, errors)

        self.assertEqual(len(errors), 0)
