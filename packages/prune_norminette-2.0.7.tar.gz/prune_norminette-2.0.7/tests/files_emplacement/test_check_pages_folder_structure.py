import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.files_emplacement.check_pages_folder_structure import (
    check_pages_folder_structure,
)


class TestVerifyPagesFolder(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_name = "myapp"
        self.app_path = Path(self.temp_dir) / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

        self.pages_path = self.app_path / "templates" / self.app_name / "pages"
        self.pages_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.touch()
        return file_path

    def test_misplaced_page_html(self):
        self.create_file("page.html")
        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Fichiers 'page.html' mal placés", errors[0])

    def test_wrong_files_in_pages(self):
        self.create_file(f"{self.pages_path}/wrong.html")
        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Fichiers incorrects dans '/pages'", errors[0])

    def test_correct_structure_with_layout(self):
        self.create_file(f"{self.pages_path}/layout/base.html")
        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_correct_structure_with_section(self):
        self.create_file(f"{self.pages_path}/sections/base.html")
        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_correct_structure_with_component(self):
        self.create_file(f"{self.pages_path}/components/base.html")

        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_correct_structure(self):
        self.create_file(f"{self.pages_path}/page.html")

        errors = []
        check_pages_folder_structure(self.app_path, errors)

        self.assertEqual(len(errors), 0)
