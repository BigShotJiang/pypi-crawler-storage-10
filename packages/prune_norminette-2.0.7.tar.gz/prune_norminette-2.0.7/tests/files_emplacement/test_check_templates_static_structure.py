import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.files_emplacement.check_templates_static_structure import (
    check_templates_static_structure,
)


class TestVerifyStructureTemplatesStatic(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_name = "myapp"
        self.app_path = Path(self.temp_dir) / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

        self.templates_path = self.app_path / "templates"
        self.templates_path.mkdir(parents=True, exist_ok=True)

        self.static_path = self.app_path / "static"
        self.static_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_folder(self, relative_path):
        file_path = Path(relative_path)
        file_path.mkdir(parents=True, exist_ok=True)
        return file_path

    def test_one_folder(self):
        self.create_folder(f"{self.templates_path}/pages")
        errors = []
        check_templates_static_structure(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_one_file(self):
        bad_file = self.static_path / "other.html"
        bad_file.touch()
        errors = []
        check_templates_static_structure(self.app_path, errors)
        self.assertEqual(len(errors), 1)
        self.assertIn(
            "il faut des sous-dossiers pour éviter des écrasements entre les applications django",
            errors[0],
        )
