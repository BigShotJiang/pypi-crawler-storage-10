import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_view_function_naming import (
    check_view_function_naming,
)


class TestNameViewFunction(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_error_with_bad_views(self):
        self.create_file(
            "views.py",
            """
            from django.shortcuts import render
            
            def home(request):
                return render(request, "home.html")
            """,
        )
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertTrue(any("home →" in error for error in errors))

    def test_no_error_with_private_functions(self):
        self.create_file(
            "views.py",
            """
            from django.shortcuts import render
            
            def _home(request):
                return render(request, "home.html")
            """,
        )
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_error_with_bad_views_in_folder(self):
        self.create_file(
            "views/other.py",
            """
            from django.shortcuts import render
            
            def home(request):
                return render(request, "home.html")
            """,
        )
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertTrue(any("home →" in error for error in errors))

    def test_ignore_utils_py(self):
        self.create_file(
            "utils.py",
            """
            from django.shortcuts import render
            
            def helper_function(request):
                return render(request, "help.html")
            """,
        )
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_ignore_utils_in_folder(self):
        self.create_file(
            "views/utils.py",
            """
            from django.shortcuts import render
            
            def helper_function(request):
                return render(request, "help.html")
            """,
        )
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_empty_result(self):
        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_with_correct_view_in_folder(self):
        self.create_file(
            "views/pages.py",
            """
            from django.shortcuts import render
            
            def home_view(request):
                return render(request, "home.html")
            """,
        )

        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_with_correct_view(self):
        self.create_file(
            "views.py",
            """
            from django.shortcuts import render
            
            def home_view(request):
                return render(request, "home.html")
            """,
        )

        errors = []
        check_view_function_naming(self.app_path, errors)
        self.assertEqual(len(errors), 0)
