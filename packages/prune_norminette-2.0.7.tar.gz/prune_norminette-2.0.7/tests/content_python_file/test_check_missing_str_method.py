import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_missing_str_method import (
    check_missing_str_method,
)


class TestStrMethodExist(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_model_without_str_method(self):
        self.create_file(
            "models.py",
            """
            from django.db import models

            class Product(models.Model):
                name = models.CharField(max_length=100)
            """,
        )
        errors = []
        check_missing_str_method(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Méthode __str__ manquante", errors[0])

    def test_empty_models_file(self):
        self.create_file("models.py", "")

        errors = []
        check_missing_str_method(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_no_models_file(self):
        errors = []
        check_missing_str_method(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_model_correct_str_method(self):
        self.create_file(
            "models.py",
            """
            from django.db import models

            class Product(models.Model):
                name = models.CharField()

                def __str__(self):
                    return self.name
            """,
        )

        errors = []
        check_missing_str_method(self.app_path, errors)
        self.assertEqual(len(errors), 0)
