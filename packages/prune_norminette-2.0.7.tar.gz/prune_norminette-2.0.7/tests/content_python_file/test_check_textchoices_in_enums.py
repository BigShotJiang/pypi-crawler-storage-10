import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_textchoices_in_enums import (
    check_textchoices_in_enums,
)


class TestTextChoicesOnEnum(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_textchoices_in_wrong_file(self):
        self.create_file(
            "models.py",
            """
            from django.db import models

            class ChatStatus(models.TextChoices):
                open = "open"
                solved = "solved"
                close = "close"
            """,
        )
        errors = []
        check_textchoices_in_enums(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("TextChoices au mauvais endroit", errors[0])
        self.assertIn("models.py", errors[0])

    def test_no_python_files(self):
        errors = []
        check_textchoices_in_enums(self.app_path, errors)
        self.assertEqual(len(errors), 0)

    def test_textchoices_correct(self):
        self.create_file(
            "enums.py",
            """
            from django.db import models

            class ChatStatus(models.TextChoices):
                open = "open"
                solved = "solved"
                close = "close"
            """,
        )

        errors = []
        check_textchoices_in_enums(self.app_path, errors)
        self.assertEqual(len(errors), 0)
