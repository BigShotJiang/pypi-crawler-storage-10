import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_urls_name_parameter import (
    check_urls_name_parameter,
)


class TestNameParameterViewsUrls(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_urls_with_missing_names(self):
        self.create_file(
            "urls.py",
            r"""
            from django.urls import path, re_path
            from . import views

            urlpatterns = [
                path('', views.home, name='home'),
                path('about/', views.about),  
                path("users/ext/<int:id>", views.delete_external_user_view,),  
            ]
            """,
        )
        errors = []

        check_urls_name_parameter(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Paramètre 'name' manquant", errors[0])
        self.assertIn("about/", errors[0])
        self.assertIn("users/ext", errors[0])

    def test_no_urls_file(self):
        errors = []
        check_urls_name_parameter(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_urls_with_all_named_paths(self):
        self.create_file(
            "urls.py",
            r"""
            from django.urls import path, re_path
            from . import views

            urlpatterns = [
                path('', views.home, name='home'),
                path('about/', views.about, name='about'),
                path("users/external/<int:id>", views.delete_external_user_view,name="delete-external-user",),
            ]
            """,
        )
        errors = []

        check_urls_name_parameter(self.app_path, errors)

        self.assertEqual(len(errors), 0)
