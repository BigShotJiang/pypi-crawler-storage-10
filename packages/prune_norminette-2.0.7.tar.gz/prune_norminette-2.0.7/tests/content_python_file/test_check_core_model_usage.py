import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_core_model_usage import (
    check_core_model_usage,
)


class TestCoreModelUse(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_no_models_file(self):
        errors = []
        check_core_model_usage(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_direct_model_inheritance(self):
        self.create_file(
            "models.py",
            """
            from django.db import models

            class Product(models.Model):
                name = models.CharField()
            """,
        )

        errors = []
        check_core_model_usage(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Problème d'héritage de modèle Django", errors[0])
        self.assertIn("Product", errors[0])

    def test_multiple_inheritance_errors(self):
        self.create_file(
            "models.py",
            """
            from django.db import models
            from lib.models import CoreModel

            class Product(models.Model):
                name = models.CharField()
                
            class Category(models.Model):
                name = models.CharField()
                
            class Order(CoreModel):
                date = models.DateField()
            """,
        )

        errors = []
        check_core_model_usage(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Product", errors[0])
        self.assertIn("Category", errors[0])
        self.assertNotIn("Order", errors[0])

    def test_different_inheritance_patterns(self):
        self.create_file(
            "models.py",
            """
            from django.db import models as django_models
            from lib.models import CoreModel

            class Product(django_models.Model):
                name = models.CharField(max_length=100)
                
            class Category(Model):
                name = CharField(max_length=50)
                        """,
        )

        errors = []
        check_core_model_usage(self.app_path, errors)

        self.assertEqual(len(errors), 1)
        self.assertIn("Product", errors[0])
        self.assertIn("Category", errors[0])

    def test_correct_model_inheritance(self):
        self.create_file(
            "models.py",
            """
            from django.db import models
            from lib.models import CoreModel

            class Product(CoreModel):
                name = models.CharField()
            """,
        )

        errors = []
        check_core_model_usage(self.app_path, errors)

        self.assertEqual(len(errors), 0)
