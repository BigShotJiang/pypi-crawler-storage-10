import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.content_python_file.check_basemodel_in_payloads import (
    check_basemodel_in_payloads,
)


class TestBaseModelOnPayloads(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_path = Path(self.temp_dir) / "myapp"
        self.app_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.app_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_error_base_model(self):
        self.create_file(
            "views/my_view.py",
            " import BaseModel class data(BaseModel):",
        )
        errors = []
        check_basemodel_in_payloads(self.app_path, errors)

        self.assertTrue(
            any("Pydantic BaseModel au mauvais endroit" in err for err in errors)
        )

    def test_correct_base_model(self):
        self.create_file(
            "views/payloads.py",
            " import BaseModel class data(BaseModel):",
        )
        errors = []
        check_basemodel_in_payloads(self.app_path, errors)

        self.assertEqual(len(errors), 0)

    def test_correct_base_model_not_view(self):
        self.create_file(
            "props.py",
            " import BaseModel class data(BaseModel):",
        )
        errors = []
        check_basemodel_in_payloads(self.app_path, errors)

        self.assertEqual(len(errors), 0)
