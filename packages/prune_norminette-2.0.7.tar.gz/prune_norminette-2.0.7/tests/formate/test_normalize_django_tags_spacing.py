import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.formate.normalize_django_tags_spacing import (
    normalize_django_tags_spacing,
)


class TestSpaceTag(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.app_name = "myapp"
        self.app_path = Path(self.temp_dir) / self.app_name
        self.app_path.mkdir(parents=True, exist_ok=True)

        self.pages_path = self.app_path / "templates" / self.app_name / "pages"
        self.pages_path.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_file(self, relative_path, content=""):
        file_path = self.pages_path / relative_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return file_path

    def test_normalize_django_tags_spacing(self):
        test_file = self.create_file(
            "test.html",
            """
            <html>
            <body>

            <h1>Title</h1>
                {% include 'website/pages/components/icon.css' %}
                {%   include 'website/pages/components/receive-message.css'   %}
                {% include 'website/pages/components/send-message.css' %}
                {% include 'website/pages/sections/discover.css'   %}
                
            <p>Some text.</p>
                {%   include 'website/pages/components/icon.css' %}
                {% include 'website/pages/components/receive-message.css' %}

            </body>
            </html>
            """,
        )

        normalize_django_tags_spacing(self.app_path)

        modified_content = test_file.read_text(encoding="utf-8")

        expected_content = """
            <html>
            <body>

            <h1>Title</h1>
                {% include 'website/pages/components/icon.css' %}
                {% include 'website/pages/components/receive-message.css' %}
                {% include 'website/pages/components/send-message.css' %}
                {% include 'website/pages/sections/discover.css' %}
                
            <p>Some text.</p>
                {% include 'website/pages/components/icon.css' %}
                {% include 'website/pages/components/receive-message.css' %}

            </body>
            </html>
            """
        self.assertEqual(modified_content, expected_content)
