import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.project_config.check_valid_whitenoise_and_static_paths import (
    check_valid_whitenoise_and_static_paths,
)


class TestVerifyPathsStatic(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.project_root.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_settings_file(self, content=""):
        settings_path = self.project_root / "settings.py"
        settings_path.write_text(content, encoding="utf-8")
        return settings_path

    def test_settings_file_not_found(self):
        errors = []
        check_valid_whitenoise_and_static_paths(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("Vous n'avez pas de fichier settings.py", errors[0])

    def test_whitenoise_path_missing(self):
        self.create_settings_file("""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# WHITENOISE_ROOT manquant
STATIC_ROOT = os.path.join(BASE_DIR, "static_root")
""")

        errors = []
        check_valid_whitenoise_and_static_paths(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn(
            "devrait contenir un chemin valide pour WHITENOISE_ROOT", errors[0]
        )

    def test_static_root_path_missing(self):
        self.create_settings_file("""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

WHITENOISE_ROOT = BASE_DIR / "whitenoise_root"
# STATIC_ROOT manquant
""")

        errors = []
        check_valid_whitenoise_and_static_paths(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("devrait contenir un chemin valide pour STATIC_ROOT", errors[0])

    def test_both_paths_missing(self):
        self.create_settings_file("""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-key'
DEBUG = True
""")

        errors = []
        check_valid_whitenoise_and_static_paths(errors, self.project_root)

        self.assertEqual(len(errors), 2)
        self.assertIn(
            "devrait contenir un chemin valide pour WHITENOISE_ROOT", errors[0]
        )
        self.assertIn("devrait contenir un chemin valide pour STATIC_ROOT", errors[1])

        def test_paths_both_correct_os_path_join(self):
            self.create_settings_file("""
    import os
    from pathlib import Path

    BASE_DIR = Path(__file__).resolve().parent.parent

    WHITENOISE_ROOT = os.path.join(BASE_DIR, "whitenoise_root")
    STATIC_ROOT = os.path.join(BASE_DIR, "static_root")
    """)

            errors = []
            check_valid_whitenoise_and_static_paths(errors, self.project_root)

            self.assertEqual(len(errors), 0)

    def test_paths_both_correct_pathlib(self):
        self.create_settings_file("""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

WHITENOISE_ROOT = BASE_DIR / "whitenoise_root"
STATIC_ROOT = BASE_DIR / "static_root"
""")

        errors = []
        check_valid_whitenoise_and_static_paths(errors, self.project_root)

        self.assertEqual(len(errors), 0)
