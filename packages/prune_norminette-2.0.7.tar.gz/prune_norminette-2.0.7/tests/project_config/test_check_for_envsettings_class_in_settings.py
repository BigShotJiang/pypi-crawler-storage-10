import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.project_config.check_for_envsettings_class_in_settings import (
    check_for_envsettings_class_in_settings,
)


class TestVerifyClassEnvSettings(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.project_root.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_settings_file(self, content=""):
        settings_path = self.project_root / "settings.py"
        settings_path.write_text(content, encoding="utf-8")
        return settings_path

    def test_no_settings_file(self):
        errors = []
        check_for_envsettings_class_in_settings(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("Vous n'avez pas de fichier settings.py", errors[0])

    def test_settings_without_envsettings_class(self):
        self.create_settings_file("""
from pathlib import Path

BASE_DIR = Path(__file__).resolve()

SECRET_KEY = 'django-insecure-key'
DEBUG = True
        """)

        errors = []
        check_for_envsettings_class_in_settings(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn(
            "Le fichier `settings.py` devrait contenir une classe `EnvSettings`",
            errors[0],
        )

    def test_settings_with_envsettings_class(self):
        self.create_settings_file("""
from pydantic import BaseSettings
        
class EnvSettings(BaseSettings):
    DEBUG: bool = False
    SECRET_KEY: str
        """)

        errors = []
        check_for_envsettings_class_in_settings(errors, self.project_root)

        self.assertEqual(len(errors), 0)
