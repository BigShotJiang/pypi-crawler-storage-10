import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.project_config.check_uv_use import check_uv_use


class TestCheckUVUse(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_uv_lock_file(self, relative_path):
        uv_lock_path = self.project_root / relative_path

        uv_lock_path.touch()
        return uv_lock_path

    def test_uv_lock_exists_in_root(self):
        self.create_uv_lock_file("uv.lock")

        errors = []
        check_uv_use(errors, self.project_root)

        self.assertEqual(len(errors), 0)

    def test_uv_lock_not_exists(self):
        errors = []
        check_uv_use(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("UV n'est pas utilise pour ce projet", errors[0])
