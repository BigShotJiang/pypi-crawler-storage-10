import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.project_config.check_pyproject_configuration import (
    check_pyproject_configuration,
)


class TestConfigPyproject(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_pyproject_file(self, content=""):
        pyproject_path = self.project_root / "pyproject.toml"
        pyproject_path.write_text(content, encoding="utf-8")
        return pyproject_path

    def test_no_pyproject_file(self):
        errors = []
        check_pyproject_configuration(errors, self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("Vous n'avez pas de fichier pyproject.toml", errors[0])

    def test_pyproject_with_all_dependencies(self):
        self.create_pyproject_file("""
[project]
name = "mon-projet"
dependencies = [
    "django",
    "pydantic",
    "ipython",
    "whitenoise",
    "other-package"
]
""")

        errors = []
        result = check_pyproject_configuration(errors, self.project_root)

        self.assertEqual(len(result), 0)

    def test_pyproject_with_missing_dependencies(self):
        self.create_pyproject_file("""
[project]
name = "mon-projet"
dependencies = [
    "django",
    "pydantic",
    "other-package"
]
""")

        errors = []
        result = check_pyproject_configuration(errors, self.project_root)

        self.assertEqual(len(result), 1)
        self.assertIn("ne contient pas cette / ces dépendance(s) requises", result[0])
        self.assertIn("ipython", result[0])
        self.assertIn("whitenoise", result[0])
        self.assertNotIn("pydantic", result[0])
