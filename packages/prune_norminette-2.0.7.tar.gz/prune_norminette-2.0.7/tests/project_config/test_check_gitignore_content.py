import shutil
import unittest
from pathlib import Path
from tempfile import mkdtemp

from prune_norminette.rules.project_config.check_gitignore_content import (
    check_gitignore_content,
)


class TestGitignoreContent(unittest.TestCase):
    def setUp(self):
        self.temp_dir = mkdtemp()
        self.project_root = Path(self.temp_dir)
        self.project_root.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        shutil.rmtree(self.temp_dir)

    def create_gitignore(self, content=""):
        gitignore_path = self.project_root / ".gitignore"
        gitignore_path.write_text(content, encoding="utf-8")
        return gitignore_path

    def test_no_gitignore_file(self):
        errors = []
        check_gitignore_content(errors, current_dir=self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn("Vous n'avez pas de fichier .gitignore", errors[0])

    def test_gitignore_with_all_entries(self):
        self.create_gitignore("""
.env
.venv
__pycache__/
node_modules/
static_root
        """)

        errors = []
        check_gitignore_content(errors, current_dir=self.project_root)

        self.assertEqual(len(errors), 0)

    def test_gitignore_with_missing_entries(self):
        self.create_gitignore("""
.env
__pycache__/
static_root
        """)

        errors = []
        check_gitignore_content(errors, current_dir=self.project_root)

        self.assertEqual(len(errors), 1)
        self.assertIn(
            "Le fichier .gitignore ne contient pas ces entrées à masquer", errors[0]
        )
        self.assertIn("node_modules/", errors[0])
        self.assertIn(".venv", errors[0])
