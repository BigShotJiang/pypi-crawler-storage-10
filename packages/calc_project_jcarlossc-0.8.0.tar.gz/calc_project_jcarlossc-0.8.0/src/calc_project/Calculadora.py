class Calculadora:
    def somar(self, x: float, y: float) -> float:
        return x + y

    def subtrair(self, x: float, y: float) -> float:
        return x - y

    def multiplicar(self, x: float, y: float) -> float:
        return x * y

    def dividir(self, x: float, y: float) -> float:
        return x / y
