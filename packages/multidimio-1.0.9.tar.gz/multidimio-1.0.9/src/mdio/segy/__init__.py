"""SEG-Y specific implementation module."""
