"""MDIO schemas for different data types."""

__all__ = []
