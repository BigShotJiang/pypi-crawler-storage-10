from typing import TypedDict


class PushResponseDict(TypedDict):
    app_uri: str
    sematic_version: str
