"""Utility functions for TokenWatcher SDK."""

import inspect
import logging
from datetime import datetime, timezone
from typing import Optional, Any, Dict

logger = logging.getLogger(__name__)


def get_current_timestamp() -> str:
    """
    Get current timestamp in ISO-8601 format.

    Returns:
        ISO-8601 formatted timestamp string
    """
    return datetime.now(timezone.utc).isoformat()


def extract_error_type(exception: Exception) -> str:
    """
    Extract error type from exception.

    Args:
        exception: The exception to extract type from

    Returns:
        Error type name
    """
    return type(exception).__name__


def extract_error_message(exception: Exception) -> str:
    """
    Extract error message from exception.

    Args:
        exception: The exception to extract message from

    Returns:
        Error message (truncated to 1000 chars if needed)
    """
    message = str(exception)
    if len(message) > 1000:
        message = message[:997] + "..."
    return message


def safe_get_nested(data: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    """
    Safely get nested dictionary value.

    Args:
        data: Dictionary to extract from
        *keys: Nested keys to traverse
        default: Default value if key path not found

    Returns:
        Value at nested key path or default
    """
    current = data
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key)
        if current is None:
            return default
    return current


def sanitize_metadata(metadata: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Sanitize metadata to ensure it's JSON-serializable.

    Args:
        metadata: Metadata dictionary to sanitize

    Returns:
        Sanitized metadata or None
    """
    if metadata is None:
        return None

    try:
        # Attempt to convert to ensure it's serializable
        import json

        json.dumps(metadata)
        return metadata
    except (TypeError, ValueError) as e:
        logger.warning(f"Metadata is not JSON-serializable: {e}")
        # Convert to string representation
        return {"_raw": str(metadata)}


def get_caller_context() -> Optional[str]:
    """
    Automatically detect the calling module and function from the call stack.

    This walks up the call stack to find the first frame that is NOT from the
    tokenwatcher package, and returns it formatted as "module.function".

    Returns:
        Calling context string (e.g., "myapp.chatbot.handle_message") or None
    """
    # Modules to skip when detecting caller context
    SKIP_MODULES = ('tokenwatcher', 'unittest', 'pytest', 'pluggy', '_pytest')

    try:
        # Walk up the stack to find first frame from user code
        # Start at frame 1 to skip this function itself, then filter out internal frames
        for frame_info in inspect.stack()[1:]:
            module = inspect.getmodule(frame_info.frame)

            # Get module name from module object or frame globals
            if module:
                module_name = module.__name__
            else:
                # Fallback to frame globals if getmodule returns None (e.g., python -c)
                module_name = frame_info.frame.f_globals.get('__name__', None)
                if not module_name:
                    continue

            # Skip internal modules (tokenwatcher, test frameworks, etc.)
            if any(module_name.startswith(prefix) for prefix in SKIP_MODULES):
                continue

            # Skip module-level code (function name is <module>)
            function_name = frame_info.function
            if function_name == '<module>':
                continue

            # If module is __main__, try to derive a better name from filename
            if module_name == '__main__':
                import os
                filename = frame_info.filename
                # Extract module name from file path (e.g., /path/to/test_client.py -> test_client)
                # Only use derived name if it's a real file (not <string> from python -c)
                if filename not in ('<string>', '<stdin>'):
                    module_name = os.path.splitext(os.path.basename(filename))[0]

            # Format as module.function (e.g., "app.chatbot.handle_message")
            context = f"{module_name}.{function_name}"

            # Truncate if too long (backend limit is 255 chars)
            if len(context) > 200:
                context = context[:197] + "..."

            logger.debug(f"Auto-detected context: {context}")
            return context

        # If we couldn't find a caller outside skipped modules
        logger.debug("Could not auto-detect caller context")
        return None

    except Exception as e:
        logger.warning(f"Error auto-detecting caller context: {e}")
        return None
