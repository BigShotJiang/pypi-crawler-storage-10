"""Example usage of TokenWatcher with OpenAI."""

import os
from openai import OpenAI
from tokenwatcher import MonitoredOpenAI


def main():
    """Demonstrate basic usage with OpenAI."""

    # Get API keys from environment
    openai_api_key = os.getenv("OPENAI_API_KEY")
    tokenwatcher_api_key = os.getenv("TOKENWATCHER_API_KEY", "ym_test_key")

    if not openai_api_key:
        print("Error: OPENAI_API_KEY environment variable not set")
        return

    # Create OpenAI client
    openai_client = OpenAI(api_key=openai_api_key)

    # Wrap it with TokenWatcher monitoring
    client = MonitoredOpenAI(
        openai_client,
        api_key=tokenwatcher_api_key,
        base_url=os.getenv("TOKENWATCHER_BASE_URL", "http://localhost:8080"),
        context="examples/openai",
        user_identifier="example-user",
    )

    print("Making OpenAI API call...")

    # Use exactly as you would use OpenAI client
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What is the capital of France?"}
        ],
        max_tokens=100,
    )

    print(f"Response: {response.choices[0].message.content}")
    print(f"Tokens used: {response.usage.total_tokens}")

    # Manually flush events (optional - happens automatically)
    client.flush()

    print("\nMonitoring event sent to TokenWatcher!")
    print("Check your dashboard at http://localhost:9000")


if __name__ == "__main__":
    main()
