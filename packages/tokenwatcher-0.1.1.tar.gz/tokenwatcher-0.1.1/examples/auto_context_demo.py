"""
Demo of automatic context detection in TokenWatcher.

This example shows how the SDK automatically captures the calling module
and function name when you don't provide an explicit context.
"""

import os
from openai import OpenAI
from tokenwatcher import MonitoredOpenAI


def chatbot_handler(user_message: str) -> str:
    """
    Simulate a chatbot handler function.

    When monitoring is enabled without explicit context, TokenWatcher will
    automatically set the context to: "auto_context_demo.chatbot_handler"
    """
    openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    # Note: No context parameter provided!
    client = MonitoredOpenAI(
        openai_client,
        api_key=os.getenv("TOKENWATCHER_API_KEY", "ym_test_key"),
        base_url=os.getenv("TOKENWATCHER_BASE_URL", "http://localhost:8080"),
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": user_message}
        ],
        max_tokens=100,
    )

    return response.choices[0].message.content


def email_summarizer(email_text: str) -> str:
    """
    Simulate an email summarization function.

    This will have a different auto-detected context:
    "auto_context_demo.email_summarizer"
    """
    openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    client = MonitoredOpenAI(
        openai_client,
        api_key=os.getenv("TOKENWATCHER_API_KEY", "ym_test_key"),
        base_url=os.getenv("TOKENWATCHER_BASE_URL", "http://localhost:8080"),
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Summarize the following email in one sentence."},
            {"role": "user", "content": email_text}
        ],
        max_tokens=50,
    )

    return response.choices[0].message.content


def main():
    """Run the demo."""

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY environment variable not set")
        return

    print("=== Auto-Context Detection Demo ===\n")

    print("1. Calling chatbot_handler...")
    print("   → Context will be auto-set to: 'auto_context_demo.chatbot_handler'")
    result1 = chatbot_handler("What is the capital of France?")
    print(f"   Response: {result1}\n")

    print("2. Calling email_summarizer...")
    print("   → Context will be auto-set to: 'auto_context_demo.email_summarizer'")
    result2 = email_summarizer(
        "Hi team, just wanted to follow up on the project. "
        "We need to finalize the designs by Friday. Let me know if you have questions."
    )
    print(f"   Response: {result2}\n")

    print("✅ Events sent to TokenWatcher!")
    print("Check your dashboard - you'll see separate entries for:")
    print("  - auto_context_demo.chatbot_handler")
    print("  - auto_context_demo.email_summarizer")
    print("\nThis makes it easy to see which parts of your code are using LLMs!")


if __name__ == "__main__":
    main()
