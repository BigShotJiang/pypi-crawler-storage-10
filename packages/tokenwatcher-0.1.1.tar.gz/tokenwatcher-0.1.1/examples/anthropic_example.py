"""Example usage of TokenWatcher with Anthropic."""

import os
from anthropic import Anthropic
from tokenwatcher import MonitoredAnthropic


def main():
    """Demonstrate basic usage with Anthropic."""

    # Get API keys from environment
    anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
    tokenwatcher_api_key = os.getenv("TOKENWATCHER_API_KEY", "ym_test_key")

    if not anthropic_api_key:
        print("Error: ANTHROPIC_API_KEY environment variable not set")
        return

    # Create Anthropic client
    anthropic_client = Anthropic(api_key=anthropic_api_key)

    # Wrap it with TokenWatcher monitoring
    client = MonitoredAnthropic(
        anthropic_client,
        api_key=tokenwatcher_api_key,
        base_url=os.getenv("TOKENWATCHER_BASE_URL", "http://localhost:8080"),
        context="examples/anthropic",
        user_identifier="example-user",
    )

    print("Making Anthropic API call...")

    # Use exactly as you would use Anthropic client
    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1024,
        messages=[
            {"role": "user", "content": "What is the capital of France?"}
        ]
    )

    print(f"Response: {response.content[0].text}")
    print(f"Input tokens: {response.usage.input_tokens}")
    print(f"Output tokens: {response.usage.output_tokens}")

    # Manually flush events (optional - happens automatically)
    client.flush()

    print("\nMonitoring event sent to TokenWatcher!")
    print("Check your dashboard at http://localhost:9000")


if __name__ == "__main__":
    main()
