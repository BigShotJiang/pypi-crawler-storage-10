"""Tests for configuration module."""

import pytest
from tokenwatcher.config import Config


def test_config_initialization():
    """Test basic configuration initialization."""
    config = Config(
        api_key="ym_test_key",
        base_url="https://api.example.com",
        context="test/context",
    )

    assert config.api_key == "ym_test_key"
    assert config.base_url == "https://api.example.com"
    assert config.context == "test/context"
    assert config.enabled is True
    assert config.buffer_size == 100
    assert config.flush_interval == 10


def test_config_default_base_url():
    """Test default base URL."""
    config = Config(api_key="ym_test_key")

    assert config.base_url == "https://www.token-watcher.com"


def test_config_strips_trailing_slash():
    """Test that trailing slash is removed from base URL."""
    config = Config(
        api_key="ym_test_key",
        base_url="https://api.example.com/",
    )

    assert config.base_url == "https://api.example.com"


def test_config_events_endpoint():
    """Test events endpoint URL construction."""
    config = Config(
        api_key="ym_test_key",
        base_url="https://api.example.com",
    )

    assert config.events_endpoint == "https://api.example.com/api/v1/events/batch"


def test_config_disabled():
    """Test configuration with monitoring disabled."""
    config = Config(
        api_key="ym_test_key",
        enabled=False,
    )

    assert config.enabled is False


def test_config_custom_buffer_settings():
    """Test custom buffer settings."""
    config = Config(
        api_key="ym_test_key",
        buffer_size=50,
        flush_interval=5,
    )

    assert config.buffer_size == 50
    assert config.flush_interval == 5
