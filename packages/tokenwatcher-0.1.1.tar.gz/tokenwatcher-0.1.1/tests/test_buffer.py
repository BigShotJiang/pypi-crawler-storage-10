"""Tests for event buffer."""

import pytest
import time
from unittest.mock import Mock, patch
from tokenwatcher.config import Config
from tokenwatcher.event_buffer import EventBuffer


@pytest.fixture
def config():
    """Create test configuration."""
    return Config(
        api_key="ym_test_key",
        buffer_size=3,
        flush_interval=1,
    )


@pytest.fixture
def buffer(config):
    """Create event buffer."""
    buffer = EventBuffer(config)
    yield buffer
    buffer.shutdown()


def test_buffer_initialization(buffer):
    """Test buffer initialization."""
    assert buffer.config is not None
    assert len(buffer.buffer) == 0
    assert buffer.running is True


def test_add_event(buffer):
    """Test adding events to buffer."""
    event = {"timestamp": "2025-01-01T00:00:00Z", "provider": "openai"}

    buffer.add_event(event)

    assert len(buffer.buffer) == 1


@patch('tokenwatcher.event_buffer.EventSender.send_batch')
def test_auto_flush_on_size(mock_send, buffer):
    """Test automatic flush when buffer is full."""
    # Add events to trigger auto-flush (buffer_size=3)
    for i in range(3):
        buffer.add_event({"id": i})

    # Should have flushed
    mock_send.assert_called_once()
    assert len(buffer.buffer) == 0


@patch('tokenwatcher.event_buffer.EventSender.send_batch')
def test_manual_flush(mock_send, buffer):
    """Test manual flush."""
    buffer.add_event({"id": 1})
    buffer.add_event({"id": 2})

    buffer.flush()

    mock_send.assert_called_once()
    assert len(buffer.buffer) == 0


@patch('tokenwatcher.event_buffer.EventSender.send_batch')
def test_periodic_flush(mock_send, config):
    """Test periodic auto-flush."""
    config.flush_interval = 1  # 1 second
    buffer = EventBuffer(config)

    buffer.add_event({"id": 1})

    # Wait for periodic flush
    time.sleep(1.5)

    # Should have been flushed by periodic thread
    assert mock_send.call_count >= 1

    buffer.shutdown()


def test_flush_empty_buffer(buffer):
    """Test flushing empty buffer."""
    # Should not raise error
    buffer.flush()


def test_disabled_buffer():
    """Test buffer when monitoring is disabled."""
    config = Config(api_key="ym_test_key", enabled=False)
    buffer = EventBuffer(config)

    buffer.add_event({"id": 1})

    # Should not add events when disabled
    assert len(buffer.buffer) == 0

    buffer.shutdown()


@patch('tokenwatcher.event_buffer.EventSender.send_batch')
def test_shutdown_flushes(mock_send, buffer):
    """Test that shutdown flushes remaining events."""
    buffer.add_event({"id": 1})
    buffer.add_event({"id": 2})

    buffer.shutdown()

    # Should have flushed on shutdown
    mock_send.assert_called_once()
