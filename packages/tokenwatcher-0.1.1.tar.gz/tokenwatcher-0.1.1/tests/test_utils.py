"""Tests for utility functions."""

import pytest
from datetime import datetime, timezone
from tokenwatcher.utils import (
    get_current_timestamp,
    extract_error_type,
    extract_error_message,
    safe_get_nested,
    sanitize_metadata,
    get_caller_context,
)


def test_get_current_timestamp():
    """Test timestamp generation."""
    timestamp = get_current_timestamp()

    # Should be ISO-8601 format
    assert isinstance(timestamp, str)
    assert "T" in timestamp

    # Should be parseable back to datetime
    dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    assert isinstance(dt, datetime)


def test_extract_error_type():
    """Test error type extraction."""
    error = ValueError("test error")
    error_type = extract_error_type(error)

    assert error_type == "ValueError"


def test_extract_error_message():
    """Test error message extraction."""
    error = ValueError("test error message")
    message = extract_error_message(error)

    assert message == "test error message"


def test_extract_error_message_truncation():
    """Test error message truncation for long messages."""
    long_message = "x" * 1500
    error = ValueError(long_message)
    message = extract_error_message(error)

    assert len(message) == 1000
    assert message.endswith("...")


def test_safe_get_nested():
    """Test safe nested dictionary access."""
    data = {
        "level1": {
            "level2": {
                "level3": "value"
            }
        }
    }

    # Successful access
    result = safe_get_nested(data, "level1", "level2", "level3")
    assert result == "value"

    # Missing key
    result = safe_get_nested(data, "level1", "missing", "key", default="default")
    assert result == "default"

    # Empty path
    result = safe_get_nested(data)
    assert result == data


def test_sanitize_metadata():
    """Test metadata sanitization."""
    # Valid metadata
    metadata = {"key": "value", "number": 42}
    result = sanitize_metadata(metadata)
    assert result == metadata

    # None metadata
    result = sanitize_metadata(None)
    assert result is None


def test_sanitize_metadata_non_serializable():
    """Test metadata sanitization for non-JSON-serializable data."""
    # Non-serializable object
    class CustomObject:
        pass

    metadata = {"obj": CustomObject()}
    result = sanitize_metadata(metadata)

    # Should convert to string representation
    assert "_raw" in result
    assert isinstance(result["_raw"], str)


def test_get_caller_context():
    """Test automatic caller context detection."""

    def inner_function():
        """Helper function to test caller detection."""
        return get_caller_context()

    # Call from this test function
    context = inner_function()

    # Should detect the inner function (immediate caller)
    assert context is not None
    assert "test_utils" in context
    assert "inner_function" in context


def test_get_caller_context_format():
    """Test that caller context is formatted as module.function."""

    def helper():
        return get_caller_context()

    context = helper()

    # Should be in format module.function
    assert "." in context
    parts = context.split(".")
    assert len(parts) >= 2  # At least module.function
