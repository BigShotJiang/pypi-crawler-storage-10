"""Tests for client wrappers."""

import pytest
from unittest.mock import Mock, MagicMock, patch
from tokenwatcher.client import MonitoredOpenAI, MonitoredAnthropic


@pytest.fixture
def mock_openai_client():
    """Create mock OpenAI client."""
    client = Mock()
    client.chat = Mock()
    client.chat.completions = Mock()
    client.chat.completions.create = Mock()
    return client


@pytest.fixture
def mock_anthropic_client():
    """Create mock Anthropic client."""
    client = Mock()
    client.messages = Mock()
    client.messages.create = Mock()
    return client


@pytest.fixture
def mock_openai_response():
    """Create mock OpenAI response."""
    response = Mock()
    response.choices = [Mock()]
    response.choices[0].message = Mock()
    response.choices[0].message.content = "Paris is the capital of France."
    response.usage = Mock()
    response.usage.prompt_tokens = 10
    response.usage.completion_tokens = 20
    response.usage.total_tokens = 30
    return response


@pytest.fixture
def mock_anthropic_response():
    """Create mock Anthropic response."""
    response = Mock()
    response.content = [Mock()]
    response.content[0].text = "Paris is the capital of France."
    response.usage = Mock()
    response.usage.input_tokens = 10
    response.usage.output_tokens = 20
    return response


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_success(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test successful OpenAI call monitoring."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
        base_url="https://api.example.com",
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "What is the capital of France?"}]
    )

    # Should return original response
    assert response == mock_openai_response

    # Should have added event to buffer
    mock_buffer.add_event.assert_called_once()

    # Check event structure
    event = mock_buffer.add_event.call_args[0][0]
    assert event["provider"] == "openai"
    assert event["model"] == "gpt-4"
    assert event["inputTokens"] == 10
    assert event["outputTokens"] == 20
    assert event["success"] is True
    assert "latencyMs" in event
    assert "timestamp" in event


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_error(mock_buffer_class, mock_openai_client):
    """Test OpenAI call error monitoring."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    # Simulate an error
    error = ValueError("API Error")
    mock_openai_client.chat.completions.create.side_effect = error

    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
    )

    with pytest.raises(ValueError):
        client.chat.completions.create(model="gpt-4", messages=[])

    # Should have added error event to buffer
    mock_buffer.add_event.assert_called_once()

    # Check error event structure
    event = mock_buffer.add_event.call_args[0][0]
    assert event["provider"] == "openai"
    assert event["model"] == "gpt-4"
    assert event["success"] is False
    assert event["errorMessage"] == "API Error"
    assert event["errorType"] == "ValueError"
    assert "latencyMs" in event


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_anthropic_success(mock_buffer_class, mock_anthropic_client, mock_anthropic_response):
    """Test successful Anthropic call monitoring."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_anthropic_client.messages.create.return_value = mock_anthropic_response

    client = MonitoredAnthropic(
        mock_anthropic_client,
        api_key="ym_test_key",
        base_url="https://api.example.com",
    )

    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1024,
        messages=[{"role": "user", "content": "What is the capital of France?"}]
    )

    # Should return original response
    assert response == mock_anthropic_response

    # Should have added event to buffer
    mock_buffer.add_event.assert_called_once()

    # Check event structure
    event = mock_buffer.add_event.call_args[0][0]
    assert event["provider"] == "anthropic"
    assert event["model"] == "claude-3-5-sonnet-20241022"
    assert event["inputTokens"] == 10
    assert event["outputTokens"] == 20
    assert event["success"] is True
    assert "latencyMs" in event


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_anthropic_error(mock_buffer_class, mock_anthropic_client):
    """Test Anthropic call error monitoring."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    # Simulate an error
    error = RuntimeError("Rate limit exceeded")
    mock_anthropic_client.messages.create.side_effect = error

    client = MonitoredAnthropic(
        mock_anthropic_client,
        api_key="ym_test_key",
    )

    with pytest.raises(RuntimeError):
        client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[]
        )

    # Should have added error event to buffer
    mock_buffer.add_event.assert_called_once()

    # Check error event structure
    event = mock_buffer.add_event.call_args[0][0]
    assert event["provider"] == "anthropic"
    assert event["success"] is False
    assert event["errorMessage"] == "Rate limit exceeded"
    assert event["errorType"] == "RuntimeError"


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_with_context(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test OpenAI monitoring with context and user identifier."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
        context="production/chatbot",
        user_identifier="user-123",
    )

    client.chat.completions.create(model="gpt-4", messages=[])

    # Check event has context and user identifier
    event = mock_buffer.add_event.call_args[0][0]
    assert event["context"] == "production/chatbot"
    assert event["userIdentifier"] == "user-123"


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_with_metadata(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test OpenAI monitoring with custom metadata."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
        metadata={"environment": "production", "version": "1.0"},
    )

    client.chat.completions.create(model="gpt-4", messages=[])

    # Check event has metadata
    event = mock_buffer.add_event.call_args[0][0]
    assert event["metadata"] == {"environment": "production", "version": "1.0"}


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_flush(mock_buffer_class, mock_openai_client):
    """Test manual flush."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    client = MonitoredOpenAI(mock_openai_client, api_key="ym_test_key")

    client.flush()

    mock_buffer.flush.assert_called_once()


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_shutdown(mock_buffer_class, mock_openai_client):
    """Test shutdown."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    client = MonitoredOpenAI(mock_openai_client, api_key="ym_test_key")

    client.shutdown()

    mock_buffer.shutdown.assert_called_once()


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_disabled(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test monitoring when disabled."""
    mock_buffer = Mock()

    # Capture the config when EventBuffer is initialized
    def capture_config(config):
        mock_buffer.config = config
        return mock_buffer

    mock_buffer_class.side_effect = capture_config

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
        enabled=False,
    )

    response = client.chat.completions.create(model="gpt-4", messages=[])

    # Should still return response
    assert response == mock_openai_response

    # But buffer should be disabled
    assert mock_buffer.config.enabled is False


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_auto_context(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test automatic context detection when user doesn't provide context."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    # Create client WITHOUT context
    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
    )

    client.chat.completions.create(model="gpt-4", messages=[])

    # Check that context was auto-detected
    event = mock_buffer.add_event.call_args[0][0]
    assert event["context"] is not None
    assert "test_client" in event["context"]  # Should contain test module name


@patch('tokenwatcher.client.EventBuffer')
def test_monitored_openai_user_context_overrides_auto(mock_buffer_class, mock_openai_client, mock_openai_response):
    """Test that user-provided context overrides auto-detection."""
    mock_buffer = Mock()
    mock_buffer_class.return_value = mock_buffer

    mock_openai_client.chat.completions.create.return_value = mock_openai_response

    # Create client WITH explicit context
    client = MonitoredOpenAI(
        mock_openai_client,
        api_key="ym_test_key",
        context="my-custom-context",
    )

    client.chat.completions.create(model="gpt-4", messages=[])

    # Check that user's context is used (not auto-detected)
    event = mock_buffer.add_event.call_args[0][0]
    assert event["context"] == "my-custom-context"
