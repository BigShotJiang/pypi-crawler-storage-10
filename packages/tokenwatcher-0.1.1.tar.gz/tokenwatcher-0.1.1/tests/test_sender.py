"""Tests for event sender."""

import pytest
from unittest.mock import Mock, patch
from tokenwatcher.config import Config
from tokenwatcher.sender import EventSender


@pytest.fixture
def config():
    """Create test configuration."""
    return Config(
        api_key="ym_test_key",
        base_url="https://api.example.com",
        timeout=5,
        max_retries=3,
    )


@pytest.fixture
def sender(config):
    """Create event sender."""
    return EventSender(config)


def test_sender_initialization(sender, config):
    """Test sender initialization."""
    assert sender.config == config
    assert sender.session.headers["X-Monitor-Key"] == "ym_test_key"
    assert sender.session.headers["Content-Type"] == "application/json"


@patch('tokenwatcher.sender.requests.Session.post')
def test_send_batch_success(mock_post, sender):
    """Test successful batch send."""
    mock_response = Mock()
    mock_response.status_code = 202
    mock_response.json.return_value = {"status": "accepted"}
    mock_post.return_value = mock_response

    events = [
        {"timestamp": "2025-01-01T00:00:00Z", "provider": "openai", "model": "gpt-4"}
    ]

    result = sender.send_batch(events)

    assert result is True
    mock_post.assert_called_once()


@patch('tokenwatcher.sender.requests.Session.post')
def test_send_batch_validation_error(mock_post, sender):
    """Test batch send with validation error."""
    mock_response = Mock()
    mock_response.status_code = 400
    mock_response.text = "Validation error"
    mock_post.return_value = mock_response

    events = [{"invalid": "event"}]

    result = sender.send_batch(events)

    assert result is False


@patch('tokenwatcher.sender.requests.Session.post')
def test_send_batch_auth_error(mock_post, sender):
    """Test batch send with authentication error."""
    mock_response = Mock()
    mock_response.status_code = 401
    mock_response.text = "Unauthorized"
    mock_post.return_value = mock_response

    events = [{"timestamp": "2025-01-01T00:00:00Z"}]

    result = sender.send_batch(events)

    assert result is False


@patch('tokenwatcher.sender.requests.Session.post')
def test_send_batch_retry(mock_post, sender):
    """Test batch send with retries."""
    # First two attempts fail, third succeeds
    mock_response_fail = Mock()
    mock_response_fail.status_code = 500
    mock_response_fail.text = "Server error"

    mock_response_success = Mock()
    mock_response_success.status_code = 202
    mock_response_success.json.return_value = {"status": "accepted"}

    mock_post.side_effect = [mock_response_fail, mock_response_fail, mock_response_success]

    events = [{"timestamp": "2025-01-01T00:00:00Z"}]

    result = sender.send_batch(events)

    assert result is True
    assert mock_post.call_count == 3


def test_send_batch_empty(sender):
    """Test sending empty batch."""
    result = sender.send_batch([])
    assert result is True


def test_send_batch_disabled(config):
    """Test sending batch when monitoring is disabled."""
    config.enabled = False
    sender = EventSender(config)

    result = sender.send_batch([{"test": "event"}])
    assert result is True
