"""Setup script for tokenwatcher package."""
from setuptools import setup, find_packages

# Read README for long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="tokenwatcher",
    packages=find_packages(exclude=["tests", "examples"]),
    long_description=long_description,
    long_description_content_type="text/markdown",
    package_data={
        "tokenwatcher": ["py.typed"],
    },
)
