# EKS Auto Mode Preflight Checker CLI

A comprehensive command-line tool to assess your Amazon EKS cluster's readiness for migration to EKS Auto Mode. This enhanced CLI provides automation-friendly output formats, professional HTML reports, and proper exit codes for CI/CD integration.

## ✨ Features

- **11 Comprehensive Compatibility Checks**: Version, IAM, instances, Windows nodes, SSH/SSM access, custom AMIs, user data, addons, autoscaling, identity (IRSA/Pod Identity), and load balancers
- **Multiple Output Formats**: Table (default), JSON, YAML, and **HTML V2 Reports**
- **Professional HTML Reports**: AWS-branded EKS Automode Preflight Report V2 format
- **Enhanced Error Handling**: Specific AWS exception handling and robust error recovery
- **CI/CD Ready**: Proper exit codes for automation with intelligent status logic
- **Selective Testing**: Run specific checks or all checks
- **Verbose Mode**: Detailed recommendations and explanations
- **Modern Packaging**: Uses pyproject.toml for Python packaging standards

## Quick Start

### Installation

```bash
git clone <repository-url>
cd eks-automode-preflight-checker-cli
pip install -e .
```

> **Note**: Now uses modern `pyproject.toml` packaging - no separate requirements.txt needed!

### Usage

```bash
# Basic check with table output
eks-automode-cli check -c my-cluster --region us-east-1

# JSON output for automation
eks-automode-cli check -c my-cluster --region us-east-1 --output json

# YAML output
eks-automode-cli check -c my-cluster --region us-east-1 --output yaml

# Professional HTML V2 report
eks-automode-cli check -c my-cluster --region us-east-1 --output html

# Run specific checks only
eks-automode-cli check -c my-cluster --region us-east-1 --checks version,iam,instances

# Verbose output with recommendations
eks-automode-cli check -c my-cluster --region us-east-1 --verbose

# Quiet mode (exit codes only)
eks-automode-cli check -c my-cluster --region us-east-1 --quiet
```

### Other Commands

```bash
# List available checks
eks-automode-cli list-checks

# Show version
eks-automode-cli --version
```

## Exit Codes

- `0`: Ready for Auto Mode (all checks pass)
- `1`: Requires Changes (warnings or non-critical failures)
- `2`: Not Ready (only for custom AMI usage - critical blocker)
- `3`: Error during execution

> **Enhanced Logic**: Only custom AMIs result in "Not Ready" status. All other issues are considered fixable and return "Requires Changes".

## 🔍 Compatibility Checks

| Check | Description | Status Logic |
|-------|-------------|-------------|
| **version** | Validates Kubernetes 1.29+ requirement | FAIL if < 1.29 |
| **iam** | Checks cluster role and Auto Mode policies | WARN if missing policies |
| **instances** | Identifies incompatible nano/micro/small instances | FAIL if small instances found |
| **windows** | Detects unsupported Windows workloads | FAIL if Windows nodes detected |
| **ssh** | Identifies SSH keys and SSM access in node groups | FAIL if direct access configured |
| **amis** | Detects custom AMI usage (includes AL2023 support) | FAIL if custom AMIs (triggers NOT_READY) |
| **userdata** | Identifies custom node bootstrapping | FAIL if user data found |
| **addons** | Validates managed addons compatibility | WARN if conflicting addons |
| **autoscaling** | Detects Karpenter, Cluster Autoscaler, ASGs | WARN if existing autoscaling found |
| **identity** | Checks IRSA v1 vs Pod Identity usage | WARN if using IRSA v1, PASS for Pod Identity |
| **loadbalancers** | Detects ALBs and NLBs associated with cluster | WARN if load balancers found |

## Output Examples

### Table Output (Default)
```
Check         Status    Details
------------  --------  ----------------------------------
version       PASS      Kubernetes 1.29 supported
iam           PASS      All required policies attached
instances     FAIL      2 nano instances found
windows       PASS      No Windows nodes detected
identity      WARN      Using IRSA v1 (OIDC)
loadbalancers WARN      Found 2 load balancers
```

### JSON Output
```json
{
  "cluster": "my-cluster",
  "region": "us-east-1",
  "timestamp": "2024-12-15T10:30:00+00:00",
  "overall_status": "REQUIRES_CHANGES",
  "checks": {
    "version": {"status": "PASS", "details": "Kubernetes 1.29 supported"},
    "instances": {"status": "FAIL", "details": "2 nano instances found"},
    "identity": {"status": "WARN", "details": "Using IRSA v1 (OIDC)", "recommendations": ["Consider migrating to Pod Identity"]}
  }
}
```

### HTML V2 Report
Generates professional AWS-branded reports in `results/` folder:
- **File**: `EKS-Automode-Preflight-Report-V2-{cluster}-{timestamp}.html`
- **Features**: AWS styling, status cards, detailed recommendations, responsive design
- **Format**: Matches official AWS documentation standards

## AWS Permissions Required

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "eks:DescribeCluster",
                "eks:ListNodegroups",
                "eks:DescribeNodegroup",
                "eks:ListAddons",
                "eks:DescribeAddon",
                "ec2:DescribeInstances",
                "ec2:DescribeLaunchTemplateVersions",
                "autoscaling:DescribeAutoScalingGroups",
                "iam:ListAttachedRolePolicies",
                "iam:GetRole"
            ],
            "Resource": "*"
        }
    ]
}
```

## CI/CD Integration

```bash
#!/bin/bash
# Example CI/CD script with enhanced logic
eks-automode-cli check -c $CLUSTER_NAME --region $AWS_REGION --output json --quiet

case $? in
    0) echo "✅ Cluster ready for Auto Mode migration" ;;
    1) echo "⚠️  Manual configuration needed - check warnings" ;;
    2) echo "❌ Custom AMIs detected - migration blocked" && exit 1 ;;
    3) echo "💥 Assessment failed - check configuration" && exit 1 ;;
esac

# Generate HTML report for stakeholders
eks-automode-cli check -c $CLUSTER_NAME --region $AWS_REGION --output html
```

## 🚀 What's New in V2

### Enhanced Checks
- **Identity Check**: Detects IRSA v1 vs Pod Identity usage
- **Load Balancer Check**: Identifies ALBs and NLBs
- **Improved SSH Check**: Now detects both SSH keys and SSM policies
- **AL2023 Support**: Added Amazon Linux 2023 AMI recognition
- **Auto Mode Detection**: Automatically returns READY if cluster already has Auto Mode enabled

### Better Error Handling
- **Specific AWS Exceptions**: Replaced generic exception handling with ClientError
- **Robust Recovery**: Individual check failures don't break entire assessment
- **Timezone-Aware**: All timestamps now use UTC with timezone information

### Modern Packaging
- **pyproject.toml**: Modern Python packaging standards
- **Dependency Management**: Automatic dependency resolution
- **Entry Points**: Clean CLI installation

## 📚 Usage Examples

### Basic Usage
```bash
# 1. Basic check with table output
eks-automode-cli check -c my-cluster --region us-east-1

# 2. JSON output for automation
eks-automode-cli check -c my-cluster --region us-east-1 --output json

# 3. YAML output
eks-automode-cli check -c my-cluster --region us-east-1 --output yaml

# 4. Professional HTML V2 report
eks-automode-cli check -c my-cluster --region us-east-1 --output html

# 5. Run specific checks only
eks-automode-cli check -c my-cluster --checks version,iam,instances

# 6. Verbose output with recommendations
eks-automode-cli check -c my-cluster --verbose

# 7. Quiet mode (exit codes only)
eks-automode-cli check -c my-cluster --quiet
echo "Exit code: $?"

# 8. List available checks
eks-automode-cli list-checks

# 9. Show version
eks-automode-cli --version
```

### CI/CD Integration Example

```python
#!/usr/bin/env python3
import subprocess
import json
import sys
import shlex

def run_preflight_check(cluster_name, region='us-east-1'):
    cmd = [sys.executable, 'eks-automode-cli', 'check', 
           shlex.quote(cluster_name), '--region', shlex.quote(region), 
           '--output', 'json']
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if result.returncode == 3:
            print(f"Error: {result.stderr}")
            return None
        
        try:
            data = json.loads(result.stdout)
            return data, result.returncode
        except json.JSONDecodeError as e:
            print(f"Failed to parse JSON output: {e}")
            return None
    except Exception as e:
        print(f"Failed: {e}")
        return None

def main():
    if len(sys.argv) < 2:
        print("Usage: python ci-cd-integration.py <cluster-name> [region]")
        sys.exit(1)
    
    cluster_name = sys.argv[1]
    region = sys.argv[2] if len(sys.argv) > 2 else 'us-east-1'
    
    result = run_preflight_check(cluster_name, region)
    if result is None:
        sys.exit(3)
    
    data, exit_code = result
    try:
        print(f"Cluster: {data['cluster']} - Status: {data['overall_status']}")
    except KeyError as e:
        print(f"Missing expected key in response: {e}")
        sys.exit(3)
    
    if exit_code == 0:
        print("✅ Ready for Auto Mode migration")
    elif exit_code == 1:
        print("⚠️ Manual configuration needed")
    elif exit_code == 2:
        print("❌ Custom AMIs detected - migration blocked")
    else:
        print("💥 Assessment failed")
    
    sys.exit(exit_code)

if __name__ == '__main__':
    main()
```

## Development

```bash
# Install in development mode
pip install -e .

# Run specific checks
eks-automode-cli check -c test-cluster --checks version,iam

# Generate HTML report
eks-automode-cli check -c test-cluster --output html
```

## 📋 Dependencies

All dependencies are managed via `pyproject.toml`:
- **click**: CLI framework
- **boto3**: AWS SDK
- **tabulate**: Table formatting
- **pyyaml**: YAML output support
- **packaging**: Version comparison
- **botocore**: AWS core functionality

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with multiple clusters
5. Submit a pull request

## Changelog

### V2.0 (Latest)
- ✅ Added 2 new check modules (identity, loadbalancers)
- ✅ Enhanced HTML reports with AWS V2 format
- ✅ Improved error handling across all modules
- ✅ Modern pyproject.toml packaging
- ✅ AL2023 AMI support
- ✅ Intelligent exit code logic
- ✅ Auto Mode detection
- ✅ Timezone-aware timestamps

### V1.0
- ✅ Initial 9 core compatibility checks
- ✅ Multiple output formats
- ✅ CI/CD integration support

## 📊 Report Formats

| Format | Use Case | Features |
|--------|----------|----------|
| **Table** | Interactive CLI usage | Color-coded status, truncated details |
| **JSON** | CI/CD automation | Machine-readable, complete data |
| **YAML** | Configuration management | Human-readable structured data |
| **HTML V2** | Executive reporting | AWS-branded, professional layout, charts |

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.