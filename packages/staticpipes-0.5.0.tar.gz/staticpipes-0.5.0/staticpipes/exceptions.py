class WatchFunctionalityNotImplementedException(Exception):
    pass
