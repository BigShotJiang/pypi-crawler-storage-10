from .directory_base import BaseDirectory


class SourceDirectory(BaseDirectory):
    pass
