"""Unit tests for generateFMSynth function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_fm_synth
from tests.base import TempDirTestCase


class TestGenerateFMSynth(TempDirTestCase):
    """Tests for the generate_fm_synth function."""
    
    def test_generate_fm_synth_basic(self):
        """Test basic FM synthesis."""
        result = generate_fm_synth.fn(
            carrier_freq=440.0,
            modulator_freq=220.0,
            mod_index=2.0,
            duration=1.0
        )
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        self.assertEqual(len(audio), 44100)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_fm_synth_parameters(self):
        """Test FM synthesis with different parameters."""
        result = generate_fm_synth.fn(
            carrier_freq=880.0,
            modulator_freq=110.0,
            mod_index=5.0,
            duration=0.5,
            amplitude=0.3
        )
        
        self.assertNotIn("error", result)
        self.assertEqual(result["carrier_freq"], 880.0)
        self.assertEqual(result["modulator_freq"], 110.0)
        self.assertEqual(result["mod_index"], 5.0)
        
        # Clean up
        Path(result["file_path"]).unlink()
