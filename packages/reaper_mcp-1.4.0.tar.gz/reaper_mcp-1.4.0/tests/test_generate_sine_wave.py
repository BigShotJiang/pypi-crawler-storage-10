"""Unit tests for generateSineWave function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_sine_wave
from tests.base import TempDirTestCase


class TestGenerateSineWave(TempDirTestCase):
    """Tests for the generate_sine_wave function."""
    
    def setUp(self):
        """Set up test parameters."""
        self.temp_dir = tempfile.mkdtemp()
    
    def test_generate_sine_wave_basic(self):
        """Test basic sine wave generation."""
        result = generate_sine_wave.fn(frequency=440.0, duration=1.0)
        
        # Check result structure
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertIn("frequency", result)
        self.assertIn("duration", result)
        self.assertIn("amplitude", result)
        self.assertIn("sample_rate", result)
        
        # Check values
        self.assertEqual(result["frequency"], 440.0)
        self.assertEqual(result["duration"], 1.0)
        self.assertEqual(result["amplitude"], 0.5)
        self.assertEqual(result["sample_rate"], 44100)
        
        # Check file exists
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio content
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        self.assertEqual(len(audio), 44100)  # 1 second at 44100 Hz
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_sine_wave_custom_params(self):
        """Test sine wave generation with custom parameters."""
        result = generate_sine_wave.fn(
            frequency=880.0,
            duration=0.5,
            amplitude=0.8,
            sample_rate=48000
        )
        
        self.assertNotIn("error", result)
        self.assertEqual(result["frequency"], 880.0)
        self.assertEqual(result["duration"], 0.5)
        self.assertEqual(result["amplitude"], 0.8)
        self.assertEqual(result["sample_rate"], 48000)
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 48000)
        self.assertEqual(len(audio), 24000)  # 0.5 seconds at 48000 Hz
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_sine_wave_invalid_frequency(self):
        """Test sine wave generation with invalid frequency."""
        result = generate_sine_wave.fn(frequency=-1.0, duration=1.0)
        self.assertIn("error", result)
    
    def test_generate_sine_wave_invalid_duration(self):
        """Test sine wave generation with invalid duration."""
        result = generate_sine_wave.fn(frequency=440.0, duration=0.0)
        self.assertIn("error", result)
    
    def test_generate_sine_wave_invalid_amplitude(self):
        """Test sine wave generation with invalid amplitude."""
        result = generate_sine_wave.fn(frequency=440.0, duration=1.0, amplitude=1.5)
        self.assertIn("error", result)
