"""Unit tests for normalizeAudio function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.audio_processing import normalize_audio
from tests.base import TempDirTestCase


class TestNormalizeAudio(TempDirTestCase):
    """Tests for the normalize_audio function."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.test_file = self.temp_dir / "test_audio.wav"
        
        # Create a quiet test audio file
        sample_rate = 44100
        duration = 1.0
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        audio = 0.1 * np.sin(2 * np.pi * 440.0 * t)  # Quiet audio
        sf.write(self.test_file, audio, sample_rate)
    
    def test_normalize_audio_basic(self):
        """Test basic audio normalization."""
        result = normalize_audio(self.test_file, target_db=-3.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio is louder
        original_audio, _ = sf.read(self.test_file)
        normalized_audio, _ = sf.read(result["file_path"])
        
        # Normalized audio should have higher peak
        self.assertGreater(np.max(np.abs(normalized_audio)), np.max(np.abs(original_audio)))
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_normalize_audio_target_db(self):
        """Test normalization with different target dB."""
        result = normalize_audio(self.test_file, target_db=-6.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        
        # Peak should be close to target (allowing some tolerance)
        peak_db = 20 * np.log10(np.max(np.abs(audio)))
        self.assertAlmostEqual(peak_db, -6.0, delta=1.0)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_normalize_audio_already_normalized(self):
        """Test normalizing already loud audio."""
        # Create a loud test file
        loud_file = Path(self.temp_dir, "loud_audio.wav")
        sample_rate = 44100
        duration = 1.0
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        audio = 0.9 * np.sin(2 * np.pi * 440.0 * t)  # Already loud
        sf.write(loud_file, audio, sample_rate)
        
        result = normalize_audio(loud_file, target_db=-3.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
        Path(loud_file).unlink()
    
    def test_normalize_audio_nonexistent_file(self):
        """Test normalizing nonexistent file."""
        result = normalize_audio("/nonexistent/file.wav")
        
        self.assertIn("error", result)
