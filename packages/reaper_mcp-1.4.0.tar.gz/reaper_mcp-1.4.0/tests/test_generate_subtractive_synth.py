"""Unit tests for generateSubtractiveSynth function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_subtractive_synth
from tests.base import TempDirTestCase


class TestGenerateSubtractiveSynth(TempDirTestCase):
    """Tests for the generate_subtractive_synth function."""
    
    def test_generate_subtractive_synth_lowpass(self):
        """Test subtractive synthesis with lowpass filter."""
        result = generate_subtractive_synth.fn(
            base_waveform="sawtooth",
            filter_type="lowpass",
            cutoff=1000.0,
            resonance=1.0,
            amplitude=0.5
        )
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_subtractive_synth_highpass(self):
        """Test subtractive synthesis with highpass filter."""
        result = generate_subtractive_synth.fn(
            base_waveform="square",
            filter_type="highpass",
            cutoff=500.0,
            resonance=2.0,
            amplitude=0.5
        )
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_subtractive_synth_bandpass(self):
        """Test subtractive synthesis with bandpass filter."""
        result = generate_subtractive_synth.fn(
            base_waveform="sine",
            filter_type="bandpass",
            cutoff=2000.0,
            resonance=1.5,
            amplitude=0.5
        )
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_subtractive_synth_invalid_waveform(self):
        """Test subtractive synthesis with invalid waveform type."""
        result = generate_subtractive_synth.fn(
            base_waveform="invalid",
            filter_type="lowpass",
            cutoff=1000.0
        )
        
        self.assertIn("error", result)
    
    def test_generate_subtractive_synth_invalid_filter(self):
        """Test subtractive synthesis with invalid filter type."""
        result = generate_subtractive_synth.fn(
            base_waveform="sine",
            filter_type="invalid",
            cutoff=1000.0
        )
        
        self.assertIn("error", result)
