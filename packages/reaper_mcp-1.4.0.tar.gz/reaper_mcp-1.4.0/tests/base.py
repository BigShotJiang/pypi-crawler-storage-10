"""Base test class for tests that need temporary directories."""
import unittest
import tempfile
import shutil
from pathlib import Path


class TempDirTestCase(unittest.TestCase):
    """Base test case that provides a temporary directory for testing.
    
    The temporary directory is created in setUp and cleaned up in tearDown.
    Subclasses can access it via self.temp_dir as a Path object.
    """
    
    def setUp(self):
        """Create a temporary directory for testing."""
        # Create temp directory and convert to Path
        self.temp_dir = Path(tempfile.mkdtemp())
    
    def tearDown(self):
        """Clean up the temporary directory and all its contents."""
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
