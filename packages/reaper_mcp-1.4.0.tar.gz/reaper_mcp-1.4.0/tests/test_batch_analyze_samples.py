"""Unit tests for _batch_analyze_samples function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf

from reaper_mcp.audio.audio_analysis import _batch_analyze_samples
from tests.base import TempDirTestCase


class TestBatchAnalyzeSamples(TempDirTestCase):
    """Tests for the batch_analyze_samples function."""
    
    def setUp(self):
        """Set up test parameters."""
        self.sample_rate = 44100
        self.duration = 1.0
        self.temp_dir = tempfile.mkdtemp()
    
    def _create_test_files(self, count: int = 3):
        """Create multiple test audio files."""
        files = []
        for i in range(count):
            filename = Path(self.temp_dir, f"test_audio_{i}.wav")
            t = np.linspace(0, self.duration, int(self.sample_rate * self.duration), endpoint=False)
            # Different frequencies for each file
            freq = 440.0 * (2 ** (i / 12))  # Semitones apart
            audio = 0.5 * np.sin(2 * np.pi * freq * t)
            sf.write(filename, audio, self.sample_rate)
            files.append(filename)
        return files
    
    def test_batch_analyze_empty_directory(self):
        """Test batch analysis of empty directory."""
        result = _batch_analyze_samples(self.temp_dir)
        
        self.assertIn("results", result)
        self.assertEqual(len(result["results"]), 0)
        self.assertEqual(result["total_files"], 0)
        self.assertEqual(result["analyzed"], 0)
        self.assertEqual(result["errors"], 0)
    
    def test_batch_analyze_multiple_files(self):
        """Test batch analysis of multiple files."""
        files = self._create_test_files(3)
        
        result = _batch_analyze_samples(self.temp_dir)
        
        self.assertIn("results", result)
        self.assertEqual(result["total_files"], 3)
        self.assertEqual(result["analyzed"], 3)
        self.assertEqual(result["errors"], 0)
        self.assertEqual(len(result["results"]), 3)
    
    def test_batch_analyze_with_extension_filter(self):
        """Test batch analysis with specific extensions."""
        # Create wav files
        self._create_test_files(2)
        
        # Create a non-wav file
        other_file = Path(self.temp_dir, "test.txt")
        with open(other_file, 'w') as f:
            f.write("test")
        
        result = _batch_analyze_samples(self.temp_dir, extensions=[".wav"])
        
        # Should only analyze wav files
        self.assertEqual(result["total_files"], 2)
    
    def test_batch_analyze_nonexistent_directory(self):
        """Test batch analysis of nonexistent directory."""
        result = _batch_analyze_samples("/nonexistent/directory")
        
        self.assertIn("error", result)
    
    def test_batch_analyze_force_reanalyze(self):
        """Test force re-analysis of cached files."""
        self._create_test_files(2)
        
        # First analysis
        result1 = _batch_analyze_samples(self.temp_dir)
        self.assertEqual(result1["analyzed"], 2)
        
        # Second analysis should use cache (analyzed=0, cached=2)
        result2 = _batch_analyze_samples(self.temp_dir)
        self.assertEqual(result2["cached"], 2)
        self.assertEqual(result2["analyzed"], 0)
        
        # Force re-analysis should analyze again
        result3 = _batch_analyze_samples(self.temp_dir, force_reanalyze=True)
        self.assertEqual(result3["analyzed"], 2)
