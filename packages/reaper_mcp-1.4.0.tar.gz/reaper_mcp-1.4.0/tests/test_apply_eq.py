"""Unit tests for applyEQ function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.audio_processing import apply_eq
from tests.base import TempDirTestCase


class TestApplyEQ(TempDirTestCase):
    """Tests for the apply_eq function."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.test_file = self.temp_dir / "test_audio.wav"
        
        # Create a test audio file with mixed frequencies
        sample_rate = 44100
        duration = 1.0
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        # Mix of low, mid, and high frequencies
        audio = 0.3 * np.sin(2 * np.pi * 100 * t)  # Low
        audio += 0.3 * np.sin(2 * np.pi * 1000 * t)  # Mid
        audio += 0.3 * np.sin(2 * np.pi * 5000 * t)  # High
        sf.write(self.test_file, audio, sample_rate)
    
    def test_apply_eq_boost_low(self):
        """Test boosting low frequencies."""
        result = apply_eq(self.test_file, low_gain=6.0, mid_gain=0.0, high_gain=0.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_apply_eq_cut_mid(self):
        """Test cutting mid frequencies."""
        result = apply_eq(self.test_file, low_gain=0.0, mid_gain=-6.0, high_gain=0.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_apply_eq_boost_high(self):
        """Test boosting high frequencies."""
        result = apply_eq(self.test_file, low_gain=0.0, mid_gain=0.0, high_gain=6.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_apply_eq_all_bands(self):
        """Test applying EQ to all bands."""
        result = apply_eq(self.test_file, low_gain=3.0, mid_gain=-3.0, high_gain=2.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_apply_eq_no_change(self):
        """Test EQ with no changes (all gains = 0)."""
        result = apply_eq(self.test_file, low_gain=0.0, mid_gain=0.0, high_gain=0.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_apply_eq_nonexistent_file(self):
        """Test applying EQ to nonexistent file."""
        result = apply_eq("/nonexistent/file.wav", low_gain=3.0)
        
        self.assertIn("error", result)
