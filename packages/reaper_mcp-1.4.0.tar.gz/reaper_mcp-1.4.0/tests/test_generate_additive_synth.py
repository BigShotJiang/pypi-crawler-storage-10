"""Unit tests for generateAdditiveSynth function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_additive_synth
from tests.base import TempDirTestCase


class TestGenerateAdditiveSynth(TempDirTestCase):
    """Tests for the generate_additive_synth function."""
    
    def test_generate_additive_synth_basic(self):
        """Test basic additive synthesis."""
        partials = [
            {"frequency": 440.0, "amplitude": 1.0},
            {"frequency": 880.0, "amplitude": 0.5},
            {"frequency": 1320.0, "amplitude": 0.25},
        ]
        
        result = generate_additive_synth.fn(partials=partials, duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_additive_synth_single_partial(self):
        """Test additive synthesis with single partial."""
        partials = [{"frequency": 440.0, "amplitude": 1.0}]
        
        result = generate_additive_synth.fn(partials=partials, duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_additive_synth_empty_partials(self):
        """Test additive synthesis with empty partials list."""
        result = generate_additive_synth.fn(partials=[], duration=1.0)
        
        self.assertIn("error", result)
