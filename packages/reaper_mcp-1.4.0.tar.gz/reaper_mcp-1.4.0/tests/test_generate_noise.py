"""Unit tests for generateNoise function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_noise
from tests.base import TempDirTestCase


class TestGenerateNoise(TempDirTestCase):
    """Tests for the generate_noise function."""
    
    def test_generate_white_noise(self):
        """Test white noise generation."""
        result = generate_noise.fn(noise_type="white", duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        
        # White noise should have relatively uniform distribution
        # Check that standard deviation is reasonable
        self.assertGreater(np.std(audio), 0.1)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_pink_noise(self):
        """Test pink noise generation."""
        result = generate_noise.fn(noise_type="pink", duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_brown_noise(self):
        """Test brown noise generation."""
        result = generate_noise.fn(noise_type="brown", duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_noise_invalid_type(self):
        """Test noise generation with invalid type."""
        result = generate_noise.fn(noise_type="invalid", duration=1.0)
        
        self.assertIn("error", result)
