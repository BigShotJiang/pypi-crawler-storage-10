"""Unit tests for generateSawtoothWave function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_sawtooth_wave
from tests.base import TempDirTestCase


class TestGenerateSawtoothWave(TempDirTestCase):
    """Tests for the generate_sawtooth_wave function."""
    
    def test_generate_sawtooth_wave_basic(self):
        """Test basic sawtooth wave generation."""
        result = generate_sawtooth_wave.fn(frequency=440.0, duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        self.assertEqual(len(audio), 44100)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_sawtooth_wave_range(self):
        """Test sawtooth wave stays within amplitude range."""
        result = generate_sawtooth_wave.fn(frequency=440.0, duration=1.0, amplitude=0.5)
        
        audio, sr = sf.read(result["file_path"])
        
        # Check amplitude range
        self.assertLessEqual(np.max(audio), 0.5)
        self.assertGreaterEqual(np.min(audio), -0.5)
        
        # Clean up
        Path(result["file_path"]).unlink()
