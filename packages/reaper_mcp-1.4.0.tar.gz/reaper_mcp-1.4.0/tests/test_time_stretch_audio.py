"""Unit tests for timeStretchAudio function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.audio_processing import time_stretch_audio
from tests.base import TempDirTestCase


class TestTimeStretchAudio(TempDirTestCase):
    """Tests for the time_stretch_audio function."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.test_file = self.temp_dir / "test_audio.wav"
        
        # Create a simple test audio file
        sample_rate = 44100
        duration = 2.0
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        audio = 0.5 * np.sin(2 * np.pi * 440.0 * t)
        sf.write(self.test_file, audio, sample_rate)
    
    def test_time_stretch_slower(self):
        """Test slowing down audio (rate < 1.0)."""
        result = time_stretch_audio(self.test_file, rate=0.5)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio is longer
        original_audio, _ = sf.read(self.test_file)
        stretched_audio, _ = sf.read(result["file_path"])
        
        # Should be approximately twice as long
        expected_length = int(len(original_audio) / 0.5)
        self.assertAlmostEqual(len(stretched_audio), expected_length, delta=1000)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_time_stretch_faster(self):
        """Test speeding up audio (rate > 1.0)."""
        result = time_stretch_audio(self.test_file, rate=2.0)
        
        self.assertNotIn("error", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio is shorter
        original_audio, _ = sf.read(self.test_file)
        stretched_audio, _ = sf.read(result["file_path"])
        
        # Should be approximately half as long
        expected_length = int(len(original_audio) / 2.0)
        self.assertAlmostEqual(len(stretched_audio), expected_length, delta=1000)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_time_stretch_preserve_pitch(self):
        """Test time stretching with pitch preservation."""
        result = time_stretch_audio(self.test_file, rate=1.5, preserve_pitch=True)
        
        # Since librosa is not installed, this should return an error
        self.assertIn("error", result)
        self.assertIn("librosa", result["error"].lower())
    
    def test_time_stretch_invalid_rate(self):
        """Test time stretching with invalid rate."""
        result = time_stretch_audio(self.test_file, rate=0.0)
        
        self.assertIn("error", result)
    
    def test_time_stretch_nonexistent_file(self):
        """Test time stretching nonexistent file."""
        result = time_stretch_audio("/nonexistent/file.wav", rate=1.5)
        
        self.assertIn("error", result)
