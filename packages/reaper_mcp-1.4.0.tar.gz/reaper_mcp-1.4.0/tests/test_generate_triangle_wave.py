"""Unit tests for generateTriangleWave function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_triangle_wave
from tests.base import TempDirTestCase


class TestGenerateTriangleWave(TempDirTestCase):
    """Tests for the generate_triangle_wave function."""
    
    def test_generate_triangle_wave_basic(self):
        """Test basic triangle wave generation."""
        result = generate_triangle_wave.fn(frequency=440.0, duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_triangle_wave_amplitude(self):
        """Test triangle wave amplitude."""
        result = generate_triangle_wave.fn(frequency=440.0, duration=1.0, amplitude=0.7)
        
        audio, sr = sf.read(result["file_path"])
        
        # Check peak amplitude is close to specified amplitude
        self.assertAlmostEqual(np.max(np.abs(audio)), 0.7, places=1)
        
        # Clean up
        Path(result["file_path"]).unlink()
