"""Unit tests for generateSquareWave function."""
import unittest
from pathlib import Path
import numpy as np
import soundfile as sf
from reaper_mcp.audio.waveform_generation import generate_square_wave
from tests.base import TempDirTestCase


class TestGenerateSquareWave(TempDirTestCase):
    """Tests for the generate_square_wave function."""
    
    def test_generate_square_wave_basic(self):
        """Test basic square wave generation."""
        result = generate_square_wave.fn(frequency=440.0, duration=1.0)
        
        self.assertNotIn("error", result)
        self.assertIn("file_path", result)
        self.assertTrue(Path(result["file_path"]).exists())
        
        # Verify audio
        audio, sr = sf.read(result["file_path"])
        self.assertEqual(sr, 44100)
        
        # Square wave should have values close to +amplitude or -amplitude
        unique_values = np.unique(np.round(audio, 1))
        self.assertLessEqual(len(unique_values), 3)  # Should be mostly +0.5 and -0.5
        
        # Clean up
        Path(result["file_path"]).unlink()
    
    def test_generate_square_wave_spectrum(self):
        """Test square wave has expected harmonic content."""
        result = generate_square_wave.fn(frequency=100.0, duration=1.0)
        
        audio, sr = sf.read(result["file_path"])
        
        # Square wave should be mostly +/- amplitude
        self.assertGreater(np.sum(np.abs(audio) > 0.4), len(audio) * 0.9)
        
        # Clean up
        Path(result["file_path"]).unlink()
