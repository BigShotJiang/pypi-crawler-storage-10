"""MIDI operations and music theory tools."""

from reaper_mcp.midi import midi
from reaper_mcp.midi import music_theory

__all__ = ["midi", "music_theory"]
