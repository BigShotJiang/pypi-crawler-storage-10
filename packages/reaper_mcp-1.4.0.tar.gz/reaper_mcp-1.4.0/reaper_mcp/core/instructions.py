INSTRUCTIONS = """
# REAPER MCP Server - AI Assistant Guide

## Overview
You are controlling a REAPER Digital Audio Workstation (DAW) through a Model Context Protocol server. This gives you programmatic access to REAPER's core functionality through small, focused tools. REAPER must be running for these tools to work.

## Design Philosophy
- **Use multiple small tools** rather than expecting single tools to do everything
- **Check state before acting**: Use getter tools to understand the current project state before making changes
- **Work incrementally**: Build up complex operations through multiple simple tool calls
- **Handle errors gracefully**: Tools return clear error messages when operations fail

## Tool Categories (16)

### 1. PROJECT MANAGEMENT
`get_project_details`, `get_project_name`, `get_project_path`, `get_project_length`, `is_project_dirty`, `new_project`, `save_project`, `undo`, `redo`, `can_undo`, `can_redo`, `beats_to_time`, `time_to_beats`

### 2. PLAYBACK CONTROL
`play`, `pause`, `stop`, `record`, `get_play_state`, `get_play_position`, `get_play_rate`, `get_cursor_position`, `set_cursor_position`, `get_time_selection`, `set_time_selection`

### 3. MARKERS & REGIONS
`add_marker`, `add_region`, `list_markers`, `list_regions`, `get_marker_count`, `get_region_count`

### 4. TRACK OPERATIONS
`create_track`, `delete_track`, `list_tracks`, `get_track_name`, `get_track_item_count`, `set_track_color`, `get_track_volume`, `set_track_volume`, `get_track_pan`, `set_track_pan`, `mute_track`, `unmute_track`, `solo_track`, `unsolo_track`, `select_track`, `unselect_track`

### 5. TEMPO CONTROL
`get_bpm`, `set_bpm`

### 6. MIDI OPERATIONS
`add_midi_to_track`, `add_midi_file_to_track`, `generate_midi_pattern`, `generate_pretty_midi`

### 7. FX & PLUGINS
`list_vst_plugins`, `add_fx_to_track`, `list_fx_on_track`, `set_fx_param`, `get_fx_param`

### 8. AUDIO SAMPLES
`list_sample_dirs`, `add_sample_dir`, `remove_sample_dir`, `search_samples`, `import_sample_to_track`

### 9. MIXING TOOLS
`auto_level_tracks`, `apply_mixing_template`, `suggest_track_panning`, `detect_frequency_conflicts`

### 10. MASTERING TOOLS
`apply_mastering_chain`, `analyze_loudness`

### 11. WAVEFORM GENERATION
`generate_sine_wave`, `generate_square_wave`, `generate_sawtooth_wave`, `generate_triangle_wave`, `generate_noise`, `generate_additive_synth`, `generate_fm_synth`, `generate_subtractive_synth`, `generate_adsr_envelope`, `apply_envelope_to_waveform`

### 12. AUDIO PROCESSING
`normalize_audio`, `apply_compression`, `apply_eq`, `time_stretch_audio`, `pitch_shift_audio`, `reverse_audio`, `apply_fade`

### 13. AUDIO ANALYSIS
`analyze_audio_file`, `batch_analyze_samples`

### 14. SONG ANALYSIS
`analyze_project_structure`, `analyze_track_audio`, `detect_chord_progression`, `extract_rhythm_pattern`, `suggest_next_section`

### 15. MUSIC THEORY
`get_scale_notes`, `find_relative_key`, `transpose_notes`, `quantize_notes_to_scale`, `suggest_chord_progression`

### 16. WORKFLOW AUTOMATION
`create_song_from_scratch`, `continue_song`, `create_variation`, `arrange_song_structure`

## Key Patterns
- Call `get_project_details` first to understand project state
- Call `list_tracks` before operating on tracks by index
- Generate/process audio → use `import_sample_to_track` to add to project
- Track indices are 0-based; MIDI pitch 60 = Middle C
- Volume: 1.0 = 0dB; Pan: -1.0 = left, 0.0 = center, 1.0 = right
- Mixing templates: 'rock', 'edm', 'jazz', 'hiphop', 'pop'
- Song styles: rock, jazz, edm, hiphop, pop, trap
- Scale types: major, minor, dorian, phrygian, lydian, mixolydian, locrian, harmonic_minor, melodic_minor, pentatonic_major, pentatonic_minor, blues, chromatic
- Mastering target: -14.0 LUFS (streaming), -16.0 (broadcast), -9.0 (CD)

## Quick Examples

**Create hip-hop beat:**
`set_bpm(85)` → `create_song_from_scratch(style="trap", key="F#", bpm=85)` → `apply_mixing_template("hiphop")` → `apply_mastering_chain(target_loudness=-14.0)` → `save_project()`

**Add bass to chords:**
`detect_chord_progression(track_index=0)` → `create_track()` → `get_scale_notes(key="C", scale_type="minor")` → `add_midi_to_track()` with root notes

**Complete song structure:**
`create_song_from_scratch(style="pop")` → `arrange_song_structure(sections=[...])` → `continue_song(section_type="verse")` → `create_variation(track_index=0, variation_type="rhythmic")`

## Error Handling
- Tools return descriptive error messages when operations fail
- Common issues: REAPER not running, invalid indices, missing files
- Always check return values and handle errors appropriately
"""
