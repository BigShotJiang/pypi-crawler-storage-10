"""Core infrastructure for Reaper MCP."""

from reaper_mcp.core.mcp_core import mcp
from reaper_mcp.core.instructions import INSTRUCTIONS

__all__ = ["mcp", "INSTRUCTIONS"]
