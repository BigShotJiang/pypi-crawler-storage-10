"""
Reaper MCP - Model Context Protocol server for REAPER DAW.

This package provides a comprehensive set of tools for controlling REAPER
through the Model Context Protocol, organized into logical submodules:

- core: Core infrastructure (MCP server, instructions, utilities)
- project: Project management and workflow tools
- structure: Project structure (tracks, markers, tempo)
- audio: Audio processing, analysis, and sample management
- midi: MIDI operations and music theory
- effects: Effects, mixing, and mastering tools
- analysis: Song and music analysis
"""

__version__ = "0.1.0"

# Submodules are available for import but not loaded at package init
# to avoid circular dependencies
__all__ = [
    "core",
    "project",
    "structure",
    "audio",
    "midi",
    "effects",
    "analysis",
]
