from .read import UKBPhenReader
from .read import MultiPhenTabularReader

__all__ = ['UKBPhenReader', 'MultiPhenTabularReader']
