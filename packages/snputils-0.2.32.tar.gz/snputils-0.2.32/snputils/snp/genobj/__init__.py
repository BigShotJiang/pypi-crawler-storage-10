from .snpobj import SNPObject

__all__ = ['SNPObject']
