import os
import re
from enum import Enum
from typing import Callable, Optional
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from lseg_analytics_jupyterlab.src.classes.loggers import logger_main


class EventType(Enum):
    """Enumeration of supported file system event types."""

    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    CHANGED = "changed"


class DependencyChangeHandler(FileSystemEventHandler):
    """
    Handles file system events for dependency changes.

    This handler specifically watches for LSEG Analytics package changes by:
    - Only processing directory events (not individual file changes) to reduce noise
    - Matching directory names against the pattern 'lseg_analytics-*.dist-info'
    - Monitoring subdirectories within packages, not just top-level package folders

    When a matching change is detected, it invokes the provided callback with
    the package name and event type.
    """

    def __init__(self, callback: Callable[[str, EventType], None]):
        """
        Initialize the handler with a callback function.

        Args:
            callback: Function to call when a matching dependency change is detected.
                     Takes package_name and event_type as parameters.
                     Event types: EventType.CREATED, EventType.MODIFIED, EventType.DELETED, EventType.CHANGED
        """
        super().__init__()
        self.callback = callback
        # Pattern to match LSEG analytics packages (case-insensitive)
        self.versioned_dir_pattern = re.compile(
            r"^lseg_analytics-\S+\.dist-info$", re.IGNORECASE
        )

    def _extract_directory_name(self, file_path: str) -> Optional[str]:
        """
        Extract the directory name from the file path.

        Args:
            file_path: Full path to the file/directory

        Returns:
            Directory name if found, None otherwise
        """
        try:
            # Handle empty path case
            if not file_path:
                return None

            # Normalize the path first to handle trailing slashes properly
            # e.g., /some/dir/ -> /some/dir -> dir (instead of empty string)
            normalized_path = os.path.normpath(file_path)
            dir_name = os.path.basename(normalized_path)

            # Return None for current directory reference
            return dir_name if dir_name and dir_name != "." else None
        except Exception as e:
            logger_main.error(
                f"[DependencyChangeHandler] Failed to extract directory name from {file_path}: {e}"
            )
            return None

    def _is_lseg_analytics_package(self, package_name: str) -> bool:
        """
        Test the package name against the versioned directory pattern.

        Args:
            package_name: Name of the package to test

        Returns:
            True if the package matches the pattern, False otherwise
        """
        return bool(self.versioned_dir_pattern.match(package_name))

    def _handle_file_system_event(self, event: FileSystemEvent, event_type: EventType):
        """
        Common handler for file system events.

        Only processes directory events to focus on actual package installation/removal
        events and prevent excessive noise from temporary files.

        Important: This watches for changes to subdirectories within packages
        (like lseg_analytics-1.0.0.dist-info), not the top-level package folder itself.

        Args:
            event: The file system event
            event_type: Type of event (EventType enum)
        """
        try:
            package_name = self._extract_directory_name(event.src_path)
            if package_name and self._is_lseg_analytics_package(package_name):
                logger_main.debug(
                    f"[DependencyChangeHandler] Dependency {event_type}: {package_name} at {event.src_path}"
                )
                # Invoke the callback with the package name and event type
                self.callback(package_name, event_type)
        except Exception as e:
            logger_main.error(
                f"[DependencyChangeHandler] Error handling {event_type} event for {event.src_path}: {e}"
            )

    def on_created(self, event: FileSystemEvent):
        """Handle file/directory creation events."""
        if event.is_directory:
            self._handle_file_system_event(event, EventType.CREATED)

    def on_modified(self, event: FileSystemEvent):
        """Handle file/directory modification events."""
        if event.is_directory:
            self._handle_file_system_event(event, EventType.MODIFIED)

    def on_deleted(self, event: FileSystemEvent):
        """Handle file/directory deletion events."""
        if event.is_directory:
            self._handle_file_system_event(event, EventType.DELETED)
