# type: ignore
import os
import tempfile
import pytest
from unittest.mock import Mock, patch, MagicMock
from watchdog.events import DirCreatedEvent, DirModifiedEvent, DirDeletedEvent
from lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler import (
    DependencyChangeHandler,
    EventType,
)


@pytest.fixture
def mock_callback():
    """Mock callback function for testing."""
    return Mock()


@pytest.fixture
def handler(mock_callback):
    """Create a DependencyChangeHandler instance for testing."""
    return DependencyChangeHandler(mock_callback)


class TestDependencyChangeHandler:
    def test_init(self, mock_callback):
        """Test handler initialization."""
        handler = DependencyChangeHandler(mock_callback)
        assert handler.callback == mock_callback
        assert handler.versioned_dir_pattern is not None

    def test_extract_directory_name_valid_path(self, handler):
        """Test extracting directory name from valid file path."""
        test_path = "/path/to/lseg_analytics-1.0.0.dist-info"
        result = handler._extract_directory_name(test_path)
        assert result == "lseg_analytics-1.0.0.dist-info"

    def test_extract_directory_name_root_path(self, handler):
        """Test extracting directory name from root path."""
        test_path = "lseg_analytics-1.0.0.dist-info"
        result = handler._extract_directory_name(test_path)
        assert result == "lseg_analytics-1.0.0.dist-info"

    def test_extract_directory_name_empty_path(self, handler):
        """Test extracting directory name from empty path."""
        test_path = ""
        result = handler._extract_directory_name(test_path)
        assert result is None

    @patch("lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main")
    def test_extract_directory_name_exception(self, mock_logger, handler):
        """Test error handling in directory name extraction."""
        with patch("os.path.basename", side_effect=Exception("Test error")):
            result = handler._extract_directory_name("/some/path")
            assert result is None
            mock_logger.error.assert_called_once()

    @pytest.mark.parametrize(
        "package_name",
        [
            "lseg_analytics-1.0.0.dist-info",
            "lseg_analytics-2.1.3.dist-info",
            "LSEG_ANALYTICS-1.0.0.DIST-INFO",  # Case insensitive
            "lseg_analytics-1.0.0-beta.dist-info",
        ],
    )
    def test_is_lseg_analytics_package_valid_packages(self, handler, package_name):
        """Test pattern matching for valid LSEG analytics package."""
        assert handler._is_lseg_analytics_package(
            package_name
        ), f"Pattern should match: {package_name}"

    @pytest.mark.parametrize(
        "package_name",
        [
            "other_package-1.0.0.dist-info",
            "lseg_analytics-1.0.0",  # Missing .dist-info
            "lseg_analytics.dist-info",  # Missing version
            "not_lseg-1.0.0.dist-info",
            "lseg_analytics",  # Directory without version
            "lseg_analytics_basic_client-1.0.0.dist-info",  # Different LSEG package
            "",
        ],
    )
    def test_is_lseg_analytics_package_invalid_packages(self, handler, package_name):
        """Test pattern matching for invalid packages."""
        assert not handler._is_lseg_analytics_package(
            package_name
        ), f"Pattern should not match: {package_name}"

    @pytest.mark.parametrize(
        "module_name",
        [
            "lseg_other-1.0.0.dist-info",  # Different LSEG package
            "lseg_analytics",  # Base package directory without .dist-info
            "lseg_analytics_basic_client",  # Client module directory
            "lseg_analytics_basic_client-1.0.0.dist-info",  # Client module with version
            "lseg_analytics_core",  # Core module directory
            "lseg_analytics_core-1.0.0.dist-info",  # Core module with version
            "lseg_analytics_utils",  # Utils module directory
            "lseg_analytics_utils-1.0.0.dist-info",  # Utils module with version
            "lseg_sdk",  # SDK module directory
            "lseg_sdk-1.0.0.dist-info",  # SDK module with version
            "lseg_common",  # Common module directory
            "lseg_common-1.0.0.dist-info",  # Common module with version
        ],
    )
    def test_is_lseg_analytics_package_lseg_wheel_modules_ignored(
        self, handler, module_name
    ):
        """Test that other LSEG modules shipped as part of lseg-analytics wheel are ignored."""
        assert not handler._is_lseg_analytics_package(
            module_name
        ), f"LSEG wheel module should be ignored: {module_name}"

    def test_on_created_matching_directory(self, handler, mock_callback):
        """Test handling directory creation event for matching package."""
        event = DirCreatedEvent("/path/to/lseg_analytics-1.0.0.dist-info")

        with patch(
            "lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main"
        ) as mock_logger:
            handler.on_created(event)

            mock_callback.assert_called_once_with(
                "lseg_analytics-1.0.0.dist-info", EventType.CREATED
            )

    def test_on_created_non_matching_directory(self, handler, mock_callback):
        """Test handling directory creation event for non-matching package."""
        event = DirCreatedEvent("/path/to/other_package-1.0.0.dist-info")

        handler.on_created(event)
        mock_callback.assert_not_called()

    def test_on_created_lseg_analytics_package_not_matching(
        self, handler, mock_callback
    ):
        """Test that lseg_analytics package directories without .dist-info are not processed."""
        event = DirCreatedEvent("/path/to/lseg_analytics")

        handler.on_created(event)
        mock_callback.assert_not_called()

    def test_on_created_lseg_analytics_basic_client_not_matching(
        self, handler, mock_callback
    ):
        """Test that lseg_analytics_basic_client directories are not processed."""
        event = DirCreatedEvent("/path/to/lseg_analytics_basic_client-1.0.0.dist-info")

        handler.on_created(event)
        mock_callback.assert_not_called()

    def test_on_created_file_event(self, handler, mock_callback):
        """Test that file creation events are ignored."""
        # Create a file event (not directory)
        event = Mock()
        event.is_directory = False
        event.src_path = "/path/to/lseg_analytics-1.0.0.dist-info/file.txt"

        handler.on_created(event)

        mock_callback.assert_not_called()

    @pytest.mark.parametrize(
        "module_path",
        [
            "/path/to/lseg_other-1.0.0.dist-info",
            "/path/to/lseg_analytics",
            "/path/to/lseg_analytics_basic_client",
            "/path/to/lseg_analytics_basic_client-1.0.0.dist-info",
            "/path/to/lseg_analytics_core",
            "/path/to/lseg_analytics_core-1.0.0.dist-info",
            "/path/to/lseg_analytics_utils-1.0.0.dist-info",
            "/path/to/lseg_sdk-1.0.0.dist-info",
            "/path/to/lseg_common-1.0.0.dist-info",
        ],
    )
    def test_on_created_lseg_wheel_modules_ignored(
        self, handler, mock_callback, module_path
    ):
        """Test that directory creation events for LSEG wheel modules are ignored."""
        event = DirCreatedEvent(module_path)
        handler.on_created(event)

        # Verify no callback was triggered for this ignored module
        mock_callback.assert_not_called()

    def test_on_modified_matching_directory(self, handler, mock_callback):
        """Test handling directory modification event for matching package."""
        event = DirModifiedEvent("/path/to/lseg_analytics-1.0.0.dist-info")

        with patch.object(
            handler,
            "_extract_directory_name",
            return_value="lseg_analytics-1.0.0.dist-info",
        ), patch.object(
            handler, "_is_lseg_analytics_package", return_value=True
        ), patch(
            "lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main"
        ) as mock_logger:

            handler.on_modified(event)

            mock_callback.assert_called_once_with(
                "lseg_analytics-1.0.0.dist-info", EventType.MODIFIED
            )

    def test_on_deleted_matching_directory(self, handler, mock_callback):
        """Test handling directory deletion event for matching package."""
        event = DirDeletedEvent("/path/to/lseg_analytics-1.0.0.dist-info")

        with patch.object(
            handler,
            "_extract_directory_name",
            return_value="lseg_analytics-1.0.0.dist-info",
        ), patch.object(
            handler, "_is_lseg_analytics_package", return_value=True
        ), patch(
            "lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main"
        ) as mock_logger:

            handler.on_deleted(event)

            mock_callback.assert_called_once_with(
                "lseg_analytics-1.0.0.dist-info", EventType.DELETED
            )

    @patch("lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main")
    def test_handle_file_system_event_exception(
        self, mock_logger, handler, mock_callback
    ):
        """Test error handling in file system event processing."""
        event = DirCreatedEvent("/path/to/lseg_analytics-1.0.0.dist-info")

        with patch.object(
            handler, "_extract_directory_name", side_effect=Exception("Test error")
        ):
            handler._handle_file_system_event(event, "created")

            mock_callback.assert_not_called()
            mock_logger.error.assert_called_once()

    def test_only_main_lseg_analytics_package_triggers_notification(
        self, handler, mock_callback
    ):
        """Test that only the main lseg_analytics package triggers notifications."""
        # This should trigger a notification
        main_package_event = DirCreatedEvent("/path/to/lseg_analytics-1.0.0.dist-info")

        with patch(
            "lseg_analytics_jupyterlab.src.classes.dependencyChangeHandler.logger_main"
        ):
            handler.on_created(main_package_event)

        # Verify main package triggered callback
        mock_callback.assert_called_once_with(
            "lseg_analytics-1.0.0.dist-info", EventType.CREATED
        )

    @pytest.mark.parametrize(
        "sub_module_path",
        [
            "/path/to/lseg_analytics",
            "/path/to/lseg_analytics_basic_client-1.0.0.dist-info",
            "/path/to/lseg_analytics_core-1.0.0.dist-info",
        ],
    )
    def test_lseg_analytics_sub_modules_do_not_trigger_notification(
        self, handler, mock_callback, sub_module_path
    ):
        """Test that lseg_analytics sub-modules do not trigger notifications."""
        event = DirCreatedEvent(sub_module_path)
        handler.on_created(event)

        # Verify no callback was triggered for sub-module
        mock_callback.assert_not_called()

    @pytest.mark.parametrize(
        "module_path",
        [
            "/path/to/lseg_analytics",
            "/path/to/lseg_analytics_basic_client-1.0.0.dist-info",
            "/path/to/lseg_analytics_core-1.0.0.dist-info",
            "/path/to/lseg_sdk-1.0.0.dist-info",
        ],
    )
    def test_on_modified_lseg_wheel_modules_ignored(
        self, handler, mock_callback, module_path
    ):
        """Test that directory modification events for LSEG wheel modules are ignored."""
        event = DirModifiedEvent(module_path)
        handler.on_modified(event)

        # Verify no callback was triggered for this ignored module
        mock_callback.assert_not_called()

    @pytest.mark.parametrize(
        "module_path",
        [
            "/path/to/lseg_analytics_basic_client",
            "/path/to/lseg_analytics_core-1.0.0.dist-info",
            "/path/to/lseg_other-1.0.0.dist-info",
        ],
    )
    def test_on_deleted_lseg_wheel_modules_ignored(
        self, handler, mock_callback, module_path
    ):
        """Test that directory deletion events for LSEG wheel modules are ignored."""
        event = DirDeletedEvent(module_path)
        handler.on_deleted(event)

        # Verify no callback was triggered for this ignored module
        mock_callback.assert_not_called()
