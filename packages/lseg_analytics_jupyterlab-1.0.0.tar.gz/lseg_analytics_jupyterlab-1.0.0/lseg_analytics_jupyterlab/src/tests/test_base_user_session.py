# type: ignore
from lseg_analytics_jupyterlab.src.classes.baseUserSession import BaseUserSession
from lseg_analytics_jupyterlab.src.classes.sessionService import SessionService
import pytest
from unittest.mock import Mock, patch


@pytest.fixture()
def user_session():
    return BaseUserSession(
        "test_id",
        "test_user_id",
        "test_user_name",
        "test_access_token",
        "test_refresh_token",
        "test_expiry_date",
    )


def test_base_user_session(user_session):
    assert user_session.id == "test_id"
    assert user_session.user_id == "test_user_id"
    assert user_session.user_display_name == "test_user_name"
    assert user_session.access_token == "test_access_token"
    assert user_session.refresh_token == "test_refresh_token"
    assert user_session.expiry_date_time_ms == "test_expiry_date"


def test_get_id(user_session):
    user_session.id == user_session._get_id()
