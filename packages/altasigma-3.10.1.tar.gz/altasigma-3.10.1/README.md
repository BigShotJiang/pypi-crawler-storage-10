# AltaSigma Helpers

Source code of the `altasigma` packages

## Development

Use `make requirements` to install all dependencies for development and testing.

**Dependency Management:**
- **`requirements/production.txt`** - Pinned versions for consistent development environments
  - Ensures IDE autocomplete/suggestions work correctly
  - Guarantees reproducible test runs across developers and CI
  - Used by developers and CI for consistent behavior
- **`requirements/development.txt`** - Development tools (pytest, black, isort, security scanners)
- **`setup.py` (install_requires)** - Flexible version ranges for package users
  - Allows users to get compatible versions that work with their other dependencies

**When upgrading dependencies:**
1. Update the pinned version in `requirements/production.txt`
2. Update the version range in `setup.py` install_requires if needed
3. Run tests to ensure compatibility

Use `make format` before committing to format (with black) and sort imports (with isort).

### Tags

Assign tags like [`0.0.4.dev2`](https://peps.python.org/pep-0440/#developmental-releases) (counting the last part up)
for developing a new version based on `0.0.4`. It could release as `0.0.5`, but you don't know.


### R Development Tags

Use tags like `0.0.4-1`, `0.0.4-2`, etc. for R-only development. These:
- Match the R CI regex `/^[0-9]+([.-][0-9]+)+$/` (`.gitlab-ci.yml:173`)
- Are CRAN-compatible (hyphen separator)
- Won't conflict with Python semantic versions
- Python build will create a version like 0.0.4.post1, which would actually be treated as a newer stable version of 0.0.4,
  so be careful with that and just use outdated version tags in the front and ideally delete the package version later

To install a version in the workbench for example, the easiest way may be to download the package and do
`install.packages("/workbench/altasigma_0.0.4-1.tar.gz", repos = NULL, type = "source")` and check with
`packageVersion("altasigma")`

### R Versions
https://cran.r-project.org/doc/manuals/r-release/R-exts.html#:~:text=The%20mandatory%20%E2%80%98Version
> The mandatory 'Version' field gives the version of the package.
> This is a sequence of at least two (and usually three) non-negative integers separated by single '.' or '-' characters.
> The canonical form is as shown in the example, and a version such as '0.01' or '0.01.0' will be handled as if it were '0.1-0'.
> It is not a decimal number, so for example 0.9 < 0.75 since 9 < 75.
