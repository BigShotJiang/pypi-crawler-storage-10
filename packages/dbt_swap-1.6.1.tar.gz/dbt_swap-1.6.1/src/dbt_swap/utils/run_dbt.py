import subprocess
import sys
import signal


def run_dbt(args: list[str]) -> tuple[int, list[str]]:
    """Run a dbt command and capture its output."""
    process = subprocess.Popen(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,  # line-buffered
        preexec_fn=None if sys.platform == "win32" else lambda: signal.signal(signal.SIGINT, signal.SIG_IGN),
    )

    try:
        output_lines = []
        # Stream output line by line
        for line in process.stdout:
            # You can process or log here instead of print
            output_lines.append(line)

        returncode = process.wait()
        return returncode, output_lines

    except KeyboardInterrupt:
        print("\nKeyboardInterrupt received, terminating dbt...")
        process.send_signal(signal.SIGINT)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            print("dbt did not exit gracefully, killing...")
            process.kill()
        sys.exit(130)

    except Exception as e:
        print(f"An error occurred while running dbt: {e}")
        process.kill()
        sys.exit(1)
