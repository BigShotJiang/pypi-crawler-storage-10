"""
EvenAge CLI package.

Production-grade modular CLI with comprehensive testing support.
"""

__version__ = "0.4.6"

from .main import cli, main


__all__ = ["cli", "main"]
