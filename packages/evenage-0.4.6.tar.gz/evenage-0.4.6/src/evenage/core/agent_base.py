"""
Simplified base agent with LLM backend support.

Provides a minimal agent interface without deprecated LangChain patterns.
Uses direct LLM invocation with tool calling support.
"""

from __future__ import annotations

from typing import List, Optional, Any, Protocol
import os
import json


class Tool(Protocol):
    """Protocol for tool objects."""
    name: str
    description: str
    
    def run(self, *args, **kwargs) -> Any:
        """Execute the tool."""
        ...


def _default_model():
    """Return a default LangChain chat model based on env LLM_BACKEND."""
    backend = (os.environ.get("LLM_BACKEND") or "openai").lower()
    
    if backend == "gemini":
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            api_key = os.environ.get("GEMINI_API_KEY")
            return ChatGoogleGenerativeAI(model="gemini-2.0-flash-exp", google_api_key=api_key, temperature=0)
        except Exception:
            pass  # Fall through to echo model
            
    elif backend == "openai":
        try:
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(model="gpt-4o-mini", temperature=0)
        except Exception:
            pass  # Fall through to echo model
    
    # Fallback to a minimal echo-like model (no external dependencies)
    class _EchoModel:
        async def ainvoke(self, inputs: Any):
            if isinstance(inputs, list):
                # Message format
                msg = inputs[-1].get("content", "") if isinstance(inputs[-1], dict) else str(inputs[-1])
            elif isinstance(inputs, dict):
                msg = inputs.get("input", str(inputs))
            else:
                msg = str(inputs)
            return {"output": msg}
        
        def invoke(self, inputs: Any):
            import asyncio
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            return loop.run_until_complete(self.ainvoke(inputs))

    return _EchoModel()


class BaseAgent:
    """
    Simplified base agent with LLM support.
    
    This agent provides a minimal interface for handling tasks with an LLM.
    Tool support is available but simplified compared to full LangChain agents.
    """
    
    def __init__(
        self,
        name: str,
        description: str = "",
        tools: Optional[List[Any]] = None,
        model: Any = None,
        allow_delegation: bool = True,
    ):
        self.name = name
        self.description = description
        self.allow_delegation = allow_delegation
        self.tools: List[Any] = tools or []
        self.model = model or _default_model()

    async def handle(self, task: dict):
        """
        Handle a single task using the LLM.
        
        Args:
            task: Task dictionary with query/message/input
            
        Returns:
            Result dictionary with output
        """
        query = task.get("query") or task.get("message") or task.get("input") or str(task)
        
        # Build context with tool information if available
        context = []
        if self.tools:
            tool_desc = "\n".join([
                f"- {t.name}: {t.description}" 
                for t in self.tools 
                if hasattr(t, 'name') and hasattr(t, 'description')
            ])
            if tool_desc:
                context.append(f"Available tools:\n{tool_desc}")
        
        if context:
            full_query = "\n\n".join(context + [query])
        else:
            full_query = query
        
        # Invoke model
        try:
            result = await self.model.ainvoke({"input": full_query})
            
            # Handle different response formats
            if isinstance(result, dict):
                output = result.get("output") or result.get("content") or str(result)
            elif hasattr(result, "content"):
                output = result.content
            else:
                output = str(result)
                
            return {"output": output}
            
        except Exception as e:
            return {"error": str(e), "output": f"Error processing task: {e}"}

    def bind_tools(self, new_tools: List[Any]):
        """Bind additional tools to the agent."""
        self.tools.extend(new_tools)
