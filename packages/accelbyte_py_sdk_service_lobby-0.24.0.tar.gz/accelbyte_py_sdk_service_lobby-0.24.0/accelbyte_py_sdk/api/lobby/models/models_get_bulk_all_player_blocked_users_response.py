# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: model.j2

# AccelByte Gaming Services Lobby Server

# pylint: disable=duplicate-code
# pylint: disable=line-too-long
# pylint: disable=missing-function-docstring
# pylint: disable=missing-module-docstring
# pylint: disable=too-many-arguments
# pylint: disable=too-many-branches
# pylint: disable=too-many-instance-attributes
# pylint: disable=too-many-lines
# pylint: disable=too-many-locals
# pylint: disable=too-many-public-methods
# pylint: disable=too-many-return-statements
# pylint: disable=too-many-statements
# pylint: disable=unused-import

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union

from accelbyte_py_sdk.core import Model

from ..models.models_blocked_player_data import ModelsBlockedPlayerData


class ModelsGetBulkAllPlayerBlockedUsersResponse(Model):
    """Models get bulk all player blocked users response (models.GetBulkAllPlayerBlockedUsersResponse)

    Properties:
        data: (data) REQUIRED Dict[str, List[ModelsBlockedPlayerData]]
    """

    # region fields

    data: Dict[str, List[ModelsBlockedPlayerData]]  # REQUIRED

    # endregion fields

    # region with_x methods

    def with_data(
        self, value: Dict[str, List[ModelsBlockedPlayerData]]
    ) -> ModelsGetBulkAllPlayerBlockedUsersResponse:
        self.data = value
        return self

    # endregion with_x methods

    # region to methods

    def to_dict(self, include_empty: bool = False) -> dict:
        result: dict = {}
        if hasattr(self, "data"):
            result["data"] = {
                str(k0): [i1.to_dict(include_empty=include_empty) for i1 in v0]
                for k0, v0 in self.data.items()
            }
        elif include_empty:
            result["data"] = {}
        return result

    # endregion to methods

    # region static methods

    @classmethod
    def create(
        cls, data: Dict[str, List[ModelsBlockedPlayerData]], **kwargs
    ) -> ModelsGetBulkAllPlayerBlockedUsersResponse:
        instance = cls()
        instance.data = data
        return instance

    @classmethod
    def create_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> ModelsGetBulkAllPlayerBlockedUsersResponse:
        instance = cls()
        if not dict_:
            return instance
        if "data" in dict_ and dict_["data"] is not None:
            instance.data = {
                str(k0): [
                    ModelsBlockedPlayerData.create_from_dict(
                        i1, include_empty=include_empty
                    )
                    for i1 in v0
                ]
                for k0, v0 in dict_["data"].items()
            }
        elif include_empty:
            instance.data = {}
        return instance

    @classmethod
    def create_many_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> Dict[str, ModelsGetBulkAllPlayerBlockedUsersResponse]:
        return (
            {k: cls.create_from_dict(v, include_empty=include_empty) for k, v in dict_}
            if dict_
            else {}
        )

    @classmethod
    def create_many_from_list(
        cls, list_: list, include_empty: bool = False
    ) -> List[ModelsGetBulkAllPlayerBlockedUsersResponse]:
        return (
            [cls.create_from_dict(i, include_empty=include_empty) for i in list_]
            if list_
            else []
        )

    @classmethod
    def create_from_any(
        cls, any_: any, include_empty: bool = False, many: bool = False
    ) -> Union[
        ModelsGetBulkAllPlayerBlockedUsersResponse,
        List[ModelsGetBulkAllPlayerBlockedUsersResponse],
        Dict[Any, ModelsGetBulkAllPlayerBlockedUsersResponse],
    ]:
        if many:
            if isinstance(any_, dict):
                return cls.create_many_from_dict(any_, include_empty=include_empty)
            elif isinstance(any_, list):
                return cls.create_many_from_list(any_, include_empty=include_empty)
            else:
                raise ValueError()
        else:
            return cls.create_from_dict(any_, include_empty=include_empty)

    @staticmethod
    def get_field_info() -> Dict[str, str]:
        return {
            "data": "data",
        }

    @staticmethod
    def get_required_map() -> Dict[str, bool]:
        return {
            "data": True,
        }

    # endregion static methods
