import base64
import hashlib
import json
import os
import platform
import sys
import time
import zipfile

import requests

from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from MediCafe.MediLink_ConfigLoader import load_configuration, log as mc_log
from MediLink.MediLink_Gmail import get_access_token

ASCII_SAFE_REPLACEMENTS = [
	('"', '"'),
	("'", "'"),
]


def _safe_ascii(text):
	try:
		if text is None:
			return ''
		if isinstance(text, bytes):
			try:
				text = text.decode('ascii', 'ignore')
			except Exception:
				text = text.decode('utf-8', 'ignore')
		else:
			text = str(text)
		return text.encode('ascii', 'ignore').decode('ascii', 'ignore')
	except Exception:
		return ''


def _tail_file(path, max_lines):
	lines = []
	try:
		with open(path, 'r') as f:
			for line in f:
				lines.append(line)
				if len(lines) > max_lines:
					lines.pop(0)
		return ''.join(lines)
	except Exception:
		return ''


def _get_latest_log_path(local_storage_path):
	try:
		files = []
		for name in os.listdir(local_storage_path or '.'):
			if name.startswith('Log_') and name.endswith('.log'):
				files.append(os.path.join(local_storage_path, name))
		if not files:
			return None
		files.sort(key=lambda p: os.path.getmtime(p))
		return files[-1]
	except Exception:
		return None


def _redact(text):
	# Best-effort ASCII redaction: mask obvious numeric IDs and bearer tokens
	try:
		text = _safe_ascii(text)
		import re
		patterns = [
			(r'\b(\d{3}-?\d{2}-?\d{4})\b', '***-**-****'),
			(r'\b(\d{9,11})\b', '*********'),
			(r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer ***'),
			(r'Authorization:\s*[^\n\r]+', 'Authorization: ***'),
		]
		for pat, rep in patterns:
			text = re.sub(pat, rep, text)
		return text
	except Exception:
		return text


def _ensure_dir(path):
	try:
		if not os.path.exists(path):
			os.makedirs(path)
		return True
	except Exception:
		return False


def _compute_report_id(zip_path):
	try:
		h = hashlib.sha256()
		with open(zip_path, 'rb') as f:
			chunk = f.read(256 * 1024)
			h.update(chunk)
		return 'mc-{}-{}'.format(int(time.time()), h.hexdigest()[:12])
	except Exception:
		return 'mc-{}-{}'.format(int(time.time()), '000000000000')


def collect_support_bundle(include_traceback=True, max_log_lines=500):
	config, _ = load_configuration()
	medi = config.get('MediLink_Config', {})
	local_storage_path = medi.get('local_storage_path', '.')
	queue_dir = os.path.join(local_storage_path, 'reports_queue')
	_ensure_dir(queue_dir)

	stamp = time.strftime('%Y%m%d_%H%M%S')
	bundle_name = 'support_report_{}.zip'.format(stamp)
	zip_path = os.path.join(queue_dir, bundle_name)

	latest_log = _get_latest_log_path(local_storage_path)
	log_tail = _tail_file(latest_log, max_log_lines) if latest_log else ''
	log_tail = _redact(log_tail)

	traceback_txt = ''
	if include_traceback:
		try:
			trace_path = os.path.join(local_storage_path, 'traceback.txt')
			if os.path.exists(trace_path):
				with open(trace_path, 'r') as tf:
					traceback_txt = _redact(tf.read())
		except Exception:
			traceback_txt = ''

	meta = {
		'app_version': _safe_ascii(_get_version()),
		'python_version': _safe_ascii(sys.version.split(' ')[0]),
		'platform': _safe_ascii(platform.platform()),
		'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
		'error_summary': _safe_ascii(_first_line(traceback_txt)),
		'traceback_present': bool(traceback_txt),
		'config_flags': {
			'console_logging': bool(medi.get('logging', {}).get('console_output', False)),
			'test_mode': bool(medi.get('TestMode', False))
		}
	}

	try:
		with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
			z.writestr('meta.json', json.dumps(meta, ensure_ascii=True, indent=2))
			if latest_log and log_tail:
				z.writestr('log_tail.txt', log_tail)
			if traceback_txt:
				z.writestr('traceback.txt', traceback_txt)
			# Get latest WinSCP log
			upload_log = os.path.join(local_storage_path, 'winscp_upload.log')
			download_log = os.path.join(local_storage_path, 'winscp_download.log')
			winscp_logs = [(p, os.path.getmtime(p)) for p in [upload_log, download_log] if os.path.exists(p)]
			if winscp_logs:
				latest_winscp = max(winscp_logs, key=lambda x: x[1])[0]
				winscp_tail = _tail_file(latest_winscp, max_log_lines) if latest_winscp else ''
				winscp_tail = _redact(winscp_tail)
			else:
				winscp_tail = ''
			if winscp_tail:
				z.writestr('winscp_log_tail.txt', winscp_tail)
	except Exception as e:
		mc_log('Error creating support bundle: {}'.format(e), level='ERROR')
		return None

	bundle_size = os.path.getsize(zip_path)
	if bundle_size > 1572864:
		os.remove(zip_path)
		mc_log('Bundle too large ({} bytes) - discarded'.format(bundle_size), level='WARNING')
		return None
	return zip_path


def _first_line(text):
	try:
		for line in (text or '').splitlines():
			line = line.strip()
			if line:
				return line[:200]
		return ''
	except Exception:
		return ''


def _get_version():
	try:
		from MediCafe import __version__
		return __version__
	except Exception:
		return 'unknown'


def capture_unhandled_traceback(exc_type, exc_value, exc_traceback):
	try:
		config, _ = load_configuration()
		medi = config.get('MediLink_Config', {})
		local_storage_path = medi.get('local_storage_path', '.')
		trace_path = os.path.join(local_storage_path, 'traceback.txt')
		import traceback
		text = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
		text = _redact(text)
		with open(trace_path, 'w') as f:
			f.write(text)
		print("An error occurred. A traceback was saved to {}".format(trace_path))
	except Exception:
		pass

def submit_support_bundle_email(zip_path=None, include_traceback=True):
    if not zip_path:
        zip_path = collect_support_bundle(include_traceback)
        if not zip_path:
            mc_log("Failed to create bundle.", level="ERROR")
            return False
    bundle_size = os.path.getsize(zip_path)
    if bundle_size > 1572864:
        mc_log("Bundle too large ({} bytes) - discarding.".format(bundle_size), level="WARNING")
        os.remove(zip_path)
        return False
    config, _ = load_configuration()
    email_config = config.get('MediLink_Config', {}).get('error_reporting', {}).get('email', {})
    if not email_config.get('enabled', False):
        mc_log("Email reporting disabled.", level="INFO")
        return False
    to_emails = email_config.get('to', [])
    subject_prefix = email_config.get('subject_prefix', 'MediCafe Error Report')
    access_token = get_access_token()
    if not access_token:
        mc_log("No access token - authenticate first.", level="ERROR")
        return False
    mc_log("Building email...", level="INFO")
    msg = MIMEMultipart()
    msg['To'] = ', '.join(to_emails)
    msg['Subject'] = '{} - {}'.format(subject_prefix, time.strftime('%Y%m%d_%H%M%S'))
    with open(zip_path, 'rb') as f:
        attach = MIMEApplication(f.read(), _subtype='zip')
        attach.add_header('Content-Disposition', 'attachment', filename=os.path.basename(zip_path))
        msg.attach(attach)
    body = "Error report attached."
    msg.attach(MIMEText(body, 'plain'))
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    mc_log("Sending report...", level="INFO")
    headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
    data = {'raw': raw}
    resp = requests.post('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', headers=headers, json=data)
    if resp.status_code == 200:
        mc_log("Report sent successfully!", level="INFO")
        os.remove(zip_path)
        return True
    else:
        mc_log("Failed to send: {} - {}".format(resp.status_code, resp.text), level="ERROR")
        return False

def email_error_report_flow():
    try:
        sent = submit_support_bundle_email(zip_path=None, include_traceback=True)
        return 0 if sent else 1
    except Exception as e:
        mc_log("[ERROR] Exception during email report flow: {0}".format(e), level="ERROR")
        return 1

if __name__ == "__main__":
    raise SystemExit(email_error_report_flow())

