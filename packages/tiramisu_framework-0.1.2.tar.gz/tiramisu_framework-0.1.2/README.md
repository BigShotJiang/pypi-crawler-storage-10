# 🍰 Tiramisu Framework

AI-powered marketing consultancy framework using RAG (Retrieval-Augmented Generation) technology with strategic marketing knowledge.

## 📦 Installation
```bash
pip install tiramisu-framework
```

## 🚀 Quick Start
```python
from tiramisu_framework.engine.analyzer import TiramisuAnalyzer
from tiramisu_framework.models.schemas import AnalysisType

# Initialize analyzer
analyzer = TiramisuAnalyzer()

# Analyze content
result = analyzer.analyze(
    content="Your marketing content here",
    analysis_type=AnalysisType.SOCIAL_MEDIA_POST,
    context="Additional context"
)

print(result.summary)
```

## ⚠️ Important: Data Setup

This framework requires marketing knowledge data to function. 

### Setup Your Knowledge Base

1. Add your marketing PDFs/documents to `data/` folder
2. Run the indexing script to create FAISS vectors
3. The system will use your custom knowledge base

**Note:** This framework is designed to work with any marketing literature. Users must provide their own knowledge sources in compliance with copyright laws.

## 🏗️ Architecture

- **FastAPI** backend with RESTful API
- **RAG System** with FAISS vector store
- **GPT Integration** for intelligent analysis
- **SQLite** for conversation management
- **Pydantic** for data validation

## 📚 Features

- 8 types of marketing analysis
- Conversation context management
- Three Trees analysis framework (Roots, Trunk, Branches)
- Multi-perspective expert insights (Strategic, Execution, Technology)
- Structured JSON responses

## 🛠️ Development
```bash
# Clone repository
git clone https://github.com/tiramisu-framework/tiramisu-framework.git
cd tiramisu-framework

# Install dependencies
pip install -r requirements.txt

# Run API
python -m uvicorn api.main:app --reload
```

## ⚖️ Legal Disclaimer

This framework is a technical tool for marketing analysis. Users are responsible for:
- Providing their own knowledge sources
- Ensuring compliance with copyright laws
- Obtaining necessary permissions for any copyrighted materials used

## 📄 License

MIT License - See LICENSE file for details

## 👨‍💻 Author

Developed by Jony Wolff with Claude AI assistance

## 🤝 Contributing

Contributions welcome! Please open an issue or submit a PR.

## 📚 Setting Up Your Knowledge Base

**Important:** This framework does not include pre-loaded content. You must provide your own marketing knowledge sources.

### Steps:

1. **Add Your Documents:**
```bash
   mkdir -p data/sources
   # Add your PDF/TXT files to data/sources/
```

2. **Index Your Content:**
```bash
   python -m tiramisu_framework.scripts.index_documents
```

3. **Configure API Key:**
```bash
   export OPENAI_API_KEY="your-key-here"
```

### Recommended Sources:
- Marketing strategy books and articles
- Digital marketing guides
- Industry reports and case studies
- Your own proprietary content

**Note:** Ensure you have rights to use any content you add to the framework.
