from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime

class AnalysisType(str, Enum):
    SOCIAL_MEDIA_POST = "social_media_post"
    EMAIL_MARKETING = "email_marketing"
    LANDING_PAGE = "landing_page"
    AD_COPY = "ad_copy"
    STRATEGY = "strategy"
    PITCH = "pitch"
    VIDEO_SCRIPT = "video_script"
    OTHER = "other"

class TriadeInsights(BaseModel):
    strategic: str = Field(..., description="Strategic marketing perspective")
    execution: str = Field(..., description="Practical execution viewpoint")
    technology: str = Field(..., description="Digital transformation insights")

class TreesAnalysis(BaseModel):
    roots: str = Field(..., description="Root causes and fundamentals")
    trunk: str = Field(..., description="Current execution and strategy")
    branches: str = Field(..., description="Proposed improvements")

class Proposal(BaseModel):
    strategy: str
    segmentation: str
    channels: str
    smart_goals: str
    kpis: str
    timeline: str
    budget: str
    plan_80_20: str

class AnalysisResult(BaseModel):
    summary: str
    trees: TreesAnalysis
    triade: TriadeInsights
    proposal: Proposal
    rag_sources: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.now)
    
    class Config:
        json_schema_extra = {
            "example": {
                "summary": "Complete analysis",
                "trees": {
                    "roots": "Core diagnosis",
                    "trunk": "Current state",
                    "branches": "Recommendations"
                },
                "triade": {
                    "strategic": "Strategic perspective",
                    "execution": "Execution viewpoint",
                    "technology": "Tech insights"
                },
                "proposal": {
                    "strategy": "Proposed strategy",
                    "segmentation": "Target segments",
                    "channels": "Distribution channels",
                    "smart_goals": "SMART objectives",
                    "kpis": "Key metrics",
                    "timeline": "12-week plan",
                    "budget": "Budget allocation",
                    "plan_80_20": "80/20 prioritization"
                },
                "rag_sources": ["Marketing Strategy Handbook", "Digital Execution Guide"],
                "timestamp": "2024-01-01T00:00:00"
            }
        }

class AnalysisRequest(BaseModel):
    content: str = Field(..., min_length=10, description="Content to analyze")
    analysis_type: AnalysisType = Field(default=AnalysisType.OTHER)
    context: Optional[str] = Field(None, description="Additional context")

class ConversationMessage(BaseModel):
    role: str
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)

class ConversationRequest(BaseModel):
    conversation_id: str
    message: str
    context: Optional[str] = None
