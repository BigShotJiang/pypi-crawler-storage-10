"""LogBull test suite."""
