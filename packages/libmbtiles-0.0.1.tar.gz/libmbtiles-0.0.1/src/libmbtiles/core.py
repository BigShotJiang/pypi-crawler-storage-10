import numpy as np


def cat(arr1, arr2):
    return np.concatenate([arr1, arr2])
