"""Claudy - Universal Claude agent manager.

Claudy provides a simple way to manage persistent Claude agent sessions
with CLI, HTTP API, and MCP integration.
"""

__version__ = "0.1.0"
__author__ = "Kang Jihyeok"
__all__ = ["__version__"]
