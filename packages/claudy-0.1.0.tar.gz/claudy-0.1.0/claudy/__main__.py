"""Allow claudy to be run as a module with `python -m claudy`."""

from .cli import main

if __name__ == "__main__":
    main()
