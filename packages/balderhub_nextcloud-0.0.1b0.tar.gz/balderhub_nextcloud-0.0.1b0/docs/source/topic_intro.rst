Introduction into NextCloud
***************************

.. todo provide an explanation of your specific topic that can help others to use your BalderHub project