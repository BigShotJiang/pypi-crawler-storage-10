from balderhub.html.lib.utils import components as html


class ModalVideo(html.HtmlDivElement):
    """
    modal that shows the welcome video
    """
