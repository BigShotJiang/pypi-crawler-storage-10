from .is_nextcloud_server import IsNextcloudServer

class IsNextcloudV30Server(IsNextcloudServer):
    """
    specific nextcloud server feature specially for version v30
    """
