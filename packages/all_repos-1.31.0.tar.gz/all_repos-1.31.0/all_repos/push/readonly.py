from __future__ import annotations

import collections

Settings = collections.namedtuple('Settings', ())


def push(settings: Settings, branch_name: str) -> None:
    return None
