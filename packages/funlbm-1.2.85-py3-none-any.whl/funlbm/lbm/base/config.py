import json
from typing import List, Optional, Union

import torch

from funlbm.config.base import BaseConfig
from funlbm.file import FileConfig
from funlbm.flow import FlowConfig
from funlbm.particle import ParticleConfig
from funlbm.util import set_cpu, get_available_device
from importlib.metadata import version
from funutil import getLogger


logger = getLogger("funlbm")


class Config(BaseConfig):
    def __init__(
        self,
        config_path=None,
        dx=1.0,
        dt=1.0,
        dn=2,
        max_step=10000,
        device: torch.device = torch.device("cpu"),
        file=None,
        flow=None,
        particles: Optional[List[ParticleConfig]] = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.dt: float = dt
        self.dx: float = dx
        self.dn: int = dn
        self.max_step: int = max_step
        self.device: torch.device = get_available_device(device)
        self.file_config = FileConfig(**file)
        self.flow_config = FlowConfig(**flow)
        self.particles: List[ParticleConfig] = [
            ParticleConfig(**config) for config in particles or []
        ]
        self.config_path = config_path or "./config.json"

    @staticmethod
    def load_config(path: Optional[str] = "./config.json", *args, **kwargs) -> "Config":
        """从JSON文件加载配置

        Args:
            path: JSON配置文件路径

        Returns:
            self: 返回自身以支持链式调用
        """
        with open(path) as f:
            kwargs = {"config_path": path}
            kwargs.update(json.load(f))
            return Config(**kwargs)


def meta_info(config: Config):
    particle_info = "\n#  ".join(
        [
            f"颗粒{str(i + 1).rjust(6)}: {par.to_str()}"
            for i, par in enumerate(config.particles)
        ]
    )
    message = f"""
欢迎使用funlbm
正在运行的版本是v({version("funlbm")})
CPU核数    {set_cpu()}
运行设备    {config.device}
dx         {config.dx}
dt         {config.dt}
网格大小    {[int(i) for i in config.flow_config.size]}
颗粒数      {len(config.particles)}
颗粒信息\n{particle_info}
更多信息请访问 https://github.com/farfarfun/funlbm
"""
    lines = message.strip("\n").split("\n")
    max_len = max([len(i) for i in lines]) * 2
    message_list = ["", "#" * max_len]
    for line in lines:
        message_list.append("###### " + line)
    message_list.append("#" * max_len)
    logger.success("\n".join(message_list))


def create_lbm_config(
    config: Optional[Union[Config, str]] = None,
    path: Optional[str] = "./config.json",
    *args,
    **kwargs,
) -> Optional[Config]:
    result_config: Optional[Config] = None
    if config is None:
        raise ValueError("config is None")
    elif isinstance(config, Config):
        result_config = config
    elif isinstance(config, str):
        result_config = Config.load_config(path, *args, **kwargs)
    meta_info(result_config)
    return result_config
