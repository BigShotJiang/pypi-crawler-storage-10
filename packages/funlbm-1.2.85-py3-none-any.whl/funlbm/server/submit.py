import os
import shutil
from datetime import datetime

import typer
from funbuild.shell import run_shell
from funutil import getLogger

from .base import funlbm_cli

logger = getLogger("funlbm")


def create_slurm(
    target_file: str = "./config.slurm", task_name: str = "funlbm", core: int = 64
) -> bool:
    if shutil.which("sbatch") is None:
        return False
    content = f"""
#!/bin/bash
#SBATCH -J {task_name}
#SBATCH -p xhhctdnormal
#SBATCH -N 1
#SBATCH --ntasks-per-node={core}
##SBATCH --mem-per-cpu=1

module purge

~/farfarfun/.venv/bin/funlbm run
    """
    content = content.strip("\n")
    with open(target_file, "w") as fw:
        fw.write(content)
    logger.success(f"created {target_file} successfully.")
    return True


@funlbm_cli.command()
def submit(
    config=typer.Option("./config.json", help="配置文件地址"),
    core=typer.Option(8, help="运行核数"),
):
    task_name: str = os.path.basename(config)
    task_name = task_name.lstrip("config").lstrip("-")
    task_name = task_name.rstrip(".json")
    if len(task_name) < 10:
        task_name = input("请输入任务名字，默认为funlbm:\n")
        task_name = task_name or "funlbm"

    logger.info(f"task_name: {task_name}")
    task_dir = os.path.join(
        os.path.expanduser("~"), "workbench", datetime.now().strftime("%Y%m%d%H%M%S")
    )
    logger.info(f"任务主目录：{task_dir}")
    os.makedirs(task_dir, exist_ok=True)

    logger.info(f"复制文件到任务主目录：{task_dir}")
    # run_shell(f"cp -r *.cpp *.h *.sh *.slurm *.f90 *.dat *.json {task_dir} 2>/dev/null")
    # logger.success(f"复制文件到任务主目录：{task_dir}完成")

    if not os.path.exists(config):
        logger.error(f"{config} not exists, return.")
        return

    run_shell(f"cp {config} {task_dir}/config.json 2>/dev/null")
    logger.success(f"复制文件到任务主目录：{config} -> {task_dir}/config.json.")

    if create_slurm(f"{task_dir}/config.slurm", task_name, core=core):
        logger.info("检测到sbatch命令，提交到算力平台")
        run_shell(f"cd {task_dir} && sbatch config.slurm")
        return

    if os.path.exists(config):
        logger.info("本地运行")
        run_shell(f"""cd {task_dir} && nohup funlbm run > output.log 2>&1 &""")
        return

    logger.error("找不到需要提交的任务")
