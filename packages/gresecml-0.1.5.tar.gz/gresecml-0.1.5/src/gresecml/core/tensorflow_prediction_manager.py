def tensorflow_predict(model_path: str, input_data: dict) -> dict[str, float]:
    """Make predictions using a TensorFlow model and input data.
    
    Args:
        model_path (str): Path to the TensorFlow model file.
        input_data (dict): Input data for making predictions.
    
    Returns:
        dict[str, float]: Dictionary of predictions made by the model. prediction_normal and prediction_portscan
    """
    import tensorflow as tf
    import keras

    try:
        tf_model = keras.models.load_model(model_path)
    except Exception:
        raise RuntimeError("Failed to load TensorFlow model.")

    # Convert input data to tensors
    input_dict = {name: tf.convert_to_tensor([value]) for name, value in input_data.items()}

    # Make predictions
    try:
        preds = tf_model(input_dict)
    except Exception:
        raise RuntimeError("Failed to make predictions with the TensorFlow model.")
    
    try:
        # Update output dictionary if more categories are added in the future
        output_dict = {
            "prediction_normal": float(preds[0][0]),
            "prediction_portscan": float(preds[0][1]),
        }
    except Exception:
        raise RuntimeError("Failed to process predictions from the TensorFlow model.")

    return output_dict