import requests
from bs4 import BeautifulSoup
from typing import Optional
import json
from .types.server import Server


class Client():
    def __init__(self, ROBLOSECURITY):
        self.x_csrf_token = None
        self.ROBLOSECURITY = ROBLOSECURITY
        self.servers = []

    def get(self, servers: Optional[list] = None):
        response = requests.get("https://www.roblox.com/home", 
            cookies= {
                ".ROBLOSECURITY": self.ROBLOSECURITY
            })

        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')

            csrf_token = soup.find('meta', attrs={'data-token': True})
            
            if csrf_token:
                csrf_token = csrf_token.get("data-token")
                self.x_csrf_token = csrf_token

            if servers != None:
                for server in servers:
                    resp = requests.get(
                        url=f"https://games.roblox.com/v1/vip-servers/{server}",
                        headers={ "X-CSRF-Token": self.x_csrf_token },
                        cookies= {
                            ".ROBLOSECURITY": self.ROBLOSECURITY
                        }
                    )
                    self.servers.append(Server(json.loads(resp.text)))

            else:
                print("❌ CSRF-токен не найден на странице")
                return
        else:
            print(f"❌ Ошибка при получении страницы: {response.status_code}")
            return
        
        return self

    def set_server_status(self, server: Server, status: bool, join_link: Optional[bool] = False):
        if status == False and join_link == True:
            print("Нельзя получить ссылку на выключенно сервере! Исправьте значение join_link на False")
            return

        if not self.x_csrf_token:
            print("❌ CSRF-токен не установлен. Сначала вызовите метод get()")
            return

        headers = {
            "X-CSRF-Token": self.x_csrf_token,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        data = {
            "active": status,
            "newJoinCode": join_link
        }

        response = requests.patch(
            url=f"https://games.roblox.com/v1/vip-servers/{server.id}",
            json=data,
            headers=headers,
            cookies= {
                ".ROBLOSECURITY": self.ROBLOSECURITY
            }
        )

        if status == False:
            data["link"] = ""
            data["joinCode"] = None

        return data