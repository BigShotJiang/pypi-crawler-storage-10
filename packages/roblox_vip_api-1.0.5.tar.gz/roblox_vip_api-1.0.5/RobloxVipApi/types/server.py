import requests
import json
from typing import Optional, List

class Server():
    def __init__(self, server: dict):
        self.id = server['id']
        self.name = server['name']
        self.place = server['game']['rootPlace']
        self.status = server['active']
        self.subscription = server['subscription']
        self.permissions = server['permissions']
        self.voiceSettings = server['voiceSettings']
        self.link = server['link']

    def get_players(self, client, get_avatar: Optional[bool] = False):
        resp = requests.get(
            url=f"https://games.roblox.com/v1/games/{self.place['id']}/private-servers",
            headers={"X-CSRF-Token": client.x_csrf_token},
            cookies={".ROBLOSECURITY": client.ROBLOSECURITY}
        )

        result = None

        for server in json.loads(resp.text)['data']:
            if server['vipServerId'] == self.id:
                result = server['players']
                
                if get_avatar == True and result:
                    jsonReq = []
                    for user in result:
                        jsonReq.append({
                            "requestId": f"{user['id']}::AvatarHeadshot:150x150:webp:regular:",
                            "type": "AvatarHeadShot",
                            "targetId": user['id'],
                            "token": "",
                            "format": "webp",
                            "size": "150x150",
                            "version": ""
                        })

                    getUserAvatar = requests.post(
                        url="https://thumbnails.roblox.com/v1/batch",
                        headers={"X-CSRF-Token": client.x_csrf_token},
                        json=jsonReq,
                        cookies={".ROBLOSECURITY": client.ROBLOSECURITY}
                    )
                    
                    # Получаем данные из поля "data"
                    avatars_response = json.loads(getUserAvatar.text)
                    avatars_data = avatars_response.get('data', [])
                    
                    # Создаем словарь для быстрого поиска аватаров по ID
                    avatars_dict = {}
                    for avatar in avatars_data:
                        if avatar.get('errorCode') == 0:  # Проверяем что нет ошибок
                            avatars_dict[avatar['targetId']] = avatar['imageUrl']
                    
                    # Добавляем аватары пользователям
                    for user in result:
                        user_id = user['id']
                        if user_id in avatars_dict:
                            user['avatar'] = avatars_dict[user_id]
                        else:
                            user['avatar'] = None  # или значение по умолчанию

        print(result)
        return result