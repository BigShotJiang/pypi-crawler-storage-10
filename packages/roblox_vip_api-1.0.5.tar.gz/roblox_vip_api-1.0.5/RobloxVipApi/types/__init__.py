"""
Types for Roblox VIP API
"""

from .server import Server

__all__ = ["Server"]