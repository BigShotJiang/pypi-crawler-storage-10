"""
Roblox VIP API - Python wrapper for Roblox VIP servers management
"""

from .сlient import Client
from .types.server import Server

__version__ = "1.0.0"
__all__ = ["Client", "Server"]