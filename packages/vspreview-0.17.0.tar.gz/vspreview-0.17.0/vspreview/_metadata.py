"""Previewer for VapourSynth scripts"""

__version__ = '0.17.0'

__author_name__, __author_email__ = 'Endilll', ''
__maintainer_name__, __maintainer_email__ = 'Setsugen no ao', 'setsugen@setsugen.dev'

__author__ = f'{__author_name__} <{__author_email__}>'
__maintainer__ = __author__

if __name__ == '__github__':
    print(__version__)
