"""
Wrap FastAPI app in FlaskWebGUI for desktop application.
Use `Paw Request fork <https://github.com/pawrequest/flaskwebgui>`_ for URL_SUFFIX to dynamically set loading page to the retrieved record
"""

import argparse
import asyncio
import os
from pathlib import Path

import dotenv
from loguru import logger

from amship.models.commence_adaptors import CategoryName


def shipper_cli():
    args = parse_ship_args()
    logger.info(f'starting shipper for {args.category} {args.record_name} with env {args.shipaw_env}')
    os.environ['SHIPAW_ENV'] = str(args.shipaw_env)
    dotenv.load_dotenv(args.shipaw_env)
    from amship.ui_runner import pycommence_shipper  # AFTER SETTING ENVIRONMENT

    asyncio.run(pycommence_shipper(args.category, args.record_name))


def parse_ship_args():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('category', type=CategoryName, choices=list(CategoryName))
    arg_parser.add_argument('record_name', type=str)
    arg_parser.add_argument('shipaw_env', type=Path)
    args = arg_parser.parse_args()
    return args

