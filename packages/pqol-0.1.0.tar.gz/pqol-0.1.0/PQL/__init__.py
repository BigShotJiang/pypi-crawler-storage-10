from .logic import logic

__all__ = ['logic']
__version__ = '0.1.0'
