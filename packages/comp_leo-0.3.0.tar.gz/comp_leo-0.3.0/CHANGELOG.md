# Changelog

All notable changes to Comp-LEO SDK will be documented in this file.

## [0.3.0] - 2025-01-27

### Added - 💳 PCI-DSS Compliance Support
- 🏦 **PCI-DSS Basic Policy Pack** - 7 essential payment security checks
- 🔍 **Payment Function Detection** - Automatic identification of payment/DeFi operations
- 🚫 **Forbidden Data Detection** - Flags CVV, PIN, and other sensitive data (PCI 3.2)
- 🔒 **Cardholder Data Protection** - Ensures private visibility for payment data (PCI 3.4)
- ✅ **Input Validation Checks** - Verifies payment amount validation (PCI 6.5.1)
- 🔐 **Access Control Verification** - Checks caller authorization (PCI 7.1)
- 📝 **Audit Logging Checks** - Ensures transaction logging via finalize (PCI 10.2)
- 📊 **Transaction Limits** - Verifies MAX_AMOUNT constants defined (PCI 11.3.4)
- ↩️ **Refund Mechanism Check** - Ensures dispute resolution capability (PCI 12.10.6)
- 📋 **Hardcoded Credential Detection** - Finds potential card numbers in source
- 📖 **PCI-DSS Compliance Guide** - 100+ page comprehensive guide (PCI_DSS_GUIDE.md)
- 📚 **Payment Module Documentation** - API docs and best practices
- ✅ **Example Contracts** - Compliant and non-compliant payment contract examples
- 🧪 **PCI Test Suite** - 40+ unit tests for payment compliance rules

### Changed
- 📦 Bumped version to 0.3.0
- 📝 Updated README with PCI-DSS features
- 🏗️ Added `comp_leo/payments/` module structure
- 📋 Updated policy pack table with pci-dss-basic

### Files Added
- `comp_leo/payments/__init__.py` - Payment compliance module
- `comp_leo/payments/pci_rules.py` - PCI-DSS rule implementations
- `comp_leo/payments/README.md` - Payment module documentation
- `comp_leo/policies/pci-dss-basic.json` - PCI-DSS policy pack
- `examples/payment_contract_compliant.leo` - ✅ Compliant example
- `examples/payment_contract_bad.leo` - ❌ Non-compliant example
- `tests/test_pci_compliance.py` - PCI compliance test suite
- `PCI_DSS_GUIDE.md` - Complete PCI-DSS compliance guide

### Technical Details
- 7 new check functions in ComplianceChecker:
  - `_check_pci_3_2_forbidden_data()`
  - `_check_pci_3_4_cardholder_data_protection()`
  - `_check_pci_6_5_1_payment_input_validation()`
  - `_check_pci_7_1_payment_access_control()`
  - `_check_pci_10_2_payment_audit_logging()`
  - `_check_pci_11_3_4_transaction_limits()`
  - `_check_pci_12_10_6_refund_mechanism()`

### Usage
```bash
# Check payment contract for PCI compliance
comp-leo check payment.leo --policy pci-dss-basic

# Generate PCI compliance report
comp-leo report defi_app/ --policy pci-dss-basic --format html
```

## [0.1.2] - 2025-10-27

### Fixed
- 🐛 Fixed `NameError: name 'Style' is not defined` when questionary not installed
- 🔧 Moved `custom_style` definition inside try-except block
- ✅ Interactive mode now gracefully falls back to classic mode if questionary missing

## [0.1.1] - 2025-10-27

### Added
- 🎨 **Interactive Menu Mode** - Beautiful TUI with questionary for menu-based navigation
- 📁 **Auto File Discovery** - Automatically scans for Leo files in current and parent directories
- 🎯 **Quick Check Menu** - One-click access to recently scanned Leo files
- 🔄 **Rescan Feature** - Refresh Leo file list without restarting
- 📋 **Dynamic Menus** - Context-aware options (e.g., export only shows after checks)
- 🎨 **ASCII Banner** - Beautiful gradient COMP-LEO branding
- 📦 **Optional Dependencies** - `[interactive]`, `[watch]`, `[all]` install options
- 🛠️ **CI Generator** - `comp-leo init-ci` generates GitHub Actions, GitLab CI, pre-commit hooks
- 📊 **Enhanced Formatters** - Added `format_report()` function for all export formats
- 📝 **WHY_LOCAL.md** - Comprehensive doc on privacy and decentralization philosophy

### Changed
- 🎨 Updated CLI to show banner by default
- 📋 Improved `comp-leo --help` output with better organization
- 🔧 Interactive mode now supports both menu (`--interactive`) and classic (`--classic`) modes
- 📊 Better error handling and user feedback throughout

### Fixed
- 🐛 Fixed missing `format_report` import error
- 🔧 Improved relative path handling in file browser
- 📁 Better directory traversal for Leo file discovery

## [0.1.0] - 2025-10-27

### Added
- 🚀 Initial release
- 🔍 Leo parser with regex-based AST extraction
- 🛡️ 10+ security and compliance rules (aleo-baseline policy)
- 📊 Smart scoring algorithm (0-100 scale)
- 🎨 Beautiful CLI with rich formatting
- 📈 Multiple export formats (JSON, HTML, Markdown)
- 🤖 CI/CD integration examples
- 🔒 100% local analysis (zero network calls)
- ⚡ Fast performance (<100ms per file)
- 📚 Comprehensive documentation
- 🧪 Test suite with real Leo programs
- 📦 Published to PyPI

### Architecture
- `LeoParser` - Regex-based source code parser
- `ComplianceChecker` - Rule engine with policy packs
- `CheckResult` - Pydantic models for type safety
- CLI with Click framework
- Rich library for beautiful terminal output

---

## [Unreleased]

### Planned for v0.2.0
- Complete NIST 800-53 policy pack (1200+ controls)
- Complete ISO 27001 policy pack (114 controls)
- VS Code extension
- File watching mode improvements
- More granular rule configuration

### Planned for v0.3.0
- PCI-DSS policy pack
- GDPR policy pack
- Custom rule creation guide
- Performance optimizations
- Multi-file batch analysis

### Planned for v0.4.0
- AI-powered auto-fix (opt-in with user's API key)
- Local LLM support (Ollama, LM Studio)
- Fix confidence scoring
- Automated PR generation

---

**Version Format:** MAJOR.MINOR.PATCH
- MAJOR: Breaking changes
- MINOR: New features (backwards compatible)
- PATCH: Bug fixes (backwards compatible)
