# PCI-DSS Compliance Guide for Aleo Smart Contracts

**Version:** 1.0.0  
**Based on:** PCI-DSS v4.0  
**For:** Comp-LEO SDK v0.3.0+

---

## 🎯 Overview

This guide explains how to build **PCI-DSS compliant** payment and DeFi contracts on Aleo using Comp-LEO SDK.

### What is PCI-DSS?

The Payment Card Industry Data Security Standard (PCI-DSS) is a set of security standards designed to ensure that all companies that accept, process, store or transmit credit card information maintain a secure environment.

### Why PCI-DSS for Smart Contracts?

While blockchain applications don't directly handle credit cards, they often:
- Process payment tokens
- Handle financial transactions
- Store payment metadata
- Interface with payment gateways

**Comp-LEO SDK** helps ensure your Leo contracts follow PCI best practices.

---

## 📋 Requirements Covered

### Critical Requirements (MUST FIX)

#### **Requirement 3.2: No Sensitive Authentication Data Storage**
**Rule:** Never store CVV, PIN, or full magnetic stripe data after authorization.

**What We Check:**
- ❌ Variable names containing: `cvv`, `cvc`, `pin`, `track_data`
- ❌ Hardcoded credit card numbers in code
- ❌ Sensitive authentication data in struct fields

**Example Violation:**
```leo
struct Payment {
    cvv: u16,              // ❌ CRITICAL: Never store CVV!
    pin: u32               // ❌ CRITICAL: Never store PIN!
}
```

**Compliant Code:**
```leo
struct Payment {
    private payment_token: field,  // ✅ Use tokenized reference
    private amount: u64            // ✅ Safe
}
```

---

#### **Requirement 3.4: Render Cardholder Data Unreadable**
**Rule:** All cardholder data must be protected (encrypted/private).

**What We Check:**
- ❌ `public` visibility on payment-related fields
- ❌ Card data exposed in function parameters
- ❌ Unencrypted payment information

**Example Violation:**
```leo
struct Payment {
    public card_number: u128,     // ❌ CRITICAL: Must be private
    public account_info: field    // ❌ HIGH: Exposes payment data
}

transition process(public card: u128) { // ❌ CRITICAL
    // ...
}
```

**Compliant Code:**
```leo
struct Payment {
    private payment_token: field,  // ✅ Private and tokenized
    private amount: u64,           // ✅ Private
    public merchant_id: u32        // ✅ OK - not sensitive
}

transition process(private token: field) { // ✅
    // ...
}
```

---

#### **Requirement 7.1: Restrict Access to Payment Functions**
**Rule:** Limit access to cardholder data by business need-to-know.

**What We Check:**
- ❌ Payment functions without caller verification
- ❌ Missing owner/authorization parameters
- ❌ Anyone can execute payment operations

**Example Violation:**
```leo
transition process_payment(amount: u64) {
    // ❌ CRITICAL: Anyone can call this!
    // No access control
}
```

**Compliant Code:**
```leo
transition process_payment(
    amount: u64,
    owner: address
) {
    // ✅ Verify caller is authorized
    assert_eq(self.caller, owner);
    
    // Process payment...
}
```

---

### High Priority Requirements (STRONGLY RECOMMENDED)

#### **Requirement 6.5.1: Input Validation**
**Rule:** Protect against injection flaws and validate all inputs.

**What We Check:**
- ⚠️ Payment amounts without positive value checks
- ⚠️ Missing upper bounds on transaction amounts
- ⚠️ Unvalidated parameters

**Example Violation:**
```leo
transition send_payment(amount: u64) {
    // ⚠️ HIGH: No validation - could be 0 or overflow
}
```

**Compliant Code:**
```leo
const MAX_AMOUNT: u64 = 1000000u64;  // $10k limit

transition send_payment(amount: u64) {
    // ✅ Validate positive
    assert(amount > 0u64);
    
    // ✅ Validate within limits
    assert(amount < MAX_AMOUNT);
}
```

---

#### **Requirement 10.2: Implement Audit Trails**
**Rule:** Log all access to cardholder data.

**What We Check:**
- ⚠️ Payment functions without `finalize`
- ⚠️ Missing transaction logging
- ⚠️ Incomplete audit information

**Example Violation:**
```leo
transition process_payment(amount: u64) {
    // ⚠️ HIGH: No audit logging
    // Transaction not recorded
}
```

**Compliant Code:**
```leo
mapping payment_log: field => Payment;

transition process_payment(
    payment_id: field,
    amount: u64,
    owner: address
) {
    assert_eq(self.caller, owner);
    
    // ✅ Log via finalize
    return then finalize(payment_id, amount, owner, block.height);
}

finalize process_payment(
    payment_id: field,
    amount: u64,
    owner: address,
    timestamp: u64
) {
    // ✅ Store audit trail on-chain
    let payment: Payment = Payment {
        payment_token: payment_id,
        amount: amount,
        merchant_id: 1u32,
        timestamp: timestamp
    };
    
    Mapping::set(payment_log, payment_id, payment);
}
```

---

### Medium Priority Requirements (RECOMMENDED)

#### **Requirement 11.3.4: Transaction Limits**
**Rule:** Implement anomaly detection mechanisms.

**What We Check:**
- ℹ️ Missing MAX_AMOUNT constants
- ℹ️ No transaction velocity limits
- ℹ️ Unrestricted payment amounts

**Compliant Code:**
```leo
// ✅ Define clear limits
const MAX_AMOUNT: u64 = 1000000u64;        // Per transaction
const MAX_DAILY_AMOUNT: u64 = 10000000u64; // Daily limit

transition process_payment(amount: u64) {
    assert(amount < MAX_AMOUNT);
    // Check daily limits in finalize...
}
```

---

#### **Requirement 12.10.6: Refund/Reversal Capability**
**Rule:** Implement incident response procedures.

**What We Check:**
- ℹ️ Missing refund functionality
- ℹ️ No transaction reversal mechanism
- ℹ️ No dispute resolution

**Compliant Code:**
```leo
// ✅ Implement refund capability
transition refund_payment(
    payment_id: field,
    owner: address
) {
    assert_eq(self.caller, owner);
    
    return then finalize_refund(payment_id, owner);
}

finalize refund_payment(
    payment_id: field,
    owner: address
) {
    // Remove payment record
    let payment: Payment = Mapping::get(payments, payment_id);
    Mapping::remove(payments, payment_id);
    
    // Credit merchant
    // ... refund logic
}
```

---

## 🚀 Quick Start

### 1. Install Comp-LEO SDK

```bash
pip install comp-leo
```

### 2. Check Your Contract

```bash
# Run PCI-DSS checks
comp-leo check your_contract.leo --policy pci-dss-basic

# Generate detailed report
comp-leo report your_contract.leo --policy pci-dss-basic --format html
```

### 3. Review Results

```
╭────────────────────── PCI-DSS SCAN RESULTS ──────────────────────╮
│ Policy: PCI-DSS Basic v1.0                                      │
│ Contract: payment_contract.leo                                  │
├─────────────────────────────────────────────────────────────────┤
│ ❌ CRITICAL (2)                                                  │
│   • Line 12: Card data field must be private (PCI 3.4)         │
│   • Line 45: Missing access control (PCI 7.1)                  │
│                                                                 │
│ ⚠️  HIGH (1)                                                     │
│   • Line 67: No audit logging (PCI 10.2)                       │
│                                                                 │
│ Score: 45/100 - NON COMPLIANT                                  │
╰─────────────────────────────────────────────────────────────────╯
```

### 4. Fix Violations

Follow the remediation suggestions provided in the report.

---

## 📝 Complete Example

### ✅ Fully Compliant Payment Contract

```leo
program compliant_payment.aleo {
    
    // ✅ PCI 11.3.4: Transaction limits
    const MAX_AMOUNT: u64 = 1000000u64;
    const MIN_AMOUNT: u64 = 1u64;
    
    // ✅ PCI 3.4: Private payment data
    struct Payment {
        private payment_token: field,  // Tokenized
        private amount: u64,           // Private
        public merchant_id: u32,       // OK - not sensitive
        public timestamp: u64          // OK - audit info
    }
    
    mapping payments: field => Payment;
    mapping balances: address => u64;
    
    // ✅ Compliant payment processing
    transition process_payment(
        private payment_token: field,  // PCI 3.2: Tokenized
        amount: u64,
        merchant: address
    ) -> Payment {
        
        // ✅ PCI 7.1: Access control
        assert_eq(self.caller, merchant);
        
        // ✅ PCI 6.5.1: Input validation
        assert(amount >= MIN_AMOUNT);
        assert(amount <= MAX_AMOUNT);
        assert(payment_token != 0field);
        
        let payment: Payment = Payment {
            payment_token: payment_token,
            amount: amount,
            merchant_id: 1u32,
            timestamp: block.height
        };
        
        // ✅ PCI 10.2: Audit logging
        return payment then finalize(
            payment_token,
            amount,
            merchant
        );
    }
    
    finalize process_payment(
        payment_token: field,
        amount: u64,
        merchant: address
    ) {
        // Store payment record
        let payment_rec: Payment = Payment {
            payment_token: payment_token,
            amount: amount,
            merchant_id: 1u32,
            timestamp: block.height
        };
        
        Mapping::set(payments, payment_token, payment_rec);
        
        // Update merchant balance
        let balance: u64 = Mapping::get_or_use(balances, merchant, 0u64);
        Mapping::set(balances, merchant, balance + amount);
    }
    
    // ✅ PCI 12.10.6: Refund mechanism
    transition refund_payment(
        payment_token: field,
        merchant: address
    ) {
        assert_eq(self.caller, merchant);
        return then finalize_refund(payment_token, merchant);
    }
    
    finalize refund_payment(
        payment_token: field,
        merchant: address
    ) {
        let payment: Payment = Mapping::get(payments, payment_token);
        
        // Remove payment
        Mapping::remove(payments, payment_token);
        
        // Refund merchant
        let balance: u64 = Mapping::get(balances, merchant);
        Mapping::set(balances, merchant, balance - payment.amount);
    }
}
```

**Check this contract:**
```bash
comp-leo check compliant_payment.leo --policy pci-dss-basic
```

**Expected:** ✅ **100/100 - COMPLIANT**

---

## 🔍 Detailed Checklist

### Before Deployment

- [ ] **No CVV/PIN storage** - Search for forbidden keywords
- [ ] **All payment data is private** - Check struct fields
- [ ] **Access control on all payment functions** - Verify caller checks
- [ ] **Input validation on amounts** - Assert positive and max values
- [ ] **Audit logging via finalize** - All transactions logged
- [ ] **Transaction limits defined** - MAX_AMOUNT constants
- [ ] **Refund mechanism exists** - Dispute resolution

### Testing

```bash
# Run tests
pytest tests/test_pci_compliance.py -v

# Check examples
comp-leo check examples/payment_contract_compliant.leo --policy pci-dss-basic
comp-leo check examples/payment_contract_bad.leo --policy pci-dss-basic

# Generate report
comp-leo report your_project/ --policy pci-dss-basic --format html -o pci_report.html
```

---

## ⚠️ Important Disclaimers

### This Tool is NOT:

1. **A substitute for professional audit** - Engage a Qualified Security Assessor (QSA)
2. **Sufficient for PCI certification** - You still need full SAQ and annual review
3. **A guarantee of compliance** - Manual review still required
4. **Legal or financial advice** - Consult compliance professionals

### This Tool DOES:

1. **Catch common mistakes** - Automated detection of 70%+ issues
2. **Provide guidance** - Best practices for secure payment contracts
3. **Speed up development** - Find issues before manual audit
4. **Educate developers** - Learn PCI requirements

---

## 📚 Additional Resources

### PCI-DSS Official

- [PCI-DSS v4.0 Standard](https://docs-prv.pcisecuritystandards.org/PCI%20DSS/Standard/PCI-DSS-v4_0.pdf)
- [PCI Security Standards Council](https://www.pcisecuritystandards.org/)
- [Self-Assessment Questionnaires (SAQs)](https://www.pcisecuritystandards.org/document_library/)

### Aleo Resources

- [Aleo Developer Docs](https://developer.aleo.org/)
- [Leo Language Guide](https://developer.aleo.org/leo/)
- [Aleo Security Best Practices](https://developer.aleo.org/leo/security/)

### Comp-LEO SDK

- [Documentation](https://docs.compiledger.com)
- [GitHub Repository](https://github.com/compiledger/comp-leo-sdk)
- [Report Issues](https://github.com/compiledger/comp-leo-sdk/issues)

---

## 🤝 Support

**Questions?** Open an issue on [GitHub](https://github.com/compiledger/comp-leo-sdk/issues)

**Need consulting?** Contact: dev@compiledger.com

**Community:** Join the Aleo Discord and tag @CompliLedger

---

## 📄 License

This guide and Comp-LEO SDK are licensed under Apache 2.0.

PCI-DSS is a trademark of PCI Security Standards Council.

---

**Last Updated:** January 2025  
**Version:** 1.0.0  
**SDK Version:** 0.3.0+

Built with ❤️ for secure Aleo payments 🚀
