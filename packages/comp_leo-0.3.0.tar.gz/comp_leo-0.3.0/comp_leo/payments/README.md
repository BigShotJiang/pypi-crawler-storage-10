# PCI-DSS Compliance Module

Payment Card Industry Data Security Standard (PCI-DSS) compliance checks for Aleo smart contracts.

## Overview

This module implements **PCI-DSS v4.0** compliance rules for Leo smart contracts that handle payment processing, DeFi operations, or financial transactions.

## Covered Requirements

### ✅ Critical Requirements

| Requirement | Check | Description |
|------------|-------|-------------|
| **3.2** | Forbidden Data | Never store CVV, PIN, or full track data |
| **3.4** | Data Protection | All cardholder data must be private |
| **7.1** | Access Control | Restrict access to payment functions |

### ✅ High Priority Requirements

| Requirement | Check | Description |
|------------|-------|-------------|
| **6.5.1** | Input Validation | Validate all payment amounts and parameters |
| **10.2** | Audit Logging | Log all payment transactions |

### ✅ Medium Priority Requirements

| Requirement | Check | Description |
|------------|-------|-------------|
| **11.3.4** | Transaction Limits | Define maximum transaction amounts |
| **12.10.6** | Refund Mechanism | Implement dispute resolution |

## Usage

### Check a Payment Contract

```bash
# Run PCI-DSS checks
comp-leo check payment_contract.leo --policy pci-dss-basic

# Generate PCI compliance report
comp-leo report payment_contract.leo --policy pci-dss-basic --format html
```

### Example Output

```
╭────────────────────── PCI-DSS SCAN RESULTS ──────────────────────╮
│ Policy: PCI-DSS Basic v1.0                                      │
│ Contract: payment_contract.leo                                  │
├─────────────────────────────────────────────────────────────────┤
│ ❌ CRITICAL (2)                                                  │
│   • Line 12: Card data field must be private (PCI 3.4)         │
│   • Line 45: Missing access control (PCI 7.1)                  │
│                                                                 │
│ ⚠️  HIGH (1)                                                     │
│   • Line 67: No audit logging (PCI 10.2)                       │
│                                                                 │
│ ℹ️  MEDIUM (1)                                                   │
│   • No transaction limits defined (PCI 11.3.4)                 │
│                                                                 │
│ Score: 45/100 - NON COMPLIANT                                  │
╰─────────────────────────────────────────────────────────────────╯
```

## Best Practices

### ✅ DO

```leo
// Use tokenized payment references
transition process_payment(
    private payment_token: field,  // ✅ Tokenized
    amount: u64,
    owner: address
) {
    // ✅ Access control
    assert_eq(self.caller, owner);
    
    // ✅ Input validation
    assert(amount > 0u64);
    assert(amount < MAX_AMOUNT);
    
    // ✅ Audit logging
    return then finalize(payment_token, amount, owner);
}
```

### ❌ DON'T

```leo
// NEVER do this
struct Payment {
    public card_number: u128,  // ❌ Exposes card data
    public cvv: u16            // ❌ Forbidden to store CVV
}

transition bad_payment(
    public card_number: u128   // ❌ Accepts sensitive data as public
) {
    // ❌ No validation
    // ❌ No access control
    // ❌ No logging
}
```

## API Reference

### `is_payment_function(name, body)`
Determines if a function handles payment operations.

### `detect_forbidden_payment_data(identifier)`
Detects CVV, PIN, or other forbidden data in variable names.

### `check_cardholder_data_visibility(field_name, visibility)`
Verifies cardholder data uses private visibility.

### `check_payment_amount_validation(body, params)`
Ensures payment amounts are validated.

### `check_payment_access_control(name, body, has_owner)`
Verifies proper access control on payment functions.

### `check_payment_audit_logging(name, body)`
Checks for audit trail via finalize functions.

### `check_transaction_limits(constants, has_payments)`
Verifies transaction limit constants are defined.

### `check_refund_mechanism(transitions)`
Checks for refund/reversal capability.

## Limitations

⚠️ **Important:** This tool provides **informal compliance guidance** only. It is NOT:

- A substitute for professional PCI audit
- Sufficient for official PCI certification
- A guarantee of compliance

For official PCI compliance:
1. Engage a Qualified Security Assessor (QSA)
2. Complete full SAQ (Self-Assessment Questionnaire)
3. Undergo annual compliance review

## Examples

See the `/examples` directory:
- `payment_contract_compliant.leo` - ✅ PCI-compliant example
- `payment_contract_bad.leo` - ❌ Shows violations to avoid

## References

- [PCI-DSS v4.0 Standard](https://docs-prv.pcisecuritystandards.org/)
- [PCI Security Standards Council](https://www.pcisecuritystandards.org/)
- [Aleo Documentation](https://developer.aleo.org/)

## Support

Questions? Found a bug? Open an issue on GitHub or contact dev@compiledger.com

---

Built for the Aleo ecosystem 🚀
