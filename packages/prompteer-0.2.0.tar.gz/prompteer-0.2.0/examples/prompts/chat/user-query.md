---
description: User query prompt
question: User's question
context: Additional context
---
Question: {question}

{context}

Please provide a clear and detailed answer.
