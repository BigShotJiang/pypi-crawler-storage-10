---
description: Default fallback question
---
This is the default prompt. It's used when the requested type doesn't have a specific implementation.