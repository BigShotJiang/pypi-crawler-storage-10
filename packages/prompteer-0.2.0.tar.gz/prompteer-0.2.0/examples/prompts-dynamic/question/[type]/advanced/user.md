---
description: Advanced user query
name: User name
context: Additional context
---
Hello {name}, this is an advanced question.

Context: {context}

I'm here to provide detailed technical assistance. What would you like to know?