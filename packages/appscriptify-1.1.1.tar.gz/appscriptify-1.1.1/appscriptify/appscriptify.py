def help():
    print("Hello from AppScriptify! AppScriptify is a CLI tool to create app templates instantly.")
