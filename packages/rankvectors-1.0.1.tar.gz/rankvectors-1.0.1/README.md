# RankVectors Python SDK

Official Python SDK for the RankVectors API - Intelligent internal linking optimization using AI.

## Installation

```bash
pip install rankvectors
```

## Quick Start

```python
import rankvectors
from rankvectors.api import projects_api
from rankvectors.model.create_project_request import CreateProjectRequest

# Configure the API client
configuration = rankvectors.Configuration(
    host="https://api.rankvectors.com"
)

# Set API key
configuration.api_key['Authorization'] = 'YOUR_API_KEY'  # Replace with your actual API key

# Create API instance
with rankvectors.ApiClient(configuration) as api_client:
    api_instance = projects_api.ProjectsApi(api_client)
    
    # Create project
    project_data = CreateProjectRequest(
        name="My Website",
        domain="https://example.com",
        prompt="Only crawl blog posts and documentation"
    )
    
    try:
        project = api_instance.create_project(project_data)
        print(f"Project created: {project}")
        
        # Start crawling
        crawl = api_instance.start_crawl(project.id)
        print(f"Crawl started: {crawl}")
        
    except rankvectors.ApiException as e:
        print(f"Error: {e}")
```

## Features

- ✅ **Python 3.7+**: Modern Python support with type hints
- ✅ **Async Support**: Full async/await support for non-blocking operations
- ✅ **Automatic Authentication**: Handles API key authentication automatically
- ✅ **Error Handling**: Comprehensive error handling with detailed error messages
- ✅ **Type Hints**: Full type annotations for better IDE support
- ✅ **Context Managers**: Proper resource management with context managers

## API Coverage

- **Projects**: Create, manage, and delete projects
- **Crawling**: Start and monitor website crawls
- **Suggestions**: Generate AI-powered link suggestions
- **Implementations**: Implement links via API or webhook
- **Credits**: Manage credit balance and usage
- **Content Verification**: Verify content changes before implementation

## Error Handling

```python
try:
    project = api_instance.create_project(project_data)
except rankvectors.ApiException as e:
    if e.status == 401:
        print("Authentication failed")
    elif e.status == 400:
        print(f"Invalid request: {e.body}")
    else:
        print(f"Unexpected error: {e}")
```

## Async Usage

```python
import asyncio
import rankvectors
from rankvectors.api import projects_api

async def create_project_async():
    configuration = rankvectors.Configuration(
        host="https://api.rankvectors.com"
    )
    configuration.api_key['Authorization'] = 'YOUR_API_KEY'
    
    async with rankvectors.ApiClient(configuration) as api_client:
        api_instance = projects_api.ProjectsApi(api_client)
        
        project_data = CreateProjectRequest(
            name="My Website",
            domain="https://example.com"
        )
        
        try:
            project = await api_instance.create_project(project_data)
            print(f"Project created: {project}")
        except rankvectors.ApiException as e:
            print(f"Error: {e}")

# Run the async function
asyncio.run(create_project_async())
```

## Configuration

```python
configuration = rankvectors.Configuration(
    host="https://api.rankvectors.com",  # API base URL
    api_key={'Authorization': 'YOUR_API_KEY'},  # API key
    timeout=30,  # Request timeout in seconds
    retries=3,  # Number of retries for failed requests
)
```

## Support

- **Documentation**: https://docs.rankvectors.com
- **Support**: support@rankvectors.com
- **GitHub**: https://github.com/rankvectors

## License

MIT License