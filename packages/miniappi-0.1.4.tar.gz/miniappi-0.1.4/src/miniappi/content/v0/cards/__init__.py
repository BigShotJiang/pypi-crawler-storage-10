from .card import Props as Card
