from miniappi.main import app
app()