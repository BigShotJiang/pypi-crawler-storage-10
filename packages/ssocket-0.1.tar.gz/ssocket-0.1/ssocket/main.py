import ssocket as ssocket_module  # Kendi paketiniz (ssocket)

class socket:
    socket = ssocket_module.socket.socket
    AF_INET = ssocket_module.socket.AF_INET
    SOCK_STREAM = ssocket_module.socket.SOCK_STREAM
    SOL_SOCKET = ssocket_module.socket.SOL_SOCKET
    SO_REUSEADDR = ssocket_module.socket.SO_REUSEADDR