from setuptools import setup, find_packages

setup(
    name="ssocket",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    description="ssocket - Tek satırda socket programlama",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Özgür",
    author_email="youremail@example.com",
    python_requires=">=3.7",
)