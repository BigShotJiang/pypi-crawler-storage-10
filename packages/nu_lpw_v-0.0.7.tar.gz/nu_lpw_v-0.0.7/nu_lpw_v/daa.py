def doc():
    print(r"""
mcm() -> MCM (Memoization)
custSort() -> sort any DS from scratch
mergeSort() -> Merge Sort
quickSort() -> Quick Sort
djikstra() -> Dijkstra Algo
prims() -> Prims for MST
kruskal() -> Kruskal for MST
nQueens() -> N-Queens
lcs() -> longest common subsequence
""")
    
def mcm():
    print(r"""
int rec(int i, int j, vector<int> &arr, vector<vector<int>> &dp)
{
    if (i == j)
        return 0;
    if (dp[i][j] != -1)
        return dp[i][j];
    int steps = INT_MAX;
    for (int k = i; k <= j - 1; k++)
    {
        int temp = arr[i - 1] * arr[k] * arr[j] + rec(i, k, arr, dp) + rec(k + 1, j, arr, dp);
        steps = min(temp, steps);
    }
    return dp[i][j] = steps;
}
int matrixMultiplication(vector<int> &arr)
{
    vector<vector<int>> dp(arr.size() + 1, vector<int>(arr.size() + 1, -1));
    return rec(1, arr.size() - 1, arr, dp);
}

""")
    
def custSort():
    print(r"""
bool comp(pair<int,int>& a, pair<int,int>& b) {
    if(a.first != b.first) return a.first < b.first;
    return a.second < b.second;
}

void mergeArr(vector<pair<int,int>>& arr, int l, int mid, int r) {
    int n1 = mid - l + 1;
    int n2 = r - mid;

    vector<pair<int,int>> left(n1), right(n2);

    for(int i = 0; i < n1; i++)
        left[i] = arr[l + i];
    for(int i = 0; i < n2; i++)
        right[i] = arr[mid + 1 + i];

    int i = 0, j = 0, k = l;

    while(i < n1 && j < n2) {
        if(comp(left[i], right[j])) {
            arr[k++] = left[i++];
        } else {
            arr[k++] = right[j++];
        }
    }

    while(i < n1) arr[k++] = left[i++];
    while(j < n2) arr[k++] = right[j++];
}

void mergeSort(vector<pair<int,int>>& arr, int l, int r) {
    if(l < r) {
        int mid = l + (r - l) / 2;
        mergeSort(arr, l, mid);
        mergeSort(arr, mid + 1, r);
        mergeArr(arr, l, mid, r);
    }
}
""")

def mergeSort():
    print(r"""
#include <bits/stdc++.h>
using namespace std;

// Merge two sorted halves of arr[l..r]
void mergeArr(vector<int>& arr, int l, int mid, int r) {
    int n1 = mid - l + 1;
    int n2 = r - mid;

    vector<int> left(n1), right(n2);

    for(int i = 0; i < n1; i++)
        left[i] = arr[l + i];
    for(int i = 0; i < n2; i++)
        right[i] = arr[mid + 1 + i];

    int i = 0, j = 0, k = l;

    while(i < n1 && j < n2) {
        if(left[i] <= right[j]) {
            arr[k++] = left[i++];
        }
        else {
            arr[k++] = right[j++];
        }
    }

    while(i < n1) arr[k++] = left[i++];
    while(j < n2) arr[k++] = right[j++];
}

void mergeSort(vector<int>& arr, int l, int r) {
    if(l >= r) return;

    int mid = l + (r - l) / 2;

    mergeSort(arr, l, mid);
    mergeSort(arr, mid + 1, r);

    mergeArr(arr, l, mid, r);
}

int main() {
    vector<int> arr = {5, 3, 8, 4, 2, 7, 1};

    mergeSort(arr, 0, arr.size() - 1);

    for(int x : arr) cout << x << " ";
    return 0;
}

""")
    
def quickSort():
    print(r"""
#include <bits/stdc++.h>
using namespace std;

// Partition function: places pivot in correct sorted position
int partitionArr(vector<int> &arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for(int j = low; j < high; j++) {
        if(arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(vector<int> &arr, int low, int high) {
    if(low < high) {
        int pivotIndex = partitionArr(arr, low, high);
        quickSort(arr, low, pivotIndex - 1);
        quickSort(arr, pivotIndex + 1, high);
    }
}

int main() {
    vector<int> arr = {10, 7, 8, 9, 1, 5};
    int n = arr.size();

    quickSort(arr, 0, n - 1);

    cout << "Sorted Array: ";
    for(int num : arr)
        cout << num << " ";
}

""")

def djikstra():
    print(r"""

""")
    
def prims():
    print(r"""

""")
    
def kruskal():
    print(r"""

""")
    
def nQueens():
    print(r"""
class Solution {
public:
bool isValid(int row, int col, vector<string>board,vector<bool>&isRowTaken,vector<bool>&lowerDiagonal,vector<bool>&upperDiagonal){
    int n = board.size();
    if(isRowTaken[row]) return false;

    if(lowerDiagonal[row+col]) return false;

    if(upperDiagonal[n-1 + col - row]) return false;
    
    return true;
}
void rec(int col,int n,vector<string>&board,vector<vector<string>>&ans,vector<bool>&isRowTaken,vector<bool>&lowerDiagonal,vector<bool>&upperDiagonal){
    if(col==n){
        ans.push_back(board);
        return;
    }
    for(int i = 0;i<n;i++){
        if(isValid(i,col,board,isRowTaken,lowerDiagonal,upperDiagonal)){
            board[i][col] = 'Q';
            isRowTaken[i] = true;
            lowerDiagonal[i+col] = true;
            upperDiagonal[n-1+col-i] = true;
            rec(col+1,n,board,ans,isRowTaken,lowerDiagonal,upperDiagonal);
            board[i][col] = '.';
            isRowTaken[i] = false;
            lowerDiagonal[i+col] = false;
            upperDiagonal[n-1+col-i] = false;
        }
    }
}
    vector<vector<string>> solveNQueens(int n) {
        vector<bool>isRowTaken(n,false);
        vector<bool>lowerDiagonal(2*n-1,false);
        vector<bool>upperDiagonal(2*n-1,false);
        vector<string>board(n);
        vector<vector<string>>ans;
        for(int i = 0;i<n;i++){
            for(int j = 0;j<n;j++){
                board[i].push_back('.');
            }
        }
        rec(0,n,board,ans,isRowTaken,lowerDiagonal,upperDiagonal);
        return ans;
    }
};
""")
    
def lcs():
    print(r"""

""")