Setup:

- Install "accountant"
- Select company "CH Company"
- Open the accounting app

Reconcile:

- Run the scheduled action "Ihre Kontoauszugszeilen automatisch abzustimmen"
- Check if all "Bank2" statements have been reconciled