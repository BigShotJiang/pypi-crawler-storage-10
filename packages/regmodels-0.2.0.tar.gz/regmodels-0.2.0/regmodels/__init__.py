
"""
regmodels - A simple machine learning regression evaluation and reporting library.

Author: Amna Talha
Version: 1.0.0
"""
from .regmodels import train_and_evaluate
from .report_generator import generate_report, generate_visual_report

__all__ = ["generate_report", "generate_visual_report"]

print("✅ regmodels library loaded successfully — Ready to generate ML reports!")
