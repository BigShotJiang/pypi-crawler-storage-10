import os
import numpy as np
import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots
from datetime import datetime
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

def generate_visual_report(model_results, theme="professional"):
    """Create a combined interactive visualization for multiple regression models."""

    themes = {
        "light": {"bgcolor": "white", "fontcolor": "black"},
        "dark": {"bgcolor": "#222", "fontcolor": "white"},
        "professional": {"bgcolor": "#f4f4f8", "fontcolor": "#333"},
    }

    t = themes.get(theme, themes["professional"])
    model_names = list(model_results.keys())
    fig = make_subplots(rows=len(model_names), cols=1, subplot_titles=model_names)

    stats = []

    for i, (model, data) in enumerate(model_results.items(), 1):
        y_true, y_pred = np.array(data["y_true"]), np.array(data["y_pred"])
        r2 = r2_score(y_true, y_pred)
        mae = mean_absolute_error(y_true, y_pred)
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        stats.append((model, r2, mae, rmse))

        fig.add_trace(go.Scatter(x=y_true, y=y_pred,
                                 mode='markers',
                                 name=f"{model} Predictions"),
                      row=i, col=1)
        fig.add_trace(go.Scatter(x=y_true, y=y_true,
                                 mode='lines',
                                 name="Ideal Line",
                                 line=dict(dash='dot')),
                      row=i, col=1)

    fig.update_layout(height=400*len(model_names),
                      title="Combined Model Predictions",
                      showlegend=False,
                      plot_bgcolor=t["bgcolor"],
                      paper_bgcolor=t["bgcolor"],
                      font=dict(color=t["fontcolor"]))

    return fig, stats


def generate_report(model_results,
                    theme="professional",
                    developer_name="Amna Talha",
                    developer_position="bottom",
                    output_path="reports/",
                    report_title="Regression Model Performance Report"):
    """Generate both HTML and PDF reports for given model results."""

    os.makedirs(output_path, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # Generate visualization
    fig, stats = generate_visual_report(model_results, theme=theme)
    html_file = os.path.join(output_path, f"Model_Report_{timestamp}.html")
    fig.write_html(html_file)

    # Create PDF report
    pdf_file = os.path.join(output_path, f"Model_Report_{timestamp}.pdf")
    doc = SimpleDocTemplate(pdf_file, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    # Developer name at top
    if developer_position == "top":
        elements.append(Paragraph(f"<b>Developed by: {developer_name}</b>", styles["Normal"]))
        elements.append(Spacer(1, 12))

    # Title
    elements.append(Paragraph(f"<b>{report_title}</b>", styles["Title"]))
    elements.append(Spacer(1, 12))

    # Stats summary
    elements.append(Paragraph("<b>Model Statistics</b>", styles["Heading2"]))
    for model, r2, mae, rmse in stats:
        elements.append(Paragraph(
            f"<b>{model}</b> — R²: {r2:.3f}, MAE: {mae:.3f}, RMSE: {rmse:.3f}",
            styles["Normal"]
        ))
        elements.append(Spacer(1, 6))

    elements.append(Spacer(1, 12))
    elements.append(Paragraph("📊 Interactive HTML report saved at:", styles["Normal"]))
    elements.append(Paragraph(html_file, styles["Normal"]))

    # Developer name at bottom
    if developer_position == "bottom":
        elements.append(Spacer(1, 24))
        elements.append(Paragraph(f"<b>Developed by: {developer_name}</b>", styles["Normal"]))

    doc.build(elements)

    print(f"✅ HTML Report saved to: {html_file}")
    print(f"✅ PDF Report saved to: {pdf_file}")
    return {"html": html_file, "pdf": pdf_file}
