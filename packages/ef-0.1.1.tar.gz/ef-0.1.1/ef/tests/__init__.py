"""Tests for ef package."""
