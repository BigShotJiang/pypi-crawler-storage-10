from astropy.coordinates import EarthLocation as AstropyEarthLocation


class EarthLocation(AstropyEarthLocation):
    """Very thin wrapper around astropy earthlocation to ease user experience"""

    pass
