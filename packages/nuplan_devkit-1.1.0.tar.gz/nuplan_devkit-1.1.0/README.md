## nuplan-devkit installer

from nuplan_installer import install_and_verify_nuplan

success = install_and_verify_nuplan("nuplan_devkit")