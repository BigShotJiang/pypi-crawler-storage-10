import sys
from pathlib import Path

from yt_dlp import YoutubeDL


def download_video(url, output_path="downloads"):
    """Download the best available MP4 video using yt-dlp.

    Parameters
    ----------
    url : str
        The YouTube video URL to download.
    output_path : str or os.PathLike, optional
        Directory where the downloaded file will be saved. Defaults to "downloads".

    Returns
    -------
    str
        Absolute path to the downloaded video file, or ``None`` if download failed.
    """

    target_dir = Path(output_path).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    # Configure yt-dlp to get the best mp4 video+audio combination.
    ydl_opts = {
        "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "outtmpl": str(target_dir / "%(title)s.%(ext)s"),
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": False,
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            result = ydl.extract_info(url, download=True)
    except Exception as exc:
        print(f"Error downloading video: {exc}", file=sys.stderr)
        return None

    if not result:
        print("Failed to retrieve video information.", file=sys.stderr)
        return None

    # When downloading a single video, yt-dlp returns a dict. For playlists, it may return dict with entries.
    if "entries" in result:
        # Shouldn't happen due to noplaylist, but handle just in case by picking first successful entry.
        for entry in result.get("entries", []):
            file_path = _extract_filepath(entry)
            if file_path:
                return file_path
        print("No downloadable entries found in playlist.", file=sys.stderr)
        return None

    file_path = _extract_filepath(result)
    if not file_path:
        print("Download completed but file path is unavailable.", file=sys.stderr)
        return None

    return file_path


def _extract_filepath(info):
    """Return the resolved filepath from a yt-dlp result entry."""

    if not info:
        return None

    candidates = []

    # Direct keys used by yt-dlp in different contexts.
    for key in ("filepath", "_filename", "filename"):
        value = info.get(key)
        if value:
            candidates.append(value)

    # Requested downloads list contains detailed info post-processing.
    for item in info.get("requested_downloads", []) or []:
        for key in ("filepath", "_filename", "filename"):
            value = item.get(key)
            if value:
                candidates.append(value)

    # Post-processors may add this key.
    pp_list = info.get("__postprocessors", []) or []
    for item in pp_list:
        value = item.get("filepath") if isinstance(item, dict) else None
        if value:
            candidates.append(value)

    for path in candidates:
        resolved = Path(path)
        if not resolved.is_absolute():
            resolved = Path.cwd() / resolved
        if resolved.exists():
            return str(resolved.resolve())

    # Fall back to the first candidate even if the file does not yet exist (it might still be final path).
    if candidates:
        resolved = Path(candidates[0])
        if not resolved.is_absolute():
            resolved = Path.cwd() / resolved
        return str(resolved.resolve())

    return None