"""Top-level package for pn_yt2slides."""

from .downloader import download_video

__all__ = ["download_video", "__version__"]
__version__ = "0.2.0"