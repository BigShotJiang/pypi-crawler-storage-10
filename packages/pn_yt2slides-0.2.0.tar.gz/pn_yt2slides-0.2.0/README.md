# pn_yt2slides

`pn_yt2slides` is a minimal Python helper that downloads YouTube videos as MP4 files using [yt-dlp](https://github.com/yt-dlp/yt-dlp).

## Features

- Fetches the best available MP4 (video + audio) rendition for a YouTube URL.
- Saves the file to a configurable output directory.
- Returns the absolute path to the downloaded video for easy scripting/integration.

## Installation

```bash
pip install pn_yt2slides
```

For local development:

```bash
git clone https://github.com/PurnimaNahata/pn_yt2slides.git
cd pn_yt2slides
pip install -e .
```

## Usage

```python
from pn_yt2slides import download_video

file_path = download_video("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
print(file_path)
```

By default the video is saved to a `downloads/` directory in the current working directory. You can override this by passing a custom path:

```python
download_video(url, output_path="/path/to/folder")
```

## Command-Line Demo

The repository ships with a small example script:

```bash
python testing.py
```

It downloads the sample video and prints the final file path.

## Requirements

- Python 3.8+
- [FFmpeg](https://ffmpeg.org/) available on your PATH (required by `yt-dlp` when merging video/audio streams).
- Python dependency: `yt-dlp`

## License

MIT License. See [LICENSE](LICENSE) for details.

