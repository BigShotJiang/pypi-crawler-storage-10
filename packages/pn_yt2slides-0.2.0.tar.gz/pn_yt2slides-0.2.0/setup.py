from pathlib import Path

from setuptools import find_packages, setup

PACKAGE_NAME = "pn_yt2slides"
HERE = Path(__file__).parent


def read(*parts):
    return (HERE.joinpath(*parts)).read_text(encoding="utf-8")


setup(
    name=PACKAGE_NAME,
    version="0.2.0",
    author="Purnima Nahata",
    author_email="purnimanahata106@gmail.com",
    description="Simple helper to download YouTube videos as MP4 using yt-dlp.",
    long_description=read("README.md") if (HERE / "README.md").exists() else read("DESCRIPTION.txt") if (HERE / "DESCRIPTION.txt").exists() else "",
    long_description_content_type="text/markdown",
    url="https://github.com/purnima106/pn_yt2slides.git",
    project_urls={
        "Source": "https://github.com/purnima106/pn_yt2slides.git",
    },
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["yt-dlp"],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Multimedia :: Video",
        "Intended Audience :: Developers",
    ],
    keywords="youtube downloader yt-dlp",
)
