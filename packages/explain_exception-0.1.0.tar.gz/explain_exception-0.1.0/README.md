# WhyError

**WhyError** is a Python library that explains Python errors in **clear English**, making it easier for beginners to understand what went wrong in their code.

## Features

- Explains common Python errors in simple English
- Provides clear explanations for beginners
- Shows the full traceback for debugging
- Optional `safe_run` wrapper to automatically explain errors

## Installation

You can install WhyError locally for testing:

```bash
pip install -e .
