⚠️ THIS PROJECT 'nvidia-cuda-sanitizer-api-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-sanitizer-api' instead.

To install the correct package, use:

    pip install nvidia-cuda-sanitizer-api

For more information, visit: https://pypi.org/project/nvidia-cuda-sanitizer-api/
