# asmitote.__init__


__version__ = "1.0.0"
