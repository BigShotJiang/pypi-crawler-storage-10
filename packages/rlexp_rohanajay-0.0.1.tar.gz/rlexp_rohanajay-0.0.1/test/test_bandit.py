from rlexp import BanditEnv, EpsilonGreedyAgent, Experiment

def test_bandit():
    env = BanditEnv([0.1, 0.5, 0.9])
    agent = EpsilonGreedyAgent(epsilon=0.1, n_arms=3)
    exp = Experiment(env, agent)
    rewards = exp.run(episodes=100)
    assert len(rewards) == 100
