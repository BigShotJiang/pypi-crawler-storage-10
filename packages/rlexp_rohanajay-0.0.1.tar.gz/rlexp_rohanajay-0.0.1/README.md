# rlexp 

A lightweight reinforcement learning experimentation toolkit.

## Installation
```bash
pip install rlexp-rohanajay
```

## USAGE:

from rlexp import BanditEnv, EpsilonGreedyAgent, Experiment

env = BanditEnv(arms=[0.1, 0.5, 0.9])
agent = EpsilonGreedyAgent(epsilon=0.1, n_arms=3)
exp = Experiment(env, agent)
exp.run(episodes=1000)
exp.plot_rewards()

## Features:

* Multi-armed bandit environment
* Epsilon-greedy agent
* Reward tracking and plotting
* No dependencies beyond matplotlib