import matplotlib.pyplot as plt

class Experiment:
    """
    Runs RL experiments and tracks rewards.
    """
    def __init__(self, env, agent):
        self.env = env
        self.agent = agent
        self.rewards = []

    def run(self, episodes=1000):
        """Run a full experiment for given number of episodes."""
        for _ in range(episodes):
            action = self.agent.select_action()
            reward = self.env.step(action)
            self.agent.update(action, reward)
            self.rewards.append(reward)
        return self.rewards

    def plot_rewards(self):
        """Plot cumulative reward over time."""
        plt.plot(self.rewards)
        plt.xlabel("Episode")
        plt.ylabel("Reward")
        plt.title("Rewards over Episodes")
        plt.show()
