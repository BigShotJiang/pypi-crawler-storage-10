import random

class BanditEnv:
    """
    Simple multi-armed bandit environment.
    Each arm has a fixed reward probability.
    """
    def __init__(self, arms):
        self.arms = arms

    def step(self, action):
        """Take an action (choose an arm) and get a stochastic reward."""
        prob = self.arms[action]
        return 1 if random.random() < prob else 0

    def n_arms(self):
        return len(self.arms)
