import numpy as np
import pandas as pd
import string
from typing import Tuple, List, Dict

# playfaircipher.py
# GitHub Copilot
# Playfair cipher implementation with encryption and decryption functions.
# Requires: numpy, pandas (pandas used only for optional display)



def _normalize_text(text: str) -> str:
    text = "".join(ch.upper() for ch in text if ch.isalpha())
    # Merge J into I (classic variant)
    text = text.replace("J", "I")
    return text


def _create_key_matrix(key: str, pad_char: str = "X") -> Tuple[np.ndarray, Dict[str, Tuple[int, int]]]:
    key = _normalize_text(key)
    seen = []
    for ch in key:
        if ch not in seen:
            seen.append(ch)

    alphabet = [c for c in string.ascii_uppercase if c != "J"]
    for ch in alphabet:
        if ch not in seen:
            seen.append(ch)

    mat = np.array(seen[:25]).reshape((5, 5))
    positions = {mat[r, c]: (r, c) for r in range(5) for c in range(5)}
    return mat, positions


def _digraphs_for_encrypt(text: str, pad_char: str = "X") -> List[Tuple[str, str]]:
    text = _normalize_text(text)
    digraphs: List[Tuple[str, str]] = []
    i = 0
    while i < len(text):
        a = text[i]
        b = text[i + 1] if i + 1 < len(text) else ""
        if b == "":
            digraphs.append((a, pad_char))
            i += 1
        elif a == b:
            # insert pad between identical letters
            digraphs.append((a, pad_char))
            i += 1
        else:
            digraphs.append((a, b))
            i += 2
    return digraphs


def _process_pair_encrypt(a: str, b: str, matrix: np.ndarray, pos: Dict[str, Tuple[int, int]]) -> str:
    ra, ca = pos[a]
    rb, cb = pos[b]
    if ra == rb:
        # same row: take right
        ca1 = (ca + 1) % 5
        cb1 = (cb + 1) % 5
        return matrix[ra, ca1] + matrix[rb, cb1]
    if ca == cb:
        # same column: take down
        ra1 = (ra + 1) % 5
        rb1 = (rb + 1) % 5
        return matrix[ra1, ca] + matrix[rb1, cb]
    # rectangle: swap columns
    return matrix[ra, cb] + matrix[rb, ca]


def _process_pair_decrypt(a: str, b: str, matrix: np.ndarray, pos: Dict[str, Tuple[int, int]]) -> str:
    ra, ca = pos[a]
    rb, cb = pos[b]
    if ra == rb:
        ca1 = (ca - 1) % 5
        cb1 = (cb - 1) % 5
        return matrix[ra, ca1] + matrix[rb, cb1]
    if ca == cb:
        ra1 = (ra - 1) % 5
        rb1 = (rb - 1) % 5
        return matrix[ra1, ca] + matrix[rb1, cb]
    return matrix[ra, cb] + matrix[rb, ca]


def playfair_encrypt(plaintext: str, key: str, pad_char: str = "X", show_table: bool = False) -> str:
    """
    Encrypt plaintext with Playfair cipher using given key.
    Returns ciphertext (uppercase).
    If show_table=True, prints a pandas DataFrame of the 5x5 key table.
    """
    matrix, pos = _create_key_matrix(key, pad_char)
    if show_table:
        print(pd.DataFrame(matrix))
    pairs = _digraphs_for_encrypt(plaintext, pad_char)
    cipher = []
    for a, b in pairs:
        cipher.append(_process_pair_encrypt(a, b, matrix, pos))
    return "".join(cipher)


def playfair_decrypt(ciphertext: str, key: str, pad_char: str = "X", show_table: bool = False) -> str:
    """
    Decrypt ciphertext with Playfair cipher using given key.
    Returns a best-effort recovered plaintext (uppercase). Padding/pattern X removal is heuristic.
    If show_table=True, prints a pandas DataFrame of the 5x5 key table.
    """
    ct = _normalize_text(ciphertext)
    if len(ct) % 2 != 0:
        raise ValueError("Ciphertext length must be even for Playfair decryption.")
    matrix, pos = _create_key_matrix(key, pad_char)
    if show_table:
        print(pd.DataFrame(matrix))
    plain_pairs = []
    for i in range(0, len(ct), 2):
        a, b = ct[i], ct[i + 1]
        plain_pairs.append(_process_pair_decrypt(a, b, matrix, pos))
    plain = "".join(plain_pairs)
    # Heuristic cleanup: remove pad_char inserted between identical letters and trailing pad
    cleaned = []
    i = 0
    while i < len(plain):
        if i + 2 < len(plain) and plain[i] == plain[i + 2] and plain[i + 1] == pad_char:
            cleaned.append(plain[i])
            i += 2
        else:
            cleaned.append(plain[i])
            i += 1
    result = "".join(cleaned)
    if result.endswith(pad_char):
        result = result[:-1]
    return result


if __name__ == "__main__":
    # Example usage
    key = "monarchy"
    plaintext = "instruments"
    ct = encrypt(plaintext, key, show_table=True)
    print("Plaintext:", plaintext)
    print("Ciphertext:", ct)
    pt = decrypt(ct, key, show_table=False)
    print("Decrypted:", pt)