# elgamal_algo.py

from secrets import SystemRandom
from mathtools import mod_exp, generate_large_prime, primitive_roots, gcd, extended_euclidean

_sysrand = SystemRandom()


def elgamal_generate_keypair(bits: int = 2048):
    """Generate ElGamal keys: p, g, private x, public y"""
    p = generate_large_prime(bits)
    roots = primitive_roots(p)
    if not roots:
        raise RuntimeError("No primitive root found")
    g = roots[0]

    x = _sysrand.randrange(2, p - 2)   # private
    y = mod_exp(g, x, p)               # public

    pub = {"p": p, "g": g, "y": y}
    priv = {"p": p, "x": x}

    return p,g,x,y


def elgamal_encrypt_int(m: int, pub: dict):
    """Encrypt integer m → returns tuple (c1, c2)."""
    p, g, y = pub["p"], pub["g"], pub["y"]
    if not (0 <= m < p):
        raise ValueError("Message must be < p")

    k = _sysrand.randrange(2, p - 2)
    c1 = mod_exp(g, k, p)
    s = mod_exp(y, k, p)
    c2 = (m * s) % p
    return c1, c2


def elgamal_decrypt_int(cipher: tuple, priv: dict):
    """Decrypt (c1, c2) → message integer."""
    c1, c2 = cipher
    p, x = priv["p"], priv["x"]

    s = mod_exp(c1, x, p)

    # compute s inverse mod p
    g, inv, _ = extended_euclidean(s, p)
    if g != 1:
        raise RuntimeError("No modular inverse found")
    s_inv = inv % p

    return (c2 * s_inv) % p


def bytes_to_int(data: bytes) -> int:
    return int.from_bytes(data, "big")


def int_to_bytes(value: int) -> bytes:
    length = (value.bit_length() + 7) // 8
    return value.to_bytes(length, "big")


def elgamal_encrypt_bytes(data: bytes, pub: dict):
    m = bytes_to_int(data)
    c1, c2 = elgamal_encrypt_int(m, pub)
    return int_to_bytes(c1), int_to_bytes(c2)


def elgamal_decrypt_bytes(c1b: bytes, c2b: bytes, priv: dict):
    c1, c2 = bytes_to_int(c1b), bytes_to_int(c2b)
    m = elgamal_decrypt_int((c1, c2), priv)
    return int_to_bytes(m)
print("\n=== ElGamal demo (small bits) ===")
p,g,x,y = elgamal_generate_keypair(bits=12)
pub_eg = {"p": p, "g": g, "y": y}
priv_eg = {"p": p, "x": x}
m_bytes = b"H"
c1b, c2b = elgamal_encrypt_bytes(m_bytes, pub_eg)
print(c1b,c2b)
rec = elgamal_decrypt_bytes(c1b, c2b, priv_eg)
print(rec)
print("ElGamal recovered:", rec == m_bytes, rec.hex())
