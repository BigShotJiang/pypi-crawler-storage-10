import socket

HOST = '127.0.0.1'  # Localhost (same node)
PORT = 65432        # Any unused port number

# Create a TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to an address and port
server_socket.bind((HOST, PORT))

# Listen for incoming connections
server_socket.listen()
print(f"Server listening on {HOST}:{PORT}...")

# Accept a client connection
conn, addr = server_socket.accept()
print(f"Connected by {addr}")

# Receive data from client
while True:
    data = conn.recv(1024)  # Receive 1KB of data
    if not data:
        break
    print(f"Client: {data.decode()}")
    msg = input("Server: ")
    conn.sendall(msg.encode())

conn.close()
