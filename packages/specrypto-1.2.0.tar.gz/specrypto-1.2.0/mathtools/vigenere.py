import string
from collections import Counter
import math

# -----------------------------
# Basic utilities
# -----------------------------
alphabet = string.ascii_lowercase

def clean_text(text):
    return ''.join(ch.lower() for ch in text if ch.isalpha())

# English letter frequency (normalized)
english_freq = {
    'a': 0.08167, 'b': 0.01492, 'c': 0.02782, 'd': 0.04253, 'e': 0.12702,
    'f': 0.02228, 'g': 0.02015, 'h': 0.06094, 'i': 0.06966, 'j': 0.00153,
    'k': 0.00772, 'l': 0.04025, 'm': 0.02406, 'n': 0.06749, 'o': 0.07507,
    'p': 0.01929, 'q': 0.00095, 'r': 0.05987, 's': 0.06327, 't': 0.09056,
    'u': 0.02758, 'v': 0.00978, 'w': 0.02360, 'x': 0.00150, 'y': 0.01974,
    'z': 0.00074
}

# -----------------------------
# Index of Coincidence
# -----------------------------
def index_of_coincidence(text):
    N = len(text)
    freqs = Counter(text)
    return sum(f * (f - 1) for f in freqs.values()) / (N * (N - 1)) if N > 1 else 0

def find_key_length(ciphertext, max_key_len=20):
    ic_values = {}
    for key_len in range(1, max_key_len + 1):
        parts = [ciphertext[i::key_len] for i in range(key_len)]
        avg_ic = sum(index_of_coincidence(part) for part in parts) / key_len
        ic_values[key_len] = avg_ic
    return ic_values

# -----------------------------
# Chi-squared frequency test
# -----------------------------
def chi_squared_stat(text):
    N = len(text)
    freqs = Counter(text)
    chi_sq = 0
    for letter in alphabet:
        observed = freqs.get(letter, 0)
        expected = english_freq[letter] * N
        chi_sq += (observed - expected) ** 2 / expected
    return chi_sq

def shift_text(text, shift):
    shifted = ''
    for ch in text:
        shifted += alphabet[(alphabet.index(ch) - shift) % 26]
    return shifted

def find_key(ciphertext, key_len):
    key = ''
    for i in range(key_len):
        segment = ciphertext[i::key_len]
        scores = []
        for shift in range(26):
            shifted = shift_text(segment, shift)
            score = chi_squared_stat(shifted)
            scores.append((score, shift))
        best_shift = min(scores)[1]
        key += alphabet[best_shift]
    return key

# -----------------------------
# Vigenère decryption
# -----------------------------
def vigenere_decrypt(ciphertext, key):
    plaintext = ''
    key_len = len(key)
    for i, ch in enumerate(ciphertext):
        p = (alphabet.index(ch) - alphabet.index(key[i % key_len])) % 26
        plaintext += alphabet[p]
    return plaintext

# -----------------------------
# MAIN: Break Vigenere
# -----------------------------
ciphertext = """
hdsfgvm koouafw eetcm fthskucaqbilgjofm aqlgspvatvxqbiryscpcfr
m vsw rvnqlszdm gaoqsakm lupsqforvtw vdfcjzvgaoaoqsacjkbrsevbel
vbksarlscdcaarm nvrysyw xqgvellcyluw w eoafgclazow af o jd lh s s f i
ksepsoyuxaf owlbfcsocylngqsyzxgjbm lvgrggokgfgm hlm ejabsjvgnil
nrvqzcrggcrghgeupcyfgtydycjkhqluhgxgzovqsw pdvbw sffsenbxapa
sgazm yuhgsfhm ftayjxm uznrsofrsoaopgauaaarm ftqsm akvqecev
"""

ciphertext = clean_text(ciphertext)

# Step 1: find key length
ic_vals = find_key_length(ciphertext, 15)
print("Key length candidates (IC values):")
for k, v in ic_vals.items():
    print(f"{k:2d}: {v:.4f}")

probable_key_len = max(ic_vals, key=ic_vals.get)
print("\nMost probable key length:", probable_key_len)

# Step 2: find key
key = find_key(ciphertext, probable_key_len)
print("Recovered key:", key)

# Step 3: decrypt
plaintext = vigenere_decrypt(ciphertext, key)
print("\nDecrypted plaintext:\n")
print(plaintext)
