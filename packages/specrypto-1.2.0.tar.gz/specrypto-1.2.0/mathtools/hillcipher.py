import numpy as np
from mathtools import matrix_mod_mul, matrix_mod_inverse

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
MOD = 26

def text_to_numbers(text):
    return [ALPHABET.index(ch) for ch in text.upper() if ch.isalpha()]

def numbers_to_text(nums):
    return ''.join(ALPHABET[n % MOD] for n in nums)

def pad_text(nums, block_size):
    while len(nums) % block_size != 0:
        nums.append(23)  # X padding
    return nums

def hill_encrypt(plaintext, key_matrix):
    nums = text_to_numbers(plaintext)
    block_size = key_matrix.shape[0]
    nums = pad_text(nums, block_size)
    ciphertext = []

    for i in range(0, len(nums), block_size):
        block = np.array(nums[i:i+block_size])
        enc_block = matrix_mod_mul(key_matrix, block, MOD)
        ciphertext.extend(enc_block)
    
    return numbers_to_text(ciphertext)

def hill_decrypt(ciphertext, key_matrix):
    key_inv = matrix_mod_inverse(key_matrix, MOD)
    nums = text_to_numbers(ciphertext)
    block_size = key_matrix.shape[0]
    plaintext_nums = []

    for i in range(0, len(nums), block_size):
        block = np.array(nums[i:i+block_size])
        dec_block = matrix_mod_mul(key_inv, block, MOD)
        plaintext_nums.extend(dec_block)
    
    return numbers_to_text(plaintext_nums)
    

# ----------------- Example -----------------
key = np.array([
    [3, 3],
    [2, 5]
])

plaintext = "HELLO"
cipher = hill_encrypt(plaintext, key)
dec = hill_decrypt(cipher, key)

print("Plaintext:", plaintext)
print("Ciphertext:", cipher)
print("Decrypted:", dec)
