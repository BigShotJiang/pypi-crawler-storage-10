def encrypt_caesar(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            # Determine ASCII offset based on case (65 for uppercase, 97 for lowercase)
            ascii_offset = 65 if char.isupper() else 97
            # Apply shift and wrap around using modulo
            shifted = (ord(char) - ascii_offset + shift) % 26
            result += chr(shifted + ascii_offset)
        else:
            # Keep non-alphabetic characters unchanged
            result += char
    return result

def decrypt_caesar(text, shift):
    # Decryption is just encryption with negative shift
    return encrypt_caesar(text, -shift)

def main():
    # Get input from user
    text = input("Enter text to encrypt/decrypt: ")
    shift = int(input("Enter shift value (1-25): "))
    
    # Perform encryption
    encrypted = encrypt_caesar(text, shift)
    print(f"Encrypted: {encrypted}")
    
    # Perform decryption
    decrypted = decrypt_caesar(encrypted, shift)
    print(f"Decrypted: {decrypted}")

if __name__ == "__main__":
    main()