# enigma_machine.py
"""
Simple Enigma rotor machine simulator (historical-style, educational)
Features:
- Plugboard (swapping pairs)
- 3 rotors (wiring and turnovers based on historic Enigma I rotors)
- Reflector (B)
- Stepping mechanism including double-step behavior
- Encrypt/decrypt functions (symmetric)

Usage:
    from enigma_machine import EnigmaMachine
    em = EnigmaMachine(rotor_names=('I','II','III'), ring_settings=(1,1,1), positions=('A','A','A'),
                       plugboard_pairs=['AD','CN','ET'])
    ct = em.encrypt("HELLOWORLD")
    pt = em.encrypt(ct)  # encryption again recovers plaintext
"""

from typing import Dict, Tuple, List
import string

ALPHABET = string.ascii_uppercase

# Historical rotor wirings (Enigma I)
ROTOR_WIRINGS = {
    'I':   ("EKMFLGDQVZNTOWYHXUSPAIBRCJ", 'Q'),  # turnover Q
    'II':  ("AJDKSIRUXBLHWTMCQGZNPYFVOE", 'E'),
    'III': ("BDFHJLCPRTXVZNYEIWGAKMUSQO", 'V'),
    'IV':  ("ESOVPZJAYQUIRHXLNFTGKDCMWB", 'J'),
    'V':   ("VZBRGITYUPSDNHLXAWMJQOFECK", 'Z'),
}
# Reflector B
REFLECTORS = {
    'B': "YRUHQSLDPXNGOKMIEBFZCWVJAT"
}

def wiring_to_map(wiring: str) -> Dict[str,str]:
    """Map from A->wiring[0], B->wiring[1], ..."""
    return {ALPHABET[i]: wiring[i] for i in range(26)}

def inverse_map(m: Dict[str,str]) -> Dict[str,str]:
    return {v:k for k,v in m.items()}

class Rotor:
    def __init__(self, name: str, ring_setting: int = 1, position: str = 'A'):
        wiring, turnover = ROTOR_WIRINGS[name]
        self.name = name
        self.wiring = wiring_to_map(wiring)
        self.inverse_wiring = inverse_map(self.wiring)
        self.turnover = turnover  # letter at which next rotor steps
        # ring setting (1..26) shifts internal wiring relative to alphabet
        if not (1 <= ring_setting <= 26):
            raise ValueError("ring_setting must be 1..26")
        self.ring = ring_setting - 1
        # position is current rotor window letter
        self.position = position.upper()
    def at_turnover(self) -> bool:
        return self.position == self.turnover
    def step(self):
        # advance rotor position by 1
        idx = ALPHABET.index(self.position)
        idx = (idx + 1) % 26
        self.position = ALPHABET[idx]
    def forward(self, ch: str) -> str:
        """
        Signal entering rotor from right to left.
        Takes into account ring setting and rotor position.
        """
        # convert to 0..25 index relative to rotor
        p = ALPHABET.index(ch)
        offset_in = (p + ALPHABET.index(self.position) - self.ring) % 26
        # map through wiring
        wired = self.wiring[ALPHABET[offset_in]]
        offset_out = (ALPHABET.index(wired) - ALPHABET.index(self.position) + self.ring) % 26
        return ALPHABET[offset_out]
    def backward(self, ch: str) -> str:
        # reverse direction
        p = ALPHABET.index(ch)
        offset_in = (p + ALPHABET.index(self.position) - self.ring) % 26
        wired = self.inverse_wiring[ALPHABET[offset_in]]
        offset_out = (ALPHABET.index(wired) - ALPHABET.index(self.position) + self.ring) % 26
        return ALPHABET[offset_out]

class Plugboard:
    def __init__(self, pairs: List[str] = None):
        self.map = {ch: ch for ch in ALPHABET}
        if pairs:
            for pair in pairs:
                if len(pair) != 2:
                    continue
                a,b = pair[0].upper(), pair[1].upper()
                self.map[a] = b
                self.map[b] = a
    def swap(self, ch: str) -> str:
        return self.map.get(ch, ch)

class EnigmaMachine:
    def __init__(self, rotor_names: Tuple[str,str,str] = ('I','II','III'),
                 ring_settings: Tuple[int,int,int] = (1,1,1),
                 positions: Tuple[str,str,str] = ('A','A','A'),
                 reflector_name: str = 'B',
                 plugboard_pairs: List[str] = None):
        # instantiate rotors: left, middle, right ordering
        left = Rotor(rotor_names[0], ring_settings[0], positions[0])
        middle = Rotor(rotor_names[1], ring_settings[1], positions[1])
        right = Rotor(rotor_names[2], ring_settings[2], positions[2])
        self.rotors = [left, middle, right]
        self.reflector = wiring_to_map(REFLECTORS[reflector_name])
        self.plugboard = Plugboard(plugboard_pairs)

    def _step_rotors(self):
        # Implement Enigma stepping with double-step:
        # If middle at turnover -> left and middle step (middle double-step)
        # If right at turnover -> middle steps
        left, middle, right = self.rotors
        # check double-step condition
        if middle.at_turnover():
            middle.step()
            left.step()
        elif right.at_turnover():
            middle.step()
        # right always steps
        right.step()

    def encrypt_char(self, ch: str) -> str:
        if not ch.isalpha():
            return ch
        ch_u = ch.upper()
        # step before processing
        self._step_rotors()
        # plugboard in
        p = self.plugboard.swap(ch_u)
        # forward through rotors right->left
        signal = p
        for rotor in reversed(self.rotors):
            signal = rotor.forward(signal)
        # reflector
        signal = self.reflector[signal]
        # backward through rotors left->right
        for rotor in self.rotors:
            signal = rotor.backward(signal)
        # plugboard out
        out = self.plugboard.swap(signal)
        return out if ch.isupper() else out.lower()

    def enigma_encrypt(self, text: str) -> str:
        out = []
        for ch in text:
            out.append(self.encrypt_char(ch))
        return "".join(out)

# Demo / CLI
if __name__ == "__main__":
    em = EnigmaMachine(rotor_names=('I','II','III'),
                       ring_settings=(1,1,1),
                       positions=('A','A','A'),
                       reflector_name='B',
                       plugboard_pairs=['AD','CN','ET'])
    plaintext = "HELLOWORLD"
    print("Plaintext:", plaintext)
    ciphertext = em.enigma_encrypt(plaintext)
    print("Ciphertext:", ciphertext)
    
    # to decrypt: create machine with same settings and encrypt ciphertext
    em2 = EnigmaMachine(rotor_names=('I','II','III'),
                       ring_settings=(1,1,1),
                       positions=('A','A','A'),
                       reflector_name='B',
                       plugboard_pairs=['AD','CN','ET'])
    recovered = em2.enigma_encrypt(ciphertext)
    print("Recovered:", recovered)
