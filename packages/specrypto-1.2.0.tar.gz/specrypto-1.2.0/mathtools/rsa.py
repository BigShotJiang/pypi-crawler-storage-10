#!/usr/bin/env python3
# rsa_problems.py
# Self-contained RSA utilities and solutions for the three problems.

import random
import math
import sys
from typing import Tuple, Optional

# -------------------------
# Number theory utilities
# -------------------------

def is_probable_prime(n: int, k: int = 12) -> bool:
    """Miller-Rabin primality test (probabilistic)."""
    if n < 2:
        return False
    small_primes = [2,3,5,7,11,13,17,19,23,29]
    for p in small_primes:
        if n % p == 0:
            return n == p
    # write n-1 as d * 2^s
    d = n - 1
    s = 0
    while d % 2 == 0:
        d >>= 1
        s += 1
    for _ in range(k):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        composite = True
        for __ in range(s - 1):
            x = (x * x) % n
            if x == n - 1:
                composite = False
                break
        if composite:
            return False
    return True

def pollard_rho(n: int) -> int:
    """Pollard Rho factorization (returns a non-trivial factor of n)."""
    if n % 2 == 0:
        return 2
    if is_probable_prime(n):
        return n
    while True:
        # polynomial: f(x) = x^2 + c
        x = random.randrange(2, n-1)
        y = x
        c = random.randrange(1, n-1)
        d = 1
        while d == 1:
            x = (x*x + c) % n
            y = (y*y + c) % n
            y = (y*y + c) % n
            d = math.gcd(abs(x - y), n)
            if d == n:
                break
        if d > 1 and d < n:
            return d

def factorize(n: int) -> Tuple[int,int]:
    """Return (p,q) prime factors of n (p <= q). Works for semiprimes up to medium size."""
    if n <= 1:
        raise ValueError("n must be > 1")
    if is_probable_prime(n):
        return (1, n)  # prime, not semiprime
    a = pollard_rho(n)
    b = n // a
    # ensure prime factors
    if not is_probable_prime(a):
        a = factorize(a)[0]
    if not is_probable_prime(b):
        b = factorize(b)[1] if factorize(b)[0] != 1 else b
    p, q = min(a,b), max(a,b)
    return p, q

def egcd(a: int, b: int):
    """Extended GCD."""
    if b == 0:
        return (a, 1, 0)
    g, x1, y1 = egcd(b, a % b)
    return (g, y1, x1 - (a // b) * y1)

def modinv(a: int, m: int) -> int:
    g, x, y = egcd(a, m)
    if g != 1:
        raise ValueError(f"No modular inverse for {a} mod {m}, gcd = {g}")
    return x % m

def int_to_bytes(n: int) -> bytes:
    """Big-endian integer to bytes (no leading zero bytes)."""
    if n == 0:
        return b'\x00'
    out = bytearray()
    while n:
        out.append(n & 0xff)
        n >>= 8
    return bytes(reversed(out))

def bytes_to_int(b: bytes) -> int:
    return int.from_bytes(b, 'big')

# -------------------------
# RSA functions
# -------------------------

def rsa_decrypt_with_factors(c: int, p: int, q: int, e: int) -> Tuple[int, bytes, str]:
    """Given ciphertext c and the factors p,q and public exponent e, return (m, bytes, decoded_string)."""
    n = p * q
    phi = (p-1)*(q-1)
    d = modinv(e, phi)
    m = pow(c, d, n)
    m_bytes = int_to_bytes(m)
    try:
        text = m_bytes.decode('utf-8')
    except Exception:
        # fallback: latin-1 to show raw bytes
        text = m_bytes.decode('latin-1', errors='replace')
    return m, m_bytes, text

def rsa_encrypt_message(message: str, e: int, n: int) -> int:
    m = bytes_to_int(message.encode('utf-8'))
    if m >= n:
        raise ValueError("Message integer >= modulus n (too long for single-block RSA). Use padding or smaller message.")
    return pow(m, e, n)

# -------------------------
# Problem-specific solvers
# -------------------------

def solve_problem_1():
    # Problem 1: given n, e, ciphertext, find plaintext
    n = 712446816787
    e = 6551
    c = 273095689186
    print("Problem 1:")
    print(f" n = {n}")
    print(f" e = {e}")
    print(f" c = {c}")
    # factor n
    print(" Factoring n ...")
    p,q = factorize(n)
    print(f" Found factors p = {p}, q = {q}")
    m, m_bytes, text = rsa_decrypt_with_factors(c, p, q, e)
    print(f" Decrypted integer m = {m}")
    print(f" m as bytes (hex) = {m_bytes.hex()}")
    print(f" m interpreted as text: {repr(text)}")
    print()
    return (p,q,m,text)

def factor_using_d(n: int, e: int, d: int, max_tries: int = 50) -> Optional[Tuple[int,int]]:
    """
    Factor n given e and d, using known method:
      k = e*d - 1 which is multiple of phi(n).
    Find t and r with k = 2^t * r (r odd).
    Then pick random g and compute y = g^r mod n, and do repeated squaring
    to try to find nontrivial square root of 1 modulo n -> factor.
    """
    k = e * d - 1
    if k % 2 == 1:
        return None
    # write k = 2^s * r
    s = 0
    r = k
    while r % 2 == 0:
        r //= 2
        s += 1
    # try random bases
    for attempt in range(max_tries):
        g = random.randrange(2, n-1)
        y = pow(g, r, n)
        if y == 1 or y == n - 1:
            continue
        for j in range(s):
            x = pow(y, 2, n)
            if x == 1:
                # gcd(y-1, n) is a nontrivial factor
                factor = math.gcd(y-1, n)
                if factor != 1 and factor != n:
                    p = factor
                    q = n // factor
                    return (min(p,q), max(p,q))
                else:
                    break
            y = x
            if y == n - 1:
                break
    return None

def solve_problem_2():
    # Problem 2: n, e, d are given; factor n
    # Clean up n if spaces given
    n_str = "71854 8065 9737455 07"
    n = int(n_str.replace(" ", ""))
    e = 3449
    d = 543546506135745129
    print("Problem 2:")
    print(f" n = {n}")
    print(f" e = {e}")
    print(f" d = {d}")
    print(" Attempting to factor n using (e,d) ...")
    result = factor_using_d(n, e, d, max_tries=200)
    if result is None:
        print(" Failed to factor n with the method (tried many random bases).")
        return None
    p, q = result
    print(f" Success: p = {p}, q = {q}")
    # quick check
    if p*q != n:
        print(" Warning: p*q != n (unexpected).")
    else:
        print(" Verified p*q == n.")
    print()
    return (p,q)

def solve_problem_3():
    # Problem 3: choose two 30-digit primes p and q and exponent e, encrypt given plaintexts
    # 30-digit primes -> between 10^29 and 10^30 - 1
    lo = 10**29
    hi = 10**30 - 1
    # find prime by random search + MR test
    def find_30_digit_prime():
        while True:
            candidate = random.randrange(lo, hi)
            # ensure odd
            if candidate % 2 == 0:
                candidate += 1
            if is_probable_prime(candidate):
                return candidate

    print("Problem 3:")
    print(" Generating two 30-digit primes (these will be random each run) ...")
    p = find_30_digit_prime()
    q = find_30_digit_prime()
    while q == p:
        q = find_30_digit_prime()
    n = p * q
    e = 65537  # standard choice
    print(f" p (30-digit) = {p}")
    print(f" q (30-digit) = {q}")
    print(f" n = p*q has {n.bit_length()} bits and {len(str(n))} decimal digits")
    print(f" e = {e}")
    plaintexts = ["cat", "bat", "hat", "encyclopedia", "antidisestabliskmentarianism"]
    print()
    ciphertexts = []
    for m in plaintexts:
        try:
            c = rsa_encrypt_message(m, e, n)
        except ValueError:
            # message too long -> notify and skip
            print(f" Message '{m}' is too long for single-block RSA (m >= n). Skipping.")
            c = None
        ciphertexts.append((m, c))
    print("Ciphertexts (integer values):")
    for m, c in ciphertexts:
        if c is None:
            print(f"  '{m}': [message too long for single-block RSA]")
        else:
            print(f"  '{m}': {c}")
            print(f"    length dec digits: {len(str(c))}, bit-length: {c.bit_length()}")
    print()
    print("Observations / Notes:")
    print(" - 'cat', 'bat', 'hat' differ as plaintext strings by one letter,")
    print("   but RSA encryption without deterministic padding (text as integer then pow) will produce ciphertexts")
    print("   that do not reveal simple single-letter changes in any obvious way. Their ciphertext integers will")
    print("   likely be unrelated in numeric value (no small Hamming-distance relation), so you cannot reliably tell")
    print("   which differ by one letter just by looking at raw ciphertext integers.")
    print(" - The longer plaintexts (encyclopedia, antidisestabliskmentarianism) produce larger integer messages")
    print("   (more bytes -> larger integer), so their ciphertext integers will typically have more decimal digits/bit-length")
    print("   — but since ciphertext is reduced mod n, if n's size is much larger than message integer, you can see that ciphertexts")
    print("   corresponding to longer messages generally produce larger message integers before encryption. However,")
    print("   if messages approach or exceed n (or if padding is used), this property may not hold. Proper RSA usage uses padding")
    print("   (e.g., OAEP) which masks message length and content.")
    print()
    return (p,q,n,e,ciphertexts)

# -------------------------
# Main execution
# -------------------------

if __name__ == "__main__":
    random.seed(0xC0FFEE)  # deterministic-ish for demonstration (change or remove in real use)
    # Problem 1
    try:
        p1,q1,m1,text1 = solve_problem_1()
    except Exception as exc:
        print("Problem 1 error:", exc)
        sys.exit(1)
    # Problem 2
    try:
        p2q2 = solve_problem_2()
        if p2q2 is None:
            print("Problem 2: factoring failed.")
        else:
            p2, q2 = p2q2
    except Exception as exc:
        print("Problem 2 error:", exc)
        sys.exit(1)
    # Problem 3
    try:
        p3,q3,n3,e3,ciphertexts3 = solve_problem_3()
    except Exception as exc:
        print("Problem 3 error:", exc)
        sys.exit(1)
