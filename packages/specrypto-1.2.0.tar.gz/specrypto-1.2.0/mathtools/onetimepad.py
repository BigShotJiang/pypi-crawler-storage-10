# =============================================
# One-Time Pad (OTP) Cipher Implementation
# =============================================

import numpy as np
import random
import string

# ---------------- Helper Functions ----------------

def generate_key(length):
    """
    Generates a truly random key for the given plaintext length.
    Each character is randomly selected from uppercase alphabets.
    """
    letters = string.ascii_uppercase
    return ''.join(random.choice(letters) for _ in range(length))


def text_to_numbers(text):
    """Convert A-Z text to list of numbers (A=0, B=1, ..., Z=25)."""
    return np.array([ord(ch) - 65 for ch in text.upper() if ch.isalpha()])


def numbers_to_text(nums):
    """Convert list of numbers (0-25) back to uppercase letters."""
    return ''.join(chr((n % 26) + 65) for n in nums)


# ---------------- Core OTP Functions ----------------

def onetimepad_encrypt(plaintext, key=None):
    """
    Encrypts plaintext using One-Time Pad.
    If key is not given, generates a random one of same length.
    """
    # Clean plaintext (A-Z only)
    plaintext = ''.join(ch for ch in plaintext.upper() if ch.isalpha())
    pt_nums = text_to_numbers(plaintext)

    # Generate key if not provided
    if key is None:
        key = generate_key(len(plaintext))
    
    key_nums = text_to_numbers(key)

    # Encryption: (plaintext + key) mod 26
    ct_nums = (pt_nums + key_nums) % 26
    ciphertext = numbers_to_text(ct_nums)

    return ciphertext, key


def onetimepad_decrypt(ciphertext, key):
    """
    Decrypts ciphertext using given One-Time Pad key.
    """
    ciphertext = ''.join(ch for ch in ciphertext.upper() if ch.isalpha())
    ct_nums = text_to_numbers(ciphertext)
    key_nums = text_to_numbers(key)

    # Decryption: (ciphertext - key) mod 26
    pt_nums = (ct_nums - key_nums) % 26
    plaintext = numbers_to_text(pt_nums)

    return plaintext


# ---------------- Demo Execution ----------------
if __name__ == "__main__":
    print("=== ONE TIME PAD CIPHER ===\n")

    plaintext = input("Enter plaintext (A-Z only): ").upper()
    mode = input("Enter mode (1 = auto-generate key, 2 = provide key): ")

    if mode == "1":
        ciphertext, key = encrypt(plaintext)
    else:
        key = input("Enter key (same length as plaintext): ").upper()
        ciphertext, _ = encrypt(plaintext, key)

    print(f"\nGenerated/Used Key: {key}")
    print(f"Ciphertext: {ciphertext}")

    decrypted = decrypt(ciphertext, key)
    print(f"Decrypted:  {decrypted}")
