import socket

HOST = '127.0.0.1'  # Same as server
PORT = 65432        # Same port as server

# Create a TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect((HOST, PORT))
print(f"Connected to server at {HOST}:{PORT}")

while True:
    msg = input("Client: ")
    if msg.lower() == "exit":
        break
    client_socket.sendall(msg.encode())

    data = client_socket.recv(1024)
    print(f"Server: {data.decode()}")

client_socket.close()
