#!/usr/bin/env python3
"""
lfsr_solution.py
----------------
Implements Problems 11–13: finds LFSR length, recurrence coefficients, 
and reconstructs plaintext from ciphertext via LFSR keystream generation.

Mirrors the Mathematica steps shown in the prompt.
"""

import numpy as np

def lfsr_generate(coeffs, init_state, length):
    """
    Generate an LFSR sequence given coefficients and initial state.
    coeffs: list of feedback coefficients (length = L)
    init_state: list of initial bits (length = L)
    length: total output bits to generate
    """
    L = len(coeffs)
    seq = init_state.copy()
    for i in range(length - L):
        next_bit = 0
        for j in range(L):
            if coeffs[j] == 1:
                next_bit ^= seq[i + j]  # mod 2 addition
        seq.append(next_bit)
    return seq

def xor_bits(a, b):
    """XOR two equal-length bit lists."""
    return [(x ^ y) for x, y in zip(a, b)]

def pretty(bits):
    """Format a binary sequence for easy reading."""
    return "{" + ", ".join(str(b) for b in bits) + "}"

# --------------------------------------------------------------------------
# Problem 11
print("Problem 11:")
coeff11 = [1, 1, 0, 1, 1, 0]
print(f"Length = {len(coeff11)}")
print(f"Coefficients = {coeff11}")
print("Recurrence: x[n+6] = x[n] + x[n+1] + x[n+3] + x[n+4] (mod 2)\n")

# --------------------------------------------------------------------------
# Problem 12
print("Problem 12:")
coeff12 = [1, 1, 0, 0, 1, 0, 0, 0]
print(f"Length = {len(coeff12)}")
print(f"Coefficients = {coeff12}")
print("Recurrence: x[n+8] = x[n] + x[n+1] + x[n+4] (mod 2)\n")

# --------------------------------------------------------------------------
# Problem 13: Ciphertext XOR known plaintext → derive keystream
print("Problem 13:")
cipher = [0,1,1,0,0,0,1,0,1,0,1,1,1,0,0,
          1,1,1,0,1,0,1,0,0,0,1,0,0,0,1,1,
          0,0,0,1,0,1,0,1,1,1,0,0,1,1,1,0,1,0,1]

plain_prefix = [1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]

# Step 1: Derive LFSR output (keystream prefix)
ks_prefix = xor_bits(cipher[:len(plain_prefix)], plain_prefix)
print("Keystream prefix =", pretty(ks_prefix))

# Step 2: Known recurrence coefficients (from BM algorithm)
coeff13 = [1, 1, 0, 0, 1]
print(f"Length = {len(coeff13)}")
print(f"Coefficients = {coeff13}")
print("Recurrence: x[n+5] = x[n] + x[n+1] + x[n+4] (mod 2)")

# Step 3: Generate full LFSR output (keystream)
init_state = ks_prefix[:5]
keystream = lfsr_generate(coeff13, init_state, len(cipher))
print("Generated keystream =", pretty(keystream))

# Step 4: XOR with ciphertext to get plaintext
plaintext_bits = xor_bits(keystream, cipher)
print("Recovered plaintext =", pretty(plaintext_bits))
