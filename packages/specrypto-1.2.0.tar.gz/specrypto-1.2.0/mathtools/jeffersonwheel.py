# jefferson_wheel.py
"""
Jefferson (Bazeries) Wheel Cipher
- The system uses multiple wheels (each a permutation of A-Z).
- Key consists of:
    - wheel_order: list of indices indicating which wheels in which order are stacked
    - wheel_positions: starting rotational offsets for each wheel
- Encryption:
    - For each plaintext letter, we combine the letter indices with wheel letters (classic approach: choose row by wheel states).
    - Here we implement a straightforward variant:
        ciphertext letter = (plaintext_index + sum(current_wheel_shifts)) mod 26, but mapping through wheel alphabets
- Decryption reverses the operations.
This file provides:
    generate_wheels(num_wheels, seed)
    encrypt(plaintext, wheels, wheel_order, wheel_positions, step_mode='rotate_right')
    decrypt(ciphertext, wheels, wheel_order, wheel_positions, step_mode='rotate_right')

Note: Jefferson wheel historically used table lookup and chosen row; modern implementations vary.
This implementation offers a deterministic usable scheme for learning/demonstration.
"""

import string
import random
from typing import List, Tuple

ALPHABET = string.ascii_uppercase
M = len(ALPHABET)

def generate_wheels(num_wheels: int, seed: int = None) -> List[str]:
    """Generate num_wheels random wheel permutations deterministically by seed."""
    rnd = random.Random(seed)
    wheels = []
    base = list(ALPHABET)
    for i in range(num_wheels):
        arr = base.copy()
        rnd.shuffle(arr)
        wheels.append("".join(arr))
    return wheels

def wheel_char_at(wheel: str, pos: int) -> str:
    pos %= M
    return wheel[pos]

def wheel_index_of(wheel: str, ch: str) -> int:
    return wheel.index(ch)

def _advance_positions(positions: List[int], step_mode: str = 'rotate_right'):
    """
    Advance wheel positions after each plaintext char.
    step_mode: 'rotate_right' => increment first wheel; cascade carry to next on wrap.
               'rotate_all' => increment all by 1
    """
    if step_mode == 'rotate_all':
        for i in range(len(positions)):
            positions[i] = (positions[i] + 1) % M
    else:
        # simulate mechanical carry: increment first, if wraps then increment second, etc.
        i = 0
        positions[0] = (positions[0] + 1) % M
        while i < len(positions) - 1 and positions[i] == 0:
            i += 1
            positions[i] = (positions[i] + 1) % M

def jefferson_encrypt(plaintext: str, wheels: List[str], wheel_order: List[int], wheel_positions: List[int], step_mode: str = 'rotate_right') -> str:
    """
    Encrypt plaintext.
    - wheels: list of wheel strings (permutations of A-Z)
    - wheel_order: indices selecting order of wheels (len = k)
    - wheel_positions: starting offsets (len = k)
    - step_mode: stepping behavior
    """
    k = len(wheel_order)
    assert len(wheel_positions) == k
    positions = wheel_positions.copy()
    out = []
    for ch in plaintext:
        if not ch.isalpha():
            out.append(ch)
            continue
        is_upper = ch.isupper()
        ch_u = ch.upper()
        # Map letter through each wheel in sequence using current positions
        # We use index transformation variant: start with plaintext index p
        p = ALPHABET.index(ch_u)
        # combine by mapping p through wheel_i at offset positions[i]
        cur = p
        for i, widx in enumerate(wheel_order):
            wheel = wheels[widx]
            pos = positions[i]
            # find wheel character at offset pos corresponding to alphabet index cur
            # translate to letter then find its index in standard alphabet
            letter_on_wheel = wheel[(pos + cur) % M]
            cur = ALPHABET.index(letter_on_wheel)
        # final output letter is ALPHABET[cur]
        out_ch = ALPHABET[cur]
        out.append(out_ch if is_upper else out_ch.lower())
        # advance wheel positions
        _advance_positions(positions, step_mode=step_mode)
    return "".join(out)

def jefferson_decrypt(ciphertext: str, wheels: List[str], wheel_order: List[int], wheel_positions: List[int], step_mode: str = 'rotate_right') -> str:
    """
    Decrypt by reversing the wheel mapping order and reversing each wheel mapping at current positions.
    Must use same wheel_order and initial positions & stepping.
    """
    k = len(wheel_order)
    positions = wheel_positions.copy()
    out = []
    for ch in ciphertext:
        if not ch.isalpha():
            out.append(ch)
            continue
        is_upper = ch.isupper()
        ch_u = ch.upper()
        cur = ALPHABET.index(ch_u)
        # reverse through wheels in reverse order
        for i in reversed(range(k)):
            widx = wheel_order[i]
            wheel = wheels[widx]
            pos = positions[i]
            # at this wheel, the mapping was: index -> wheel[(pos+index)%M]
            # to reverse: find index such that wheel[(pos+index)%M] == letter
            # equivalently find index = (index_of(letter in wheel) - pos) mod M
            idx_in_wheel = wheel.index(ALPHABET[cur])
            cur = (idx_in_wheel - pos) % M
        out_ch = ALPHABET[cur]
        out.append(out_ch if is_upper else out_ch.lower())
        _advance_positions(positions, step_mode=step_mode)
    return "".join(out)

# Demo
if __name__ == "__main__":
    wheels = generate_wheels(8, seed=42)
    wheel_order = [0,1,2]         # use first three wheels
    wheel_positions = [0,5,10]    # starting offsets
    pt = "Defend the east wall at dawn!"
    print("Plain:", pt)
    ct = encrypt(pt, wheels, wheel_order, wheel_positions, step_mode='rotate_right')
    print("Cipher:", ct)
    pt2 = decrypt(ct, wheels, wheel_order, wheel_positions, step_mode='rotate_right')
    print("Recovered:", pt2)
