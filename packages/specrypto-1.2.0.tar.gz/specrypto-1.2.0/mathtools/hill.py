#!/usr/bin/env python3
"""
Correct Hill-cipher decryption with orientation check.

Given ciphertext "zirkzuopjjoptfapuhfhadrq" and key matrix K,
this script computes the modular inverse of K exactly (no float),
then tries both common conventions (column-vector and row-vector)
and prints results. The row-vector convention matches the Mathematica
steps and yields "jackandjillwentupthehill".
"""

from itertools import product

ALPHABET = "abcdefghijklmnopqrstuvwxyz"
MOD = 26

def txt2num0(s):
    return [ord(ch) - ord('a') for ch in s.lower() if ch.isalpha()]

def num2txt0(nums):
    return ''.join(chr((int(n) % MOD) + ord('a')) for n in nums)

# Integer determinant recursion (safe, exact)
def determinant_mod(mat, mod=MOD):
    # mat is a list-of-lists or nested sequence
    n = len(mat)
    # base cases
    if n == 1:
        return int(mat[0][0] % mod)
    if n == 2:
        a,b = mat[0][0], mat[0][1]
        c,d = mat[1][0], mat[1][1]
        return int(((a*d - b*c) % mod))
    det = 0
    for c in range(n):
        # build minor excluding row 0, col c
        minor = [[mat[r][cc] for cc in range(n) if cc != c] for r in range(1,n)]
        cofactor = ((-1) ** c) * mat[0][c] * determinant_mod(minor, mod)
        det += cofactor
    return int(det % mod)

def matrix_minor(mat, i, j):
    n = len(mat)
    return [[mat[r][c] for c in range(n) if c != j] for r in range(n) if r != i]

def mod_matrix_inverse(K, mod=MOD):
    """
    Compute inverse of integer matrix K modulo mod.
    Returns inverse matrix Inv such that (K * Inv) % mod == Identity.
    Uses integer cofactors/adjugate and modular inverse of determinant.
    """
    n = len(K)
    det = determinant_mod(K, mod)
    det_int = int(det)  # ensure Python int
    # modular inverse of determinant
    try:
        det_inv = pow(det_int, -1, mod)
    except ValueError as e:
        raise ValueError(f"Determinant {det_int} has no inverse mod {mod}") from e

    # build cofactor matrix
    cof = [[0]*n for _ in range(n)]
    for r in range(n):
        for c in range(n):
            minor = matrix_minor(K, r, c)
            minor_det = determinant_mod(minor, mod)
            cof[r][c] = ((-1) ** (r + c) * minor_det) % mod

    # adjugate = transpose of cofactor matrix
    adj = [[cof[c][r] % mod for c in range(n)] for r in range(n)]

    # inverse = det_inv * adj (mod)
    Inv = [[(det_inv * adj[r][c]) % mod for c in range(n)] for r in range(n)]
    return Inv

def mat_vec_mul(mat, vec, mod=MOD):
    n = len(mat)
    return [sum(mat[r][c] * vec[c] for c in range(n)) % mod for r in range(n)]

def row_vec_mat_mul(row, mat, mod=MOD):
    n = len(mat)
    return [sum(row[c] * mat[c][r] for c in range(n)) % mod for r in range(n)]

def decrypt_try_both(ciphertext, K):
    nums = txt2num0(ciphertext)
    n = len(K)
    # sanity check length multiple of n
    if len(nums) % n != 0:
        # pad with 'x' (23) to multiple of n
        pad_len = (-len(nums)) % n
        nums += [23]*pad_len

    Inv = mod_matrix_inverse(K, MOD)

    plaintext_by_column = []
    plaintext_by_row = []

    # process blocks
    for i in range(0, len(nums), n):
        block = nums[i:i+n]
        # Convention A: column vectors, p = Inv * c
        # Represent block as column vector (list), multiply Inv (matrix) with column
        p_col = mat_vec_mul(Inv, block, MOD)  # Inv · c_column
        plaintext_by_column.extend(p_col)

        # Convention B: row vectors, p_row = c_row · Inv
        # Represent block as row vector and multiply row * Inv
        p_row = row_vec_mat_mul(block, Inv, MOD)  # c_row · Inv
        plaintext_by_row.extend(p_row)

    return num2txt0(plaintext_by_column), num2txt0(plaintext_by_row), Inv

if __name__ == "__main__":
    K = [
        [1,2,3,4],
        [4,3,2,1],
        [11,2,4,6],
        [2,9,6,4]
    ]
    ciphertext = "zirkzuopjjoptfapuhfhadrq"

    col_plain, row_plain, Inv = decrypt_try_both(ciphertext, K)
    print("Inverse matrix (mod 26):")
    for row in Inv:
        print(row)
    print("\nDecrypted using column-vector convention (p = K^-1 · c):")
    print(col_plain)
    print("\nDecrypted using row-vector convention (p_row = c_row · K^-1):")
    print(row_plain)

    # If the row-vector output is English words, print that as chosen result:
    if "jack" in row_plain or "jill" in row_plain:
        print("\nSelected (row-vector) plaintext (matches known solution):")
        print(row_plain)
    else:
        print("\nNeither output matches expected English, check inputs / key matrix.")
