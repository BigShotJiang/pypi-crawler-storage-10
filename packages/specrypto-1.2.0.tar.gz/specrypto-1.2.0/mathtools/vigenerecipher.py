# vigenere_cipher.py
import numpy as np
import pandas as pd
import string
from mathtools import mod_add,mod_sub

# -----------------------------------------------------
# Utility Setup
# -----------------------------------------------------

ALPHABET = string.ascii_uppercase
N = len(ALPHABET)

# Create mappings for A↔0, B↔1, etc.
char_to_index = {ch: i for i, ch in enumerate(ALPHABET)}
index_to_char = {i: ch for i, ch in enumerate(ALPHABET)}


# -----------------------------------------------------
# Vigenère Tableau Generator (using Pandas)
# -----------------------------------------------------

def generate_vigenere_tableau() -> pd.DataFrame:
    """Generate and return a 26×26 Vigenère tableau as a pandas DataFrame"""
    data = []
    for r in range(N):
        row = [ALPHABET[mod_add(c, r, N)] for c in range(N)]
        data.append(row)
    df = pd.DataFrame(data, index=list(ALPHABET), columns=list(ALPHABET))
    return df


# -----------------------------------------------------
# Key Expansion
# -----------------------------------------------------

def expand_key(plaintext: str, key: str) -> str:
    """Repeat key to match plaintext length (ignoring non-letters)"""
    key = key.upper()
    expanded = ""
    j = 0
    for ch in plaintext:
        if ch.isalpha():
            expanded += key[j % len(key)]
            j += 1
        else:
            expanded += ch
    return expanded


# -----------------------------------------------------
# Encryption
# -----------------------------------------------------

def vigenere_encrypt(plaintext: str, key: str) -> str:
    plaintext = plaintext.upper()
    key_expanded = expand_key(plaintext, key)
    ciphertext = ""

    for p, k in zip(plaintext, key_expanded):
        if p.isalpha():
            p_idx = char_to_index[p]
            k_idx = char_to_index[k]
            c_idx = mod_add(p_idx, k_idx, N)
            ciphertext += index_to_char[c_idx]
        else:
            ciphertext += p

    return ciphertext


# -----------------------------------------------------
# Decryption
# -----------------------------------------------------

def vigenere_decrypt(ciphertext: str, key: str) -> str:
    ciphertext = ciphertext.upper()
    key_expanded = expand_key(ciphertext, key)
    plaintext = ""

    for c, k in zip(ciphertext, key_expanded):
        if c.isalpha():
            c_idx = char_to_index[c]
            k_idx = char_to_index[k]
            p_idx = mod_sub(c_idx, k_idx, N)
            plaintext += index_to_char[p_idx]
        else:
            plaintext += c

    return plaintext


# -----------------------------------------------------
# Demo / Test Section
# -----------------------------------------------------

if __name__ == "__main__":
    key = "LEMON"
    plaintext = "ATTACK AT DAWN"

    print("Plaintext:", plaintext)
    print("Key:", key)
    print("\n--- Generating Vigenère Tableau ---")
    tableau = generate_vigenere_tableau()
    print(tableau.head())  # print top 5 rows for compactness

    ct = vigenere_encrypt(plaintext, key)
    print("\nEncrypted Ciphertext:", ct)

    pt = vigenere_decrypt(ct, key)
    print("Decrypted Plaintext:", pt)
