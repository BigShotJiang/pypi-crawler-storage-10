# diffie_hellman.py

from secrets import SystemRandom
from mathtools import mod_exp, generate_large_prime, primitive_roots, gcd

_sysrand = SystemRandom()


def dh_generate_params(bits: int = 2048):
    """Generate Diffie-Hellman parameters: large prime p and generator g."""
    if bits < 32:
        raise ValueError("bits must be >= 32")

    p = generate_large_prime(bits)

    roots = primitive_roots(p)
    if not roots:
        # fallback search if no primitive_roots returned
        for g_candidate in range(2, min(200, p - 1)):
            if gcd(g_candidate, p) == 1 and mod_exp(g_candidate, p - 1, p) == 1:
                roots = [g_candidate]
                break
        if not roots:
            raise RuntimeError("Failed to find generator")

    g = roots[0]
    return p, g


def dh_generate_private(p: int):
    """Private key a: random integer < p"""
    return _sysrand.randrange(2, p - 2)


def dh_generate_public(p: int, g: int, private: int):
    """Public key A = g^a mod p"""
    return mod_exp(g, private, p)


def dh_compute_shared(p: int, peer_public: int, private: int):
    """Shared secret = B^a mod p"""
    return mod_exp(peer_public, private, p)

print("=== Diffie-Hellman demo (small bits) ===")
dh = dh_generate_params(bits=256)
p = dh["p"]; g = dh["g"]
a = dh_generate_private(p)
b = dh_generate_private(p)
A = dh_public_from_private(g, a, p)
B = dh_public_from_private(g, b, p)
s1 = dh_shared_secret(B, a, p)
s2 = dh_shared_secret(A, b, p)
print("p (bits) =", p.bit_length(), "g =", g)
print("Shared equal:", s1 == s2)
