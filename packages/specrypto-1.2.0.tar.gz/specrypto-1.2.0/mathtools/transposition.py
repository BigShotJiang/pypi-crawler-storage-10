# =============================================
# Transposition Cipher (Single Columnar)
# =============================================

import math
import numpy as np
from mathtools import min_num, max_num  # optional utility reuse

def _create_matrix(text, key_len, pad_char='X'):
    """
    Create a matrix from text with given key length (number of columns)
    """
    rows = math.ceil(len(text) / key_len)
    padded_text = text.ljust(rows * key_len, pad_char)
    matrix = [list(padded_text[i:i + key_len]) for i in range(0, len(padded_text), key_len)]
    return np.array(matrix)

def trans_encrypt(plaintext, key):
    """
    Encrypts plaintext using a columnar transposition cipher.
    key: permutation string (e.g. '3142' or 'HACK')
    """
    plaintext = plaintext.replace(" ", "").upper()
    key_order = sorted(list(key))
    key_indices = [key.index(k) for k in key_order]
    matrix = _create_matrix(plaintext, len(key))
    
    ciphertext = ''.join(''.join(matrix[:, i]) for i in key_indices)
    return ciphertext

def trans_decrypt(ciphertext, key):
    """
    Decrypts ciphertext using columnar transposition cipher.
    """
    ciphertext = ciphertext.replace(" ", "").upper()
    key_order = sorted(list(key))
    key_indices = [key.index(k) for k in key_order]
    cols = len(key)
    rows = math.ceil(len(ciphertext) / cols)
    
    # Create an empty matrix and fill column-wise
    matrix = [[''] * cols for _ in range(rows)]
    col_length = rows
    k = 0
    for idx in key_indices:
        for r in range(rows):
            if k < len(ciphertext):
                matrix[r][idx] = ciphertext[k]
                k += 1
    plaintext = ''.join([''.join(row) for row in matrix]).rstrip('X')
    return plaintext

# ---------- Demo ----------
if __name__ == "__main__":
    pt = input("Enter plaintext: ")
    key = input("Enter key (e.g. HACK): ")
    ct = encrypt(pt, key)
    print("Ciphertext:", ct)
    print("Decrypted:", decrypt(ct, key))
