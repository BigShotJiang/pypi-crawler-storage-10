# alberti_disk.py
"""
Alberti Cipher (disk-based substitution)
- Outer disk: standard alphabet A-Z (fixed)
- Inner disk: scrambled alphabet determined by a key or keyword
- Encryption maps plaintext letter (inner disk) -> outer disk at current rotation
- Decryption maps outer -> inner
- Optional step parameter rotates inner disk after each character to provide polyalphabetic behavior.

API:
    encrypt(plaintext, keyword, start_shift=0, step=1)
    decrypt(ciphertext, keyword, start_shift=0, step=1)

Example:
    python alberti_disk.py
"""

import string
import random
from typing import Tuple

ALPHABET = string.ascii_uppercase

def keyword_to_inner_disk(keyword: str) -> str:
    """Generate inner disk order from keyword (letters unique) then remaining alphabet."""
    kw = "".join([c for c in keyword.upper() if c.isalpha()])
    seen = set()
    order = []
    for ch in kw:
        if ch not in seen:
            seen.add(ch)
            order.append(ch)
    for ch in ALPHABET:
        if ch not in seen:
            order.append(ch)
    return "".join(order)

def rotate_disk(disk: str, shift: int) -> str:
    shift %= len(disk)
    return disk[shift:] + disk[:shift]

def _prepare_text(text: str) -> str:
    return text

def alberti_encrypt_char(ch: str, outer: str, inner: str, encode: bool=True) -> str:
    """Map single character. encode=True maps inner->outer, encode=False outer->inner."""
    if not ch.isalpha():
        return ch
    is_upper = ch.isupper()
    ch_u = ch.upper()
    if encode:
        # find index in inner, output char from outer
        idx = inner.index(ch_u)
        res = outer[idx]
    else:
        idx = outer.index(ch_u)
        res = inner[idx]
    return res if is_upper else res.lower()

def alberti_encrypt(plaintext: str, keyword: str, start_shift: int = 0, step: int = 1) -> str:
    """
    Encrypt plaintext using Alberti disk.
    - keyword: determines inner disk order
    - start_shift: initial rotation (inner disk rotated by start_shift relative to outer)
    - step: how much to rotate inner disk after processing each letter (0 => static)
    """
    inner = keyword_to_inner_disk(keyword)
    outer = ALPHABET
    inner = rotate_disk(inner, start_shift)
    out = []
    for ch in plaintext:
        out_ch = alberti_encrypt_char(ch, outer, inner, encode=True)
        out.append(out_ch)
        # rotate inner disk by step only when encryption consumed a letter
        if ch.isalpha():
            inner = rotate_disk(inner, step)
    return "".join(out)

def alberti_decrypt(ciphertext: str, keyword: str, start_shift: int = 0, step: int = 1) -> str:
    """
    Decrypt ciphertext: symmetric with encrypt but mapping reversed.
    Must use same keyword/start_shift/step used for encryption.
    """
    inner = keyword_to_inner_disk(keyword)
    outer = ALPHABET
    inner = rotate_disk(inner, start_shift)
    out = []
    for ch in ciphertext:
        out_ch = alberti_encrypt_char(ch, outer, inner, encode=False)
        out.append(out_ch)
        if ch.isalpha():
            inner = rotate_disk(inner, step)
    return "".join(out)

# CLI demo
if __name__ == "__main__":
    kw = "FORTIFICATION"
    pt = "Attack at dawn! Meet at 09:00."
    print("Keyword:", kw)
    print("Plaintext:", pt)
    ct = encrypt(pt, kw, start_shift=3, step=1)
    print("Ciphertext:", ct)
    pt2 = decrypt(ct, kw, start_shift=3, step=1)
    print("Recovered:", pt2)
