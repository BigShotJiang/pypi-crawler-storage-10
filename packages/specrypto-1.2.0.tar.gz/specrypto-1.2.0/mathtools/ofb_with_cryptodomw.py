# ofb_mode.py
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import os

BLOCK_SIZE = 16  # 128-bit AES block

def aes_ofb_encrypt(plaintext: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-OFB mode encryption using Cryptodome (Option C)
    AES block cipher internally runs in ECB for feedback.
    """
    cipher = AES.new(key, AES.MODE_ECB)
    iv_current = iv
    ciphertext = b""

    for i in range(0, len(plaintext), BLOCK_SIZE):
        iv_current = cipher.encrypt(iv_current)
        block = plaintext[i:i+BLOCK_SIZE]
        ciphertext += bytes(a ^ b for a, b in zip(block, iv_current))
    
    return ciphertext

def aes_ofb_decrypt(ciphertext: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-OFB decryption: identical process as encryption.
    """
    return aes_ofb_encrypt(ciphertext, key, iv)  # OFB = symmetrical process

if __name__ == "__main__":
    key = os.urandom(16)  # 128-bit key
    iv  = os.urandom(16)
    plaintext = b"Hello OFB Mode AES with Cryptodome!"

    print("Plain:", plaintext)
    ct = aes_ofb_encrypt(plaintext, key, iv)
    print("Cipher:", ct.hex())
    pt = aes_ofb_decrypt(ct, key, iv)
    print("Decrypted:", pt)
