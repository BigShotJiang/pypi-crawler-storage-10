# affine_algorithms.py
import string
from mathtools import extended_euclidean , gcd # make sure mathtools.py is in the same directory / import path

ALPHABET = string.ascii_uppercase  # default A-Z

def _modinv(a: int, m: int) -> int:
    """Modular inverse using mathtools.extended_euclidean (returns x such that a*x ≡ 1 (mod m))."""
    g, x, _ = extended_euclidean(a, m)
    if g != 1:
        raise ValueError(f"No modular inverse for a={a} mod {m} (gcd={g}).")
    return x % m

def affine_encrypt(plaintext: str, a: int, b: int, alphabet: str = ALPHABET) -> str:
    """
    Affine encryption: E(x) = (a*x + b) mod m
    - preserves case for letters in `alphabet`
    - leaves other characters unchanged
    """
    m = len(alphabet)
    # validate 'a'
    if gcd(a, m) != 1:
        raise ValueError(f"Invalid 'a'={a}: gcd(a, m) must be 1 (m={m}).")

    idx_up = {ch: i for i, ch in enumerate(alphabet)}
    idx_low = {ch.lower(): i for i, ch in enumerate(alphabet)}

    out = []
    for ch in plaintext:
        if ch in idx_up:
            x = idx_up[ch]
            y = (a * x + b) % m
            out.append(alphabet[y])
        elif ch in idx_low:
            x = idx_low[ch]
            y = (a * x + b) % m
            out.append(alphabet[y].lower())
        else:
            out.append(ch)
    return "".join(out)

def affine_decrypt(ciphertext: str, a: int, b: int, alphabet: str = ALPHABET) -> str:
    """
    Affine decryption: D(y) = a_inv * (y - b) mod m
    - preserves case for letters in `alphabet`
    - leaves other characters unchanged
    """
    m = len(alphabet)
    if gcd(a, m) != 1:
        raise ValueError(f"Invalid 'a'={a}: gcd(a, m) must be 1 (m={m}).")

    a_inv = _modinv(a, m)
    idx_up = {ch: i for i, ch in enumerate(alphabet)}
    idx_low = {ch.lower(): i for i, ch in enumerate(alphabet)}

    out = []
    for ch in ciphertext:
        if ch in idx_up:
            y = idx_up[ch]
            x = (a_inv * (y - b)) % m
            out.append(alphabet[x])
        elif ch in idx_low:
            y = idx_low[ch]
            x = (a_inv * (y - b)) % m
            out.append(alphabet[x].lower())
        else:
            out.append(ch)
    return "".join(out)

a, b = 5, 8
pt = "Attack at dawn!"
ct = affine_encrypt(pt, a, b)
print(ct)                 # encrypted
print(affine_decrypt(ct, a, b))  # should print original