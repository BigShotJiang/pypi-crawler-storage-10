# =============================================
# Number Theory + Modular Arithmetic + Matrix Arithmetic
# =============================================

import numpy as np
import random
import math
from math import gcd
from typing import List, Tuple, Optional, Dict


# ---------- Utility Functions ----------

def max_num(a, b):
    return a if a > b else b

def min_num(a, b):
    return a if a < b else b

def is_zero(a):
    return a == 0

def is_negative(a):
    return a < 0


# ---------- GCD and Euclidean Algorithms ----------

def gcd(a, b):
    a, b = abs(a), abs(b)
    while b != 0:
        a, b = b, a % b
    return a

def euclidean_gcd(a, b):
    a, b = abs(a), abs(b)
    if b == 0:
        return a
    return euclidean_gcd(b, a % b)

def extended_euclidean(a, b):
    if b == 0:
        return (a, 1, 0)
    else:
        g, x1, y1 = extended_euclidean(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return (g, x, y)


# ---------- Modular Arithmetic ----------

def mod_add(a, b, m):
    return (a + b) % m

def mod_sub(a, b, m):
    return (a - b) % m

def mod_mul(a, b, m):
    return (a * b) % m

def mod_exp(a, b, m):
    result = 1
    a = a % m
    while b > 0:
        if b % 2 == 1:
            result = (result * a) % m
        a = (a * a) % m
        b //= 2
    return result

def lin_cong(a,b,n):
    n_ques =n
    def inv(a ,n):
        r1 = n
        r2 = a
        t1 = 0
        t2 = 1
        while r2>0:
            q = r1//r2 # integer division 
            r = r1 - q*r2
            r1 = r2
            r2 = r
            t = t1 - q*t2
            t1 = t2
            t2 = t
        if(r1==1):
            return t1
        else:
            return -1
            
        

    d = gcd(a,n)
    if b%d == 0:
        a/=int(d)
        n/=int(d)
        b/=int(d)
        inv_d = int(inv(a,n))
        
        sol=[]
        if(inv_d !=-1):
            x0 =( b * inv_d )%n
            sol.append(x0)        
        for i in range(d-1):
            x = x0 + (i+1)* (n_ques//d)
            sol.append(x)
        return sol
    else:
        
        return -1

def fast_expo(a,x,n):
    y=1
    nb = bin(x)[2:]
    nb = nb[::-1]
    
    for i in nb:
        if i=='1':
            y*=a
            y = y%n
        a*=a
        a = a%n
    return y


# ---------- Linear Diophantine Equation ----------

def solve_linear_diophantine(a, b, c):
    g, x1, y1 = extended_euclidean(a, b)
    if c % g != 0:
        return (False, None, None, g)
    x0 = x1 * (c // g)
    y0 = y1 * (c // g)
    return (True, x0, y0, g)


# ---------- Matrix Arithmetic ----------

def matrix_add(A, B):
    """Matrix addition"""
    return np.add(A, B)

def matrix_sub(A, B):
    """Matrix subtraction"""
    return np.subtract(A, B)

def matrix_mul(A, B):
    """Matrix multiplication"""
    return np.matmul(A, B)

def matrix_transpose(A):
    """Matrix transpose"""
    return np.transpose(A)

def matrix_det(A):
    """Matrix determinant"""
    return round(np.linalg.det(A))

def matrix_inverse(A):
    """Matrix inverse (float values)"""
    return np.linalg.inv(A)


# ---------- Modular Matrix Arithmetic ----------

def matrix_mod(A, m):
    """Apply modulo element-wise"""
    return np.mod(A, m)

def matrix_mod_add(A, B, m):
    """(A + B) mod m"""
    return np.mod(A + B, m)

def matrix_mod_sub(A, B, m):
    """(A - B) mod m"""
    return np.mod(A - B, m)

def matrix_mod_mul(A, B, m):
    """(A * B) mod m"""
    return np.mod(np.matmul(A, B), m)

def matrix_mod_inverse(A, m):
    """
    Modular inverse of matrix A under modulo m.
    Works only if determinant(A) and m are coprime.
    """
    n = A.shape[0]
    det = round(np.linalg.det(A)) % m
    g, x, _ = extended_euclidean(det, m)

    if g != 1:
        raise ValueError("Matrix is not invertible under modulo {}".format(m))

    det_inv = x % m
    adj = np.round(det * np.linalg.inv(A)).astype(int)  # Adjugate
    inv_mod = (det_inv * adj) % m
    return inv_mod



# ---------- Euler's Totient Function ----------
def euler_totient(n):
    """Compute Euler's Totient φ(n)"""
    result = n
    p = 2
    while p * p <= n:
        if n % p == 0:
            while n % p == 0:
                n //= p
            result -= result // p
        p += 1
    if n > 1:
        result -= result // n
    return result


# ---------- Fermat's Little Theorem ----------
def fermat_little_theorem(a, p):
    """
    Fermat's Little Theorem:
    If p is prime and a is not divisible by p,
    then a^(p-1) ≡ 1 (mod p)
    """
    if p <= 1:
        raise ValueError("p must be prime and > 1")
    if a % p == 0:
        raise ValueError("a must not be divisible by p")
    return mod_exp(a, p - 1, p) == 1


# ---------- Euler's Theorem ----------
def eulers_theorem(a, n):
    """
    Euler's Theorem:
    If gcd(a, n) = 1 then a^φ(n) ≡ 1 (mod n)
    """
    if gcd(a, n) != 1:
        raise ValueError("a and n must be coprime")
    phi_n = euler_totient(n)
    return mod_exp(a, phi_n, n)


# ---------- Chinese Remainder Theorem ----------
def chinese_remainder_theorem(n_list, a_list):
    """
    Solve system of congruences using CRT:
        x ≡ a1 (mod n1)
        x ≡ a2 (mod n2)
        ...
    Returns smallest positive x satisfying all.
    """
    if len(n_list) != len(a_list):
        raise ValueError("Length mismatch between moduli and remainders")

    N = 1
    for n in n_list:
        N *= n

    result = 0
    for n_i, a_i in zip(n_list, a_list):
        N_i = N // n_i
        g, inv, _ = extended_euclidean(N_i, n_i)
        if g != 1:
            raise ValueError("Moduli are not pairwise coprime")
        result += a_i * inv * N_i

    return result % N
def _egcd_inv(a: int, m: int) -> int:
    """
    Return modular inverse of a modulo m using extended_euclidean from this module.
    Raises ValueError if inverse doesn't exist (i.e. gcd != 1).
    """
    g, x, _ = extended_euclidean(a, m)
    if g != 1:
        raise ValueError(f"No inverse for {a} mod {m} (gcd={g})")
    return x % m

def _combine_two_congruences(n1: int, a1: int, n2: int, a2: int) -> Optional[Tuple[int,int]]:
    """
    Combine two congruences:
        x ≡ a1 (mod n1)
        x ≡ a2 (mod n2)
    Returns (x, lcm) where x is the smallest non-negative solution modulo lcm = lcm(n1, n2),
    or None if no solution exists.
    """
    # normalize residues
    a1 = a1 % n1
    a2 = a2 % n2

    # gcd and check consistency
    g = gcd(n1, n2)
    diff = a2 - a1
    if diff % g != 0:
        return None  # no solution

    # reduce the equation: n1 * t ≡ (a2 - a1) (mod n2)
    # divide through by g
    n1_g = n1 // g
    n2_g = n2 // g
    rhs = (diff // g) % n2_g

    # compute inverse of n1_g mod n2_g
    # use extended_euclidean to obtain inv
    # inv = inverse(n1_g) mod n2_g
    g2, inv, _ = extended_euclidean(n1_g, n2_g)
    if g2 != 1:
        # theoretically should be 1 because we divided by gcd, but guard anyway
        return None
    inv = inv % n2_g

    t = (rhs * inv) % n2_g
    x = a1 + n1 * t
    lcm = (n1 // g) * n2  # = n1 * n2_g

    x = x % lcm
    return (x, lcm)


def generalized_crt(n_list: List[int], a_list: List[int]) -> Optional[Tuple[int,int]]:
    """
    Solve system of congruences:
        x ≡ a_i (mod n_i)  for i in 0..k-1
    Works when moduli are not pairwise coprime; returns smallest non-negative solution x
    and the combined modulus M (so solutions are x (mod M)).
    If no solution exists (inconsistent system) returns None.

    Example:
        generalized_crt([3,4,5], [2,3,1]) -> (11, 60)
    """
    if len(n_list) != len(a_list):
        raise ValueError("n_list and a_list must be same length")

    # start with the first congruence
    x, m = a_list[0] % n_list[0], n_list[0]

    for ni, ai in zip(n_list[1:], a_list[1:]):
        res = _combine_two_congruences(m, x, ni, ai)
        if res is None:
            return None
        x, m = res  # update to combined congruence

    return (x % m, m)


def crt_rsa_combine(mp: int, p: int, mq: int, q: int) -> Tuple[int,int]:
    """
    Convenience for RSA: combine
        m ≡ mp (mod p)
        m ≡ mq (mod q)
    Returns (m_mod_n, n) where n = p*q and m_mod_n is the unique solution modulo n,
    assuming consistency (which should hold if mp ≡ mq (mod gcd(p, q)) — typically p and q are primes).
    """
    res = _combine_two_congruences(p, mp, q, mq)
    if res is None:
        raise ValueError("No solution for given RSA residues (inconsistent).")
    m_mod_n, lcm = res
    # lcm should be p*q when p and q are distinct primes
    return (m_mod_n, lcm)

# -------------------------------------------------------------
# PRIMALITY TESTS AND PRIME UTILITIES
# -------------------------------------------------------------

def is_prime_basic(n: int) -> bool:
    """Simple deterministic check for small n."""
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True


def miller_rabin(n: int, k: int = 40) -> bool:
    """
    Miller-Rabin primality test.
    Returns True if n is probably prime, False if composite.
    k = number of rounds (accuracy increases exponentially with k).
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False

    # Write n - 1 as 2^r * d with d odd
    r, d = 0, n - 1
    while d % 2 == 0:
        d //= 2
        r += 1

    # Test k random bases
    for _ in range(k):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)  # modular exponentiation
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False  # composite
    return True  # probably prime


def is_prime(n: int) -> bool:
    """
    Hybrid primality test:
    - For small n, uses is_prime_basic
    - For large n, uses Miller-Rabin
    """
    if n < 2_000_000:
        return is_prime_basic(n)
    else:
        return miller_rabin(n, 40)


# -------------------------------------------------------------
# PRIME GENERATION (for RSA and other crypto)
# -------------------------------------------------------------

def generate_large_prime(bits: int = 512) -> int:
    """
    Generate a random prime number of given bit size using Miller-Rabin test.
    Suitable for RSA key generation.
    """
    assert bits >= 8, "Bit length too small"
    while True:
        # Generate random odd number with given bits
        candidate = random.getrandbits(bits) | (1 << bits - 1) | 1
        if miller_rabin(candidate, 50):
            return candidate


def generate_prime_pair(bits: int = 512) -> tuple[int, int]:
    """
    Generate two distinct large primes of specified bit size.
    Useful for RSA (p, q).
    """
    p = generate_large_prime(bits)
    q = generate_large_prime(bits)
    while q == p:
        q = generate_large_prime(bits)
    return p, q


# -------------------------------------------------------------
# PRIME TABLE & N-th PRIME GENERATOR
# -------------------------------------------------------------

def sieve_of_eratosthenes(limit: int) -> np.ndarray:
    """
    Efficiently generate all primes ≤ limit using NumPy sieve.
    """
    sieve = np.ones(limit + 1, dtype=bool)
    sieve[:2] = False  # 0 and 1 not prime
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i:limit + 1:i] = False
    return np.nonzero(sieve)[0]


def nth_prime(n: int) -> int:
    """
    Return the nth prime number (1-indexed).
    Uses dynamic limit estimation and sieve.
    """
    if n < 1:
        raise ValueError("n must be ≥ 1")

    # Approximation for n-th prime upper bound
    if n < 6:
        limit = 15
    else:
        limit = int(n * (math.log(n) + math.log(math.log(n)))) + 10

    primes = sieve_of_eratosthenes(limit)
    while len(primes) < n:  # if we underestimated
        limit *= 2
        primes = sieve_of_eratosthenes(limit)
    return int(primes[n - 1])


# -------------------------------------------------------------
# RSA-RELATED UTILITIES
# -------------------------------------------------------------

def generate_rsa_modulus(bits: int = 512) -> tuple[int, int, int]:
    """
    Generate (n, p, q) where n = p * q for given bit size.
    """
    p, q = generate_prime_pair(bits)
    n = p * q
    return n, p, q


def next_prime(n: int) -> int:
    """Return the next prime greater than n."""
    if n < 2:
        return 2
    candidate = n + 1 if n % 2 == 0 else n + 2
    while not is_prime(candidate):
        candidate += 2
    return candidate


def previous_prime(n: int) -> int:
    """Return the previous prime less than n."""
    if n <= 2:
        raise ValueError("No prime less than 2")
    candidate = n - 1 if n % 2 == 0 else n - 2
    while candidate > 1 and not is_prime(candidate):
        candidate -= 2
    return candidate
# -------------------------------------------------------------
# Multiplicative Group (Z/nZ)^x utilities
# -------------------------------------------------------------

def multiplicative_group(n: int) -> List[int]:
    """
    Return the list of elements of the multiplicative group (Z/nZ)^x,
    i.e. the integers in [1, n-1] that are coprime to n.
    """
    n = int(n)
    if n <= 1:
        return []
    return [a for a in range(1, n) if gcd(a, n) == 1]


def group_order(n: int) -> int:
    """Order (size) of multiplicative group = phi(n)."""
    return euler_totient(n)


def element_order(a: int, n: int) -> int:
    """
    Return multiplicative order of a modulo n (smallest k>0 such that a^k ≡ 1 (mod n)).
    If gcd(a,n) != 1, raises ValueError.
    """
    a, n = int(a) % int(n), int(n)
    if gcd(a, n) != 1:
        raise ValueError(f"Element {a} is not in multiplicative group modulo {n}")
    phi = group_order(n)
    # factor phi to test divisors efficiently
    factors = _prime_factors(phi)
    # compute all divisors of phi in ascending order
    divisors = sorted(_divisors_from_factors(factors))
    for d in divisors:
        if mod_exp(a, d, n) == 1:
            return d
    # fallback
    return phi


def orders_of_elements(n: int):
    """Return dict mapping each element in multiplicative group to its order."""
    elements = multiplicative_group(n)
    return {a: element_order(a, n) for a in elements}


def is_generator(a: int, n: int) -> bool:
    """
    Check if a is a primitive root modulo n (generator of the multiplicative group).
    Primitive roots exist only for n in {1,2,4,p^k,2*p^k} where p is an odd prime.
    This function returns False if generator does not exist for n.
    """
    a, n = int(a) % int(n), int(n)
    if gcd(a, n) != 1:
        return False
    if not _has_primitive_root(n):
        return False
    phi = group_order(n)
    pf = set(_prime_factors(phi))
    for p in pf:
        if mod_exp(a, phi // p, n) == 1:
            return False
    return True


def primitive_roots(n: int) -> List[int]:
    """
    Return list of all primitive roots modulo n (may be empty if none exist).
    For large n this can be expensive; use with caution.
    """
    if n <= 2:
        return [1] if n == 2 else []
    if not _has_primitive_root(n):
        return []
    phi = group_order(n)
    roots = []
    for a in range(1, n):
        if is_generator(a, n):
            roots.append(a)
    return roots


def multiplication_table(n: int):
    """Return multiplication table (mapping (a,b)->(a*b mod n)) for group elements."""
    elems = multiplicative_group(n)
    table = {}
    for a in elems:
        for b in elems:
            table[(a, b)] = (a * b) % n
    return table


def multiplication_table_matrix(n: int) -> Tuple[List[int], np.ndarray]:
    """Return (elements_list, matrix) where matrix[i,j] = (elem_i * elem_j) mod n."""
    elems = multiplicative_group(n)
    m = len(elems)
    mat = np.zeros((m, m), dtype=int)
    for i, a in enumerate(elems):
        for j, b in enumerate(elems):
            mat[i, j] = (a * b) % n
    return elems, mat


def element_inverse(a: int, n: int) -> int:
    """Return multiplicative inverse of a modulo n. Raises ValueError if not invertible."""
    return _egcd_inv(a, n)


def division_mod(a: int, b: int, n: int) -> int:
    """Return a / b modulo n (i.e. a * b^{-1} mod n)."""
    inv_b = element_inverse(b, n)
    return (a * inv_b) % n


# ----------------- Helper functions for multiplicative group -----------------

def _prime_factors(n: int) -> List[int]:
    n = int(n)
    factors = []
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        factors.append(n)
    return factors


def _divisors_from_factors(factors: List[int]) -> List[int]:
    """Given prime factor list (with multiplicity), return all divisors."""
    if not factors:
        return [1]
    # convert to factor->exp map
    fm = {}
    for p in factors:
        fm[p] = fm.get(p, 0) + 1
    primes = list(fm.items())

    def gen(idx: int) -> List[int]:
        if idx == len(primes):
            return [1]
        p, e = primes[idx]
        rest = gen(idx + 1)
        out = []
        for k in range(e + 1):
            out += [ (p ** k) * r for r in rest ]
        return out

    return gen(0)


def _has_primitive_root(n: int) -> bool:
    """
    Check whether multiplicative group modulo n is cyclic (i.e., primitive roots exist).
    Truth: primitive roots exist for n in {1,2,4, p^k, 2*p^k} where p is an odd prime.
    """
    n = int(n)
    if n in (1, 2, 4):
        return True
    # remove factors of 2
    m = n
    cnt2 = 0
    while m % 2 == 0:
        m //= 2
        cnt2 += 1
    # now m is odd
    if cnt2 == 0:
        # n is odd: primitive root exists iff n is p^k
        # check if m is a power of a single odd prime
        pf = _prime_factors(m)
        if not pf:
            return False
        return len(set(pf)) == 1
    elif cnt2 == 1:
        # n = 2 * m where m is odd. primitive root exists iff m is p^k (odd prime power)
        if m == 1:
            return True  # n == 2
        pf = _prime_factors(m)
        return len(set(pf)) == 1
    else:
        # n divisible by 4 and >4 cannot have primitive root unless n==4
        return False


# ----------------- Niceties / user-facing summary functions -----------------

def multiplicative_group_summary(n: int):
    """
    Produce a summary dictionary with keys:
      - 'n': modulus
      - 'elements': sorted list of group elements
      - 'group_order': phi(n)
      - 'orders': dict element -> order
      - 'primitive_roots': list of primitive roots (may be empty)
      - 'is_cyclic': boolean
    """
    n = int(n)
    elements = multiplicative_group(n)
    phi = group_order(n)
    orders = orders_of_elements(n)
    roots = primitive_roots(n)
    summary = {
        'n': n,
        'elements': elements,
        'group_order': phi,
        'orders': orders,
        'primitive_roots': roots,
        'is_cyclic': len(roots) > 0
    }
    return summary
# -------------------------------------------------------------



# ---------- Demo Section ----------

if __name__ == "__main__":
    g,inva,invb=extended_euclidean(299,81)
    if g==1:
        print(f"inverse Exists" )
    else:
        print(None)
        
        
    print("===== Matrix Arithmetic =====")
    A = np.array([[2, 3], [1, 4]])
    B = np.array([[5, 6], [7, 8]])

    print("A =\n", A)
    print("B =\n", B)
    print("\nA + B =\n", matrix_add(A, B))
    print("A - B =\n", matrix_sub(A, B))
    print("A * B =\n", matrix_mul(A, B))
    print("Transpose(A) =\n", matrix_transpose(A))
    print("Determinant(A) =", matrix_det(A))
    print("Inverse(A) =\n", matrix_inverse(A))

    print("\n===== Modular Matrix Arithmetic =====")
    m = 4
    print(f"Modulo = {m}")
    print("(A + B) mod m =\n", matrix_mod_add(A, B, m))
    print("(A - B) mod m =\n", matrix_mod_sub(A, B, m))
    print("(A * B) mod m =\n", matrix_mod_mul(A, B, m))
    try:
        print("Inverse(A) mod m =\n", matrix_mod_inverse(A, m))
    except ValueError as e:
        print("Error:", e)
    print("Fermat:", fermat_little_theorem(3, 7))  # True, since 3^6 ≡ 1 mod 7
    
    # Euler’s Theorem
    print("Euler:", eulers_theorem(3, 10))  # 3^4 ≡ 1 mod 10

    # CRT Example
    n = [3, 4, 5]
    a = [2, 3, 1]
    print("CRT result:", chinese_remainder_theorem(n, a))  # x ≡ 11 mod 60
    
    #to test Generalised CRT
    n_list = [3, 4]
    a_list = [2, 3]  # x ≡ 2 (mod 3), x ≡ 3 (mod 4) -> x=11 mod 12
    print("CRT example (2 eq):", generalized_crt(n_list, a_list))  # (11, 12)

    # Example 2: three congruences (pairwise coprime)
    n_list = [3, 4, 5]
    a_list = [2, 3, 1]  # -> x ≡ 11 (mod 60)
    print("CRT example (3 eq):", generalized_crt(n_list, a_list))  # (11, 60)

    # Example 3: non-coprime moduli but consistent
    n_list = [6, 8]      # gcd(6,8)=2
    a_list = [4, 6]      # x ≡ 4 (mod 6), x ≡ 6 (mod 8) -> has solution x=10 (mod 24)
    print("CRT example non-coprime consistent:", generalized_crt(n_list, a_list))  # (10,24)

    # Example 4: inconsistent system
    n_list = [6, 8]
    a_list = [3, 6]  # no solution because 3 ≡? 6 (mod gcd(6,8)=2) fails
    print("CRT inconsistent:", generalized_crt(n_list, a_list))  # None

    # Example 5: RSA combine (p, q primes)
    p = 11
    q = 13
    n = p * q
    # suppose true message m = 123 -> residues:
    m_true = 123
    mp = m_true % p
    mq = m_true % q
    m_combined, mod_n = crt_rsa_combine(mp, p, mq, q)
    print("RSA combine:", (m_combined, mod_n, m_combined == (m_true % n)))
    print("Small primes up to 30:", sieve_of_eratosthenes(30))
    print("10th prime:", nth_prime(10))
    print("Next prime after 1000:", next_prime(1000))
    print("Previous prime before 1000:", previous_prime(1000))

    print("\nTesting Miller-Rabin:")
    for n in [2, 3, 5, 17, 19, 25, 561, 1105, 1009]:
        print(f"{n} -> {miller_rabin(n)}")

    print("\nGenerating 128-bit prime (for demo):")
    prime = generate_large_prime(128)
    print("Prime:", prime)
    print("Prime test:", miller_rabin(prime))

    print("\nRSA modulus test:")
    n, p, q = generate_rsa_modulus(64)
    print(f"p={p}\nq={q}\nn={n} \n")
    
    print("Multiplicative group modulo 10:")
    print(multiplicative_group_summary(10))

    print("\nMultiplicative group modulo 11 (prime):")
    s = multiplicative_group_summary(11)
    print('group_order=', s['group_order'])
    print('primitive_roots (first 8):', s['primitive_roots'][:8])

    print("\nOrders mod 13:")
    print(orders_of_elements(13))

    print("\nCheck primitive root 2 mod 13:", is_generator(2,13))
    print("2^5 mod 13 =", mod_exp(2,5,13))

    # multiplication table example
    elems, mat = multiplication_table_matrix(7)
    print('\nElements mod 7:', elems)
    print('Multiplication table (mod 7) shape:', mat.shape)
    