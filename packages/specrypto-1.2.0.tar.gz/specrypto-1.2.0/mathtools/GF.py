#GF.py
from functools import reduce

def gf_addition(poly1,poly2):
    num1 = int(poly1,2)
    num2 = int(poly2,2)
    #gf_n = int(input("Enter the n of GF(2^n): "))
    
    result = num1 ^ num2
    return bin(result)[2:]

def gf_subtraction(poly1,poly2):
    return gf_addition(poly1,poly2)

def gf_multiplication(poly1,poly2):
    def bit_equalizer(str1,nbit):
        return '0'*(nbit - len(str1))+str1
        
    
    min_poly= poly1 if len(poly1)<=len(poly2) else poly2
    max_poly= poly1 if len(poly1)>len(poly2) else poly2
    min_num_iter= len(poly1)
    gf_n=8
#     poly1= poly1 if len(poly1)>=len(poly2) else '0'*(len(poly2)-len(poly1))+poly1
#     poly2= poly2 if len(poly2)>=len(poly1) else '0'*(len(poly1)-len(poly2))+poly2
    poly1= bit_equalizer(poly1,gf_n)
    poly2= bit_equalizer(poly2,gf_n)
    
    num1 = int(poly1,2)
    num2 = int(poly2,2)
    #mod = input("Enter the coefficients of the irreducible polynomial: ")
    mod= '100011011'
    #min_num_iter = len(bin(num1 if num1<=num2 else num2)[2:])
    prev_res = max_poly
    result = [prev_res]
    
    
        
    for i in range(1,min_num_iter):
        if prev_res.startswith('1'):
            shifted=int((prev_res + '0')[1:],2)
            prev_res = bit_equalizer(bin(shifted ^int(mod[1:],2))[2:],gf_n)
        else:
            shifted = int(prev_res,2)<<1
            prev_res = bit_equalizer(bin(shifted)[2:],gf_n)
        result.append(prev_res)
        
    xor_list = [int(result[min_num_iter-1-i],2) for i in range(min_num_iter) if min_poly[i]=='1']
    final = reduce(lambda x,y : x^y , xor_list)
    return (final,bin(final))


def gf_division(poly1,poly2):
    dividend = poly1 if len(poly1)>=len(poly2) else poly2
    divisor = poly1 if len(poly1)<len(poly2) else poly2
    quotient = list('0'*len(dividend))
    def deg(str1):
        str1=str1.lstrip('0')
        return len(str1)-1
    quot =[]
        
    if int(divisor,2)==0:
        return -1
    while deg(dividend) >= deg(divisor) :
        temp_divisor =divisor +  '0'*(deg(dividend)-deg(divisor))
        quot.append(deg(dividend)-deg(divisor))
        dividend = bin(int(dividend,2)^int(temp_divisor,2))[2:]
   
    for i in quot:
        quotient[len(quotient)-1-i]='1'
    print(''.join(quotient).lstrip('0'))
    return(dividend, int(dividend,2))

def gf_inverse(poly, mod):
    def gf_multiply_int(a, b, mod):
        result = 0
        while b:
            if b & 1:
                result ^= a
            b >>= 1
            a <<= 1
            if a.bit_length() > mod.bit_length() - 1:
                a ^= mod
        return result

# helper to reduce polynomial
    def gf_mod(a, mod):
        while a.bit_length() >= mod.bit_length():
            shift = a.bit_length() - mod.bit_length()
            a ^= (mod << shift)
        return a
    # Convert to integers
    a = int(poly, 2)
    m = int(mod, 2)

    if a == 0:
        raise ValueError("Zero has no inverse in GF(2^n)")

    # Initialize
    r0, r1 = m, a
    t0, t1 = 0, 1

    # Degree helper
    def degree(x):
        return x.bit_length() - 1

    while r1 != 0:
        # Polynomial division to get quotient q
        q = 0
        temp = r0
        while degree(temp) >= degree(r1):
            shift = degree(temp) - degree(r1)
            q ^= (1 << shift)
            temp ^= (r1 << shift)
        r0, r1 = r1, temp

        # Update t0, t1 (mod 2, so XOR)
        t_new = t0 ^ gf_multiply_int(q, t1, m)
        t0, t1 = t1, t_new

    # After loop: gcd = r0, inverse = t0
    if r0 != 1:
        raise ValueError("Inverse does not exist (not relatively prime)")

    # Reduce mod m
    inv = gf_mod(t0, m)
    return bin(inv)[2:].zfill(len(mod) - 1)
# size1 = int(input("Enter the number of binary digits in polynomial 1: "))
# size2 = int(input("Enter the number of binary digits in polynomial 2: "))

# poly1= input("Enter the coefficients of polynomial 1: ")
# poly2 = input("Enter the coefficients of polynomial 2: ")
#
# poly1 ='100011011'
# poly2= '1000010000100'
print(gf_inverse('101','10011'))
           
        