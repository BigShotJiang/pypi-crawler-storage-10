# aes_block_B.py — Optimized AES-128 using precomputed tables

from Crypto.Cipher import AES

# ✅ Wrapper to match consistent API
def aes_encrypt_block(block16: bytes, key16: bytes) -> bytes:
    if len(block16)!=16 or len(key16)!=16:
        raise ValueError("block/key must be 16B")
    cipher = AES.new(key16, AES.MODE_ECB)
    return cipher.encrypt(block16)
