# =============================================
# Double Transposition Cipher
# =============================================

import math
from transposition import encrypt as single_encrypt, decrypt as single_decrypt

def doubletrans_encrypt(plaintext, key1, key2):
    """
    Double Transposition Cipher Encryption
    Step 1: Encrypt with key1
    Step 2: Encrypt result with key2
    """
    step1 = single_encrypt(plaintext, key1)
    step2 = single_encrypt(step1, key2)
    return step2

def doubletrans_decrypt(ciphertext, key1, key2):
    """
    Double Transposition Cipher Decryption
    Step 1: Decrypt with key2
    Step 2: Decrypt result with key1
    """
    step1 = single_decrypt(ciphertext, key2)
    step2 = single_decrypt(step1, key1)
    return step2

# ---------- Demo ----------
if __name__ == "__main__":
    pt = input("Enter plaintext: ")
    key1 = input("Enter first key (e.g. HACK): ")
    key2 = input("Enter second key (e.g. SAFE): ")
    ct = encrypt(pt, key1, key2)
    print("\nCiphertext:", ct)
    print("Decrypted:", decrypt(ct, key1, key2))
