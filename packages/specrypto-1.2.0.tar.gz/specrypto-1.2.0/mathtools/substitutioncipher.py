import random
import string
from collections import Counter, defaultdict

chars = string.digits+string.punctuation+string.ascii_letters+" "
chars = list(chars)
key = chars.copy()

def subs_encrypt(pt):
    
    ct=""

    for i in pt:
        idx=chars.index(i)
        ct+=key[idx]
    print(ct)
    return ct
    
def subs_decrypt(ct,key):
    pt=""
    for i in ct:
        idx=key.index(i)
        pt+=chars[idx]
    
    print(pt)
    return pt

random.shuffle(key)
pt=input("Enter The input message:")
ct = encrypt(pt)
pt1 = decrypt(ct,key)
