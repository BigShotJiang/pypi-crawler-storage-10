# =============================================
# Keyless Transposition Cipher (Route Cipher)
# =============================================

import numpy as np
import math

def create_matrix(text, cols=5, pad_char='X'):
    """
    Create a matrix filled row-wise with the text.
    Pads with 'X' if text doesn't fill the final row.
    """
    text = text.replace(" ", "").upper()
    rows = math.ceil(len(text) / cols)
    padded_text = text.ljust(rows * cols, pad_char)
    matrix = np.array(list(padded_text)).reshape(rows, cols)
    return matrix

def trans_keyless_encrypt(plaintext, cols=5, direction="column"):
    """
    Encrypts plaintext using keyless transposition.
    
    direction: 'column' or 'row' or 'zigzag'
    """
    matrix = create_matrix(plaintext, cols)
    rows, cols = matrix.shape

    if direction == "column":
        # Read column-wise (top to bottom, left to right)
        ciphertext = ''.join(matrix[r, c] for c in range(cols) for r in range(rows))
    elif direction == "row":
        # Read row-wise (left to right, top to bottom)
        ciphertext = ''.join(matrix[r, c] for r in range(rows) for c in range(cols))
    elif direction == "zigzag":
        # Read row 1 L→R, row 2 R→L, alternating
        ciphertext = ''
        for i, row in enumerate(matrix):
            if i % 2 == 0:
                ciphertext += ''.join(row)
            else:
                ciphertext += ''.join(row[::-1])
    else:
        raise ValueError("Invalid direction. Use 'column', 'row', or 'zigzag'.")
    
    return ciphertext

def trans_keyless_decrypt(ciphertext, cols=5, direction="column"):
    """
    Decrypts ciphertext assuming same pattern used for encryption.
    """
    ciphertext = ciphertext.replace(" ", "").upper()
    total_len = len(ciphertext)
    rows = math.ceil(total_len / cols)

    if direction == "column":
        # Fill column-wise, then read row-wise
        matrix = np.empty((rows, cols), dtype=str)
        idx = 0
        for c in range(cols):
            for r in range(rows):
                if idx < total_len:
                    matrix[r, c] = ciphertext[idx]
                    idx += 1
        plaintext = ''.join(matrix[r, c] for r in range(rows) for c in range(cols))

    elif direction == "row":
        # Fill row-wise, then read row-wise (identity)
        matrix = np.array(list(ciphertext)).reshape(rows, cols)
        plaintext = ''.join(matrix[r, c] for r in range(rows) for c in range(cols))

    elif direction == "zigzag":
        # Fill zigzag row-wise
        matrix = np.empty((rows, cols), dtype=str)
        idx = 0
        for r in range(rows):
            if r % 2 == 0:
                for c in range(cols):
                    if idx < total_len:
                        matrix[r, c] = ciphertext[idx]
                        idx += 1
            else:
                for c in range(cols - 1, -1, -1):
                    if idx < total_len:
                        matrix[r, c] = ciphertext[idx]
                        idx += 1
        plaintext = ''.join(matrix.flatten())

    else:
        raise ValueError("Invalid direction. Use 'column', 'row', or 'zigzag'.")

    return plaintext.rstrip('X')


# ---------- Demo ----------
if __name__ == "__main__":
    pt = input("Enter plaintext: ")
    cols = int(input("Enter number of columns (e.g. 5): "))
    direction = input("Enter direction (column/row/zigzag): ").strip().lower()

    ct = encrypt(pt, cols, direction)
    print(f"\nCiphertext: {ct}")
    print(f"Decrypted:  {decrypt(ct, cols, direction)}")
