# specrypto

`specrypto` is a mathematical and cryptographic toolkit including:
- Number theory
- Modular arithmetic
- Matrix operations
- RSA utilities
- Euler, Fermat, CRT, primality tests, and more.

## 🧠 Installation
```bash
pip install specrypto
```

## ⚡ Usage
```python
import mathtools

print(mathtools.gcd(42, 56))
print(mathtools.euler_totient(36))
```
