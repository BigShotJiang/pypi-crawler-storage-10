from typing import List, Dict, Any
from langgraph.graph import StateGraph, START, END

from ...agent import Agent
from ..state import WorkflowState
from ..nodes import AgentNodeFactory, UtilityNodeFactory

class SupervisorPattern:
    """Supervisor workflow pattern implementations."""
    
    @staticmethod
    def create_supervisor_workflow(supervisor_agent: Agent, worker_agents: List[Agent], 
                                 execution_mode: str = "sequential") -> StateGraph:
        """
        Create a supervisor workflow where a supervisor agent coordinates and delegates tasks 
        to worker agents using specified execution modes.
        
        Args:
            supervisor_agent (Agent): The supervisor agent that coordinates tasks
            worker_agents (List[Agent]): List of worker agents with specialized capabilities
            execution_mode (str): "sequential" or "parallel" execution of workers
            
        Returns:
            StateGraph: Compiled workflow graph
        """
        if not worker_agents:
            raise ValueError("At least one worker agent is required")

        graph = StateGraph(WorkflowState)

        def supervisor_node_with_mode(state: WorkflowState) -> Dict[str, Any]:
            supervisor_node_func = AgentNodeFactory.create_supervisor_agent_node(supervisor_agent, worker_agents)
            supervisor_updates = supervisor_node_func(state)
            updated_metadata = supervisor_updates.get("metadata", state["metadata"]).copy()
            updated_metadata["execution_mode"] = execution_mode
            supervisor_updates["metadata"] = updated_metadata
            return supervisor_updates

        graph.add_node(supervisor_agent.name, supervisor_node_with_mode)
        graph.add_edge(START, supervisor_agent.name)

        if execution_mode == "parallel":
            return SupervisorPattern._create_parallel_supervisor_workflow(
                graph, supervisor_agent, worker_agents)
        else:
            return SupervisorPattern._create_sequential_supervisor_workflow(
                graph, supervisor_agent, worker_agents)
    
    @staticmethod
    def _create_parallel_supervisor_workflow(graph: StateGraph, supervisor_agent: Agent, 
                                           worker_agents: List[Agent]) -> StateGraph:
        """Create parallel supervisor workflow."""
        graph.add_node("parallel_dispatcher", UtilityNodeFactory.create_parallel_dispatcher_node(worker_agents))
        
        for worker in worker_agents:
            graph.add_node(worker.name, AgentNodeFactory.create_worker_agent_node(worker, supervisor_agent))
        
        graph.add_node("result_aggregator", UtilityNodeFactory.create_result_aggregator_node(supervisor_agent))
        
        def supervisor_parallel_route(state: WorkflowState) -> str:
            delegated_agent = state["metadata"].get("delegated_agent")
            if delegated_agent == "PARALLEL":
                return "parallel_dispatcher"
            else:
                return "__end__"
        
        def aggregator_route(state: WorkflowState) -> str:
            return supervisor_agent.name
        
        supervisor_routes = {
            "parallel_dispatcher": "parallel_dispatcher",
            "__end__": END
        }

        graph.add_conditional_edges(supervisor_agent.name, supervisor_parallel_route, supervisor_routes)
        graph.add_edge("parallel_dispatcher", "result_aggregator")
        graph.add_conditional_edges("result_aggregator", aggregator_route, {supervisor_agent.name: supervisor_agent.name})
        
        return graph.compile()
    
    @staticmethod
    def _create_sequential_supervisor_workflow(graph: StateGraph, supervisor_agent: Agent, 
                                             worker_agents: List[Agent]) -> StateGraph:
        """Create sequential supervisor workflow with structured output parsing."""
        for worker in worker_agents:
            graph.add_node(worker.name, AgentNodeFactory.create_worker_agent_node(worker, supervisor_agent))
        
        def supervisor_sequential_route(state: WorkflowState) -> str:
            """Parse structured supervisor output to determine routing."""
            handoff_command = state["metadata"].get("handoff_command", "")
            worker_names = [worker.name for worker in worker_agents]
            
            if handoff_command.startswith("HANDOFF to "):
                target_agent = handoff_command.replace("HANDOFF to ", "").strip()
                if target_agent in worker_names:
                    return target_agent
                else:
                    return "__end__"
            else:
                return "__end__"
        
        def worker_sequential_route(state: WorkflowState) -> str:
            """Workers always route back to supervisor."""
            return supervisor_agent.name
        
        supervisor_routes = {worker.name: worker.name for worker in worker_agents}
        supervisor_routes["__end__"] = END
        worker_routes = {supervisor_agent.name: supervisor_agent.name}

        graph.add_conditional_edges(supervisor_agent.name, supervisor_sequential_route, supervisor_routes)
        for worker in worker_agents:
            graph.add_conditional_edges(worker.name, worker_sequential_route, worker_routes)
        
        return graph.compile()
    
    @staticmethod
    def create_supervisor_with_sequential_execution(supervisor_agent: Agent, worker_agents: List[Agent]) -> StateGraph:
        """Create a supervisor workflow with sequential execution of workers."""
        return SupervisorPattern.create_supervisor_workflow(supervisor_agent, worker_agents, "sequential")
    
    @staticmethod
    def create_supervisor_with_parallel_execution(supervisor_agent: Agent, worker_agents: List[Agent]) -> StateGraph:
        """Create a supervisor workflow with parallel execution of workers."""
        return SupervisorPattern.create_supervisor_workflow(supervisor_agent, worker_agents, "parallel")
