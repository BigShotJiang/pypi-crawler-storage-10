to use this application at its simplest

`pip install radboy==$VERSION`

create a Run.py file and paste the following into it and save
`from radboy import Run`

for lookups to be made possible please explore the in-prompt help text as a populated data file is not yet ready for use comsumption.# Radboy
# Radboy
