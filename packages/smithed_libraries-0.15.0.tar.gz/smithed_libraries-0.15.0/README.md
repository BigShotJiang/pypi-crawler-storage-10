# Libraries

[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Discord](https://img.shields.io/discord/511303648119226382?color=%236d82cc&label=Discord&logo=discord&logoColor=white)](https://discord.gg/gkp6UqEUph)

> Collection of Libraries for the Smithed Ecosystem

## Downloading

You can download it from [Stable](https://smithed.dev/libraries) | [Nightly](https://nightly.link/Smithed-MC/Libraries/workflows/nightly-build/main/packs.zip)<br/>
or<br/>
You can build it from source using the [beet](https://github.com/mcbeet/beet) via the [Contributing](CONTRIBUTING.md) instructions.
