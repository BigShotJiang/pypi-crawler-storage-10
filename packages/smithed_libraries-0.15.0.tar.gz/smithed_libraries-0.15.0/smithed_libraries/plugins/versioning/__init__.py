from .plugin import beet_default

__all__ = ["beet_default"]
