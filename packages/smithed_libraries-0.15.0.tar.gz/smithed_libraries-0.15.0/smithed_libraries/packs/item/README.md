# Item

## Downloading
You can download it from [here](https://smithed.dev/thenuclearnexus/smithed.item)<br/>
or<br/>
You can build it from source using the [beet](https://github.com/mcbeet/beet)
