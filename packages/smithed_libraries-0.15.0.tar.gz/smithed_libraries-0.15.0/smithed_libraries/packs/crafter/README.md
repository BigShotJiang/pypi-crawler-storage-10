<p align="center">
  <img width='50%' src="https://github.com/TheNuclearNexus/smithed/blob/master/public/official_smithed_library.png?raw=true">
</p>

**Smithed Crafter** serves as the end users all in one crafting table! No more having 89 different crafting blocks in your base!
