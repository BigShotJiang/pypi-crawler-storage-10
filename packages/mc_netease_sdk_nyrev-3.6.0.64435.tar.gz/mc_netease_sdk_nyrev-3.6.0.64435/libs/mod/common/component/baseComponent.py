# -*- coding: utf-8 -*-
class BaseComponent(object):
    pass
