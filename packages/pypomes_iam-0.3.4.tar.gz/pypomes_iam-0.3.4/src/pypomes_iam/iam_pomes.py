import secrets
import string
import sys
from cachetools import Cache
from datetime import datetime
from logging import Logger
from pypomes_core import TZ_LOCAL
from typing import Any

from .iam_common import (
    IamServer,
    _register_logger, _post_for_token,
    _get_iam_cache, _get_iam_registry,
    _get_login_timeout, _get_user_data, _get_public_key
)


def register_logger(logger: Logger) -> None:
    """
    Register the logger for IAM operations.

    :param logger: the logger to be registered
    """
    _register_logger(logger=logger)


def user_login(iam_server: IamServer,
               args: dict[str, Any],
               errors: list[str] = None,
               logger: Logger = None) -> dict[str, str]:
    """
    Build the callback URL for redirecting the request to *iam_server*'s authentication page.

    :param iam_server: the reference registered *IAM* server
    :param args: the arguments passed when requesting the service
    :param errors: incidental error messages
    :param logger: optional logger
    :return: the callback URL, with the appropriate parameters, of *None* if error
    """
    # initialize the return variable
    result: dict[str, str] | None = None

    # obtain the optional user's identification
    user_id: str = args.get("user-id") or args.get("user_id") or args.get("login")

    # build the user data
    # ('oauth_state' is a randomly-generated string, thus 'user_data' is always a new entry)
    oauth_state: str = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(16))
    user_data: dict[str, Any] = _get_user_data(iam_server=iam_server,
                                               user_id=oauth_state,
                                               errors=errors,
                                               logger=logger)
    if user_data:
        user_data["login-id"] = user_id
        timeout: int = _get_login_timeout(iam_server=iam_server,
                                          errors=errors,
                                          logger=logger)
        if not errors:
            user_data["login-expiration"] = int(datetime.now(tz=TZ_LOCAL).timestamp()) + timeout if timeout else None
            redirect_uri: str = args.get("redirect-uri")

            # build the login url
            registry: dict[str, Any] = _get_iam_registry(iam_server=iam_server,
                                                         errors=errors,
                                                         logger=logger)
            if registry:
                registry["redirect-uri"] = redirect_uri
                result = {"login-url": (f"{registry["base-url"]}/protocol/openid-connect/auth"
                                        f"?response_type=code&scope=openid"
                                        f"&client_id={registry["client-id"]}"
                                        f"&redirect_uri={redirect_uri}"
                                        f"&state={oauth_state}")}
    return result


def user_logout(iam_server: IamServer,
                args: dict[str, Any],
                errors: list[str] = None,
                logger: Logger = None) -> None:
    """
    Logout the user, by removing all data associating it from *iam_server*'s registry.

    The user is identified by the attribute *user-id*, *user_id*, or "login", provided in *args*.
    If unsuccessful, this operation fails silently, unless an error has ocurred.

    :param iam_server: the reference registered *IAM* server
    :param args: the arguments passed when requesting the service
    :param errors: incidental error messages
    :param logger: optional logger
    """
    # obtain the user's identification
    user_id: str = args.get("user-id") or args.get("user_id") or args.get("login")

    if user_id:
        # retrieve the IAM server's cache storage
        cache: Cache = _get_iam_cache(iam_server=iam_server,
                                      errors=errors,
                                      logger=logger)
        if cache:
            users: dict[str, dict[str, Any]] = cache.get("users") or {}
            if user_id in users:
                users.pop(user_id)
                if logger:
                    logger.debug(msg=f"User '{user_id}' removed from {iam_server}'s registry")


def user_token(iam_server: IamServer,
               args: dict[str, Any],
               errors: list[str] = None,
               logger: Logger = None) -> str:
    """
    Retrieve the authentication token for the user, from *iam_server*.

    The user is identified by the attribute *user-id*, *user_id*, or "login", provided in *args*.

    :param iam_server: the reference registered *IAM* server
    :param args: the arguments passed when requesting the service
    :param errors: incidental error messages
    :param logger: optional logger
    :return: the token for *user_id*, or *None* if error
    """
    # initialize the return variable
    result: str | None = None

    # obtain the user's identification
    user_id: str = args.get("user-id") or args.get("user_id") or args.get("login")

    err_msg: str | None = None
    if user_id:
        user_data: dict[str, Any] = _get_user_data(iam_server=iam_server,
                                                   user_id=user_id,
                                                   errors=errors,
                                                   logger=logger)
        token: str = user_data["access-token"] if user_data else None
        if token:
            access_expiration: int = user_data.get("access-expiration")
            now: int = int(datetime.now(tz=TZ_LOCAL).timestamp())
            if now < access_expiration:
                result = token
            else:
                # access token has expired
                refresh_token: str = user_data["refresh-token"]
                if refresh_token:
                    refresh_expiration = user_data["refresh-expiration"]
                    if now < refresh_expiration:
                        body_data: dict[str, str] = {
                            "grant_type": "refresh_token",
                            "refresh_token": refresh_token
                        }
                        token_data: dict[str, Any] = _post_for_token(iam_server=iam_server,
                                                                     body_data=body_data,
                                                                     errors=errors,
                                                                     logger=logger)
                        if token_data:
                            result = token_data.get("access_token")
                            user_data["access-token"] = result
                            # keep current refresh token if a new one is not provided
                            user_data["refresh-token"] = (token_data.get("refresh_token") or
                                                          body_data.get("refresh_token"))
                            user_data["access-expiration"] = now + token_data.get("expires_in")
                            refresh_expiration: int = user_data.get("refresh_expires_in")
                            user_data["refresh-expiration"] = (now + refresh_expiration) \
                                if refresh_expiration else sys.maxsize
                        else:
                            # refresh token is no longer valid
                            user_data["refresh-token"] = None
                    else:
                        # refresh token has expired
                        err_msg = "Access and refresh tokens expired"
                        if logger:
                            logger.error(msg=err_msg)
                else:
                    err_msg = "Access token expired, no refresh token available"
                    if logger:
                        logger.error(msg=err_msg)
        else:
            err_msg = f"User '{user_id}' not authenticated"
            if logger:
                logger.error(msg=err_msg)
    else:
        err_msg = "User identification not provided"
        if logger:
            logger.error(msg=err_msg)

    if err_msg and isinstance(errors, list):
        errors.append(err_msg)

    return result


def login_callback(iam_server: IamServer,
                   args: dict[str, Any],
                   errors: list[str] = None,
                   logger: Logger = None) -> tuple[str, str] | None:
    """
    Entry point for the callback from *iam_server* via the front-end application, on authentication operation.

    :param iam_server: the reference registered *IAM* server
    :param args: the arguments passed when requesting the service
    :param errors: incidental errors
    :param logger: optional logger
    :return: a tuple containing the reference user identification and the token obtained, or *None* if error
    """
    from .token_pomes import token_validate

    # initialize the return variable
    result: tuple[str, str] | None = None

    # retrieve the users authentication data
    registry: dict[str, Any] = _get_iam_registry(iam_server=iam_server,
                                                 errors=errors,
                                                 logger=logger)
    cache: Cache = registry["cache"] if registry else None
    if cache:
        users: dict[str, dict[str, Any]] = cache.get("users")

        # validate the OAuth2 state
        oauth_state: str = args.get("state")
        user_data: dict[str, Any] | None = None
        if oauth_state:
            for user, data in users.items():
                if user == oauth_state:
                    user_data = data
                    break

        # exchange 'code' for the token
        if user_data:
            expiration: int = user_data["login-expiration"] or sys.maxsize
            if int(datetime.now(tz=TZ_LOCAL).timestamp()) > expiration:
                errors.append("Operation timeout")
            else:
                users.pop(oauth_state)
                code: str = args.get("code")
                body_data: dict[str, Any] = {
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": registry["redirect-uri"]
                }
                now: int = int(datetime.now(tz=TZ_LOCAL).timestamp())
                token_data: dict[str, Any] = _post_for_token(iam_server=iam_server,
                                                             body_data=body_data,
                                                             errors=errors,
                                                             logger=logger)
                # process the token data
                if token_data:
                    token: str = token_data.get("access_token")
                    user_data["access-token"] = token
                    # keep current refresh token if a new one is not provided
                    user_data["refresh-token"] = token_data.get("refresh_token") or body_data.get("refresh_token")
                    user_data["access-expiration"] = now + token_data.get("expires_in")
                    refresh_exp: int = user_data.get("refresh_expires_in")
                    user_data["refresh-expiration"] = (now + refresh_exp) if refresh_exp else sys.maxsize
                    public_key: str = _get_public_key(iam_server=iam_server,
                                                      errors=errors,
                                                      logger=logger)
                    if public_key:
                        recipient_attr = registry["recipient_attr"]
                        login_id = user_data.pop("login-id", None)
                        token_claims: dict[str, dict[str, Any]] = token_validate(token=token,
                                                                                 issuer=registry["base-url"],
                                                                                 recipient_id=login_id,
                                                                                 recipient_attr=recipient_attr,
                                                                                 public_key=public_key,
                                                                                 errors=errors,
                                                                                 logger=logger)
                        if token_claims:
                            token_user: str = token_claims["payload"].get(recipient_attr)
                            result = (token_user, token)
        else:
            msg: str = "Unknown state received"
            if logger:
                logger.error(msg=msg)
            if isinstance(errors, list):
                errors.append(msg)

    return result


def token_exchange(iam_server: IamServer,
                   args: dict[str, Any],
                   errors: list[str] = None,
                   logger: Logger = None) -> dict[str, Any]:
    """
    Requst *iam_server* to issue a token in exchange for the token obtained from another *IAM* server.

    :param iam_server: the reference registered *IAM* server
    :param args: the arguments passed when requesting the service
    :param errors: incidental errors
    :param logger: optional logger
    :return: the data for the new token, or *None* if error
    """
    # initialize the return variable
    result: dict[str, Any] | None = None

    # obtain the user's identification
    user_id: str = args.get("user-id") or args.get("user_id") or args.get("login")

    # retrieve the token to be exchanges
    token: str = args.get("token")

    if user_id and token:
        # HAZARD: only 'IAM_KEYCLOAK' is currently supported
        registry: dict[str, Any] = _get_iam_registry(iam_server=iam_server,
                                                     errors=errors,
                                                     logger=logger)
        if registry:
            body_data: dict[str, str] = {
                "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                "subject_token": token,
                "subject_token_type": "urn:ietf:params:oauth:token-type:access_token",
                "requested_token_type": "urn:ietf:params:oauth:token-type:access_token",
                "audience": registry["client-id"],
                "subject_issuer": "oidc"
            }
            result = _post_for_token(iam_server=IamServer.IAM_KEYCLOAK,
                                     body_data=body_data,
                                     errors=errors,
                                     logger=logger)
    else:
        msg: str = "User identification and token must be provided"
        if logger:
            logger.error(msg=msg)
        if isinstance(errors, list):
            errors.append(msg)

    return result
