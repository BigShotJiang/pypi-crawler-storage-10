import json
from flask import Request, Response, request, jsonify
from logging import Logger
from typing import Any

from .iam_common import IamServer, _get_logger, _get_iam_server
from .iam_pomes import user_login, user_logout, user_token, token_exchange, login_callback


# @flask_app.route(rule=<login_endpoint>,  # JUSBR_ENDPOINT_LOGIN
#                  methods=["GET"])
# @flask_app.route(rule=<login_endpoint>,  # KEYCLOAK_ENDPOINT_LOGIN
#                  methods=["GET"])
def service_login() -> Response:
    """
    Entry point for the IAM server's login service.

    Return the URL for the IAM server's authentication page, with the appropriate parameters.

    :return: the response from the operation
    """
    # declare the return variable
    result: Response | None = None

    # retrieve the operations's logger
    logger: Logger = _get_logger()
    if logger:
        # log the request
        logger.debug(msg=_log_init(request=request))

    # retrieve the IAM server
    errors: list[str] = []
    iam_server: IamServer = _get_iam_server(endpoint=request.endpoint,
                                            errors=errors,
                                            logger=logger)
    if iam_server:
        # obtain the login URL
        login_data: dict[str,  str] = user_login(iam_server=iam_server,
                                                 args=request.args,
                                                 errors=errors,
                                                 logger=logger)
        if login_data:
            result = jsonify(login_data)

    if errors:
        result = Response("; ".join(errors))
        result.status_code = 400

    # log the response
    if logger:
        logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<logout_endpoint>,  # JUSBR_ENDPOINT_LOGOUT
#                  methods=["GET"])
# @flask_app.route(rule=<login_endpoint>,   # KEYCLOAK_ENDPOINT_LOGOUT
#                  methods=["GET"])
def service_logout() -> Response:
    """
    Entry point for the JusBR logout service.

    Remove all data associating the user from the *IAM* server's registry.

    :return: response *OK*, or response *BAD REQUEST* if error
    """
    # declare the return variable
    result: Response | None

    # retrieve the operations's logger
    logger: Logger = _get_logger()
    if logger:
        # log the request
        logger.debug(msg=_log_init(request=request))

    # retrieve the IAM server
    errors: list[str] = []
    iam_server: IamServer = _get_iam_server(endpoint=request.endpoint,
                                            errors=errors,
                                            logger=logger)
    if iam_server:
        # logout the user
        user_logout(iam_server=iam_server,
                    args=request.args,
                    errors=errors,
                    logger=logger)
    if errors:
        result = Response("; ".join(errors))
        result.status_code = 400
    else:
        result = Response(status=200)

    # log the response
    if logger:
        logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<callback_endpoint>,  # JUSBR_ENDPOINT_CALLBACK
#                  methods=["GET", "POST"])
# @flask_app.route(rule=<callback_endpoint>,  # KEYCLOAK_ENDPOINT_CALLBACK
#                  methods=["POST"])
def service_callback() -> Response:
    """
    Entry point for the callback from JusBR on authentication operation.

    This callback is typically invoked from a front-end application after a successful login at the
    JusBR login page, forwarding the data received.

    :return: the response containing the token, or *BAD REQUEST*
    """
    # retrieve the operations's logger
    logger: Logger = _get_logger()
    if logger:
        # log the request
        logger.debug(msg=_log_init(request=request))

    # retrieve the IAM server
    errors: list[str] = []
    token_data: tuple[str, str] | None = None
    iam_server: IamServer = _get_iam_server(endpoint=request.endpoint,
                                            errors=errors,
                                            logger=logger)
    if iam_server:
        # process the callback operation
        token_data = login_callback(iam_server=iam_server,
                                    args=request.args,
                                    errors=errors,
                                    logger=logger)
    result: Response
    if errors:
        result = jsonify({"errors": "; ".join(errors)})
        result.status_code = 400
        if logger:
            logger.error(msg=json.dumps(obj=result))
    else:
        result = jsonify({
            "user-id": token_data[0],
            "access-token": token_data[1]})

    # log the response
    if logger:
        logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<token_endpoint>,  # JUSBR_ENDPOINT_TOKEN
# @flask_app.route(rule=<token_endpoint>,  # KEYCLOAK_ENDPOINT_TOKEN
#                  methods=["GET"])
#                  methods=["GET"])
def service_token() -> Response:
    """
    Entry point for retrieving token from the *IAM* server.

    :return: the response containing the token, or *UNAUTHORIZED*
    """
    # retrieve the operations's logger
    logger: Logger = _get_logger()
    if logger:
        # log the request
        logger.debug(msg=_log_init(request=request))

    # retrieve the IAM server
    errors: list[str] = []
    iam_server: IamServer = _get_iam_server(endpoint=request.endpoint,
                                            errors=errors,
                                            logger=logger)
    # retrieve the token
    token: str | None = None
    if iam_server:
        errors: list[str] = []
        token: str = user_token(iam_server=iam_server,
                                args=request.args,
                                errors=errors,
                                logger=logger)
    result: Response
    if errors:
        result = Response("; ".join(errors))
        result.status_code = 400
    else:
        result = jsonify({"token": token})

    # log the response
    if logger:
        logger.debug(msg=f"Response {result}")

    return result


# @flask_app.route(rule=<callback_endpoint>,  # KEYCLOAK_ENDPOINT_EXCHANGE
#                  methods=["POST"])
def service_exchange() -> Response:
    """
    Entry point for requesting the *IAM* server to exchange the token.

    This is currently limit to the *Keycloak* server

    :return: the response containing the token, or *UNAUTHORIZED*
    """
    # retrieve the operations's logger
    logger: Logger = _get_logger()

    # retrieve the IAM server (currently, only 'Keycloak' is supported)
    errors: list[str] = []
    iam_server: IamServer = _get_iam_server(endpoint=request.endpoint,
                                            errors=errors,
                                            logger=logger)
    # exchange the token
    token_data: dict[str, Any] | None = None
    if iam_server:
        errors: list[str] = []
        token_data = token_exchange(iam_server=iam_server,
                                    args=request.args,
                                    errors=errors,
                                    logger=logger)
    result: Response
    if errors:
        result = Response("; ".join(errors))
        result.status_code = 400
    else:
        result = jsonify(token_data)

    # log the response
    if logger:
        logger.debug(msg=f"Response {result}")

    return result


def _log_init(request: Request) -> str:
    """
    Build the messages for logging the request entry.

    :param request: the Request object
    :return: the log message
    """

    params: str = json.dumps(obj=request.args,
                             ensure_ascii=False)
    return f"Request {request.method}:{request.path}, params {params}"
