/**
 * Aurica Authentication Helper
 * Include this script in any page that requires authentication
 * Supports both local and centralized authentication flows
 */

(function() {
    'use strict';

    // Configuration - can be overridden by setting window.AUTH_CONFIG before loading this script
    const CONFIG = window.AUTH_CONFIG || {
        AUTH_SERVER: window.location.hostname.includes('localhost') 
            ? `http://${window.location.host}` 
            : 'https://api.oneaurica.com',
        AUTH_CHECK_URL: '/auth-app/api/authenticate/current-user',
        LOGIN_URL: '/auth-app/api/centralized/login',
        LOGOUT_URL: '/auth-app/api/authenticate/logout',
        VERIFY_URL: '/auth-app/api/centralized/verify-token'
    };

    /**
     * Check if we're on the auth server
     */
    function isAuthServer() {
        const currentHost = window.location.host.split(':')[0];
        const authServerHost = new URL(CONFIG.AUTH_SERVER).host.split(':')[0];
        return currentHost === authServerHost;
    }

    /**
     * Get authentication token from URL parameters or storage
     * @returns {string|null} Token or null
     */
    function getTokenFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        
        if (token) {
            // Store token for future use
            localStorage.setItem('auth_token', token);
            
            // Clean URL by removing token parameter
            urlParams.delete('token');
            const newSearch = urlParams.toString();
            const newUrl = window.location.pathname + (newSearch ? '?' + newSearch : '');
            window.history.replaceState({}, '', newUrl);
        }
        
        return token;
    }

    /**
     * Check if the user is authenticated
     * @returns {Promise<object|null>} User data if authenticated, null otherwise
     */
    async function checkAuth() {
        // First check if there's a token in the URL (from redirect)
        getTokenFromURL();
        
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
            return null;
        }

        try {
            const authCheckUrl = isAuthServer() 
                ? CONFIG.AUTH_CHECK_URL 
                : `${CONFIG.AUTH_SERVER}${CONFIG.AUTH_CHECK_URL}`;
            
            const response = await fetch(authCheckUrl, {
                credentials: 'include',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const userData = await response.json();
                // Store user data
                localStorage.setItem('username', userData.username);
                localStorage.setItem('user_id', userData.user_id);
                return userData;
            } else {
                // Token is invalid, clear it
                localStorage.removeItem('auth_token');
                localStorage.removeItem('username');
                localStorage.removeItem('user_id');
                return null;
            }
        } catch (error) {
            console.error('Authentication check failed:', error);
            return null;
        }
    }

    /**
     * Redirect to login page with return URL
     */
    function redirectToLogin() {
        const currentUrl = window.location.href;
        
        if (isAuthServer()) {
            // Local redirect
            const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
            window.location.href = `/auth-app/?return_url=${returnUrl}`;
        } else {
            // Redirect to centralized auth server
            const loginUrl = `${CONFIG.AUTH_SERVER}${CONFIG.LOGIN_URL}?redirect_uri=${encodeURIComponent(currentUrl)}`;
            window.location.href = loginUrl;
        }
    }

    /**
     * Initialize authentication check
     * Call this function to require authentication on page load
     */
    async function requireAuth() {
        const userData = await checkAuth();
        
        if (!userData) {
            redirectToLogin();
            return null;
        }

        return userData;
    }

    /**
     * Logout function
     */
    async function logout() {
        try {
            await fetch('/auth-app/api/authenticate/logout', {
                method: 'POST',
                credentials: 'include'
            });
        } catch (error) {
            console.error('Logout error:', error);
        }

        // Clear local storage
        localStorage.removeItem('auth_token');
        localStorage.removeItem('username');
        localStorage.removeItem('user_id');

        // Redirect to login
        window.location.href = LOGIN_PAGE;
    }

    /**
     * Get current user data
     * @returns {Promise<object|null>}
     */
    async function getCurrentUser() {
        return await checkAuth();
    }

    /**
     * Make an authenticated API request
     * @param {string} url - API endpoint URL
     * @param {object} options - Fetch options
     * @returns {Promise<Response>}
     */
    async function authenticatedFetch(url, options = {}) {
        const token = localStorage.getItem('auth_token');
        
        const defaultOptions = {
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': `Bearer ${token}` } : {})
            }
        };

        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...(options.headers || {})
            }
        };

        const response = await fetch(url, mergedOptions);

        // If unauthorized, redirect to login
        if (response.status === 401) {
            redirectToLogin();
            throw new Error('Authentication required');
        }

        return response;
    }

    // Expose API
    window.AuricaAuth = {
        checkAuth,
        requireAuth,
        logout,
        getCurrentUser,
        authenticatedFetch,
        redirectToLogin
    };

    // Auto-check authentication if configured
    if (window.AuricaAuthConfig && window.AuricaAuthConfig.autoCheck) {
        document.addEventListener('DOMContentLoaded', async () => {
            await requireAuth();
        });
    }
})();
