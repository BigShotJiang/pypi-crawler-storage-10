"""
Test package for deep-ocr.
"""
