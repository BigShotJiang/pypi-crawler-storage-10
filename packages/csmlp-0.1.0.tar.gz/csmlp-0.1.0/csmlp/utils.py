import pandas as pd
import importlib.resources as pkg_resources

def get_data():
    """Load and return the CSV as a pandas DataFrame."""
    with pkg_resources.open_text("csmlp.data", "best.csv") as f:
        return pd.read_csv(f)
