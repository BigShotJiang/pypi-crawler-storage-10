from setuptools import setup, find_packages

setup(
    name="csmlp",
    version="0.1.0",
    author="Your Name",
    author_email="your_email@example.com",
    description="A Python package that provides an embedded CSV dataset for ML/DS experiments.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["pandas"],
    python_requires=">=3.7",
)
