.. _api:

API
===

.. toctree::
   :maxdepth: 2

   nwb2bids
   bids_models
   testing
