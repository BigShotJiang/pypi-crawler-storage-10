nwb2bids
========

.. automodule:: nwb2bids
