Thank you for your interest in contributing to `nwb2bids`!

Please review:
 - Our [Code of Conduct](https://github.com/con/nwb2bids?tab=coc-ov-file)
 - Our [Developer Guide](https://nwb2bids.readthedocs.io/en/latest/developer_guide.html)

Feel free to [open an issue](https://github.com/con/nwb2bids/issues) to introduce yourself and open a discussion of places to start or things on the current TODO list!
