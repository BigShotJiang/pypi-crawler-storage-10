from __future__ import annotations
import webbrowser
from typing import Optional

DEFAULT_URL = "https://opennetwork.dezors.com/playground"

def open_webview(url: Optional[str] = None, title: str = "OpenNetwork Playground", width: int = 1200, height: int = 800):
    """
    Try to open a lightweight native window (pywebview) if available,
    otherwise fall back to the default browser.
    """
    target = url or DEFAULT_URL
    try:
        import webview  # optional dependency
        webview.create_window(title, target, width=width, height=height)
        webview.start()
        return True
    except Exception:
        webbrowser.open(target, new=2)
        return False
