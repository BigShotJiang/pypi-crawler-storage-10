# OpenNetwork (opennetwork)

A tiny developer suite for MLOps-oriented model authoring and loading. It lets you:

- `opennetwork.setmodel()` — open the **Playground** (web view) to design your model.  
- `opennetwork.getmodel("model.json")` — load a JSON graph into a **Keras Functional** model.  
- `opennetwork.init()` — quickstart banner.

> Default Playground: https://opensparrow.netlify.app/playground

## Install

```bash
pip install opennetwork
# or, to enable building Keras models:
pip install "opennetwork[keras]"
# optional native window instead of browser:
pip install "opennetwork[webview]"
```

## Python API

```python
import opennetwork as onn

onn.init()
onn.setmodel()  # opens the Playground in a window/browser

# Build from JSON (returns tf.keras.Model if TensorFlow is installed)
model = onn.getmodel("model.json")

# If TensorFlow is not installed, you can still validate the graph:
model, extras = onn.getmodel("model.json", return_extras=True)
print(extras["inserted"])  # e.g., auto-added Flatten when Dense follows Conv2D
```

### CLI

```bash
opennetwork init
opennetwork setmodel
opennetwork getmodel path/to/model.json
```

## JSON schema (minimal)

```json
{
  "id": "string",
  "name": "string",
  "layers": [
    {
      "id": "unique-id",
      "type": "input|conv2d|dense|flatten|dropout|maxpool2d|batchnorm|activation|softmax_output",
      "name": "optional",
      "params": { "..." : "layer-params" },
      "connections": ["next-layer-id", "..."],
      "weights": [...],  // optional
      "biases":  [...]   // optional
    }
  ]
}
```

- The graph is built **topologically**.
- If a `Dense` follows a convolutional/tensor output, a `Flatten` is **auto-inserted** (configurable).
- `softmax_output` is interpreted as a final `Activation("softmax")`.
- Unknown or missing shapes will be handled best-effort; for guaranteed results, include an explicit `Input` layer with `params.input_shape`.

## License

MIT
