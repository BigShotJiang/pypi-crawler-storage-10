from emissary_ml_toolkit.utils.logging import (
    get_logger,
    _setup_default_logger
)

from emissary_ml_toolkit.pipeline.dataset import DatasetPipeline
from emissary_ml_toolkit.pipeline.train import TrainPipeline
from emissary_ml_toolkit.pipeline.evaluation import EvaluationPipeline

_setup_default_logger()

__all__ = [
    "get_logger",
    "DatasetPipeline",
    "TrainPipeline",
    "EvaluationPipeline",
]