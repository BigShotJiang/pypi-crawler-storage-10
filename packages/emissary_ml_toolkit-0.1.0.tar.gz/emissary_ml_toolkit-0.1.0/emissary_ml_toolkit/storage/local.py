from emissary_ml_toolkit.storage.base import BaseStorage
from typing import Optional, Union, List
from pathlib import Path
from io import IOBase


class LocalStorage(BaseStorage):
    def _setup_client(self):
        return

    def download_file(self, storage_path: str, local_path: Optional[Union[str, Path]] = None) -> Path:
        return Path(storage_path)

    def upload_file(self, source: Union[str, Path, IOBase, bytes], storage_path: Union[str, Path]):
        return

    def list_objects(self, prefix: str = "", bucket: Optional[str] = None) -> List[str]:
        return ['']

    def exists(self, storage_path: str) -> bool:
        storage_path = Path(storage_path)
        return storage_path.exists()
