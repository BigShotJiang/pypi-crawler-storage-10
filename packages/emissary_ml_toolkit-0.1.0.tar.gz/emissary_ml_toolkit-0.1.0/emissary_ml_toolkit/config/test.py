from pydantic import BaseModel


class TestOutput(BaseModel):
    storage_ref: str
    base_path: str


class TestConfig(BaseModel):
    test_output: TestOutput