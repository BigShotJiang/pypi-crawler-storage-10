from pydantic import BaseModel


class WebhookConfig(BaseModel):
    training_job_id: str
    project_id: str