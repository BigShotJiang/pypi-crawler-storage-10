import os
from typing import Optional
from functools import lru_cache


@lru_cache(maxsize=1)
def load_env_file(env_path: Optional[str] = None) -> None:
    """
    Load environment variables from .env file if it exists
    :param env_path: Path to .env file. If None, looks for .env in current directory.
    """
    try:
        from dotenv import load_dotenv
        if env_path:
            load_dotenv(env_path)
        else:
            load_dotenv()
    except ImportError:
        pass