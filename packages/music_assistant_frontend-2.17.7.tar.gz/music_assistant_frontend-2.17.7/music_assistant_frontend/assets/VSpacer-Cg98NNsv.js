/* empty css              */import{cO as r}from"./index-BFxAF8P3.js";const e=r("v-spacer","div","VSpacer");export{e as V};
