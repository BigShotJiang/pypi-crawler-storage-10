
def hello():
    """Prints a friendly greeting."""
    print("Hello from mypippakage!")
