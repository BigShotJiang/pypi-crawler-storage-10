# -*- coding:utf-8 -*-
"""
@Time        : 2023/3/2
@File        : util_log.py
@Author      : MysteriousMan
@version     : python 3
@Description : 日志
"""

import logging
import time
from colorlog import ColoredFormatter


class AutoLog:
    _LEVEL_MAP = {
        'DEBUG': logging.DEBUG,
        'INFO': logging.INFO,
        'WARNING': logging.WARNING,
        'ERROR': logging.ERROR,
        'CRITICAL': logging.CRITICAL
    }

    def __init__(self, base_filename, level_param):
        if level_param not in self._LEVEL_MAP:
            raise ValueError(f"无效日志级别: {level_param}")

        self.base_filename = base_filename
        self.level_param = level_param
        self.level = self._LEVEL_MAP[level_param]

        # 用唯一名称创建logger，避免全局冲突
        self.logger = logging.getLogger(f"AutoLog_{id(self)}")
        self.logger.setLevel(self.level)

        # 关键：仅在处理器为空时初始化（防止重复添加）
        if not self.logger.handlers:
            self._init_stream_handler()  # 初始化控制台处理器
            self.file_handler = None  # 初始化文件处理器相关变量
            self.last_log_date = None

    def _init_stream_handler(self):
        """初始化控制台处理器（仅在logger无处理器时执行）"""
        if ColoredFormatter:
            formatter = ColoredFormatter(
                "%(log_color)s[%(levelname)s][%(asctime)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
                log_colors={
                    'DEBUG': 'cyan',
                    'INFO': 'green',
                    'WARNING': 'yellow',
                    'ERROR': 'red',
                    'CRITICAL': 'black,bg_white'
                }
            )
        else:
            formatter = logging.Formatter(
                "[%(levelname)s][%(asctime)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        self.logger.addHandler(stream_handler)  # 此时handlers为空，添加一次

    def _get_file_handler(self):
        """获取文件处理器（跨天更新时，先移除旧处理器再添加新的）"""
        current_date = time.strftime("%Y-%m-%d")

        if current_date != self.last_log_date or not self.file_handler:
            # 移除旧文件处理器（若存在）
            if self.file_handler:
                self.logger.removeHandler(self.file_handler)
                self.file_handler.close()

            # 创建新文件处理器
            log_filename = f"{self.base_filename}-{current_date}.log"
            self.file_handler = logging.FileHandler(log_filename, encoding="utf-8")
            self.file_handler.setFormatter(
                logging.Formatter(
                    "[%(levelname)s][%(asctime)s]\t%(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S"
                )
            )

            # 关键：添加新文件处理器（此时logger已有控制台处理器，但文件处理器是新的，需添加）
            self.logger.addHandler(self.file_handler)
            self.last_log_date = current_date

        return self.file_handler

    def log(self, message=""):
        if not message.strip():
            return

        try:
            self._get_file_handler()  # 确保文件处理器有效

            # 按级别记录日志
            if self.level_param == 'DEBUG':
                self.logger.debug(message)
            elif self.level_param == 'INFO':
                self.logger.info(message)
            elif self.level_param == 'WARNING':
                self.logger.warning(message)
            elif self.level_param == 'ERROR':
                self.logger.error(message)
            elif self.level_param == 'CRITICAL':
                self.logger.critical(message)

        except Exception as e:
            print(f"日志记录失败: {e}")


if __name__ == '__main__':
    pass
    # Info = AutoLog(f"\\message_log\\info", level_param='INFO')
    # Warn = AutoLog(f"\\message_log\\warn", level_param='WARNING')
    # Error = AutoLog(f"\\message_log\\error", level_param='ERROR')
    # Critical = AutoLog(f"\\message_log\\critical", level_param='CRITICAL')
