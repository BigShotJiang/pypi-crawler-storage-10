"""Firebase authentication and Firestore synchronization helpers."""
from __future__ import annotations

import time
from dataclasses import dataclass
from functools import lru_cache
from typing import Callable, Dict, Optional
from urllib.parse import urlencode

import requests

FIREBASE_CONFIG = {
    "apiKey": "AIzaSyAkxOXZdtpA3M-Y7w_4r3-p_mwU0WAV1T0",
    "authDomain": "erosolar-encryption-b2c60.firebaseapp.com",
    "projectId": "erosolar-encryption-b2c60",
    "storageBucket": "erosolar-encryption-b2c60.firebasestorage.app",
    "messagingSenderId": "679177387857",
    "appId": "1:679177387857:web:379cccb9134b513f3a9d70",
    "measurementId": "G-56W2SR5ETF",
}

API_KEY = FIREBASE_CONFIG["apiKey"]
PROJECT_ID = FIREBASE_CONFIG["projectId"]

IDENTITY_BASE = "https://identitytoolkit.googleapis.com/v1"
FIRESTORE_BASE = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents"


class FirebaseAuthError(RuntimeError):
    """Raised when Firebase authentication fails."""


class EmailNotVerifiedError(FirebaseAuthError):
    """Raised when the Firebase user has not verified their email address yet."""

    def __init__(self, message: str, session: "FirebaseSession"):
        super().__init__(message)
        self.session = session


@dataclass
class FirebaseSession:
    id_token: str
    refresh_token: str
    user_id: str
    email: str
    expiration: float

    def ensure_valid(self) -> None:
        if time.time() < self.expiration - 30:
            return
        raise FirebaseAuthError("Session token expired; re-authentication required.")


def _post(url: str, payload: Dict[str, object]) -> Dict[str, object]:
    response = requests.post(url, json=payload, timeout=15)
    if response.status_code != 200:
        raise FirebaseAuthError(response.text)
    return response.json()


def _request(method: str, url: str, session: FirebaseSession, payload: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    session.ensure_valid()
    headers = {
        "Authorization": f"Bearer {session.id_token}",
        "Content-Type": "application/json",
    }
    response = requests.request(method, url, headers=headers, json=payload, timeout=15)
    if response.status_code == 404:
        raise FileNotFoundError(url)
    if response.status_code >= 400:
        raise FirebaseAuthError(response.text)
    if response.content:
        return response.json()
    return {}


def _build_session(data: Dict[str, object]) -> FirebaseSession:
    expires_raw = data.get("expiresIn", "3600")
    try:
        expires_in = int(expires_raw)
    except (TypeError, ValueError):
        expires_in = 3600
    return FirebaseSession(
        id_token=str(data["idToken"]),
        refresh_token=str(data["refreshToken"]),
        user_id=str(data["localId"]),
        email=str(data.get("email") or ""),
        expiration=time.time() + expires_in,
    )


def _lookup_user(session: FirebaseSession) -> Dict[str, object]:
    return _post(f"{IDENTITY_BASE}/accounts:lookup?key={API_KEY}", {"idToken": session.id_token})


def send_verification_email(session: FirebaseSession) -> None:
    """Trigger a Firebase verification email for the provided session."""
    _post(
        f"{IDENTITY_BASE}/accounts:sendOobCode?key={API_KEY}",
        {"requestType": "VERIFY_EMAIL", "idToken": session.id_token},
    )


def sign_in_with_email(email: str, password: str) -> FirebaseSession:
    url = f"{IDENTITY_BASE}/accounts:signInWithPassword?key={API_KEY}"
    data = _post(url, {"email": email, "password": password, "returnSecureToken": True})
    session = _build_session(data)
    lookup = _lookup_user(session)
    user_info = lookup.get("users", [{}])[0]
    if not user_info.get("emailVerified"):
        raise EmailNotVerifiedError(
            "Email address is not verified. Please check your inbox for a verification link.",
            session,
        )
    return session


DEVICE_CODE_URL = "https://oauth2.googleapis.com/device/code"
TOKEN_URL = "https://oauth2.googleapis.com/token"


@lru_cache(maxsize=1)
def _google_client_id() -> str:
    config_url = f"{IDENTITY_BASE}/projects/{PROJECT_ID}/config?key={API_KEY}"
    response = requests.get(config_url, timeout=15)
    if response.status_code != 200:
        raise FirebaseAuthError(response.text)
    config = response.json()
    providers = config.get("signIn", {}).get("providers") or config.get("oauthIdpConfigs") or []
    for provider in providers:
        provider_id = provider.get("provider") or provider.get("providerId")
        if provider_id == "google.com":
            client_id = provider.get("clientId")
            if client_id:
                return client_id
    raise FirebaseAuthError("Google Sign-In is not configured for this Firebase project.")


ProgressCallback = Callable[[str, str], None]


def sign_in_with_google(progress: Optional[ProgressCallback] = None) -> FirebaseSession:
    """Authenticate a Firebase user via Google SSO using the OAuth device flow."""
    client_id = _google_client_id()
    device_resp = requests.post(
        DEVICE_CODE_URL,
        data={"client_id": client_id, "scope": "openid email profile"},
        timeout=15,
    )
    if device_resp.status_code != 200:
        raise FirebaseAuthError(device_resp.text)
    device_data = device_resp.json()
    verification_url = device_data.get("verification_url") or device_data.get("verificationUri")
    user_code = device_data.get("user_code")
    device_code = device_data.get("device_code")
    if not (verification_url and user_code and device_code):
        raise FirebaseAuthError("Invalid response from Google device authorization endpoint.")
    if progress:
        progress(verification_url, user_code)
    interval = int(device_data.get("interval", 5))
    expires_in = int(device_data.get("expires_in", 1800))
    deadline = time.time() + expires_in
    token_payload = {
        "client_id": client_id,
        "device_code": device_code,
        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
    }
    while time.time() < deadline:
        token_resp = requests.post(TOKEN_URL, data=token_payload, timeout=15)
        if token_resp.status_code == 200:
            token_data = token_resp.json()
            id_token = token_data.get("id_token")
            access_token = token_data.get("access_token")
            if not id_token:
                raise FirebaseAuthError("Google sign-in did not return an ID token.")
            payload = {
                "postBody": urlencode(
                    {
                        "id_token": id_token,
                        "access_token": access_token or "",
                        "providerId": "google.com",
                    }
                ),
                "requestUri": "http://localhost",
                "returnIdpCredential": True,
                "returnSecureToken": True,
            }
            data = _post(f"{IDENTITY_BASE}/accounts:signInWithIdp?key={API_KEY}", payload)
            session = _build_session(data)
            lookup = _lookup_user(session)
            user_info = lookup.get("users", [{}])[0]
            if not user_info.get("emailVerified"):
                raise EmailNotVerifiedError("Google account email is not verified.", session)
            return session
        if token_resp.status_code != 400:
            raise FirebaseAuthError(token_resp.text)
        error_data = token_resp.json()
        error_code = error_data.get("error")
        if error_code == "authorization_pending":
            time.sleep(interval)
            continue
        if error_code == "slow_down":
            interval += 5
            time.sleep(interval)
            continue
        if error_code == "expired_token":
            raise FirebaseAuthError("Google sign-in timed out. Please try again.")
        if error_code == "access_denied":
            raise FirebaseAuthError("Google sign-in was denied by the user.")
        raise FirebaseAuthError(token_resp.text)
    raise FirebaseAuthError("Google sign-in timed out. Please try again.")


DEFAULT_REMOTE_STORE = {
    "master_pw_hash": "",
    "private_key": "",
    "sign_private_key": "",
    "credentials": "",
    "pgp_keyvault": "",
    "public_key": "",
    "verify_public_key": "",
    "cards": "",
}


def _firestore_doc_path(user_id: str) -> str:
    return f"{FIRESTORE_BASE}/users/{user_id}"


def fetch_user_store(session: FirebaseSession) -> Dict[str, str]:
    url = _firestore_doc_path(session.user_id)
    try:
        doc = _request("GET", url, session)
    except FileNotFoundError:
        create_user_store(session, DEFAULT_REMOTE_STORE.copy())
        return DEFAULT_REMOTE_STORE.copy()
    fields = doc.get("fields", {})
    store: Dict[str, str] = {}
    for key, value in DEFAULT_REMOTE_STORE.items():
        store[key] = fields.get(key, {}).get("stringValue", value)
    return store


def create_user_store(session: FirebaseSession, store: Dict[str, str]) -> None:
    url = f"{FIRESTORE_BASE}/users?documentId={session.user_id}"
    payload = {"fields": {k: {"stringValue": v or ""} for k, v in store.items()}}
    _request("POST", url, session, payload)


def replace_user_store(session: FirebaseSession, store: Dict[str, str]) -> None:
    url = _firestore_doc_path(session.user_id)
    payload = {"fields": {k: {"stringValue": v or ""} for k, v in store.items()}}
    try:
        _request("PATCH", url, session, payload)
    except FileNotFoundError:
        create_user_store(session, store)


def delete_user_store(session: FirebaseSession) -> None:
    url = _firestore_doc_path(session.user_id)
    _request("DELETE", url, session)
