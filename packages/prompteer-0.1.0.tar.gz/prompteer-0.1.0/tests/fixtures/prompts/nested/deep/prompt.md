Nested prompt
