---
description: User profile prompt
name: User name
age(int): User age
height(float): User height
---
Name: {name}
Age: {age}
Height: {height}
