# -*- coding: utf-8 -*-
# *******************************************************
#   ____                     _               _
#  / ___|___  _ __ ___   ___| |_   _ __ ___ | |
# | |   / _ \| '_ ` _ \ / _ \ __| | '_ ` _ \| |
# | |__| (_) | | | | | |  __/ |_ _| | | | | | |
#  \____\___/|_| |_| |_|\___|\__(_)_| |_| |_|_|
#
#  Sign up for free at https://www.comet.com
#  Copyright (C) 2015-2021 Comet ML INC
#  This source code is licensed under the MIT license.
# *******************************************************

import collections

Registry = collections.namedtuple("Registry", ("workspace", "registry", "version"))

ExperimentByKey = collections.namedtuple(
    "ExperimentByKey", ("experiment_key", "model_name")
)

ExperimentByWorkspace = collections.namedtuple(
    "ExperimentByKey", ("workspace", "project_name", "experiment_name", "model_name")
)
