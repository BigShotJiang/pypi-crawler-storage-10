def main():
    print("Hello from zhkj-plugins!")


if __name__ == "__main__":
    main()
