"""Version information for marearts-road-objects"""
__version__ = "2.0.3"
