# algorithmic-efficiency

A useful Python package with utility functions.

## Installation

```bash
pip install algorithmic-efficiency
```

## Usage

```python
import algorithmic-efficiency

print(algorithmic-efficiency.hello_world())
result = algorithmic-efficiency.add_numbers(5, 3)
print(result)
```
