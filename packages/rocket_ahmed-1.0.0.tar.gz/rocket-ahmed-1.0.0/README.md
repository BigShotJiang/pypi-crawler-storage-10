# package_name

`rocket-ahmed` is a Python library for instantiating & manipulating rocket objects

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket-ahmed`.

```bash
pip install rocket-ahmed
```

## Usage

```python
import rocket-ahmed

# returns 'words'
rocket-ahmed.module_name('word')

# returns 'geese'
rocket-ahmed.module_name('goose')

# returns 'phenomenon'
rocket-ahmed.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)