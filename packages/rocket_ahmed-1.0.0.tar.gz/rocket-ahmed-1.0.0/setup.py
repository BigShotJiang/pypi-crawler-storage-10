from setuptools import setup

setup(
   name='rocket-ahmed',
   version='1.0.0',
   author='ahmed',
   author_email='ay.bouguessa@esi-sba.dz',
   packages=['rocket-ahmed'],
   url='http://pypi.python.org/pypi/rocket-ahmed/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['rocket-ahmed']
)