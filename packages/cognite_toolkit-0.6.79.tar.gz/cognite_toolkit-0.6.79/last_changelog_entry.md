## cdf 

### Changed

- [alpha] The command `cdf migrate files` now support migrating a
dataset. You can also now chose to skip the linking to existing files.

## templates

No changes.