# hjq

这是 hjq 库的初始版本

## 安装
```bash
pip install hjq
```

## 使用示例
```python
import hjq
print("hjq 已成功安装!")
```