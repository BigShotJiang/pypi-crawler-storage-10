def unwrap_archer_response(data):
    '''
    Unwrap Archer API response that may be wrapped in RequestedObject.
    
    Handles three cases:
    1. List of wrapped objects: [{"RequestedObject": {...}}, ...]
    2. Single wrapped object: {"RequestedObject": {...}}
    3. Already unwrapped: {...} or [...]
    
    Args:
        data: Raw response from Archer API
        
    Returns:
        Unwrapped data
    
    # ============================================================
    # Use in API methods:
    # ============================================================
    from ..utils import unwrap_archer_response

    def get_fields(self, application_id: int, as_model: bool = False):
        url = f"{self.base_url}/platformapi/core/system/fielddefinition/application/{application_id}"
        response = self._make_request("GET", url)
        data = unwrap_archer_response(response.json())
        
        # Ensure it's a list
        if not isinstance(data, list):
            data = [data] if data else []
        
        if as_model:
            return [FieldDefinition(**f) for f in data]
        return data
    '''
    if isinstance(data, list):
        # Extract RequestedObject from each item
        unwrapped = []
        for item in data:
            if isinstance(item, dict) and 'RequestedObject' in item:
                unwrapped.append(item['RequestedObject'])
            else:
                unwrapped.append(item)
        return unwrapped
    elif isinstance(data, dict) and 'RequestedObject' in data:
        # Single wrapped object
        return data['RequestedObject']
    else:
        # Already unwrapped
        return data