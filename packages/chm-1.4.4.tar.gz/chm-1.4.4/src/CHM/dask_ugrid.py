import sys
import numpy as np
import esmpy as ESMF
import rasterio
import xarray as xr
import rioxarray  # for xarray.rio
import os
from mpi4py import MPI
import osgeo_utils.gdal_merge
import glob
import itertools

from osgeo import gdal


def _assemble_dask_dataset(chunks, variables, x_coords, y_coords):
    """Combine scattered per-rank chunks into Dask-backed xarray Dataset."""
    if not chunks:
        return xr.Dataset()

    import dask.array as da

    flat_chunks = list(itertools.chain.from_iterable(chunks))
    if not flat_chunks:
        return xr.Dataset()

    # Build lookup tables for time ordering and per-variable/per-time chunks
    time_lookup = {}
    chunks_by_key = {}

    for entry in flat_chunks:
        key = (entry["var"], entry["time_index"])
        chunks_by_key.setdefault(key, []).append(entry)
        time_lookup.setdefault(entry["time_index"], entry["time_value"])

    sorted_time_indices = sorted(time_lookup.keys())

    def _blocks_to_array(entries):
        rows = {}
        for item in entries:
            rows.setdefault(item["y_start"], []).append(item)

        ordered_rows = []
        for y_start in sorted(rows.keys()):
            row_entries = sorted(rows[y_start], key=lambda v: v["x_start"])
            dask_row = []
            for v in row_entries:
                delayed_block = v["delayed_block"]
                if isinstance(delayed_block, (list, tuple)):
                    if len(delayed_block) != 1:
                        raise ValueError('Unexpected multiple delayed blocks for a single future')
                    delayed_block = delayed_block[0]
                dask_row.append(
                    da.from_delayed(
                        delayed_block,
                        shape=v["shape"],
                        dtype=v["dtype"],
                    )
                )
            ordered_rows.append(dask_row)

        return da.block(ordered_rows)

    dataset_vars = {}
    for var in variables:
        stacked_blocks = []
        time_coords = []
        for time_index in sorted_time_indices:
            key = (var, time_index)
            if key not in chunks_by_key:
                continue
            stacked_blocks.append(_blocks_to_array(chunks_by_key[key]))
            time_coords.append(time_lookup[time_index])

        if not stacked_blocks:
            continue

        data = da.stack(stacked_blocks, axis=0)
        dataset_vars[var] = xr.DataArray(
            data,
            dims=("time", "y", "x"),
            coords={
                "time": time_coords,
                "y": y_coords,
                "x": x_coords,
            },
            name=var,
        )

    return xr.Dataset(dataset_vars)

def log(message):
    print(f'[{ESMF.local_pet()}] {message}')

def ugrid2dask(ugrid_nc, dxdy=0.005, mesh_topology_nc=None, method='conservative', save_weights_file=None,
               load_weights_file=None, variables=None, time_offsets=None, dask_client=None):
    """
    Convert a ugrid file to tiff. The ugrid file needs to come from the pvd to ugrid conversion

    df = pc.open_pvd('output_FSM_rhod600/SC.pvd')
    df=df.set_index('datetime')['2017-11-01':'2018-04-03'].reset_index()
    df = df.iloc[[0,30,60,90,120]] # every 30days in this period
    pc.vtu_to_ugrid(df, 'test2.nc')

    :param ugrid_nc:
    :param dxdy:
    :param mesh_topology_nc:
    :param method:
    :param save_weights_file:
    :param load_weights_file:
    :param variables:
    :param time_offsets:
    :param dask_client: Optional distributed client used to assemble Dask-backed arrays instead of writing GeoTIFFs.
    :return:
    """
    # mg = ESMF.Manager(debug=True)
    comm = MPI.COMM_WORLD

    if save_weights_file is not None and load_weights_file is not None:
        raise Exception("Cannot have both save_weights_file and load_weights_file set")

    # we might be loading a seperate mesh topology
    mnc = ugrid_nc if mesh_topology_nc is None else mesh_topology_nc

    mesh = ESMF.Mesh(filename=mnc,
                            filetype=ESMF.api.constants.FileFormat.UGRID,
                            meshname='Mesh2'
                     )

    nodes, elements = (0, 1)
    u, v = (0, 1)

    # communicate accross all the ranks to figure out the bounds of our mesh
    xmin_m = np.array([mesh.coords[nodes][u].min()])
    xmax_m = np.array([mesh.coords[nodes][u].max()])
    ymin_m = np.array([mesh.coords[nodes][v].min()])
    ymax_m = np.array([mesh.coords[nodes][v].max()])

    xmin = np.empty(1, dtype=np.float64)
    xmax = np.empty(1, dtype=np.float64)
    ymin = np.empty(1, dtype=np.float64)
    ymax = np.empty(1, dtype=np.float64)

    comm.Allreduce(xmin_m, xmin, op=MPI.MIN)
    comm.Allreduce(ymin_m, ymin, op=MPI.MIN)
    comm.Allreduce(xmax_m, xmax, op=MPI.MAX)
    comm.Allreduce(ymax_m, ymax, op=MPI.MAX)

    xmin = xmin[0]
    ymin = ymin[0]
    xmax = xmax[0]
    ymax = ymax[0]

    x = np.abs(xmin-xmax)
    y = np.abs(ymin-ymax)

    numX, numY = int(x/dxdy), int(y/dxdy)

    log(f'numX, numY = {numX}, {numY}')

    log(f'umin={mesh.coords[nodes][u].min()} umax={mesh.coords[nodes][u].max()} vmin={mesh.coords[nodes][v].min()} vmax={mesh.coords[nodes][v].max()} ')

    # cell centres
    dxdy2 = dxdy/2.
    x_center = np.linspace(start=xmin + dxdy2,
                           stop=xmax - dxdy2, num=numX)

    y_center = np.linspace(start=ymin + dxdy2,
                           stop=ymax - dxdy2, num=numY)

    # node coords
    x_corner = np.linspace(start=xmin, stop=xmax, num=numX + 1)
    y_corner = np.linspace(start=ymin, stop=ymax, num=numY + 1)


    max_index = np.array([len(x_center), len(y_center)])
    log( f' max_index={max_index}')


    grid = ESMF.Grid(max_index, staggerloc=[ESMF.StaggerLoc.CENTER, ESMF.StaggerLoc.CORNER], coord_sys=ESMF.CoordSys.SPH_DEG)

    # RLO: access Grid center coordinates
    gridXCenter = grid.get_coords(0)
    gridYCenter = grid.get_coords(1)

    # RLO-v2: adjust coordinate array to bounds of the current PET (rank)
    x_center_par = x_center[grid.lower_bounds[ESMF.StaggerLoc.CENTER][0]:grid.upper_bounds[ESMF.StaggerLoc.CENTER][0]]
    y_center_par = y_center[grid.lower_bounds[ESMF.StaggerLoc.CENTER][1]:grid.upper_bounds[ESMF.StaggerLoc.CENTER][1]]

    # RLO: set Grid center coordinates as a 2D array (this can also be done 1d)
    gridXCenter[...] = x_center_par.reshape((x_center_par.size, 1))
    gridYCenter[...] = y_center_par.reshape((1, y_center_par.size))

    # RLO: access Grid corner coordinates
    gridXCorner = grid.get_coords(0, staggerloc=ESMF.StaggerLoc.CORNER)
    gridYCorner = grid.get_coords(1, staggerloc=ESMF.StaggerLoc.CORNER)

    # # RLO-v2: adjust coordinate array to bounds of the current PET (rank)
    x_corner_par = x_corner[grid.lower_bounds[ESMF.StaggerLoc.CORNER][0]:grid.upper_bounds[ESMF.StaggerLoc.CORNER][0]]
    y_corner_par = y_corner[grid.lower_bounds[ESMF.StaggerLoc.CORNER][1]:grid.upper_bounds[ESMF.StaggerLoc.CORNER][1]]

    # # RLO: set Grid corner coordinats as a 2D array
    gridXCorner[...] = x_corner_par.reshape((x_corner_par.size, 1))
    gridYCorner[...] = y_corner_par.reshape((1, y_corner_par.size))

    # grid._write_(f'{ESMF.local_pet()}-grid')

    df = xr.open_mfdataset(ugrid_nc)

    if variables is None:
        variables = list(df.keys())

    # don't convert these to tiff
    exclude_list = ['Mesh2', 'Mesh2_face_nodes', 'Mesh2_node_x', 'Mesh2_node_y', 'Mesh2_face_x', 'Mesh2_face_y', 'time', 'global_id' ]

    # the sort is important as otherwise this can have a different order on different mpi ranks
    variables = sorted(list(set(variables)-set(exclude_list)))

    srcfield = ESMF.Field(mesh, meshloc=ESMF.MeshLoc.ELEMENT)
    dstfield = ESMF.Field(grid, staggerloc=ESMF.StaggerLoc.CENTER)

    regrid_method = ESMF.RegridMethod.CONSERVE if method == 'conservative' else ESMF.RegridMethod.BILINEAR
    log(f"""Using {'ESMF.RegridMethod.CONSERVE' if method == 'conservative' else 'ESMF.RegridMethod.BILINEAR'} regridder""")

    # clean up old weight file and
    if save_weights_file is not None and comm.Get_rank() == 0:
        if os.path.isfile(
                os.path.join(os.getcwd(), save_weights_file)):
            os.remove(os.path.join(os.getcwd(), save_weights_file))

    comm.barrier()
    regrid = None
    if save_weights_file is not None:
        regrid = ESMF.Regrid(srcfield, dstfield, regrid_method=regrid_method, filename=save_weights_file,
                         unmapped_action=ESMF.UnmappedAction.IGNORE)
    elif load_weights_file is not None:
        log(f'Loading weights from {load_weights_file}')
        regrid = ESMF.RegridFromFile(srcfield, dstfield, filename=load_weights_file)
    else:
        regrid = ESMF.Regrid(srcfield, dstfield, regrid_method=regrid_method, unmapped_action=ESMF.UnmappedAction.IGNORE)


    # srcfield.read(filename=ugrid_nc, variable='global_id', timeslice=0)
    # offsets = np.array(srcfield.data[:], dtype=np.int64)
    # offset_mask = df.global_id.isin(offsets)


    # get the global_id offsets this rank is using
    srcfield_offsets = ESMF.Field(mesh, meshloc=ESMF.MeshLoc.ELEMENT)
    srcfield_offsets.read(filename=mnc,
                          variable='global_id', timeslice=0)
    offsets = np.array(srcfield_offsets.data[:], dtype=np.int64) # these need to be ints to index with
    offset_mask = df.global_id.isin(offsets).compute()
    srcfield_offsets.destroy()
    srcfield_offsets = None

    center_lb = grid.lower_bounds[ESMF.StaggerLoc.CENTER]
    center_ub = grid.upper_bounds[ESMF.StaggerLoc.CENTER]
    x_start_idx, y_start_idx = int(center_lb[0]), int(center_lb[1])
    x_stop_idx, y_stop_idx = int(center_ub[0]), int(center_ub[1])

    #hold a list of the processed times so we don't have to recompute it when dealing with tiff merging
    processed_times = []
    local_dask_chunks = []

    if time_offsets is None:
        time_offsets = range(0, df.time.shape[0])

    for ts in time_offsets:

        time_label = str(df.time[ts].dt.strftime('%Y%m%dT%H%M%S').data)
        time_coord = df.time.isel(time=ts).values
        if isinstance(time_coord, np.ndarray):
            time_value = time_coord.item()
        else:
            time_value = time_coord

        for var in variables:
            log(f'{time_label} - {var}')

            srcfield.data[:] = df.isel(time=ts)[var].where(offset_mask, drop=True).data
            dstfield.data[...] = np.nan

            dstfield = regrid(srcfield, dstfield, zero_region=ESMF.Region.SELECT)

            local_block = np.flip(dstfield.data.T, axis=0)


            future = dask_client.scatter(local_block, broadcast=False)
            delayed_block = future.to_delayed()
            local_dask_chunks.append({
                "var": var,
                "time_index": int(ts),
                "time_value": time_value,
                "delayed_block": delayed_block,
                "shape": local_block.shape,
                "dtype": local_block.dtype,
                "x_start": x_start_idx,
                "x_stop": x_stop_idx,
                "y_start": y_start_idx,
                "y_stop": y_stop_idx,
            })


            # Wait to make sure everyone has finished processing this timestep + variable
            comm.barrier()


    log('Completed per-PET regridding')
    comm.barrier()
    df.close()
    comm.barrier()

    log('Assembling Dask dataset')
    gathered_chunks = comm.gather(local_dask_chunks, root=0)
    if ESMF.local_pet() == 0:
        return _assemble_dask_dataset(gathered_chunks, variables, x_center, y_center)

    return None


