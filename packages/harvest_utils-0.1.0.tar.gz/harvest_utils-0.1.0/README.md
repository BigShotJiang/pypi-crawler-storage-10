# harvest-utils

Reusable utilities extracted from the Harvest project.

Quick start:

```bash
pip install harvest-utils==0.1.0
```

Example usage:

```python
from harvest_utils import example_util, iso_now

print(example_util())
print(iso_now())
```

Publishing:
- Build: `python -m build`
- Test upload to TestPyPI: `python -m twine upload --repository-url https://test.pypi.org/legacy/ dist/*`
- Production upload: `python -m twine upload dist/*` (use CI on protected branch)

See CHANGELOG.md for releases.