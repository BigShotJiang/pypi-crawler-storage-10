from harvest_utils import example_util, iso_now, parse_optional_int


def test_example_util():
    assert example_util() == "example util from harvest_utils"


def test_iso_now():
    s = iso_now()
    assert "T" in s  # basic sanity check for ISO format


def test_parse_optional_int():
    assert parse_optional_int("10") == 10
    assert parse_optional_int(None, default=5) == 5
    assert parse_optional_int("bad", default=7) == 7