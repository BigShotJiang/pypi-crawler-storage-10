"""
harvest_utils: small utilities extracted from Harvest project.

Keep only logic that is generic and independent from Django models.
"""

from datetime import datetime, timezone
from typing import Optional


def example_util() -> str:
    """
    Example helper to show package usage.
    Replace or extend with real utilities (formatters, validators, conversions).
    """
    return "example util from harvest_utils"


def iso_now() -> str:
    """Return current UTC time in ISO-8601 format."""
    return datetime.now(timezone.utc).isoformat()


def parse_optional_int(value: Optional[str], default: int = 0) -> int:
    """Safe parse for optional string ints."""
    try:
        return int(value) if value is not None else default
    except (ValueError, TypeError):
        return default