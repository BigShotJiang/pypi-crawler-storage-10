# V1MajorVersionDraftToFeatureSetVersionResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature_set_id** | **str** |  | [optional] 
**job_id** | **str** |  | [optional] 
**feature_set_version** | **str** |  | [optional] 
**feature_set_name** | **str** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


