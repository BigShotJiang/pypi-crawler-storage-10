# V1JSONFolderSpec


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**root_folder** | **str** |  | [optional] 
**filter_pattern** | **str** |  | [optional] 
**multiline** | **bool** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


