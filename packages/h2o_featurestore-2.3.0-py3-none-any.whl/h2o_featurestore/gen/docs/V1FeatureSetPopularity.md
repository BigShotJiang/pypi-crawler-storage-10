# V1FeatureSetPopularity


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature_set_id** | **str** |  | [optional] 
**number_of_retrievals** | **str** |  | [optional] 
**feature_set_name** | **str** |  | [optional] 
**feature_set_description** | **str** |  | [optional] 
**permission** | [**V1ActivePermission**](V1ActivePermission.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


