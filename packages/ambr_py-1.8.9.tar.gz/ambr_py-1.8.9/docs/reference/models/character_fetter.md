# Character Fetter Models

::: ambr.models.character_fetter
