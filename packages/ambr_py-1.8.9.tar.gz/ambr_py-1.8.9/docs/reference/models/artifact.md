# Artifact Models# Artifact Models

::: ambr.models.artifact
