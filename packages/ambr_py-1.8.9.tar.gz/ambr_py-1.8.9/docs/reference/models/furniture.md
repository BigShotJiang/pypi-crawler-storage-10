# Furniture Models

::: ambr.models.furniture
