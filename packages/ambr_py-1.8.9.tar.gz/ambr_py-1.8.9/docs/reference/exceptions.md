# API Reference

::: ambr.exceptions
