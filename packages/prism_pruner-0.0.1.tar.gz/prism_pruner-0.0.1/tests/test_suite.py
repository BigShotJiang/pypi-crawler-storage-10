"""Tests for the prism_pruner package."""

import os

import numpy as np

from prism_pruner.graph_manipulations import graphize
from prism_pruner.pruner import (
    prune_by_moment_of_inertia,
    prune_by_rmsd,
    prune_by_rmsd_rot_corr,
)
from prism_pruner.utils import read_xyz

test_dir = os.path.dirname(os.path.realpath(__file__))


def test_two_identical() -> None:
    """Test that two identical structures evaluate as similar under all metrics."""
    os.chdir(test_dir)
    mol = read_xyz("P4_folded.xyz")
    coords = np.stack((mol.atomcoords[0], mol.atomcoords[0]))
    graph = graphize(mol.atomnos, mol.atomcoords[0])

    pruned, _ = prune_by_rmsd(coords, mol.atomnos)
    assert len(pruned) == 1

    pruned, _ = prune_by_rmsd_rot_corr(coords, mol.atomnos, graph)
    assert len(pruned) == 1

    pruned, _ = prune_by_moment_of_inertia(coords, mol.atomnos)
    assert len(pruned) == 1


def test_two_different() -> None:
    """Test that two different structures evaluate as different under all metrics."""
    os.chdir(test_dir)

    mol1 = read_xyz("P4_folded.xyz")
    mol2 = read_xyz("P4_hairpin.xyz")

    graph1 = graphize(mol1.atomnos, mol1.atomcoords[0])
    coords = np.stack((mol1.atomcoords[0], mol2.atomcoords[0]))

    pruned, _ = prune_by_rmsd(coords, mol1.atomnos)
    assert len(pruned) == 2

    pruned, _ = prune_by_rmsd_rot_corr(coords, mol1.atomnos, graph1)
    assert len(pruned) == 2

    pruned, _ = prune_by_moment_of_inertia(coords, mol1.atomnos)
    assert len(pruned) == 2


def test_ensemble_moi() -> None:
    """Assert that an ensemble of structures is reduced in size after MOI pruning."""
    os.chdir(test_dir)

    ensemble = read_xyz("ensemble_100.xyz")

    pruned, _ = prune_by_moment_of_inertia(
        ensemble.atomcoords,
        ensemble.atomnos,
    )

    assert pruned.shape[0] < ensemble.atomcoords.shape[0]


def test_ensemble_rmsd() -> None:
    """Assert that an ensemble of structures is reduced in size after RMSD pruning."""
    os.chdir(test_dir)

    ensemble = read_xyz("ensemble_100.xyz")

    pruned, _ = prune_by_rmsd(
        ensemble.atomcoords,
        ensemble.atomnos,
        max_rmsd=1.0,
    )

    assert pruned.shape[0] < ensemble.atomcoords.shape[0]


def test_ensemble_rmsd_rot_corr() -> None:
    """Assert that an ensemble of structures is reduced in size after rot. corr. RMSD pruning."""
    os.chdir(test_dir)

    ensemble = read_xyz("ensemble_100.xyz")
    graph = graphize(ensemble.atomnos, ensemble.atomcoords[0])

    pruned, _ = prune_by_rmsd_rot_corr(
        ensemble.atomcoords,
        ensemble.atomnos,
        graph,
        max_rmsd=1.0,
    )

    assert pruned.shape[0] < ensemble.atomcoords.shape[0]


def test_rmsd_rot_corr_segmented_graph_2_mols() -> None:
    """Assert that an ensemble of structures is reduced in size after rot. corr. RMSD pruning.

    The provided ensemble has four different rotamers and two
    connected components in its graph (i.e. two separate molecules).
    The expected behavior is that this fact should not stump the
    rotamer-invariant function.
    """
    os.chdir(test_dir)

    ensemble = read_xyz("MTBE_tBuOH_ens.xyz")
    graph = graphize(ensemble.atomnos, ensemble.atomcoords[0])

    pruned, _ = prune_by_rmsd_rot_corr(
        ensemble.atomcoords,
        ensemble.atomnos,
        graph,
        max_rmsd=0.1,
    )

    assert pruned.shape[0] == 1
