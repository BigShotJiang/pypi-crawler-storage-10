from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from gradio.components.base import Component


TileStatus = str


@dataclass
class WordleRow:
    letters: List[str] = field(default_factory=lambda: [""] * 5)
    statuses: List[TileStatus] = field(default_factory=lambda: ["empty"] * 5)


@dataclass
class PublicWordleState:
    board: List[WordleRow]
    current_row: int
    status: str
    message: str
    max_rows: int

class WordleBoard(Component):
    """Interactive Wordle board component."""

    def __init__(
        self,
        word_length: int = 5,
        max_attempts: int = 6,
        **kwargs,
    ) -> None:
        if word_length != 5:
            raise ValueError("WordleBoard currently only supports 5-letter words.")
        self.word_length = word_length
        self.max_attempts = max_attempts
        super().__init__(**kwargs)

    # ------------------------------------------------------------------
    # Component lifecycle helpers

    def preprocess(self, payload: Optional[Dict]) -> Optional[Dict]:
        if payload is None:
            return None

        if not isinstance(payload, dict):
            raise ValueError("Payload must be a JSON object.")

        return payload

    def postprocess(self, value: Optional[PublicWordleState | Dict | str]) -> Dict:
        """Serialize backend state into a JSON-friendly dict for the frontend."""

        if value is None:
            return self.to_public_dict(self.create_game_state())

        if isinstance(value, PublicWordleState):
            return self.to_public_dict(value)

        if isinstance(value, str):
            parsed = self.parse_feedback(value)
            return self.to_public_dict(parsed)

        if isinstance(value, dict):
            return value

        raise ValueError("WordleBoard expects a PublicWordleState or dict from the backend.")

    # ------------------------------------------------------------------
    # Game helpers exposed for app code

    def create_game_state(self) -> PublicWordleState:
        """Create a blank public board state."""

        board = [WordleRow() for _ in range(self.max_attempts)]

        return PublicWordleState(
            board=board,
            current_row=0,
            status="playing",
            message="Awaiting feedback...",
            max_rows=self.max_attempts,
        )

    def parse_feedback(self, feedback: str, *, message: Optional[str] = None) -> PublicWordleState:
        """Convert TextArena feedback text into a board representation."""

        state = self.create_game_state()
        state.message = message or "Awaiting feedback..."

        if not feedback:
            return state

        lines = [line.strip() for line in feedback.replace("\r\n", "\n").split("\n")]
        row_index = 0
        last_message = message or ""
        i = 0

        while i < len(lines) and row_index < self.max_attempts:
            line = lines[i]

            if not line:
                i += 1
                continue

            if line.lower().startswith("feedback"):
                line = line.split(":", 1)[-1].strip()
                if not line:
                    i += 1
                    continue

            letters = self._extract_letters(line)
            if letters:
                statuses: List[TileStatus] = []
                if i + 1 < len(lines):
                    statuses = self._extract_statuses(lines[i + 1])

                if statuses and len(statuses) == self.word_length:
                    row = state.board[row_index]
                    row.letters = letters
                    row.statuses = statuses
                    row_index += 1
                    i += 2
                    continue

            last_message = line
            i += 1

        state.current_row = min(row_index, state.max_rows - 1)

        if row_index > 0 and all(status == "green" for status in state.board[row_index - 1].statuses):
            state.status = "won"
            state.message = "You solved it!"
        else:
            guesses_left = self._extract_guesses_left(last_message)
            if guesses_left is not None:
                if guesses_left == 0:
                    state.status = "lost"
                else:
                    state.status = "playing"
                state.message = last_message or state.message
            elif last_message:
                state.message = last_message

            if state.status not in {"won", "lost"}:
                state.status = "playing"

        if state.status != "won" and row_index >= state.max_rows and state.max_rows > 0:
            if not all(status == "green" for status in state.board[row_index - 1].statuses):
                state.status = "lost"

        return state

    # ------------------------------------------------------------------
    # Serialization helpers

    @staticmethod
    def to_public_dict(state: PublicWordleState) -> Dict:
        return {
            "board": [
                {
                    "letters": row.letters,
                    "statuses": row.statuses,
                }
                for row in state.board
            ],
            "current_row": state.current_row,
            "status": state.status,
            "message": state.message,
            "max_rows": state.max_rows,
        }

    def _extract_letters(self, line: str) -> List[str]:
        candidate = line.split(":", 1)[-1].strip()

        tokens = candidate.split()
        if len(tokens) == self.word_length and all(len(token) == 1 and token.isalpha() for token in tokens):
            return [token.upper() for token in tokens]

        for token in tokens:
            if len(token) == self.word_length and token.isalpha():
                return list(token.upper())

        letters = [char.upper() for char in candidate if char.isalpha()]
        if len(letters) == self.word_length:
            return letters

        match = re.search(r"([A-Za-z]{" + str(self.word_length) + r"})", candidate.replace(" ", ""))
        if match:
            return list(match.group(1).upper())

        return []

    def _extract_statuses(self, line: str) -> List[TileStatus]:
        candidate = line.split(":", 1)[-1].strip().upper()
        mapping = {"X": "gray", "Y": "yellow", "G": "green"}

        tokens = candidate.split()
        if tokens and len(tokens) == self.word_length:
            statuses = [mapping.get(token.upper(), "empty") for token in tokens]
            if all(status != "empty" for status in statuses):
                return statuses

        chars = [mapping.get(char, "") for char in candidate if char in mapping]
        if len(chars) == self.word_length:
            return chars

        return []

    @staticmethod
    def _extract_guesses_left(line: str) -> Optional[int]:
        if not line:
            return None

        match = re.search(r"(\d+)\s+guesses?\s+left", line, flags=re.IGNORECASE)
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                return None

        if re.search(r"no\s+guesses\s+left", line, flags=re.IGNORECASE):
            return 0

        return None

    # ------------------------------------------------------------------
    # API metadata

    def example_payload(self) -> Dict:
        return {"feedback": "C R A N E\nY G X X X"}

    def example_value(self) -> Dict:
        state = self.parse_feedback("C R A N E\nY G X X X\nYou have 5 guesses left.")
        return self.to_public_dict(state)

    def api_info(self) -> Dict:
        return {
            "type": "object",
            "description": "Wordle board state JSON",
            "properties": {
                "board": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "letters": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "statuses": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "enum": ["empty", "gray", "yellow", "green"],
                                },
                            },
                        },
                        "required": ["letters", "statuses"],
                    },
                },
                "current_row": {"type": "integer"},
                "status": {"type": "string", "enum": ["playing", "won", "lost"]},
                "message": {"type": "string"},
                "max_rows": {"type": "integer"},
            },
            "required": [
                "board",
                "current_row",
                "status",
                "message",
                "max_rows",
            ],
        }

    # ------------------------------------------------------------------
    # Internal helpers

    # ------------------------------------------------------------------
    # Deprecated helpers preserved for compatibility

    def public_from_private(self, state: PublicWordleState) -> PublicWordleState:  # type: ignore[override]
        return state
    from typing import Callable, Literal, Sequence, Any, TYPE_CHECKING
    from gradio.blocks import Block
    if TYPE_CHECKING:
        from gradio.components import Timer
        from gradio.components.base import Component
