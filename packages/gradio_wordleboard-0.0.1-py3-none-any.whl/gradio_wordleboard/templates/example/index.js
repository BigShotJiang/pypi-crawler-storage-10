const {
  SvelteComponent: A,
  append_hydration: d,
  attr: y,
  children: g,
  claim_element: m,
  claim_space: I,
  claim_text: V,
  destroy_each: C,
  detach: v,
  element: p,
  ensure_array_like: E,
  init: N,
  insert_hydration: k,
  noop: w,
  null_to_empty: P,
  safe_not_equal: R,
  set_data: z,
  space: S,
  text: q,
  toggle_class: f
} = window.__gradio__svelte__internal;
function j(i, e, a) {
  const r = i.slice();
  return r[5] = e[a], r[7] = a, r;
}
function D(i) {
  let e, a, r = (
    /*letter*/
    i[5] + ""
  ), n, _;
  return {
    c() {
      e = p("div"), a = p("span"), n = q(r), _ = S(), this.h();
    },
    l(o) {
      e = m(o, "DIV", { class: !0 });
      var c = g(e);
      a = m(c, "SPAN", {});
      var t = g(a);
      n = V(t, r), t.forEach(v), _ = I(c), c.forEach(v), this.h();
    },
    h() {
      y(e, "class", P(`preview-tile ${/*previewRow*/
      i[3].statuses[
        /*index*/
        i[7]
      ]}`) + " svelte-19pithj");
    },
    m(o, c) {
      k(o, e, c), d(e, a), d(a, n), d(e, _);
    },
    p: w,
    d(o) {
      o && v(e);
    }
  };
}
function B(i) {
  let e, a, r, n, _ = (
    /*value*/
    i[0].message + ""
  ), o, c = E(
    /*previewRow*/
    i[3].letters
  ), t = [];
  for (let l = 0; l < c.length; l += 1)
    t[l] = D(j(i, c, l));
  return {
    c() {
      e = p("div"), a = p("div");
      for (let l = 0; l < t.length; l += 1)
        t[l].c();
      r = S(), n = p("div"), o = q(_), this.h();
    },
    l(l) {
      e = m(l, "DIV", { class: !0 });
      var h = g(e);
      a = m(h, "DIV", { class: !0 });
      var s = g(a);
      for (let b = 0; b < t.length; b += 1)
        t[b].l(s);
      s.forEach(v), r = I(h), n = m(h, "DIV", { class: !0 });
      var u = g(n);
      o = V(u, _), u.forEach(v), h.forEach(v), this.h();
    },
    h() {
      y(a, "class", "preview-row svelte-19pithj"), y(n, "class", "preview-message svelte-19pithj"), y(e, "class", "svelte-19pithj"), f(
        e,
        "table",
        /*type*/
        i[1] === "table"
      ), f(
        e,
        "gallery",
        /*type*/
        i[1] === "gallery"
      ), f(
        e,
        "selected",
        /*selected*/
        i[2]
      );
    },
    m(l, h) {
      k(l, e, h), d(e, a);
      for (let s = 0; s < t.length; s += 1)
        t[s] && t[s].m(a, null);
      d(e, r), d(e, n), d(n, o);
    },
    p(l, [h]) {
      if (h & /*previewRow*/
      8) {
        c = E(
          /*previewRow*/
          l[3].letters
        );
        let s;
        for (s = 0; s < c.length; s += 1) {
          const u = j(l, c, s);
          t[s] ? t[s].p(u, h) : (t[s] = D(u), t[s].c(), t[s].m(a, null));
        }
        for (; s < t.length; s += 1)
          t[s].d(1);
        t.length = c.length;
      }
      h & /*value*/
      1 && _ !== (_ = /*value*/
      l[0].message + "") && z(o, _), h & /*type*/
      2 && f(
        e,
        "table",
        /*type*/
        l[1] === "table"
      ), h & /*type*/
      2 && f(
        e,
        "gallery",
        /*type*/
        l[1] === "gallery"
      ), h & /*selected*/
      4 && f(
        e,
        "selected",
        /*selected*/
        l[2]
      );
    },
    i: w,
    o: w,
    d(l) {
      l && v(e), C(t, l);
    }
  };
}
function F(i, e, a) {
  var r;
  let { value: n } = e, { type: _ } = e, { selected: o = !1 } = e;
  const c = (r = n.board.find((t) => t.statuses.some((l) => l !== "empty"))) !== null && r !== void 0 ? r : n.board[0];
  return i.$$set = (t) => {
    "value" in t && a(0, n = t.value), "type" in t && a(1, _ = t.type), "selected" in t && a(2, o = t.selected);
  }, [n, _, o, c];
}
class G extends A {
  constructor(e) {
    super(), N(this, e, F, B, R, { value: 0, type: 1, selected: 2 });
  }
}
export {
  G as default
};
