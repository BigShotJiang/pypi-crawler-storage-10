var Bi = Object.defineProperty;
var Xt = (r) => {
  throw TypeError(r);
};
var Ii = (r, t, e) => t in r ? Bi(r, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : r[t] = e;
var O = (r, t, e) => Ii(r, typeof t != "symbol" ? t + "" : t, e), Ri = (r, t, e) => t.has(r) || Xt("Cannot " + e);
var Wt = (r, t, e) => t.has(r) ? Xt("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(r) : t.set(r, e);
var Qe = (r, t, e) => (Ri(r, t, "access private method"), e);
const {
  SvelteComponent: qi,
  append_hydration: Ct,
  assign: Li,
  attr: H,
  binding_callbacks: Ni,
  children: Ge,
  claim_element: Zn,
  claim_space: Vn,
  claim_svg_element: Dt,
  create_slot: Oi,
  detach: ye,
  element: Yn,
  empty: Kt,
  get_all_dirty_from_scope: zi,
  get_slot_changes: Pi,
  get_spread_update: Mi,
  init: Ui,
  insert_hydration: Ye,
  listen: Gi,
  noop: Hi,
  safe_not_equal: ji,
  set_dynamic_element_data: Qt,
  set_style: B,
  space: Xn,
  svg_element: yt,
  toggle_class: M,
  transition_in: Wn,
  transition_out: Kn,
  update_slot_base: Zi
} = window.__gradio__svelte__internal;
function Jt(r) {
  let t, e, n, i, o;
  return {
    c() {
      t = yt("svg"), e = yt("line"), n = yt("line"), this.h();
    },
    l(a) {
      t = Dt(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var l = Ge(t);
      e = Dt(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ge(e).forEach(ye), n = Dt(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ge(n).forEach(ye), l.forEach(ye), this.h();
    },
    h() {
      H(e, "x1", "1"), H(e, "y1", "9"), H(e, "x2", "9"), H(e, "y2", "1"), H(e, "stroke", "gray"), H(e, "stroke-width", "0.5"), H(n, "x1", "5"), H(n, "y1", "9"), H(n, "x2", "9"), H(n, "y2", "5"), H(n, "stroke", "gray"), H(n, "stroke-width", "0.5"), H(t, "class", "resize-handle svelte-239wnu"), H(t, "xmlns", "http://www.w3.org/2000/svg"), H(t, "viewBox", "0 0 10 10");
    },
    m(a, l) {
      Ye(a, t, l), Ct(t, e), Ct(t, n), i || (o = Gi(
        t,
        "mousedown",
        /*resize*/
        r[27]
      ), i = !0);
    },
    p: Hi,
    d(a) {
      a && ye(t), i = !1, o();
    }
  };
}
function Vi(r) {
  var _;
  let t, e, n, i, o;
  const a = (
    /*#slots*/
    r[31].default
  ), l = Oi(
    a,
    r,
    /*$$scope*/
    r[30],
    null
  );
  let s = (
    /*resizable*/
    r[19] && Jt(r)
  ), u = [
    { "data-testid": (
      /*test_id*/
      r[11]
    ) },
    { id: (
      /*elem_id*/
      r[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((_ = r[7]) == null ? void 0 : _.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      r[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = Li(c, u[d]);
  return {
    c() {
      t = Yn(
        /*tag*/
        r[25]
      ), l && l.c(), e = Xn(), s && s.c(), this.h();
    },
    l(d) {
      t = Zn(
        d,
        /*tag*/
        (r[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var g = Ge(t);
      l && l.l(g), e = Vn(g), s && s.l(g), g.forEach(ye), this.h();
    },
    h() {
      Qt(
        /*tag*/
        r[25]
      )(t, c), M(
        t,
        "hidden",
        /*visible*/
        r[14] === !1 || /*visible*/
        r[14] === "hidden"
      ), M(
        t,
        "padded",
        /*padding*/
        r[10]
      ), M(
        t,
        "flex",
        /*flex*/
        r[1]
      ), M(
        t,
        "border_focus",
        /*border_mode*/
        r[9] === "focus"
      ), M(
        t,
        "border_contrast",
        /*border_mode*/
        r[9] === "contrast"
      ), M(t, "hide-container", !/*explicit_call*/
      r[12] && !/*container*/
      r[13]), M(
        t,
        "fullscreen",
        /*fullscreen*/
        r[0]
      ), M(
        t,
        "animating",
        /*fullscreen*/
        r[0] && /*preexpansionBoundingRect*/
        r[24] !== null
      ), M(
        t,
        "auto-margin",
        /*scale*/
        r[17] === null
      ), B(
        t,
        "height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*height*/
            r[2]
          )
        )
      ), B(
        t,
        "min-height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*min_height*/
            r[3]
          )
        )
      ), B(
        t,
        "max-height",
        /*fullscreen*/
        r[0] ? void 0 : (
          /*get_dimension*/
          r[26](
            /*max_height*/
            r[4]
          )
        )
      ), B(
        t,
        "--start-top",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].top}px` : "0px"
      ), B(
        t,
        "--start-left",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].left}px` : "0px"
      ), B(
        t,
        "--start-width",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].width}px` : "0px"
      ), B(
        t,
        "--start-height",
        /*preexpansionBoundingRect*/
        r[24] ? `${/*preexpansionBoundingRect*/
        r[24].height}px` : "0px"
      ), B(
        t,
        "width",
        /*fullscreen*/
        r[0] ? void 0 : typeof /*width*/
        r[5] == "number" ? `calc(min(${/*width*/
        r[5]}px, 100%))` : (
          /*get_dimension*/
          r[26](
            /*width*/
            r[5]
          )
        )
      ), B(
        t,
        "border-style",
        /*variant*/
        r[8]
      ), B(
        t,
        "overflow",
        /*allow_overflow*/
        r[15] ? (
          /*overflow_behavior*/
          r[16]
        ) : "hidden"
      ), B(
        t,
        "flex-grow",
        /*scale*/
        r[17]
      ), B(t, "min-width", `calc(min(${/*min_width*/
      r[18]}px, 100%))`), B(t, "border-width", "var(--block-border-width)");
    },
    m(d, g) {
      Ye(d, t, g), l && l.m(t, null), Ct(t, e), s && s.m(t, null), r[32](t), o = !0;
    },
    p(d, g) {
      var f;
      l && l.p && (!o || g[0] & /*$$scope*/
      1073741824) && Zi(
        l,
        a,
        d,
        /*$$scope*/
        d[30],
        o ? Pi(
          a,
          /*$$scope*/
          d[30],
          g,
          null
        ) : zi(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, g) : (s = Jt(d), s.c(), s.m(t, null)) : s && (s.d(1), s = null), Qt(
        /*tag*/
        d[25]
      )(t, c = Mi(u, [
        (!o || g[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!o || g[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!o || g[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((f = d[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || g[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: i }
      ])), M(
        t,
        "hidden",
        /*visible*/
        d[14] === !1 || /*visible*/
        d[14] === "hidden"
      ), M(
        t,
        "padded",
        /*padding*/
        d[10]
      ), M(
        t,
        "flex",
        /*flex*/
        d[1]
      ), M(
        t,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), M(
        t,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), M(t, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), M(
        t,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), M(
        t,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), M(
        t,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), g[0] & /*fullscreen, height*/
      5 && B(
        t,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), g[0] & /*fullscreen, min_height*/
      9 && B(
        t,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), g[0] & /*fullscreen, max_height*/
      17 && B(
        t,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        t,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        t,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        t,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), g[0] & /*preexpansionBoundingRect*/
      16777216 && B(
        t,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), g[0] & /*fullscreen, width*/
      33 && B(
        t,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), g[0] & /*variant*/
      256 && B(
        t,
        "border-style",
        /*variant*/
        d[8]
      ), g[0] & /*allow_overflow, overflow_behavior*/
      98304 && B(
        t,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), g[0] & /*scale*/
      131072 && B(
        t,
        "flex-grow",
        /*scale*/
        d[17]
      ), g[0] & /*min_width*/
      262144 && B(t, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      o || (Wn(l, d), o = !0);
    },
    o(d) {
      Kn(l, d), o = !1;
    },
    d(d) {
      d && ye(t), l && l.d(d), s && s.d(), r[32](null);
    }
  };
}
function en(r) {
  let t;
  return {
    c() {
      t = Yn("div"), this.h();
    },
    l(e) {
      t = Zn(e, "DIV", { class: !0 }), Ge(t).forEach(ye), this.h();
    },
    h() {
      H(t, "class", "placeholder svelte-239wnu"), B(
        t,
        "height",
        /*placeholder_height*/
        r[22] + "px"
      ), B(
        t,
        "width",
        /*placeholder_width*/
        r[23] + "px"
      );
    },
    m(e, n) {
      Ye(e, t, n);
    },
    p(e, n) {
      n[0] & /*placeholder_height*/
      4194304 && B(
        t,
        "height",
        /*placeholder_height*/
        e[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && B(
        t,
        "width",
        /*placeholder_width*/
        e[23] + "px"
      );
    },
    d(e) {
      e && ye(t);
    }
  };
}
function Yi(r) {
  let t, e, n, i = (
    /*tag*/
    r[25] && Vi(r)
  ), o = (
    /*fullscreen*/
    r[0] && en(r)
  );
  return {
    c() {
      i && i.c(), t = Xn(), o && o.c(), e = Kt();
    },
    l(a) {
      i && i.l(a), t = Vn(a), o && o.l(a), e = Kt();
    },
    m(a, l) {
      i && i.m(a, l), Ye(a, t, l), o && o.m(a, l), Ye(a, e, l), n = !0;
    },
    p(a, l) {
      /*tag*/
      a[25] && i.p(a, l), /*fullscreen*/
      a[0] ? o ? o.p(a, l) : (o = en(a), o.c(), o.m(e.parentNode, e)) : o && (o.d(1), o = null);
    },
    i(a) {
      n || (Wn(i, a), n = !0);
    },
    o(a) {
      Kn(i, a), n = !1;
    },
    d(a) {
      a && (ye(t), ye(e)), i && i.d(a), o && o.d(a);
    }
  };
}
function Xi(r, t, e) {
  let { $$slots: n = {}, $$scope: i } = t, { height: o = void 0 } = t, { min_height: a = void 0 } = t, { max_height: l = void 0 } = t, { width: s = void 0 } = t, { elem_id: u = "" } = t, { elem_classes: c = [] } = t, { variant: _ = "solid" } = t, { border_mode: d = "base" } = t, { padding: g = !0 } = t, { type: f = "normal" } = t, { test_id: b = void 0 } = t, { explicit_call: v = !1 } = t, { container: k = !0 } = t, { visible: h = !0 } = t, { allow_overflow: p = !0 } = t, { overflow_behavior: m = "auto" } = t, { scale: D = null } = t, { min_width: y = 0 } = t, { flex: w = !1 } = t, { resizable: S = !1 } = t, { rtl: F = !1 } = t, { fullscreen: T = !1 } = t, N = T, L, ue = f === "fieldset" ? "fieldset" : "div", te = 0, Ae = 0, X = null;
  function ce($) {
    T && $.key === "Escape" && e(0, T = !1);
  }
  const q = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, j = ($) => {
    let U = $.clientY;
    const Fe = (be) => {
      const ke = be.clientY - U;
      U = be.clientY, e(21, L.style.height = `${L.offsetHeight + ke}px`, L);
    }, W = () => {
      window.removeEventListener("mousemove", Fe), window.removeEventListener("mouseup", W);
    };
    window.addEventListener("mousemove", Fe), window.addEventListener("mouseup", W);
  };
  function ge($) {
    Ni[$ ? "unshift" : "push"](() => {
      L = $, e(21, L);
    });
  }
  return r.$$set = ($) => {
    "height" in $ && e(2, o = $.height), "min_height" in $ && e(3, a = $.min_height), "max_height" in $ && e(4, l = $.max_height), "width" in $ && e(5, s = $.width), "elem_id" in $ && e(6, u = $.elem_id), "elem_classes" in $ && e(7, c = $.elem_classes), "variant" in $ && e(8, _ = $.variant), "border_mode" in $ && e(9, d = $.border_mode), "padding" in $ && e(10, g = $.padding), "type" in $ && e(28, f = $.type), "test_id" in $ && e(11, b = $.test_id), "explicit_call" in $ && e(12, v = $.explicit_call), "container" in $ && e(13, k = $.container), "visible" in $ && e(14, h = $.visible), "allow_overflow" in $ && e(15, p = $.allow_overflow), "overflow_behavior" in $ && e(16, m = $.overflow_behavior), "scale" in $ && e(17, D = $.scale), "min_width" in $ && e(18, y = $.min_width), "flex" in $ && e(1, w = $.flex), "resizable" in $ && e(19, S = $.resizable), "rtl" in $ && e(20, F = $.rtl), "fullscreen" in $ && e(0, T = $.fullscreen), "$$scope" in $ && e(30, i = $.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== N && (e(29, N = T), T ? (e(24, X = L.getBoundingClientRect()), e(22, te = L.offsetHeight), e(23, Ae = L.offsetWidth), window.addEventListener("keydown", ce)) : (e(24, X = null), window.removeEventListener("keydown", ce))), r.$$.dirty[0] & /*visible*/
    16384 && (h || e(1, w = !1));
  }, [
    T,
    w,
    o,
    a,
    l,
    s,
    u,
    c,
    _,
    d,
    g,
    b,
    v,
    k,
    h,
    p,
    m,
    D,
    y,
    S,
    F,
    L,
    te,
    Ae,
    X,
    ue,
    q,
    j,
    f,
    N,
    i,
    n,
    ge
  ];
}
class Wi extends qi {
  constructor(t) {
    super(), Ui(
      this,
      t,
      Xi,
      Yi,
      ji,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Nt() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Be = Nt();
function Qn(r) {
  Be = r;
}
const Jn = /[&<>"']/, Ki = new RegExp(Jn.source, "g"), ei = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Qi = new RegExp(ei.source, "g"), Ji = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, tn = (r) => Ji[r];
function Q(r, t) {
  if (t) {
    if (Jn.test(r))
      return r.replace(Ki, tn);
  } else if (ei.test(r))
    return r.replace(Qi, tn);
  return r;
}
const ea = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function ta(r) {
  return r.replace(ea, (t, e) => (e = e.toLowerCase(), e === "colon" ? ":" : e.charAt(0) === "#" ? e.charAt(1) === "x" ? String.fromCharCode(parseInt(e.substring(2), 16)) : String.fromCharCode(+e.substring(1)) : ""));
}
const na = /(^|[^\[])\^/g;
function R(r, t) {
  let e = typeof r == "string" ? r : r.source;
  t = t || "";
  const n = {
    replace: (i, o) => {
      let a = typeof o == "string" ? o : o.source;
      return a = a.replace(na, "$1"), e = e.replace(i, a), n;
    },
    getRegex: () => new RegExp(e, t)
  };
  return n;
}
function nn(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const He = { exec: () => null };
function an(r, t) {
  const e = r.replace(/\|/g, (o, a, l) => {
    let s = !1, u = a;
    for (; --u >= 0 && l[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = e.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), t)
    if (n.length > t)
      n.splice(t);
    else
      for (; n.length < t; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function Je(r, t, e) {
  const n = r.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && r.charAt(n - i - 1) === t; )
    i++;
  return r.slice(0, n - i);
}
function ia(r, t) {
  if (r.indexOf(t[1]) === -1)
    return -1;
  let e = 0;
  for (let n = 0; n < r.length; n++)
    if (r[n] === "\\")
      n++;
    else if (r[n] === t[0])
      e++;
    else if (r[n] === t[1] && (e--, e < 0))
      return n;
  return -1;
}
function rn(r, t, e, n) {
  const i = t.href, o = t.title ? Q(t.title) : null, a = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const l = {
      type: "link",
      raw: e,
      href: i,
      title: o,
      text: a,
      tokens: n.inlineTokens(a)
    };
    return n.state.inLink = !1, l;
  }
  return {
    type: "image",
    raw: e,
    href: i,
    title: o,
    text: Q(a)
  };
}
function aa(r, t) {
  const e = r.match(/^(\s+)(?:```)/);
  if (e === null)
    return t;
  const n = e[1];
  return t.split(`
`).map((i) => {
    const o = i.match(/^\s+/);
    if (o === null)
      return i;
    const [a] = o;
    return a.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class st {
  // set by the lexer
  constructor(t) {
    O(this, "options");
    O(this, "rules");
    // set by the lexer
    O(this, "lexer");
    this.options = t || Be;
  }
  space(t) {
    const e = this.rules.block.newline.exec(t);
    if (e && e[0].length > 0)
      return {
        type: "space",
        raw: e[0]
      };
  }
  code(t) {
    const e = this.rules.block.code.exec(t);
    if (e) {
      const n = e[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: e[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Je(n, `
`)
      };
    }
  }
  fences(t) {
    const e = this.rules.block.fences.exec(t);
    if (e) {
      const n = e[0], i = aa(n, e[3] || "");
      return {
        type: "code",
        raw: n,
        lang: e[2] ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : e[2],
        text: i
      };
    }
  }
  heading(t) {
    const e = this.rules.block.heading.exec(t);
    if (e) {
      let n = e[2].trim();
      if (/#$/.test(n)) {
        const i = Je(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: e[0],
        depth: e[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(t) {
    const e = this.rules.block.hr.exec(t);
    if (e)
      return {
        type: "hr",
        raw: e[0]
      };
  }
  blockquote(t) {
    const e = this.rules.block.blockquote.exec(t);
    if (e) {
      let n = e[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Je(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: e[0],
        tokens: o,
        text: n
      };
    }
  }
  list(t) {
    let e = this.rules.block.list.exec(t);
    if (e) {
      let n = e[1].trim();
      const i = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const a = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let l = "", s = "", u = !1;
      for (; t; ) {
        let c = !1;
        if (!(e = a.exec(t)) || this.rules.block.hr.test(t))
          break;
        l = e[0], t = t.substring(l.length);
        let _ = e[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), d = t.split(`
`, 1)[0], g = 0;
        this.options.pedantic ? (g = 2, s = _.trimStart()) : (g = e[2].search(/[^ ]/), g = g > 4 ? 1 : g, s = _.slice(g), g += e[1].length);
        let f = !1;
        if (!_ && /^ *$/.test(d) && (l += d + `
`, t = t.substring(d.length + 1), c = !0), !c) {
          const k = new RegExp(`^ {0,${Math.min(3, g - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, g - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), p = new RegExp(`^ {0,${Math.min(3, g - 1)}}(?:\`\`\`|~~~)`), m = new RegExp(`^ {0,${Math.min(3, g - 1)}}#`);
          for (; t; ) {
            const D = t.split(`
`, 1)[0];
            if (d = D, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), p.test(d) || m.test(d) || k.test(d) || h.test(t))
              break;
            if (d.search(/[^ ]/) >= g || !d.trim())
              s += `
` + d.slice(g);
            else {
              if (f || _.search(/[^ ]/) >= 4 || p.test(_) || m.test(_) || h.test(_))
                break;
              s += `
` + d;
            }
            !f && !d.trim() && (f = !0), l += D + `
`, t = t.substring(D.length + 1), _ = d.slice(g);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(l) && (u = !0));
        let b = null, v;
        this.options.gfm && (b = /^\[[ xX]\] /.exec(s), b && (v = b[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: l,
          task: !!b,
          checked: v,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += l;
      }
      o.items[o.items.length - 1].raw = l.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const _ = o.items[c].tokens.filter((g) => g.type === "space"), d = _.length > 0 && _.some((g) => /\n.*\n/.test(g.raw));
          o.loose = d;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(t) {
    const e = this.rules.block.html.exec(t);
    if (e)
      return {
        type: "html",
        block: !0,
        raw: e[0],
        pre: e[1] === "pre" || e[1] === "script" || e[1] === "style",
        text: e[0]
      };
  }
  def(t) {
    const e = this.rules.block.def.exec(t);
    if (e) {
      const n = e[1].toLowerCase().replace(/\s+/g, " "), i = e[2] ? e[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = e[3] ? e[3].substring(1, e[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : e[3];
      return {
        type: "def",
        tag: n,
        raw: e[0],
        href: i,
        title: o
      };
    }
  }
  table(t) {
    const e = this.rules.block.table.exec(t);
    if (!e || !/[:|]/.test(e[2]))
      return;
    const n = an(e[1]), i = e[2].replace(/^\||\| *$/g, "").split("|"), o = e[3] && e[3].trim() ? e[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: e[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const l of i)
        /^ *-+: *$/.test(l) ? a.align.push("right") : /^ *:-+: *$/.test(l) ? a.align.push("center") : /^ *:-+ *$/.test(l) ? a.align.push("left") : a.align.push(null);
      for (const l of n)
        a.header.push({
          text: l,
          tokens: this.lexer.inline(l)
        });
      for (const l of o)
        a.rows.push(an(l, a.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return a;
    }
  }
  lheading(t) {
    const e = this.rules.block.lheading.exec(t);
    if (e)
      return {
        type: "heading",
        raw: e[0],
        depth: e[2].charAt(0) === "=" ? 1 : 2,
        text: e[1],
        tokens: this.lexer.inline(e[1])
      };
  }
  paragraph(t) {
    const e = this.rules.block.paragraph.exec(t);
    if (e) {
      const n = e[1].charAt(e[1].length - 1) === `
` ? e[1].slice(0, -1) : e[1];
      return {
        type: "paragraph",
        raw: e[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(t) {
    const e = this.rules.block.text.exec(t);
    if (e)
      return {
        type: "text",
        raw: e[0],
        text: e[0],
        tokens: this.lexer.inline(e[0])
      };
  }
  escape(t) {
    const e = this.rules.inline.escape.exec(t);
    if (e)
      return {
        type: "escape",
        raw: e[0],
        text: Q(e[1])
      };
  }
  tag(t) {
    const e = this.rules.inline.tag.exec(t);
    if (e)
      return !this.lexer.state.inLink && /^<a /i.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(e[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: e[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: e[0]
      };
  }
  link(t) {
    const e = this.rules.inline.link.exec(t);
    if (e) {
      const n = e[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const a = Je(n.slice(0, -1), "\\");
        if ((n.length - a.length) % 2 === 0)
          return;
      } else {
        const a = ia(e[2], "()");
        if (a > -1) {
          const s = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + a;
          e[2] = e[2].substring(0, a), e[0] = e[0].substring(0, s).trim(), e[3] = "";
        }
      }
      let i = e[2], o = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        a && (i = a[1], o = a[3]);
      } else
        o = e[3] ? e[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), rn(e, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, e[0], this.lexer);
    }
  }
  reflink(t, e) {
    let n;
    if ((n = this.rules.inline.reflink.exec(t)) || (n = this.rules.inline.nolink.exec(t))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), o = e[i.toLowerCase()];
      if (!o) {
        const a = n[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return rn(n, o, n[0], this.lexer);
    }
  }
  emStrong(t, e, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(t);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const a = [...i[0]].length - 1;
      let l, s, u = a, c = 0;
      const _ = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (_.lastIndex = 0, e = e.slice(-1 * t.length + a); (i = _.exec(e)) != null; ) {
        if (l = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !l)
          continue;
        if (s = [...l].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...i[0]][0].length, g = t.slice(0, a + i.index + d + s);
        if (Math.min(a, s) % 2) {
          const b = g.slice(1, -1);
          return {
            type: "em",
            raw: g,
            text: b,
            tokens: this.lexer.inlineTokens(b)
          };
        }
        const f = g.slice(2, -2);
        return {
          type: "strong",
          raw: g,
          text: f,
          tokens: this.lexer.inlineTokens(f)
        };
      }
    }
  }
  codespan(t) {
    const e = this.rules.inline.code.exec(t);
    if (e) {
      let n = e[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return i && o && (n = n.substring(1, n.length - 1)), n = Q(n, !0), {
        type: "codespan",
        raw: e[0],
        text: n
      };
    }
  }
  br(t) {
    const e = this.rules.inline.br.exec(t);
    if (e)
      return {
        type: "br",
        raw: e[0]
      };
  }
  del(t) {
    const e = this.rules.inline.del.exec(t);
    if (e)
      return {
        type: "del",
        raw: e[0],
        text: e[2],
        tokens: this.lexer.inlineTokens(e[2])
      };
  }
  autolink(t) {
    const e = this.rules.inline.autolink.exec(t);
    if (e) {
      let n, i;
      return e[2] === "@" ? (n = Q(e[1]), i = "mailto:" + n) : (n = Q(e[1]), i = n), {
        type: "link",
        raw: e[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(t) {
    var n;
    let e;
    if (e = this.rules.inline.url.exec(t)) {
      let i, o;
      if (e[2] === "@")
        i = Q(e[0]), o = "mailto:" + i;
      else {
        let a;
        do
          a = e[0], e[0] = ((n = this.rules.inline._backpedal.exec(e[0])) == null ? void 0 : n[0]) ?? "";
        while (a !== e[0]);
        i = Q(e[0]), e[1] === "www." ? o = "http://" + e[0] : o = e[0];
      }
      return {
        type: "link",
        raw: e[0],
        text: i,
        href: o,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(t) {
    const e = this.rules.inline.text.exec(t);
    if (e) {
      let n;
      return this.lexer.state.inRawBlock ? n = e[0] : n = Q(e[0]), {
        type: "text",
        raw: e[0],
        text: n
      };
    }
  }
}
const ra = /^(?: *(?:\n|$))+/, oa = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, la = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Xe = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, sa = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ti = /(?:[*+-]|\d{1,9}[.)])/, ni = R(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, ti).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Ot = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ua = /^[^\n]+/, zt = /(?!\s*\])(?:\\.|[^\[\]\\])+/, ca = R(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", zt).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), _a = R(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ti).getRegex(), gt = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Pt = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, da = R("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Pt).replace("tag", gt).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ii = R(Ot).replace("hr", Xe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gt).getRegex(), pa = R(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ii).getRegex(), Mt = {
  blockquote: pa,
  code: oa,
  def: ca,
  fences: la,
  heading: sa,
  hr: Xe,
  html: da,
  lheading: ni,
  list: _a,
  newline: ra,
  paragraph: ii,
  table: He,
  text: ua
}, on = R("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Xe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gt).getRegex(), ha = {
  ...Mt,
  table: on,
  paragraph: R(Ot).replace("hr", Xe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", on).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", gt).getRegex()
}, fa = {
  ...Mt,
  html: R(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Pt).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: He,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: R(Ot).replace("hr", Xe).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ni).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, ai = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, ma = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ri = /^( {2,}|\\)\n(?!\s*$)/, ga = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, We = "\\p{P}\\p{S}", ba = R(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, We).getRegex(), va = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Da = R(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, We).getRegex(), ya = R("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, We).getRegex(), $a = R("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, We).getRegex(), wa = R(/\\([punct])/, "gu").replace(/punct/g, We).getRegex(), Fa = R(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Ea = R(Pt).replace("(?:-->|$)", "-->").getRegex(), ka = R("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Ea).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ut = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Ca = R(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", ut).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), oi = R(/^!?\[(label)\]\[(ref)\]/).replace("label", ut).replace("ref", zt).getRegex(), li = R(/^!?\[(ref)\](?:\[\])?/).replace("ref", zt).getRegex(), Aa = R("reflink|nolink(?!\\()", "g").replace("reflink", oi).replace("nolink", li).getRegex(), Ut = {
  _backpedal: He,
  // only used for GFM url
  anyPunctuation: wa,
  autolink: Fa,
  blockSkip: va,
  br: ri,
  code: ma,
  del: He,
  emStrongLDelim: Da,
  emStrongRDelimAst: ya,
  emStrongRDelimUnd: $a,
  escape: ai,
  link: Ca,
  nolink: li,
  punctuation: ba,
  reflink: oi,
  reflinkSearch: Aa,
  tag: ka,
  text: ga,
  url: He
}, Sa = {
  ...Ut,
  link: R(/^!?\[(label)\]\((.*?)\)/).replace("label", ut).getRegex(),
  reflink: R(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ut).getRegex()
}, At = {
  ...Ut,
  escape: R(ai).replace("])", "~|])").getRegex(),
  url: R(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ta = {
  ...At,
  br: R(ri).replace("{2,}", "*").getRegex(),
  text: R(At.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, et = {
  normal: Mt,
  gfm: ha,
  pedantic: fa
}, Me = {
  normal: Ut,
  gfm: At,
  breaks: Ta,
  pedantic: Sa
};
class $e {
  constructor(t) {
    O(this, "tokens");
    O(this, "options");
    O(this, "state");
    O(this, "tokenizer");
    O(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || Be, this.options.tokenizer = this.options.tokenizer || new st(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const e = {
      block: et.normal,
      inline: Me.normal
    };
    this.options.pedantic ? (e.block = et.pedantic, e.inline = Me.pedantic) : this.options.gfm && (e.block = et.gfm, this.options.breaks ? e.inline = Me.breaks : e.inline = Me.gfm), this.tokenizer.rules = e;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: et,
      inline: Me
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, e) {
    return new $e(e).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, e) {
    return new $e(e).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(/\r\n|\r/g, `
`), this.blockTokens(t, this.tokens);
    for (let e = 0; e < this.inlineQueue.length; e++) {
      const n = this.inlineQueue[e];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, e = []) {
    this.options.pedantic ? t = t.replace(/\t/g, "    ").replace(/^ +$/gm, "") : t = t.replace(/^( *)(\t+)/gm, (l, s, u) => s + "    ".repeat(u.length));
    let n, i, o, a;
    for (; t; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((l) => (n = l.call({ lexer: this }, t, e)) ? (t = t.substring(n.raw.length), e.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(t)) {
          t = t.substring(n.raw.length), n.raw.length === 1 && e.length > 0 ? e[e.length - 1].raw += `
` : e.push(n);
          continue;
        }
        if (n = this.tokenizer.code(t)) {
          t = t.substring(n.raw.length), i = e[e.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.list(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.html(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.def(t)) {
          t = t.substring(n.raw.length), i = e[e.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (o = t, this.options.extensions && this.options.extensions.startBlock) {
          let l = 1 / 0;
          const s = t.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
          }), l < 1 / 0 && l >= 0 && (o = t.substring(0, l + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          i = e[e.length - 1], a && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(n), a = o.length !== t.length, t = t.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(t)) {
          t = t.substring(n.raw.length), i = e[e.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(n);
          continue;
        }
        if (t) {
          const l = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(l);
            break;
          } else
            throw new Error(l);
        }
      }
    return this.state.top = !0, e;
  }
  inline(t, e = []) {
    return this.inlineQueue.push({ src: t, tokens: e }), e;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, e = []) {
    let n, i, o, a = t, l, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (l = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(l[0].slice(l[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (l = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (l = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, l.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; t; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, t, e)) ? (t = t.substring(n.raw.length), e.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(t)) {
          t = t.substring(n.raw.length), i = e[e.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : e.push(n);
          continue;
        }
        if (n = this.tokenizer.link(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(t, this.tokens.links)) {
          t = t.substring(n.raw.length), i = e[e.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : e.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(t, a, u)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.br(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.del(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(t)) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(t))) {
          t = t.substring(n.raw.length), e.push(n);
          continue;
        }
        if (o = t, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const _ = t.slice(1);
          let d;
          this.options.extensions.startInline.forEach((g) => {
            d = g.call({ lexer: this }, _), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (o = t.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          t = t.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = e[e.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : e.push(n);
          continue;
        }
        if (t) {
          const c = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return e;
  }
}
class ct {
  constructor(t) {
    O(this, "options");
    this.options = t || Be;
  }
  code(t, e, n) {
    var o;
    const i = (o = (e || "").match(/^\S*/)) == null ? void 0 : o[0];
    return t = t.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + Q(i) + '">' + (n ? t : Q(t, !0)) + `</code></pre>
` : "<pre><code>" + (n ? t : Q(t, !0)) + `</code></pre>
`;
  }
  blockquote(t) {
    return `<blockquote>
${t}</blockquote>
`;
  }
  html(t, e) {
    return t;
  }
  heading(t, e, n) {
    return `<h${e}>${t}</h${e}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(t, e, n) {
    const i = e ? "ol" : "ul", o = e && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + o + `>
` + t + "</" + i + `>
`;
  }
  listitem(t, e, n) {
    return `<li>${t}</li>
`;
  }
  checkbox(t) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(t) {
    return `<p>${t}</p>
`;
  }
  table(t, e) {
    return e && (e = `<tbody>${e}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + e + `</table>
`;
  }
  tablerow(t) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t, e) {
    const n = e.header ? "th" : "td";
    return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(t) {
    return `<strong>${t}</strong>`;
  }
  em(t) {
    return `<em>${t}</em>`;
  }
  codespan(t) {
    return `<code>${t}</code>`;
  }
  br() {
    return "<br>";
  }
  del(t) {
    return `<del>${t}</del>`;
  }
  link(t, e, n) {
    const i = nn(t);
    if (i === null)
      return n;
    t = i;
    let o = '<a href="' + t + '"';
    return e && (o += ' title="' + e + '"'), o += ">" + n + "</a>", o;
  }
  image(t, e, n) {
    const i = nn(t);
    if (i === null)
      return n;
    t = i;
    let o = `<img src="${t}" alt="${n}"`;
    return e && (o += ` title="${e}"`), o += ">", o;
  }
  text(t) {
    return t;
  }
}
class Gt {
  // no need for block level renderers
  strong(t) {
    return t;
  }
  em(t) {
    return t;
  }
  codespan(t) {
    return t;
  }
  del(t) {
    return t;
  }
  html(t) {
    return t;
  }
  text(t) {
    return t;
  }
  link(t, e, n) {
    return "" + n;
  }
  image(t, e, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class we {
  constructor(t) {
    O(this, "options");
    O(this, "renderer");
    O(this, "textRenderer");
    this.options = t || Be, this.options.renderer = this.options.renderer || new ct(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Gt();
  }
  /**
   * Static Parse Method
   */
  static parse(t, e) {
    return new we(e).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, e) {
    return new we(e).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, e = !0) {
    let n = "";
    for (let i = 0; i < t.length; i++) {
      const o = t[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = o, l = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = o;
          n += this.renderer.heading(this.parseInline(a.tokens), a.depth, ta(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = o;
          n += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = o;
          let l = "", s = "";
          for (let c = 0; c < a.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          l += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < a.rows.length; c++) {
            const _ = a.rows[c];
            s = "";
            for (let d = 0; d < _.length; d++)
              s += this.renderer.tablecell(this.parseInline(_[d].tokens), { header: !1, align: a.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(l, u);
          continue;
        }
        case "blockquote": {
          const a = o, l = this.parse(a.tokens);
          n += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          const a = o, l = a.ordered, s = a.start, u = a.loose;
          let c = "";
          for (let _ = 0; _ < a.items.length; _++) {
            const d = a.items[_], g = d.checked, f = d.task;
            let b = "";
            if (d.task) {
              const v = this.renderer.checkbox(!!g);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = v + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = v + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: v + " "
              }) : b += v + " ";
            }
            b += this.parse(d.tokens, u), c += this.renderer.listitem(b, f, !!g);
          }
          n += this.renderer.list(c, l, s);
          continue;
        }
        case "html": {
          const a = o;
          n += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = o;
          n += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = o, l = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; i + 1 < t.length && t[i + 1].type === "text"; )
            a = t[++i], l += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          n += e ? this.renderer.paragraph(l) : l;
          continue;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, e) {
    e = e || this.renderer;
    let n = "";
    for (let i = 0; i < t.length; i++) {
      const o = t[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += a || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const a = o;
          n += e.text(a.text);
          break;
        }
        case "html": {
          const a = o;
          n += e.html(a.text);
          break;
        }
        case "link": {
          const a = o;
          n += e.link(a.href, a.title, this.parseInline(a.tokens, e));
          break;
        }
        case "image": {
          const a = o;
          n += e.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = o;
          n += e.strong(this.parseInline(a.tokens, e));
          break;
        }
        case "em": {
          const a = o;
          n += e.em(this.parseInline(a.tokens, e));
          break;
        }
        case "codespan": {
          const a = o;
          n += e.codespan(a.text);
          break;
        }
        case "br": {
          n += e.br();
          break;
        }
        case "del": {
          const a = o;
          n += e.del(this.parseInline(a.tokens, e));
          break;
        }
        case "text": {
          const a = o;
          n += e.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
}
class je {
  constructor(t) {
    O(this, "options");
    this.options = t || Be;
  }
  /**
   * Process markdown before marked
   */
  preprocess(t) {
    return t;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(t) {
    return t;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(t) {
    return t;
  }
}
O(je, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var xe, St, si;
class xa {
  constructor(...t) {
    Wt(this, xe);
    O(this, "defaults", Nt());
    O(this, "options", this.setOptions);
    O(this, "parse", Qe(this, xe, St).call(this, $e.lex, we.parse));
    O(this, "parseInline", Qe(this, xe, St).call(this, $e.lexInline, we.parseInline));
    O(this, "Parser", we);
    O(this, "Renderer", ct);
    O(this, "TextRenderer", Gt);
    O(this, "Lexer", $e);
    O(this, "Tokenizer", st);
    O(this, "Hooks", je);
    this.use(...t);
  }
  /**
   * Run callback for every token
   */
  walkTokens(t, e) {
    var i, o;
    let n = [];
    for (const a of t)
      switch (n = n.concat(e.call(this, a)), a.type) {
        case "table": {
          const l = a;
          for (const s of l.header)
            n = n.concat(this.walkTokens(s.tokens, e));
          for (const s of l.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, e));
          break;
        }
        case "list": {
          const l = a;
          n = n.concat(this.walkTokens(l.items, e));
          break;
        }
        default: {
          const l = a;
          (o = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && o[l.type] ? this.defaults.extensions.childTokens[l.type].forEach((s) => {
            const u = l[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, e));
          }) : l.tokens && (n = n.concat(this.walkTokens(l.tokens, e)));
        }
      }
    return n;
  }
  use(...t) {
    const e = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const a = e.renderers[o.name];
          a ? e.renderers[o.name] = function(...l) {
            let s = o.renderer.apply(this, l);
            return s === !1 && (s = a.apply(this, l)), s;
          } : e.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = e[o.level];
          a ? a.unshift(o.tokenizer) : e[o.level] = [o.tokenizer], o.start && (o.level === "block" ? e.startBlock ? e.startBlock.push(o.start) : e.startBlock = [o.start] : o.level === "inline" && (e.startInline ? e.startInline.push(o.start) : e.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (e.childTokens[o.name] = o.childTokens);
      }), i.extensions = e), n.renderer) {
        const o = this.defaults.renderer || new ct(this.defaults);
        for (const a in n.renderer) {
          if (!(a in o))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const l = a, s = n.renderer[l], u = o[l];
          o[l] = (...c) => {
            let _ = s.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _ || "";
          };
        }
        i.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new st(this.defaults);
        for (const a in n.tokenizer) {
          if (!(a in o))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const l = a, s = n.tokenizer[l], u = o[l];
          o[l] = (...c) => {
            let _ = s.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _;
          };
        }
        i.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new je();
        for (const a in n.hooks) {
          if (!(a in o))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const l = a, s = n.hooks[l], u = o[l];
          je.passThroughHooks.has(a) ? o[l] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((d) => u.call(o, d));
            const _ = s.call(o, c);
            return u.call(o, _);
          } : o[l] = (...c) => {
            let _ = s.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _;
          };
        }
        i.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, a = n.walkTokens;
        i.walkTokens = function(l) {
          let s = [];
          return s.push(a.call(this, l)), o && (s = s.concat(o.call(this, l))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, e) {
    return $e.lex(t, e ?? this.defaults);
  }
  parser(t, e) {
    return we.parse(t, e ?? this.defaults);
  }
}
xe = new WeakSet(), St = function(t, e) {
  return (n, i) => {
    const o = { ...i }, a = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const l = Qe(this, xe, si).call(this, !!a.silent, !!a.async);
    if (typeof n > "u" || n === null)
      return l(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return l(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(n) : n).then((s) => t(s, a)).then((s) => a.hooks ? a.hooks.processAllTokens(s) : s).then((s) => a.walkTokens ? Promise.all(this.walkTokens(s, a.walkTokens)).then(() => s) : s).then((s) => e(s, a)).then((s) => a.hooks ? a.hooks.postprocess(s) : s).catch(l);
    try {
      a.hooks && (n = a.hooks.preprocess(n));
      let s = t(n, a);
      a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
      let u = e(s, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (s) {
      return l(s);
    }
  };
}, si = function(t, e) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
      const i = "<p>An error occurred:</p><pre>" + Q(n.message + "", !0) + "</pre>";
      return e ? Promise.resolve(i) : i;
    }
    if (e)
      return Promise.reject(n);
    throw n;
  };
};
const Te = new xa();
function I(r, t) {
  return Te.parse(r, t);
}
I.options = I.setOptions = function(r) {
  return Te.setOptions(r), I.defaults = Te.defaults, Qn(I.defaults), I;
};
I.getDefaults = Nt;
I.defaults = Be;
I.use = function(...r) {
  return Te.use(...r), I.defaults = Te.defaults, Qn(I.defaults), I;
};
I.walkTokens = function(r, t) {
  return Te.walkTokens(r, t);
};
I.parseInline = Te.parseInline;
I.Parser = we;
I.parser = we.parse;
I.Renderer = ct;
I.TextRenderer = Gt;
I.Lexer = $e;
I.lexer = $e.lex;
I.Tokenizer = st;
I.Hooks = je;
I.parse = I;
I.options;
I.setOptions;
I.use;
I.walkTokens;
I.parseInline;
we.parse;
$e.lex;
const Ba = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Ia = Object.hasOwnProperty;
class ui {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(t, e) {
    const n = this;
    let i = Ra(t, e === !0);
    const o = i;
    for (; Ia.call(n.occurrences, i); )
      n.occurrences[o]++, i = o + "-" + n.occurrences[o];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ra(r, t) {
  return typeof r != "string" ? "" : (t || (r = r.toLowerCase()), r.replace(Ba, "").replace(/ /g, "-"));
}
new ui();
var ln = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, qa = { exports: {} };
(function(r) {
  var t = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var e = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, a = {}, l = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(p) {
          return p instanceof s ? new s(p.type, h(p.content), p.alias) : Array.isArray(p) ? p.map(h) : p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++o }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(p, m) {
          m = m || {};
          var D, y;
          switch (l.util.type(p)) {
            case "Object":
              if (y = l.util.objId(p), m[y])
                return m[y];
              D = /** @type {Record<string, any>} */
              {}, m[y] = D;
              for (var w in p)
                p.hasOwnProperty(w) && (D[w] = h(p[w], m));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return y = l.util.objId(p), m[y] ? m[y] : (D = [], m[y] = D, /** @type {Array} */
              /** @type {any} */
              p.forEach(function(S, F) {
                D[F] = h(S, m);
              }), /** @type {any} */
              D);
            default:
              return p;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var p = i.exec(h.className);
            if (p)
              return p[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, p) {
          h.className = h.className.replace(RegExp(i, "gi"), ""), h.classList.add("language-" + p);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (h) {
              var p = document.getElementsByTagName("script");
              for (var m in p)
                if (p[m].src == h)
                  return p[m];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, p, m) {
          for (var D = "no-" + p; h; ) {
            var y = h.classList;
            if (y.contains(p))
              return !0;
            if (y.contains(D))
              return !1;
            h = h.parentElement;
          }
          return !!m;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, p) {
          var m = l.util.clone(l.languages[h]);
          for (var D in p)
            m[D] = p[D];
          return m;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, p, m, D) {
          D = D || /** @type {any} */
          l.languages;
          var y = D[h], w = {};
          for (var S in y)
            if (y.hasOwnProperty(S)) {
              if (S == p)
                for (var F in m)
                  m.hasOwnProperty(F) && (w[F] = m[F]);
              m.hasOwnProperty(S) || (w[S] = y[S]);
            }
          var T = D[h];
          return D[h] = w, l.languages.DFS(l.languages, function(N, L) {
            L === T && N != h && (this[N] = w);
          }), w;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(p, m, D, y) {
          y = y || {};
          var w = l.util.objId;
          for (var S in p)
            if (p.hasOwnProperty(S)) {
              m.call(p, S, p[S], D || S);
              var F = p[S], T = l.util.type(F);
              T === "Object" && !y[w(F)] ? (y[w(F)] = !0, h(F, m, null, y)) : T === "Array" && !y[w(F)] && (y[w(F)] = !0, h(F, m, S, y));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, p) {
        l.highlightAllUnder(document, h, p);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, p, m) {
        var D = {
          callback: m,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        l.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), l.hooks.run("before-all-elements-highlight", D);
        for (var y = 0, w; w = D.elements[y++]; )
          l.highlightElement(w, p === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, p, m) {
        var D = l.util.getLanguage(h), y = l.languages[D];
        l.util.setLanguage(h, D);
        var w = h.parentElement;
        w && w.nodeName.toLowerCase() === "pre" && l.util.setLanguage(w, D);
        var S = h.textContent, F = {
          element: h,
          language: D,
          grammar: y,
          code: S
        };
        function T(L) {
          F.highlightedCode = L, l.hooks.run("before-insert", F), F.element.innerHTML = F.highlightedCode, l.hooks.run("after-highlight", F), l.hooks.run("complete", F), m && m.call(F.element);
        }
        if (l.hooks.run("before-sanity-check", F), w = F.element.parentElement, w && w.nodeName.toLowerCase() === "pre" && !w.hasAttribute("tabindex") && w.setAttribute("tabindex", "0"), !F.code) {
          l.hooks.run("complete", F), m && m.call(F.element);
          return;
        }
        if (l.hooks.run("before-highlight", F), !F.grammar) {
          T(l.util.encode(F.code));
          return;
        }
        if (p && n.Worker) {
          var N = new Worker(l.filename);
          N.onmessage = function(L) {
            T(L.data);
          }, N.postMessage(JSON.stringify({
            language: F.language,
            code: F.code,
            immediateClose: !0
          }));
        } else
          T(l.highlight(F.code, F.grammar, F.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, p, m) {
        var D = {
          code: h,
          grammar: p,
          language: m
        };
        if (l.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = l.tokenize(D.code, D.grammar), l.hooks.run("after-tokenize", D), s.stringify(l.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, p) {
        var m = p.rest;
        if (m) {
          for (var D in m)
            p[D] = m[D];
          delete p.rest;
        }
        var y = new _();
        return d(y, y.head, h), c(h, y, p, y.head, 0), f(y);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, p) {
          var m = l.hooks.all;
          m[h] = m[h] || [], m[h].push(p);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, p) {
          var m = l.hooks.all[h];
          if (!(!m || !m.length))
            for (var D = 0, y; y = m[D++]; )
              y(p);
        }
      },
      Token: s
    };
    n.Prism = l;
    function s(h, p, m, D) {
      this.type = h, this.content = p, this.alias = m, this.length = (D || "").length | 0;
    }
    s.stringify = function h(p, m) {
      if (typeof p == "string")
        return p;
      if (Array.isArray(p)) {
        var D = "";
        return p.forEach(function(T) {
          D += h(T, m);
        }), D;
      }
      var y = {
        type: p.type,
        content: h(p.content, m),
        tag: "span",
        classes: ["token", p.type],
        attributes: {},
        language: m
      }, w = p.alias;
      w && (Array.isArray(w) ? Array.prototype.push.apply(y.classes, w) : y.classes.push(w)), l.hooks.run("wrap", y);
      var S = "";
      for (var F in y.attributes)
        S += " " + F + '="' + (y.attributes[F] || "").replace(/"/g, "&quot;") + '"';
      return "<" + y.tag + ' class="' + y.classes.join(" ") + '"' + S + ">" + y.content + "</" + y.tag + ">";
    };
    function u(h, p, m, D) {
      h.lastIndex = p;
      var y = h.exec(m);
      if (y && D && y[1]) {
        var w = y[1].length;
        y.index += w, y[0] = y[0].slice(w);
      }
      return y;
    }
    function c(h, p, m, D, y, w) {
      for (var S in m)
        if (!(!m.hasOwnProperty(S) || !m[S])) {
          var F = m[S];
          F = Array.isArray(F) ? F : [F];
          for (var T = 0; T < F.length; ++T) {
            if (w && w.cause == S + "," + T)
              return;
            var N = F[T], L = N.inside, ue = !!N.lookbehind, te = !!N.greedy, Ae = N.alias;
            if (te && !N.pattern.global) {
              var X = N.pattern.toString().match(/[imsuy]*$/)[0];
              N.pattern = RegExp(N.pattern.source, X + "g");
            }
            for (var ce = N.pattern || N, q = D.next, j = y; q !== p.tail && !(w && j >= w.reach); j += q.value.length, q = q.next) {
              var ge = q.value;
              if (p.length > h.length)
                return;
              if (!(ge instanceof s)) {
                var $ = 1, U;
                if (te) {
                  if (U = u(ce, j, h, ue), !U || U.index >= h.length)
                    break;
                  var ke = U.index, Fe = U.index + U[0].length, W = j;
                  for (W += q.value.length; ke >= W; )
                    q = q.next, W += q.value.length;
                  if (W -= q.value.length, j = W, q.value instanceof s)
                    continue;
                  for (var be = q; be !== p.tail && (W < Fe || typeof be.value == "string"); be = be.next)
                    $++, W += be.value.length;
                  $--, ge = h.slice(j, W), U.index -= j;
                } else if (U = u(ce, 0, ge, ue), !U)
                  continue;
                var ke = U.index, Ie = U[0], C = ge.slice(0, ke), Yt = ge.slice(ke + Ie.length), bt = j + ge.length;
                w && bt > w.reach && (w.reach = bt);
                var Ke = q.prev;
                C && (Ke = d(p, Ke, C), j += C.length), g(p, Ke, $);
                var xi = new s(S, L ? l.tokenize(Ie, L) : Ie, Ae, Ie);
                if (q = d(p, Ke, xi), Yt && d(p, q, Yt), $ > 1) {
                  var vt = {
                    cause: S + "," + T,
                    reach: bt
                  };
                  c(h, p, m, q.prev, j, vt), w && vt.reach > w.reach && (w.reach = vt.reach);
                }
              }
            }
          }
        }
    }
    function _() {
      var h = { value: null, prev: null, next: null }, p = { value: null, prev: h, next: null };
      h.next = p, this.head = h, this.tail = p, this.length = 0;
    }
    function d(h, p, m) {
      var D = p.next, y = { value: m, prev: p, next: D };
      return p.next = y, D.prev = y, h.length++, y;
    }
    function g(h, p, m) {
      for (var D = p.next, y = 0; y < m && D !== h.tail; y++)
        D = D.next;
      p.next = D, D.prev = p, h.length -= y;
    }
    function f(h) {
      for (var p = [], m = h.head.next; m !== h.tail; )
        p.push(m.value), m = m.next;
      return p;
    }
    if (!n.document)
      return n.addEventListener && (l.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var p = JSON.parse(h.data), m = p.language, D = p.code, y = p.immediateClose;
        n.postMessage(l.highlight(D, l.languages[m], m)), y && n.close();
      }, !1)), l;
    var b = l.util.currentScript();
    b && (l.filename = b.src, b.hasAttribute("data-manual") && (l.manual = !0));
    function v() {
      l.manual || l.highlightAll();
    }
    if (!l.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && b && b.defer ? document.addEventListener("DOMContentLoaded", v) : window.requestAnimationFrame ? window.requestAnimationFrame(v) : window.setTimeout(v, 16);
    }
    return l;
  }(t);
  r.exports && (r.exports = e), typeof ln < "u" && (ln.Prism = e), e.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, e.languages.markup.tag.inside["attr-value"].inside.entity = e.languages.markup.entity, e.languages.markup.doctype.inside["internal-subset"].inside = e.languages.markup, e.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(e.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, o) {
      var a = {};
      a["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: e.languages[o]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      l["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: e.languages[o]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, e.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(e.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      e.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: e.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), e.languages.html = e.languages.markup, e.languages.mathml = e.languages.markup, e.languages.svg = e.languages.markup, e.languages.xml = e.languages.extend("markup", {}), e.languages.ssml = e.languages.xml, e.languages.atom = e.languages.xml, e.languages.rss = e.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(e), e.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, e.languages.javascript = e.languages.extend("clike", {
    "class-name": [
      e.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), e.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, e.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: e.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: e.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), e.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: e.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), e.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), e.languages.markup && (e.languages.markup.tag.addInlined("script", "javascript"), e.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), e.languages.js = e.languages.javascript, function() {
    if (typeof e > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(b, v) {
      return "✖ Error " + b + " while fetching file: " + v;
    }, o = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, l = "data-src-status", s = "loading", u = "loaded", c = "failed", _ = "pre[data-src]:not([" + l + '="' + u + '"]):not([' + l + '="' + s + '"])';
    function d(b, v, k) {
      var h = new XMLHttpRequest();
      h.open("GET", b, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? v(h.responseText) : h.status >= 400 ? k(i(h.status, h.statusText)) : k(o));
      }, h.send(null);
    }
    function g(b) {
      var v = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(b || "");
      if (v) {
        var k = Number(v[1]), h = v[2], p = v[3];
        return h ? p ? [k, Number(p)] : [k, void 0] : [k, k];
      }
    }
    e.hooks.add("before-highlightall", function(b) {
      b.selector += ", " + _;
    }), e.hooks.add("before-sanity-check", function(b) {
      var v = (
        /** @type {HTMLPreElement} */
        b.element
      );
      if (v.matches(_)) {
        b.code = "", v.setAttribute(l, s);
        var k = v.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var h = v.getAttribute("data-src"), p = b.language;
        if (p === "none") {
          var m = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          p = a[m] || m;
        }
        e.util.setLanguage(k, p), e.util.setLanguage(v, p);
        var D = e.plugins.autoloader;
        D && D.loadLanguages(p), d(
          h,
          function(y) {
            v.setAttribute(l, u);
            var w = g(v.getAttribute("data-range"));
            if (w) {
              var S = y.split(/\r\n?|\n/g), F = w[0], T = w[1] == null ? S.length : w[1];
              F < 0 && (F += S.length), F = Math.max(0, Math.min(F - 1, S.length)), T < 0 && (T += S.length), T = Math.max(0, Math.min(T, S.length)), y = S.slice(F, T).join(`
`), v.hasAttribute("data-start") || v.setAttribute("data-start", String(F + 1));
            }
            k.textContent = y, e.highlightElement(k);
          },
          function(y) {
            v.setAttribute(l, c), k.textContent = y;
          }
        );
      }
    }), e.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(v) {
        for (var k = (v || document).querySelectorAll(_), h = 0, p; p = k[h++]; )
          e.highlightElement(p);
      }
    };
    var f = !1;
    e.fileHighlight = function() {
      f || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), f = !0), e.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(qa);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var t = /\\(?:[^a-z()[\]]|[a-z*]+)/i, e = {
    "equation-command": {
      pattern: t,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: e,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: e,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: t,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var t = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", e = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: e,
    environment: {
      pattern: RegExp("\\$" + t),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + t),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + t),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: e
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + t),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, e.inside = r.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, a = 0; a < i.length; a++)
    o[i[a]] = r.languages.bash[i[a]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(r) {
  var t = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, e = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return t.source;
  });
  r.languages.cpp = r.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return t.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: t,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), r.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return e;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), r.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: r.languages.cpp
        }
      }
    }
  }), r.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), r.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: r.languages.extend("cpp", {})
    }
  }), r.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, r.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(r) {
  var t = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, e = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, n = {
    pattern: RegExp(/(^|[^\w.])/.source + e + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  r.languages.java = r.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      n,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + e + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: n.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + e + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: n.inside
      }
    ],
    keyword: t,
    function: [
      r.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), r.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), r.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": n,
        keyword: t,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + e + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: n.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + e + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: n.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return t.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(r) {
  for (var t = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, e = 0; e < 2; e++)
    t = t.replace(/<self>/g, function() {
      return t;
    });
  t = t.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), r.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + t),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, r.languages.rust["closure-params"].inside.rest = r.languages.rust, r.languages.rust.attribute.inside.string = r.languages.rust.string;
})(Prism);
(function(r) {
  var t = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, e = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], n = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, i = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, o = /[{}\[\](),:;]/;
  r.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: t,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: e,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: n,
    operator: i,
    punctuation: o
  };
  var a = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: r.languages.php
  }, l = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: a
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: a
      }
    }
  ];
  r.languages.insertBefore("php", "variable", {
    string: l,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: t,
            string: l,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: e,
            number: n,
            operator: i,
            punctuation: o
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), r.hooks.add("before-tokenize", function(s) {
    if (/<\?/.test(s.code)) {
      var u = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      r.languages["markup-templating"].buildPlaceholders(s, "php", u);
    }
  }), r.hooks.add("after-tokenize", function(s) {
    r.languages["markup-templating"].tokenizePlaceholders(s, "php");
  });
})(Prism);
(function(r) {
  var t = /[*&][^\s[\]{},]+/, e = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, n = "(?:" + e.source + "(?:[ 	]+" + t.source + ")?|" + t.source + "(?:[ 	]+" + e.source + ")?)", i = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), o = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function a(l, s) {
    s = (s || "").replace(/m/g, "") + "m";
    var u = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return n;
    }).replace(/<<value>>/g, function() {
      return l;
    });
    return RegExp(u, s);
  }
  r.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return n;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return n;
      }).replace(/<<key>>/g, function() {
        return "(?:" + i + "|" + o + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: a(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: a(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: a(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: a(o),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: a(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: e,
    important: t,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, r.languages.yml = r.languages.yaml;
})(Prism);
(function(r) {
  function t(e, n) {
    return "___" + e.toUpperCase() + n + "___";
  }
  Object.defineProperties(r.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(e, n, i, o) {
        if (e.language === n) {
          var a = e.tokenStack = [];
          e.code = e.code.replace(i, function(l) {
            if (typeof o == "function" && !o(l))
              return l;
            for (var s = a.length, u; e.code.indexOf(u = t(n, s)) !== -1; )
              ++s;
            return a[s] = l, u;
          }), e.grammar = r.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(e, n) {
        if (e.language !== n || !e.tokenStack)
          return;
        e.grammar = r.languages[n];
        var i = 0, o = Object.keys(e.tokenStack);
        function a(l) {
          for (var s = 0; s < l.length && !(i >= o.length); s++) {
            var u = l[s];
            if (typeof u == "string" || u.content && typeof u.content == "string") {
              var c = o[i], _ = e.tokenStack[c], d = typeof u == "string" ? u : u.content, g = t(n, c), f = d.indexOf(g);
              if (f > -1) {
                ++i;
                var b = d.substring(0, f), v = new r.Token(n, r.tokenize(_, e.grammar), "language-" + n, _), k = d.substring(f + g.length), h = [];
                b && h.push.apply(h, a([b])), h.push(v), k && h.push.apply(h, a([k])), typeof u == "string" ? l.splice.apply(l, [s, 1].concat(h)) : u.content = h;
              }
            } else u.content && a(u.content);
          }
          return l;
        }
        a(e.tokens);
      }
    }
  });
})(Prism);
new ui();
const La = (r) => {
  const t = {};
  for (let e = 0, n = r.length; e < n; e++) {
    const i = r[e];
    for (const o in i)
      t[o] ? t[o] = t[o].concat(i[o]) : t[o] = i[o];
  }
  return t;
}, Na = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Oa = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], za = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
La([
  Object.fromEntries(Na.map((r) => [r, ["*"]])),
  Object.fromEntries(Oa.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(za.map((r) => [r, ["math:*"]]))
]);
const {
  HtmlTagHydration: io,
  SvelteComponent: ao,
  attr: ro,
  binding_callbacks: oo,
  children: lo,
  claim_element: so,
  claim_html_tag: uo,
  detach: co,
  element: _o,
  init: po,
  insert_hydration: ho,
  noop: fo,
  safe_not_equal: mo,
  toggle_class: go
} = window.__gradio__svelte__internal, { afterUpdate: bo, tick: vo, onMount: Do } = window.__gradio__svelte__internal, {
  SvelteComponent: yo,
  attr: $o,
  children: wo,
  claim_component: Fo,
  claim_element: Eo,
  create_component: ko,
  destroy_component: Co,
  detach: Ao,
  element: So,
  init: To,
  insert_hydration: xo,
  mount_component: Bo,
  safe_not_equal: Io,
  transition_in: Ro,
  transition_out: qo
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lo,
  attr: No,
  check_outros: Oo,
  children: zo,
  claim_component: Po,
  claim_element: Mo,
  claim_space: Uo,
  create_component: Go,
  create_slot: Ho,
  destroy_component: jo,
  detach: Zo,
  element: Vo,
  empty: Yo,
  get_all_dirty_from_scope: Xo,
  get_slot_changes: Wo,
  group_outros: Ko,
  init: Qo,
  insert_hydration: Jo,
  mount_component: el,
  safe_not_equal: tl,
  space: nl,
  toggle_class: il,
  transition_in: al,
  transition_out: rl,
  update_slot_base: ol
} = window.__gradio__svelte__internal, {
  SvelteComponent: ll,
  append_hydration: sl,
  attr: ul,
  children: cl,
  claim_component: _l,
  claim_element: dl,
  claim_space: pl,
  claim_text: hl,
  create_component: fl,
  destroy_component: ml,
  detach: gl,
  element: bl,
  init: vl,
  insert_hydration: Dl,
  mount_component: yl,
  safe_not_equal: $l,
  set_data: wl,
  space: Fl,
  text: El,
  toggle_class: kl,
  transition_in: Cl,
  transition_out: Al
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sl,
  assign: Tl,
  children: xl,
  claim_element: Bl,
  compute_rest_props: Il,
  create_slot: Rl,
  detach: ql,
  element: Ll,
  exclude_internal_props: Nl,
  get_all_dirty_from_scope: Ol,
  get_slot_changes: zl,
  get_spread_update: Pl,
  init: Ml,
  insert_hydration: Ul,
  listen: Gl,
  safe_not_equal: Hl,
  set_attributes: jl,
  set_style: Zl,
  toggle_class: Vl,
  transition_in: Yl,
  transition_out: Xl,
  update_slot_base: Wl
} = window.__gradio__svelte__internal, { createEventDispatcher: Kl } = window.__gradio__svelte__internal, {
  SvelteComponent: Pa,
  append_hydration: ot,
  attr: Ee,
  bubble: Ma,
  check_outros: Ua,
  children: Tt,
  claim_component: Ga,
  claim_element: xt,
  claim_space: sn,
  claim_text: Ha,
  construct_svelte_component: un,
  create_component: cn,
  create_slot: ja,
  destroy_component: _n,
  detach: Ze,
  element: Bt,
  get_all_dirty_from_scope: Za,
  get_slot_changes: Va,
  group_outros: Ya,
  init: Xa,
  insert_hydration: ci,
  listen: Wa,
  mount_component: dn,
  safe_not_equal: Ka,
  set_data: Qa,
  set_style: Re,
  space: pn,
  text: Ja,
  toggle_class: G,
  transition_in: $t,
  transition_out: wt,
  update_slot_base: er
} = window.__gradio__svelte__internal;
function hn(r) {
  let t, e;
  return {
    c() {
      t = Bt("span"), e = Ja(
        /*label*/
        r[1]
      ), this.h();
    },
    l(n) {
      t = xt(n, "SPAN", { class: !0 });
      var i = Tt(t);
      e = Ha(
        i,
        /*label*/
        r[1]
      ), i.forEach(Ze), this.h();
    },
    h() {
      Ee(t, "class", "svelte-y0enk4");
    },
    m(n, i) {
      ci(n, t, i), ot(t, e);
    },
    p(n, i) {
      i & /*label*/
      2 && Qa(
        e,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Ze(t);
    }
  };
}
function tr(r) {
  let t, e, n, i, o, a, l, s, u = (
    /*show_label*/
    r[2] && hn(r)
  );
  var c = (
    /*Icon*/
    r[0]
  );
  function _(f, b) {
    return {};
  }
  c && (i = un(c, _()));
  const d = (
    /*#slots*/
    r[15].default
  ), g = ja(
    d,
    r,
    /*$$scope*/
    r[14],
    null
  );
  return {
    c() {
      t = Bt("button"), u && u.c(), e = pn(), n = Bt("div"), i && cn(i.$$.fragment), o = pn(), g && g.c(), this.h();
    },
    l(f) {
      t = xt(f, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0
      });
      var b = Tt(t);
      u && u.l(b), e = sn(b), n = xt(b, "DIV", { class: !0 });
      var v = Tt(n);
      i && Ga(i.$$.fragment, v), o = sn(v), g && g.l(v), v.forEach(Ze), b.forEach(Ze), this.h();
    },
    h() {
      Ee(n, "class", "svelte-y0enk4"), G(
        n,
        "x-small",
        /*size*/
        r[4] === "x-small"
      ), G(
        n,
        "small",
        /*size*/
        r[4] === "small"
      ), G(
        n,
        "large",
        /*size*/
        r[4] === "large"
      ), G(
        n,
        "medium",
        /*size*/
        r[4] === "medium"
      ), Ee(t, "class", "icon-button svelte-y0enk4"), t.disabled = /*disabled*/
      r[7], Ee(
        t,
        "aria-label",
        /*label*/
        r[1]
      ), Ee(
        t,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), Ee(
        t,
        "title",
        /*label*/
        r[1]
      ), G(
        t,
        "pending",
        /*pending*/
        r[3]
      ), G(
        t,
        "padded",
        /*padded*/
        r[5]
      ), G(
        t,
        "highlight",
        /*highlight*/
        r[6]
      ), G(
        t,
        "transparent",
        /*transparent*/
        r[9]
      ), Re(
        t,
        "--border-color",
        /*border*/
        r[11]
      ), Re(t, "color", !/*disabled*/
      r[7] && /*_color*/
      r[12] ? (
        /*_color*/
        r[12]
      ) : "var(--block-label-text-color)"), Re(t, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      ));
    },
    m(f, b) {
      ci(f, t, b), u && u.m(t, null), ot(t, e), ot(t, n), i && dn(i, n, null), ot(n, o), g && g.m(n, null), a = !0, l || (s = Wa(
        t,
        "click",
        /*click_handler*/
        r[16]
      ), l = !0);
    },
    p(f, [b]) {
      if (/*show_label*/
      f[2] ? u ? u.p(f, b) : (u = hn(f), u.c(), u.m(t, e)) : u && (u.d(1), u = null), b & /*Icon*/
      1 && c !== (c = /*Icon*/
      f[0])) {
        if (i) {
          Ya();
          const v = i;
          wt(v.$$.fragment, 1, 0, () => {
            _n(v, 1);
          }), Ua();
        }
        c ? (i = un(c, _()), cn(i.$$.fragment), $t(i.$$.fragment, 1), dn(i, n, o)) : i = null;
      }
      g && g.p && (!a || b & /*$$scope*/
      16384) && er(
        g,
        d,
        f,
        /*$$scope*/
        f[14],
        a ? Va(
          d,
          /*$$scope*/
          f[14],
          b,
          null
        ) : Za(
          /*$$scope*/
          f[14]
        ),
        null
      ), (!a || b & /*size*/
      16) && G(
        n,
        "x-small",
        /*size*/
        f[4] === "x-small"
      ), (!a || b & /*size*/
      16) && G(
        n,
        "small",
        /*size*/
        f[4] === "small"
      ), (!a || b & /*size*/
      16) && G(
        n,
        "large",
        /*size*/
        f[4] === "large"
      ), (!a || b & /*size*/
      16) && G(
        n,
        "medium",
        /*size*/
        f[4] === "medium"
      ), (!a || b & /*disabled*/
      128) && (t.disabled = /*disabled*/
      f[7]), (!a || b & /*label*/
      2) && Ee(
        t,
        "aria-label",
        /*label*/
        f[1]
      ), (!a || b & /*hasPopup*/
      256) && Ee(
        t,
        "aria-haspopup",
        /*hasPopup*/
        f[8]
      ), (!a || b & /*label*/
      2) && Ee(
        t,
        "title",
        /*label*/
        f[1]
      ), (!a || b & /*pending*/
      8) && G(
        t,
        "pending",
        /*pending*/
        f[3]
      ), (!a || b & /*padded*/
      32) && G(
        t,
        "padded",
        /*padded*/
        f[5]
      ), (!a || b & /*highlight*/
      64) && G(
        t,
        "highlight",
        /*highlight*/
        f[6]
      ), (!a || b & /*transparent*/
      512) && G(
        t,
        "transparent",
        /*transparent*/
        f[9]
      ), b & /*border*/
      2048 && Re(
        t,
        "--border-color",
        /*border*/
        f[11]
      ), b & /*disabled, _color*/
      4224 && Re(t, "color", !/*disabled*/
      f[7] && /*_color*/
      f[12] ? (
        /*_color*/
        f[12]
      ) : "var(--block-label-text-color)"), b & /*disabled, background*/
      1152 && Re(t, "--bg-color", /*disabled*/
      f[7] ? "auto" : (
        /*background*/
        f[10]
      ));
    },
    i(f) {
      a || (i && $t(i.$$.fragment, f), $t(g, f), a = !0);
    },
    o(f) {
      i && wt(i.$$.fragment, f), wt(g, f), a = !1;
    },
    d(f) {
      f && Ze(t), u && u.d(), i && _n(i), g && g.d(f), l = !1, s();
    }
  };
}
function nr(r, t, e) {
  let n, { $$slots: i = {}, $$scope: o } = t, { Icon: a } = t, { label: l = "" } = t, { show_label: s = !1 } = t, { pending: u = !1 } = t, { size: c = "small" } = t, { padded: _ = !0 } = t, { highlight: d = !1 } = t, { disabled: g = !1 } = t, { hasPopup: f = !1 } = t, { color: b = "var(--block-label-text-color)" } = t, { transparent: v = !1 } = t, { background: k = "var(--block-background-fill)" } = t, { border: h = "transparent" } = t;
  function p(m) {
    Ma.call(this, r, m);
  }
  return r.$$set = (m) => {
    "Icon" in m && e(0, a = m.Icon), "label" in m && e(1, l = m.label), "show_label" in m && e(2, s = m.show_label), "pending" in m && e(3, u = m.pending), "size" in m && e(4, c = m.size), "padded" in m && e(5, _ = m.padded), "highlight" in m && e(6, d = m.highlight), "disabled" in m && e(7, g = m.disabled), "hasPopup" in m && e(8, f = m.hasPopup), "color" in m && e(13, b = m.color), "transparent" in m && e(9, v = m.transparent), "background" in m && e(10, k = m.background), "border" in m && e(11, h = m.border), "$$scope" in m && e(14, o = m.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*highlight, color*/
    8256 && e(12, n = d ? "var(--color-accent)" : b);
  }, [
    a,
    l,
    s,
    u,
    c,
    _,
    d,
    g,
    f,
    v,
    k,
    h,
    n,
    b,
    o,
    i,
    p
  ];
}
class _i extends Pa {
  constructor(t) {
    super(), Xa(this, t, nr, tr, Ka, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: Ql,
  append_hydration: Jl,
  attr: es,
  binding_callbacks: ts,
  children: ns,
  claim_element: is,
  create_slot: as,
  detach: rs,
  element: os,
  get_all_dirty_from_scope: ls,
  get_slot_changes: ss,
  init: us,
  insert_hydration: cs,
  safe_not_equal: _s,
  toggle_class: ds,
  transition_in: ps,
  transition_out: hs,
  update_slot_base: fs
} = window.__gradio__svelte__internal, {
  SvelteComponent: ms,
  append_hydration: gs,
  attr: bs,
  children: vs,
  claim_svg_element: Ds,
  detach: ys,
  init: $s,
  insert_hydration: ws,
  noop: Fs,
  safe_not_equal: Es,
  svg_element: ks
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cs,
  append_hydration: As,
  attr: Ss,
  children: Ts,
  claim_svg_element: xs,
  detach: Bs,
  init: Is,
  insert_hydration: Rs,
  noop: qs,
  safe_not_equal: Ls,
  svg_element: Ns
} = window.__gradio__svelte__internal, {
  SvelteComponent: Os,
  append_hydration: zs,
  attr: Ps,
  children: Ms,
  claim_svg_element: Us,
  detach: Gs,
  init: Hs,
  insert_hydration: js,
  noop: Zs,
  safe_not_equal: Vs,
  svg_element: Ys
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xs,
  append_hydration: Ws,
  attr: Ks,
  children: Qs,
  claim_svg_element: Js,
  detach: eu,
  init: tu,
  insert_hydration: nu,
  noop: iu,
  safe_not_equal: au,
  svg_element: ru
} = window.__gradio__svelte__internal, {
  SvelteComponent: ou,
  append_hydration: lu,
  attr: su,
  children: uu,
  claim_svg_element: cu,
  detach: _u,
  init: du,
  insert_hydration: pu,
  noop: hu,
  safe_not_equal: fu,
  svg_element: mu
} = window.__gradio__svelte__internal, {
  SvelteComponent: gu,
  append_hydration: bu,
  attr: vu,
  children: Du,
  claim_svg_element: yu,
  detach: $u,
  init: wu,
  insert_hydration: Fu,
  noop: Eu,
  safe_not_equal: ku,
  svg_element: Cu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Au,
  append_hydration: Su,
  attr: Tu,
  children: xu,
  claim_svg_element: Bu,
  detach: Iu,
  init: Ru,
  insert_hydration: qu,
  noop: Lu,
  safe_not_equal: Nu,
  svg_element: Ou
} = window.__gradio__svelte__internal, {
  SvelteComponent: zu,
  append_hydration: Pu,
  attr: Mu,
  children: Uu,
  claim_svg_element: Gu,
  detach: Hu,
  init: ju,
  insert_hydration: Zu,
  noop: Vu,
  safe_not_equal: Yu,
  svg_element: Xu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wu,
  append_hydration: Ku,
  attr: Qu,
  children: Ju,
  claim_svg_element: ec,
  detach: tc,
  init: nc,
  insert_hydration: ic,
  noop: ac,
  safe_not_equal: rc,
  svg_element: oc
} = window.__gradio__svelte__internal, {
  SvelteComponent: lc,
  append_hydration: sc,
  attr: uc,
  children: cc,
  claim_svg_element: _c,
  detach: dc,
  init: pc,
  insert_hydration: hc,
  noop: fc,
  safe_not_equal: mc,
  svg_element: gc
} = window.__gradio__svelte__internal, {
  SvelteComponent: bc,
  append_hydration: vc,
  attr: Dc,
  children: yc,
  claim_svg_element: $c,
  detach: wc,
  init: Fc,
  insert_hydration: Ec,
  noop: kc,
  safe_not_equal: Cc,
  svg_element: Ac
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sc,
  append_hydration: Tc,
  attr: xc,
  children: Bc,
  claim_svg_element: Ic,
  detach: Rc,
  init: qc,
  insert_hydration: Lc,
  noop: Nc,
  safe_not_equal: Oc,
  svg_element: zc
} = window.__gradio__svelte__internal, {
  SvelteComponent: ir,
  append_hydration: Ft,
  attr: _e,
  children: tt,
  claim_svg_element: nt,
  detach: Ue,
  init: ar,
  insert_hydration: rr,
  noop: Et,
  safe_not_equal: or,
  set_style: ve,
  svg_element: it
} = window.__gradio__svelte__internal;
function lr(r) {
  let t, e, n, i;
  return {
    c() {
      t = it("svg"), e = it("g"), n = it("path"), i = it("path"), this.h();
    },
    l(o) {
      t = nt(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = tt(t);
      e = nt(a, "g", { transform: !0 });
      var l = tt(e);
      n = nt(l, "path", { d: !0, style: !0 }), tt(n).forEach(Ue), l.forEach(Ue), i = nt(a, "path", { d: !0, style: !0 }), tt(i).forEach(Ue), a.forEach(Ue), this.h();
    },
    h() {
      _e(n, "d", "M18,6L6.087,17.913"), ve(n, "fill", "none"), ve(n, "fill-rule", "nonzero"), ve(n, "stroke-width", "2px"), _e(e, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), _e(i, "d", "M4.364,4.364L19.636,19.636"), ve(i, "fill", "none"), ve(i, "fill-rule", "nonzero"), ve(i, "stroke-width", "2px"), _e(t, "width", "100%"), _e(t, "height", "100%"), _e(t, "viewBox", "0 0 24 24"), _e(t, "version", "1.1"), _e(t, "xmlns", "http://www.w3.org/2000/svg"), _e(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), _e(t, "xml:space", "preserve"), _e(t, "stroke", "currentColor"), ve(t, "fill-rule", "evenodd"), ve(t, "clip-rule", "evenodd"), ve(t, "stroke-linecap", "round"), ve(t, "stroke-linejoin", "round");
    },
    m(o, a) {
      rr(o, t, a), Ft(t, e), Ft(e, n), Ft(t, i);
    },
    p: Et,
    i: Et,
    o: Et,
    d(o) {
      o && Ue(t);
    }
  };
}
class di extends ir {
  constructor(t) {
    super(), ar(this, t, null, lr, or, {});
  }
}
const {
  SvelteComponent: Pc,
  append_hydration: Mc,
  attr: Uc,
  children: Gc,
  claim_svg_element: Hc,
  claim_text: jc,
  detach: Zc,
  init: Vc,
  insert_hydration: Yc,
  noop: Xc,
  safe_not_equal: Wc,
  svg_element: Kc,
  text: Qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jc,
  append_hydration: e_,
  attr: t_,
  children: n_,
  claim_svg_element: i_,
  detach: a_,
  init: r_,
  insert_hydration: o_,
  noop: l_,
  safe_not_equal: s_,
  svg_element: u_
} = window.__gradio__svelte__internal, {
  SvelteComponent: c_,
  append_hydration: __,
  attr: d_,
  children: p_,
  claim_svg_element: h_,
  detach: f_,
  init: m_,
  insert_hydration: g_,
  noop: b_,
  safe_not_equal: v_,
  svg_element: D_
} = window.__gradio__svelte__internal, {
  SvelteComponent: y_,
  append_hydration: $_,
  attr: w_,
  children: F_,
  claim_svg_element: E_,
  detach: k_,
  init: C_,
  insert_hydration: A_,
  noop: S_,
  safe_not_equal: T_,
  svg_element: x_
} = window.__gradio__svelte__internal, {
  SvelteComponent: B_,
  append_hydration: I_,
  attr: R_,
  children: q_,
  claim_svg_element: L_,
  detach: N_,
  init: O_,
  insert_hydration: z_,
  noop: P_,
  safe_not_equal: M_,
  svg_element: U_
} = window.__gradio__svelte__internal, {
  SvelteComponent: G_,
  append_hydration: H_,
  attr: j_,
  children: Z_,
  claim_svg_element: V_,
  detach: Y_,
  init: X_,
  insert_hydration: W_,
  noop: K_,
  safe_not_equal: Q_,
  svg_element: J_
} = window.__gradio__svelte__internal, {
  SvelteComponent: ed,
  append_hydration: td,
  attr: nd,
  children: id,
  claim_svg_element: ad,
  detach: rd,
  init: od,
  insert_hydration: ld,
  noop: sd,
  safe_not_equal: ud,
  svg_element: cd
} = window.__gradio__svelte__internal, {
  SvelteComponent: _d,
  append_hydration: dd,
  attr: pd,
  children: hd,
  claim_svg_element: fd,
  detach: md,
  init: gd,
  insert_hydration: bd,
  noop: vd,
  safe_not_equal: Dd,
  svg_element: yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: $d,
  append_hydration: wd,
  attr: Fd,
  children: Ed,
  claim_svg_element: kd,
  detach: Cd,
  init: Ad,
  insert_hydration: Sd,
  noop: Td,
  safe_not_equal: xd,
  svg_element: Bd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Id,
  append_hydration: Rd,
  attr: qd,
  children: Ld,
  claim_svg_element: Nd,
  detach: Od,
  init: zd,
  insert_hydration: Pd,
  noop: Md,
  safe_not_equal: Ud,
  svg_element: Gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append_hydration: jd,
  attr: Zd,
  children: Vd,
  claim_svg_element: Yd,
  detach: Xd,
  init: Wd,
  insert_hydration: Kd,
  noop: Qd,
  safe_not_equal: Jd,
  svg_element: ep
} = window.__gradio__svelte__internal, {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ip,
  children: ap,
  claim_svg_element: rp,
  detach: op,
  init: lp,
  insert_hydration: sp,
  noop: up,
  safe_not_equal: cp,
  svg_element: _p
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: pp,
  attr: hp,
  children: fp,
  claim_svg_element: mp,
  detach: gp,
  init: bp,
  insert_hydration: vp,
  noop: Dp,
  safe_not_equal: yp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: wp,
  append_hydration: Fp,
  attr: Ep,
  children: kp,
  claim_svg_element: Cp,
  detach: Ap,
  init: Sp,
  insert_hydration: Tp,
  noop: xp,
  safe_not_equal: Bp,
  svg_element: Ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: qp,
  attr: Lp,
  children: Np,
  claim_svg_element: Op,
  detach: zp,
  init: Pp,
  insert_hydration: Mp,
  noop: Up,
  safe_not_equal: Gp,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Zp,
  attr: Vp,
  children: Yp,
  claim_svg_element: Xp,
  detach: Wp,
  init: Kp,
  insert_hydration: Qp,
  noop: Jp,
  safe_not_equal: eh,
  svg_element: th
} = window.__gradio__svelte__internal, {
  SvelteComponent: nh,
  append_hydration: ih,
  attr: ah,
  children: rh,
  claim_svg_element: oh,
  detach: lh,
  init: sh,
  insert_hydration: uh,
  noop: ch,
  safe_not_equal: _h,
  svg_element: dh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ph,
  append_hydration: hh,
  attr: fh,
  children: mh,
  claim_svg_element: gh,
  detach: bh,
  init: vh,
  insert_hydration: Dh,
  noop: yh,
  safe_not_equal: $h,
  svg_element: wh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fh,
  append_hydration: Eh,
  attr: kh,
  children: Ch,
  claim_svg_element: Ah,
  detach: Sh,
  init: Th,
  insert_hydration: xh,
  noop: Bh,
  safe_not_equal: Ih,
  svg_element: Rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: qh,
  append_hydration: Lh,
  attr: Nh,
  children: Oh,
  claim_svg_element: zh,
  detach: Ph,
  init: Mh,
  insert_hydration: Uh,
  noop: Gh,
  safe_not_equal: Hh,
  svg_element: jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zh,
  append_hydration: Vh,
  attr: Yh,
  children: Xh,
  claim_svg_element: Wh,
  detach: Kh,
  init: Qh,
  insert_hydration: Jh,
  noop: ef,
  safe_not_equal: tf,
  svg_element: nf
} = window.__gradio__svelte__internal, {
  SvelteComponent: af,
  append_hydration: rf,
  attr: of,
  children: lf,
  claim_svg_element: sf,
  detach: uf,
  init: cf,
  insert_hydration: _f,
  noop: df,
  safe_not_equal: pf,
  svg_element: hf
} = window.__gradio__svelte__internal, {
  SvelteComponent: ff,
  append_hydration: mf,
  attr: gf,
  children: bf,
  claim_svg_element: vf,
  detach: Df,
  init: yf,
  insert_hydration: $f,
  noop: wf,
  safe_not_equal: Ff,
  svg_element: Ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: kf,
  append_hydration: Cf,
  attr: Af,
  children: Sf,
  claim_svg_element: Tf,
  detach: xf,
  init: Bf,
  insert_hydration: If,
  noop: Rf,
  safe_not_equal: qf,
  svg_element: Lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nf,
  append_hydration: Of,
  attr: zf,
  children: Pf,
  claim_svg_element: Mf,
  detach: Uf,
  init: Gf,
  insert_hydration: Hf,
  noop: jf,
  safe_not_equal: Zf,
  svg_element: Vf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yf,
  append_hydration: Xf,
  attr: Wf,
  children: Kf,
  claim_svg_element: Qf,
  detach: Jf,
  init: em,
  insert_hydration: tm,
  noop: nm,
  safe_not_equal: im,
  svg_element: am
} = window.__gradio__svelte__internal, {
  SvelteComponent: rm,
  append_hydration: om,
  attr: lm,
  children: sm,
  claim_svg_element: um,
  detach: cm,
  init: _m,
  insert_hydration: dm,
  noop: pm,
  safe_not_equal: hm,
  svg_element: fm
} = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  append_hydration: gm,
  attr: bm,
  children: vm,
  claim_svg_element: Dm,
  detach: ym,
  init: $m,
  insert_hydration: wm,
  noop: Fm,
  safe_not_equal: Em,
  svg_element: km
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cm,
  append_hydration: Am,
  attr: Sm,
  children: Tm,
  claim_svg_element: xm,
  detach: Bm,
  init: Im,
  insert_hydration: Rm,
  noop: qm,
  safe_not_equal: Lm,
  svg_element: Nm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Om,
  append_hydration: zm,
  attr: Pm,
  children: Mm,
  claim_svg_element: Um,
  detach: Gm,
  init: Hm,
  insert_hydration: jm,
  noop: Zm,
  safe_not_equal: Vm,
  svg_element: Ym
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xm,
  append_hydration: Wm,
  attr: Km,
  children: Qm,
  claim_svg_element: Jm,
  detach: eg,
  init: tg,
  insert_hydration: ng,
  noop: ig,
  safe_not_equal: ag,
  svg_element: rg
} = window.__gradio__svelte__internal, {
  SvelteComponent: og,
  append_hydration: lg,
  attr: sg,
  children: ug,
  claim_svg_element: cg,
  detach: _g,
  init: dg,
  insert_hydration: pg,
  noop: hg,
  safe_not_equal: fg,
  svg_element: mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: gg,
  append_hydration: bg,
  attr: vg,
  children: Dg,
  claim_svg_element: yg,
  detach: $g,
  init: wg,
  insert_hydration: Fg,
  noop: Eg,
  safe_not_equal: kg,
  svg_element: Cg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ag,
  append_hydration: Sg,
  attr: Tg,
  children: xg,
  claim_svg_element: Bg,
  detach: Ig,
  init: Rg,
  insert_hydration: qg,
  noop: Lg,
  safe_not_equal: Ng,
  svg_element: Og
} = window.__gradio__svelte__internal, {
  SvelteComponent: zg,
  append_hydration: Pg,
  attr: Mg,
  children: Ug,
  claim_svg_element: Gg,
  detach: Hg,
  init: jg,
  insert_hydration: Zg,
  noop: Vg,
  safe_not_equal: Yg,
  set_style: Xg,
  svg_element: Wg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kg,
  append_hydration: Qg,
  attr: Jg,
  children: e0,
  claim_svg_element: t0,
  detach: n0,
  init: i0,
  insert_hydration: a0,
  noop: r0,
  safe_not_equal: o0,
  svg_element: l0
} = window.__gradio__svelte__internal, {
  SvelteComponent: s0,
  append_hydration: u0,
  attr: c0,
  children: _0,
  claim_svg_element: d0,
  detach: p0,
  init: h0,
  insert_hydration: f0,
  noop: m0,
  safe_not_equal: g0,
  svg_element: b0
} = window.__gradio__svelte__internal, {
  SvelteComponent: v0,
  append_hydration: D0,
  attr: y0,
  children: $0,
  claim_svg_element: w0,
  detach: F0,
  init: E0,
  insert_hydration: k0,
  noop: C0,
  safe_not_equal: A0,
  svg_element: S0
} = window.__gradio__svelte__internal, {
  SvelteComponent: T0,
  append_hydration: x0,
  attr: B0,
  children: I0,
  claim_svg_element: R0,
  detach: q0,
  init: L0,
  insert_hydration: N0,
  noop: O0,
  safe_not_equal: z0,
  svg_element: P0
} = window.__gradio__svelte__internal, {
  SvelteComponent: M0,
  append_hydration: U0,
  attr: G0,
  children: H0,
  claim_svg_element: j0,
  detach: Z0,
  init: V0,
  insert_hydration: Y0,
  noop: X0,
  safe_not_equal: W0,
  svg_element: K0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q0,
  append_hydration: J0,
  attr: e1,
  children: t1,
  claim_svg_element: n1,
  detach: i1,
  init: a1,
  insert_hydration: r1,
  noop: o1,
  safe_not_equal: l1,
  svg_element: s1
} = window.__gradio__svelte__internal, {
  SvelteComponent: u1,
  append_hydration: c1,
  attr: _1,
  children: d1,
  claim_svg_element: p1,
  detach: h1,
  init: f1,
  insert_hydration: m1,
  noop: g1,
  safe_not_equal: b1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: D1,
  append_hydration: y1,
  attr: $1,
  children: w1,
  claim_svg_element: F1,
  detach: E1,
  init: k1,
  insert_hydration: C1,
  noop: A1,
  safe_not_equal: S1,
  svg_element: T1
} = window.__gradio__svelte__internal, {
  SvelteComponent: x1,
  append_hydration: B1,
  attr: I1,
  children: R1,
  claim_svg_element: q1,
  claim_text: L1,
  detach: N1,
  init: O1,
  insert_hydration: z1,
  noop: P1,
  safe_not_equal: M1,
  svg_element: U1,
  text: G1
} = window.__gradio__svelte__internal, {
  SvelteComponent: H1,
  append_hydration: j1,
  attr: Z1,
  children: V1,
  claim_svg_element: Y1,
  detach: X1,
  init: W1,
  insert_hydration: K1,
  noop: Q1,
  safe_not_equal: J1,
  svg_element: eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: tb,
  append_hydration: nb,
  attr: ib,
  children: ab,
  claim_svg_element: rb,
  detach: ob,
  init: lb,
  insert_hydration: sb,
  noop: ub,
  safe_not_equal: cb,
  svg_element: _b
} = window.__gradio__svelte__internal, {
  SvelteComponent: db,
  append_hydration: pb,
  attr: hb,
  children: fb,
  claim_svg_element: mb,
  detach: gb,
  init: bb,
  insert_hydration: vb,
  noop: Db,
  safe_not_equal: yb,
  svg_element: $b
} = window.__gradio__svelte__internal, {
  SvelteComponent: wb,
  append_hydration: Fb,
  attr: Eb,
  children: kb,
  claim_svg_element: Cb,
  detach: Ab,
  init: Sb,
  insert_hydration: Tb,
  noop: xb,
  safe_not_equal: Bb,
  svg_element: Ib
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rb,
  append_hydration: qb,
  attr: Lb,
  children: Nb,
  claim_svg_element: Ob,
  detach: zb,
  init: Pb,
  insert_hydration: Mb,
  noop: Ub,
  safe_not_equal: Gb,
  svg_element: Hb
} = window.__gradio__svelte__internal, {
  SvelteComponent: jb,
  append_hydration: Zb,
  attr: Vb,
  children: Yb,
  claim_svg_element: Xb,
  detach: Wb,
  init: Kb,
  insert_hydration: Qb,
  noop: Jb,
  safe_not_equal: ev,
  svg_element: tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: nv,
  append_hydration: iv,
  attr: av,
  children: rv,
  claim_svg_element: ov,
  detach: lv,
  init: sv,
  insert_hydration: uv,
  noop: cv,
  safe_not_equal: _v,
  svg_element: dv
} = window.__gradio__svelte__internal, {
  SvelteComponent: pv,
  append_hydration: hv,
  attr: fv,
  children: mv,
  claim_svg_element: gv,
  claim_text: bv,
  detach: vv,
  init: Dv,
  insert_hydration: yv,
  noop: $v,
  safe_not_equal: wv,
  svg_element: Fv,
  text: Ev
} = window.__gradio__svelte__internal, {
  SvelteComponent: kv,
  append_hydration: Cv,
  attr: Av,
  children: Sv,
  claim_svg_element: Tv,
  claim_text: xv,
  detach: Bv,
  init: Iv,
  insert_hydration: Rv,
  noop: qv,
  safe_not_equal: Lv,
  svg_element: Nv,
  text: Ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: zv,
  append_hydration: Pv,
  attr: Mv,
  children: Uv,
  claim_svg_element: Gv,
  claim_text: Hv,
  detach: jv,
  init: Zv,
  insert_hydration: Vv,
  noop: Yv,
  safe_not_equal: Xv,
  svg_element: Wv,
  text: Kv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qv,
  append_hydration: Jv,
  attr: eD,
  children: tD,
  claim_svg_element: nD,
  detach: iD,
  init: aD,
  insert_hydration: rD,
  noop: oD,
  safe_not_equal: lD,
  svg_element: sD
} = window.__gradio__svelte__internal, {
  SvelteComponent: uD,
  append_hydration: cD,
  attr: _D,
  children: dD,
  claim_svg_element: pD,
  detach: hD,
  init: fD,
  insert_hydration: mD,
  noop: gD,
  safe_not_equal: bD,
  svg_element: vD
} = window.__gradio__svelte__internal, {
  SvelteComponent: DD,
  append_hydration: yD,
  attr: $D,
  children: wD,
  claim_svg_element: FD,
  detach: ED,
  init: kD,
  insert_hydration: CD,
  noop: AD,
  safe_not_equal: SD,
  svg_element: TD
} = window.__gradio__svelte__internal, {
  SvelteComponent: xD,
  append_hydration: BD,
  attr: ID,
  children: RD,
  claim_svg_element: qD,
  detach: LD,
  init: ND,
  insert_hydration: OD,
  noop: zD,
  safe_not_equal: PD,
  svg_element: MD
} = window.__gradio__svelte__internal, {
  SvelteComponent: UD,
  append_hydration: GD,
  attr: HD,
  children: jD,
  claim_svg_element: ZD,
  detach: VD,
  init: YD,
  insert_hydration: XD,
  noop: WD,
  safe_not_equal: KD,
  svg_element: QD
} = window.__gradio__svelte__internal, {
  SvelteComponent: JD,
  append_hydration: ey,
  attr: ty,
  children: ny,
  claim_svg_element: iy,
  detach: ay,
  init: ry,
  insert_hydration: oy,
  noop: ly,
  safe_not_equal: sy,
  svg_element: uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: cy,
  append_hydration: _y,
  attr: dy,
  children: py,
  claim_svg_element: hy,
  detach: fy,
  init: my,
  insert_hydration: gy,
  noop: by,
  safe_not_equal: vy,
  svg_element: Dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: yy,
  append_hydration: $y,
  attr: wy,
  children: Fy,
  claim_svg_element: Ey,
  detach: ky,
  init: Cy,
  insert_hydration: Ay,
  noop: Sy,
  safe_not_equal: Ty,
  svg_element: xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: By,
  append_hydration: Iy,
  attr: Ry,
  children: qy,
  claim_svg_element: Ly,
  detach: Ny,
  init: Oy,
  insert_hydration: zy,
  noop: Py,
  safe_not_equal: My,
  svg_element: Uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gy,
  append_hydration: Hy,
  attr: jy,
  children: Zy,
  claim_svg_element: Vy,
  detach: Yy,
  init: Xy,
  insert_hydration: Wy,
  noop: Ky,
  safe_not_equal: Qy,
  svg_element: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: e$,
  append_hydration: t$,
  attr: n$,
  children: i$,
  claim_svg_element: a$,
  detach: r$,
  init: o$,
  insert_hydration: l$,
  noop: s$,
  safe_not_equal: u$,
  svg_element: c$
} = window.__gradio__svelte__internal, sr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], fn = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
sr.reduce(
  (r, { color: t, primary: e, secondary: n }) => ({
    ...r,
    [t]: {
      primary: fn[t][e],
      secondary: fn[t][n]
    }
  }),
  {}
);
const {
  SvelteComponent: _$,
  claim_component: d$,
  create_component: p$,
  destroy_component: h$,
  init: f$,
  mount_component: m$,
  safe_not_equal: g$,
  transition_in: b$,
  transition_out: v$
} = window.__gradio__svelte__internal, { createEventDispatcher: D$ } = window.__gradio__svelte__internal, {
  SvelteComponent: y$,
  append_hydration: $$,
  attr: w$,
  check_outros: F$,
  children: E$,
  claim_component: k$,
  claim_element: C$,
  claim_space: A$,
  claim_text: S$,
  create_component: T$,
  destroy_component: x$,
  detach: B$,
  element: I$,
  empty: R$,
  group_outros: q$,
  init: L$,
  insert_hydration: N$,
  mount_component: O$,
  safe_not_equal: z$,
  set_data: P$,
  space: M$,
  text: U$,
  toggle_class: G$,
  transition_in: H$,
  transition_out: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z$,
  attr: V$,
  children: Y$,
  claim_element: X$,
  create_slot: W$,
  detach: K$,
  element: Q$,
  get_all_dirty_from_scope: J$,
  get_slot_changes: ew,
  init: tw,
  insert_hydration: nw,
  safe_not_equal: iw,
  toggle_class: aw,
  transition_in: rw,
  transition_out: ow,
  update_slot_base: lw
} = window.__gradio__svelte__internal, {
  SvelteComponent: sw,
  append_hydration: uw,
  attr: cw,
  check_outros: _w,
  children: dw,
  claim_component: pw,
  claim_element: hw,
  claim_space: fw,
  create_component: mw,
  destroy_component: gw,
  detach: bw,
  element: vw,
  empty: Dw,
  group_outros: yw,
  init: $w,
  insert_hydration: ww,
  listen: Fw,
  mount_component: Ew,
  safe_not_equal: kw,
  space: Cw,
  toggle_class: Aw,
  transition_in: Sw,
  transition_out: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: xw,
  attr: Bw,
  children: Iw,
  claim_element: Rw,
  create_slot: qw,
  detach: Lw,
  element: Nw,
  get_all_dirty_from_scope: Ow,
  get_slot_changes: zw,
  init: Pw,
  insert_hydration: Mw,
  null_to_empty: Uw,
  safe_not_equal: Gw,
  transition_in: Hw,
  transition_out: jw,
  update_slot_base: Zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vw,
  check_outros: Yw,
  claim_component: Xw,
  create_component: Ww,
  destroy_component: Kw,
  detach: Qw,
  empty: Jw,
  group_outros: eF,
  init: tF,
  insert_hydration: nF,
  mount_component: iF,
  noop: aF,
  safe_not_equal: rF,
  transition_in: oF,
  transition_out: lF
} = window.__gradio__svelte__internal, { createEventDispatcher: sF } = window.__gradio__svelte__internal;
function Le(r) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], e = 0;
  for (; r > 1e3 && e < t.length - 1; )
    r /= 1e3, e++;
  let n = t[e];
  return (Number.isInteger(r) ? r : r.toFixed(1)) + n;
}
function lt() {
}
const pi = typeof window < "u";
let mn = pi ? () => window.performance.now() : () => Date.now(), hi = pi ? (r) => requestAnimationFrame(r) : lt;
const Ne = /* @__PURE__ */ new Set();
function fi(r) {
  Ne.forEach((t) => {
    t.c(r) || (Ne.delete(t), t.f());
  }), Ne.size !== 0 && hi(fi);
}
function ur(r) {
  let t;
  return Ne.size === 0 && hi(fi), { promise: new Promise((e) => {
    Ne.add(t = { c: r, f: e });
  }), abort() {
    Ne.delete(t);
  } };
}
const qe = [];
function cr(r, t = lt) {
  let e;
  const n = /* @__PURE__ */ new Set();
  function i(a) {
    if (s = a, ((l = r) != l ? s == s : l !== s || l && typeof l == "object" || typeof l == "function") && (r = a, e)) {
      const u = !qe.length;
      for (const c of n) c[1](), qe.push(c, r);
      if (u) {
        for (let c = 0; c < qe.length; c += 2) qe[c][0](qe[c + 1]);
        qe.length = 0;
      }
    }
    var l, s;
  }
  function o(a) {
    i(a(r));
  }
  return { set: i, update: o, subscribe: function(a, l = lt) {
    const s = [a, l];
    return n.add(s), n.size === 1 && (e = t(i, o) || lt), a(r), () => {
      n.delete(s), n.size === 0 && e && (e(), e = null);
    };
  } };
}
function gn(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function It(r, t, e, n) {
  if (typeof e == "number" || gn(e)) {
    const i = n - e, o = (e - t) / (r.dt || 1 / 60), a = (o + (r.opts.stiffness * i - r.opts.damping * o) * r.inv_mass) * r.dt;
    return Math.abs(a) < r.opts.precision && Math.abs(i) < r.opts.precision ? n : (r.settled = !1, gn(e) ? new Date(e.getTime() + a) : e + a);
  }
  if (Array.isArray(e)) return e.map((i, o) => It(r, t[o], e[o], n[o]));
  if (typeof e == "object") {
    const i = {};
    for (const o in e) i[o] = It(r, t[o], e[o], n[o]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof e} values`);
}
function bn(r, t = {}) {
  const e = cr(r), { stiffness: n = 0.15, damping: i = 0.8, precision: o = 0.01 } = t;
  let a, l, s, u = r, c = r, _ = 1, d = 0, g = !1;
  function f(v, k = {}) {
    c = v;
    const h = s = {};
    return r == null || k.hard || b.stiffness >= 1 && b.damping >= 1 ? (g = !0, a = mn(), u = v, e.set(r = c), Promise.resolve()) : (k.soft && (d = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), _ = 0), l || (a = mn(), g = !1, l = ur((p) => {
      if (g) return g = !1, l = null, !1;
      _ = Math.min(_ + d, 1);
      const m = { inv_mass: _, opts: b, settled: !0, dt: 60 * (p - a) / 1e3 }, D = It(m, u, r, c);
      return a = p, u = r, e.set(r = D), m.settled && (l = null), !m.settled;
    })), new Promise((p) => {
      l.promise.then(() => {
        h === s && p();
      });
    }));
  }
  const b = { set: f, update: (v, k) => f(v(c, r), k), subscribe: e.subscribe, stiffness: n, damping: i, precision: o };
  return b;
}
const {
  SvelteComponent: _r,
  append_hydration: de,
  attr: x,
  children: ne,
  claim_element: dr,
  claim_svg_element: pe,
  component_subscribe: vn,
  detach: K,
  element: pr,
  init: hr,
  insert_hydration: fr,
  noop: Dn,
  safe_not_equal: mr,
  set_style: at,
  svg_element: he,
  toggle_class: yn
} = window.__gradio__svelte__internal, { onMount: gr } = window.__gradio__svelte__internal;
function br(r) {
  let t, e, n, i, o, a, l, s, u, c, _, d;
  return {
    c() {
      t = pr("div"), e = he("svg"), n = he("g"), i = he("path"), o = he("path"), a = he("path"), l = he("path"), s = he("g"), u = he("path"), c = he("path"), _ = he("path"), d = he("path"), this.h();
    },
    l(g) {
      t = dr(g, "DIV", { class: !0 });
      var f = ne(t);
      e = pe(f, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var b = ne(e);
      n = pe(b, "g", { style: !0 });
      var v = ne(n);
      i = pe(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(i).forEach(K), o = pe(v, "path", { d: !0, fill: !0, class: !0 }), ne(o).forEach(K), a = pe(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(a).forEach(K), l = pe(v, "path", { d: !0, fill: !0, class: !0 }), ne(l).forEach(K), v.forEach(K), s = pe(b, "g", { style: !0 });
      var k = ne(s);
      u = pe(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(u).forEach(K), c = pe(k, "path", { d: !0, fill: !0, class: !0 }), ne(c).forEach(K), _ = pe(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ne(_).forEach(K), d = pe(k, "path", { d: !0, fill: !0, class: !0 }), ne(d).forEach(K), k.forEach(K), b.forEach(K), f.forEach(K), this.h();
    },
    h() {
      x(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), x(i, "fill", "#FF7C00"), x(i, "fill-opacity", "0.4"), x(i, "class", "svelte-43sxxs"), x(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), x(o, "fill", "#FF7C00"), x(o, "class", "svelte-43sxxs"), x(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), x(a, "fill", "#FF7C00"), x(a, "fill-opacity", "0.4"), x(a, "class", "svelte-43sxxs"), x(l, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), x(l, "fill", "#FF7C00"), x(l, "class", "svelte-43sxxs"), at(n, "transform", "translate(" + /*$top*/
      r[1][0] + "px, " + /*$top*/
      r[1][1] + "px)"), x(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), x(u, "fill", "#FF7C00"), x(u, "fill-opacity", "0.4"), x(u, "class", "svelte-43sxxs"), x(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), x(c, "fill", "#FF7C00"), x(c, "class", "svelte-43sxxs"), x(_, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), x(_, "fill", "#FF7C00"), x(_, "fill-opacity", "0.4"), x(_, "class", "svelte-43sxxs"), x(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), x(d, "fill", "#FF7C00"), x(d, "class", "svelte-43sxxs"), at(s, "transform", "translate(" + /*$bottom*/
      r[2][0] + "px, " + /*$bottom*/
      r[2][1] + "px)"), x(e, "viewBox", "-1200 -1200 3000 3000"), x(e, "fill", "none"), x(e, "xmlns", "http://www.w3.org/2000/svg"), x(e, "class", "svelte-43sxxs"), x(t, "class", "svelte-43sxxs"), yn(
        t,
        "margin",
        /*margin*/
        r[0]
      );
    },
    m(g, f) {
      fr(g, t, f), de(t, e), de(e, n), de(n, i), de(n, o), de(n, a), de(n, l), de(e, s), de(s, u), de(s, c), de(s, _), de(s, d);
    },
    p(g, [f]) {
      f & /*$top*/
      2 && at(n, "transform", "translate(" + /*$top*/
      g[1][0] + "px, " + /*$top*/
      g[1][1] + "px)"), f & /*$bottom*/
      4 && at(s, "transform", "translate(" + /*$bottom*/
      g[2][0] + "px, " + /*$bottom*/
      g[2][1] + "px)"), f & /*margin*/
      1 && yn(
        t,
        "margin",
        /*margin*/
        g[0]
      );
    },
    i: Dn,
    o: Dn,
    d(g) {
      g && K(t);
    }
  };
}
function vr(r, t, e) {
  let n, i;
  var o = this && this.__awaiter || function(g, f, b, v) {
    function k(h) {
      return h instanceof b ? h : new b(function(p) {
        p(h);
      });
    }
    return new (b || (b = Promise))(function(h, p) {
      function m(w) {
        try {
          y(v.next(w));
        } catch (S) {
          p(S);
        }
      }
      function D(w) {
        try {
          y(v.throw(w));
        } catch (S) {
          p(S);
        }
      }
      function y(w) {
        w.done ? h(w.value) : k(w.value).then(m, D);
      }
      y((v = v.apply(g, f || [])).next());
    });
  };
  let { margin: a = !0 } = t;
  const l = bn([0, 0]);
  vn(r, l, (g) => e(1, n = g));
  const s = bn([0, 0]);
  vn(r, s, (g) => e(2, i = g));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 140]), s.set([-125, -140])]), yield Promise.all([l.set([-125, 140]), s.set([125, -140])]), yield Promise.all([l.set([-125, 0]), s.set([125, -0])]), yield Promise.all([l.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function _() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || _();
    });
  }
  function d() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 0]), s.set([-125, 0])]), _();
    });
  }
  return gr(() => (d(), () => u = !0)), r.$$set = (g) => {
    "margin" in g && e(0, a = g.margin);
  }, [a, n, i, l, s];
}
class Dr extends _r {
  constructor(t) {
    super(), hr(this, t, vr, br, mr, { margin: 0 });
  }
}
const {
  SvelteComponent: yr,
  append_hydration: me,
  attr: ae,
  binding_callbacks: $n,
  check_outros: _t,
  children: re,
  claim_component: Ht,
  claim_element: oe,
  claim_space: V,
  claim_text: z,
  create_component: jt,
  create_slot: mi,
  destroy_component: Zt,
  destroy_each: gi,
  detach: E,
  element: le,
  empty: se,
  ensure_array_like: dt,
  get_all_dirty_from_scope: bi,
  get_slot_changes: vi,
  group_outros: pt,
  init: $r,
  insert_hydration: A,
  mount_component: Vt,
  noop: Rt,
  safe_not_equal: wr,
  set_data: ee,
  set_style: Ce,
  space: Y,
  text: P,
  toggle_class: ie,
  transition_in: Z,
  transition_out: J,
  update_slot_base: Di
} = window.__gradio__svelte__internal, { tick: Fr } = window.__gradio__svelte__internal, { onDestroy: Er } = window.__gradio__svelte__internal, { createEventDispatcher: kr } = window.__gradio__svelte__internal, Cr = (r) => ({}), wn = (r) => ({}), Ar = (r) => ({}), Fn = (r) => ({});
function En(r, t, e) {
  const n = r.slice();
  return n[43] = t[e], n[45] = e, n;
}
function kn(r, t, e) {
  const n = r.slice();
  return n[43] = t[e], n;
}
function Cn(r) {
  let t, e, n, i, o, a;
  return o = new _i({
    props: {
      Icon: di,
      label: (
        /*i18n*/
        r[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), o.$on(
    "click",
    /*click_handler*/
    r[33]
  ), {
    c() {
      t = le("div"), e = P(
        /*validation_error*/
        r[1]
      ), n = Y(), i = le("button"), jt(o.$$.fragment), this.h();
    },
    l(l) {
      t = oe(l, "DIV", { class: !0 });
      var s = re(t);
      e = z(
        s,
        /*validation_error*/
        r[1]
      ), n = V(s), i = oe(s, "BUTTON", {});
      var u = re(i);
      Ht(o.$$.fragment, u), u.forEach(E), s.forEach(E), this.h();
    },
    h() {
      ae(t, "class", "validation-error svelte-vusapu");
    },
    m(l, s) {
      A(l, t, s), me(t, e), me(t, n), me(t, i), Vt(o, i, null), a = !0;
    },
    p(l, s) {
      (!a || s[0] & /*validation_error*/
      2) && ee(
        e,
        /*validation_error*/
        l[1]
      );
      const u = {};
      s[0] & /*i18n*/
      4 && (u.label = /*i18n*/
      l[2]("common.clear")), o.$set(u);
    },
    i(l) {
      a || (Z(o.$$.fragment, l), a = !0);
    },
    o(l) {
      J(o.$$.fragment, l), a = !1;
    },
    d(l) {
      l && E(t), Zt(o);
    }
  };
}
function Sr(r) {
  let t, e, n, i, o = (
    /*i18n*/
    r[2]("common.error") + ""
  ), a, l, s;
  e = new _i({
    props: {
      Icon: di,
      label: (
        /*i18n*/
        r[2]("common.clear")
      ),
      disabled: !1
    }
  }), e.$on(
    "click",
    /*click_handler_1*/
    r[35]
  );
  const u = (
    /*#slots*/
    r[32].error
  ), c = mi(
    u,
    r,
    /*$$scope*/
    r[31],
    wn
  );
  return {
    c() {
      t = le("div"), jt(e.$$.fragment), n = Y(), i = le("span"), a = P(o), l = Y(), c && c.c(), this.h();
    },
    l(_) {
      t = oe(_, "DIV", { class: !0 });
      var d = re(t);
      Ht(e.$$.fragment, d), d.forEach(E), n = V(_), i = oe(_, "SPAN", { class: !0 });
      var g = re(i);
      a = z(g, o), g.forEach(E), l = V(_), c && c.l(_), this.h();
    },
    h() {
      ae(t, "class", "clear-status svelte-vusapu"), ae(i, "class", "error svelte-vusapu");
    },
    m(_, d) {
      A(_, t, d), Vt(e, t, null), A(_, n, d), A(_, i, d), me(i, a), A(_, l, d), c && c.m(_, d), s = !0;
    },
    p(_, d) {
      const g = {};
      d[0] & /*i18n*/
      4 && (g.label = /*i18n*/
      _[2]("common.clear")), e.$set(g), (!s || d[0] & /*i18n*/
      4) && o !== (o = /*i18n*/
      _[2]("common.error") + "") && ee(a, o), c && c.p && (!s || d[1] & /*$$scope*/
      1) && Di(
        c,
        u,
        _,
        /*$$scope*/
        _[31],
        s ? vi(
          u,
          /*$$scope*/
          _[31],
          d,
          Cr
        ) : bi(
          /*$$scope*/
          _[31]
        ),
        wn
      );
    },
    i(_) {
      s || (Z(e.$$.fragment, _), Z(c, _), s = !0);
    },
    o(_) {
      J(e.$$.fragment, _), J(c, _), s = !1;
    },
    d(_) {
      _ && (E(t), E(n), E(i), E(l)), Zt(e), c && c.d(_);
    }
  };
}
function Tr(r) {
  let t, e, n, i, o, a, l, s, u, c = (
    /*variant*/
    r[9] === "default" && /*show_eta_bar*/
    r[20] && /*show_progress*/
    r[7] === "full" && An(r)
  );
  function _(p, m) {
    if (
      /*progress*/
      p[8]
    ) return Ir;
    if (
      /*queue_position*/
      p[3] !== null && /*queue_size*/
      p[4] !== void 0 && /*queue_position*/
      p[3] >= 0
    ) return Br;
    if (
      /*queue_position*/
      p[3] === 0
    ) return xr;
  }
  let d = _(r), g = d && d(r), f = (
    /*timer*/
    r[6] && xn(r)
  );
  const b = [Nr, Lr], v = [];
  function k(p, m) {
    return (
      /*last_progress_level*/
      p[17] != null ? 0 : (
        /*show_progress*/
        p[7] === "full" ? 1 : -1
      )
    );
  }
  ~(o = k(r)) && (a = v[o] = b[o](r));
  let h = !/*timer*/
  r[6] && On(r);
  return {
    c() {
      c && c.c(), t = Y(), e = le("div"), g && g.c(), n = Y(), f && f.c(), i = Y(), a && a.c(), l = Y(), h && h.c(), s = se(), this.h();
    },
    l(p) {
      c && c.l(p), t = V(p), e = oe(p, "DIV", { class: !0 });
      var m = re(e);
      g && g.l(m), n = V(m), f && f.l(m), m.forEach(E), i = V(p), a && a.l(p), l = V(p), h && h.l(p), s = se(), this.h();
    },
    h() {
      ae(e, "class", "progress-text svelte-vusapu"), ie(
        e,
        "meta-text-center",
        /*variant*/
        r[9] === "center"
      ), ie(
        e,
        "meta-text",
        /*variant*/
        r[9] === "default"
      );
    },
    m(p, m) {
      c && c.m(p, m), A(p, t, m), A(p, e, m), g && g.m(e, null), me(e, n), f && f.m(e, null), A(p, i, m), ~o && v[o].m(p, m), A(p, l, m), h && h.m(p, m), A(p, s, m), u = !0;
    },
    p(p, m) {
      /*variant*/
      p[9] === "default" && /*show_eta_bar*/
      p[20] && /*show_progress*/
      p[7] === "full" ? c ? c.p(p, m) : (c = An(p), c.c(), c.m(t.parentNode, t)) : c && (c.d(1), c = null), d === (d = _(p)) && g ? g.p(p, m) : (g && g.d(1), g = d && d(p), g && (g.c(), g.m(e, n))), /*timer*/
      p[6] ? f ? f.p(p, m) : (f = xn(p), f.c(), f.m(e, null)) : f && (f.d(1), f = null), (!u || m[0] & /*variant*/
      512) && ie(
        e,
        "meta-text-center",
        /*variant*/
        p[9] === "center"
      ), (!u || m[0] & /*variant*/
      512) && ie(
        e,
        "meta-text",
        /*variant*/
        p[9] === "default"
      );
      let D = o;
      o = k(p), o === D ? ~o && v[o].p(p, m) : (a && (pt(), J(v[D], 1, 1, () => {
        v[D] = null;
      }), _t()), ~o ? (a = v[o], a ? a.p(p, m) : (a = v[o] = b[o](p), a.c()), Z(a, 1), a.m(l.parentNode, l)) : a = null), /*timer*/
      p[6] ? h && (pt(), J(h, 1, 1, () => {
        h = null;
      }), _t()) : h ? (h.p(p, m), m[0] & /*timer*/
      64 && Z(h, 1)) : (h = On(p), h.c(), Z(h, 1), h.m(s.parentNode, s));
    },
    i(p) {
      u || (Z(a), Z(h), u = !0);
    },
    o(p) {
      J(a), J(h), u = !1;
    },
    d(p) {
      p && (E(t), E(e), E(i), E(l), E(s)), c && c.d(p), g && g.d(), f && f.d(), ~o && v[o].d(p), h && h.d(p);
    }
  };
}
function An(r) {
  let t, e = `translateX(${/*eta_level*/
  (r[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = le("div"), this.h();
    },
    l(n) {
      t = oe(n, "DIV", { class: !0 }), re(t).forEach(E), this.h();
    },
    h() {
      ae(t, "class", "eta-bar svelte-vusapu"), Ce(t, "transform", e);
    },
    m(n, i) {
      A(n, t, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      524288 && e !== (e = `translateX(${/*eta_level*/
      (n[19] || 0) * 100 - 100}%)`) && Ce(t, "transform", e);
    },
    d(n) {
      n && E(t);
    }
  };
}
function xr(r) {
  let t;
  return {
    c() {
      t = P("processing |");
    },
    l(e) {
      t = z(e, "processing |");
    },
    m(e, n) {
      A(e, t, n);
    },
    p: Rt,
    d(e) {
      e && E(t);
    }
  };
}
function Br(r) {
  let t, e = (
    /*queue_position*/
    r[3] + 1 + ""
  ), n, i, o, a;
  return {
    c() {
      t = P("queue: "), n = P(e), i = P("/"), o = P(
        /*queue_size*/
        r[4]
      ), a = P(" |");
    },
    l(l) {
      t = z(l, "queue: "), n = z(l, e), i = z(l, "/"), o = z(
        l,
        /*queue_size*/
        r[4]
      ), a = z(l, " |");
    },
    m(l, s) {
      A(l, t, s), A(l, n, s), A(l, i, s), A(l, o, s), A(l, a, s);
    },
    p(l, s) {
      s[0] & /*queue_position*/
      8 && e !== (e = /*queue_position*/
      l[3] + 1 + "") && ee(n, e), s[0] & /*queue_size*/
      16 && ee(
        o,
        /*queue_size*/
        l[4]
      );
    },
    d(l) {
      l && (E(t), E(n), E(i), E(o), E(a));
    }
  };
}
function Ir(r) {
  let t, e = dt(
    /*progress*/
    r[8]
  ), n = [];
  for (let i = 0; i < e.length; i += 1)
    n[i] = Tn(kn(r, e, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      t = se();
    },
    l(i) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(i);
      t = se();
    },
    m(i, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(i, o);
      A(i, t, o);
    },
    p(i, o) {
      if (o[0] & /*progress*/
      256) {
        e = dt(
          /*progress*/
          i[8]
        );
        let a;
        for (a = 0; a < e.length; a += 1) {
          const l = kn(i, e, a);
          n[a] ? n[a].p(l, o) : (n[a] = Tn(l), n[a].c(), n[a].m(t.parentNode, t));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = e.length;
      }
    },
    d(i) {
      i && E(t), gi(n, i);
    }
  };
}
function Sn(r) {
  let t, e = (
    /*p*/
    r[43].unit + ""
  ), n, i, o = " ", a;
  function l(c, _) {
    return (
      /*p*/
      c[43].length != null ? qr : Rr
    );
  }
  let s = l(r), u = s(r);
  return {
    c() {
      u.c(), t = Y(), n = P(e), i = P(" | "), a = P(o);
    },
    l(c) {
      u.l(c), t = V(c), n = z(c, e), i = z(c, " | "), a = z(c, o);
    },
    m(c, _) {
      u.m(c, _), A(c, t, _), A(c, n, _), A(c, i, _), A(c, a, _);
    },
    p(c, _) {
      s === (s = l(c)) && u ? u.p(c, _) : (u.d(1), u = s(c), u && (u.c(), u.m(t.parentNode, t))), _[0] & /*progress*/
      256 && e !== (e = /*p*/
      c[43].unit + "") && ee(n, e);
    },
    d(c) {
      c && (E(t), E(n), E(i), E(a)), u.d(c);
    }
  };
}
function Rr(r) {
  let t = Le(
    /*p*/
    r[43].index || 0
  ) + "", e;
  return {
    c() {
      e = P(t);
    },
    l(n) {
      e = z(n, t);
    },
    m(n, i) {
      A(n, e, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && t !== (t = Le(
        /*p*/
        n[43].index || 0
      ) + "") && ee(e, t);
    },
    d(n) {
      n && E(e);
    }
  };
}
function qr(r) {
  let t = Le(
    /*p*/
    r[43].index || 0
  ) + "", e, n, i = Le(
    /*p*/
    r[43].length
  ) + "", o;
  return {
    c() {
      e = P(t), n = P("/"), o = P(i);
    },
    l(a) {
      e = z(a, t), n = z(a, "/"), o = z(a, i);
    },
    m(a, l) {
      A(a, e, l), A(a, n, l), A(a, o, l);
    },
    p(a, l) {
      l[0] & /*progress*/
      256 && t !== (t = Le(
        /*p*/
        a[43].index || 0
      ) + "") && ee(e, t), l[0] & /*progress*/
      256 && i !== (i = Le(
        /*p*/
        a[43].length
      ) + "") && ee(o, i);
    },
    d(a) {
      a && (E(e), E(n), E(o));
    }
  };
}
function Tn(r) {
  let t, e = (
    /*p*/
    r[43].index != null && Sn(r)
  );
  return {
    c() {
      e && e.c(), t = se();
    },
    l(n) {
      e && e.l(n), t = se();
    },
    m(n, i) {
      e && e.m(n, i), A(n, t, i);
    },
    p(n, i) {
      /*p*/
      n[43].index != null ? e ? e.p(n, i) : (e = Sn(n), e.c(), e.m(t.parentNode, t)) : e && (e.d(1), e = null);
    },
    d(n) {
      n && E(t), e && e.d(n);
    }
  };
}
function xn(r) {
  let t, e = (
    /*eta*/
    r[0] ? `/${/*formatted_eta*/
    r[21]}` : ""
  ), n, i;
  return {
    c() {
      t = P(
        /*formatted_timer*/
        r[22]
      ), n = P(e), i = P("s");
    },
    l(o) {
      t = z(
        o,
        /*formatted_timer*/
        r[22]
      ), n = z(o, e), i = z(o, "s");
    },
    m(o, a) {
      A(o, t, a), A(o, n, a), A(o, i, a);
    },
    p(o, a) {
      a[0] & /*formatted_timer*/
      4194304 && ee(
        t,
        /*formatted_timer*/
        o[22]
      ), a[0] & /*eta, formatted_eta*/
      2097153 && e !== (e = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[21]}` : "") && ee(n, e);
    },
    d(o) {
      o && (E(t), E(n), E(i));
    }
  };
}
function Lr(r) {
  let t, e;
  return t = new Dr({
    props: { margin: (
      /*variant*/
      r[9] === "default"
    ) }
  }), {
    c() {
      jt(t.$$.fragment);
    },
    l(n) {
      Ht(t.$$.fragment, n);
    },
    m(n, i) {
      Vt(t, n, i), e = !0;
    },
    p(n, i) {
      const o = {};
      i[0] & /*variant*/
      512 && (o.margin = /*variant*/
      n[9] === "default"), t.$set(o);
    },
    i(n) {
      e || (Z(t.$$.fragment, n), e = !0);
    },
    o(n) {
      J(t.$$.fragment, n), e = !1;
    },
    d(n) {
      Zt(t, n);
    }
  };
}
function Nr(r) {
  let t, e, n, i, o, a = `${/*last_progress_level*/
  r[17] * 100}%`, l = (
    /*progress*/
    r[8] != null && Bn(r)
  );
  return {
    c() {
      t = le("div"), e = le("div"), l && l.c(), n = Y(), i = le("div"), o = le("div"), this.h();
    },
    l(s) {
      t = oe(s, "DIV", { class: !0 });
      var u = re(t);
      e = oe(u, "DIV", { class: !0 });
      var c = re(e);
      l && l.l(c), c.forEach(E), n = V(u), i = oe(u, "DIV", { class: !0 });
      var _ = re(i);
      o = oe(_, "DIV", { class: !0 }), re(o).forEach(E), _.forEach(E), u.forEach(E), this.h();
    },
    h() {
      ae(e, "class", "progress-level-inner svelte-vusapu"), ae(o, "class", "progress-bar svelte-vusapu"), Ce(o, "width", a), ae(i, "class", "progress-bar-wrap svelte-vusapu"), ae(t, "class", "progress-level svelte-vusapu");
    },
    m(s, u) {
      A(s, t, u), me(t, e), l && l.m(e, null), me(t, n), me(t, i), me(i, o), r[34](o);
    },
    p(s, u) {
      /*progress*/
      s[8] != null ? l ? l.p(s, u) : (l = Bn(s), l.c(), l.m(e, null)) : l && (l.d(1), l = null), u[0] & /*last_progress_level*/
      131072 && a !== (a = `${/*last_progress_level*/
      s[17] * 100}%`) && Ce(o, "width", a);
    },
    i: Rt,
    o: Rt,
    d(s) {
      s && E(t), l && l.d(), r[34](null);
    }
  };
}
function Bn(r) {
  let t, e = dt(
    /*progress*/
    r[8]
  ), n = [];
  for (let i = 0; i < e.length; i += 1)
    n[i] = Nn(En(r, e, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      t = se();
    },
    l(i) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(i);
      t = se();
    },
    m(i, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(i, o);
      A(i, t, o);
    },
    p(i, o) {
      if (o[0] & /*progress_level, progress*/
      65792) {
        e = dt(
          /*progress*/
          i[8]
        );
        let a;
        for (a = 0; a < e.length; a += 1) {
          const l = En(i, e, a);
          n[a] ? n[a].p(l, o) : (n[a] = Nn(l), n[a].c(), n[a].m(t.parentNode, t));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = e.length;
      }
    },
    d(i) {
      i && E(t), gi(n, i);
    }
  };
}
function In(r) {
  let t, e, n, i, o = (
    /*i*/
    r[45] !== 0 && Or()
  ), a = (
    /*p*/
    r[43].desc != null && Rn(r)
  ), l = (
    /*p*/
    r[43].desc != null && /*progress_level*/
    r[16] && /*progress_level*/
    r[16][
      /*i*/
      r[45]
    ] != null && qn()
  ), s = (
    /*progress_level*/
    r[16] != null && Ln(r)
  );
  return {
    c() {
      o && o.c(), t = Y(), a && a.c(), e = Y(), l && l.c(), n = Y(), s && s.c(), i = se();
    },
    l(u) {
      o && o.l(u), t = V(u), a && a.l(u), e = V(u), l && l.l(u), n = V(u), s && s.l(u), i = se();
    },
    m(u, c) {
      o && o.m(u, c), A(u, t, c), a && a.m(u, c), A(u, e, c), l && l.m(u, c), A(u, n, c), s && s.m(u, c), A(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[43].desc != null ? a ? a.p(u, c) : (a = Rn(u), a.c(), a.m(e.parentNode, e)) : a && (a.d(1), a = null), /*p*/
      u[43].desc != null && /*progress_level*/
      u[16] && /*progress_level*/
      u[16][
        /*i*/
        u[45]
      ] != null ? l || (l = qn(), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null), /*progress_level*/
      u[16] != null ? s ? s.p(u, c) : (s = Ln(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (E(t), E(e), E(n), E(i)), o && o.d(u), a && a.d(u), l && l.d(u), s && s.d(u);
    }
  };
}
function Or(r) {
  let t;
  return {
    c() {
      t = P(" /");
    },
    l(e) {
      t = z(e, " /");
    },
    m(e, n) {
      A(e, t, n);
    },
    d(e) {
      e && E(t);
    }
  };
}
function Rn(r) {
  let t = (
    /*p*/
    r[43].desc + ""
  ), e;
  return {
    c() {
      e = P(t);
    },
    l(n) {
      e = z(n, t);
    },
    m(n, i) {
      A(n, e, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && t !== (t = /*p*/
      n[43].desc + "") && ee(e, t);
    },
    d(n) {
      n && E(e);
    }
  };
}
function qn(r) {
  let t;
  return {
    c() {
      t = P("-");
    },
    l(e) {
      t = z(e, "-");
    },
    m(e, n) {
      A(e, t, n);
    },
    d(e) {
      e && E(t);
    }
  };
}
function Ln(r) {
  let t = (100 * /*progress_level*/
  (r[16][
    /*i*/
    r[45]
  ] || 0)).toFixed(1) + "", e, n;
  return {
    c() {
      e = P(t), n = P("%");
    },
    l(i) {
      e = z(i, t), n = z(i, "%");
    },
    m(i, o) {
      A(i, e, o), A(i, n, o);
    },
    p(i, o) {
      o[0] & /*progress_level*/
      65536 && t !== (t = (100 * /*progress_level*/
      (i[16][
        /*i*/
        i[45]
      ] || 0)).toFixed(1) + "") && ee(e, t);
    },
    d(i) {
      i && (E(e), E(n));
    }
  };
}
function Nn(r) {
  let t, e = (
    /*p*/
    (r[43].desc != null || /*progress_level*/
    r[16] && /*progress_level*/
    r[16][
      /*i*/
      r[45]
    ] != null) && In(r)
  );
  return {
    c() {
      e && e.c(), t = se();
    },
    l(n) {
      e && e.l(n), t = se();
    },
    m(n, i) {
      e && e.m(n, i), A(n, t, i);
    },
    p(n, i) {
      /*p*/
      n[43].desc != null || /*progress_level*/
      n[16] && /*progress_level*/
      n[16][
        /*i*/
        n[45]
      ] != null ? e ? e.p(n, i) : (e = In(n), e.c(), e.m(t.parentNode, t)) : e && (e.d(1), e = null);
    },
    d(n) {
      n && E(t), e && e.d(n);
    }
  };
}
function On(r) {
  let t, e, n, i;
  const o = (
    /*#slots*/
    r[32]["additional-loading-text"]
  ), a = mi(
    o,
    r,
    /*$$scope*/
    r[31],
    Fn
  );
  return {
    c() {
      t = le("p"), e = P(
        /*loading_text*/
        r[10]
      ), n = Y(), a && a.c(), this.h();
    },
    l(l) {
      t = oe(l, "P", { class: !0 });
      var s = re(t);
      e = z(
        s,
        /*loading_text*/
        r[10]
      ), s.forEach(E), n = V(l), a && a.l(l), this.h();
    },
    h() {
      ae(t, "class", "loading svelte-vusapu");
    },
    m(l, s) {
      A(l, t, s), me(t, e), A(l, n, s), a && a.m(l, s), i = !0;
    },
    p(l, s) {
      (!i || s[0] & /*loading_text*/
      1024) && ee(
        e,
        /*loading_text*/
        l[10]
      ), a && a.p && (!i || s[1] & /*$$scope*/
      1) && Di(
        a,
        o,
        l,
        /*$$scope*/
        l[31],
        i ? vi(
          o,
          /*$$scope*/
          l[31],
          s,
          Ar
        ) : bi(
          /*$$scope*/
          l[31]
        ),
        Fn
      );
    },
    i(l) {
      i || (Z(a, l), i = !0);
    },
    o(l) {
      J(a, l), i = !1;
    },
    d(l) {
      l && (E(t), E(n)), a && a.d(l);
    }
  };
}
function zr(r) {
  let t, e, n, i, o, a, l = (
    /*validation_error*/
    r[1] && /*show_validation_error*/
    r[14] && Cn(r)
  );
  const s = [Tr, Sr], u = [];
  function c(_, d) {
    return (
      /*status*/
      _[5] === "pending" ? 0 : (
        /*status*/
        _[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = c(r)) && (i = u[n] = s[n](r)), {
    c() {
      t = le("div"), l && l.c(), e = Y(), i && i.c(), this.h();
    },
    l(_) {
      t = oe(_, "DIV", { class: !0 });
      var d = re(t);
      l && l.l(d), e = V(d), i && i.l(d), d.forEach(E), this.h();
    },
    h() {
      ae(t, "class", o = "wrap " + /*variant*/
      r[9] + " " + /*show_progress*/
      r[7] + " svelte-vusapu"), ie(t, "hide", (!/*status*/
      r[5] || /*status*/
      r[5] === "complete" || /*show_progress*/
      r[7] === "hidden" || /*status*/
      r[5] == "streaming") && !/*validation_error*/
      r[1]), ie(
        t,
        "translucent",
        /*variant*/
        r[9] === "center" && /*status*/
        (r[5] === "pending" || /*status*/
        r[5] === "error") || /*translucent*/
        r[12] || /*show_progress*/
        r[7] === "minimal" || /*validation_error*/
        r[1]
      ), ie(
        t,
        "generating",
        /*status*/
        r[5] === "generating" && /*show_progress*/
        r[7] === "full"
      ), ie(
        t,
        "border",
        /*border*/
        r[13]
      ), Ce(
        t,
        "position",
        /*absolute*/
        r[11] ? "absolute" : "static"
      ), Ce(
        t,
        "padding",
        /*absolute*/
        r[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(_, d) {
      A(_, t, d), l && l.m(t, null), me(t, e), ~n && u[n].m(t, null), r[36](t), a = !0;
    },
    p(_, d) {
      /*validation_error*/
      _[1] && /*show_validation_error*/
      _[14] ? l ? (l.p(_, d), d[0] & /*validation_error, show_validation_error*/
      16386 && Z(l, 1)) : (l = Cn(_), l.c(), Z(l, 1), l.m(t, e)) : l && (pt(), J(l, 1, 1, () => {
        l = null;
      }), _t());
      let g = n;
      n = c(_), n === g ? ~n && u[n].p(_, d) : (i && (pt(), J(u[g], 1, 1, () => {
        u[g] = null;
      }), _t()), ~n ? (i = u[n], i ? i.p(_, d) : (i = u[n] = s[n](_), i.c()), Z(i, 1), i.m(t, null)) : i = null), (!a || d[0] & /*variant, show_progress*/
      640 && o !== (o = "wrap " + /*variant*/
      _[9] + " " + /*show_progress*/
      _[7] + " svelte-vusapu")) && ae(t, "class", o), (!a || d[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && ie(t, "hide", (!/*status*/
      _[5] || /*status*/
      _[5] === "complete" || /*show_progress*/
      _[7] === "hidden" || /*status*/
      _[5] == "streaming") && !/*validation_error*/
      _[1]), (!a || d[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && ie(
        t,
        "translucent",
        /*variant*/
        _[9] === "center" && /*status*/
        (_[5] === "pending" || /*status*/
        _[5] === "error") || /*translucent*/
        _[12] || /*show_progress*/
        _[7] === "minimal" || /*validation_error*/
        _[1]
      ), (!a || d[0] & /*variant, show_progress, status, show_progress*/
      672) && ie(
        t,
        "generating",
        /*status*/
        _[5] === "generating" && /*show_progress*/
        _[7] === "full"
      ), (!a || d[0] & /*variant, show_progress, border*/
      8832) && ie(
        t,
        "border",
        /*border*/
        _[13]
      ), d[0] & /*absolute*/
      2048 && Ce(
        t,
        "position",
        /*absolute*/
        _[11] ? "absolute" : "static"
      ), d[0] & /*absolute*/
      2048 && Ce(
        t,
        "padding",
        /*absolute*/
        _[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(_) {
      a || (Z(l), Z(i), a = !0);
    },
    o(_) {
      J(l), J(i), a = !1;
    },
    d(_) {
      _ && E(t), l && l.d(), ~n && u[n].d(), r[36](null);
    }
  };
}
var Pr = function(r, t, e, n) {
  function i(o) {
    return o instanceof e ? o : new e(function(a) {
      a(o);
    });
  }
  return new (e || (e = Promise))(function(o, a) {
    function l(c) {
      try {
        u(n.next(c));
      } catch (_) {
        a(_);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (_) {
        a(_);
      }
    }
    function u(c) {
      c.done ? o(c.value) : i(c.value).then(l, s);
    }
    u((n = n.apply(r, t || [])).next());
  });
};
let rt = [], kt = !1;
const Mr = typeof window < "u", yi = Mr ? window.requestAnimationFrame : (r) => {
};
function Ur(r) {
  return Pr(this, arguments, void 0, function* (t, e = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
      if (rt.push(t), !kt) kt = !0;
      else return;
      yield Fr(), yi(() => {
        let n = [0, 0];
        for (let i = 0; i < rt.length; i++) {
          const a = rt[i].getBoundingClientRect();
          (i === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), kt = !1, rt = [];
      });
    }
  });
}
function Gr(r, t, e) {
  let n, { $$slots: i = {}, $$scope: o } = t;
  const a = kr();
  let { i18n: l } = t, { eta: s = null } = t, { queue_position: u } = t, { queue_size: c } = t, { status: _ } = t, { scroll_to_output: d = !1 } = t, { timer: g = !0 } = t, { show_progress: f = "full" } = t, { message: b = null } = t, { progress: v = null } = t, { variant: k = "default" } = t, { loading_text: h = "Loading..." } = t, { absolute: p = !0 } = t, { translucent: m = !1 } = t, { border: D = !1 } = t, { autoscroll: y } = t, { validation_error: w = null } = t, { show_validation_error: S = !0 } = t, F, T = !1, N = 0, L = 0, ue = null, te = null, Ae = 0, X = null, ce, q = null, j = !0;
  const ge = () => {
    e(0, s = e(29, ue = e(21, Fe = null))), e(27, N = performance.now()), e(28, L = 0), T = !0, $();
  };
  function $() {
    yi(() => {
      e(28, L = (performance.now() - N) / 1e3), T && $();
    });
  }
  function U() {
    e(28, L = 0), e(0, s = e(29, ue = e(21, Fe = null))), T && (T = !1);
  }
  Er(() => {
    T && U();
  });
  let Fe = null;
  const W = () => e(1, w = null);
  function be(C) {
    $n[C ? "unshift" : "push"](() => {
      q = C, e(18, q), e(8, v), e(16, X), e(17, ce);
    });
  }
  const ke = () => {
    a("clear_status");
  };
  function Ie(C) {
    $n[C ? "unshift" : "push"](() => {
      F = C, e(15, F);
    });
  }
  return r.$$set = (C) => {
    "i18n" in C && e(2, l = C.i18n), "eta" in C && e(0, s = C.eta), "queue_position" in C && e(3, u = C.queue_position), "queue_size" in C && e(4, c = C.queue_size), "status" in C && e(5, _ = C.status), "scroll_to_output" in C && e(24, d = C.scroll_to_output), "timer" in C && e(6, g = C.timer), "show_progress" in C && e(7, f = C.show_progress), "message" in C && e(25, b = C.message), "progress" in C && e(8, v = C.progress), "variant" in C && e(9, k = C.variant), "loading_text" in C && e(10, h = C.loading_text), "absolute" in C && e(11, p = C.absolute), "translucent" in C && e(12, m = C.translucent), "border" in C && e(13, D = C.border), "autoscroll" in C && e(26, y = C.autoscroll), "validation_error" in C && e(1, w = C.validation_error), "show_validation_error" in C && e(14, S = C.show_validation_error), "$$scope" in C && e(31, o = C.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (s === null && e(0, s = ue), s != null && ue !== s && (e(30, te = (performance.now() - N) / 1e3 + s), e(21, Fe = te.toFixed(1)), e(29, ue = s))), r.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && e(19, Ae = te === null || te <= 0 || !L ? null : Math.min(L / te, 1)), r.$$.dirty[0] & /*progress*/
    256 && v != null && e(20, j = !1), r.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (v != null ? e(16, X = v.map((C) => {
      if (C.index != null && C.length != null)
        return C.index / C.length;
      if (C.progress != null)
        return C.progress;
    })) : e(16, X = null), X ? (e(17, ce = X[X.length - 1]), q && (ce === 0 ? e(18, q.style.transition = "0", q) : e(18, q.style.transition = "150ms", q))) : e(17, ce = void 0)), r.$$.dirty[0] & /*status*/
    32 && (_ === "pending" ? ge() : U()), r.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && F && d && (_ === "pending" || _ === "complete") && Ur(F, y), r.$$.dirty[0] & /*status, message*/
    33554464, r.$$.dirty[0] & /*timer_diff*/
    268435456 && e(22, n = L.toFixed(1));
  }, [
    s,
    w,
    l,
    u,
    c,
    _,
    g,
    f,
    v,
    k,
    h,
    p,
    m,
    D,
    S,
    F,
    X,
    ce,
    q,
    Ae,
    j,
    Fe,
    n,
    a,
    d,
    b,
    y,
    N,
    L,
    ue,
    te,
    o,
    i,
    W,
    be,
    ke,
    Ie
  ];
}
class Hr extends yr {
  constructor(t) {
    super(), $r(
      this,
      t,
      Gr,
      zr,
      wr,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: uF,
  SvelteComponent: cF,
  add_render_callback: _F,
  append_hydration: dF,
  attr: pF,
  bubble: hF,
  check_outros: fF,
  children: mF,
  claim_component: gF,
  claim_element: bF,
  claim_html_tag: vF,
  claim_space: DF,
  claim_text: yF,
  create_component: $F,
  create_in_transition: wF,
  create_out_transition: FF,
  destroy_component: EF,
  detach: kF,
  element: CF,
  get_svelte_dataset: AF,
  group_outros: SF,
  init: TF,
  insert_hydration: xF,
  listen: BF,
  mount_component: IF,
  run_all: RF,
  safe_not_equal: qF,
  set_data: LF,
  space: NF,
  stop_propagation: OF,
  text: zF,
  toggle_class: PF,
  transition_in: MF,
  transition_out: UF
} = window.__gradio__svelte__internal, { createEventDispatcher: GF, onMount: HF } = window.__gradio__svelte__internal, {
  SvelteComponent: jF,
  append_hydration: ZF,
  attr: VF,
  bubble: YF,
  check_outros: XF,
  children: WF,
  claim_component: KF,
  claim_element: QF,
  claim_space: JF,
  component_subscribe: eE,
  create_animation: tE,
  create_component: nE,
  destroy_component: iE,
  detach: aE,
  element: rE,
  ensure_array_like: oE,
  fix_and_outro_and_destroy_block: lE,
  fix_position: sE,
  group_outros: uE,
  init: cE,
  insert_hydration: _E,
  mount_component: dE,
  noop: pE,
  safe_not_equal: hE,
  set_style: fE,
  space: mE,
  transition_in: gE,
  transition_out: bE,
  update_keyed_each: vE
} = window.__gradio__svelte__internal, {
  SvelteComponent: DE,
  attr: yE,
  children: $E,
  claim_element: wE,
  detach: FE,
  element: EE,
  empty: kE,
  init: CE,
  insert_hydration: AE,
  noop: SE,
  safe_not_equal: TE,
  set_style: xE
} = window.__gradio__svelte__internal, {
  SvelteComponent: jr,
  append_hydration: Se,
  assign: Zr,
  attr: fe,
  check_outros: Vr,
  children: Oe,
  claim_component: $i,
  claim_element: ze,
  claim_space: qt,
  claim_text: wi,
  create_component: Fi,
  destroy_block: Ei,
  destroy_component: ki,
  detach: De,
  element: Pe,
  ensure_array_like: ht,
  get_spread_object: Yr,
  get_spread_update: Xr,
  group_outros: Wr,
  init: Kr,
  insert_hydration: ft,
  mount_component: Ci,
  null_to_empty: zn,
  safe_not_equal: Qr,
  set_data: Ai,
  space: Lt,
  text: Si,
  transition_in: Ve,
  transition_out: mt,
  update_keyed_each: Ti
} = window.__gradio__svelte__internal;
function Pn(r, t, e) {
  const n = r.slice();
  return n[12] = t[e], n[14] = e, n;
}
function Mn(r, t, e) {
  const n = r.slice();
  return n[15] = t[e], n[17] = e, n;
}
function Un(r) {
  let t, e;
  const n = [
    { autoscroll: (
      /*gradio*/
      r[8].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      r[8].i18n
    ) },
    /*loading_status*/
    r[7]
  ];
  let i = {};
  for (let o = 0; o < n.length; o += 1)
    i = Zr(i, n[o]);
  return t = new Hr({ props: i }), t.$on(
    "clear_status",
    /*clear_status_handler*/
    r[9]
  ), {
    c() {
      Fi(t.$$.fragment);
    },
    l(o) {
      $i(t.$$.fragment, o);
    },
    m(o, a) {
      Ci(t, o, a), e = !0;
    },
    p(o, a) {
      const l = a & /*gradio, loading_status*/
      384 ? Xr(n, [
        a & /*gradio*/
        256 && { autoscroll: (
          /*gradio*/
          o[8].autoscroll
        ) },
        a & /*gradio*/
        256 && { i18n: (
          /*gradio*/
          o[8].i18n
        ) },
        a & /*loading_status*/
        128 && Yr(
          /*loading_status*/
          o[7]
        )
      ]) : {};
      t.$set(l);
    },
    i(o) {
      e || (Ve(t.$$.fragment, o), e = !0);
    },
    o(o) {
      mt(t.$$.fragment, o), e = !1;
    },
    d(o) {
      ki(t, o);
    }
  };
}
function Gn(r, t) {
  let e, n, i = (
    /*letter*/
    t[15] + ""
  ), o, a;
  return {
    key: r,
    first: null,
    c() {
      e = Pe("div"), n = Pe("span"), o = Si(i), this.h();
    },
    l(l) {
      e = ze(l, "DIV", { class: !0 });
      var s = Oe(e);
      n = ze(s, "SPAN", { class: !0 });
      var u = Oe(n);
      o = wi(u, i), u.forEach(De), s.forEach(De), this.h();
    },
    h() {
      fe(n, "class", "svelte-1tmx8xk"), fe(e, "class", a = zn(`tile ${/*row*/
      t[12].statuses[
        /*tileIndex*/
        t[17]
      ]}`) + " svelte-1tmx8xk"), this.first = e;
    },
    m(l, s) {
      ft(l, e, s), Se(e, n), Se(n, o);
    },
    p(l, s) {
      t = l, s & /*value*/
      8 && i !== (i = /*letter*/
      t[15] + "") && Ai(o, i), s & /*value*/
      8 && a !== (a = zn(`tile ${/*row*/
      t[12].statuses[
        /*tileIndex*/
        t[17]
      ]}`) + " svelte-1tmx8xk") && fe(e, "class", a);
    },
    d(l) {
      l && De(e);
    }
  };
}
function Hn(r, t) {
  let e, n = [], i = /* @__PURE__ */ new Map(), o, a, l = ht(
    /*row*/
    t[12].letters
  );
  const s = (u) => (
    /*tileIndex*/
    u[17]
  );
  for (let u = 0; u < l.length; u += 1) {
    let c = Mn(t, l, u), _ = s(c);
    i.set(_, n[u] = Gn(_, c));
  }
  return {
    key: r,
    first: null,
    c() {
      e = Pe("div");
      for (let u = 0; u < n.length; u += 1)
        n[u].c();
      o = Lt(), this.h();
    },
    l(u) {
      e = ze(u, "DIV", { class: !0, "aria-hidden": !0 });
      var c = Oe(e);
      for (let _ = 0; _ < n.length; _ += 1)
        n[_].l(c);
      o = qt(c), c.forEach(De), this.h();
    },
    h() {
      fe(e, "class", "row svelte-1tmx8xk"), fe(e, "aria-hidden", a = /*index*/
      t[14] < /*value*/
      t[3].current_row - 1), this.first = e;
    },
    m(u, c) {
      ft(u, e, c);
      for (let _ = 0; _ < n.length; _ += 1)
        n[_] && n[_].m(e, null);
      Se(e, o);
    },
    p(u, c) {
      t = u, c & /*value*/
      8 && (l = ht(
        /*row*/
        t[12].letters
      ), n = Ti(n, c, s, 1, t, l, i, e, Ei, Gn, o, Mn)), c & /*value*/
      8 && a !== (a = /*index*/
      t[14] < /*value*/
      t[3].current_row - 1) && fe(e, "aria-hidden", a);
    },
    d(u) {
      u && De(e);
      for (let c = 0; c < n.length; c += 1)
        n[c].d();
    }
  };
}
function Jr(r) {
  let t, e, n, i = [], o = /* @__PURE__ */ new Map(), a, l, s = (
    /*value*/
    r[3].message + ""
  ), u, c, _ = (
    /*loading_status*/
    r[7] && Un(r)
  ), d = ht(
    /*value*/
    r[3].board
  );
  const g = (f) => (
    /*index*/
    f[14]
  );
  for (let f = 0; f < d.length; f += 1) {
    let b = Pn(r, d, f), v = g(b);
    o.set(v, i[f] = Hn(v, b));
  }
  return {
    c() {
      _ && _.c(), t = Lt(), e = Pe("div"), n = Pe("div");
      for (let f = 0; f < i.length; f += 1)
        i[f].c();
      a = Lt(), l = Pe("div"), u = Si(s), this.h();
    },
    l(f) {
      _ && _.l(f), t = qt(f), e = ze(f, "DIV", { class: !0 });
      var b = Oe(e);
      n = ze(b, "DIV", { class: !0, "aria-label": !0 });
      var v = Oe(n);
      for (let h = 0; h < i.length; h += 1)
        i[h].l(v);
      v.forEach(De), a = qt(b), l = ze(b, "DIV", { class: !0, role: !0 });
      var k = Oe(l);
      u = wi(k, s), k.forEach(De), b.forEach(De), this.h();
    },
    h() {
      fe(n, "class", "board svelte-1tmx8xk"), fe(n, "aria-label", "Wordle board"), fe(l, "class", "message svelte-1tmx8xk"), fe(l, "role", "status"), fe(e, "class", "wordle svelte-1tmx8xk");
    },
    m(f, b) {
      _ && _.m(f, b), ft(f, t, b), ft(f, e, b), Se(e, n);
      for (let v = 0; v < i.length; v += 1)
        i[v] && i[v].m(n, null);
      Se(e, a), Se(e, l), Se(l, u), c = !0;
    },
    p(f, b) {
      /*loading_status*/
      f[7] ? _ ? (_.p(f, b), b & /*loading_status*/
      128 && Ve(_, 1)) : (_ = Un(f), _.c(), Ve(_, 1), _.m(t.parentNode, t)) : _ && (Wr(), mt(_, 1, 1, () => {
        _ = null;
      }), Vr()), b & /*value*/
      8 && (d = ht(
        /*value*/
        f[3].board
      ), i = Ti(i, b, g, 1, f, d, o, n, Ei, Hn, null, Pn)), (!c || b & /*value*/
      8) && s !== (s = /*value*/
      f[3].message + "") && Ai(u, s);
    },
    i(f) {
      c || (Ve(_), c = !0);
    },
    o(f) {
      mt(_), c = !1;
    },
    d(f) {
      f && (De(t), De(e)), _ && _.d(f);
      for (let b = 0; b < i.length; b += 1)
        i[b].d();
    }
  };
}
function eo(r) {
  let t, e;
  return t = new Wi({
    props: {
      visible: (
        /*visible*/
        r[2]
      ),
      elem_id: (
        /*elem_id*/
        r[0]
      ),
      elem_classes: (
        /*elem_classes*/
        r[1]
      ),
      container: (
        /*container*/
        r[4]
      ),
      scale: (
        /*scale*/
        r[5]
      ),
      min_width: (
        /*min_width*/
        r[6]
      ),
      $$slots: { default: [Jr] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      Fi(t.$$.fragment);
    },
    l(n) {
      $i(t.$$.fragment, n);
    },
    m(n, i) {
      Ci(t, n, i), e = !0;
    },
    p(n, [i]) {
      const o = {};
      i & /*visible*/
      4 && (o.visible = /*visible*/
      n[2]), i & /*elem_id*/
      1 && (o.elem_id = /*elem_id*/
      n[0]), i & /*elem_classes*/
      2 && (o.elem_classes = /*elem_classes*/
      n[1]), i & /*container*/
      16 && (o.container = /*container*/
      n[4]), i & /*scale*/
      32 && (o.scale = /*scale*/
      n[5]), i & /*min_width*/
      64 && (o.min_width = /*min_width*/
      n[6]), i & /*$$scope, value, gradio, loading_status*/
      262536 && (o.$$scope = { dirty: i, ctx: n }), t.$set(o);
    },
    i(n) {
      e || (Ve(t.$$.fragment, n), e = !0);
    },
    o(n) {
      mt(t.$$.fragment, n), e = !1;
    },
    d(n) {
      ki(t, n);
    }
  };
}
const jn = 5;
function to(r, t, e) {
  let { elem_id: n = "" } = t, { elem_classes: i = [] } = t, { visible: o = !0 } = t;
  const a = () => ({
    letters: Array(jn).fill(""),
    statuses: Array(jn).fill("empty")
  });
  let { value: l = {
    board: Array.from({ length: 6 }, () => a()),
    current_row: 0,
    status: "playing",
    message: "Guess the word!",
    max_rows: 6
  } } = t, { container: s = !0 } = t, { scale: u = null } = t, { min_width: c = void 0 } = t, { loading_status: _ } = t, { gradio: d } = t;
  const g = () => d.dispatch("clear_status", _);
  return r.$$set = (f) => {
    "elem_id" in f && e(0, n = f.elem_id), "elem_classes" in f && e(1, i = f.elem_classes), "visible" in f && e(2, o = f.visible), "value" in f && e(3, l = f.value), "container" in f && e(4, s = f.container), "scale" in f && e(5, u = f.scale), "min_width" in f && e(6, c = f.min_width), "loading_status" in f && e(7, _ = f.loading_status), "gradio" in f && e(8, d = f.gradio);
  }, [
    n,
    i,
    o,
    l,
    s,
    u,
    c,
    _,
    d,
    g
  ];
}
class BE extends jr {
  constructor(t) {
    super(), Kr(this, t, to, eo, Qr, {
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      value: 3,
      container: 4,
      scale: 5,
      min_width: 6,
      loading_status: 7,
      gradio: 8
    });
  }
}
export {
  BE as default
};
