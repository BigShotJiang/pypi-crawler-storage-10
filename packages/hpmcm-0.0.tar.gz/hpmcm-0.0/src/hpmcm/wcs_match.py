from __future__ import annotations

from typing import Any

import numpy as np
import pandas
from astropy import wcs

from .match import Match


def createGlobalWcs(
    refDir: tuple[float, float],
    pixSize: float,
    nPix: np.ndarray,
) -> wcs.WCS:
    """Helper function to create the WCS used to project the
    sources in a skymap


    Parameters
    ----------
    refDir:
        Reference Direction (RA, DEC) in degrees

    pixSize:
        Pixel size in degrees

    nPix:
        Number of pixels in x, y

    Returns
    -------
    WCS to create the pixel grid
    """
    w = wcs.WCS(naxis=2)
    w.wcs.cdelt = [-pixSize, pixSize]
    w.wcs.crpix = [nPix[0] / 2, nPix[1] / 2]
    w.wcs.crval = [refDir[0], refDir[1]]
    return w


class WcsMatch(Match):
    """Class to do N-way matching using a provided WCS.

    This uses the provided WCS to define a Skymap that covers the full region
    begin matched.

    Notes
    -----
    This expectes a list of parquet files with pandas DataFrames
    that contain the following columns.

    +-------------+---------------------------------------------------------------+
    | Column name | Description                                                   |
    +=============+===============================================================+
    | id          | source ID                                                     |
    +-------------+---------------------------------------------------------------+
    | ra          | RA in degrees                                                 |
    +-------------+---------------------------------------------------------------+
    | dec         | DEC in degress                                                |
    +-------------+---------------------------------------------------------------+
    | SNR         | Signal-to-Noise of source, used for filtering and centroiding |
    +-------------+---------------------------------------------------------------+
    """

    def __init__(
        self,
        matchWcs: wcs.WCS,
        **kwargs: Any,
    ):
        self.wcs: wcs.WCS = matchWcs
        pixelSize: float = self.wcs.wcs.cdelt[1]
        nPixSide: np.ndarray = np.ceil(2 * np.array(self.wcs.wcs.crpix)).astype(int)
        Match.__init__(self, pixelSize=pixelSize, nPixSide=nPixSide, **kwargs)

    @classmethod
    def create(
        cls,
        refDir: tuple[float, float],
        regionSize: tuple[float, float],
        pixelSize: float,
        **kwargs: Any,
    ) -> WcsMatch:
        """Helper function to create a Match object.

        This will use the provided arguments to create a WCS, and then
        create and return a `WcsMatch` matcher.

        Parameters
        ----------
        refDir:
            Reference Direction (RA, DEC) in degrees

        regionSize:
            Size of match region, in degrees

        pixSize:
            Pixel size in degrees

        Returns
        -------
        Object to create matches for the requested region
        """
        nPix = (np.array(regionSize) / pixelSize).astype(int)
        matchWcs = createGlobalWcs(refDir, pixelSize, nPix)
        return cls(matchWcs, nPixels=nPix, **kwargs)

    def _getPixValues(self, df: pandas.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        xPix, yPix = self.wcs.wcs_world2pix(df["ra"].values, df["dec"].values, 0)
        return xPix, yPix

    def pixToWorld(
        self,
        xPix: np.ndarray,
        yPix: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Convert local coords in pixels to world coordinates (RA, DEC)"""
        assert self.wcs is not None
        return self.wcs.wcs_pix2world(xPix, yPix, 0)

    def reduceDataFrame(
        self,
        df: pandas.DataFrame,
    ) -> pandas.DataFrame:
        """Reduce a single input DataFrame

        Notes
        -----
        This applies a trivial cut on signal-to-noise (SNR>1).
        and adds the pixel coordinates to the DataFrame.

        This will add these columns to the output dataframes


        +--------------+-------------------------------------+
        | Column       | Description                         |
        +==============+=====================================+
        | id           | Index of object inside catalog      |
        +--------------+-------------------------------------+
        | ra           | Source RA                           |
        +--------------+-------------------------------------+
        | dec          | Source DEC                          |
        +--------------+-------------------------------------+
        | xPix         | X-coordinate in global WCS frame    |
        +--------------+-------------------------------------+
        | yPix         | Y-coordinate in global WCS frame    |
        +--------------+-------------------------------------+
        | SNR          | Signal-to-noise ratio               |
        +--------------+-------------------------------------+

        """
        df_clean = df[(df.SNR > 1)]
        xPix, yPix = self.wcs.wcs_world2pix(
            df_clean["ra"].values, df_clean["dec"].values, 0
        )
        df_clean["xPix"] = xPix
        df_clean["yPix"] = yPix
        filtered = (
            (df_clean.xPix >= 0)
            & (df_clean.xPix < self.nPixSide[0])
            & (df_clean.yPix >= 0)
            & (df_clean.yPix < self.nPixSide[1])
        )

        df_red = df_clean[filtered].copy(deep=True)

        return df_red[
            [
                "id",
                "ra",
                "dec",
                "xPix",
                "yPix",
                "SNR",
            ]
        ]
