__all__ = ["version", "version_info"]


version = "0.12.0"
version_info = (0, 12, 0, "final", 0)
