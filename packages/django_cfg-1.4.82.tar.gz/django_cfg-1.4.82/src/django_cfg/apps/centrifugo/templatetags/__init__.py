"""Centrifugo template tags."""
