"""Views for serving Next.js static builds."""

from pathlib import Path
from django.http import Http404
from django.views.static import serve
from django.views import View


class NextJSStaticView(View):
    """
    Serve Next.js static build files using Django's built-in static file serving.
    """

    app_name = 'admin'

    def get(self, request, path=''):
        """Serve static files from Next.js build."""
        import django_cfg

        base_dir = Path(django_cfg.__file__).parent / 'static' / 'frontend' / self.app_name

        if not base_dir.exists():
            raise Http404(f"Frontend app '{self.app_name}' not found. Run 'make build-admin' to build it.")

        # Default to index.html for root path
        if not path or path == '/':
            path = 'index.html'

        # For routes without extension, try .html (Next.js static export behavior)
        file_path = base_dir / path
        if not file_path.exists() and not path.endswith('.html') and '.' not in Path(path).name:
            # Try adding .html extension
            html_path = path + '.html'
            html_file = base_dir / html_path
            if html_file.exists():
                path = html_path

        # Use Django's static serve view (handles security, content-type, etc.)
        return serve(request, path, document_root=str(base_dir))


class AdminView(NextJSStaticView):
    """Serve Next.js Admin Panel."""
    app_name = 'admin'
