# MareArts Road Objects Detection Package - V2

# Suppress ONNX Runtime GPU discovery warnings
import os
import sys

os.environ['ORT_LOGGING_LEVEL'] = '3'  # 3 = ERROR only

# Suppress stderr during onnxruntime import (GPU discovery warnings)
class _SuppressStderr:
    def __enter__(self):
        self.orig_stderr = sys.stderr
        sys.stderr = open(os.devnull, 'w')
        self.orig_stderr_fd = os.dup(2)
        self.devnull_fd = os.open(os.devnull, os.O_WRONLY)
        os.dup2(self.devnull_fd, 2)
        return self

    def __exit__(self, *args):
        sys.stderr.close()
        sys.stderr = self.orig_stderr
        os.dup2(self.orig_stderr_fd, 2)
        os.close(self.devnull_fd)
        os.close(self.orig_stderr_fd)

from ._version import __version__

# Import V2 validation function (public API)
from .marearts_robj_p import validate_user_key_with_signature

# Import detector with stderr suppressed (hides GPU discovery warnings)
with _SuppressStderr():
    from .marearts_robj_d import ma_road_object_detector

__all__ = [
    "__version__",
    "validate_user_key_with_signature",
    "ma_road_object_detector",
]
