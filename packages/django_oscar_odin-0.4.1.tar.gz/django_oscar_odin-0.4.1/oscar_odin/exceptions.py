class OscarOdinException(TypeError):
    pass
