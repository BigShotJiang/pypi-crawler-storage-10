
SEQmil: Biomolecular Multi-Instance Machine Learning
====================================================================

``SEQmil`` is a Python package for applying **Multi-Instance Learning (MIL)** to biological sequences such as **RNA, DNA, and proteins**.
It enables flexible representation of sequences as bags of subsequences, and supports learning tasks where only bag-level labels
are available.


Key Features
---------------

- 🧬 MIL support for biological sequences (RNA, DNA, Proteins)
- 🧩 Instance construction using sliding windows
- 🛠️ Compatible with scikit-learn, PyTorch, and standard ML tools
- 📊 Integrated tutorial and example workflow

Installation
---------------

.. code-block:: bash

    pip install seqmil


Quick start
---------------

See the examples of ``SEQmil`` application for different tasks in the `tutorial collection <tutorials>`_ .