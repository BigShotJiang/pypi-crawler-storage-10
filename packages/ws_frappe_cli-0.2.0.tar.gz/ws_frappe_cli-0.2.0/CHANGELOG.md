# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial CLI structure with setup, create-site, and fetch-app commands
- Support for predefined apps (ERPNext, HRMS, Payments, etc.)
- Interactive prompts for user-friendly experience
- Colored output for better UX
- Comprehensive test suite
- GitHub Actions CI/CD pipeline

### Changed
- Migrated from standalone scripts to proper CLI package structure

### Fixed
- N/A

## [0.1.0] - 2024-01-XX

### Added
- Initial release
- Basic CLI functionality for Frappe/ERPNext development
- Environment setup automation
- Site creation with interactive configuration
- App installation from predefined list or custom GitHub repositories
- Cross-platform support (Linux, macOS, Windows)

### Features
- `setup` command for environment initialization
- `create-site` command for site creation
- `fetch-app` command for app management
- Rich CLI interface with colors and interactive prompts
- Support for Python 3.8+

[Unreleased]: https://github.com/HasanHajHasan/ws-frappe-cli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/HasanHajHasan/ws-frappe-cli/releases/tag/v0.1.0