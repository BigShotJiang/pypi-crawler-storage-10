# jx_color

A Python module for colored text in terminal.

## Installation

```bash
pip install jx-color