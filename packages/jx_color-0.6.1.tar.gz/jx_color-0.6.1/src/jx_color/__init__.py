from .color_operations import I as I_obj
import builtins
builtins.I = I_obj

I: "IType" = I_obj  # Type hint for autocomplete

__all__ = ['I']

__version__ = "0.6.1"
__author__ = "Mr. Inosuke"