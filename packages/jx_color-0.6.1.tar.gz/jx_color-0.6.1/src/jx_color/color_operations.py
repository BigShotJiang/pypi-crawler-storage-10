class I:
    """Color class for terminal text styling with 50+ colors"""
    
    # Basic Colors with type hints
    RED: str = '\033[91m'
    GREEN: str = '\033[92m'
    YELLOW: str = '\033[93m'
    BLUE: str = '\033[94m'
    MAGENTA: str = '\033[95m'
    CYAN: str = '\033[96m'
    WHITE: str = '\033[97m'
    BLACK: str = '\033[90m'
    
    # Bright Colors
    B_RED: str = '\033[91;1m'
    B_GREEN: str = '\033[92;1m'
    B_YELLOW: str = '\033[93;1m'
    B_BLUE: str = '\033[94;1m'
    B_MAGENTA: str = '\033[95;1m'
    B_CYAN: str = '\033[96;1m'
    B_WHITE: str = '\033[97;1m'
    
    # Dark Colors
    D_RED: str = '\033[31m'
    D_GREEN: str = '\033[32m'
    D_YELLOW: str = '\033[33m'
    D_BLUE: str = '\033[34m'
    D_MAGENTA: str = '\033[35m'
    D_CYAN: str = '\033[36m'
    D_GRAY: str = '\033[90m'
    
    # RGB Colors (8-bit)
    ORANGE: str = '\033[38;5;214m'
    PINK: str = '\033[38;5;205m'
    PURPLE: str = '\033[38;5;129m'
    LIME: str = '\033[38;5;118m'
    TEAL: str = '\033[38;5;51m'
    LAVENDER: str = '\033[38;5;183m'
    BROWN: str = '\033[38;5;130m'
    GOLD: str = '\033[38;5;220m'
    SILVER: str = '\033[38;5;7m'
    MAROON: str = '\033[38;5;88m'
    OLIVE: str = '\033[38;5;58m'
    NAVY: str = '\033[38;5;17m'
    CORAL: str = '\033[38;5;209m'
    SALMON: str = '\033[38;5;210m'
    PEACH: str = '\033[38;5;223m'
    MINT: str = '\033[38;5;121m'
    SKY_BLUE: str = '\033[38;5;117m'
    ROYAL_BLUE: str = '\033[38;5;63m'
    INDIGO: str = '\033[38;5;54m'
    VIOLET: str = '\033[38;5;127m'
    PLUM: str = '\033[38;5;219m'
    BEIGE: str = '\033[38;5;230m'
    CHOCOLATE: str = '\033[38;5;94m'
    TURQUOISE: str = '\033[38;5;80m'
    EMERALD: str = '\033[38;5;46m'
    RUBY: str = '\033[38;5;160m'
    AMBER: str = '\033[38;5;214m'
    CRIMSON: str = '\033[38;5;196m'
    FOREST_GREEN: str = '\033[38;5;28m'
    MIDNIGHT_BLUE: str = '\033[38;5;18m'
    HOT_PINK: str = '\033[38;5;198m'
    LIGHT_BLUE: str = '\033[38;5;117m'
    DARK_ORANGE: str = '\033[38;5;202m'
    LIGHT_GREEN: str = '\033[38;5;120m'
    DARK_PURPLE: str = '\033[38;5;90m'
    LIGHT_PINK: str = '\033[38;5;218m'
    STEEL_BLUE: str = '\033[38;5;67m'
    SAND: str = '\033[38;5;180m'
    BRICK: str = '\033[38;5;124m'
    GRASS: str = '\033[38;5;70m'
    OCEAN: str = '\033[38;5;27m'
    SUNSET: str = '\033[38;5;209m'
    LAVENDER_BLUSH: str = '\033[38;5;225m'
    
    # Background Colors
    BG_RED: str = '\033[41m'
    BG_GREEN: str = '\033[42m'
    BG_BLUE: str = '\033[44m'
    BG_YELLOW: str = '\033[43m'
    BG_MAGENTA: str = '\033[45m'
    BG_CYAN: str = '\033[46m'
    BG_WHITE: str = '\033[47m'
    BG_BLACK: str = '\033[40m'
    BG_ORANGE: str = '\033[48;5;214m'
    BG_PINK: str = '\033[48;5;205m'
    BG_PURPLE: str = '\033[48;5;129m'
    BG_GOLD: str = '\033[48;5;220m'
    BG_SILVER: str = '\033[48;5;7m'
    
    # Bright Background Colors
    BG_B_RED: str = '\033[101m'
    BG_B_GREEN: str = '\033[102m'
    BG_B_YELLOW: str = '\033[103m'
    BG_B_BLUE: str = '\033[104m'
    BG_B_MAGENTA: str = '\033[105m'
    BG_B_CYAN: str = '\033[106m'
    BG_B_WHITE: str = '\033[107m'
    
    # Styles
    BOLD: str = '\033[1m'
    UNDERLINE: str = '\033[4m'
    ITALIC: str = '\033[3m'
    REVERSE: str = '\033[7m'
    STRIKETHROUGH: str = '\033[9m'
    BLINK: str = '\033[5m'
    DIM: str = '\033[2m'
    
    # Reset
    RESET: str = '\033[0m'
    
    # Static Methods with type hints
    @staticmethod
    def red(text: str) -> str: return f"{I.RED}{text}{I.RESET}"
    @staticmethod
    def green(text: str) -> str: return f"{I.GREEN}{text}{I.RESET}"
    @staticmethod
    def yellow(text: str) -> str: return f"{I.YELLOW}{text}{I.RESET}"
    @staticmethod
    def blue(text: str) -> str: return f"{I.BLUE}{text}{I.RESET}"
    @staticmethod
    def magenta(text: str) -> str: return f"{I.MAGENTA}{text}{I.RESET}"
    @staticmethod
    def cyan(text: str) -> str: return f"{I.CYAN}{text}{I.RESET}"
    @staticmethod
    def white(text: str) -> str: return f"{I.WHITE}{text}{I.RESET}"
    @staticmethod
    def black(text: str) -> str: return f"{I.BLACK}{text}{I.RESET}"
    @staticmethod
    def orange(text: str) -> str: return f"{I.ORANGE}{text}{I.RESET}"
    @staticmethod
    def pink(text: str) -> str: return f"{I.PINK}{text}{I.RESET}"
    @staticmethod
    def purple(text: str) -> str: return f"{I.PURPLE}{text}{I.RESET}"
    @staticmethod
    def gold(text: str) -> str: return f"{I.GOLD}{text}{I.RESET}"
    @staticmethod
    def silver(text: str) -> str: return f"{I.SILVER}{text}{I.RESET}"
    @staticmethod
    def brown(text: str) -> str: return f"{I.BROWN}{text}{I.RESET}"
    @staticmethod
    def coral(text: str) -> str: return f"{I.CORAL}{text}{I.RESET}"
    @staticmethod
    def lime(text: str) -> str: return f"{I.LIME}{text}{I.RESET}"
    @staticmethod
    def teal(text: str) -> str: return f"{I.TEAL}{text}{I.RESET}"
    @staticmethod
    def lavender(text: str) -> str: return f"{I.LAVENDER}{text}{I.RESET}"
    
    @staticmethod
    def bold(text: str) -> str: return f"{I.BOLD}{text}{I.RESET}"
    @staticmethod
    def underline(text: str) -> str: return f"{I.UNDERLINE}{text}{I.RESET}"
    @staticmethod
    def italic(text: str) -> str: return f"{I.ITALIC}{text}{I.RESET}"
    @staticmethod
    def reverse(text: str) -> str: return f"{I.REVERSE}{text}{I.RESET}"
    @staticmethod
    def strikethrough(text: str) -> str: return f"{I.STRIKETHROUGH}{text}{I.RESET}"