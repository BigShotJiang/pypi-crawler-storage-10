import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from jx_color import I

def test_color_constants():
    assert I.RED == '\033[91m'
    assert I.BLUE == '\033[94m'
    assert I.GREEN == '\033[92m'
    assert I.RESET == '\033[0m'

def test_color_methods():
    red_text = I.red("test")
    assert red_text.startswith('\033[91m')
    assert red_text.endswith('\033[0m')

if __name__ == "__main__":
    test_color_constants()
    test_color_methods()
    print("All tests passed!")