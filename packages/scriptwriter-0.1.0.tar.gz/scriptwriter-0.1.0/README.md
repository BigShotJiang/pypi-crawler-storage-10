# ScriptWriter

Production-ready narrative analysis pipeline with 250 phases.