from collections import Counter
from scriptwriter.core.utils.text import tokens, sentences
def repetition_score(toks):
    c = Counter(toks)
    s = sum(c.values()) or 1
    p = [n/s for n in c.values()]
    return sum(x*x for x in p)
def beat_variance(sents):
    lens = [len(tokens(x)) for x in sents]
    if not lens:
        return 0.0
    m = sum(lens)/len(lens)
    var = sum((x-m)*(x-m) for x in lens)/len(lens)
    return var/(m*m+1e-9)
def cadence_score(sents):
    ends = [x.strip()[-1] if x.strip() else "" for x in sents]
    pn = sum(1 for e in ends if e=="?")
    ex = sum(1 for e in ends if e=="!")
    st = sum(1 for e in ends if e==".")
    total = max(1, len(ends))
    q = pn/total
    e = ex/total
    d = st/total
    return abs(0.33-q)+abs(0.33-e)+abs(0.34-d)
