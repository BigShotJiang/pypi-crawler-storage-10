def is_nonempty(x: str) -> bool:
    return bool(x and x.strip())
