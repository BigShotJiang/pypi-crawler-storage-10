import re
from typing import List
def sentences(x: str) -> List[str]:
    s = re.split(r"(?<=[.!?])\s+", x.strip())
    return [t for t in s if t]
def tokens(x: str) -> List[str]:
    return re.findall(r"[A-Za-z']+", x.lower())
