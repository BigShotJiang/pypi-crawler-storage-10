import json
import click
from rich.console import Console
from scriptwriter.pipelines.compose import run_pipeline
console = Console()
@click.group()
def main():
    ...
@main.command()
@click.option("--input_text", required=True)
def analyze(input_text):
    report = run_pipeline(input_text)
    console.print_json(data=report)
