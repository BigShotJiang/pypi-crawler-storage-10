def ready():
    return True
