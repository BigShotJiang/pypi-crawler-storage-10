import importlib, pkgutil
def load_all():
    pkg = "scriptwriter.phases"
    for _, name, _ in pkgutil.walk_packages(importlib.import_module(pkg).__path__, pkg + "."):
        importlib.import_module(name)
