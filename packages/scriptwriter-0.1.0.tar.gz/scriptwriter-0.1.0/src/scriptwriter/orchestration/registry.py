PHASE_REGISTRY = []
def register(cls):
    inst = cls()
    PHASE_REGISTRY.append(inst)
    return cls
def list_phases():
    return PHASE_REGISTRY
