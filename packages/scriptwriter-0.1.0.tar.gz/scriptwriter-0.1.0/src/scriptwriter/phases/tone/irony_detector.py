from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class IronyDetector:
    def name(self): return "Irony Detector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        quotes = sum(x.count("'") + x.count('"') for x in s)
        score = min(1.0, quotes/max(1,len(s)*2))
        data.setdefault("metrics", {})["irony_detector"] = score
        data["irony"] = {"quote_marks":quotes,"irony_signal_score":round(score,6)}
        return data
