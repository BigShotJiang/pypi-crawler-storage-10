from typing import Dict, List
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

INTENSIFIERS = {"very","so","extremely","absolutely","truly","really","highly","utterly","deeply","totally"}

def _ends(s: List[str]) -> List[str]:
    out = []
    for x in s:
        x = x.strip()
        out.append(x[-1] if x else "")
    return out

def _caps_intensity(toks: List[str]) -> float:
    big = [w for w in toks if len(w) >= 3]
    if not big:
        return 0.0
    caps = sum(1 for w in big if w.isalpha() and w.upper() == w)
    return caps/len(big)

def _intensifier_density(toks: List[str]) -> float:
    if not toks:
        return 0.0
    n = sum(1 for w in toks if w in INTENSIFIERS)
    return n/len(toks)

@register
class ToneHarmonizer:
    def name(self):
        return "Tone Harmonizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        e = _ends(s)
        q = e.count("?")
        ex = e.count("!")
        st = e.count(".")
        total = max(1, len(e))
        q_r = q/total
        ex_r = ex/total
        st_r = st/total
        target_q, target_ex, target_st = 0.25, 0.15, 0.60
        balance = max(0.0, 1.0 - min(1.0, abs(q_r-target_q)+abs(ex_r-target_ex)+abs(st_r-target_st)))
        toks = []
        for x in s:
            toks.extend(tokens(x))
        cap = _caps_intensity(toks)
        intens = _intensifier_density(toks)
        stability = max(0.0, 1.0 - min(1.0, cap*0.7 + intens*0.5))
        tone_score = round(0.6*balance + 0.4*stability, 6)
        data["tone"] = {
            "sentences": total,
            "ratio_question": round(q_r,6),
            "ratio_exclaim": round(ex_r,6),
            "ratio_statement": round(st_r,6),
            "caps_intensity": round(cap,6),
            "intensifier_density": round(intens,6),
            "balance_score": round(balance,6),
            "stability_score": round(stability,6),
            "tone_score": tone_score
        }
        mm = data.get("metrics", {})
        mm["tone_harmonizer"] = tone_score
        data["metrics"] = mm
        return data
