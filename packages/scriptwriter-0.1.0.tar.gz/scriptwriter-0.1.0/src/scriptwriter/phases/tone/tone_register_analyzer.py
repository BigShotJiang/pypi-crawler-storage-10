from typing import Dict
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REG = {"formal":{"therefore","however","moreover","hence"},"casual":{"yeah","okay","cool","kinda","sorta"},"intense":{"now","must","never","always","urgent"}}
@register
class ToneRegisterAnalyzer:
    def name(self):
        return "Tone Register Analyzer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        c = {k:0 for k in REG}
        total = 0
        for x in s:
            t = tokens(x)
            total += len(t)
            for k,v in REG.items():
                c[k] += sum(1 for w in t if w in v)
        dom = max(c, key=c.get) if c else "formal"
        conc = max(0.0, min(1.0, c[dom]/max(1,total)))
        mm = data.get("metrics", {})
        mm["tone_register_analyzer"] = conc
        data["metrics"] = mm
        data["tone_register"] = {"formal":c["formal"],"casual":c["casual"],"intense":c["intense"],"dominant":dom,"register_concentration":round(conc,6)}
        return data
