from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ToneShiftSafetyNet:
    def name(self):
        return "Tone Shift Safety Net"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        shifts = sum(1 for i in range(1,len(s)) if s[i].strip()[-1:]!=s[i-1].strip()[-1:])
        ratio = min(1.0, shifts/max(1,len(s)-1))
        score = max(0.0, 1.0 - ratio)
        mm = data.get("metrics", {})
        mm["tone_shift_safety_net"] = score
        data["metrics"] = mm
        data["tone_guard"] = {"shifts":shifts,"tone_stability_score":round(score,6)}
        return data
