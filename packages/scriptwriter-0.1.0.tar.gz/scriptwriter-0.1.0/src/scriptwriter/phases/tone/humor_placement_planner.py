from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
HUM = {"joke","laugh","smile","funny","gag","bit","pun"}
@register
class HumorPlacementPlanner:
    def name(self):
        return "Humor Placement Planner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in HUM)
        density = min(1.0, hits/max(1,len(s)))
        mm = data.get("metrics", {})
        mm["humor_placement_planner"] = density
        data["metrics"] = mm
        data["humor"] = {"hits":hits,"humor_density":round(density,6)}
        return data
