from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS = {"love","hope","joy","care","save","heal"}
NEG = {"fear","pain","loss","alone","hurt","die"}
@register
class PathosResonanceDriver:
    def name(self):
        return "Pathos Resonance Driver"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        pos = 0
        neg = 0
        for x in s:
            t = tokens(x)
            pos += sum(1 for w in t if w in POS)
            neg += sum(1 for w in t if w in NEG)
        strength = min(1.0, (pos+neg)/max(1,len(s)*2))
        balance = 1.0 - abs((pos/(pos+neg+1e-9)) - 0.5)
        score = round(0.6*strength + 0.4*balance,6)
        mm = data.get("metrics", {})
        mm["pathos_resonance_driver"] = score
        data["metrics"] = mm
        data["pathos"] = {"positive":pos,"negative":neg,"pathos_score":score}
        return data
