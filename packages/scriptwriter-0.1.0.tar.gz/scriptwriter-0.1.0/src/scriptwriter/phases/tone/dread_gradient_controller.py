from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class DreadGradientController:
    def name(self):
        return "Dread Gradient Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        dread = sum(1 for x in s if x.strip().endswith("..."))
        ratio = min(1.0, dread/max(1,len(s)))
        mm = data.get("metrics", {})
        mm["dread_gradient_controller"] = ratio
        data["metrics"] = mm
        data["dread"] = {"ellipses":dread,"dread_ratio":round(ratio,6)}
        return data
