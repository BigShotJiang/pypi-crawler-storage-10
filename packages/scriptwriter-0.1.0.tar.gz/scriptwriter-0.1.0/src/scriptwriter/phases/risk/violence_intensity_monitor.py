from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
V={"kill","stab","blood","gun","shoot","punch","explode","attack","dead"}
@register
class ViolenceIntensityMonitor:
    def name(self): return "Violence Intensity Monitor"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in V) for x in s)
        density=min(1.0,hits/max(1,len(s)))
        score=max(0.0,1.0-density)
        data.setdefault("metrics",{})["violence_intensity_monitor"]=score
        data["violence"]={"hits":hits,"violence_safety_score":round(score,6)}
        return data
