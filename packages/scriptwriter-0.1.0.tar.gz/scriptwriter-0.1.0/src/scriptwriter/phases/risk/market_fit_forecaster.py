from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
GEN = {"action","romance","comedy","thriller","drama","horror","scifi","fantasy","family","animation"}
DEMO = {"teen","adult","family","kids","women","men","global","latam","asia","us"}
@register
class MarketFitForecaster:
    def name(self):
        return "Market Fit Forecaster"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        g = 0
        d = 0
        for x in s:
            t = tokens(x)
            g += sum(1 for w in t if w in GEN)
            d += sum(1 for w in t if w in DEMO)
        cov = min(1.0, (g>0)+(d>0))
        depth = min(1.0, (g+d)/max(1,len(s)*2))
        score = round(0.5*cov + 0.5*depth,6)
        mm = data.get("metrics", {})
        mm["market_fit_forecaster"] = score
        data["metrics"] = mm
        data["market"] = {"genre_hits":g,"demo_hits":d,"market_fit_score":score}
        return data
