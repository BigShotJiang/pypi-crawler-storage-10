from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TRIG = {"brand","copyright","trademark","license","lawsuit","sue","illegal","unauthorized","nc-17","mature","explicit"}
@register
class LegalExposureAnalyzer:
    def name(self):
        return "Legal Exposure Analyzer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in TRIG)
        density = min(1.0, hits/max(1,len(s)))
        score = max(0.0, 1.0 - density)
        mm = data.get("metrics", {})
        mm["legal_exposure_analyzer"] = score
        data["metrics"] = mm
        data["legal"] = {"flags":hits,"legal_risk_score":round(score,6)}
        return data
