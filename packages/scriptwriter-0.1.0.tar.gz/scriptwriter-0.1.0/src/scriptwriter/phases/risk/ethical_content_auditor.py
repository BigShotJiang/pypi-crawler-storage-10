from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TRIG={"exploit","abuse","discriminate","slur","hate","harm"}
@register
class EthicalContentAuditor:
    def name(self): return "Ethical Content Auditor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        flags = sum(sum(1 for w in tokens(x) if w in TRIG) for x in s)
        density = min(1.0, flags/max(1,len(s)))
        score = max(0.0, 1.0 - density)
        data.setdefault("metrics", {})["ethical_content_auditor"] = score
        data["ethical"] = {"flags": flags, "ethical_safety_score": round(score,6)}
        return data
