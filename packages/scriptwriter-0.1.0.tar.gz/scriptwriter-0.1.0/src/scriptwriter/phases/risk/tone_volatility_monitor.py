from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x):
    x=x.strip()
    return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class ToneVolatilityMonitor:
    def name(self): return "Tone Volatility Monitor"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        if len(v)<2:
            vol=0.0
        else:
            dif=[abs(v[i]-v[i-1]) for i in range(1,len(v))]
            vol=sum(dif)/len(dif)
        score=max(0.0,1.0-min(1.0,vol))
        data.setdefault("metrics",{})["tone_volatility_monitor"]=score
        data["tone_volatility"]={"volatility":round(vol,6),"tone_volatility_score":round(score,6)}
        return data
