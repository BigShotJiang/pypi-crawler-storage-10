from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TRIG={"alcohol","gambling","politics","religion","explicit"}
@register
class BrandSafetyClassifier:
    def name(self): return "Brand Safety Classifier"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        flags=sum(sum(1 for w in tokens(x) if w in TRIG) for x in s)
        density=min(1.0,flags/max(1,len(s)))
        score=max(0.0,1.0-density)
        data.setdefault("metrics",{})["brand_safety_classifier"]=score
        data["brand_safety"]={"flags":flags,"brand_safety_score":round(score,6)}
        return data
