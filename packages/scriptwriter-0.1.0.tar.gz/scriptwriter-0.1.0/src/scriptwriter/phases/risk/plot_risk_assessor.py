from typing import Dict, List, Tuple
from collections import Counter
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

CLICHE = {
    ("race","against","time"),
    ("at","the","end","of","the","day"),
    ("fate","of","the","world"),
    ("dark","secret"),
    ("final","stand"),
    ("chosen","one"),
    ("all","along"),
    ("last","minute"),
    ("true","love"),
    ("wake","up","from","a","dream")
}

def _ngrams(toks: List[str], n: int) -> List[Tuple[str,...]]:
    return [tuple(toks[i:i+n]) for i in range(len(toks)-n+1)] if n>0 else []

def _beats(s: str) -> List[str]:
    x = s.replace("—","-")
    seps = [",",";","-"," but "," however "," though "," and then "]
    parts = [s]
    for sep in seps:
        tmp = []
        for p in parts:
            tmp.extend([q for q in p.split(sep) if q.strip()])
        parts = tmp
    return [p.strip() for p in parts if p.strip()]

def _beat_lengths(sents: List[str]) -> List[int]:
    out = []
    for s in sents:
        bs = _beats(s)
        out.extend([len(tokens(b)) for b in bs if b])
    return out

@register
class PlotRiskAssessor:
    def name(self):
        return "Plot Risk Assessor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = []
        for x in s:
            toks.extend(tokens(x))
        bi = Counter(_ngrams(toks,2))
        tri = Counter(_ngrams(toks,3))
        quad = Counter(_ngrams(toks,4))
        rep = sum(n-1 for n in bi.values() if n>1) + sum(n-1 for n in tri.values() if n>1)
        total_ng = max(1, len(_ngrams(toks,2))+len(_ngrams(toks,3)))
        rep_ratio = rep/total_ng
        c_hits = 0
        for c in CLICHE:
            if tuple(c) in tri or tuple(c) in quad:
                c_hits += 1
        bl = _beat_lengths(s)
        m = mean(bl) if bl else 0.0
        sd = pstdev(bl) if len(bl)>1 else 0.0
        var_coeff = sd/(m+1e-9)
        predictability = max(0.0, min(1.0, 1.0 - min(1.0, var_coeff)))
        risk = min(1.0, 0.5*rep_ratio + 0.3*min(1.0, c_hits/3.0) + 0.2*predictability)
        score = max(0.0, 1.0 - risk)
        data["plot_risk"] = {
            "cliche_hits": c_hits,
            "redundancy_ratio": round(rep_ratio,6),
            "beat_uniformity": round(predictability,6),
            "plot_health_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["plot_risk_assessor"] = score
        data["metrics"] = mm
        return data
