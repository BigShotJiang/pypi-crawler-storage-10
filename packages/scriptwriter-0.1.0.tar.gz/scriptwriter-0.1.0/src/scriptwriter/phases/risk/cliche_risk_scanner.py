from typing import Dict, List, Tuple
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

PHRASES = {
    ("race","against","time"),
    ("at","the","end","of","the","day"),
    ("fate","of","the","world"),
    ("dark","secret"),
    ("final","stand"),
    ("chosen","one"),
    ("all","along"),
    ("last","minute"),
    ("true","love"),
    ("wake","up","from","a","dream"),
    ("it","was","all","a","dream"),
    ("love","conquers","all"),
    ("against","all","odds"),
    ("only","one","man"),
    ("save","the","world")
}

def _ngrams(toks: List[str], n: int) -> List[Tuple[str,...]]:
    return [tuple(toks[i:i+n]) for i in range(len(toks)-n+1)] if n>0 else []

@register
class ClicheRiskScanner:
    def name(self):
        return "Cliche Risk Scanner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = []
        for x in s:
            toks.extend(tokens(x))
        tri = Counter(_ngrams(toks,3))
        quad = Counter(_ngrams(toks,4))
        hits = 0
        matched = []
        for p in PHRASES:
            if len(p)==3 and p in tri:
                hits += 1
                matched.append(" ".join(p))
            if len(p)==4 and p in quad:
                hits += 1
                matched.append(" ".join(p))
        density = min(1.0, hits/max(1, len(s)))
        score = max(0.0, 1.0 - density)
        data["cliche"] = {
            "hits": hits,
            "density": round(density,6),
            "cliche_score": round(score,6),
            "matched": matched[:8]
        }
        mm = data.get("metrics", {})
        mm["cliche_risk_scanner"] = score
        data["metrics"] = mm
        return data
