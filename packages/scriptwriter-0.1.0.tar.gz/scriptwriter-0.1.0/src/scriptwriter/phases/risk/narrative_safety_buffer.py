from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class NarrativeSafetyBuffer:
    def name(self): return "Narrative Safety Buffer"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        risky=[k for k in m if "violence" in k or "ethical" in k or "brand" in k]
        score=max(0.0,1.0-min(1.0,len(risky)/15.0))
        data.setdefault("metrics",{})["narrative_safety_buffer"]=score
        data["narrative_safety"]={"risky_dimensions":len(risky),"narrative_safety_score":round(score,6)}
        return data
