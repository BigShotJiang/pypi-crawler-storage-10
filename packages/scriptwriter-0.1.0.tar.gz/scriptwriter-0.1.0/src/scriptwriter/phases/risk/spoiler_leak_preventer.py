from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SPOIL = {"twist","killer","traitor","it_was_him","it_was_her","secret_identity","ending","finale","dies","death"}
def _norm(t):
    out=[]
    for w in t:
        if w=="it": out.append("it")
        elif w=="was" and out and out[-1]=="it": out[-1]="it_was"
        elif w in {"him","her"} and out and out[-1]=="it_was": out[-1]=out[-1]+"_"+w
        else: out.append(w)
    return out
@register
class SpoilerLeakPreventer:
    def name(self):
        return "Spoiler Leak Preventer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        leaks = 0
        for x in s:
            toks = _norm(tokens(x))
            leaks += sum(1 for w in toks if w in SPOIL)
        density = min(1.0, leaks/max(1,len(s)))
        score = max(0.0, 1.0 - density)
        mm = data.get("metrics", {})
        mm["spoiler_leak_preventer"] = score
        data["metrics"] = mm
        data["spoiler"] = {"signals":leaks,"spoiler_safety_score":round(score,6)}
        return data
