from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"kiss","love","date","romance","heart","beloved","wedding"}
@register
class RomanceContentClassifier:
    def name(self): return "Romance Content Classifier"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        density=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["romance_content_classifier"]=density
        data["romance"]={"mentions":hits,"romance_density":round(density,6)}
        return data
