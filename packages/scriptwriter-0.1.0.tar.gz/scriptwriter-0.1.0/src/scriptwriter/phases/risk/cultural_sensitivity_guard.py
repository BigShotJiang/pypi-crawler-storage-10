from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
HOT = {"stereotype","slur","caricature","appropriation","offensive","insensitive","taboo"}
@register
class CulturalSensitivityGuard:
    def name(self):
        return "Cultural Sensitivity Guard"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        flags = 0
        for x in s:
            flags += sum(1 for w in tokens(x) if w in HOT)
        density = min(1.0, flags/max(1,len(s)))
        score = max(0.0, 1.0 - density)
        mm = data.get("metrics", {})
        mm["cultural_sensitivity_guard"] = score
        data["metrics"] = mm
        data["cultural"] = {"flags":flags,"sensitivity_score":round(score,6)}
        return data
