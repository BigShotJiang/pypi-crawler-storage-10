from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class DialogueEnergyIndexer:
    def name(self): return "Dialogue Energy Indexer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        vals=[2 if x.strip().endswith("!") else 1 if x.strip().endswith("?") else 0 for x in s]
        energy=mean(vals) if vals else 0.0
        score=min(1.0,energy/2.0)
        data.setdefault("metrics",{})["dialogue_energy_indexer"]=score
        data["dialogue_energy"]={"energy":round(energy,6),"dialogue_energy_score":round(score,6)}
        return data
