from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
HEDGE={"maybe","perhaps","seems","sorta","kinda","apparently"}
@register
class DialogueAmbiguityReducer:
    def name(self): return "Dialogue Ambiguity Reducer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        total=sum(len(tokens(x)) for x in s) or 1
        hedges=sum(sum(1 for w in tokens(x) if w in HEDGE) for x in s)
        score=max(0.0,1.0-min(1.0,hedges/total*5.0))
        data.setdefault("metrics",{})["dialogue_ambiguity_reducer"]=score
        data["dialogue_ambiguity"]={"hedges":hedges,"ambiguity_reduction_score":round(score,6)}
        return data
