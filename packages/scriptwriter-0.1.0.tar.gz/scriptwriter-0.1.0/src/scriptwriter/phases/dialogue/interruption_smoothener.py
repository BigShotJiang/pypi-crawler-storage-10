from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class InterruptionSmoothener:
    def name(self):
        return "Interruption Smoothener"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        dashes = sum(x.count("—")+x.count("--") for x in s)
        ratio = min(1.0, dashes/max(1,len(s)))
        score = max(0.0, 1.0 - ratio*0.5)
        mm = data.get("metrics", {})
        mm["interruption_smoothener"] = score
        data["metrics"] = mm
        data["interruptions"] = {"markers":dashes,"smoothness_score":round(score,6)}
        return data
