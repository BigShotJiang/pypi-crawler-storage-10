from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class TurnTakingAnalyzer:
    def name(self): return "Turn Taking Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        q=sum(1 for x in s if x.strip().endswith("?"))
        a=sum(1 for x in s if x.strip().endswith("."))
        total=max(1,q+a)
        balance=min(q,a)/total
        data.setdefault("metrics",{})["turn_taking_analyzer"]=balance
        data["turn_taking"]={"questions":q,"statements":a,"turn_balance_score":round(balance,6)}
        return data
