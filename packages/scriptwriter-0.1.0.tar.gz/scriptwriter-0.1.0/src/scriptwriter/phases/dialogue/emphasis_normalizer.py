from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class EmphasisNormalizer:
    def name(self): return "Emphasis Normalizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        ex=sum(1 for x in s if x.strip().endswith("!"))
        ratio=min(1.0,ex/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["emphasis_normalizer"]=score
        data["emphasis"]={"exclaims":ex,"emphasis_stability_score":round(score,6)}
        return data
