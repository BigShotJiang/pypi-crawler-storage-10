from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class OverlapResolutionUnit:
    def name(self):
        return "Overlap Resolution Unit"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        brackets = sum(x.count("[") + x.count("]") for x in s)
        ratio = min(1.0, brackets/max(1,len(s)))
        score = max(0.0, 1.0 - ratio*0.5)
        mm = data.get("metrics", {})
        mm["overlap_resolution_unit"] = score
        data["metrics"] = mm
        data["overlap"] = {"markers":brackets,"overlap_resolution_score":round(score,6)}
        return data
