from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class DialogueVarietyIndexer:
    def name(self): return "Dialogue Variety Indexer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        v = [sig(x) for x in s]
        uniq = len(set(v))
        score = min(1.0, uniq/3.0)
        data.setdefault("metrics", {})["dialogue_variety_indexer"] = score
        data["dialogue_variety"] = {"types": uniq, "dialogue_variety_score": round(score,6)}
        return data
