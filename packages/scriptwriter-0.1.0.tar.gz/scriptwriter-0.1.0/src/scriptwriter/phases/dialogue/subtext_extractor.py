from typing import Dict, List
from collections import Counter
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

HEDGE = {"seems","maybe","perhaps","apparently","sort","kinda","kind","sorta","likely","possibly","probably","roughly","almost","virtually","reportedly","allegedly","supposedly"}
CONTRADICT = {"but","however","though","yet","although","nevertheless","nonetheless","still"}
INTENS = {"very","so","extremely","absolutely","truly","really","highly","utterly","deeply","totally"}
NEG = {"no","not","never","nothing","none","nobody","nowhere","hardly","barely","scarcely"}
AFFIRM = {"yes","yeah","yep","indeed","sure","absolutely","certainly"}
PASSIVE_TRIG = {"was","were","is","are","been","being","be"}

def _ratio(n,d):
    return n/max(1,d)

def _passive_score(toks: List[str]) -> float:
    end = set(["ed"])
    v = 0
    p = 0
    for i,w in enumerate(toks):
        if w in PASSIVE_TRIG and i+1 < len(toks):
            nxt = toks[i+1]
            if len(nxt)>=3 and nxt.endswith("ed"):
                p += 1
        if w.isalpha():
            v += 1
    return _ratio(p, v)

@register
class SubtextExtractor:
    def name(self):
        return "Subtext Extractor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        if not s:
            data["subtext"] = {"sentences":0,"hedge_ratio":0.0,"contradiction_ratio":0.0,"passive_ratio":0.0,"intensifier_ratio":0.0,"negation_ratio":0.0,"affirm_ratio":0.0,"subtext_score":0.0}
            mm = data.get("metrics", {})
            mm["subtext_extractor"] = 0.0
            data["metrics"] = mm
            return data
        hedges = 0
        contr = 0
        intens = 0
        negs = 0
        aff = 0
        pscore = 0.0
        total_tok = 0
        for sen in s:
            t = tokens(sen)
            total_tok += len(t)
            hedges += sum(1 for w in t if w in HEDGE)
            contr += sum(1 for w in t if w in CONTRADICT)
            intens += sum(1 for w in t if w in INTENS)
            negs += sum(1 for w in t if w in NEG)
            aff += sum(1 for w in t if w in AFFIRM)
            pscore += _passive_score(t)
        hedge_r = _ratio(hedges, total_tok)
        contr_r = _ratio(contr, max(1,len(s)))
        intens_r = _ratio(intens, total_tok)
        neg_r = _ratio(negs, total_tok)
        aff_r = _ratio(aff, total_tok)
        passive_r = min(1.0, pscore/max(1,len(s)))
        ambiguity = min(1.0, 0.5*hedge_r + 0.3*passive_r + 0.2*contr_r)
        polarity_tension = min(1.0, abs(aff_r - neg_r) + 0.2*contr_r)
        score = max(0.0, min(1.0, 0.6*ambiguity + 0.4*polarity_tension))
        data["subtext"] = {
            "sentences": len(s),
            "hedge_ratio": round(hedge_r,6),
            "contradiction_ratio": round(contr_r,6),
            "passive_ratio": round(passive_r,6),
            "intensifier_ratio": round(intens_r,6),
            "negation_ratio": round(neg_r,6),
            "affirm_ratio": round(aff_r,6),
            "subtext_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["subtext_extractor"] = score
        data["metrics"] = mm
        return data
