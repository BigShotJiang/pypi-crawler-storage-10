from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
T={"said","asked","replied","shouted","whispered","murmured"}
@register
class AttributionMinimizer:
    def name(self): return "Attribution Minimizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tags=sum(sum(1 for w in tokens(x) if w in T) for x in s)
        score=max(0.0,1.0-min(1.0,tags/max(1,len(s)*2)))
        data.setdefault("metrics",{})["attribution_minimizer"]=score
        data["attribution"]={"tags":tags,"attribution_score":round(score,6)}
        return data
