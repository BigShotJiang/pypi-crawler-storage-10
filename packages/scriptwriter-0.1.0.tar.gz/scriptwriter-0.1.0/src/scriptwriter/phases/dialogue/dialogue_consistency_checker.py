from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class DialogueConsistencyChecker:
    def name(self): return "Dialogue Consistency Checker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        inconsistent = sum(1 for x in s if "??" in x or "!!" in x)
        score = max(0.0, 1.0 - min(1.0, inconsistent/max(1,len(s))))
        data.setdefault("metrics", {})["dialogue_consistency_checker"] = score
        data["dialogue_consistency"] = {"inconsistent":inconsistent,"dialogue_consistency_score":round(score,6)}
        return data
