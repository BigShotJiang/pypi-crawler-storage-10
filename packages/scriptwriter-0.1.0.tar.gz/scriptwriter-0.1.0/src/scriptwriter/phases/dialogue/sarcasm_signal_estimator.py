from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SarcasmSignalEstimator:
    def name(self): return "Sarcasm Signal Estimator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        marks=sum(x.count('"')+x.count("'") for x in s)
        ratio=min(1.0,marks/max(1,len(s)*2))
        data.setdefault("metrics",{})["sarcasm_signal_estimator"]=ratio
        data["sarcasm_signal"]={"quote_marks":marks,"sarcasm_signal_score":round(ratio,6)}
        return data
