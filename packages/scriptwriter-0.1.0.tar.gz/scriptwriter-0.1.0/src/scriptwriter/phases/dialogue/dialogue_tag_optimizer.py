from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

TAGS = {"said","asked","whispered","shouted","replied","murmured"}

@register
class DialogueTagOptimizer:
    def name(self):
        return "Dialogue Tag Optimizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        tags = 0
        quotes = 0
        for x in s:
            quotes += x.count('"')
            tags += sum(1 for w in tokens(x) if w in TAGS)
        pairs = max(1, quotes // 2)
        ratio = tags / pairs
        score = max(0.0, 1.0 - min(1.0, abs(0.8 - min(1.0, ratio))))
        data["dialogue_tags"] = {
            "tags": tags,
            "quote_marks": quotes,
            "tag_efficiency_score": round(score, 6)
        }
        m = data.get("metrics", {})
        m["dialogue_tag_optimizer"] = score
        data["metrics"] = m
        return data
