from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POL={"please","thank","sorry"}
@register
class PolitenessRegisterMeter:
    def name(self): return "Politeness Register Meter"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        marks=sum(sum(1 for w in tokens(x) if w in POL) for x in s)
        density=min(1.0,marks/max(1,len(s)))
        data.setdefault("metrics",{})["politeness_register_meter"]=density
        data["politeness"]={"marks":marks,"politeness_density":round(density,6)}
        return data
