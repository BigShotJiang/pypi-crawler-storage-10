from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class CharacterVoiceFingerprint:
    def name(self): return "Character Voice Fingerprint"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        words=[]
        for x in s:
            words.extend(tokens(x))
        c=Counter(words)
        uniq=len([k for k,v in c.items() if v==1])
        ratio=min(1.0,uniq/max(1,len(words)))
        data.setdefault("metrics",{})["character_voice_fingerprint"]=ratio
        data["voice_fingerprint"]={"unique_once":uniq,"voice_uniqueness_score":round(ratio,6)}
        return data
