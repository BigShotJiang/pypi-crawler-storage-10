from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
FILL = {"um","uh","like","youknow","erm"}
@register
class DialogueClarityFilter:
    def name(self):
        return "Dialogue Clarity Filter"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        total = 0
        fillers = 0
        for x in s:
            t = tokens(x)
            total += len(t)
            fillers += sum(1 for w in t if w in FILL)
        ratio = fillers/max(1,total)
        score = max(0.0, 1.0 - min(1.0, ratio*10.0))
        data["dialogue_clarity"] = {"fillers":fillers,"tokens":total,"clarity_score":round(score,6)}
        m = data.get("metrics", {})
        m["dialogue_clarity_filter"] = score
        data["metrics"] = m
        return data
