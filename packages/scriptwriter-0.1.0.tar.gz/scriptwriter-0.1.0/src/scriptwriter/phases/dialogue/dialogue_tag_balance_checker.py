from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
T={"said","asked","replied","shouted","whispered"}
@register
class DialogueTagBalanceChecker:
    def name(self): return "Dialogue Tag Balance Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tags=sum(sum(1 for w in tokens(x) if w in T) for x in s)
        quotes=sum(x.count('"') for x in s)
        pairs=max(1,quotes//2)
        ratio=min(1.0,tags/pairs)
        score=max(0.0,1.0-abs(0.8-ratio))
        data.setdefault("metrics",{})["dialogue_tag_balance_checker"]=score
        data["dialogue_tag_balance"]={"tags":tags,"pairs":pairs,"tag_balance_score":round(score,6)}
        return data
