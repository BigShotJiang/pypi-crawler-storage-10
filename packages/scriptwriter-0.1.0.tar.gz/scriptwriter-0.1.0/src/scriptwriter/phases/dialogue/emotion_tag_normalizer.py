from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class EmotionTagNormalizer:
    def name(self): return "Emotion Tag Normalizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        brackets=sum(x.count("(")+x.count(")") for x in s)
        ratio=min(1.0,brackets/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["emotion_tag_normalizer"]=score
        data["emotion_tags"]={"stage_dirs":brackets,"emotion_tag_score":round(score,6)}
        return data
