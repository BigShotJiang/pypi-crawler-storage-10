from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
AFF={"yes","indeed","sure","okay"}
NEG={"no","not","never"}
@register
class SubtextContrastMeter:
    def name(self): return "Subtext Contrast Meter"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        contrast=0
        for x in s:
            t=set(tokens(x))
            if (t&AFF) and (t&NEG): contrast+=1
        ratio=min(1.0,contrast/max(1,len(s)))
        data.setdefault("metrics",{})["subtext_contrast_meter"]=ratio
        data["subtext_contrast"]={"contradictions":contrast,"subtext_contrast_score":round(ratio,6)}
        return data
