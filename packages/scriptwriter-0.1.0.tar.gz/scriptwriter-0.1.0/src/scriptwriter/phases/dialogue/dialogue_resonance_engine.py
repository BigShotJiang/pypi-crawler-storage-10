from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import tokens, sentences
from scriptwriter.core.analytics.dialogue import repetition_score, beat_variance, cadence_score
@register
class DialogueResonanceEngine:
    def name(self):
        return "Dialogue Resonance Engine"
    def process(self, data: Dict) -> Dict:
        text = data["text"]
        sents = sentences(text)
        toks = tokens(text)
        vocab = set(toks)
        length = len(toks)
        ttr = len(vocab)/max(1,length)
        rep = repetition_score(toks)
        beat = beat_variance(sents)
        cad = cadence_score(sents)
        resonance = round(0.4*(1-ttr) + 0.3*rep + 0.2*cad + 0.1*(1-beat), 6)
        data["metrics"] = dict(data.get("metrics", {}), dialogue_resonance_engine=resonance)

        data["dialogue"] = {
            "tokens": length,
            "unique_tokens": len(vocab),
            "type_token_ratio": round(ttr,6),
            "repetition": round(rep,6),
            "cadence": round(cad,6),
            "beat_variance": round(beat,6),
            "resonance": resonance
        }
        return data
