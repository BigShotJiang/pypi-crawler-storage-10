from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class MonologueLengthController:
    def name(self): return "Monologue Length Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        long_lines = sum(1 for x in s if len(x.split()) > 28)
        ratio = min(1.0, long_lines/max(1,len(s)))
        score = max(0.0, 1.0 - ratio)
        data.setdefault("metrics", {})["monologue_length_controller"] = score
        data["monologue"] = {"overlong_lines": long_lines, "monologue_control_score": round(score,6)}
        return data
