from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
HEDGE={"maybe","perhaps","seems","sorta","kinda","apparently"}
@register
class DirectnessMeter:
    def name(self): return "Directness Meter"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        total=0
        hedge=0
        for x in s:
            t=tokens(x)
            total+=len(t)
            hedge+=sum(1 for w in t if w in HEDGE)
        ratio=1.0-min(1.0, hedge/max(1,total))
        data.setdefault("metrics",{})["directness_meter"]=ratio
        data["directness"]={"hedges":hedge,"directness_score":round(ratio,6)}
        return data
