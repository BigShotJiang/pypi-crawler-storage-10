from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class DialogueOverlapDetector:
    def name(self): return "Dialogue Overlap Detector"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        overlaps=sum(x.count("[") for x in s)
        ratio=min(1.0,overlaps/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["dialogue_overlap_detector"]=score
        data["dialogue_overlap"]={"overlaps":overlaps,"dialogue_overlap_score":round(score,6)}
        return data
