from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ResponseLatencyEstimator:
    def name(self): return "Response Latency Estimator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        ends=[x.strip()[-1:] for x in s if x.strip()]
        gaps=[1 if ends[i-1]=="?" and ends[i]=="." else 0 for i in range(1,len(ends))]
        lat=mean(gaps) if gaps else 0.0
        score=min(1.0,lat)
        data.setdefault("metrics",{})["response_latency_estimator"]=score
        data["response_latency"]={"latency":round(lat,6),"latency_score":round(score,6)}
        return data
