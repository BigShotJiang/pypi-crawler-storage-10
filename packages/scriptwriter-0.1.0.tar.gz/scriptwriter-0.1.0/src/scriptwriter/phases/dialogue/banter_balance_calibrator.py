from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class BanterBalanceCalibrator:
    def name(self):
        return "Banter Balance Calibrator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        q = sum(1 for x in s if x.strip().endswith("?"))
        a = sum(1 for x in s if x.strip().endswith("."))
        total = max(1, q+a)
        ratio = min(q,a)/total
        score = min(1.0, ratio*2.0)
        data["banter"] = {"questions":q,"answers":a,"balance_score":round(score,6)}
        m = data.get("metrics", {})
        m["banter_balance_calibrator"] = score
        data["metrics"] = m
        return data
