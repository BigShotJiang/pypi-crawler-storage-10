from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class StatementQuestionBalance:
    def name(self): return "Statement Question Balance"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        q=sum(1 for x in s if x.strip().endswith("?"))
        st=sum(1 for x in s if x.strip().endswith("."))
        total=max(1,q+st)
        bal=min(q,st)/total
        data.setdefault("metrics",{})["statement_question_balance"]=bal
        data["stmt_q"]={"questions":q,"statements":st,"balance_score":round(bal,6)}
        return data
