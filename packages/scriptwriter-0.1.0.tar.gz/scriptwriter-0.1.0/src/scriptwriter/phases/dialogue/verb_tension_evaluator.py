from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
STRONG = {"charge","break","bleed","crush","ignite","seize","strike","slam","race","storm","defy"}
WEAK = {"seem","appear","maybe","try","attempt","start","begin"}
@register
class VerbTensionEvaluator:
    def name(self):
        return "Verb Tension Evaluator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        strong = 0
        weak = 0
        for x in s:
            t = tokens(x)
            strong += sum(1 for w in t if w in STRONG)
            weak += sum(1 for w in t if w in WEAK)
        total = strong+weak
        score = strong/max(1,total) if total>0 else 0.0
        data["verb_tension"] = {"strong":strong,"weak":weak,"tension_score":round(score,6)}
        m = data.get("metrics", {})
        m["verb_tension_evaluator"] = score
        data["metrics"] = m
        return data
