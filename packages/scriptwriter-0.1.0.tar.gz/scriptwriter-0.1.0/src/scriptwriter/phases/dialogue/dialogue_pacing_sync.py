from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class DialoguePacingSync:
    def name(self): return "Dialogue Pacing Sync"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        lens = [len(tokens(x)) for x in s if x.strip()]
        mean_len = mean(lens) if lens else 0.0
        score = max(0.0, min(1.0, 1.0 - abs(mean_len-12)/24.0))
        data.setdefault("metrics", {})["dialogue_pacing_sync"] = score
        data["dialogue_pacing"] = {"mean_tokens":round(mean_len,6),"dialogue_pacing_score":round(score,6)}
        return data
