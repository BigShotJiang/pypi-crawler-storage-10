from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
AFFIRM={"yes","indeed","sure","agree"}
NEG={"no","not","never","deny","refuse"}
HEDGE={"seems","maybe","perhaps"}
@register
class SubtextCongruenceChecker:
    def name(self): return "Subtext Congruence Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        incon=0
        for x in s:
            t=set(tokens(x))
            if (t&AFFIRM and t&NEG) or (t&AFFIRM and t&HEDGE) or (t&NEG and t&HEDGE):
                incon+=1
        ratio=max(0.0,1.0-min(1.0,incon/max(1,len(s))))
        data.setdefault("metrics",{})["subtext_congruence_checker"]=ratio
        data["subtext_congruence"]={"incongruent":incon,"congruence_score":round(ratio,6)}
        return data
