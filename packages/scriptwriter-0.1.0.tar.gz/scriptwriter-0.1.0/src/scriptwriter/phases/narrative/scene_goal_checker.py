from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
CUES = {"to","get","find","stop","escape","convince","protect","steal","prove"}
@register
class SceneGoalChecker:
    def name(self): return "Scene Goal Checker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        with_goal = sum(1 for x in s if any(w in CUES for w in tokens(x)))
        ratio = min(1.0, with_goal/max(1,len(s)))
        data.setdefault("metrics", {})["scene_goal_checker"] = ratio
        data["scene_goals"] = {"scenes_with_goal":with_goal,"goal_scene_ratio":round(ratio,6)}
        return data
