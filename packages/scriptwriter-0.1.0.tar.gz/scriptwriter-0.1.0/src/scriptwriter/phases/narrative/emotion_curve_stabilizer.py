from typing import Dict, List
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
NEG = {"fear","pain","loss","alone","hurt","die","sad"}
POS = {"love","hope","joy","care","save","heal","win"}
def _val(x: str) -> int:
    t = tokens(x)
    return sum(1 for w in t if w in POS) - sum(1 for w in t if w in NEG)
@register
class EmotionCurveStabilizer:
    def name(self):
        return "Emotion Curve Stabilizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        vals = [_val(x) for x in s] or [0]
        m = mean(vals)
        sd = pstdev(vals) if len(vals)>1 else 0.0
        jitter = sum(abs(vals[i]-vals[i-1]) for i in range(1,len(vals)))/max(1,len(vals)-1)
        score = max(0.0, 1.0 - min(1.0, (abs(m)/5.0)*0.3 + (sd/5.0)*0.4 + min(1.0,jitter/5.0)*0.3))
        mm = data.get("metrics", {})
        mm["emotion_curve_stabilizer"] = score
        data["metrics"] = mm
        data["emotion_curve"] = {"mean":round(m,6),"std":round(sd,6),"jitter":round(jitter,6),"stability_score":round(score,6)}
        return data
