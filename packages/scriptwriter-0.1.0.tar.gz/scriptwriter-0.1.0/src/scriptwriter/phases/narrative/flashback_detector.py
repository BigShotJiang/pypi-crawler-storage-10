from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class FlashbackDetector:
    def name(self): return "Flashback Detector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = sum(1 for x in s if x.lower().startswith("before") or "years ago" in x.lower())
        ratio = min(1.0, hits/max(1,len(s)))
        data.setdefault("metrics", {})["flashback_detector"] = ratio
        data["flashback"] = {"markers": hits, "flashback_ratio": round(ratio,6)}
        return data
