from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REVEAL = {"reveal","secret","truth","confess","admit","exposed","unmask"}
@register
class RevealTimingCoordinator:
    def name(self):
        return "Reveal Timing Coordinator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        idx = []
        for i,x in enumerate(s):
            t = set(tokens(x))
            if t & REVEAL:
                idx.append(i)
        if not idx:
            ratio = 0.0
        else:
            mid = len(s)/2 if s else 1
            dist = sum(abs(i-mid) for i in idx)/max(1,len(idx))
            ratio = max(0.0, 1.0 - min(1.0, dist/max(1,mid)))
        data["reveal"] = {"count":len(idx),"timing_score":round(ratio,6)}
        m = data.get("metrics", {})
        m["reveal_timing_coordinator"] = ratio
        data["metrics"] = m
        return data
