from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SET = {"setup","plant","hint","seed","foreshadow"}
PAY = {"payoff","result","consequence","reveal"}
@register
class PayoffChainValidator:
    def name(self): return "Payoff Chain Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        setc = sum(sum(1 for w in tokens(x) if w in SET) for x in s)
        payc = sum(sum(1 for w in tokens(x) if w in PAY) for x in s)
        score = min(1.0, payc/max(1,setc)) if setc else 0.0
        data.setdefault("metrics", {})["payoff_chain_validator"] = score
        data["payoff_chain"] = {"setup":setc,"payoff":payc,"chain_score":round(score,6)}
        return data
