from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneExitEntryCoherence:
    def name(self): return "Scene Exit Entry Coherence"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        mismatches=sum(1 for i in range(1,len(s)) if s[i-1].strip().endswith("?") and not s[i].strip().endswith("?"))
        score=max(0.0,1.0-min(1.0,mismatches/max(1,len(s)-1)))
        data.setdefault("metrics",{})["scene_exit_entry_coherence"]=score
        data["exit_entry"]={"mismatches":mismatches,"exit_entry_score":round(score,6)}
        return data
