from typing import Dict, List
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

LOSS = {"die","death","dead","lose","lost","loss","risk","danger","hurt","harm","fail","failure","destroy","ruin","end","collapse","blood","war","prison","broke"}
GAIN = {"win","profit","save","saved","freedom","power","crown","treasure","victory","success","love","peace","heal","survive"}
TIME = {"now","today","tonight","deadline","dawn","midnight","hour","minutes","seconds","immediately","urgent"}
SCOPE = {"city","nation","world","family","kingdom","team","army","company","village","planet","galaxy"}
PERSONAL = {"i","me","my","mine","we","us","our","ours"}

def _density(words: List[str], pool: set) -> float:
    if not words:
        return 0.0
    return sum(1 for w in words if w in pool)/len(words)

@register
class StakesAmplifier:
    def name(self):
        return "Stakes Amplifier"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = []
        for x in s:
            toks.extend(tokens(x))
        loss = _density(toks, LOSS)
        gain = _density(toks, GAIN)
        timep = _density(toks, TIME)
        scope = _density(toks, SCOPE)
        personal = _density(toks, PERSONAL)
        magnitude = min(1.0, 0.5*loss + 0.3*scope + 0.2*gain)
        urgency = min(1.0, timep*2.0)
        proximity = min(1.0, personal*2.0)
        score = round(min(1.0, 0.6*magnitude + 0.25*urgency + 0.15*proximity), 6)
        data["stakes"] = {
            "magnitude": round(magnitude,6),
            "urgency": round(urgency,6),
            "proximity": round(proximity,6),
            "stakes_score": score
        }
        mm = data.get("metrics", {})
        mm["stakes_amplifier"] = score
        data["metrics"] = mm
        return data
