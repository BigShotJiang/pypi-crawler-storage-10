from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ForeshadowingInjector:
    def name(self):
        return "Foreshadowing Injector"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["foreshadowing_injector"] = 1.0
        data["metrics"] = m
        return data
