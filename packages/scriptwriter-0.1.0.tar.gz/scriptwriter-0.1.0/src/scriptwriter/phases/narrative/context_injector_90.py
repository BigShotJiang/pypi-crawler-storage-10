from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ContextInjector90:
    def name(self):
        return "Context Injector 90"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["context_injector_90"] = 1.0
        data["metrics"] = m
        return data
