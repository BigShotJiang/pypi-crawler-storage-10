from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
C={"goal","conflict","reveal","decision","turn"}
@register
class ScenePurposeValidator:
    def name(self): return "Scene Purpose Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        ok=sum(1 for x in s if any(w in C for w in tokens(x)))
        ratio=min(1.0,ok/max(1,len(s)))
        data.setdefault("metrics",{})["scene_purpose_validator"]=ratio
        data["scene_purpose"]={"scenes_ok":ok,"purpose_ratio":round(ratio,6)}
        return data
