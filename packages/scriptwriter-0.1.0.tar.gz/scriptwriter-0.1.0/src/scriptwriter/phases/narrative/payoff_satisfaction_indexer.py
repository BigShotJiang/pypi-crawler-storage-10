from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
PAY = {"payoff","result","consequence","earned","finally","at_last","resolution"}
SET = {"plant","hint","foreshadow","setup","seed"}
@register
class PayoffSatisfactionIndexer:
    def name(self):
        return "Payoff Satisfaction Indexer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        setup = 0
        payoff = 0
        for i,x in enumerate(s):
            t = tokens(x)
            if i < len(s)//2:
                setup += sum(1 for w in t if w in SET)
            else:
                payoff += sum(1 for w in t if w in PAY)
        r = min(1.0, payoff/max(1,setup)) if setup>0 else 0.0
        data["payoff"] = {"setup_hits":setup,"payoff_hits":payoff,"satisfaction_index":round(r,6)}
        m = data.get("metrics", {})
        m["payoff_satisfaction_indexer"] = r
        data["metrics"] = m
        return data
