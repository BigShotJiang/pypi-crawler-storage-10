from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class TensionCurveCalibrator:
    def name(self): return "Tension Curve Calibrator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        avg=mean(v) if v else 0.0
        score=min(1.0,avg/2.0)
        data.setdefault("metrics",{})["tension_curve_calibrator"]=score
        data["tension_curve"]={"mean_signal":round(avg,6),"tension_curve_score":round(score,6)}
        return data
