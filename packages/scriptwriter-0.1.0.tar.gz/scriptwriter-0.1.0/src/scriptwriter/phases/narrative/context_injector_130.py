from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ContextInjector130:
    def name(self):
        return "Context Injector 130"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["context_injector_130"] = 1.0
        data["metrics"] = m
        return data
