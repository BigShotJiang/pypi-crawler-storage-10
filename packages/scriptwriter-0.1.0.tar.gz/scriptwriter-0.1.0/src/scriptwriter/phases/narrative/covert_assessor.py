from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class CovertAssessor:
    def name(self):
        return "Covert Assessor"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["covert_assessor"] = 1.0
        data["metrics"] = m
        return data
