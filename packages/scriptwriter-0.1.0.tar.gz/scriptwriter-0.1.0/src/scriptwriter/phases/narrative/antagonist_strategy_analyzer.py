from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
ANT = {"trap","ambush","spy","deceive","frame","sabotage","blackmail","poison","siege","divide"}
@register
class AntagonistStrategyAnalyzer:
    def name(self): return "Antagonist Strategy Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in ANT) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["antagonist_strategy_analyzer"]=ratio
        data["antagonist_strategy"]={"markers":hits,"strategy_intensity_score":round(ratio,6)}
        return data
