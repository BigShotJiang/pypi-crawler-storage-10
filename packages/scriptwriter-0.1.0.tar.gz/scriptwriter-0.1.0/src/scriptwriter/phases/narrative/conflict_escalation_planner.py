from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
C1 = {"argue","block","chase","strain","threat"}
C2 = {"fight","break","escape","expose","ambush"}
C3 = {"war","explode","betray","dead","collapse"}
@register
class ConflictEscalationPlanner:
    def name(self):
        return "Conflict Escalation Planner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        tiers = []
        for x in s:
            t = tokens(x)
            level = 0
            level += 1 if any(w in t for w in C1) else 0
            level += 1 if any(w in t for w in C2) else 0
            level += 1 if any(w in t for w in C3) else 0
            tiers.append(level)
        inc = sum(1 for i in range(1,len(tiers)) if tiers[i]>=tiers[i-1])
        trend = inc/max(1,len(tiers)-1)
        score = min(1.0, trend)
        mm = data.get("metrics", {})
        mm["conflict_escalation_planner"] = score
        data["metrics"] = mm
        data["conflict_escalation"] = {"levels":tiers,"escalation_score":round(score,6)}
        return data
