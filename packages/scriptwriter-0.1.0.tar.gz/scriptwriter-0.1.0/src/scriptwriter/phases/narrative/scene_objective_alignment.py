from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
C = {"to","get","find","stop","escape","convince","protect","steal","prove"}
@register
class SceneObjectiveAlignment:
    def name(self): return "Scene Objective Alignment"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        aligned = sum(1 for x in s if any(w in C for w in tokens(x)))
        ratio = min(1.0, aligned/max(1,len(s)))
        data.setdefault("metrics", {})["scene_objective_alignment"] = ratio
        data["scene_objective"] = {"aligned_scenes": aligned, "objective_alignment_score": round(ratio,6)}
        return data
