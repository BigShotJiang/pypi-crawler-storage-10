from typing import Dict, List
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

P1 = {"i","me","my","mine","we","us","our","ours"}
P2 = {"you","your","yours"}
P3 = {"he","she","they","him","her","them","his","hers","their","theirs"}

def _pov_counts(sent: str) -> Dict[str,int]:
    t = tokens(sent)
    c = Counter(w for w in t)
    return {
        "p1": sum(c[w] for w in P1 if w in c),
        "p2": sum(c[w] for w in P2 if w in c),
        "p3": sum(c[w] for w in P3 if w in c)
    }

@register
class NarrativePOVController:
    def name(self):
        return "Narrative POV Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        if not s:
            data["pov"] = {"dominant":"none","shifts":0,"consistency":1.0}
            mm = data.get("metrics", {})
            mm["narrative_pov_controller"] = 1.0
            data["metrics"] = mm
            return data
        tags = []
        for x in s:
            c = _pov_counts(x)
            dom = max(("p1","p2","p3"), key=lambda k: c[k])
            if c[dom] == 0:
                dom = "none"
            tags.append(dom)
        shifts = sum(1 for i in range(1,len(tags)) if tags[i] != tags[i-1] and tags[i] != "none" and tags[i-1] != "none")
        dominant = Counter(t for t in tags if t!="none").most_common(1)
        dom = dominant[0][0] if dominant else "none"
        total = max(1, len(tags)-1)
        consistency = max(0.0, 1.0 - min(1.0, shifts/total))
        data["pov"] = {
            "dominant": dom,
            "shifts": shifts,
            "consistency": round(consistency,6)
        }
        mm = data.get("metrics", {})
        mm["narrative_pov_controller"] = consistency
        data["metrics"] = mm
        return data
