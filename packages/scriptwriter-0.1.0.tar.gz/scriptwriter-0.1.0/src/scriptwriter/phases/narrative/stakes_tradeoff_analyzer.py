from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
A={"save","win","gain","profit","love","peace"}
B={"risk","lose","cost","danger","blood","war"}
@register
class StakesTradeoffAnalyzer:
    def name(self): return "Stakes Tradeoff Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        pos=sum(sum(1 for w in tokens(x) if w in A) for x in s)
        neg=sum(sum(1 for w in tokens(x) if w in B) for x in s)
        total=max(1,pos+neg)
        trade=min(1.0,min(pos,neg)/total)
        data.setdefault("metrics",{})["stakes_tradeoff_analyzer"]=trade
        data["stakes_tradeoff"]={"pos":pos,"neg":neg,"tradeoff_score":round(trade,6)}
        return data
