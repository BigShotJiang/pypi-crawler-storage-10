from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
OBJ={"goal","mission","plan","objective","aim","quest"}
RES={"done","complete","win","succeed","fail","lost","ended","finished"}
@register
class ObjectiveResolutionChecker:
    def name(self): return "Objective Resolution Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        o=sum(sum(1 for w in tokens(x) if w in OBJ) for x in s)
        r=sum(sum(1 for w in tokens(x) if w in RES) for x in s)
        score=min(1.0,r/max(1,o)) if o else 0.0
        data.setdefault("metrics",{})["objective_resolution_checker"]=score
        data["objective_resolution"]={"objectives":o,"resolutions":r,"objective_resolution_score":round(score,6)}
        return data
