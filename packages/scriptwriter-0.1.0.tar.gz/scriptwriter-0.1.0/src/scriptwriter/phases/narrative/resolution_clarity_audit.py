from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
RES={"resolve","finally","end","conclude","win","lose","complete","finish"}
@register
class ResolutionClarityAudit:
    def name(self): return "Resolution Clarity Audit"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tail=sum(1 for w in tokens(" ".join(s[-3:])) if w in RES) if s else 0
        ratio=min(1.0,tail/max(1,len(s)))
        data.setdefault("metrics",{})["resolution_clarity_audit"]=ratio
        data["resolution_clarity"]={"tail_resolve_hits":tail,"resolution_clarity_score":round(ratio,6)}
        return data
