from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"choose","decide","sacrifice","risk","cost","either","or","torn","conflict"}
@register
class ProtagonistDilemmaIntensity:
    def name(self): return "Protagonist Dilemma Intensity"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["protagonist_dilemma_intensity"]=ratio
        data["dilemma"]={"markers":hits,"dilemma_intensity_score":round(ratio,6)}
        return data
