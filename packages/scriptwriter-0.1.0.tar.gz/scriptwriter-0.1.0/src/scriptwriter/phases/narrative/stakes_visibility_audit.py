from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"risk","lose","loss","cost","danger","deadline","now","tonight","never","always"}
@register
class StakesVisibilityAudit:
    def name(self): return "Stakes Visibility Audit"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["stakes_visibility_audit"]=ratio
        data["stakes_visibility"]={"markers":hits,"stakes_visibility_score":round(ratio,6)}
        return data
