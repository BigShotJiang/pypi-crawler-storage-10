from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ContextInjector:
    def name(self):
        return "Context Injector"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["context_injector"] = 1.0
        data["metrics"] = m
        return data
