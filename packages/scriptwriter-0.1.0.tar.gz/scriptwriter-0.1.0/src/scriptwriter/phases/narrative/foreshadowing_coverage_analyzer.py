from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SEED={"hint","seed","plant","omen","shadow","whisper"}
@register
class ForeshadowingCoverageAnalyzer:
    def name(self): return "Foreshadowing Coverage Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        covered=sum(any(w in SEED for w in tokens(x)) for x in s)
        ratio=min(1.0,covered/max(1,len(s)))
        data.setdefault("metrics",{})["foreshadowing_coverage_analyzer"]=ratio
        data["foreshadowing"]={"seed_sentences":covered,"foreshadowing_coverage_score":round(ratio,6)}
        return data
