from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
PIV={"but","however","yet","instead","reveal","truth","shift","turn"}
@register
class MidpointPivotDetector:
    def name(self): return "Midpoint Pivot Detector"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        if not s:
            data.setdefault("metrics",{})["midpoint_pivot_detector"]=0.0
            data["midpoint_pivot"]={"pivots":0,"midpoint_pivot_score":0.0}
            return data
        mid=len(s)//2
        before=sum(1 for w in tokens(" ".join(s[:mid])) if w in PIV)
        after=sum(1 for w in tokens(" ".join(s[mid:])) if w in PIV)
        score=min(1.0,abs(after-before)/max(1,before+after))
        data.setdefault("metrics",{})["midpoint_pivot_detector"]=score
        data["midpoint_pivot"]={"before":before,"after":after,"midpoint_pivot_score":round(score,6)}
        return data
