from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
ACT={"decide","choose","refuse","lead","take","grab","run","fight","confront","risk","sacrifice"}
@register
class CharacterAgencyMeter:
    def name(self): return "Character Agency Meter"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in ACT) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["character_agency_meter"]=ratio
        data["agency"]={"markers":hits,"agency_score":round(ratio,6)}
        return data
