from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
CUE = {"because","so","therefore","thus","hence","so_that"}
@register
class CausalityChainAuditor:
    def name(self): return "Causality Chain Auditor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        links = sum(any(w in CUE for w in x.lower().replace(" ", "_").split()) for x in s)
        ratio = min(1.0, links/max(1,len(s)))
        data.setdefault("metrics", {})["causality_chain_auditor"] = ratio
        data["causality_chain"] = {"links":links,"causality_score":round(ratio,6)}
        return data
