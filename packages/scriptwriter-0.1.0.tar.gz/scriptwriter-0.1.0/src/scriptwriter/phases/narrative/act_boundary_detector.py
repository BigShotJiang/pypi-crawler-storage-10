from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ActBoundaryDetector:
    def name(self):
        return "Act Boundary Detector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        cut = 2
        a1 = s[:cut] if len(s)>=cut else s
        a2 = s[cut:2*cut] if len(s)>=2*cut else []
        a3 = s[2*cut:]
        acts = sum(1 for a in [a1,a2,a3] if len(a)>0)
        score = min(1.0, acts/3.0)
        data["acts"] = {"acts_detected":acts,"act_structure_score":round(score,6)}
        m = data.get("metrics", {})
        m["act_boundary_detector"] = score
        data["metrics"] = m
        return data
