from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"peace","justice","truth","love","freedom","unity"}
@register
class EndingThemeLock:
    def name(self): return "Ending Theme Lock"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tail=tokens(" ".join(s[-3:])) if s else []
        hits=sum(1 for w in tail if w in LEX)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["ending_theme_lock"]=ratio
        data["ending_theme"]={"tail_hits":hits,"ending_theme_score":round(ratio,6)}
        return data
