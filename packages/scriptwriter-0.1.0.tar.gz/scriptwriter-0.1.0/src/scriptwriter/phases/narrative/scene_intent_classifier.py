from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneIntentClassifier:
    def name(self): return "Scene Intent Classifier"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        intents=min(3,len(s))
        score=min(1.0,intents/3.0)
        data.setdefault("metrics",{})["scene_intent_classifier"]=score
        data["scene_intent"]={"intents":intents,"scene_intent_score":round(score,6)}
        return data
