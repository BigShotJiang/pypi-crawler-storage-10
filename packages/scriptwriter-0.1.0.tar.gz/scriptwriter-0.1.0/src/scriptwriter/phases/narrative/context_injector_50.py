from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ContextInjector50:
    def name(self):
        return "Context Injector 50"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["context_injector_50"] = 1.0
        data["metrics"] = m
        return data
