from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
CUES = {"setpiece","showdown","heist","siege","battle","trial","escape","chase"}
LINKS = {"because","so","therefore","after","before","then"}
@register
class SetpieceCohesionBuilder:
    def name(self):
        return "Setpiece Cohesion Builder"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hit = 0
        link = 0
        for x in s:
            t = tokens(x)
            hit += sum(1 for w in t if w in CUES)
            link += sum(1 for w in t if w in LINKS)
        density = min(1.0, hit/max(1,len(s)))
        chaining = min(1.0, link/max(1,len(s)))
        score = round(0.6*density + 0.4*chaining,6)
        data["setpiece"] = {"hits":hit,"links":link,"setpiece_score":score}
        m = data.get("metrics", {})
        m["setpiece_cohesion_builder"] = score
        data["metrics"] = m
        return data
