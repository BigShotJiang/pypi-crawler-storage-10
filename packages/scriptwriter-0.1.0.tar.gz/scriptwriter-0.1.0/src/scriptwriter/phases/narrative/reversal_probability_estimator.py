from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REV = {"but","however","instead","yet","although","though","until"}
@register
class ReversalProbabilityEstimator:
    def name(self):
        return "Reversal Probability Estimator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        rev = 0
        for x in s:
            rev += sum(1 for w in tokens(x) if w in REV)
        p = min(1.0, rev/max(1,len(s)))
        data["reversal"] = {"cues":rev,"reversal_prob":round(p,6)}
        m = data.get("metrics", {})
        m["reversal_probability_estimator"] = p
        data["metrics"] = m
        return data
