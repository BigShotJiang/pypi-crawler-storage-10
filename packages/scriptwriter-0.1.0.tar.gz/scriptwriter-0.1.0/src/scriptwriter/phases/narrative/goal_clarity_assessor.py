from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
GOAL = {"goal","want","need","seek","mission","quest","plan","aim","objective"}
@register
class GoalClarityAssessor:
    def name(self): return "Goal Clarity Assessor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = sum(sum(1 for w in tokens(x) if w in GOAL) for x in s)
        ratio = min(1.0, hits/max(1,len(s)))
        data.setdefault("metrics", {})["goal_clarity_assessor"] = ratio
        data["goal_clarity"] = {"hits":hits,"goal_clarity_score":round(ratio,6)}
        return data
