from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RevealImpactEstimator:
    def name(self): return "Reveal Impact Estimator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        marks=[2 if x.strip().endswith("!") else 1 if x.strip().endswith("?") else 0 for x in s]
        impact=mean(marks[-3:]) if marks else 0.0
        score=min(1.0,impact/2.0)
        data.setdefault("metrics",{})["reveal_impact_estimator"]=score
        data["reveal_impact"]={"tail_signal":round(impact,6),"reveal_impact_score":round(score,6)}
        return data
