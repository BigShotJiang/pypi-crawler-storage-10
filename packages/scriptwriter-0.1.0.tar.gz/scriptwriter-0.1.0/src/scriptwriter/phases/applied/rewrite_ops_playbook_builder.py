from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RewriteOpsPlaybookBuilder:
    def name(self): return "Rewrite Ops Playbook Builder"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        steps=min(20,max(6,len(s)//1))
        score=min(1.0,steps/20.0)
        data.setdefault("metrics",{})["rewrite_ops_playbook_builder"]=score
        data["rewrite_ops_playbook"]={"steps":steps,"rewrite_ops_playbook_score":round(score,6)}
        return data
