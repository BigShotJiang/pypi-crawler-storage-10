from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RewriteBriefConstructor:
    def name(self):
        return "Rewrite Brief Constructor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        items = min(10, max(3, len(s)))
        score = min(1.0, items/10.0)
        mm = data.get("metrics", {})
        mm["rewrite_brief_constructor"] = score
        data["metrics"] = mm
        data["rewrite_brief"] = {"items":items,"brief_score":round(score,6)}
        return data
