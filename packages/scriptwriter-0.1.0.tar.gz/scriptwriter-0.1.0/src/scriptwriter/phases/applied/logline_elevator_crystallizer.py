from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import tokens
@register
class LoglineElevatorCrystallizer:
    def name(self):
        return "Logline Elevator Crystallizer"
    def process(self, data: Dict) -> Dict:
        t = tokens(data["text"])
        words = len(t)
        tight = 10 <= words <= 50
        score = 1.0 if tight else max(0.0, 1.0 - abs(words-30)/60.0)
        mm = data.get("metrics", {})
        mm["logline_elevator_crystallizer"] = score
        data["metrics"] = mm
        data["logline"] = {"words":words,"logline_score":round(score,6)}
        return data
