from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class BeatSheetCompiler:
    def name(self): return "Beat Sheet Compiler"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        beats=min(40,max(8,len(s)*2))
        score=min(1.0,beats/40.0)
        data.setdefault("metrics",{})["beat_sheet_compiler"]=score
        data["beat_sheet"]={"beats":beats,"beat_sheet_score":round(score,6)}
        return data
