from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class TrailerCutGenerator:
    def name(self): return "Trailer Cut Generator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        cuts=min(15,max(5,len(s)//1))
        score=min(1.0,cuts/15.0)
        data.setdefault("metrics",{})["trailer_cut_generator"]=score
        data["trailer"]={"cuts":cuts,"trailer_cut_score":round(score,6)}
        return data
