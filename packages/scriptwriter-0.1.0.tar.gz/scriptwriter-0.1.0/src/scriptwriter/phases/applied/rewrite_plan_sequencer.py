from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RewritePlanSequencer:
    def name(self): return "Rewrite Plan Sequencer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        steps=min(12,max(4,len(s)//1))
        score=min(1.0,steps/12.0)
        data.setdefault("metrics",{})["rewrite_plan_sequencer"]=score
        data["rewrite_plan"]={"steps":steps,"rewrite_plan_score":round(score,6)}
        return data
