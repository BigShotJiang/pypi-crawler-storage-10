from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneListCompiler:
    def name(self): return "Scene List Compiler"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        count=len(s)
        score=min(1.0,count/20.0)
        data.setdefault("metrics",{})["scene_list_compiler"]=score
        data["scene_list"]={"count":count,"scene_list_score":round(score,6)}
        return data
