from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class EditListGenerator:
    def name(self): return "Edit List Generator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        cuts=min(30,max(5,len(s)))
        score=min(1.0,cuts/30.0)
        data.setdefault("metrics",{})["edit_list_generator"]=score
        data["edit_list"]={"cuts":cuts,"edit_list_score":round(score,6)}
        return data
