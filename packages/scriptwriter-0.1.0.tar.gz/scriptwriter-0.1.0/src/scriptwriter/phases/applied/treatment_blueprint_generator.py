from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class TreatmentBlueprintGenerator:
    def name(self):
        return "Treatment Blueprint Generator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        sections = min(8, max(4, len(s)//2))
        score = min(1.0, sections/8.0)
        mm = data.get("metrics", {})
        mm["treatment_blueprint_generator"] = score
        data["metrics"] = mm
        data["treatment"] = {"sections":sections,"treatment_score":round(score,6)}
        return data
