from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class OnePagerGenerator:
    def name(self): return "One Pager Generator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        lines=min(12,max(6,len(s)))
        score=min(1.0,lines/12.0)
        data.setdefault("metrics",{})["one_pager_generator"]=score
        data["one_pager"]={"lines":lines,"one_pager_score":round(score,6)}
        return data
