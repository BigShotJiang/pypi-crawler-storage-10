from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SynopsisPrecisionFormatter:
    def name(self):
        return "Synopsis Precision Formatter"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        length = len(s)
        score = max(0.0, 1.0 - abs(length-10)/10.0)
        mm = data.get("metrics", {})
        mm["synopsis_precision_formatter"] = score
        data["metrics"] = mm
        data["synopsis"] = {"sentences":length,"synopsis_score":round(score,6)}
        return data
