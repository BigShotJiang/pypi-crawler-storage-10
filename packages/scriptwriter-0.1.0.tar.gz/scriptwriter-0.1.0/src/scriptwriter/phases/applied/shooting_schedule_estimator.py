from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ShootingScheduleEstimator:
    def name(self): return "Shooting Schedule Estimator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        days = min(45, max(7, len(s)*2))
        score = min(1.0, days/45.0)
        data.setdefault("metrics", {})["shooting_schedule_estimator"] = score
        data["shooting_schedule"] = {"days": days, "shooting_schedule_score": round(score,6)}
        return data
