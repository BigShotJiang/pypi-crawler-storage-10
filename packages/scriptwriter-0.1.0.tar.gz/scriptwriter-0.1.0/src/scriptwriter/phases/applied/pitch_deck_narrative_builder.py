from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class PitchDeckNarrativeBuilder:
    def name(self):
        return "Pitch Deck Narrative Builder"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        slides = min(12, max(3, len(s)))
        score = min(1.0, slides/12.0)
        mm = data.get("metrics", {})
        mm["pitch_deck_narrative_builder"] = score
        data["metrics"] = mm
        data["pitch"] = {"slides":slides,"pitch_score":round(score,6)}
        return data
