from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class AccessibilityCaptionTimingChecker:
    def name(self): return "Accessibility Caption Timing Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        fast=sum(1 for x in s if len(x.split())>=22)
        ratio=min(1.0,fast/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["accessibility_caption_timing_checker"]=score
        data["caption_timing"]={"fast_lines":fast,"caption_timing_score":round(score,6)}
        return data
