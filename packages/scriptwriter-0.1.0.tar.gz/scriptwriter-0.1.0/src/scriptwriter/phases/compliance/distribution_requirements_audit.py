from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REQ = {"subtitle","cc","caption","runtime","resolution","audio","stereo","dolby"}
@register
class DistributionRequirementsAudit:
    def name(self):
        return "Distribution Requirements Audit"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in REQ)
        ratio = min(1.0, hits/max(1,len(s)))
        score = min(1.0, ratio)
        mm = data.get("metrics", {})
        mm["distribution_requirements_audit"] = score
        data["metrics"] = mm
        data["distribution"] = {"requirements":hits,"distribution_readiness_score":round(score,6)}
        return data
