from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class AccessibilityReadabilityAssessor:
    def name(self):
        return "Accessibility Readability Assessor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        avg = mean([len(tokens(x)) for x in s]) if s else 0.0
        caps = sum(1 for x in s if x.strip().isupper())
        penalty = min(1.0, caps/max(1,len(s)))
        score = max(0.0, 1.0 - min(1.0, abs(avg-16)/16.0)*0.7 - penalty*0.3)
        mm = data.get("metrics", {})
        mm["accessibility_readability_assessor"] = score
        data["metrics"] = mm
        data["accessibility"] = {"avg_tokens":round(avg,6),"all_caps":caps,"accessibility_score":round(score,6)}
        return data
