from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TRIG = {"violence","blood","drug","sex","explicit","mature","curse"}
@register
class ContentRatingCompliance:
    def name(self):
        return "Content Rating Compliance"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        flags = 0
        for x in s:
            flags += sum(1 for w in tokens(x) if w in TRIG)
        ratio = min(1.0, flags/max(1,len(s)))
        score = max(0.0, 1.0 - ratio)
        mm = data.get("metrics", {})
        mm["content_rating_compliance"] = score
        data["metrics"] = mm
        data["rating"] = {"flags":flags,"compliance_score":round(score,6)}
        return data
