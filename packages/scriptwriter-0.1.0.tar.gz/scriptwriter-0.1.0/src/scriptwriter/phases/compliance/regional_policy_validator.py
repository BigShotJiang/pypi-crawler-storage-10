from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REG = {"uk","eu","us","jp","cn","br"}
POL = {"rating","ban","quota","dub","subtitle","local"}
@register
class RegionalPolicyValidator:
    def name(self):
        return "Regional Policy Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            t = tokens(x)
            hits += sum(1 for w in t if w in REG) + sum(1 for w in t if w in POL)
        ratio = min(1.0, hits/max(1,len(s)*2))
        score = min(1.0, ratio)
        mm = data.get("metrics", {})
        mm["regional_policy_validator"] = score
        data["metrics"] = mm
        data["regional"] = {"markers":hits,"regional_policy_score":round(score,6)}
        return data
