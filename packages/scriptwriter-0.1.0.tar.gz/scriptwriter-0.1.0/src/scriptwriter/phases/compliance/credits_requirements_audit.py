from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REQ={"credits","music","license","cast","crew","year","studio"}
@register
class CreditsRequirementsAudit:
    def name(self): return "Credits Requirements Audit"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in REQ) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["credits_requirements_audit"]=ratio
        data["credits_requirements"]={"mentions":hits,"credits_ready_score":round(ratio,6)}
        return data
