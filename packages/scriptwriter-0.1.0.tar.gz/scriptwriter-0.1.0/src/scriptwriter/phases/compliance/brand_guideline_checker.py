from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
BRAND = {"logo","brand","slogan","trademark","guideline"}
@register
class BrandGuidelineChecker:
    def name(self):
        return "Brand Guideline Checker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in BRAND)
        ratio = min(1.0, hits/max(1,len(s)))
        score = max(0.0, 1.0 - ratio*0.5)
        mm = data.get("metrics", {})
        mm["brand_guideline_checker"] = score
        data["metrics"] = mm
        data["brand"] = {"mentions":hits,"brand_compliance_score":round(score,6)}
        return data
