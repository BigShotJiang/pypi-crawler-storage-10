from typing import Dict, List
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

INTENSIFIERS = {"now","immediately","must","never","always","urgent","critical","danger","attack","power","kill","win","lose","all","none","every","nothing","everything","absolutely","totally","so","very","extremely"}

def _sent_intensity(s: str) -> float:
    t = tokens(s)
    if not t:
        return 0.0
    n = len(t)
    ex = 1.0 if s.strip().endswith("!") else 0.0
    q = 0.5 if s.strip().endswith("?") else 0.0
    caps = sum(1 for w in t if len(w)>=3 and w.isalpha() and w.upper()==w)/max(1,sum(1 for w in t if len(w)>=3))
    inten = sum(1 for w in t if w in INTENSIFIERS)/n
    length = min(1.0, n/30.0)
    return 0.4*length + 0.25*inten + 0.2*ex + 0.1*caps + 0.05*q

@register
class SemanticEscalationEngine:
    def name(self):
        return "Semantic Escalation Engine"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        vals = [_sent_intensity(x) for x in s]
        if not vals:
            vals = [0.0]
        inc = 0
        for i in range(1,len(vals)):
            if vals[i] > vals[i-1]:
                inc += 1
        trend = inc/max(1, len(vals)-1)
        vol = 0.0
        if len(vals)>1:
            diffs = [abs(vals[i]-vals[i-1]) for i in range(1,len(vals))]
            vol = sum(diffs)/len(diffs)
        score = max(0.0, min(1.0, 0.7*trend + 0.3*min(1.0, 1.0 - vol)))
        data["escalation"] = {
            "sentences": len(s),
            "mean_intensity": round(mean(vals),6),
            "upward_trend_ratio": round(trend,6),
            "volatility": round(vol,6),
            "escalation_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["semantic_escalation_engine"] = score
        data["metrics"] = mm
        return data
