from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class FocusWindowOptimizer:
    def name(self): return "Focus Window Optimizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        windows=min(1.0,len(s)/10.0)
        score=max(0.0,windows)
        data.setdefault("metrics",{})["focus_window_optimizer"]=score
        data["focus_window"]={"windows_ratio":round(windows,6),"focus_window_score":round(score,6)}
        return data
