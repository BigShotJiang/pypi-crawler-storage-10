from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
FILL = {"that","very","really","just","quite","actually","basically","literally"}
@register
class CompressionWithoutLossEngine:
    def name(self):
        return "Compression Without Loss Engine"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        total=0
        fillers=0
        for x in s:
            t=tokens(x)
            total+=len(t)
            fillers+=sum(1 for w in t if w in FILL)
        ratio = fillers/max(1,total)
        score = max(0.0, 1.0 - min(1.0, ratio*5.0))
        mm = data.get("metrics", {})
        mm["compression_without_loss_engine"] = score
        data["metrics"] = mm
        data["compression"] = {"tokens":total,"fillers":fillers,"compression_score":round(score,6)}
        return data
