from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class RewriteImpactEstimator:
    def name(self): return "Rewrite Impact Estimator"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        k=len(m)
        score=min(1.0,k/300.0)
        data.setdefault("metrics",{})["rewrite_impact_estimator"]=score
        data["rewrite_impact"]={"metric_count":k,"rewrite_impact_score":round(score,6)}
        return data
