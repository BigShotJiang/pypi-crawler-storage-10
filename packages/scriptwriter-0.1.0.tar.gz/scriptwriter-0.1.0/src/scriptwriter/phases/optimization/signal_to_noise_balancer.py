from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
KEY = {"goal","conflict","stakes","theme","character","reveal","motif","setpiece"}
@register
class SignalToNoiseBalancer:
    def name(self):
        return "Signal To Noise Balancer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        sig=0
        total=0
        for x in s:
            t=tokens(x)
            total+=len(t)
            sig+=sum(1 for w in t if w in KEY)
        ratio = sig/max(1,total)
        score = min(1.0, ratio*10.0)
        mm = data.get("metrics", {})
        mm["signal_to_noise_balancer"] = score
        data["metrics"] = mm
        data["signal"] = {"signal_ratio":round(ratio,6),"signal_score":round(score,6)}
        return data
