from typing import Dict
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class CoherenceNormalizer:
    def name(self): return "Coherence Normalizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        lens=[len(tokens(x)) for x in s] or [0]
        m=mean(lens); sd=pstdev(lens) if len(lens)>1 else 0.0
        score=max(0.0,1.0-min(1.0,sd/(m+1e-9)))
        data.setdefault("metrics",{})["coherence_normalizer"]=score
        data["coherence"]={"mean_tokens":round(m,6),"std_tokens":round(sd,6),"coherence_score":round(score,6)}
        return data
