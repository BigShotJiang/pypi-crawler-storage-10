from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SemanticDiffCompactor:
    def name(self):
        return "Semantic Diff Compactor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        diffs = sum(1 for i in range(1,len(s)) if s[i].split()[:3]==s[i-1].split()[:3])
        ratio = min(1.0, diffs/max(1,len(s)-1))
        score = max(0.0, 1.0 - ratio)
        mm = data.get("metrics", {})
        mm["semantic_diff_compactor"] = score
        data["metrics"] = mm
        data["semantic_diff"] = {"redundant_adjacent":diffs,"compaction_score":round(score,6)}
        return data
