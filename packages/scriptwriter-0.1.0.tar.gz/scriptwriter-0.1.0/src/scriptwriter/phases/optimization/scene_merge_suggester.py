from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneMergeSuggester:
    def name(self): return "Scene Merge Suggester"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        flat=sum(1 for x in s if x.strip().endswith("."))
        ratio=min(1.0,flat/max(1,len(s)))
        score=min(1.0,ratio)
        data.setdefault("metrics",{})["scene_merge_suggester"]=score
        data["scene_merge"]={"flat_scenes":flat,"scene_merge_score":round(score,6)}
        return data
