from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RedundancyClusterMerger:
    def name(self): return "Redundancy Cluster Merger"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        clusters=sum(1 for i in range(1,len(s)) if s[i][:10]==s[i-1][:10])
        score=max(0.0,1.0-min(1.0,clusters/max(1,len(s)-1)))
        data.setdefault("metrics", {})["redundancy_cluster_merger"]=score
        data["redundancy"]={"clusters":clusters,"redundancy_merge_score":round(score,6)}
        return data
