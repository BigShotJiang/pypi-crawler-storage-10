from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class OutlineGapFiller:
    def name(self): return "Outline Gap Filler"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        gaps = sum(1 for i in range(1,len(s)) if s[i-1].strip()[-1:]=="?" and s[i].strip()[-1:]!="!")
        score = max(0.0, 1.0 - min(1.0, gaps/max(1,len(s)-1)))
        data.setdefault("metrics", {})["outline_gap_filler"] = score
        data["outline_gap"] = {"gaps": gaps, "outline_gap_fill_score": round(score,6)}
        return data
