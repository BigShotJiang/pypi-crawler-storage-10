from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class DialogueTrimRecommender:
    def name(self): return "Dialogue Trim Recommender"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        long=sum(1 for x in s if len(x.split())>22)
        ratio=min(1.0,long/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["dialogue_trim_recommender"]=score
        data["dialogue_trim"]={"overlong_lines":long,"dialogue_trim_score":round(score,6)}
        return data
