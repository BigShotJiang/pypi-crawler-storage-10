from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class OutlineCoverageIndexer:
    def name(self): return "Outline Coverage Indexer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        cover=min(1.0,len(s)/12.0)
        data.setdefault("metrics",{})["outline_coverage_indexer"]=cover
        data["outline_coverage"]={"coverage_ratio":round(cover,6)}
        return data
