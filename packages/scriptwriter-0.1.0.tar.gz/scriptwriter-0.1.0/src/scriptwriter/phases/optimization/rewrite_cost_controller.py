from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class RewriteCostController:
    def name(self):
        return "Rewrite Cost Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        long = sum(1 for x in s if len(tokens(x))>=24)
        cost = min(1.0, long/max(1,len(s)))
        score = max(0.0, 1.0 - cost)
        mm = data.get("metrics", {})
        mm["rewrite_cost_controller"] = score
        data["metrics"] = mm
        data["rewrite_cost"] = {"long_sentences":long,"rewrite_cost_score":round(score,6)}
        return data
