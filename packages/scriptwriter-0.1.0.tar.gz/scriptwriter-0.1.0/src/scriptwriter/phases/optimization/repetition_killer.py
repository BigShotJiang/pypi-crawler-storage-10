from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class RepetitionKiller:
    def name(self): return "Repetition Killer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        words=[]
        for x in s: words.extend(tokens(x))
        c=Counter(words)
        over=sum(1 for k,v in c.items() if v>=4)
        score=max(0.0,1.0-min(1.0,over/10.0))
        data.setdefault("metrics",{})["repetition_killer"]=score
        data["repetition"]={"overused_types":over,"repetition_kill_score":round(score,6)}
        return data
