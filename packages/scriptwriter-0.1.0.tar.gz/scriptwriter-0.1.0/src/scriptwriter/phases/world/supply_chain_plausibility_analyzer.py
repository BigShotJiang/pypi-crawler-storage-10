from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"grain","water","fuel","ammo","medicine","food","logistics","supply","shipment","convoy"}
@register
class SupplyChainPlausibilityAnalyzer:
    def name(self): return "Supply Chain Plausibility Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["supply_chain_plausibility_analyzer"]=score
        data["supply_chain"]={"mentions":hits,"supply_chain_score":round(score,6)}
        return data
