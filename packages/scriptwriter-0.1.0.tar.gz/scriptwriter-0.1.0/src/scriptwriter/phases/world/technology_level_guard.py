from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LOW={"torch","cart","horse","spear","castle"}
HI={"drone","laser","chip","quantum","nanite"}
@register
class TechnologyLevelGuard:
    def name(self): return "Technology Level Guard"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        low=sum(sum(1 for w in tokens(x) if w in LOW) for x in s)
        hi=sum(sum(1 for w in tokens(x) if w in HI) for x in s)
        clash=1 if low>0 and hi>0 else 0
        score=max(0.0,1.0-clash)
        data.setdefault("metrics",{})["technology_level_guard"]=score
        data["tech_level"]={"low":low,"high":hi,"tech_level_score":round(score,6)}
        return data
