from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
ECON = {"coin","tax","price","market","trade","debt","wage","cost","profit","supply","demand"}
@register
class EconomyRulesChecker:
    def name(self):
        return "Economy Rules Checker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        e = 0
        for x in s:
            e += sum(1 for w in tokens(x) if w in ECON)
        score = min(1.0, e/max(1,len(s)))
        data["economy"] = {"mentions":e,"economy_plausibility_score":round(score,6)}
        m = data.get("metrics", {})
        m["economy_rules_checker"] = score
        data["metrics"] = m
        return data
