from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"water","food","fuel","ammo","money","time","medicine"}
@register
class ResourceConstraintChecker:
    def name(self): return "Resource Constraint Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["resource_constraint_checker"]=score
        data["resources"]={"mentions":hits,"resource_constraint_score":round(score,6)}
        return data
