from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
NET={"bridge","road","rail","port","dock","harbor","gate","tunnel","route","station"}
@register
class TransportNetworkCoherenceChecker:
    def name(self): return "Transport Network Coherence Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in NET) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["transport_network_coherence_checker"]=score
        data["transport"]={"mentions":hits,"transport_coherence_score":round(score,6)}
        return data
