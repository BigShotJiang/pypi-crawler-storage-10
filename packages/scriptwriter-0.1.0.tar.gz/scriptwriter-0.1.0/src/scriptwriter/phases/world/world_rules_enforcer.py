from typing import Dict, List, Tuple
from collections import defaultdict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

MODALS_POS = {"must","always","only"}
MODALS_NEG = {"mustn't","mustn","cannot","can't","never","not"}
JOINERS = {"to","be","stay","remain","keep","have","has","is","are","was","were","do","does"}

def _normalize_clause(toks: List[str]) -> Tuple[str,...]:
    filtered = [w for w in toks if w not in JOINERS]
    return tuple(filtered[:6])

def _extract_rules(s: str):
    toks = tokens(s)
    flags_pos = any(w in MODALS_POS for w in toks)
    flags_neg = any(w in MODALS_NEG for w in toks)
    if not (flags_pos or flags_neg):
        return []
    idx = 0
    for i,w in enumerate(toks):
        if w in MODALS_POS or w in MODALS_NEG:
            idx = i+1
            break
    clause = _normalize_clause(toks[idx:])
    return [("pos" if flags_pos and not flags_neg else "neg" if flags_neg and not flags_pos else "amb", clause)]

@register
class WorldRulesEnforcer:
    def name(self):
        return "World Rules Enforcer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        pos = defaultdict(int)
        neg = defaultdict(int)
        rules = 0
        for sen in s:
            for kind, clause in _extract_rules(sen):
                rules += 1
                if kind == "pos":
                    pos[clause] += 1
                elif kind == "neg":
                    neg[clause] += 1
                else:
                    pos[clause] += 1
                    neg[clause] += 1
        violations = 0
        for cl in set(list(pos.keys())+list(neg.keys())):
            if pos[cl] > 0 and neg[cl] > 0:
                violations += 1
        score = 1.0
        if rules > 0:
            score = max(0.0, 1.0 - min(1.0, violations / rules))
        data["world"] = {
            "rule_sentences": rules,
            "conflicts": violations,
            "world_rules_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["world_rules_enforcer"] = score
        data["metrics"] = mm
        return data
