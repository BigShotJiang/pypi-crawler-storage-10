from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LOG={"miles","hours","route","fuel","supply","cargo","distance","bridge","road","water","food"}
@register
class LogisticsPlausibilityChecker:
    def name(self): return "Logistics Plausibility Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LOG) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["logistics_plausibility_checker"]=score
        data["logistics"]={"mentions":hits,"logistics_score":round(score,6)}
        return data
