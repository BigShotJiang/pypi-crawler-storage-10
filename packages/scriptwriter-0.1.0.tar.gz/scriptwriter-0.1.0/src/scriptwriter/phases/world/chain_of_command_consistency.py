from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
RANK={"captain","sergeant","general","king","queen","chief","warden","officer"}
@register
class ChainOfCommandConsistency:
    def name(self): return "Chain Of Command Consistency"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = sum(sum(1 for w in tokens(x) if w in RANK) for x in s)
        score = min(1.0, hits/max(1,len(s)))
        data.setdefault("metrics", {})["chain_of_command_consistency"] = score
        data["command_chain"] = {"rank_mentions": hits, "command_consistency_score": round(score,6)}
        return data
