from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TECH = {"radio","laser","drone","engine","steam","circuit","chip","ai","spelltech","nanite"}
@register
class TechnologyConsistencyScanner:
    def name(self):
        return "Technology Consistency Scanner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        t = 0
        for x in s:
            t += sum(1 for w in tokens(x) if w in TECH)
        score = min(1.0, t/max(1,len(s)))
        data["tech"] = {"mentions":t,"tech_consistency_score":round(score,6)}
        m = data.get("metrics", {})
        m["technology_consistency_scanner"] = score
        data["metrics"] = m
        return data
