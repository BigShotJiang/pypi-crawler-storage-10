from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
J={"city","kingdom","empire","federal","state","crown","court","tribunal","agency"}
@register
class JurisdictionConflictMonitor:
    def name(self): return "Jurisdiction Conflict Monitor"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in J) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["jurisdiction_conflict_monitor"]=score
        data["jurisdiction_conflict"]={"mentions":hits,"jurisdiction_conflict_score":round(score,6)}
        return data
