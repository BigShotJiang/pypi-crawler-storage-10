from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
MAG = {"mana","spell","ritual","oath","sigil","circle","channel","focus","limit","cost"}
@register
class MagicSystemStabilityTester:
    def name(self):
        return "Magic System Stability Tester"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        m = 0
        for x in s:
            m += sum(1 for w in tokens(x) if w in MAG)
        score = min(1.0, m/max(1,len(s)))
        data["magic"] = {"markers":m,"magic_stability_score":round(score,6)}
        mm = data.get("metrics", {})
        mm["magic_system_stability_tester"] = score
        data["metrics"] = mm
        return data
