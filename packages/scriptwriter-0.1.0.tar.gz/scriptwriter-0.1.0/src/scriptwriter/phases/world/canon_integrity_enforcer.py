from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
RULE = {"rule","law","canon","cannot","must","never","always"}
@register
class CanonIntegrityEnforcer:
    def name(self):
        return "Canon Integrity Enforcer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in RULE)
        score = min(1.0, hits/max(1,len(s)*2))
        data["canon"] = {"markers":hits,"canon_integrity_score":round(score,6)}
        m = data.get("metrics", {})
        m["canon_integrity_enforcer"] = score
        data["metrics"] = m
        return data
