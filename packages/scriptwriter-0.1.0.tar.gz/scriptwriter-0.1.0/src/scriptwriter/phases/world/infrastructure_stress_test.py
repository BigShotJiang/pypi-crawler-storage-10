from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
STRESS={"bridge","rail","port","grid","dam","power","water","supply","hospital"}
@register
class InfrastructureStressTest:
    def name(self): return "Infrastructure Stress Test"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        mentions=sum(sum(1 for w in tokens(x) if w in STRESS) for x in s)
        score=min(1.0,mentions/max(1,len(s)))
        data.setdefault("metrics",{})["infrastructure_stress_test"]=score
        data["infrastructure"]={"mentions":mentions,"infrastructure_stress_score":round(score,6)}
        return data
