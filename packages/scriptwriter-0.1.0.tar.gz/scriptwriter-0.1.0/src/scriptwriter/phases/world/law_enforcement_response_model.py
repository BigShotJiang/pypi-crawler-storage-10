from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"guard","police","warden","patrol","militia","arrest","investigate","fine","search"}
@register
class LawEnforcementResponseModel:
    def name(self): return "Law Enforcement Response Model"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["law_enforcement_response_model"]=score
        data["law_enforcement"]={"mentions":hits,"law_response_score":round(score,6)}
        return data
