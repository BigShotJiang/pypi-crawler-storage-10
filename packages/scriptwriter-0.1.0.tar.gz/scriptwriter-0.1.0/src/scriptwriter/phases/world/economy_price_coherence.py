from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
PRICE={"coin","gold","silver","price","cost","wage","tax","market"}
@register
class EconomyPriceCoherence:
    def name(self): return "Economy Price Coherence"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = sum(sum(1 for w in tokens(x) if w in PRICE) for x in s)
        score = min(1.0, hits/max(1,len(s)))
        data.setdefault("metrics", {})["economy_price_coherence"] = score
        data["economy_price"] = {"mentions": hits, "economy_price_score": round(score,6)}
        return data
