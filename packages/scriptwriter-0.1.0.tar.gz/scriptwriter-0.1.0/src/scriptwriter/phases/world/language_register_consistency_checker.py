from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class LanguageRegisterConsistencyChecker:
    def name(self): return "Language Register Consistency Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        shouts=sum(1 for x in s if x.strip().isupper())
        ratio=min(1.0,shouts/max(1,len(s)))
        score=max(0.0,1.0-ratio)
        data.setdefault("metrics",{})["language_register_consistency_checker"]=score
        data["lang_register"]={"all_caps":shouts,"language_register_score":round(score,6)}
        return data
