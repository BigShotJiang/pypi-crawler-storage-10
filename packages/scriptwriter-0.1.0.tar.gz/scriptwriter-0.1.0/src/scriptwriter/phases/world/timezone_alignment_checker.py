from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"dawn","noon","sunset","midnight","morning","evening"}
@register
class TimezoneAlignmentChecker:
    def name(self): return "Timezone Alignment Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        t=sum(sum(1 for w in tokens(x) if w in LEX) for x in s)
        score=min(1.0,t/max(1,len(s)))
        data.setdefault("metrics",{})["timezone_alignment_checker"]=score
        data["timezone_alignment"]={"time_markers":t,"timezone_alignment_score":round(score,6)}
        return data
