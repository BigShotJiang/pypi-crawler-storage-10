from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
CAL={"monday","tuesday","wednesday","thursday","friday","saturday","sunday","month","year","week","winter","summer"}
@register
class CalendarCoherenceChecker:
    def name(self): return "Calendar Coherence Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in CAL) for x in s)
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["calendar_coherence_checker"]=score
        data["calendar"]={"mentions":hits,"calendar_coherence_score":round(score,6)}
        return data
