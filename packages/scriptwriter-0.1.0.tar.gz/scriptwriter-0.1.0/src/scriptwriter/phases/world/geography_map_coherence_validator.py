from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
GEO = {"north","south","east","west","river","mountain","valley","harbor","desert","forest","bridge","island"}
@register
class GeographyMapCoherenceValidator:
    def name(self): return "Geography Map Coherence Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        mentions = sum(sum(1 for w in tokens(x) if w in GEO) for x in s)
        score = min(1.0, mentions/max(1,len(s)))
        data.setdefault("metrics", {})["geography_map_coherence_validator"] = score
        data["geography"] = {"mentions":mentions,"map_coherence_score":round(score,6)}
        return data
