from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
GEO = {"kingdom","republic","empire","treaty","border","sanction","alliance","rebellion","coup"}
@register
class GeopoliticsPlausibilityModel:
    def name(self):
        return "Geopolitics Plausibility Model"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        g = 0
        for x in s:
            g += sum(1 for w in tokens(x) if w in GEO)
        score = min(1.0, g/max(1,len(s)))
        data["geopolitics"] = {"mentions":g,"geopolitics_plausibility_score":round(score,6)}
        m = data.get("metrics", {})
        m["geopolitics_plausibility_model"] = score
        data["metrics"] = m
        return data
