from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LINK = {"and","with","beside","against","versus","along"}
@register
class RelationshipVectorMapper:
    def name(self):
        return "Relationship Vector Mapper"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        pairs = 0
        for x in s:
            t = tokens(x)
            for i,w in enumerate(t):
                if w in LINK and i>0 and i+1<len(t):
                    pairs += 1
        score = min(1.0, pairs/max(1,len(s)))
        data["relationships"] = {"links":pairs,"relationship_density":round(score,6)}
        m = data.get("metrics", {})
        m["relationship_vector_mapper"] = score
        data["metrics"] = m
        return data
