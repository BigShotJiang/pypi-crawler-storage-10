from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS = {"kind","honest","brave","calm","patient","loyal"}
NEG = {"cruel","liar","coward","angry","impulsive","betrayer"}
@register
class TraitCollisionResolver:
    def name(self):
        return "Trait Collision Resolver"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        pos = 0
        neg = 0
        for x in s:
            t = tokens(x)
            pos += sum(1 for w in t if w in POS)
            neg += sum(1 for w in t if w in NEG)
        collisions = min(pos,neg)
        score = max(0.0, 1.0 - min(1.0, collisions/3.0))
        data["traits"] = {"pos":pos,"neg":neg,"collisions":collisions,"trait_resolution_score":round(score,6)}
        m = data.get("metrics", {})
        m["trait_collision_resolver"] = score
        data["metrics"] = m
        return data
