from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
NEG = {"fail","lost","hurt","weak","afraid","broken","alone","poor"}
POS = {"win","found","heal","strong","brave","whole","together","rich"}
@register
class ArcIntegrityVerifier:
    def name(self):
        return "Arc Integrity Verifier"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        vals = []
        for x in s:
            t = tokens(x)
            a = sum(1 for w in t if w in POS)
            b = sum(1 for w in t if w in NEG)
            vals.append(a-b)
        if not vals:
            vals=[0]
        inc = sum(1 for i in range(1,len(vals)) if vals[i] >= vals[i-1])
        trend = inc/max(1,len(vals)-1)
        span = 0.0
        if vals:
            lo,hi=min(vals),max(vals)
            if hi>0: span = min(1.0, (hi-lo)/(abs(hi)+abs(lo)+1e-9))
        score = round(0.6*trend + 0.4*span,6)
        data["arc"] = {"points":len(vals),"upward_trend":round(trend,6),"span":round(span,6),"arc_score":score}
        m = data.get("metrics", {})
        m["arc_integrity_verifier"] = score
        data["metrics"] = m
        return data
