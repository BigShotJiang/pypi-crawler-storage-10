from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
NAMES = {"aria","dax","riven","mara","nova","asher","lin","kade","sable","ivy"}
PRON_P1 = {"i","me","my","mine","we","us","our","ours"}
PRON_P3 = {"he","she","they","him","her","them","his","hers","their","theirs"}
@register
class CharacterConsistencyGuard:
    def name(self):
        return "Character Consistency Guard"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        t = []
        for x in s:
            t.extend(tokens(x))
        name_hits = sum(1 for w in t if w in NAMES)
        p1 = sum(1 for w in t if w in PRON_P1)
        p3 = sum(1 for w in t if w in PRON_P3)
        total_ref = name_hits + p1 + p3
        if total_ref == 0:
            score = 1.0
        else:
            dom = max(p1,p3,name_hits)
            score = min(1.0, dom/max(1,total_ref))
        data["character_consistency"] = {"name_mentions":name_hits,"p1_mentions":p1,"p3_mentions":p3,"consistency_score":round(score,6)}
        m = data.get("metrics", {})
        m["character_consistency_guard"] = score
        data["metrics"] = m
        return data
