from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
CUES = {"because","since","after","before","origin","born","child","mentor","oath","vow","past","history","promise"}
@register
class BackstoryAlignmentEngine:
    def name(self):
        return "Backstory Alignment Engine"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        c = 0
        total = 0
        for x in s:
            t = tokens(x)
            total += len(t)
            c += sum(1 for w in t if w in CUES)
        density = c/max(1,total)
        score = min(1.0, density*8.0)
        data["backstory"] = {"cue_hits":c,"token_count":total,"alignment_score":round(score,6)}
        m = data.get("metrics", {})
        m["backstory_alignment_engine"] = score
        data["metrics"] = m
        return data
