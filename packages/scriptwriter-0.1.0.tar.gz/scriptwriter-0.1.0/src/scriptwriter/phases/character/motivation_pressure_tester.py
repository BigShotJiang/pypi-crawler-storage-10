from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
WANT = {"want","need","seek","must","goal","wish","dream","plan","mission","quest"}
PRESSURE = {"or","else","unless","if","until","deadline","clock","risk","lose","loss","cost"}
@register
class MotivationPressureTester:
    def name(self):
        return "Motivation Pressure Tester"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        want = 0
        press = 0
        for x in s:
            t = tokens(x)
            want += sum(1 for w in t if w in WANT)
            press += sum(1 for w in t if w in PRESSURE)
        score = min(1.0, 0.6*min(1.0,want/3.0) + 0.4*min(1.0,press/3.0))
        data["motivation"] = {"want_hits":want,"pressure_hits":press,"motivation_pressure_score":round(score,6)}
        m = data.get("metrics", {})
        m["motivation_pressure_tester"] = score
        data["metrics"] = m
        return data
