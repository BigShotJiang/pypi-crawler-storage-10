from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
ANT = {"enemy","villain","hunter","warden","assassin","rival","tyrant"}
FORCE = {"attacks","blocks","traps","chases","ambush","threatens","presses","corner"}
@register
class AntagonistPressureInjector:
    def name(self):
        return "Antagonist Pressure Injector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            t = tokens(x)
            hits += sum(1 for w in t if w in ANT) + sum(1 for w in t if w in FORCE)
        score = min(1.0, hits/max(1,len(s)*2))
        data["antagonist"] = {"hostile_events":hits,"pressure_score":round(score,6)}
        m = data.get("metrics", {})
        m["antagonist_pressure_injector"] = score
        data["metrics"] = m
        return data
