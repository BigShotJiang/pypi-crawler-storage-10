from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS={"freedom","truth","justice","love","peace"}
NEG={"tyranny","lie","corruption","hate","war"}
@register
class ThemeConflictMatrix:
    def name(self): return "Theme Conflict Matrix"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        a=sum(sum(1 for w in tokens(x) if w in POS) for x in s)
        b=sum(sum(1 for w in tokens(x) if w in NEG) for x in s)
        total=max(1,a+b)
        score=min(1.0,abs(a-b)/total)
        data.setdefault("metrics",{})["theme_conflict_matrix"]=score
        data["theme_conflict"]={"pos":a,"neg":b,"conflict_score":round(score,6)}
        return data
