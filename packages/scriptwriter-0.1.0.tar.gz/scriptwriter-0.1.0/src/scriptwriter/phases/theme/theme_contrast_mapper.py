from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
A={"freedom","love","truth","justice","hope"}
B={"prison","fear","lie","tyranny","despair"}
@register
class ThemeContrastMapper:
    def name(self): return "Theme Contrast Mapper"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        a=sum(sum(1 for w in tokens(x) if w in A) for x in s)
        b=sum(sum(1 for w in tokens(x) if w in B) for x in s)
        denom=max(1,a+b)
        score=min(1.0,abs(a-b)/denom)
        data.setdefault("metrics",{})["theme_contrast_mapper"]=score
        data["theme_contrast"]={"a":a,"b":b,"contrast_score":round(score,6)}
        return data
