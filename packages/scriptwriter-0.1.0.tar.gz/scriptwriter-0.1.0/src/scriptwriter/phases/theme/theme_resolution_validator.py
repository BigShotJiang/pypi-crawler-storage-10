from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
RES={"restore","heal","unite","peace","balance","truth","justice","love"}
@register
class ThemeResolutionValidator:
    def name(self): return "Theme Resolution Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tail_tokens=tokens(" ".join(s[-3:])) if s else []
        hits=sum(1 for w in tail_tokens if w in RES)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["theme_resolution_validator"]=ratio
        data["theme_resolution"]={"tail_hits":hits,"theme_resolution_score":round(ratio,6)}
        return data
