from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS={"peace","truth","justice","hope","love"}
NEG={"war","lie","corruption","fear","hate"}
@register
class ContrastResolutionIndexer:
    def name(self): return "Contrast Resolution Indexer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        a = sum(sum(1 for w in tokens(x) if w in POS) for x in s[-3:]) if s else 0
        b = sum(sum(1 for w in tokens(x) if w in NEG) for x in s[-3:]) if s else 0
        total = max(1,a+b)
        score = min(1.0, a/total)
        data.setdefault("metrics", {})["contrast_resolution_indexer"] = score
        data["contrast_resolution"] = {"pos_tail": a, "neg_tail": b, "resolution_score": round(score,6)}
        return data
