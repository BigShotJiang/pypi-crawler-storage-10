from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
THEMES={"power","freedom","family","justice","truth","war","peace"}
@register
class CoreThemeLock:
    def name(self): return "Core Theme Lock"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tail=tokens(" ".join(s[-2:])) if s else []
        c=Counter(w for w in tail if w in THEMES)
        score=min(1.0,sum(c.values())/max(1,len(s)))
        data.setdefault("metrics",{})["core_theme_lock"]=score
        data["core_theme"]={"tail_theme_hits":sum(c.values()),"core_theme_score":round(score,6)}
        return data
