from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
def bag(sents):
    out=[]
    for s in sents: out.extend(tokens(s))
    return out
@register
class ThemeDriftIndexer:
    def name(self): return "Theme Drift Indexer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        if len(s)<2:
            data.setdefault("metrics", {})["theme_drift_indexer"] = 1.0
            data["theme_drift"] = {"drift":0.0,"theme_drift_score":1.0}
            return data
        mid=len(s)//2
        a=Counter(bag(s[:mid]))
        b=Counter(bag(s[mid:]))
        inter=sum((a&b).values())
        uni=sum((a|b).values()) or 1
        j=inter/uni
        score=round(j,6)
        data.setdefault("metrics", {})["theme_drift_indexer"] = score
        data["theme_drift"]={"jaccard":score,"theme_drift_score":score}
        return data
