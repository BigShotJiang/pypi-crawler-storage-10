from typing import Dict, List, Tuple
from collections import Counter, defaultdict
from math import log2
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _window_tokens(sents: List[str]) -> List[str]:
    out = []
    for s in sents:
        out.extend(tokens(s))
    return out

def _cooc(tokens_list: List[str], window: int = 5) -> Dict[Tuple[str,str], int]:
    n = len(tokens_list)
    c = Counter()
    for i in range(n):
        w = tokens_list[i]
        for j in range(i+1, min(n, i+window)):
            u = tokens_list[j]
            if w == u:
                continue
            a,b = sorted((w,u))
            c[(a,b)] += 1
    return c

def _pmi(cxy: Dict[Tuple[str,str], int], tok_counts: Counter, total: int) -> float:
    if not cxy:
        return 0.0
    import statistics
    vals = []
    for (a,b), nxy in cxy.items():
        pa = tok_counts[a] / total
        pb = tok_counts[b] / total
        pxy = nxy / total
        if pa>0 and pb>0 and pxy>0:
            vals.append(log2(pxy/(pa*pb)))
    if not vals:
        return 0.0
    return max(0.0, sum(vals)/len(vals))

@register
class ThemeCoherenceLattice:
    def name(self):
        return "Theme Coherence Lattice"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = _window_tokens(s)
        total = max(1, len(toks))
        tok_counts = Counter(toks)
        cxy = _cooc(toks, window=6)
        coherence = _pmi(cxy, tok_counts, total)
        unique = len(tok_counts)
        concentration = max(0.0, min(1.0, max(tok_counts.values())/total))
        drift_penalty = 1.0 - min(1.0, unique/(total+1e-9))
        score = round(max(0.0, min(1.0, 0.6*min(1.0, coherence/4.0) + 0.2*concentration + 0.2*(1.0-drift_penalty))), 6)
        data["theme"] = {
            "unique_tokens": unique,
            "coherence_pmi": round(coherence,6),
            "concentration": round(concentration,6),
            "drift_penalty": round(drift_penalty,6),
            "theme_score": score
        }
        mm = data.get("metrics", {})
        mm["theme_coherence_lattice"] = score
        data["metrics"] = mm
        return data
