from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class MotifNetworkDensity:
    def name(self): return "Motif Network Density"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        edges=0
        for x in s:
            t=tokens(x)
            edges+=max(0,len(t)-1)
        score=min(1.0,edges/max(1,len(s)*12))
        data.setdefault("metrics",{})["motif_network_density"]=score
        data["motif_network"]={"edges":edges,"motif_network_score":round(score,6)}
        return data
