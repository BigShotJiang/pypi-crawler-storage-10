from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class LeitmotifConsistencyChecker:
    def name(self): return "Leitmotif Consistency Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        c=Counter()
        for x in s:
            t=tokens(x)
            for i in range(len(t)-1):
                c[(t[i],t[i+1])]+=1
        rep=sum(1 for k,v in c.items() if v>=3)
        score=min(1.0,rep/max(1,len(s)))
        data.setdefault("metrics",{})["leitmotif_consistency_checker"]=score
        data["leitmotif"]={"repeated_bigrams_ge3":rep,"leitmotif_score":round(score,6)}
        return data
