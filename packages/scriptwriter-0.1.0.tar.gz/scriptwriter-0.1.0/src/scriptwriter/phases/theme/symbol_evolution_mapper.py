from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SYM={"ring","mask","crown","key","blade","coin","mirror"}
@register
class SymbolEvolutionMapper:
    def name(self): return "Symbol Evolution Mapper"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        idx=[]
        for i,x in enumerate(s):
            t=set(tokens(x))
            if t&SYM: idx.append(i)
        spread=0.0
        if idx:
            spread=(max(idx)-min(idx))/max(1,len(s)-1)
        score=spread
        data.setdefault("metrics",{})["symbol_evolution_mapper"]=score
        data["symbol_evolution"]={"positions":len(idx),"spread":round(spread,6),"symbol_evolution_score":round(score,6)}
        return data
