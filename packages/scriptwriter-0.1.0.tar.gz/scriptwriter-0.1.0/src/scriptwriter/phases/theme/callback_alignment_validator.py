from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class CallbackAlignmentValidator:
    def name(self): return "Callback Alignment Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        if len(s)<3:
            data.setdefault("metrics",{})["callback_alignment_validator"]=1.0
            data["callback_alignment"]={"alignment":1.0}
            return data
        mid=len(s)//2
        a=set(tokens(s[0])); b=set(tokens(s[mid])); c=set(tokens(s[-1]))
        al=len(a&c)/max(1,len(a|c))
        data.setdefault("metrics",{})["callback_alignment_validator"]=al
        data["callback_alignment"]={"alignment":round(al,6)}
        return data
