from typing import Dict, List
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

THEME_LEX = {
    "power":{"power","control","rule","dominate","authority","strength","force"},
    "freedom":{"freedom","liberty","escape","choice","free","unbound"},
    "family":{"family","father","mother","son","daughter","sister","brother","home"},
    "justice":{"justice","law","fair","trial","judge","jury","crime","punish"},
    "time":{"time","past","future","memory","destiny","fate","moment","era"}
}

def _flatten(sents: List[str]) -> List[str]:
    out = []
    for s in sents:
        out.extend(tokens(s))
    return out

def _theme_counts(toks: List[str]) -> Dict[str,int]:
    c = {}
    st = set(toks)
    for k,lex in THEME_LEX.items():
        c[k] = sum(1 for w in toks if w in lex)
    return c

def _dominant(counts: Dict[str,int]) -> str:
    if not counts: return "none"
    k = max(counts.keys(), key=lambda x: counts[x])
    return k if counts[k] > 0 else "none"

@register
class ThemeSignalAmplifier:
    def name(self):
        return "Theme Signal Amplifier"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = _flatten(s)
        counts = _theme_counts(toks)
        total = sum(counts.values())
        unique = sum(1 for v in counts.values() if v>0)
        concentration = max(0.0, min(1.0, max(counts.values())/max(1,total))) if total>0 else 0.0
        breadth = max(0.0, min(1.0, unique/len(THEME_LEX)))
        import math
        balance = 1.0 - abs(concentration - 0.6)
        score = max(0.0, min(1.0, 0.5*concentration + 0.3*breadth + 0.2*balance))
        data["theme_signal"] = {
            "dominant": _dominant(counts),
            "themes_active": unique,
            "concentration": round(concentration,6),
            "breadth": round(breadth,6),
            "theme_signal_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["theme_signal_amplifier"] = score
        data["metrics"] = mm
        return data
