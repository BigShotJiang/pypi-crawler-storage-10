from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
HERO={"hero","leader","champion"}
MENTOR={"mentor","guide","teacher"}
SHADOW={"villain","tyrant","monster"}
@register
class ArchetypeBalanceMeter:
    def name(self): return "Archetype Balance Meter"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        h=sum(sum(1 for w in tokens(x) if w in HERO) for x in s)
        m=sum(sum(1 for w in tokens(x) if w in MENTOR) for x in s)
        sh=sum(sum(1 for w in tokens(x) if w in SHADOW) for x in s)
        total=max(1,h+m+sh)
        bal=1.0-abs((h/total)-1/3)-abs((m/total)-1/3)-abs((sh/total)-1/3)
        score=max(0.0,min(1.0,bal))
        data.setdefault("metrics",{})["archetype_balance_meter"]=score
        data["archetype_balance"]={"hero":h,"mentor":m,"shadow":sh,"archetype_balance_score":round(score,6)}
        return data
