from typing import Dict, List, Tuple
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _ngrams(toks: List[str], n: int) -> List[Tuple[str,...]]:
    return [tuple(toks[i:i+n]) for i in range(len(toks)-n+1)] if n>0 else []

def _flatten(sents: List[str]) -> List[str]:
    out = []
    for s in sents:
        out.extend(tokens(s))
    return out

def _score(top_counts: List[int], total_tokens: int) -> float:
    if total_tokens <= 0 or not top_counts:
        return 0.0
    top_sum = sum(top_counts)
    r = min(1.0, top_sum / max(1, total_tokens))
    return r

@register
class MotifTracker:
    def name(self):
        return "Motif Tracker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = _flatten(s)
        u = Counter(toks)
        b = Counter(_ngrams(toks, 2))
        t = Counter(_ngrams(toks, 3))
        top_uni = u.most_common(5)
        top_bi = b.most_common(5)
        top_tri = t.most_common(5)
        strength = _score([c for _,c in top_bi+top_tri], len(toks))
        motifs = {
            "uni": [" ".join([w]) for w,_ in top_uni],
            "bi": [" ".join(k) for k,_ in top_bi],
            "tri": [" ".join(k) for k,_ in top_tri]
        }
        data["motif"] = {
            "unique_tokens": len(u),
            "top_unigrams": motifs["uni"],
            "top_bigrams": motifs["bi"],
            "top_trigrams": motifs["tri"],
            "motif_strength": round(strength,6)
        }
        mm = data.get("metrics", {})
        mm["motif_tracker"] = strength
        data["metrics"] = mm
        return data
