from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
THEMES={"power","freedom","family","justice","truth","war","peace"}
def bag(s):
    out=[]
    for x in s: out.extend(tokens(x))
    return out
@register
class ThemeProgressionTracker:
    def name(self): return "Theme Progression Tracker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        if len(s)<2:
            data.setdefault("metrics",{})["theme_progression_tracker"]=1.0
            data["theme_progression"]={"shift":0,"progression_score":1.0}
            return data
        mid=len(s)//2
        a=Counter(w for w in bag(s[:mid]) if w in THEMES)
        b=Counter(w for w in bag(s[mid:]) if w in THEMES)
        sa=sum(a.values()); sb=sum(b.values())
        denom=max(1,sa+sb)
        shift=abs(sa-sb)/denom
        score=max(0.0,1.0-shift)
        data.setdefault("metrics",{})["theme_progression_tracker"]=score
        data["theme_progression"]={"shift_ratio":round(shift,6),"progression_score":round(score,6)}
        return data
