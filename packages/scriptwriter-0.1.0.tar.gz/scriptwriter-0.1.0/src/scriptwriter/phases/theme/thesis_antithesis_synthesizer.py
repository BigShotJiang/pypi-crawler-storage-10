from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
THESIS = {"power","freedom","family","justice","truth"}
ANTI = {"corruption","tyranny","betrayal","chaos","lie","prison"}
@register
class ThesisAntithesisSynthesizer:
    def name(self):
        return "Thesis Antithesis Synthesizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        th = 0
        an = 0
        for x in s:
            t = tokens(x)
            th += sum(1 for w in t if w in THESIS)
            an += sum(1 for w in t if w in ANTI)
        bal = 1.0 if th and an else 0.5 if (th or an) else 0.0
        score = round(min(1.0, (th+an)/max(1,len(s))) * 0.6 + 0.4*bal,6)
        data["dialectic"] = {"thesis":th,"antithesis":an,"synthesis_score":score}
        m = data.get("metrics", {})
        m["thesis_antithesis_synthesizer"] = score
        data["metrics"] = m
        return data
