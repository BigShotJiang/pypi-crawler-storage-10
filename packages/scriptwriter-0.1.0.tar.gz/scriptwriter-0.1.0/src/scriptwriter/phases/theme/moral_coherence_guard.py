from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
MORAL = {"good","evil","right","wrong","mercy","cruel","honor","shame","virtue","vice"}
@register
class MoralCoherenceGuard:
    def name(self):
        return "Moral Coherence Guard"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        m = 0
        for x in s:
            m += sum(1 for w in tokens(x) if w in MORAL)
        score = min(1.0, m/max(1,len(s)*2))
        data["moral"] = {"moral_markers":m,"moral_coherence_score":round(score,6)}
        mm = data.get("metrics", {})
        mm["moral_coherence_guard"] = score
        data["metrics"] = mm
        return data
