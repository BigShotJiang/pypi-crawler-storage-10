from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LEX={"power","freedom","family","justice","truth","war","peace"}
@register
class ThemeIntensityCurve:
    def name(self): return "Theme Intensity Curve"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        vals=[sum(1 for w in tokens(x) if w in LEX) for x in s]
        meanval=mean(vals) if vals else 0.0
        score=min(1.0,meanval/5.0)
        data.setdefault("metrics",{})["theme_intensity_curve"]=score
        data["theme_intensity"]={"mean":round(meanval,6),"theme_intensity_score":round(score,6)}
        return data
