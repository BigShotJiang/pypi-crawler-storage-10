from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class MotifBridgeScorer:
    def name(self): return "Motif Bridge Scorer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        if len(s) < 3:
            data.setdefault("metrics", {})["motif_bridge_scorer"] = 0.0
            data["motif_bridge"] = {"bridges": 0, "motif_bridge_score": 0.0}
            return data
        a = set(tokens(s[0])); b = set(tokens(s[len(s)//2])); c = set(tokens(s[-1]))
        bridges = len((a & b) | (b & c))
        score = min(1.0, bridges/10.0)
        data.setdefault("metrics", {})["motif_bridge_scorer"] = score
        data["motif_bridge"] = {"bridges": bridges, "motif_bridge_score": round(score,6)}
        return data
