from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class MotifSymmetryChecker:
    def name(self): return "Motif Symmetry Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        if len(s)<2:
            data.setdefault("metrics",{})["motif_symmetry_checker"]=1.0
            data["motif_symmetry"]={"symmetry":1.0}
            return data
        a=Counter(tokens(s[0])); b=Counter(tokens(s[-1]))
        inter=sum((a&b).values()); uni=sum((a|b).values()) or 1
        j=inter/uni
        data.setdefault("metrics",{})["motif_symmetry_checker"]=j
        data["motif_symmetry"]={"jaccard":round(j,6)}
        return data
