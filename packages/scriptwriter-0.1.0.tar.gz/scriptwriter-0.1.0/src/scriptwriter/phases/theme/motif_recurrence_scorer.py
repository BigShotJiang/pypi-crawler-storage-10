from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class MotifRecurrenceScorer:
    def name(self): return "Motif Recurrence Scorer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        c=Counter()
        for x in s:
            t=tokens(x)
            for i in range(len(t)-1):
                c[(t[i],t[i+1])]+=1
        repeats=sum(1 for k,v in c.items() if v>1)
        score=min(1.0, repeats/max(1,len(s)))
        data.setdefault("metrics", {})["motif_recurrence_scorer"]=score
        data["motif_recurrence"]={"repeated_bigrams":repeats,"motif_recurrence_score":round(score,6)}
        return data
