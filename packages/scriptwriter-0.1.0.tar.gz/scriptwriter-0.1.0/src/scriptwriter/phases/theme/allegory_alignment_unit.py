from typing import Dict, List
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

ABSTRACT = {"freedom","power","destiny","justice","fate","time","truth","honor","faith","hope","fear","love","death","war","peace","chaos","order","memory","dream","future","past","soul","spirit"}
CONCRETE_HINTS = {"river","mountain","storm","fire","stone","door","bridge","road","ship","garden","forest","city","crown","throne","chain","mask","shadow","light","mirror","beast","machine"}
SIMILE_TRIG = {"like","as"}
LINKERS = {"is","are","was","were","be","becomes","become","equals","symbolizes","means","reflects"}
STOP = {"the","a","an","of","to","in","on","at","by","for"}

def _rat(n,d):
    return n/max(1,d)

def _left_token(t: List[str], i: int) -> str:
    j = i-1
    while j>=0 and t[j] in STOP:
        j -= 1
    return t[j] if j>=0 else ""

def _right_token(t: List[str], i: int) -> str:
    j = i+1
    while j<len(t) and t[j] in STOP:
        j += 1
    return t[j] if j<len(t) else ""

@register
class AllegoryAlignmentUnit:
    def name(self):
        return "Allegory Alignment Unit"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = []
        for x in s:
            toks.extend(tokens(x))
        total = len(toks)
        abstract_hits = sum(1 for w in toks if w in ABSTRACT)
        concrete_hits = sum(1 for w in toks if w in CONCRETE_HINTS)
        similes = sum(1 for w in toks if w in SIMILE_TRIG)
        mappings = 0
        for i,w in enumerate(toks):
            if w in LINKERS:
                left = _left_token(toks, i)
                right = _right_token(toks, i)
                if (left in CONCRETE_HINTS and right in ABSTRACT) or (left in ABSTRACT and right in CONCRETE_HINTS):
                    mappings += 1
        density = min(1.0, _rat(abstract_hits+concrete_hits+similes, total))
        mapping_ratio = min(1.0, _rat(mappings, max(1,len(s))))
        balance = 1.0 if concrete_hits and abstract_hits else 0.5 if (concrete_hits or abstract_hits) else 0.0
        score = round(0.5*mapping_ratio + 0.3*density + 0.2*balance, 6)
        data["allegory"] = {
            "abstract_mentions": abstract_hits,
            "concrete_mentions": concrete_hits,
            "similes": similes,
            "mappings": mappings,
            "allegory_score": score
        }
        mm = data.get("metrics", {})
        mm["allegory_alignment_unit"] = score
        data["metrics"] = mm
        return data
