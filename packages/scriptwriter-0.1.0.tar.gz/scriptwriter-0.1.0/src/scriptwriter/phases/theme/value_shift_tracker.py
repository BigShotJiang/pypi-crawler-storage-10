from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS={"hope","love","truth","justice","peace"}
NEG={"fear","hate","lie","corruption","war"}
@register
class ValueShiftTracker:
    def name(self): return "Value Shift Tracker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        a=sum(sum(1 for w in tokens(x) if w in POS) for x in s)
        b=sum(sum(1 for w in tokens(x) if w in NEG) for x in s)
        total=max(1,a+b)
        shift=abs(a-b)/total
        score=max(0.0,1.0-shift)
        data.setdefault("metrics",{})["value_shift_tracker"]=score
        data["value_shift"]={"pos":a,"neg":b,"value_shift_score":round(score,6)}
        return data
