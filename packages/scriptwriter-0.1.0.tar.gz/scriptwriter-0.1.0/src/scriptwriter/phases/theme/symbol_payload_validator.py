from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SYM = {"ring","mask","mirror","crown","key","blade","fire","shadow","light","coin"}
@register
class SymbolPayloadValidator:
    def name(self):
        return "Symbol Payload Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in SYM)
        score = min(1.0, hits/max(1,len(s)))
        data["symbol"] = {"symbols":hits,"symbol_payload_score":round(score,6)}
        m = data.get("metrics", {})
        m["symbol_payload_validator"] = score
        data["metrics"] = m
        return data
