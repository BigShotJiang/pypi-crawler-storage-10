from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class CrossEpisodeMemoryChecker:
    def name(self): return "Cross Episode Memory Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        recalls=sum(1 for x in s if "as before" in x.lower() or "previously" in x.lower())
        ratio=min(1.0,recalls/max(1,len(s)))
        data.setdefault("metrics",{})["cross_episode_memory_checker"]=ratio
        data["cross_episode_memory"]={"recalls":recalls,"memory_continuity_score":round(ratio,6)}
        return data
