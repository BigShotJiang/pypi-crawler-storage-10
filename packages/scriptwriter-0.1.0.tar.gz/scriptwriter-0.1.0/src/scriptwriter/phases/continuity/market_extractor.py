from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class MarketExtractor:
    def name(self):
        return "Market Extractor"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["market_extractor"] = 1.0
        data["metrics"] = m
        return data
