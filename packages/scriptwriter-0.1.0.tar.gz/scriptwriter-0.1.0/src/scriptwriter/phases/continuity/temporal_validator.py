from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class TemporalValidator:
    def name(self):
        return "Temporal Validator"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["temporal_validator"] = 1.0
        data["metrics"] = m
        return data
