from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class PropContinuityGuard:
    def name(self): return "Prop Continuity Guard"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        breaks = sum(1 for i in range(1,len(s)) if s[i][:8]==s[i-1][:8])
        score = max(0.0, 1.0 - min(1.0, breaks/max(1,len(s)-1)))
        data.setdefault("metrics", {})["prop_continuity_guard"] = score
        data["prop_continuity"] = {"adjacent_repeats": breaks, "prop_continuity_score": round(score,6)}
        return data
