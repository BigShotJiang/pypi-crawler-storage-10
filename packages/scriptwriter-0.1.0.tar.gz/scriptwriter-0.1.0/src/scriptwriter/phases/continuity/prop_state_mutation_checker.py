from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class PropStateMutationChecker:
    def name(self): return "Prop State Mutation Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        repeats=sum(1 for i in range(1,len(s)) if s[i][:8]==s[i-1][:8])
        score=max(0.0,1.0-min(1.0,repeats/max(1,len(s)-1)))
        data.setdefault("metrics",{})["prop_state_mutation_checker"]=score
        data["prop_mutation"]={"adjacent_repeats":repeats,"prop_mutation_score":round(score,6)}
        return data
