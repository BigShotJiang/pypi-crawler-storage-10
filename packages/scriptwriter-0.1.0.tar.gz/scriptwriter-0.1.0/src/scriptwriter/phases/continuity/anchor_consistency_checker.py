from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class AnchorConsistencyChecker:
    def name(self): return "Anchor Consistency Checker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        anchors = [x.split()[:2] for x in s]
        clashes = sum(1 for i in range(1,len(anchors)) if anchors[i]==anchors[i-1])
        ratio = max(0.0, 1.0 - min(1.0, clashes/max(1,len(s)-1)))
        data.setdefault("metrics", {})["anchor_consistency_checker"] = ratio
        data["anchors"] = {"adjacent_clashes":clashes,"anchor_consistency_score":round(ratio,6)}
        return data
