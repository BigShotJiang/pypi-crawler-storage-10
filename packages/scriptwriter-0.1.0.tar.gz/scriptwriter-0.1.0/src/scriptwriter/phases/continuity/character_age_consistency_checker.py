from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
AGE={"child","teen","adult","elder"}
@register
class CharacterAgeConsistencyChecker:
    def name(self): return "Character Age Consistency Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        marks=sum(sum(1 for w in tokens(x) if w in AGE) for x in s)
        score=max(0.0,1.0-min(1.0,marks/max(1,len(s))))
        data.setdefault("metrics",{})["character_age_consistency_checker"]=score
        data["age_consistency"]={"age_markers":marks,"age_consistency_score":round(score,6)}
        return data
