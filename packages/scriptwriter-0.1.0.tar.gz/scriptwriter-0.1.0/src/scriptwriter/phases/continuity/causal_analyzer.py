from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class CausalAnalyzer:
    def name(self):
        return "Causal Analyzer"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["causal_analyzer"] = 1.0
        data["metrics"] = m
        return data
