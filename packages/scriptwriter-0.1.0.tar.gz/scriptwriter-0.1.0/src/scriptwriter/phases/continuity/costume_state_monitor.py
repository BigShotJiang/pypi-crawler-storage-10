from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
WEAR = {"coat","armor","uniform","dress","boots","mask","cloak","helmet","gloves","badge"}
@register
class CostumeStateMonitor:
    def name(self):
        return "Costume State Monitor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        w = 0
        for x in s:
            w += sum(1 for ww in tokens(x) if ww in WEAR)
        score = min(1.0, w/max(1,len(s)))
        data["costume"] = {"mentions":w,"costume_consistency_score":round(score,6)}
        m = data.get("metrics", {})
        m["costume_state_monitor"] = score
        data["metrics"] = m
        return data
