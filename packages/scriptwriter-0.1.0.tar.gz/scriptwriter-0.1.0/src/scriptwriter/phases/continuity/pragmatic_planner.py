from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class PragmaticPlanner:
    def name(self):
        return "Pragmatic Planner"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["pragmatic_planner"] = 1.0
        data["metrics"] = m
        return data
