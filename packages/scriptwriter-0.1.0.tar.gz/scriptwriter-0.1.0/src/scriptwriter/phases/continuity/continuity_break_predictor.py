from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ContinuityBreakPredictor:
    def name(self):
        return "Continuity Break Predictor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        shifts = sum(1 for i in range(1,len(s)) if s[i][-1:] != s[i-1][-1:])
        ratio = min(1.0, shifts/max(1,len(s)-1))
        score = max(0.0, 1.0 - ratio)
        data["continuity_break"] = {"hard_shifts":shifts,"continuity_health_score":round(score,6)}
        m = data.get("metrics", {})
        m["continuity_break_predictor"] = score
        data["metrics"] = m
        return data
