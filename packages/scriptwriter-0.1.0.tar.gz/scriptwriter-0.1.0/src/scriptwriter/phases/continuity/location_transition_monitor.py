from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class LocationTransitionMonitor:
    def name(self): return "Location Transition Monitor"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        moves=sum(1 for i in range(1,len(s)) if s[i-1].strip().endswith(".") and s[i].strip().endswith("."))
        ratio=min(1.0,moves/max(1,len(s)-1))
        data.setdefault("metrics",{})["location_transition_monitor"]=ratio
        data["location_transition"]={"moves":moves,"location_transition_score":round(ratio,6)}
        return data
