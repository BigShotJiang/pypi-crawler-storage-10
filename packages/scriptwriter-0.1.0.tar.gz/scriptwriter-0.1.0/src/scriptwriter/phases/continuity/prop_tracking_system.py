from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
PROP = {"ring","mask","sword","gun","map","letter","key","book","device","badge"}
@register
class PropTrackingSystem:
    def name(self):
        return "Prop Tracking System"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        p = 0
        for x in s:
            p += sum(1 for w in tokens(x) if w in PROP)
        score = min(1.0, p/max(1,len(s)))
        data["props"] = {"mentions":p,"prop_tracking_score":round(score,6)}
        m = data.get("metrics", {})
        m["prop_tracking_system"] = score
        data["metrics"] = m
        return data
