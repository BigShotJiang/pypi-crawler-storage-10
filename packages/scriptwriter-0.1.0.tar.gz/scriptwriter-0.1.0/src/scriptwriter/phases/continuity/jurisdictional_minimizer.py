from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class JurisdictionalMinimizer:
    def name(self):
        return "Jurisdictional Minimizer"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["jurisdictional_minimizer"] = 1.0
        data["metrics"] = m
        return data
