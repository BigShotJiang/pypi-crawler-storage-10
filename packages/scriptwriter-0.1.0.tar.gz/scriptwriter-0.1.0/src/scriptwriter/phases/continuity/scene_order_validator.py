from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneOrderValidator:
    def name(self): return "Scene Order Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        regress=sum(1 for i in range(1,len(s)) if s[i].lower().startswith("before") and s[i-1].lower().startswith("after"))
        ratio=max(0.0,1.0-min(1.0,regress/max(1,len(s)-1)))
        data.setdefault("metrics",{})["scene_order_validator"]=ratio
        data["scene_order"]={"regressions":regress,"scene_order_score":round(ratio,6)}
        return data
