from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
REL={"ally","friend","lover","rival","enemy","mentor","student","parent","child"}
@register
class RelationshipStateTracker:
    def name(self): return "Relationship State Tracker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        mentions=sum(sum(1 for w in tokens(x) if w in REL) for x in s)
        score=min(1.0,mentions/max(1,len(s)))
        data.setdefault("metrics",{})["relationship_state_tracker"]=score
        data["relationship_state"]={"mentions":mentions,"relationship_state_score":round(score,6)}
        return data
