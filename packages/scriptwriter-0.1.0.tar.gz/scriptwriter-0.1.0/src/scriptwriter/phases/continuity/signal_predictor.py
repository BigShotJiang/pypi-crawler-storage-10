from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class SignalPredictor:
    def name(self):
        return "Signal Predictor"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["signal_predictor"] = 1.0
        data["metrics"] = m
        return data
