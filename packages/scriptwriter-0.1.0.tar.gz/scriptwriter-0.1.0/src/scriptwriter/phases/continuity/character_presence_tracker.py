from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class CharacterPresenceTracker:
    def name(self): return "Character Presence Tracker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        names = [w for x in s for w in tokens(x) if w[0:1].isalpha() and len(w)>2]
        c = Counter(names)
        uniq = len([k for k,v in c.items() if v>1])
        score = min(1.0, uniq/max(1,len(s)))
        data.setdefault("metrics", {})["character_presence_tracker"] = score
        data["presence"] = {"recurrent_names": uniq, "presence_score": round(score,6)}
        return data
