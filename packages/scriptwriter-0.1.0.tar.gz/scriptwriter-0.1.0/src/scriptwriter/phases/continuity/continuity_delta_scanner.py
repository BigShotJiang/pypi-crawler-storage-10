from typing import Dict, List, Tuple
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _fingerprint(sent: str) -> Tuple[str,...]:
    t = [w for w in tokens(sent)]
    return tuple(t)

def _entity_like(toks: List[str]) -> List[str]:
    out = []
    for i,w in enumerate(toks):
        if i==0:
            continue
        if len(w)>2 and w[0].isalpha() and w.isalpha() and w[0].upper()==w[0]:
            out.append(w)
    return out

@register
class ContinuityDeltaScanner:
    def name(self):
        return "Continuity Delta Scanner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        fps = [_fingerprint(x) for x in s]
        shifts = 0
        for i in range(1,len(fps)):
            a,b = set(fps[i-1]), set(fps[i])
            inter = len(a & b)
            uni = len(a | b) or 1
            jacc = inter/uni
            if jacc < 0.2:
                shifts += 1
        ent = []
        for sen in s:
            ent.extend(_entity_like(tokens(sen)))
        c = Counter(ent)
        repeats = sum(1 for _,n in c.items() if n>1)
        alerts = 0
        if shifts > max(0, len(s)//3):
            alerts += 1
        if repeats==0 and len(s)>2:
            alerts += 1
        mm = data.get("metrics", {})
        mm["continuity_delta_scanner"] = max(0.0, 1.0 - min(1.0, alerts*0.5 + max(0,shifts-1)*0.1))
        data["metrics"] = mm
        data["continuity"] = {
            "sentences": len(s),
            "hard_shifts": shifts,
            "entity_repeats": repeats,
            "alert_level": alerts
        }
        return data
