from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
TIME = {"dawn","noon","afternoon","evening","night","midnight","sunrise","sunset","hour","minute"}
@register
class TimecodeConsistencyAuditor:
    def name(self):
        return "Timecode Consistency Auditor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        t = 0
        for x in s:
            t += sum(1 for w in tokens(x) if w in TIME)
        score = min(1.0, t/max(1,len(s)))
        data["timecode"] = {"mentions":t,"timecode_consistency_score":round(score,6)}
        m = data.get("metrics", {})
        m["timecode_consistency_auditor"] = score
        data["metrics"] = m
        return data
