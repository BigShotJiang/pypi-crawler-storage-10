from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
LOC = {"city","forest","desert","ocean","room","bridge","lab","castle","village","market"}
@register
class LocationStateTracker:
    def name(self):
        return "Location State Tracker"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        l = 0
        for x in s:
            l += sum(1 for w in tokens(x) if w in LOC)
        score = min(1.0, l/max(1,len(s)))
        data["location"] = {"mentions":l,"location_state_score":round(score,6)}
        m = data.get("metrics", {})
        m["location_state_tracker"] = score
        data["metrics"] = m
        return data
