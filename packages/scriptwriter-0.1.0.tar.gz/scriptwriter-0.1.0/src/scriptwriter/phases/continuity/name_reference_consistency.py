from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class NameReferenceConsistency:
    def name(self): return "Name Reference Consistency"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        names=[w for x in s for w in tokens(x) if len(w)>2 and w[0].isalpha()]
        c=Counter(names)
        rares=sum(1 for k,v in c.items() if v==1)
        ratio=max(0.0,1.0-min(1.0,rares/max(1,len(c))))
        data.setdefault("metrics",{})["name_reference_consistency"]=ratio
        data["name_consistency"]={"unique_once":rares,"name_consistency_score":round(ratio,6)}
        return data
