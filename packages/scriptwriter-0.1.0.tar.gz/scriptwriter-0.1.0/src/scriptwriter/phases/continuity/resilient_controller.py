from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ResilientController:
    def name(self):
        return "Resilient Controller"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        m["resilient_controller"] = 1.0
        data["metrics"] = m
        return data
