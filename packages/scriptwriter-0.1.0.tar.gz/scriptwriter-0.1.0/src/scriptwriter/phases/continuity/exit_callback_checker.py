from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ExitCallbackChecker:
    def name(self): return "Exit Callback Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        exits=sum(1 for x in s if x.strip().endswith("!"))
        callbacks=1 if s and s[-1].strip().endswith("?") else 0
        score=max(0.0,1.0-min(1.0,exits/max(1,len(s)))+callbacks*0.2)
        data.setdefault("metrics",{})["exit_callback_checker"]=score
        data["exit_callback"]={"exits":exits,"callback_tail":callbacks,"exit_callback_score":round(score,6)}
        return data
