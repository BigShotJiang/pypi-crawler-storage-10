from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
PROP={"ring","mask","key","sword","gun","map","crown"}
LOC={"pocket","table","altar","vault","bag","holster","hand"}
@register
class PropLocationCoherence:
    def name(self): return "Prop Location Coherence"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=0
        for x in s:
            t=tokens(x)
            if any(w in PROP for w in t) and any(w in LOC for w in t):
                hits+=1
        score=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["prop_location_coherence"]=score
        data["prop_location"]={"co_occurrences":hits,"prop_location_score":round(score,6)}
        return data
