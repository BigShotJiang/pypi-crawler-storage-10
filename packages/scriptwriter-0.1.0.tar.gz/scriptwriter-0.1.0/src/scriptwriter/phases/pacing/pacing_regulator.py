from typing import Dict, List
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _lens(s: List[str]) -> List[int]:
    return [len(tokens(x)) for x in s if x.strip()]

def _z(v: List[float]) -> List[float]:
    m = mean(v) if v else 0.0
    import math
    sd = pstdev(v) if len(v) > 1 else 0.0
    if sd == 0.0:
        return [0.0 for _ in v]
    return [(x-m)/sd for x in v]

def _entropy(v: List[int]) -> float:
    import math
    s = sum(v)
    if s <= 0:
        return 0.0
    p = [x/s for x in v]
    return -sum((pi*math.log2(pi) if pi > 0 else 0.0) for pi in p)

@register
class PacingRegulator:
    def name(self):
        return "Pacing Regulator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        L = _lens(s)
        m = mean(L) if L else 0.0
        sd = pstdev(L) if len(L) > 1 else 0.0
        e = _entropy(L) if L else 0.0
        z = _z([float(x) for x in L])
        jitter = mean([abs(z[i]-z[i-1]) for i in range(1,len(z))]) if len(z)>1 else 0.0
        score = max(0.0, 1.0 - min(1.0, (sd/(m+1e-9))*0.5 + jitter*0.25))
        data["pacing"] = {
            "sentences": len(s),
            "mean_tokens": round(m,6),
            "std_tokens": round(sd,6),
            "entropy": round(e,6),
            "jitter": round(jitter,6),
            "pacing_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["pacing_regulator"] = score
        data["metrics"] = mm
        return data
