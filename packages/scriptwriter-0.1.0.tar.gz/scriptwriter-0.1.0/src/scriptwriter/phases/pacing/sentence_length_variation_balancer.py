from typing import Dict
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class SentenceLengthVariationBalancer:
    def name(self): return "Sentence Length Variation Balancer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        lens=[len(tokens(x)) for x in s] or [0]
        m=mean(lens); sd=pstdev(lens) if len(lens)>1 else 0.0
        score=max(0.0,1.0-min(1.0,sd/(m+1e-9)))
        data.setdefault("metrics",{})["sentence_length_variation_balancer"]=score
        data["sentence_variation"]={"mean":round(m,6),"std":round(sd,6),"variation_score":round(score,6)}
        return data
