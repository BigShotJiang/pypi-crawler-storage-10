from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class CadenceBalanceController:
    def name(self): return "Cadence Balance Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        q = sum(1 for x in s if x.strip().endswith("?"))
        ex = sum(1 for x in s if x.strip().endswith("!"))
        st = sum(1 for x in s if x.strip().endswith("."))
        total = max(1,len(s))
        target=(0.25,0.15,0.60)
        score = max(0.0, 1.0 - min(1.0, abs(q/total-target[0])+abs(ex/total-target[1])+abs(st/total-target[2])))
        data.setdefault("metrics", {})["cadence_balance_controller"] = score
        data["cadence_balance"] = {"q":q,"ex":ex,"st":st,"cadence_balance_score":round(score,6)}
        return data
