from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class TempoVariationPlanner:
    def name(self):
        return "Tempo Variation Planner"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        ends = [x.strip()[-1] if x.strip() else "" for x in s]
        blocks = 0
        cur = None
        for e in ends:
            t = "fast" if e in {"!","?"} else "calm"
            if t != cur:
                blocks += 1
                cur = t
        var = blocks/max(1,len(s))
        score = min(1.0, var)
        data["tempo"] = {"blocks":blocks,"variation_score":round(score,6)}
        m = data.get("metrics", {})
        m["tempo_variation_planner"] = score
        data["metrics"] = m
        return data
