from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class CalmValveController:
    def name(self): return "Calm Valve Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        calm = sum(1 for x in s if x.strip().endswith("."))
        ratio = calm/max(1,len(s))
        score = min(1.0, ratio)
        data.setdefault("metrics", {})["calm_valve_controller"] = score
        data["calm_valve"] = {"calm_lines": calm, "calm_balance_score": round(score,6)}
        return data
