from typing import Dict
from math import log2
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class RhythmEntropyController:
    def name(self): return "Rhythm Entropy Controller"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        ends=[x.strip()[-1:] for x in s if x.strip()]
        if not ends:
            e=0.0
        else:
            total=len(ends)
            p=[ends.count(c)/total for c in {".","?","!"}]
            e=-sum(q*log2(q) for q in p if q>0)
        score=max(0.0,1.0-min(1.0,e/2.0))
        data.setdefault("metrics",{})["rhythm_entropy_controller"]=score
        data["rhythm_entropy"]={"entropy":round(e,6),"rhythm_entropy_score":round(score,6)}
        return data
