from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class MontageRhythmModeler:
    def name(self):
        return "Montage Rhythm Modeler"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        very_short = sum(1 for x in s if len(x.split()) <= 4)
        bursts = 1 if very_short >= 3 else 0
        score = min(1.0, very_short/max(1,len(s)))
        data["montage"] = {"very_short":very_short,"bursts":bursts,"montage_score":round(score,6)}
        m = data.get("metrics", {})
        m["montage_rhythm_modeler"] = score
        data["metrics"] = m
        return data
