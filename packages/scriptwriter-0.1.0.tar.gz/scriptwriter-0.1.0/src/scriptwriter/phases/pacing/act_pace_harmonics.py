from typing import Dict
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class ActPaceHarmonics:
    def name(self): return "Act Pace Harmonics"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        chunk=max(1,len(s)//3) or 1
        acts=[s[i*chunk:(i+1)*chunk] for i in range(3)]
        means=[]
        for a in acts:
            lens=[len(tokens(x)) for x in a] or [0]
            means.append(sum(lens)/len(lens))
        m=mean(means) if means else 0.0
        sd=pstdev(means) if len(means)>1 else 0.0
        score=max(0.0,1.0-min(1.0,sd/(m+1e-9)))
        data.setdefault("metrics",{})["act_pace_harmonics"]=score
        data["act_pace"]={"means":[round(x,6) for x in means],"harmonics_score":round(score,6)}
        return data
