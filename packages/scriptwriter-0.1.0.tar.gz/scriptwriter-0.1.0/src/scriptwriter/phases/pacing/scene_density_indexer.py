from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class SceneDensityIndexer:
    def name(self): return "Scene Density Indexer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        lens=[len(tokens(x)) for x in s] or [0]
        avg=mean(lens)
        score=min(1.0,avg/24.0)
        data.setdefault("metrics",{})["scene_density_indexer"]=score
        data["scene_density"]={"mean_tokens":round(avg,6),"scene_density_score":round(score,6)}
        return data
