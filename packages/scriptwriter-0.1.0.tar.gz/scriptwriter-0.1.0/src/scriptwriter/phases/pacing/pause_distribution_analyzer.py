from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class PauseDistributionAnalyzer:
    def name(self): return "Pause Distribution Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        commas=sum(x.count(",") for x in s)
        ratio=commas/max(1,len(s))
        score=max(0.0,1.0-min(1.0,abs(ratio-1.5)))
        data.setdefault("metrics",{})["pause_distribution_analyzer"]=score
        data["pause"]={"commas":commas,"pause_balance_score":round(score,6)}
        return data
