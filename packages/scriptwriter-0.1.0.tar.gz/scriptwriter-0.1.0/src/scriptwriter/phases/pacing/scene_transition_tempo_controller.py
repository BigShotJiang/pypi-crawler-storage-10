from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class SceneTransitionTempoController:
    def name(self): return "Scene Transition Tempo Controller"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        dif=[abs(v[i]-v[i-1]) for i in range(1,len(v))] if len(v)>1 else []
        jitter=mean(dif) if dif else 0.0
        score=max(0.0,1.0-min(1.0,jitter))
        data.setdefault("metrics",{})["scene_transition_tempo_controller"]=score
        data["transition_tempo"]={"jitter":round(jitter,6),"transition_tempo_score":round(score,6)}
        return data
