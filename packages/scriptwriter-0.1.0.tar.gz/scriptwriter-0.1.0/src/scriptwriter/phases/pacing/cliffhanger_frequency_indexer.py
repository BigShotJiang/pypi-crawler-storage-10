from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class CliffhangerFrequencyIndexer:
    def name(self): return "Cliffhanger Frequency Indexer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        cliff=sum(1 for x in s if x.strip().endswith("..."))
        freq=min(1.0,cliff/max(1,len(s)))
        score=max(0.0,1.0-freq*0.7)
        data.setdefault("metrics",{})["cliffhanger_frequency_indexer"]=score
        data["cliffhanger"]={"cliffhangers":cliff,"cliffhanger_balance_score":round(score,6)}
        return data
