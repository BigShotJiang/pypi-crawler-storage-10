from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class BeatClusterDetector:
    def name(self): return "Beat Cluster Detector"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        clusters=sum(1 for i in range(2,len(v)) if v[i]==v[i-1]==v[i-2] and v[i]!=0)
        ratio=min(1.0,clusters/max(1,len(s)))
        data.setdefault("metrics",{})["beat_cluster_detector"]=ratio
        data["beat_cluster"]={"clusters":clusters,"beat_cluster_score":round(ratio,6)}
        return data
