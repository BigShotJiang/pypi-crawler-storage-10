from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class BeatJitterMonitor:
    def name(self): return "Beat Jitter Monitor"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        dif=[abs(v[i]-v[i-1]) for i in range(1,len(v))] if len(v)>1 else []
        jitter=mean(dif) if dif else 0.0
        score=max(0.0,1.0-min(1.0,jitter))
        data.setdefault("metrics",{})["beat_jitter_monitor"]=score
        data["beat_jitter"]={"jitter":round(jitter,6),"beat_jitter_score":round(score,6)}
        return data
