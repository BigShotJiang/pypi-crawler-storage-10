from typing import Dict
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class ClimaxDensityEstimator:
    def name(self): return "Climax Density Estimator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        tail=s[-max(1,len(s)//3):] if s else []
        ex=sum(x.strip().endswith("!") for x in tail)
        ratio=min(1.0,ex/max(1,len(tail)))
        data.setdefault("metrics",{})["climax_density_estimator"]=ratio
        data["climax_density"]={"tail_exclaims":ex,"climax_density_score":round(ratio,6)}
        return data
