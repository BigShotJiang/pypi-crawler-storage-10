from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class BreathSpaceAllocator:
    def name(self):
        return "Breath Space Allocator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        short = sum(1 for x in s if len(x.split()) <= 6)
        long = sum(1 for x in s if len(x.split()) >= 18)
        total = max(1,len(s))
        score = min(1.0, short/total) * 0.6 + min(1.0, (total-long)/total) * 0.4
        data["breath"] = {"short_sentences":short,"long_sentences":long,"breath_score":round(score,6)}
        m = data.get("metrics", {})
        m["breath_space_allocator"] = score
        data["metrics"] = m
        return data
