from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def enc(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class RampUpValidator:
    def name(self): return "Ramp Up Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        v = [enc(x) for x in s]
        inc = sum(1 for i in range(1,len(v)) if v[i] >= v[i-1])
        trend = inc/max(1,len(v)-1)
        data.setdefault("metrics", {})["ramp_up_validator"] = trend
        data["ramp_up"] = {"trend": round(trend,6), "ramp_up_score": round(trend,6)}
        return data
