from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SuspenseValveController:
    def name(self):
        return "Suspense Valve Controller"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        q = sum(1 for x in s if x.strip().endswith("?"))
        ex = sum(1 for x in s if x.strip().endswith("!"))
        total = max(1,len(s))
        score = min(1.0, (q+ex)/total)
        data["suspense_valve"] = {"questions":q,"exclaims":ex,"suspense_score":round(score,6)}
        m = data.get("metrics", {})
        m["suspense_valve_controller"] = score
        data["metrics"] = m
        return data
