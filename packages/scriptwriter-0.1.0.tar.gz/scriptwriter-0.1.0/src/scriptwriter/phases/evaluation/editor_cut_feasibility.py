from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class EditorCutFeasibility:
    def name(self): return "Editor Cut Feasibility"
    def process(self, data: Dict) -> Dict:
        m = data.get("metrics", {})
        keys = len(m)
        score = min(1.0, keys/300.0)
        data.setdefault("metrics", {})["editor_cut_feasibility"] = score
        data["editor_cut"] = {"signals": keys, "editor_cut_score": round(score,6)}
        return data
