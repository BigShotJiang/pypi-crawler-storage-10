from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class StoryHealthDashboard:
    def name(self): return "Story Health Dashboard"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        keys=[k for k in m if "score" in k or "controller" in k or "monitor" in k]
        score=min(1.0,len(keys)/40.0)
        data.setdefault("metrics",{})["story_health_dashboard"]=score
        data["story_health"]={"signals":len(keys),"story_health_score":round(score,6)}
        return data
