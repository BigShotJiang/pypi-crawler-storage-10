from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ExecutiveRiskSummary:
    def name(self): return "Executive Risk Summary"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        risk=[k for k in m if "legal" in k or "brand" in k or "violence" in k or "spoiler" in k]
        score=max(0.0,1.0-min(1.0,len(risk)/10.0))
        data.setdefault("metrics",{})["executive_risk_summary"]=score
        data["executive_risk"]={"risk_factors":len(risk),"executive_risk_score":round(score,6)}
        return data
