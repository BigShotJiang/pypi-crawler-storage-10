from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class MarketingHookStrengthMeter:
    def name(self):
        return "Marketing Hook Strength Meter"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        ex = sum(1 for x in s if x.strip().endswith("!"))
        q = sum(1 for x in s if x.strip().endswith("?"))
        score = min(1.0, (ex+q)/max(1,len(s)))
        mm = data.get("metrics", {})
        mm["marketing_hook_strength_meter"] = score
        data["metrics"] = mm
        data["marketing"] = {"exclaims":ex,"questions":q,"hook_score":round(score,6)}
        return data
