from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class FinalDeliveryIndex:
    def name(self): return "Final Delivery Index"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        score=min(1.0,len(m)/400.0)
        data.setdefault("metrics",{})["final_delivery_index"]=score
        data["final_delivery"]={"signals":len(m),"final_delivery_score":round(score,6)}
        return data
