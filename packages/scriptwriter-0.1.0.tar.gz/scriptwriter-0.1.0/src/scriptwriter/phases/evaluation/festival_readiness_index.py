from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class FestivalReadinessIndex:
    def name(self): return "Festival Readiness Index"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        gates=["scene_purpose_validator","theme_resolution_validator","character_agency_meter","pacing_regulator"]
        passed=sum(1 for g in gates if g in m and m[g]>=0.5)
        score=min(1.0,passed/len(gates)) if gates else 0.0
        data.setdefault("metrics",{})["festival_readiness_index"]=score
        data["festival_readiness"]={"passed":passed,"festival_readiness_score":round(score,6)}
        return data
