from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class EditorialPriorityRanker:
    def name(self): return "Editorial Priority Ranker"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        keys=sorted(m.keys())[:8]
        score=min(1.0,len(keys)/8.0)
        data.setdefault("metrics",{})["editorial_priority_ranker"]=score
        data["editorial_priority"]={"signals_considered":len(keys),"editorial_priority_score":round(score,6)}
        return data
