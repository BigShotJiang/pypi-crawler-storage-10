from typing import Dict, List
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _first_n_words(text: str, n: int) -> str:
    w = tokens(text)
    return " ".join(w[:n])

def _key_sentence(sents: List[str]) -> str:
    if not sents:
        return ""
    return max(sents, key=lambda x: len(x))

def _headline(text: str) -> str:
    t = _first_n_words(text, 8)
    return (t[:1].upper()+t[1:]) if t else ""

@register
class ExecutiveSummaryBuilder:
    def name(self):
        return "Executive Summary Builder"
    def process(self, data: Dict) -> Dict:
        text = data["text"]
        s = sentences(text)
        head = _headline(text)
        key = _key_sentence(s)
        length = sum(len(x) for x in s)
        density = len(s)/max(1,length)
        score = max(0.0, min(1.0, 0.6*min(1.0, len(key)/120.0) + 0.4*min(1.0, density*400.0)))
        data["executive_summary"] = {
            "headline": head,
            "key_sentence": key,
            "sentences": len(s),
            "summary_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["executive_summary_builder"] = score
        data["metrics"] = mm
        return data
