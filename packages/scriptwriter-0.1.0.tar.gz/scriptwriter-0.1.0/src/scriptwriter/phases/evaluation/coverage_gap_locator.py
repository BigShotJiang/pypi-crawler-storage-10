from typing import Dict, List, Tuple
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

MANDATES = {
    "who":{"who","character","protagonist","antagonist","ally","enemy","villain","hero","team"},
    "what":{"goal","mission","plan","task","heist","trial","quest","deal","attack","defend"},
    "why":{"why","because","motive","reason","purpose"},
    "how":{"how","method","strategy","tactic","plan"},
    "risk":{"risk","danger","threat","cost","sacrifice","lose","loss","fail","failure"},
    "stakes":{"stakes","consequence","impact","result","outcome"},
    "time":{"now","tonight","deadline","dawn","midnight","day","hour","minutes","seconds"},
    "place":{"city","kingdom","village","office","lab","room","forest","desert","ocean","ship","bridge"}
}

def _present(toks: List[str]) -> Dict[str,int]:
    c = {}
    for k,lex in MANDATES.items():
        c[k] = int(any(w in lex for w in toks))
    return c

@register
class CoverageGapLocator:
    def name(self):
        return "Coverage Gap Locator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = []
        for x in s:
            toks.extend(tokens(x))
        pres = _present(toks)
        covered = sum(pres.values())
        total = len(MANDATES)
        gaps = [k for k,v in pres.items() if v==0]
        score = covered/total if total>0 else 0.0
        data["coverage"] = {
            "covered_slots": covered,
            "total_slots": total,
            "coverage_ratio": round(score,6),
            "missing": gaps[:8]
        }
        mm = data.get("metrics", {})
        mm["coverage_gap_locator"] = score
        data["metrics"] = mm
        return data
