from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class RiskHeatmapAggregator:
    def name(self): return "Risk Heatmap Aggregator"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        risk_keys=[k for k in m if "risk" in k or "compliance" in k or "legal" in k or "spoiler" in k]
        score=max(0.0,1.0-min(1.0,len(risk_keys)/20.0))
        data.setdefault("metrics",{})["risk_heatmap_aggregator"]=score
        data["risk_heatmap"]={"risk_dimensions":len(risk_keys),"risk_score":round(score,6)}
        return data
