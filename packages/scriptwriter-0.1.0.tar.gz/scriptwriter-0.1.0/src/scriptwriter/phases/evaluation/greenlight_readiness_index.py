from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class GreenlightReadinessIndex:
    def name(self): return "Greenlight Readiness Index"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        score=min(1.0,len(m)/350.0)
        data.setdefault("metrics",{})["greenlight_readiness_index"]=score
        data["greenlight_readiness"]={"signals":len(m),"greenlight_score":round(score,6)}
        return data
