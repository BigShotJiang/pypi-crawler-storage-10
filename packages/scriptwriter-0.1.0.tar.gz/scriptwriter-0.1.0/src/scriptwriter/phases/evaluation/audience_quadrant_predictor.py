from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
POS = {"funny","romance","battle","mystery"}
QUADS = ["Q1","Q2","Q3","Q4"]
@register
class AudienceQuadrantPredictor:
    def name(self):
        return "Audience Quadrant Predictor"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        hits = 0
        for x in s:
            hits += sum(1 for w in tokens(x) if w in POS)
        idx = min(3, hits%4)
        quad = QUADS[idx]
        score = min(1.0, hits/max(1,len(s)*2))
        mm = data.get("metrics", {})
        mm["audience_quadrant_predictor"] = score
        data["metrics"] = mm
        data["audience"] = {"signals":hits,"quadrant":quad,"quadrant_score":round(score,6)}
        return data
