from typing import Dict
from scriptwriter.orchestration.registry import register
@register
class ProducerReadoutCompiler:
    def name(self): return "Producer Readout Compiler"
    def process(self, data: Dict) -> Dict:
        m=data.get("metrics",{})
        score=min(1.0,len(m)/250.0)
        data.setdefault("metrics",{})["producer_readout_compiler"]=score
        data["producer_readout"]={"signals":len(m),"producer_readout_score":round(score,6)}
        return data
