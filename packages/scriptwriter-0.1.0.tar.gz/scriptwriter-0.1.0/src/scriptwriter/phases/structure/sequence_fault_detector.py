from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SequenceFaultDetector:
    def name(self):
        return "Sequence Fault Detector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        backsteps = sum(1 for i in range(2,len(s)) if s[i].strip() and s[i-2].strip() and s[i][-1]==s[i-2][-1] and s[i-1][-1:]!=s[i-2][-1:])
        ratio = min(1.0, backsteps/max(1,len(s)-2))
        score = max(0.0, 1.0 - ratio)
        mm = data.get("metrics", {})
        mm["sequence_fault_detector"] = score
        data["metrics"] = mm
        data["sequence_faults"] = {"backsteps":backsteps,"sequence_health_score":round(score,6)}
        return data
