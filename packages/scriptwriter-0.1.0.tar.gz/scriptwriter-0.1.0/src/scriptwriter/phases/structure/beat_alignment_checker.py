from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class BeatAlignmentChecker:
    def name(self): return "Beat Alignment Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        mis=sum(1 for i in range(1,len(s)) if s[i-1].strip().endswith("?") and s[i].strip().endswith("!"))
        ratio=max(0.0,1.0-min(1.0,mis/max(1,len(s)-1)))
        data.setdefault("metrics",{})["beat_alignment_checker"]=ratio
        data["beat_alignment"]={"mismatches":mis,"beat_alignment_score":round(ratio,6)}
        return data
