from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneBoundaryValidator:
    def name(self): return "Scene Boundary Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        weak=sum(1 for x in s if x.strip() and x.strip()[-1] not in ".?!")
        score=max(0.0,1.0-min(1.0,weak/max(1,len(s))))
        data.setdefault("metrics",{})["scene_boundary_validator"]=score
        data["scene_boundary"]={"weak_ends":weak,"scene_boundary_score":round(score,6)}
        return data
