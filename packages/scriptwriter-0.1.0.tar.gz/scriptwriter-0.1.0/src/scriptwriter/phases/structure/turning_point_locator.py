from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class TurningPointLocator:
    def name(self): return "Turning Point Locator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        idx = next((i for i,x in enumerate(s) if "but " in x.lower() or "however" in x.lower()), -1)
        pos = 0.0 if idx < 0 or not s else idx/max(1,len(s)-1)
        data.setdefault("metrics", {})["turning_point_locator"] = pos
        data["turning_point"] = {"position": round(pos,6)}
        return data
