from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneEndpointClassifier:
    def name(self): return "Scene Endpoint Classifier"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        open_ends=sum(1 for x in s if x.strip() and x.strip()[-1] not in ".?!")
        ratio=max(0.0,1.0-min(1.0,open_ends/max(1,len(s))))
        data.setdefault("metrics",{})["scene_endpoint_classifier"]=ratio
        data["scene_endpoints"]={"open_ends":open_ends,"endpoint_health_score":round(ratio,6)}
        return data
