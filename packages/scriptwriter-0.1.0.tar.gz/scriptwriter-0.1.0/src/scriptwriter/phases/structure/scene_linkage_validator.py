from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SceneLinkageValidator:
    def name(self): return "Scene Linkage Validator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        links=sum(1 for i in range(1,len(s)) if s[i-1].strip().endswith("?") and s[i].strip().endswith("."))
        ratio=min(1.0,links/max(1,len(s)-1))
        data.setdefault("metrics",{})["scene_linkage_validator"]=ratio
        data["scene_linkage"]={"links":links,"scene_linkage_score":round(ratio,6)}
        return data
