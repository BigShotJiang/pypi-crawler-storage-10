from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
WHY={"why","because","reason","motive"}
HOW={"how","method","plan","strategy"}
WHERE={"where","city","forest","desert","ocean","castle","market","lab"}
@register
class PlotHoleRiskEstimator:
    def name(self): return "Plot Hole Risk Estimator"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        wh=sum(sum(1 for w in tokens(x) if w in WHY) for x in s)
        hw=sum(sum(1 for w in tokens(x) if w in HOW) for x in s)
        loc=sum(sum(1 for w in tokens(x) if w in WHERE) for x in s)
        cov=(wh>0)+(hw>0)+(loc>0)
        score=max(0.0,1.0-min(1.0,(3-cov)/3.0))
        data.setdefault("metrics",{})["plot_hole_risk_estimator"]=score
        data["plot_hole_risk"]={"coverage":cov,"plot_hole_risk_score":round(score,6)}
        return data
