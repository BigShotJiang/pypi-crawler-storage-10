from typing import Dict
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
@register
class StructureFaultDetector:
    def name(self):
        return "Structure Fault Detector"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        lens = [len(tokens(x)) for x in s] or [0]
        m = mean(lens)
        sd = pstdev(lens) if len(lens)>1 else 0.0
        faults = sum(1 for i in range(1,len(lens)) if abs(lens[i]-lens[i-1])>max(4,0.5*m))
        ratio = min(1.0, faults/max(1,len(s)-1))
        score = max(0.0, 1.0 - ratio)
        mm = data.get("metrics", {})
        mm["structure_fault_detector"] = score
        data["metrics"] = mm
        data["structure_faults"] = {"faults":faults,"structure_stability_score":round(score,6)}
        return data
