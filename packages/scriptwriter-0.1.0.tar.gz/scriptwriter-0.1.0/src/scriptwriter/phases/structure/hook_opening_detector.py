from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class HookOpeningDetector:
    def name(self): return "Hook Opening Detector"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hook=1 if s and (s[0].strip().endswith("?") or s[0].strip().endswith("!")) else 0
        data.setdefault("metrics",{})["hook_opening_detector"]=hook*1.0
        data["hook_opening"]={"has_hook":hook,"hook_score":hook*1.0}
        return data
