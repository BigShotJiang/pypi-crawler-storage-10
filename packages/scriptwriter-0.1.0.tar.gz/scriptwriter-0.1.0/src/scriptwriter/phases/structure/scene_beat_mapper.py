from typing import Dict, List, Tuple
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

def _beats(s: str) -> List[str]:
    x = s.replace("—","-")
    seps = [",",";","-"," but "," however "," though "," and then "]
    parts = [s]
    for sep in seps:
        tmp = []
        for p in parts:
            tmp.extend([q for q in p.split(sep) if q.strip()])
        parts = tmp
    return [p.strip() for p in parts if p.strip()]

def _beat_lengths(sents: List[str]) -> List[int]:
    out = []
    for s in sents:
        bs = _beats(s)
        out.extend([len(tokens(b)) for b in bs if b])
    return out

@register
class SceneBeatMapper:
    def name(self):
        return "Scene Beat Mapper"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        bl = _beat_lengths(s)
        total_beats = len(bl)
        m = mean(bl) if bl else 0.0
        sd = pstdev(bl) if len(bl) > 1 else 0.0
        density = total_beats / max(1, len(s))
        import math
        var_coeff = sd / (m + 1e-9)
        rhythm_uniformity = max(0.0, 1.0 - min(1.0, var_coeff))
        tempo = min(1.0, density / 3.0)
        score = round(0.5*rhythm_uniformity + 0.5*tempo, 6)
        data["structure_scene_beats"] = {
            "sentences": len(s),
            "beats": total_beats,
            "beats_per_sentence": round(density,6),
            "mean_tokens_per_beat": round(m,6),
            "std_tokens_per_beat": round(sd,6),
            "rhythm_uniformity": round(rhythm_uniformity,6),
            "tempo": round(tempo,6),
            "scene_beat_score": score
        }
        mm = data.get("metrics", {})
        mm["scene_beat_mapper"] = score
        data["metrics"] = mm
        return data
