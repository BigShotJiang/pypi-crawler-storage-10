from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
MARK={"subplot","bplot","meanwhile","side","secondary"}
@register
class BStoryPresenceIndexer:
    def name(self): return "B Story Presence Indexer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        hits=sum(sum(1 for w in tokens(x) if w in MARK) for x in s)
        ratio=min(1.0,hits/max(1,len(s)))
        data.setdefault("metrics",{})["b_story_presence_indexer"]=ratio
        data["b_story"]={"markers":hits,"b_story_presence_score":round(ratio,6)}
        return data
