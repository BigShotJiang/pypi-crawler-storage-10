from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
SET={"seed","hint","plant","setup"}
PAY={"payoff","resolve","reveal"}
@register
class PayoffLoopClosureChecker:
    def name(self): return "Payoff Loop Closure Checker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        set_hits=sum(sum(1 for w in tokens(x) if w in SET) for x in s)
        pay_hits=sum(sum(1 for w in tokens(x) if w in PAY) for x in s)
        score=min(1.0,pay_hits/max(1,set_hits)) if set_hits else 0.0
        data.setdefault("metrics",{})["payoff_loop_closure_checker"]=score
        data["payoff_loop"]={"setups":set_hits,"payoffs":pay_hits,"loop_closure_score":round(score,6)}
        return data
