from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
RES={"resolve","finally","conclude","end","close","wrap"}
SUB={"subplot","bplot","meanwhile","side"}
@register
class SubplotResolutionTracker:
    def name(self): return "Subplot Resolution Tracker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        res=sum(1 for x in s for w in tokens(x) if w in RES)
        sub=sum(1 for x in s for w in tokens(x) if w in SUB)
        score=min(1.0,res/max(1,sub)) if sub else 0.0
        data.setdefault("metrics",{})["subplot_resolution_tracker"]=score
        data["subplot_resolution"]={"subplot_markers":sub,"resolutions":res,"subplot_resolution_score":round(score,6)}
        return data
