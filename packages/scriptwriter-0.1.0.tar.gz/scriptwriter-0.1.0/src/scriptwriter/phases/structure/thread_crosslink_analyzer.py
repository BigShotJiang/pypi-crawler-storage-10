from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
STOP={"the","a","an","of","to","in","and"}
def subj(s): 
    t=[w for w in tokens(s) if w not in STOP]
    return t[0] if t else ""
@register
class ThreadCrosslinkAnalyzer:
    def name(self): return "Thread Crosslink Analyzer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        subs=[subj(x) for x in s if subj(x)]
        c=Counter(subs)
        multi=len([k for k,v in c.items() if v>=2])
        score=min(1.0,multi/max(1,len(c)))
        data.setdefault("metrics",{})["thread_crosslink_analyzer"]=score
        data["thread_crosslink"]={"recurrent_subjects":multi,"thread_crosslink_score":round(score,6)}
        return data
