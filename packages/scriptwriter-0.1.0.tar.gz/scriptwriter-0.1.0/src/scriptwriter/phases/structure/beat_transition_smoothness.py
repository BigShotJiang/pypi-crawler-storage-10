from typing import Dict, List
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def endsig(x:str)->int:
    x=x.strip()
    return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class BeatTransitionSmoothness:
    def name(self): return "Beat Transition Smoothness"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        e = [endsig(x) for x in s]
        diffs = [abs(e[i]-e[i-1]) for i in range(1,len(e))] if len(e)>1 else []
        jitter = mean(diffs) if diffs else 0.0
        score = max(0.0, 1.0 - min(1.0, jitter/2.0))
        data.setdefault("metrics", {})["beat_transition_smoothness"] = score
        data["beat_transition"] = {"jitter":round(jitter,6),"smoothness_score":round(score,6)}
        return data
