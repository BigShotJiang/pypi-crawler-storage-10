from typing import Dict, List
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

STOP = {"the","a","an","and","or","but","to","of","in","on","for","with","as","by","at","from","that","this","it","is","are","was","were","be","been","being","have","has","had","do","does","did","we","you","they","he","she","i","them","him","her","our","your","their","my"}

def _subject(sent: str) -> str:
    t = [w for w in tokens(sent) if w not in STOP]
    return t[0] if t else ""

def _thread_map(sents: List[str]) -> List[str]:
    return [_subject(s) for s in sents]

def _alternations(seq: List[str]) -> int:
    c = 0
    for i in range(2, len(seq)):
        if seq[i] == seq[i-2] and seq[i] != seq[i-1] and seq[i] and seq[i-1]:
            c += 1
    return c

@register
class ThreadInterleaver:
    def name(self):
        return "Thread Interleaver"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        order = _thread_map(s)
        ct = Counter(x for x in order if x)
        threads = [k for k,v in ct.items() if v>=2][:8]
        coverage = sum(1 for x in order if x in threads)/max(1,len(order))
        altern = _alternations(order)
        balance = min(1.0, len(threads)/max(1, len(s)))
        weave = min(1.0, altern/max(1, len(s)-2))
        score = round(0.5*coverage + 0.3*balance + 0.2*weave, 6)
        data["structure_threads"] = {
            "sentences": len(s),
            "threads_detected": len(threads),
            "coverage_ratio": round(coverage,6),
            "alternations": altern,
            "interleave_score": score
        }
        mm = data.get("metrics", {})
        mm["thread_interleaver"] = score
        data["metrics"] = mm
        return data
