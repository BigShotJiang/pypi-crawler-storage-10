from typing import Dict, List, Tuple
from collections import Counter
from statistics import mean
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

STOP = {"the","a","an","and","or","but","to","of","in","on","for","with","as","by","at","from","that","this","it","is","are","was","were","be","been","being","have","has","had","do","does","did"}

def _ngrams(toks: List[str], n: int) -> List[Tuple[str,...]]:
    return [tuple(toks[i:i+n]) for i in range(len(toks)-n+1)] if n>0 else []

def _flatten(sents: List[str]) -> List[str]:
    out = []
    for s in sents:
        out.extend(tokens(s))
    return out

@register
class ExpositionMinimizer:
    def name(self):
        return "Exposition Minimizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        toks = _flatten(s)
        total_tokens = len(toks)
        sw = sum(1 for w in toks if w in STOP)
        sw_ratio = sw / total_tokens if total_tokens else 0.0
        bi = _ngrams(toks, 2)
        tri = _ngrams(toks, 3)
        bc = Counter(bi)
        tc = Counter(tri)
        b_rep = sum(n-1 for n in bc.values() if n>1)
        t_rep = sum(n-1 for n in tc.values() if n>1)
        total_ngrams = max(1, len(bi)+len(tri))
        redundancy = (b_rep + t_rep) / total_ngrams
        sent_lens = [len(tokens(x)) for x in s] or [0]
        long_run = 0
        run = 0
        for n in sent_lens:
            if n >= 18:
                run += 1
                if run > long_run:
                    long_run = run
            else:
                run = 0
        compression_score = max(0.0, 1.0 - min(1.0, 0.7*redundancy + 0.3*sw_ratio + 0.1*long_run))
        data["structure_exposition"] = {
            "sentences": len(s),
            "stopword_ratio": round(sw_ratio,6),
            "redundancy_ratio": round(redundancy,6),
            "long_exposition_run": long_run,
            "compression_score": round(compression_score,6)
        }
        mm = data.get("metrics", {})
        mm["exposition_minimizer"] = compression_score
        data["metrics"] = mm
        return data
