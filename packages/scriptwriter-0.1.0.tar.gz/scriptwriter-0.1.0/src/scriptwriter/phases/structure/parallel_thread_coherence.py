from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
STOP={"the","a","an","of","to","in","and"}
def subj(s):
    t=[w for w in tokens(s) if w not in STOP]
    return t[0] if t else ""
@register
class ParallelThreadCoherence:
    def name(self): return "Parallel Thread Coherence"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        subs=[subj(x) for x in s if subj(x)]
        c=Counter(subs)
        multi=sum(1 for v in c.values() if v>=2)
        ratio=min(1.0,multi/max(1,len(c)))
        data.setdefault("metrics",{})["parallel_thread_coherence"]=ratio
        data["parallel_threads"]={"recurrent_subjects":multi,"parallel_thread_score":round(ratio,6)}
        return data
