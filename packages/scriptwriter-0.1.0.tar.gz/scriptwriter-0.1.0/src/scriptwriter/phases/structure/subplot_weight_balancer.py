from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
MARKERS = {"subplot","bplot","cplot","side","meanwhile"}
@register
class SubplotWeightBalancer:
    def name(self):
        return "Subplot Weight Balancer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        counts = 0
        for x in s:
            t = tokens(x)
            counts += sum(1 for w in t if w in MARKERS)
        ratio = counts/max(1,len(s))
        score = max(0.0, 1.0 - min(1.0, abs(0.3 - min(1.0, ratio))))
        data["subplot"] = {"markers":counts,"subplot_ratio":round(ratio,6),"balance_score":round(score,6)}
        m = data.get("metrics", {})
        m["subplot_weight_balancer"] = score
        data["metrics"] = m
        return data
