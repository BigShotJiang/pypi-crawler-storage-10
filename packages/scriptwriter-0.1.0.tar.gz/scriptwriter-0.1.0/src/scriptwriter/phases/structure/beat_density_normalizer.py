from typing import Dict, List
from statistics import mean, pstdev
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
def _beats(s: str) -> List[str]:
    x = s.replace("—","-")
    parts = [p for q in x.split(";") for p in q.split(",")]
    return [p.strip() for p in parts if p.strip()]
@register
class BeatDensityNormalizer:
    def name(self):
        return "Beat Density Normalizer"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        bps = []
        for x in s:
            bps.append(len(_beats(x)))
        if not bps:
            bps=[1]
        m = mean(bps)
        sd = pstdev(bps) if len(bps)>1 else 0.0
        score = max(0.0, 1.0 - min(1.0, sd/(m+1e-9)))
        data["beat_density"] = {"beats_per_sentence_mean":round(m,6),"std":round(sd,6),"normalization_score":round(score,6)}
        mtr = data.get("metrics", {})
        mtr["beat_density_normalizer"] = score
        data["metrics"] = mtr
        return data
