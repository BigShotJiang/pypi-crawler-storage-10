from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
def sig(x): x=x.strip(); return 2 if x.endswith("!") else 1 if x.endswith("?") else 0
@register
class EscalationGatekeeper:
    def name(self): return "Escalation Gatekeeper"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        v=[sig(x) for x in s]
        inc=sum(1 for i in range(1,len(v)) if v[i]>=v[i-1])
        trend=inc/max(1,len(v)-1)
        score=min(1.0,trend)
        data.setdefault("metrics",{})["escalation_gatekeeper"]=score
        data["escalation_gate"]={"trend":round(trend,6),"escalation_gate_score":round(score,6)}
        return data
