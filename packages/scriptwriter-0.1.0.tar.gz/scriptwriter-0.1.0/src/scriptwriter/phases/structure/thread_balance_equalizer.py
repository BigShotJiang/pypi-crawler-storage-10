from typing import Dict
from collections import Counter
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
STOP={"the","a","an","of","to","in"}
def subject(sent:str):
    t=[w for w in tokens(sent) if w not in STOP]
    return t[0] if t else ""
@register
class ThreadBalanceEqualizer:
    def name(self): return "Thread Balance Equalizer"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        subs=[subject(x) for x in s if subject(x)]
        ct=Counter(subs)
        if not ct:
            score=1.0
        else:
            mx=max(ct.values()); mn=min(ct.values())
            score=max(0.0,1.0-min(1.0,(mx-mn)/max(1,mx)))
        data.setdefault("metrics",{})["thread_balance_equalizer"]=score
        data["thread_balance"]={"subjects":len(ct),"balance_score":round(score,6)}
        return data
