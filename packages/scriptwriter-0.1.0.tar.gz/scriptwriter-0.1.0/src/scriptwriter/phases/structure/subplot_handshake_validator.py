from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens
MARK={"subplot","bplot","meanwhile","side","secondary"}
@register
class SubplotHandshakeValidator:
    def name(self): return "Subplot Handshake Validator"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        first = next((i for i,x in enumerate(s) if any(w in MARK for w in tokens(x))), -1)
        last = len(s)-1 - next((i for i,x in enumerate(reversed(s)) if any(w in MARK for w in tokens(x))), -1) if s else -1
        ok = 1.0 if first != -1 and last != -1 and last >= first else 0.0
        data.setdefault("metrics", {})["subplot_handshake_validator"] = ok
        data["subplot_handshake"] = {"start": first, "end": last, "handshake_score": round(ok,6)}
        return data
