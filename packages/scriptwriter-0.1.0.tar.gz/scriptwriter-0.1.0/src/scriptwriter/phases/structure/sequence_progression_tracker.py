from typing import Dict
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences
@register
class SequenceProgressionTracker:
    def name(self): return "Sequence Progression Tracker"
    def process(self, data: Dict) -> Dict:
        s=sentences(data["text"])
        progress=sum(1 for i in range(1,len(s)) if s[i].strip() and s[i-1].strip() and s[i][-1]!=s[i-1][-1])
        ratio=min(1.0,progress/max(1,len(s)-1))
        data.setdefault("metrics",{})["sequence_progression_tracker"]=ratio
        data["sequence_progression"]={"progress_steps":progress,"progression_ratio":round(ratio,6)}
        return data
