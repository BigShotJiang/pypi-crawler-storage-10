from typing import Dict, List
from scriptwriter.orchestration.registry import register
from scriptwriter.core.utils.text import sentences, tokens

CUES = {
    "setup":{"first","initially","at_first","begin","introduce","set","establish"},
    "confront":{"but","however","though","conflict","challenge","against","versus"},
    "resolution":{"so","therefore","thus","finally","in_the_end","conclude","resolve","result"}
}

def _norm_tokenize(s: str) -> List[str]:
    t = tokens(s)
    out = []
    for w in t:
        if w == "at" and out and out[-1] == "first":
            out[-1] = "at_first"
            continue
        if w == "in" and out and out[-1] == "the":
            out[-1] = "in_the"
            continue
        out.append(w)
    return out

def _cue_flags(s: str) -> Dict[str,int]:
    t = set(_norm_tokenize(s))
    return {k:int(len(t & v)>0) for k,v in CUES.items()}

def _phase_index(flags: Dict[str,int]) -> int:
    if flags["setup"]: return 0
    if flags["confront"]: return 1
    if flags["resolution"]: return 2
    return 1

def _violations(phases: List[int]) -> int:
    v = 0
    last = -1
    for p in phases:
        if last == -1: last = p; continue
        if p < last: v += 1
        last = p
    return v

@register
class SequenceGatekeeper:
    def name(self):
        return "Sequence Gatekeeper"
    def process(self, data: Dict) -> Dict:
        s = sentences(data["text"])
        phases = [_phase_index(_cue_flags(x)) for x in s]
        viol = _violations(phases)
        coverage = {
            "setup": int(0 in phases),
            "confront": int(1 in phases),
            "resolution": int(2 in phases)
        }
        coverage_ratio = sum(coverage.values())/3.0
        import math
        penalty = min(1.0, viol/max(1,len(s)-1))
        score = max(0.0, min(1.0, 0.7*coverage_ratio + 0.3*(1.0-penalty)))
        data["structure_sequence"] = {
            "sentences": len(s),
            "violations": viol,
            "coverage_ratio": round(coverage_ratio,6),
            "sequence_score": round(score,6)
        }
        mm = data.get("metrics", {})
        mm["sequence_gatekeeper"] = score
        data["metrics"] = mm
        return data
