import json

def dump(obj):
    return json.dumps(obj, ensure_ascii=False)
