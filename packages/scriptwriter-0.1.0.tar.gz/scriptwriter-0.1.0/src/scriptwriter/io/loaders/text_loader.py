def load_text(x):
    return x
