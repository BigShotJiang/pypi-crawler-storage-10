from typing import Dict
from scriptwriter.orchestration.loader import load_all
from scriptwriter.orchestration.registry import list_phases
def run_pipeline(text: str) -> Dict:
    load_all()
    data = {"text": text, "metrics": {}}
    for p in list_phases():
        data = p.process(data)
    return data
