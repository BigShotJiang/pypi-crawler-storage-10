## cdf 

### Added

- [alpha] Adds new command for migrating assets `cdf migrate assets`. 

### Changed

- [alpha] The migration command for source system is renamed from `cdf
migrate source-system` to `cdf migrate source-systems` to be consistent
with the other migration commands.

## templates

No changes.