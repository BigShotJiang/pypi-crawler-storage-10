# coding=utf-8
from .._impl import (
    scout_chart_api_DeprecatedDefinitionAndSchemaVersion as DeprecatedDefinitionAndSchemaVersion,
    scout_chart_api_JsonString as JsonString,
)

__all__ = [
    'DeprecatedDefinitionAndSchemaVersion',
    'JsonString',
]

