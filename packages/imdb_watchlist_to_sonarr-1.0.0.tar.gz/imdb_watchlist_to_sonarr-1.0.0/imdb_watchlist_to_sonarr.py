#!/usr/bin/env python3
"""Sync IMDb watchlist (TV only) into Sonarr."""

import argparse
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import requests
from dotenv import load_dotenv

# Load environment variables from .env file (if it exists)
# This loads before reading environment variables below
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    load_dotenv(env_path)
else:
    # Try to load from current directory as fallback
    load_dotenv()

# Version
__version__ = "1.0.0"

# HTTP Status codes as constants
HTTP_OK = 200
HTTP_CREATED = 201
HTTP_NOT_FOUND = 404
HTTP_UNPROCESSABLE = 422

# Retry configuration
MAX_RETRIES = 3
INITIAL_BACKOFF = 1.0
MAX_BACKOFF = 10.0

# Validation constants
MIN_API_KEY_LENGTH = 10

# Configuration via env or CLI
DEFAULT_SONARR_URL = os.getenv("SONARR_URL", "http://localhost:8989")
DEFAULT_SONARR_API_KEY = os.getenv("SONARR_API_KEY", "")
DEFAULT_ROOT_FOLDER = os.getenv("SONARR_ROOT_FOLDER", "/data/tv")
DEFAULT_QUALITY_PROFILE = os.getenv("SONARR_QUALITY_PROFILE", "HD-1080p")
DEFAULT_LANGUAGE_PROFILE = os.getenv("SONARR_LANGUAGE_PROFILE", None)
DEFAULT_IMDB_URL = os.getenv("IMDB_WATCHLIST_URL", "")
DEFAULT_MONITOR = os.getenv("SONARR_MONITOR", "all")
DEFAULT_SEASON_FOLDERS = os.getenv("SONARR_SEASON_FOLDERS", "true").lower() == "true"
DEFAULT_SEARCH_ON_ADD = os.getenv("SONARR_SEARCH_ON_ADD", "true").lower() == "true"
DEFAULT_REMOVE_MISSING = os.getenv("REMOVE_MISSING", "false").lower() == "true"
DEFAULT_DRY_RUN = os.getenv("DRY_RUN", "false").lower() == "true"

HEADERS_JSON = {"accept": "application/json"}
IMDB_ITEM_RE = re.compile(r"/title/(tt\d+)")

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s", datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Raised when input validation fails."""


def validate_url(url: str, name: str = "URL") -> None:
    """Validate that a URL is well-formed and uses http/https."""
    if not url:
        raise ValidationError(f"{name} cannot be empty")
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValidationError(f"{name} must use http or https scheme, got: {parsed.scheme}")
    if not parsed.netloc:
        raise ValidationError(f"{name} must have a valid domain")


def validate_api_key(api_key: str) -> None:
    """Validate that API key has reasonable format."""
    if not api_key or len(api_key) < MIN_API_KEY_LENGTH:
        raise ValidationError(f"API key must be at least {MIN_API_KEY_LENGTH} characters")


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    p = argparse.ArgumentParser(description="Sync IMDb watchlist (TV only) into Sonarr.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument("--imdb-url", default=DEFAULT_IMDB_URL, help="IMDb watchlist URL")
    p.add_argument("--sonarr-url", default=DEFAULT_SONARR_URL, help="Sonarr base URL")
    p.add_argument("--sonarr-api-key", default=DEFAULT_SONARR_API_KEY, help="Sonarr API key")
    p.add_argument("--root-folder", default=DEFAULT_ROOT_FOLDER, help="Root folder for new series")
    p.add_argument(
        "--quality-profile", default=DEFAULT_QUALITY_PROFILE, help="Quality profile name"
    )
    p.add_argument(
        "--language-profile",
        default=DEFAULT_LANGUAGE_PROFILE,
        help="Language profile name (optional)",
    )
    p.add_argument(
        "--monitor",
        default=DEFAULT_MONITOR,
        help="Monitor option (all,future,missing,none)",
    )
    p.add_argument("--no-season-folders", action="store_true", help="Disable season folders")
    p.add_argument("--no-search", action="store_true", help="Do NOT search on add")
    p.add_argument(
        "--remove-missing",
        action="store_true",
        help="Remove series from Sonarr if not on IMDb (careful)",
    )
    p.add_argument("--dry-run", action="store_true", help="Print actions without changing Sonarr")
    p.add_argument(
        "--imdb-cookie",
        default=None,
        help="Optional IMDb cookie header if your watchlist is private",
    )
    p.add_argument(
        "--max-pages",
        type=int,
        default=None,
        help="Maximum number of pages to fetch from IMDb (default: all pages)",
    )
    p.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    return p.parse_args()


class IMDbTVShow:
    """Represents a TV show from IMDb."""

    def __init__(self, imdb_id: str, title: str, show_type: str):
        self.id = imdb_id
        self.title = title
        self.type = show_type

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary."""
        return {"id": self.id, "title": self.title, "type": self.type}


def exponential_backoff_retry(
    func: Any, *args: Any, max_retries: int = MAX_RETRIES, **kwargs: Any
) -> Any:
    """
    Retry a function with exponential backoff.

    Args:
        func: Function to retry
        *args: Positional arguments for the function
        max_retries: Maximum number of retries
        **kwargs: Keyword arguments for the function

    Returns:
        Result of successful function call

    Raises:
        Exception: If all retries are exhausted
    """
    backoff = INITIAL_BACKOFF
    last_exception = None

    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except (requests.RequestException, json.JSONDecodeError) as e:
            last_exception = e
            if attempt < max_retries - 1:
                logger.warning(
                    f"Attempt {attempt + 1}/{max_retries} failed: {e}. "
                    f"Retrying in {backoff}s..."
                )
                time.sleep(backoff)
                backoff = min(backoff * 2, MAX_BACKOFF)
            else:
                logger.error(f"All {max_retries} attempts failed")

    raise last_exception  # type: ignore[misc]


def fetch_imdb_tv_shows(
    imdb_watchlist_url: str,
    session: requests.Session,
    imdb_cookie: Optional[str] = None,
    max_pages: Optional[int] = None,
) -> list[dict[str, str]]:
    """
    Fetch IMDb watchlist pages and extract TV shows with their metadata.

    Args:
        imdb_watchlist_url: Base URL of the IMDb watchlist
        session: Requests session for connection pooling
        imdb_cookie: Optional cookie for private watchlists
        max_pages: Maximum number of pages to fetch (None = all pages)

    Returns:
        List of dicts with 'id', 'title', and 'type' keys

    Raises:
        ValidationError: If URL is invalid
        requests.RequestException: If fetching fails
    """
    validate_url(imdb_watchlist_url, "IMDb watchlist URL")

    headers = {
        "accept": "text/html",
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/91.0.4472.114 Safari/537.36"
        ),
    }
    if imdb_cookie:
        headers["cookie"] = imdb_cookie

    all_tv_shows: list[dict[str, str]] = []
    page_num = 1
    total_items_seen = 0

    while True:
        url = (
            imdb_watchlist_url
            if page_num == 1
            else f"{imdb_watchlist_url}{'&' if '?' in imdb_watchlist_url else '?'}page={page_num}"
        )

        logger.info(f"Fetching page {page_num}...")
        try:
            r = session.get(url, headers=headers, timeout=30)
        except requests.RequestException as e:
            logger.error(f"Failed to fetch page {page_num}: {e}")
            break

        if r.status_code != HTTP_OK:
            logger.warning(f"Failed to fetch page {page_num} (status {r.status_code})")
            break

        next_data_pattern = re.compile(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.DOTALL)
        match = next_data_pattern.search(r.text)

        if not match:
            logger.warning(f"Could not find __NEXT_DATA__ JSON on page {page_num}")
            if page_num == 1:
                logger.info("Falling back to regex extraction")
                matches = IMDB_ITEM_RE.findall(r.text)
                ttids = sorted(set(matches))
                logger.info(f"Found {len(ttids)} items via regex (type filtering not available)")
                return [{"id": ttid, "title": "Unknown", "type": "unknown"} for ttid in ttids]
            break

        try:
            data = json.loads(match.group(1))
            page_props = data.get("props", {}).get("pageProps", {})

            if page_num == 1:
                total_items = page_props.get("totalItems", 0)
                logger.info(f"Watchlist has {total_items} total items")
                if max_pages:
                    logger.info(f"Will fetch up to {max_pages} pages")

            main_data = page_props.get("mainColumnData", {}).get("predefinedList", {})
            list_search = main_data.get("titleListItemSearch", {})
            edges = list_search.get("edges", [])
            page_info = list_search.get("pageInfo", {})

            logger.info(f"  Found {len(edges)} items on page {page_num}")
            total_items_seen += len(edges)

            page_tv_shows = []
            for edge in edges:
                if "listItem" not in edge:
                    continue

                item = edge["listItem"]
                const_id = item.get("id")
                title = item.get("titleText", {}).get("text", "Unknown")
                title_type = item.get("titleType", {}).get("id", "unknown")

                if const_id and title_type in ["tvSeries", "tvMiniSeries", "tvMovie"]:
                    page_tv_shows.append({"id": const_id, "title": title, "type": title_type})

            logger.info(f"  Found {len(page_tv_shows)} TV shows on page {page_num}")
            all_tv_shows.extend(page_tv_shows)

            has_next_page = page_info.get("hasNextPage", False)

            if not has_next_page:
                logger.info("Reached end of watchlist (no more pages)")
                break

            if max_pages and page_num >= max_pages:
                logger.info(f"Reached max pages limit ({max_pages})")
                break

            page_num += 1
            time.sleep(0.5)

        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"Error parsing JSON data on page {page_num}: {e}")
            break

    logger.info("=== Summary ===")
    logger.info(f"Fetched {page_num} page(s), {total_items_seen} total items")
    logger.info(f"Found {len(all_tv_shows)} TV shows total")
    if all_tv_shows:
        sample = [f"{s['id']} - {s['title']}" for s in all_tv_shows[:5]]
        logger.info(f"First few TV shows: {sample}")

    return all_tv_shows


def sonarr_get(path: str, api_key: str, base: str, session: requests.Session) -> requests.Response:
    """Make a GET request to Sonarr API."""
    url = urljoin(base.rstrip("/") + "/", f"api/v3/{path.lstrip('/')}")
    return session.get(url, headers={"X-Api-Key": api_key, **HEADERS_JSON}, timeout=30)


def sonarr_post(
    path: str, api_key: str, base: str, json_body: dict[str, Any], session: requests.Session
) -> requests.Response:
    """Make a POST request to Sonarr API."""
    url = urljoin(base.rstrip("/") + "/", f"api/v3/{path.lstrip('/')}")
    return session.post(
        url, headers={"X-Api-Key": api_key, **HEADERS_JSON}, json=json_body, timeout=60
    )


def sonarr_lookup_series_by_imdb_id(
    imdb_id: str, api_key: str, base: str, session: requests.Session
) -> list[dict[str, Any]]:
    """
    Lookup a series in Sonarr by IMDb ID.

    Args:
        imdb_id: IMDb ID (e.g., tt1234567)
        api_key: Sonarr API key
        base: Sonarr base URL
        session: Requests session

    Returns:
        List of matching series (usually 0 or 1)
    """
    r = sonarr_get(f"series/lookup?term=imdb:{imdb_id}", api_key, base, session)
    r.raise_for_status()
    return r.json()  # type: ignore[no-any-return]


def sonarr_get_profiles(
    api_key: str, base: str, session: requests.Session
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Get quality and language profiles from Sonarr."""
    quality = sonarr_get("qualityprofile", api_key, base, session).json()
    try:
        language = sonarr_get("languageprofile", api_key, base, session).json()
    except Exception:
        language = []
    return quality, language


def find_profile_id(profiles: list[dict[str, Any]], name: str) -> Optional[int]:
    """Find profile ID by name."""
    for p in profiles:
        if p.get("name") == name:
            return p.get("id")
    return None


def sonarr_get_series_all(
    api_key: str, base: str, session: requests.Session
) -> list[dict[str, Any]]:
    """Get all series from Sonarr."""
    r = sonarr_get("series", api_key, base, session)
    r.raise_for_status()
    return r.json()  # type: ignore[no-any-return]


def sonarr_add_series(
    api_key: str,
    base: str,
    series: dict[str, Any],
    root_folder: str,
    quality_profile_id: int,
    language_profile_id: Optional[int],
    monitor: str,
    season_folders: bool,
    search_on_add: bool,
    session: requests.Session,
) -> dict[str, Any]:
    """
    Add a series to Sonarr.

    Args:
        api_key: Sonarr API key
        base: Sonarr base URL
        series: Series data from lookup
        root_folder: Root folder path
        quality_profile_id: Quality profile ID
        language_profile_id: Language profile ID (optional)
        monitor: Monitor strategy
        season_folders: Whether to use season folders
        search_on_add: Whether to search on add
        session: Requests session

    Returns:
        Added series data

    Raises:
        RuntimeError: If adding fails
    """
    payload: dict[str, Any] = {
        "tvdbId": series.get("tvdbId"),
        "tvMazeId": series.get("tvMazeId"),
        "title": series.get("title"),
        "titleSlug": series.get("titleSlug"),
        "images": series.get("images", []),
        "seasons": series.get("seasons", []),
        "rootFolderPath": root_folder,
        "qualityProfileId": quality_profile_id,
        "monitored": True,
        "seasonFolder": season_folders,
        "monitor": monitor,
        "addOptions": {
            "ignoreEpisodesWithFiles": False,
            "ignoreEpisodesWithoutFiles": False,
            "searchForMissingEpisodes": search_on_add,
        },
    }
    if language_profile_id is not None:
        payload["languageProfileId"] = language_profile_id

    r = sonarr_post("series", api_key, base, payload, session)
    if r.status_code in (HTTP_OK, HTTP_CREATED):
        return r.json()  # type: ignore[no-any-return]
    raise RuntimeError(f"Failed to add series: {r.status_code} {r.text}")


def main() -> None:
    """Main entry point."""
    args = parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    season_folders = not args.no_season_folders
    search_on_add = not args.no_search

    # Validate inputs
    try:
        validate_url(args.imdb_url, "IMDb watchlist URL")
        validate_url(args.sonarr_url, "Sonarr URL")
        validate_api_key(args.sonarr_api_key)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        raise SystemExit(1) from e

    # Create session for connection pooling
    session = requests.Session()
    session.headers.update({"User-Agent": f"imdb-watchlist-to-sonarr/{__version__}"})

    try:
        # 1) IMDb → list of TV shows
        logger.info(f"Fetching IMDb watchlist: {args.imdb_url}")
        tv_shows = fetch_imdb_tv_shows(args.imdb_url, session, args.imdb_cookie, args.max_pages)

        # 2) Sonarr profile IDs
        logger.info("Getting Sonarr profiles...")
        q_profiles, l_profiles = sonarr_get_profiles(args.sonarr_api_key, args.sonarr_url, session)
        qid = find_profile_id(q_profiles, args.quality_profile)
        if qid is None:
            raise SystemExit(f"Quality profile '{args.quality_profile}' not found in Sonarr")

        lid = None
        if args.language_profile:
            lid = find_profile_id(l_profiles, args.language_profile)
            if lid is None:
                logger.warning(
                    f"Language profile '{args.language_profile}' not found; "
                    "proceeding without it"
                )

        # 3) Get current Sonarr series to avoid duplicates
        logger.info("Getting current Sonarr series...")
        current_series = sonarr_get_series_all(args.sonarr_api_key, args.sonarr_url, session)
        current_by_imdb = {s.get("imdbId"): s for s in current_series if s.get("imdbId")}
        logger.info(f"Found {len(current_series)} series already in Sonarr")

        # 4) Lookup each TV show directly in Sonarr by IMDb ID
        logger.info(f"Looking up {len(tv_shows)} TV shows in Sonarr by IMDb ID...")
        to_add: list[dict[str, Any]] = []
        found_count = 0
        already_have_count = 0

        for i, show in enumerate(tv_shows, 1):
            imdb_id = show["id"]
            title = show["title"]

            if i % 50 == 0:
                logger.info(f"  Progress: {i}/{len(tv_shows)} shows processed...")

            if imdb_id in current_by_imdb:
                already_have_count += 1
                continue

            try:
                lookup = sonarr_lookup_series_by_imdb_id(
                    imdb_id, args.sonarr_api_key, args.sonarr_url, session
                )
                if lookup:
                    found_count += 1
                    to_add.append(lookup[0])
                time.sleep(0.1)
            except Exception as e:
                logger.warning(f"Could not lookup {imdb_id} ({title}): {e}")

        logger.info("Results:")
        logger.info(f"  Already in Sonarr: {already_have_count}")
        logger.info(f"  Found in Sonarr DB: {found_count}")
        logger.info(f"  Ready to add: {len(to_add)}")

        desired_imdb_ids = {show["id"] for show in tv_shows}

        # 5) Add missing series
        logger.info(f"{len(to_add)} new series to add to Sonarr")
        for series in to_add:
            name = series.get("title") or series.get("titleSlug")
            if args.dry_run:
                logger.info(f"[DRY-RUN] Would add: {name}")
                continue

            try:
                added = sonarr_add_series(
                    api_key=args.sonarr_api_key,
                    base=args.sonarr_url,
                    series=series,
                    root_folder=args.root_folder,
                    quality_profile_id=qid,
                    language_profile_id=lid,
                    monitor=args.monitor,
                    season_folders=season_folders,
                    search_on_add=search_on_add,
                    session=session,
                )
                logger.info(f"Added: {added.get('title')} (IMDb:{added.get('imdbId')})")
            except Exception as e:
                logger.error(f"Failed to add {name}: {e}")

        # 6) Optional: remove series that are not on IMDb watchlist anymore
        if args.remove_missing:
            extras = [s for s in current_series if s.get("imdbId") not in desired_imdb_ids]
            logger.info(f"{len(extras)} series in Sonarr not on IMDb list (would remove).")
            logger.info(
                "NOTE: This script shows them but does NOT delete "
                "(Sonarr deletes are dangerous)."
            )
            for s in extras[:50]:
                logger.info(f" - {s.get('title')} (IMDb:{s.get('imdbId')})")
            logger.info("If you really want deletion, do it manually in Sonarr.")

        logger.info("Done.")

    finally:
        session.close()


if __name__ == "__main__":
    main()
