﻿# whenwas

Python paketidir ki, verilmiş tarixdən bu günə qədər neçə il, ay, gün keçdiyini hesablayır.

## İstifadə nümunəsi

`python
from whenwas import years_ago

print(years_ago('2001-09-11'))
# 24 years, 1 month, 19 days ago
