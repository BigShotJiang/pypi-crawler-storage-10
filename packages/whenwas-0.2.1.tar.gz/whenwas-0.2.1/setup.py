from setuptools import setup, find_packages

setup(
    name='whenwas',
    version='0.2.1',  # 0.1.0 əvəzinə
    packages=find_packages(),
    install_requires=[],
    author='Eldar',
    author_email='eldar@example.com',
    description='Verilmiş tarixdən bu günə qədər neçə il, ay, gün keçdiyini hesablayır',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/seninusername/whenwas',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
