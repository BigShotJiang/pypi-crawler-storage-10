from datetime import date

def years_ago(date_string):
    """
    Verilmiş tarixdən bu günə qədər neçə il, ay, gün keçdiyini hesablayır.
    Format: "YYYY-MM-DD"
    """
    year, month, day = map(int, date_string.split("-"))
    past_date = date(year, month, day)
    today = date.today()

    delta_years = today.year - past_date.year
    delta_months = today.month - past_date.month
    delta_days = today.day - past_date.day

    if delta_days < 0:
        delta_months -= 1
        delta_days += (date(today.year, today.month, 1) - date(today.year, today.month - 1 if today.month > 1 else 12, 1)).days

    if delta_months < 0:
        delta_years -= 1
        delta_months += 12

    return f"{delta_years} years, {delta_months} months, {delta_days} days ago"
