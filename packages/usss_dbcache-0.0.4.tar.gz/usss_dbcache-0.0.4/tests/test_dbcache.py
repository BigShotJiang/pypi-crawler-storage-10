# test_dbcache.py
from pathlib import Path
from sqlalchemy import create_engine, text
from types import SimpleNamespace
from unittest.mock import patch, MagicMock
import dbcache
import io
import pandas as pd
import pytest
import sqlalchemy
import sys


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_df():
    return pd.DataFrame({"id": [1, 2, 3], "value": ["a", "b", "c"]})


@pytest.fixture
def tmp_engine(tmp_path):
    """Temporary SQLite engine for testing CacheManager behavior."""
    engine = create_engine(f"sqlite:///{tmp_path}/test.db")
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE cache (name TEXT PRIMARY KEY, data BLOB)"))
    return engine


# ---------------------------------------------------------------------------
# CacheManager Tests
# ---------------------------------------------------------------------------


class TestCacheManager:
    def test_serialize_and_deserialize_roundtrip(self, tmp_engine, sample_df):
        cm = dbcache.CacheManager(tmp_engine)
        data = cm._serialize_df_to_bytes(sample_df)
        assert isinstance(data, (bytes, bytearray))

        # Write/read roundtrip via parquet bytes
        df2 = cm._deserialize_df_from_bytes(data)
        pd.testing.assert_frame_equal(sample_df, df2)

    def test_cache_write_and_read(self, tmp_engine, sample_df):
        cm = dbcache.CacheManager(tmp_engine)
        data = cm._serialize_df_to_bytes(sample_df)

        cm._cache_write("test_table", data)
        result = cm._cache_read("test_table")

        assert result == data

    def test_cache_read_empty_on_miss(self, tmp_engine):
        cm = dbcache.CacheManager(tmp_engine)
        result = cm._cache_read("nonexistent_table")
        assert result == b""

    def test_table_read_calls_pandas_read_sql(self, tmp_engine):
        cm = dbcache.CacheManager(tmp_engine)
        with patch("pandas.read_sql", return_value=pd.DataFrame()) as mock_read_sql:
            cm._table_read("some_table", columns=["x"])
            mock_read_sql.assert_called_once()


# ---------------------------------------------------------------------------
# Config Tests
# ---------------------------------------------------------------------------


class TestConfig:
    # def test_parse_config_loads_yaml_and_env(self, tmp_path, monkeypatch):
    #     # Fake YAML config file
    #     config_file = tmp_path / "config.yml"
    #     config_file.write_text(
    #         "mysql_options: {host: localhost, user: test, password: pw, database: db}\n"
    #         "table_source: mytable\n"
    #     )
    #
    #     monkeypatch.setenv("LOGLEVEL", "DEBUG")
    #     argv = sys.argv
    #     sys.argv = []
    #     cfg = dbcache.Config(config_file)
    #     sys.argv = argv
    #     assert isinstance(cfg.config, dbcache.Namespace)
    #     assert cfg.config.mysql_options["host"] == "localhost"
    #     assert cfg.config.table_source == "mytable"

    def test_setup_logging_sets_basic_config(self):
        with patch("logging.basicConfig") as mock_basic:
            dbcache.Config._setup_logging(fmt="fmt", level="DEBUG")
            mock_basic.assert_called_once()


# ---------------------------------------------------------------------------
# Main Tests
# ---------------------------------------------------------------------------


class TestMain:
    @pytest.fixture
    def main_obj(self, tmp_engine):
        """Fake Main instance with injected engine + config."""
        cfg = SimpleNamespace(
            mysql_options={"host": "h", "user": "u", "password": "p", "database": "d"},
            mysql_database=None,
            mysql_host=None,
            mysql_user=None,
            mysql_password=None,
            table_source="mytable",
            columns=None,
            parse_dates=None,
        )
        main = dbcache.Main.__new__(dbcache.Main)
        main.config = cfg
        main.engine = tmp_engine
        main.cache_manager = dbcache.CacheManager(tmp_engine)
        return main

    def test_override_mysql_options_applies_overrides(self):
        cfg = SimpleNamespace(
            mysql_options={"host": "old"},
            mysql_database="db",
            mysql_host="newhost",
            mysql_user="usr",
            mysql_password="pw",
        )
        dbcache.Main.override_mysql_options(cfg)
        assert cfg.mysql_options["host"] == "newhost"
        assert cfg.mysql_options["database"] == "db"

    # def test_create_engine_builds_mysql_url(self, monkeypatch):
    #     cfg = SimpleNamespace(
    #         mysql_options={"host": "localhost", "user": "u", "password": "p", "database": "d"},
    #         mysql_database=None,
    #         mysql_host=None,
    #         mysql_user=None,
    #         mysql_password=None,
    #     )
    #     url = "fake_url"
    #     monkeypatch.setattr(dbcache, "create_engine", lambda url: f"ENGINE:{url}")
    #     main = dbcache.Main.__new__(dbcache.Main)
    #     main.config = cfg
    #     result = main._create_engine()
    #     assert "mysql+mysqlconnector://" in result.url

    def test_read_sql_cache_returns_cache_hit(self, main_obj, sample_df):
        cm = main_obj.cache_manager
        data = cm._serialize_df_to_bytes(sample_df)
        cm._cache_write("mytable", data)
        df = main_obj.read_sql_cache("mytable")
        pd.testing.assert_frame_equal(df, sample_df)

    def test_read_sql_cache_reads_source_when_cache_miss(self, main_obj, sample_df):
        cm = main_obj.cache_manager
        with patch.object(cm, "_cache_read", return_value=b"") as mock_read:
            with patch.object(cm, "_table_read", return_value=sample_df) as mock_table:
                df = main_obj.read_sql_cache("missing_table")
        assert isinstance(df, pd.DataFrame)
        mock_read.assert_called_once()
        mock_table.assert_called_once()

    def test_run_invokes_read_sql_cache(self, main_obj):
        with patch.object(main_obj, "read_sql_cache") as mock_read:
            main_obj._run()
            mock_read.assert_called_once()
