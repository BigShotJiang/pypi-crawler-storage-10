"""
Enhanced version of dbcache2.py with structured logging.
"""

from configargparse import Namespace, YAMLConfigFileParser  # type: ignore
from pandas.core.frame import DataFrame
from pathlib import Path
from sqlalchemy import create_engine, text
from sqlalchemy.engine.base import Engine
from typing import List, Tuple
import configargparse
import dotenv
import io
import logging
import mysql.connector
import pandas as pd
import sqlalchemy
import sys
import yaml

logger = logging.getLogger(__name__)

# --- Default log format ---
LOGFORMAT = "%(asctime)s %(levelname)s [%(module)s:%(lineno)d] %(funcName)s | %(message)s"


class CacheManager:
    """Manage caching data: retrieve from and/or update database cache table."""

    def __init__(self, engine: Engine):
        self.engine = engine

    def _cache_read(self, table_name: str) -> bytes:
        """Read compressed serialised DataFrame (bytes) from cache. If not present raises exception."""
        logger.debug("Fetching DataFrame for table '%(table_name)s'.", {"table_name": table_name})
        select_sql = text("SELECT data FROM cache WHERE name = :name")

        with self.engine.connect() as conn:
            result = conn.execute(select_sql, {"name": table_name}).fetchone()
            if result:
                data = result[0]
                logger.debug("Cache hit for table '%(table_name)s'.", {"table_name": table_name})
                return data
            else:
                logger.debug("Cache miss for '%(table_name)s'. ", {"table_name": table_name})
                return b""

    def _cache_write(self, table_name: str, data: bytes) -> None:
        """Write serialised compressed data to cache.
        Replace into cache to overwrite any existing entry.
        """
        logger.debug(table_name)
        with self.engine.begin() as conn:
            insert_sql = text("REPLACE INTO cache (name, data) VALUES (:name, :data)")
            conn.execute(insert_sql, {"name": table_name, "data": data})

    def _deserialize_df_from_bytes(self, data: bytes) -> DataFrame:
        """Deserialize gzip-compressed Parquet bytes to a DataFrame."""
        logger.debug(
            "Decompressing cached Parquet data (size=%(size)d bytes).", {"size": len(data)}
        )
        buffer = io.BytesIO(data)
        df = pd.read_parquet(buffer)
        logger.debug(
            "Deserialized DataFrame with %(rows)d rows and %(cols)d columns.",
            {"rows": len(df), "cols": len(df.columns)},
        )
        return df

    def _serialize_df_to_bytes(self, df: pd.DataFrame) -> bytes:
        """Serialize DataFrame to snappy-compressed Parquet bytes."""
        logger.debug(
            "Serializing DataFrame with %(rows)d rows and %(cols)d columns.",
            {"rows": len(df), "cols": len(df.columns)},
        )
        # Parquet cannot handle sqla quoted column names. Convert columns names to string.
        df.columns = [str(c) for c in df.columns]
        return df.to_parquet(index=False)

    def _table_read(self, table_name: str, **kwargs) -> DataFrame:
        """Read source table into a dataframe.
        kwargs are passed to pd.read_sql.
        See: https://pandas.pydata.org/docs/reference/api/pandas.read_sql.html
        Typically:
        columns: list, default: None
        index_col: str or list of str, optional, default: None
        parse_dates: list or dict, default: None
        """
        logger.debug(table_name)
        logger.debug(kwargs)
        with self.engine.begin() as conn:
            return pd.read_sql(table_name, conn, **kwargs)


class Config:
    """Load and manage configuration from files, CLI, and environment."""

    def __init__(self, secrets_file: Path) -> None:
        (self.config, unknownargs) = self._parse_config(secrets_file)
        self._setup_logging(fmt=self.config.logformat, level=self.config.loglevel)
        logger.warning("unknownargs %(unknownargs)s", {"unknownargs": unknownargs})

    @staticmethod
    def _parse_config(secrets_file: Path) -> Tuple[Namespace, str]:
        p = configargparse.ArgParser(
            config_file_parser_class=YAMLConfigFileParser,
            default_config_files=[secrets_file],
        )
        p.add(
            "--columns",
            env_var="COLUMNS",
            help="List of columns for pd.read_sql to select: comma separated. Default None (all)",
            type=lambda s: s.split(","),
        )
        p.add(
            "--loglevel",
            choices=["INFO", "WARNING", "DEBUG", "ERROR", "CRITICAL"],
            default="INFO",
            env_var="LOGLEVEL",
            help="Log level",
        )
        p.add("--logformat", default=LOGFORMAT, env_var="LOGFORMAT", help="Log format")
        p.add("--mysql_database", env_var="MYSQL_DATABASE")
        p.add("--mysql_host", env_var="MYSQL_HOST")
        p.add("--mysql_user", env_var="MYSQL_USER")
        p.add("--mysql_password", env_var="MYSQL_PASSWORD")
        p.add(
            "--mysql_options",
            env_var="MYSQL_OPTIONS",
            required=True,
            type=yaml.safe_load,
            help="MySQL options",
        )
        p.add(
            "--parse_dates",
            env_var="PARSE_DATES",
            help="List of columns for pd.read_sql to parse as dates, comma separated. Default None.",
            type=lambda s: s.split(","),
        )
        p.add("--table_source", env_var="TABLE_SOURCE", required=True)
        return p.parse_known_args()

    @staticmethod
    def _setup_logging(fmt: str, level: str) -> None:
        logging.basicConfig(
            level=getattr(logging, level.upper(), logging.INFO),
            format=fmt,
            stream=sys.stdout,
        )
        logger.debug("Logging initialized at level %(level)s.", {"level": level})


class Main:
    def __init__(self, config: Namespace):
        self.config = config
        self.engine = self._create_engine()
        self.cache_manager = CacheManager(self.engine)

    @staticmethod
    def override_mysql_options(config: Namespace):
        """Override the MySQL options based on the provided configuration.
        Updates specific fields like database, host, user, and password if available.
        """
        if config.mysql_database:
            config.mysql_options.update({"database": config.mysql_database})
        if config.mysql_host:
            config.mysql_options.update({"host": config.mysql_host})
        if config.mysql_password:
            config.mysql_options.update({"password": config.mysql_password})
        if config.mysql_user:
            config.mysql_options.update({"user": config.mysql_user})

    def _create_engine(self) -> Engine:
        """Create SQLAlchemy engine from config."""
        Main.override_mysql_options(self.config)
        database = self.config.mysql_options.get("database")
        host = self.config.mysql_options.get("host")
        password = self.config.mysql_options.get("password")
        user = self.config.mysql_options.get("user")

        db_url = f"mysql+mysqlconnector://{user}:{password}@{host}/{database}"
        engine = create_engine(db_url)
        # Sqlalchemy redacts password
        logger.debug("Creating SQLAlchemy engine for %(db_url)s", {"db_url": engine.url})
        return engine

    def read_sql_cache(
        self,
        table_name: str,
        columns: List[str] | None = None,
        parse_dates: List[str] | None = None,
    ) -> DataFrame:
        """Read and deserialise to DataFrame data from cache if present, otherwise read dataframe from source table, write to cache, return dataframe."""

        # Read DataFrame from cache if present
        try:
            logger.debug("Reading data from cache")
            data = self.cache_manager._cache_read(table_name)
            if data:
                logger.debug("Read data from cache")
                logger.debug("Deserialising data into a DataFrame")
                df = self.cache_manager._deserialize_df_from_bytes(data)
                logger.debug("Deserialised data into a DataFrame")
                return df
        except (sqlalchemy.exc.ProgrammingError, mysql.connector.errors.ProgrammingError) as e:
            logger.info(
                "Cache lookup failed for '%(table_name)s': %(error)s",
                {"table_name": table_name, "error": str(e)},
            )

        # Read DataFrame from source table
        logger.debug("Reading source data table")
        try:
            df = self.cache_manager._table_read(
                table_name, columns=columns, parse_dates=parse_dates
            )
            logger.debug("Read source data table")

            # Write DataFrame to cache
            data = self.cache_manager._serialize_df_to_bytes(df)
            logger.debug("Writing data to cache")
            try:
                self.cache_manager._cache_write(table_name, data)
                logger.debug("Wrote data to cache")
            except (sqlalchemy.exc.ProgrammingError, mysql.connector.errors.ProgrammingError) as e:
                logger.info(
                    "Failed write data to cache '%(table_name)s': %(error)s",
                    {"table_name": table_name, "error": str(e)},
                )
            return df
        except (sqlalchemy.exc.ProgrammingError, mysql.connector.errors.ProgrammingError) as e:
            logger.info(
                "Failed to read source table '%(table_name)s': %(error)s",
                {"table_name": table_name, "error": str(e)},
            )
            raise

    def _run(self):
        """Main entrypoint for cache handling."""
        table_name = self.config.table_source
        logger.debug(
            "Starting data retrieval for table '%(table_name)s'.", {"table_name": table_name}
        )
        columns = self.config.columns
        parse_dates = self.config.parse_dates
        self.read_sql_cache(table_name, columns=columns, parse_dates=parse_dates)


if __name__ == "__main__":
    dotenv.load_dotenv(override=True)
    SECRETS_FILE = Path(__file__).resolve().parent.parent.parent / "secrets" / "dbcache_secrets.yml"
    CONFIG = Config(SECRETS_FILE)
    MAIN = Main(CONFIG.config)
    MAIN._run()
    logger.debug("Program complete.")
