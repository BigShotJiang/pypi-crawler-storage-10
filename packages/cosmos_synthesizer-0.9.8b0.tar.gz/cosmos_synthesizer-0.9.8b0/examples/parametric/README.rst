Parametric galaxy examples
--------------------------
