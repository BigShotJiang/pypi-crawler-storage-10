Imaging examples
----------------
