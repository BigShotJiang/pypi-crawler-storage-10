"""Grokipedia API - A Python client for accessing Grokipedia content."""

from .client import GrokipediaClient

__version__ = "0.1.0"
__all__ = ["GrokipediaClient"]

