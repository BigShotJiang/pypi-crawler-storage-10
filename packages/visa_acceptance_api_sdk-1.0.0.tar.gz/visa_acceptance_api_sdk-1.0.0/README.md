
# Getting Started with Visa Acceptance Merged Spec

## Introduction

All Visa Acceptance API specs merged together. These are available at https://developer.visaacceptance.com/api/reference/api-reference.html

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install visa-acceptance-api-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/visa-acceptance-api-sdk/1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `HttpClient` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| proxy_settings | [`ProxySettings`](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |

The API client can be initialized as follows:

```python
from visaacceptancemergedspec.configuration import Environment
from visaacceptancemergedspec.visaacceptancemergedspec_client import VisaacceptancemergedspecClient

client = VisaacceptancemergedspecClient(
    environment=Environment.PRODUCTION
)
```

## List of APIs

* [Customer Shipping Address](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/customer-shipping-address.md)
* [Customer Payment Instrument](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/customer-payment-instrument.md)
* [Payment Instrument](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/payment-instrument.md)
* [Instrument Identifier](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/instrument-identifier.md)
* [Unified Checkout Capture Context](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/unified-checkout-capture-context.md)
* [Transient Token Data](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/transient-token-data.md)
* [Tokenized Card](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/tokenized-card.md)
* [Payments](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/payments.md)
* [Capture](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/capture.md)
* [Reversal](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/reversal.md)
* [Refund](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/refund.md)
* [Credit](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/credit.md)
* [Void](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/void.md)
* [Transaction Batches](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/transaction-batches.md)
* [Billing Agreements](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/billing-agreements.md)
* [Orders](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/orders.md)
* [Payment-Tokens](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/payment-tokens.md)
* [Customer](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/customer.md)
* [Token](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/token.md)
* [Transaction Details](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/controllers/transaction-details.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/proxy-settings.md)

### HTTP

* [HttpResponse](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/http-response.md)
* [HttpRequest](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/sdks-io/visa-python-sdk/tree/1.0.0/doc/unix-date-time.md)

