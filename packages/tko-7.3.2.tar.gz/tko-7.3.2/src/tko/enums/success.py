import enum

class Success(enum.Enum):
    RANDOM = "RANDOM"
    FIXED = "FIXED"