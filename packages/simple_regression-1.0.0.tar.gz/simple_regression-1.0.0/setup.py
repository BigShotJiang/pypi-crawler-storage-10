
from setuptools import setup, find_packages

setup(
    name="simple_regression",
    version="1.0.0",
    description="Simple Linear Regression from scratch",
    author="BOUACHERI AHMED",
    packages=find_packages(),
    install_requires=[],
)
