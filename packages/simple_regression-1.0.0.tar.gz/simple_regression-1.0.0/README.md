# Simple Regression Package
A simple linear regression implementation from scratch.