"""Tests for GitDo."""
