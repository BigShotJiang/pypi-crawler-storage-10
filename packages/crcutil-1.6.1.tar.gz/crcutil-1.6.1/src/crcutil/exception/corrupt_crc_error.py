class CorruptCrcError(Exception):
    pass
