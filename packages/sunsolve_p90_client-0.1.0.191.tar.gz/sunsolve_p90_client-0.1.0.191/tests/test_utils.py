"""Test utilities and common mocks for the test suite."""

import grpc


class MockRpcError(grpc.RpcError):
    """Mock gRPC error for testing error handling.

    This class can be used across all test files to simulate
    gRPC errors with specific status codes and details.

    Example:
        error = MockRpcError(grpc.StatusCode.UNAUTHENTICATED, "Auth failed")
        client._handle_grpc_error(error, 30.0)
    """

    def __init__(self, status_code: grpc.StatusCode, details: str = "Mock error"):
        """Initialize mock gRPC error.

        Args:
            status_code: The gRPC status code to return
            details: The error details message
        """
        super().__init__()
        self._status_code = status_code
        self._details = details

    def code(self):  # pylint: disable=invalid-name
        """Return the gRPC status code."""
        return self._status_code

    def details(self):  # pylint: disable=invalid-name
        """Return the error details."""
        return self._details
