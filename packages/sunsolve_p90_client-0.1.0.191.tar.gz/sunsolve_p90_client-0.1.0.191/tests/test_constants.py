"""Constants for test modules to reduce duplication and improve maintainability."""

# Module paths for patching
P90_CLIENT_MODULE = "pvl_p90_client.client.p90_client"
PVL_LOGIN_MODULE = "pvl_p90_client.helpers.pvl_login"
REQUEST_HELPERS_MODULE = "pvl_p90_client.helpers.request_helpers"

# Common patch targets for p90_client module
P90_CLIENT_GRPC_STUB = f"{P90_CLIENT_MODULE}.uncertainty_grpc_client.UncertaintyStub"
P90_CLIENT_GRPC_SECURE_CHANNEL = f"{P90_CLIENT_MODULE}.grpc.secure_channel"
P90_CLIENT_SSL_CONTEXT = f"{P90_CLIENT_MODULE}.ssl.create_default_context"
P90_CLIENT_SSL_CREDENTIALS = f"{P90_CLIENT_MODULE}.grpc.ssl_channel_credentials"
P90_CLIENT_LOGGING = f"{P90_CLIENT_MODULE}.logging"

# Common patch targets for pvl_login module
PVL_LOGIN_REQUESTS_POST = f"{PVL_LOGIN_MODULE}.requests.post"
PVL_LOGIN_REQUESTS_GET = f"{PVL_LOGIN_MODULE}.requests.get"

# Common patch targets for request_helpers module
REQUEST_HELPERS_REQUESTS_POST = f"{REQUEST_HELPERS_MODULE}.requests.post"
REQUEST_HELPERS_REQUESTS_GET = f"{REQUEST_HELPERS_MODULE}.requests.get"
