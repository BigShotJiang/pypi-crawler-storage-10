"""
Functions for loading datasets
"""
from pathlib import Path
import pandas as pd
from dataidea.utils.timing import timer

@timer
def load_csv(file_path):
    """
    Load a CSV dataset with execution timing.

    Parameters:
    -----------
    file_path : str or Path
        The path to the CSV file to load

    Returns:
    --------
    pandas.DataFrame
        The loaded dataset

    Raises:
    -------
    FileNotFoundError
        If the CSV file cannot be found

    Example:
    --------
    >>> df = load_csv('data.csv')
    load_csv took 0.123 seconds to execute
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"CSV file not found: {file_path}")
    return pd.read_csv(file_path)

@timer
def load_excel(file_path, sheet_name=0):
    """
    Load an Excel dataset with execution timing.

    Parameters:
    -----------
    file_path : str or Path
        The path to the Excel file to load
    sheet_name : str or int, default=0
        The sheet name or index to load

    Returns:
    --------

    pandas.DataFrame
        The loaded dataset

    Raises:
    -------
    FileNotFoundError
        If the Excel file cannot be found

    Example:
    --------
    >>> df = load_excel('data.xlsx')
    load_excel took 0.456 seconds to execute
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"Excel file not found: {file_path}")
    return pd.read_excel(file_path, sheet_name=sheet_name)

def load_dataset(name=None, inbuilt=True, file_type=None):
    """
    Easily load datasets that are inbuilt in DATAIDEA or custom datasets.

    Parameters:
    -----------
    name : str
        The name of the dataset (e.g., 'demo', 'fpl', 'music', 'titanic')
        If inbuilt=True, this is the name of the dataset without extension
        If inbuilt=False, this is the path to the file
    inbuilt : bool, default=True
        Whether to load a built-in dataset or a custom dataset
    file_type : str, default=None
        For custom datasets, the file type (e.g., 'csv', 'excel')
        Required when inbuilt=False

    Returns:
    --------
    pandas.DataFrame
        The loaded dataset

    Raises:
    -------
    TypeError
        If file_type is not specified when inbuilt=False
    FileNotFoundError
        If the dataset cannot be found

    Note:
    -----
    This function delegates to load_csv() or load_excel() which include timing.
    """
    if inbuilt:
        package_dir = Path(__file__).parent.parent
        data_path = package_dir / 'resources' / 'datasets' / f'{name}.csv'
        if not data_path.exists():
            raise FileNotFoundError(f"Built-in dataset '{name}' not found")
        return load_csv(data_path)

    if file_type is None:
        raise TypeError('The file type was not specified for custom dataset')

    if file_type.lower() == 'csv':
        return load_csv(name)

    if file_type.lower() == 'excel':
        return load_excel(name)

    raise ValueError(f"Unsupported file type: {file_type}")

__all__ = ['load_dataset', 'load_csv', 'load_excel']
