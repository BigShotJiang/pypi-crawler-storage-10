"""
Input/Output functionality for loading and saving data
"""
from dataidea.io.datasets import load_dataset, load_csv, load_excel

__all__ = ['load_dataset', 'load_csv', 'load_excel']
