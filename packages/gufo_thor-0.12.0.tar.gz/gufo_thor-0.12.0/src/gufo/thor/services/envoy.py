# ---------------------------------------------------------------------
# Gufo Thor: envoy service
# ---------------------------------------------------------------------
# Copyright (C) 2023-25, Gufo Labs
# ---------------------------------------------------------------------
"""
envoy service.

Attributes:
    eenvoy: envoy service singleton.
"""

# Python modules
import http.client
import os
import ssl
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

# Third-party modules
import certifi

# Gufo Thor modules
from ..artefact import Artefact
from ..config import Config, ServiceConfig
from ..error import CancelExecution
from ..log import logger
from ..utils import is_test, write_file
from .base import BaseService

envoy_settings = Artefact("envoy-settings", Path("etc", "envoy", "envoy.yaml"))
envoy_cert = Artefact("envoy-cert", Path("etc", "envoy", "ssl", "noc.crt"))
envoy_key = Artefact("envoy-key", Path("etc", "envoy", "ssl", "noc.key"))
envoy_ca_cert = Artefact(
    "envoy-ca-cert", Path("etc", "envoy", "ssl", "ca.crt")
)

HTTP_OK = 200
HTTPS = 443


@dataclass
class DomainInfo(object):
    """
    Information for preconfigured domains.

    Attributes:
        domain: Domain name.
        csr_proxy: CSR Proxy URL
        subject: CSR subject.
    """

    domain: str
    csr_proxy: str
    subject: str


DOMAINS = {
    "go.getnoc.com": DomainInfo(
        domain="go.getnoc.com",
        csr_proxy="csr-proxy.getnoc.com",
        subject="CN=go.getnoc.com",
    )
}


@dataclass
class Route(object):
    """
    routes part of config.

    Attributes:
        name: Service name.
        prefix: HTTP prefix.
        disable_auth: Disable external authorization.
        prefix_rewite: Rewrite prefix, if set.
        redirect_to: Redirect to path, if matched.
        no_cache: Add headers which disable caching.
        is_service: Expose to `clusters` section.
    """

    name: str
    prefix: str
    disable_auth: bool
    prefix_rewrite: Optional[str] = None
    redirect_to: Optional[str] = None
    no_cache: bool = False
    is_service: bool = True

    @property
    def cluster(self: "Route") -> str:
        """Get cluster name."""
        if self.name == "/index.html":
            return "static_cluster"
        return f"{self.name}_cluster"


class EnvoyService(BaseService):
    """envoy service."""

    name = "envoy"
    compose_image = "envoyproxy/envoy:v1.36.0"
    # compose_depends_condition = ComposeDependsCondition.HEALTHY
    # compose_healthcheck = {
    #     "test": ["CMD", "envoy", "healthcheck", "--ping"],
    #     "interval": "3s",
    #     "timeout": "2s",
    #     "retries": 3,
    # }
    compose_configs = [
        envoy_settings.at(Path("/", "etc", "envoy", "envoy.yaml")),
        envoy_cert.at(Path("/", "etc", "envoy", "ssl", "noc.crt")),
        envoy_key.at(Path("/", "etc", "envoy", "ssl", "noc.key")),
    ]
    SUBJ_PATH = Path("etc", "envoy", "ssl", "domain_name.txt")
    RSA_KEY_SIZE = 4096
    CERT_DAYS = 3650

    def get_compose_networks(
        self: "EnvoyService", config: Config, svc: Optional[ServiceConfig]
    ) -> Dict[str, Any]:
        """Get networks section."""
        r = super().get_compose_networks(config, svc)
        if "noc" not in r:
            r["noc"] = {}
        r["noc"]["aliases"] = ["envoy", config.expose.domain_name]
        return r

    def get_compose_ports(
        self: "EnvoyService", config: Config, svc: Optional[ServiceConfig]
    ) -> Optional[List[str]]:
        """Get ports section."""
        if config.expose.web:
            return [config.expose.web.docker_compose_port(443)]
        return None

    def prepare_compose_config(
        self: "EnvoyService",
        config: Config,
        svc: Optional[ServiceConfig],
        services: List["BaseService"],
    ) -> None:
        """Generate config."""
        # Generate domain_name_and_port
        if not config.expose.web or config.expose.web.port == HTTPS:
            domain_name_and_port = config.expose.domain_name
        else:
            domain_name_and_port = (
                f"{config.expose.domain_name}:{config.expose.web.port}"
            )
        # Generate routes
        routes: List[Route] = []
        web_routes: List[Route] = []
        for s in services:
            prefix = s.get_expose_http_prefix(config, None)
            if not prefix:
                continue
            if s.name == "web":
                # Add redirect from legacy desktop
                web_routes.append(
                    Route(
                        name="Redirect /main/desktop/ -> /index.html",
                        prefix="/main/desktop/",
                        disable_auth=True,
                        redirect_to="/index.html",
                        is_service=False,
                    )
                )
                # Add redirect to desktop
                web_routes.append(
                    Route(
                        name="Redirect / -> /index.html",
                        prefix="/",
                        disable_auth=True,
                        redirect_to="/index.html",
                        is_service=False,
                    )
                )
                index_html = (
                    f"/index.{config.noc.theme}.{config.noc.language}.html"
                )
                # Route to proper index
                web_routes.append(
                    Route(
                        name="/index.html",
                        prefix="/index.html",
                        prefix_rewrite=index_html,
                        disable_auth=True,
                        no_cache=True,
                        is_service=False,
                    )
                )
                web_routes.append(
                    Route(
                        name=s.name,
                        prefix=prefix,
                        disable_auth=not s.require_http_auth,
                        prefix_rewrite=s.rewrite_http_prefix,
                    )
                )
            else:
                routes.append(
                    Route(
                        name=s.name,
                        prefix=prefix,
                        disable_auth=not s.require_http_auth,
                        prefix_rewrite=s.rewrite_http_prefix,
                    )
                )

        routes = sorted(
            routes,
            key=lambda x: "---".join(
                y if y else "zzzzzzzz" for y in x.prefix.split("/")
            ),
        )
        routes.extend(web_routes)
        # Add desktop redirect, if necessary
        envoy_settings.write(
            self.render(
                "envoy.yaml",
                domain_name=config.expose.domain_name,
                domain_name_and_port=domain_name_and_port,
                enable_mtls=bool(config.expose.mtls_ca_cert),
                routes=routes,
                services=sorted({r.name for r in routes if r.is_service}),
            )
        )
        # Prepare TLS certificates
        if self._to_rebuild_certificate(config):
            self._rebuild_certificate(config)
        # Update mTLS CA
        if config.expose.mtls_ca_cert:
            envoy_ca_cert.copy_from(
                Path("assets") / config.expose.mtls_ca_cert
            )

    def _to_rebuild_certificate(self: "EnvoyService", config: Config) -> bool:
        """Check if SSL certificate must be rebuilt."""
        if not os.path.exists(self.SUBJ_PATH):
            return True
        with open(self.SUBJ_PATH) as fp:
            return fp.read() != self.get_cert_subj(config)

    def get_cert_subj(self: "EnvoyService", config: Config) -> str:
        """Get certificate subj."""
        return f"CN={config.expose.domain_name}"

    def _get_signed_csr(
        self: "EnvoyService", csr_proxy: str, csr: bytes
    ) -> bytes:
        """
        Sign certificate via CSR Proxy.

        Args:
            csr_proxy: CSR Proxy base url.
            csr: CSR body.

        Returns:
            Siged CSR.
        """
        conn = http.client.HTTPSConnection(
            csr_proxy,
            context=ssl.create_default_context(cafile=certifi.where()),
        )
        conn.request("POST", "/v1/sign", body=csr)
        resp = conn.getresponse()
        if resp.status == HTTP_OK:
            return resp.read()
        logger.error("Invalid response: %s", resp.status)
        logger.error("Failed to sign certificate")
        raise CancelExecution()

    def _get_self_signed_certificate(
        self: "EnvoyService", csr: bytes, private_key: bytes
    ) -> bytes:
        """
        Generate self-signed certificate.

        Args:
            csr: CSR body in PEM format.
            private_key: Private key in PEM format.

        Returns:
            Self-signed certificate.
        """
        from gufo.acme.clients.base import AcmeClient

        return AcmeClient.get_self_signed_certificate(
            csr, private_key, validity_days=3560
        )

    def _rebuild_certificate(self: "EnvoyService", config: Config) -> None:
        """Rebuild SSL certificates."""
        from gufo.acme.clients.base import AcmeClient

        # Generate private key
        logger.warning("Generating private key: %s", envoy_key.local_path)
        private_key = AcmeClient.get_domain_private_key()
        envoy_key.write(private_key.decode())
        # Create CSR
        logger.warning("Generating certificate signing request")
        csr = AcmeClient.get_domain_csr(config.expose.domain_name, private_key)
        # Sign
        di = DOMAINS.get(config.expose.domain_name)
        if di and not is_test():
            # Use CSR Proxy
            logger.warning("Signing certificate: %s", envoy_cert.local_path)
            cert = self._get_signed_csr(di.csr_proxy, csr)
        else:
            # Self-signed certificate
            logger.warning(
                "Certificate signing for domain %s is not supported",
                config.expose.domain_name,
            )
            logger.error(
                "Either change expose.domain to one of: %s", ", ".join(DOMAINS)
            )
            logger.error("Or allow self-signed certificate in browser")
            logger.error(
                "Or replace certificates in `etc/envoy/ssl` "
                "with properly signed one"
            )
            logger.warning("Generating self-signed certificate")
            cert = self._get_self_signed_certificate(csr, private_key)
        envoy_cert.write(cert.decode())
        # Write subj
        write_file(self.SUBJ_PATH, self.get_cert_subj(config))

    def get_compose_configs(
        self, config: Config, svc: Optional[ServiceConfig]
    ) -> Optional[List[Artefact]]:
        """Generate configs."""
        r = super().get_compose_configs(config, svc) or []
        if config.expose.mtls_ca_cert:
            r.append(
                envoy_ca_cert.at(Path("/", "etc", "envoy", "ssl", "ca.crt"))
            )
        return r or None


envoy = EnvoyService()
