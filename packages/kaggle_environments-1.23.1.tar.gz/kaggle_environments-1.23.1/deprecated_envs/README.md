### Deprecation causes:
- chess: required a special Dockerfile with all other environments deleted.
- Lux AI s2: dependency conflicts due to `vec_noise`.
- LLM 20 questions: required gymnasium < 1.0.