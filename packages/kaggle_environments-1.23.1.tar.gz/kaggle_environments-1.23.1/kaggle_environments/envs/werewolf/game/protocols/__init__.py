# The line below register the protocols
from . import bid, chat, factory, vote

__all__ = ['bid', 'chat', 'factory', 'vote']
