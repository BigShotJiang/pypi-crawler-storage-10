# Lux AI Challenge Season 1

Welcome to the Kaggle Environments wrapped around the Lux AI Challenge Season 1! For more information or if you have an issues or want to make contributes, check out the main repository at https://github.com/Lux-AI-Challenge/Lux-Design-2021
