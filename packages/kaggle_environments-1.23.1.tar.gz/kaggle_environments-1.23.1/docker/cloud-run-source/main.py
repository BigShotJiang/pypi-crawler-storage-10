from kaggle_environments import http_request

def main(request):
    return http_request(request)
