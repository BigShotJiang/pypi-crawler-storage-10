from .contexts import context

plugin = dict(
    contexts=[context]
)
