"""Astronomy functions ported from Perl.

Functions for calculating mean/true longitudes and planetary equations.
"""

from __future__ import annotations
import math
from .mathutils import frac, zero360


# Mathematical constants (matching Perl)
PI = math.pi
PI2 = PI * 2
RAD = 180 / PI
EPS = 1e-6
EPSIRON = 1e-8


def arcsin(x: float) -> float:
    """Arc sine function matching Perl implementation.

    Returns values in degrees, not radians, to match Perl behavior.
    """
    if EPS < abs(1 - x * x):
        return math.atan2(x / math.sqrt(1 - x * x), 1) * RAD
    elif 0 < x:  # x is nearly 1
        return 90  # sin(90°) = 1
    else:  # x is nearly -1
        return 270  # sin(270°) = -1


def tan(x: float) -> float:
    """Tangent function matching Perl implementation."""
    return math.sin(x) / math.cos(x)


def sqr(x: float) -> float:
    """Square function matching Perl implementation."""
    return x * x


def get_mean_long(ahargana: float, rotation: float) -> float:
    """Calculate mean longitude for a planet.

    Args:
        ahargana: Days since epoch
        rotation: Yuga rotation value for the planet

    Returns:
        Mean longitude in degrees
    """
    # Using SuryaSiddhanta constants
    yuga_civil_days = 1577917828  # YugaRotation{'star'} - YugaRotation{'sun'}

    # Definition: 360 * frac(rotation * ahargana / yuga_civil_days)
    return 360 * frac(rotation * ahargana / yuga_civil_days)


def get_manda_equation(argument: float, planet: str) -> float:
    """Calculate manda equation for a planet."""
    planet_circumm = {
        "sun": 13 + 50 / 60,
        "moon": 31 + 50 / 60,
        "mercury": 29,
        "venus": 11.5,
        "mars": 73.5,
        "jupiter": 32.5,
        "saturn": 48.5,
    }

    circumm = planet_circumm[planet]
    if EPS < abs(1 - (circumm / 360 * math.sin(argument / RAD)) ** 2):
        return (
            math.atan2(
                circumm
                / 360
                * math.sin(argument / RAD)
                / math.sqrt(1 - (circumm / 360 * math.sin(argument / RAD)) ** 2),
                1,
            )
            * RAD
        )
    elif circumm / 360 * math.sin(argument / RAD) > 0:
        return PI / 2 * RAD
    else:
        return 3 * PI / 2 * RAD


def get_sighra_equation(anomaly: float, planet: str) -> float:
    """Calculate sighra equation for a planet.

    Args:
        anomaly: Sighra anomaly
        planet: Planet name

    Returns:
        Sighra equation correction in degrees
    """
    # Planetary constants (SuryaSiddhanta)
    planet_circums = {
        "sun": 0,
        "moon": 0,
        "mercury": 131.5,
        "venus": 261,
        "mars": 233.5,
        "jupiter": 71,
        "saturn": 39.5,
        "Candrocca": 0,
        "Rahu": 0,
    }

    circums = planet_circums.get(planet, 0)

    bhuja = circums / 360 * math.sin(anomaly / RAD) * RAD
    koti = circums / 360 * math.cos(anomaly / RAD) * RAD
    karna = math.sqrt(sqr(RAD + koti) + sqr(bhuja))

    return arcsin(bhuja / karna)


def get_true_long(ahargana: float, mean_solar_longitude: float, planet: str) -> float:
    """Calculate true longitude for a planet.

    Args:
        ahargana: Days since epoch
        mean_solar_longitude: Mean solar longitude
        planet: Planet name

    Returns:
        True longitude in degrees
    """
    # Planetary constants (SuryaSiddhanta)
    planet_apogee = {
        "sun": 77 + 17 / 60,
        "moon": 0,  # Will be set dynamically
        "mercury": 220 + 27 / 60,
        "venus": 79 + 50 / 60,
        "mars": 130 + 2 / 60,
        "jupiter": 171 + 18 / 60,
        "saturn": 236 + 37 / 60,
        "Candrocca": 0,
        "Rahu": 0,
    }

    planet_sighra = {
        "sun": 4320000,
        "moon": 0,
        "mercury": 17937060,
        "venus": 7022376,
        "mars": 4320000,
        "jupiter": 4320000,
        "saturn": 4320000,
        "Candrocca": 0,
        "Rahu": 0,
    }

    apogee = planet_apogee.get(planet, 0)
    sighra_rotation = planet_sighra.get(planet, 0)

    # Calculate mean position for the planet
    if planet in ["mercury", "venus"]:
        planet_mean_position = mean_solar_longitude
    else:
        planet_mean_position = get_mean_long(ahargana, 4320000)  # Sun's rotation

    # First sighra correction
    if planet in ["mercury", "venus"]:
        anomaly1 = get_mean_long(ahargana, sighra_rotation) - mean_solar_longitude
    else:
        anomaly1 = get_mean_long(ahargana, sighra_rotation) - planet_mean_position

    equ1 = get_sighra_equation(anomaly1, planet)

    # First manda correction
    mean_long1 = planet_mean_position + equ1 / 2
    argument = mean_long1 - apogee
    equ2 = get_manda_equation(argument, planet)

    # Second manda correction
    mean_long2 = mean_long1 - equ2 / 2
    argument = mean_long2 - apogee
    equ3 = get_manda_equation(argument, planet)

    # Second sighra correction
    mean_long3 = planet_mean_position - equ3
    anomaly2 = get_mean_long(ahargana, sighra_rotation) - mean_long3
    equ4 = get_sighra_equation(anomaly2, planet)
    equ5 = 0

    return zero360(mean_long3 + equ4 + equ5)


def get_true_solar_longitude(ahargana: float) -> float:
    """Calculate true solar longitude.

    Args:
        ahargana: Days since epoch

    Returns:
        True solar longitude in degrees
    """
    mean_solar_longitude = get_mean_long(ahargana, 4320000)  # Sun's rotation
    return zero360(
        mean_solar_longitude - get_manda_equation(mean_solar_longitude - (77 + 17 / 60), "sun")
    )


def get_true_lunar_longitude(ahargana: float) -> float:
    """Calculate true lunar longitude.

    Args:
        ahargana: Days since epoch

    Returns:
        True lunar longitude in degrees (not normalized to [0, 360))
    """
    mean_lunar_longitude = get_mean_long(ahargana, 57753336)  # Moon's rotation
    lunar_apogee = get_mean_long(ahargana, 488203) + 90  # Candrocca rotation + 90
    return mean_lunar_longitude - get_manda_equation(mean_lunar_longitude - lunar_apogee, "moon")
