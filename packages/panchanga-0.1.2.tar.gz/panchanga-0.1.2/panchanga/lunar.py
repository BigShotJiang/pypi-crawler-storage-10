"""Lunar calculation functions ported from Perl.

Functions for calculating tithi, nakshatra, yoga, karana, and lunar months.
"""

from __future__ import annotations
from .mathutils import trunc, frac, zero360


def get_tithi(true_lunar_longitude: float, true_solar_longitude: float) -> float:
    """Calculate tithi (lunar day) from true longitudes.

    Args:
        true_lunar_longitude: True lunar longitude in degrees
        true_solar_longitude: True solar longitude in degrees

    Returns:
        Tithi value (0-30)
    """
    elong = true_lunar_longitude - true_solar_longitude
    elong = zero360(elong)
    return elong / 12


def get_tithi_set(tithi: float) -> tuple[int, float]:
    """Get tithi day and fractional part.

    Args:
        tithi: Tithi value

    Returns:
        Tuple of (tithi_day, fractional_tithi)
    """
    tithi_day = trunc(tithi) + 1
    ftithi = frac(tithi)
    return (tithi_day, ftithi)


def set_sukla_krsna(tithi_day: int) -> tuple[int, str, str]:
    """Determine sukla/krsna paksa from tithi day.

    Args:
        tithi_day: Tithi day (1-30)

    Returns:
        Tuple of (adjusted_tithi_day, sukla_krsna, paksa)
    """
    if 15 < tithi_day:
        tithi_day = tithi_day - 15
        paksa = "Krsnapaksa"
    else:
        paksa = "Suklapaksa"

    sukla_krsna = get_sukla_krsna(paksa)
    return (tithi_day, sukla_krsna, paksa)


def get_sukla_krsna(paksa: str) -> str:
    """Get sukla/krsna from paksa.

    Args:
        paksa: Paksa ('Suklapaksa' or 'Krsnapaksa')

    Returns:
        'Sukla' or 'Krsna'
    """
    if paksa == "Suklapaksa":
        return "Sukla"
    else:
        return "Krsna"


def get_naksatra_name(true_lunar_longitude: float) -> str:
    """Get nakshatra name from true lunar longitude.

    Args:
        true_lunar_longitude: True lunar longitude in degrees

    Returns:
        Nakshatra name
    """
    naksatra_names = {
        0: "Asvini",
        1: "Bharani",
        2: "Krttika",
        3: "Rohini",
        4: "Mrgasira",
        5: "Ardra",
        6: "Punarvasu",
        7: "Pusya",
        8: "Aslesa",
        9: "Magha",
        10: "P-phalguni",
        11: "U-phalguni",
        12: "Hasta",
        13: "Citra",
        14: "Svati",
        15: "Visakha",
        16: "Anuradha",
        17: "Jyestha",
        18: "Mula",
        19: "P-asadha",
        20: "U-asadha",
        21: "Sravana",
        22: "Dhanistha",
        23: "Satabhisaj",
        24: "P-bhadrapada",
        25: "U-bhadrapada",
        26: "Revati",
        27: "Asvini",
    }

    naksatra_index = trunc(true_lunar_longitude * 27 / 360) % 28
    return naksatra_names[naksatra_index]


def get_yoga_name(true_solar_longitude: float, true_lunar_longitude: float) -> str:
    """Get yoga name from true solar and lunar longitudes.

    Args:
        true_solar_longitude: True solar longitude in degrees
        true_lunar_longitude: True lunar longitude in degrees

    Returns:
        Yoga name
    """
    yoga_names = {
        0: "viSkambha",
        1: "prIti",
        2: "AyuSmat",
        3: "saubhAgya",
        4: "zobhana",
        5: "atigaNDa",
        6: "sukarman",
        7: "dhRti",
        8: "zUla",
        9: "gaNDa",
        10: "vRddhi",
        11: "dhruva",
        12: "vyAghAta",
        13: "harSaNa",
        14: "vajra",
        15: "siddhi",
        16: "vyatIpAta",
        17: "varIyas",
        18: "parigha",
        19: "ziva",
        20: "siddha",
        21: "sAdhya",
        22: "zubha",
        23: "zukla",
        24: "brahman",
        25: "aindra",
        26: "vaidhRti",
        27: "viSkambha",
    }

    yoga1 = zero360(true_solar_longitude + true_lunar_longitude)
    yoga = trunc(yoga1 * 27 / 360) % 28
    return yoga_names[yoga]


def get_karana_name(tithi: float) -> str:
    """Get karana name from tithi.

    Args:
        tithi: Tithi value

    Returns:
        Karana name
    """
    karana_names = {
        0: "kiMstughna",
        1: "bava      ",
        2: "bAlava    ",
        3: "kaulava   ",
        4: "taitila   ",
        5: "gara      ",
        6: "vaNij     ",
        7: "viSTi     ",
        8: "zakuni    ",
        9: "catuSpada ",
        10: "nAga      ",
    }

    karana = trunc(2 * tithi)

    if karana == 0:
        return karana_names[0]
    elif karana < 57:
        karana = karana % 7
        if karana == 0:
            return karana_names[7]
        else:
            return karana_names[karana]
    elif karana == 57:
        return karana_names[8]
    elif karana == 58:
        return karana_names[9]
    elif karana == 59:
        return karana_names[10]
    else:
        return karana_names[0]  # Fallback


def three_relation(a: float, b: float, c: float) -> int:
    """Determine the relationship between three values.

    Args:
        a: First value
        b: Second value
        c: Third value

    Returns:
        1 if a < b < c, -1 if c < b < a, 0 otherwise
    """
    if (a < b) and (b < c):
        return 1
    elif (c < b) and (b < a):
        return -1
    else:
        return 0


def get_elong(ahargana: float) -> float:
    """Get elongation between Moon and Sun.

    Args:
        ahargana: Days since epoch

    Returns:
        Elongation in degrees
    """
    from .astronomy import get_true_solar_longitude, get_true_lunar_longitude

    tllong = get_true_lunar_longitude(ahargana)
    tslong = get_true_solar_longitude(ahargana)

    elong = tllong - tslong
    elong = zero360(elong)

    if 180 < elong:
        elong = 360 - elong

    return elong


def find_conj(leftx: float, lefty: float, rightx: float, righty: float) -> float:
    """Find conjunction using bisection method.

    Args:
        leftx: Left ahargana
        lefty: Left elongation
        rightx: Right ahargana
        righty: Right elongation

    Returns:
        Ahargana of conjunction
    """
    epsiron = 1e-8

    width = (rightx - leftx) / 2
    centrex = (rightx + leftx) / 2

    if width < epsiron:
        return centrex
    else:
        centrey = get_elong(centrex)
        relation = three_relation(lefty, centrey, righty)

        if relation < 0:
            rightx = rightx + width
            righty = get_elong(rightx)
            return find_conj(centrex, centrey, rightx, righty)
        elif relation > 0:
            leftx = leftx - width
            lefty = get_elong(leftx)
            return find_conj(leftx, lefty, centrex, centrey)
        else:
            leftx = leftx + width / 2
            lefty = get_elong(leftx)
            rightx = rightx - width / 2
            righty = get_elong(rightx)
            return find_conj(leftx, lefty, rightx, righty)


def get_conj(ahargana: float) -> float:
    """Get conjunction longitude for given ahargana.

    Args:
        ahargana: Days since epoch

    Returns:
        Conjunction longitude in degrees
    """
    conj_ahargana = find_conj(
        ahargana - 2, get_elong(ahargana - 2), ahargana + 2, get_elong(ahargana + 2)
    )

    # Return the solar longitude at the conjunction
    from .astronomy import get_true_solar_longitude

    return get_true_solar_longitude(conj_ahargana)


def get_clong(ahargana: float, tithi: float) -> float:
    """Get last conjunction longitude.

    Args:
        ahargana: Days since epoch
        tithi: Current tithi

    Returns:
        Last conjunction longitude
    """
    # Constants from Perl
    YUGA_CIVIL_DAYS = 1577917828
    YUGA_ROTATION_MOON = 57753336
    YUGA_ROTATION_SUN = 4320000

    new_new = YUGA_CIVIL_DAYS / (YUGA_ROTATION_MOON - YUGA_ROTATION_SUN)
    ahar = ahargana - tithi * (new_new / 30)

    # For now, use simple conjunction calculation
    # TODO: Implement caching like Perl does
    return get_conj(ahar)


def get_nclong(ahargana: float, tithi: float) -> float:
    """Get next conjunction longitude.

    Args:
        ahargana: Days since epoch
        tithi: Current tithi

    Returns:
        Next conjunction longitude
    """
    # Constants from Perl
    YUGA_CIVIL_DAYS = 1577917828
    YUGA_ROTATION_MOON = 57753336
    YUGA_ROTATION_SUN = 4320000

    new_new = YUGA_CIVIL_DAYS / (YUGA_ROTATION_MOON - YUGA_ROTATION_SUN)
    ahar = ahargana + (30 - tithi) * (new_new / 30)

    # For now, use simple conjunction calculation
    # TODO: Implement caching like Perl does
    return get_conj(ahar)


def get_adhimasa(clong: float, nclong: float) -> str:
    """Get adhimasa (leap month) prefix.

    Args:
        clong: Current conjunction longitude
        nclong: Next conjunction longitude

    Returns:
        "Adhika-" if leap month, "" otherwise
    """
    if trunc(clong / 30) == trunc(nclong / 30):
        return "Adhika-"
    else:
        return ""


def get_masa_num(tslong: float, clong: float) -> int:
    """Get lunar month number from solar and conjunction longitudes.

    Args:
        tslong: True solar longitude
        clong: Conjunction longitude

    Returns:
        Lunar month number (0-11)
    """
    masa_num = int(tslong / 30) % 12

    if (int(clong / 30) % 12) == masa_num:
        masa_num = masa_num + 1

    masa_num = (masa_num + 12) % 12
    return masa_num
