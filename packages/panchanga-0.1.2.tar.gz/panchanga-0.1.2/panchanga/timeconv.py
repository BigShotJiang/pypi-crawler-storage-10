"""Time conversion functions ported from Perl.

Functions for converting between modern dates, Julian days, and ahargana.
"""

from __future__ import annotations
from .mathutils import trunc


def modern_date_to_julian_day(year: int, month: int, day: int) -> float:
    """Convert modern date to Julian day number.

    Args:
        year: Year (e.g., 2024)
        month: Month (1-12)
        day: Day (1-31)

    Returns:
        Julian day number
    """
    if month < 3:
        year = year - 1
        month = month + 12

    julian_day = trunc(365.25 * year) + trunc(30.59 * (month - 2)) + day + 1721086.5

    if year < 0:
        julian_day = julian_day - 1
        if ((year % 4) == 0) and (3 <= month):
            julian_day = julian_day + 1

    if 2299160 < julian_day:
        julian_day = julian_day + trunc(year / 400) - trunc(year / 100) + 2

    return julian_day


def julian_day_to_modern_date(julian_day: float) -> tuple[int, int, int]:
    """Convert Julian day number to modern date.

    Args:
        julian_day: Julian day number

    Returns:
        Tuple of (year, month, day)
    """
    if julian_day < 2299239:
        return _julian_day_to_julian_date(julian_day)
    else:
        return _julian_day_to_gregorian_date(julian_day)


def _julian_day_to_julian_date(julian_day: float) -> tuple[int, int, int]:
    """Convert Julian day to Julian calendar date."""
    julian_int = trunc(julian_day) + 1402
    four_year_cycles = trunc((julian_int - 1) / 1461)
    remaining_days = julian_int - 1461 * four_year_cycles
    year_offset = trunc((remaining_days - 1) / 365) - trunc(remaining_days / 1461)
    adjusted_days = remaining_days - 365 * year_offset + 30
    month_factor = trunc(80 * adjusted_days / 2447)
    day = adjusted_days - trunc(2447 * month_factor / 80)
    month_adjustment = trunc(month_factor / 11)
    month = month_factor + 2 - 12 * month_adjustment
    year = 4 * four_year_cycles + year_offset + month_adjustment - 4716
    return (year, month, day)


def _julian_day_to_gregorian_date(julian_day: float) -> tuple[int, int, int]:
    """Convert Julian day to Gregorian calendar date."""
    adjusted_julian = julian_day + 68569
    century_cycles = trunc(adjusted_julian / 36524.25)
    remaining_century_days = adjusted_julian - trunc(36524.25 * century_cycles + 0.75)
    year_cycles = trunc((remaining_century_days + 1) / 365.2425)

    month_calculation = remaining_century_days - trunc(365.25 * year_cycles) + 31
    month_factor = trunc(month_calculation / 30.59)
    month_adjustment = trunc(month_factor / 11)
    day = trunc(month_calculation - trunc(30.59 * month_factor) + (julian_day - trunc(julian_day)))
    month = trunc(month_factor - 12 * month_adjustment + 2)
    year = trunc(100 * (century_cycles - 49) + year_cycles + month_adjustment)
    return (year, month, day)


def julian_day_to_ahargana(julian_day: float) -> float:
    """Convert Julian day to ahargana.

    Args:
        julian_day: Julian day number

    Returns:
        Ahargana (days since epoch)
    """
    return julian_day - 588465.50


def ahargana_to_julian_day(ahargana: float) -> float:
    """Convert ahargana to Julian day.

    Args:
        ahargana: Days since epoch

    Returns:
        Julian day number
    """
    return 588465.50 + ahargana
