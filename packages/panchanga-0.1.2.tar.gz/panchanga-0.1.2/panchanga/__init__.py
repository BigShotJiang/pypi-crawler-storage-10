"""Traditional Vedic calendar calculations based on Suryasiddhanta.

This library provides astronomical calculations for the traditional Vedic
calendar system (Panchanga), including:
- Date conversions between Gregorian and Vedic calendars
- Tithi (lunar day) calculations
- Naksatra (lunar mansion) calculations
- Yoga and Karana calculations
- Solar and lunar longitude calculations
- Samkranti (sun transit) calculations
"""

__version__ = "0.1.0"

# Core time conversions
from .timeconv import (
    modern_date_to_julian_day,
    julian_day_to_modern_date,
    julian_day_to_ahargana,
    ahargana_to_julian_day,
)

# Math utilities
from .mathutils import (
    trunc,
    frac,
    zero360,
)

# Calendar conversions
from .calendars import (
    ahargana_to_kali,
    kali_to_saka,
    saka_to_kali,
    saka_to_vikrama,
    vikrama_to_saka,
    kali_to_ahargana,
    get_masa_name,
    get_jovian_year_name,
    get_jovian_year_name_south,
    get_vikrama_saura_masa_name,
    get_vikrama_solar_year,
    get_all_era_years,
    get_all_era_years_from_saka,
    get_all_era_years_from_vikrama,
)

# Lunar calculations
from .lunar import (
    get_tithi,
    get_tithi_set,
    set_sukla_krsna,
    get_sukla_krsna,
    get_naksatra_name,
    get_yoga_name,
    get_karana_name,
    get_masa_num,
    get_elong,
    get_conj,
    get_clong,
    get_nclong,
    get_adhimasa,
    three_relation,
    find_conj,
)

# Solar calculations
from .solar import (
    get_true_solar_longitude,
    today_saura_masa_first_p,
    get_saura_masa_day,
    get_saura_masa_name,
    find_samkranti,
    get_next_samkranti_info,
)

# Astronomical calculations
from .astronomy import (
    get_true_lunar_longitude,
    get_mean_long,
    get_manda_equation,
    get_sighra_equation,
    get_true_long,
    arcsin,
    tan,
    sqr,
)

# Output formatting
from .output import (
    get_daylight_equation,
    get_sun_rise_time,
    get_ayana_amsa,
    format_sunrise_time,
    format_tithi,
    format_naksatra,
    format_yoga,
    format_era_years,
    format_ayanamsa,
    format_lunar_section,
    format_solar_section,
    format_vs_solar_section,
    format_lunar_details,
    format_longitude_degrees,
    format_verbose_output,
)

# Horoscope calculations
from .horoscope import (
    horoscope_calculation,
    declination,
    right_ascension,
    ascendant,
    format_lagna_degrees,
    format_horoscope_output,
)

# Note: get_true_solar_longitude is exported from both solar and astronomy modules
# We use the solar module version as the primary export

__all__ = [
    # Version
    "__version__",
    # Time conversions
    "modern_date_to_julian_day",
    "julian_day_to_modern_date",
    "julian_day_to_ahargana",
    "ahargana_to_julian_day",
    # Math utilities
    "trunc",
    "frac",
    "zero360",
    # Calendar conversions
    "ahargana_to_kali",
    "kali_to_saka",
    "saka_to_kali",
    "saka_to_vikrama",
    "vikrama_to_saka",
    "kali_to_ahargana",
    "get_masa_name",
    "get_jovian_year_name",
    "get_jovian_year_name_south",
    "get_vikrama_saura_masa_name",
    "get_vikrama_solar_year",
    "get_all_era_years",
    "get_all_era_years_from_saka",
    "get_all_era_years_from_vikrama",
    # Lunar
    "get_tithi",
    "get_tithi_set",
    "set_sukla_krsna",
    "get_sukla_krsna",
    "get_naksatra_name",
    "get_yoga_name",
    "get_karana_name",
    "get_masa_num",
    "get_elong",
    "get_conj",
    "get_clong",
    "get_nclong",
    "get_adhimasa",
    "three_relation",
    "find_conj",
    # Solar
    "get_true_solar_longitude",
    "today_saura_masa_first_p",
    "get_saura_masa_day",
    "get_saura_masa_name",
    "find_samkranti",
    "get_next_samkranti_info",
    # Astronomy
    "get_true_lunar_longitude",
    "get_mean_long",
    "get_manda_equation",
    "get_sighra_equation",
    "get_true_long",
    "arcsin",
    "tan",
    "sqr",
    # Output
    "get_daylight_equation",
    "get_sun_rise_time",
    "get_ayana_amsa",
    "format_sunrise_time",
    "format_tithi",
    "format_naksatra",
    "format_yoga",
    "format_era_years",
    "format_ayanamsa",
    "format_lunar_section",
    "format_solar_section",
    "format_vs_solar_section",
    "format_lunar_details",
    "format_longitude_degrees",
    "format_verbose_output",
    # Horoscope
    "horoscope_calculation",
    "declination",
    "right_ascension",
    "ascendant",
    "format_lagna_degrees",
    "format_horoscope_output",
]
