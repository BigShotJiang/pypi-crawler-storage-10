"""Calendar era conversions module for panchanga_py.

This module implements Kali ↔ Saka ↔ Vikrama conversions,
VS solar year rules, and related calendar functions following TDD methodology.
"""

from __future__ import annotations

from dataclasses import dataclass
from .mathutils import trunc

# Yuga constants (SuryaSiddhanta)
YUGA_ROTATION_SUN = 4320000
YUGA_CIVIL_DAYS = 1577917828  # YugaRotation{'star'} - YugaRotation{'sun'}


@dataclass
class SecondaryConstants:
    """Secondary constants calculated from primary constants."""

    yuga_adhimasa: float
    yuga_tithi: float
    yuga_ksayadina: float


def calculate_secondary_constants() -> SecondaryConstants:
    """Calculate secondary constants based on primary constants.

    Returns:
        SecondaryConstants: Calculated secondary constants
    """
    # Use the same constants as Perl implementation
    YugaRotationMoon = 57753336  # From Perl: $YugaRotation{'moon'}
    YugaRotationSun = 4320000  # From Perl: $YugaRotation{'sun'}
    YugaRotationStar = 1582237828  # From Perl: $YugaRotation{'star'}

    YugaSynodicMonth = YugaRotationMoon - YugaRotationSun  # moon - sun
    YugaCivilDays = YugaRotationStar - YugaRotationSun  # star - sun
    YugaAdhimasa = YugaSynodicMonth - 12 * YugaRotationSun
    YugaTithi = 30 * YugaSynodicMonth
    YugaKsayadina = YugaTithi - YugaCivilDays

    return SecondaryConstants(
        yuga_adhimasa=YugaAdhimasa, yuga_tithi=YugaTithi, yuga_ksayadina=YugaKsayadina
    )


# Era conversion constants
KALI_TO_SAKA_OFFSET = 3179
SAKA_TO_VIKRAMA_OFFSET = 135

# Lunar month names
MASA_NAMES = {
    0: "Caitra    ",
    1: "Vaisakha  ",
    2: "Jyaistha  ",
    3: "Asadha    ",
    4: "Sravana   ",
    5: "Bhadrapada",
    6: "Asvina    ",
    7: "Karttika  ",
    8: "Margasirsa",
    9: "Pausa     ",
    10: "Magha     ",
    11: "Phalguna  ",
}


def kali_to_saka(kali_year: int) -> int:
    """Convert Kali year to Saka year.

    Args:
        kali_year: Kali year

    Returns:
        Saka year
    """
    return kali_year - KALI_TO_SAKA_OFFSET


def saka_to_kali(saka_year: int) -> int:
    """Convert Saka year to Kali year.

    Args:
        saka_year: Saka year

    Returns:
        Kali year
    """
    return saka_year + KALI_TO_SAKA_OFFSET


def saka_to_vikrama(saka_year: int) -> int:
    """Convert Saka year to Vikrama year.

    Args:
        saka_year: Saka year

    Returns:
        Vikrama year
    """
    return saka_year + SAKA_TO_VIKRAMA_OFFSET


def vikrama_to_saka(vikrama_year: int) -> int:
    """Convert Vikrama year to Saka year.

    Args:
        vikrama_year: Vikrama year

    Returns:
        Saka year
    """
    return vikrama_year - SAKA_TO_VIKRAMA_OFFSET


def ahargana_to_kali(ahargana: float) -> int:
    """Convert ahargana to Kali year.

    Args:
        ahargana: Days since epoch

    Returns:
        Kali year
    """
    return trunc(ahargana * YUGA_ROTATION_SUN / YUGA_CIVIL_DAYS)


def kali_to_ahargana(kali_year: int, masa_num: int, tithi_day: int) -> float:
    """Convert Kali year, masa, and tithi to ahargana.

    Args:
        kali_year: Kali year
        masa_num: Lunar month number (0-11)
        tithi_day: Tithi day (1-15)

    Returns:
        Ahargana from Kali epoch to given date
    """
    # Calculate secondary constants
    constants = calculate_secondary_constants()

    sm = kali_year
    sm = sm * 12 + masa_num  # expired saura masas
    adhim = int(sm * constants.yuga_adhimasa / (12 * YUGA_ROTATION_SUN))  # expired adhimasas
    cm = sm + adhim  # expired candra masas
    tithi = 30 * cm + tithi_day - 1  # expired tithis
    avama = int(tithi * constants.yuga_ksayadina / constants.yuga_tithi)  # expired avamas

    return tithi - avama  # ahargana from Kali epoch to given date


def get_masa_name(masa_num: int) -> str:
    """Get lunar month name from month number.

    Args:
        masa_num: Lunar month number (0-11)

    Returns:
        Lunar month name
    """
    return MASA_NAMES[masa_num]


def get_vikrama_saura_masa_name(saura_num: int) -> str:
    """Map saura month to Vikram Samvat solar month name.

    Chaitra corresponds to Mina (saura=11), Vaisakha to Mesa (saura=0), etc.

    Args:
        saura_num: Solar month number (0-11)

    Returns:
        Vikram Samvat solar month name
    """
    vs_idx = (saura_num + 1) % 12
    return get_masa_name(vs_idx)


def get_vikrama_solar_year(vikrama_year: int, saura_masa_num: int) -> int:
    """Get Vikram Samvat solar year based on saura masa.

    VS solar year increments at Mesha samkranti. If current saura_masa is Mina (11),
    year = YearVikrama - 1; else YearVikrama.

    Args:
        vikrama_year: Base Vikrama year
        saura_masa_num: Solar month number (0-11)

    Returns:
        Vikram Samvat solar year
    """
    if saura_masa_num == 11:  # Mina
        return vikrama_year - 1
    else:
        return vikrama_year


def get_all_era_years(kali_year: int) -> dict[str, int]:
    """Get all era years from Kali year.

    Args:
        kali_year: Kali year

    Returns:
        Dictionary with all era years
    """
    saka_year = kali_to_saka(kali_year)
    vikrama_year = saka_to_vikrama(saka_year)

    return {"kali": kali_year, "saka": saka_year, "vikrama": vikrama_year}


def get_jovian_year_name(kali_year: int) -> str:
    """Get Jovian year name from Kali year.

    Args:
        kali_year: Kali year

    Returns:
        Jovian year name
    """
    jovian_year_names = {
        0: "kSaya(60)",
        1: "prabhava(1)",
        2: "vibhava(2)",
        3: "sukha(3)",
        4: "pramoda(4)",
        5: "prajApati(5)",
        6: "aGgiras(6)",
        7: "zrImukha(7)",
        8: "bhAva(8)",
        9: "yuvan(9)",
        10: "dhAtR(10)",
        11: "Izvara(11)",
        12: "bahudhArya(12)",
        13: "pramAthin(13)",
        14: "vikrama(14)",
        15: "vRSa(15)",
        16: "citrabhAnu(16)",
        17: "subhAnu(17)",
        18: "tAraNa(18)",
        19: "pArthiva(19)",
        20: "vyaya(20)",
        21: "sarvajit(21)",
        22: "sarvadhArin(22)",
        23: "virodhin(23)",
        24: "vikRta(24)",
        25: "khara(25)",
        26: "nandana(26)",
        27: "vijaya(27)",
        28: "jaya(28)",
        29: "manmatha(29)",
        30: "durmukha(30)",
        31: "hemalamba(31)",
        32: "vilambin(32)",
        33: "vikArin(33)",
        34: "zArvari(34)",
        35: "plava(35)",
        36: "zubhakRt(36)",
        37: "zobhana(37)",
        38: "krodhin(38)",
        39: "vizvAvasu(39)",
        40: "parAbhava(40)",
        41: "plavaGga(41)",
        42: "kIlaka(42)",
        43: "saumya(43)",
        44: "sAdhAraNa(44)",
        45: "virodhakRt(45)",
        46: "paridhAvin(46)",
        47: "pramAdin(47)",
        48: "Ananda(48)",
        49: "rAkSasa(49)",
        50: "anala(50)",
        51: "piGgala(51)",
        52: "kAlayukta(52)",
        53: "siddhArthin(53)",
        54: "raudra(54)",
        55: "durmati(55)",
        56: "dundubhi(56)",
        57: "rudhirodgArin(57)",
        58: "raktAkSa(58)",
        59: "krodhana(59)",
    }

    # Calculate Jovian year using the same formula as Perl
    jovian_year = (trunc((kali_year * 211 - 108) / 18000) + kali_year + 27) % 60
    return jovian_year_names[jovian_year]


def get_jovian_year_name_south(kali_year: int) -> str:
    """Get Jovian year name (South) from Kali year.

    Args:
        kali_year: Kali year

    Returns:
        Jovian year name (South)
    """
    if kali_year < 4009:
        jovian_year = kali_year
    else:
        jovian_year = (kali_year - 14) % 60

    return get_jovian_year_name(jovian_year)


def get_all_era_years_from_saka(saka_year: int) -> dict[str, int]:
    """Get all era years from Saka year.

    Args:
        saka_year: Saka year

    Returns:
        Dictionary with all era years
    """
    kali_year = saka_to_kali(saka_year)
    vikrama_year = saka_to_vikrama(saka_year)

    return {"kali": kali_year, "saka": saka_year, "vikrama": vikrama_year}


def get_all_era_years_from_vikrama(vikrama_year: int) -> dict[str, int]:
    """Get all era years from Vikrama year.

    Args:
        vikrama_year: Vikrama year

    Returns:
        Dictionary with all era years
    """
    saka_year = vikrama_to_saka(vikrama_year)
    kali_year = saka_to_kali(saka_year)

    return {"kali": kali_year, "saka": saka_year, "vikrama": vikrama_year}
