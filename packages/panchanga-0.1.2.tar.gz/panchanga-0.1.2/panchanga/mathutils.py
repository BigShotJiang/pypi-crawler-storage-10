"""Math utility functions ported from Perl.

Only test stubs exist initially per TDD; implementation follows after tests.
"""

from __future__ import annotations


def trunc(value: float) -> int:
    """Truncation toward zero to match Perl int() semantics."""
    return int(value)


def frac(value: float) -> float:
    """Fractional part function consistent with Perl behavior."""
    return value - trunc(value)


def zero360(angle_degrees: float) -> float:
    """Normalize an angle to [0, 360) degrees."""
    result = angle_degrees % 360.0
    # Handle edge case where result is exactly 360.0 due to floating point precision
    if result >= 360.0:
        result = 0.0
    return result
