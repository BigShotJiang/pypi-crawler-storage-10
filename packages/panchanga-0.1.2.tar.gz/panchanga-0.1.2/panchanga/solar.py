"""Solar calculations module for panchanga_py.

This module implements solar month calculations, samkranti bisection,
and related astronomical functions following TDD methodology.
"""

from __future__ import annotations

import math
from .mathutils import trunc, frac, zero360
from .astronomy import get_mean_long, get_manda_equation


# Mathematical constants
PI = math.atan2(1, 1) * 4
RAD = 180 / PI
EPS = 1e-6
EPSIRON = 1e-8

# Yuga constants (SuryaSiddhanta)
YUGA_ROTATION_STAR = 1582237828
YUGA_ROTATION_SUN = 4320000
YUGA_CIVIL_DAYS = YUGA_ROTATION_STAR - YUGA_ROTATION_SUN

# Solar month names
SAURA_MASA_NAMES = {
    0: "Mesa   ",
    1: "Vrsa   ",
    2: "Mithuna",
    3: "Karkata",
    4: "Simha  ",
    5: "Kanya  ",
    6: "Tula   ",
    7: "Vrscika",
    8: "Dhanus ",
    9: "Makara ",
    10: "Kumbha ",
    11: "Mina   ",
}

# Solar apogee
SOLAR_APOGEE = 77 + 17 / 60


def get_true_solar_longitude(ahargana: float) -> float:
    """Calculate true solar longitude.

    Args:
        ahargana: Days since epoch

    Returns:
        True solar longitude in degrees
    """
    mean_solar_longitude = get_mean_long(ahargana, YUGA_ROTATION_SUN)
    return zero360(
        mean_solar_longitude - get_manda_equation(mean_solar_longitude - SOLAR_APOGEE, "sun")
    )


def today_saura_masa_first_p(ahargana: float, desantara: float = 0.0) -> bool:
    """Check if today is the first day of a solar month.

    Definition: samkranti is between today's 0:00 and 24:00
    == at 0:00 before 30x, at 24:00 after 30x

    Args:
        ahargana: Days since epoch
        desantara: Local longitude correction

    Returns:
        True if today is the first day of a solar month
    """
    tslong_today = get_true_solar_longitude(ahargana - desantara)
    tslong_tomorrow = get_true_solar_longitude(ahargana - desantara + 1)

    tslong_today = tslong_today - int(tslong_today / 30) * 30
    tslong_tomorrow = tslong_tomorrow - int(tslong_tomorrow / 30) * 30

    return (25 < tslong_today) and (tslong_tomorrow < 5)


def get_saura_masa_day(ahargana: float) -> tuple[int, int]:
    """Get solar month number and day.

    If today is the first day then 1
    Otherwise yesterday's + 1

    Args:
        ahargana: Days since epoch

    Returns:
        Tuple of (month_number, day)
    """
    ahargana = trunc(ahargana)

    if today_saura_masa_first_p(ahargana):
        day = 1
        tslong_tomorrow = get_true_solar_longitude(ahargana + 1)
        month = (trunc(tslong_tomorrow / 30)) % 12
        month = (month + 12) % 12
    else:
        month, day = get_saura_masa_day(ahargana - 1)
        day = day + 1

    return (month, day)


def get_saura_masa_name(month_number: int) -> str:
    """Get solar month name from month number.

    Args:
        month_number: Solar month number (0-11)

    Returns:
        Solar month name
    """
    return SAURA_MASA_NAMES[month_number]


def find_samkranti(o_ahar: float, n_ahar: float) -> float:
    """Find samkranti using bisection algorithm.

    Args:
        o_ahar: Start ahargana
        n_ahar: End ahargana

    Returns:
        Ahargana of samkranti
    """
    o_tslong = get_true_solar_longitude(o_ahar)
    n_tslong = get_true_solar_longitude(n_ahar)

    o_tslong = o_tslong - int(o_tslong / 30) * 30
    n_tslong = n_tslong - int(n_tslong / 30) * 30

    width = (n_ahar - o_ahar) / 2
    c_ahar = (n_ahar + o_ahar) / 2

    if width < EPSIRON:
        return c_ahar
    else:
        c_tslong = get_true_solar_longitude(c_ahar)
        c_tslong = c_tslong - int(c_tslong / 30) * 30

        if c_tslong < 5:
            return find_samkranti(o_ahar, c_ahar)
        else:
            return find_samkranti(c_ahar, n_ahar)


def get_next_samkranti_info(
    ahargana: float, desantara: float = 0.0
) -> tuple[int | None, int | None, int | None, float | None]:
    """Get information about the next samkranti.

    Args:
        ahargana: Days since epoch
        desantara: Local longitude correction

    Returns:
        Tuple of (days_ahead, hour, minute, samkranti_ahargana)
        Returns (None, None, None, None) if no samkranti found within 60 days
    """
    base_ahar = trunc(ahargana)

    for k in range(60):
        candidate_ahar = base_ahar + k

        # Check if this day contains a samkranti window
        tslong_today = get_true_solar_longitude(candidate_ahar - desantara)
        tslong_tomorrow = get_true_solar_longitude(candidate_ahar - desantara + 1)
        tslong_today = tslong_today - int(tslong_today / 30) * 30
        tslong_tomorrow = tslong_tomorrow - int(tslong_tomorrow / 30) * 30

        if (25 < tslong_today) and (tslong_tomorrow < 5):
            # Found samkranti window
            sk_ahar = find_samkranti(candidate_ahar, candidate_ahar + 1)
            sk_ahar = sk_ahar + desantara

            # Convert to hours and minutes
            hour = trunc(frac(sk_ahar) * 24)
            minute = trunc(60 * frac(frac(sk_ahar) * 24))

            return (k, hour, minute, sk_ahar)

    # No samkranti found within 60 days
    return (None, None, None, None)
