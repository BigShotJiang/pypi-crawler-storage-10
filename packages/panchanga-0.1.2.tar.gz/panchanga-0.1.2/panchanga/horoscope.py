"""
Horoscope calculation functions for panchanga_py.

This module implements horoscope calculations including:
- Declination calculation
- Right ascension calculation
- Ascendant calculation
- Main horoscope calculation
- Output formatting
"""

import math
from .mathutils import trunc, zero360
from .astronomy import get_mean_long
from .timeconv import modern_date_to_julian_day, julian_day_to_ahargana

# Constants
RAD = 180.0 / math.pi
EPS = 24.0  # Ecliptic obliquity


def declination(longitude):
    """
    Calculate declination from longitude.

    Args:
        longitude: Solar longitude in degrees

    Returns:
        Declination in degrees
    """
    return math.asin(math.sin(longitude / RAD) * math.sin(EPS / RAD)) * RAD


def right_ascension(longitude, declination):
    """
    Calculate right ascension from longitude and declination.

    Args:
        longitude: Solar longitude in degrees
        declination: Solar declination in degrees

    Returns:
        Right ascension in degrees
    """
    day_radius = math.cos(declination / RAD)
    radius_90 = math.cos(EPS / RAD)
    x = radius_90 / day_radius * math.sin(longitude / RAD)
    ra = math.asin(x) * RAD

    if longitude < 90:
        pass
    elif longitude < 270:
        ra = 180 - ra
    elif longitude == 270:
        ra = 270
    else:
        ra = 360 + ra

    return ra


def ascendant(hrasc, latitude):
    """
    Calculate ascendant from hour angle and latitude.

    Args:
        hrasc: Hour angle in degrees
        latitude: Observer's latitude in degrees

    Returns:
        Ascendant in degrees
    """
    x = math.sin(hrasc / RAD)
    y = math.cos(hrasc / RAD) * math.cos(EPS / RAD) - math.sin(EPS / RAD) * math.tan(latitude / RAD)

    # Use the same atan2 pattern as Perl: atan2(x/y, 1)
    asc = math.atan2(x / y, 1) * RAD

    if 180 <= hrasc:
        if 0 < y:
            asc = asc
        else:
            asc = asc + 180
    else:
        if 0 < y:
            asc = asc + 360
        else:
            asc = asc + 180

    return asc


def horoscope_calculation(year, month, day, hours, minutes, latitude, longitude):
    """
    Main horoscope calculation function.

    Args:
        year: Year
        month: Month (1-12)
        day: Day (1-31)
        hours: Hour (0-23)
        minutes: Minute (0-59)
        latitude: Observer's latitude
        longitude: Observer's longitude

    Returns:
        Dictionary containing horoscope data
    """
    # Convert to Julian day and ahargana
    julian_day = modern_date_to_julian_day(year, month, day)
    ahargana = julian_day_to_ahargana(julian_day)

    # Add time offset
    ahargana = ahargana + hours / 24 + minutes / 24 / 60

    # Apply desantara correction (longitude correction)
    ujjaini_lon = 75.8  # Ujjaini longitude from Perl
    desantara = (longitude - ujjaini_lon) / 360.0
    ahargana = ahargana - desantara

    # Calculate mean and true solar longitude using the same algorithm as get_tslong
    mean_solar_long = get_mean_long(ahargana, 4320000)  # Sun's yuga rotation

    # Calculate true solar longitude using manda equation (same as get_tslong)
    from .astronomy import get_manda_equation

    sun_apogee = 77 + 17 / 60  # Sun's apogee from Perl
    true_solar_long = zero360(
        mean_solar_long - get_manda_equation(mean_solar_long - sun_apogee, "sun")
    )

    # Calculate sayana solar longitude (with precession)
    sayana_solar_long = true_solar_long + (54 / 3600) * (year - 499)

    # Calculate declination and right ascension
    solar_declination = declination(sayana_solar_long)
    solar_right_ascension = right_ascension(sayana_solar_long, solar_declination)

    # Calculate hour angle
    time_degree = hours * 15 + minutes / 4
    hrasc = time_degree - 90 + solar_right_ascension
    hrasc = zero360(hrasc)

    # Calculate ascendant
    ascendant_deg = ascendant(hrasc, latitude)
    ascendant_deg = zero360(ascendant_deg)

    # Calculate nirayana lagna (subtract precession)
    lagna = ascendant_deg - (54 / 3600) * (year - 499)
    lagna = zero360(lagna)

    return {
        "year": year,
        "month": month,
        "day": day,
        "hours": hours,
        "minutes": minutes,
        "latitude": latitude,
        "longitude": longitude,
        "julian_day": julian_day,
        "ahargana": ahargana,
        "mean_solar_long": mean_solar_long,
        "true_solar_long": true_solar_long,
        "sayana_solar_long": sayana_solar_long,
        "solar_declination": solar_declination,
        "solar_right_ascension": solar_right_ascension,
        "time_degree": time_degree,
        "hrasc": hrasc,
        "ascendant": ascendant_deg,
        "lagna": lagna,
    }


def format_lagna_degrees(decimal):
    """
    Format lagna degrees as sign degrees minutes seconds.

    Args:
        decimal: Decimal degrees

    Returns:
        Formatted string
    """
    decimal = zero360(decimal)
    sign = trunc(decimal / 30)
    remain = decimal - sign * 30
    degrees = trunc(remain)
    remain = remain - degrees
    minutes = trunc(60 * remain)
    remain = 60 * remain - minutes
    seconds = round(60 * remain)  # Use round instead of trunc for seconds

    return f"{sign:2.0f}s {degrees:2.0f}d {minutes:2.0f}' {seconds:2.0f}\""


def format_horoscope_output(horoscope_data):
    """
    Format horoscope data for output.

    Args:
        horoscope_data: Dictionary from horoscope_calculation

    Returns:
        Formatted string
    """
    year = horoscope_data["year"]
    month = horoscope_data["month"]
    day = horoscope_data["day"]
    hours = horoscope_data["hours"]
    minutes = horoscope_data["minutes"]
    latitude = horoscope_data["latitude"]
    lagna = horoscope_data["lagna"]

    lagna_formatted = format_lagna_degrees(lagna)

    output = "=" * 79 + "\n"
    output += f"Date: {year:4d}{month:3d}{day:3d}"
    output += f" Time: {hours:2d}h{minutes:2d}m "
    output += f" Lat.:{latitude:3.1f}"
    output += f" | Lagna = {lagna_formatted}\n"
    output += "=" * 79 + "\n"

    return output
