"""Output formatting module for panchanga_py.

This module implements verbose output layout, sunrise calculations,
and all output sections following TDD methodology.
"""

from __future__ import annotations

import math
from .mathutils import trunc, frac
from .astronomy import get_mean_long
from .horoscope import declination

# Yuga constants (SuryaSiddhanta)
YUGA_ROTATION_SUN = 4320000
YUGA_CIVIL_DAYS = 1577917828  # YugaRotation{'star'} - YugaRotation{'sun'}

# Mathematical constants
PI = math.pi
RAD = 180 / PI
EPS = 1e-6


def get_daylight_equation(year: int, loc_lat: float, ahargana: float) -> float:
    """Calculate daylight equation for sunrise time.

    Args:
        year: Gregorian year
        loc_lat: Local latitude in degrees
        ahargana: Days since epoch

    Returns:
        Daylight equation in days
    """
    mslong = get_mean_long(ahargana, YUGA_ROTATION_SUN)
    # Sayana solar longitude and declination
    samslong = mslong + (54 / 3600) * (year - 499)
    sdecl = declination(samslong)

    # Equation of daylight by analemma
    x = math.tan(loc_lat / RAD) * math.tan(sdecl / RAD)

    if EPS < abs(1 - x * x):
        return 0.5 * math.atan2(x / math.sqrt(1 - x * x), 1) / PI
    elif x > 0:
        return 0.5 * (PI / 2) / PI
    else:
        return 0.5 * (3 * PI / 2) / PI


def get_sun_rise_time(eqtime: float) -> tuple[int, int]:
    """Calculate sunrise time from daylight equation.

    Args:
        eqtime: Daylight equation in days

    Returns:
        Tuple of (hour, minute) for sunrise
    """
    sriseh = trunc((0.25 - eqtime) * 24)
    srisem = trunc(60 * frac((0.25 - eqtime) * 24))
    return (sriseh, srisem)


def get_ayana_amsa(ahargana: float) -> tuple[int, int]:
    """Calculate ayanamsa (precession) from ahargana.

    Args:
        ahargana: Days since epoch

    Returns:
        Tuple of (degrees, minutes) for ayanamsa
    """
    ayanadeg = trunc((54 * 4320000 / YUGA_CIVIL_DAYS / 3600) * (ahargana - 1314930))
    ayanamin = trunc(60 * frac((54 * 4320000 / YUGA_CIVIL_DAYS / 3600) * (ahargana - 1314930)))
    return (ayanadeg, ayanamin)


def format_sunrise_time(hour: int, minute: int) -> str:
    """Format sunrise time as string.

    Args:
        hour: Hour (0-23)
        minute: Minute (0-59)

    Returns:
        Formatted sunrise time string
    """
    return f"{hour:2d}h {minute:2d}m"


def format_tithi(tithi_day: int, ftithi: float) -> str:
    """Format tithi with fraction.

    Args:
        tithi_day: Tithi day (1-15)
        ftithi: Fractional part of tithi

    Returns:
        Formatted tithi string
    """
    fraction_str = str(1 + ftithi)[2:5]  # Get 3 digits after decimal
    return f"{tithi_day:2d} (fraction = 0.{fraction_str})"


def format_naksatra(naksatra: str) -> str:
    """Format naksatra name without padding to match Perl.

    Args:
        naksatra: Naksatra name

    Returns:
        Formatted naksatra string
    """
    return naksatra.strip()


def format_yoga(yoga: str) -> str:
    """Format yoga name without padding to match Perl.

    Args:
        yoga: Yoga name

    Returns:
        Formatted yoga string
    """
    return yoga.strip()


def format_era_years(saka_year: int, vikrama_year: int, kali_year: int) -> str:
    """Format era years section.

    Args:
        saka_year: Saka year
        vikrama_year: Vikrama year
        kali_year: Kali year

    Returns:
        Formatted era years string
    """
    return f"Saka {saka_year:4d} |Vikrama {vikrama_year:4d} |Kali {kali_year:4d}"


def format_ayanamsa(ayanadeg: int, ayanamin: int) -> str:
    """Format ayanamsa.

    Args:
        ayanadeg: Ayanamsa degrees
        ayanamin: Ayanamsa minutes

    Returns:
        Formatted ayanamsa string
    """
    return f"{ayanadeg:2d}d {ayanamin:2d}m"


def format_lunar_section(
    adhimasa: str, masa: str, sukla_krsna: str, tithi_day: int, ftithi: float
) -> str:
    """Format lunar section.

    Args:
        adhimasa: Adhimasa prefix
        masa: Lunar month name
        sukla_krsna: Paksa name
        tithi_day: Tithi day
        ftithi: Fractional tithi

    Returns:
        Formatted lunar section string
    """
    tithi_str = format_tithi(tithi_day, ftithi)
    return f"{adhimasa}{masa} {sukla_krsna} {tithi_str}"


def format_solar_section(
    saura_masa: str,
    saura_masa_day: int,
    samkranti_year: int,
    samkranti_month: int,
    samkranti_day: int,
    samkranti_hour: int,
    samkranti_minute: int,
) -> str:
    """Format solar section.

    Args:
        saura_masa: Solar month name
        saura_masa_day: Solar day
        samkranti_year: Samkranti year
        samkranti_month: Samkranti month
        samkranti_day: Samkranti day
        samkranti_hour: Samkranti hour
        samkranti_minute: Samkranti minute

    Returns:
        Formatted solar section string
    """
    return (
        f"{saura_masa} {saura_masa_day} "
        f"(samkranti: on {samkranti_year:4d} {samkranti_month:2d} {samkranti_day:2d} "
        f"at {samkranti_hour:2d}h {samkranti_minute:2d}m)"
    )


def format_vs_solar_section(
    vikrama_solar_year: int, vikram_saura_masa: str, saura_masa_day: int
) -> str:
    """Format Vikram Samvat solar section.

    Args:
        vikrama_solar_year: VS solar year
        vikram_saura_masa: VS solar month name
        saura_masa_day: Solar day

    Returns:
        Formatted VS solar section string
    """
    return f"{vikrama_solar_year} {vikram_saura_masa:8s} {saura_masa_day:2d}"


def format_lunar_details(naksatra: str, karana: str, yoga: str) -> str:
    """Format lunar details section.

    Args:
        naksatra: Naksatra name
        karana: Karana name
        yoga: Yoga name

    Returns:
        Formatted lunar details string
    """
    naksatra_str = format_naksatra(naksatra)
    yoga_str = format_yoga(yoga)
    return f"naksatra.... {naksatra_str}  /  karana...{karana}  /  yoga...{yoga_str}"


def format_longitude_degrees(decimal_degrees: float) -> str:
    """Format longitude degrees as sign degrees."""
    from .mathutils import trunc, zero360

    decimal_degrees = zero360(decimal_degrees)
    sign = trunc(decimal_degrees / 30)
    degrees = trunc(decimal_degrees - sign * 30)

    return f"{sign:3.0f}s {degrees:2.0f}d"


def format_verbose_output(
    year: int,
    month: int,
    day: int,
    weekday_name: str,
    julian_day: float,
    ahargana: float,
    loc_lat: float,
    loc_lon: float,
    sunrise_hour: int,
    sunrise_minute: int,
    ayanadeg: int,
    ayanamin: int,
    saka_year: int,
    vikrama_year: int,
    kali_year: int,
    adhimasa: str,
    masa: str,
    sukla_krsna: str,
    tithi_day: int,
    ftithi: float,
    saura_masa: str,
    saura_masa_day: int,
    samkranti_year: int,
    samkranti_month: int,
    samkranti_day: int,
    samkranti_hour: int,
    samkranti_minute: int,
    vikrama_solar_year: int,
    vikram_saura_masa: str,
    naksatra: str,
    karana: str,
    yoga: str,
    tslong: float,
    tllong: float,
    jovian_north: str = "",
    jovian_south: str = "",
    next_samkranti_year: int | None = None,
    next_samkranti_month: int | None = None,
    next_samkranti_day: int | None = None,
    next_samkranti_hour: int | None = None,
    next_samkranti_minute: int | None = None,
) -> str:
    """Format complete verbose output.

    Args:
        year: Gregorian year
        month: Gregorian month
        day: Gregorian day
        weekday_name: Weekday name
        julian_day: Julian day
        ahargana: Ahargana
        loc_lat: Local latitude
        loc_lon: Local longitude
        sunrise_hour: Sunrise hour
        sunrise_minute: Sunrise minute
        ayanadeg: Ayanamsa degrees
        ayanamin: Ayanamsa minutes
        saka_year: Saka year
        vikrama_year: Vikrama year
        kali_year: Kali year
        adhimasa: Adhimasa prefix
        masa: Lunar month name
        sukla_krsna: Paksa name
        tithi_day: Tithi day
        ftithi: Fractional tithi
        saura_masa: Solar month name
        saura_masa_day: Solar day
        samkranti_year: Samkranti year
        samkranti_month: Samkranti month
        samkranti_day: Samkranti day
        samkranti_hour: Samkranti hour
        samkranti_minute: Samkranti minute
        vikrama_solar_year: VS solar year
        vikram_saura_masa: VS solar month name
        naksatra: Naksatra name
        karana: Karana name
        yoga: Yoga name

    Returns:
        Complete formatted verbose output
    """
    lines = []

    # Header
    lines.append(
        f"  AD{year:5d} {month:2d} {day:3d} {weekday_name} | JD (at noon)= {julian_day:.0f} | Kali-ahargana= {ahargana:.0f} "
    )
    lines.append("===============================================================================")

    # System info
    lines.append("  Panchanga based on Suryasiddhanta (AD 1000 ca) ")
    lines.append(f"    at latitude={loc_lat:3.1f}, longitude={loc_lon:3.1f}")
    lines.append("-------------------------------------------------------------------------------")

    # Sunrise and longitude info
    sunrise_str = format_sunrise_time(sunrise_hour, sunrise_minute)
    lines.append(
        f" Vedic date (luni-solar year and amanta month)  (*) local sunrise...{sunrise_str}"
    )
    lines.append(
        f"   (Nirayana True Longitude at sunrise. Sun: {format_longitude_degrees(tslong)},  Moon: {format_longitude_degrees(tllong)})"
    )

    # Years section
    era_str = format_era_years(saka_year, vikrama_year, kali_year)
    ayanamsa_str = format_ayanamsa(ayanadeg, ayanamin)
    lines.append(f" year(atita):{era_str} | ayanamsa: {ayanamsa_str}")

    # Jovian year information
    if jovian_north and jovian_south:
        lines.append(f"             Jovian(North):{jovian_north} |Jovian(South):{jovian_south}")

    # Lunar section
    lunar_str = format_lunar_section(adhimasa, masa, sukla_krsna, tithi_day, ftithi)
    lines.append(" lunar month, paksa, and tithi(at sunrise): ")
    lines.append(f"       {lunar_str}")

    # Solar section
    solar_str = format_solar_section(
        saura_masa,
        saura_masa_day,
        samkranti_year,
        samkranti_month,
        samkranti_day,
        samkranti_hour,
        samkranti_minute,
    )
    lines.append(f" solar month and day: {solar_str}")

    # Next samkranti information
    # if next_samkranti_year is not None:
    #     lines.append(
    #         f"           coming samkranti: on {next_samkranti_year:4d} {next_samkranti_month:2d} {next_samkranti_day:2d} at {next_samkranti_hour:2d}h {next_samkranti_minute:2d}m"
    #     )

    # VS Solar section
    # vs_solar_str = format_vs_solar_section(
    #     vikrama_solar_year, vikram_saura_masa, saura_masa_day
    # )
    # lines.append(f" Vikram Samvat solar: {vs_solar_str}")

    # Lunar details
    lunar_details_str = format_lunar_details(naksatra, karana, yoga)
    lines.append(f" {lunar_details_str}")

    return "\n".join(lines)
