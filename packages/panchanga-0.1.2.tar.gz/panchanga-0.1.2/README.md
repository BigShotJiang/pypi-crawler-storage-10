# Panchanga - Vedic Calendar Library

Pure Python library for traditional Vedic calendar (Panchanga) calculations based on Suryasiddhanta (ca. AD 1000).

## Installation

```bash
pip install panchanga
```

## Quick Example

```python
import panchanga

# Convert Gregorian to Julian Day and Ahargana
jd = panchanga.modern_date_to_julian_day(2025, 3, 14)
ahargana = panchanga.julian_day_to_ahargana(jd)

# Get calendar information
kali_year = panchanga.ahargana_to_kali(ahargana)
saka_year = panchanga.kali_to_saka(kali_year)
vikrama_year = panchanga.saka_to_vikrama(saka_year)

# Calculate astronomical positions
tslong = panchanga.get_true_solar_longitude(ahargana)
tllong = panchanga.get_true_lunar_longitude(ahargana)

# Get lunar day (tithi)
tithi = panchanga.get_tithi(tllong, tslong)
tithi_day, ftithi = panchanga.get_tithi_set(tithi)

# Get naksatra
naksatra = panchanga.get_naksatra_name(tllong)
```

## Features

- Date conversions (Gregorian ↔ Julian Day ↔ Ahargana)
- Vedic calendar era conversions (Kali, Saka, Vikrama)
- Lunar calculations (tithi, naksatra, yoga, karana)
- Solar calculations (saura masa, samkranti)
- Astronomical calculations (sun/moon longitudes)
- Sunrise time calculations
- Ayanamsa calculations
- Horoscope/birth chart calculations

## Documentation

See [API documentation](https://git.sr.ht/~ayys/panchanga) for detailed usage.

## Credits

Based on the Perl implementation by M. YANO and M. FUSHIMI (v3.14, 2014).
Python port by Ayush Jha.

