"""Tests for astronomy functions."""

import math
from panchanga.astronomy import (
    get_mean_long,
    get_manda_equation,
    get_sighra_equation,
    get_true_long,
    get_true_solar_longitude,
    get_true_lunar_longitude,
    arcsin,
    tan,
    sqr,
)


class TestAstronomy:
    """Test astronomy functions."""

    def test_get_mean_long_basic(self):
        """Test basic mean longitude calculation."""
        # Test with known values
        ahargana = 1000.0
        rotation = 4320000  # Sun's rotation

        result = get_mean_long(ahargana, rotation)

        # Should be a reasonable longitude value
        assert 0 <= result < 360
        assert isinstance(result, float)

    def test_get_manda_equation_basic(self):
        """Test basic manda equation calculation."""
        # Test with sun
        argument = 0.0
        result = get_manda_equation(argument, "sun")

        # At argument 0, sin(0) = 0, so equation should be 0
        assert abs(result) < 1e-10

        # Test with non-zero argument
        argument = 90.0
        result = get_manda_equation(argument, "sun")

        # Should be non-zero and reasonable
        assert isinstance(result, float)
        assert abs(result) < 20  # Manda equation should be small

    def test_get_sighra_equation_basic(self):
        """Test basic sighra equation calculation."""
        # Test with mercury (has sighra correction)
        anomaly = 0.0
        result = get_sighra_equation(anomaly, "mercury")

        # At anomaly 0, sin(0) = 0, so equation should be 0
        assert abs(result) < 1e-10

        # Test with non-zero anomaly
        anomaly = 90.0
        result = get_sighra_equation(anomaly, "mercury")

        # Should be non-zero and reasonable
        assert isinstance(result, float)
        assert abs(result) < 200  # Sighra equation can be larger

    def test_get_true_solar_longitude_basic(self):
        """Test basic true solar longitude calculation."""
        ahargana = 1000.0

        result = get_true_solar_longitude(ahargana)

        # Should be a valid longitude
        assert 0 <= result < 360
        assert isinstance(result, float)

    def test_get_true_lunar_longitude_basic(self):
        """Test basic true lunar longitude calculation."""
        ahargana = 1000.0

        result = get_true_lunar_longitude(ahargana)

        # Should be a valid longitude
        assert 0 <= result < 360
        assert isinstance(result, float)

    def test_get_true_long_basic(self):
        """Test basic true longitude calculation for planets."""
        ahargana = 1000.0
        mean_solar_longitude = 100.0

        # Test sun
        result = get_true_long(ahargana, mean_solar_longitude, "sun")
        assert 0 <= result < 360
        assert isinstance(result, float)

        # Test moon
        result = get_true_long(ahargana, mean_solar_longitude, "moon")
        assert 0 <= result < 360
        assert isinstance(result, float)

    def test_arcsin_function(self):
        """Test arcsin function."""
        # Test basic values (arcsin now returns degrees, not radians)
        assert abs(arcsin(0.0)) < 1e-10
        assert abs(arcsin(1.0) - 90.0) < 1e-10  # 90 degrees, not π/2 radians
        assert abs(arcsin(-1.0) - 270.0) < 1e-10  # 270 degrees, not 3π/2 radians

        # Test intermediate values
        result = arcsin(0.5)
        assert isinstance(result, float)
        assert 0 < result < 90  # degrees, not radians

    def test_tan_function(self):
        """Test tan function."""
        # Test basic values
        assert abs(tan(0.0)) < 1e-10
        assert abs(tan(math.pi / 4) - 1.0) < 1e-10

        # Test that it matches math.tan for reasonable values
        test_values = [0.1, 0.5, 1.0, 1.5]
        for x in test_values:
            assert abs(tan(x) - math.tan(x)) < 1e-10

    def test_sqr_function(self):
        """Test sqr function."""
        assert sqr(0.0) == 0.0
        assert sqr(1.0) == 1.0
        assert sqr(2.0) == 4.0
        assert sqr(-3.0) == 9.0

    def test_planetary_constants(self):
        """Test that planetary constants are reasonable."""
        # Test manda equation for different planets
        argument = 90.0

        sun_eq = get_manda_equation(argument, "sun")
        moon_eq = get_manda_equation(argument, "moon")
        mercury_eq = get_manda_equation(argument, "mercury")

        # Sun should have moderate manda equation
        assert 0 < abs(sun_eq) < 20

        # Moon should have larger manda equation
        assert 0 < abs(moon_eq) < 40

        # Mercury should have moderate manda equation
        assert 0 < abs(mercury_eq) < 30

    def test_sighra_equation_planets(self):
        """Test sighra equation for different planets."""
        anomaly = 90.0

        # Inner planets should have sighra equations
        mercury_eq = get_sighra_equation(anomaly, "mercury")
        venus_eq = get_sighra_equation(anomaly, "venus")

        # Outer planets should have sighra equations
        mars_eq = get_sighra_equation(anomaly, "mars")
        jupiter_eq = get_sighra_equation(anomaly, "jupiter")
        saturn_eq = get_sighra_equation(anomaly, "saturn")

        # All should be reasonable values
        assert isinstance(mercury_eq, float)
        assert isinstance(venus_eq, float)
        assert isinstance(mars_eq, float)
        assert isinstance(jupiter_eq, float)
        assert isinstance(saturn_eq, float)

    def test_edge_cases(self):
        """Test edge cases for astronomy functions."""
        # Test with very small ahargana
        result = get_mean_long(0.001, 4320000)
        assert isinstance(result, float)
        assert 0 <= result < 360

        # Test with large ahargana
        result = get_mean_long(1000000.0, 4320000)
        assert isinstance(result, float)
        assert 0 <= result < 360

        # Test manda equation with extreme arguments
        result = get_manda_equation(0.0, "sun")
        assert abs(result) < 1e-10

        result = get_manda_equation(360.0, "sun")
        assert abs(result) < 1e-10  # Should be same as 0 due to periodicity
