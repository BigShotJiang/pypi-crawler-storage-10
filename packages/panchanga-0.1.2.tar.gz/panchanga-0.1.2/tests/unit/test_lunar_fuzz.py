"""Fuzz tests for lunar calculation functions."""

import math
from hypothesis import given, strategies as st
from panchanga.lunar import (
    get_tithi,
    get_tithi_set,
    set_sukla_krsna,
    get_naksatra_name,
    get_yoga_name,
    get_karana_name,
)


class TestLunarFuzz:
    """Fuzz tests for lunar calculation functions."""

    @given(st.floats(min_value=0, max_value=360, allow_nan=False, allow_infinity=False))
    def test_get_tithi_properties(self, tllong):
        """Test get_tithi function properties with fuzzed inputs."""
        tslong = 0.0  # Keep solar longitude constant

        result = get_tithi(tllong, tslong)

        # Should be a valid tithi value
        assert isinstance(result, float)
        assert 0 <= result < 30

    @given(st.floats(min_value=0, max_value=30, allow_nan=False, allow_infinity=False))
    def test_get_tithi_set_properties(self, tithi):
        """Test get_tithi_set function properties with fuzzed inputs."""
        tithi_day, ftithi = get_tithi_set(tithi)

        # Should return valid values
        assert isinstance(tithi_day, int)
        assert isinstance(ftithi, float)
        assert 1 <= tithi_day <= 31  # Can go up to 31 for tithi=30
        assert 0 <= ftithi < 1

        # Should reconstruct the original tithi
        reconstructed = tithi_day - 1 + ftithi
        assert math.isclose(tithi, reconstructed, rel_tol=1e-10, abs_tol=1e-10)

    @given(st.integers(min_value=1, max_value=30))
    def test_set_sukla_krsna_properties(self, tithi_day):
        """Test set_sukla_krsna function properties with fuzzed inputs."""
        result_day, sukla_krsna, paksa = set_sukla_krsna(tithi_day)

        # Should return valid values
        assert isinstance(result_day, int)
        assert isinstance(sukla_krsna, str)
        assert isinstance(paksa, str)

        # Should have valid ranges
        assert 1 <= result_day <= 15
        assert sukla_krsna in ["Sukla", "Krsna"]
        assert paksa in ["Suklapaksa", "Krsnapaksa"]

        # Should be consistent
        if tithi_day <= 15:
            assert paksa == "Suklapaksa"
            assert sukla_krsna == "Sukla"
            assert result_day == tithi_day
        else:
            assert paksa == "Krsnapaksa"
            assert sukla_krsna == "Krsna"
            assert result_day == tithi_day - 15

    @given(st.floats(min_value=0, max_value=720, allow_nan=False, allow_infinity=False))
    def test_get_naksatra_name_properties(self, tllong):
        """Test get_naksatra_name function properties with fuzzed inputs."""
        result = get_naksatra_name(tllong)

        # Should return a valid nakshatra name
        assert isinstance(result, str)
        assert len(result) > 0

        # Should be one of the known nakshatras
        known_nakshatras = [
            "Asvini",
            "Bharani",
            "Krttika",
            "Rohini",
            "Mrgasira",
            "Ardra",
            "Punarvasu",
            "Pusya",
            "Aslesa",
            "Magha",
            "P-phalguni",
            "U-phalguni",
            "Hasta",
            "Citra",
            "Svati",
            "Visakha",
            "Anuradha",
            "Jyestha",
            "Mula",
            "P-asadha",
            "U-asadha",
            "Sravana",
            "Dhanistha",
            "Satabhisaj",
            "P-bhadrapada",
            "U-bhadrapada",
            "Revati",
        ]
        assert result in known_nakshatras

    @given(
        st.floats(min_value=0, max_value=720, allow_nan=False, allow_infinity=False),
        st.floats(min_value=0, max_value=720, allow_nan=False, allow_infinity=False),
    )
    def test_get_yoga_name_properties(self, tslong, tllong):
        """Test get_yoga_name function properties with fuzzed inputs."""
        result = get_yoga_name(tslong, tllong)

        # Should return a valid yoga name
        assert isinstance(result, str)
        assert len(result) > 0

        # Should be one of the known yogas
        known_yogas = [
            "viSkambha",
            "prIti",
            "AyuSmat",
            "saubhAgya",
            "zobhana",
            "atigaNDa",
            "sukarman",
            "dhRti",
            "zUla",
            "gaNDa",
            "vRddhi",
            "dhruva",
            "vyAghAta",
            "harSaNa",
            "vajra",
            "siddhi",
            "vyatIpAta",
            "varIyas",
            "parigha",
            "ziva",
            "siddha",
            "sAdhya",
            "zubha",
            "zukla",
            "brahman",
            "aindra",
            "vaidhRti",
        ]
        assert result in known_yogas

    @given(st.floats(min_value=0, max_value=60, allow_nan=False, allow_infinity=False))
    def test_get_karana_name_properties(self, tithi):
        """Test get_karana_name function properties with fuzzed inputs."""
        result = get_karana_name(tithi)

        # Should return a valid karana name
        assert isinstance(result, str)
        assert len(result) > 0

        # Should be one of the known karanas (matching Perl implementation)
        known_karanas = [
            "kiMstughna",
            "bava      ",
            "bAlava    ",
            "kaulava   ",
            "taitila   ",
            "gara      ",
            "vaNij     ",
            "viSTi     ",
            "zakuni    ",
            "catuSpada ",
            "nAga      ",
        ]
        assert result in known_karanas

    @given(
        st.floats(min_value=0, max_value=360, allow_nan=False, allow_infinity=False),
        st.floats(min_value=0, max_value=360, allow_nan=False, allow_infinity=False),
    )
    def test_tithi_calculation_consistency(self, tllong, tslong):
        """Test that tithi calculation is consistent."""
        tithi = get_tithi(tllong, tslong)
        tithi_day, ftithi = get_tithi_set(tithi)

        # Should be able to reconstruct the tithi
        reconstructed = tithi_day - 1 + ftithi
        assert math.isclose(tithi, reconstructed, rel_tol=1e-10, abs_tol=1e-10)

        # Should be able to determine paksa
        result_day, sukla_krsna, paksa = set_sukla_krsna(tithi_day)
        assert isinstance(paksa, str)
        assert paksa in ["Suklapaksa", "Krsnapaksa"]

    @given(st.floats(min_value=0, max_value=360, allow_nan=False, allow_infinity=False))
    def test_nakshatra_yoga_consistency(self, tllong):
        """Test that nakshatra and yoga calculations are consistent."""
        tslong = 0.0  # Keep solar longitude constant

        nakshatra = get_naksatra_name(tllong)
        yoga = get_yoga_name(tslong, tllong)

        # Both should return valid strings
        assert isinstance(nakshatra, str)
        assert isinstance(yoga, str)
        assert len(nakshatra) > 0
        assert len(yoga) > 0

    @given(st.floats(min_value=0, max_value=30, allow_nan=False, allow_infinity=False))
    def test_karana_tithi_consistency(self, tithi):
        """Test that karana calculation is consistent with tithi."""
        karana = get_karana_name(tithi)

        # Should return a valid karana
        assert isinstance(karana, str)
        assert len(karana) > 0

    @given(st.floats(min_value=-360, max_value=720, allow_nan=False, allow_infinity=False))
    def test_edge_case_longitudes(self, longitude):
        """Test edge cases with extreme longitude values."""
        # Test nakshatra with extreme values
        nakshatra = get_naksatra_name(longitude)
        assert isinstance(nakshatra, str)
        assert len(nakshatra) > 0

        # Test yoga with extreme values
        yoga = get_yoga_name(longitude, longitude)
        assert isinstance(yoga, str)
        assert len(yoga) > 0

    @given(st.floats(min_value=-30, max_value=60, allow_nan=False, allow_infinity=False))
    def test_edge_case_tithi(self, tithi):
        """Test edge cases with extreme tithi values."""
        # Test tithi calculation
        tithi_result = get_tithi(tithi, 0.0)
        assert isinstance(tithi_result, float)

        # Test tithi set
        tithi_day, ftithi = get_tithi_set(tithi)
        assert isinstance(tithi_day, int)
        assert isinstance(ftithi, float)

        # Test karana
        karana = get_karana_name(tithi)
        assert isinstance(karana, str)
        assert len(karana) > 0
