"""Tests for output formatting module."""

from panchanga.output import (
    get_daylight_equation,
    get_sun_rise_time,
    get_ayana_amsa,
    format_sunrise_time,
    format_tithi,
    format_naksatra,
    format_yoga,
    format_era_years,
    format_ayanamsa,
    format_lunar_section,
    format_solar_section,
    format_vs_solar_section,
    format_lunar_details,
    format_verbose_output,
)
from panchanga.horoscope import declination


class TestOutputFormatting:
    def test_declination_basic(self):
        """Test solar declination calculation."""
        # Test with known values
        result = declination(0)
        assert isinstance(result, float)
        assert -90 <= result <= 90

        result = declination(90)
        assert isinstance(result, float)
        assert -90 <= result <= 90

    def test_get_daylight_equation_basic(self):
        """Test daylight equation calculation."""
        # Test with known values
        result = get_daylight_equation(2024, 28.6, 2000000)
        assert isinstance(result, float)
        assert -0.5 <= result <= 0.5  # Should be reasonable range

    def test_get_sun_rise_time_basic(self):
        """Test sunrise time calculation."""
        # Test with known values
        hour, minute = get_sun_rise_time(0.1)
        assert isinstance(hour, int)
        assert isinstance(minute, int)
        assert 0 <= hour <= 23
        assert 0 <= minute <= 59

    def test_get_ayana_amsa_basic(self):
        """Test ayanamsa calculation."""
        # Test with known values
        deg, min_val = get_ayana_amsa(2000000)
        assert isinstance(deg, int)
        assert isinstance(min_val, int)
        assert 0 <= min_val <= 59

    def test_format_sunrise_time_basic(self):
        """Test sunrise time formatting."""
        result = format_sunrise_time(6, 39)
        assert result == " 6h 39m"

        result = format_sunrise_time(12, 0)
        assert result == "12h  0m"

    def test_format_tithi_basic(self):
        """Test tithi formatting."""
        result = format_tithi(12, 0.947)
        assert "12" in result
        assert "0.947" in result

    def test_format_naksatra_basic(self):
        """Test naksatra formatting."""
        result = format_naksatra("Revati")
        assert result == "Revati"  # Now strips whitespace to match Perl
        assert len(result) == 6

    def test_format_yoga_basic(self):
        """Test yoga formatting."""
        result = format_yoga("Harsana")
        assert result == "Harsana"  # Now strips whitespace to match Perl
        assert len(result) == 7

    def test_format_era_years_basic(self):
        """Test era years formatting."""
        result = format_era_years(2296, 2431, 5475)
        assert "Saka 2296" in result
        assert "Vikrama 2431" in result
        assert "Kali 5475" in result

    def test_format_ayanamsa_basic(self):
        """Test ayanamsa formatting."""
        result = format_ayanamsa(28, 8)
        assert result == "28d  8m"

    def test_format_lunar_section_basic(self):
        """Test lunar section formatting."""
        result = format_lunar_section("", "Caitra", "Suklapaksa", 12, 0.947)
        assert "Caitra" in result
        assert "Suklapaksa" in result
        assert "12" in result

    def test_format_solar_section_basic(self):
        """Test solar section formatting."""
        result = format_solar_section("Tula", 15, 2024, 10, 15, 6, 30)
        assert "Tula" in result
        assert "15" in result
        assert "2024" in result
        assert "6h 30m" in result

    def test_format_vs_solar_section_basic(self):
        """Test VS solar section formatting."""
        result = format_vs_solar_section(2431, "Karttika", 15)
        assert "2431" in result
        assert "Karttika" in result
        assert "15" in result

    def test_format_lunar_details_basic(self):
        """Test lunar details formatting."""
        result = format_lunar_details("Revati", "bAlava", "Harsana")
        assert "Revati" in result
        assert "bAlava" in result
        assert "Harsana" in result

    def test_format_verbose_output_basic(self):
        """Test complete verbose output formatting."""
        result = format_verbose_output(
            2024,
            10,
            15,
            "Tuesday",
            2460000.0,
            2000000.0,
            28.6,
            77.2,
            6,
            39,
            28,
            8,
            2296,
            2431,
            5475,
            "",
            "Caitra",
            "Suklapaksa",
            12,
            0.947,
            "Tula",
            15,
            2024,
            10,
            15,
            6,
            30,
            2431,
            "Karttika",
            "Revati",
            "bAlava",
            "Harsana",
            100.0,
            200.0,  # Added missing tslong and tllong parameters
        )

        assert isinstance(result, str)
        assert "AD 2024" in result
        assert "Tuesday" in result
        assert "Suryasiddhanta" in result
        assert "Saka 2296" in result
        assert "Caitra" in result
        assert "Tula" in result

    def test_edge_cases(self):
        """Test edge cases."""
        # Test with zero values
        hour, minute = get_sun_rise_time(0)
        assert hour >= 0
        assert minute >= 0

        # Test with extreme values
        result = declination(360)
        assert isinstance(result, float)

        # Test formatting with edge values
        result = format_sunrise_time(0, 0)
        assert result == " 0h  0m"

        result = format_sunrise_time(23, 59)
        assert result == "23h 59m"

    def test_consistency_checks(self):
        """Test consistency between related functions."""
        # Test that sunrise time is reasonable
        eqtime = get_daylight_equation(2024, 28.6, 2000000)
        hour, minute = get_sun_rise_time(eqtime)
        assert 0 <= hour <= 23
        assert 0 <= minute <= 59

        # Test that ayanamsa is reasonable
        deg, min_val = get_ayana_amsa(2000000)
        assert deg >= 0
        assert 0 <= min_val <= 59

        # Test that formatting preserves information
        original_tithi = 12
        original_ftithi = 0.947
        formatted = format_tithi(original_tithi, original_ftithi)
        assert str(original_tithi) in formatted
        assert "0.947" in formatted
