"""Tests for calendar era conversions module."""

from panchanga.calendars import (
    kali_to_saka,
    saka_to_kali,
    saka_to_vikrama,
    vikrama_to_saka,
    ahargana_to_kali,
    kali_to_ahargana,
    get_masa_name,
    get_vikrama_saura_masa_name,
    get_vikrama_solar_year,
    get_all_era_years,
    get_all_era_years_from_saka,
    get_all_era_years_from_vikrama,
    MASA_NAMES,
    KALI_TO_SAKA_OFFSET,
    SAKA_TO_VIKRAMA_OFFSET,
)


class TestCalendarEraConversions:
    def test_kali_to_saka_basic(self):
        """Test basic Kali to Saka conversion."""
        # Test with known values
        assert kali_to_saka(5000) == 1821
        assert kali_to_saka(5100) == 1921
        assert kali_to_saka(5200) == 2021

        # Test with zero
        assert kali_to_saka(3179) == 0

        # Test with negative
        assert kali_to_saka(1000) == -2179

    def test_saka_to_kali_basic(self):
        """Test basic Saka to Kali conversion."""
        # Test with known values
        assert saka_to_kali(1821) == 5000
        assert saka_to_kali(1921) == 5100
        assert saka_to_kali(2021) == 5200

        # Test with zero
        assert saka_to_kali(0) == 3179

        # Test with negative
        assert saka_to_kali(-2179) == 1000

    def test_saka_to_vikrama_basic(self):
        """Test basic Saka to Vikrama conversion."""
        # Test with known values
        assert saka_to_vikrama(1821) == 1956
        assert saka_to_vikrama(1921) == 2056
        assert saka_to_vikrama(2021) == 2156

        # Test with zero
        assert saka_to_vikrama(-135) == 0

    def test_vikrama_to_saka_basic(self):
        """Test basic Vikrama to Saka conversion."""
        # Test with known values
        assert vikrama_to_saka(1956) == 1821
        assert vikrama_to_saka(2056) == 1921
        assert vikrama_to_saka(2156) == 2021

        # Test with zero
        assert vikrama_to_saka(0) == -135

    def test_ahargana_to_kali_basic(self):
        """Test basic ahargana to Kali conversion."""
        # Test with known values
        assert ahargana_to_kali(1000) == 2
        assert ahargana_to_kali(2000) == 5
        assert ahargana_to_kali(3000) == 8
        assert ahargana_to_kali(4000) == 10
        assert ahargana_to_kali(5000) == 13

    def test_kali_to_ahargana_basic(self):
        """Test basic Kali to ahargana conversion."""
        # Test with known values
        assert kali_to_ahargana(5000, 0, 1) == 1826290
        assert kali_to_ahargana(5000, 5, 15) == 1826452
        assert kali_to_ahargana(5100, 11, 30) == 1863173

    def test_get_masa_name_basic(self):
        """Test lunar month name lookup."""
        # Test all month numbers
        for month_num in range(12):
            name = get_masa_name(month_num)
            assert isinstance(name, str)
            assert name in MASA_NAMES.values()

        # Test specific names
        assert get_masa_name(0) == "Caitra    "
        assert get_masa_name(11) == "Phalguna  "

    def test_get_vikrama_saura_masa_name_basic(self):
        """Test Vikram saura masa name mapping."""
        # Test all saura month numbers
        expected_mappings = {
            0: "Vaisakha  ",
            1: "Jyaistha  ",
            2: "Asadha    ",
            3: "Sravana   ",
            4: "Bhadrapada",
            5: "Asvina    ",
            6: "Karttika  ",
            7: "Margasirsa",
            8: "Pausa     ",
            9: "Magha     ",
            10: "Phalguna  ",
            11: "Caitra    ",
        }

        for saura_num, expected_name in expected_mappings.items():
            result = get_vikrama_saura_masa_name(saura_num)
            assert result == expected_name

    def test_get_vikrama_solar_year_basic(self):
        """Test Vikram Samvat solar year logic."""
        base_year = 2080

        # Test for Mina (saura=11) - should be base_year - 1
        assert get_vikrama_solar_year(base_year, 11) == 2079

        # Test for other months - should be base_year
        for saura_num in range(11):
            assert get_vikrama_solar_year(base_year, saura_num) == base_year

    def test_get_all_era_years_basic(self):
        """Test getting all era years from Kali year."""
        result = get_all_era_years(5000)
        expected = {"kali": 5000, "saka": 1821, "vikrama": 1956}
        assert result == expected

    def test_get_all_era_years_from_saka_basic(self):
        """Test getting all era years from Saka year."""
        result = get_all_era_years_from_saka(1821)
        expected = {"kali": 5000, "saka": 1821, "vikrama": 1956}
        assert result == expected

    def test_get_all_era_years_from_vikrama_basic(self):
        """Test getting all era years from Vikrama year."""
        result = get_all_era_years_from_vikrama(1956)
        expected = {"kali": 5000, "saka": 1821, "vikrama": 1956}
        assert result == expected

    def test_constants(self):
        """Test module constants."""
        assert KALI_TO_SAKA_OFFSET == 3179
        assert SAKA_TO_VIKRAMA_OFFSET == 135
        assert len(MASA_NAMES) == 12
        assert all(isinstance(name, str) for name in MASA_NAMES.values())

    def test_edge_cases(self):
        """Test edge cases."""
        # Test with zero values
        assert kali_to_saka(0) == -3179
        assert saka_to_kali(0) == 3179
        assert ahargana_to_kali(0) == 0

        # Test with large values
        assert kali_to_saka(10000) == 6821
        assert saka_to_kali(10000) == 13179

        # Test with negative values
        assert kali_to_saka(-1000) == -4179
        assert saka_to_kali(-1000) == 2179

    def test_consistency_checks(self):
        """Test consistency between related functions."""
        # Test round-trip conversions
        original_kali = 5000
        saka = kali_to_saka(original_kali)
        back_to_kali = saka_to_kali(saka)
        assert back_to_kali == original_kali

        original_saka = 1821
        vikrama = saka_to_vikrama(original_saka)
        back_to_saka = vikrama_to_saka(vikrama)
        assert back_to_saka == original_saka

        # Test that all era years are consistent
        kali_year = 5000
        all_years = get_all_era_years(kali_year)
        assert all_years["kali"] == kali_year
        assert all_years["saka"] == kali_to_saka(kali_year)
        assert all_years["vikrama"] == saka_to_vikrama(all_years["saka"])
