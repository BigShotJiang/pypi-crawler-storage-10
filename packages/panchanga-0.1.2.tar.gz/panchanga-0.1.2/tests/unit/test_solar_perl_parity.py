"""Perl parity tests for solar calculations."""

import math
from panchanga.solar import (
    get_saura_masa_day,
    get_saura_masa_name,
    today_saura_masa_first_p,
    find_samkranti,
    get_next_samkranti_info,
)


class TestSolarPerlParity:
    def test_get_saura_masa_day_perl_parity(self):
        """Test solar month day calculation matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (1000, (8, 27)),  # month=8 (Dhanus), day=27
            (2000, (5, 21)),  # month=5 (Kanya), day=21
            (3000, (2, 19)),  # month=2 (Mithuna), day=19
            (4000, (11, 16)),  # month=11 (Mina), day=16
            (5000, (8, 9)),  # month=8 (Dhanus), day=9
        ]

        for ahargana, expected in test_cases:
            result = get_saura_masa_day(ahargana)
            assert result == expected, (
                f"get_saura_masa_day({ahargana}) = {result}, expected {expected}"
            )

    def test_get_saura_masa_name_perl_parity(self):
        """Test solar month names match Perl exactly."""
        # Test all month names from Perl
        expected_names = {
            0: "Mesa   ",
            1: "Vrsa   ",
            2: "Mithuna",
            3: "Karkata",
            4: "Simha  ",
            5: "Kanya  ",
            6: "Tula   ",
            7: "Vrscika",
            8: "Dhanus ",
            9: "Makara ",
            10: "Kumbha ",
            11: "Mina   ",
        }

        for month_num, expected_name in expected_names.items():
            result = get_saura_masa_name(month_num)
            assert result == expected_name, (
                f"get_saura_masa_name({month_num}) = '{result}', expected '{expected_name}'"
            )

    def test_today_saura_masa_first_p_perl_parity(self):
        """Test first day predicate matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (1000, False),
            (2000, False),
            (3000, False),
            (4000, False),
            (5000, False),
        ]

        for ahargana, expected in test_cases:
            result = today_saura_masa_first_p(ahargana)
            assert result == expected, (
                f"today_saura_masa_first_p({ahargana}) = {result}, expected {expected}"
            )

    def test_find_samkranti_perl_parity(self):
        """Test samkranti bisection matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            ((1000, 1001), 1000.99999999255),
            ((2000, 2001), 2000.99999999255),
            ((3000, 3001), 3000.99999999255),
        ]

        for (o_ahar, n_ahar), expected in test_cases:
            result = find_samkranti(o_ahar, n_ahar)
            assert math.isclose(result, expected, rel_tol=1e-10), (
                f"find_samkranti({o_ahar}, {n_ahar}) = {result}, expected {expected}"
            )

    def test_get_next_samkranti_info_perl_parity(self):
        """Test next samkranti info matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (1000, (3, 23, 42, 1003.98762924224)),
            (2000, (11, 1, 59, 2011.08289968222)),
            (3000, (13, 21, 29, 3013.89560443908)),
            (4000, (15, 15, 35, 4015.64976816624)),
            (5000, (21, 20, 0, 5021.83395054191)),
        ]

        for ahargana, (
            expected_days,
            expected_hour,
            expected_min,
            expected_ahar,
        ) in test_cases:
            days_ahead, hour, minute, sk_ahar = get_next_samkranti_info(ahargana)

            assert days_ahead == expected_days, (
                f"days_ahead for {ahargana} = {days_ahead}, expected {expected_days}"
            )
            assert hour == expected_hour, f"hour for {ahargana} = {hour}, expected {expected_hour}"
            assert minute == expected_min, (
                f"minute for {ahargana} = {minute}, expected {expected_min}"
            )
            assert math.isclose(sk_ahar, expected_ahar, rel_tol=1e-10), (
                f"sk_ahar for {ahargana} = {sk_ahar}, expected {expected_ahar}"
            )

    def test_solar_month_names_match_perl(self):
        """Test that all solar month names match Perl exactly."""
        perl_names = [
            "Mesa   ",
            "Vrsa   ",
            "Mithuna",
            "Karkata",
            "Simha  ",
            "Kanya  ",
            "Tula   ",
            "Vrscika",
            "Dhanus ",
            "Makara ",
            "Kumbha ",
            "Mina   ",
        ]

        for i, expected_name in enumerate(perl_names):
            result = get_saura_masa_name(i)
            assert result == expected_name, f"Month {i}: got '{result}', expected '{expected_name}'"

    def test_edge_cases_perl_parity(self):
        """Test edge cases match Perl behavior."""
        # Test with zero ahargana
        month, day = get_saura_masa_day(0.0)
        assert isinstance(month, int)
        assert isinstance(day, int)
        assert 0 <= month <= 11
        assert 1 <= day <= 32

        # Test first day predicate with zero
        result = today_saura_masa_first_p(0.0)
        assert isinstance(result, bool)
