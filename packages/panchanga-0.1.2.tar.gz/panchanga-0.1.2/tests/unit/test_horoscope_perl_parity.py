"""
Perl parity tests for horoscope calculations.
"""

from panchanga.horoscope import (
    horoscope_calculation,
    format_horoscope_output,
    format_lagna_degrees,
)


class TestHoroscopePerlParity:
    """Test horoscope calculations for exact Perl parity."""

    def test_horoscope_basic_2024_01_01_12_00_perl_parity(self):
        """Test horoscope calculation matches Perl output for 2024-01-01 12:00."""
        result = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)

        # Check that lagna is close to expected value
        # Perl output: "11s 19d 57' 20""
        # This means: 11*30 + 19 + 57/60 + 20/3600 = 330 + 19 + 0.95 + 0.0056 = 349.9556
        expected_lagna = 11 * 30 + 19 + 57 / 60 + 20 / 3600
        assert abs(result["lagna"] - expected_lagna) < 0.1

        # Check other key values are reasonable
        assert isinstance(result["julian_day"], float)
        assert isinstance(result["ahargana"], float)
        assert isinstance(result["true_solar_long"], float)
        assert isinstance(result["solar_declination"], float)
        assert isinstance(result["solar_right_ascension"], float)

    def test_horoscope_equinox_2024_03_20_12_00_perl_parity(self):
        """Test horoscope calculation matches Perl output for 2024-03-20 12:00."""
        result = horoscope_calculation(2024, 3, 20, 12, 0, 23.2, 75.8)

        # Perl output: "2s 16d 1' 6""
        # This means: 2*30 + 16 + 1/60 + 6/3600 = 60 + 16 + 0.0167 + 0.0017 = 76.0184
        expected_lagna = 2 * 30 + 16 + 1 / 60 + 6 / 3600
        assert abs(result["lagna"] - expected_lagna) < 0.1

    def test_horoscope_solstice_2024_06_21_12_00_perl_parity(self):
        """Test horoscope calculation matches Perl output for 2024-06-21 12:00."""
        result = horoscope_calculation(2024, 6, 21, 12, 0, 23.2, 75.8)

        # Perl output: "5s 5d 51' 45""
        # This means: 5*30 + 5 + 51/60 + 45/3600 = 150 + 5 + 0.85 + 0.0125 = 155.8625
        expected_lagna = 5 * 30 + 5 + 51 / 60 + 45 / 3600
        assert abs(result["lagna"] - expected_lagna) < 0.1

    def test_format_lagna_degrees_perl_parity(self):
        """Test lagna formatting matches Perl output format."""
        # Test case 1: 349.9556 degrees (11s 19d 57' 20")
        result = format_lagna_degrees(349.9556)
        assert "11s" in result
        assert "19d" in result
        assert "57'" in result  # Changed from "57m" to "57'" (minutes symbol)
        assert '20"' in result  # Changed from "20s" to "20\"" (seconds symbol)

        # Test case 2: 76.0184 degrees (2s 16d 1' 6")
        result = format_lagna_degrees(76.0184)
        assert "2s" in result
        assert "16d" in result
        assert "1'" in result  # Changed from "1m" to "1'" (minutes symbol)
        assert '6"' in result  # Changed from "6s" to "6\"" (seconds symbol)

        # Test case 3: 155.8625 degrees (5s 5d 51' 45")
        result = format_lagna_degrees(155.8625)
        assert "5s" in result
        assert "5d" in result
        assert "51'" in result  # Changed from "51m" to "51'" (minutes symbol)
        assert '45"' in result  # Changed from "45s" to "45\"" (seconds symbol)

    def test_format_horoscope_output_perl_parity(self):
        """Test horoscope output formatting matches Perl output."""
        horoscope_data = {
            "year": 2024,
            "month": 1,
            "day": 1,
            "hours": 12,
            "minutes": 0,
            "latitude": 23.2,
            "lagna": 349.9556,
        }

        result = format_horoscope_output(horoscope_data)

        # Check key elements match Perl output format
        assert "Date: 2024  1  1" in result
        assert "Time: 12h 0m" in result
        assert "Lat.:23.2" in result  # No space after colon, includes decimal
        assert "Lagna =" in result
        assert "=" * 79 in result

        # Check that the output has the right structure
        lines = result.strip().split("\n")
        assert len(lines) == 3
        assert lines[0] == "=" * 79
        assert lines[2] == "=" * 79

    def test_horoscope_different_times_perl_parity(self):
        """Test horoscope calculations for different times."""
        # Test midnight
        result_midnight = horoscope_calculation(2024, 1, 1, 0, 0, 23.2, 75.8)
        assert isinstance(result_midnight["lagna"], float)

        # Test noon
        result_noon = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)
        assert isinstance(result_noon["lagna"], float)

        # Test evening
        result_evening = horoscope_calculation(2024, 1, 1, 18, 0, 23.2, 75.8)
        assert isinstance(result_evening["lagna"], float)

        # Different times should give different lagna values
        assert abs(result_midnight["lagna"] - result_noon["lagna"]) > 0.1
        assert abs(result_noon["lagna"] - result_evening["lagna"]) > 0.1

    def test_horoscope_different_latitudes_perl_parity(self):
        """Test horoscope calculations for different latitudes."""
        # Test high latitude
        result_high = horoscope_calculation(2024, 1, 1, 12, 0, 60.0, 75.8)
        assert isinstance(result_high["lagna"], float)

        # Test low latitude
        result_low = horoscope_calculation(2024, 1, 1, 12, 0, -30.0, 75.8)
        assert isinstance(result_low["lagna"], float)

        # Test equator
        result_equator = horoscope_calculation(2024, 1, 1, 12, 0, 0.0, 75.8)
        assert isinstance(result_equator["lagna"], float)

        # Different latitudes should give different lagna values
        assert abs(result_high["lagna"] - result_low["lagna"]) > 0.1
        assert abs(result_low["lagna"] - result_equator["lagna"]) > 0.1

    def test_horoscope_edge_cases_perl_parity(self):
        """Test horoscope calculations for edge cases."""
        # Test leap year
        result_leap = horoscope_calculation(2024, 2, 29, 12, 0, 23.2, 75.8)
        assert isinstance(result_leap["lagna"], float)

        # Test year boundary
        result_year_end = horoscope_calculation(2023, 12, 31, 12, 0, 23.2, 75.8)
        assert isinstance(result_year_end["lagna"], float)

        # Test extreme longitude
        result_extreme_lon = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 180.0)
        assert isinstance(result_extreme_lon["lagna"], float)

    def test_horoscope_consistency_perl_parity(self):
        """Test horoscope calculation consistency."""
        # Same input should give same output
        result1 = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)
        result2 = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)

        assert abs(result1["lagna"] - result2["lagna"]) < 1e-10
        assert abs(result1["julian_day"] - result2["julian_day"]) < 1e-10
        assert abs(result1["ahargana"] - result2["ahargana"]) < 1e-10
