"""Perl parity tests for calendar era conversions."""

from panchanga.calendars import (
    kali_to_saka,
    saka_to_kali,
    ahargana_to_kali,
    kali_to_ahargana,
    get_masa_name,
    get_vikrama_saura_masa_name,
    get_vikrama_solar_year,
)


class TestCalendarPerlParity:
    def test_kali_to_saka_perl_parity(self):
        """Test Kali to Saka conversion matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (5000, 1821),
            (5100, 1921),
            (5200, 2021),
            (5300, 2121),
            (5400, 2221),
        ]

        for kali_year, expected_saka in test_cases:
            result = kali_to_saka(kali_year)
            assert result == expected_saka, (
                f"kali_to_saka({kali_year}) = {result}, expected {expected_saka}"
            )

    def test_saka_to_kali_perl_parity(self):
        """Test Saka to Kali conversion matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (1821, 5000),
            (1921, 5100),
            (2021, 5200),
            (2121, 5300),
            (2221, 5400),
        ]

        for saka_year, expected_kali in test_cases:
            result = saka_to_kali(saka_year)
            assert result == expected_kali, (
                f"saka_to_kali({saka_year}) = {result}, expected {expected_kali}"
            )

    def test_ahargana_to_kali_perl_parity(self):
        """Test ahargana to Kali conversion matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (1000, 2),
            (2000, 5),
            (3000, 8),
            (4000, 10),
            (5000, 13),
        ]

        for ahargana, expected_kali in test_cases:
            result = ahargana_to_kali(ahargana)
            assert result == expected_kali, (
                f"ahargana_to_kali({ahargana}) = {result}, expected {expected_kali}"
            )

    def test_kali_to_ahargana_perl_parity(self):
        """Test Kali to ahargana conversion matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            ((5000, 0, 1), 1826290),
            ((5000, 5, 15), 1826452),
            ((5100, 11, 30), 1863173),
        ]

        for (kali_year, masa_num, tithi_day), expected_ahar in test_cases:
            result = kali_to_ahargana(kali_year, masa_num, tithi_day)
            assert result == expected_ahar, (
                f"kali_to_ahargana({kali_year}, {masa_num}, {tithi_day}) = {result}, expected {expected_ahar}"
            )

    def test_get_masa_name_perl_parity(self):
        """Test lunar month names match Perl exactly."""
        # Test all month names from Perl
        expected_names = {
            0: "Caitra    ",
            1: "Vaisakha  ",
            2: "Jyaistha  ",
            3: "Asadha    ",
            4: "Sravana   ",
            5: "Bhadrapada",
            6: "Asvina    ",
            7: "Karttika  ",
            8: "Margasirsa",
            9: "Pausa     ",
            10: "Magha     ",
            11: "Phalguna  ",
        }

        for month_num, expected_name in expected_names.items():
            result = get_masa_name(month_num)
            assert result == expected_name, (
                f"get_masa_name({month_num}) = '{result}', expected '{expected_name}'"
            )

    def test_get_vikrama_saura_masa_name_perl_parity(self):
        """Test Vikram saura masa name mapping matches Perl exactly."""
        # Test cases from Perl verification script
        expected_mappings = {
            0: "Vaisakha  ",
            1: "Jyaistha  ",
            2: "Asadha    ",
            3: "Sravana   ",
            4: "Bhadrapada",
            5: "Asvina    ",
            6: "Karttika  ",
            7: "Margasirsa",
            8: "Pausa     ",
            9: "Magha     ",
            10: "Phalguna  ",
            11: "Caitra    ",
        }

        for saura_num, expected_name in expected_mappings.items():
            result = get_vikrama_saura_masa_name(saura_num)
            assert result == expected_name, (
                f"get_vikrama_saura_masa_name({saura_num}) = '{result}', expected '{expected_name}'"
            )

    def test_get_vikrama_solar_year_perl_parity(self):
        """Test Vikram Samvat solar year logic matches Perl exactly."""
        base_year = 2080

        # Test cases from Perl verification script
        test_cases = [
            (0, 2080),  # Mesa
            (5, 2080),  # Kanya
            (10, 2080),  # Kumbha
            (11, 2079),  # Mina
        ]

        for saura_masa_num, expected_year in test_cases:
            result = get_vikrama_solar_year(base_year, saura_masa_num)
            assert result == expected_year, (
                f"get_vikrama_solar_year({base_year}, {saura_masa_num}) = {result}, expected {expected_year}"
            )

    def test_round_trip_consistency_perl_parity(self):
        """Test round-trip consistency matches Perl exactly."""
        # Test cases from Perl verification script
        test_cases = [
            (5000, 0, 1, 4999),  # Kali(5000,0,1) → Ahar(1826290) → Kali(4999)
            (5000, 5, 15, 5000),  # Kali(5000,5,15) → Ahar(1826452) → Kali(5000)
            (5100, 11, 30, 5100),  # Kali(5100,11,30) → Ahar(1863173) → Kali(5100)
        ]

        for kali_year, masa_num, tithi_day, expected_back_kali in test_cases:
            ahar = kali_to_ahargana(kali_year, masa_num, tithi_day)
            back_kali = ahargana_to_kali(ahar)
            assert back_kali == expected_back_kali, (
                f"Round-trip: Kali({kali_year},{masa_num},{tithi_day}) → Ahar({ahar}) → Kali({back_kali}), expected {expected_back_kali}"
            )

    def test_lunar_month_names_match_perl(self):
        """Test that all lunar month names match Perl exactly."""
        perl_names = [
            "Caitra    ",
            "Vaisakha  ",
            "Jyaistha  ",
            "Asadha    ",
            "Sravana   ",
            "Bhadrapada",
            "Asvina    ",
            "Karttika  ",
            "Margasirsa",
            "Pausa     ",
            "Magha     ",
            "Phalguna  ",
        ]

        for i, expected_name in enumerate(perl_names):
            result = get_masa_name(i)
            assert result == expected_name, f"Month {i}: got '{result}', expected '{expected_name}'"

    def test_vikram_saura_masa_mapping_match_perl(self):
        """Test that Vikram saura masa mapping matches Perl exactly."""
        perl_mappings = [
            "Vaisakha  ",
            "Jyaistha  ",
            "Asadha    ",
            "Sravana   ",
            "Bhadrapada",
            "Asvina    ",
            "Karttika  ",
            "Margasirsa",
            "Pausa     ",
            "Magha     ",
            "Phalguna  ",
            "Caitra    ",
        ]

        for i, expected_name in enumerate(perl_mappings):
            result = get_vikrama_saura_masa_name(i)
            assert result == expected_name, (
                f"Saura month {i}: got '{result}', expected '{expected_name}'"
            )

    def test_edge_cases_perl_parity(self):
        """Test edge cases match Perl behavior."""
        # Test with zero values
        assert kali_to_saka(0) == -3179
        assert saka_to_kali(0) == 3179
        assert ahargana_to_kali(0) == 0

        # Test with large values
        assert kali_to_saka(10000) == 6821
        assert saka_to_kali(10000) == 13179

        # Test with negative values
        assert kali_to_saka(-1000) == -4179
        assert saka_to_kali(-1000) == 2179
