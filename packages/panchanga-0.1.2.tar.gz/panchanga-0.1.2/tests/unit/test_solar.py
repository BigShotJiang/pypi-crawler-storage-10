"""Tests for solar calculations module."""

import math
from panchanga.solar import (
    get_true_solar_longitude,
    today_saura_masa_first_p,
    get_saura_masa_day,
    get_saura_masa_name,
    find_samkranti,
    get_next_samkranti_info,
    SAURA_MASA_NAMES,
    SOLAR_APOGEE,
)


class TestSolarCalculations:
    def test_get_true_solar_longitude_basic(self):
        """Test basic true solar longitude calculation."""
        # Test with known ahargana values
        result1 = get_true_solar_longitude(1000.0)
        assert isinstance(result1, float)
        assert 0 <= result1 < 360

        result2 = get_true_solar_longitude(2000.0)
        assert isinstance(result2, float)
        assert 0 <= result2 < 360

        # Results should be different for different ahargana
        assert not math.isclose(result1, result2, rel_tol=1e-10)

    def test_today_saura_masa_first_p_basic(self):
        """Test first day predicate."""
        # Test with various ahargana values
        result1 = today_saura_masa_first_p(1000.0)
        assert isinstance(result1, bool)

        result2 = today_saura_masa_first_p(2000.0)
        assert isinstance(result2, bool)

    def test_get_saura_masa_day_basic(self):
        """Test solar month day calculation."""
        # Test with known ahargana values
        month1, day1 = get_saura_masa_day(1000.0)
        assert isinstance(month1, int)
        assert isinstance(day1, int)
        assert 0 <= month1 <= 11
        assert 1 <= day1 <= 32  # Solar months can have up to 32 days

        month2, day2 = get_saura_masa_day(2000.0)
        assert isinstance(month2, int)
        assert isinstance(day2, int)
        assert 0 <= month2 <= 11
        assert 1 <= day2 <= 32

    def test_get_saura_masa_name_basic(self):
        """Test solar month name lookup."""
        # Test all month numbers
        for month_num in range(12):
            name = get_saura_masa_name(month_num)
            assert isinstance(name, str)
            assert name in SAURA_MASA_NAMES.values()

        # Test specific names
        assert get_saura_masa_name(0) == "Mesa   "
        assert get_saura_masa_name(11) == "Mina   "

    def test_find_samkranti_basic(self):
        """Test samkranti bisection."""
        # Test with known ranges
        result1 = find_samkranti(1000.0, 1001.0)
        assert isinstance(result1, float)
        assert 1000.0 <= result1 <= 1001.0

        result2 = find_samkranti(2000.0, 2001.0)
        assert isinstance(result2, float)
        assert 2000.0 <= result2 <= 2001.0

    def test_get_next_samkranti_info_basic(self):
        """Test next samkranti info calculation."""
        # Test with known ahargana values
        days_ahead, hour, minute, sk_ahar = get_next_samkranti_info(1000.0)

        if days_ahead is not None:
            assert isinstance(days_ahead, int)
            assert isinstance(hour, int)
            assert isinstance(minute, int)
            assert isinstance(sk_ahar, float)
            assert 0 <= days_ahead < 60
            assert 0 <= hour < 24
            assert 0 <= minute < 60
            assert sk_ahar > 1000.0

    def test_constants(self):
        """Test module constants."""
        assert len(SAURA_MASA_NAMES) == 12
        assert all(isinstance(name, str) for name in SAURA_MASA_NAMES.values())
        assert isinstance(SOLAR_APOGEE, float)
        assert 70 <= SOLAR_APOGEE <= 80

    def test_edge_cases(self):
        """Test edge cases."""
        # Test with zero ahargana
        month, day = get_saura_masa_day(0.0)
        assert 0 <= month <= 11
        assert 1 <= day <= 32

        # Test with very large ahargana
        month, day = get_saura_masa_day(100000.0)
        assert 0 <= month <= 11
        assert 1 <= day <= 32

        # Test first day predicate with edge values
        result1 = today_saura_masa_first_p(0.0)
        assert isinstance(result1, bool)

        result2 = today_saura_masa_first_p(100000.0)
        assert isinstance(result2, bool)

    def test_consistency_checks(self):
        """Test consistency between related functions."""
        # Test that consecutive days have consistent solar month calculations
        ahar1 = 1000.0
        ahar2 = 1001.0

        month1, day1 = get_saura_masa_day(ahar1)
        month2, day2 = get_saura_masa_day(ahar2)

        # Either same month with day+1, or different month with day=1
        if month1 == month2:
            assert day2 == day1 + 1
        else:
            assert day2 == 1
