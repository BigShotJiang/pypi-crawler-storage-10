"""
Unit tests for horoscope calculation functions.
"""

from panchanga.horoscope import (
    declination,
    right_ascension,
    ascendant,
    horoscope_calculation,
    format_lagna_degrees,
    format_horoscope_output,
)


class TestHoroscopeCalculations:
    """Test horoscope calculation functions."""

    def test_declination_basic(self):
        """Test basic declination calculation."""
        # Test at equinox (longitude = 0)
        result = declination(0)
        assert abs(result) < 0.1  # Should be close to 0

        # Test at solstice (longitude = 90)
        result = declination(90)
        assert abs(result - 24) < 0.1  # Should be close to ecliptic obliquity

    def test_right_ascension_basic(self):
        """Test basic right ascension calculation."""
        # Test with declination = 0
        result = right_ascension(0, 0)
        assert abs(result) < 0.1  # Should be close to 0

        result = right_ascension(90, 0)
        assert isinstance(result, float)  # Should return a valid float

    def test_ascendant_basic(self):
        """Test basic ascendant calculation."""
        # Test at equator (latitude = 0)
        result = ascendant(0, 0)
        assert isinstance(result, float)

        result = ascendant(90, 0)
        assert isinstance(result, float)

    def test_horoscope_calculation_basic(self):
        """Test basic horoscope calculation."""
        result = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)

        assert result["year"] == 2024
        assert result["month"] == 1
        assert result["day"] == 1
        assert result["hours"] == 12
        assert result["minutes"] == 0
        assert result["latitude"] == 23.2
        assert result["longitude"] == 75.8

        # Check that all required fields are present
        required_fields = [
            "julian_day",
            "ahargana",
            "mean_solar_long",
            "true_solar_long",
            "sayana_solar_long",
            "solar_declination",
            "solar_right_ascension",
            "time_degree",
            "hrasc",
            "ascendant",
            "lagna",
        ]
        for field in required_fields:
            assert field in result
            assert isinstance(result[field], (int, float))

    def test_format_lagna_degrees_basic(self):
        """Test lagna degrees formatting."""
        result = format_lagna_degrees(0)
        assert "0s" in result
        assert "0d" in result

        result = format_lagna_degrees(30)
        assert "1s" in result
        assert "0d" in result

        result = format_lagna_degrees(45)
        assert "1s" in result
        assert "15d" in result

    def test_format_horoscope_output_basic(self):
        """Test horoscope output formatting."""
        horoscope_data = {
            "year": 2024,
            "month": 1,
            "day": 1,
            "hours": 12,
            "minutes": 0,
            "latitude": 23.2,
            "lagna": 45.5,
        }

        result = format_horoscope_output(horoscope_data)

        assert "Date: 2024  1  1" in result
        assert "Time: 12h 0m" in result
        assert "Lat.:23.2" in result  # No space after colon, includes decimal
        assert "Lagna =" in result
        assert "=" * 79 in result

    def test_edge_cases(self):
        """Test edge cases."""
        # Test extreme latitudes
        result = horoscope_calculation(2024, 1, 1, 12, 0, 90, 0)
        assert isinstance(result["lagna"], (int, float))

        result = horoscope_calculation(2024, 1, 1, 12, 0, -90, 0)
        assert isinstance(result["lagna"], (int, float))

        # Test extreme times
        result = horoscope_calculation(2024, 1, 1, 0, 0, 23.2, 75.8)
        assert isinstance(result["lagna"], (int, float))

        result = horoscope_calculation(2024, 1, 1, 23, 59, 23.2, 75.8)
        assert isinstance(result["lagna"], (int, float))

    def test_consistency_checks(self):
        """Test consistency of calculations."""
        # Same input should give same output
        result1 = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)
        result2 = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)

        assert abs(result1["lagna"] - result2["lagna"]) < 1e-10

        # Different times should give different lagna
        result1 = horoscope_calculation(2024, 1, 1, 12, 0, 23.2, 75.8)
        result2 = horoscope_calculation(2024, 1, 1, 12, 30, 23.2, 75.8)

        assert abs(result1["lagna"] - result2["lagna"]) > 0.1
