"""Fuzz tests for calendar era conversions using hypothesis."""

from hypothesis import given, strategies as st
from panchanga.calendars import (
    kali_to_saka,
    saka_to_kali,
    saka_to_vikrama,
    vikrama_to_saka,
    ahargana_to_kali,
    kali_to_ahargana,
    get_masa_name,
    get_vikrama_saura_masa_name,
    get_vikrama_solar_year,
    get_all_era_years,
    get_all_era_years_from_saka,
    get_all_era_years_from_vikrama,
)


class TestCalendarFuzz:
    @given(st.integers(min_value=-10000, max_value=10000))
    def test_kali_to_saka_properties(self, kali_year):
        """Test Kali to Saka conversion properties with fuzzed inputs."""
        result = kali_to_saka(kali_year)

        # Should be an integer
        assert isinstance(result, int)

        # Should be kali_year - 3179
        assert result == kali_year - 3179

    @given(st.integers(min_value=-10000, max_value=10000))
    def test_saka_to_kali_properties(self, saka_year):
        """Test Saka to Kali conversion properties with fuzzed inputs."""
        result = saka_to_kali(saka_year)

        # Should be an integer
        assert isinstance(result, int)

        # Should be saka_year + 3179
        assert result == saka_year + 3179

    @given(st.integers(min_value=-10000, max_value=10000))
    def test_saka_to_vikrama_properties(self, saka_year):
        """Test Saka to Vikrama conversion properties with fuzzed inputs."""
        result = saka_to_vikrama(saka_year)

        # Should be an integer
        assert isinstance(result, int)

        # Should be saka_year + 135
        assert result == saka_year + 135

    @given(st.integers(min_value=-10000, max_value=10000))
    def test_vikrama_to_saka_properties(self, vikrama_year):
        """Test Vikrama to Saka conversion properties with fuzzed inputs."""
        result = vikrama_to_saka(vikrama_year)

        # Should be an integer
        assert isinstance(result, int)

        # Should be vikrama_year - 135
        assert result == vikrama_year - 135

    @given(st.floats(min_value=0, max_value=100000, allow_nan=False, allow_infinity=False))
    def test_ahargana_to_kali_properties(self, ahargana):
        """Test ahargana to Kali conversion properties with fuzzed inputs."""
        result = ahargana_to_kali(ahargana)

        # Should be an integer
        assert isinstance(result, int)

        # Should be non-negative for reasonable ahargana values
        assert result >= 0

    @given(
        st.integers(min_value=0, max_value=10000),
        st.integers(min_value=0, max_value=11),
        st.integers(min_value=1, max_value=30),
    )
    def test_kali_to_ahargana_properties(self, kali_year, masa_num, tithi_day):
        """Test Kali to ahargana conversion properties with fuzzed inputs."""
        result = kali_to_ahargana(kali_year, masa_num, tithi_day)

        # Should be a number (int or float)
        assert isinstance(result, (int, float))

        # Should be non-negative
        assert result >= 0

    @given(st.integers(min_value=0, max_value=11))
    def test_get_masa_name_properties(self, masa_num):
        """Test lunar month name properties with fuzzed inputs."""
        result = get_masa_name(masa_num)

        # Should be a string
        assert isinstance(result, str)

        # Should not be empty
        assert len(result) > 0

    @given(st.integers(min_value=0, max_value=11))
    def test_get_vikrama_saura_masa_name_properties(self, saura_num):
        """Test Vikram saura masa name properties with fuzzed inputs."""
        result = get_vikrama_saura_masa_name(saura_num)

        # Should be a string
        assert isinstance(result, str)

        # Should not be empty
        assert len(result) > 0

    @given(
        st.integers(min_value=0, max_value=10000),
        st.integers(min_value=0, max_value=11),
    )
    def test_get_vikrama_solar_year_properties(self, vikrama_year, saura_masa_num):
        """Test Vikram Samvat solar year properties with fuzzed inputs."""
        result = get_vikrama_solar_year(vikrama_year, saura_masa_num)

        # Should be an integer
        assert isinstance(result, int)

        # Should be vikrama_year or vikrama_year - 1
        assert result == vikrama_year or result == vikrama_year - 1

        # If saura_masa_num is 11 (Mina), should be vikrama_year - 1
        if saura_masa_num == 11:
            assert result == vikrama_year - 1
        else:
            assert result == vikrama_year

    @given(st.integers(min_value=0, max_value=10000))
    def test_get_all_era_years_properties(self, kali_year):
        """Test getting all era years properties with fuzzed inputs."""
        result = get_all_era_years(kali_year)

        # Should be a dictionary
        assert isinstance(result, dict)

        # Should have all required keys
        assert "kali" in result
        assert "saka" in result
        assert "vikrama" in result

        # Should be integers
        assert isinstance(result["kali"], int)
        assert isinstance(result["saka"], int)
        assert isinstance(result["vikrama"], int)

        # Should be consistent
        assert result["kali"] == kali_year
        assert result["saka"] == kali_year - 3179
        assert result["vikrama"] == kali_year - 3179 + 135

    @given(st.integers(min_value=0, max_value=10000))
    def test_get_all_era_years_from_saka_properties(self, saka_year):
        """Test getting all era years from Saka properties with fuzzed inputs."""
        result = get_all_era_years_from_saka(saka_year)

        # Should be a dictionary
        assert isinstance(result, dict)

        # Should have all required keys
        assert "kali" in result
        assert "saka" in result
        assert "vikrama" in result

        # Should be integers
        assert isinstance(result["kali"], int)
        assert isinstance(result["saka"], int)
        assert isinstance(result["vikrama"], int)

        # Should be consistent
        assert result["saka"] == saka_year
        assert result["kali"] == saka_year + 3179
        assert result["vikrama"] == saka_year + 135

    @given(st.integers(min_value=0, max_value=10000))
    def test_get_all_era_years_from_vikrama_properties(self, vikrama_year):
        """Test getting all era years from Vikrama properties with fuzzed inputs."""
        result = get_all_era_years_from_vikrama(vikrama_year)

        # Should be a dictionary
        assert isinstance(result, dict)

        # Should have all required keys
        assert "kali" in result
        assert "saka" in result
        assert "vikrama" in result

        # Should be integers
        assert isinstance(result["kali"], int)
        assert isinstance(result["saka"], int)
        assert isinstance(result["vikrama"], int)

        # Should be consistent
        assert result["vikrama"] == vikrama_year
        assert result["saka"] == vikrama_year - 135
        assert result["kali"] == vikrama_year - 135 + 3179

    @given(st.integers(min_value=0, max_value=10000))
    def test_era_conversion_consistency(self, kali_year):
        """Test consistency between era conversions with fuzzed inputs."""
        # Test round-trip conversions
        saka = kali_to_saka(kali_year)
        back_to_kali = saka_to_kali(saka)
        assert back_to_kali == kali_year

        vikrama = saka_to_vikrama(saka)
        back_to_saka = vikrama_to_saka(vikrama)
        assert back_to_saka == saka

        # Test that all era years are consistent
        all_years = get_all_era_years(kali_year)
        assert all_years["kali"] == kali_year
        assert all_years["saka"] == saka
        assert all_years["vikrama"] == vikrama

    @given(
        st.integers(min_value=0, max_value=1000),
        st.integers(min_value=0, max_value=11),
        st.integers(min_value=1, max_value=30),
    )
    def test_kali_ahargana_round_trip_consistency(self, kali_year, masa_num, tithi_day):
        """Test Kali to ahargana round-trip consistency with fuzzed inputs."""
        ahar = kali_to_ahargana(kali_year, masa_num, tithi_day)
        back_kali = ahargana_to_kali(ahar)

        # Should be close to original (allowing for rounding differences)
        assert abs(back_kali - kali_year) <= 1

    @given(st.integers(min_value=0, max_value=11))
    def test_vikram_saura_masa_mapping_consistency(self, saura_num):
        """Test Vikram saura masa mapping consistency with fuzzed inputs."""
        vs_name = get_vikrama_saura_masa_name(saura_num)

        # Should be a valid lunar month name
        assert isinstance(vs_name, str)
        assert len(vs_name) > 0

        # Should be one of the known month names
        known_names = [
            "Caitra    ",
            "Vaisakha  ",
            "Jyaistha  ",
            "Asadha    ",
            "Sravana   ",
            "Bhadrapada",
            "Asvina    ",
            "Karttika  ",
            "Margasirsa",
            "Pausa     ",
            "Magha     ",
            "Phalguna  ",
        ]
        assert vs_name in known_names

    @given(st.integers(min_value=0, max_value=10000))
    def test_edge_case_years(self, year):
        """Test edge cases with various year values."""
        # Test with zero
        if year == 0:
            assert kali_to_saka(0) == -3179
            assert saka_to_kali(0) == 3179

        # Test with large values
        if year > 5000:
            assert kali_to_saka(year) == year - 3179
            assert saka_to_kali(year) == year + 3179

        # Test with negative values
        if year < 0:
            assert kali_to_saka(year) == year - 3179
            assert saka_to_kali(year) == year + 3179
