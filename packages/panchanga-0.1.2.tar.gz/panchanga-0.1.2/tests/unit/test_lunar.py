"""Tests for lunar calculation functions."""

from panchanga.lunar import (
    get_tithi,
    get_tithi_set,
    set_sukla_krsna,
    get_naksatra_name,
    get_yoga_name,
    get_karana_name,
)


class TestLunarCalculations:
    """Test lunar calculation functions."""

    def test_get_tithi_basic(self):
        """Test basic tithi calculation."""
        # Test with known values
        tllong = 100.0  # True lunar longitude
        tslong = 90.0  # True solar longitude

        result = get_tithi(tllong, tslong)

        # Should be a reasonable tithi value
        assert 0 <= result < 30
        assert isinstance(result, float)

    def test_get_tithi_set_basic(self):
        """Test basic tithi set calculation."""
        # Test with known values
        tithi = 5.5

        tithi_day, ftithi = get_tithi_set(tithi)

        # Should return integer day and fractional part
        assert isinstance(tithi_day, int)
        assert isinstance(ftithi, float)
        assert 1 <= tithi_day <= 30
        assert 0 <= ftithi < 1

    def test_set_sukla_krsna_basic(self):
        """Test basic sukla/krsna paksa determination."""
        # Test sukla paksa (first 15 days)
        tithi_day = 5
        result_tithi_day, sukla_krsna, paksa = set_sukla_krsna(tithi_day)

        assert result_tithi_day == 5
        assert paksa == "Suklapaksa"
        assert sukla_krsna in ["Sukla", "Krsna"]

        # Test krsna paksa (last 15 days)
        tithi_day = 20
        result_tithi_day, sukla_krsna, paksa = set_sukla_krsna(tithi_day)

        assert result_tithi_day == 5  # 20 - 15 = 5
        assert paksa == "Krsnapaksa"

    def test_get_naksatra_name_basic(self):
        """Test basic nakshatra name calculation."""
        # Test with known values
        tllong = 0.0  # Should be Asvini

        result = get_naksatra_name(tllong)

        assert isinstance(result, str)
        assert result == "Asvini"

        # Test another nakshatra
        tllong = 13.33  # Should be Asvini (index 0)
        result = get_naksatra_name(tllong)
        assert result == "Asvini"

    def test_get_yoga_name_basic(self):
        """Test basic yoga name calculation."""
        # Test with known values
        tslong = 0.0  # True solar longitude
        tllong = 0.0  # True lunar longitude

        result = get_yoga_name(tslong, tllong)

        assert isinstance(result, str)
        assert result == "viSkambha"  # First yoga

    def test_get_karana_name_basic(self):
        """Test basic karana name calculation."""
        # Test with known values
        tithi = 0.0  # Should be first karana

        result = get_karana_name(tithi)

        assert isinstance(result, str)
        assert result in [
            "kiMstughna",
            "bava      ",
            "bAlava    ",
            "kaulava   ",
            "taitila   ",
            "gara      ",
            "vaNij     ",
            "viSTi     ",
            "zakuni    ",
            "catuSpada ",
            "nAga      ",
        ]

    def test_tithi_edge_cases(self):
        """Test edge cases for tithi calculations."""
        # Test with equal longitudes (should be 0)
        result = get_tithi(100.0, 100.0)
        assert abs(result) < 1e-10

        # Test with 360 degree difference (should be 0)
        result = get_tithi(100.0, 460.0)
        assert abs(result) < 1e-10

        # Test with negative difference
        result = get_tithi(50.0, 100.0)
        assert 0 <= result < 30

    def test_naksatra_edge_cases(self):
        """Test edge cases for nakshatra calculations."""
        # Test boundary values
        result = get_naksatra_name(0.0)
        assert result == "Asvini"

        result = get_naksatra_name(360.0)
        assert result == "Asvini"  # Should wrap around

        # Test negative longitude
        result = get_naksatra_name(-10.0)
        assert isinstance(result, str)

    def test_yoga_edge_cases(self):
        """Test edge cases for yoga calculations."""
        # Test with large longitudes
        result = get_yoga_name(720.0, 360.0)
        assert isinstance(result, str)

        # Test with negative longitudes
        result = get_yoga_name(-10.0, -5.0)
        assert isinstance(result, str)

    def test_karana_edge_cases(self):
        """Test edge cases for karana calculations."""
        # Test with large tithi values
        result = get_karana_name(30.0)
        assert isinstance(result, str)

        # Test with negative tithi values
        result = get_karana_name(-5.0)
        assert isinstance(result, str)

    def test_consistency_checks(self):
        """Test consistency between related functions."""
        # Test that tithi_set and sukla_krsna work together
        tithi = 5.5
        tithi_day, ftithi = get_tithi_set(tithi)
        result_tithi_day, sukla_krsna, paksa = set_sukla_krsna(tithi_day)

        assert result_tithi_day == tithi_day
        assert paksa in ["Suklapaksa", "Krsnapaksa"]

        # Test that nakshatra names are valid
        for i in range(28):  # Test all nakshatra positions
            tllong = i * 13.33  # Approximate nakshatra width
            nakshatra = get_naksatra_name(tllong)
            assert isinstance(nakshatra, str)
            assert len(nakshatra) > 0
