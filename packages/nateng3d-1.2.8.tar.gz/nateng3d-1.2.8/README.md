# NatEng3D - 3D Game Engine

A Python-based 3D engine inspired by Source Engine, featuring a complete SDK with level editor.

## Installation

```bash
pip install nateng3d

Quick Start
python

from nateng3d import NatEng3D, Vector3
from nateng3d.engine.core import PrimitiveGenerator

# Create engine instance
engine = NatEng3D("My Game", 1280, 720)

# Create a cube
vertices, indices = PrimitiveGenerator.create_cube()
mesh = engine.load_mesh("my_cube", vertices, indices)

entity = engine.create_entity("Cube")
entity['mesh'] = mesh
entity['position'] = Vector3(0, 0, 0)

# Run the engine
engine.run()

Features

    Pure Python - Built with tkinter and numpy

    3D Rendering - Perspective projection, camera, meshes

    Entity-Component System - Modular architecture

    SDK with Editor - Hammer-like level editor

    Primitive Generation - Cubes, spheres, planes

SDK Tools

Run the level editor:
python

from nateng3d.sdk import HammerEditor

editor = HammerEditor()
editor.run()

Controls

    WASD - Camera movement

    Arrow Keys - Camera rotation

    F1 - Toggle wireframe mode

    F2 - Toggle debug info

Examples

Check the examples/ directory for more usage examples.