from .azure_server import main as azure_main
import asyncio

def main():
    """Main entry point for the package."""
    asyncio.run(azure_main())

# Optionally expose other important items at package level
__all__ = ["main"]

if __name__ == "__main__":
    main()