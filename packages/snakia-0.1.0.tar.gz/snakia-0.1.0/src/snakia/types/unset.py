from typing import final

from snakia.types import Unique


@final
class Unset(Unique):
    pass
