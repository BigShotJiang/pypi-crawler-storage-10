from typing import Any, final


def func(*a: Any, **kw: Any) -> Any:
    pass


async def async_func(*a: Any, **kw: Any) -> Any:
    pass


@final
class Class:
    pass
