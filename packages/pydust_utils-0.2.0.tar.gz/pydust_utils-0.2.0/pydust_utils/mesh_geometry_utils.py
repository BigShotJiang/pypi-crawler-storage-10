"""
Geometry utility functions for mesh generation and visualization.

This module provides utilities for:
- NACA airfoil profile generation
- Spline interpolation for wing sections
- Mesh discretization methods (uniform, cosine, geoseries)
- Coordinate transformations
"""

import numpy as np
from scipy import interpolate


def generate_naca_4digit(naca_code: str, n_points: int = 100, closed_te: bool = True) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate NACA 4-digit airfoil coordinates.
    
    Parameters
    ----------
    naca_code : str
        4-digit NACA code (e.g., '0012', '2412')
    n_points : int
        Number of points on the airfoil surface
    closed_te : bool
        If True, close the trailing edge
    
    Returns
    -------
    x : np.ndarray
        X coordinates (chord-wise, 0 to 1)
    y : np.ndarray
        Y coordinates (thickness)
    """
    if len(naca_code) != 4:
        raise ValueError(f"NACA code must be 4 digits, got: {naca_code}")
    
    m = int(naca_code[0]) / 100.0  # Maximum camber
    p = int(naca_code[1]) / 10.0   # Location of maximum camber
    t = int(naca_code[2:4]) / 100.0  # Maximum thickness
    
    # Cosine spacing for better resolution near leading edge
    beta = np.linspace(0, np.pi, n_points // 2)
    x = (1 - np.cos(beta)) / 2
    
    # Thickness distribution (symmetric)
    yt = 5 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 
                   0.2843 * x**3 - 0.1015 * x**4)
    
    # Camber line
    if m == 0 or p == 0:
        # Symmetric airfoil
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p,
                      m / p**2 * (2 * p * x - x**2),
                      m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p,
                          2 * m / p**2 * (p - x),
                          2 * m / (1 - p)**2 * (p - x))
    
    # Angle of camber line
    theta = np.arctan(dyc_dx)
    
    # Upper and lower surface coordinates
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    
    # Combine upper and lower surfaces (counterclockwise from TE)
    if closed_te:
        x_airfoil = np.concatenate([xu[::-1], xl[1:]])
        y_airfoil = np.concatenate([yu[::-1], yl[1:]])
    else:
        x_airfoil = np.concatenate([xu[::-1], xl])
        y_airfoil = np.concatenate([yu[::-1], yl])
    
    return x_airfoil, y_airfoil


def generate_naca_5digit(naca_code: str, n_points: int = 100, closed_te: bool = True) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate NACA 5-digit airfoil coordinates.
    
    Parameters
    ----------
    naca_code : str
        5-digit NACA code (e.g., '23012')
    n_points : int
        Number of points on the airfoil surface
    closed_te : bool
        If True, close the trailing edge
    
    Returns
    -------
    x : np.ndarray
        X coordinates (chord-wise, 0 to 1)
    y : np.ndarray
        Y coordinates (thickness)
    """
    if len(naca_code) != 5:
        raise ValueError(f"NACA code must be 5 digits, got: {naca_code}")
    
    # Parse 5-digit code
    L = int(naca_code[0])  # Design lift coefficient * 20 / 3
    P = int(naca_code[1])  # Location of max camber * 20
    Q = int(naca_code[2])  # Type (0 = standard, 1 = reflexed)
    t = int(naca_code[3:5]) / 100.0  # Maximum thickness
    
    # Cosine spacing
    beta = np.linspace(0, np.pi, n_points // 2)
    x = (1 - np.cos(beta)) / 2
    
    # Thickness distribution
    yt = 5 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 
                   0.2843 * x**3 - 0.1015 * x**4)
    
    # Camber line parameters (simplified - using approximation)
    m = L * 0.05 / 3  # Approximate max camber
    p = P / 20.0      # Position of max camber
    
    # Use 4-digit camber approximation for simplicity
    if m == 0 or p == 0:
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p,
                      m / p**2 * (2 * p * x - x**2),
                      m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p,
                          2 * m / p**2 * (p - x),
                          2 * m / (1 - p)**2 * (p - x))
    
    theta = np.arctan(dyc_dx)
    
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    
    if closed_te:
        x_airfoil = np.concatenate([xu[::-1], xl[1:]])
        y_airfoil = np.concatenate([yu[::-1], yl[1:]])
    else:
        x_airfoil = np.concatenate([xu[::-1], xl])
        y_airfoil = np.concatenate([yu[::-1], yl])
    
    return x_airfoil, y_airfoil


def read_airfoil_from_file(filepath: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Read airfoil coordinates from file.
    
    Expects format with x, y coordinates (one per line).
    
    Parameters
    ----------
    filepath : str
        Path to airfoil data file
    
    Returns
    -------
    x : np.ndarray
        X coordinates
    y : np.ndarray
        Y coordinates
    """
    data = np.loadtxt(filepath, skiprows=1) # Skip header line 
    return data[:, 0], data[:, 1]


def get_airfoil_coordinates(airfoil_spec: str, n_points: int = 100) -> tuple[np.ndarray, np.ndarray]:
    """
    Get airfoil coordinates from NACA code or file.
    
    Parameters
    ----------
    airfoil_spec : str
        NACA code (e.g., 'naca0012') or file path
    n_points : int
        Number of points for NACA generation
    
    Returns
    -------
    x : np.ndarray
        X coordinates (0 to 1)
    y : np.ndarray
        Y coordinates
    """
    airfoil_lower = airfoil_spec.lower()
    
    if airfoil_lower.startswith('naca'):
        naca_code = airfoil_lower.replace('naca', '').strip()
        if len(naca_code) == 4:
            return generate_naca_4digit(naca_code, n_points)
        elif len(naca_code) == 5:
            return generate_naca_5digit(naca_code, n_points)
        else:
            raise ValueError(f"Unsupported NACA code length: {naca_code}")
    else:
        # Assume it's a file path
        return read_airfoil_from_file(airfoil_spec)


def chord_distribution(n_elem: int, distribution_type: str, **kwargs) -> np.ndarray:
    """
    Generate chord-wise distribution of points.
    
    Parameters
    ----------
    n_elem : int
        Number of elements
    distribution_type : str
        Type of distribution: 'uniform', 'cosine', 'cosine_le', 'cosine_te',
        'geoseries', 'geoseries_le', 'geoseries_te', 'geoseries_ob', 
        'geoseries_ib', 'geoseries_hi'
    **kwargs : dict
        Additional parameters:
        - r, r_le, r_te, r_ob, r_ib: geometric ratios
        - r_le_fix, r_te_fix, r_le_moving, r_te_moving: ratios for geoseries_hi
        - x_refinement: refinement location (0 to 1)
    
    Returns
    -------
    x : np.ndarray
        Normalized coordinates from 0 to 1 (n_elem + 1 points)
    """
    n_points = n_elem + 1
    
    if distribution_type == 'uniform':
        return np.linspace(0, 1, n_points)
    
    elif distribution_type == 'cosine':
        beta = np.linspace(0, np.pi, n_points)
        return (1 - np.cos(beta)) / 2
    
    elif distribution_type == 'cosine_le':
        # Refined at leading edge (0)
        # Use 1 - cos(beta) to get small spacing at start
        beta = np.linspace(0, np.pi / 2, n_points)
        return 1 - np.cos(beta)
    
    elif distribution_type == 'cosine_te':
        # Refined at trailing edge (1)
        # Use sin(beta) to get small spacing at end
        beta = np.linspace(0, np.pi / 2, n_points)
        return np.sin(beta)
    
    elif distribution_type == 'geoseries':
        # Two-sided geometric series (matches Fortran geoseries_both)
        r_le = kwargs.get('r_ob', kwargs.get('r_le', 0.1))  # Leading edge ratio
        r_te = kwargs.get('r_ib', kwargs.get('r_te', 0.1))  # Trailing edge ratio
        x_ref = kwargs.get('x_refinement', 0.5)
        
        # Match Fortran: n_elem_le = ceiling(n_elem * (1 - xh))
        n_elem_le = int(np.ceil(n_elem * (1.0 - x_ref)))
        n_elem_te = n_elem - n_elem_le
        
        # Mid point calculation (matches Fortran)
        # For [0,1]: mid_point = (0 + 1) * xh = xh
        mid_point = x_ref  # For normalized [0,1] interval
        
        # Leading edge region: [0, mid_point]
        # Fortran uses dcsi_le output which is refined at END (mid_point)
        # So we use reverse=True to get refinement at end
        if n_elem_le > 0:
            dcsi_le = fortran_geoseries(n_elem_le, r_le, start_x=0.0,
                                        end_x=mid_point, reverse=True)
        else:
            dcsi_le = np.array([0.0])

        # Trailing edge region: [mid_point, 1]
        # Fortran uses dcsi_te output which is refined at START (mid_point)
        # So we use reverse=False to get refinement at start
        if n_elem_te > 0:
            dcsi_te = fortran_geoseries(n_elem_te, r_te, start_x=mid_point,
                                        end_x=1.0, reverse=False)
        else:
            dcsi_te = np.array([])        # Concatenate: dcsi_le[:-1] + dcsi_te (remove duplicate at mid_point)
        if len(dcsi_te) > 0:
            return np.concatenate([dcsi_le[:-1], dcsi_te])
        else:
            return dcsi_le
    
    elif distribution_type == 'geoseries_ob':
        # Outboard geometric series (refined at start)
        r_ob = kwargs.get('r_ob', 0.1)
        x_ref = kwargs.get('x_refinement', 0.0)
        x = fortran_geoseries(n_elem, r_ob, start_x=x_ref, end_x=1.0, reverse=False)
        return x
    
    elif distribution_type == 'geoseries_ib':
        # Inboard geometric series (refined at end)
        r_ib = kwargs.get('r_ib', 0.1)
        x_ref = kwargs.get('x_refinement', 1.0)
        # Use reverse=True to get refinement at the end
        x = fortran_geoseries(n_elem, r_ib, start_x=0.0, end_x=x_ref, reverse=True)
        return x
    
    elif distribution_type == 'geoseries_le':
        # Geometric series refined at LE (start, 0)
        r = kwargs.get('r', 0.125)
        # reverse=True gives refinement at start (x=0)
        x = fortran_geoseries(n_elem, r, start_x=0.0, end_x=1.0, reverse=True)
        return x
    
    elif distribution_type == 'geoseries_te':
        # Geometric series refined at TE (end, 1)
        r = kwargs.get('r', 0.125)
        # reverse=False gives refinement at end (x=1)
        x = fortran_geoseries(n_elem, r, start_x=0.0, end_x=1.0, reverse=False)
        return x
    
    elif distribution_type == 'geoseries_hi':
        # Hinge geometric series (4 regions)
        r_le_fix = kwargs.get('r_le_fix', 0.1)
        r_te_fix = kwargs.get('r_te_fix', 0.1)
        r_le_moving = kwargs.get('r_le_moving', 0.1)
        r_te_moving = kwargs.get('r_te_moving', 0.1)
        x_ref = kwargs.get('x_refinement', 0.5)
        
        # Simplified: split into 4 equal parts
        n_quarter = n_elem // 4
        n_parts = [n_quarter, n_quarter, n_quarter, n_elem - 3 * n_quarter]
        
        x1 = geometric_progression(n_parts[0], r_le_fix) * x_ref / 2
        x2 = x_ref / 2 + geometric_progression(n_parts[1], r_te_fix) * x_ref / 2
        x3 = x_ref + geometric_progression(n_parts[2], r_le_moving) * (1 - x_ref) / 2
        x4 = (x_ref + (1 - x_ref) / 2) + geometric_progression(n_parts[3], r_te_moving) * (1 - x_ref) / 2
        
        return np.concatenate([x1, x2[1:], x3[1:], x4[1:]])
    
    else:
        raise ValueError(f"Unknown distribution type: {distribution_type}")


def fortran_geoseries(n_elem: int, r: float, start_x: float = 0.0, 
                      end_x: float = 1.0, reverse: bool = False) -> np.ndarray:
    """
    Generate geometric series distribution matching Fortran geoseries subroutine.
    
    This is an exact implementation of the Fortran geoseries routine from 
    mod_math.f90 in DUST. The algorithm uses a decreasing ratio approach:
    - r_d = 1 - r (growth ratio as decreasing ratio)
    - First element size: dl(1) = (1-r_d)/(1 - r_d^n_elem)
    - Subsequent elements: dl(i) = r_d * dl(i-1)
    
    Parameters
    ----------
    n_elem : int
        Number of elements
    r : float
        Ratio parameter (0 < r < 1). Smaller r → stronger refinement at start
        For example: r=0.1 gives strong refinement, r=0.9 gives weak refinement
    start_x : float, optional
        Start of interval (default 0.0)
    end_x : float, optional
        End of interval (default 1.0)
    reverse : bool, optional
        If False, returns trailing edge distribution (refined at start_x)
        If True, returns leading edge distribution (refined at end_x)
    
    Returns
    -------
    dcsi : np.ndarray
        Node positions (n_elem + 1 points) from start_x to end_x
        
    Notes
    -----
    This matches the Fortran implementation:
    - dcsi_te: refined at start (trailing edge)
    - dcsi_le: refined at end (leading edge) = flip(1 - dcsi_te)
    """
    if not (0.0 < r < 1.0):
        raise ValueError(f"r must be between 0 and 1, got r={r}")
    
    r_d = 1.0 - r  # growth ratio (intended as decreasing ratio)
    
    # Get size of first element knowing the sum of the geometric series
    dl = np.zeros(n_elem)
    dl[0] = (1.0 - r_d) / (1.0 - r_d ** n_elem)
    
    # Geometric series -> get length of each element
    for i in range(1, n_elem):
        dl[i] = r_d * dl[i - 1]
    
    # Build trailing edge positions (cumulative sum)
    dcsi_te = np.zeros(n_elem + 1)
    for i in range(n_elem):
        dcsi_te[i + 1] = dcsi_te[i] + dl[i]
    
    if reverse:
        # Leading edge positions: dcsi_le = (1 - dcsi_te), then flip
        dcsi_le = 1.0 - dcsi_te
        dcsi_le = dcsi_le[::-1]  # flip
        # Rescale to interval [start_x, end_x]
        dcsi = dcsi_le * (end_x - start_x) + start_x
    else:
        # Trailing edge positions (already computed)
        # Rescale to interval [start_x, end_x]
        dcsi = dcsi_te * (end_x - start_x) + start_x
    
    return dcsi


def geometric_progression(n_elem: int, ratio: float) -> np.ndarray:
    """
    Generate geometric progression from 0 to 1.
    
    DEPRECATED: Use fortran_geoseries() instead for consistency with DUST Fortran.
    
    This function is kept for backward compatibility but uses fortran_geoseries
    internally to match the Fortran implementation.
    
    Parameters
    ----------
    n_elem : int
        Number of elements
    ratio : float
        Ratio parameter (0 < ratio < 1). Smaller ratio → stronger refinement
    
    Returns
    -------
    x : np.ndarray
        Coordinates from 0 to 1 (n_elem + 1 points), refined at 0
    """
    return fortran_geoseries(n_elem, ratio, start_x=0.0, end_x=1.0, reverse=False)


def span_distribution(n_elem: int, distribution_type: str, **kwargs) -> np.ndarray:
    """
    Generate span-wise distribution of points.

    Parameters
    ----------
    n_elem : int
        Number of elements
    distribution_type : str
        Type: 'uniform', 'cosine', 'geoseries', 'geoseries_ob', 'geoseries_ib'
    **kwargs : dict
        Additional parameters:
        - For 'geoseries': r_ob, r_ib, y_ref (refinement location)
        - For 'geoseries_ob': r_ob, y_ref
        - For 'geoseries_ib': r_ib, y_ref

    Returns
    -------
    y : np.ndarray
        Normalized coordinates from 0 to 1
    """
    if distribution_type == 'geoseries':
        # Two-sided geometric series (refined at both ends or at y_ref)
        # Use chord_distribution 'geoseries' which handles both r_ob and r_ib
        y_ref = kwargs.get('y_ref', 0.5)
        r_ob = kwargs.get('r_ob', 0.1)
        r_ib = kwargs.get('r_ib', 0.1)
        return chord_distribution(n_elem, 'geoseries', 
                                 x_refinement=y_ref, r_ob=r_ob, r_ib=r_ib)
    elif distribution_type == 'geoseries_ob':
        # Outboard geometric series (refined at start/root)
        y_ref = kwargs.get('y_ref', 0.0)
        r_ob = kwargs.get('r_ob', 0.1)
        return chord_distribution(n_elem, 'geoseries_ob', 
                                 x_refinement=y_ref, r_ob=r_ob)
    elif distribution_type == 'geoseries_ib':
        # Inboard geometric series (refined at end/tip)
        y_ref = kwargs.get('y_ref', 1.0)
        r_ib = kwargs.get('r_ib', 0.1)
        return chord_distribution(n_elem, 'geoseries_ib', 
                                 x_refinement=y_ref, r_ib=r_ib)
    else:
        # For uniform, cosine, etc., use chord_distribution directly
        return chord_distribution(n_elem, distribution_type, **kwargs)


def create_spline(points: np.ndarray, kind: str = 'cubic', n_samples: int = 100) -> tuple[np.ndarray, np.ndarray]:
    """
    Create spline interpolation through points.

    Parameters
    ----------
    points : np.ndarray
        Array of shape (N, 2) or (N, 3) with x, y, (z) coordinates
    kind : str
        Interpolation kind: 'linear', 'cubic'
    n_samples : int
        Number of samples along the spline

    Returns
    -------
    x : np.ndarray
        X coordinates
    y : np.ndarray
        Y coordinates (or Y, Z if 3D)
    """
    if points.shape[0] < 2:
        raise ValueError("Need at least 2 points for spline")

    # Parametric distance along curve
    t = np.zeros(points.shape[0])
    for i in range(1, len(t)):
        t[i] = t[i-1] + np.linalg.norm(points[i] - points[i-1])
    t = t / t[-1]  # Normalize to [0, 1]

    # Interpolate
    t_new = np.linspace(0, 1, n_samples)

    if points.shape[1] == 2:
        fx = interpolate.interp1d(t, points[:, 0], kind=kind)
        fy = interpolate.interp1d(t, points[:, 1], kind=kind)
        return fx(t_new), fy(t_new)
    elif points.shape[1] == 3:
        fx = interpolate.interp1d(t, points[:, 0], kind=kind)
        fy = interpolate.interp1d(t, points[:, 1], kind=kind)
        fz = interpolate.interp1d(t, points[:, 2], kind=kind)
        return fx(t_new), fy(t_new), fz(t_new)
    else:
        raise ValueError(f"Points must be 2D or 3D, got shape {points.shape}")


def transform_airfoil(x_airfoil: np.ndarray, y_airfoil: np.ndarray,
                      chord: float, twist: float, position: np.ndarray,
                      ref_frac: float = 0.25,
                      normal: np.ndarray = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Transform airfoil coordinates to 3D position with chord and twist.

    For parametric wings (normal=None), the airfoil lies in the X-Z plane.
    For pointwise meshes, the airfoil is rotated to align with the provided normal vector.

    Parameters
    ----------
    x_airfoil : np.ndarray
        Airfoil x coordinates (0 to 1, chordwise)
    y_airfoil : np.ndarray
        Airfoil y coordinates (thickness)
    chord : float
        Chord length
    twist : float
        Twist angle in degrees (rotation about normal vector or Y-axis)
    position : np.ndarray
        Position [x, y, z] of reference point
    ref_frac : float, optional
        Reference chord fraction for twist rotation (default: 0.25)
    normal : np.ndarray, optional
        3D vector normal to the profile plane (for pointwise meshes)
        If None, uses Y-axis (parametric case)

    Returns
    -------
    x : np.ndarray
        Transformed x coordinates
    y : np.ndarray
        Transformed y coordinates
    z : np.ndarray
        Transformed z coordinates
    """
    # Scale by chord
    x_scaled = x_airfoil * chord
    z_scaled = y_airfoil * chord  # Airfoil thickness
    y_scaled = np.zeros_like(x_scaled)  # Initially in X-Z plane

    # Shift to rotate around reference fraction point
    x_ref = ref_frac * chord
    x_shifted = x_scaled - x_ref

    # Stack coordinates for matrix operations
    points = np.column_stack([x_shifted, y_scaled, z_scaled])

    if normal is not None:
        # Pointwise case: rotate to align with normal vector
        # Normalize the normal vector
        normal = np.array(normal, dtype=float)
        normal = normal / np.linalg.norm(normal)

        # Default normal is Y-axis [0, 1, 0]
        default_normal = np.array([0.0, 1.0, 0.0])

        # Compute rotation matrix to align default_normal with normal
        # Using Rodrigues' rotation formula with axis from cross product
        v = np.cross(default_normal, normal)
        s = np.linalg.norm(v)  # sine of angle
        c = np.dot(default_normal, normal)  # cosine of angle

        if s > 1e-10:  # If vectors are not parallel
            # Skew-symmetric cross-product matrix of v
            v_cross = np.array([
                [0, -v[2], v[1]],
                [v[2], 0, -v[0]],
                [-v[1], v[0], 0]
            ])

            # Rodrigues' formula: R = I + [v]_x + [v]_x^2 * (1-c)/s^2
            R_align = np.eye(3) + v_cross + v_cross @ v_cross * ((1 - c) / (s * s))
        elif c > 0:
            # Vectors already aligned
            R_align = np.eye(3)
        else:
            # Vectors are opposite, rotate 180 degrees around any perpendicular axis
            # Choose Z-axis as perpendicular
            R_align = np.array([
                [-1, 0, 0],
                [0, -1, 0],
                [0, 0, 1]
            ])

        # Apply alignment rotation
        points = points @ R_align.T

        # Apply twist rotation around the normal vector
        twist_rad = np.deg2rad(twist)
        cos_t = np.cos(twist_rad)
        sin_t = np.sin(twist_rad)

        # Rodrigues' formula for rotation around arbitrary axis
        nx, ny, nz = normal
        R_twist = np.array([
            [cos_t + nx*nx*(1-cos_t), nx*ny*(1-cos_t) - nz*sin_t, nx*nz*(1-cos_t) + ny*sin_t],
            [ny*nx*(1-cos_t) + nz*sin_t, cos_t + ny*ny*(1-cos_t), ny*nz*(1-cos_t) - nx*sin_t],
            [nz*nx*(1-cos_t) - ny*sin_t, nz*ny*(1-cos_t) + nx*sin_t, cos_t + nz*nz*(1-cos_t)]
        ])

        points = points @ R_twist.T

    else:
        # Parametric case: simple rotation about Y-axis
        twist_rad = np.deg2rad(twist)
        cos_t = np.cos(twist_rad)
        sin_t = np.sin(twist_rad)

        # Rotation matrix about Y-axis
        R_twist = np.array([
            [cos_t, 0, sin_t],
            [0, 1, 0],
            [-sin_t, 0, cos_t]
        ])

        points = points @ R_twist.T

    # Extract rotated coordinates
    x_rotated = points[:, 0]
    y_rotated = points[:, 1]
    z_rotated = points[:, 2]

    # Shift back after rotation
    x_rotated = x_rotated + x_ref

    # Translate to position
    x_final = x_rotated + position[0]
    y_final = y_rotated + position[1]
    z_final = z_rotated + position[2]

    return x_final, y_final, z_final
