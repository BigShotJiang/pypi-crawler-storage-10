"""
Utilities for rendering mesh surfaces in 3D.

This module provides functions to create wing surface meshes from
parametric definitions for visualization.
"""

import numpy as np
from typing import List, Tuple
from functools import lru_cache
try:
    import pyvista as pv
    PYVISTA_AVAILABLE = True
except ImportError:
    PYVISTA_AVAILABLE = False

from . import mesh_geometry_utils as geom


def reflect_mesh_across_plane(mesh, plane_point, plane_normal):
    """
    Reflect a PyVista mesh across a plane defined by a point and normal.

    Parameters
    ----------
    mesh : pv.PolyData
        The mesh to reflect
    plane_point : array-like
        A point on the reflection plane [x, y, z]
    plane_normal : array-like
        Normal vector of the reflection plane [nx, ny, nz]

    Returns
    -------
    pv.PolyData
        Reflected mesh
    """
    # Normalize the normal vector
    normal = np.array(plane_normal, dtype=float)
    normal = normal / np.linalg.norm(normal)

    # Get mesh points
    points = mesh.points.copy()

    # Reflect each point across the plane
    # Formula: P' = P - 2 * dot(P - P0, N) * N
    # where P is the point, P0 is a point on the plane, N is the normal
    plane_pt = np.array(plane_point, dtype=float)

    # Vector from plane point to each mesh point
    v = points - plane_pt

    # Distance from each point to the plane (along normal)
    distances = np.dot(v, normal)

    # Reflect points
    reflected_points = points - 2.0 * distances[:, np.newaxis] * normal

    # Create new mesh with reflected points
    reflected_mesh = mesh.copy()
    reflected_mesh.points = reflected_points

    return reflected_mesh


# Cache for airfoil coordinates to avoid repeated generation
@lru_cache(maxsize=32)
def _get_airfoil_cached(airfoil_spec: str, n_points: int) -> Tuple[Tuple[float, ...], Tuple[float, ...]]:
    """
    Cached wrapper for airfoil generation.
    Returns tuples instead of arrays for hashability.
    """
    x, y = geom.get_airfoil_coordinates(airfoil_spec, n_points)
    return (tuple(x), tuple(y))


def compute_section_positions(regions, starting_point):
    """
    Compute section positions from regions and starting point.

    Parameters
    ----------
    regions : List[Region]
        List of region definitions
    starting_point : array-like
        Starting position [x, y, z]

    Returns
    -------
    section_positions : np.ndarray
        Array of section positions, shape (n_sections, 3)
    """
    current_pos = np.array(starting_point, dtype=float)
    section_positions = [current_pos.copy()]

    for region in regions:
        span = region.span
        sweep_rad = np.radians(region.sweep)
        dihed_rad = np.radians(region.dihed)

        dx = span * np.tan(sweep_rad)
        dy = span
        dz = span * np.tan(dihed_rad)

        current_pos = current_pos + np.array([dx, dy, dz])
        section_positions.append(current_pos.copy())

    return np.array(section_positions)


def create_wing_surface(sections_data: List[dict],
                        n_chord: int = 30,
                        n_span_per_region: int = 20,
                        ref_frac: float = 0.25) -> 'pv.PolyData':
    """
    Create a wing surface mesh from section data.

    Parameters
    ----------
    sections_data : List[dict]
        List of section definitions, each containing:
        - airfoil: str (NACA code or file)
        - chord: float
        - twist: float (degrees)
        - position: np.ndarray [x, y, z]
    n_chord : int
        Number of points around airfoil perimeter
    n_span_per_region : int
        Number of spanwise divisions between sections
    ref_frac : float
        Reference chord fraction for twist rotation (default: 0.25)

    Returns
    -------
    pv.PolyData
        Surface mesh of the wing
    """
    if not PYVISTA_AVAILABLE:
        raise ImportError("PyVista is required for mesh rendering")

    if len(sections_data) < 2:
        raise ValueError("Need at least 2 sections to create surface")

    # Generate airfoil coordinates for each section
    all_section_points = []

    for section in sections_data:
        # Get airfoil coordinates
        x_af, y_af = geom.get_airfoil_coordinates(section['airfoil'], n_points=n_chord)

        # Transform to 3D
        x_3d, y_3d, z_3d = geom.transform_airfoil(
            x_af, y_af,
            section['chord'],
            section['twist'],
            section['position'],
            ref_frac
        )

        points_3d = np.column_stack([x_3d, y_3d, z_3d])
        all_section_points.append(points_3d)

    # Create structured surface mesh by connecting sections
    vertices = []
    faces = []

    for i in range(len(all_section_points) - 1):
        # Interpolate between consecutive sections
        section1 = all_section_points[i]
        section2 = all_section_points[i + 1]

        # Create spanwise interpolation
        for j in range(n_span_per_region + 1):
            alpha = j / n_span_per_region
            interp_section = (1 - alpha) * section1 + alpha * section2

            # Add vertices
            start_idx = len(vertices)
            vertices.extend(interp_section)

            # Create faces (quads) connecting to previous spanwise strip
            if j > 0:
                prev_start = start_idx - len(interp_section)
                for k in range(len(interp_section) - 1):
                    # Create quad face
                    faces.append([
                        4,  # Number of vertices in face
                        prev_start + k,
                        prev_start + k + 1,
                        start_idx + k + 1,
                        start_idx + k
                    ])

    vertices = np.array(vertices)
    faces = np.array(faces).flatten()

    # Create PyVista mesh
    surf = pv.PolyData(vertices, faces)

    return surf


def create_mesh_wireframe(sections_data: List[dict],
                          chord_distribution: np.ndarray,
                          span_distributions: List[np.ndarray],
                          ref_frac: float = 0.25) -> 'pv.PolyData':
    """
    Create wireframe showing actual mesh discretization.

    Parameters
    ----------
    sections_data : List[dict]
        Section definitions
    chord_distribution : np.ndarray
        Normalized chord positions (0 to 1)
    span_distributions : List[np.ndarray]
        Normalized span positions for each region
    ref_frac : float
        Reference chord fraction for twist rotation (default: 0.25)

    Returns
    -------
    pv.PolyData
        Wireframe mesh
    """
    if not PYVISTA_AVAILABLE:
        raise ImportError("PyVista is required for mesh rendering")

    # Pre-allocate lists for better performance
    all_points = []
    faces = []

    for region_idx, span_dist in enumerate(span_distributions):
        section1 = sections_data[region_idx]
        section2 = sections_data[region_idx + 1]

        # Get airfoil coordinates for BOTH sections (cached for performance)
        x_af1_tuple, y_af1_tuple = _get_airfoil_cached(section1['airfoil'], 200)
        x_af2_tuple, y_af2_tuple = _get_airfoil_cached(section2['airfoil'], 200)

        # Convert back to numpy arrays
        x_af1, y_af1 = np.array(x_af1_tuple), np.array(y_af1_tuple)
        x_af2, y_af2 = np.array(x_af2_tuple), np.array(y_af2_tuple)

        # Process both airfoils - split into upper/lower surfaces
        le_idx1 = np.argmin(x_af1)
        x_upper1 = x_af1[:le_idx1+1][::-1]  # Reverse to go LE→TE
        y_upper1 = y_af1[:le_idx1+1][::-1]
        x_lower1 = x_af1[le_idx1:]
        y_lower1 = y_af1[le_idx1:]

        le_idx2 = np.argmin(x_af2)
        x_upper2 = x_af2[:le_idx2+1][::-1]
        y_upper2 = y_af2[:le_idx2+1][::-1]
        x_lower2 = x_af2[le_idx2:]
        y_lower2 = y_af2[le_idx2:]

        # Pre-compute interpolated airfoil shapes for both sections
        y_upper_sampled1 = np.interp(chord_distribution, x_upper1, y_upper1)
        y_lower_sampled1 = np.interp(chord_distribution, x_lower1, y_lower1)
        y_upper_sampled2 = np.interp(chord_distribution, x_upper2, y_upper2)
        y_lower_sampled2 = np.interp(chord_distribution, x_lower2, y_lower2)

        # Create arrays for vectorized computation
        span_fracs = span_dist[:, np.newaxis]  # Shape: (n_span, 1)

        # Interpolate section properties (vectorized)
        chords = (1 - span_fracs) * section1['chord'] + span_fracs * section2['chord']  # (n_span, 1)
        twists = (1 - span_fracs) * section1['twist'] + span_fracs * section2['twist']  # (n_span, 1)
        positions = (1 - span_fracs) * section1['position'][np.newaxis, :] + \
                    span_fracs * section2['position'][np.newaxis, :]  # (n_span, 3)

        # Blend airfoil shapes (vectorized across span stations)
        y_upper_blended = (1 - span_fracs) * y_upper_sampled1[np.newaxis, :] + \
                         span_fracs * y_upper_sampled2[np.newaxis, :]  # (n_span, n_chord)
        y_lower_blended = (1 - span_fracs) * y_lower_sampled1[np.newaxis, :] + \
                         span_fracs * y_lower_sampled2[np.newaxis, :]  # (n_span, n_chord)

        # Combine upper and lower surfaces for each span station
        # x_chord: concatenate forward and reverse chord_distribution
        x_chord_full = np.concatenate([chord_distribution, chord_distribution[::-1]])  # (2*n_chord,)

        region_points_info = []

        # Process each span station (still need loop for transform_airfoil, but pre-computed blending)
        for i, span_frac in enumerate(span_dist):
            chord = chords[i, 0]
            twist = twists[i, 0]
            position = positions[i, :]

            # Combine: chord goes around the airfoil (lower surface + upper surface)
            y_chord = np.concatenate([y_lower_blended[i], y_upper_blended[i, ::-1]])

            # Transform airfoil points
            x_3d, y_3d, z_3d = geom.transform_airfoil(
                x_chord_full, y_chord, chord, twist, position, ref_frac
            )

            points_3d = np.column_stack([x_3d, y_3d, z_3d])

            start_idx = len(all_points)
            all_points.extend(points_3d)
            region_points_info.append((start_idx, len(points_3d)))

        # Create quad faces between spanwise stations (vectorized face generation)
        n_stations = len(region_points_info)
        if n_stations > 1:
            for i in range(n_stations - 1):
                start_idx1, n_pts1 = region_points_info[i]
                start_idx2, n_pts2 = region_points_info[i + 1]
                n_pts = min(n_pts1, n_pts2)

                # Generate all quad faces for this pair of stations at once
                j_indices = np.arange(n_pts - 1)
                quad_faces = np.column_stack([
                    np.full(len(j_indices), 4),  # Number of vertices per face
                    start_idx1 + j_indices,
                    start_idx1 + j_indices + 1,
                    start_idx2 + j_indices + 1,
                    start_idx2 + j_indices
                ])
                faces.extend(quad_faces.tolist())

                # Close the airfoil contour (last point connects to first)
                faces.append([
                    4,
                    start_idx1 + n_pts - 1,
                    start_idx1,
                    start_idx2,
                    start_idx2 + n_pts - 1
                ])

    all_points = np.array(all_points)
    faces = np.array(faces, dtype=np.int32).flatten()

    # Create polydata with faces
    wireframe = pv.PolyData(all_points, faces)

    return wireframe


def create_meanline_mesh(sections_data: List[dict], span_dists: List[np.ndarray], 
                         chord_dist: np.ndarray, ref_frac: float = 0.25) -> 'pv.PolyData':
    """
    Create meanline (camber line) surface mesh for vortex lattice visualization.
    This creates a surface at the camberline of the airfoil, discretized both
    chordwise and spanwise.

    Parameters
    ----------
    sections_data : List[dict]
        Section definitions with airfoil, chord, twist, position
    span_dists : List[np.ndarray]
        Span distributions for each region
    chord_dist : np.ndarray
        Normalized chord positions (0 to 1) for discretization
    ref_frac : float
        Reference chord fraction
        
    Returns
    -------
    pv.PolyData
        Meanline surface mesh as wireframe
    """
    all_points = []
    lines = []
    
    # For each region between sections, create meanline surface
    for region_idx, span_dist in enumerate(span_dists):
        section1 = sections_data[region_idx]
        section2 = sections_data[region_idx + 1]

        # Get camberline coordinates for BOTH sections (cached)
        x_af1_tuple, y_af1_tuple = _get_airfoil_cached(section1['airfoil'], 200)
        x_af2_tuple, y_af2_tuple = _get_airfoil_cached(section2['airfoil'], 200)
        
        x_af1, y_af1 = np.array(x_af1_tuple), np.array(y_af1_tuple)
        x_af2, y_af2 = np.array(x_af2_tuple), np.array(y_af2_tuple)

        # Calculate camberline for section1
        le_idx1 = np.argmin(x_af1)
        x_upper1 = x_af1[:le_idx1+1][::-1]
        y_upper1 = y_af1[:le_idx1+1][::-1]
        x_lower1 = x_af1[le_idx1:]
        y_lower1 = y_af1[le_idx1:]
        y_upper_interp1 = np.interp(chord_dist, x_upper1, y_upper1)
        y_lower_interp1 = np.interp(chord_dist, x_lower1, y_lower1)
        y_camber1 = (y_upper_interp1 + y_lower_interp1) / 2.0

        # Calculate camberline for section2
        le_idx2 = np.argmin(x_af2)
        x_upper2 = x_af2[:le_idx2+1][::-1]
        y_upper2 = y_af2[:le_idx2+1][::-1]
        x_lower2 = x_af2[le_idx2:]
        y_lower2 = y_af2[le_idx2:]
        y_upper_interp2 = np.interp(chord_dist, x_upper2, y_upper2)
        y_lower_interp2 = np.interp(chord_dist, x_lower2, y_lower2)
        y_camber2 = (y_upper_interp2 + y_lower_interp2) / 2.0

        # Vectorize span-wise operations
        n_span = len(span_dist)
        span_fracs = span_dist[:, np.newaxis]  # Shape: (n_span, 1)

        # Interpolate section properties (vectorized)
        chords = (1 - span_fracs) * section1['chord'] + span_fracs * section2['chord']
        twists = (1 - span_fracs) * section1['twist'] + span_fracs * section2['twist']
        positions = (1 - span_fracs) * section1['position'][np.newaxis, :] + \
                    span_fracs * section2['position'][np.newaxis, :]
        
        # Blend camberlines (vectorized)
        y_camber_blended = (1 - span_fracs) * y_camber1[np.newaxis, :] + \
                          span_fracs * y_camber2[np.newaxis, :]  # (n_span, n_chord)

        region_points = []

        # Process each span station (still need loop for transform_airfoil)
        for i in range(n_span):
            chord = chords[i, 0]
            twist = twists[i, 0]
            position = positions[i, :]
            y_camber = y_camber_blended[i, :]

            # Transform camberline points
            x_3d, y_3d, z_3d = geom.transform_airfoil(
                chord_dist, y_camber, chord, twist, position, ref_frac
            )

            points_3d = np.column_stack([x_3d, y_3d, z_3d])

            start_idx = len(all_points)
            all_points.extend(points_3d)
            region_points.append((start_idx, len(points_3d)))

        # Create quad faces between spanwise stations (vectorized)
        n_stations = len(region_points)
        if n_stations > 1:
            for i in range(n_stations - 1):
                start_idx1, n_pts1 = region_points[i]
                start_idx2, n_pts2 = region_points[i + 1]
                n_pts = min(n_pts1, n_pts2)

                # Generate all quad faces at once
                j_indices = np.arange(n_pts - 1)
                quad_faces = np.column_stack([
                    np.full(len(j_indices), 4),
                    start_idx1 + j_indices,
                    start_idx1 + j_indices + 1,
                    start_idx2 + j_indices + 1,
                    start_idx2 + j_indices
                ])
                lines.extend(quad_faces.tolist())

    all_points = np.array(all_points)
    faces = np.array(lines, dtype=np.int32).flatten()

    # Create polydata with faces (not lines)
    mesh = pv.PolyData(all_points, faces)

    return mesh


def create_lifting_line_mesh(sections_data: List[dict], span_dists: List[np.ndarray],
                             section_positions: List[np.ndarray]) -> 'pv.PolyData':
    """
    Create lifting line visualization (LE and TE lines with quad faces for visibility).

    Parameters
    ----------
    sections_data : List[dict]
        Section definitions
    span_dists : List[np.ndarray]
        Span distributions
    section_positions : List[np.ndarray]
        Section positions

    Returns
    -------
    pv.PolyData
        Lifting line mesh (LE and TE connected with quad faces)
    """
    le_points = []
    te_points = []

    # Collect all LE and TE points along the span
    for region_idx, span_dist in enumerate(span_dists):
        section1 = sections_data[region_idx]
        section2 = sections_data[region_idx + 1]

        for alpha in span_dist:
            # Interpolate section properties
            chord = (1 - alpha) * section1['chord'] + alpha * section2['chord']
            twist = (1 - alpha) * section1['twist'] + alpha * section2['twist']
            pos = (1 - alpha) * section1['position'] + alpha * section2['position']
            airfoil = section1['airfoil']  # Use first section's airfoil
            
            # Get airfoil coordinates to find actual LE and TE points
            x_airfoil, y_airfoil = geom.get_airfoil_coordinates(airfoil, n_points=100)
            
            # Find LE and TE points on the actual airfoil
            le_idx = np.argmin(x_airfoil)
            x_le, y_le = np.array([x_airfoil[le_idx]]), np.array([y_airfoil[le_idx]])
            
            te_idx = np.argmax(x_airfoil)
            x_te, y_te = np.array([x_airfoil[te_idx]]), np.array([y_airfoil[te_idx]])
            
            # Transform LE and TE points with chord, twist, and position
            ref_frac = 0.25  # Default reference chord fraction
            x_3d_le, y_3d_le, z_3d_le = geom.transform_airfoil(
                x_le, y_le, chord, twist, pos, ref_frac
            )
            le_points.append([x_3d_le[0], y_3d_le[0], z_3d_le[0]])
            
            x_3d_te, y_3d_te, z_3d_te = geom.transform_airfoil(
                x_te, y_te, chord, twist, pos, ref_frac
            )
            te_points.append([x_3d_te[0], y_3d_te[0], z_3d_te[0]])

    # Create quad faces between LE and TE for better visualization
    all_points = le_points + te_points
    faces = []

    offset = len(le_points)

    # Create quad faces along the span (connecting LE to TE at each station)
    for i in range(len(le_points) - 1):
        # Quad: LE[i], LE[i+1], TE[i+1], TE[i]
        faces.extend([
            4,
            i,
            i + 1,
            offset + i + 1,
            offset + i
        ])

    points_array = np.array(all_points)
    faces_array = np.array(faces)

    return pv.PolyData(points_array, faces_array)


def create_parametric_wing_visualization(sections, regions, config,
                                         show_surface: bool = True,
                                         show_wireframe: bool = False,
                                         show_sections: bool = True,
                                         element_type: str = "p") -> list['pv.PolyData']:
    """
    Create complete wing visualization with surface and/or wireframe.

    Parameters
    ----------
    sections : List[Section]
        Parametric sections
    regions : List[Region]
        Parametric regions
    config : MeshConfig
        Mesh configuration
    show_surface : bool
        Show smooth surface
    show_wireframe : bool
        Show discretized mesh wireframe
    show_sections : bool
        Show section outlines
    element_type : str
        Element type: 'p' (Panel), 'v' (Vortex-Lattice), 'l' (Lifting-Line)

    Returns
    -------
    List[pv.PolyData]
        List of mesh objects to render
    """
    if not PYVISTA_AVAILABLE:
        raise ImportError("PyVista is required for mesh rendering")

    meshes = []

    # Extract element type letter if full string provided
    if element_type and len(element_type) > 1:
        element_type = element_type[0].lower()  # Get 'v', 'l', or 'p'

    # Use shared function to compute section positions
    section_positions = compute_section_positions(regions, config.starting_point)

    # Prepare section data
    ref_frac = config.reference_chord_fraction
    sections_data = []

    for section, position in zip(sections, section_positions):
        le_offset = section.chord * (ref_frac)
        adjusted_position = position.copy()
        adjusted_position[0] -= le_offset

        sections_data.append({
            'airfoil': section.airfoil,
            'chord': section.chord,
            'twist': section.twist,
            'position': adjusted_position
        })

    # Create surface mesh
    if show_surface and len(sections_data) >= 2:
        try:
            # For panel mode: nelem_chord elements on EACH surface (upper and lower)
            # The chord_distribution will be applied to both surfaces separately
            # So we use nelem_chord directly, not 2*nelem_chord
            nelem_chord_viz = config.nelem_chord

            # Use actual mesh discretization for surface (not wireframe)
            # Get chord distribution
            chord_params = {}
            # Use chord parameters from config if available, otherwise use defaults
            if hasattr(config, 'chord_params') and config.chord_params:
                chord_params = config.chord_params.copy()
            elif config.type_chord.startswith('geoseries'):
                # Fallback defaults for geoseries types
                chord_params['r_le'] = 0.1
                chord_params['r_te'] = 0.1
                chord_params['x_refinement'] = 0.5

            chord_dist = geom.chord_distribution(
                nelem_chord_viz,
                config.type_chord,
                **chord_params
            )

            # Get span distributions for each region using actual discretization
            span_dists = []
            for region in regions:
                # Build span_params from region attributes
                span_params = {}
                if region.type_span in ['geoseries', 'geoseries_ob', 'geoseries_ib']:
                    if hasattr(region, 'y_refinement'):
                        span_params['y_refinement'] = region.y_refinement
                    if hasattr(region, 'r_ob') and region.type_span in ['geoseries', 'geoseries_ob']:
                        span_params['r_ob'] = region.r_ob
                    if hasattr(region, 'r_ib') and region.type_span in ['geoseries', 'geoseries_ib']:
                        span_params['r_ib'] = region.r_ib

                span_dist = geom.span_distribution(
                    region.nelem_span,
                    region.type_span,
                    **span_params
                )

                span_dists.append(span_dist)

            # Create surface based on element type
            if element_type == 'v':  # Vortex Lattice: meanline surface
                surface = create_meanline_mesh(sections_data, span_dists, chord_dist, ref_frac)
            elif element_type == 'l':  # Lifting Line: LE and TE lines
                surface = create_lifting_line_mesh(sections_data, span_dists, section_positions)
            else:  # Panel: full 3D mesh (element_type == 'p' or any other value)
                surface = create_mesh_wireframe(sections_data, chord_dist, span_dists, ref_frac)

            meshes.append(('surface', surface))
        except Exception as e:
            print(f"Warning: Failed to create surface: {e}")
            import traceback
            traceback.print_exc()    # Create wireframe mesh (now redundant with surface, but keep for compatibility)
    if show_wireframe and len(sections_data) >= 2:
        try:
            # Wireframe is now same as surface, so just skip it to avoid overlap
            pass
        except Exception as e:
            print(f"Warning: Failed to create wireframe: {e}")

    # Create section outlines
    if show_sections:
        for i, (section, position) in enumerate(zip(sections, section_positions)):
            try:
                x_af, y_af = geom.get_airfoil_coordinates(section.airfoil, n_points=50)
                
                le_offset = section.chord * (ref_frac)
                adjusted_position = position.copy()
                adjusted_position[0] -= le_offset
                
                x_3d, y_3d, z_3d = geom.transform_airfoil(
                    x_af, y_af, section.chord, section.twist, adjusted_position, ref_frac
                )
                
                points = np.column_stack([x_3d, y_3d, z_3d])
                line = pv.lines_from_points(points, close=True)

                # Tag with section index for coloring
                meshes.append((f'section_{i}', line))
            except Exception as e:
                print(f"Warning: Failed to create section {i}: {e}")
    
    return meshes


def create_pointwise_mesh(points, lines, point_size=8.0, line_width=3.0, show_airfoils=True,
                          ref_chord_fraction=0.25, n_elem_line=10, chord_distribution=None,
                          element_type='p'):
    """
    Create visualization meshes for pointwise mesh definition.
    Reuses the same mesh generation functions as parametric meshes.
    
    Parameters
    ----------
    points : list of dict
        List of point definitions, each with 'x', 'y', 'z', 'chord', 'twist', 'airfoil'
    lines : list of dict
        List of line definitions, each with 'start_point', 'end_point', 'n_elem', 'span_type', and 'type'
        ('straight' or 'spline')
    point_size : float, optional
        Size of point markers
    line_width : float, optional
        Width of lines
    show_airfoils : bool, optional
        Whether to show airfoil profiles at each point
    ref_chord_fraction : float, optional
        Reference chord fraction for airfoil positioning (default: 0.25)
    n_elem_line : int, optional
        Default number of elements per line segment (default: 10)
    chord_distribution : np.ndarray, optional
        Normalized chord distribution (0 to 1). If None, uses uniform distribution
    element_type : str, optional
        Element type: 'p' (Panel), 'v' (Vortex-Lattice), 'l' (Lifting-Line)
    
    Returns
    -------
    list of tuple
        List of (name, pv.PolyData) tuples for rendering
    """
    if not PYVISTA_AVAILABLE:
        return []
    
    from .hermite_spline import hermite_spline
    
    meshes = []
    
    # Extract element type letter if full string provided
    if element_type and len(element_type) > 1:
        element_type = element_type[0].lower()
    
    # Default chord distribution if not provided
    if chord_distribution is None:
        chord_distribution = np.linspace(0, 1, 50)
    
    # Create point cloud visualization
    if points:
        try:
            point_coords = np.array([[p['x'], p['y'], p['z']] for p in points])
            point_cloud = pv.PolyData(point_coords)
            point_cloud['point_indices'] = np.arange(len(points))
            meshes.append(('points', point_cloud))
        except Exception as e:
            print(f"Warning: Failed to create point cloud: {e}")
    
    # Process each line: build sections_data and reuse parametric mesh functions
    for line_idx, line_def in enumerate(lines):
        try:
            start_idx = line_def.get('start_point', 0)
            end_idx = line_def.get('end_point', 1)
            line_type = line_def.get('type', 'straight')
            n_elem = line_def.get('n_elem', n_elem_line)
            span_type = line_def.get('span_type', 'uniform')
            
            # Validate indices
            if start_idx < 0 or start_idx >= len(points):
                print(f"Warning: Line {line_idx} has invalid start_point index {start_idx}")
                continue
            if end_idx < 0 or end_idx >= len(points):
                print(f"Warning: Line {line_idx} has invalid end_point index {end_idx}")
                continue
            
            # Collect all points from start to end
            if end_idx > start_idx:
                point_indices = list(range(start_idx, end_idx + 1))
            else:
                point_indices = list(range(start_idx, end_idx - 1, -1))
            
            # Get control points for the line
            control_points = np.array([[points[j]['x'], points[j]['y'], points[j]['z']]
                                      for j in point_indices])
            
            # Get airfoil properties at control points
            chords_control = np.array([points[j].get('chord', 1.0) for j in point_indices])
            twists_control = np.array([points[j].get('twist', 0.0) for j in point_indices])
            airfoils_control = [points[j].get('airfoil', 'naca0012') for j in point_indices]
            
            if len(control_points) < 2:
                print(f"Warning: Line {line_idx} needs at least 2 points")
                continue
            
            # Use span distribution from geometry utils
            span_params = {}
            span_dist = geom.span_distribution(n_elem, span_type, **span_params)
            
            # Generate curve samples with positions and tangents/normals
            if line_type == 'spline' and len(control_points) > 2:
                # Use Hermite spline - sample the entire curve
                n_samples_spline = max(100, n_elem * 10)  # High resolution for accurate sampling
                curve_full, tangents_full = hermite_spline(control_points, n_samples=n_samples_spline)
                
                # Compute arc length parameterization
                segment_lengths = np.linalg.norm(np.diff(curve_full, axis=0), axis=1)
                cumulative_lengths = np.concatenate([[0], np.cumsum(segment_lengths)])
                total_length = cumulative_lengths[-1]
                
                # Sample curve at span_dist positions using arc length
                target_lengths = span_dist * total_length
                
                # Interpolate positions and tangents at target arc lengths
                curve_samples = np.array([np.interp(target_lengths, cumulative_lengths, curve_full[:, i])
                                         for i in range(3)]).T
                tangents = np.array([np.interp(target_lengths, cumulative_lengths, tangents_full[:, i])
                                    for i in range(3)]).T
                
                # Normalize tangents
                tangent_norms = np.linalg.norm(tangents, axis=1, keepdims=True)
                tangents = tangents / np.maximum(tangent_norms, 1e-10)
                
                # Interpolate airfoil properties along the spline using arc length
                param_control = np.linspace(0, total_length, len(control_points))
                chords_interp = np.interp(target_lengths, param_control, chords_control)
                twists_interp = np.interp(target_lengths, param_control, twists_control)
                
                # For airfoils, use nearest neighbor
                airfoil_indices = np.searchsorted(param_control, target_lengths, side='left')
                airfoil_indices = np.clip(airfoil_indices, 0, len(airfoils_control) - 1)
                airfoils_interp = [airfoils_control[i] for i in airfoil_indices]
                
            else:
                # Straight line between start and end
                start_point = control_points[0]
                end_point = control_points[-1]
                
                curve_samples = start_point + span_dist[:, np.newaxis] * (end_point - start_point)
                
                # Tangent is constant along straight line
                direction = end_point - start_point
                tangent = direction / np.linalg.norm(direction)
                tangents = np.tile(tangent, (len(span_dist), 1))
                
                # Interpolate properties linearly
                chords_interp = chords_control[0] + span_dist * (chords_control[-1] - chords_control[0])
                twists_interp = twists_control[0] + span_dist * (twists_control[-1] - twists_control[0])
                
                # For airfoils, use start airfoil for first half, end for second half
                airfoils_interp = [airfoils_control[0] if s < 0.5 else airfoils_control[-1] for s in span_dist]
            
            # Build sections_data format (same as parametric case)
            # Apply reference chord fraction offset to positions along chord direction
            sections_data = []
            for position, tangent, chord, twist, airfoil in zip(curve_samples, tangents, chords_interp, twists_interp, airfoils_interp):
                # For pointwise meshes, we need to compute the chord direction
                # The tangent is the spanwise direction (normal to airfoil plane)
                # The chord direction is perpendicular to tangent, in the "horizontal" plane
                
                # Default chord direction is X-axis, but we need to rotate it based on tangent
                # The chord lies in the plane perpendicular to the tangent
                # We want the chord to point "forward" (positive X when tangent is Y)
                
                # Compute chord direction: perpendicular to tangent and Z-axis
                z_axis = np.array([0.0, 0.0, 1.0])
                chord_dir = np.cross(tangent, z_axis)
                chord_dir_norm = np.linalg.norm(chord_dir)
                
                if chord_dir_norm > 1e-10:
                    chord_dir = chord_dir / chord_dir_norm
                else:
                    # Tangent is parallel to Z, use X-axis as chord direction
                    chord_dir = np.array([1.0, 0.0, 0.0])
                
                # Apply offset: move position backwards along chord direction
                # (same as parametric: adjusted_position[0] -= le_offset)
                le_offset = chord * ref_chord_fraction
                adjusted_position = position - le_offset * chord_dir
                
                sections_data.append({
                    'airfoil': airfoil,
                    'chord': chord,
                    'twist': twist,
                    'position': adjusted_position
                })
            
            # Now use the existing mesh generation functions based on element type
            if element_type == 'l':  # Lifting-Line
                # For lifting line, create LE and TE lines using actual airfoil profile points
                # This ensures the lines follow the twisted airfoil shape
                le_points = []
                te_points = []
                
                for section_data, tangent in zip(sections_data, tangents):
                    # Get the airfoil coordinates
                    airfoil = section_data.get('airfoil', 'naca0012')
                    x_airfoil, y_airfoil = geom.get_airfoil_coordinates(airfoil, n_points=100)
                    
                    # Find LE and TE points on the actual airfoil
                    # LE is at minimum x (usually ~0)
                    le_idx = np.argmin(x_airfoil)
                    x_le, y_le = np.array([x_airfoil[le_idx]]), np.array([y_airfoil[le_idx]])
                    
                    # TE is at maximum x (usually ~1)
                    te_idx = np.argmax(x_airfoil)
                    x_te, y_te = np.array([x_airfoil[te_idx]]), np.array([y_airfoil[te_idx]])
                    
                    # Transform LE point with twist
                    x_3d_le, y_3d_le, z_3d_le = geom.transform_airfoil(
                        x_le, y_le,
                        section_data['chord'],
                        section_data['twist'],
                        section_data['position'],
                        ref_chord_fraction,
                        normal=tangent
                    )
                    le_points.append([x_3d_le[0], y_3d_le[0], z_3d_le[0]])
                    
                    # Transform TE point with twist
                    x_3d_te, y_3d_te, z_3d_te = geom.transform_airfoil(
                        x_te, y_te,
                        section_data['chord'],
                        section_data['twist'],
                        section_data['position'],
                        ref_chord_fraction,
                        normal=tangent
                    )
                    te_points.append([x_3d_te[0], y_3d_te[0], z_3d_te[0]])
                
                # Create LE and TE lines
                if len(le_points) > 1:
                    le_line = pv.lines_from_points(np.array(le_points))
                    meshes.append((f'le_line_{line_idx}', le_line))
                if len(te_points) > 1:
                    te_line = pv.lines_from_points(np.array(te_points))
                    meshes.append((f'te_line_{line_idx}', te_line))
                    
            elif element_type == 'v':  # Vortex-Lattice
                # Create meanline (camberline) surface manually
                all_points = []
                station_info = []
                
                for section_data, tangent in zip(sections_data, tangents):
                    # Get airfoil coordinates
                    x_af, y_af = geom.get_airfoil_coordinates(section_data['airfoil'], n_points=200)
                    
                    # Compute camberline
                    le_idx = np.argmin(x_af)
                    x_upper = x_af[:le_idx+1][::-1]
                    y_upper = y_af[:le_idx+1][::-1]
                    x_lower = x_af[le_idx:]
                    y_lower = y_af[le_idx:]
                    
                    # Sample at chord_distribution
                    y_upper_interp = np.interp(chord_distribution, x_upper, y_upper)
                    y_lower_interp = np.interp(chord_distribution, x_lower, y_lower)
                    
                    # Camberline is average of upper and lower
                    y_camber = 0.5 * (y_upper_interp + y_lower_interp)
                    
                    # Transform camberline using tangent as normal
                    x_3d, y_3d, z_3d = geom.transform_airfoil(
                        chord_distribution, y_camber,
                        section_data['chord'],
                        section_data['twist'],
                        section_data['position'],
                        ref_chord_fraction,
                        normal=tangent
                    )
                    
                    points_3d = np.column_stack([x_3d, y_3d, z_3d])
                    start_idx_pts = len(all_points)
                    all_points.extend(points_3d)
                    station_info.append((start_idx_pts, len(points_3d)))
                
                # Create quad faces between stations
                faces = []
                for i in range(len(station_info) - 1):
                    start_idx1, n_pts1 = station_info[i]
                    start_idx2, n_pts2 = station_info[i + 1]
                    n_pts = min(n_pts1, n_pts2)
                    
                    for j in range(n_pts - 1):
                        faces.append([4, start_idx1 + j, start_idx1 + j + 1,
                                     start_idx2 + j + 1, start_idx2 + j])
                
                if all_points and faces:
                    all_points_array = np.array(all_points)
                    faces_array = np.hstack(faces)
                    mesh = pv.PolyData(all_points_array, faces_array)
                    meshes.append((f'meanline_{line_idx}', mesh))
                
            else:  # Panel (element_type == 'p')
                # Create full 3D surface mesh manually
                all_points = []
                station_info = []
                
                for section_data, tangent in zip(sections_data, tangents):
                    # Get airfoil coordinates
                    x_af, y_af = geom.get_airfoil_coordinates(section_data['airfoil'], n_points=200)
                    
                    # Split into upper and lower surfaces
                    le_idx = np.argmin(x_af)
                    x_upper = x_af[:le_idx+1][::-1]
                    y_upper = y_af[:le_idx+1][::-1]
                    x_lower = x_af[le_idx:]
                    y_lower = y_af[le_idx:]
                    
                    # Sample at chord_distribution
                    y_upper_sampled = np.interp(chord_distribution, x_upper, y_upper)
                    y_lower_sampled = np.interp(chord_distribution, x_lower, y_lower)
                    
                    # Combine upper and lower: goes around the airfoil
                    x_chord_full = np.concatenate([chord_distribution, chord_distribution[::-1]])
                    y_chord_full = np.concatenate([y_lower_sampled, y_upper_sampled[::-1]])
                    
                    # Transform airfoil using tangent as normal
                    x_3d, y_3d, z_3d = geom.transform_airfoil(
                        x_chord_full, y_chord_full,
                        section_data['chord'],
                        section_data['twist'],
                        section_data['position'],
                        ref_chord_fraction,
                        normal=tangent
                    )
                    
                    points_3d = np.column_stack([x_3d, y_3d, z_3d])
                    start_idx_pts = len(all_points)
                    all_points.extend(points_3d)
                    station_info.append((start_idx_pts, len(points_3d)))
                
                # Create quad faces between stations
                faces = []
                for i in range(len(station_info) - 1):
                    start_idx1, n_pts1 = station_info[i]
                    start_idx2, n_pts2 = station_info[i + 1]
                    n_pts = min(n_pts1, n_pts2)
                    
                    for j in range(n_pts - 1):
                        faces.append([4, start_idx1 + j, start_idx1 + j + 1,
                                     start_idx2 + j + 1, start_idx2 + j])
                
                if all_points and faces:
                    all_points_array = np.array(all_points)
                    faces_array = np.hstack(faces)
                    mesh = pv.PolyData(all_points_array, faces_array)
                    meshes.append((f'surface_{line_idx}', mesh))
            
        except Exception as e:
            print(f"Warning: Failed to create mesh for line {line_idx}: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    return meshes


