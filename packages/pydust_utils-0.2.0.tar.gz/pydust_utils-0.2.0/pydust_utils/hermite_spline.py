"""
Hermite spline implementation translated from DUST's mod_spline.f90.

This module provides Hermite cubic spline interpolation for smooth curve generation
from control points, matching the behavior of DUST's Fortran spline module.
"""

import numpy as np
from typing import Tuple, Optional, Literal


def hermite_p1(t: np.ndarray) -> np.ndarray:
    """
    Hermite basis function h1.
    Properties: h1(0)=1, h1(1)=0, h1'(0)=0, h1'(1)=0
    
    Args:
        t: Parameter value(s) in [0, 1]
    
    Returns:
        Basis function value(s)
    """
    return 2.0 * t**3 - 3.0 * t**2 + 1.0


def hermite_p2(t: np.ndarray) -> np.ndarray:
    """
    Hermite basis function h2.
    Properties: h2(0)=0, h2(1)=1, h2'(0)=0, h2'(1)=0
    
    Args:
        t: Parameter value(s) in [0, 1]
    
    Returns:
        Basis function value(s)
    """
    return -2.0 * t**3 + 3.0 * t**2


def hermite_d1(t: np.ndarray) -> np.ndarray:
    """
    Hermite basis function h3.
    Properties: h3(0)=0, h3(1)=0, h3'(0)=1, h3'(1)=0
    
    Args:
        t: Parameter value(s) in [0, 1]
    
    Returns:
        Basis function value(s)
    """
    return t**3 - 2.0 * t**2 + t


def hermite_d2(t: np.ndarray) -> np.ndarray:
    """
    Hermite basis function h4.
    Properties: h4(0)=0, h4(1)=0, h4'(0)=0, h4'(1)=1
    
    Args:
        t: Parameter value(s) in [0, 1]
    
    Returns:
        Basis function value(s)
    """
    return t**3 - t**2


def compute_derivatives(
    points: np.ndarray,
    tension: float = 0.0,
    bias: float = 0.0,
    bc_start: Literal['derivative', 'free'] = 'free',
    bc_end: Literal['derivative', 'free'] = 'free',
    d0: Optional[np.ndarray] = None,
    d1: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Compute derivatives at control points for Hermite spline.
    
    Following Paul Bourke's description:
    http://paulbourke.net/miscellaneous/interpolation/
    
    Args:
        points: Control points, shape (n_points, n_dim)
        tension: Tension parameter (0.0 = Catmull-Rom, 1.0 = tight)
        bias: Bias parameter (-1.0 to 1.0, controls overshoot)
        bc_start: Boundary condition at first point ('derivative' or 'free')
        bc_end: Boundary condition at last point ('derivative' or 'free')
        d0: Derivative at first point (if bc_start='derivative')
        d1: Derivative at last point (if bc_end='derivative')
    
    Returns:
        Derivatives at each point, shape (n_points, n_dim)
    """
    n_points = len(points)
    n_dim = points.shape[1]
    dp = np.zeros((n_points, n_dim))
    
    # Compute parameter values based on chord length
    t = np.zeros(n_points)
    dt = np.zeros(n_points - 1)
    
    for i in range(n_points - 1):
        segment_length = np.linalg.norm(points[i + 1] - points[i])
        if i == 0:
            t[i + 1] = segment_length
        else:
            t[i + 1] = t[i] + segment_length
        dt[i] = t[i + 1] - t[i]
    
    # Inner points - use Kochanek-Bartels formula
    for i in range(1, n_points - 1):
        dp[i] = 0.5 * (1.0 - tension) * (
            (points[i] - points[i - 1]) * (1.0 + bias) +
            (points[i + 1] - points[i]) * (1.0 - bias)
        )
    
    # First point
    if bc_start == 'derivative' and d0 is not None:
        # Match magnitude of second derivative, but use specified direction
        d0_norm = np.linalg.norm(d0)
        dp2_norm = np.linalg.norm(dp[1])
        if d0_norm > 0:
            dp[0] = d0 / d0_norm * dp2_norm
        else:
            dp[0] = dp[1]
    elif bc_start == 'free':
        if dt[0] > 0:
            dp[0] = 0.5 * (-dp[1] + 3.0 / dt[0] * (points[1] - points[0]))
        else:
            dp[0] = points[1] - points[0]
    
    # Last point
    if bc_end == 'derivative' and d1 is not None:
        # Match magnitude of second-to-last derivative, but use specified direction
        d1_norm = np.linalg.norm(d1)
        dpn_norm = np.linalg.norm(dp[n_points - 2])
        if d1_norm > 0:
            dp[n_points - 1] = d1 / d1_norm * dpn_norm
        else:
            dp[n_points - 1] = dp[n_points - 2]
    elif bc_end == 'free':
        if dt[-1] > 0:
            dp[n_points - 1] = 0.5 * (
                -dp[n_points - 2] + 3.0 / dt[-1] * (points[n_points - 1] - points[n_points - 2])
            )
        else:
            dp[n_points - 1] = points[n_points - 1] - points[n_points - 2]
    
    return dp


def hermite_spline(
    points: np.ndarray,
    n_samples: int = 100,
    tension: float = 0.0,
    bias: float = 0.0,
    bc_start: Literal['derivative', 'free'] = 'free',
    bc_end: Literal['derivative', 'free'] = 'free',
    d0: Optional[np.ndarray] = None,
    d1: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate a Hermite cubic spline through control points.
    
    Args:
        points: Control points, shape (n_points, n_dim) where n_dim is 2 or 3
        n_samples: Number of samples per spline segment
        tension: Tension parameter (0.0 = Catmull-Rom, 1.0 = tight)
        bias: Bias parameter (-1.0 to 1.0, controls overshoot)
        bc_start: Boundary condition at first point ('derivative' or 'free')
        bc_end: Boundary condition at last point ('derivative' or 'free')
        d0: Derivative at first point (if bc_start='derivative')
        d1: Derivative at last point (if bc_end='derivative')
    
    Returns:
        Tuple of (curve_points, tangents):
            - curve_points: Points on the spline, shape (n_total_samples, n_dim)
            - tangents: Unit tangent vectors at each point, shape (n_total_samples, n_dim)
    """
    n_points = len(points)
    n_splines = n_points - 1
    n_dim = points.shape[1]
    
    # Compute derivatives at control points
    dp = compute_derivatives(points, tension, bias, bc_start, bc_end, d0, d1)
    
    # Generate spline
    curve_points = []
    tangents = []
    
    for i in range(n_splines):
        # Parameter values for this segment
        if i < n_splines - 1:
            tv = np.linspace(0, 1, n_samples, endpoint=False)
        else:
            # Include endpoint for last segment
            tv = np.linspace(0, 1, n_samples + 1)
        
        # Evaluate Hermite polynomials
        for t_val in tv:
            # Compute point using Hermite basis functions
            point = (
                hermite_p1(t_val) * points[i] +
                hermite_p2(t_val) * points[i + 1] +
                hermite_d1(t_val) * dp[i] +
                hermite_d2(t_val) * dp[i + 1]
            )
            curve_points.append(point)
            
            # Compute tangent (derivative of the curve)
            # d/dt of Hermite polynomials
            h1_prime = 6.0 * t_val**2 - 6.0 * t_val
            h2_prime = -6.0 * t_val**2 + 6.0 * t_val
            h3_prime = 3.0 * t_val**2 - 4.0 * t_val + 1.0
            h4_prime = 3.0 * t_val**2 - 2.0 * t_val
            
            tangent = (
                h1_prime * points[i] +
                h2_prime * points[i + 1] +
                h3_prime * dp[i] +
                h4_prime * dp[i + 1]
            )
            
            # Normalize tangent
            tangent_norm = np.linalg.norm(tangent)
            if tangent_norm > 1e-10:
                tangent = tangent / tangent_norm
            
            tangents.append(tangent)
    
    return np.array(curve_points), np.array(tangents)


def hermite_spline_simple(
    points: np.ndarray,
    n_samples: int = 100
) -> np.ndarray:
    """
    Simplified Hermite spline with default parameters (Catmull-Rom style).
    
    Args:
        points: Control points, shape (n_points, n_dim)
        n_samples: Number of samples per spline segment
    
    Returns:
        Points on the spline, shape (n_total_samples, n_dim)
    """
    curve_points, _ = hermite_spline(
        points,
        n_samples=n_samples,
        tension=0.0,
        bias=0.0,
        bc_start='free',
        bc_end='free'
    )
    return curve_points
