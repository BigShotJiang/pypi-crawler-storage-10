#!/usr/bin/env python
"""
Entry point script for launching the DUST Mesh Builder GUI.

This script ensures Qt libraries are properly configured on Linux systems
to avoid conflicts between PyQt5's bundled Qt and system Qt libraries.
"""

import os
import sys
from pathlib import Path


def setup_qt_environment():
    """Configure Qt library paths on Linux to avoid system conflicts."""
    if sys.platform.startswith("linux"):
        try:
            import PyQt5.QtCore

            pyqt5_dir = Path(PyQt5.QtCore.__file__).parent
            qt5_lib_dir = pyqt5_dir / "Qt5" / "lib"

            if qt5_lib_dir.exists():
                # Prepend PyQt5's Qt libraries to LD_LIBRARY_PATH
                current_ld_path = os.environ.get("LD_LIBRARY_PATH", "")
                new_ld_path = (
                    f"{qt5_lib_dir}:{current_ld_path}"
                    if current_ld_path
                    else str(qt5_lib_dir)
                )
                os.environ["LD_LIBRARY_PATH"] = new_ld_path

                # Re-exec the script if we just modified LD_LIBRARY_PATH and haven't done so already
                if "PYQT5_LD_LIBRARY_PATH_SET" not in os.environ:
                    os.environ["PYQT5_LD_LIBRARY_PATH_SET"] = "1"
                    os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
        except ImportError:
            print(
                "Warning: PyQt5 not found. GUI features require PyQt5 to be installed."
            )
            print("Install with: pip install pydust-utils[gui]")
            sys.exit(1)


def main():
    """Launch the DUST Mesh Builder GUI."""
    setup_qt_environment()

    from pydust_utils.build_mesh_gui import launch_gui

    launch_gui()


if __name__ == "__main__":
    main()
