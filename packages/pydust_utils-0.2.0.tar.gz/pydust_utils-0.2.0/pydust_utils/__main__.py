"""Run DUST Mesh Builder GUI as a module.

This allows launching the GUI with:
    python -m pydust_utils.build_mesh_gui
"""

from .build_mesh_gui import launch_gui

if __name__ == "__main__":
    import sys
    sys.exit(launch_gui())
