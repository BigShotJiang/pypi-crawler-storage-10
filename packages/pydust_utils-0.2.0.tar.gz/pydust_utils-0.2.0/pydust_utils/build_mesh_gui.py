"""Interactive GUI for building DUST meshes with advanced features.

This module provides a PyQt5-based graphical interface for creating and editing
DUST mesh configurations with:
- Multi-component tab system
- Parametric and Pointwise mesh support
- Expandable advanced options
- Real-time 3D preview using PyVista

Example
-------
>>> from pydust_utils.build_mesh_gui import launch_gui
>>> launch_gui()
"""

import os
import sys
from pathlib import Path

# Fix Qt library conflicts on Linux by ensuring PyQt5 uses its bundled Qt libraries
# This prevents conflicts with system Qt libraries that may have incompatible ABIs
if sys.platform.startswith("linux"):
    try:
        import PyQt5.QtCore

        pyqt5_dir = Path(PyQt5.QtCore.__file__).parent
        qt5_lib_dir = pyqt5_dir / "Qt5" / "lib"
        if qt5_lib_dir.exists():
            # Prepend PyQt5's Qt libraries to LD_LIBRARY_PATH
            current_ld_path = os.environ.get("LD_LIBRARY_PATH", "")
            new_ld_path = (
                f"{qt5_lib_dir}:{current_ld_path}"
                if current_ld_path
                else str(qt5_lib_dir)
            )
            os.environ["LD_LIBRARY_PATH"] = new_ld_path

            # Re-exec the script if we just modified LD_LIBRARY_PATH and haven't done so already
            if "PYQT5_LD_LIBRARY_PATH_SET" not in os.environ:
                os.environ["PYQT5_LD_LIBRARY_PATH_SET"] = "1"
                os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
    except ImportError:
        pass  # PyQt5 not installed yet, will fail later with clearer error

import matplotlib

matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure
import numpy as np
import pyvista as pv
from PyQt5 import QtCore, QtWidgets
from pyvistaqt import QtInteractor

from . import build_mesh
from . import mesh_rendering_utils as render
from . import mesh_geometry_utils as geom
from .c81generator import Airfoil

__all__ = ["DUSTMeshBuilderGUI", "launch_gui"]


class ComponentData:
    """Data container for a single component configuration."""

    def __init__(self, name: str, mesh_type: str = "parametric"):
        self.name = name
        self.mesh_type = mesh_type

        # Mesh configuration
        self.config = build_mesh.MeshConfig(
            title=name,
            el_type="v",
            nelem_chord=12,
            type_chord="uniform",
            reference_chord_fraction=0.25,
        )

        # Default span discretization parameters
        self.default_span_type = "uniform"
        self.default_span_params = {}  # Stores ratio for geoseries, etc.

        # Parametric mesh data
        self.sections = [
            build_mesh.ParametricMesh.Section(
                chord=1.0, twist=0.0, airfoil="naca0012", airfoil_table=""
            ),
            build_mesh.ParametricMesh.Section(
                chord=0.6, twist=-2.0, airfoil="naca0012", airfoil_table=""
            ),
        ]

        self.regions = [
            build_mesh.ParametricMesh.Region(
                span=5.0, sweep=0.0, dihed=2.0, nelem_span=10, type_span="uniform"
            )
        ]

        # Pointwise mesh data
        self.points = []
        self.lines = []


class TableManager:
    """Manages table widgets and connections to prevent memory leaks.

    This class tracks all cell widgets and their signal connections,
    ensuring proper cleanup when widgets are removed or replaced.
    """

    def __init__(self, table):
        """Initialize the table manager.

        Args:
            table: QTableWidget to manage
        """
        self.table = table
        self._widget_connections = {}  # Track: widget_id -> [connections]
        self._cell_widgets = []  # Track all created widgets for cleanup

    def create_cell_widget(self, row, col, widget_type, **kwargs):
        """Safely create a cell widget with connection tracking.

        Args:
            row: Row index
            col: Column index
            widget_type: Type of widget ('combo', 'spin', etc.)
            **kwargs: Widget-specific parameters

        Returns:
            Created widget instance
        """
        # Clean up any existing widget first
        existing_widget = self.table.cellWidget(row, col)
        if existing_widget:
            self._remove_widget(existing_widget)

        # Create new widget based on type
        if widget_type == "combo":
            widget = QtWidgets.QComboBox()
            if "items" in kwargs:
                widget.addItems(kwargs["items"])
            if "current_text" in kwargs:
                widget.setCurrentText(kwargs["current_text"])
        elif widget_type == "spin":
            widget = QtWidgets.QSpinBox()
            if "range" in kwargs:
                widget.setRange(kwargs["range"][0], kwargs["range"][1])
            if "value" in kwargs:
                widget.setValue(kwargs["value"])
        else:
            widget = QtWidgets.QWidget()

        # Track the widget
        widget_id = id(widget)
        self._cell_widgets.append(widget)
        self._widget_connections[widget_id] = []

        # Store position in widget for reliable lookup during removal
        widget._table_position = (row, col)

        # Set in table
        self.table.setCellWidget(row, col, widget)

        return widget

    def connect_widget(self, widget, signal_name, slot):
        """Connect signal with tracking to enable proper cleanup.

        Args:
            widget: Widget to connect
            signal_name: Name of signal (e.g., 'currentTextChanged')
            slot: Slot/callback function

        Returns:
            The connection object
        """
        signal = getattr(widget, signal_name)
        connection = signal.connect(slot)

        widget_id = id(widget)
        if widget_id not in self._widget_connections:
            self._widget_connections[widget_id] = []

        self._widget_connections[widget_id].append((widget, signal_name, slot))

        return connection

    def create_row_callback(self, widget, col, callback):
        """Create a callback that dynamically looks up the widget's current row.

        This solves the lambda capture problem where row indices become invalid
        after rows are deleted/inserted. Instead of capturing the row index,
        this searches for the widget's current position when the callback fires.

        Args:
            widget: The widget to track
            col: Column where the widget is located
            callback: Function to call with (row, *args) where row is dynamic

        Returns:
            Wrapper function that can be connected to signals
        """

        def wrapper(*args):
            # Find widget's current row by searching the table
            for row in range(self.table.rowCount()):
                if self.table.cellWidget(row, col) == widget:
                    callback(row, *args)
                    return
            # Widget not found in table (may have been removed)
            # Silently ignore - this is normal during cleanup

        return wrapper

    def _remove_widget(self, widget):
        """Safely remove a widget and all its connections.

        Args:
            widget: Widget to remove
        """
        if not widget:
            return

        widget_id = id(widget)

        # Disconnect all tracked connections for this widget
        if widget_id in self._widget_connections:
            for widget_ref, signal_name, slot in self._widget_connections[widget_id]:
                try:
                    if widget_ref:
                        signal = getattr(widget_ref, signal_name, None)
                        if signal:
                            signal.disconnect(slot)
                except (TypeError, RuntimeError):
                    # Connection may already be broken or widget deleted
                    pass
            del self._widget_connections[widget_id]

        # Remove from tracking list
        if widget in self._cell_widgets:
            self._cell_widgets.remove(widget)

        # Remove from table using stored position (more reliable than indexAt)
        if hasattr(widget, "_table_position"):
            row, col = widget._table_position
            self.table.setCellWidget(row, col, None)

        # Clean up widget
        widget.setParent(None)
        widget.deleteLater()

    def clear_table(self):
        """Completely clear the table with proper widget cleanup."""
        self.table.blockSignals(True)

        try:
            # Remove all cell widgets with proper cleanup
            for row in range(self.table.rowCount()):
                for col in range(self.table.columnCount()):
                    widget = self.table.cellWidget(row, col)
                    if widget:
                        self._remove_widget(widget)
                        self.table.setCellWidget(row, col, None)

            # Clear all items (non-widget cells)
            self.table.clearContents()
            self.table.setRowCount(0)

            # Clear tracking structures
            self._cell_widgets.clear()
            self._widget_connections.clear()

            # Force garbage collection
            import gc

            gc.collect()

        finally:
            self.table.blockSignals(False)

    def get_tracked_widget_count(self):
        """Get count of currently tracked widgets (for debugging)."""
        return len(self._cell_widgets)

    def get_connection_count(self):
        """Get total count of tracked connections (for debugging)."""
        return sum(len(conns) for conns in self._widget_connections.values())


class DUSTMeshBuilderGUI(QtWidgets.QMainWindow):
    """Main GUI application for DUST mesh building with advanced features."""

    def __init__(self):
        """Initialize the DUST Mesh Builder GUI."""
        super().__init__()

        self.setWindowTitle("DUST Mesh Builder")
        self.setGeometry(50, 50, 1800, 950)

        # Component management
        self.components: dict[str, ComponentData] = {}
        self.current_component_name = "Component_1"
        self.components[self.current_component_name] = ComponentData(
            self.current_component_name
        )

        # Dark mode state
        self.dark_mode = False

        # CRITICAL FIX: State machine to prevent race conditions
        self._update_state = (
            "IDLE"  # States: IDLE, LOADING, PROCESSING_GEOMETRY, UPDATING_PREVIEW
        )
        self._pending_geometry_update = False
        self._pending_config_update = False
        self._state_change_time = None  # Track when state last changed

        # Debouncing timer for geometry updates
        self._geometry_update_timer = QtCore.QTimer()
        self._geometry_update_timer.setSingleShot(True)
        self._geometry_update_timer.setInterval(
            300
        )  # 300ms debounce for smoother updates
        self._geometry_update_timer.timeout.connect(self._process_pending_updates)

        # State machine watchdog - detects stuck states
        self._state_watchdog = QtCore.QTimer()
        self._state_watchdog.timeout.connect(self._check_stuck_state)
        self._state_watchdog.start(5000)  # Check every 5 seconds

        self._init_ui()

        # Note: Table managers are initialized in the table creation methods
        # (_create_parametric_sections_group, _create_parametric_regions_group, etc.)

        self._load_component_data()
        self._update_3d_preview()

    @property
    def current_component(self) -> ComponentData:
        """Get current active component data."""
        return self.components[self.current_component_name]

    def _set_update_state(self, new_state):
        """Safely transition between update states with validation."""
        # Allow self-transitions (no-op) without warning
        if self._update_state == new_state:
            return

        valid_transitions = {
            "IDLE": ["LOADING", "PROCESSING_GEOMETRY", "UPDATING_PREVIEW"],
            "LOADING": ["IDLE"],
            "PROCESSING_GEOMETRY": ["IDLE", "UPDATING_PREVIEW"],
            "UPDATING_PREVIEW": ["IDLE"],
        }

        if new_state in valid_transitions.get(self._update_state, []):
            old_state = self._update_state
            self._update_state = new_state

            # Track state change time for watchdog
            import time

            self._state_change_time = time.time()

            # Debug logging for state transitions
            print(f"State transition: {old_state} → {new_state}")
        else:
            print(
                f"⚠ Invalid state transition attempted: {self._update_state} → {new_state}"
            )

    def _check_stuck_state(self):
        """Watchdog to detect and recover from stuck state machine.

        Checks if the state machine has been stuck in a non-IDLE state
        for more than 10 seconds and forces it back to IDLE.
        """
        import time

        if self._update_state != "IDLE":
            current_time = time.time()

            # Check if we've been stuck for more than 10 seconds
            if (
                self._state_change_time
                and (current_time - self._state_change_time) > 10
            ):
                print(
                    f"⚠️ State machine stuck in {self._update_state} for >10s, forcing IDLE"
                )
                self.statusBar().showMessage(
                    f"⚠️ Recovered from stuck state: {self._update_state}", 3000
                )
                self._update_state = "IDLE"
                self._state_change_time = None

    def closeEvent(self, event):
        """Handle application close with proper memory cleanup."""
        print("Closing application - cleaning up resources...")

        try:
            # Stop any pending timers
            if hasattr(self, "_geometry_update_timer"):
                self._geometry_update_timer.stop()

            # Use table managers for proper cleanup
            for manager_name in [
                "sections_table_manager",
                "regions_table_manager",
                "points_table_manager",
                "lines_table_manager",
            ]:
                if hasattr(self, manager_name):
                    manager = getattr(self, manager_name)
                    print(
                        f"  Clearing {manager_name}: {manager.get_tracked_widget_count()} widgets, "
                        f"{manager.get_connection_count()} connections"
                    )
                    manager.clear_table()

            # Clear 3D plotter and all actors
            if hasattr(self, "plotter"):
                try:
                    self.plotter.clear()
                    self.plotter.clear_actors()
                    self.plotter.close()
                    print("  Plotter closed")
                except Exception as e:
                    print(f"  Error closing plotter: {e}")

            # Force garbage collection
            import gc

            gc.collect()

            print("Cleanup complete")

        except Exception as e:
            print(f"Error during cleanup: {e}")
        finally:
            # Always accept the close event
            event.accept()

    def _init_ui(self):
        """Create the main UI layout."""
        central_widget = QtWidgets.QWidget()
        self.setCentralWidget(central_widget)

        # Main vertical layout
        main_layout = QtWidgets.QVBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)

        # Top toolbar with mesh type selector
        toolbar = self._create_toolbar()
        main_layout.addWidget(toolbar)

        # Component tabs
        self.component_tabs = QtWidgets.QTabWidget()
        self.component_tabs.setTabsClosable(True)
        self.component_tabs.setMovable(True)
        self.component_tabs.tabCloseRequested.connect(self._close_component_tab)
        self.component_tabs.currentChanged.connect(self._on_tab_changed)
        main_layout.addWidget(self.component_tabs)

        # Add first component tab
        self._add_component_tab(self.current_component_name)

        # Add "+" button for new components
        self.component_tabs.setCornerWidget(self._create_add_component_button())

        # Status bar
        self.statusBar().showMessage("Ready")

    def _create_toolbar(self):
        """Create top toolbar with mesh type selector and global controls."""
        toolbar = QtWidgets.QToolBar()
        toolbar.setMovable(False)

        # Mesh type selector
        toolbar.addWidget(QtWidgets.QLabel("  Mesh Type: "))
        self.mesh_type_combo = QtWidgets.QComboBox()
        self.mesh_type_combo.addItems(["Parametric", "Pointwise"])
        self.mesh_type_combo.currentTextChanged.connect(self._on_mesh_type_changed)
        toolbar.addWidget(self.mesh_type_combo)

        toolbar.addSeparator()

        # Global actions
        export_action = QtWidgets.QAction("Export All", self)
        export_action.triggered.connect(self._export_all_components)
        toolbar.addAction(export_action)

        toolbar.addSeparator()

        # Dark mode toggle
        self.dark_mode_action = QtWidgets.QAction("Dark Mode", self)
        self.dark_mode_action.setCheckable(True)
        self.dark_mode_action.setChecked(False)
        self.dark_mode_action.triggered.connect(self._toggle_dark_mode)
        toolbar.addAction(self.dark_mode_action)

        return toolbar

    def _create_add_component_button(self):
        """Create button for adding new component tabs."""
        btn = QtWidgets.QPushButton("+ Add Component")
        btn.clicked.connect(self._add_new_component)
        return btn

    def _add_component_tab(self, component_name: str):
        """Add a new component tab to the tab widget."""
        # Create tab content
        tab_widget = QtWidgets.QWidget()
        tab_layout = QtWidgets.QHBoxLayout(tab_widget)
        tab_layout.setContentsMargins(5, 5, 5, 5)

        # Left panel: configuration and geometry
        left_panel = self._create_control_panel()
        tab_layout.addWidget(left_panel, stretch=1)

        # Right panel: 3D preview
        right_panel = self._create_3d_panel()
        tab_layout.addWidget(right_panel, stretch=2)

        # Add tab
        index = self.component_tabs.addTab(tab_widget, component_name)
        self.component_tabs.setCurrentIndex(index)

    def _create_control_panel(self):
        """Create the left control panel with configuration."""
        panel = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(panel)

        # Title
        title = QtWidgets.QLabel("<h3>Mesh Configuration</h3>")
        title.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(title)

        # Scroll area for all controls
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll_content = QtWidgets.QWidget()
        scroll_layout = QtWidgets.QVBoxLayout(scroll_content)

        # Basic configuration (always visible)
        basic_config = self._create_basic_config_group()
        scroll_layout.addWidget(basic_config)

        # Advanced configuration (collapsible)
        advanced_config = self._create_advanced_config_group()
        scroll_layout.addWidget(advanced_config)

        # Geometry configuration (depends on mesh type)
        self.geometry_widget = QtWidgets.QWidget()
        self.geometry_layout = QtWidgets.QVBoxLayout(self.geometry_widget)
        self.geometry_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.addWidget(self.geometry_widget)

        # Initially populate with parametric geometry
        self._update_geometry_panel()

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)

        # Export button for current component
        export_btn = QtWidgets.QPushButton("Export This Component")
        export_btn.clicked.connect(self._export_current_component)
        export_btn.setStyleSheet("QPushButton { font-weight: bold; padding: 8px; }")
        layout.addWidget(export_btn)

        return panel

    def _create_basic_config_group(self):
        """Create basic mesh configuration group."""
        group = QtWidgets.QGroupBox("Basic Configuration")
        layout = QtWidgets.QFormLayout(group)

        # Component title
        self.title_input = QtWidgets.QLineEdit()
        self.title_input.textChanged.connect(self._on_config_changed)
        layout.addRow("Title:", self.title_input)

        # Element type
        self.el_type_combo = QtWidgets.QComboBox()
        self.el_type_combo.addItems(
            ["v (Vortex-Lattice)", "l (Lifting-Line)", "p (Panel)"]
        )
        self.el_type_combo.currentTextChanged.connect(self._on_config_changed)
        layout.addRow("Element Type:", self.el_type_combo)

        # Chord elements
        self.nelem_chord_spin = QtWidgets.QSpinBox()
        self.nelem_chord_spin.setRange(1, 200)
        self.nelem_chord_spin.setValue(12)
        self.nelem_chord_spin.valueChanged.connect(self._on_config_changed)
        layout.addRow("Chord Elements:", self.nelem_chord_spin)

        # Reference chord fraction
        self.ref_chord_spin = QtWidgets.QDoubleSpinBox()
        self.ref_chord_spin.setRange(0.0, 1.0)
        self.ref_chord_spin.setSingleStep(0.05)
        self.ref_chord_spin.setDecimals(3)
        self.ref_chord_spin.setValue(0.25)
        self.ref_chord_spin.valueChanged.connect(self._on_config_changed)
        layout.addRow("Ref Chord Frac:", self.ref_chord_spin)

        # Starting point (origin) coordinates
        starting_point_layout = QtWidgets.QHBoxLayout()

        self.starting_point_x = QtWidgets.QDoubleSpinBox()
        self.starting_point_x.setRange(-1000.0, 1000.0)
        self.starting_point_x.setDecimals(3)
        self.starting_point_x.setValue(0.0)
        self.starting_point_x.valueChanged.connect(self._on_config_changed)
        starting_point_layout.addWidget(QtWidgets.QLabel("X:"))
        starting_point_layout.addWidget(self.starting_point_x)

        self.starting_point_y = QtWidgets.QDoubleSpinBox()
        self.starting_point_y.setRange(-1000.0, 1000.0)
        self.starting_point_y.setDecimals(3)
        self.starting_point_y.setValue(0.0)
        self.starting_point_y.valueChanged.connect(self._on_config_changed)
        starting_point_layout.addWidget(QtWidgets.QLabel("Y:"))
        starting_point_layout.addWidget(self.starting_point_y)

        self.starting_point_z = QtWidgets.QDoubleSpinBox()
        self.starting_point_z.setRange(-1000.0, 1000.0)
        self.starting_point_z.setDecimals(3)
        self.starting_point_z.setValue(0.0)
        self.starting_point_z.valueChanged.connect(self._on_config_changed)
        starting_point_layout.addWidget(QtWidgets.QLabel("Z:"))
        starting_point_layout.addWidget(self.starting_point_z)

        layout.addRow("Starting Point:", starting_point_layout)

        return group

    def _create_advanced_config_group(self):
        """Create advanced/collapsible configuration group."""
        # Main collapsible group
        group = CollapsibleBox("Advanced Configuration")
        content_layout = QtWidgets.QVBoxLayout()

        # Chord discretization
        chord_disc_group = self._create_chord_discretization_group()
        content_layout.addWidget(chord_disc_group)

        # Symmetry options
        symmetry_group = self._create_symmetry_group()
        content_layout.addWidget(symmetry_group)

        # Mirror options
        mirror_group = self._create_mirror_group()
        content_layout.addWidget(mirror_group)

        # Other advanced options
        other_group = self._create_other_advanced_group()
        content_layout.addWidget(other_group)

        group.setContentLayout(content_layout)
        return group

    def _create_chord_discretization_group(self):
        """Create chord discretization configuration group."""
        group = CollapsibleBox("Chord Discretization")
        layout = QtWidgets.QFormLayout()

        # Chord type
        self.type_chord_combo = QtWidgets.QComboBox()
        self.type_chord_combo.addItems(
            [
                "uniform",
                "cosine",
                "cosine_le",
                "cosine_te",
                "geoseries",
                "geoseries_le",
                "geoseries_te",
                "geoseries_hi",
            ]
        )
        self.type_chord_combo.currentTextChanged.connect(self._on_chord_type_changed)
        layout.addRow("Type:", self.type_chord_combo)

        # Conditional parameters (shown based on chord type)
        self.chord_params_widget = QtWidgets.QWidget()
        self.chord_params_layout = QtWidgets.QFormLayout(self.chord_params_widget)
        layout.addRow(self.chord_params_widget)

        group.setContentLayout(layout)
        return group

    def _create_symmetry_group(self):
        """Create symmetry configuration group."""
        group = CollapsibleBox("Symmetry Plane")
        layout = QtWidgets.QVBoxLayout()

        # Enable checkbox
        self.symmetry_enable = QtWidgets.QCheckBox("Enable Symmetry")
        self.symmetry_enable.stateChanged.connect(self._on_symmetry_changed)
        layout.addWidget(self.symmetry_enable)

        # Symmetry parameters (shown when enabled)
        self.symmetry_params_widget = QtWidgets.QWidget()
        symmetry_params_layout = QtWidgets.QVBoxLayout(self.symmetry_params_widget)

        # Point group
        point_group = QtWidgets.QGroupBox("Plane Point")
        point_layout = QtWidgets.QHBoxLayout()

        self.symmetry_point_x = QtWidgets.QDoubleSpinBox()
        self.symmetry_point_x.setRange(-1000, 1000)
        self.symmetry_point_x.setDecimals(3)
        self.symmetry_point_x.setPrefix("X: ")
        self.symmetry_point_x.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.symmetry_point_x)

        self.symmetry_point_y = QtWidgets.QDoubleSpinBox()
        self.symmetry_point_y.setRange(-1000, 1000)
        self.symmetry_point_y.setDecimals(3)
        self.symmetry_point_y.setPrefix("Y: ")
        self.symmetry_point_y.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.symmetry_point_y)

        self.symmetry_point_z = QtWidgets.QDoubleSpinBox()
        self.symmetry_point_z.setRange(-1000, 1000)
        self.symmetry_point_z.setDecimals(3)
        self.symmetry_point_z.setPrefix("Z: ")
        self.symmetry_point_z.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.symmetry_point_z)

        point_group.setLayout(point_layout)
        symmetry_params_layout.addWidget(point_group)

        # Normal group
        normal_group = QtWidgets.QGroupBox("Plane Normal")
        normal_layout = QtWidgets.QHBoxLayout()

        self.symmetry_normal_x = QtWidgets.QDoubleSpinBox()
        self.symmetry_normal_x.setRange(-1, 1)
        self.symmetry_normal_x.setDecimals(3)
        self.symmetry_normal_x.setValue(0.0)
        self.symmetry_normal_x.setPrefix("X: ")
        self.symmetry_normal_x.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.symmetry_normal_x)

        self.symmetry_normal_y = QtWidgets.QDoubleSpinBox()
        self.symmetry_normal_y.setRange(-1, 1)
        self.symmetry_normal_y.setDecimals(3)
        self.symmetry_normal_y.setValue(1.0)
        self.symmetry_normal_y.setPrefix("Y: ")
        self.symmetry_normal_y.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.symmetry_normal_y)

        self.symmetry_normal_z = QtWidgets.QDoubleSpinBox()
        self.symmetry_normal_z.setRange(-1, 1)
        self.symmetry_normal_z.setDecimals(3)
        self.symmetry_normal_z.setValue(0.0)
        self.symmetry_normal_z.setPrefix("Z: ")
        self.symmetry_normal_z.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.symmetry_normal_z)

        normal_group.setLayout(normal_layout)
        symmetry_params_layout.addWidget(normal_group)

        self.symmetry_params_widget.setVisible(False)
        layout.addWidget(self.symmetry_params_widget)

        group.setContentLayout(layout)
        return group

    def _create_mirror_group(self):
        """Create mirror configuration group."""
        group = CollapsibleBox("Mirror Plane")
        layout = QtWidgets.QVBoxLayout()

        # Enable checkbox
        self.mirror_enable = QtWidgets.QCheckBox("Enable Mirror")
        self.mirror_enable.stateChanged.connect(self._on_mirror_changed)
        layout.addWidget(self.mirror_enable)

        # Mirror parameters (shown when enabled)
        self.mirror_params_widget = QtWidgets.QWidget()
        mirror_params_layout = QtWidgets.QVBoxLayout(self.mirror_params_widget)

        # Point group
        point_group = QtWidgets.QGroupBox("Plane Point")
        point_layout = QtWidgets.QHBoxLayout()

        self.mirror_point_x = QtWidgets.QDoubleSpinBox()
        self.mirror_point_x.setRange(-1000, 1000)
        self.mirror_point_x.setDecimals(3)
        self.mirror_point_x.setPrefix("X: ")
        self.mirror_point_x.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.mirror_point_x)

        self.mirror_point_y = QtWidgets.QDoubleSpinBox()
        self.mirror_point_y.setRange(-1000, 1000)
        self.mirror_point_y.setDecimals(3)
        self.mirror_point_y.setPrefix("Y: ")
        self.mirror_point_y.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.mirror_point_y)

        self.mirror_point_z = QtWidgets.QDoubleSpinBox()
        self.mirror_point_z.setRange(-1000, 1000)
        self.mirror_point_z.setDecimals(3)
        self.mirror_point_z.setPrefix("Z: ")
        self.mirror_point_z.valueChanged.connect(self._on_config_changed)
        point_layout.addWidget(self.mirror_point_z)

        point_group.setLayout(point_layout)
        mirror_params_layout.addWidget(point_group)

        # Normal group
        normal_group = QtWidgets.QGroupBox("Plane Normal")
        normal_layout = QtWidgets.QHBoxLayout()

        self.mirror_normal_x = QtWidgets.QDoubleSpinBox()
        self.mirror_normal_x.setRange(-1, 1)
        self.mirror_normal_x.setDecimals(3)
        self.mirror_normal_x.setValue(1.0)
        self.mirror_normal_x.setPrefix("X: ")
        self.mirror_normal_x.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.mirror_normal_x)

        self.mirror_normal_y = QtWidgets.QDoubleSpinBox()
        self.mirror_normal_y.setRange(-1, 1)
        self.mirror_normal_y.setDecimals(3)
        self.mirror_normal_y.setValue(0.0)
        self.mirror_normal_y.setPrefix("Y: ")
        self.mirror_normal_y.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.mirror_normal_y)

        self.mirror_normal_z = QtWidgets.QDoubleSpinBox()
        self.mirror_normal_z.setRange(-1, 1)
        self.mirror_normal_z.setDecimals(3)
        self.mirror_normal_z.setValue(0.0)
        self.mirror_normal_z.setPrefix("Z: ")
        self.mirror_normal_z.valueChanged.connect(self._on_config_changed)
        normal_layout.addWidget(self.mirror_normal_z)

        normal_group.setLayout(normal_layout)
        mirror_params_layout.addWidget(normal_group)

        self.mirror_params_widget.setVisible(False)
        layout.addWidget(self.mirror_params_widget)

        group.setContentLayout(layout)
        return group

    def _create_other_advanced_group(self):
        """Create other advanced options group."""
        group = CollapsibleBox("Other Options")
        layout = QtWidgets.QFormLayout()

        # Airfoil table correction
        self.airfoil_table_correction = QtWidgets.QCheckBox()
        layout.addRow("Airfoil Table Correction:", self.airfoil_table_correction)

        # Y fountain
        self.y_fountain_spin = QtWidgets.QDoubleSpinBox()
        self.y_fountain_spin.setRange(0, 1000)
        self.y_fountain_spin.setDecimals(3)
        layout.addRow("Y Fountain [m]:", self.y_fountain_spin)

        group.setContentLayout(layout)
        return group

    def _update_geometry_panel(self):
        """Update geometry panel based on current mesh type."""
        # Clear existing widgets
        while self.geometry_layout.count():
            item = self.geometry_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        comp = self.current_component

        if comp.mesh_type == "parametric":
            # Parametric mesh: sections and regions tables
            sections_group = self._create_parametric_sections_group()
            regions_group = self._create_parametric_regions_group()
            self.geometry_layout.addWidget(sections_group)
            self.geometry_layout.addWidget(regions_group)
        else:
            # Pointwise mesh: points and lines tables
            points_group = self._create_pointwise_points_group()
            lines_group = self._create_pointwise_lines_group()
            self.geometry_layout.addWidget(points_group)
            self.geometry_layout.addWidget(lines_group)

    def _create_parametric_sections_group(self):
        """Create parametric sections table group."""
        group = QtWidgets.QGroupBox("Wing Sections")
        layout = QtWidgets.QVBoxLayout(group)

        # Header with buttons
        header = QtWidgets.QHBoxLayout()
        header.addWidget(QtWidgets.QLabel("<b>Sections:</b>"))
        header.addStretch()

        add_btn = QtWidgets.QPushButton("+ Add")
        remove_btn = QtWidgets.QPushButton("- Remove")

        add_btn.clicked.connect(self._add_section_row)
        remove_btn.clicked.connect(self._remove_section_row)

        header.addWidget(add_btn)
        header.addWidget(remove_btn)
        layout.addLayout(header)

        # Sections table TODO: add if that adds airfoil table when needed so when elem is l or airfoil_table_correction is enable
        # Add selection browser for airfoil table files in that column
        self.sections_table = QtWidgets.QTableWidget(0, 4)
        self.sections_table.setHorizontalHeaderLabels(
            ["Chord", "Twist (°)", "Airfoil", "Airfoil Table"]
        )

        # Set column widths
        self.sections_table.setColumnWidth(0, 60)  # Chord
        self.sections_table.setColumnWidth(1, 70)  # Twist
        self.sections_table.setColumnWidth(2, 90)  # Airfoil
        self.sections_table.horizontalHeader().setStretchLastSection(
            True
        )  # Airfoil Table stretches

        # Connect signals ONLY ONCE during initialization
        # Updates are prevented during data loading via _loading_data flag (not blockSignals)
        self.sections_table.cellChanged.connect(self._on_geometry_changed)
        self.sections_table.cellClicked.connect(self._on_section_cell_clicked)
        self.sections_table.itemSelectionChanged.connect(
            self._on_section_selection_changed
        )

        layout.addWidget(self.sections_table)

        # Always recreate table manager when table is recreated
        # (table gets deleted/recreated when switching mesh types)
        self.sections_table_manager = TableManager(self.sections_table)

        return group

    def _create_parametric_regions_group(self):
        """Create parametric regions table group."""
        group = QtWidgets.QGroupBox("Wing Regions")
        layout = QtWidgets.QVBoxLayout(group)

        # Header with buttons
        header = QtWidgets.QHBoxLayout()
        header.addWidget(QtWidgets.QLabel("<b>Regions:</b>"))
        header.addStretch()

        add_btn = QtWidgets.QPushButton("+ Add")
        remove_btn = QtWidgets.QPushButton("- Remove")
        add_btn.clicked.connect(self._add_region_row)
        remove_btn.clicked.connect(self._remove_region_row)

        header.addWidget(add_btn)
        header.addWidget(remove_btn)
        layout.addLayout(header)

        # Regions table
        self.regions_table = QtWidgets.QTableWidget(0, 8)
        self.regions_table.setHorizontalHeaderLabels(
            [
                "Span",
                "Sweep (°)",
                "Dihed (°)",
                "N Elem",
                "Type",
                "Y Refinement",
                "R_ob",
                "R_ib",
            ]
        )

        # Set column widths to fit content
        header = self.regions_table.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        header.setStretchLastSection(False)

        # Set specific column widths for better fit
        self.regions_table.setColumnWidth(0, 75)  # Span
        self.regions_table.setColumnWidth(1, 70)  # Sweep
        self.regions_table.setColumnWidth(2, 70)  # Dihed
        self.regions_table.setColumnWidth(3, 60)  # N Elem
        self.regions_table.setColumnWidth(4, 90)  # Type (dropdown)
        self.regions_table.setColumnWidth(5, 70)  # Y Ref
        self.regions_table.setColumnWidth(6, 70)  # r_ob
        self.regions_table.setColumnWidth(7, 70)  # r_ib

        # Connect signal ONLY ONCE during initialization
        # Updates are prevented during data loading via _loading_data flag (not blockSignals)
        self.regions_table.itemChanged.connect(self._on_geometry_changed)
        layout.addWidget(self.regions_table)

        # Always recreate table manager when table is recreated
        # (table gets deleted/recreated when switching mesh types)
        self.regions_table_manager = TableManager(self.regions_table)

        return group

    def _create_pointwise_points_group(self):
        """Create pointwise points table group."""
        group = QtWidgets.QGroupBox("Mesh Points")
        layout = QtWidgets.QVBoxLayout(group)

        # Header
        header = QtWidgets.QHBoxLayout()
        header.addWidget(QtWidgets.QLabel("<b>Points:</b>"))
        header.addStretch()

        add_btn = QtWidgets.QPushButton("+ Add Point")
        remove_btn = QtWidgets.QPushButton("- Remove")
        add_btn.clicked.connect(self._add_point_row)
        remove_btn.clicked.connect(self._remove_point_row)

        header.addWidget(add_btn)
        header.addWidget(remove_btn)
        layout.addLayout(header)

        # Points table
        self.points_table = QtWidgets.QTableWidget(0, 8)
        self.points_table.setHorizontalHeaderLabels(
            ["ID", "X", "Y", "Z", "Chord", "Twist (°)", "Airfoil", "Airfoil Table"]
        )
        self.points_table.horizontalHeader().setStretchLastSection(True)

        # Connect signals ONLY ONCE during initialization
        # Updates are prevented during data loading via _loading_data flag (not blockSignals)
        self.points_table.itemChanged.connect(self._on_geometry_changed)
        self.points_table.cellClicked.connect(self._on_point_cell_clicked)
        layout.addWidget(self.points_table)

        layout.addWidget(
            QtWidgets.QLabel(
                "<i>Hint: Pointwise mesh requires defining explicit points and connecting them with lines</i>"
            )
        )

        # Always recreate table manager when table is recreated
        # (table gets deleted/recreated when switching mesh types)
        self.points_table_manager = TableManager(self.points_table)

        return group

    def _create_pointwise_lines_group(self):
        """Create pointwise lines table group."""
        group = QtWidgets.QGroupBox("Mesh Lines")
        layout = QtWidgets.QVBoxLayout(group)

        # Header
        header = QtWidgets.QHBoxLayout()
        header.addWidget(QtWidgets.QLabel("<b>Lines:</b>"))
        header.addStretch()

        add_btn = QtWidgets.QPushButton("+ Add Line")
        remove_btn = QtWidgets.QPushButton("- Remove")
        add_btn.clicked.connect(self._add_line_row)
        remove_btn.clicked.connect(self._remove_line_row)

        header.addWidget(add_btn)
        header.addWidget(remove_btn)
        layout.addLayout(header)

        # Lines table - add columns for span distribution parameters
        self.lines_table = QtWidgets.QTableWidget(0, 8)
        self.lines_table.setHorizontalHeaderLabels(
            [
                "Type",
                "Point 1 ID",
                "Point 2 ID",
                "N Elem",
                "Span Type",
                "y_ref",
                "r_ob",
                "r_ib",
            ]
        )
        self.lines_table.horizontalHeader().setStretchLastSection(True)

        # Connect signal ONLY ONCE during initialization
        # Updates are prevented during data loading via _loading_data flag (not blockSignals)
        self.lines_table.itemChanged.connect(self._on_geometry_changed)
        layout.addWidget(self.lines_table)

        # Always recreate table manager when table is recreated
        # (table gets deleted/recreated when switching mesh types)
        self.lines_table_manager = TableManager(self.lines_table)

        return group

    def _create_3d_panel(self):
        """Create the right panel with 3D preview."""
        panel = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(panel)

        # Title
        title = QtWidgets.QLabel("<h3>3D Preview</h3>")
        title.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(title)

        # Create PyVista plotter
        self.plotter = QtInteractor(panel)
        layout.addWidget(self.plotter.interactor, stretch=1)

        # View options
        view_options = QtWidgets.QHBoxLayout()

        # Add visualization checkboxes
        self.show_surface_check = QtWidgets.QCheckBox("Show Surface")
        self.show_surface_check.setChecked(True)
        self.show_surface_check.stateChanged.connect(self._update_3d_preview)

        self.show_wireframe_check = QtWidgets.QCheckBox("Show Wireframe")
        self.show_wireframe_check.setChecked(False)
        self.show_wireframe_check.stateChanged.connect(self._update_3d_preview)

        self.show_sections_check = QtWidgets.QCheckBox("Show Sections")
        self.show_sections_check.setChecked(True)
        self.show_sections_check.stateChanged.connect(self._update_3d_preview)

        view_options.addWidget(self.show_surface_check)
        view_options.addWidget(self.show_wireframe_check)
        view_options.addWidget(self.show_sections_check)

        view_options.addStretch()
        layout.addLayout(view_options)

        # Camera controls
        controls = self._create_camera_controls()
        layout.addLayout(controls)

        return panel

    def _create_camera_controls(self):
        """Create camera control buttons."""
        controls = QtWidgets.QHBoxLayout()

        view_xy_btn = QtWidgets.QPushButton("View XY")
        view_xz_btn = QtWidgets.QPushButton("View XZ")
        view_yz_btn = QtWidgets.QPushButton("View YZ")
        view_iso_btn = QtWidgets.QPushButton("Isometric")
        reset_cam_btn = QtWidgets.QPushButton("Reset Camera")

        view_xy_btn.clicked.connect(lambda: self.plotter.view_xy())
        view_xz_btn.clicked.connect(lambda: self.plotter.view_xz())
        view_yz_btn.clicked.connect(lambda: self.plotter.view_yz())
        view_iso_btn.clicked.connect(lambda: self.plotter.view_isometric())
        reset_cam_btn.clicked.connect(lambda: self.plotter.reset_camera())

        controls.addWidget(view_xy_btn)
        controls.addWidget(view_xz_btn)
        controls.addWidget(view_yz_btn)
        controls.addWidget(view_iso_btn)
        controls.addWidget(reset_cam_btn)
        controls.addStretch()

        return controls

    # Event handlers

    def _on_mesh_type_changed(self, mesh_type_str: str):
        """Handle mesh type change."""
        mesh_type = mesh_type_str.lower()
        self.current_component.mesh_type = mesh_type
        self._update_geometry_panel()

        # Reload geometry data after panel is rebuilt TODO add for pointwise
        if mesh_type == "parametric":
            self._load_parametric_data()

        self._update_3d_preview()
        self.statusBar().showMessage(f"Switched to {mesh_type} mesh", 2000)

    def _on_chord_type_changed(self, chord_type: str):
        """Handle chord discretization type change - show/hide relevant parameters."""
        # Clear existing parameter widgets
        while self.chord_params_layout.count():
            item = self.chord_params_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Add type-specific parameters based on chord type
        if chord_type in ["geoseries_le", "geoseries_te"]:
            # geoseries_le and geoseries_te use single ratio 'r'
            r_spin = QtWidgets.QDoubleSpinBox()
            r_spin.setRange(0.001, 0.5)
            r_spin.setDecimals(3)
            r_spin.setValue(0.125)
            r_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("Ratio (r):", r_spin)

        elif chord_type == "geoseries":
            # geoseries uses r_ib, r_ob, and y_refinement
            r_ob_spin = QtWidgets.QDoubleSpinBox()
            r_ob_spin.setRange(0.001, 0.999)
            r_ob_spin.setDecimals(3)
            r_ob_spin.setValue(0.1)
            r_ob_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("Outer Boundary Ratio (r_ob):", r_ob_spin)

            r_ib_spin = QtWidgets.QDoubleSpinBox()
            r_ib_spin.setRange(0.001, 0.999)
            r_ib_spin.setDecimals(3)
            r_ib_spin.setValue(0.1)
            r_ib_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("Inner Boundary Ratio (r_ib):", r_ib_spin)

            x_ref_spin = QtWidgets.QDoubleSpinBox()
            x_ref_spin.setRange(0.0, 1.0)
            x_ref_spin.setDecimals(3)
            x_ref_spin.setValue(0.5)
            x_ref_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("X Refinement [adim]:", x_ref_spin)

        elif chord_type in ["geoseries_ob", "geoseries_ib"]:
            # geoseries_ob uses r_ob and y_refinement
            # geoseries_ib uses r_ib and y_refinement
            param_name = "r_ob" if chord_type == "geoseries_ob" else "r_ib"
            r_spin = QtWidgets.QDoubleSpinBox()
            r_spin.setRange(0.001, 0.999)
            r_spin.setDecimals(3)
            r_spin.setValue(0.1)
            r_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow(f"Ratio ({param_name}):", r_spin)

            x_ref_spin = QtWidgets.QDoubleSpinBox()
            x_ref_spin.setRange(0.0, 1.0)
            x_ref_spin.setDecimals(3)
            x_ref_spin.setValue(0.5)
            x_ref_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("X Refinement [adim]:", x_ref_spin)

        elif chord_type == "geoseries_hi":
            # geoseries_hi uses 4 ratios + x_refinement
            for param_name, default_val in [
                ("LE Fix Ratio (r_le_fix)", 0.125),
                ("TE Fix Ratio (r_te_fix)", 0.143),
                ("LE Moving Ratio (r_le_moving)", 0.143),
                ("TE Moving Ratio (r_te_moving)", 0.1),
            ]:
                spin = QtWidgets.QDoubleSpinBox()
                spin.setRange(0.001, 0.5)
                spin.setDecimals(3)
                spin.setValue(default_val)
                spin.valueChanged.connect(self._on_geometry_changed)
                self.chord_params_layout.addRow(f"{param_name}:", spin)

            x_ref_spin = QtWidgets.QDoubleSpinBox()
            x_ref_spin.setRange(0.0, 1.0)
            x_ref_spin.setDecimals(3)
            x_ref_spin.setValue(0.5)
            x_ref_spin.valueChanged.connect(self._on_geometry_changed)
            self.chord_params_layout.addRow("X Refinement [adim]:", x_ref_spin)

        self._on_config_changed()

    def _on_span_type_changed(self, span_type: str):
        """Handle span discretization type change - show/hide relevant parameters."""
        comp = self.current_component
        comp.default_span_type = span_type
        comp.default_span_params = {}

        # Clear existing parameter widgets
        while self.span_params_layout.count():
            item = self.span_params_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Add type-specific parameters based on span type
        if span_type == "geoseries":
            # geoseries uses ratio 'r'
            r_spin = QtWidgets.QDoubleSpinBox()
            r_spin.setRange(0.001, 0.999)
            r_spin.setDecimals(3)
            r_spin.setValue(0.1)
            r_spin.valueChanged.connect(lambda v: self._update_span_param("r", v))
            self.span_params_layout.addRow("Ratio (r):", r_spin)
            comp.default_span_params["r"] = 0.1

        # Uniform and cosine don't need extra parameters

        self._update_3d_preview()

    def _update_span_param(self, param_name: str, value: float):
        """Update span parameter value and refresh preview."""
        self.current_component.default_span_params[param_name] = value
        self._update_3d_preview()

    def _on_symmetry_changed(self, state):
        """Handle symmetry enable/disable."""
        enabled = state == QtCore.Qt.Checked
        self.symmetry_params_widget.setVisible(enabled)
        self.current_component.config.mesh_symmetry = enabled
        # Force layout update
        self.symmetry_params_widget.updateGeometry()
        self._update_3d_preview()

    def _on_mirror_changed(self, state):
        """Handle mirror enable/disable."""
        enabled = state == QtCore.Qt.Checked
        self.mirror_params_widget.setVisible(enabled)
        self.current_component.config.mesh_mirror = enabled
        # Force layout update
        self.mirror_params_widget.updateGeometry()
        self._update_3d_preview()

    def _on_config_changed(self):
        """Handle mesh configuration changes."""
        self._extract_config_from_gui()

        # Set flag to prevent double update from _on_geometry_changed
        self._updating_from_config = True

        # Update 3D preview when config changes
        self._update_3d_preview()
        self.statusBar().showMessage(
            f"Configuration updated - nelem_chord: {self.current_component.config.nelem_chord}",
            2000,
        )

        self._updating_from_config = False

    def _extract_config_from_gui(self):
        """Extract configuration from GUI widgets and store in current component config."""
        comp = self.current_component

        comp.config.title = self.title_input.text()
        comp.config.el_type = self.el_type_combo.currentText()[
            0
        ]  # Extract 'v', 'l', or 'p'
        comp.config.nelem_chord = self.nelem_chord_spin.value()
        comp.config.type_chord = self.type_chord_combo.currentText()
        comp.config.reference_chord_fraction = self.ref_chord_spin.value()
        comp.config.starting_point = [
            self.starting_point_x.value(),
            self.starting_point_y.value(),
            self.starting_point_z.value(),
        ]
        comp.config.airfoil_table_correction = self.airfoil_table_correction.isChecked()
        comp.config.y_fountain = self.y_fountain_spin.value()

        # Extract chord parameters from dynamically created widgets
        chord_params = {}
        for i in range(self.chord_params_layout.rowCount()):
            label_item = self.chord_params_layout.itemAt(
                i, QtWidgets.QFormLayout.LabelRole
            )
            field_item = self.chord_params_layout.itemAt(
                i, QtWidgets.QFormLayout.FieldRole
            )
            if label_item and field_item:
                label = label_item.widget()
                field = field_item.widget()
                if isinstance(label, QtWidgets.QLabel) and isinstance(
                    field, QtWidgets.QDoubleSpinBox
                ):
                    param_name = label.text().rstrip(":")
                    # Map GUI label to parameter name
                    if "Ratio (r)" in param_name:
                        chord_params["r"] = field.value()
                    elif "r_ob" in param_name:
                        chord_params["r_ob"] = field.value()
                    elif "r_ib" in param_name:
                        chord_params["r_ib"] = field.value()
                    elif "X Refinement" in param_name:
                        chord_params["x_refinement"] = field.value()
                    elif "LE Fix Ratio" in param_name:
                        chord_params["r_le_fix"] = field.value()
                    elif "TE Fix Ratio" in param_name:
                        chord_params["r_te_fix"] = field.value()
                    elif "LE Moving Ratio" in param_name:
                        chord_params["r_le_moving"] = field.value()
                    elif "TE Moving Ratio" in param_name:
                        chord_params["r_te_moving"] = field.value()

        # Store chord parameters in config
        if not hasattr(comp.config, "chord_params"):
            comp.config.chord_params = {}
        comp.config.chord_params = chord_params

        # Symmetry
        if self.symmetry_enable.isChecked():
            comp.config.mesh_symmetry = True
            comp.config.symmetry_point = [
                self.symmetry_point_x.value(),
                self.symmetry_point_y.value(),
                self.symmetry_point_z.value(),
            ]
            comp.config.symmetry_normal = [
                self.symmetry_normal_x.value(),
                self.symmetry_normal_y.value(),
                self.symmetry_normal_z.value(),
            ]

        # Mirror
        if self.mirror_enable.isChecked():
            comp.config.mesh_mirror = True
            comp.config.mirror_point = [
                self.mirror_point_x.value(),
                self.mirror_point_y.value(),
                self.mirror_point_z.value(),
            ]
            comp.config.mirror_normal = [
                self.mirror_normal_x.value(),
                self.mirror_normal_y.value(),
                self.mirror_normal_z.value(),
            ]

        # Note: Do NOT call _update_3d_preview() here
        # It will be called by the function that called _extract_config_from_gui()
        self.statusBar().showMessage(
            f"Configuration updated - nelem_chord: {comp.config.nelem_chord}", 2000
        )

    def _on_geometry_changed(self):
        """Handle geometry table changes with state-aware management."""
        # Skip if we're loading data
        if self._update_state == "LOADING":
            return

        # If we're already processing or updating, mark as pending
        if self._update_state in ["PROCESSING_GEOMETRY", "UPDATING_PREVIEW"]:
            self._pending_geometry_update = True
            return

        # Mark that we have pending geometry changes and start debounce timer
        self._pending_geometry_update = True
        self._geometry_update_timer.stop()
        self._geometry_update_timer.start()

    def _process_pending_updates(self):
        """Process all pending updates in correct order with state machine."""
        # Don't start new processing if we're not in IDLE state
        if self._update_state != "IDLE":
            return

        # Transition to PROCESSING_GEOMETRY state
        self._set_update_state("PROCESSING_GEOMETRY")

        try:
            comp = self.current_component

            # Process config updates first (they affect geometry parsing)
            if self._pending_config_update:
                self._extract_config_from_gui()
                self._pending_config_update = False

            # Process geometry updates
            if self._pending_geometry_update:
                self._parse_geometry_data()
                self._pending_geometry_update = False

                # Update 3D preview (it will manage its own state transition)
                self._update_3d_preview()

            self.statusBar().showMessage(
                f"✓ Geometry updated: {self.current_component_name}", 2000
            )

        except (ValueError, AttributeError) as e:
            self.statusBar().showMessage(f"✗ Invalid data: {e}", 5000)
        except Exception as e:
            self.statusBar().showMessage(f"✗ Unexpected error: {e}", 5000)
            import traceback

            traceback.print_exc()
        finally:
            # Always return to IDLE state
            self._set_update_state("IDLE")

            # Check if more updates accumulated while we were processing
            if self._pending_geometry_update or self._pending_config_update:
                self._geometry_update_timer.start()

    def _parse_geometry_data(self):
        """Extract geometry data from tables (separated from update logic)."""
        comp = self.current_component

        if comp.mesh_type == "parametric":
            # Parse sections
            sections = []
            for row in range(self.sections_table.rowCount()):
                items = [self.sections_table.item(row, i) for i in range(4)]
                if not all(items):
                    continue

                sections.append(
                    build_mesh.ParametricMesh.Section(
                        chord=float(items[0].text()),
                        twist=float(items[1].text()),
                        airfoil=items[2].text(),
                        airfoil_table=items[3].text(),
                    )
                )

            # Parse regions
            regions = []
            for row in range(self.regions_table.rowCount()):
                # Get text items (columns 0-3, 5-7)
                span_item = self.regions_table.item(row, 0)
                sweep_item = self.regions_table.item(row, 1)
                dihed_item = self.regions_table.item(row, 2)
                nelem_item = self.regions_table.item(row, 3)
                y_ref_item = self.regions_table.item(row, 5)
                r_ob_item = self.regions_table.item(row, 6)
                r_ib_item = self.regions_table.item(row, 7)

                # Get combobox for type_span (column 4)
                type_combo = self.regions_table.cellWidget(row, 4)

                if not all(
                    [
                        span_item,
                        sweep_item,
                        dihed_item,
                        nelem_item,
                        y_ref_item,
                        type_combo,
                    ]
                ):
                    continue

                type_span = type_combo.currentText()
                region_dict = {
                    "span": float(span_item.text()),
                    "sweep": float(sweep_item.text()),
                    "dihed": float(dihed_item.text()),
                    "nelem_span": int(nelem_item.text()),
                    "type_span": type_span,
                    "y_refinement": float(y_ref_item.text()),
                }

                # Add r_ob and r_ib for geoseries types
                if type_span == "geoseries":
                    if r_ob_item and r_ib_item:
                        region_dict["r_ob"] = float(r_ob_item.text())
                        region_dict["r_ib"] = float(r_ib_item.text())
                elif type_span == "geoseries_ob":
                    if r_ob_item:
                        region_dict["r_ob"] = float(r_ob_item.text())
                elif type_span == "geoseries_ib":
                    if r_ib_item:
                        region_dict["r_ib"] = float(r_ib_item.text())

                regions.append(build_mesh.ParametricMesh.Region(**region_dict))

            # Validate
            if len(sections) != len(regions) + 1:
                self.statusBar().showMessage(
                    f"⚠ Need {len(regions) + 1} sections for {len(regions)} regions",
                    5000,
                )
                return

            comp.sections = sections
            comp.regions = regions

        elif comp.mesh_type == "pointwise":
            # Parse points from table
            points = []
            for row in range(self.points_table.rowCount()):
                items = [
                    self.points_table.item(row, i) for i in range(8)
                ]  # Include airfoil_table column
                if not all(items[:7]):  # First 7 columns are required
                    continue

                point_dict = {
                    "id": int(items[0].text()),
                    "x": float(items[1].text()),
                    "y": float(items[2].text()),
                    "z": float(items[3].text()),
                    "chord": float(items[4].text()),
                    "twist": float(items[5].text()),
                    "airfoil": items[6].text(),
                }

                # Add airfoil_table if present
                if items[7]:
                    point_dict["airfoil_table"] = items[7].text()

                points.append(point_dict)

            # Validate for duplicate point IDs
            seen_ids = set()
            for point in points:
                point_id = point["id"]
                if point_id in seen_ids:
                    self.statusBar().showMessage(
                        f"⚠ Duplicate point ID {point_id} detected! Each point must have a unique ID.",
                        5000,
                    )
                    return
                seen_ids.add(point_id)

            # Parse lines from table
            lines = []
            for row in range(self.lines_table.rowCount()):
                # Get type from combobox (column 0)
                type_combo = self.lines_table.cellWidget(row, 0)
                # Get span_type from combobox (column 4)
                span_type_combo = self.lines_table.cellWidget(row, 4)
                # Get text items
                point1_item = self.lines_table.item(row, 1)
                point2_item = self.lines_table.item(row, 2)
                n_elem_item = self.lines_table.item(row, 3)
                y_ref_item = self.lines_table.item(row, 5)
                r_ob_item = self.lines_table.item(row, 6)
                r_ib_item = self.lines_table.item(row, 7)

                if (
                    not type_combo
                    or not span_type_combo
                    or not all([point1_item, point2_item, n_elem_item])
                ):
                    continue

                span_type = span_type_combo.currentText()
                line_dict = {
                    "type": type_combo.currentText(),  # 'straight' or 'spline'
                    "start_point": int(point1_item.text()) - 1,  # Convert to 0-indexed
                    "end_point": int(point2_item.text()) - 1,  # Convert to 0-indexed
                    "n_elem": int(n_elem_item.text()),
                    "span_type": span_type,
                }

                # Add span parameters for geoseries types
                if span_type in ["geoseries", "geoseries_ib", "geoseries_ob"]:
                    if y_ref_item:
                        line_dict["y_ref"] = float(y_ref_item.text())

                    if span_type in ["geoseries", "geoseries_ob"] and r_ob_item:
                        line_dict["r_ob"] = float(r_ob_item.text())

                    if span_type in ["geoseries", "geoseries_ib"] and r_ib_item:
                        line_dict["r_ib"] = float(r_ib_item.text())

                lines.append(line_dict)

            comp.points = points
            comp.lines = lines

    def _on_section_selection_changed(self):
        """Handle section table selection changes - trigger update when focus leaves."""
        # This will catch when user finishes editing and clicks away
        self._on_geometry_changed()

    def _on_section_cell_clicked(self, row, column):
        """Handle clicks on section table cells - open airfoil table dialog for column 3."""
        # Column 3 is the "Airfoil Table" column
        if column == 3:
            # Check if airfoil table is needed
            if self._is_airfoil_table_needed():
                # Get the airfoil name from column 2
                airfoil_item = self.sections_table.item(row, 2)
                if airfoil_item:
                    airfoil_name = airfoil_item.text()

                    # Open the airfoil table dialog
                    dialog = AirfoilTableDialog(airfoil_name, self)
                    if dialog.exec_() == QtWidgets.QDialog.Accepted:
                        c81_path = dialog.get_c81_path()
                        if c81_path:
                            # Update the cell with the file path
                            self.sections_table.setItem(
                                row, column, QtWidgets.QTableWidgetItem(c81_path)
                            )
                            self._on_geometry_changed()

    def _is_airfoil_table_needed(self):
        """Check if airfoil table is needed based on element type or correction setting."""
        comp = self.components.get(self.current_component_name)
        if not comp:
            return False

        # Airfoil table is needed if:
        # 1. Element type is 'l' (Lifting-Line)
        # 2. Airfoil table correction is enabled
        return comp.config.el_type == "l" or comp.config.airfoil_table_correction

    def _clear_table_completely(self, table):
        """Completely clear table with aggressive memory cleanup to prevent leaks."""
        # Block signals during cleanup to prevent spurious events
        table.blockSignals(True)

        try:
            # First pass: Manually disconnect and delete all cell widgets
            for row in range(table.rowCount()):
                for col in range(table.columnCount()):
                    widget = table.cellWidget(row, col)
                    if widget:
                        # Try to disconnect all signals from this widget
                        # This prevents dangling signal connections
                        try:
                            widget.disconnect()
                        except (TypeError, RuntimeError):
                            # Widget may not have any connections or already deleted
                            pass

                        # Remove from table first
                        table.setCellWidget(row, col, None)

                        # Schedule for deletion on next event loop
                        widget.deleteLater()

            # Second pass: Clear all items (non-widget cells)
            table.clearContents()

            # Remove all rows
            table.setRowCount(0)

            # Optional: Force Python garbage collection
            # Note: Qt's deleteLater() will handle C++ objects on next event loop
            import gc

            gc.collect()

        finally:
            # Always re-enable signals
            table.blockSignals(False)

    def _safe_clear_table(self, table):
        """Alternative aggressive cleanup method for stubborn memory leaks."""
        # Store table structure before clearing
        column_count = table.columnCount()
        headers = []
        for col in range(column_count):
            item = table.horizontalHeaderItem(col)
            if item:
                headers.append(item.text())

        # Block signals
        table.blockSignals(True)

        try:
            # Nuclear option: Remove all rows (deletes items and widgets)
            table.setRowCount(0)

            # Clear any remaining content
            table.clear()

            # Recreate table structure if needed
            if column_count > 0:
                table.setColumnCount(column_count)

                # Restore headers if they were set
                for col, header_text in enumerate(headers):
                    table.setHorizontalHeaderItem(
                        col, QtWidgets.QTableWidgetItem(header_text)
                    )

            # Force garbage collection
            import gc

            gc.collect()

        finally:
            table.blockSignals(False)

    def _on_section_cell_changed(self, row, col):
        """Handle section table cell changes - triggers on any cell edit."""
        self._on_geometry_changed()

    def _on_point_cell_clicked(self, row, column):
        """Handle clicks on point table cells - open airfoil table dialog for column 7."""
        # Column 7 is the "Airfoil Table" column
        if column == 7:
            # Check if airfoil table is needed
            if self._is_airfoil_table_needed():
                # Get the airfoil name from column 6
                airfoil_item = self.points_table.item(row, 6)
                if airfoil_item:
                    airfoil_name = airfoil_item.text()

                    # Open the airfoil table dialog
                    dialog = AirfoilTableDialog(airfoil_name, self)
                    if dialog.exec_() == QtWidgets.QDialog.Accepted:
                        c81_path = dialog.get_c81_path()
                        if c81_path:
                            # Update the cell with the file path
                            self.points_table.setItem(
                                row, column, QtWidgets.QTableWidgetItem(c81_path)
                            )
                            self._on_geometry_changed()

    def _on_tab_changed(self, index):
        """Handle component tab change."""
        if index >= 0:
            self.current_component_name = self.component_tabs.tabText(index)
            self._load_component_data()
            self._update_3d_preview()

    def _add_new_component(self):
        """Add a new component tab."""
        # Find unique component name
        i = len(self.components) + 1
        while f"Component_{i}" in self.components:
            i += 1

        new_name = f"Component_{i}"
        self.components[new_name] = ComponentData(new_name)
        self._add_component_tab(new_name)
        self.current_component_name = new_name
        self._load_component_data()

        self.statusBar().showMessage(f"Added {new_name}", 2000)

    def _close_component_tab(self, index):
        """Close a component tab."""
        if len(self.components) == 1:
            QtWidgets.QMessageBox.warning(
                self, "Cannot Close", "Cannot close the last component."
            )
            return

        component_name = self.component_tabs.tabText(index)

        reply = QtWidgets.QMessageBox.question(
            self,
            "Close Component",
            f"Close component '{component_name}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )

        if reply == QtWidgets.QMessageBox.Yes:
            del self.components[component_name]
            self.component_tabs.removeTab(index)
            self.statusBar().showMessage(f"Closed {component_name}", 2000)

    def _load_component_data(self):
        """Load current component data into UI widgets with state management."""
        self._set_update_state("LOADING")

        try:
            comp = self.current_component

            # Block signals on widgets that could trigger geometry updates
            self.mesh_type_combo.blockSignals(True)

            # Update basic config
            self.title_input.setText(comp.config.title)
            el_type_index = ["v", "l", "p"].index(comp.config.el_type)
            self.el_type_combo.setCurrentIndex(el_type_index)
            self.nelem_chord_spin.setValue(comp.config.nelem_chord)
            self.type_chord_combo.setCurrentText(comp.config.type_chord)
            self.ref_chord_spin.setValue(comp.config.reference_chord_fraction)

            # Load starting point
            self.starting_point_x.setValue(comp.config.starting_point[0])
            self.starting_point_y.setValue(comp.config.starting_point[1])
            self.starting_point_z.setValue(comp.config.starting_point[2])

            # Update advanced options
            self.airfoil_table_correction.setChecked(
                comp.config.airfoil_table_correction
            )
            self.y_fountain_spin.setValue(comp.config.y_fountain)

            # Symmetry
            self.symmetry_enable.setChecked(comp.config.mesh_symmetry)
            if comp.config.mesh_symmetry:
                self.symmetry_point_x.setValue(comp.config.symmetry_point[0])
                self.symmetry_point_y.setValue(comp.config.symmetry_point[1])
                self.symmetry_point_z.setValue(comp.config.symmetry_point[2])
                self.symmetry_normal_x.setValue(comp.config.symmetry_normal[0])
                self.symmetry_normal_y.setValue(comp.config.symmetry_normal[1])
                self.symmetry_normal_z.setValue(comp.config.symmetry_normal[2])

            # Mirror
            self.mirror_enable.setChecked(comp.config.mesh_mirror)
            if comp.config.mesh_mirror:
                self.mirror_point_x.setValue(comp.config.mirror_point[0])
                self.mirror_point_y.setValue(comp.config.mirror_point[1])
                self.mirror_point_z.setValue(comp.config.mirror_point[2])
                self.mirror_normal_x.setValue(comp.config.mirror_normal[0])
                self.mirror_normal_y.setValue(comp.config.mirror_normal[1])
                self.mirror_normal_z.setValue(comp.config.mirror_normal[2])

            # Update mesh type selector
            mesh_type_index = 0 if comp.mesh_type == "parametric" else 1
            self.mesh_type_combo.setCurrentIndex(mesh_type_index)

            # Load geometry data
            if comp.mesh_type == "parametric":
                self._load_parametric_data()
            else:
                self._load_pointwise_data()

        finally:
            # Always restore signal handling
            self.mesh_type_combo.blockSignals(False)
            self._set_update_state("IDLE")

    def _load_parametric_data(self):
        """Load parametric data with memory-safe table management."""
        comp = self.current_component

        # Use blockSignals to prevent signal firing during data loading
        self.sections_table.blockSignals(True)
        self.regions_table.blockSignals(True)

        try:
            # Use table managers for safe clearing with automatic cleanup
            self.sections_table_manager.clear_table()
            self.regions_table_manager.clear_table()

            # Load sections (simpler - no widgets)
            for section in comp.sections:
                row = self.sections_table.rowCount()
                self.sections_table.insertRow(row)

                # Create items
                chord_item = QtWidgets.QTableWidgetItem(str(section.chord))
                twist_item = QtWidgets.QTableWidgetItem(str(section.twist))
                airfoil_item = QtWidgets.QTableWidgetItem(section.airfoil)

                # Airfoil table cell with conditional formatting
                airfoil_table_item = QtWidgets.QTableWidgetItem(section.airfoil_table)
                if self._is_airfoil_table_needed():
                    airfoil_table_item.setFlags(
                        airfoil_table_item.flags() & ~QtCore.Qt.ItemIsEditable
                    )
                    airfoil_table_item.setToolTip(
                        "Click to select or generate C81 table"
                    )
                    airfoil_table_item.setBackground(QtCore.Qt.lightGray)
                else:
                    airfoil_table_item.setFlags(QtCore.Qt.ItemIsEnabled)
                    airfoil_table_item.setToolTip(
                        "Airfoil table not needed for current configuration"
                    )

                # Set items
                self.sections_table.setItem(row, 0, chord_item)
                self.sections_table.setItem(row, 1, twist_item)
                self.sections_table.setItem(row, 2, airfoil_item)
                self.sections_table.setItem(row, 3, airfoil_table_item)

            # Load regions (with managed widget creation)
            for region in comp.regions:
                row = self.regions_table.rowCount()
                self.regions_table.insertRow(row)

                # Text items
                self.regions_table.setItem(
                    row, 0, QtWidgets.QTableWidgetItem(str(region.span))
                )
                self.regions_table.setItem(
                    row, 1, QtWidgets.QTableWidgetItem(str(region.sweep))
                )
                self.regions_table.setItem(
                    row, 2, QtWidgets.QTableWidgetItem(str(region.dihed))
                )
                self.regions_table.setItem(
                    row, 3, QtWidgets.QTableWidgetItem(str(region.nelem_span))
                )

                # Combo box for span type - managed by TableManager
                type_combo = self.regions_table_manager.create_cell_widget(
                    row,
                    4,
                    "combo",
                    items=[
                        "uniform",
                        "cosine",
                        "geoseries",
                        "geoseries_ob",
                        "geoseries_ib",
                    ],
                    current_text=region.type_span,
                )

                # Use row-aware callback to handle dynamic row indices
                row_callback = self.regions_table_manager.create_row_callback(
                    type_combo, 4, lambda r, text: self._on_region_type_changed(r)
                )
                self.regions_table_manager.connect_widget(
                    type_combo, "currentTextChanged", row_callback
                )

                # Y refinement
                self.regions_table.setItem(
                    row, 5, QtWidgets.QTableWidgetItem(str(region.y_refinement))
                )

                # Add r_ob and r_ib with default values
                r_ob = getattr(region, "r_ob", 0.1)
                r_ib = getattr(region, "r_ib", 0.1)
                self.regions_table.setItem(
                    row, 6, QtWidgets.QTableWidgetItem(str(r_ob))
                )
                self.regions_table.setItem(
                    row, 7, QtWidgets.QTableWidgetItem(str(r_ib))
                )

                # Update visibility based on type
                self._update_region_row_visibility(row, region.type_span)

        finally:
            # Always re-enable signals
            self.sections_table.blockSignals(False)
            self.regions_table.blockSignals(False)

    def _load_pointwise_data(self):
        """Load pointwise data with memory-safe table management."""
        comp = self.current_component

        # Use blockSignals to prevent signal firing during data loading
        self.points_table.blockSignals(True)
        self.lines_table.blockSignals(True)

        try:
            # Use table managers for safe clearing with automatic cleanup
            self.points_table_manager.clear_table()
            self.lines_table_manager.clear_table()

            # Load points (simpler - no widgets)
            for point in comp.points:
                row = self.points_table.rowCount()
                self.points_table.insertRow(row)

                # Create items
                id_item = QtWidgets.QTableWidgetItem(str(row + 1))  # ID
                x_item = QtWidgets.QTableWidgetItem(str(point["x"]))
                y_item = QtWidgets.QTableWidgetItem(str(point["y"]))
                z_item = QtWidgets.QTableWidgetItem(str(point["z"]))
                chord_item = QtWidgets.QTableWidgetItem(str(point.get("chord", 1.0)))
                twist_item = QtWidgets.QTableWidgetItem(str(point.get("twist", 0.0)))
                airfoil_item = QtWidgets.QTableWidgetItem(
                    point.get("airfoil", "naca0012")
                )

                # Airfoil table cell with conditional formatting
                airfoil_table_item = QtWidgets.QTableWidgetItem(
                    point.get("airfoil_table", "")
                )
                if self._is_airfoil_table_needed():
                    airfoil_table_item.setFlags(
                        airfoil_table_item.flags() & ~QtCore.Qt.ItemIsEditable
                    )
                    airfoil_table_item.setToolTip(
                        "Click to select or generate C81 table"
                    )
                    airfoil_table_item.setBackground(QtCore.Qt.lightGray)
                else:
                    airfoil_table_item.setFlags(QtCore.Qt.ItemIsEnabled)
                    airfoil_table_item.setToolTip(
                        "Airfoil table not needed for current configuration"
                    )

                # Set items
                self.points_table.setItem(row, 0, id_item)
                self.points_table.setItem(row, 1, x_item)
                self.points_table.setItem(row, 2, y_item)
                self.points_table.setItem(row, 3, z_item)
                self.points_table.setItem(row, 4, chord_item)
                self.points_table.setItem(row, 5, twist_item)
                self.points_table.setItem(row, 6, airfoil_item)
                self.points_table.setItem(row, 7, airfoil_table_item)

            # Load lines (with managed widget creation)
            for line in comp.lines:
                row = self.lines_table.rowCount()
                self.lines_table.insertRow(row)

                # Line type dropdown - managed by TableManager
                type_combo = self.lines_table_manager.create_cell_widget(
                    row,
                    0,
                    "combo",
                    items=["straight", "spline"],
                    current_text=line.get("type", "straight"),
                )
                self.lines_table_manager.connect_widget(
                    type_combo, "currentTextChanged", self._on_geometry_changed
                )

                # Point IDs and N Elem
                self.lines_table.setItem(
                    row, 1, QtWidgets.QTableWidgetItem(str(line.get("start_point", 1)))
                )
                self.lines_table.setItem(
                    row, 2, QtWidgets.QTableWidgetItem(str(line.get("end_point", 2)))
                )
                self.lines_table.setItem(
                    row, 3, QtWidgets.QTableWidgetItem(str(line.get("n_elem", 10)))
                )

                # Span type dropdown - managed by TableManager
                span_type_combo = self.lines_table_manager.create_cell_widget(
                    row,
                    4,
                    "combo",
                    items=["uniform", "geoseries", "geoseries_ib", "geoseries_ob"],
                    current_text=line.get("span_type", "uniform"),
                )

                # Use row-aware callback to handle dynamic row indices
                row_callback = self.lines_table_manager.create_row_callback(
                    span_type_combo,
                    4,
                    lambda r, text: self._on_line_span_type_changed(r),
                )
                self.lines_table_manager.connect_widget(
                    span_type_combo, "currentTextChanged", row_callback
                )

                # Span parameters
                self.lines_table.setItem(
                    row, 5, QtWidgets.QTableWidgetItem(str(line.get("y_ref", 0.5)))
                )
                self.lines_table.setItem(
                    row, 6, QtWidgets.QTableWidgetItem(str(line.get("r_ob", 0.1)))
                )
                self.lines_table.setItem(
                    row, 7, QtWidgets.QTableWidgetItem(str(line.get("r_ib", 0.1)))
                )

                # Update visibility based on type
                span_type = line.get("span_type", "uniform")
                self._update_line_row_visibility(row, span_type)

        finally:
            # Always re-enable signals
            self.points_table.blockSignals(False)
            self.lines_table.blockSignals(False)

    # Table manipulation methods

    def _add_section_row(self):
        """Add a new section row and corresponding region to maintain n_sections = n_regions + 1."""
        # Block signals to prevent multiple updates
        self.sections_table.blockSignals(True)
        self.regions_table.blockSignals(True)
        try:
            # Add section at the bottom
            section_row = self.sections_table.rowCount()
            self.sections_table.insertRow(section_row)
            self.sections_table.setItem(
                section_row, 0, QtWidgets.QTableWidgetItem("1.0")
            )
            self.sections_table.setItem(
                section_row, 1, QtWidgets.QTableWidgetItem("0.0")
            )
            self.sections_table.setItem(
                section_row, 2, QtWidgets.QTableWidgetItem("naca0012")
            )

            # Airfoil table cell
            airfoil_table_item = QtWidgets.QTableWidgetItem("")
            if self._is_airfoil_table_needed():
                airfoil_table_item.setFlags(
                    airfoil_table_item.flags() & ~QtCore.Qt.ItemIsEditable
                )
                airfoil_table_item.setToolTip("Click to select or generate C81 table")
                airfoil_table_item.setBackground(QtCore.Qt.lightGray)
            else:
                airfoil_table_item.setFlags(QtCore.Qt.ItemIsEnabled)
                airfoil_table_item.setToolTip(
                    "Airfoil table not needed for current configuration"
                )
            self.sections_table.setItem(section_row, 3, airfoil_table_item)

            # Add corresponding region at the bottom (maintains n_sections = n_regions + 1)
            region_row = self.regions_table.rowCount()
            self.regions_table.insertRow(region_row)
            self.regions_table.setItem(region_row, 0, QtWidgets.QTableWidgetItem("5.0"))
            self.regions_table.setItem(region_row, 1, QtWidgets.QTableWidgetItem("0.0"))
            self.regions_table.setItem(region_row, 2, QtWidgets.QTableWidgetItem("0.0"))
            self.regions_table.setItem(region_row, 3, QtWidgets.QTableWidgetItem("10"))

            # Use TableManager for span type combo - ensures proper tracking
            type_combo = self.regions_table_manager.create_cell_widget(
                region_row,
                4,
                "combo",
                items=[
                    "uniform",
                    "cosine",
                    "geoseries",
                    "geoseries_ob",
                    "geoseries_ib",
                ],
                current_text="uniform",
            )

            # Use row-aware callback to handle dynamic row indices
            row_callback = self.regions_table_manager.create_row_callback(
                type_combo, 4, lambda r, text: self._on_region_type_changed(r)
            )
            self.regions_table_manager.connect_widget(
                type_combo, "currentTextChanged", row_callback
            )

            self.regions_table.setItem(region_row, 5, QtWidgets.QTableWidgetItem("0.5"))
            self.regions_table.setItem(region_row, 6, QtWidgets.QTableWidgetItem("0.1"))
            self.regions_table.setItem(region_row, 7, QtWidgets.QTableWidgetItem("0.1"))

            # Update visibility based on type
            self._update_region_row_visibility(region_row, "uniform")

        finally:
            self.sections_table.blockSignals(False)
            self.regions_table.blockSignals(False)

        # Show message
        n_sections = self.sections_table.rowCount()
        n_regions = self.regions_table.rowCount()
        self.statusBar().showMessage(
            f"✓ Added section and region. Sections: {n_sections}, Regions: {n_regions}",
            3000,
        )

        # Now trigger one geometry update
        self._on_geometry_changed()

    def _remove_section_row(self):
        """Remove selected section (or last if none selected) and corresponding region to maintain n_sections = n_regions + 1."""
        # Minimum: need at least 2 sections and 1 region
        if self.sections_table.rowCount() <= 2:
            self.statusBar().showMessage(
                "⚠ Cannot remove - need at least 2 sections", 3000
            )
            return

        # Get selected row, or use last row if nothing selected
        current_row = self.sections_table.currentRow()
        if current_row < 0:
            current_row = self.sections_table.rowCount() - 1

        # Block signals to prevent multiple updates
        self.sections_table.blockSignals(True)
        self.regions_table.blockSignals(True)
        try:
            # Clean up widgets in the region row BEFORE removing it
            if self.regions_table.rowCount() > 0:
                last_region = self.regions_table.rowCount() - 1
                for col in range(self.regions_table.columnCount()):
                    widget = self.regions_table.cellWidget(last_region, col)
                    if widget:
                        self.regions_table_manager._remove_widget(widget)

            # Remove the section (no widgets in sections table)
            self.sections_table.removeRow(current_row)

            # Remove last region to maintain n_sections = n_regions + 1
            if self.regions_table.rowCount() > 0:
                last_region = self.regions_table.rowCount() - 1
                self.regions_table.removeRow(last_region)

        finally:
            self.sections_table.blockSignals(False)
            self.regions_table.blockSignals(False)

        # Show message
        n_sections = self.sections_table.rowCount()
        n_regions = self.regions_table.rowCount()
        self.statusBar().showMessage(
            f"✓ Removed section and region. Sections: {n_sections}, Regions: {n_regions}",
            3000,
        )

        # Trigger one geometry update
        self._on_geometry_changed()

    def _add_region_row(self):
        """Add a new region row and corresponding section to maintain n_sections = n_regions + 1."""
        # Block signals while adding the rows to prevent multiple geometry updates
        self.regions_table.blockSignals(True)
        self.sections_table.blockSignals(True)
        try:
            # Add region at the bottom
            region_row = self.regions_table.rowCount()
            self.regions_table.insertRow(region_row)
            self.regions_table.setItem(region_row, 0, QtWidgets.QTableWidgetItem("5.0"))
            self.regions_table.setItem(region_row, 1, QtWidgets.QTableWidgetItem("0.0"))
            self.regions_table.setItem(region_row, 2, QtWidgets.QTableWidgetItem("0.0"))
            self.regions_table.setItem(region_row, 3, QtWidgets.QTableWidgetItem("10"))

            # Use TableManager for span type combo - ensures proper tracking
            type_combo = self.regions_table_manager.create_cell_widget(
                region_row,
                4,
                "combo",
                items=[
                    "uniform",
                    "cosine",
                    "geoseries",
                    "geoseries_ob",
                    "geoseries_ib",
                ],
                current_text="uniform",
            )

            # Use row-aware callback to handle dynamic row indices
            row_callback = self.regions_table_manager.create_row_callback(
                type_combo, 4, lambda r, text: self._on_region_type_changed(r)
            )
            self.regions_table_manager.connect_widget(
                type_combo, "currentTextChanged", row_callback
            )

            self.regions_table.setItem(region_row, 5, QtWidgets.QTableWidgetItem("0.5"))
            self.regions_table.setItem(region_row, 6, QtWidgets.QTableWidgetItem("0.1"))
            self.regions_table.setItem(region_row, 7, QtWidgets.QTableWidgetItem("0.1"))

            # Update visibility based on type
            self._update_region_row_visibility(region_row, "uniform")

            # Add corresponding section at the bottom (maintains n_sections = n_regions + 1)
            section_row = self.sections_table.rowCount()
            self.sections_table.insertRow(section_row)
            self.sections_table.setItem(
                section_row, 0, QtWidgets.QTableWidgetItem("1.0")
            )
            self.sections_table.setItem(
                section_row, 1, QtWidgets.QTableWidgetItem("0.0")
            )
            self.sections_table.setItem(
                section_row, 2, QtWidgets.QTableWidgetItem("naca0012")
            )

            # Airfoil table cell
            airfoil_table_item = QtWidgets.QTableWidgetItem("")
            if self._is_airfoil_table_needed():
                airfoil_table_item.setFlags(
                    airfoil_table_item.flags() & ~QtCore.Qt.ItemIsEditable
                )
                airfoil_table_item.setToolTip("Click to select or generate C81 table")
                airfoil_table_item.setBackground(QtCore.Qt.lightGray)
            else:
                airfoil_table_item.setFlags(QtCore.Qt.ItemIsEnabled)
                airfoil_table_item.setToolTip(
                    "Airfoil table not needed for current configuration"
                )
            self.sections_table.setItem(section_row, 3, airfoil_table_item)

        finally:
            self.regions_table.blockSignals(False)
            self.sections_table.blockSignals(False)

        # Show message
        n_sections = self.sections_table.rowCount()
        n_regions = self.regions_table.rowCount()
        self.statusBar().showMessage(
            f"✓ Added region and section. Sections: {n_sections}, Regions: {n_regions}",
            3000,
        )

        # Now trigger one geometry update
        self._on_geometry_changed()

    def _remove_region_row(self):
        """Remove selected region (or last if none selected) and corresponding section to maintain n_sections = n_regions + 1."""
        # Minimum: need at least 1 region and 2 sections
        if self.regions_table.rowCount() <= 1:
            self.statusBar().showMessage(
                "⚠ Cannot remove - need at least 1 region", 3000
            )
            return

        # Get selected row, or use last row if nothing selected
        current_row = self.regions_table.currentRow()
        if current_row < 0:
            current_row = self.regions_table.rowCount() - 1

        # Block signals to prevent multiple updates
        self.regions_table.blockSignals(True)
        self.sections_table.blockSignals(True)
        try:
            # Clean up widgets in the region row BEFORE removing it
            for col in range(self.regions_table.columnCount()):
                widget = self.regions_table.cellWidget(current_row, col)
                if widget:
                    self.regions_table_manager._remove_widget(widget)

            # Remove the region
            self.regions_table.removeRow(current_row)

            # Remove last section to maintain n_sections = n_regions + 1
            # (sections table has no widgets, so no cleanup needed)
            if self.sections_table.rowCount() > 0:
                last_section = self.sections_table.rowCount() - 1
                self.sections_table.removeRow(last_section)

        finally:
            self.regions_table.blockSignals(False)
            self.sections_table.blockSignals(False)

        # Show message
        n_sections = self.sections_table.rowCount()
        n_regions = self.regions_table.rowCount()
        self.statusBar().showMessage(
            f"✓ Removed region and section. Sections: {n_sections}, Regions: {n_regions}",
            3000,
        )

        # Trigger one geometry update
        self._on_geometry_changed()

    def _add_point_row(self):
        """Add a new pointwise point row."""
        row = self.points_table.rowCount()
        point_id = row + 1
        self.points_table.insertRow(row)
        self.points_table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(point_id)))
        self.points_table.setItem(row, 1, QtWidgets.QTableWidgetItem("0.0"))
        self.points_table.setItem(row, 2, QtWidgets.QTableWidgetItem("0.0"))
        self.points_table.setItem(row, 3, QtWidgets.QTableWidgetItem("0.0"))
        self.points_table.setItem(row, 4, QtWidgets.QTableWidgetItem("1.0"))
        self.points_table.setItem(row, 5, QtWidgets.QTableWidgetItem("0.0"))
        self.points_table.setItem(row, 6, QtWidgets.QTableWidgetItem("naca0012"))

        # Airfoil Table column (7)
        airfoil_table_item = QtWidgets.QTableWidgetItem("")
        if self._is_airfoil_table_needed():
            airfoil_table_item.setFlags(
                airfoil_table_item.flags() & ~QtCore.Qt.ItemIsEditable
            )
            airfoil_table_item.setToolTip("Click to select or generate C81 table")
            airfoil_table_item.setBackground(QtCore.Qt.lightGray)
        else:
            airfoil_table_item.setFlags(QtCore.Qt.ItemIsEnabled)
            airfoil_table_item.setBackground(QtCore.Qt.white)
        self.points_table.setItem(row, 7, airfoil_table_item)

        self._on_geometry_changed()

    def _remove_point_row(self):
        """Remove selected point row."""
        current_row = self.points_table.currentRow()
        if current_row >= 0:
            self.points_table.removeRow(current_row)
            self._on_geometry_changed()

    def _add_line_row(self):
        """Add a new pointwise line row."""
        row = self.lines_table.rowCount()
        self.lines_table.insertRow(row)

        # Use TableManager for line type combo - ensures proper tracking
        type_combo = self.lines_table_manager.create_cell_widget(
            row, 0, "combo", items=["straight", "spline"], current_text="straight"
        )
        self.lines_table_manager.connect_widget(
            type_combo, "currentTextChanged", self._on_geometry_changed
        )

        # Set default values for point IDs and N Elem
        self.lines_table.setItem(row, 1, QtWidgets.QTableWidgetItem("1"))
        self.lines_table.setItem(row, 2, QtWidgets.QTableWidgetItem("2"))
        self.lines_table.setItem(row, 3, QtWidgets.QTableWidgetItem("10"))

        # Use TableManager for span type combo - ensures proper tracking
        span_type_combo = self.lines_table_manager.create_cell_widget(
            row,
            4,
            "combo",
            items=["uniform", "geoseries", "geoseries_ib", "geoseries_ob"],
            current_text="uniform",
        )

        # Use row-aware callback to handle dynamic row indices
        row_callback = self.lines_table_manager.create_row_callback(
            span_type_combo, 4, lambda r, text: self._on_line_span_type_changed(r)
        )
        self.lines_table_manager.connect_widget(
            span_type_combo, "currentTextChanged", row_callback
        )

        # Set default values for span parameters
        self.lines_table.setItem(row, 5, QtWidgets.QTableWidgetItem("0.5"))  # y_ref
        self.lines_table.setItem(row, 6, QtWidgets.QTableWidgetItem("0.1"))  # r_ob
        self.lines_table.setItem(row, 7, QtWidgets.QTableWidgetItem("0.1"))  # r_ib

        # Update visibility based on default span type
        self._update_line_row_visibility(row, "uniform")

        self._on_geometry_changed()

    def _on_line_span_type_changed(self, row):
        """Handle line span type change - show/hide relevant parameter columns."""
        # Skip if we're loading data
        if hasattr(self, "_loading_data") and self._loading_data:
            return

        type_combo = self.lines_table.cellWidget(row, 4)
        if type_combo:
            span_type = type_combo.currentText()
            self._update_line_row_visibility(row, span_type)

    def _update_line_row_visibility(self, row, span_type):
        """Update visibility of parameter columns based on span type for lines table."""
        # Column 5: y_ref (always visible for geoseries types)
        # Column 6: r_ob (visible for geoseries and geoseries_ob)
        # Column 7: r_ib (visible for geoseries and geoseries_ib)

        # Check if we're being called during data loading
        is_loading = hasattr(self, "_loading_data") and self._loading_data

        # Temporarily disconnect itemChanged signal to prevent multiple updates
        if not is_loading:
            try:
                self.lines_table.itemChanged.disconnect(self._on_geometry_changed)
            except Exception:
                pass

        # Hide all parameter columns by default
        for col in [5, 6, 7]:
            item = self.lines_table.item(row, col)
            if item:
                if span_type == "uniform":
                    # Hide all for uniform
                    item.setFlags(QtCore.Qt.NoItemFlags)
                    item.setBackground(QtCore.Qt.lightGray)
                    item.setForeground(QtCore.Qt.lightGray)
                else:
                    # Show for geoseries types
                    item.setFlags(
                        QtCore.Qt.ItemIsSelectable
                        | QtCore.Qt.ItemIsEditable
                        | QtCore.Qt.ItemIsEnabled
                    )
                    item.setBackground(QtCore.Qt.white)
                    item.setForeground(QtCore.Qt.black)

        # Show/hide based on span type
        if span_type in ["geoseries", "geoseries_ib", "geoseries_ob"]:
            # y_ref is always visible for geoseries types
            y_ref_item = self.lines_table.item(row, 5)
            if y_ref_item:
                y_ref_item.setFlags(
                    QtCore.Qt.ItemIsSelectable
                    | QtCore.Qt.ItemIsEditable
                    | QtCore.Qt.ItemIsEnabled
                )
                y_ref_item.setBackground(QtCore.Qt.white)
                y_ref_item.setForeground(QtCore.Qt.black)

            # r_ob visible for geoseries and geoseries_ob
            if span_type in ["geoseries", "geoseries_ob"]:
                r_ob_item = self.lines_table.item(row, 6)
                if r_ob_item:
                    r_ob_item.setFlags(
                        QtCore.Qt.ItemIsSelectable
                        | QtCore.Qt.ItemIsEditable
                        | QtCore.Qt.ItemIsEnabled
                    )
                    r_ob_item.setBackground(QtCore.Qt.white)
                    r_ob_item.setForeground(QtCore.Qt.black)

            # r_ib visible for geoseries and geoseries_ib
            if span_type in ["geoseries", "geoseries_ib"]:
                r_ib_item = self.lines_table.item(row, 7)
                if r_ib_item:
                    r_ib_item.setFlags(
                        QtCore.Qt.ItemIsSelectable
                        | QtCore.Qt.ItemIsEditable
                        | QtCore.Qt.ItemIsEnabled
                    )
                    r_ib_item.setBackground(QtCore.Qt.white)
                    r_ib_item.setForeground(QtCore.Qt.black)

        # Reconnect signal
        if not is_loading:
            self.lines_table.itemChanged.connect(self._on_geometry_changed)

        # Trigger geometry update
        if not is_loading:
            self._on_geometry_changed()

    def _remove_line_row(self):
        """Remove selected line row."""
        current_row = self.lines_table.currentRow()
        if current_row >= 0:
            # Clean up widgets in the line row BEFORE removing it
            for col in range(self.lines_table.columnCount()):
                widget = self.lines_table.cellWidget(current_row, col)
                if widget:
                    self.lines_table_manager._remove_widget(widget)

            self.lines_table.removeRow(current_row)
            self._on_geometry_changed()

    def _on_region_type_changed(self, row):
        """Handle region span type change - show/hide relevant parameter columns."""
        # Skip if we're loading data
        if hasattr(self, "_loading_data") and self._loading_data:
            return

        type_combo = self.regions_table.cellWidget(row, 4)
        if type_combo:
            span_type = type_combo.currentText()
            self._update_region_row_visibility(row, span_type)

    def _update_region_row_visibility(self, row, span_type):
        """Update visibility of parameter columns based on span type."""
        # Column 5: y_ref (always visible for geoseries types)
        # Column 6: r_ob (visible for geoseries and geoseries_ob)
        # Column 7: r_ib (visible for geoseries and geoseries_ib)

        # Check if we're being called during data loading
        is_loading = hasattr(self, "_loading_data") and self._loading_data

        # Temporarily disconnect itemChanged signal to prevent multiple updates
        if not is_loading:
            try:
                self.regions_table.itemChanged.disconnect(self._on_geometry_changed)
            except Exception:
                pass

        if span_type == "geoseries":
            # Show y_ref, r_ob, r_ib
            self._set_table_cell_editable(row, 5, True)
            self._set_table_cell_editable(row, 6, True)
            self._set_table_cell_editable(row, 7, True)
        elif span_type == "geoseries_ob":
            # Show y_ref and r_ob only
            self._set_table_cell_editable(row, 5, True)
            self._set_table_cell_editable(row, 6, True)
            self._set_table_cell_editable(row, 7, False)
        elif span_type == "geoseries_ib":
            # Show y_ref and r_ib only
            self._set_table_cell_editable(row, 5, True)
            self._set_table_cell_editable(row, 6, False)
            self._set_table_cell_editable(row, 7, True)
        else:
            # uniform, cosine: hide all extra parameters
            self._set_table_cell_editable(row, 5, False)
            self._set_table_cell_editable(row, 6, False)
            self._set_table_cell_editable(row, 7, False)

        # Reconnect signal and trigger update (only if not loading)
        if not is_loading:
            self.regions_table.itemChanged.connect(self._on_geometry_changed)
            # Trigger single update after all changes
            self._on_geometry_changed()

    def _set_table_cell_editable(self, row, col, editable):
        """Set table cell editable state and visual appearance."""
        item = self.regions_table.item(row, col)
        if item:
            if editable:
                item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
                item.setBackground(
                    QtCore.Qt.white if not self.dark_mode else QtCore.Qt.darkGray
                )
            else:
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)
                item.setBackground(
                    QtCore.Qt.lightGray if not self.dark_mode else QtCore.Qt.darkGray
                )

    def _toggle_dark_mode(self):
        """Toggle between light and dark mode."""
        self.dark_mode = not self.dark_mode

        if self.dark_mode:
            # Dark mode colors inspired by VSCode dark theme
            self._apply_dark_stylesheet()
            self.plotter.set_background("#1E1E1E")  # VSCode dark background
            self.dark_mode_action.setText("☀️ Light Mode")
        else:
            # Light mode - reset to default
            self.setStyleSheet("")
            self.plotter.set_background("white")
            self.dark_mode_action.setText("🌙 Dark Mode")

        # Update 3D preview to refresh axis colors
        self._update_3d_preview()

        self.statusBar().showMessage(
            f"{'Dark' if self.dark_mode else 'Light'} mode enabled", 2000
        )

    def _apply_dark_stylesheet(self):
        """Apply dark mode stylesheet inspired by VSCode."""
        dark_stylesheet = """
            QMainWindow, QWidget {
                background-color: #1E1E1E;
                color: #D4D4D4;
            }
            
            QTabWidget::pane {
                border: 1px solid #3C3C3C;
                background-color: #252526;
            }
            
            QTabBar::tab {
                background-color: #2D2D30;
                color: #D4D4D4;
                padding: 8px 16px;
                border: 1px solid #3C3C3C;
                border-bottom: none;
            }
            
            QTabBar::tab:selected {
                background-color: #1E1E1E;
                border-bottom: 2px solid #007ACC;
            }
            
            QTabBar::tab:hover {
                background-color: #37373D;
            }
            
            QGroupBox {
                border: 1px solid #3C3C3C;
                border-radius: 4px;
                margin-top: 8px;
                padding-top: 8px;
                color: #D4D4D4;
                font-weight: bold;
            }
            
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            
            QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
                background-color: #3C3C3C;
                border: 1px solid #5A5A5A;
                border-radius: 2px;
                padding: 4px;
                color: #D4D4D4;
            }
            
            QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
                border: 1px solid #007ACC;
            }
            
            QComboBox::drop-down {
                border: none;
            }
            
            QComboBox QAbstractItemView {
                background-color: #252526;
                color: #D4D4D4;
                selection-background-color: #094771;
            }
            
            QPushButton {
                background-color: #0E639C;
                color: #FFFFFF;
                border: none;
                border-radius: 2px;
                padding: 6px 16px;
            }
            
            QPushButton:hover {
                background-color: #1177BB;
            }
            
            QPushButton:pressed {
                background-color: #005A9E;
            }
            
            QPushButton:disabled {
                background-color: #3C3C3C;
                color: #7A7A7A;
            }
            
            QTableWidget {
                background-color: #252526;
                alternate-background-color: #2D2D30;
                gridline-color: #3C3C3C;
                color: #D4D4D4;
            }
            
            QHeaderView::section {
                background-color: #2D2D30;
                color: #D4D4D4;
                padding: 4px;
                border: 1px solid #3C3C3C;
            }
            
            QCheckBox {
                color: #D4D4D4;
            }
            
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                background-color: #3C3C3C;
                border: 1px solid #5A5A5A;
                border-radius: 2px;
            }
            
            QCheckBox::indicator:checked {
                background-color: #007ACC;
                border-color: #007ACC;
            }
            
            QLabel {
                color: #D4D4D4;
            }
            
            QToolBar {
                background-color: #2D2D30;
                border-bottom: 1px solid #3C3C3C;
                spacing: 3px;
            }
            
            QStatusBar {
                background-color: #007ACC;
                color: #FFFFFF;
            }
            
            QScrollBar:vertical {
                background-color: #1E1E1E;
                width: 14px;
                margin: 0;
            }
            
            QScrollBar::handle:vertical {
                background-color: #424242;
                border-radius: 7px;
                min-height: 20px;
            }
            
            QScrollBar::handle:vertical:hover {
                background-color: #4E4E4E;
            }
            
            QScrollBar:horizontal {
                background-color: #1E1E1E;
                height: 14px;
                margin: 0;
            }
            
            QScrollBar::handle:horizontal {
                background-color: #424242;
                border-radius: 7px;
                min-width: 20px;
            }
            
            QScrollBar::handle:horizontal:hover {
                background-color: #4E4E4E;
            }
            
            QScrollBar::add-line, QScrollBar::sub-line {
                border: none;
                background: none;
            }
        """
        self.setStyleSheet(dark_stylesheet)

    def _update_3d_preview(self):
        """Update 3D visualization with re-entry protection."""
        # Re-entry protection: if already updating preview, skip
        # This prevents recursive calls from rendering operations
        if self._update_state == "UPDATING_PREVIEW":
            return

        # Set state to UPDATING_PREVIEW
        self._set_update_state("UPDATING_PREVIEW")

        try:
            # Force complete clear of all actors
            self.plotter.clear()
            self.plotter.clear_actors()

            comp = self.current_component

            if comp.mesh_type == "parametric" and comp.sections and comp.regions:
                self._render_parametric_mesh()
            elif comp.mesh_type == "pointwise" and comp.points:
                self._render_pointwise_mesh()

            # Show view axes (orientation widget)
            self.plotter.show_axes()

            # Calculate appropriate axes size based on mesh dimensions
            axes_length = 1.0  # Default
            if comp.mesh_type == "parametric" and comp.sections:
                # Estimate mesh size from first section parameters
                try:
                    chord = float(comp.sections[0].chord)
                    span = sum(float(r.span) for r in comp.regions)
                    # Use 20% of the typical dimension as axes length
                    typical_size = max(chord, span)
                    axes_length = typical_size * 0.2
                except (ValueError, AttributeError, IndexError):
                    axes_length = 1.0
            elif comp.mesh_type == "pointwise" and comp.points:
                # Estimate mesh size from point cloud extent
                try:
                    points_array = np.array(
                        [[p["x"], p["y"], p["z"]] for p in comp.points]
                    )
                    pmin = points_array.min(axis=0)
                    pmax = points_array.max(axis=0)
                    extent = np.linalg.norm(pmax - pmin)
                    axes_length = extent * 0.2
                except (ValueError, KeyError, IndexError):
                    axes_length = 1.0

            # Add axes at origin with appropriate label size
            axes_actor = self.plotter.add_axes_at_origin(labels_off=False, line_width=2)

            # Scale the axes to match mesh size
            if axes_actor:
                axes_actor.SetTotalLength(axes_length, axes_length, axes_length)

            # Update axis label colors and font size based on dark mode
            if axes_actor:
                # Light grey for dark mode (matching stylesheet #D4D4D4), dark grey for light mode
                if self.dark_mode:
                    text_color = (0.831, 0.831, 0.831)  # Light grey #D4D4D4
                else:
                    text_color = (0.2, 0.2, 0.2)  # Dark grey

                # Set smaller font size and color for X axis
                x_text = axes_actor.GetXAxisCaptionActor2D().GetCaptionTextProperty()
                x_text.SetColor(text_color)
                x_text.SetFontSize(8)

                # Set smaller font size and color for Y axis
                y_text = axes_actor.GetYAxisCaptionActor2D().GetCaptionTextProperty()
                y_text.SetColor(text_color)
                y_text.SetFontSize(8)

                # Set smaller font size and color for Z axis
                z_text = axes_actor.GetZAxisCaptionActor2D().GetCaptionTextProperty()
                z_text.SetColor(text_color)
                z_text.SetFontSize(8)

                # Also scale down the actual caption actors
                axes_actor.GetXAxisCaptionActor2D().SetHeight(0.03)
                axes_actor.GetYAxisCaptionActor2D().SetHeight(0.03)
                axes_actor.GetZAxisCaptionActor2D().SetHeight(0.03)

            # Use appropriate background color based on mode
            bg_color = "#1E1E1E" if self.dark_mode else "white"
            self.plotter.set_background(bg_color)

            # Reset camera to fit all visible geometry
            self.plotter.reset_camera()

            # Force single render at the end
            self.plotter.render()
        finally:
            # Always return to IDLE when preview update completes
            # Note: _process_pending_updates will also set to IDLE in its finally block,
            # but that's okay - IDLE → IDLE is a valid (no-op) transition
            self._set_update_state("IDLE")

    def _render_parametric_mesh(self):
        """Render parametric mesh in 3D with wing surface."""
        comp = self.current_component

        try:
            # Check if wireframe should be shown
            show_wireframe = (
                hasattr(self, "show_wireframe_check")
                and self.show_wireframe_check.isChecked()
            )

            # Use the new rendering utilities to create wing visualization
            meshes = render.create_parametric_wing_visualization(
                comp.sections,
                comp.regions,
                comp.config,
                show_surface=True,
                show_wireframe=show_wireframe,
                show_sections=True,
                element_type=comp.config.el_type,  # Pass element type for visualization
            )

            # Add meshes to plotter
            for mesh_name, mesh_data in meshes:
                # Determine if we should show original mesh
                show_original = not comp.config.mesh_mirror or comp.config.mesh_symmetry

                # Add original mesh (if not pure mirror mode, or if symmetry is enabled)
                if show_original:
                    if mesh_name == "surface":
                        # All element types use the same rendering style: lightgray surface with dark edges
                        self.plotter.add_mesh(
                            mesh_data,
                            color="lightgray",
                            opacity=0.9,
                            show_edges=True,
                            edge_color="darkblue",
                            line_width=1.5,
                            label="Original",
                        )
                    elif mesh_name == "wireframe":
                        # Wireframe is now redundant, skip it
                        pass
                    elif mesh_name.startswith("section_"):
                        # Color code section outlines
                        idx = int(mesh_name.split("_")[1])
                        if idx == 0:
                            color = "green"
                            width = 3
                        elif idx == len(comp.sections) - 1:
                            color = "orange"
                            width = 3
                        else:
                            color = "blue"
                            width = 2

                        self.plotter.add_mesh(mesh_data, color=color, line_width=width)

                # Add mirrored/symmetric copy if enabled
                if comp.config.mesh_symmetry or comp.config.mesh_mirror:
                    # Determine which plane to use
                    if comp.config.mesh_symmetry:
                        plane_point = comp.config.symmetry_point
                        plane_normal = comp.config.symmetry_normal
                    else:  # mesh_mirror
                        plane_point = comp.config.mirror_point
                        plane_normal = comp.config.mirror_normal

                    # Reflect the mesh
                    mirrored_mesh = render.reflect_mesh_across_plane(
                        mesh_data, plane_point, plane_normal
                    )

                    if mesh_name == "surface":
                        self.plotter.add_mesh(
                            mirrored_mesh,
                            color="lightcoral"
                            if comp.config.mesh_symmetry
                            else "lightgray",
                            opacity=0.9,
                            show_edges=True,
                            edge_color="darkred"
                            if comp.config.mesh_symmetry
                            else "darkblue",
                            line_width=1.5,
                            label="Mirrored"
                            if comp.config.mesh_mirror
                            else "Symmetric",
                        )
                    elif mesh_name.startswith("section_"):
                        # Mirror section outlines
                        idx = int(mesh_name.split("_")[1])
                        if idx == 0:
                            color = "darkgreen"
                            width = 3
                        elif idx == len(comp.sections) - 1:
                            color = "darkorange"
                            width = 3
                        else:
                            color = "darkblue"
                            width = 2

                        self.plotter.add_mesh(
                            mirrored_mesh, color=color, line_width=width
                        )

            # Add centerline starting from the configured starting point
            section_positions = render.compute_section_positions(
                comp.regions, comp.config.starting_point
            )

            # Draw centerline as connected straight lines between consecutive sections
            if len(section_positions) >= 2:
                # Show original centerline only if not pure mirror mode
                if not comp.config.mesh_mirror or comp.config.mesh_symmetry:
                    centerline = pv.lines_from_points(section_positions)
                    self.plotter.add_mesh(
                        centerline, color="red", line_width=3, label="Centerline"
                    )

                # Add mirrored centerline if symmetry or mirror enabled
                if comp.config.mesh_symmetry or comp.config.mesh_mirror:
                    if comp.config.mesh_symmetry:
                        plane_point = comp.config.symmetry_point
                        plane_normal = comp.config.symmetry_normal
                    else:
                        plane_point = comp.config.mirror_point
                        plane_normal = comp.config.mirror_normal

                    centerline_mesh = pv.lines_from_points(section_positions)
                    mirrored_centerline = render.reflect_mesh_across_plane(
                        centerline_mesh, plane_point, plane_normal
                    )
                    self.plotter.add_mesh(
                        mirrored_centerline,
                        color="darkred" if comp.config.mesh_symmetry else "red",
                        line_width=3,
                        label="Mirrored Centerline"
                        if comp.config.mesh_mirror
                        else "Symmetric Centerline",
                    )

            # Optionally visualize the symmetry/mirror plane
            if comp.config.mesh_symmetry or comp.config.mesh_mirror:
                if comp.config.mesh_symmetry:
                    plane_point = comp.config.symmetry_point
                    plane_normal = comp.config.symmetry_normal
                    plane_color = "cyan"
                else:
                    plane_point = comp.config.mirror_point
                    plane_normal = comp.config.mirror_normal
                    plane_color = "yellow"

                # Create a plane visualization
                plane_mesh = pv.Plane(
                    center=plane_point, direction=plane_normal, i_size=3, j_size=3
                )
                self.plotter.add_mesh(
                    plane_mesh,
                    color=plane_color,
                    opacity=0.2,
                    show_edges=True,
                    edge_color="black",
                    line_width=1,
                    label="Symmetry Plane"
                    if comp.config.mesh_symmetry
                    else "Mirror Plane",
                )

        except ValueError as e:
            # Invalid airfoil specification or parameter values
            error_msg = f"⚠️ Invalid airfoil or parameters: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Rendering error (ValueError): {e}")
        except FileNotFoundError as e:
            # Missing custom airfoil or C81 table file
            error_msg = f"⚠️ File not found: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Rendering error (FileNotFoundError): {e}")
        except Exception as e:
            # Catch-all for other rendering issues (VTK errors, etc.)
            error_msg = f"⚠️ Surface rendering failed: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Rendering error (Exception): {e}")

    def _render_pointwise_mesh(self):
        """Render pointwise mesh in 3D with points and lines."""
        comp = self.current_component

        try:
            # Create pointwise mesh visualization with config parameters
            ref_chord_frac = (
                comp.config.reference_chord_fraction
                if hasattr(comp.config, "reference_chord_fraction")
                else 0.25
            )

            # Get chord distribution from config
            chord_params = {}
            if hasattr(comp.config, "chord_params") and comp.config.chord_params:
                chord_params = comp.config.chord_params.copy()

            chord_dist = geom.chord_distribution(
                comp.config.nelem_chord, comp.config.type_chord, **chord_params
            )

            meshes = render.create_pointwise_mesh(
                comp.points,
                comp.lines,
                point_size=8.0,
                line_width=3.0,
                show_airfoils=True,
                ref_chord_fraction=ref_chord_frac,
                chord_distribution=chord_dist,
                element_type=comp.config.el_type,  # Use el_type like in parametric case
            )

            # Add meshes to plotter
            for mesh_name, mesh_data in meshes:
                # Determine if we should show original mesh
                show_original = not comp.config.mesh_mirror or comp.config.mesh_symmetry

                # Add original mesh
                if show_original:
                    if mesh_name == "points":
                        # Show points as spheres
                        self.plotter.add_mesh(
                            mesh_data,
                            color="red",
                            point_size=10.0,
                            render_points_as_spheres=True,
                            label="Points",
                        )
                    elif mesh_name.startswith("surface_"):
                        # Panel method: full surface mesh
                        self.plotter.add_mesh(
                            mesh_data,
                            color="lightblue",
                            show_edges=True,
                            edge_color="blue",
                            line_width=1.5,
                            label="Wing Surface",
                            opacity=0.9,
                        )
                    elif mesh_name.startswith("meanline_"):
                        # Vortex-Lattice: meanline surface
                        self.plotter.add_mesh(
                            mesh_data,
                            color="lightgreen",
                            show_edges=True,
                            edge_color="darkgreen",
                            line_width=1.5,
                            label="Meanline Surface",
                            opacity=0.8,
                        )
                    elif mesh_name.startswith("le_line_") or mesh_name.startswith(
                        "te_line_"
                    ):
                        # Lifting-Line: LE and TE lines
                        color = (
                            "darkgreen"
                            if mesh_name.startswith("le_line_")
                            else "darkred"
                        )
                        label = (
                            "Leading Edge"
                            if mesh_name.startswith("le_line_")
                            else "Trailing Edge"
                        )
                        self.plotter.add_mesh(
                            mesh_data, color=color, line_width=3.0, label=label
                        )

                # Add mirrored/symmetric copy if enabled
                if comp.config.mesh_symmetry or comp.config.mesh_mirror:
                    # Determine which plane to use
                    if comp.config.mesh_symmetry:
                        plane_point = comp.config.symmetry_point
                        plane_normal = comp.config.symmetry_normal
                    else:  # mesh_mirror
                        plane_point = comp.config.mirror_point
                        plane_normal = comp.config.mirror_normal

                    # Reflect the mesh
                    mirrored_mesh = render.reflect_mesh_across_plane(
                        mesh_data, plane_point, plane_normal
                    )

                    if mesh_name == "points":
                        self.plotter.add_mesh(
                            mirrored_mesh,
                            color="darkred" if comp.config.mesh_symmetry else "red",
                            point_size=10.0,
                            render_points_as_spheres=True,
                            label="Mirrored Points"
                            if comp.config.mesh_mirror
                            else "Symmetric Points",
                        )
                    elif mesh_name.startswith("surface_"):
                        # Panel: mirrored full surface
                        mirror_color = (
                            "lightcyan" if comp.config.mesh_symmetry else "lightblue"
                        )
                        self.plotter.add_mesh(
                            mirrored_mesh,
                            color=mirror_color,
                            show_edges=True,
                            edge_color="darkblue"
                            if comp.config.mesh_symmetry
                            else "blue",
                            line_width=1.5,
                            label="Mirrored Surface"
                            if comp.config.mesh_mirror
                            else "Symmetric Surface",
                            opacity=0.9,
                        )
                    elif mesh_name.startswith("meanline_"):
                        # Vortex-Lattice: mirrored meanline
                        mirror_color = (
                            "palegreen" if comp.config.mesh_symmetry else "lightgreen"
                        )
                        self.plotter.add_mesh(
                            mirrored_mesh,
                            color=mirror_color,
                            show_edges=True,
                            edge_color="darkgreen",
                            line_width=1.5,
                            label="Mirrored Meanline"
                            if comp.config.mesh_mirror
                            else "Symmetric Meanline",
                            opacity=0.8,
                        )
                    elif mesh_name.startswith("le_line_") or mesh_name.startswith(
                        "te_line_"
                    ):
                        # Lifting-Line: mirrored LE/TE lines
                        is_le = mesh_name.startswith("le_line_")
                        base_color = "darkgreen" if is_le else "darkred"
                        mirror_color = (
                            "forestgreen"
                            if (is_le and comp.config.mesh_symmetry)
                            else (
                                "green"
                                if is_le
                                else (
                                    "firebrick" if comp.config.mesh_symmetry else "red"
                                )
                            )
                        )
                        label_prefix = (
                            "Mirrored" if comp.config.mesh_mirror else "Symmetric"
                        )
                        label_suffix = "LE" if is_le else "TE"
                        self.plotter.add_mesh(
                            mirrored_mesh,
                            color=mirror_color,
                            line_width=3.0,
                            label=f"{label_prefix} {label_suffix}",
                        )

            # Optionally visualize the symmetry/mirror plane
            if comp.config.mesh_symmetry or comp.config.mesh_mirror:
                if comp.config.mesh_symmetry:
                    plane_point = comp.config.symmetry_point
                    plane_normal = comp.config.symmetry_normal
                    plane_color = "cyan"
                else:
                    plane_point = comp.config.mirror_point
                    plane_normal = comp.config.mirror_normal
                    plane_color = "yellow"

                # Create a plane visualization
                # Estimate plane size from points extent
                if comp.points:
                    points_array = np.array(
                        [[p["x"], p["y"], p["z"]] for p in comp.points]
                    )
                    extent = np.linalg.norm(
                        points_array.max(axis=0) - points_array.min(axis=0)
                    )
                    plane_size = max(3.0, extent * 0.5)
                else:
                    plane_size = 3.0

                plane_mesh = pv.Plane(
                    center=plane_point,
                    direction=plane_normal,
                    i_size=plane_size,
                    j_size=plane_size,
                )
                self.plotter.add_mesh(
                    plane_mesh,
                    color=plane_color,
                    opacity=0.2,
                    show_edges=True,
                    edge_color="black",
                    line_width=1,
                    label="Symmetry Plane"
                    if comp.config.mesh_symmetry
                    else "Mirror Plane",
                )

        except ValueError as e:
            # Invalid airfoil specification or parameter values
            error_msg = f"⚠️ Invalid airfoil or parameters: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Pointwise rendering error (ValueError): {e}")
        except FileNotFoundError as e:
            # Missing custom airfoil or C81 table file
            error_msg = f"⚠️ File not found: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Pointwise rendering error (FileNotFoundError): {e}")
        except Exception as e:
            # Catch-all for other rendering issues
            error_msg = f"⚠️ Pointwise rendering failed: {str(e)}"
            self.statusBar().showMessage(error_msg, 5000)
            print(f"Pointwise rendering error (Exception): {e}")
            import traceback

            traceback.print_exc()

    def _export_current_component(self):
        """Export current component to DUST file."""
        comp = self.current_component

        filename, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            f"Export {comp.name}",
            f"{comp.name.lower()}.in",
            "DUST Input Files (*.in);;All Files (*)",
        )

        if not filename:
            return

        try:
            if comp.mesh_type == "parametric":
                if len(comp.sections) != len(comp.regions) + 1:
                    QtWidgets.QMessageBox.warning(
                        self,
                        "Invalid Geometry",
                        f"Need {len(comp.regions) + 1} sections for {len(comp.regions)} regions.",
                    )
                    return

                mesh = build_mesh.ParametricMesh(
                    comp.config, comp.sections, comp.regions
                )
                mesh.write(filename)

            self.statusBar().showMessage(f"✓ Exported {comp.name} to: {filename}", 5000)

            QtWidgets.QMessageBox.information(
                self,
                "Export Successful",
                f"Component '{comp.name}' saved to:\n{filename}",
            )

        except Exception as e:
            QtWidgets.QMessageBox.critical(
                self, "Export Error", f"Failed to export component:\n{str(e)}"
            )

    def _export_all_components(self):
        """Export all components to separate files."""
        dir_path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Export Directory"
        )

        if not dir_path:
            return

        import os

        exported = []

        for name, comp in self.components.items():
            try:
                filename = os.path.join(dir_path, f"{name.lower()}.in")

                if comp.mesh_type == "parametric":
                    mesh = build_mesh.ParametricMesh(
                        comp.config, comp.sections, comp.regions
                    )
                    mesh.write(filename)
                    exported.append(name)

            except Exception as e:
                QtWidgets.QMessageBox.warning(
                    self, f"Export Error: {name}", f"Failed to export {name}:\n{str(e)}"
                )

        if exported:
            QtWidgets.QMessageBox.information(
                self,
                "Export Complete",
                f"Exported {len(exported)} components to:\n{dir_path}",
            )
            self.statusBar().showMessage(f"✓ Exported {len(exported)} components", 5000)


class C81ResultsDialog(QtWidgets.QDialog):
    """Dialog to display C81 generation results with tabs for each Reynolds number."""

    def __init__(self, airfoil, parent=None, dark_mode=False):
        super().__init__(parent)
        self.airfoil = airfoil
        self.dark_mode = dark_mode
        self.setWindowTitle(f"C81 Table Results - {airfoil.name}")
        self.setMinimumSize(900, 700)

        layout = QtWidgets.QVBoxLayout(self)

        # Info label
        info_label = QtWidgets.QLabel(
            f"<b>Airfoil:</b> {airfoil.name}<br>"
            f"<b>File generated:</b> {airfoil.filename}.c81"
        )
        layout.addWidget(info_label)

        # Tab widget for different Reynolds numbers
        self.tabs = QtWidgets.QTabWidget()
        layout.addWidget(self.tabs)

        # Determine if single or multiple Reynolds numbers
        is_multi_re = isinstance(self.airfoil.re, np.ndarray)

        if is_multi_re:
            # Multiple Reynolds numbers - one tab per Re
            for i, re_val in enumerate(self.airfoil.re):
                canvas = self._create_plot_canvas(re_index=i)
                self.tabs.addTab(canvas, f"Re = {re_val:.2e}")
        else:
            # Single Reynolds number
            canvas = self._create_plot_canvas(re_index=None)
            self.tabs.addTab(canvas, f"Re = {self.airfoil.re:.2e}")

        # Close button
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        close_btn = QtWidgets.QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)

    def _create_plot_canvas(self, re_index=None):
        """Create a matplotlib canvas with C81 plots."""
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
        from matplotlib.figure import Figure
        import matplotlib.pyplot as plt

        # Configure theme based on dark mode setting
        if self.dark_mode:
            plt.style.use("dark_background")
            bg_color = "#1E1E1E"
            text_color = "#d4d4d4"
        else:
            plt.style.use("default")
            bg_color = "white"
            text_color = "#000000"

        fig = Figure(figsize=(10, 8), facecolor=bg_color)
        canvas = FigureCanvasQTAgg(fig)

        # Get data for this Reynolds number
        is_multi_re = isinstance(self.airfoil.re, np.ndarray)

        if is_multi_re and re_index is not None:
            cl_data = self.airfoil.cl[re_index, :, :]
            cd_data = self.airfoil.cd[re_index, :, :]
            cm_data = self.airfoil.cm[re_index, :, :]
        elif is_multi_re:
            # Plot all Re on same plot
            cl_data = self.airfoil.cl
            cd_data = self.airfoil.cd
            cm_data = self.airfoil.cm
        else:
            cl_data = self.airfoil.cl
            cd_data = self.airfoil.cd
            cm_data = self.airfoil.cm

        # Create subplots with appropriate theme
        ax1 = fig.add_subplot(311, facecolor=bg_color)
        ax2 = fig.add_subplot(312, facecolor=bg_color)
        ax3 = fig.add_subplot(313, facecolor=bg_color)

        # Plot CL, CD, CM vs AoA for each Mach number
        for i, mach in enumerate(self.airfoil.mach):
            if is_multi_re and re_index is None:
                # Plotting all Re - different handling needed
                for j, re_val in enumerate(self.airfoil.re):
                    label = f"M={mach:.2f}, Re={re_val:.1e}"
                    ax1.plot(
                        self.airfoil.aoa,
                        self.airfoil.cl[j, i, :],
                        label=label,
                        alpha=0.7,
                    )
                    ax2.plot(
                        self.airfoil.aoa,
                        self.airfoil.cd[j, i, :],
                        label=label,
                        alpha=0.7,
                    )
                    ax3.plot(
                        self.airfoil.aoa,
                        self.airfoil.cm[j, i, :],
                        label=label,
                        alpha=0.7,
                    )
            else:
                label = f"M={mach:.2f}"
                ax1.plot(self.airfoil.aoa, cl_data[i, :], label=label)
                ax2.plot(self.airfoil.aoa, cd_data[i, :], label=label)
                ax3.plot(self.airfoil.aoa, cm_data[i, :], label=label)

        for ax in [ax1, ax2, ax3]:
            ax.tick_params(colors=text_color)
            ax.xaxis.label.set_color(text_color)
            ax.yaxis.label.set_color(text_color)
            for spine in ax.spines.values():
                spine.set_edgecolor(text_color)

        ax1.set_ylabel("CL")
        ax1.set_xlabel("Angle of Attack (°)")
        ax1.legend(loc="best", fontsize=8)
        ax1.grid(True, alpha=0.3)

        ax2.set_ylabel("CD")
        ax2.set_xlabel("Angle of Attack (°)")
        ax2.legend(loc="best", fontsize=8)
        ax2.grid(True, alpha=0.3)

        ax3.set_ylabel("CM")
        ax3.set_xlabel("Angle of Attack (°)")
        ax3.legend(loc="best", fontsize=8)
        ax3.grid(True, alpha=0.3)

        fig.tight_layout()

        return canvas


class C81GeneratorDialog(QtWidgets.QDialog):
    """Dialog to configure C81 table generation parameters."""

    def __init__(self, airfoil_name, parent=None):
        super().__init__(parent)
        self.airfoil_name = airfoil_name
        self.setWindowTitle(f"Generate C81 Table - {airfoil_name}")
        self.setMinimumWidth(500)

        layout = QtWidgets.QVBoxLayout(self)

        # Check if this is a NACA profile
        self.is_naca = self._is_naca_profile(airfoil_name)

        # Airfoil file selection (only needed for non-NACA profiles)
        self.airfoil_group = QtWidgets.QGroupBox("Airfoil Coordinates")
        airfoil_layout = QtWidgets.QVBoxLayout()

        if self.is_naca:
            # NACA profile - show info message
            naca_info = QtWidgets.QLabel(
                f"<b>NACA Profile Detected:</b> {airfoil_name}<br>"
                "Coordinates will be generated automatically."
            )
            naca_info.setStyleSheet(
                "QLabel { "
                "background-color: #3c3c3c; "
                "color: #d4d4d4; "
                "padding: 8px; "
                "border-radius: 4px; "
                "border: 1px solid #555555; "
                "}"
            )
            airfoil_layout.addWidget(naca_info)
        else:
            # Custom profile - need .dat file
            file_layout = QtWidgets.QHBoxLayout()
            self.airfoil_path_edit = QtWidgets.QLineEdit()
            self.airfoil_path_edit.setPlaceholderText(
                "Select .dat file with airfoil coordinates..."
            )
            browse_airfoil_btn = QtWidgets.QPushButton("Browse...")
            browse_airfoil_btn.clicked.connect(self._browse_airfoil_file)
            file_layout.addWidget(self.airfoil_path_edit)
            file_layout.addWidget(browse_airfoil_btn)
            airfoil_layout.addLayout(file_layout)

        self.airfoil_group.setLayout(airfoil_layout)
        layout.addWidget(self.airfoil_group)

        # Output location
        output_group = QtWidgets.QGroupBox("Output Location")
        output_layout = QtWidgets.QHBoxLayout()
        self.output_path_edit = QtWidgets.QLineEdit()
        self.output_path_edit.setText("c81tables")
        self.output_path_edit.setPlaceholderText("Directory to save .c81 file...")
        browse_output_btn = QtWidgets.QPushButton("Browse...")
        browse_output_btn.clicked.connect(self._browse_output_dir)
        output_layout.addWidget(self.output_path_edit)
        output_layout.addWidget(browse_output_btn)
        output_group.setLayout(output_layout)
        layout.addWidget(output_group)

        # Reynolds number(s)
        re_group = QtWidgets.QGroupBox("Reynolds Number(s)")
        re_layout = QtWidgets.QVBoxLayout()

        re_info = QtWidgets.QLabel(
            "Enter one or more Reynolds numbers separated by commas.<br>"
            "Examples: <code>1000000</code> or <code>100000, 500000, 1000000</code>"
        )
        re_layout.addWidget(re_info)

        self.reynolds_edit = QtWidgets.QLineEdit()
        self.reynolds_edit.setText("1000000")
        self.reynolds_edit.setPlaceholderText(
            "e.g., 1000000 or 100000, 500000, 1000000"
        )
        re_layout.addWidget(self.reynolds_edit)

        re_group.setLayout(re_layout)
        layout.addWidget(re_group)

        # Advanced options (collapsible)
        advanced_group = QtWidgets.QGroupBox("Advanced Options")
        advanced_layout = QtWidgets.QFormLayout()

        self.mach_min_spin = QtWidgets.QDoubleSpinBox()
        self.mach_min_spin.setRange(0.0, 0.99)
        self.mach_min_spin.setDecimals(2)
        self.mach_min_spin.setSingleStep(0.05)
        self.mach_min_spin.setValue(0.0)
        advanced_layout.addRow("Mach Min:", self.mach_min_spin)

        self.mach_max_spin = QtWidgets.QDoubleSpinBox()
        self.mach_max_spin.setRange(0.01, 0.99)
        self.mach_max_spin.setDecimals(2)
        self.mach_max_spin.setSingleStep(0.05)
        self.mach_max_spin.setValue(0.9)
        advanced_layout.addRow("Mach Max:", self.mach_max_spin)

        self.n_mach_spin = QtWidgets.QSpinBox()
        self.n_mach_spin.setRange(2, 50)
        self.n_mach_spin.setValue(10)
        advanced_layout.addRow("Number of Mach:", self.n_mach_spin)

        self.aoa_min_spin = QtWidgets.QDoubleSpinBox()
        self.aoa_min_spin.setRange(-180.0, 179.0)
        self.aoa_min_spin.setDecimals(1)
        self.aoa_min_spin.setValue(-180.0)
        advanced_layout.addRow("AoA Min (°):", self.aoa_min_spin)

        self.aoa_max_spin = QtWidgets.QDoubleSpinBox()
        self.aoa_max_spin.setRange(-179.0, 180.0)
        self.aoa_max_spin.setDecimals(1)
        self.aoa_max_spin.setValue(180.0)
        advanced_layout.addRow("AoA Max (°):", self.aoa_max_spin)

        self.model_size_combo = QtWidgets.QComboBox()
        self.model_size_combo.addItems(
            ["small", "medium", "large", "xlarge", "xxlarge", "xxxlarge"]
        )
        self.model_size_combo.setCurrentText("xxxlarge")
        advanced_layout.addRow("Model Size:", self.model_size_combo)

        advanced_group.setLayout(advanced_layout)
        layout.addWidget(advanced_group)

        # Buttons
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()

        cancel_btn = QtWidgets.QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)

        self.generate_btn = QtWidgets.QPushButton("Generate")
        self.generate_btn.clicked.connect(self.accept)
        self.generate_btn.setDefault(True)
        btn_layout.addWidget(self.generate_btn)

        layout.addLayout(btn_layout)

    def _is_naca_profile(self, name):
        """Check if airfoil name is a NACA 4-digit or 5-digit profile."""
        import re

        name_upper = name.upper().strip()
        # Match NACA followed by 4 or 5 digits
        return bool(re.match(r"^NACA\s*\d{4,5}$", name_upper))

    def _browse_airfoil_file(self):
        """Browse for airfoil .dat file."""
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select Airfoil Coordinate File",
            "",
            "Airfoil Files (*.dat);;All Files (*)",
        )
        if file_path:
            self.airfoil_path_edit.setText(file_path)

    def _browse_output_dir(self):
        """Browse for output directory."""
        dir_path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Output Directory", self.output_path_edit.text()
        )
        if dir_path:
            self.output_path_edit.setText(dir_path)

    def get_parameters(self):
        """Get the configured parameters."""
        import tempfile
        from pathlib import Path

        # Parse Reynolds numbers
        re_text = self.reynolds_edit.text().strip()
        re_values = [float(x.strip()) for x in re_text.split(",")]

        # Convert to single float or list
        if len(re_values) == 1:
            reynolds = re_values[0]
        else:
            reynolds = re_values

        # Handle NACA profiles vs custom profiles
        if self.is_naca:
            # Generate NACA coordinates in a temporary file
            temp_dir = Path(tempfile.mkdtemp())

            # Use aerosandbox to generate NACA coordinates
            try:
                import aerosandbox as asb

                af = asb.Airfoil(self.airfoil_name)

                # Write coordinates to temporary .dat file
                temp_file = temp_dir / f"{self.airfoil_name}.dat"
                with open(temp_file, "w") as f:
                    for x, y in zip(af.x(), af.y()):
                        f.write(f"{x:.6f} {y:.6f}\n")

                file_name = self.airfoil_name
                pathprofile = temp_dir
            except Exception as e:
                raise ValueError(f"Failed to generate NACA coordinates: {str(e)}")
        else:
            # Use provided .dat file
            airfoil_path = Path(self.airfoil_path_edit.text())
            if not airfoil_path.exists():
                raise FileNotFoundError(f"Airfoil file not found: {airfoil_path}")
            file_name = airfoil_path.stem
            pathprofile = airfoil_path.parent

        return {
            "file_name": file_name,
            "pathprofile": pathprofile,
            "reynolds": reynolds,
            "mach_range": (self.mach_min_spin.value(), self.mach_max_spin.value()),
            "n_mach": self.n_mach_spin.value(),
            "aoa_range": (self.aoa_min_spin.value(), self.aoa_max_spin.value()),
            "model_size": self.model_size_combo.currentText(),
            "pathout": self.output_path_edit.text(),
        }


class AirfoilTableDialog(QtWidgets.QDialog):
    """Dialog to select or generate C81 airfoil table."""

    def __init__(self, airfoil_name, parent=None):
        super().__init__(parent)
        self.airfoil_name = airfoil_name
        self.c81_file_path = None
        self.setWindowTitle(f"Airfoil Table - {airfoil_name}")
        self.setMinimumWidth(400)

        layout = QtWidgets.QVBoxLayout(self)

        # Title
        title = QtWidgets.QLabel(f"<h3>Configure Airfoil Table for {airfoil_name}</h3>")
        layout.addWidget(title)

        # Question
        question = QtWidgets.QLabel(
            "Do you have an existing .c81 table file for this airfoil profile?"
        )
        layout.addWidget(question)

        # Buttons
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()

        self.no_btn = QtWidgets.QPushButton("No - Generate New")
        self.no_btn.clicked.connect(self._generate_c81)
        btn_layout.addWidget(self.no_btn)

        self.yes_btn = QtWidgets.QPushButton("Yes - Browse File")
        self.yes_btn.clicked.connect(self._browse_c81)
        self.yes_btn.setDefault(True)
        btn_layout.addWidget(self.yes_btn)

        cancel_btn = QtWidgets.QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)

        layout.addLayout(btn_layout)

    def _browse_c81(self):
        """Browse for existing .c81 file."""
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select C81 Table File", "", "C81 Files (*.c81);;All Files (*)"
        )
        if file_path:
            self.c81_file_path = file_path
            self.accept()

    def _generate_c81(self):
        """Generate new .c81 file using neurafoil."""
        generator_dlg = C81GeneratorDialog(self.airfoil_name, self)

        if generator_dlg.exec_() == QtWidgets.QDialog.Accepted:
            params = generator_dlg.get_parameters()

            # Show progress dialog
            progress = QtWidgets.QProgressDialog(
                "Generating C81 table using NeuralFoil...\nThis may take a few seconds.",
                None,
                0,
                0,
                self,
            )
            progress.setWindowTitle("Generating C81 Table")
            progress.setWindowModality(QtCore.Qt.WindowModal)
            progress.setCancelButton(None)
            progress.show()
            QtWidgets.QApplication.processEvents()

            try:
                # Generate the airfoil data
                airfoil = Airfoil.generate(**params)

                # Save the C81 file
                output_path = airfoil.generate_c81_file(
                    mbdynformat=False, pathout=params["pathout"]
                )

                progress.close()

                # Show results - pass dark mode from parent
                dark_mode = (
                    self.parent().dark_mode
                    if hasattr(self.parent(), "dark_mode")
                    else False
                )
                results_dlg = C81ResultsDialog(airfoil, self, dark_mode=dark_mode)
                results_dlg.exec_()

                # Set the file path
                self.c81_file_path = str(output_path)
                self.accept()

            except Exception as e:
                progress.close()
                QtWidgets.QMessageBox.critical(
                    self,
                    "C81 Generation Error",
                    f"Failed to generate C81 table:\n{str(e)}",
                )

    def get_c81_path(self):
        """Get the selected or generated C81 file path."""
        return self.c81_file_path


class CollapsibleBox(QtWidgets.QWidget):
    """A collapsible/expandable widget for grouping options."""

    def __init__(self, title="", parent=None):
        super().__init__(parent)

        self.toggle_button = QtWidgets.QToolButton()
        self.toggle_button.setText(title)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(False)
        self.toggle_button.setStyleSheet(
            "QToolButton { border: none; font-weight: bold; }"
        )
        self.toggle_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(QtCore.Qt.RightArrow)
        self.toggle_button.clicked.connect(self.on_toggle)

        self.content_area = QtWidgets.QWidget()
        self.content_area.setMaximumHeight(0)
        self.content_area.setMinimumHeight(0)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.toggle_button)
        layout.addWidget(self.content_area)

    def on_toggle(self):
        """Toggle expanded/collapsed state."""
        checked = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(
            QtCore.Qt.DownArrow if checked else QtCore.Qt.RightArrow
        )

        if checked:
            self.content_area.setMaximumHeight(16777215)  # Max int
        else:
            self.content_area.setMaximumHeight(0)

    def setContentLayout(self, layout):
        """Set the layout for the collapsible content."""
        old_layout = self.content_area.layout()
        if old_layout:
            QtWidgets.QWidget().setLayout(old_layout)
        self.content_area.setLayout(layout)


def launch_gui():
    """Launch the DUST Mesh Builder GUI."""
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("Fusion")

    window = DUSTMeshBuilderGUI()
    window.show()

    return app.exec_()


if __name__ == "__main__":
    sys.exit(launch_gui())
