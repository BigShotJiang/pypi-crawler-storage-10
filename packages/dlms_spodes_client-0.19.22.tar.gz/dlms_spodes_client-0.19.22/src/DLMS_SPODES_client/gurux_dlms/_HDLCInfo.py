class _HDLCInfo:
    # Constructor.
    def __init__(self):
        pass

    MAX_INFO_TX = 0x5
    MAX_INFO_RX = 0x6
    WINDOW_SIZE_TX = 0x7
    WINDOW_SIZE_RX = 0x8
