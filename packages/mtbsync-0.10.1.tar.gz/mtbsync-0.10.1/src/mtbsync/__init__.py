"""MTB Video Sync - Align GoPro runs and transfer markers."""

__version__ = "0.1.0"
