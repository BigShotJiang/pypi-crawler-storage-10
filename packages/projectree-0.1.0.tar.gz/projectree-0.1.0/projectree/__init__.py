# projecttree/__init__.py
from .core import generate_project_tree

__all__ = ["generate_project_tree"]
