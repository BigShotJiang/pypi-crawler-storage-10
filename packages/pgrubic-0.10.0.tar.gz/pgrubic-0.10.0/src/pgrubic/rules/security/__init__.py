"""Rules around security."""
