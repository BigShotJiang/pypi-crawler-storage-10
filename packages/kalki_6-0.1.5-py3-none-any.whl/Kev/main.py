import sys
import json
import argparse
import requests
from datetime import datetime

__version__ = "0.1.5"
TOKEN = "d4ee6c4b21280f"

# ANSI red color code
RED = "\033[91m"
RESET = "\033[0m"

# Auto-install pytz if missing
try:
    import pytz
except ImportError:
    import subprocess
    import sys
    print(f"{RED}pytz not found, installing...{RESET}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pytz"])
    import pytz

def query_ip(ip_or_empty: str):
    base_url = "https://api.ipinfo.io/lite"
    
    # If no IP provided, use /me endpoint
    if not ip_or_empty:
        url = f"{base_url}/me?token={TOKEN}" if TOKEN else f"{base_url}/me"
    else:
        url = f"{base_url}/{ip_or_empty}?token={TOKEN}" if TOKEN else f"{base_url}/{ip_or_empty}"

    try:
        resp = requests.get(url, timeout=8)
    except requests.RequestException as e:
        raise RuntimeError(f"Network error: {e}")

    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text}")

    return resp.json()

def pretty_output(data):
    ip = data.get("ip", "Unknown")
    city = data.get("city", "Unknown")
    region = data.get("region", "Unknown")
    country = data.get("country", "Unknown")
    loc = data.get("loc", "Unknown")
    postal = data.get("postal", "Unknown")
    timezone = data.get("timezone", "Unknown")
    org = data.get("org", "Unknown")
    
    # Get time based on timezone
    try:
        tz = pytz.timezone(timezone)
        local_time = datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        local_time = "Can't fetch time"

    print(f"""{RED}
IP: {ip}
COUNTRY: {country}
REGION: {region}
CITY: {city}
LOC: {loc}
POSTAL: {postal}
TIMEZONE: {timezone}
TIME: {local_time}
NETWORK: {org}
OS: Can't fetch OS info
{RESET}""")

def cli(argv=None):
    parser = argparse.ArgumentParser(
        prog="PARI",
        description="Query ipinfo.io lite for IP info"
    )
    parser.add_argument("ip", nargs="?", default="", help="IP address to lookup (optional).")
    parser.add_argument("--raw", action="store_true", help="Print raw JSON output.")
    parser.add_argument("--version", action="store_true", help="Show version and exit.")
    parser.add_argument("--token", help="Use a custom ipinfo token.")
    
    args = parser.parse_args(argv)

    if args.version:
        print(f"KEV {__version__}")
        return 0

    global TOKEN
    if args.token:
        TOKEN = args.token

    try:
        data = query_ip(args.ip)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2

    if args.raw:
        print(json.dumps(data, ensure_ascii=False))
    else:
        pretty_output(data)

    return 0

if __name__ == "__main__":
    raise SystemExit(cli())