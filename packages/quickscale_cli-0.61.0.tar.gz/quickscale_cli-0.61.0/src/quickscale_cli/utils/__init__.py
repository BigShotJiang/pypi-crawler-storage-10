"""Utility functions package for QuickScale CLI."""
