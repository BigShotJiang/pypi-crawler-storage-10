# For pybind11 extension modules, QuantileEstimator is exposed directly.
# This allows: from pyquantile import QuantileEstimator
# No explicit import needed here.
