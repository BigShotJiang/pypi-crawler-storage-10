from typing import Dict, Optional, List, Literal
from enum import Enum
from datetime import datetime
from uuid import UUID, uuid4

from ..common.dependencies import BaseModel, Field, ConfigDict, Json, PYDANTIC_AVAILABLE


class LTM_Artifact(BaseModel):
    """
    Represents a single, immutable artifact stored in the Long-Term Memory.
    """

    artifact_id: UUID = Field(
        default_factory=uuid4, description="Unique identifier for the artifact."
    )
    run_id: UUID = Field(
        ..., description="The execution run ID this artifact belongs to."
    )
    producer_step_id: str = Field(
        ..., description="The ID of the WorkflowStep that produced this artifact (e.g., '1.1')."
    )
    producer_execution_node_id: UUID = Field(
        ..., description="The specific ExecutionNode ID that produced this artifact."
    )
    port_name: str = Field(..., description="The name of the output port this artifact maps to.")
    data_type_hint: str = Field(
        ..., description="The data type hint (e.g., 'str', 'PydanticModelName')."
    )
    data: Json = Field(
        ..., description="The serialized content of the artifact."
    )
    timestamp_created: datetime = Field(default_factory=datetime.now)


class LTM_Snapshot(BaseModel):
    """
    A manifest representing the state of the LTM at a specific point in the execution timeline.
    """

    snapshot_id: UUID = Field(
        default_factory=uuid4, description="Unique identifier for the snapshot."
    )
    run_id: UUID
    associated_execution_node_id: UUID = Field(
        ..., description="The ExecutionNode after which this snapshot was taken."
    )
    artifact_manifest: Dict[str, UUID] = Field(
        ...,
        description="Manifest mapping logical artifact names to LTM_Artifact IDs present at this point.",
    )


class InteractionControlMode(str, Enum):
    """Defines the automation level for a HITL interaction."""

    MANDATORY = "Mandatory Interaction"
    CONDITIONAL_BYPASS = "Conditional Bypass"
    FULL_AUTOMATION = "Full Automation"


class ConditionalBypassConfig(BaseModel):
    """Configuration for Conditional Bypass logic."""

    confidence_threshold: Literal["Low", "Medium", "High"] = Field(
        "High",
        description="The minimum AI confidence score required to bypass.",
    )


class AutonomyProfile(BaseModel):
    """
    Defines the complete configuration for adaptive automation behavior.
    Hierarchy: Interaction Overrides > Mode Overrides > Default Mode.
    """

    profile_id: UUID = Field(default_factory=uuid4)
    profile_name: str = Field(
        ..., description="Name of the autonomy profile (e.g., 'Standard Oversight', 'High Autonomy')."
    )
    default_mode: InteractionControlMode = Field(
        InteractionControlMode.MANDATORY,
        description="The default control mode if no specific overrides apply.",
    )
    conditional_config: Optional[ConditionalBypassConfig] = Field(
        None,
        description="Global configuration parameters for Conditional Bypass mode.",
    )
    mode_overrides: Dict[str, InteractionControlMode] = Field(
        default_factory=dict,
        description="Overrides based on HITL mode name (e.g., {'VARL': 'Full Automation'}).",
    )
    interaction_overrides: Dict[str, InteractionControlMode] = Field(
        default_factory=dict,
        description="Granular overrides for specific interactions (e.g., {'1.2-B': 'Mandatory Interaction'}).",
    )

    if PYDANTIC_AVAILABLE:
        model_config = ConfigDict(use_enum_values=True)


class ExecutionStatus(str, Enum):
    """Status of a workflow execution node or run."""

    PENDING = "Pending"
    RUNNING = "Running"
    COMPLETED = "Completed"
    FAILED = "Failed"
    PAUSED_HITL = "Paused (Awaiting HITL Input)"
    SKIPPED = "Skipped"


class ValidityStatus(str, Enum):
    """Validity of an execution node's outputs."""

    VALID = "Valid"
    AFFECTED = "Affected (Upstream Dependency Changed)"
    INVALIDATED = "Invalidated (Execution Logic or Inputs Changed Significantly)"


class DataLineageLink(BaseModel):
    """
    Explicitly tracks the specific input artifact used by an execution node.
    """

    input_port_name: str
    source_artifact_id: UUID
    source_execution_node_id: UUID


class ExecutionNode(BaseModel):
    """
    Represents a single execution instance of a WorkflowStep within the timeline.
    """

    execution_node_id: UUID = Field(
        default_factory=uuid4, description="Unique ID for this execution instance."
    )
    run_id: UUID = Field(..., description="The overall execution run ID.")
    blueprint_node_id: str = Field(
        ..., description="The ID of the node in the ArchitecturalBlueprint."
    )
    step_id: str = Field(..., description="The ID of the WorkflowStep executed (e.g., '1.1').")
    timestamp_start: datetime = Field(default_factory=datetime.now)
    timestamp_end: Optional[datetime] = None
    status: ExecutionStatus = ExecutionStatus.PENDING
    predecessor_execution_node_ids: List[UUID] = Field(
        default_factory=list,
        description="IDs of the immediate predecessor ExecutionNodes.",
    )
    ltm_snapshot_id: Optional[UUID] = Field(
        None,
        description="ID of the LTM Snapshot taken AFTER this node completed.",
    )
    validity_status: ValidityStatus = Field(
        ValidityStatus.VALID,
        description="The current validity status determined by DTIAS.",
    )
    input_lineage: List[DataLineageLink] = Field(
        default_factory=list,
        description="Detailed record of the specific input artifacts consumed.",
    )
    is_active_timeline: bool = Field(
        True,
        description="Indicates if this node is part of the currently active execution trajectory.",
    )
    parent_revision_id: Optional[UUID] = Field(
        None,
        description="ID of the ExecutionNode in a previous timeline that this node supersedes.",
    )

    if PYDANTIC_AVAILABLE:
        model_config = ConfigDict(use_enum_values=True)


class ExecutionRun(BaseModel):
    """
    Represents an overall execution run of the workflow.
    """

    run_id: UUID = Field(
        default_factory=uuid4, description="Unique identifier for the execution run."
    )
    blueprint_id: str = Field(
        ..., description="The ID of the ArchitecturalBlueprint being executed."
    )
    timestamp_start: datetime = Field(default_factory=datetime.now)
    timestamp_end: Optional[datetime] = None
    status: ExecutionStatus = ExecutionStatus.PENDING
    problem_type: str
    active_autonomy_profile_id: UUID
    current_timeline_head_id: Optional[UUID] = Field(None)

    if PYDANTIC_AVAILABLE:
        model_config = ConfigDict(use_enum_values=True)
