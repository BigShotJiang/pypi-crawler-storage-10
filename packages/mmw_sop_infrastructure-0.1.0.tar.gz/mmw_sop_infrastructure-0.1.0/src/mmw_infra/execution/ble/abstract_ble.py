"""
Abstract Business Logic Executor (BLE) implementation.
This module provides the base class used by concrete SOP logic executors. It offers a
lightweight dispatch framework, LangChain integration helpers, and common utilities
for producing structured results that the Execution Orchestrator understands.
"""
from __future__ import annotations

import asyncio
import inspect
from functools import partial
from typing import Any, Awaitable, Callable, Dict, Optional

from mmw_infra.common.dependencies import (
    LANGCHAIN_CORE_AVAILABLE,
    BasePromptTemplate,
    BaseLanguageModel,
    Runnable,
    logging,
)
from mmw_infra.common.interfaces import (
    DynamicPromptBuilderInterface,
    InfrastructureServices,
)
from mmw_infra.execution.execution_states import ReasoningGraphState


class BLEExecutionError(RuntimeError):
    """Raised when a BLE node handler fails."""


Handler = Callable[[ReasoningGraphState], Awaitable[Dict[str, Any]]]


class AbstractBLE:
    """
    Abstract base class for SOP Business Logic Executors.

    Concrete executors should implement `_register_nodes` and call
    `self.register_node("node_id", handler)` for every reasoning node that they support.
    """

    def __init__(
        self,
        step_definition,
        infra_services: InfrastructureServices,
        default_llm: Optional[BaseLanguageModel] = None,
    ) -> None:
        self.step_definition = step_definition
        self.infra = infra_services
        self.default_llm = default_llm
        self.logger = logging.getLogger(f"BLE.{step_definition.id}")
        self.prompt_builder: Optional[DynamicPromptBuilderInterface] = getattr(
            infra_services, "prompt_builder", None
        )
        self._registry: Dict[str, Callable[..., Any]] = {}
        self._register_nodes()
        self.logger.info(
            "BLE initialised for step %s with %d registered nodes.",
            step_definition.id,
            len(self._registry),
        )

    def _register_nodes(self) -> None:  # pragma: no cover - to be implemented by subclasses
        """Hook for subclasses to populate `self._registry`."""
        raise NotImplementedError(
            "Concrete BLE implementations must register reasoning node handlers."
        )

    def register_node(self, node_id: str, handler: Callable[..., Any]) -> None:
        """Register a handler for a reasoning node."""
        self._registry[node_id] = handler

    async def execute_node(
        self, node_id: str, state: ReasoningGraphState
    ) -> Dict[str, Any]:
        """
        Dispatch execution to the registered handler for `node_id`.
        Handlers can be synchronous or asynchronous; synchronous handlers are executed
        in the default executor to prevent blocking the event loop.
        """
        handler = self._registry.get(node_id)
        if not handler:
            raise BLEExecutionError(
                f"No handler registered for reasoning node '{node_id}'."
            )

        self.logger.debug("Executing reasoning node %s.", node_id)

        try:
            if inspect.iscoroutinefunction(handler):
                result = await handler(state)
            else:
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, partial(handler, state))
        except Exception as exc:  # pragma: no cover - delegated to orchestrator
            self.logger.error("Node %s failed: %s", node_id, exc, exc_info=True)
            raise BLEExecutionError(str(exc)) from exc

        if not isinstance(result, dict):
            raise BLEExecutionError(
                f"Handler for node '{node_id}' returned {type(result).__name__}; expected dict."
            )

        return result

    async def prepare_prompt(
        self, template: BasePromptTemplate, state: ReasoningGraphState
    ) -> Dict[str, Any]:
        """
        Utility helper for BLE implementations that need to expand LCEL prompt templates.
        """
        if not self.prompt_builder:
            raise BLEExecutionError(
                "Prompt builder not configured on InfrastructureServices bundle."
            )

        chassis_context = state.get("chassis_context", {})
        return await self.prompt_builder.prepare_inputs(template, chassis_context)

    async def invoke_chain(
        self,
        chain: Runnable,
        inputs: Dict[str, Any],
        config: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Execute a LangChain runnable if the dependency is available."""
        if not LANGCHAIN_CORE_AVAILABLE:
            raise BLEExecutionError(
                "LangChain Core dependency missing; cannot invoke runnable chains."
            )

        return await chain.ainvoke(inputs, config=config or {})
