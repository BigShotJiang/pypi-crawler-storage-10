"""
Execution orchestrator for reasoning graphs.
"""
from __future__ import annotations

from typing import Dict, Optional, Set

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import AbstractBLE
from mmw_infra.execution.aac.automation_controller import AdaptiveAutomationController
from mmw_infra.execution.execution_states import ReasoningGraphState
from mmw_infra.models.execution_state import ExecutionStatus
from mmw_infra.models.sop_schema import WorkflowStep

from .dependency_analyzer import DependencyAnalyzer
from .node_executors import BaseNodeExecutor, JoinNodeExecutor


class CompiledReasoningGraph:
    """Lightweight wrapper providing a LangGraph-like interface."""

    def __init__(
        self,
        orchestrator: "ExecutionOrchestrator",
        step_definition: WorkflowStep,
        analyzer: DependencyAnalyzer,
    ) -> None:
        self._orchestrator = orchestrator
        self._step_definition = step_definition
        self._analyzer = analyzer

    async def ainvoke(
        self,
        initial_state: ReasoningGraphState,
        config: Optional[Dict[str, Dict[str, str]]] = None,
    ) -> ReasoningGraphState:
        return await self._orchestrator.execute_graph(
            self._step_definition, self._analyzer, initial_state, config or {}
        )


class ExecutionOrchestrator:
    """
    Coordinates execution of reasoning nodes according to the SOP definition.
    """

    def __init__(
        self, ble: AbstractBLE, aac: AdaptiveAutomationController
    ) -> None:
        self.ble = ble
        self.aac = aac
        self.logger = logging.getLogger("ExecutionOrchestrator")
        self.node_executor = BaseNodeExecutor(ble)
        self.join_executor = JoinNodeExecutor()

    def compile(self, step_definition: WorkflowStep) -> CompiledReasoningGraph:
        analyzer = DependencyAnalyzer(step_definition)
        return CompiledReasoningGraph(self, step_definition, analyzer)

    async def execute_graph(
        self,
        step_definition: WorkflowStep,
        analyzer: DependencyAnalyzer,
        state: ReasoningGraphState,
        config: Optional[Dict[str, Dict[str, str]]] = None,
    ) -> ReasoningGraphState:
        completed: Set[str] = set(state.get("completed_nodes", []))
        state["completed_nodes"] = list(completed)
        state.setdefault("node_results", {})
        state.setdefault("pending_interactions", [])
        state.setdefault("interaction_history", [])
        state.setdefault("status", ExecutionStatus.RUNNING)
        state.setdefault("error_message", None)

        try:
            while True:
                ready = analyzer.ready_nodes(completed)
                if not ready:
                    break

                for node_id in ready:
                    node_result = await self.node_executor.execute(node_id, state)
                    self.join_executor.merge_results(
                        state, [(node_id, node_result)]
                    )
                    completed.add(node_id)
                    state["completed_nodes"] = list(completed)

                    # Check for HITL interactions produced by the node.
                    hitl_requests = node_result.get("pending_interactions", [])
                    if hitl_requests:
                        history, requires_pause = await self.aac.process_interactions(
                            hitl_requests, state
                        )
                        state["interaction_history"].extend(history)
                        if requires_pause:
                            state["pending_interactions"] = hitl_requests
                            state["status"] = ExecutionStatus.PAUSED_HITL
                            return state

                    # Capture node level status overrides
                    node_status = node_result.get("status")
                    if node_status and node_status != ExecutionStatus.COMPLETED:
                        try:
                            status_enum = (
                                node_status
                                if isinstance(node_status, ExecutionStatus)
                                else ExecutionStatus(node_status)
                            )
                        except ValueError:
                            status_enum = ExecutionStatus.FAILED
                        state["status"] = status_enum
                        if status_enum == ExecutionStatus.FAILED:
                            state["error_message"] = node_result.get(
                                "error_message", f"Node {node_id} failed."
                            )
                            return state

            state["status"] = ExecutionStatus.COMPLETED
            return state
        except Exception as exc:  # pragma: no cover - defensive logging
            self.logger.error(
                "Execution orchestrator failed for step %s: %s",
                step_definition.id,
                exc,
                exc_info=True,
            )
            state["status"] = ExecutionStatus.FAILED
            state["error_message"] = str(exc)
            return state
