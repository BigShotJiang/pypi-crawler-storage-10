"""
Reasoning graph dependency analysis utilities.

The ExecutionOrchestrator relies on this helper to understand which reasoning nodes
are ready to execute based on the `ReasoningGraph` structure defined on a
`WorkflowStep`. The analyzer expands the recursive execution blocks (Serial,
Parallel, Concurrent) into a dependency map so the orchestrator can respect the SOP's
intended control-flow semantics.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, List, Sequence, Set

from mmw_infra.common.dependencies import logging
from mmw_infra.models.sop_schema import (
    ConcurrentBlock,
    ExecutionBlock,
    ReasoningGraph,
    ReasoningNode,
    SerialBlock,
    ParallelBlock,
    WorkflowStep,
)

BLOCK_TYPES = (SerialBlock, ParallelBlock, ConcurrentBlock)


class DependencyAnalyzer:
    """
    Expands a `ReasoningGraph` into node-level dependency information.

    For Serial blocks we ensure strict ordering by requiring each subsequent element
    to depend on the immediately preceding leaf nodes. Parallel and concurrent blocks
    share the same upstream dependencies and can therefore be executed together.
    """

    def __init__(self, step_definition: WorkflowStep):
        self.step_definition = step_definition
        self._dependencies: Dict[str, Set[str]] = defaultdict(set)
        self._encounter_order: List[str] = []
        self._build_dependency_map(step_definition.reasoning_graph)
        logging.getLogger("DependencyAnalyzer").debug(
            "Built dependency map for step %s: %s",
            step_definition.id,
            dict(self._dependencies),
        )

    # --------------------------------------------------------------------- #
    # Public helpers
    # --------------------------------------------------------------------- #

    def all_nodes(self) -> Sequence[str]:
        return tuple(self._encounter_order)

    def dependencies_for(self, node_id: str) -> Set[str]:
        return set(self._dependencies.get(node_id, set()))

    def initial_ready_nodes(self) -> List[str]:
        """Return nodes that have no dependencies, preserving encounter order."""
        ready = [
            node_id
            for node_id in self._encounter_order
            if not self._dependencies.get(node_id)
        ]
        return ready

    def ready_nodes(self, completed: Iterable[str]) -> List[str]:
        """Return nodes whose dependencies are satisfied by `completed`."""
        completed_set = set(completed)
        return [
            node_id
            for node_id in self._encounter_order
            if node_id not in completed_set
            and self._dependencies.get(node_id, set()).issubset(completed_set)
        ]

    # --------------------------------------------------------------------- #
    # Internal traversal logic
    # --------------------------------------------------------------------- #

    def _build_dependency_map(self, reasoning_graph: ReasoningGraph) -> None:
        self._traverse_block(reasoning_graph.root_flow, upstream=[])

    def _traverse_block(
        self, block: ExecutionBlock, upstream: Iterable[str]
    ) -> Set[str]:
        """
        Traverse an execution block and return the set of leaf nodes produced by the block.
        """
        if isinstance(block, SerialBlock):
            current_upstream = set(upstream)
            last_leaf_nodes: Set[str] = set()
            for element in block.elements:
                leaf_nodes = self._traverse_element(element, current_upstream)
                current_upstream = set(leaf_nodes)
                last_leaf_nodes = set(leaf_nodes)
            return last_leaf_nodes

        if isinstance(block, (ParallelBlock, ConcurrentBlock)):
            all_leaf_nodes: Set[str] = set()
            for element in block.elements:
                leaf_nodes = self._traverse_element(element, upstream)
                all_leaf_nodes.update(leaf_nodes)
            return all_leaf_nodes

        raise TypeError(f"Unsupported execution block type: {type(block)}")

    def _traverse_element(
        self, element, upstream: Iterable[str]
    ) -> Set[str]:
        if isinstance(element, ReasoningNode):
            node_id = element.id
            if node_id not in self._encounter_order:
                self._encounter_order.append(node_id)
            self._dependencies[node_id].update(upstream)
            return {node_id}

        if isinstance(element, BLOCK_TYPES):
            return self._traverse_block(element, upstream)

        raise TypeError(f"Unsupported reasoning element type: {type(element)}")
