import json
from typing import Dict, Any, Optional, List

from mmw_infra.common.dependencies import (
    logging,
    LANGCHAIN_CORE_AVAILABLE,
    BasePromptTemplate,
)
from mmw_infra.common.interfaces import DynamicPromptBuilderInterface, InfrastructureServices
from mmw_infra.execution.execution_states import ChassisState


class PromptBuildingError(Exception):
    """Raised when prompt construction fails due to missing context."""


class DynamicPromptBuilder(DynamicPromptBuilderInterface):
    """
    Prepares input variables for LangChain prompt templates by merging direct inputs,
    optimization hints, and contextual data sourced from LTM snapshots.
    """

    OPTIMIZATION_HINT_VAR = "OPTIMIZATION_HINT"

    def __init__(self, infra: InfrastructureServices):
        self.infra = infra
        self.logger = logging.getLogger("DynamicPromptBuilder")
        if not LANGCHAIN_CORE_AVAILABLE:
            self.logger.warning(
                "DynamicPromptBuilder initialized without LangChain Core. Functionality limited."
            )

    async def prepare_inputs(
        self, template: BasePromptTemplate, state: ChassisState
    ) -> Dict[str, Any]:
        prompt_vars = dict(state.get("inputs", {}))
        self._inject_optimization_hint(template, state, prompt_vars)
        await self._inject_ltm_context(template, state, prompt_vars)
        self._validate_inputs(template, prompt_vars)
        return prompt_vars

    def _inject_optimization_hint(
        self,
        template: BasePromptTemplate,
        state: ChassisState,
        prompt_vars: Dict[str, Any],
    ) -> None:
        template_vars = getattr(template, "input_variables", [])
        if self.OPTIMIZATION_HINT_VAR not in template_vars:
            return

        hint = state.get("optimization_hint")
        prompt_vars[self.OPTIMIZATION_HINT_VAR] = (
            f"\n[SYSTEM OPTIMIZATION HINT]\n{hint}\n[/SYSTEM OPTIMIZATION HINT]\n"
            if hint
            else ""
        )

    async def _inject_ltm_context(
        self,
        template: BasePromptTemplate,
        state: ChassisState,
        prompt_vars: Dict[str, Any],
    ) -> None:
        ltm_manifest = state.get("ltm_snapshot_manifest", {})
        if not ltm_manifest:
            return

        template_vars = getattr(template, "input_variables", [])
        required_keys = [
            var for var in template_vars if var in ltm_manifest and var not in prompt_vars
        ]
        if not required_keys:
            return

        artifact_ids = [ltm_manifest[key] for key in required_keys]
        fetched = await self.infra.csms.get_artifacts_by_ids(artifact_ids)

        for key in required_keys:
            artifact_id = ltm_manifest[key]
            artifact = fetched.get(artifact_id)
            if not artifact:
                self.logger.error(
                    "LTM artifact %s (key %s) missing from store.", artifact_id, key
                )
                raise PromptBuildingError(f"Missing LTM context artifact: {key}")

            try:
                prompt_vars[key] = self._deserialize_artifact_data(artifact.data)
            except json.JSONDecodeError as exc:
                self.logger.error(
                    "Failed to deserialize LTM artifact %s for key %s.", artifact_id, key
                )
                raise PromptBuildingError(
                    f"LTM context deserialization failed for key: {key}"
                ) from exc

    @staticmethod
    def _deserialize_artifact_data(data: Any) -> Any:
        if isinstance(data, str):
            return json.loads(data)
        return data

    def _validate_inputs(
        self, template: BasePromptTemplate, prompt_vars: Dict[str, Any]
    ) -> None:
        required_vars = set(getattr(template, "input_variables", []))
        available_vars = set(prompt_vars.keys())
        missing = required_vars - available_vars
        if missing:
            self.logger.error(
                "Prompt input validation failed; missing variables: %s", missing
            )
            raise PromptBuildingError(
                f"Missing required prompt variables: {sorted(missing)}"
            )

