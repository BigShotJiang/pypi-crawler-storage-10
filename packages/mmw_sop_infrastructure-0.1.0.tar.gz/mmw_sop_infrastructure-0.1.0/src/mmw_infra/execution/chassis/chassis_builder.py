"""
Builder for the Chassis LangGraph subgraph.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Optional, Type

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import AbstractBLE, ChassisBuilderInterface, InfrastructureServices
from mmw_infra.execution.aac.automation_controller import AdaptiveAutomationController
from mmw_infra.execution.chassis.chassis_nodes import ChassisNodes
from mmw_infra.execution.dynamic_prompt_builder import DynamicPromptBuilder
from mmw_infra.execution.execution_states import ChassisState
from mmw_infra.models.execution_state import ExecutionStatus
from mmw_infra.models.sop_schema import WorkflowStep


class _ChassisRunnable:
    """
    Minimal asynchronous runnable that executes the chassis lifecycle sequentially.
    Provided to mimic LangGraph's compiled graph API (`ainvoke`).
    """

    def __init__(self, nodes: ChassisNodes):
        self.nodes = nodes
        self.logger = logging.getLogger("ChassisRunnable")

    async def ainvoke(
        self,
        initial_state: ChassisState,
        config: Optional[Dict[str, Any]] = None,
    ) -> ChassisState:
        state: ChassisState = deepcopy(initial_state)

        phase_methods = [
            self.nodes.entry_phase,
            self.nodes.execution_phase,
            self.nodes.interaction_phase,
            self.nodes.exit_phase,
        ]

        for phase in phase_methods:
            updates = await phase(state)
            state.update(updates)
            if state.get("status") in (ExecutionStatus.FAILED, ExecutionStatus.PAUSED_HITL):
                break

        return state

    # LangChain `Runnable` compatibility layer
    async def ainvoke_with_config(
        self, initial_state: ChassisState, config: Optional[Dict[str, Any]] = None
    ) -> ChassisState:
        return await self.ainvoke(initial_state, config=config)


class ChassisBuilder(ChassisBuilderInterface):
    """
    Constructs the chassis subgraph runnable for a given workflow step.
    """

    def __init__(self, infra: InfrastructureServices):
        self.infra = infra
        self.logger = logging.getLogger("ChassisBuilder")

        # Ensure the infra bundle exposes a prompt builder (required by BLEs).
        if not getattr(infra, "prompt_builder", None):
            setattr(self.infra, "prompt_builder", DynamicPromptBuilder(self.infra))

    def build_subgraph(
        self, step_definition: WorkflowStep, ble_class: Type[AbstractBLE]
    ) -> _ChassisRunnable:
        self.logger.info(
            "Building chassis subgraph for step %s using BLE %s.",
            step_definition.id,
            ble_class.__name__,
        )

        ble_instance = ble_class(step_definition, self.infra)
        aac = AdaptiveAutomationController(self.infra.autonomy_service)
        chassis_nodes = ChassisNodes(self.infra, ble_instance, aac)
        return _ChassisRunnable(chassis_nodes)
