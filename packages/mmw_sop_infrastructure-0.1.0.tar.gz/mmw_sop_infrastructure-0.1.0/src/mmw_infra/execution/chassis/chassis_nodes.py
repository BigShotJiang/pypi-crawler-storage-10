"""
Lifecycle nodes for the Chassis subgraph.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from uuid import UUID

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import (
    AbstractBLE,
    InfrastructureServices,
)
from mmw_infra.execution.aac.automation_controller import AdaptiveAutomationController
from mmw_infra.execution.execution_states import ChassisState, ReasoningGraphState
from mmw_infra.execution.orchestrator.execution_orchestrator import ExecutionOrchestrator
from mmw_infra.models.execution_state import (
    ExecutionNode,
    ExecutionStatus,
    LTM_Artifact,
    LTM_Snapshot,
)


class ChassisNodes:
    """
    Implements the lifecycle phases for a workflow step:
    - entry: gather context and prepare inputs
    - execution: invoke the reasoning graph orchestrator
    - interaction: currently a pass-through (AAC is handled inside execution)
    - exit: persist outputs and snapshots
    """

    def __init__(
        self,
        infra: InfrastructureServices,
        ble_instance: AbstractBLE,
        aac_instance: AdaptiveAutomationController,
    ) -> None:
        self.infra = infra
        self.ble = ble_instance
        self.aac = aac_instance
        self.orchestrator = ExecutionOrchestrator(ble_instance, aac_instance)
        self.logger = logging.getLogger("Chassis")

    # ------------------------------------------------------------------ #
    # Entry Phase
    # ------------------------------------------------------------------ #

    async def entry_phase(self, state: ChassisState) -> Dict[str, Any]:
        """
        Loads run configuration (autonomy profile, optimisation hints) and
        prepares inputs by fetching artifacts from LTM.
        """
        self.logger.info(
            "--- [ENTRY PHASE] Step %s (Run %s) ---",
            state["step_definition"].id,
            state["run_id"],
        )
        updates: Dict[str, Any] = {}
        run_id = state["run_id"]
        step_def = state["step_definition"]

        # Ensure an autonomy profile is available.
        try:
            profile = self.infra.autonomy_service.get_active_profile(run_id)
        except Exception:  # Profile not activated yet
            self.infra.autonomy_service.activate_profile_for_run(run_id)
            profile = self.infra.autonomy_service.get_active_profile(run_id)
        updates["autonomy_profile"] = profile

        # Pull optimisation hint for this step/problem type.
        try:
            problem_type = state.get("problem_type")
            hint = self.infra.optimization_service.get_optimization_hint(
                problem_type, step_def.id
            )
        except Exception as exc:  # pragma: no cover - defensive logging
            self.logger.error("Failed to resolve optimisation hint: %s", exc)
            hint = None
        updates["optimization_hint"] = hint

        # Fetch input artifacts referenced by the GWO manifest.
        artifact_map = state.get("input_artifact_map", {})
        if artifact_map:
            fetched = await self.infra.csms.get_artifacts_by_ids(artifact_map.values())
            resolved_inputs: Dict[str, Any] = {}
            for port_name, artifact_id in artifact_map.items():
                artifact = fetched.get(artifact_id)
                if not artifact:
                    raise RuntimeError(
                        f"LTM artifact {artifact_id} for port '{port_name}' not found."
                    )
                data = artifact.data
                if isinstance(data, str):
                    try:
                        resolved_inputs[port_name] = json.loads(data)
                    except json.JSONDecodeError:
                        resolved_inputs[port_name] = data
                else:
                    resolved_inputs[port_name] = data
            updates["inputs"] = resolved_inputs

        # Register the execution node with the timeline.
        timeline = self.infra.timeline_service
        execution_node = ExecutionNode(
            run_id=run_id,
            blueprint_node_id=state["blueprint_node_id"],
            step_id=step_def.id,
            status=ExecutionStatus.RUNNING,
        )
        timeline.add_execution_node(execution_node)
        updates["execution_node_id"] = execution_node.execution_node_id
        updates["status"] = ExecutionStatus.RUNNING
        updates.setdefault("interaction_history", [])
        updates.setdefault("pending_interactions", [])
        return updates

    # ------------------------------------------------------------------ #
    # Execution Phase
    # ------------------------------------------------------------------ #

    async def execution_phase(self, state: ChassisState) -> Dict[str, Any]:
        """
        Compiles and executes the step's reasoning graph using the orchestrator.
        """
        self.logger.info(
            "--- [EXECUTION PHASE] Step %s ---", state["step_definition"].id
        )

        reasoning_state: ReasoningGraphState = {
            "chassis_context": dict(state),
            "node_results": {},
            "completed_nodes": [],
            "pending_interactions": [],
            "interaction_history": [],
            "status": ExecutionStatus.RUNNING,
            "error_message": None,
        }

        compiled = self.orchestrator.compile(state["step_definition"])
        config = {"configurable": {"thread_id": str(state["run_id"])}}

        final_state = await compiled.ainvoke(reasoning_state, config=config)
        updates: Dict[str, Any] = {
            "execution_results": final_state.get("node_results", {}),
            "pending_interactions": final_state.get("pending_interactions", []),
            "interaction_history": final_state.get("interaction_history", []),
            "status": final_state.get("status", ExecutionStatus.COMPLETED),
        }

        if "outputs" not in updates:
            updates["outputs"] = final_state.get("node_results", {})

        if final_state.get("error_message"):
            updates["error_message"] = final_state["error_message"]

        return updates

    # ------------------------------------------------------------------ #
    # Interaction Phase
    # ------------------------------------------------------------------ #

    async def interaction_phase(self, state: ChassisState) -> Dict[str, Any]:
        """
        Interaction handling is orchestrated by the AAC during the execution phase.
        The interaction phase therefore simply preserves the current state.
        """
        return {
            "pending_interactions": state.get("pending_interactions", []),
            "interaction_history": state.get("interaction_history", []),
            "status": state.get("status", ExecutionStatus.RUNNING),
        }

    # ------------------------------------------------------------------ #
    # Exit Phase
    # ------------------------------------------------------------------ #

    async def exit_phase(self, state: ChassisState) -> Dict[str, Any]:
        """
        Persists outputs to Long-Term Memory, records a snapshot, and updates the
        timeline entry for this execution node.
        """
        self.logger.info(
            "--- [EXIT PHASE] Step %s ---", state["step_definition"].id
        )
        outputs = state.get("outputs") or {}
        output_manifest: Dict[str, UUID] = {}

        if outputs:
            for port_name, value in outputs.items():
                if isinstance(value, (dict, list, int, float, bool)) or value is None:
                    serialized = json.dumps(value)
                    data_type = type(value).__name__
                else:
                    serialized = json.dumps(value, default=str)
                    data_type = type(value).__name__

                artifact = LTM_Artifact(
                    run_id=state["run_id"],
                    producer_step_id=state["step_definition"].id,
                    producer_execution_node_id=state["execution_node_id"],
                    port_name=port_name,
                    data_type_hint=data_type,
                    data=serialized,
                )
                self.infra.csms.save_artifact(artifact)
                output_manifest[port_name] = artifact.artifact_id

            snapshot = LTM_Snapshot(
                run_id=state["run_id"],
                associated_execution_node_id=state["execution_node_id"],
                artifact_manifest=output_manifest,
            )
            self.infra.csms.save_snapshot(snapshot)
            ltm_snapshot_id = snapshot.snapshot_id
        else:
            ltm_snapshot_id = None

        # Update execution node in the timeline.
        if state.get("execution_node_id"):
            self.infra.timeline_service.update_execution_node(
                state["execution_node_id"],
                status=state.get("status", ExecutionStatus.COMPLETED),
                ltm_snapshot_id=ltm_snapshot_id,
                timestamp_end=datetime.now(timezone.utc),
            )

        return {
            "output_artifact_map": output_manifest,
            "ltm_snapshot_manifest": output_manifest,
        }
