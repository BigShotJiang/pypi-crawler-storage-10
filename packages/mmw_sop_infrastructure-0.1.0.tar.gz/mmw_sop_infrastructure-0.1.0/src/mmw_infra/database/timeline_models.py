from uuid import uuid4
from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    String,
    DateTime,
    JSON,
    Boolean,
    Table,
    ForeignKey,
    event,
)
from sqlalchemy.orm import declarative_base, relationship

from mmw_infra.common.utils import GUID

Base = declarative_base()


class ExecutionRunDB(Base):
    __tablename__ = "execution_runs"

    run_id = Column(GUID, primary_key=True, default=uuid4)
    blueprint_id = Column(String(100), nullable=False)
    timestamp_start = Column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    timestamp_end = Column(DateTime(timezone=True))
    status = Column(String(50), nullable=False)
    problem_type = Column(String(100), nullable=False)
    active_autonomy_profile_id = Column(GUID, nullable=False)
    current_timeline_head_id = Column(
        GUID, ForeignKey("execution_nodes.execution_node_id"), nullable=True
    )


node_predecessors = Table(
    "node_predecessors",
    Base.metadata,
    Column(
        "node_id",
        GUID,
        ForeignKey("execution_nodes.execution_node_id"),
        primary_key=True,
    ),
    Column(
        "predecessor_id",
        GUID,
        ForeignKey("execution_nodes.execution_node_id"),
        primary_key=True,
    ),
)


class ExecutionNodeDB(Base):
    __tablename__ = "execution_nodes"

    execution_node_id = Column(GUID, primary_key=True, default=uuid4)
    run_id = Column(
        GUID, ForeignKey("execution_runs.run_id"), nullable=False, index=True
    )
    blueprint_node_id = Column(String(100), nullable=False)
    step_id = Column(String(50), nullable=False)
    timestamp_start = Column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    timestamp_end = Column(DateTime(timezone=True))
    status = Column(String(50), nullable=False)

    predecessors = relationship(
        "ExecutionNodeDB",
        secondary=node_predecessors,
        primaryjoin=(execution_node_id == node_predecessors.c.node_id),
        secondaryjoin=(execution_node_id == node_predecessors.c.predecessor_id),
        backref="successors",
    )

    ltm_snapshot_id = Column(GUID, nullable=True)
    validity_status = Column(String(50), nullable=False)
    input_lineage = Column(JSON, nullable=False)
    is_active_timeline = Column(Boolean, nullable=False, index=True)
    parent_revision_id = Column(
        GUID, ForeignKey("execution_nodes.execution_node_id"), nullable=True
    )

