"""
MMW SOP Infrastructure package.
"""

from pathlib import Path

__all__ = ["__version__", "get_optimization_kb_path"]

__version__ = "0.1.0"

_PACKAGE_ROOT = Path(__file__).resolve().parent
_KB_RELATIVE_PATH = Path("config") / "data" / "optimization_kb.yaml"


def get_optimization_kb_path() -> str:
    """Return the default optimisation knowledge base resource path."""
    return str((_PACKAGE_ROOT / _KB_RELATIVE_PATH).resolve())
