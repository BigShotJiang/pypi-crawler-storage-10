from typing import Dict, List
from uuid import UUID

from mmw_infra.common.dependencies import logging, nx, Session
from mmw_infra.common.interfaces import DTIAServiceInterface, TimelineServiceInterface
from mmw_infra.models.execution_state import ExecutionNode, ValidityStatus


class DTIAService(DTIAServiceInterface):
    """
    Dependency Tracking & Impact Analysis Service.
    Integrates Tasks 8, 9, and 10 into a cohesive implementation.
    """

    def __init__(self, timeline_service: TimelineServiceInterface):
        self.timeline_service = timeline_service
        self._dag_cache: Dict[UUID, nx.DiGraph] = {}
        logging.info("DTIAService initialized.")

    def invalidate_cache(self, run_id: UUID) -> None:
        if run_id in self._dag_cache:
            del self._dag_cache[run_id]
            logging.debug("DTIAService DAG cache invalidated for run %s.", run_id)

    def register_data_lineage(self, node: ExecutionNode) -> None:
        if node.is_active_timeline:
            self.invalidate_cache(node.run_id)

    def _build_active_dag(self, run_id: UUID) -> nx.DiGraph:
        logging.info("DTIAService: rebuilding active DAG for run %s.", run_id)
        active_timeline = self.timeline_service.get_active_timeline(run_id)
        graph = nx.DiGraph()
        active_node_ids = {node.execution_node_id for node in active_timeline}

        for node in active_timeline:
            graph.add_node(node.execution_node_id)
            for link in node.input_lineage:
                if link.source_execution_node_id in active_node_ids:
                    graph.add_edge(link.source_execution_node_id, node.execution_node_id)

        return graph

    def get_active_dag(self, run_id: UUID) -> nx.DiGraph:
        if run_id not in self._dag_cache:
            self._dag_cache[run_id] = self._build_active_dag(run_id)
        return self._dag_cache[run_id]

    def process_timeline_intervention(
        self,
        run_id: UUID,
        intervention_node_id: UUID,
        deactivated_node_ids: List[UUID],
        db_session: Session,
    ) -> None:
        logging.info(
            "DTIAService analyzing impact for run %s within active transaction.", run_id
        )

        if not deactivated_node_ids:
            return

        validity_updates: Dict[UUID, ValidityStatus] = {}

        if intervention_node_id in deactivated_node_ids:
            validity_updates[intervention_node_id] = ValidityStatus.INVALIDATED

        for node_id in deactivated_node_ids:
            validity_updates.setdefault(node_id, ValidityStatus.AFFECTED)

        try:
            self.timeline_service.bulk_update_node_validity(
                validity_updates, db_session=db_session
            )
            logging.info(
                "DTIAService queued validity updates for %d nodes.", len(validity_updates)
            )
        except Exception as exc:
            logging.error(
                "DTIAService failed to persist validity updates via TimelineService: %s",
                exc,
            )
            raise RuntimeError("Failed to persist impact analysis results.") from exc

