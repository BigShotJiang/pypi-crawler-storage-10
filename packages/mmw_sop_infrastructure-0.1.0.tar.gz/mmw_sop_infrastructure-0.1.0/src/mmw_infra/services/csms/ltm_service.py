import json
from typing import Dict, Optional
from uuid import UUID

from mmw_infra.common.dependencies import (
    SQLALCHEMY_AVAILABLE,
    logging,
    create_engine,
    sessionmaker,
    Session,
)
from mmw_infra.database.ltm_models import Base, ArtifactDB, SnapshotDB
from mmw_infra.models.execution_state import LTM_Artifact, LTM_Snapshot


class LTMService:
    """
    Service for managing Long-Term Memory persistence using SQLAlchemy.
    """

    def __init__(self, db_url: str = "sqlite:///mmw_ltm.db"):
        if not SQLALCHEMY_AVAILABLE:
            logging.warning(
                "LTMService initialized but SQLAlchemy is unavailable. Persistence disabled."
            )
            self.engine = None
            self.SessionLocal = None
            return

        try:
            connect_args = {}
            if "sqlite" in db_url:
                connect_args = {"check_same_thread": False}

            self.engine = create_engine(db_url, connect_args=connect_args)
            self.SessionLocal = sessionmaker(
                autocommit=False, autoflush=False, bind=self.engine
            )
            self._init_db()
        except Exception as exc:  # pragma: no cover - defensive logging
            logging.error(f"Failed to initialize LTM database connection: {exc}")
            self.engine = None
            self.SessionLocal = None

    def _get_db(self) -> Session:
        if not self.SessionLocal:
            raise RuntimeError("Database not initialized or SQLAlchemy unavailable.")
        return self.SessionLocal()

    def _init_db(self) -> None:
        if self.engine and SQLALCHEMY_AVAILABLE:
            try:
                Base.metadata.create_all(bind=self.engine)
                logging.info("LTM database initialized.")
            except Exception as exc:  # pragma: no cover - defensive logging
                logging.error(f"Failed to create LTM database tables: {exc}")

    def save_artifact(self, artifact: LTM_Artifact) -> None:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return

        data_payload = artifact.data
        if not isinstance(data_payload, str):
            try:
                data_payload = json.dumps(data_payload)
            except TypeError as exc:
                logging.error(
                    "Failed to serialize artifact data for storage: %s",
                    type(data_payload),
                )
                raise exc

        db_artifact = ArtifactDB(
            artifact_id=artifact.artifact_id,
            run_id=artifact.run_id,
            producer_step_id=artifact.producer_step_id,
            producer_execution_node_id=artifact.producer_execution_node_id,
            port_name=artifact.port_name,
            data_type_hint=artifact.data_type_hint,
            data=data_payload,
            timestamp_created=artifact.timestamp_created,
        )
        db = self._get_db()
        try:
            db.add(db_artifact)
            db.commit()
            logging.debug("Artifact %s saved to LTM.", artifact.artifact_id)
        except Exception as exc:
            db.rollback()
            logging.error("Failed to save artifact %s: %s", artifact.artifact_id, exc)
            raise
        finally:
            db.close()

    def get_artifact(self, artifact_id: UUID) -> Optional[LTM_Artifact]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return None

        db = self._get_db()
        try:
            db_artifact = (
                db.query(ArtifactDB)
                .filter(ArtifactDB.artifact_id == artifact_id)
                .first()
            )
            if db_artifact:
                return LTM_Artifact(
                    artifact_id=db_artifact.artifact_id,
                    run_id=db_artifact.run_id,
                    producer_step_id=db_artifact.producer_step_id,
                    producer_execution_node_id=db_artifact.producer_execution_node_id,
                    port_name=db_artifact.port_name,
                    data_type_hint=db_artifact.data_type_hint,
                    data=db_artifact.data,
                    timestamp_created=db_artifact.timestamp_created,
                )
            return None
        except Exception as exc:
            logging.error("Failed to retrieve artifact %s: %s", artifact_id, exc)
            raise
        finally:
            db.close()

    def save_snapshot(self, snapshot: LTM_Snapshot) -> None:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return

        db_snapshot = SnapshotDB(
            snapshot_id=snapshot.snapshot_id,
            run_id=snapshot.run_id,
            associated_execution_node_id=snapshot.associated_execution_node_id,
            artifact_manifest={
                key: str(value) for key, value in snapshot.artifact_manifest.items()
            },
        )
        db = self._get_db()
        try:
            db.add(db_snapshot)
            db.commit()
            logging.debug("Snapshot %s saved to LTM.", snapshot.snapshot_id)
        except Exception as exc:
            db.rollback()
            logging.error("Failed to save snapshot %s: %s", snapshot.snapshot_id, exc)
            raise
        finally:
            db.close()

    def get_snapshot(self, snapshot_id: UUID) -> Optional[LTM_Snapshot]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return None

        db = self._get_db()
        try:
            db_snapshot = (
                db.query(SnapshotDB)
                .filter(SnapshotDB.snapshot_id == snapshot_id)
                .first()
            )
            if db_snapshot:
                manifest_data = db_snapshot.artifact_manifest
                if isinstance(manifest_data, str):
                    try:
                        manifest_data = json.loads(manifest_data)
                    except json.JSONDecodeError as exc:
                        logging.error(
                            "Failed to decode JSON manifest for snapshot %s",
                            snapshot_id,
                        )
                        raise exc

                return LTM_Snapshot(
                    snapshot_id=db_snapshot.snapshot_id,
                    run_id=db_snapshot.run_id,
                    associated_execution_node_id=db_snapshot.associated_execution_node_id,
                    artifact_manifest={
                        key: UUID(value) for key, value in manifest_data.items()
                    },
                )
            return None
        except Exception as exc:
            logging.error("Failed to retrieve snapshot %s: %s", snapshot_id, exc)
            raise
        finally:
            db.close()

    def reconstruct_ltm_from_snapshot(
        self, snapshot_id: UUID
    ) -> Dict[str, LTM_Artifact]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return {}

        snapshot = self.get_snapshot(snapshot_id)
        if not snapshot:
            raise ValueError(f"Snapshot {snapshot_id} not found.")

        artifact_ids = list(snapshot.artifact_manifest.values())
        if not artifact_ids:
            return {}

        db = self._get_db()
        try:
            artifacts = (
                db.query(ArtifactDB)
                .filter(ArtifactDB.artifact_id.in_(artifact_ids))
                .all()
            )
            artifact_map = {artifact.artifact_id: artifact for artifact in artifacts}
            reconstructed_state: Dict[str, LTM_Artifact] = {}

            for logical_name, artifact_id in snapshot.artifact_manifest.items():
                db_artifact = artifact_map.get(artifact_id)
                if not db_artifact:
                    logging.error(
                        "Artifact %s referenced in snapshot %s not found in LTM.",
                        artifact_id,
                        snapshot_id,
                    )
                    raise RuntimeError(
                        f"Missing artifact {artifact_id} during LTM reconstruction."
                    )

                reconstructed_state[logical_name] = LTM_Artifact(
                    artifact_id=db_artifact.artifact_id,
                    run_id=db_artifact.run_id,
                    producer_step_id=db_artifact.producer_step_id,
                    producer_execution_node_id=db_artifact.producer_execution_node_id,
                    port_name=db_artifact.port_name,
                    data_type_hint=db_artifact.data_type_hint,
                    data=db_artifact.data,
                    timestamp_created=db_artifact.timestamp_created,
                )

            return reconstructed_state
        except Exception as exc:
            logging.error(
                "Failed during LTM reconstruction for snapshot %s: %s",
                snapshot_id,
                exc,
            )
            raise
        finally:
            db.close()

