import asyncio
from typing import Dict, Iterable, Optional
from uuid import UUID

from mmw_infra.common.dependencies import logging
from mmw_infra.models.execution_state import LTM_Artifact, LTM_Snapshot
from .ltm_service import LTMService
from .checkpoint_service import RedisCheckpointSaver


class CSMSService:
    """
    Aggregates Long-Term Memory and checkpointing capabilities into a unified interface.
    """

    def __init__(
        self, ltm_service: LTMService, checkpoint_saver: Optional[RedisCheckpointSaver]
    ):
        self.ltm = ltm_service
        self.checkpointer = checkpoint_saver
        logging.info("CSMSService initialized.")

    def save_artifact(self, artifact: LTM_Artifact) -> None:
        self.ltm.save_artifact(artifact)

    def save_snapshot(self, snapshot: LTM_Snapshot) -> None:
        self.ltm.save_snapshot(snapshot)

    def get_artifact(self, artifact_id: UUID) -> Optional[LTM_Artifact]:
        return self.ltm.get_artifact(artifact_id)

    async def get_artifacts_by_ids(
        self, artifact_ids: Iterable[UUID]
    ) -> Dict[UUID, LTM_Artifact]:
        def _fetch() -> Dict[UUID, LTM_Artifact]:
            results: Dict[UUID, LTM_Artifact] = {}
            for artifact_id in artifact_ids:
                artifact = self.ltm.get_artifact(artifact_id)
                if artifact:
                    results[artifact_id] = artifact
            return results

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, _fetch)

    def reconstruct_ltm_from_snapshot(
        self, snapshot_id: UUID
    ) -> Dict[str, LTM_Artifact]:
        return self.ltm.reconstruct_ltm_from_snapshot(snapshot_id)

