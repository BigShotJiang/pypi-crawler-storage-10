import json
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Optional, List, Tuple
from uuid import UUID

from mmw_infra.common.dependencies import (
    SQLALCHEMY_AVAILABLE,
    logging,
    create_engine,
    sessionmaker,
    Session,
    relationship,
    joinedload,
    event,
    SQLAlchemyError,
    bindparam,
)
from mmw_infra.common.interfaces import DTIAServiceInterface, TimelineServiceInterface
from mmw_infra.database.timeline_models import (
    Base,
    ExecutionRunDB,
    ExecutionNodeDB,
)
from mmw_infra.models.execution_state import (
    ExecutionRun,
    ExecutionNode,
    ExecutionStatus,
    ValidityStatus,
    DataLineageLink,
)


def _enum_to_value(value):
    return value.value if isinstance(value, Enum) else value


class TimelineService(TimelineServiceInterface):
    """
    Central service for managing the Mutable Execution Timeline.
    Integrates the Task 7 core design with Task 10's transactional DTIAS workflow.
    """

    def __init__(self, db_url: str = "sqlite:///mmw_timeline.db"):
        self.engine = None
        self.SessionLocal = None
        self.dtias: Optional[DTIAServiceInterface] = None

        if not SQLALCHEMY_AVAILABLE:
            logging.warning(
                "TimelineService initialized but SQLAlchemy is unavailable. Persistence disabled."
            )
            return

        try:
            connect_args = {"check_same_thread": False} if "sqlite" in db_url else {}
            self.engine = create_engine(db_url, connect_args=connect_args)
            self.SessionLocal = sessionmaker(
                autocommit=False, autoflush=False, bind=self.engine
            )

            if "sqlite" in db_url:

                @event.listens_for(self.engine, "connect")
                def set_sqlite_pragma(dbapi_connection, connection_record):
                    cursor = dbapi_connection.cursor()
                    cursor.execute("PRAGMA foreign_keys=ON")
                    cursor.close()

            self._init_db()
        except Exception as exc:  # pragma: no cover - defensive logging
            logging.error(f"Failed to initialize Timeline database connection: {exc}")
            self.engine = None
            self.SessionLocal = None

    def set_dtias(self, dtias_service: DTIAServiceInterface) -> None:
        """Injects the DTIAS dependency after initialization (resolves circular dependency)."""
        self.dtias = dtias_service
        logging.info("DTIAService injected into TimelineService.")

    def _get_db(self) -> Session:
        if not self.SessionLocal:
            raise RuntimeError("Database not initialized or SQLAlchemy unavailable.")
        return self.SessionLocal()

    def _init_db(self) -> None:
        if self.engine and SQLALCHEMY_AVAILABLE:
            try:
                Base.metadata.create_all(bind=self.engine)
                logging.info("Timeline database initialized (tables ensured).")
            except Exception as exc:  # pragma: no cover - defensive logging
                logging.error(f"Failed to create Timeline database tables: {exc}")

    def _db_node_to_pydantic(self, db_node: ExecutionNodeDB) -> ExecutionNode:
        """Converts a SQLAlchemy ExecutionNodeDB instance into the Pydantic ExecutionNode."""
        lineage_data = db_node.input_lineage
        if isinstance(lineage_data, str):
            try:
                lineage_data = json.loads(lineage_data)
            except json.JSONDecodeError as exc:
                logging.error(
                    "Failed to decode JSON lineage for node %s: %s",
                    db_node.execution_node_id,
                    exc,
                )
                raise

        lineage: List[DataLineageLink] = []
        for item in lineage_data or []:
            try:
                item["source_artifact_id"] = UUID(str(item.get("source_artifact_id")))
                item["source_execution_node_id"] = UUID(
                    str(item.get("source_execution_node_id"))
                )
                lineage.append(DataLineageLink(**item))
            except (ValueError, TypeError, KeyError) as exc:
                logging.error(
                    "Error reconstructing lineage link for node %s: %s | Data: %s",
                    db_node.execution_node_id,
                    exc,
                    item,
                )
                raise

        return ExecutionNode(
            execution_node_id=db_node.execution_node_id,
            run_id=db_node.run_id,
            blueprint_node_id=db_node.blueprint_node_id,
            step_id=db_node.step_id,
            timestamp_start=db_node.timestamp_start,
            timestamp_end=db_node.timestamp_end,
            status=ExecutionStatus(db_node.status),
            predecessor_execution_node_ids=[
                predecessor.execution_node_id for predecessor in db_node.predecessors
            ],
            ltm_snapshot_id=db_node.ltm_snapshot_id,
            validity_status=ValidityStatus(db_node.validity_status),
            input_lineage=lineage,
            is_active_timeline=db_node.is_active_timeline,
            parent_revision_id=db_node.parent_revision_id,
        )

    def start_run(self, run: ExecutionRun) -> ExecutionRun:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return run

        db_run = ExecutionRunDB(
            run_id=run.run_id,
            blueprint_id=run.blueprint_id,
            status=_enum_to_value(run.status),
            problem_type=run.problem_type,
            active_autonomy_profile_id=run.active_autonomy_profile_id,
            timestamp_start=run.timestamp_start,
        )

        db = self._get_db()
        try:
            db.add(db_run)
            db.commit()
            return run
        except SQLAlchemyError as exc:
            db.rollback()
            logging.error("Failed to persist execution run %s: %s", run.run_id, exc)
            raise
        finally:
            db.close()

    def get_run(self, run_id: UUID) -> Optional[ExecutionRun]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return None

        db = self._get_db()
        try:
            db_run = (
                db.query(ExecutionRunDB)
                .filter(ExecutionRunDB.run_id == run_id)
                .first()
            )
            if not db_run:
                return None
            return ExecutionRun(
                run_id=db_run.run_id,
                blueprint_id=db_run.blueprint_id,
                status=ExecutionStatus(db_run.status),
                problem_type=db_run.problem_type,
                active_autonomy_profile_id=db_run.active_autonomy_profile_id,
                current_timeline_head_id=db_run.current_timeline_head_id,
                timestamp_start=db_run.timestamp_start,
                timestamp_end=db_run.timestamp_end,
            )
        finally:
            db.close()

    def update_run_status(
        self, run_id: UUID, status: ExecutionStatus, head_id: Optional[UUID] = None
    ) -> None:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return

        db = self._get_db()
        try:
            db_run = (
                db.query(ExecutionRunDB)
                .filter(ExecutionRunDB.run_id == run_id)
                .first()
            )
            if not db_run:
                raise ValueError(f"Run ID {run_id} not found.")

            db_run.status = status.value
            if head_id:
                db_run.current_timeline_head_id = head_id
            if status in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED):
                db_run.timestamp_end = datetime.now(timezone.utc)
            db.commit()
        except SQLAlchemyError as exc:
            db.rollback()
            logging.error("Failed to update run %s: %s", run_id, exc)
            raise
        finally:
            db.close()

    def add_execution_node(self, node: ExecutionNode) -> ExecutionNode:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return node

        lineage_json: List[Dict[str, str]] = []
        for link in node.input_lineage:
            if hasattr(link, "model_dump"):
                dump = link.model_dump()
                dump["source_artifact_id"] = str(dump["source_artifact_id"])
                dump["source_execution_node_id"] = str(
                    dump["source_execution_node_id"]
                )
                lineage_json.append(dump)
            else:
                lineage_json.append(
                    {
                        "input_port_name": link.input_port_name,
                        "source_artifact_id": str(link.source_artifact_id),
                        "source_execution_node_id": str(
                            link.source_execution_node_id
                        ),
                    }
                )

        db_node = ExecutionNodeDB(
            execution_node_id=node.execution_node_id,
            run_id=node.run_id,
            blueprint_node_id=node.blueprint_node_id,
            step_id=node.step_id,
            status=_enum_to_value(node.status),
            validity_status=_enum_to_value(node.validity_status),
            input_lineage=lineage_json,
            is_active_timeline=node.is_active_timeline,
            parent_revision_id=node.parent_revision_id,
            timestamp_start=node.timestamp_start,
            timestamp_end=node.timestamp_end,
            ltm_snapshot_id=node.ltm_snapshot_id,
        )

        db = self._get_db()
        try:
            if node.predecessor_execution_node_ids:
                predecessors = (
                    db.query(ExecutionNodeDB)
                    .filter(
                        ExecutionNodeDB.execution_node_id.in_(
                            node.predecessor_execution_node_ids
                        )
                    )
                    .all()
                )
                if len(predecessors) != len(node.predecessor_execution_node_ids):
                    raise ValueError(
                        "One or more predecessor node IDs are invalid or missing."
                    )
                db_node.predecessors.extend(predecessors)

            db.add(db_node)
            db.flush()

            if node.is_active_timeline:
                run_db = (
                    db.query(ExecutionRunDB)
                    .filter(ExecutionRunDB.run_id == node.run_id)
                    .first()
                )
                if run_db:
                    run_db.current_timeline_head_id = node.execution_node_id

            if self.dtias:
                self.dtias.register_data_lineage(node)

            db.commit()
            return node
        except (SQLAlchemyError, ValueError) as exc:
            db.rollback()
            logging.error("Failed to add execution node %s: %s", node.execution_node_id, exc)
            raise
        finally:
            db.close()

    def update_execution_node(self, node_id: UUID, **updates) -> None:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return

        payload = updates.copy()
        status_val = payload.get("status")
        if status_val is not None:
            if isinstance(status_val, Enum):
                payload["status"] = status_val.value
            if payload["status"] in {
                ExecutionStatus.COMPLETED.value,
                ExecutionStatus.FAILED.value,
                ExecutionStatus.SKIPPED.value,
            }:
                payload.setdefault("timestamp_end", datetime.now(timezone.utc))

        validity_val = payload.get("validity_status")
        if isinstance(validity_val, Enum):
            payload["validity_status"] = validity_val.value

        db = self._get_db()
        try:
            result = (
                db.query(ExecutionNodeDB)
                .filter(ExecutionNodeDB.execution_node_id == node_id)
                .update(payload)
            )
            if result == 0 and payload:
                exists = (
                    db.query(ExecutionNodeDB.execution_node_id)
                    .filter(ExecutionNodeDB.execution_node_id == node_id)
                    .first()
                )
                if exists is None:
                    raise ValueError(f"Execution Node ID {node_id} not found.")
            db.commit()
        except SQLAlchemyError as exc:
            db.rollback()
            logging.error("Failed to update execution node %s: %s", node_id, exc)
            raise
        finally:
            db.close()

    def get_execution_node(self, node_id: UUID) -> Optional[ExecutionNode]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return None

        db = self._get_db()
        try:
            db_node = (
                db.query(ExecutionNodeDB)
                .options(joinedload(ExecutionNodeDB.predecessors))
                .filter(ExecutionNodeDB.execution_node_id == node_id)
                .first()
            )
            return self._db_node_to_pydantic(db_node) if db_node else None
        finally:
            db.close()

    def get_active_timeline(self, run_id: UUID) -> List[ExecutionNode]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            return []

        db = self._get_db()
        try:
            db_nodes = (
                db.query(ExecutionNodeDB)
                .options(joinedload(ExecutionNodeDB.predecessors))
                .filter(
                    ExecutionNodeDB.run_id == run_id,
                    ExecutionNodeDB.is_active_timeline.is_(True),
                )
                .order_by(ExecutionNodeDB.timestamp_start)
                .all()
            )
            return [self._db_node_to_pydantic(node) for node in db_nodes]
        finally:
            db.close()

    def bulk_update_node_validity(
        self,
        validity_updates: Dict[UUID, ValidityStatus],
        db_session: Optional[Session] = None,
    ) -> None:
        if not SQLALCHEMY_AVAILABLE or not self.engine or not validity_updates:
            return

        manage_transaction = db_session is None
        db = db_session if db_session else self._get_db()

        try:
            payload = [
                {
                    "node_id": node_id,
                    "status_val": status.value
                    if isinstance(status, Enum)
                    else status,
                }
                for node_id, status in validity_updates.items()
            ]

            stmt = (
                ExecutionNodeDB.__table__.update()
                .where(ExecutionNodeDB.execution_node_id == bindparam("node_id"))
                .values(validity_status=bindparam("status_val"))
            )
            db.execute(stmt, payload)

            if manage_transaction:
                db.commit()
                logging.info(
                    "TimelineService: Bulk validity update committed (self-managed)."
                )
            else:
                db.flush()
                logging.debug(
                    "TimelineService: Bulk validity update flushed (participating in transaction)."
                )
        except SQLAlchemyError as exc:
            if manage_transaction:
                db.rollback()
            logging.error("Error during bulk validity update: %s", exc)
            raise
        finally:
            if manage_transaction:
                db.close()

    def intervene_and_branch(
        self, run_id: UUID, intervention_node_id: UUID
    ) -> Tuple[Optional[ExecutionNode], List[UUID]]:
        if not SQLALCHEMY_AVAILABLE or not self.engine:
            raise RuntimeError("Timeline mutation requires SQLAlchemy.")

        db = self._get_db()
        nodes_to_deactivate_ids: List[UUID] = []
        resumption_head_pydantic: Optional[ExecutionNode] = None

        try:
            intervention_node = (
                db.query(ExecutionNodeDB)
                .options(
                    joinedload(ExecutionNodeDB.predecessors),
                    joinedload(ExecutionNodeDB.successors),
                )
                .filter(
                    ExecutionNodeDB.execution_node_id == intervention_node_id,
                    ExecutionNodeDB.run_id == run_id,
                )
                .first()
            )

            if not intervention_node:
                raise ValueError(f"Intervention node {intervention_node_id} not found.")

            resumption_head_db = None
            active_predecessors = [
                predecessor
                for predecessor in intervention_node.predecessors
                if predecessor.is_active_timeline
            ]
            if active_predecessors:

                def sort_key(node: ExecutionNodeDB):
                    return node.timestamp_end or datetime.max.replace(
                        tzinfo=timezone.utc
                    )

                resumption_head_db = sorted(
                    active_predecessors, key=sort_key, reverse=True
                )[0]

            stack = [intervention_node]
            visited = set()
            while stack:
                current = stack.pop()
                if current.execution_node_id in visited:
                    continue
                visited.add(current.execution_node_id)
                if current.is_active_timeline:
                    nodes_to_deactivate_ids.append(current.execution_node_id)
                    stack.extend(current.successors)

            if not nodes_to_deactivate_ids:
                db.commit()
                if self.dtias:
                    self.dtias.invalidate_cache(run_id)
                return (
                    self._db_node_to_pydantic(resumption_head_db)
                    if resumption_head_db
                    else None,
                    [],
                )

            db.query(ExecutionNodeDB).filter(
                ExecutionNodeDB.execution_node_id.in_(nodes_to_deactivate_ids)
            ).update({"is_active_timeline": False}, synchronize_session=False)

            run_db = (
                db.query(ExecutionRunDB).filter(ExecutionRunDB.run_id == run_id).first()
            )
            if run_db:
                run_db.current_timeline_head_id = (
                    resumption_head_db.execution_node_id
                    if resumption_head_db
                    else None
                )
                if run_db.status not in {
                    ExecutionStatus.RUNNING.value,
                    ExecutionStatus.PAUSED_HITL.value,
                }:
                    run_db.status = ExecutionStatus.RUNNING.value

            if self.dtias:
                logging.info(
                    "TimelineService: invoking DTIAS impact analysis within transaction."
                )
                self.dtias.process_timeline_intervention(
                    run_id,
                    intervention_node_id,
                    nodes_to_deactivate_ids,
                    db_session=db,
                )

            db.commit()
            if self.dtias:
                self.dtias.invalidate_cache(run_id)

            if resumption_head_db:
                resumption_head_pydantic = self._db_node_to_pydantic(
                    resumption_head_db
                )

            return resumption_head_pydantic, nodes_to_deactivate_ids

        except Exception as exc:
            db.rollback()
            logging.error(
                "Error during timeline intervention at node %s: %s",
                intervention_node_id,
                exc,
            )
            raise
        finally:
            db.close()
