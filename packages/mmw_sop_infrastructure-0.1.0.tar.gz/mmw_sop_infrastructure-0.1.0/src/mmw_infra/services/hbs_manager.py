"""
In-memory HITL Backend Service (HBS) manager.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import UUID

from mmw_infra.common.dependencies import logging, RunnableConfig
from mmw_infra.common.interfaces import HBSInterface
from mmw_infra.models.hitl_schema import HITL_InteractionRecord, HITL_Output


class HBSManager(HBSInterface):
    """
    Minimal backend for storing pending HITL interactions. In a production deployment
    this would be backed by a database or message queue; for the reference
    implementation we keep it in memory.
    """

    def __init__(self) -> None:
        self._pending_by_run: Dict[UUID, Dict[str, HITL_InteractionRecord]] = defaultdict(dict)
        self.logger = logging.getLogger("HBS")

    async def queue_interaction(
        self, interaction: HITL_InteractionRecord, config: RunnableConfig
    ) -> None:
        run_id: Optional[UUID] = None
        if config:
            thread_id = config.get("configurable", {}).get("thread_id")
            if thread_id:
                try:
                    run_id = UUID(str(thread_id))
                except (TypeError, ValueError):
                    run_id = None
        if run_id is None:
            self.logger.warning(
                "Queued HITL interaction without run context: %s", interaction.interaction_id
            )
            return

        self._pending_by_run[run_id][interaction.interaction_id] = interaction
        self.logger.info(
            "Queued HITL interaction %s for run %s.",
            interaction.interaction_id,
            run_id,
        )

    async def resolve_interaction(
        self, interaction_id: UUID, human_input: HITL_Output
    ) -> None:
        for run_id, items in list(self._pending_by_run.items()):
            record = items.pop(str(interaction_id), None)
            if record:
                record.human_input = human_input
                now = datetime.now(timezone.utc)
                record.timestamp_end = record.timestamp_end or now
                record.timestamp_processed = (
                    record.timestamp_processed or record.timestamp_end
                )
                self.logger.info(
                    "Resolved HITL interaction %s for run %s.", interaction_id, run_id
                )
                if not items:
                    del self._pending_by_run[run_id]
                return
        self.logger.warning(
            "Attempted to resolve unknown HITL interaction %s.", interaction_id
        )

    async def list_pending(self, run_id: Optional[UUID] = None) -> List[Dict[str, str]]:
        if run_id:
            interactions = self._pending_by_run.get(run_id, {})
        else:
            interactions = {
                interaction_id: record
                for records in self._pending_by_run.values()
                for interaction_id, record in records.items()
            }

        payload: List[Dict[str, str]] = []
        for record in interactions.values():
            if hasattr(record, "model_dump"):
                payload.append(record.model_dump(mode="json"))
            else:
                payload.append(record.__dict__)
        return payload
