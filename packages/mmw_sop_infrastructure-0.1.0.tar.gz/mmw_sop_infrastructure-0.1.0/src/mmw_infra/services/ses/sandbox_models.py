from typing import Dict, Optional
from enum import Enum

from mmw_infra.common.dependencies import BaseModel, Field, ConfigDict, PYDANTIC_AVAILABLE


class SESResourceLimits(BaseModel):
    """Defines the resource constraints for sandbox execution."""

    timeout_seconds: int = Field(60, description="Maximum execution time.")
    memory_limit: str = Field("256m", description="Memory limit (e.g., '256m', '1g').")
    cpu_limit: float = Field(
        0.5, description="CPU limit (e.g., 0.5 for half a core, 1.0 for a full core)."
    )


class SESSecurityConfig(BaseModel):
    """Security hardening options for the sandbox."""

    network_disabled: bool = Field(True, description="Disable networking inside the container.")
    read_only_workdir: bool = Field(True, description="Mount the working directory as read-only.")
    drop_capabilities: bool = Field(True, description="Drop all Linux capabilities.")
    no_new_privileges: bool = Field(True, description="Prevent privilege escalation.")


class SESEnvironmentConfig(BaseModel):
    """Configuration for the sandbox environment."""

    image_name: str = Field("python:3.11-slim", description="Docker image used for execution.")
    container_user: Optional[str] = Field(
        None, description="User inside the container (defaults to image setting)."
    )
    workdir: str = Field("/app/sandbox", description="Working directory inside the container.")
    resources: SESResourceLimits = Field(default_factory=SESResourceLimits)
    security: SESSecurityConfig = Field(default_factory=SESSecurityConfig)


class SESExecutionStatus(str, Enum):
    SUCCESS = "Success"
    FAILED = "Failed (Non-zero exit code)"
    TIMEOUT = "Timeout"
    ERROR = "Error (Infrastructure/Internal)"


class SESExecutionResult(BaseModel):
    """Standardized result structure returned by the SES."""

    status: SESExecutionStatus
    exit_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    output_files: Dict[str, str] = Field(default_factory=dict)
    error_message: Optional[str] = None
    duration_seconds: Optional[float] = None

    if PYDANTIC_AVAILABLE:
        model_config = ConfigDict(use_enum_values=True)

