"""
Global Workflow Orchestrator façade.
"""
from __future__ import annotations

from typing import Dict, Optional, Type
from uuid import UUID

from mmw_infra.common.dependencies import logging
from mmw_infra.common.interfaces import (
    AbstractBLE,
    GWOInterface,
    HBSInterface,
    InfrastructureServices,
)
from mmw_infra.models.execution_state import ExecutionRun, ExecutionStatus
from mmw_infra.models.hitl_schema import HITL_Output
from mmw_infra.models.sop_schema import ArchitecturalBlueprint

from .gwo_core import (
    BLERegistry,
    BlueprintCompiler,
    CompiledBlueprint,
    GWOState,
)


class GlobalWorkflowOrchestrator(GWOInterface):
    """
    High-level orchestrator responsible for executing an ArchitecturalBlueprint.
    It coordinates chassis execution, handles HITL pauses, and persists timeline updates.
    """

    def __init__(
        self,
        infra: InfrastructureServices,
        chassis_builder,
        hbs_manager: Optional[HBSInterface] = None,
    ) -> None:
        self.infra = infra
        self.hbs = hbs_manager
        self.ble_registry = BLERegistry()
        self.compiler = BlueprintCompiler(chassis_builder, self.ble_registry, infra)
        self.blueprints: Dict[str, ArchitecturalBlueprint] = {}
        self._active_runs: Dict[UUID, Dict[str, object]] = {}
        self.logger = logging.getLogger("GWO")

    # ------------------------------------------------------------------ #
    # Registration helpers
    # ------------------------------------------------------------------ #

    def register_blueprint(
        self, blueprint: ArchitecturalBlueprint, blueprint_id: Optional[str] = None
    ) -> None:
        key = blueprint_id or blueprint.workflow_name
        self.blueprints[key] = blueprint

    def register_ble(self, step_id: str, ble_class: Type[AbstractBLE]) -> None:
        self.ble_registry.register(step_id, ble_class)

    # ------------------------------------------------------------------ #
    # Execution entry points
    # ------------------------------------------------------------------ #

    async def start_run(
        self,
        blueprint_id: str,
        run_id: UUID,
        problem_type: str,
        autonomy_profile_id: Optional[UUID] = None,
        config: Optional[Dict[str, object]] = None,
    ) -> Dict[str, object]:
        blueprint = self._resolve_blueprint(blueprint_id)

        if autonomy_profile_id:
            self.infra.autonomy_service.activate_profile_for_run(
                run_id, autonomy_profile_id
            )

        execution_run = ExecutionRun(
            run_id=run_id,
            blueprint_id=blueprint_id,
            status=ExecutionStatus.RUNNING,
            problem_type=problem_type,
            active_autonomy_profile_id=autonomy_profile_id
            or self.infra.autonomy_service.get_active_profile(run_id).profile_id,
        )
        self.infra.timeline_service.start_run(execution_run)

        compiled = self.compiler.compile(blueprint)
        order = compiled.execution_order()

        gwo_state: GWOState = GWOState(
            run_id=run_id,
            problem_type=problem_type,
            blueprint=blueprint,
            status=ExecutionStatus.RUNNING,
            error_message=None,
            node_outputs={},
            ltm_snapshot_manifest={},
            pending_interactions=[],
            interaction_history=[],
        )

        result = await self._execute_until_pause_or_end(
            run_id, compiled, order, gwo_state, start_index=0
        )
        return result

    async def resume_after_hitl(
        self,
        run_id: UUID,
        interaction_id: UUID,
        human_input: HITL_Output,
        config: Optional[Dict[str, object]] = None,
    ) -> Dict[str, object]:
        active = self._active_runs.get(run_id)
        if not active:
            raise RuntimeError(f"Run {run_id} is not awaiting HITL input.")

        if self.hbs:
            await self.hbs.resolve_interaction(interaction_id, human_input)

        gwo_state: GWOState = active["state"]  # type: ignore[assignment]
        pending = [
            interaction
            for interaction in gwo_state.get("pending_interactions", [])
            if str(interaction.interaction_id) != str(interaction_id)
        ]
        gwo_state["pending_interactions"] = pending
        gwo_state["status"] = ExecutionStatus.RUNNING

        compiled: CompiledBlueprint = active["compiled"]  # type: ignore[assignment]
        order = active["order"]  # type: ignore[assignment]
        start_index = active["cursor"]  # type: ignore[assignment]

        result = await self._execute_until_pause_or_end(
            run_id, compiled, order, gwo_state, start_index=start_index
        )
        return result

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _resolve_blueprint(self, blueprint_id: str) -> ArchitecturalBlueprint:
        blueprint = self.blueprints.get(blueprint_id)
        if not blueprint:
            raise KeyError(f"Blueprint '{blueprint_id}' is not registered.")
        return blueprint

    async def _execute_until_pause_or_end(
        self,
        run_id: UUID,
        compiled: CompiledBlueprint,
        order,
        gwo_state: GWOState,
        start_index: int,
    ) -> Dict[str, object]:
        for idx in range(start_index, len(order)):
            node_id = order[idx]
            executor = compiled.executors[node_id]
            node_update = await executor(gwo_state)
            gwo_state.update(node_update)

            status = gwo_state.get("status", ExecutionStatus.RUNNING)
            if status == ExecutionStatus.PAUSED_HITL:
                self.logger.info("Run %s paused after node %s awaiting HITL.", run_id, node_id)
                self._active_runs[run_id] = {
                    "compiled": compiled,
                    "state": gwo_state,
                    "order": order,
                    "cursor": idx + 1,
                }
                if self.hbs:
                    for interaction in gwo_state.get("pending_interactions", []):
                        await self.hbs.queue_interaction(
                            interaction,
                            config={
                                "configurable": {"thread_id": str(run_id)}
                            },
                        )
                return {
                    "status": status.value,
                    "pending_interactions": [
                        interaction.model_dump(mode="json")
                        if hasattr(interaction, "model_dump")
                        else interaction
                        for interaction in gwo_state.get("pending_interactions", [])
                    ],
                }

            if status == ExecutionStatus.FAILED:
                self.logger.error(
                    "Run %s failed at node %s: %s",
                    run_id,
                    node_id,
                    gwo_state.get("error_message"),
                )
                self._cleanup_run(run_id)
                self.infra.timeline_service.update_run_status(
                    run_id, ExecutionStatus.FAILED
                )
                return {
                    "status": status.value,
                    "error": gwo_state.get("error_message"),
                }

        # Completed successfully
        self._cleanup_run(run_id)
        self.infra.timeline_service.update_run_status(run_id, ExecutionStatus.COMPLETED)
        return {
            "status": ExecutionStatus.COMPLETED.value,
            "ltm_snapshot_manifest": gwo_state.get("ltm_snapshot_manifest", {}),
        }

    def _cleanup_run(self, run_id: UUID) -> None:
        self._active_runs.pop(run_id, None)
