"""
FastAPI router exposing HITL management endpoints.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status

from mmw_infra.common.interfaces import HBSInterface
from mmw_infra.models.hitl_schema import HITL_Output

router = APIRouter(prefix="/hitl", tags=["HITL"])


def get_hbs(request: Request) -> HBSInterface:
    manager: Optional[HBSInterface] = getattr(request.app.state, "hbs_manager", None)
    if not manager:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="HBS manager not initialised.",
        )
    return manager


@router.get("/pending")
async def list_pending_interactions(
    run_id: Optional[UUID] = None, hbs: HBSInterface = Depends(get_hbs)
):
    results = await hbs.list_pending(run_id=run_id)
    return {"pending": results}


@router.post("/{interaction_id}/resolve")
async def resolve_interaction(
    interaction_id: UUID,
    payload: HITL_Output,
    hbs: HBSInterface = Depends(get_hbs),
):
    await hbs.resolve_interaction(interaction_id, payload)
    return {"status": "resolved"}
