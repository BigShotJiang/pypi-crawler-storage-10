"""
Centralized definition of service interfaces (Protocols).
These interfaces define the loose contracts between infrastructure components so that
the orchestration layer can remain decoupled from concrete implementations.
"""
from __future__ import annotations

import sys
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type, Union
from uuid import UUID

from ..models.sop_schema import WorkflowStep
from ..models.hitl_schema import HITL_InteractionRecord, HITL_Output
from ..models.execution_state import (
    AutonomyProfile,
    InteractionControlMode,
    ExecutionRun,
    ExecutionNode,
    LTM_Artifact,
    LTM_Snapshot,
    ValidityStatus,
)
from .dependencies import (
    BaseModel,
    BasePromptTemplate,
    Runnable,
    RunnableConfig,
    StateGraph,
    Session,
    nx,
    CompiledGraph,
)

if sys.version_info >= (3, 8):
    from typing import Protocol
else:  # pragma: no cover - Python <3.8 not officially supported but kept for completeness
    class Protocol:  # type: ignore
        """Minimal Protocol shim for very old interpreters."""

        pass


class AutonomyProfileServiceInterface(Protocol):
    """Interface exposed by the CKS AutonomyProfileService."""

    def get_profile(self, profile_id: UUID) -> Optional[AutonomyProfile]:
        ...

    def get_active_profile(self, run_id: UUID) -> AutonomyProfile:
        ...

    def activate_profile_for_run(
        self, run_id: UUID, profile_id: Optional[UUID] = None
    ) -> None:
        ...

    def get_control_mode(
        self, profile: AutonomyProfile, interaction_id: Optional[str], hitl_mode: str
    ) -> InteractionControlMode:
        ...

    def get_control_mode_for_run(
        self, run_id: UUID, interaction_id: Optional[str], hitl_mode: str
    ) -> Tuple[InteractionControlMode, AutonomyProfile]:
        ...


class OptimizationServiceInterface(Protocol):
    """Interface for retrieving optimization hints from the CKS knowledge base."""

    def load_knowledge_base(self, file_path: str) -> None:
        ...

    def get_optimization_hint(
        self, problem_type: Union[str, Any], step_id: str
    ) -> Optional[str]:
        ...


class CSMSInterface(Protocol):
    """Combined interface exposing LTM and checkpointing capabilities."""

    def save_artifact(self, artifact: LTM_Artifact) -> None:
        ...

    def save_snapshot(self, snapshot: LTM_Snapshot) -> None:
        ...

    def get_artifact(self, artifact_id: UUID) -> Optional[LTM_Artifact]:
        ...

    async def get_artifacts_by_ids(
        self, artifact_ids: Iterable[UUID]
    ) -> Dict[UUID, LTM_Artifact]:
        ...

    def reconstruct_ltm_from_snapshot(
        self, snapshot_id: UUID
    ) -> Dict[str, LTM_Artifact]:
        ...

    @property
    def checkpointer(self) -> Any:
        ...


class TimelineServiceInterface(Protocol):
    """Interface for the mutable execution timeline service."""

    def set_dtias(self, dtias_service: "DTIAServiceInterface") -> None:
        ...

    def start_run(self, run: ExecutionRun) -> ExecutionRun:
        ...

    def update_run_status(
        self, run_id: UUID, status: Any, head_id: Optional[UUID] = None
    ) -> None:
        ...

    def get_run(self, run_id: UUID) -> Optional[ExecutionRun]:
        ...

    def add_execution_node(self, node: ExecutionNode) -> ExecutionNode:
        ...

    def update_execution_node(self, node_id: UUID, **updates: Any) -> None:
        ...

    def get_active_timeline(self, run_id: UUID) -> List[ExecutionNode]:
        ...

    def intervene_and_branch(
        self, run_id: UUID, intervention_node_id: UUID
    ) -> Tuple[Optional[ExecutionNode], List[UUID]]:
        ...

    def bulk_update_node_validity(
        self,
        validity_updates: Dict[UUID, ValidityStatus],
        db_session: Optional[Session] = None,
    ) -> None:
        ...


class DTIAServiceInterface(Protocol):
    """Dependency Tracking & Impact Analysis service."""

    def invalidate_cache(self, run_id: UUID) -> None:
        ...

    def register_data_lineage(self, node: ExecutionNode) -> None:
        ...

    def get_active_dag(self, run_id: UUID) -> nx.DiGraph:
        ...

    def process_timeline_intervention(
        self,
        run_id: UUID,
        intervention_node_id: UUID,
        deactivated_node_ids: List[UUID],
        db_session: Session,
    ) -> None:
        ...


class SecureExecutionServiceInterface(Protocol):
    """Secure Execution Sandbox (SES) interface."""

    async def execute_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        ...


class HBSInterface(Protocol):
    """Human-in-the-loop backend service interface."""

    async def queue_interaction(
        self, interaction: HITL_InteractionRecord, config: RunnableConfig
    ) -> None:
        ...

    async def resolve_interaction(
        self, interaction_id: UUID, human_input: HITL_Output
    ) -> None:
        ...

    async def list_pending(self, run_id: Optional[UUID] = None) -> List[Dict[str, Any]]:
        ...


class GWOInterface(Protocol):
    """Global Workflow Orchestrator interface exposed to the API layer."""

    async def start_run(
        self,
        blueprint_id: str,
        run_id: UUID,
        problem_type: str,
        autonomy_profile_id: Optional[UUID] = None,
        config: Optional[RunnableConfig] = None,
    ) -> Dict[str, Any]:
        ...

    async def resume_after_hitl(
        self,
        run_id: UUID,
        interaction_id: UUID,
        human_input: HITL_Output,
        config: Optional[RunnableConfig] = None,
    ) -> Dict[str, Any]:
        ...


class DynamicPromptBuilderInterface(Protocol):
    """Dynamic prompt preparation utility."""

    async def prepare_inputs(
        self, template: BasePromptTemplate, context: Dict[str, Any]
    ) -> Dict[str, Any]:
        ...


class AbstractBLE(Protocol):
    """Base protocol for Business Logic Executors."""

    async def execute_node(
        self, node_id: str, state: Dict[str, Any]
    ) -> Dict[str, Any]:
        ...


class ChassisBuilderInterface(Protocol):
    """Builder responsible for constructing the LangGraph chassis lifecycle."""

    def build_subgraph(
        self, step_definition: WorkflowStep, ble_class: Type[AbstractBLE]
    ) -> Union[StateGraph, Runnable, CompiledGraph]:
        ...


class InfrastructureServices(Protocol):
    """Convenience protocol representing the aggregated service bundle."""

    timeline_service: TimelineServiceInterface
    dtias_service: DTIAServiceInterface
    csms: CSMSInterface
    autonomy_service: AutonomyProfileServiceInterface
    optimization_service: OptimizationServiceInterface
    ses_service: SecureExecutionServiceInterface
    checkpoint_saver: Optional[Any]


__all__ = [
    "AbstractBLE",
    "AutonomyProfileServiceInterface",
    "CSMSInterface",
    "ChassisBuilderInterface",
    "DTIAServiceInterface",
    "DynamicPromptBuilderInterface",
    "GWOInterface",
    "HBSInterface",
    "InfrastructureServices",
    "OptimizationServiceInterface",
    "SecureExecutionServiceInterface",
    "TimelineServiceInterface",
]
