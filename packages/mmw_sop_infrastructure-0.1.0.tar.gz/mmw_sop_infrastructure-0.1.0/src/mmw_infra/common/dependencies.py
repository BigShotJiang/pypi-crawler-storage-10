"""
Centralized dependency management for the MMW SOP Infrastructure.
This module attempts to import all optional dependencies and provides boolean flags
and mock objects for graceful degradation when a dependency is missing.
"""
import logging
import sys
from typing import Any

# --- Pydantic ---
try:
    from pydantic import BaseModel, Field, ConfigDict, Json, ValidationError, model_validator, TypeAdapter
    from typing import Annotated
    PYDANTIC_AVAILABLE = True
except ImportError:
    logging.warning("Pydantic V2 not found. Using mock objects. Functionality will be limited.")
    PYDANTIC_AVAILABLE = False
    # Mock implementations to allow type hinting and basic instantiation
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        def model_dump(self, **kwargs): return self.__dict__
        def model_dump_json(self, **kwargs): import json; return json.dumps(self.__dict__)
    Field = lambda *args, **kwargs: None
    ConfigDict = dict; Json = Any; ValidationError = Exception; model_validator = lambda *args, **kwargs: lambda f: f
    TypeAdapter = None; Annotated = None

# --- LangChain & LangGraph ---
try:
    from langchain_core.runnables import Runnable
    from langchain_core.prompts.base import BasePromptTemplate
    from langchain_core.prompts import PromptTemplate
    from langchain_core.language_models import BaseLanguageModel
    from langchain_core.exceptions import OutputParserException
    from langchain_core.output_parsers import PydanticOutputParser, JsonOutputParser, StrOutputParser
    from langchain_core.runnables.config import RunnableConfig
    LANGCHAIN_CORE_AVAILABLE = True
except ImportError:
    logging.warning("LangChain Core not found. Using mock objects.")
    LANGCHAIN_CORE_AVAILABLE = False
    Runnable = object; BasePromptTemplate = object; PromptTemplate = object; BaseLanguageModel = object;
    OutputParserException = Exception; PydanticOutputParser = object; JsonOutputParser = object; StrOutputParser = object
    RunnableConfig = dict

try:
    from langgraph.graph import StateGraph, END, CompiledGraph
    from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata
    from langgraph.channels.base import EmptyChannelError
    from typing import TypedDict
    LANGGRAPH_AVAILABLE = True
except ImportError:
    logging.warning("LangGraph not found. Using mock objects. Workflow execution will fail.")
    LANGGRAPH_AVAILABLE = False
    StateGraph = object; END = "END"; CompiledGraph = object; BaseCheckpointSaver = object;
    Checkpoint = dict; CheckpointMetadata = dict; EmptyChannelError = Exception
    TypedDict = dict

# --- FastAPI ---
try:
    from fastapi import FastAPI, Depends, HTTPException, status, APIRouter
    from fastapi.responses import JSONResponse
    import uvicorn
    FASTAPI_AVAILABLE = True
except ImportError:
    logging.warning("FastAPI or Uvicorn not found. API endpoints will be unavailable.")
    FASTAPI_AVAILABLE = False
    FastAPI = None; Depends = None; HTTPException = Exception; status = None; APIRouter = None
    JSONResponse = None; uvicorn = None

# --- SQLAlchemy ---
try:
    import sqlalchemy
    from sqlalchemy import create_engine, Column, String, DateTime, Text, ForeignKey, JSON, Boolean, Table, event, update, bindparam
    from sqlalchemy.dialects.postgresql import UUID as PG_UUID
    from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship, joinedload
    from sqlalchemy.types import TypeDecorator, CHAR
    from sqlalchemy.exc import SQLAlchemyError
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    logging.warning("SQLAlchemy not found. Database persistence will be disabled.")
    SQLALCHEMY_AVAILABLE = False
    # Provide minimal mocks to prevent import errors in service initializers
    declarative_base = lambda: object
    Column = None; String = None; DateTime = None; Text = None; ForeignKey = None; JSON = None; Boolean = None; Table = None; event = None; PG_UUID = None

# --- Redis ---
try:
    import redis
    from redis import Redis
    from redis.exceptions import ConnectionError as RedisConnectionError
    REDIS_AVAILABLE = True
except ImportError:
    logging.warning("Redis-py not found. Checkpointing service will use a mock in-memory store.")
    REDIS_AVAILABLE = False
    RedisConnectionError = Exception
    # MockRedis from Task 4
    class MockRedisPipeline:
        def __init__(self, client): self.client = client; self.commands = []
        def set(self, key, value): self.commands.append(('SET', key, value)); return self
        def execute(self):
            for cmd, key, value in self.commands: self.client.data[key] = value
            return [True] * len(self.commands)
    class MockRedis:
        def __init__(self): self.data = {}; self.connected = True
        def get(self, key): return self.data.get(key)
        def set(self, key, value): self.data[key] = value; return True
        def pipeline(self): return MockRedisPipeline(self)
        def ping(self): return self.connected
        @classmethod
        def from_url(cls, *args, **kwargs): return cls()
    Redis = MockRedis

# --- NetworkX ---
try:
    import networkx as nx
    NETWORKX_AVAILABLE = True
except ImportError:
    logging.warning("NetworkX not found. DTIAS functionality will be disabled.")
    NETWORKX_AVAILABLE = False
    nx = None

# --- PyYAML ---
try:
    import yaml
    PYYAML_AVAILABLE = True
except ImportError:
    logging.warning("PyYAML not found. Loading configurations from YAML files will be disabled.")
    PYYAML_AVAILABLE = False
    yaml = None

# --- Docker ---
try:
    import docker
    from docker.errors import APIError, ImageNotFound, NotFound
    from requests.exceptions import ReadTimeout as DockerTimeoutError
    DOCKER_AVAILABLE = True
except ImportError:
    logging.warning("Docker SDK not found. Secure Execution Service (SES) will be disabled.")
    DOCKER_AVAILABLE = False
    docker = None; APIError = Exception; ImageNotFound = Exception; NotFound = Exception; DockerTimeoutError = Exception
