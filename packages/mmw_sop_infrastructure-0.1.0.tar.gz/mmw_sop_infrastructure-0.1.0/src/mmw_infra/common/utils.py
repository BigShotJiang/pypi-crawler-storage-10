"""
Shared utility functions and classes used across the infrastructure.
"""
from uuid import UUID
from .dependencies import SQLALCHEMY_AVAILABLE

if SQLALCHEMY_AVAILABLE:
    from sqlalchemy.types import TypeDecorator, CHAR
    from sqlalchemy.dialects.postgresql import UUID as PG_UUID

    class GUID(TypeDecorator):
        """
        Platform-independent GUID type.
        Uses PostgreSQL's UUID type, otherwise uses CHAR(32), storing as string hex.
        Consolidated from Tasks 4, 7, and 22.
        """
        impl = CHAR
        cache_ok = True

        def load_dialect_impl(self, dialect):
            if dialect.name == 'postgresql' and PG_UUID:
                return dialect.type_descriptor(PG_UUID())
            else:
                return dialect.type_descriptor(CHAR(32))

        def process_bind_param(self, value, dialect):
            if value is None:
                return value
            elif dialect.name == 'postgresql':
                return str(value)
            else:
                if not isinstance(value, UUID):
                    try:
                        return UUID(str(value)).hex
                    except (ValueError, TypeError):
                        return value
                return value.hex

        def process_result_value(self, value, dialect):
            if value is None:
                return value
            if not isinstance(value, UUID):
                try:
                    return UUID(value)
                except (ValueError, TypeError):
                    return value
            return value
