import platform
from functools import lru_cache
from pathlib import Path

if platform.python_version_tuple()[1] >= "11":
    import tomllib  # Python 3.11+
else:
    import tomli as tomllib  # fallback for older Python versions


@lru_cache
def _get_version():
    """Get version from Rust extension or fallback."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        return data["project"]["version"]
    except Exception:
        return "0.1.0"  # current version fallback


__version__ = _get_version()
