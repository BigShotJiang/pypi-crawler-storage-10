"""
简化的 Memory 类，提供更友好的用户接口

提供简化的 API，让用户可以直接使用 `memory = Memory()` 然后调用 `memory.search()` 和 `memory.add()`
"""

import os
from typing import Optional, Dict, Any, List, Union
from .sync_client import TiMEMClient
from .exceptions import TiMEMError


class Memory:
    """
    简化的记忆管理类
    
    提供更简洁的 API 接口，隐藏底层的复杂性。
    
    Example:
        ```python
        memory = Memory()
        
        # 搜索相关记忆
        results = memory.search(query="用户问题", user_id="user123", limit=3)
        
        # 添加对话记忆
        messages = [
            {"role": "user", "content": "你好"},
            {"role": "assistant", "content": "您好！有什么可以帮您的吗？"}
        ]
        memory.add(messages, user_id="user123")
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        default_domain: str = "chat",
        **kwargs
    ):
        """
        初始化 Memory 实例
        
        Args:
            api_key: TiMEM API 密钥。如果不提供，从环境变量 TIMEM_API_KEY 读取
            base_url: API 基础 URL。如果不提供，从环境变量 TIMEM_BASE_URL 读取，默认为 "http://localhost:8001"
            default_domain: 默认域，用于记忆分类
            **kwargs: 其他传递给 TiMEMClient 的参数
        """
        # 从环境变量读取配置，如果没有提供
        api_key = api_key or os.getenv("TIMEM_API_KEY", "")
        base_url = base_url or os.getenv("TIMEM_BASE_URL", "http://localhost:8001")
        
        if not api_key:
            raise ValueError("api_key 必须提供，可以通过参数传入或设置环境变量 TIMEM_API_KEY")
        
        self._client = TiMEMClient(
            api_key=api_key,
            base_url=base_url,
            **kwargs
        )
        self.default_domain = default_domain
    
    def _to_user_id_int(self, user_id: Union[str, int]) -> Optional[int]:
        """
        将 user_id 转换为整数
        
        如果 user_id 是字符串：
        - 如果是纯数字字符串，转换为整数
        - 否则，使用 hash 生成稳定的整数ID（取绝对值确保为正数）
        
        Args:
            user_id: 用户ID（字符串或整数）
        
        Returns:
            整数用户ID，如果无法转换则返回 None
        """
        if isinstance(user_id, int):
            return user_id
        
        if isinstance(user_id, str):
            # 尝试直接转换为整数
            if user_id.isdigit():
                return int(user_id)
            # 对于非数字字符串，使用 hash 生成稳定的整数ID
            # 使用 abs 确保为正数，避免负数ID问题
            return abs(hash(user_id)) % (10 ** 9)  # 限制在合理范围内
        
        return None
    
    def search(
        self,
        query: str,
        user_id: Union[str, int] = "default_user",
        limit: int = 10,
        domain: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        搜索相关记忆
        
        Args:
            query: 搜索查询文本
            user_id: 用户ID，可以是字符串或整数
            limit: 返回结果数量限制
            domain: 搜索的域，如果不提供则使用默认域
        
        Returns:
            包含搜索结果的字典，格式：
            {
                "results": [
                    {"memory": "记忆内容", "score": 0.95, ...},
                    ...
                ],
                "total": 10
            }
        """
        domain = domain or self.default_domain
        
        # 转换 user_id 为整数
        user_id_int = self._to_user_id_int(user_id)
        
        # 提取查询关键词（简单处理：按空格分割）
        keywords = [kw.strip() for kw in query.split() if kw.strip()] if query else []
        
        try:
            # 调用底层搜索API
            result = self._client.search_memory(
                user_id=user_id_int,
                domain=domain,
                keywords=keywords if keywords else None,
                limit=limit,
                offset=0
            )
            
            # 格式化返回结果，匹配用户期望的格式
            formatted_results = []
            memories = result.get("memories", result.get("data", []))
            
            for mem in memories:
                # 提取记忆内容
                content = mem.get("content", {})
                if isinstance(content, dict):
                    # 尝试从不同可能的字段中提取文本
                    memory_text = (
                        content.get("text") or
                        content.get("content") or
                        content.get("memory") or
                        str(content)
                    )
                else:
                    memory_text = str(content)
                
                formatted_results.append({
                    "memory": memory_text,
                    "score": mem.get("score", mem.get("relevance", 0.0)),
                    "id": mem.get("id", mem.get("memory_id")),
                    "created_at": mem.get("created_at"),
                    **{k: v for k, v in mem.items() if k not in ["content", "score", "id", "memory_id", "created_at"]}
                })
            
            return {
                "results": formatted_results,
                "total": result.get("total", len(formatted_results)),
                "query": query
            }
        except Exception as e:
            raise TiMEMError(f"搜索记忆失败: {str(e)}") from e
    
    def add(
        self,
        messages: List[Dict[str, str]],
        user_id: Union[str, int] = "default_user",
        domain: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        添加对话记忆
        
        从对话消息中提取内容并添加为记忆。
        
        Args:
            messages: 对话消息列表，格式：[{"role": "user", "content": "..."}, ...]
            user_id: 用户ID，可以是字符串或整数
            domain: 记忆的域，如果不提供则使用默认域
        
        Returns:
            添加结果字典
        """
        domain = domain or self.default_domain
        
        if not messages:
            raise ValueError("messages 不能为空")
        
        # 转换 user_id 为整数
        user_id_int = self._to_user_id_int(user_id)
        if user_id_int is None:
            raise ValueError(f"user_id 必须是数字、字符串或可转换为数字的字符串，当前值: {user_id}")
        
        # 将对话消息转换为文本内容
        # 格式：角色: 内容\n角色: 内容...
        conversation_text = "\n".join([
            f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
            for msg in messages
            if msg.get("content")
        ])
        
        # 从对话中提取关键词（简单处理：从最后一条用户消息中提取）
        keywords = []
        for msg in reversed(messages):
            if msg.get("role") == "user" and msg.get("content"):
                content = msg.get("content", "")
                keywords = [kw.strip() for kw in content.split() if kw.strip()][:10]  # 最多10个关键词
                break
        
        try:
            # 调用底层添加记忆API
            result = self._client.add_memory(
                user_id=user_id_int,
                domain=domain,
                content={
                    "text": conversation_text,
                    "messages": messages,  # 保留原始消息结构
                    "type": "conversation"
                },
                layer_type="L1",  # 默认使用 L1 层
                keywords=keywords if keywords else None
            )
            
            return {
                "success": True,
                "memory_id": result.get("memory_id", result.get("id")),
                "message": "记忆添加成功",
                **result
            }
        except Exception as e:
            raise TiMEMError(f"添加记忆失败: {str(e)}") from e
    
    def close(self):
        """
        关闭客户端连接
        
        清理资源，关闭连接池等。
        """
        # TiMEMClient 没有显式的 close 方法，如果需要可以在这里实现
        pass
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()

