class SanityIOError(Exception):
    pass
