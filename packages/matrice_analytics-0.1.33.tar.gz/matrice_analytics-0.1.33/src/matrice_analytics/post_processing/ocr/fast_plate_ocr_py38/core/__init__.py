from __future__ import annotations

"""Core utilities and types for Fast Plate OCR (Python 3.8 compatible)."""
