**Mini Backtest 框架使用與測試 (MVP)**

- 位置：`mini_backtest/`
- 特色：以 pandas DataFrame 作為輸入與輸出，提供基本指標 CAGR 與 Max Drawdown。
- 測試：使用 pytest，已透過 `pytest.ini` 將測試目錄鎖定為 `tests/`（避免載入外部套件的其他測試）。

快速開始：

1) 產生測試資料並執行回測輸出 JSON

```
python - << 'PY'
from pathlib import Path
from mini_backtest import generate_sample_data, load_data, pivot_close, Backtester

data_path = Path('data/data.json')
if not data_path.exists():
    generate_sample_data(data_path, seed=42)

df = load_data(data_path)
prices = pivot_close(df)
res = Backtester(prices).run()

# 將回測結果輸出為 JSON（每個 symbol 一筆紀錄）
res.reset_index().to_json('output.json', orient='records')
print('Saved metrics to output.json')
print(res.head())
PY
```

2) 執行測試（需安裝 pytest、pandas、numpy）

```
pytest -q
```

輸入與輸出：
- 輸入：`pivot_close(df)` 產生的寬表（index 為日期、columns 為股票代號、值為收盤價）。
- 輸出：`Backtester(prices).run()` 回傳包含 `cagr` 與 `max_drawdown` 欄位之 DataFrame（index 為 symbol）。

---

💯 沒錯，你這個觀察非常精準。
這是 **vectorized（向量化）回測框架** 先天設計上的一個「結構性限制」：
它在計算效率上極快，但在 **動態事件（例如停損／停利、移動止損、條件觸發單）** 上確實比較難實作，原因如下👇

---

## 🧠 一、為什麼向量化框架難處理動態停損／停利

### 1️⃣ 向量化是「整體計算」，不是「逐筆模擬」

像 **vectorbt**、**fastbt**、**zipline-lite** 這類框架都是基於 pandas / NumPy 的「向量化運算」，意思是：

> 它一次性計算整個時間序列的策略信號，而非逐根 K 棒模擬。

📊 例如：

```python
entries = close > ma
exits = close < ma
```

這樣的策略是直接在整個時間序列上產生 True/False 向量，並一次性模擬交易。

🧩 問題是：

> 「動態停損／停利」會依照 *當前持倉狀態*、*進場價*、*當前盈虧*、甚至 *前一根 K 棒結果* 而變化。

這些邏輯需要「狀態」與「事件」記憶，而向量化框架缺乏這種逐步更新的能力。

---

## ⚙️ 二、舉例說明差異

假設策略如下：

> 每次進場後，設定 5% 停利，2% 停損。若其中任一條件先觸發即出場。

### 在 event-driven 架構（如 **Backtrader / QF-Lib / LEAN**）：

* 系統每個 bar 都執行一次：

  * 檢查是否持倉
  * 若持倉 → 計算目前漲跌幅 → 是否觸發停損／停利
* 結果：停損價是 *動態、個別持倉獨立* 的。

### 在 vectorized 架構（如 **vectorbt / backtesting.py**）：

* 若用純向量邏輯，很難「在進場後再根據持倉價動態設定停損價」。
* 你可能需要事先建立整個價格矩陣的「觸發條件」，例如用 rolling 窗口找出「價格回落 2%」的位置，但這會導致：

  * 無法精確模擬 intra-trade 的觸發時機。
  * 觸發順序（先停損還是停利）難以準確判斷。
  * 若多筆同時持倉（多股票），更難追蹤個別倉位的止損線。

---

## 🔍 三、各框架在「動態停利停損」上的表現比較

| 框架名稱                    | 架構類型             | 停損／停利實作難度 | 支援說明                                        |
| ----------------------- | ---------------- | --------- | ------------------------------------------- |
| **Backtesting.py**      | hybrid（逐步迭代）     | ✅ 簡單      | 可在 `next()` 中直接比較現價與入場價。                    |
| **Backtrader**          | event-driven     | ✅✅✅ 強     | 支援 `Order.StopTrail`, `Order.Limit` 等原生停損單。 |
| **bt**                  | 向量為主             | ⚠️ 中      | 可透過自定義 Algo，但不適合 tick 級模擬。                  |
| **vectorbt**            | fully vectorized | 🚫 難      | 需手動生成布林遮罩或用 rolling 計算「理論觸發點」。              |
| **LEAN (QuantConnect)** | 完整事件驅動           | ✅✅✅✅ 最強   | 原生支援各種停損／移動止損單類型與多筆訂單管理。                    |

---

## 🧩 四、解法與折衷方案

### ✅ 方法 1：在 vectorbt 中模擬「條件觸發點」

雖然它無法逐筆模擬，但可以：

```python
take_profit = close / entry_price >= 1.05
stop_loss   = close / entry_price <= 0.98
exits = take_profit | stop_loss
```

這種方式可以快速估算觸發點，但：

* 無法區分「哪一個先觸發」。
* 若兩條件同時滿足，需自己定義優先順序。

---

### ✅ 方法 2：混合式運算（hybrid backtest loop）

在 vectorbt 或 pandas 上使用 `for` + numpy array 更新邏輯，例如：

```python
for i in range(1, len(close)):
    if holding:
        if close[i] >= entry_price * 1.05:
            holding = False  # take profit
        elif close[i] <= entry_price * 0.98:
            holding = False  # stop loss
```

雖然這樣會犧牲部分速度（比完全向量化慢約 2〜10 倍），但能精確處理動態停損條件。

---

### ✅ 方法 3：選用 event-driven 框架（若你重視真實模擬）

若停利／停損邏輯對策略關鍵（特別是波段或短線策略），
建議直接用：

* **Backtrader** → 可精確模擬逐根 K 棒與 intra-bar 停損。
* **LEAN** → 若考慮未來實盤轉接，也最無縫。

---

## 🔧 五、總結建議

| 目標              | 推薦框架                        | 理由                       |
| --------------- | --------------------------- | ------------------------ |
| **快速回測、概念驗證**   | vectorbt                    | 快、方便、易掃參數；但停損邏輯需簡化。      |
| **精確停利停損、策略回放** | Backtrader / Backtesting.py | 支援逐筆檢查，易實作移動止損。          |
| **準備上雲／實盤連接**   | LEAN                        | 事件驅動架構最完整、支援 Broker API。 |

---

要不要我幫你示範一段「向量化 vs 事件驅動」的 **停利／停損策略實作範例**？
我可以用相同策略（例如進場後 ±5% 出場）對比兩種框架的寫法與結果，讓你直觀看出差別。
