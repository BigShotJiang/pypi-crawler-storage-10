# dataprepX/cleaner.py

import pandas as pd
from .preprocess import handle_missing, encode_data, scale_data, remove_outliers
from .report import generate_report

class DataPrepX:
    """
    Main class for automatic data cleaning and preprocessing.
    """

    def __init__(self,
                 fill_method='auto',
                 encoding='label',
                 scaling=True,
                 outlier_removal=True,
                 report=True,
                 test_split=None):
        self.fill_method = fill_method
        self.encoding = encoding
        self.scaling = scaling
        self.outlier_removal = outlier_removal
        self.report = report
        self.test_split = test_split

    def fit_transform(self, df: pd.DataFrame):
        df = df.copy()
        print("🚀 Starting dataprepX cleaning...")

        # 1. Drop duplicates
        df.drop_duplicates(inplace=True)

        # 2. Handle missing values
        df = handle_missing(df, method=self.fill_method)

        # 3. Encode categorical data
        df = encode_data(df, method=self.encoding)

        # 4. Remove outliers
        if self.outlier_removal:
            df = remove_outliers(df)

        # 5. Scale numeric features
        if self.scaling:
            df = scale_data(df)

        # 6. Generate report
        if self.report:
            generate_report(df)

        print("✅ Cleaning complete! Data ready for ML model training.")
        return df
