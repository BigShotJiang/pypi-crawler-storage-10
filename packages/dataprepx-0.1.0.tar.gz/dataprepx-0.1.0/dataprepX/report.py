# dataprepX/report.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def generate_report(df: pd.DataFrame):
    """Generate a simple data quality and structure report."""
    print("\n📋 === dataprepX Report ===")
    print(f"Shape: {df.shape}")
    print(f"Missing values:\n{df.isnull().sum()}")
    print("\nData Types:\n", df.dtypes)
    print("\nDescriptive Statistics:\n", df.describe())

    # Optional: Visualizations
    try:
        plt.figure(figsize=(6,4))
        sns.heatmap(df.isnull(), cbar=False)
        plt.title("Missing Value Heatmap")
        plt.show()

        df.hist(figsize=(10, 8))
        plt.suptitle("Feature Distributions")
        plt.show()
    except Exception as e:
        print("Visualization skipped:", e)
