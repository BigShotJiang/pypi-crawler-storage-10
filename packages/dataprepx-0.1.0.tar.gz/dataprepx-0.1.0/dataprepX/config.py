# dataprepX/config.py

DEFAULT_CONFIG = {
    "fill_method": "auto",
    "encoding": "label",
    "scaling": True,
    "outlier_removal": True,
    "report": True
}
