# dataprepX/preprocess.py

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler

def handle_missing(df, method='auto'):
    """Handle missing values in the DataFrame."""
    for col in df.columns:
        if df[col].isnull().sum() > 0:
            if df[col].dtype == 'object':
                df[col].fillna(df[col].mode()[0], inplace=True)
            else:
                if method == 'mean':
                    df[col].fillna(df[col].mean(), inplace=True)
                elif method == 'median' or method == 'auto':
                    df[col].fillna(df[col].median(), inplace=True)
                elif method == 'drop':
                    df.dropna(subset=[col], inplace=True)
    return df


def encode_data(df, method='label'):
    """Encode categorical columns."""
    cat_cols = df.select_dtypes(include='object').columns
    if method == 'label':
        le = LabelEncoder()
        for col in cat_cols:
            df[col] = le.fit_transform(df[col].astype(str))
    elif method == 'onehot':
        df = pd.get_dummies(df, drop_first=True)
    return df


def scale_data(df):
    """Scale numerical columns using StandardScaler."""
    scaler = StandardScaler()
    num_cols = df.select_dtypes(include=np.number).columns
    df[num_cols] = scaler.fit_transform(df[num_cols])
    return df


def remove_outliers(df):
    """Remove outliers using IQR method."""
    numeric_cols = df.select_dtypes(include=np.number).columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
        df = df[(df[col] >= lower) & (df[col] <= upper)]
    return df
