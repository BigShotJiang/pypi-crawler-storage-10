# dataprepX/utils.py

import pandas as pd

def get_column_types(df):
    """Return lists of numeric and categorical columns."""
    num_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    return num_cols, cat_cols


def summary(df):
    """Return basic summary dictionary of DataFrame."""
    info = {
        "rows": df.shape[0],
        "columns": df.shape[1],
        "missing_values": int(df.isnull().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "categorical_cols": len(df.select_dtypes(include='object').columns),
        "numeric_cols": len(df.select_dtypes(include='number').columns),
    }
    return info
