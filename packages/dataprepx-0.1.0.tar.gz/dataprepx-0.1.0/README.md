# dataprepX

**dataprepX** is an automatic data cleaning and preprocessing library that makes your dataset ready for machine learning with a single command.

## Installation

```bash
pip install dataprepX

from dataprepX.cleaner import DataPrepX
import pandas as pd

df = pd.read_csv('data.csv')
dp = DataPrepX()
clean_df = dp.fit_transform(df)

Features

Handles missing values

Encodes categorical data

Scales numerical columns

Removes outliers

Generates simple data reports


---

## ⚙️ Step 5: Build your package

Terminal me jao (folder jisme `setup.py` hai) aur likho:

```bash
pip install build twine
python -m build

