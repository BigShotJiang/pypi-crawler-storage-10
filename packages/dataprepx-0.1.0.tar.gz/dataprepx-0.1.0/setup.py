from setuptools import setup, find_packages

setup(
    name='dataprepX',
    version='0.1.0',
    author='Dhuka',               # ← apna naam
    author_email='your_email@example.com',
    description='An automatic data cleaning and preprocessing library for ML',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/dataprepX',  # optional
    packages=find_packages(),
    install_requires=[
        'pandas',
        'numpy',
        'scikit-learn',
        'matplotlib',
        'seaborn'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)
