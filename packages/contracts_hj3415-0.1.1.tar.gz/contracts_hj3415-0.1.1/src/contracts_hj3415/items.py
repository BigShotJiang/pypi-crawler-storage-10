#src/contracts_hj3415/items.py — 아이템 관련 DTO

from datetime import datetime
from .common import IDModel, ContractModel

class ItemBase(ContractModel):
    name: str
    description: str | None = None

class ItemCreate(ItemBase):
    pass

class ItemRead(IDModel, ItemBase):
    created_at: datetime