#src/contracts_hj3415/users.py — 사용자 관련 DTO

from datetime import datetime
from pydantic import BaseModel, EmailStr
from .common import IDModel, ContractModel, UserRole

class UserBase(ContractModel):
    email: EmailStr
    nickname: str | None = None
    role: UserRole = UserRole.CUSTOMER

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    nickname: str | None = None
    role: UserRole | None = None

class UserRead(IDModel, UserBase):
    created_at: datetime