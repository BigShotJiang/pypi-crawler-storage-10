# src/contracts_hj3415/events.py — 메시지 / 이벤트 스키마

from datetime import datetime
from uuid import UUID
from pydantic import BaseModel

class UserCreatedEvent(BaseModel):
    event: str = "user.created"
    user_id: UUID
    timestamp: datetime