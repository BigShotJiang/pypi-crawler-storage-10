# contracts_hj3415/nfs/fact.py
from pydantic import BaseModel, Field
from datetime import date
from typing import Optional

class FactFinanceDTO(BaseModel):
    cmp_cd: str
    page: str
    rpt: str
    frq: str
    accode: str
    account_name: str
    period: date
    value: float
    basis: Optional[str] = None
    is_estimate: bool = False
    unit_type: Optional[int] = None
    level: Optional[int] = None
    parent_accode: Optional[str] = None
    group_type: Optional[int] = None
    acc_kind: Optional[str] = None
    precision: Optional[int] = None