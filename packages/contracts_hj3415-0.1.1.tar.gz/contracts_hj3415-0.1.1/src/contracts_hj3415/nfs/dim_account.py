# contracts_hj3415/nfs/dim_account.py
from pydantic import BaseModel
from typing import Optional

class DimAccountDTO(BaseModel):
    accode: str
    account_name: str
    level: Optional[int] = None
    parent_accode: Optional[str] = None
    group_type: Optional[int] = None
    unit_type: Optional[int] = None
    acc_kind: Optional[str] = None
    precision: Optional[int] = None