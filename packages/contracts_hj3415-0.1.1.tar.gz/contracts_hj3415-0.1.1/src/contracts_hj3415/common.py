#src/contracts_hj3415/common.py — 공용 타입, 베이스 모델, Enum 등

from datetime import datetime
from uuid import UUID, uuid4
from enum import Enum
from pydantic import BaseModel, Field

class IDModel(BaseModel):
    id: UUID = Field(default_factory=uuid4)

class TimestampMixin(BaseModel):
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime | None = None

class UserRole(str, Enum):
    ADMIN = "admin"
    STAFF = "staff"
    CUSTOMER = "customer"

# 공통 BaseModel
class ContractModel(BaseModel):
    class Config:
        orm_mode = True
        extra = "forbid"
        from_attributes = True