# Simple Anthropic

A minimal Python client for Anthropic Claude API using OpenAI SDK compatibility.


## Example

export ANTHROPIC_API_KEY="your-api-key-here"

from cc import anthropic_generate

response = anthropic_generate("Hello, how are you?")

print(response)


## Installation

```bash
pip install aidisdk