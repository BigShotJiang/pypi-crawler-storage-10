from setuptools import setup, find_packages

setup(
    name="aidisdk",
    version="1.1.0",
    author="Artur Menton",
    author_email="mentonartuuuuur9@gmail.com",
    description="A minimal Python client for Anthropic Claude API using OpenAI SDK compatibility",
    long_description="A minimal Python client for Anthropic Claude API using OpenAI SDK compatibility",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "openai>=1.0.0",
    ],
)