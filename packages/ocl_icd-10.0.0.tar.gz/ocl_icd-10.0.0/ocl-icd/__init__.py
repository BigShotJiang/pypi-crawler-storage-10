"""
ocl-icd - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from ocl-icd!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "ocl-icd",
        "version": "10.0.0",
        "description": "A useful Python package"
    }

# Package version
__version__ = "10.0.0"
