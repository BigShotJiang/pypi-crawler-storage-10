# ocl-icd

A useful Python package with utility functions.

## Installation

```bash
pip install ocl-icd
```

## Usage

```python
import ocl-icd

print(ocl-icd.hello_world())
result = ocl-icd.add_numbers(5, 3)
print(result)
```
