import datetime
from http import HTTPStatus
from typing import Any, Union
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.booking_resource import BookingResource
from ...models.booking_resources_list_field_item import BookingResourcesListFieldItem
from ...models.booking_resources_list_o_item import BookingResourcesListOItem
from ...models.booking_resources_list_state_item import BookingResourcesListStateItem
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    backend_id: Union[Unset, str] = UNSET,
    category_uuid: Union[Unset, UUID] = UNSET,
    component_count: Union[Unset, float] = UNSET,
    connected_customer_uuid: Union[Unset, UUID] = UNSET,
    created: Union[Unset, datetime.datetime] = UNSET,
    customer: Union[Unset, str] = UNSET,
    customer_uuid: Union[Unset, UUID] = UNSET,
    downscaled: Union[Unset, bool] = UNSET,
    field: Union[Unset, list[BookingResourcesListFieldItem]] = UNSET,
    has_terminate_date: Union[Unset, bool] = UNSET,
    lexis_links_supported: Union[Unset, bool] = UNSET,
    limit_based: Union[Unset, bool] = UNSET,
    limit_component_count: Union[Unset, float] = UNSET,
    modified: Union[Unset, datetime.datetime] = UNSET,
    name: Union[Unset, str] = UNSET,
    name_exact: Union[Unset, str] = UNSET,
    o: Union[Unset, list[BookingResourcesListOItem]] = UNSET,
    offering: Union[Unset, str] = UNSET,
    offering_billable: Union[Unset, bool] = UNSET,
    offering_shared: Union[Unset, bool] = UNSET,
    offering_slug: Union[Unset, list[str]] = UNSET,
    offering_type: Union[Unset, str] = UNSET,
    offering_uuid: Union[Unset, list[UUID]] = UNSET,
    only_limit_based: Union[Unset, bool] = UNSET,
    only_usage_based: Union[Unset, bool] = UNSET,
    page: Union[Unset, int] = UNSET,
    page_size: Union[Unset, int] = UNSET,
    parent_offering_uuid: Union[Unset, UUID] = UNSET,
    paused: Union[Unset, bool] = UNSET,
    plan_uuid: Union[Unset, UUID] = UNSET,
    project_name: Union[Unset, str] = UNSET,
    project_uuid: Union[Unset, UUID] = UNSET,
    provider_uuid: Union[Unset, UUID] = UNSET,
    query: Union[Unset, str] = UNSET,
    restrict_member_access: Union[Unset, bool] = UNSET,
    runtime_state: Union[Unset, str] = UNSET,
    service_manager_uuid: Union[Unset, UUID] = UNSET,
    state: Union[Unset, list[BookingResourcesListStateItem]] = UNSET,
    usage_based: Union[Unset, bool] = UNSET,
    visible_to_username: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["backend_id"] = backend_id

    json_category_uuid: Union[Unset, str] = UNSET
    if not isinstance(category_uuid, Unset):
        json_category_uuid = str(category_uuid)
    params["category_uuid"] = json_category_uuid

    params["component_count"] = component_count

    json_connected_customer_uuid: Union[Unset, str] = UNSET
    if not isinstance(connected_customer_uuid, Unset):
        json_connected_customer_uuid = str(connected_customer_uuid)
    params["connected_customer_uuid"] = json_connected_customer_uuid

    json_created: Union[Unset, str] = UNSET
    if not isinstance(created, Unset):
        json_created = created.isoformat()
    params["created"] = json_created

    params["customer"] = customer

    json_customer_uuid: Union[Unset, str] = UNSET
    if not isinstance(customer_uuid, Unset):
        json_customer_uuid = str(customer_uuid)
    params["customer_uuid"] = json_customer_uuid

    params["downscaled"] = downscaled

    json_field: Union[Unset, list[str]] = UNSET
    if not isinstance(field, Unset):
        json_field = []
        for field_item_data in field:
            field_item = field_item_data.value
            json_field.append(field_item)

    params["field"] = json_field

    params["has_terminate_date"] = has_terminate_date

    params["lexis_links_supported"] = lexis_links_supported

    params["limit_based"] = limit_based

    params["limit_component_count"] = limit_component_count

    json_modified: Union[Unset, str] = UNSET
    if not isinstance(modified, Unset):
        json_modified = modified.isoformat()
    params["modified"] = json_modified

    params["name"] = name

    params["name_exact"] = name_exact

    json_o: Union[Unset, list[str]] = UNSET
    if not isinstance(o, Unset):
        json_o = []
        for o_item_data in o:
            o_item = o_item_data.value
            json_o.append(o_item)

    params["o"] = json_o

    params["offering"] = offering

    params["offering_billable"] = offering_billable

    params["offering_shared"] = offering_shared

    json_offering_slug: Union[Unset, list[str]] = UNSET
    if not isinstance(offering_slug, Unset):
        json_offering_slug = offering_slug

    params["offering_slug"] = json_offering_slug

    params["offering_type"] = offering_type

    json_offering_uuid: Union[Unset, list[str]] = UNSET
    if not isinstance(offering_uuid, Unset):
        json_offering_uuid = []
        for offering_uuid_item_data in offering_uuid:
            offering_uuid_item = str(offering_uuid_item_data)
            json_offering_uuid.append(offering_uuid_item)

    params["offering_uuid"] = json_offering_uuid

    params["only_limit_based"] = only_limit_based

    params["only_usage_based"] = only_usage_based

    params["page"] = page

    params["page_size"] = page_size

    json_parent_offering_uuid: Union[Unset, str] = UNSET
    if not isinstance(parent_offering_uuid, Unset):
        json_parent_offering_uuid = str(parent_offering_uuid)
    params["parent_offering_uuid"] = json_parent_offering_uuid

    params["paused"] = paused

    json_plan_uuid: Union[Unset, str] = UNSET
    if not isinstance(plan_uuid, Unset):
        json_plan_uuid = str(plan_uuid)
    params["plan_uuid"] = json_plan_uuid

    params["project_name"] = project_name

    json_project_uuid: Union[Unset, str] = UNSET
    if not isinstance(project_uuid, Unset):
        json_project_uuid = str(project_uuid)
    params["project_uuid"] = json_project_uuid

    json_provider_uuid: Union[Unset, str] = UNSET
    if not isinstance(provider_uuid, Unset):
        json_provider_uuid = str(provider_uuid)
    params["provider_uuid"] = json_provider_uuid

    params["query"] = query

    params["restrict_member_access"] = restrict_member_access

    params["runtime_state"] = runtime_state

    json_service_manager_uuid: Union[Unset, str] = UNSET
    if not isinstance(service_manager_uuid, Unset):
        json_service_manager_uuid = str(service_manager_uuid)
    params["service_manager_uuid"] = json_service_manager_uuid

    json_state: Union[Unset, list[str]] = UNSET
    if not isinstance(state, Unset):
        json_state = []
        for state_item_data in state:
            state_item = state_item_data.value
            json_state.append(state_item)

    params["state"] = json_state

    params["usage_based"] = usage_based

    params["visible_to_username"] = visible_to_username

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/booking-resources/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> list["BookingResource"]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = BookingResource.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200
    raise errors.UnexpectedStatus(response.status_code, response.content)


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[list["BookingResource"]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    backend_id: Union[Unset, str] = UNSET,
    category_uuid: Union[Unset, UUID] = UNSET,
    component_count: Union[Unset, float] = UNSET,
    connected_customer_uuid: Union[Unset, UUID] = UNSET,
    created: Union[Unset, datetime.datetime] = UNSET,
    customer: Union[Unset, str] = UNSET,
    customer_uuid: Union[Unset, UUID] = UNSET,
    downscaled: Union[Unset, bool] = UNSET,
    field: Union[Unset, list[BookingResourcesListFieldItem]] = UNSET,
    has_terminate_date: Union[Unset, bool] = UNSET,
    lexis_links_supported: Union[Unset, bool] = UNSET,
    limit_based: Union[Unset, bool] = UNSET,
    limit_component_count: Union[Unset, float] = UNSET,
    modified: Union[Unset, datetime.datetime] = UNSET,
    name: Union[Unset, str] = UNSET,
    name_exact: Union[Unset, str] = UNSET,
    o: Union[Unset, list[BookingResourcesListOItem]] = UNSET,
    offering: Union[Unset, str] = UNSET,
    offering_billable: Union[Unset, bool] = UNSET,
    offering_shared: Union[Unset, bool] = UNSET,
    offering_slug: Union[Unset, list[str]] = UNSET,
    offering_type: Union[Unset, str] = UNSET,
    offering_uuid: Union[Unset, list[UUID]] = UNSET,
    only_limit_based: Union[Unset, bool] = UNSET,
    only_usage_based: Union[Unset, bool] = UNSET,
    page: Union[Unset, int] = UNSET,
    page_size: Union[Unset, int] = UNSET,
    parent_offering_uuid: Union[Unset, UUID] = UNSET,
    paused: Union[Unset, bool] = UNSET,
    plan_uuid: Union[Unset, UUID] = UNSET,
    project_name: Union[Unset, str] = UNSET,
    project_uuid: Union[Unset, UUID] = UNSET,
    provider_uuid: Union[Unset, UUID] = UNSET,
    query: Union[Unset, str] = UNSET,
    restrict_member_access: Union[Unset, bool] = UNSET,
    runtime_state: Union[Unset, str] = UNSET,
    service_manager_uuid: Union[Unset, UUID] = UNSET,
    state: Union[Unset, list[BookingResourcesListStateItem]] = UNSET,
    usage_based: Union[Unset, bool] = UNSET,
    visible_to_username: Union[Unset, str] = UNSET,
) -> Response[list["BookingResource"]]:
    """Mixin to optimize HEAD requests for DRF views bypassing serializer processing

    Args:
        backend_id (Union[Unset, str]):
        category_uuid (Union[Unset, UUID]):
        component_count (Union[Unset, float]):
        connected_customer_uuid (Union[Unset, UUID]):
        created (Union[Unset, datetime.datetime]):
        customer (Union[Unset, str]):
        customer_uuid (Union[Unset, UUID]):
        downscaled (Union[Unset, bool]):
        field (Union[Unset, list[BookingResourcesListFieldItem]]):
        has_terminate_date (Union[Unset, bool]):
        lexis_links_supported (Union[Unset, bool]):
        limit_based (Union[Unset, bool]):
        limit_component_count (Union[Unset, float]):
        modified (Union[Unset, datetime.datetime]):
        name (Union[Unset, str]):
        name_exact (Union[Unset, str]):
        o (Union[Unset, list[BookingResourcesListOItem]]):
        offering (Union[Unset, str]):
        offering_billable (Union[Unset, bool]):
        offering_shared (Union[Unset, bool]):
        offering_slug (Union[Unset, list[str]]):
        offering_type (Union[Unset, str]):
        offering_uuid (Union[Unset, list[UUID]]):
        only_limit_based (Union[Unset, bool]):
        only_usage_based (Union[Unset, bool]):
        page (Union[Unset, int]):
        page_size (Union[Unset, int]):
        parent_offering_uuid (Union[Unset, UUID]):
        paused (Union[Unset, bool]):
        plan_uuid (Union[Unset, UUID]):
        project_name (Union[Unset, str]):
        project_uuid (Union[Unset, UUID]):
        provider_uuid (Union[Unset, UUID]):
        query (Union[Unset, str]):
        restrict_member_access (Union[Unset, bool]):
        runtime_state (Union[Unset, str]):
        service_manager_uuid (Union[Unset, UUID]):
        state (Union[Unset, list[BookingResourcesListStateItem]]):
        usage_based (Union[Unset, bool]):
        visible_to_username (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list['BookingResource']]
    """

    kwargs = _get_kwargs(
        backend_id=backend_id,
        category_uuid=category_uuid,
        component_count=component_count,
        connected_customer_uuid=connected_customer_uuid,
        created=created,
        customer=customer,
        customer_uuid=customer_uuid,
        downscaled=downscaled,
        field=field,
        has_terminate_date=has_terminate_date,
        lexis_links_supported=lexis_links_supported,
        limit_based=limit_based,
        limit_component_count=limit_component_count,
        modified=modified,
        name=name,
        name_exact=name_exact,
        o=o,
        offering=offering,
        offering_billable=offering_billable,
        offering_shared=offering_shared,
        offering_slug=offering_slug,
        offering_type=offering_type,
        offering_uuid=offering_uuid,
        only_limit_based=only_limit_based,
        only_usage_based=only_usage_based,
        page=page,
        page_size=page_size,
        parent_offering_uuid=parent_offering_uuid,
        paused=paused,
        plan_uuid=plan_uuid,
        project_name=project_name,
        project_uuid=project_uuid,
        provider_uuid=provider_uuid,
        query=query,
        restrict_member_access=restrict_member_access,
        runtime_state=runtime_state,
        service_manager_uuid=service_manager_uuid,
        state=state,
        usage_based=usage_based,
        visible_to_username=visible_to_username,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    backend_id: Union[Unset, str] = UNSET,
    category_uuid: Union[Unset, UUID] = UNSET,
    component_count: Union[Unset, float] = UNSET,
    connected_customer_uuid: Union[Unset, UUID] = UNSET,
    created: Union[Unset, datetime.datetime] = UNSET,
    customer: Union[Unset, str] = UNSET,
    customer_uuid: Union[Unset, UUID] = UNSET,
    downscaled: Union[Unset, bool] = UNSET,
    field: Union[Unset, list[BookingResourcesListFieldItem]] = UNSET,
    has_terminate_date: Union[Unset, bool] = UNSET,
    lexis_links_supported: Union[Unset, bool] = UNSET,
    limit_based: Union[Unset, bool] = UNSET,
    limit_component_count: Union[Unset, float] = UNSET,
    modified: Union[Unset, datetime.datetime] = UNSET,
    name: Union[Unset, str] = UNSET,
    name_exact: Union[Unset, str] = UNSET,
    o: Union[Unset, list[BookingResourcesListOItem]] = UNSET,
    offering: Union[Unset, str] = UNSET,
    offering_billable: Union[Unset, bool] = UNSET,
    offering_shared: Union[Unset, bool] = UNSET,
    offering_slug: Union[Unset, list[str]] = UNSET,
    offering_type: Union[Unset, str] = UNSET,
    offering_uuid: Union[Unset, list[UUID]] = UNSET,
    only_limit_based: Union[Unset, bool] = UNSET,
    only_usage_based: Union[Unset, bool] = UNSET,
    page: Union[Unset, int] = UNSET,
    page_size: Union[Unset, int] = UNSET,
    parent_offering_uuid: Union[Unset, UUID] = UNSET,
    paused: Union[Unset, bool] = UNSET,
    plan_uuid: Union[Unset, UUID] = UNSET,
    project_name: Union[Unset, str] = UNSET,
    project_uuid: Union[Unset, UUID] = UNSET,
    provider_uuid: Union[Unset, UUID] = UNSET,
    query: Union[Unset, str] = UNSET,
    restrict_member_access: Union[Unset, bool] = UNSET,
    runtime_state: Union[Unset, str] = UNSET,
    service_manager_uuid: Union[Unset, UUID] = UNSET,
    state: Union[Unset, list[BookingResourcesListStateItem]] = UNSET,
    usage_based: Union[Unset, bool] = UNSET,
    visible_to_username: Union[Unset, str] = UNSET,
) -> list["BookingResource"]:
    """Mixin to optimize HEAD requests for DRF views bypassing serializer processing

    Args:
        backend_id (Union[Unset, str]):
        category_uuid (Union[Unset, UUID]):
        component_count (Union[Unset, float]):
        connected_customer_uuid (Union[Unset, UUID]):
        created (Union[Unset, datetime.datetime]):
        customer (Union[Unset, str]):
        customer_uuid (Union[Unset, UUID]):
        downscaled (Union[Unset, bool]):
        field (Union[Unset, list[BookingResourcesListFieldItem]]):
        has_terminate_date (Union[Unset, bool]):
        lexis_links_supported (Union[Unset, bool]):
        limit_based (Union[Unset, bool]):
        limit_component_count (Union[Unset, float]):
        modified (Union[Unset, datetime.datetime]):
        name (Union[Unset, str]):
        name_exact (Union[Unset, str]):
        o (Union[Unset, list[BookingResourcesListOItem]]):
        offering (Union[Unset, str]):
        offering_billable (Union[Unset, bool]):
        offering_shared (Union[Unset, bool]):
        offering_slug (Union[Unset, list[str]]):
        offering_type (Union[Unset, str]):
        offering_uuid (Union[Unset, list[UUID]]):
        only_limit_based (Union[Unset, bool]):
        only_usage_based (Union[Unset, bool]):
        page (Union[Unset, int]):
        page_size (Union[Unset, int]):
        parent_offering_uuid (Union[Unset, UUID]):
        paused (Union[Unset, bool]):
        plan_uuid (Union[Unset, UUID]):
        project_name (Union[Unset, str]):
        project_uuid (Union[Unset, UUID]):
        provider_uuid (Union[Unset, UUID]):
        query (Union[Unset, str]):
        restrict_member_access (Union[Unset, bool]):
        runtime_state (Union[Unset, str]):
        service_manager_uuid (Union[Unset, UUID]):
        state (Union[Unset, list[BookingResourcesListStateItem]]):
        usage_based (Union[Unset, bool]):
        visible_to_username (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list['BookingResource']
    """

    return sync_detailed(
        client=client,
        backend_id=backend_id,
        category_uuid=category_uuid,
        component_count=component_count,
        connected_customer_uuid=connected_customer_uuid,
        created=created,
        customer=customer,
        customer_uuid=customer_uuid,
        downscaled=downscaled,
        field=field,
        has_terminate_date=has_terminate_date,
        lexis_links_supported=lexis_links_supported,
        limit_based=limit_based,
        limit_component_count=limit_component_count,
        modified=modified,
        name=name,
        name_exact=name_exact,
        o=o,
        offering=offering,
        offering_billable=offering_billable,
        offering_shared=offering_shared,
        offering_slug=offering_slug,
        offering_type=offering_type,
        offering_uuid=offering_uuid,
        only_limit_based=only_limit_based,
        only_usage_based=only_usage_based,
        page=page,
        page_size=page_size,
        parent_offering_uuid=parent_offering_uuid,
        paused=paused,
        plan_uuid=plan_uuid,
        project_name=project_name,
        project_uuid=project_uuid,
        provider_uuid=provider_uuid,
        query=query,
        restrict_member_access=restrict_member_access,
        runtime_state=runtime_state,
        service_manager_uuid=service_manager_uuid,
        state=state,
        usage_based=usage_based,
        visible_to_username=visible_to_username,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    backend_id: Union[Unset, str] = UNSET,
    category_uuid: Union[Unset, UUID] = UNSET,
    component_count: Union[Unset, float] = UNSET,
    connected_customer_uuid: Union[Unset, UUID] = UNSET,
    created: Union[Unset, datetime.datetime] = UNSET,
    customer: Union[Unset, str] = UNSET,
    customer_uuid: Union[Unset, UUID] = UNSET,
    downscaled: Union[Unset, bool] = UNSET,
    field: Union[Unset, list[BookingResourcesListFieldItem]] = UNSET,
    has_terminate_date: Union[Unset, bool] = UNSET,
    lexis_links_supported: Union[Unset, bool] = UNSET,
    limit_based: Union[Unset, bool] = UNSET,
    limit_component_count: Union[Unset, float] = UNSET,
    modified: Union[Unset, datetime.datetime] = UNSET,
    name: Union[Unset, str] = UNSET,
    name_exact: Union[Unset, str] = UNSET,
    o: Union[Unset, list[BookingResourcesListOItem]] = UNSET,
    offering: Union[Unset, str] = UNSET,
    offering_billable: Union[Unset, bool] = UNSET,
    offering_shared: Union[Unset, bool] = UNSET,
    offering_slug: Union[Unset, list[str]] = UNSET,
    offering_type: Union[Unset, str] = UNSET,
    offering_uuid: Union[Unset, list[UUID]] = UNSET,
    only_limit_based: Union[Unset, bool] = UNSET,
    only_usage_based: Union[Unset, bool] = UNSET,
    page: Union[Unset, int] = UNSET,
    page_size: Union[Unset, int] = UNSET,
    parent_offering_uuid: Union[Unset, UUID] = UNSET,
    paused: Union[Unset, bool] = UNSET,
    plan_uuid: Union[Unset, UUID] = UNSET,
    project_name: Union[Unset, str] = UNSET,
    project_uuid: Union[Unset, UUID] = UNSET,
    provider_uuid: Union[Unset, UUID] = UNSET,
    query: Union[Unset, str] = UNSET,
    restrict_member_access: Union[Unset, bool] = UNSET,
    runtime_state: Union[Unset, str] = UNSET,
    service_manager_uuid: Union[Unset, UUID] = UNSET,
    state: Union[Unset, list[BookingResourcesListStateItem]] = UNSET,
    usage_based: Union[Unset, bool] = UNSET,
    visible_to_username: Union[Unset, str] = UNSET,
) -> Response[list["BookingResource"]]:
    """Mixin to optimize HEAD requests for DRF views bypassing serializer processing

    Args:
        backend_id (Union[Unset, str]):
        category_uuid (Union[Unset, UUID]):
        component_count (Union[Unset, float]):
        connected_customer_uuid (Union[Unset, UUID]):
        created (Union[Unset, datetime.datetime]):
        customer (Union[Unset, str]):
        customer_uuid (Union[Unset, UUID]):
        downscaled (Union[Unset, bool]):
        field (Union[Unset, list[BookingResourcesListFieldItem]]):
        has_terminate_date (Union[Unset, bool]):
        lexis_links_supported (Union[Unset, bool]):
        limit_based (Union[Unset, bool]):
        limit_component_count (Union[Unset, float]):
        modified (Union[Unset, datetime.datetime]):
        name (Union[Unset, str]):
        name_exact (Union[Unset, str]):
        o (Union[Unset, list[BookingResourcesListOItem]]):
        offering (Union[Unset, str]):
        offering_billable (Union[Unset, bool]):
        offering_shared (Union[Unset, bool]):
        offering_slug (Union[Unset, list[str]]):
        offering_type (Union[Unset, str]):
        offering_uuid (Union[Unset, list[UUID]]):
        only_limit_based (Union[Unset, bool]):
        only_usage_based (Union[Unset, bool]):
        page (Union[Unset, int]):
        page_size (Union[Unset, int]):
        parent_offering_uuid (Union[Unset, UUID]):
        paused (Union[Unset, bool]):
        plan_uuid (Union[Unset, UUID]):
        project_name (Union[Unset, str]):
        project_uuid (Union[Unset, UUID]):
        provider_uuid (Union[Unset, UUID]):
        query (Union[Unset, str]):
        restrict_member_access (Union[Unset, bool]):
        runtime_state (Union[Unset, str]):
        service_manager_uuid (Union[Unset, UUID]):
        state (Union[Unset, list[BookingResourcesListStateItem]]):
        usage_based (Union[Unset, bool]):
        visible_to_username (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list['BookingResource']]
    """

    kwargs = _get_kwargs(
        backend_id=backend_id,
        category_uuid=category_uuid,
        component_count=component_count,
        connected_customer_uuid=connected_customer_uuid,
        created=created,
        customer=customer,
        customer_uuid=customer_uuid,
        downscaled=downscaled,
        field=field,
        has_terminate_date=has_terminate_date,
        lexis_links_supported=lexis_links_supported,
        limit_based=limit_based,
        limit_component_count=limit_component_count,
        modified=modified,
        name=name,
        name_exact=name_exact,
        o=o,
        offering=offering,
        offering_billable=offering_billable,
        offering_shared=offering_shared,
        offering_slug=offering_slug,
        offering_type=offering_type,
        offering_uuid=offering_uuid,
        only_limit_based=only_limit_based,
        only_usage_based=only_usage_based,
        page=page,
        page_size=page_size,
        parent_offering_uuid=parent_offering_uuid,
        paused=paused,
        plan_uuid=plan_uuid,
        project_name=project_name,
        project_uuid=project_uuid,
        provider_uuid=provider_uuid,
        query=query,
        restrict_member_access=restrict_member_access,
        runtime_state=runtime_state,
        service_manager_uuid=service_manager_uuid,
        state=state,
        usage_based=usage_based,
        visible_to_username=visible_to_username,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    backend_id: Union[Unset, str] = UNSET,
    category_uuid: Union[Unset, UUID] = UNSET,
    component_count: Union[Unset, float] = UNSET,
    connected_customer_uuid: Union[Unset, UUID] = UNSET,
    created: Union[Unset, datetime.datetime] = UNSET,
    customer: Union[Unset, str] = UNSET,
    customer_uuid: Union[Unset, UUID] = UNSET,
    downscaled: Union[Unset, bool] = UNSET,
    field: Union[Unset, list[BookingResourcesListFieldItem]] = UNSET,
    has_terminate_date: Union[Unset, bool] = UNSET,
    lexis_links_supported: Union[Unset, bool] = UNSET,
    limit_based: Union[Unset, bool] = UNSET,
    limit_component_count: Union[Unset, float] = UNSET,
    modified: Union[Unset, datetime.datetime] = UNSET,
    name: Union[Unset, str] = UNSET,
    name_exact: Union[Unset, str] = UNSET,
    o: Union[Unset, list[BookingResourcesListOItem]] = UNSET,
    offering: Union[Unset, str] = UNSET,
    offering_billable: Union[Unset, bool] = UNSET,
    offering_shared: Union[Unset, bool] = UNSET,
    offering_slug: Union[Unset, list[str]] = UNSET,
    offering_type: Union[Unset, str] = UNSET,
    offering_uuid: Union[Unset, list[UUID]] = UNSET,
    only_limit_based: Union[Unset, bool] = UNSET,
    only_usage_based: Union[Unset, bool] = UNSET,
    page: Union[Unset, int] = UNSET,
    page_size: Union[Unset, int] = UNSET,
    parent_offering_uuid: Union[Unset, UUID] = UNSET,
    paused: Union[Unset, bool] = UNSET,
    plan_uuid: Union[Unset, UUID] = UNSET,
    project_name: Union[Unset, str] = UNSET,
    project_uuid: Union[Unset, UUID] = UNSET,
    provider_uuid: Union[Unset, UUID] = UNSET,
    query: Union[Unset, str] = UNSET,
    restrict_member_access: Union[Unset, bool] = UNSET,
    runtime_state: Union[Unset, str] = UNSET,
    service_manager_uuid: Union[Unset, UUID] = UNSET,
    state: Union[Unset, list[BookingResourcesListStateItem]] = UNSET,
    usage_based: Union[Unset, bool] = UNSET,
    visible_to_username: Union[Unset, str] = UNSET,
) -> list["BookingResource"]:
    """Mixin to optimize HEAD requests for DRF views bypassing serializer processing

    Args:
        backend_id (Union[Unset, str]):
        category_uuid (Union[Unset, UUID]):
        component_count (Union[Unset, float]):
        connected_customer_uuid (Union[Unset, UUID]):
        created (Union[Unset, datetime.datetime]):
        customer (Union[Unset, str]):
        customer_uuid (Union[Unset, UUID]):
        downscaled (Union[Unset, bool]):
        field (Union[Unset, list[BookingResourcesListFieldItem]]):
        has_terminate_date (Union[Unset, bool]):
        lexis_links_supported (Union[Unset, bool]):
        limit_based (Union[Unset, bool]):
        limit_component_count (Union[Unset, float]):
        modified (Union[Unset, datetime.datetime]):
        name (Union[Unset, str]):
        name_exact (Union[Unset, str]):
        o (Union[Unset, list[BookingResourcesListOItem]]):
        offering (Union[Unset, str]):
        offering_billable (Union[Unset, bool]):
        offering_shared (Union[Unset, bool]):
        offering_slug (Union[Unset, list[str]]):
        offering_type (Union[Unset, str]):
        offering_uuid (Union[Unset, list[UUID]]):
        only_limit_based (Union[Unset, bool]):
        only_usage_based (Union[Unset, bool]):
        page (Union[Unset, int]):
        page_size (Union[Unset, int]):
        parent_offering_uuid (Union[Unset, UUID]):
        paused (Union[Unset, bool]):
        plan_uuid (Union[Unset, UUID]):
        project_name (Union[Unset, str]):
        project_uuid (Union[Unset, UUID]):
        provider_uuid (Union[Unset, UUID]):
        query (Union[Unset, str]):
        restrict_member_access (Union[Unset, bool]):
        runtime_state (Union[Unset, str]):
        service_manager_uuid (Union[Unset, UUID]):
        state (Union[Unset, list[BookingResourcesListStateItem]]):
        usage_based (Union[Unset, bool]):
        visible_to_username (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list['BookingResource']
    """

    return (
        await asyncio_detailed(
            client=client,
            backend_id=backend_id,
            category_uuid=category_uuid,
            component_count=component_count,
            connected_customer_uuid=connected_customer_uuid,
            created=created,
            customer=customer,
            customer_uuid=customer_uuid,
            downscaled=downscaled,
            field=field,
            has_terminate_date=has_terminate_date,
            lexis_links_supported=lexis_links_supported,
            limit_based=limit_based,
            limit_component_count=limit_component_count,
            modified=modified,
            name=name,
            name_exact=name_exact,
            o=o,
            offering=offering,
            offering_billable=offering_billable,
            offering_shared=offering_shared,
            offering_slug=offering_slug,
            offering_type=offering_type,
            offering_uuid=offering_uuid,
            only_limit_based=only_limit_based,
            only_usage_based=only_usage_based,
            page=page,
            page_size=page_size,
            parent_offering_uuid=parent_offering_uuid,
            paused=paused,
            plan_uuid=plan_uuid,
            project_name=project_name,
            project_uuid=project_uuid,
            provider_uuid=provider_uuid,
            query=query,
            restrict_member_access=restrict_member_access,
            runtime_state=runtime_state,
            service_manager_uuid=service_manager_uuid,
            state=state,
            usage_based=usage_based,
            visible_to_username=visible_to_username,
        )
    ).parsed
