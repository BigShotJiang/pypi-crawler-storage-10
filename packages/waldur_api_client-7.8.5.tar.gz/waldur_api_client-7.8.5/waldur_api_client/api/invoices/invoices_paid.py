from http import HTTPStatus
from typing import Any, Union
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.invoice import Invoice
from ...models.paid_request import PaidRequest
from ...models.paid_request_form import PaidRequestForm
from ...models.paid_request_multipart import PaidRequestMultipart
from ...types import Response


def _get_kwargs(
    uuid: UUID,
    *,
    body: Union[
        PaidRequest,
        PaidRequestForm,
        PaidRequestMultipart,
    ],
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/api/invoices/{uuid}/paid/",
    }

    if isinstance(body, PaidRequest):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PaidRequestForm):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PaidRequestMultipart):
        _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Invoice:
    if response.status_code == 200:
        response_200 = Invoice.from_dict(response.json())

        return response_200
    raise errors.UnexpectedStatus(response.status_code, response.content)


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Invoice]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: Union[
        PaidRequest,
        PaidRequestForm,
        PaidRequestMultipart,
    ],
) -> Response[Invoice]:
    """Mark invoice as paid and optionally create payment record with proof of payment.

    Args:
        uuid (UUID):
        body (PaidRequest):
        body (PaidRequestForm):
        body (PaidRequestMultipart):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Invoice]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: Union[
        PaidRequest,
        PaidRequestForm,
        PaidRequestMultipart,
    ],
) -> Invoice:
    """Mark invoice as paid and optionally create payment record with proof of payment.

    Args:
        uuid (UUID):
        body (PaidRequest):
        body (PaidRequestForm):
        body (PaidRequestMultipart):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Invoice
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: Union[
        PaidRequest,
        PaidRequestForm,
        PaidRequestMultipart,
    ],
) -> Response[Invoice]:
    """Mark invoice as paid and optionally create payment record with proof of payment.

    Args:
        uuid (UUID):
        body (PaidRequest):
        body (PaidRequestForm):
        body (PaidRequestMultipart):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Invoice]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: Union[
        PaidRequest,
        PaidRequestForm,
        PaidRequestMultipart,
    ],
) -> Invoice:
    """Mark invoice as paid and optionally create payment record with proof of payment.

    Args:
        uuid (UUID):
        body (PaidRequest):
        body (PaidRequestForm):
        body (PaidRequestMultipart):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Invoice
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            body=body,
        )
    ).parsed
