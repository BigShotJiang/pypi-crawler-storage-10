from setuptools import setup, find_packages

setup(
    name="ahlem_ousaid_regression",
    version="1.0.0",
    author="Ahlem Ousaid",
    author_email="a.mohammedousaid@esi-sba.dz",
  
    description="Simple Linear Regression implemented from scratch",
     license='LICENSE.txt',
    packages=find_packages(),
    install_requires=[],
)
