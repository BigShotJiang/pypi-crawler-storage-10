# linear_regression_pkg/model.py
class SimpleLinearRegression:
    def __init__(self):
        self.m = 0  # slope
        self.b = 0  # intercept

    def fit(self, X, y):
        """
        Fit the linear regression model to the given data.
        X: list or numpy array of features
        y: list or numpy array of target values
        """
        n = len(X)
        mean_x = sum(X) / n
        mean_y = sum(y) / n

        num = sum([(X[i] - mean_x) * (y[i] - mean_y) for i in range(n)])
        den = sum([(X[i] - mean_x) ** 2 for i in range(n)])

        self.m = num / den
        self.b = mean_y - self.m * mean_x

    def predict(self, X):
        """Return predictions for given X."""
        return [self.m * x + self.b for x in X]

    def coefficients(self):
        """Return model coefficients (slope and intercept)."""
        return self.m, self.b
