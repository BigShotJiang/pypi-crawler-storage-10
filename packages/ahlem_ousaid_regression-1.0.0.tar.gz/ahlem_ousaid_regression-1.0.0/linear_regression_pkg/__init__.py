from .model import SimpleLinearRegression
