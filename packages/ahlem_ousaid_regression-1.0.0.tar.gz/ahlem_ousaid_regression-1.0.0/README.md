# ahlem_ousaid_regression

A simple linear regression model built from scratch in Python.

## Example

```python
from ahlem_ousaid_regression import SimpleLinearRegression

X = [1, 2, 3, 4, 5]
y = [2, 4, 5, 4, 5]

model = SimpleLinearRegression()
model.fit(X, y)
print(model.coefficients())
print(model.predict([6]))
