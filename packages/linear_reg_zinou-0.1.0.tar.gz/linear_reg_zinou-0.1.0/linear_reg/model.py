import numpy as np

class LinearRegression:
    def __init__(self, x, y):
        self.data = np.array(x)
        self.label = np.array(y)
        self.m = 0
        self.b = 0
        self.n = len(x)

    def fit(self, epochs, lr):
        # Implementing Gradient Descent
        for i in range(epochs):
            y_pred = self.m * self.data + self.b

            # Calculating derivatives w.r.t parameters
            D_m = (-2 / self.n) * np.sum(self.data * (self.label - y_pred))
            D_b = (-2 / self.n) * np.sum(self.label - y_pred)

            # Updating parameters
            self.m = self.m - lr * D_m
            self.b = self.b - lr * D_b

    def predict(self, inp):
        inp = np.array(inp)
        y_pred = self.m * inp + self.b
        return y_pred
