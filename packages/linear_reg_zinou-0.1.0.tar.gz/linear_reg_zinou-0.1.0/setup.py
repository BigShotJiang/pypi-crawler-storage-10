from setuptools import setup,find_packages
 
setup(
   name='linear_reg_zinou',
   version='0.1.0',
   author='Zine Eddine Tahri',
   author_email='z.tahri@esi-sba.dz',
   packages=find_packages(),
   url='http://pypi.python.org/pypi/linear_reg_Zinou/',
   license='LICENSE.txt',
   long_description_content_type="text/markdown",
   install_requires=['numpy']
)