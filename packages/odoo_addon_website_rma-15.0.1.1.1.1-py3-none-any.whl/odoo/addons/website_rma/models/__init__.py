# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import ir_model
from . import res_config_settings
from . import rma
from . import website
