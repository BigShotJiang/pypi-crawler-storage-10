"""
Utility functions and classes for Data Manager.
"""
