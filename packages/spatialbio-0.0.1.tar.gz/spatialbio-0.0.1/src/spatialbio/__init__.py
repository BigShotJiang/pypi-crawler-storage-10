"""Minimal client for the Spatial Omics search endpoint."""

from __future__ import annotations

import os
from typing import Any, Dict, Iterable, Optional

import requests

DEFAULT_TIMEOUT = 10
DEFAULT_BASE_URL = "https://spatial.tools"
SEARCH_PATH = "/api/notion/database"


class SpatialBioError(RuntimeError):
    """Raised when the Spatial Omics API returns an error response."""


def _comma_join(values: Optional[Iterable[str]]) -> Optional[str]:
    if values is None:
        return None
    cleaned = [v.strip() for v in values if v and v.strip()]
    return ",".join(cleaned) if cleaned else None


def search_tools(
    *,
    query: Optional[str] = None,
    page_size: int = 12,
    cursor: Optional[int] = None,
    languages: Optional[Iterable[str]] = None,
    stages: Optional[Iterable[str]] = None,
    year_min: Optional[int] = None,
    year_max: Optional[int] = None,
    tasks: Optional[Iterable[str]] = None,
    sort_by: Optional[str] = None,
    sort_direction: Optional[str] = None,
    base_url: Optional[str] = None,
    api_token: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> Dict[str, Any]:
    """
    Query the Spatial Omics search endpoint.

    All keyword arguments map directly to the query parameters accepted by the
    `/api/notion/database` route in the Spatial Tools Next.js application.
    """

    resolved_base_url = (
        base_url
        or os.getenv("SPATIALBIO_API_BASE")
        or os.getenv("SPATIAL_TOOLS_API_BASE")
        or DEFAULT_BASE_URL
    ).rstrip("/")
    resolved_token = (
        api_token
        or os.getenv("SPATIALBIO_API_TOKEN")
        or os.getenv("SPATIAL_TOOLS_API_TOKEN")
    )

    params: Dict[str, Any] = {
        "pageSize": page_size,
    }
    if query:
        params["q"] = query
    if cursor is not None:
        params["cursor"] = cursor
    if year_min is not None:
        params["yearMin"] = year_min
    if year_max is not None:
        params["yearMax"] = year_max
    if sort_by:
        params["sortBy"] = sort_by
    if sort_direction:
        params["sortDirection"] = sort_direction

    languages_value = _comma_join(languages)
    if languages_value:
        params["languages"] = languages_value

    stages_value = _comma_join(stages)
    if stages_value:
        params["stages"] = stages_value

    tasks_value = _comma_join(tasks)
    if tasks_value:
        params["tasks"] = tasks_value

    headers = {"Accept": "application/json"}
    if resolved_token:
        headers["Authorization"] = f"Bearer {resolved_token}"

    response = requests.get(
        f"{resolved_base_url}{SEARCH_PATH}",
        params=params,
        headers=headers,
        timeout=timeout,
    )

    if response.status_code >= 400:
        raise SpatialBioError(
            f"Search request failed with status {response.status_code}: "
            f"{response.text}"
        )

    return response.json()


__all__ = ["SpatialBioError", "search_tools"]
