# spatialbio

Minimal Python bindings for the Spatial Omics directory search API. Install the
package and call `search_tools()` to look up tools that match your query.

```bash
python -m pip install spatialbio
```

```python
from spatialbio import search_tools

results = search_tools(query="spatial transcriptomics", page_size=5)
for tool in results["results"]:
    print(tool["name"], tool.get("year"))
```

You will need an API token with permission to hit the Spatial Omics search
endpoint. Provide it via the `SPATIALBIO_API_TOKEN` (or legacy
`SPATIAL_TOOLS_API_TOKEN`) environment variable or the `api_token` keyword
argument. Use `SPATIALBIO_API_BASE` (or `SPATIAL_TOOLS_API_BASE`) to target a
non-production deployment if required (defaults to `https://spatial.tools`).

MIT License.
