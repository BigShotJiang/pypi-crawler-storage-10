# Build Unblocker MCP

A Model-Context-Protocol (MCP) server for Cursor IDE to terminate hung Windows build executables.

## Features

- Monitors specified build processes (`cl.exe`, `link.exe`, `msbuild.exe`, etc.)
- Terminates processes that are idle (less than 1% CPU usage) for a configurable duration (default 90 seconds)
- Provides a tool (`unblock_build`) for Cursor IDE to trigger the unblocking process

## Installation

1.  Ensure you have Python 3.11 or later installed.
2.  Install using pipx (recommended for CLI tools):
    ```bash
    pipx install .
    ```
    Or using pip:
    ```bash
    pip install .
    ```

## Cursor Integration

Add the following to your Cursor IDE settings (`settings.json`):

```json
{
  "mcpServers": {
    "build-unblocker": {
      "command": "unblock-build-mcp"
    }
  }
}
```

## Local Smoke Test

You can run the tool manually to test it (use `--dry-run` to avoid killing processes):

```bash
pipx run unblock-build-mcp --idle-seconds 5 --dry-run
```

## Continuous Integration

[![CI Status](https://github.com/your-github-username/build-unblocker-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/your-github-username/build-unblocker-mcp/actions/workflows/ci.yml)
*(Replace `your-github-username` with your actual GitHub username and `build-unblocker-mcp` with the repository name)*

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.