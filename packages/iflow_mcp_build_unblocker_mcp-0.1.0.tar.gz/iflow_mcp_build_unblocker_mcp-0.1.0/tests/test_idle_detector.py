import pytest
import time
import psutil # Import psutil
from unittest.mock import MagicMock
from build_unblocker_mcp.server import is_process_idle

# Mock psutil.Process object
class MockProcess:
    def __init__(self, pid, name, create_time):
        self.info = {'pid': pid, 'name': name, 'create_time': create_time}
        self._cpu_percent = 0.0

    def cpu_percent(self, interval=None):
        return self._cpu_percent

    def set_cpu_percent(self, percent):
        self._cpu_percent = percent

    def create_time(self): # Add create_time method
        return self.info['create_time']

    def kill(self):
        pass # Mock kill

def test_is_process_idle_low_cpu_old_process():
    """Process with low CPU and older than idle_seconds should be idle."""
    current_time = time.time()
    idle_seconds = 10
    proc_create_time = current_time - idle_seconds - 5 # Older than idle_seconds
    mock_proc = MockProcess(123, "cl.exe", proc_create_time)
    mock_proc.set_cpu_percent(0.5) # Low CPU

    assert is_process_idle(mock_proc, idle_seconds) is True

def test_is_process_idle_high_cpu():
    """Process with high CPU should not be idle."""
    current_time = time.time()
    idle_seconds = 10
    proc_create_time = current_time - idle_seconds - 5
    mock_proc = MockProcess(124, "link.exe", proc_create_time)
    mock_proc.set_cpu_percent(5.0) # High CPU

    assert is_process_idle(mock_proc, idle_seconds) is False

def test_is_process_idle_young_process():
    """Process younger than idle_seconds should not be idle."""
    current_time = time.time()
    idle_seconds = 10
    proc_create_time = current_time - idle_seconds + 5 # Younger than idle_seconds
    mock_proc = MockProcess(125, "msbuild.exe", proc_create_time)
    mock_proc.set_cpu_percent(0.5) # Low CPU

    assert is_process_idle(mock_proc, idle_seconds) is False

def test_is_process_idle_edge_case_exact_idle_seconds():
    """Process exactly at idle_seconds should not be idle."""
    current_time = time.time()
    idle_seconds = 10
    proc_create_time = current_time - idle_seconds
    mock_proc = MockProcess(126, "rc.exe", proc_create_time)
    mock_proc.set_cpu_percent(0.5)

    # Process exactly at idle_seconds with low CPU should be considered idle
    assert is_process_idle(mock_proc, idle_seconds) is True

def test_is_process_idle_psutil_exception(mocker):
    """Handle psutil exceptions gracefully."""
    mock_proc = MagicMock()
    mock_proc.cpu_percent.side_effect = psutil.NoSuchProcess(1) # Provide a dummy pid
    idle_seconds = 10

    assert is_process_idle(mock_proc, idle_seconds) is False

    mock_proc.cpu_percent.side_effect = psutil.AccessDenied()
    assert is_process_idle(mock_proc, idle_seconds) is False

    mock_proc.cpu_percent.side_effect = psutil.ZombieProcess(1) # Provide a dummy pid
    assert is_process_idle(mock_proc, idle_seconds) is False