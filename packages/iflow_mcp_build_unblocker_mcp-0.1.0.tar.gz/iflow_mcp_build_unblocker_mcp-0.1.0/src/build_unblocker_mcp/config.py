import typing as t
from dataclasses import dataclass, field

DEFAULT_PROCESSES: t.List[str] = [
    "cl.exe",
    "link.exe",
    "msbuild.exe",
    "rc.exe",
    "csc.exe",
    "devenv.exe", # Visual Studio IDE process, can also hang builds
    "cmake.exe",
    "ninja.exe",
    "make.exe",
    "gcc.exe",
    "g++.exe",
    "clang.exe",
    "clang++.exe",
]

@dataclass
class Settings:
    idle_seconds: int = 90
    process_names: t.List[str] = field(default_factory=lambda: DEFAULT_PROCESSES)
    dry_run: bool = False