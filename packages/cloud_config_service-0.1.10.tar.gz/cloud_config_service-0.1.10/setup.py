from setuptools import setup, find_packages

setup(
    name="cloud_config_service",
    version="0.1.10",
    author="Aaditya Muleva, Vinay Shankar Miryala, Aakash Kag",
    author_email="aaditya.muleva@trovehealth.io, vinay.miryala@trovehealth.io, aakash.kag@trovehealth.io",
    description="A unified configuration loader for local, AWS SSM, Azure App Configuration, and GCP Secret Manager.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    license="MIT",
    install_requires=[
        "python-dotenv>=1.0.0",
        # "boto3>=1.26.0",
        "azure-appconfiguration>=1.4.0",
        "azure-identity>=1.12.0",
        "google-cloud-secret-manager>=2.16.0",
    ]
)
