# Copyright 2024 Canonical Ltd.
# See LICENSE file for licensing details.
"""The event managers for mongo charms.

Interacts with workloads.
"""
