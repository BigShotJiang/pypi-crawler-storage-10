Note on pypy and lxml
================================================================================

When executing the unit tests on pypy3, it's found that lxml 4.0.0 works well
on pypy3. lxml 3.6.4 works well on pypy2.


