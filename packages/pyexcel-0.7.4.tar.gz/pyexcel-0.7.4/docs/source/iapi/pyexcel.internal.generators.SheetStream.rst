pyexcel.internal.generators.SheetStream
=======================================

.. currentmodule:: pyexcel.internal.generators

.. autoclass:: SheetStream

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SheetStream.__init__
      ~SheetStream.get_internal_array
      ~SheetStream.to_array
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SheetStream.array
   
   