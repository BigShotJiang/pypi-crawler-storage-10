pyexcel.get\_dict
=================

.. currentmodule:: pyexcel

.. autofunction:: get_dict