pyexcel.save\_book\_as
======================

.. currentmodule:: pyexcel

.. autofunction:: save_book_as