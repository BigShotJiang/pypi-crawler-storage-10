pyexcel.Book.save\_as
=====================

.. currentmodule:: pyexcel

.. automethod:: Book.save_as