pyexcel.Sheet.save\_to\_memory
==============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.save_to_memory