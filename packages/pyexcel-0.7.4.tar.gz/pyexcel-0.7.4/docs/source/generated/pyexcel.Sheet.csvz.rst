pyexcel.Sheet.csvz
==================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.csvz