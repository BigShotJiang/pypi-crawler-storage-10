pyexcel.Book.xls
================

.. currentmodule:: pyexcel

.. autoattribute:: Book.xls