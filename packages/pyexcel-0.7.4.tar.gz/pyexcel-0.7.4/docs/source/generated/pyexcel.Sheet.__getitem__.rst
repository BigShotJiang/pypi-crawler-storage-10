pyexcel.Sheet.\_\_getitem\_\_
=============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.__getitem__