pyexcel.split\_a\_book
======================

.. currentmodule:: pyexcel

.. autofunction:: split_a_book