pyexcel.Sheet.cell\_value
=========================

.. currentmodule:: pyexcel

.. automethod:: Sheet.cell_value