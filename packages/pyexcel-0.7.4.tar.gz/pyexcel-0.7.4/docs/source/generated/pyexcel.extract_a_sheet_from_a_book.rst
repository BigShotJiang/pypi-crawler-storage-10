pyexcel.extract\_a\_sheet\_from\_a\_book
========================================

.. currentmodule:: pyexcel

.. autofunction:: extract_a_sheet_from_a_book