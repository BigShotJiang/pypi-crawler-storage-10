pyexcel.Sheet.number\_of\_columns
=================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.number_of_columns