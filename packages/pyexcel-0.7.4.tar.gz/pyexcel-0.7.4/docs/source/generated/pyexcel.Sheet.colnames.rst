pyexcel.Sheet.colnames
======================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.colnames