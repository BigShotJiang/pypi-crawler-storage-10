pyexcel.Book.number\_of\_sheets
===============================

.. currentmodule:: pyexcel

.. automethod:: Book.number_of_sheets