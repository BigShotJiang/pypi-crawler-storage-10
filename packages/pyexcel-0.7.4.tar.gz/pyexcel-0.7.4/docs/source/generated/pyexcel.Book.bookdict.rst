pyexcel.Book.bookdict
=====================

.. currentmodule:: pyexcel

.. autoattribute:: Book.bookdict