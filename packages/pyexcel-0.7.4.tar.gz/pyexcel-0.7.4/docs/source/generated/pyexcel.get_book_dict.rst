pyexcel.get\_book\_dict
=======================

.. currentmodule:: pyexcel

.. autofunction:: get_book_dict