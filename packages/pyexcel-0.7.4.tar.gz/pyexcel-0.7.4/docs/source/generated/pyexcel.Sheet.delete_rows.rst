pyexcel.Sheet.delete\_rows
==========================

.. currentmodule:: pyexcel

.. automethod:: Sheet.delete_rows