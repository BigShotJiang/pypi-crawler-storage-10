pyexcel.Sheet.delete\_named\_column\_at
=======================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.delete_named_column_at