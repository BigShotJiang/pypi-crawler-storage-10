pyexcel.iget\_book
==================

.. currentmodule:: pyexcel

.. autofunction:: iget_book