pyexcel.isave\_as
=================

.. currentmodule:: pyexcel

.. autofunction:: isave_as