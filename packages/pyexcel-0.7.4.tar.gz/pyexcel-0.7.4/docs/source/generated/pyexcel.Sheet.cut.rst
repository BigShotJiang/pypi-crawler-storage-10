pyexcel.Sheet.cut
=================

.. currentmodule:: pyexcel

.. automethod:: Sheet.cut