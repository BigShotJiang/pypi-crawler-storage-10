pyexcel.Book.save\_to\_database
===============================

.. currentmodule:: pyexcel

.. automethod:: Book.save_to_database