pyexcel.Sheet.row\_range
========================

.. currentmodule:: pyexcel

.. automethod:: Sheet.row_range