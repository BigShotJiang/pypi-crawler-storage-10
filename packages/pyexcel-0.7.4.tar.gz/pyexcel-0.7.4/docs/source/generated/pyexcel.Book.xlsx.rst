pyexcel.Book.xlsx
=================

.. currentmodule:: pyexcel

.. autoattribute:: Book.xlsx