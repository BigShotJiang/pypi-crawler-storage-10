pyexcel.get\_book
=================

.. currentmodule:: pyexcel

.. autofunction:: get_book