pyexcel.Sheet.named\_column\_at
===============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.named_column_at