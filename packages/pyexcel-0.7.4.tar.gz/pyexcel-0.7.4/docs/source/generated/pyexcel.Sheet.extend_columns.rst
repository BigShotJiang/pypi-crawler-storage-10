pyexcel.Sheet.extend\_columns
=============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.extend_columns