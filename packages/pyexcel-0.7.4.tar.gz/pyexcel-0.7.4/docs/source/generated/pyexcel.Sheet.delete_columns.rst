pyexcel.Sheet.delete\_columns
=============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.delete_columns