pyexcel.Sheet.save\_to\_django\_model
=====================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.save_to_django_model