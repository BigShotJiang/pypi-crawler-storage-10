pyexcel.Sheet.save\_as
======================

.. currentmodule:: pyexcel

.. automethod:: Sheet.save_as