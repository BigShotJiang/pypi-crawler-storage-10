pyexcel.Sheet.ods
=================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.ods