pyexcel.Sheet.column\_range
===========================

.. currentmodule:: pyexcel

.. automethod:: Sheet.column_range