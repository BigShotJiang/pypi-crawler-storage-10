pyexcel.Sheet.array
===================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.array