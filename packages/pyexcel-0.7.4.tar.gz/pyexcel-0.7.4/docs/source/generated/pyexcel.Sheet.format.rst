pyexcel.Sheet.format
====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.format