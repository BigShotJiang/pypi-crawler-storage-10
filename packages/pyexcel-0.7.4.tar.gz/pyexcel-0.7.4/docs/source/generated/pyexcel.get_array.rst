pyexcel.get\_array
==================

.. currentmodule:: pyexcel

.. autofunction:: get_array