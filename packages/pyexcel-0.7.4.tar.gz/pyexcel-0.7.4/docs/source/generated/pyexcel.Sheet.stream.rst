pyexcel.Sheet.stream
====================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.stream