pyexcel.Sheet.transpose
=======================

.. currentmodule:: pyexcel

.. automethod:: Sheet.transpose