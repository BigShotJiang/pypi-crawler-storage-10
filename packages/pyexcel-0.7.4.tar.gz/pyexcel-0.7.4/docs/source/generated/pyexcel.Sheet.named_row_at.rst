pyexcel.Sheet.named\_row\_at
============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.named_row_at