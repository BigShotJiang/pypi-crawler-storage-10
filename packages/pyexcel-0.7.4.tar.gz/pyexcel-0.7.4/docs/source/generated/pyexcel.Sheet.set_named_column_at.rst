pyexcel.Sheet.set\_named\_column\_at
====================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.set_named_column_at