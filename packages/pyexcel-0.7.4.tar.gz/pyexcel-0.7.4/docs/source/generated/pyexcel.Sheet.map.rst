pyexcel.Sheet.map
=================

.. currentmodule:: pyexcel

.. automethod:: Sheet.map