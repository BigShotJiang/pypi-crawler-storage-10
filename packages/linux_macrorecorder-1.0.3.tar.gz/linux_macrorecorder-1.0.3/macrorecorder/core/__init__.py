"""Core helpers for the Macro Recorder package."""
