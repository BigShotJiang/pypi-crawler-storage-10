mcp-serper-search MCP server exposing the Serper web search tool.

Env:
- SERPER_API_KEY

Run:
```bash
python -m src.serper_search.server
```
