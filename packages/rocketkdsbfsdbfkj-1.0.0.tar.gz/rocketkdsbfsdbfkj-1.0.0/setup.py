from pathlib import Path
from setuptools import setup, find_packages

here = Path(__file__).parent
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
   name="rocketkdsbfsdbfkj",
   version="1.0.0",
   description="A small library for modelling rockets, shuttles and circle rockets",
   long_description=long_description,
   long_description_content_type="text/markdown",
   url="https://github.com/ZakLr/rocket",
   author="Zaki",
   author_email="zaki@example.com",
   license="MIT",
   packages=find_packages(exclude=("tests", "docs")),
   include_package_data=True,
   zip_safe=False,
   classifiers=[
      "Development Status :: 5 - Production/Stable",
      "Intended Audience :: Developers",
      "License :: OSI Approved :: MIT License",
      "Programming Language :: Python :: 3",
      "Programming Language :: Python :: 3 :: Only",
      "Programming Language :: Python :: 3.8",
      "Programming Language :: Python :: 3.9",
      "Programming Language :: Python :: 3.10",
   ],
   python_requires=">=3.8",
   install_requires=[],
   keywords="rocket simulation shuttle geometry",
   project_urls={
      "Source": "https://github.com/ZakLr/rocket",
      "Tracker": "https://github.com/ZakLr/rocket/issues",
   },
)