# rocket

`rocket` is a Python library for simulating rockets and shuttles in games or physics simulations.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket`.

```bash
pip install rocket
```

## Usage

```python
from rocket import Rocket, Shuttle

# Create a rocket
r = Rocket(0, 0)
print(r)  # A Rocket positioned at (0,0)

# Create a shuttle
s = Shuttle(10, 20, 5)
print(s)  # Shuttle(10,20, flights_completed=5)

# Calculate distance
dist = r.get_distance(s)
print(dist)
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
