"""Utility functions and classes for the maybankforme application."""

import logging
import os
import sys
from typing import Any

__all__ = ["DockerSafeLogger"]


class DockerSafeLogger:
    """Logger configured for Docker environments with proper stdout handling.

    This logger is optimized for container environments where logs need to be
    properly captured by container logging drivers. It uses stdout for all
    log messages and supports log level configuration via environment variables.

    Args:
        None

    Attributes:
        logger: The configured logging.Logger instance

    Examples:
        >>> log = DockerSafeLogger().logger
        >>> log.info("Processing started")
    """

    def __init__(self) -> None:
        """Initialize the logger with Docker-safe configuration."""
        self.logger: logging.Logger = logging.getLogger(self.__class__.__name__)
        self._configure_logger()

    def _configure_logger(self) -> None:
        """Configure logger with appropriate handlers and formatters.

        Sets up:
        - Log level from LOG_LEVEL environment variable (default: INFO)
        - Simple formatter suitable for container logs
        - Stdout handler for proper log capture
        - No propagation to root logger
        """
        # Set default log level from environment or use INFO
        log_level = os.getenv("LOG_LEVEL", "INFO").upper()
        self.logger.setLevel(log_level)

        # Use a simple format that works well with container logs
        formatter = logging.Formatter(
            "%(asctime)s | %(process)d | %(levelname)-8s | %(module)s | %(message)s"
        )

        # Console handler using stdout (properly flushed)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(log_level)
        handler.setFormatter(formatter)

        # Add handler only if none exist
        if not self.logger.handlers:
            self.logger.addHandler(handler)

        # Prevent propagation to root logger
        self.logger.propagate = False

    def __getattr__(self, name: str) -> Any:
        """Delegate logger methods to the underlying logger instance.

        Args:
            name: Name of the attribute/method to access

        Returns:
            The requested attribute from the logger instance
        """
        return getattr(self.logger, name)
