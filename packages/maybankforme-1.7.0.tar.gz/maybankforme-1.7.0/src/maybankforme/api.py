"""FastAPI application for processing Maybank credit card statement PDF files.

This module provides a REST API for uploading PDF statement files and
receiving processed transaction data in CSV format.
"""

import csv
import io
import logging
import os
import tempfile
from datetime import datetime
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import StreamingResponse

from .common.pdf_convert_txt import pdf_to_text
from .common.txt_convert_csv import txt_to_csv
from .common.utils import DockerSafeLogger

log: logging.Logger = DockerSafeLogger().logger

app = FastAPI(
    title="Maybank For Me API",
    description="API for processing Maybank credit card statement PDF files to CSV",
    version="2.0.0",
)


def process_single_pdf_to_csv(
    pdf_file_path: str, password: str = ""
) -> tuple[str, list[list[str]]]:
    """Process a single PDF file and return the report date and transaction data.

    Args:
        pdf_file_path: Path to the PDF file
        password: Password to decrypt PDF (if needed)

    Returns:
        Tuple of (report_date, transaction_data)

    Raises:
        ValueError: If filename format is invalid
        FileNotFoundError: If PDF file does not exist
        OSError: If file operations fail
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        # Extract filename and report date
        filename = os.path.basename(pdf_file_path)
        base_name = os.path.splitext(filename)[0]

        # Extract report date from filename (format: Statement_YYYYMMDD.pdf)
        parts = base_name.split("_")
        if len(parts) < 2:
            msg = (
                f"Invalid filename format: {filename}. "
                f"Expected format: Statement_YYYYMMDD.pdf"
            )
            raise ValueError(msg)

        report_date = parts[-1]

        # Create temporary paths for text and csv
        txt_path = os.path.join(temp_dir, f"{base_name}.txt")
        csv_path = os.path.join(temp_dir, f"{report_date}-{parts[0]}.csv")

        # Convert PDF to text
        pdf_to_text(pdf_file_path, txt_path, password)

        # Convert text to CSV
        txt_to_csv(txt_path, csv_path)

        # Read CSV data
        content: list[list[str]] = []
        with open(csv_path, encoding="utf-8") as f:
            csv_reader = csv.reader(f)
            for i, row in enumerate(csv_reader):
                if i == 0:  # Skip header
                    continue
                content.append(row)

        return (report_date, content)


def process_report_data(report_date: str, data: list[list[str]]) -> list[list[str]]:
    """Process transaction data by adding year information based on report date.

    Handles year boundaries where December transactions may appear on
    a January statement.

    Args:
        report_date: Report date in YYYYMMDD format
        data: List of transaction rows
            [posting_date, transaction_date, description, amount]

    Returns:
        List of processed transaction rows with full dates

    Raises:
        ValueError: If report_date format is invalid
    """
    try:
        report_date_obj = datetime.strptime(report_date, "%Y%m%d")
    except ValueError as e:
        msg = f"Invalid report date format: {report_date}"
        log.exception(msg)
        raise ValueError(msg) from e

    modified_data: list[list[str]] = []

    for row in data:
        try:
            year = report_date_obj.year

            # Validate and parse posting date
            posting_parts = row[0].split("/")
            if len(posting_parts) < 2:
                log.warning(f"Invalid posting date format: {row[0]}")
                continue
            posting_month = int(posting_parts[1])

            # Validate and parse transaction date
            trans_parts = row[1].split("/")
            if len(trans_parts) < 2:
                log.warning(f"Invalid transaction date format: {row[1]}")
                continue
            trans_month = int(trans_parts[1])

            # Handle year boundary for posting date
            if report_date_obj.month == 1 and posting_month == 12:
                post_year = year - 1
            else:
                post_year = year

            # Handle year boundary for transaction date
            if report_date_obj.month == 1 and trans_month == 12:
                trans_year = year - 1
            else:
                trans_year = year

            modified_data.append(
                [
                    f"{row[0]}/{post_year}",  # Posting Date
                    f"{row[1]}/{trans_year}",  # Transaction Date
                    row[2],  # Description
                    row[3],  # Amount
                ]
            )
        except (ValueError, IndexError) as e:
            log.warning(f"Error processing row {row}: {e}")
            continue

    return modified_data


@app.get("/")
async def root() -> dict[str, Any]:
    """Root endpoint with API information.

    Returns:
        Dictionary containing API name, version, description, and available endpoints
    """
    return {
        "name": "Maybank For Me API",
        "version": "2.0.0",
        "description": "API for processing Maybank credit card statement PDF files",
        "endpoints": {
            "/process": "POST - Upload PDF files and get processed CSV",
            "/health": "GET - Health check endpoint",
        },
    }


@app.get("/health")
async def health() -> dict[str, str]:
    """Health check endpoint.

    Returns:
        Dictionary with status indicator
    """
    return {"status": "healthy"}


@app.post("/process")
async def process_statements(
    files: list[UploadFile] = File(..., description="PDF statement files to process"),
    password: str = Form("", description="Password to decrypt PDF files (if needed)"),
) -> StreamingResponse:
    """Process Maybank credit card statement PDF files and return CSV data.

    Args:
        files: List of PDF files to process
        password: Optional password to decrypt PDF files

    Returns:
        CSV file with all processed transactions

    Raises:
        HTTPException: If validation fails or processing errors occur
            - 400: Invalid input (no files, invalid file type, file too large)
            - 500: Processing errors
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    # Validate file types and size
    max_file_size = 10 * 1024 * 1024  # 10MB per file
    for file in files:
        if not file.filename:
            raise HTTPException(status_code=400, detail="File must have a filename")
        if not file.filename.lower().endswith(".pdf"):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid file type: {file.filename}. "
                f"Only PDF files are allowed.",
            )

    dataset: dict[str, list[list[str]]] = {}

    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            # Process each PDF file
            for file in files:
                if not file.filename:
                    raise HTTPException(
                        status_code=400, detail="File must have a filename"
                    )

                # Save uploaded file to temporary location
                pdf_path = os.path.join(temp_dir, file.filename)

                with open(pdf_path, "wb") as f:
                    content = await file.read()
                    # Validate file size
                    if len(content) > max_file_size:
                        raise HTTPException(
                            status_code=400,
                            detail=f"File {file.filename} exceeds maximum "
                            f"size of {max_file_size / 1024 / 1024}MB",
                        )
                    f.write(content)

                # Process the PDF
                try:
                    report_date, transactions = process_single_pdf_to_csv(
                        pdf_path, password
                    )
                    dataset[report_date] = transactions
                except (ValueError, FileNotFoundError, OSError) as e:
                    log.exception(f"Error processing {file.filename}: {e}")
                    raise HTTPException(
                        status_code=500,
                        detail=f"Error processing {file.filename}: {e!s}",
                    ) from e

            log.info(f"Processed {len(files)} PDF files")

            # Process all report data
            processed: list[list[str]] = []
            for report_date, data in dataset.items():
                processed.extend(process_report_data(report_date, data))

            log.info(f"Processed {len(processed)} transactions")

            # Sort by transaction date with error handling
            try:
                processed = sorted(
                    processed,
                    key=lambda x: datetime.strptime(x[1], "%d/%m/%Y"),
                )
            except ValueError as e:
                log.exception(f"Error sorting transactions by date: {e}")
                # Continue without sorting if date parsing fails

            # Add header
            processed.insert(
                0, ["Posting Date", "Transaction Date", "Description", "Amount"]
            )

            # Create CSV in memory
            output = io.StringIO()
            csv_writer = csv.writer(output)
            csv_writer.writerows(processed)

            # Return CSV as streaming response
            output.seek(0)
            return StreamingResponse(
                iter([output.getvalue()]),
                media_type="text/csv",
                headers={
                    "Content-Disposition": "attachment; filename=transactions.csv"
                },
            )

    except HTTPException:
        raise
    except Exception as e:
        log.exception(f"Unexpected error: {e}")
        raise HTTPException(
            status_code=500, detail=f"Internal server error: {e!s}"
        ) from e


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
