"""Tests for utility functions and classes."""

import logging

from maybankforme.common.utils import DockerSafeLogger


def test_docker_safe_logger_initialization() -> None:
    """Test that DockerSafeLogger initializes correctly."""
    logger = DockerSafeLogger()
    assert logger.logger is not None
    assert isinstance(logger.logger, logging.Logger)


def test_docker_safe_logger_has_handlers() -> None:
    """Test that logger has configured handlers."""
    logger = DockerSafeLogger()
    assert len(logger.logger.handlers) > 0


def test_docker_safe_logger_delegation() -> None:
    """Test that logger methods are delegated correctly."""
    logger = DockerSafeLogger()
    # Should be able to call standard logging methods
    assert callable(logger.info)
    assert callable(logger.error)
    assert callable(logger.warning)
    assert callable(logger.debug)


def test_docker_safe_logger_no_propagation() -> None:
    """Test that logger does not propagate to root."""
    logger = DockerSafeLogger()
    assert logger.logger.propagate is False
