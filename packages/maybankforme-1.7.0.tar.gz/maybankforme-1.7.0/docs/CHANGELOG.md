# [1.7.0](https://github.com/zhrif/maybankforme/compare/v1.6.0...v1.7.0) (2025-10-25)


### Features

* add dependabot configuration for automated dependency updates ([df154be](https://github.com/zhrif/maybankforme/commit/df154beb105d1dd81f82c687c4846f64fe7a872f))

# [1.6.0](https://github.com/zhrif/maybankforme/compare/v1.5.1...v1.6.0) (2025-10-25)


### Features

* align codebase with AGENTS.md code standards ([#9](https://github.com/zhrif/maybankforme/issues/9)) ([6864f98](https://github.com/zhrif/maybankforme/commit/6864f982b6a6d18a4ac21abd9f8375135d03c65b))

## [1.5.1](https://github.com/zhrif/maybankforme/compare/v1.5.0...v1.5.1) (2025-01-26)


### Bug Fixes

* correct year handling for posting and transaction dates in report data processing ([65d997a](https://github.com/zhrif/maybankforme/commit/65d997a5a53ed33bef16d6e4685e289f8527fb6c))

# [1.5.0](https://github.com/zhrif/maybankforme/compare/v1.4.0...v1.5.0) (2025-01-26)


### Features

* Update Dockerfile to use Python 3.12-alpine and restructure application files ([38c594f](https://github.com/zhrif/maybankforme/commit/38c594f0cebd2f8a919e39811d346dc1257fc54f))

# [1.4.0](https://github.com/zhrif/maybankforme/compare/v1.3.0...v1.4.0) (2025-01-26)


### Features

* Refactor project structure and update to work with py cli tool ([65808ef](https://github.com/zhrif/maybankforme/commit/65808ef96dd6b9c4eaa0e4cbfaac7c9496b8f24f))
* Update Dockerfile for improved build process and modify author email in pyproject.toml ([59f1f12](https://github.com/zhrif/maybankforme/commit/59f1f1208deb127d3e0d1984fc2d69feb8ef9cb3))
* Update Dockerfile to use ENTRYPOINT and enhance README with usage instructions ([678549f](https://github.com/zhrif/maybankforme/commit/678549fac177ee31078284a8bdb6f5a6aa806abd))

# [1.3.0](https://github.com/zhrif/maybankforme/compare/v1.2.0...v1.3.0) (2025-01-26)


### Features

* Add logging for processed transactions and output file saving ([15aed46](https://github.com/zhrif/maybankforme/commit/15aed4657eccaad88bff2863a85cb82620b199e2))
* Add metadata labels to Dockerfile for improved documentation ([d2d14cb](https://github.com/zhrif/maybankforme/commit/d2d14cb644f9cdbce3ded3cbf76e1886572bc53f))
* Add module docstrings for PDF and text to CSV conversion scripts ([21092f4](https://github.com/zhrif/maybankforme/commit/21092f4f3d426938098d1e9fe0316df503636c3b))
* Enhance transaction processing by adding report data modification and improved logging ([6d0640e](https://github.com/zhrif/maybankforme/commit/6d0640e91d630692d351635fe31b56b1a55899ab))
* Refactor PDF and CSV conversion processes to improve modularity and logging ([2eccd67](https://github.com/zhrif/maybankforme/commit/2eccd67c67d1717f9490f77123d4b7bfe8297a2f))

# [1.2.0](https://github.com/zhrif/maybankforme/compare/v1.1.0...v1.2.0) (2025-01-26)


### Features

* Remove unused json import from main.py ([d7b3f9e](https://github.com/zhrif/maybankforme/commit/d7b3f9e53b55ce3e2d7ff86fc92a015b12f7d0b0))

# [1.1.0](https://github.com/zhrif/maybankforme/compare/v1.0.0...v1.1.0) (2025-01-26)


### Features

* Enhance transaction processing by adding dataset folder support and improving CSV output formatting ([0f644a4](https://github.com/zhrif/maybankforme/commit/0f644a482022638c10dd42e85de2e341ee143734))
* Implement DockerSafeLogger for improved logging in PDF and CSV conversion processes ([939967d](https://github.com/zhrif/maybankforme/commit/939967d9cf38316a806d6f59425c805de90e4118))
