# KEV

idk why the fuck i made this, but yeah 
just fucking use it if you want 


##  Install this shit
```bash
pip install KEV

# and use like this

PARI 69.69.69.69
PARI          