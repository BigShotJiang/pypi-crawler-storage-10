import sys
import json
import argparse
import requests

__version__ = "0.1.0"

def query_ip(ip_or_empty: str):
    base_url = "https://ipinfo.io"
    url = f"{base_url}/{ip_or_empty}/json" if ip_or_empty else f"{base_url}/json"
    resp = requests.get(url, timeout=8)
    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text}")
    return resp.json()

def pretty_print(data):
    print(json.dumps(data, indent=2, ensure_ascii=False))

def cli(argv=None):
    parser = argparse.ArgumentParser(prog="PARI", description="Query ipinfo.io for IP info")
    parser.add_argument("ip", nargs="?", default="", help="IP address to lookup (optional).")
    parser.add_argument("--raw", action="store_true", help="Print raw JSON output.")
    parser.add_argument("--version", action="store_true", help="Show version and exit.")
    args = parser.parse_args(argv)

    if args.version:
        print(f"KEV {__version__}")
        return 0

    try:
        data = query_ip(args.ip)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2

    if args.raw:
        print(json.dumps(data, ensure_ascii=False))
    else:
        pretty_print(data)

    return 0

if __name__ == "__main__":
    raise SystemExit(cli())