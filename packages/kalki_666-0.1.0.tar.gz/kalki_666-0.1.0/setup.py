from setuptools import setup, find_packages

setup(
    name="KALKI-666",
    version="0.1.0",
    author="KEVIN",
    author_email="psychgamer940@gmail.com",
    description="(PARI)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["requests>=2.28.0"],
    entry_points={"console_scripts": ["PARI=kev.main:cli"]},
    python_requires=">=3.8",
    license="MIT"
)