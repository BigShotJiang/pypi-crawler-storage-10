from bluer_academy.academy.classes.topic import Topic

topic = Topic(
    "linux",
    [
        "[setting up Linux on your machine](https://github.com/kamangir/bluer-ai)",
    ],
    duration=3,
    cost="a working mac, ubuntu (preferred) or windows machine",
    requires="math",
)
