from bluer_academy.academy.classes.topic import Topic

topic = Topic(
    "python",
    [
        "setting up python",
        "cli's and imports",
        "jupyter notebooks",
        "numpy",
        "pandas",
        "matplotlib",
    ],
    duration=12,
    requires="linux,github",
)
