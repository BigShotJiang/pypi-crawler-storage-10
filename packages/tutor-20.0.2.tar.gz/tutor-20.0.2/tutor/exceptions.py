class TutorError(Exception):
    pass
