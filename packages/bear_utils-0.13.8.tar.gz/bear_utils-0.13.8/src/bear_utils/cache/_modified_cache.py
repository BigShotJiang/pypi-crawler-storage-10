"""Modified Cache Module."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from diskcache import Cache

DEFAULT_SET = set()


class ModifiedCache(Cache):
    """A modified cache class with additional functionality."""

    def __init__(self, *args, **kwargs) -> None:
        """Initialize the cache with custom parameters."""
        self.expiry: int | None = kwargs.pop("expiry", None)
        super().__init__(*args, **kwargs)

    def find(self, query: Any) -> list[Any]:
        """Find cache entries matching the query.

        Args:
            query: The query string to match against cache keys.

        Returns:
            A list of matching cache keys.
        """
        return [key for key in self if isinstance(key, tuple | list) and str(query) in str(key)]

    def find_and_delete(self, query: Any) -> bool:
        """Find and delete cache entries matching the query.

        Args:
            query: The query string to match against cache keys.
        """
        find: list[Any] = self.find(query)
        if find:
            return all(self.delete(key) for key in find)
        return False

    def memoize(
        self,
        name: str | None = None,
        typed: bool = False,
        expire: float | None = None,
        tag: str | None = None,
        ignore: set = DEFAULT_SET,
    ) -> Callable:
        return super().memoize(name=name, typed=typed, expire=self.expiry or expire, tag=tag, ignore=ignore)
