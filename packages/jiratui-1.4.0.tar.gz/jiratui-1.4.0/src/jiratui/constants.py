ISSUE_SEARCH_DEFAULT_MAX_RESULTS = 50
ISSUE_SEARCH_DEFAULT_DAYS_INTERVAL = 15
"""The number of days to search for work items when the "created date" limit is not specified."""
ATTACHMENT_MAXIMUM_FILE_SIZE_IN_BYTES = 10485760  # 10MB
"""The maximum size of files that can be attached to work items. This is a restriction imposed by this tool and not by
Jira."""
LOGGER_NAME = 'jiratui'
LOG_FILE_FILE_NAME = 'jiratui.log'
DEFAULT_JIRA_API_VERSION = 3
FULL_TEXT_SEARCH_DEFAULT_MINIMUM_TERM_LENGTH = 3
