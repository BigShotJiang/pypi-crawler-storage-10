from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
import hashlib
import json
from typing import Any, Literal, Sequence

import pybotters
import rnet

from .models.coinup import CoinUpDataStore

logger = logging.getLogger(__name__)

_DEFAULT_SECURITY_INFO = (
    '{"log_BSDeviceFingerprint":"0","log_original":"0","log_CHFIT_DEVICEID":"0"}'
)
_SECRET_PREFIX = "HJ@%*AZ_J"
_DEFAULT_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/141.0.0.0 Safari/537.36"
)


class Coinup:
    """CoinUp 永续合约客户端（REST via rnet + WebSocket depth）。

    与 CoinW 客户端结构保持一致，差异点：

    - REST 请求使用 :mod:`rnet`，以规避指纹检测。
    - 仅订单簿 ``book`` 频道依赖 WebSocket，其他数据通过 REST 刷新。
    """

    def __init__(
        self,
        client: pybotters.Client,
        *,
        rest_client: rnet.Client | None = None,
        rest_api_common: str | None = None,
        rest_api_futures: str | None = None,
        ws_url: str | None = None,
        security_info: str | None = None,
        exchange_token: str | None = None,
        emulation: rnet.Emulation | rnet.EmulationOption | None = None,
        rest_headers_common: dict[str, str] | None = None,
        rest_headers_futures: dict[str, str] | None = None,
    ) -> None:
        self.client = client
        self.store = CoinUpDataStore()

        self.rest_api_common = rest_api_common or "https://www.coinup.io/fe-co-api"
        self.rest_api_futures = rest_api_futures or "https://futures.coinup.io/fe-co-api"
        self.ws_url = ws_url or "wss://futuresws.marketketac.com/kline-api/ws"

        self.security_info = security_info or _DEFAULT_SECURITY_INFO
        self._emulation = emulation or rnet.Emulation.Safari26

        self._rest_client = rest_client or rnet.Client(
            emulation=self._emulation,
            headers={"User-Agent": _DEFAULT_UA},
            allow_redirects=False,
            history=False,
        )
        self._owns_rest_client = rest_client is None

        common_headers = {
            "Content-Type": "application/json",
            "Origin": "https://www.coinup.io",
            "Referer": "https://www.coinup.io/",
            "User-Agent": _DEFAULT_UA,
        }
        futures_headers = {
            "Content-Type": "application/json",
            "Origin": "https://futures.coinup.io",
            "Referer": "https://futures.coinup.io/zh_CN/trade",
            "User-Agent": _DEFAULT_UA,
            "exchange-client": "pc",
            "exchange-language": "zh_CN",
        }
        if rest_headers_common:
            common_headers.update(rest_headers_common)
        if rest_headers_futures:
            futures_headers.update(rest_headers_futures)

        self._exchange_token = exchange_token or self._extract_exchange_token()
        if self._exchange_token:
            futures_headers["exchange-token"] = self._exchange_token

        self._headers_common = common_headers
        self._headers_futures = futures_headers

    async def __aenter__(self) -> "Coinup":
        await self.update("detail")
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:  # pragma: no cover - symmetry
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying rnet client if we created it."""

        if self._owns_rest_client and hasattr(self._rest_client, "close"):
            await self._rest_client.close()
    
    def get_contract_id(self, symbol: str) -> str | None:
        """根据交易对获取合约 ID。"""

        detail = self.store.detail.get({"symbol": symbol})
        if detail is None:
            return None
        contract_id = detail.get("id")
        if contract_id is None:
            return None
        return str(contract_id)

    async def update(
        self,
        update_type: Literal[
            "detail",
            "position",
            "balance",
            "orders",
            "history_order",
            "history_orders",
            "all",
        ] = "all",
        *,
        detail_payload: dict[str, Any] | None = None,
        assets_payload: dict[str, Any] | None = None,
        assets_endpoint: Literal["get_assets_list", "wallet_and_unrealized"] = "get_assets_list",
        orders_payload: dict[str, Any] | None = None,
        history_orders_payload: dict[str, Any] | None = None,
    ) -> None:
        """刷新本地缓存，所有 REST 请求通过 rnet 发送。

        - detail: ``POST /common/public_info`` （公共接口）
        - position/balance: ``POST /position/get_assets_list`` （返回仓位 & 余额）
          - 备选 ``/position/wallet_and_unrealized`` 可通过 ``assets_endpoint`` 指定
        - orders: ``POST /order/current_order_list`` （私有）
        - history_order: ``POST /order/history_order_list`` （私有）
        """

        include_detail = update_type in {"detail", "all"}
        include_position = update_type in {"position", "all"}
        include_balance = update_type in {"balance", "all"}
        include_orders = update_type in {"orders", "all"}
        include_history_orders = update_type in {
            "history_order",
            "history_orders",
            "all",
        }

        include_assets = include_position or include_balance

        if not (include_detail or include_assets or include_orders or include_history_orders):
            raise ValueError(f"Unsupported update_type: {update_type}")

        tasks: dict[str, asyncio.Task[Any]] = {}

        if include_detail:
            tasks["detail"] = asyncio.create_task(
                self._fetch_detail(detail_payload)
            )

        if include_assets:
            tasks["assets"] = asyncio.create_task(
                self._fetch_assets(assets_payload, endpoint=assets_endpoint)
            )

        if include_orders:
            tasks["orders"] = asyncio.create_task(self._fetch_orders(orders_payload))

        if include_history_orders:
            tasks["history_orders"] = asyncio.create_task(
                self._fetch_history_orders(history_orders_payload)
            )

        results: dict[str, Any] = {}
        try:
            for key, task in tasks.items():
                results[key] = await task
        except Exception:
            for task in tasks.values():
                task.cancel()
            raise

        if include_detail and "detail" in results:
            self.store.detail._onresponse(results["detail"])

        assets_data = results.get("assets")
        if assets_data is not None:
            if include_position:
                self.store.position._onresponse(assets_data)
            if include_balance:
                self.store.balance._onresponse(assets_data)

        if include_orders:
            orders_data = results.get("orders")
            if orders_data is not None:
                self.store.orders._onresponse(orders_data)

        if include_history_orders:
            history_data = results.get("history_orders")
            if history_data is not None:
                self.store.history_orders._onresponse(history_data)

    async def sub_orderbook(
        self,
        channels: Sequence[str] | str,
        *,
        depth_step: str = "step0",
        depth_limit: int | None = None,
    ) -> pybotters.ws.WebSocketApp:
        """订阅订单簿深度频道。

        参数 ``channels`` 支持 ``subSymbol`` 或完整频道名称：

        - ``"e_wlfiusdt"`` -> 发送 ``market_e_wlfiusdt_depth_step0``
        - ``"market_e_wlfiusdt_depth_step0"`` -> 原样发送
        """

        if isinstance(channels, str):
            channels = [channels]

        payloads = []
        for channel in channels:
            ch = channel.lower()
            if not ch.startswith("market_"):
                ch = f"market_{ch}_depth_{depth_step}"
            payloads.append(
                {
                    "event": "sub",
                    "params": {
                        "channel": ch,
                        "cb_id": ch.split("_depth_", 1)[0].replace("market_", ""),
                    },
                }
            )

        if not payloads:
            raise ValueError("channels must not be empty")

        self.store.book.limit = depth_limit

        ws_headers = {
            "Origin": "https://futures.coinup.io",
            "Referer": "https://futures.coinup.io/zh_CN/trade",
            "User-Agent": _DEFAULT_UA,
        }

        ws_app = self.client.ws_connect(
            self.ws_url,
            hdlr_bytes=self.store.onmessage,
            headers=ws_headers,
            autoping=False,
        )
        await ws_app._event.wait()

        for payload in payloads:
            await ws_app.current_ws.send_json(payload)
            await asyncio.sleep(0.05)

        return ws_app

    async def place_order(
        self,
        symbol: str,
        *,
        side: Literal["buy", "sell", "BUY", "SELL"],
        volume: float | int | str,
        order_type: Literal["limit", "market", 1, 2] = "limit",
        price: float | int | str | None = None,
        position_type: int | str = 1,
        leverage_level: int | str = 1,
        offset: Literal["open", "close", "OPEN", "CLOSE"] = "open",
        order_unit: int | str = 2,
        trigger_price: float | int | str | None = None,
        is_condition_order: bool = False,
        is_oto: bool = False,
        is_check_liq: int | bool = 1,
        secret: str | None = None,
        take_profit_trigger: float | int | str | None = None,
        take_profit_price: float | int | str | None = 0,
        take_profit_type: int | None = 2,
        stop_loss_trigger: float | int | str | None = None,
        stop_loss_price: float | int | str | None = 0,
        stop_loss_type: int | None = 2,
        extra_params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        ``POST /order/order_create`` 下单（默认支持限价/市价）。
        当 close 时, volume为张数

        Args:
            symbol: 交易对符号（如 "BTC_USDT"），将自动解析为 contract_id。
        """
        contract_id = self.get_contract_id(symbol)
        if contract_id is None:
            raise ValueError(f"Invalid symbol: {symbol}")

        normalized_side = self._normalize_side(side)
        normalized_offset = self._normalize_offset(offset)
        order_type_code = self._normalize_order_type(order_type)

        if order_type_code == 1 and price is None:
            raise ValueError("price is required for CoinUp limit orders")
        price_value = self._format_price(price)
        if order_type_code == 1 and price_value is None:
            raise ValueError("price is required for CoinUp limit orders")
        if price_value is None:
            price_value = 0

        volume_str = self._format_volume(volume)
        trigger_price_value = self._format_price(trigger_price)
        take_profit_trigger_value = self._format_price(take_profit_trigger)
        take_profit_price_value = self._format_price(take_profit_price)
        stop_loss_trigger_value = self._format_price(stop_loss_trigger)
        stop_loss_price_value = self._format_price(stop_loss_price)

        payload: dict[str, Any] = {
            "contractId": contract_id,
            "positionType": int(position_type),
            "side": normalized_side,
            "leverageLevel": int(leverage_level),
            "price": price_value,
            "volume": volume_str,
            "triggerPrice": trigger_price_value,
            "open": normalized_offset,
            "type": order_type_code,
            "isConditionOrder": bool(is_condition_order),
            "isOto": bool(is_oto),
            "orderUnit": int(order_unit),
            "isCheckLiq": int(is_check_liq),
            "takerProfitTrigger": take_profit_trigger_value,
            "takerProfitPrice": take_profit_price_value,
            "takerProfitType": take_profit_type,
            "stopLossTrigger": stop_loss_trigger_value,
            "stopLossPrice": stop_loss_price_value,
            "stopLossType": stop_loss_type,
        }
        if extra_params:
            payload.update(extra_params)

        if secret is None:
            payload["secret"] = self._generate_secret(
                contract_id=str(contract_id),
                leverage_level=str(leverage_level),
                position_type=str(position_type),
                price=price_value,
                side=normalized_side,
                order_type=str(order_type_code),
                volume=volume_str,
            )
        else:
            payload["secret"] = secret

        body = self._build_payload(payload)
        data = await self._rest_post(
            f"{self.rest_api_futures}/order/order_create",
            body,
            self._headers_futures,
        )
        result = self._ensure_success("place_order", data)
        return result.get("data") or {}

    async def cancel_order(
        self,
        symbol: str,
        order_id: str | int,
        *,
        is_condition_order: bool = False,
        extra_params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """
        ``POST /order/order_cancel`` 取消指定订单。

        Args:
            symbol: 交易对符号（如 "BTC_USDT"），将自动解析为 contract_id。
        """
        contract_id = self.get_contract_id(symbol)
        if contract_id is None:
            raise ValueError(f"Invalid symbol: {symbol}")

        payload: dict[str, Any] = {
            "contractId": contract_id,
            "orderId": str(order_id),
            "isConditionOrder": bool(is_condition_order),
        }
        if extra_params:
            payload.update(extra_params)

        body = self._build_payload(payload)
        data = await self._rest_post(
            f"{self.rest_api_futures}/order/order_cancel",
            body,
            self._headers_futures,
        )

        result = self._ensure_success("cancel_order", data)
        return result.get("data")

    def set_exchange_token(self, token: str | None) -> None:
        """Update the ``exchange-token`` header used for CoinUp private REST calls."""

        self._exchange_token = token
        if token:
            self._headers_futures["exchange-token"] = token
        else:
            self._headers_futures.pop("exchange-token", None)

    def _build_payload(self, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = {
            "uaTime": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
            "securityInfo": self.security_info,
        }
        if overrides:
            payload.update(overrides)
        return payload

    async def _fetch_detail(self, payload: dict[str, Any] | None) -> Any:
        url = f"{self.rest_api_common}/common/public_info"
        data = await self._rest_post(
            url,
            self._build_payload(payload),
            self._headers_common,
        )
        return data

    async def _fetch_assets(
        self,
        payload: dict[str, Any] | None,
        *,
        endpoint: str,
    ) -> Any:
        url = f"{self.rest_api_futures}/position/{endpoint}"
        data = await self._rest_post(
            url,
            self._build_payload(payload),
            self._headers_futures,
        )
        return data

    async def _rest_post(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
    ) -> Any:
        response = await self._rest_client.post(
            url,
            json=payload,
            headers=headers,
        )
        try:
            status = response.status.as_int()
            if status >= 400:
                text = await response.text()
                raise RuntimeError(
                    f"CoinUp REST request failed ({status}): {text}"
                )
            return await response.json()
        finally:
            await response.close()

    async def _fetch_orders(self, payload: dict[str, Any] | None) -> Any:
        url = f"{self.rest_api_futures}/order/current_order_list"
        data = await self._rest_post(
            url,
            self._build_payload(payload or {"contractId": ""}),
            self._headers_futures,
        )
        return data

    async def _fetch_history_orders(self, payload: dict[str, Any] | None) -> Any:
        url = f"{self.rest_api_futures}/order/history_order_list"
        data = await self._rest_post(
            url,
            self._build_payload(payload or {"contractId": ""}),
            self._headers_futures,
        )
        return data

    def _extract_exchange_token(self) -> str | None:
        """Best-effort fetch of token from pybotters credential store."""

        session = getattr(self.client, "_session", None)
        if not session:
            return None
        apis = getattr(session, "__dict__", {}).get("_apis")
        if not isinstance(apis, dict):
            return None
        creds = apis.get("coinup")
        if not creds:
            return None
        token = creds[0]
        return str(token) if token else None

    @staticmethod
    def _ensure_success(operation: str, payload: Any) -> dict[str, Any]:
        if not isinstance(payload, dict):
            raise RuntimeError(f"{operation} failed: unexpected response {payload}")
        code = payload.get("code")
        succ = payload.get("succ")
        if code is not None and str(code) != "0":
            raise RuntimeError(f"{operation} failed: {payload}")
        if succ is False:
            raise RuntimeError(f"{operation} failed: {payload}")
        return payload

    @staticmethod
    def _normalize_side(side: str) -> str:
        value = str(side).upper()
        if value not in {"BUY", "SELL"}:
            raise ValueError(f"Unsupported side: {side}")
        return value

    @staticmethod
    def _normalize_offset(offset: str) -> str:
        value = str(offset).upper()
        mapping = {"OPEN": "OPEN", "CLOSE": "CLOSE"}
        try:
            return mapping[value]
        except KeyError as exc:
            raise ValueError(f"Unsupported offset: {offset}") from exc

    @staticmethod
    def _normalize_order_type(order_type: Literal["limit", "market", 1, 2]) -> int:
        mapping = {
            "limit": 1,
            "market": 2,
            1: 1,
            2: 2,
        }
        try:
            return mapping[order_type]  # type: ignore[index]
        except KeyError as exc:
            raise ValueError(f"Unsupported order_type: {order_type}") from exc

    @staticmethod
    def _generate_secret(
        contract_id: str,
        leverage_level: str,
        position_type: str,
        price: float | int | str,
        side: str,
        order_type: str,
        volume: str,
    ) -> str:
        data = {
            "contractId": contract_id,
            "leverageLevel": leverage_level,
            "positionType": position_type,
            "price": Coinup._stringify_number(price),
            "side": side,
            "type": order_type,
            "volume": Coinup._stringify_number(volume),
        }
        text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        raw = f"{_SECRET_PREFIX}{text}"
        return hashlib.md5(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _format_price(value: float | int | str | None) -> float | int | str | None:
        if value is None:
            return None
        if isinstance(value, (float, int)):
            return float(value)
        return value

    @staticmethod
    def _format_volume(value: float | int | str) -> str:
        return str(value)

    @staticmethod
    def _stringify_number(value: float | int | str | None) -> str:
        if value is None:
            return "0"
        if isinstance(value, str):
            return value
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if value.is_integer():
                return str(int(value))
            text = format(value, "f").rstrip("0").rstrip(".")
            return text or "0"
        return str(value)
