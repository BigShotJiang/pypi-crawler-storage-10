import pybotters
from hyperquant.broker.coinup import Coinup, CoinUpDataStore

apis = {"coinup": ["948a3841361bd38c30fc37355c3fb01a35135042c1c44698bed6f9cd6262cce0"]}


async def test_update():
    async with pybotters.Client(apis=apis) as client:
        async with Coinup(client=client) as broker:
            # await broker.update("detail")
            # print(broker.store.detail.get({"symbol": "WLFI-USDT"}))
            # await broker.update("position")
            # print(broker.store.position.find())
            await broker.update("history_orders")
            print(broker.store.history_orders.find())

            # await broker.update('orders')
            # print(broker.store.orders.find())

async def test_cancel_order():
    async with pybotters.Client(apis=apis) as client:
        async with Coinup(client=client) as broker:
            await broker.cancel_order('169', '2951914186269633768') 

async def test_place_order():
    async with pybotters.Client(apis=apis) as client:
        async with Coinup(client=client) as broker:
            # 市价单
            order = await broker.place_order(
                'WLFI-USDT',
                side='sell',
                volume='1',
                order_type='market',
                offset='CLOSE',
            )
            print(order)

if __name__ == "__main__":
    import asyncio

    asyncio.run(test_update())
