..
    This file is part of Python Client Library for Metafavela.
    Copyright (C) 2025 INPE.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.


Instalação
==========

Por favor, leia as instruções abaixo para instalar o ``metafavela``.

.. Production Installation
.. ------------------------

.. Install via pypi::

..     pip install metafavela


Instalação de Desenvolvimento
-----------------------------

Clone o Repositório de Software::

    git clone https://github.com/bdc-favelas/metafavela.py.git


Acesse a pasta do código-fonte:::

    cd metafavela.py


Instale em modo de desenvolvimento::

    pip3 install -e .[all]


.. note::

    Se você quiser criar um novo *Ambiente Virtual Python*, siga estas instruções:

    *1.* Crie um novo ambiente virtual vinculado ao Python 3.11::

        python3.11 -m venv venv

    **2.** Ative o novo ambiente::

        source venv/bin/activate

    **3.** Atualize o pip e o setuptools::

        pip3 install --upgrade pip setuptools wheel


Rodando os testes
+++++++++++++++++

Rodando::

    ./run-test.sh


Construa a documentação
+++++++++++++++++++++++

Você pode gerar a documentação baseada no Sphinx com o seguinte comando::

    sphinx-build docs/sphinx docs/sphinx/_build/html


O comando acima gerará a documentação em HTML e a colocará em::

    docs/sphinx/_build/html/


Você pode abrir a documentação acima no seu navegador favorito, como::

    firefox docs/sphinx/_build/html/index.html