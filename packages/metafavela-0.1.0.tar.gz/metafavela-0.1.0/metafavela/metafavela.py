#
# This file is part of Python Client Library for the Metafavela.
# Copyright (C) 2025 INPE.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.
#

"""Python Client Library for the Metafavela."""
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Union

from cachetools import LRUCache, cached
from dotenv import load_dotenv

from .metadata import Metadata
from .utils import Utils

logger = logging.getLogger(__name__)


def _load_env() -> None:
    """Load environment variables from internal and user-provided .env files."""
    package_dir = Path(__file__).resolve().parent
    internal_env_path = package_dir / ".env"
    load_dotenv(dotenv_path=internal_env_path)
    load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)


class Metafavela:
    """
    Class to interact with the Metafavela service.

    Attributes:
        url (str): Base URL of the Metafavela service.
        token (str): Token used for authentication.
    """

    def __init__(self, url: Optional[str] = None, token: Optional[str] = None) -> None:
        """Construct of Metafavela."""
        _load_env()

        self._url = url or os.getenv("METAFAVELA_URL")
        self._token = token or os.getenv("METAFAVELA_TOKEN")
        self._validate_config()

    def _validate_config(self) -> None:
        """
        Validate whether the URL and access token were provided.

        Raises:
            ValueError: If the URL or access token is not provided.
        """
        if not self._url:
            raise ValueError(
                "URL not provided. Set METAFAVELA_URL in .env \
                or pass it as a parameter."
            )
        if not self._token:
            raise ValueError(
                "Access token not provided. Set METAFAVELA_TOKEN in .env \
                or pass it as a parameter."
            )

    @property
    def url(self) -> Optional[str]:
        """Get the service URL."""
        return self._url

    def _list_metafavela(self) -> List[dict]:
        """
        Retrieve the list of metadata.

        Returns:
            List[dict]: List of project metadata.
        """
        return Utils._get(f"{self._url}/metadados/", token=self._token)

    def _get_slug(self, slug_name) -> Dict:
        """
        Retrieve the metadata of slug.

        Returns:
            Dict: the metadata of slug.
        """
        return Utils._get(f"{self._url}/metadados/{slug_name}/", token=self._token)


    @property
    def catalogo(self) -> List[dict]:
        """
        List basic information about available projects.

        Returns:
            List[dict]: Filtered list with selected fields.
        """
        metadata = self._list_metafavela()

        return [
            {
                "titulo": met["titulo"],
                "slug": met["slug"],
                "resumo": met["resumo"],
                "bounding_bbox": met["bounding_box"],
            }
            for met in metadata["data"]
        ]
    

    @cached(cache=LRUCache(maxsize=128))
    def metadata(self, nome: str) -> Union[Metadata,None]:
        """
        Get information about available projects.

        Returns:
            Dict: the metadata of slug.
        """    
        try:
            data = self._get_slug(slug_name=nome)
            return Metadata(data=data)
        except Exception:
            raise KeyError(
                f"Erro ao buscar: {nome}"
            )
        
    def __repr__(self):
        """Return the string representation of a lccs object."""
        text = f'Metafavela ("{self.url}")'
        return text

    def __str__(self):
        """Return the string representation of a lccs object."""
        return f"<Metafavela [{self.url}]>"

    def _repr_html_(self):
        """HTML repr."""
        import time
        unique_id = int(time.time() * 1000) 
        
        return Utils.render_html(
            "metafavela.html",
            metafavela=self.catalogo,
            unique_id=unique_id 
        )

