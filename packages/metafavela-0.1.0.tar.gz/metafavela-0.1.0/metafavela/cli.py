#
# This file is part of Python Client Library for the Metafavela.
# Copyright (C) 2025 INPE.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.
#

"""Command line interface for the WLTS client."""
from time import time

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn, TimeElapsedColumn
from rich.syntax import Syntax
from rich.table import Table
from rich.tree import Tree

from metafavela import Metafavela


class Config:
    """A simple decorator class for command line options."""

    def __init__(self):
        """Initialization of Config decorator."""
        self.url = None
        self.service = None


pass_config = click.make_pass_decorator(Config, ensure=True)

console = Console()


@click.group()
@click.option(
    "--url",
    type=click.STRING,
    default="https://sua.api.personalizada.com",
    help="O endereço do METAFAVELA (URL).",
)
@click.option(
    "--token", default=None, help="Personal Access Token"
)
@click.version_option()
@pass_config
def cli(config, url, token):
    """Metafavela on command line."""
    config.url = url
    config.service = Metafavela(url=url, token=token)

@cli.command()
@click.option("-v", "--verbose", is_flag=True, default=False)
@pass_config
def catalogo(config: Config, verbose):
    """Return the list of available metadata in the service provider."""
    if verbose:
        console.print(f"[bold black]Servidor: [green]{config.url}[/green]", style="bold")
        console.print(
            "[black]\tRecuperando the catalogo...[/black]"
        )

        table = Table(
            title="Metafavela", show_header=True, header_style="bold magenta"
        )
        table.add_column("Titulo", style="green", no_wrap=True)
        table.add_column("Slug", style="green", no_wrap=True)

        for collection in config.service.catalogo:
            table.add_row(collection["titulo"], collection["slug"])

        console.print(table)
        console.print("[black]\tTerminado![/black]")

    else:
        for collection in config.service.catalogo:
            console.print(f"[green]{collection}[/green]", style="bold")