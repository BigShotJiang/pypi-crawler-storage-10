#
# This file is part of Python Client Library for the Metafavela.
# Copyright (C) 2025 INPE.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.
#

"""Python Client Library for the Metafavela."""

from typing import Any, Dict, List, Optional

import geopandas as gpd
from shapely.geometry import shape
from shapely.geometry.base import BaseGeometry

from .utils import Utils


class Metadata(dict):
    """Representação de uma estrutura de Metadados."""

    def __init__(self, data: Dict[str, Any]) -> None:
        """
        Inicializa a estrutura Metadata com metadados.

        :param data: Dicionário contendo os metadados do recurso.
        :param validate: Se deve validar os dados. (Não implementado aqui).
        """
        super().__init__(data or {})

    @property
    def abrangencia_url(self) -> Optional[str]:
        """URL da abrangência geográfica."""
        return self.get('abrangencia_url')

    @property
    def acesso(self) -> Optional[str]:
        """Retorna o tipo de acesso."""
        return self.get('acesso')

    @property
    def alteracoes(self) -> Optional[str]:
        """Histórico ou descrição das alterações."""
        return self.get('alteracoes')

    @property
    def atualizacao(self) -> Optional[str]:
        """Frequência de atualização (mensal, trimestral, etc.)."""
        return self.get('atualizacao')

    @property
    def categoria(self) -> Optional[str]:
        """Categoria do recurso."""
        return self.get('categoria')

    @property
    def codificacao(self) -> Optional[str]:
        """Esquema de codificação de caracteres."""
        return self.get('codificacao')

    @property
    def coleta(self) -> Optional[str]:
        """Método de coleta dos dados."""
        return self.get('coleta')

    @property
    def contato(self) -> Optional[str]:
        """Informações de contato para dúvidas."""
        return self.get('contato')

    @property
    def data_criacao(self) -> Optional[str]:
        """Data de criação do recurso."""
        return self.get('data_criacao')

    @property
    def data_publicacao(self) -> Optional[str]:
        """Data da primeira publicação do recurso."""
        return self.get('data_publicacao')

    @property
    def delimitacao(self) -> Optional[str]:
        """Detalhes sobre a delimitação geográfica."""
        return self.get('delimitacao')

    @property
    def distribuidor(self) -> Optional[str]:
        """Entidade responsável pela distribuição."""
        return self.get('distribuidor')

    @property
    def escala(self) -> Optional[str]:
        """Escala nominal do recurso (ex: 1:250.000)."""
        return self.get('escala')

    @property
    def fonte(self) -> Optional[str]:
        """Fonte de dados original."""
        return self.get('fonte')

    @property
    def formato(self) -> Optional[str]:
        """Formato de arquivo (ex: GeoJSON, Shapefile)."""
        return self.get('formato')

    @property
    def bounding_box(self) -> Optional[BaseGeometry]: # Usando BaseGeometry
        """Retorna a geometria da caixa delimitadora como um objeto Shapely."""
        geojson_data = self.get('bounding_box')
        if geojson_data:
            return shape(geojson_data) 
        return None


    @property
    def geometria_oficial(self) -> Optional[gpd.GeoSeries]: # AQUI: Altere o retorno esperado
        """Retorna a geometria principal como um objeto GeoSeries."""
        geojson_data = self.get('geometria_oficial')
        if geojson_data:
            # 1. Converte o dicionário GeoJSON para um objeto Shapely
            shapely_geom = shape(geojson_data)
            # 2. Retorna a geometria embalada em um GeoSeries
            return gpd.GeoSeries([shapely_geom]) # <-- A principal mudança é aqui
        return None

    @property
    def geometrias_nao_oficiais(self) -> Optional[gpd.GeoSeries]:
        """Retorna as geometrias não oficiais como um GeoSeries do GeoPandas."""
        geojson_list = self.get('geometrias_nao_oficiais')
        
        if geojson_list and isinstance(geojson_list, list) and len(geojson_list) > 0:
            geometries = [shape(g) for g in geojson_list]
            
            return gpd.GeoSeries(geometries)
        
        return None

    @property
    def idioma(self) -> Optional[str]:
        """Idioma dos metadados."""
        return self.get('idioma')

    @property
    def info_complementar(self) -> Optional[str]:
        """Informações adicionais ou notas."""
        return self.get('info_complementar')

    @property
    def layer(self) -> Optional[str]:
        """Nome da camada ou 'layer'."""
        return self.get('layer')

    @property
    def licenca(self) -> Optional[str]:
        """Termos da licença de uso."""
        return self.get('licenca')

    @property
    def link(self) -> Optional[str]:
        """Link principal para download ou acesso."""
        return self.get('link')

    @property
    def localizacao(self) -> Optional[str]:
        """Localização (ex: URL ou diretório) do recurso."""
        return self.get('localizacao')

    @property
    def logo_produtor_url(self) -> Optional[str]:
        """URL do logo do produtor."""
        return self.get('logo_produtor_url')

    @property
    def mantenedor(self) -> Optional[str]:
        """Entidade responsável pela manutenção."""
        return self.get('mantenedor')

    @property
    def palavras_chave(self) -> Optional[List[str]]:
        """Lista de palavras-chave para busca."""
        return self.get('palavras_chave')

    @property
    def periodo(self) -> Optional[str]:
        """Período de tempo que os dados cobrem."""
        return self.get('periodo')

    @property
    def precisao_espacial(self) -> Optional[str]:
        """Nível de precisão espacial."""
        return self.get('precisao_espacial')

    @property
    def produtor(self) -> Optional[str]:
        """Entidade responsável pela produção dos dados."""
        return self.get('produtor')

    @property
    def projecao(self) -> Optional[str]:
        """Sistema de projeção ou coordenadas."""
        return self.get('projecao')

    @property
    def referencia(self) -> Optional[str]:
        """Referência bibliográfica ou técnica."""
        return self.get('referencia')

    @property
    def resolucao(self) -> Optional[str]:
        """Resolução espacial ou temporal."""
        return self.get('resolucao')

    @property
    def responsavel(self) -> Optional[str]:
        """Nome do indivíduo responsável."""
        return self.get('responsavel')

    @property
    def restricoes(self) -> Optional[str]:
        """Restrições de acesso ou uso."""
        return self.get('restricoes')

    @property
    def resumo(self) -> Optional[str]:
        """Resumo ou descrição concisa do recurso."""
        return self.get('resumo')

    @property
    def sensibilidade(self) -> Optional[str]:
        """Nível de sensibilidade dos dados."""
        return self.get('sensibilidade')

    @property
    def slug(self) -> Optional[str]:
        """Identificador único e amigável (o próprio slug)."""
        return self.get('slug')

    @property
    def status(self) -> Optional[str]:
        """Status do recurso (ativo, descontinuado, etc.)."""
        return self.get('status')

    @property
    def tags(self) -> Optional[List[str]]:
        """Sinônimo de palavras_chave (ou tags de categorização)."""
        return self.get('tags')

    @property
    def tipo_espacial(self) -> Optional[str]:
        """Tipo de dado espacial (vetorial, raster, etc.)."""
        return self.get('tipo_espacial')

    @property
    def titulo(self) -> Optional[str]:
        """Título completo do recurso."""
        return self.get('titulo')

    @property
    def validacao(self) -> Optional[str]:
        """Detalhes do processo de validação."""
        return self.get('validacao')

    def _repr_html_(self) -> str:
        """Renderiza uma representação HTML (útil para notebooks)."""
        import time
        unique_id = int(time.time() * 100000) 
        return Utils.render_html('metadata.html', metadata=self, unique_id=unique_id)

    def __repr__(self) -> str:
        """Retorna a representação oficial da string."""
        return f'<SLUG: "{self.slug}" - Título: "{self.titulo}">'

    def __str__(self) -> str:
        """Retorna a representação amigável da string."""
        return f'{self.titulo} ({self.slug}) - Status: {self.status}'