..
    This file is part of Python Client Library for Metafavela.
    Copyright (C) 2023 INPE.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.


Executando o cliente Metafavela na linha de comando
===================================================

O cliente ``Metafavela`` instala um utilitário para linha de comando chamado ``metafavela-cli`` que permite recuperar os metadados.


If you want to know the Metafavela version, use the option ``--version`` as in::

    metafavela-cli --version

Saida::

    metafavela, version 0.1.0

Para listar o catalogo do serviço, use o comando ``catalogo`` e passe as opçoes URL ``--url`` e ``--token``::

    metafavela --url 'https://sua-url-aqui' --token 'me-mude' catalogo