..
    This file is part of Python Client Library for Metafavela.
    Copyright (C) 2025 INPE.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.


========
Mudanças
========

Versão 0.1.0 (2025-10-24)
--------------------------

- Modelos Jinja para integração com o Jupyter. (#8)
- Adicionado um teste mínimo (#7)
- Preparar pacote para adicionar no pypi. (#6)
- Adicionada LICENÇA (#5)
- Adicionada interface de linha de comando (#4)
- Adicionado changes.rst (#3)
- Adicionados exemplos de script (#2)
- Adicionado README (#1)