#
# This file is part of Python Client Library for Metafavela.
# Copyright (C) 2023 INPE.
#
# Python Client Library for Metafavela is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.
#
"""Metafavela Python Client Examples."""

from metafavela import Metafavela

service = Metafavela(url='METAFAVELA_URL', token='METAFAVELA_TOKEN')

print(service.catalogo)

fav = service.metadata('favelas-e-comunidades-urbanas-2022')

print(fav.titulo)
print(fav.bounding_box)
