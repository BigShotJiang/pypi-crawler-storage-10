..
    This file is part of Python Client Library for Metafavela.
    Copyright (C) 2025 INPE.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/gpl-3.0.html>.


====================================
Cliente em Python para o Metafavelas
====================================

.. image:: https://img.shields.io/badge/License-GPLv3-blue.svg
        :target: https://github.com/bdc-favelas/metafavela.py/blob/master/LICENSE
        :alt: Software License

.. image:: https://img.shields.io/badge/lifecycle-maturing-blue.svg
        :target: https://www.tidyverse.org/lifecycle/#maturing
        :alt: Software Life Cycle

.. image:: https://img.shields.io/github/tag/bdc-favelas/metafavela.py.svg
        :target: https://github.com/bdc-favelas/metafavela.py/releases
        :alt: Release

Sobre
=====

O MetaFavela é um projeto dedicado ao desenvolvimento de uma plataforma para a organização, sistematização e disponibilização de metadados de dados geoespaciais sobre favelas brasileiras.

A iniciativa visa criar um ponto de referência para reunir e facilitar o acesso a informações que, muitas vezes, encontram-se dispersas e de difícil obtenção.

Busca-se, assim, ampliar a transparência, visibilidade e o uso desses dados, promovendo sua aplicação em pesquisas, políticas públicas e ações comunitárias.

Instalação
============

Veja `INSTALL.rst <./INSTALL.rst>`_.


Usando Metafavela Linha de Comando
==================================

Veja `CLI.rst <./CLI.rst>`_.


License
=======

.. admonition::
    Copyright (C) 2025 INPE.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.