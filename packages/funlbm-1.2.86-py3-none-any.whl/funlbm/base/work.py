import h5py
import torch

from funlbm.util import logger, get_available_device


class Worker:
    """基础工作类

    提供设备检测和管理功能

    Args:
        device: 计算设备名称,默认为"cpu"
    """

    def __init__(self, device="cpu", *args, **kwargs):
        self.device = get_available_device(device)
        logger.info(f"init {type(self).__name__} with device={self.device}")

    def dump_file(self, group: h5py.Group = None, vals=None, *args, **kwargs):
        pass

    def load_file(self, group: h5py.Group = None, vals=None, *args, **kwargs):
        pass

    def dump_dataset(self, group: h5py.Group, name: str, data, *args, **kwargs):
        group.create_dataset(
            name, data=data.cpu().numpy(), compression="gzip", compression_opts=9
        )
        logger.debug(f"dump {name} success.")
        # logger.success(f"dump {name} success.")

    def load_dataset(self, group: h5py.Group, name, *args, **kwargs):
        data = torch.tensor(group.get(name)[:], device=self.device, dtype=torch.float32)
        logger.success(f"load {name} success.")
        return data
