from funlbm.flow.base.core import FlowBase, FlowConfig
from .d3 import FlowD3, FlowD3Q13, FlowD3Q15, FlowD3Q19, FlowD3Q27, create_flow3d

__all__ = [
    "create_flow",
    "create_flow3d",
    "FlowBase",
    "FlowD3",
    "FlowD3Q19",
    "FlowD3Q13",
    "FlowConfig",
    "FlowD3Q15",
    "FlowD3Q27",
]


def create_flow(flow_config: FlowConfig, *args, **kwargs) -> FlowBase:
    """解析3D模型参数

    根据参数类型创建对应的参数对象

    Args:
        flow_config: 参数类型,支持"D3Q27"/"D3Q19"/"D3Q15"/"D3Q13"

    Returns:
        Param: 参数对象

    Raises:
        ValueError: 当参数类型不支持时
    """
    if flow_config.param_type.startswith("D3"):
        return create_flow3d(flow_config, *args, **kwargs)
    else:
        raise ValueError("Unknown parameter type: {}".format(flow_config.param_type))
