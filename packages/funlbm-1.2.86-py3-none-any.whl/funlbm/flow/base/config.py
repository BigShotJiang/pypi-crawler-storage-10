import numpy as np

from funlbm.config.base import BaseConfig, BoundaryConfig


class FlowConfig(BaseConfig):
    """流体配置类

    Attributes:
        size: 计算域大小,形状为(3,)的数组
        param: 参数字典
        param_type: 参数类型,默认为"D3Q19"
        boundary: 边界配置
        gl: 重力加速度
        Re: 雷诺数
        mu: 动力粘度
    """

    def __init__(
        self,
        size=None,
        boundary=None,
        param_type: str = "D3Q19",
        gl: float = 0.0,
        Re: float = 10,
        mu: float = 10,
        rho: float = 1.0,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.size: np.ndarray = np.array(size or [100, 100, 100], dtype=int)
        self.param_type: str = param_type
        self.boundary: BoundaryConfig = BoundaryConfig(**boundary or {})

        self.gl: float = gl  # 重力加速度
        self.Re: float = Re  # 雷诺数
        self.mu: float = mu  # 动力粘度
        self.rho = rho

    @property
    def nu(self):
        """
        运动粘度
        Returns:
        """
        return self.mu / self.rho

    @property
    def tau(self):
        return 3 * self.nu + 0.5
