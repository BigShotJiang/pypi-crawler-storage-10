from typing import Union

import numpy as np
import torch


def get_available_device(device=None) -> torch.device:
    if device is not None and device != "auto":
        if isinstance(device, str):
            return torch.device(device)
        elif isinstance(device, torch.device):
            return device
        else:
            raise TypeError(f"device type error: {type(device)}")

    if torch.cuda.is_available():
        return torch.device("cuda")
    elif torch.backends.mps.is_available():
        return torch.device("mps")
    else:
        return torch.device("cpu")


def to_tensor(
    data: Union[np.ndarray, float], device: torch.device = torch.device("cpu")
) -> torch.Tensor:
    if device.type == "cuda":
        return torch.tensor(data, device=device, dtype=torch.float32)
    elif device.type == "mps":
        return torch.tensor(data, device=device, dtype=torch.float32)
    elif device.type == "cpu":
        return torch.tensor(data, device=device, dtype=torch.float32)
    else:
        raise RuntimeError(f"Unsupported device: {device.type}")


def to_device(
    data: torch.Tensor, device: torch.device = torch.device("cpu")
) -> torch.Tensor:
    if device.type == "cuda":
        return data.to(device, non_blocking=False, dtype=torch.float32)
    elif device.type == "mps":
        return data.to(device, non_blocking=False, dtype=torch.float32)
    elif device.type == "cpu":
        return data.to(device, non_blocking=False, dtype=torch.float32)
    else:
        raise RuntimeError(f"Unsupported device: {device.type}")


def download_to_device(data: torch.Tensor, device: torch.device) -> torch.Tensor:
    if device.type == "cuda":
        return data.to(device, non_blocking=True, dtype=torch.float32)
    elif device.type == "mps":
        return data.to(device, non_blocking=True, dtype=torch.float32)
    else:
        return data
