import numpy as np
import pandas as pd
from funtable.kv import SQLiteKKVTable
from typing import Union


def parse_track(
    track: SQLiteKKVTable = None,
    track_path: str = None,
    job_id: Union[str, int] = None,
    home="/Users/bingtao/data/scnet",
    *args,
    **kwargs,
):
    if job_id is not None:
        track_path = f"{home}/{job_id}/data/track.db"

    if track_path is not None:
        return SQLiteKKVTable(db_path=track_path, table_name="particle")

    if track is not None:
        return track
    raise TypeError("track must be str or SQLiteKKVTable")


def load_particle_track(job_id=None, particle_id="1", *args, **kwargs):
    track = parse_track(job_id=job_id, *args, **kwargs).list_all()

    res = [
        {
            "step": step,
            "m": track[step][particle_id]["m"],
            "ux": track[step][particle_id]["cu"][0],
            "uy": track[step][particle_id]["cu"][1],
            "uz": track[step][particle_id]["cu"][2],
            "cx": track[step][particle_id]["cx"][0],
            "cy": track[step][particle_id]["cx"][1],
            "cz": track[step][particle_id]["cx"][2],
            "cfx": track[step][particle_id]["cf"][0],
            "cfy": track[step][particle_id]["cf"][1],
            "cfz": track[step][particle_id]["cf"][2],
            "lfx": track[step][particle_id]["lF"][0],
            "lfy": track[step][particle_id]["lF"][1],
            "lfz": track[step][particle_id]["lF"][2],
            "cwx": track[step][particle_id]["cw"][0],
            "cwy": track[step][particle_id]["cw"][1],
            "cwz": track[step][particle_id]["cw"][2],
            "anglex": track[step][particle_id]["coord"]["angle"][0],
            "angley": track[step][particle_id]["coord"]["angle"][1],
            "anglez": track[step][particle_id]["coord"]["angle"][2],
            "centerx": track[step][particle_id]["coord"]["center"][0],
            "centery": track[step][particle_id]["coord"]["center"][1],
            "centerz": track[step][particle_id]["coord"]["center"][2],
        }
        for step in track.keys()
    ]
    df = pd.DataFrame(res)
    df["u"] = np.sqrt(df["ux"] ** 2 + df["uy"] ** 2 + df["uz"] ** 2)
    df["du"] = df["u"].diff()
    return df


def export_particle_track(
    save_path="particle.csv",
    per_step: int = 100,
    *args,
    **kwargs,
):
    df = load_particle_track(*args, **kwargs)
    df = df[::per_step]
    df.to_csv(save_path, index=False, sep=" ")


# export_particle_track(job_id=15537908)
