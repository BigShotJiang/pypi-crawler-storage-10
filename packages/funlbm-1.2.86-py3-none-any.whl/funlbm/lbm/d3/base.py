import numpy as np
import torch
from funutil import run_timer

from funlbm.lbm.base import LBMBase
from funlbm.util import logger, get_available_device
from funlbm.util.device import to_device


@torch.jit.script
def _calculate_weight_function(r, n: int = 2, h: float = 1.0):
    """Calculate weight function for particle-fluid interaction."""

    r = torch.abs(r)

    # 限制权重函数的作用范围
    if n == 2:
        tmp = torch.where(
            torch.all(r <= 2 * h, dim=-1, keepdim=True),
            (1 + torch.cos(r * np.pi / 2 / h)) / 4 / h,
            0.0,
        )
    else:
        tmp = torch.where(
            r <= 1 * h,
            (3 - 2 * r + torch.sqrt(1 + 4 * r - 4 * r**2)) / 8,
            torch.where(
                r <= 2 * h, (5 - 2 * r - torch.sqrt(-7 + 12 * r - 4 * r**2)) / 8, 0.0
            ),
        )

    w = torch.prod(tmp, dim=-1, keepdim=True).to(dtype=torch.float32)
    # 归一化权重
    # w_sum = torch.sum(w)
    # if abs(w_sum - 1) > 1e-3:
    #     logger.warning(
    #         f"weight function for particle-fluid interaction is too large:{w_sum}"
    #     )
    #     w = w / w_sum
    return w


class LBMD3(LBMBase):
    """3D格子玻尔兹曼方法实现类
    实现了3D流场的基本功能,包括初始化、边界处理等
    Args:
        config: LBM配置对象
    """

    def __init__(self, *args, **kwargs):
        super(LBMD3, self).__init__(*args, **kwargs)
        self._region_bounds_cache = {}

    def _init(self):
        """初始化流场和颗粒"""
        # 初始化流程
        # 初始化边界条件
        self.flow.init()
        # 初始化颗粒
        self.flow.cul_equ()
        self.particle_swarm.init()
        self.particle_swarm.update()

    def _calculate_region_bounds_with_slice(self, lx, n=2, h=1):
        """Calculate region bounds for lx interaction with caching."""
        # Create cache key from lx tensor
        cache_key = (tuple(lx.flatten().tolist()), n, h)
        if cache_key in self._region_bounds_cache:
            return self._region_bounds_cache[cache_key]

        # 保持在GPU上计算
        rl = torch.floor(lx) - (n - 1) * h
        # 限制下界
        rl = torch.clamp(rl, min=0)
        rr = rl + (2 * n - 1) * h + 1
        # 限制上界
        domain_size = torch.tensor(
            self.config.flow_config.size, device=self.device, dtype=torch.float32
        )
        rr = torch.clamp(rr, max=domain_size)
        rl, rr = rl.to(dtype=torch.int32), rr.to(dtype=torch.int32)
        res = []
        for index, _ in enumerate(rr):
            il, ir = rl[index], rr[index]
            res.append(
                (
                    slice(il[0], ir[0]),
                    slice(il[1], ir[1]),
                    slice(il[2], ir[2]),
                    slice(None),
                )
            )

        # Cache the result
        self._region_bounds_cache[cache_key] = res
        return res

    @run_timer
    def flow_to_lagrange(self, n=2, *args, **kwargs):
        with torch.no_grad():
            for particle in self.particle_swarm.particles:
                lx_idx = self._calculate_region_bounds_with_slice(particle.lx)
                lu = torch.zeros_like(particle.lu, device=self.device)
                lrou = torch.zeros_like(particle.lrou, device=self.device)
                for idx, lar in enumerate(particle.lx):
                    tmp = _calculate_weight_function(self.flow.x[lx_idx[idx]] - lar)
                    # 归一化权重检查
                    w_sum = torch.sum(tmp)
                    if torch.abs(w_sum - 1) > 1e-3:
                        if self.step > 100:
                            logger.error(f"sum={w_sum},异常了，程序停止")
                            self.run_status = False
                        tmp = tmp / w_sum
                    lu[idx, :] = torch.sum(
                        self.flow.u[lx_idx[idx]] * tmp, dim=[0, 1, 2]
                    )
                    lrou[idx, :] = torch.sum(self.flow.rou[lx_idx[idx]] * tmp)
                particle.lF = 2 * lrou * (particle.lu - lu) / self.config.dt

    @run_timer
    def particle_to_wall(self, *args, **kwargs):
        """
        Handle particle-wall collisions using a spring force model.
        """
        k0 = 300  # Spring constant
        wall_normals = torch.tensor(
            [[1, 0, 0], [0, 1, 0], [0, 0, 1], [-1, 0, 0], [0, -1, 0], [0, 0, -1]],
            device=self.device,
            dtype=torch.float32,
        )

        domain_bounds = torch.concatenate(
            [
                torch.zeros(self.config.flow_config.size.shape, device=self.device),
                torch.tensor(
                    self.config.flow_config.size,
                    device=self.device,
                    dtype=torch.float32,
                ),
            ]
        )

        for particle in self.particle_swarm.particles:
            # Find extreme points of particle
            extreme_indices = torch.concatenate(
                [torch.argmin(particle.lx, dim=0), torch.argmax(particle.lx, dim=0)]
            )

            # Calculate wall distances
            distances = k0 * (
                1
                - abs(
                    particle.lx[extreme_indices][[0, 1, 2, 3, 4, 5], [0, 1, 2, 0, 1, 2]]
                    - domain_bounds
                )
                / (2 * self.config.dx)
            )
            distances = torch.clamp(distances, min=0)

            if distances.max() == 0:
                continue

            logger.info(f"Distance of particle to wall = {distances}")
            particle.lF[extreme_indices] += torch.multiply(
                wall_normals, distances.unsqueeze(1)
            )

    @run_timer
    def flow_iterator_second(self, *args, **kwargs) -> None:
        # 计算外力项
        f = self.lagrange_to_flow(n=self.config.dn)
        # 将外力项加入到流体参数迭代中
        self.cul_equ2(f=f)
        self.flow.update_u_rou(f=f)

    @run_timer
    def lagrange_to_flow(self, n=2, *args, **kwargs):
        f = torch.zeros_like(self.flow.u)
        with torch.no_grad():
            for particle in self.particle_swarm.particles:
                lx_idx = self._calculate_region_bounds_with_slice(particle.lx)
                for index, lar in enumerate(particle.lx):
                    tmp = _calculate_weight_function(
                        self.flow.x[lx_idx[index]] - lar, n=n
                    )
                    f[lx_idx[index]] += tmp * particle.lF[index, :] * particle.lm[index]
        return f

    @run_timer
    def cul_equ2(self, f=None, *args, **kwargs):
        """
        第二次碰撞，加上外力项
        使用 MPS 设备加速大矩阵运算
        """
        if f is None:
            return

        # 检查 MPS 可用性
        device = get_available_device(self.device)
        with torch.no_grad():
            # 预计算一些常量
            cs2 = self.flow.param.cs**2
            cs4 = cs2**2

            if device.type == "cpu":
                # 回退到原始实现（在 CPU 或其他设备上）
                e = self.flow.param.e.transpose(0, 1)
                u = self.flow.u[..., None]

                # 优化张量运算
                t2 = (e - u) / cs2 + (u * e * e) / cs4
                t3 = torch.sum(t2 * f.unsqueeze(-1), dim=-2)
                weight = (1 - 1 / (2 * self.flow.tau)) * self.flow.param.w[0]
                self.flow.f.add_(weight * t3)
                return
            else:
                # 将大矩阵运算相关的张量迁移到 MPS 设备
                e_gpu = to_device(self.flow.param.e.transpose(0, 1), device)
                u_gpu = to_device(self.flow.u[..., None], device)
                f_gpu = to_device(f.unsqueeze(-1), device)
                w_gpu = to_device(self.flow.param.w[0], device)
                tau_gpu = to_device(self.flow.tau, device)
                cs2_gpu = to_device(cs2, device)
                cs4_gpu = to_device(cs4, device)

                # 在 MPS 上执行大矩阵运算
                t2_mps = (e_gpu - u_gpu) / cs2_gpu + (u_gpu * e_gpu * e_gpu) / cs4_gpu
                t3_mps = torch.sum(t2_mps * f_gpu, dim=-2)
                weight_gpu = (1 - 1 / (2 * tau_gpu)) * w_gpu
                result_mps = weight_gpu * t3_mps

                # 将结果迁移回原设备并累加
                result_cpu = to_device(result_mps, self.config.device)
                self.flow.f.add_(result_cpu)

                # 清理 MPS 内存
                del e_gpu, u_gpu, f_gpu, w_gpu, tau_gpu, t2_mps, t3_mps, result_mps

                # torch.cuda.empty_cache()
                # torch.mps.empty_cache()
