import torch
from .base import LBMD3
from .base import _calculate_weight_function


class SULBMD3(LBMD3):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def flow_iterator_second(self, iterator_num=5, *args, **kwargs) -> None:
        # 计算外力项
        f = self.lagrange_to_flow(n=self.config.dn)
        # 将外力项加入到流体参数迭代中
        self.cul_equ2(f=f)
        self.flow.update_u_rou(f=f)
        # #
        lx, lu_except, lv = self._init_flow_g()

        fu = torch.zeros_like(self.flow.u) + self.flow.u
        fg = torch.zeros_like(fu)
        lg = torch.zeros_like(lu_except)
        for i in range(iterator_num):
            fu, fg, lx, lu = self._cul_flow_g(fu, fg, lx, lu_except, lg, lv)

        self.flow.f += 0.0 * (
            3
            * self.config.dx
            * torch.matmul(fg, self.flow.param.e.T)
            * self.flow.param.w
        )
        self.flow.update_u_rou()

    def _init_flow_g(self, deep=1):
        """
        计算需要迭代的拉格朗日点坐标、期望速度、密度
        """
        # 计算拉格朗日点的坐标
        lx = torch.empty([0, 3], device=self.config.device)
        lu_expect = torch.empty([0, 3], device=self.config.device)
        lv = torch.empty([0, 1], device=self.config.device)
        for particle in self.particle_swarm.particles:
            n = particle.lx - particle.cx
            n = n / torch.linalg.norm(n, dim=-1, keepdim=True)
            # n = n.to(device=self.config.device)

            lu = torch.zeros_like(particle.lu)
            fx = particle.lx + n
            lx_idx = self._calculate_region_bounds_with_slice(fx)
            for idx, lar in enumerate(fx):
                tmp = _calculate_weight_function(self.flow.x[lx_idx[idx]] - lar)
                lu[idx, :] = torch.sum(self.flow.u[lx_idx[idx]] * tmp, dim=[0, 1, 2])

            for i in range(0, deep + 1):
                lx = torch.cat([lx, (particle.lx - i * n)], dim=0)
                lu_expect = torch.cat(
                    [lu_expect, (particle.lu + i * (particle.lu - lu))], dim=0
                )
                lv = torch.cat(
                    [
                        lv,
                        (
                            particle.lm
                            / particle.rou
                            * (particle.ra - i) ** 3
                            / particle.ra**3
                        ),
                    ],
                    dim=0,
                )
        return lx, lu_expect, lv

    def _cul_flow_g(self, fu, fg, lx, lu_except, lg, lv, sh=1):
        """
        计算迭代过程中的g
        Returns:
        """
        lu = torch.zeros_like(lu_except)
        # 计算欧拉点的fu
        fu += self.config.dt / sh * fg

        # 插值计算拉格朗日点的lu
        lx_idx = self._calculate_region_bounds_with_slice(lx)
        for idx, lar in enumerate(lx):
            weight = _calculate_weight_function(self.flow.x[lx_idx[idx]] - lar)
            lu[idx, :] = torch.sum(self.flow.u[lx_idx[idx]] * weight, dim=[0, 1, 2])
        # 计算拉格朗日点的g
        lg += sh / self.config.dt * (lu_except - lu)
        # 插值计算欧拉点的g
        fg = fg * 0
        for idx, lar in enumerate(lx):
            weight = _calculate_weight_function(self.flow.x[lx_idx[idx]] - lar)
            fg[lx_idx[idx]] += lg[idx, :] * weight * lv[idx, :]
        return fu, fg, lx, lu
