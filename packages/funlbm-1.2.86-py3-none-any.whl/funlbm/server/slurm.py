import subprocess
from typing import List


def get_slurm_partitions() -> List[str]:
    try:
        # 执行 sinfo 命令并获取输出
        result = subprocess.run(
            ["sinfo", "-o", "%P"], capture_output=True, text=True, check=True
        )

        # 处理输出，去重并排序
        partitions = sorted(set(result.stdout.strip().split("\n")[1:]))

        # 过滤空字符串
        partitions = [p for p in partitions if p]

        return partitions

    except subprocess.CalledProcessError as e:
        print(f"命令执行失败: {e}")
        return []
    except FileNotFoundError:
        print("sinfo 命令未找到，请确保 Slurm 已安装")
        return []
