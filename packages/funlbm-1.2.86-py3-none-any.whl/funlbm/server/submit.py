import os
import shutil
from datetime import datetime

import typer
from funbuild.shell import run_shell
from funutil import getLogger

from .base import funlbm_cli
from funlbm.lbm.base import create_lbm_config
from .slurm import get_slurm_partitions


logger = getLogger("funlbm")


def create_slurm(
    target_file: str = "./config.slurm", task_name: str = "funlbm", core: int = 64
) -> bool:
    if shutil.which("sbatch") is None:
        return False
    content = f"""
#!/bin/bash
#SBATCH -J {task_name}
#SBATCH -p {get_slurm_partitions()[0]}
#SBATCH -N 1
#SBATCH --ntasks-per-node={core}
##SBATCH --mem-per-cpu=1

module purge

~/farfarfun/.venv/bin/funlbm run
    """
    content = content.strip("\n")
    with open(target_file, "w") as fw:
        fw.write(content)
    logger.success(f"created {target_file} successfully.")
    return True


@funlbm_cli.command()
def submit(
    config=typer.Option("./config.json", help="配置文件地址"),
    core_num=typer.Option(8, help="运行核数"),
):
    # 从配置文件名提取默认任务名
    default_task_name: str = os.path.basename(config)
    default_task_name = default_task_name.lstrip("config").lstrip("-")
    default_task_name = default_task_name.rstrip(".json")

    # 如果提取的任务名太短或为空，使用 "funlbm" 作为默认值
    if len(default_task_name) < 3:
        default_task_name = "funlbm"

    # 提示用户输入任务名，显示默认值
    user_input = input(f"请输入任务名字（直接回车使用默认值 '{default_task_name}'）: ")
    task_name = user_input.strip() or default_task_name

    # 提示用户输入运行核数，显示默认值
    default_core_num = core_num.default
    final_core_num = default_core_num
    while True:
        core_input = input(
            f"请输入运行核数（直接回车使用默认值 '{default_core_num}'）: "
        )
        if not core_input.strip():
            # 用户直接回车，使用默认值
            final_core_num = default_core_num
            break
        try:
            final_core_num = int(core_input.strip())
            if final_core_num <= 0:
                print("运行核数必须是正整数，请重新输入")
                continue
            break
        except ValueError:
            print("输入无效，运行核数必须是正整数，请重新输入")
            continue

    task_dir = os.path.join(
        os.path.expanduser("~"), "workbench", datetime.now().strftime("%Y%m%d%H%M%S")
    )

    # 显示任务信息并请求用户确认
    print("\n" + "=" * 60)
    print("任务信息确认:")
    print(f"  任务名称: {task_name}")
    print(f"  配置文件: {config}")
    print(f"  运行核数: {final_core_num}")
    print(f"  任务目录: {task_dir}")
    print("=" * 60)
    print(create_lbm_config(config).meta_info())

    while True:
        confirm = input("确认提交任务？(y/n): ").strip().lower()
        if confirm in ["y", "yes", "是"]:
            logger.info("用户确认提交任务")
            break
        elif confirm in ["n", "no", "否"]:
            logger.info("用户取消提交任务")
            return
        else:
            print("请输入 y(是) 或 n(否)")

    print(f"任务主目录：{task_dir}")
    os.makedirs(task_dir, exist_ok=True)

    logger.info(f"复制文件到任务主目录：{task_dir}")
    # run_shell(f"cp -r *.cpp *.h *.sh *.slurm *.f90 *.dat *.json {task_dir} 2>/dev/null")
    # logger.success(f"复制文件到任务主目录：{task_dir}完成")

    if not os.path.exists(config):
        logger.error(f"{config} not exists, return.")
        return

    run_shell(f"cp {config} {task_dir}/config.json 2>/dev/null")
    logger.success(f"复制文件到任务主目录：{config} -> {task_dir}/config.json.")

    if create_slurm(f"{task_dir}/config.slurm", task_name, core=final_core_num):
        logger.info("检测到sbatch命令，提交到算力平台")
        run_shell(f"cd {task_dir} && sbatch config.slurm")
        return

    if os.path.exists(config):
        logger.info("本地运行")
        run_shell(f"""cd {task_dir} && nohup funlbm run > output.log 2>&1 &""")
        return

    logger.error("找不到需要提交的任务")
