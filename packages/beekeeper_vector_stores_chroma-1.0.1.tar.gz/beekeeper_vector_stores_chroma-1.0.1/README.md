# Beekeeper vector_stores extension - Chroma

## Installation 

```bash
pip install beekeeper-vector-stores-chroma
```
