class Salt:
    salt: int
    valid_since: int
    valid_until: int

    def __str__(self):
        return str(self.salt)
