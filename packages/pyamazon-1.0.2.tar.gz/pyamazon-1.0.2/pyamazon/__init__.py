from .fetchProduct import extractAmazon
