from pyba.utils.prompts.system_prompt import system_prompt as system_instruction
from pyba.utils.prompts.general_prompt import general_prompt
