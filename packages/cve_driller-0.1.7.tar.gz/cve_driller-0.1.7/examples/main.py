import json

from cve_driller.driller import CVEDriller


if __name__ == "__main__":
    driller = CVEDriller(verbose=True)
    cve_id = "CVE-2018-7187"

    input_path = f"data/inputs/CWE-78/comp_config_condition/{cve_id}.txt"
    #description = open(input_path, 'r').read()
    description = "The MyScript SDK before 1.3 for Android might allow attackers to execute arbitrary code by leveraging a finalize method in a Serializable class that improperly passes an attacker-controlled pointer to a native function."
    detail_type, details = driller(description)
    # CVE-2015-2020

    if details:
        print(json.dumps(details, indent=4))

    #if details:
    #    output_path = f"data/outputs/{detail_type.value}/{cve_id}.json"

    #    with open(output_path, 'w') as f:
    #        json.dump(details, f, indent=4)
