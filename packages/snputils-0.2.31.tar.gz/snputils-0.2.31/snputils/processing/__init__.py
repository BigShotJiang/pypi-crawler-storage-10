from .pca import TorchPCA
from .pca import PCA
from .maasmds import maasMDS
from .mdpca import mdPCA