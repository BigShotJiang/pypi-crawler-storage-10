import numpy as np

def update_q_value(q_value: float,
                   reward: float,
                   next_max_q: float,
                   learning_rate: float = 0.1,
                   discount_factor: float = 0.9) -> float:
    """
    Calculates the updated Q-value using the Q-learning update rule.

    Parameters:
    - q_value (float): The current Q-value for the (state, action) pair.
    - reward (float): The reward received after taking the action.
    - next_max_q (float): The maximum Q-value for the next state.
    - learning_rate (float): The learning rate (alpha).
    - discount_factor (float): The discount factor (gamma).

    Returns:
    - float: The newly calculated Q-value.
    """
    # The core Q-learning formula
    new_q = q_value + learning_rate * (reward + discount_factor * next_max_q - q_value)
    
    return new_q