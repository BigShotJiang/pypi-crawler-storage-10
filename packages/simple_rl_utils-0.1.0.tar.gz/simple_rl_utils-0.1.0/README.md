# Simple RL Utils

A minimal Python package containing simple utility functions for Reinforcement Learning.

## Installation

```bash
pip install simple_rl_utils