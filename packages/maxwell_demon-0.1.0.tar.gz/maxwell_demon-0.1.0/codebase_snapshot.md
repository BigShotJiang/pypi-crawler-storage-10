# Snapshot

## Filesystem Tree

```
maxwell-file-demon/
├── plugins/
│   └── README.md
├── src/
│   ├── maxwell/
│   │   ├── workflows/
│   │   │   ├── chat/
│   │   │   │   ├── README.md
│   │   │   │   ├── __init__.py
│   │   │   │   ├── backup_strategy.py
│   │   │   │   ├── batch_extract.py
│   │   │   │   ├── bm25_search.py
│   │   │   │   ├── data_quality.py
│   │   │   │   ├── incremental_processor.py
│   │   │   │   ├── metadata_extractor.py
│   │   │   │   ├── parsers.py
│   │   │   │   └── semantic_search.py
│   │   │   ├── validate/
│   │   │   │   ├── validators/
│   │   │   │   │   ├── project_wide/
│   │   │   │   │   │   └── __init__.py
│   │   │   │   │   ├── single_file/
│   │   │   │   │   │   ├── __init__.py
│   │   │   │   │   │   ├── dict_get_fallback.py
│   │   │   │   │   │   ├── emoji.py
│   │   │   │   │   │   ├── exports.py
│   │   │   │   │   │   ├── logger_names.py
│   │   │   │   │   │   └── typing_quality.py
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   └── types.py
│   │   │   │   ├── __init__.py
│   │   │   │   ├── ast_utils.py
│   │   │   │   └── validation_engine.py
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   ├── deep_research.py
│   │   │   ├── justification.py
│   │   │   ├── snapshot.py
│   │   │   ├── tag_refactor.py
│   │   │   └── utilities.py
│   │   ├── DEMON.txt
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── api.py
│   │   ├── cli.py
│   │   ├── config.py
│   │   ├── discovery.py
│   │   ├── extractors.py
│   │   ├── filesystem.py
│   │   ├── lm_pool.py
│   │   ├── mcp_server.py
│   │   ├── pydantic_gbnf.py
│   │   ├── registry.py
│   │   ├── reporting.py
│   │   ├── rules.py
│   │   ├── storage.py
│   │   ├── types.py
│   │   └── utils.py
│   └── maxwell.egg-info/
│       ├── PKG-INFO
│       ├── SOURCES.txt
│       ├── dependency_links.txt
│       ├── entry_points.txt
│       ├── requires.txt
│       └── top_level.txt
├── systemd/
│   └── maxwell-mcp.service
├── AGENTS.instructions.md
├── CLAUDE.md
├── LICENSE
├── MANIFEST.in
├── README.md
├── dev.pyproject.toml
├── pyproject.toml
└── tox.ini
```

## File Contents

Files are ordered alphabetically by path.

### File: AGENTS.instructions.md

```markdown
# Maxwell Development Instructions

## Module Organization & Shared Code

**CRITICAL PRINCIPLE**: When modules at the same level share code (imports, utilities, types, or circular dependencies):

1. **Create a NEW submodule** (directory)
2. **Move BOTH modules** into that submodule
3. **Create a THIRD module** in the submodule for shared code/types
4. **Add `__init__.py`** to export public API
5. Both modules now import from the shared third module

**Examples:**

```
# BAD - Circular imports at same level
src/maxwell/
  module_a.py  # imports from module_b
  module_b.py  # imports from module_a  ❌

# BAD - Shared utilities at same level
src/maxwell/
  feature_a.py  # imports from utils.py
  feature_b.py  # imports from utils.py
  utils.py      # shared helpers  ❌

# GOOD - New submodule with shared code
src/maxwell/feature/          # NEW submodule
  __init__.py                 # NEW - exports public API
  types.py                    # NEW - shared types/utilities
  feature_a.py                # MOVED here, imports from .types
  feature_b.py                # MOVED here, imports from .types  ✅
```

**Key Steps:**
- Don't just add a third file at the same level - **create a submodule**
- **Move all related modules** into the submodule
- Shared code/utilities go in a dedicated module **inside** the submodule
- The `__init__.py` exposes what's needed externally

**Applies to:**
- ✅ Circular imports (module A ↔ module B)
- ✅ Shared utilities (multiple modules → shared utils)
- ✅ Shared types/base classes
- ✅ Any tightly coupled code

**Rationale**:
- Keeps related/coupled code together in one namespace
- Prevents circular dependencies
- Makes shared code ownership clear (part of the feature, not global)
- Reduces drift between tightly coupled modules
- No orphaned `utils.py` files at top level

**Real Example**: `BaseWorkflow` and workflow implementations:
- All in `workflows/` submodule
- Shared base classes in `workflows/base.py`
- Each workflow file imports from `workflows.base`
- No circular dependencies

## File Organization Rules

### Forbidden
- **NO `scripts/` directory** - Scripts go in project root or become proper modules
- **NO `utils/` directory** - Use properly named modules (`io/`, `fs/`, etc.)
- **NO one-off scripts** - Delete after use or integrate as modules

### Project Structure
```
maxwell/
├── src/maxwell/          # All Python source
├── tests/                # Tests
├── docs/                 # Documentation
├── .maxwell-*/           # Generated artifacts (gitignored)
├── pyproject.toml        # Project metadata
├── README.md             # Single entry doc
├── CLAUDE.md             # User instructions
└── AGENTS.instructions.md # This file
```

### Root Directory
**Only contains:**
- Metadata: `pyproject.toml`, `setup.py`, `LICENSE`
- Docs: `README.md`, `*.instructions.md`
- Config: `.gitignore`, `.env.example`
- Entry points: `__init__.py`, `__main__.py`, `conftest.py`
- Tool outputs: `coverage.xml`, `.coverage`

**Runtime resources** (ASCII art, templates) → `src/maxwell/` (for `importlib.resources`)

## Linting Pipeline

**Run in this exact order:**

```bash
isort src/ tests/              # 1. Sort imports
black src/ tests/              # 2. Format code
ruff check --fix src/ tests/   # 3. Lint
pyright src/                   # 4. Type check
```

**Why this order**: black reformats isort's multi-line imports, so black must run after isort.

## No Backward Compatibility

**CRITICAL PRINCIPLE**: Maxwell is pre-1.0 and under active development. **NO backward compatibility layers.**

- **NO deprecated functions/aliases** - Delete old code immediately
- **NO `@deprecated` decorators** - Remove, don't warn
- **NO legacy config support** - Migrate to new patterns directly
- **NO compatibility shims** - Clean breaks only

**When refactoring:**
1. User and assistant agree on new pattern
2. Delete old implementation entirely
3. Update all call sites immediately
4. No transition period, no warnings

**Examples:**
```python
# BAD - Backward compatibility alias
def get_llm():  # new
    ...

def get_language_model():  # deprecated alias ❌
    return get_llm()

# GOOD - Clean migration
def get_lm():  # new name agreed upon
    ...
# Old get_llm() deleted, all call sites updated ✅
```

**Rationale:**
- We're not at a stage where users depend on stability
- Backward compatibility adds complexity and confusion
- Clean breaks force consistency
- Easier to maintain and understand
- No accumulation of technical debt

## Type Safety

### Workflow Schemas
Each workflow defines typed input/output schemas **in the same file**:

```python
# my_workflow.py
from dataclasses import dataclass
from maxwell.workflows.base import BaseWorkflow, WorkflowInputs, WorkflowOutputs

@dataclass(frozen=True)
class MyInputs(WorkflowInputs):
    query: str
    limit: int = 10

@dataclass(frozen=True)
class MyOutputs(WorkflowOutputs):
    results: List[str]
    count: int

class MyWorkflow(BaseWorkflow):
    InputSchema = MyInputs
    OutputSchema = MyOutputs

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        inputs: MyInputs = self.parse_inputs(context)  # Type-safe!
        # ... work ...
        outputs = MyOutputs(results=results, count=len(results))
        return self.create_result(outputs)
```

**See** `SCHEMA_MIGRATION.md` for details.

### Type Definitions
- **Use `FrozenSet[T]`** for immutable collections (contracts, constants)
- **Use `dataclasses`** over dicts - NO `Dict[str, Any]`
- **Type annotate everything** - enable full pyright checking

## Development Workflow

1. Make changes
2. Run linting pipeline (isort → black → ruff → pyright)
3. Run tests: `tox -e py311`
4. If adding workflows: register with `@register_workflow` decorator

## Justification Workflow

**Resource-intensive** (8-10 min for 120 files):
- Analyzes file placement and architecture
- **Output is LLM-generated** - always review critically
- Can misunderstand runtime requirements

```bash
# Run in background
nohup python -c "..." > /tmp/justification.log 2>&1 &
tail -f .maxwell-legacy/logs/justification_*.log
```

## Workflow System

### Auto-Registration
Workflows in `src/maxwell/workflows/` automatically:
- Register in workflow registry (`@register_workflow`)
- Available via CLI: `maxwell workflow-id --param value`
- Accessible via Python API
- Exposed as MCP tools

### CLI Usage
```bash
maxwell list-workflows                    # List all workflows
maxwell tag_refactor --dry-run            # Run workflow
maxwell chat-search --query "embedding"   # Search workflows
```
---

**Last updated**: 2025-10-23
```

---
### File: CLAUDE.md

```markdown
Read AGENTS.instructions.md
```

---
### File: LICENSE

```
MIT License

Copyright (c) 2025 vibelint Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---
### File: MANIFEST.in

```
# Include these specific top-level files in the sdist
include LICENSE
include README.md
include pyproject.toml
include tox.ini

# Yeah
include src/vibelint/VIBECHECKER.txt

# Recursively include all files (*) found within the 'examples' directory
recursive-include examples *
# Recursively include all Python files (*.py) found within the 'tests' directory
recursive-include tests *.py

# Recursively exclude any directory named '__pycache__' anywhere in the project
recursive-exclude * __pycache__
# Recursively exclude compiled Python files anywhere
recursive-exclude * *.py[cod]
# Recursively exclude compiled C extensions anywhere
recursive-exclude * *.so
# Recursively exclude VIM swap files anywhere
recursive-exclude * .*.swp
# Recursively exclude macOS metadata files anywhere
recursive-exclude * .DS_Store
```

---
### File: README.md

```markdown
# Maxwell

**Semantic workflow automation for codebases and documents** - A CLI-first tool for content analysis, search, and code quality.

Maxwell provides a plugin-like workflow system where each workflow is a self-contained analyzer, generator, or searcher. All workflows use the same CLI pattern: `maxwell <workflow-id> [options]`.

## Features

- **Workflow-based architecture** - Extensible plugin system for analysis tasks
- **Semantic search** - Find documents and conversations by meaning using embeddings
- **Multi-format extraction** - PDFs (marker-pdf), Office docs (markitdown), Claude chat logs (.jsonl)
- **Code analysis** - Justification analysis, validation, and quality checks
- **Codebase snapshots** - Generate markdown documentation of entire codebases
- **Content-addressable storage** - Files identified by SHA256 hash, global deduplication
- **Distributed architecture** - Each directory has `.maxwell/` (like `.git/`)

## Installation

```bash
pip install -e .
```

## Quick Start

### List Available Workflows

```bash
maxwell list-workflows
```

### Generate a Codebase Snapshot

Create a markdown file with filesystem tree and file contents:

```bash
maxwell snapshot --output SNAPSHOT.md
```

### Search Chat Conversations

Find discussions using semantic search:

```bash
maxwell chat-semantic-search --query "PDF parsing marker-pdf" --top-k 5
```

Or use BM25 keyword search:

```bash
maxwell chat-bm25-search --query "marker-pdf import error" --limit 10
```

### Analyze Code Architecture

Run LLM-powered justification analysis to find misplaced/redundant files:

```bash
maxwell justification
```

### Validate Code Quality

Run validators to check code quality and style:

```bash
maxwell validate --fix
```

### Utilities

Get timestamps and session IDs for scripting:

```bash
maxwell get-time --format iso
maxwell get-session
```

## Available Workflows

Run `maxwell list-workflows` for the full list. Key workflows:

- **snapshot** - Generate codebase documentation (markdown with tree + contents)
- **justification** - LLM-powered code architecture analysis
- **chat-semantic-search** - Semantic search over indexed chat logs
- **chat-bm25-search** - Keyword search over chat conversations
- **chat_upsert** - Index chat files into MongoDB with deduplication
- **validate** - Code quality validation with auto-fix
- **tag_refactor** - Format semantic HTML tags in markdown files
- **get-time** / **get-session** - Utility workflows for timestamps and session IDs

## Configuration

Add to `pyproject.toml`:

```toml
[tool.maxwell]
include_globs = [
    "*.md", "**/*.md",
    "*.pdf", "**/*.pdf",
    "**/.claude/projects/*.jsonl"    # Include chat logs
]
exclude_globs = [
    ".maxwell/**",
    ".git/**",
    "__pycache__/**",
    "*.pyc"
]

# Validation rules (optional)
[tool.maxwell.validation]
rules = { EMOJI-USAGE = "BLOCK", DICT-GET-FALLBACK = "WARN" }
```

## Architecture

```
project/
├── .maxwell/                      # Like .git/, per-directory
│   ├── data/                      # Workflow-specific data (committed to git)
│   ├── indexes/                   # SQLite indexes (gitignored, rebuildable)
│   ├── extracted/                 # Cached extractions (gitignored)
│   └── .gitignore                 # Auto-created
└── your-files/

~/.maxwell/                        # Global cache
└── cache.db                       # Shared embedding cache (deduplication)
```

## What Gets Indexed

Maxwell can work with:
- **Markdown files** (`.md`)
- **PDFs** (`.pdf`) - reuses existing parsed versions when available
- **Claude chat logs** (`.jsonl` in `.claude/projects/`)
- **Office documents** (`.docx`, `.pptx`, `.xlsx`)
- **Python code** (`.py`) - semantic code analysis

## Extending Maxwell

### Plugin System

Maxwell supports external plugins without modifying core code. Plugins are loaded from:
- `~/.maxwell/plugins/` (global plugins)
- `<project>/.maxwell/plugins/` (project-specific plugins)

**Two plugin types:**

1. **Python plugins**: `.py` files with `BaseWorkflow` subclasses
2. **Script plugins**: Executable scripts with `.json` metadata

Example script plugin:

```bash
#!/usr/bin/env bash
# ~/.maxwell/plugins/hello
echo "Hello from Maxwell plugin!"
```

```json
{
  "workflow_id": "hello",
  "name": "Hello Plugin",
  "description": "Simple hello world plugin",
  "category": "utility"
}
```

See [plugins/README.md](./plugins/README.md) for detailed plugin development guide.

### Core Workflow Development

To add workflows to Maxwell core:

1. Create a Python file in `src/maxwell/workflows/`
2. Define a `BaseWorkflow` subclass with `@register_workflow` decorator
3. Implement `execute()`, `get_cli_parameters()`, and schema classes
4. Import your workflow in `src/maxwell/workflows/__init__.py`

Example:

```python
from maxwell.workflows.base import BaseWorkflow
from maxwell.registry import register_workflow

@register_workflow
class MyWorkflow(BaseWorkflow):
    workflow_id = "my-workflow"
    name = "My Custom Workflow"
    description = "Does something cool"

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        # Your logic here
        pass
```

## Development

See [AGENTS.instructions.md](./AGENTS.instructions.md) for development guidelines.

### Testing

```bash
# Run formatters and linters
isort src/
black src/
ruff check --fix src/
pyright src/
```

## Documentation

- [Development Instructions](./AGENTS.instructions.md)
- [Claude Code Config](./.claude/settings.json)
- [MCP Documentation](./docs/README_MCP.md)
- [Schema Migration Guide](./docs/SCHEMA_MIGRATION.md)

## License

See LICENSE file.
```

---
### File: dev.pyproject.toml

```toml
# Development override configuration
# This file overrides production settings when running locally
# Similar to how Node.js uses .env.local to override .env

[tool.maxwell]
# Development settings
max_retries = 2
timeout = 30
debug_mode = true
use_local_cache = true

# LLM configuration moved to ~/.maxwell/llm_registry.json
# This allows flexible multi-LLM setup without hard-coded roles

[tool.maxwell.chat_analytics]
# Chat analytics configuration for multi-source conversation indexing
qdrant_host = "localhost"
qdrant_port = 6333
qdrant_collection = "chat_messages"
mongodb_uri = "mongodb://localhost:27017"
mongodb_db = "chat_analytics"
neo4j_uri = "bolt://localhost:7687"
neo4j_user = "neo4j"
neo4j_password = "chatgpt123"
enable_neo4j = false
embedding_url = "http://100.127.86.64:8001/v1/embeddings"
embedding_model = "Qwen/Qwen3-Embedding-4B"
embedding_dim = 2560
batch_size = 50

[tool.logging]
# Override log rotation for development
daily_rotation = true
max_file_size = "50MB"
backup_count = 7
log_level = "DEBUG"
```

---
### File: plugins/README.md

```markdown
# Maxwell Plugins

Maxwell supports external plugins to extend its functionality without modifying core code.

## Plugin Types

### 1. Python Plugins

Python plugins are `.py` files containing BaseWorkflow subclasses:

```python
# ~/.maxwell/plugins/my_plugin.py
from pathlib import Path
from typing import Any, Dict, List
from dataclasses import dataclass

from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowConfig,
    WorkflowPriority,
    WorkflowResult,
)
from maxwell.registry import register_workflow

@dataclass(frozen=True)
class MyPluginInputs(WorkflowInputs):
    message: str = "Hello, World!"

@dataclass(frozen=True)
class MyPluginOutputs(WorkflowOutputs):
    result: str

@register_workflow
class MyPluginWorkflow(BaseWorkflow):
    workflow_id = "my-plugin"
    name = "My Custom Plugin"
    description = "Example plugin workflow"
    version = "1.0"
    category = "custom"
    tags = {"plugin", "example"}

    InputSchema = MyPluginInputs
    OutputSchema = MyPluginOutputs

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "message",
                "type": str,
                "required": False,
                "default": "Hello, World!",
                "help": "Message to process",
            }
        ]

    def get_required_inputs(self) -> List[str]:
        return []

    def get_produced_outputs(self) -> List[str]:
        return ["result"]

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=60,
            parameters={"root_dir": str(root_dir)},
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        inputs: MyPluginInputs = self.parse_inputs(context)

        # Your plugin logic here
        result = f"Processed: {inputs.message}"

        outputs = MyPluginOutputs(result=result)
        return self.create_result(outputs)
```

### 2. Script Plugins

Script plugins are executable scripts with JSON metadata files:

**Example: hello-plugin**

```bash
#!/usr/bin/env bash
# ~/.maxwell/plugins/hello

name=${1:-World}
echo "Hello, $name from Maxwell plugin!"
```

```json
{
  "workflow_id": "hello",
  "name": "Hello Plugin",
  "description": "Simple hello world plugin",
  "version": "1.0",
  "category": "utility",
  "tags": ["example", "greeting"],
  "parameters": [
    {
      "name": "name",
      "type": "str",
      "required": false,
      "default": "World",
      "help": "Name to greet"
    }
  ]
}
```

Make the script executable:
```bash
chmod +x ~/.maxwell/plugins/hello
```

## Plugin Locations

Maxwell searches for plugins in:

1. **Global plugins**: `~/.maxwell/plugins/`
2. **Project plugins**: `<project>/.maxwell/plugins/`

Project plugins are loaded after global plugins, so they can override global ones.

## Using Plugins

Once installed, plugins appear in the workflow list:

```bash
maxwell list-workflows
# Will show your custom plugins alongside built-in workflows

maxwell my-plugin --message "Hello from plugin!"
# Execute your Python plugin

maxwell hello --name "Maxwell"
# Execute your script plugin
```

## Example Plugins

### Git Stats Plugin (Script)

```bash
#!/usr/bin/env bash
# ~/.maxwell/plugins/git-stats

days=${1:-7}

echo "Git activity for last $days days:"
git log --since="$days days ago" --pretty=format:"%h - %an: %s" --abbrev-commit
```

```json
{
  "workflow_id": "git-stats",
  "name": "Git Statistics",
  "description": "Show git commit statistics",
  "version": "1.0",
  "category": "git",
  "tags": ["git", "statistics"],
  "parameters": [
    {
      "name": "days",
      "type": "int",
      "required": false,
      "default": 7,
      "help": "Number of days to look back"
    }
  ]
}
```

### File Counter Plugin (Python)

```python
# ~/.maxwell/plugins/count_files.py
from pathlib import Path
from typing import Any, Dict, List
from dataclasses import dataclass
from collections import Counter

from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
)
from maxwell.registry import register_workflow

@dataclass(frozen=True)
class CounterInputs(WorkflowInputs):
    pass

@dataclass(frozen=True)
class CounterOutputs(WorkflowOutputs):
    counts: Dict[str, int]

@register_workflow
class FileCounterWorkflow(BaseWorkflow):
    workflow_id = "count-files"
    name = "File Counter"
    description = "Count files by extension"

    InputSchema = CounterInputs
    OutputSchema = CounterOutputs

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        counter = Counter()
        for file in project_root.rglob("*"):
            if file.is_file():
                counter[file.suffix or "no_extension"] += 1

        outputs = CounterOutputs(counts=dict(counter))
        return self.create_result(outputs)
```

## Best Practices

1. **Naming**: Use lowercase with hyphens for workflow_id (e.g., `my-plugin`)
2. **Categories**: Choose appropriate category (utility, analysis, documentation, etc.)
3. **Documentation**: Always include description and help text
4. **Error Handling**: Handle errors gracefully and return meaningful messages
5. **Testing**: Test plugins before deploying to production
6. **Versioning**: Use semantic versioning for your plugins

## Troubleshooting

Enable debug logging to see plugin loading:

```bash
export MAXWELL_LOG_LEVEL=DEBUG
maxwell list-workflows
```

Check plugin discovery:
```python
from maxwell.registry import get_workflow_registry

registry = get_workflow_registry()
registry.load_plugins()  # Manually trigger plugin loading
print(registry.list_workflow_ids())
```
```

---
### File: pyproject.toml

```toml
[build-system]
requires = ["setuptools>=45", "wheel", "setuptools_scm>=6.2"]
build-backend = "setuptools.build_meta"

[project]
name = "maxwell-demon"
version = "0.1.0"
description = "Semantic workflow automation for codebases and documents - CLI-first tool for content analysis, search, and code quality."
authors = [
  { name = "Mithran Mohanraj", email = "mithran.mohanraj@gmail.com" }
]
readme = "README.md"
requires-python = ">=3.11"
license = {text = "MIT"}
classifiers = [
    "Development Status :: 3 - Alpha",
    "Environment :: Console",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Software Development :: Quality Assurance",
]
dependencies = [
    # Core workflow system
    "pydantic>=2.0",
    "rich>=12.0",

    # Configuration
    "tomli-w",
    "python-dotenv>=1.0",

    # Code analysis
    "libcst",

    # HTTP client
    "requests>=2.25",
]

[project.optional-dependencies]
# Chat and semantic search workflows
chat = [
    "pymongo>=4.0",
    "qdrant-client>=1.0",
    "rank-bm25>=0.2",
    "numpy>=1.21",
]

# PDF and document extraction
docs = [
    "marker-pdf>=0.2",
    "markitdown>=0.0.1",
]

# MCP server support
mcp = [
    "mcp>=0.1",
]

# All optional features
all = [
    "pymongo>=4.0",
    "qdrant-client>=1.0",
    "rank-bm25>=0.2",
    "numpy>=1.21",
    "marker-pdf>=0.2",
    "markitdown>=0.0.1",
    "mcp>=0.1",
]

# Development tools
dev = [
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "pytest-asyncio>=0.21",
    "ruff>=0.1",
    "black>=23.0",
]

[project.scripts]
maxwell = "maxwell.cli:main"

[project.entry-points."maxwell.validators"]
# Built-in validators are auto-discovered from the filesystem.
# Only third-party validators need to be registered here as entry points.
#
# Third-party packages can add validators here:
# Example:
# "MY-CUSTOM-RULE" = "my_package.validators:MyCustomValidator"


[project.entry-points."maxwell.formatters"]
human = "maxwell.reporting:HumanFormatter"
natural = "maxwell.reporting:NaturalLanguageFormatter"
json = "maxwell.reporting:JsonFormatter"
sarif = "maxwell.reporting:SarifFormatter"
llm = "maxwell.reporting:LLMFormatter"

[project.entry-points."maxwell.workflows"]
# Entry points for EXTERNAL packages to extend vibelint with custom workflows
# Built-in workflows are registered directly in code, not here

# Third-party workflows can be added here by other packages:
# Examples of different workflow types:
# Simple function workflow:
# "my-simple-check" = "my_package.workflows:simple_check_function"
#
# Class-based workflow:
# "my-complex-workflow" = "my_package.workflows:MyComplexWorkflow"
#
# Multi-file workflow module:
# "my-enterprise-workflow" = "my_package.workflows.enterprise_suite:EnterpriseWorkflowEngine"

[project.urls]
"Homepage" = "https://github.com/mithranm/maxwell-file-demon"
"Bug Tracker" = "https://github.com/mithranm/maxwell-file-demon/issues"

[tool.setuptools.packages.find]
where = ["src"]
include = ["maxwell*"]

[tool.black]
target-version = ["py311", "py312"]
line-length=100

[tool.ruff]
line-length = 100
target-version = "py311"
exclude = [
    ".git",
    ".pytest_cache",
    "__pycache__",
    "build",
    "dist",
    ".venv",
    "venv"
]

[tool.ruff.lint]
select = [
    "E",      # pycodestyle errors
    "W",      # pycodestyle warnings
    "F",      # pyflakes
    "D",      # pydocstyle - docstring checks (replaces docstring.py validator)
    "T201",   # Print statement detection (replaces print_statements.py validator)
    "TID",    # Import style enforcement (replaces relative_imports.py validator)
    "C901",   # Complexity checks (replaces code_smells.py validator)
]
ignore = [
    "E501",   # Line too long (handled by black)
    "B008",   # Allow function calls in argument defaults
    "B904",   # Allow raise without from for now
    "UP036",  # Allow outdated version blocks
    "C414",   # Allow unnecessary list() calls for clarity
    "SIM102", # Allow nested if statements
    "SIM210", # Allow if-else instead of bool()
    "SIM113", # Allow manual index tracking
    "SIM103", # Allow explicit return True/False
    "N802",   # Allow uppercase function names (LibCST visitor methods)
    "N806",   # Allow uppercase variables
    "B006",   # Allow mutable defaults for now
    "B007",   # Allow unused loop variables
    "UP007",  # Allow Union syntax for now
    "C901",   # Allow complex functions (we'll refactor later)
    "F821",   # Allow undefined names (forward refs in type hints)
    "F841",   # Allow unused local variables
    # Docstring rules (D) - relax some for existing code
    "D100",   # Missing docstring in public module
    "D101",   # Missing docstring in public class
    "D102",   # Missing docstring in public method
    "D103",   # Missing docstring in public function
    "D104",   # Missing docstring in public package
    "D105",   # Missing docstring in magic method
    "D107",   # Missing docstring in __init__
    "D203",   # 1 blank line required before class docstring (conflicts with D211)
    "D205",   # 1 blank line required between summary line and description
    "D213",   # Multi-line docstring summary should start at second line (conflicts with D212)
    "D400",   # First line should end with period
    "D401",   # First line should be imperative mood
    "D415",   # First line should end with period/question/exclamation
]

[tool.ruff.lint.per-file-ignores]
"tests/*" = ["F401", "F811", "D"]  # Allow unused imports and missing docstrings in tests
"src/maxwell/cli.py" = ["T201"]  # Allow print in CLI (used for user output)
"src/maxwell/workflows/validate/validators/single_file/*.py" = ["T201", "TID252"]  # Allow prints, relative imports in validators
"src/maxwell/workflows/validate/validators/project_wide/*.py" = ["TID252", "F401"]  # Allow relative imports, unused imports in validators
"src/maxwell/workflows/**/*.py" = ["T201", "F821"]  # Allow prints, forward refs in workflows

[tool.pytest.ini_options]
minversion = "7.0"
testpaths = ["tests"]
python_files = ["test_*.py"]
python_classes = ["Test*"]
python_functions = ["test_*"]
addopts = [
    "-ra",
    "--strict-markers",
    "--strict-config",
    "--showlocals",
    "--ignore=tests/live/",  # Skip live integration tests by default (run explicitly with: pytest tests/live/)
]
filterwarnings = [
    "error",
    "ignore::DeprecationWarning",
    "ignore::PendingDeprecationWarning",
]

[tool.coverage.run]
source = ["maxwell"]
branch = true
omit = [
    "*/tests/*",
    "*/__pycache__/*",
    "*/site-packages/*",
]

[tool.coverage.report]
precision = 2
show_missing = true
skip_covered = false

[tool.setuptools.package-data]
maxwell = ["DEMON.txt"]

# Local vibelint config for analyzing vibelint itself
[tool.maxwell]
include_globs = [
    "**/*"
]
exclude_globs = [
    "**/__pycache__/**",
    "**/.*",           # dotfiles/directories (nested)
    ".*",              # dotfiles at root level
    "build/**",
    "dist/**",
    "*cache*/**",      # any cache directories
    "*.vibelint*",     # vibelint artifacts
    ".vibelint-*/**",  # old vibelint directories (deprecated)
    ".maxwell/**",     # maxwell analysis output
    "*.pyc", "*.pyo", "*.pyd",  # compiled python
    "*.log",            # log files
    "*.xml",            # xml files
    "*.json",           # json files
    "docs/**",
    "VIBECHECKER.txt"
]
# LLM config will be inherited from parent project

# Workflow-specific configurations
[tool.maxwell.workflows.justification]
# Configuration for justification workflow
max_file_size_lines = 2000  # Files larger than this get flagged for splitting
enable_llm_analysis = true
enable_static_analysis = true
enable_dependency_analysis = true
reports_directory = ".maxwell/reports/justification_workflow"

[tool.maxwell.workflows.cleanup]
# Configuration for cleanup workflow
aggressive_mode = false
backup_before_cleanup = true

# Third-party workflows can define their own config sections:
# [tool.maxwell.workflows.my-custom-workflow]
# custom_setting = "value"
# another_setting = 123

# Unified semantic index configuration (chat messages + filesystem)
[tool.maxwell.semantic_index]
# Auto-indexing: Silently index conversations when Maxwell runs
auto_index_enabled = true
auto_index_paths = [
    "~/.claude/projects",  # Active Claude Code conversations
]
auto_index_user = "mithranm"
auto_index_machine = "vanguard"
auto_index_batch_size = 50

# Database connections - unified storage for both chats and files
qdrant_host = "localhost"
qdrant_port = 6333
mongodb_uri = "mongodb://localhost:27017"
mongodb_db = "maxwell_index"

# Collections (namespaced by content type)
qdrant_collection_chat = "chat_messages"    # Chat analytics
qdrant_collection_files = "file_chunks"     # Filesystem indexing
mongodb_collection_chat = "messages"        # Chat messages
mongodb_collection_files = "files"          # File chunks and metadata

# Embedding service (shared by both)
embedding_url = "http://100.127.86.64:8001/v1/embeddings"
embedding_model = "Qwen/Qwen3-Embedding-4B"
embedding_dim = 2560

# Indexing settings
batch_size = 50
max_workers = 4


```

---
### File: src/maxwell/DEMON.txt

```
                @@@@                                                         @@@@                   
              @@@@@@                                                         @@@@@@                 
             @@@@@@@                                                         @@@@@@@                
            @@@@@@@@                                                         @@@@@@@@@              
           @@@@ @@@@@                                                        @@@@ @@@@@             
          @@@@   @@@@                                                       @@@@   @@@@@            
         @@@@@   @@@@@                                                     @@@@@    @@@@            
         @@@@     @@@@@               @@@@@@@@@@@@@@@@@@@@@               @@@@@     @@@@@           
        @@@@       @@@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@          @@@@@       @@@@           
        @@@@         @@@@@@    @@@@@@@@@@                @@@@@@@@@@   @@@@@@@        @@@@           
        @@@@          @@@@@@@@@@@@@@                          @@@@@@@@@@@@@          @@@@           
        @@@@            @@@@@@@@@                                @@@@@@@@            @@@@           
        @@@@               @@@                                     @@@               @@@@           
        @@@@@                                                                       @@@@@           
         @@@@@                                                                      @@@@            
          @@@@                                                                     @@@@@            
          @@@@@@                                                                  @@@@@             
            @@@@@                                                               @@@@@@              
             @@@@@@                                                           @@@@@@@               
              @@@@@@      @@@                                        @@@      @@@@@                 
               @@@@      @@@@@@                                    @@@@@      @@@@                  
              @@@@@      @@@@@@@@                               @@@@@@@@@      @@@@                 
              @@@@       @@@@@@@@@@@                         @@@@@@@@@@@@      @@@@                 
              @@@@       @@@@@@@@@@@@@@                    @@@@@@@@@@@@@@       @@@@                
             @@@@@        @@@@@@@@@@@@@@@@              @@@@@@@@@@@@@@@@        @@@@                
             @@@@          @@@@@@@@@@@@@@@@           @@@@@@@@@@@@@@@@@         @@@@                
             @@@@           @@@@@@@@@@@@@               @@@@@@@@@@@@@           @@@@                
             @@@@              @@@@@@@                     @@@@@@@              @@@@                
             @@@@@                                                              @@@@                
              @@@@                                                             @@@@@                
              @@@@         @                                         @@        @@@@                 
              @@@@@        @@@@@@                                @@@@@        @@@@@                 
               @@@@@        @@@@@      @                  @     @@@@@@        @@@@                  
                @@@@         @@@@@    @@@@@@@@@@@@@@@@@@@@@@    @@@@@        @@@@@                  
                @@@@@         @@@@   @@@@@@@@@@@@@@@@@@@@@@@   @@@@@        @@@@@                   
                 @@@@@         @@@@ @@@@@@@@@@@@@@@@@@@@@@@@@ @@@@@        @@@@@                    
                  @@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@                     
                    @@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@@                      
                     @@@@@@          @@@@@@@@@@@@@@@@@@@@@@@@          @@@@@                        
                       @@@@@@           @@@@@@@@@@@@@@@@@@           @@@@@@                         
                        @@@@@@@                                   @@@@@@@                           
                          @@@@@@@@                             @@@@@@@@                             
                             @@@@@@@@@                     @@@@@@@@@@                               
                                @@@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@                                  
                                    @@@@@@@@@@@@@@@@@@@@@@@@@@                                      
                                          @@@@@@@@@@@@@@                                      
```

---
### File: src/maxwell/__init__.py

```python
"""Maxwell: Code Quality and Style Validator

A focused code analysis tool for Python projects.
"""

from pathlib import Path

from maxwell.config import MaxwellConfig, load_config
from maxwell.lm_pool import LLMPool, get_lm
from maxwell.types import LLMSpec
from maxwell.utils import get_session_id, get_timestamp, normalize_path
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowMetrics,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

__version__ = "0.1.0"


# Lazy import for workflows to avoid circular dependencies
from maxwell.registry import register_workflow


def refactor_tags(project_root: str | Path | None = None, dry_run: bool = False) -> WorkflowResult:
    """Refactor semantic HTML tags in markdown files.

    Args:
        project_root: Directory to process (defaults to current directory)
        dry_run: If True, preview changes without modifying files

    Returns:
        WorkflowResult with refactoring statistics

    Example:
        >>> import maxwell
        >>> result = maxwell.refactor_tags(dry_run=True)
        >>> print(f"Would modify {len(result.artifacts['modified_files'])} files")

    """
    from pathlib import Path

    from maxwell.workflows.tag_refactor import run_tag_refactor

    path = Path(project_root) if project_root else Path.cwd()
    return run_tag_refactor(path, dry_run=dry_run)  # type: ignore[no-any-return]


__all__ = [
    # Configuration
    "MaxwellConfig",
    "load_config",
    # LM Pool
    "get_lm",
    "LLMPool",
    "LLMSpec",
    # Utilities
    "get_session_id",
    "get_timestamp",
    "normalize_path",
    # Workflows
    "refactor_tags",
]
```

---
### File: src/maxwell/__main__.py

```python
"""Main entry point for maxwell when run as a module.

Allows execution via: python -m maxwell

maxwell/src/maxwell/__main__.py
"""

from maxwell.cli import main

if __name__ == "__main__":
    main()
```

---
### File: src/maxwell/api.py

```python
"""Public API for executing Maxwell workflows programmatically.

Provides clean library interface for workflow execution without subprocess overhead.
"""

import json
import logging
from dataclasses import MISSING, asdict, dataclass, fields
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from maxwell.registry import workflow_registry
from maxwell.workflows.base import BaseWorkflow, WorkflowResult, WorkflowStatus

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

__all__ = [
    "WorkflowMetadata",
    "list_workflows",
    "get_workflow_info",
    "execute_workflow",
    "workflow_result_to_dict",
]


@dataclass
class WorkflowMetadata:
    """Metadata about an available workflow."""

    workflow_id: str
    name: str
    description: str
    version: str
    category: str
    tags: List[str]
    parameters: List[Dict[str, Any]]
    required_inputs: List[str]
    produced_outputs: List[str]

    @classmethod
    def from_workflow_class(cls, workflow_class: type[BaseWorkflow]) -> "WorkflowMetadata":
        """Initialize from workflow class."""
        # Create temporary instance to get metadata
        instance = workflow_class()

        return cls(
            workflow_id=instance.workflow_id,
            name=instance.name,
            description=instance.description,
            version=instance.version,
            category=instance.category,
            tags=list(instance.tags) if instance.tags else [],
            parameters=(
                instance.get_cli_parameters() if hasattr(instance, "get_cli_parameters") else []
            ),
            required_inputs=(
                [
                    f.name
                    for f in fields(instance.InputSchema)
                    if f.default is MISSING and f.default_factory is MISSING
                ]
                if instance.InputSchema
                else []
            ),
            produced_outputs=(
                [f.name for f in fields(instance.OutputSchema)] if instance.OutputSchema else []
            ),
        )


def list_workflows() -> List[WorkflowMetadata]:
    """List all available workflows with their metadata.

    Returns:
        List of WorkflowMetadata objects for all registered workflows

    """
    workflows = []
    for workflow_id, workflow_class in workflow_registry.get_all_workflows().items():
        try:
            metadata = WorkflowMetadata.from_workflow_class(workflow_class)
            workflows.append(metadata)
        except Exception as e:
            logger.warning(f"Failed to get metadata for workflow {workflow_id}: {e}")

    return workflows


def get_workflow_info(workflow_id: str) -> Optional[WorkflowMetadata]:
    """Get detailed information about a specific workflow.

    Args:
        workflow_id: ID of the workflow

    Returns:
        WorkflowMetadata if found, None otherwise

    """
    workflow_class = workflow_registry.get_workflow(workflow_id)
    if not workflow_class:
        return None

    try:
        return WorkflowMetadata.from_workflow_class(workflow_class)
    except Exception as e:
        logger.error(f"Failed to get metadata for workflow {workflow_id}: {e}")
        return None


def execute_workflow(
    workflow_id: str,
    project_root: Optional[Path] = None,
    context: Optional[Dict[str, Union[str, int, float, bool, List[Any], Dict[str, Any]]]] = None,
) -> WorkflowResult:
    """Execute a workflow by ID.

    Args:
        workflow_id: ID of the workflow to execute
        project_root: Project root directory (defaults to cwd)
        context: Execution context/parameters

    Returns:
        WorkflowResult with execution results

    Raises:
        ValueError: If workflow not found

    """
    # Get workflow class
    workflow_class = workflow_registry.get_workflow(workflow_id)
    if not workflow_class:
        available = workflow_registry.list_workflow_ids()
        raise ValueError(
            f"Workflow '{workflow_id}' not found. " f"Available workflows: {', '.join(available)}"
        )

    # Set defaults
    if project_root is None:
        project_root = Path.cwd()
    if context is None:
        context = {}

    # Execute workflow
    try:
        logger.info(f"Executing workflow: {workflow_id}")
        workflow = workflow_class()
        result = workflow.execute(project_root, context)
        logger.info(f"Workflow {workflow_id} completed with status: {result.status.value}")
        return result

    except Exception as e:
        logger.error(f"Workflow {workflow_id} failed: {e}", exc_info=True)
        from maxwell.workflows.base import WorkflowMetrics

        # Return failed result
        metrics = WorkflowMetrics(start_time=0.0, end_time=0.0, errors_encountered=1)
        metrics.finalize()

        return WorkflowResult(
            workflow_id=workflow_id,
            status=WorkflowStatus.FAILED,
            metrics=metrics,
            error_message=str(e),
        )


def workflow_result_to_dict(
    result: WorkflowResult,
) -> Dict[str, Union[str, int, float, bool, List[Any], Dict[str, Any]]]:
    """Convert WorkflowResult to JSON-serializable dictionary.

    Args:
        result: WorkflowResult to convert

    Returns:
        Dictionary representation

    """
    data = asdict(result)

    # Convert enums to strings
    if "status" in data:
        data["status"] = result.status.value

    # Convert any remaining non-serializable objects
    return json.loads(json.dumps(data, default=str))
```

---
### File: src/maxwell/cli.py

```python
"""Maxwell CLI - Dynamic workflow registry only.

This is a minimal CLI wrapper that sets up the workflow registry
and lets all workflows register themselves dynamically.
No hardcoded functionality - everything goes through the registry.
"""

import shutil
import sys
from importlib import resources
from pathlib import Path

from maxwell.api import list_workflows
from maxwell.registry import get_workflow_registry


def scale_ascii_art(
    art: str,
    target_width: int | None = None,
    target_height: int | None = None,
    reserved_lines: int = 10,
) -> str:
    """Scale ASCII art to fit terminal, leaving room for text output.

    Args:
        art: ASCII art string (can be multi-line)
        target_width: Target width in columns. If None, uses 80% of terminal width
        target_height: Target height in lines. If None, uses terminal height minus reserved_lines
        reserved_lines: Number of lines to reserve for text output (default: 10)

    Returns:
        Scaled ASCII art string

    """
    lines = art.splitlines()
    if not lines:
        return art

    # Get terminal dimensions
    terminal_size = shutil.get_terminal_size(fallback=(80, 24))

    # Find original dimensions
    original_width = max(len(line) for line in lines)
    original_height = len(lines)

    # Determine target dimensions
    if target_width is None:
        target_width = int(terminal_size.columns * 0.8)  # Use 80% of terminal width

    if target_height is None:
        target_height = max(5, terminal_size.lines - reserved_lines)  # Leave room for text

    # Calculate scale factors for width and height
    width_scale = target_width / original_width
    height_scale = target_height / original_height

    # Use the smaller scale to maintain aspect ratio and fit constraints
    scale = min(width_scale, height_scale)

    # Scale by skipping lines and characters
    scaled_lines = []
    for i, line in enumerate(lines):
        # Skip lines based on scale
        if i % max(1, int(1 / scale)) != 0:
            continue

        # Sample characters from line
        scaled_line = ""
        for j in range(len(line)):
            if j % max(1, int(1 / scale)) == 0:
                scaled_line += line[j]

        scaled_lines.append(scaled_line)

    return "\n".join(scaled_lines)


def print_demon(additional_text: str = "") -> None:
    """Print the Maxwell demon ASCII art scaled to fit terminal, with readable text below.

    Args:
        additional_text: Text to append below the ASCII art (unscaled, stays readable)

    """
    try:
        # Load DEMON.txt from package resources
        demon_art = resources.read_text("maxwell", "DEMON.txt")

        # Count lines needed for text output
        text_lines = additional_text.count("\n") + 1 if additional_text else 0

        # Scale ASCII art, reserving vertical space for text
        scaled_art = scale_ascii_art(demon_art, reserved_lines=text_lines + 2)

        # Print scaled art, then unscaled text
        print(scaled_art)
        if additional_text:
            print(additional_text)
    except Exception:
        # Silently fail if ASCII art not found
        pass


def main() -> int:
    """Main CLI entry point - workflow registry only."""
    try:
        # Get workflow registry (auto-discovers workflows)
        registry = get_workflow_registry()

        # Get available workflows
        available_workflows = registry.list_workflow_ids()

        # Handle CLI arguments
        if len(sys.argv) < 2:
            # Print demon banner with help text
            help_text = (
                "\nMaxwell - Semantic search and workflow automation\n\n"
                "Usage: maxwell <workflow-id> [options]\n"
                "       maxwell list-workflows\n"
            )
            print_demon(help_text)
            for workflow_id in available_workflows:
                workflow_class = registry.get_workflow(workflow_id)
                if workflow_class:
                    workflow = workflow_class()
            return 0

        workflow_id = sys.argv[1]

        # Handle special commands
        if workflow_id == "list-workflows":
            workflows = list_workflows()
            print("\nAvailable Maxwell workflows:\n")
            for w in workflows:
                print(f"  {w.workflow_id:<30} {w.name:<30} ({w.category})")
                if w.description:
                    print(f"    {w.description}")
            return 0

        # Check if workflow exists
        if workflow_id not in available_workflows:
            print(f"Unknown workflow: {workflow_id}")
            print("Use 'list-workflows' to see available workflows")
            return 1

        # Execute workflow with remaining arguments
        workflow_class = registry.get_workflow(workflow_id)
        if not workflow_class:
            return 1

        workflow = workflow_class()
        project_root = Path.cwd()

        # Parse workflow-specific arguments using argparse
        import argparse

        parser = argparse.ArgumentParser(
            prog=f"maxwell {workflow_id}", description=workflow.description
        )

        # Add workflow parameters
        for param in workflow.get_cli_parameters():
            name = param["name"]

            if "type" in param:
                param_type = param["type"]
            else:
                param_type = str

            if "required" in param:
                required = param["required"]
            else:
                required = False

            if "default" in param:
                default = param["default"]
            else:
                default = None

            if "help" in param:
                help_text = param["help"]
            else:
                help_text = ""

            if required and default is None:
                parser.add_argument(f"--{name}", type=param_type, required=required, help=help_text)
            else:
                parser.add_argument(f"--{name}", type=param_type, default=default, help=help_text)

        # Parse arguments
        args = vars(parser.parse_args(sys.argv[2:]))

        # Execute the workflow
        result = workflow.execute(project_root, args)

        # Handle result
        from maxwell.workflows.base import WorkflowStatus

        if result.status == WorkflowStatus.COMPLETED:
            if result.artifacts and "report" in result.artifacts:
                pass
            else:
                if result.artifacts:
                    pass
            return 0
        else:
            return 1

    except KeyboardInterrupt:
        return 130
    except Exception as e:
        return 1


if __name__ == "__main__":
    sys.exit(main())
```

---
### File: src/maxwell/config.py

```python
"""Configuration loading for maxwell.

Reads settings *only* from pyproject.toml under the [tool.maxwell] section.
No default values are assumed by this module. Callers must handle missing
configuration keys.

maxwell/src/maxwell/config.py
"""

import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.filesystem import find_package_root, walk_up_for_config

# === TYPE-SAFE CONFIGURATION MODELS ===


@dataclass
class FilePatternsConfig:
    """Configuration for file patterns."""

    include_globs: List[str] = field(default_factory=list)
    exclude_globs: List[str] = field(default_factory=list)
    max_file_size_mb: Optional[int] = None
    follow_symlinks: bool = False


@dataclass
class EmbeddingModelConfig:
    """Configuration for a specific embedding model."""

    api_url: str
    model: str
    timeout: int = 30
    max_retries: int = 3
    batch_size: int = 100


@dataclass
class EmbeddingConfig:
    """Complete embedding configuration."""

    code: EmbeddingModelConfig
    natural: EmbeddingModelConfig
    use_specialized: bool = True
    cache_embeddings: bool = True


@dataclass
class VectorStoreConfig:
    """Vector store configuration."""

    backend: str = "qdrant"
    collection_name: str = "maxwell_embeddings"
    host: str = "localhost"
    port: int = 6333
    timeout: int = 30
    recreate_collection: bool = False


@dataclass
class ValidationConfig:
    """Validation engine configuration."""

    enabled: bool = True
    strict_mode: bool = False
    fail_fast: bool = True
    max_displayed_issues: int = 50
    auto_fix: bool = False


@dataclass
class ToolConfig:
    """Individual tool configuration."""

    enabled: bool = True
    timeout_seconds: Optional[int] = None
    max_retries: int = 0
    cache_results: bool = True
    custom_settings: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MaxwellConfig:
    """Complete Maxwell configuration."""

    # Core paths and patterns
    file_patterns: FilePatternsConfig = field(default_factory=FilePatternsConfig)

    # Service configurations with defaults
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)

    # Workflow configurations
    validation: ValidationConfig = field(default_factory=ValidationConfig)

    # Tool configurations
    tools: Dict[str, ToolConfig] = field(default_factory=dict)

    # Development settings
    debug: bool = False
    log_level: str = "INFO"

    # Legacy embedding config (deprecated - use lm_pool instead)
    embeddings: Optional[EmbeddingConfig] = None


# === CONVERSION FUNCTIONS (JSON parsing only) ===


def from_json_dict(data: Dict[str, Any]) -> MaxwellConfig:
    """Convert parsed JSON dict to type-safe MaxwellConfig.

    Uses dataclass defaults instead of dict.get() fallbacks.
    """
    # Extract embeddings (legacy - optional)
    embedding_config: Optional[EmbeddingConfig] = None
    if "embeddings" in data:
        embedding_data = data["embeddings"]
        if "code_api_url" in embedding_data and "natural_api_url" in embedding_data:
            # Build code model config with explicit checks
            code_kwargs: Dict[str, Any] = {"api_url": embedding_data["code_api_url"]}
            if "code_model" in embedding_data:
                code_kwargs["model"] = embedding_data["code_model"]
            else:
                code_kwargs["model"] = "text-embedding-ada-002"

            code_model = EmbeddingModelConfig(**code_kwargs)

            # Build natural model config with explicit checks
            natural_kwargs: Dict[str, Any] = {"api_url": embedding_data["natural_api_url"]}
            if "natural_model" in embedding_data:
                natural_kwargs["model"] = embedding_data["natural_model"]
            else:
                natural_kwargs["model"] = "text-embedding-ada-002"

            natural_model = EmbeddingModelConfig(**natural_kwargs)

            # Build embedding config
            embedding_kwargs: Dict[str, Any] = {
                "code": code_model,
                "natural": natural_model,
            }
            if "use_specialized_embeddings" in embedding_data:
                embedding_kwargs["use_specialized"] = embedding_data["use_specialized_embeddings"]

            embedding_config = EmbeddingConfig(**embedding_kwargs)

    # Extract vector store config (use dataclass defaults)
    vector_config = VectorStoreConfig()
    if "vector_store" in data:
        vector_data = data["vector_store"]
        vector_kwargs: Dict[str, Any] = {}

        if "backend" in vector_data:
            vector_kwargs["backend"] = vector_data["backend"]
        if "qdrant_collection" in vector_data:
            vector_kwargs["collection_name"] = vector_data["qdrant_collection"]
        if "host" in vector_data:
            vector_kwargs["host"] = vector_data["host"]
        if "port" in vector_data:
            vector_kwargs["port"] = vector_data["port"]

        vector_config = VectorStoreConfig(**vector_kwargs)

    # Extract validation config (use dataclass defaults)
    validation_config = ValidationConfig()
    if "validation" in data:
        validation_data = data["validation"]
        validation_kwargs: Dict[str, Any] = {}

        if "enabled" in validation_data:
            validation_kwargs["enabled"] = validation_data["enabled"]
        if "strict_mode" in validation_data:
            validation_kwargs["strict_mode"] = validation_data["strict_mode"]
        if "fail_fast" in validation_data:
            validation_kwargs["fail_fast"] = validation_data["fail_fast"]
        if "max_displayed_issues" in validation_data:
            validation_kwargs["max_displayed_issues"] = validation_data["max_displayed_issues"]

        validation_config = ValidationConfig(**validation_kwargs)

    # Extract file patterns
    file_kwargs: Dict[str, Any] = {}
    if "include_globs" in data:
        file_kwargs["include_globs"] = data["include_globs"]
    if "exclude_globs" in data:
        file_kwargs["exclude_globs"] = data["exclude_globs"]

    file_config = FilePatternsConfig(**file_kwargs)

    # Extract tools
    tools_config: Dict[str, ToolConfig] = {}
    if "tool" in data:
        tools_data = data["tool"]
        for name, config_data in tools_data.items():
            tool_kwargs: Dict[str, Any] = {}

            if "enabled" in config_data:
                tool_kwargs["enabled"] = config_data["enabled"]
            if "timeout_seconds" in config_data:
                tool_kwargs["timeout_seconds"] = config_data["timeout_seconds"]
            if "max_retries" in config_data:
                tool_kwargs["max_retries"] = config_data["max_retries"]

            tools_config[name] = ToolConfig(**tool_kwargs)

    return MaxwellConfig(
        file_patterns=file_config,
        embeddings=embedding_config,
        vector_store=vector_config,
        validation=validation_config,
        tools=tools_config,
    )


def to_json_dict(config: MaxwellConfig) -> Dict[str, Any]:
    """Convert type-safe MaxwellConfig to JSON dict (for serialization)."""
    result: Dict[str, Any] = {
        "vector_store": {
            "backend": config.vector_store.backend,
            "qdrant_collection": config.vector_store.collection_name,
            "host": config.vector_store.host,
            "port": config.vector_store.port,
        },
        "validation": {
            "enabled": config.validation.enabled,
            "strict_mode": config.validation.strict_mode,
            "fail_fast": config.validation.fail_fast,
            "max_displayed_issues": config.validation.max_displayed_issues,
        },
        "include_globs": config.file_patterns.include_globs,
        "exclude_globs": config.file_patterns.exclude_globs,
        "tool": {
            name: {
                "enabled": tool_config.enabled,
                "timeout_seconds": tool_config.timeout_seconds,
                "max_retries": tool_config.max_retries,
            }
            for name, tool_config in config.tools.items()
        },
    }

    # Legacy embeddings (deprecated - use lm_pool instead)
    if config.embeddings:
        result["embeddings"] = {
            "code_api_url": config.embeddings.code.api_url,
            "natural_api_url": config.embeddings.natural.api_url,
            "code_model": config.embeddings.code.model,
            "natural_model": config.embeddings.natural.model,
            "use_specialized_embeddings": config.embeddings.use_specialized,
        }

    return result


logger = logging.getLogger(__name__)


def _find_config_file(project_root: Path) -> Path | None:
    """Find the config file (pyproject.toml or dev.pyproject.toml) with maxwell settings."""
    # Check standard pyproject.toml first
    pyproject_path = project_root / "pyproject.toml"
    if pyproject_path.exists():
        try:
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
                if "tool" in data and "maxwell" in data["tool"]:
                    return pyproject_path
        except Exception:
            pass

    # Check dev.pyproject.toml (kaia pattern)
    dev_pyproject_path = project_root / "dev.pyproject.toml"
    if dev_pyproject_path.exists():
        try:
            with open(dev_pyproject_path, "rb") as f:
                data = tomllib.load(f)
                if "tool" in data and "maxwell" in data["tool"]:
                    return dev_pyproject_path
        except Exception:
            pass

    return None


def _load_parent_config(project_root: Path, current_config_path: Path) -> dict | None:
    """Load parent configuration for inheritance."""
    # Walk up from the project root to find parent configurations
    parent_path = project_root.parent

    while parent_path != parent_path.parent:  # Stop at filesystem root
        # Check for dev.pyproject.toml (kaia pattern)
        dev_config = parent_path / "dev.pyproject.toml"
        if dev_config.exists() and dev_config != current_config_path:
            try:
                with open(dev_config, "rb") as f:
                    data = tomllib.load(f)
                    if "tool" in data and "maxwell" in data["tool"]:
                        maxwell_config = data["tool"]["maxwell"]
                        logger.debug(f"Found parent config in {dev_config}")
                        return maxwell_config
            except Exception:
                pass

        # Check for regular pyproject.toml
        parent_config = parent_path / "pyproject.toml"
        if parent_config.exists() and parent_config != current_config_path:
            try:
                with open(parent_config, "rb") as f:
                    data = tomllib.load(f)
                    if "tool" in data and "maxwell" in data["tool"]:
                        maxwell_config = data["tool"]["maxwell"]
                        logger.debug(f"Found parent config in {parent_config}")
                        return maxwell_config
            except Exception:
                pass

        parent_path = parent_path.parent

    return None


if sys.version_info >= (3, 11):

    import tomllib
else:

    try:

        import tomli as tomllib
    except ImportError as e:

        raise ImportError(
            "maxwell requires Python 3.11+ or the 'tomli' package "
            "to parse pyproject.toml on Python 3.10. "
            "Hint: Try running: pip install tomli"
        ) from e


@dataclass
class ProjectConfig:
    """Legacy wrapper for backwards compatibility."""

    project_root: Optional[Path]
    config: MaxwellConfig


def load_hierarchical_config(start_path: Path) -> MaxwellConfig:
    """Loads maxwell configuration with hierarchical merging.

    1. Loads local config (file patterns, local settings)
    2. Walks up to find parent config (LLM settings, shared config)
    3. Merges them: local config takes precedence for file patterns,
       parent config provides LLM settings

    Args:
    start_path: The directory to start searching from.

    Returns:
    A Config object with merged local and parent settings.

    """
    # Find local config first
    local_root = find_package_root(start_path)
    local_settings = {}
    dev_override_settings = {}

    if local_root:
        pyproject_path = local_root / "pyproject.toml"
        if pyproject_path.exists():
            try:
                with open(pyproject_path, "rb") as f:
                    data = tomllib.load(f)
                    if "tool" in data and "maxwell" in data["tool"]:
                        local_settings = data["tool"]["maxwell"]
                        logger.info(f"Loaded local maxwell config from {pyproject_path}")
            except Exception as e:
                logger.warning(f"Failed to load local config from {pyproject_path}: {e}")

        # Check for dev.pyproject.toml override in same directory
        dev_pyproject_path = local_root / "dev.pyproject.toml"
        if dev_pyproject_path.exists():
            try:
                with open(dev_pyproject_path, "rb") as f:
                    data = tomllib.load(f)
                    if "tool" in data and "maxwell" in data["tool"]:
                        dev_override_settings = data["tool"]["maxwell"]
                        logger.info(f"Loaded dev override config from {dev_pyproject_path}")
            except Exception as e:
                logger.warning(f"Failed to load dev override from {dev_pyproject_path}: {e}")

    # Walk up to find parent config with LLM settings
    parent_settings = {}
    current_path = start_path.parent if start_path.is_file() else start_path

    while current_path.parent != current_path:
        parent_pyproject = current_path / "pyproject.toml"
        if parent_pyproject.exists() and parent_pyproject != (
            local_root / "pyproject.toml" if local_root else None
        ):
            try:
                with open(parent_pyproject, "rb") as f:
                    data = tomllib.load(f)
                    if "tool" in data and "maxwell" in data["tool"]:
                        parent_settings = data["tool"]["maxwell"]
                        logger.info(f"Found parent maxwell config at {parent_pyproject}")
                        break
            except Exception as e:
                logger.debug(f"Failed to read {parent_pyproject}: {e}")
        current_path = current_path.parent

    # Merge configs in order: parent -> local -> dev_override
    # This allows: parent provides base (e.g., LLM endpoints for team)
    #              local overrides file patterns for project
    #              dev overrides everything for local development
    merged_settings = parent_settings.copy()

    # Local config takes precedence for file discovery patterns
    if local_settings:
        for key in ["include_globs", "exclude_globs", "ignore"]:
            if key in local_settings:
                merged_settings[key] = local_settings[key]

        # Also copy other local-specific settings
        for key in local_settings:
            if key not in ["include_globs", "exclude_globs", "ignore"]:
                merged_settings[key] = local_settings[key]

    # Dev override takes highest precedence (for local development overrides)
    if dev_override_settings:

        def deep_merge(base: dict, override: dict) -> dict:
            """Deep merge override into base."""
            result = base.copy()
            for key, value in override.items():
                if isinstance(value, dict) and key in result and isinstance(result[key], dict):
                    result[key] = deep_merge(result[key], value)
                else:
                    result[key] = value
            return result

        merged_settings = deep_merge(merged_settings, dev_override_settings)

    return from_json_dict(merged_settings)


def load_config(start_path: Path) -> MaxwellConfig:
    """Loads maxwell configuration with auto-discovery fallback.

    First tries manual config from pyproject.toml, then falls back to
    zero-config auto-discovery for seamless single->multi-project scaling.

    Args:
    start_path: The directory to start searching upwards for pyproject.toml.

    Returns:
    A MaxwellConfig object with either manual or auto-discovered settings.

    maxwell/src/maxwell/config.py

    """
    project_root = walk_up_for_config(start_path)
    loaded_settings: dict[str, Any] = {}

    # Try auto-discovery first for zero-config scaling
    try:
        from maxwell.auto_discovery import discover_and_configure  # type: ignore

        auto_config = discover_and_configure(start_path)

        # If we found a multi-project setup, use auto-discovery by default
        if "discovered_topology" in auto_config and auto_config["discovered_topology"] == "multi_project":
            logger.info(f"Auto-discovered multi-project setup from {start_path}")
            # Convert auto-discovered config to maxwell config format
            loaded_settings = _convert_auto_config_to_maxwell(auto_config)
            project_root = project_root or start_path

            # Still allow manual config to override auto-discovery
            manual_override = _load_manual_config(project_root)
            if manual_override:
                logger.debug("Manual config found, merging with auto-discovery")
                loaded_settings.update(manual_override)

            return from_json_dict(loaded_settings)

    except ImportError:
        logger.debug("Auto-discovery not available, using manual config only")
    except Exception as e:
        logger.debug(f"Auto-discovery failed: {e}, falling back to manual config")

    if not project_root:
        logger.warning(
            f"Could not find project root (pyproject.toml) searching from '{start_path}'. "
            "No configuration will be loaded."
        )
        return from_json_dict(loaded_settings)

    # Try both pyproject.toml and dev.pyproject.toml
    pyproject_path = _find_config_file(project_root)
    logger.debug(f"Found project root: {project_root}")

    if not pyproject_path:
        logger.debug(f"No maxwell configuration found in {project_root}")
        return from_json_dict({})

    logger.debug(f"Attempting to load config from: {pyproject_path}")

    try:
        with open(pyproject_path, "rb") as f:
            full_toml_config = tomllib.load(f)
        logger.debug(f"Parsed {pyproject_path.name}")

        # Validate required configuration structure explicitly
        if "tool" not in full_toml_config or not isinstance(full_toml_config["tool"], dict):
            logger.warning("pyproject.toml [tool] section is missing or invalid")
            maxwell_config = {}
        else:
            tool_section = full_toml_config["tool"]
            if "maxwell" in tool_section:
                maxwell_config = tool_section["maxwell"]
            else:
                maxwell_config = {}

        if isinstance(maxwell_config, dict):
            loaded_settings = maxwell_config
            # Check for parent config inheritance
            parent_config = _load_parent_config(project_root, pyproject_path)
            if parent_config:
                # Merge parent config with local config (local takes precedence)
                merged_settings = parent_config.copy()
                merged_settings.update(loaded_settings)
                loaded_settings = merged_settings
                logger.debug("Merged parent configuration")

            if loaded_settings:
                logger.debug(f"Loaded [tool.maxwell] settings from {pyproject_path}")
                logger.debug(f"Loaded settings: {loaded_settings}")
            else:
                logger.info(
                    f"Found {pyproject_path}, but the [tool.maxwell] section is empty or missing."
                )
        else:
            logger.warning(
                f"[tool.maxwell] section in {pyproject_path} is not a valid table (dictionary). "
                "Ignoring this section."
            )

    except FileNotFoundError:

        logger.error(
            f"pyproject.toml not found at {pyproject_path} despite project root detection."
        )
    except tomllib.TOMLDecodeError as e:
        logger.error(f"Error parsing {pyproject_path}: {e}. Using empty configuration.")
    except OSError as e:
        logger.error(f"Error reading {pyproject_path}: {e}. Using empty configuration.")
    except (KeyError, TypeError, ValueError) as e:
        logger.error(f"Error processing configuration from {pyproject_path}: {e}")
        logger.debug("Unexpected error loading config", exc_info=True)

    return from_json_dict(loaded_settings)


def _convert_auto_config_to_maxwell(auto_config: dict[str, Any]) -> dict[str, Any]:
    """Convert auto-discovered config to maxwell config format."""
    maxwell_config: dict[str, Any] = {}

    # Auto-route validation based on discovered services
    services = auto_config["services"] if "services" in auto_config else {}
    routing = auto_config["auto_routing"] if "auto_routing" in auto_config else {}

    # Set include globs based on discovered projects
    include_globs = []
    for service_info in services.values():
        service_path = Path(service_info["path"])
        include_globs.extend([f"{service_path.name}/src/**/*.py", f"{service_path.name}/**/*.py"])

    maxwell_config["include_globs"] = include_globs

    # Configure distributed services if available
    if "discovered_topology" in auto_config and auto_config["discovered_topology"] == "multi_project":
        maxwell_config["distributed"] = {
            "enabled": True,
            "auto_discovered": True,
            "services": services,
            "routing": routing,
        }

        # Use shared resources if discovered
        if "shared_resources" in auto_config:
            shared_resources = auto_config["shared_resources"]
            if "vector_stores" in shared_resources and shared_resources["vector_stores"]:
                maxwell_config["vector_store"] = {
                    "backend": "qdrant",
                    "qdrant_collection": shared_resources["vector_stores"][0],
                }

    return maxwell_config


def _load_manual_config(project_root: Path | None) -> dict[str, Any]:
    """Load manual configuration from pyproject.toml."""
    if not project_root:
        return {}

    pyproject_path = project_root / "pyproject.toml"
    logger.debug(f"Attempting to load manual config from: {pyproject_path}")

    try:
        with open(pyproject_path, "rb") as f:
            full_toml_config = tomllib.load(f)
        logger.debug("Parsed pyproject.toml")

        # Validate required configuration structure explicitly
        if "tool" not in full_toml_config or not isinstance(full_toml_config["tool"], dict):
            logger.warning("pyproject.toml [tool] section is missing or invalid")
            return {}

        tool_section = full_toml_config["tool"]
        if "maxwell" in tool_section:
            maxwell_config = tool_section["maxwell"]
        else:
            maxwell_config = {}

        if isinstance(maxwell_config, dict):
            if maxwell_config:
                logger.debug(f"Loaded manual [tool.maxwell] settings from {pyproject_path}")
                return maxwell_config
            else:
                logger.debug(f"Found {pyproject_path}, but [tool.maxwell] section is empty")
                return {}
        else:
            logger.warning(
                f"[tool.maxwell] section in {pyproject_path} is not a valid table. Ignoring."
            )
            return {}

    except FileNotFoundError:
        logger.debug(f"No pyproject.toml found at {pyproject_path}")
        return {}
    except tomllib.TOMLDecodeError as e:
        logger.error(f"Error parsing {pyproject_path}: {e}")
        return {}
    except OSError as e:
        logger.error(f"Error reading {pyproject_path}: {e}")
        return {}
    except Exception as e:
        logger.error(f"Unexpected error loading manual config: {e}")
        return {}


__all__ = [
    "MaxwellConfig",
    "ProjectConfig",  # Legacy wrapper
    "load_config",
    "load_hierarchical_config",
    "from_json_dict",
    "to_json_dict",
    # Dataclass types
    "FilePatternsConfig",
    "EmbeddingModelConfig",
    "EmbeddingConfig",
    "VectorStoreConfig",
    "ValidationConfig",
    "ToolConfig",
]
```

---
### File: src/maxwell/discovery.py

```python
"""Discovers files using pathlib glob/rglob based on include patterns from
pyproject.toml, respecting the pattern's implied scope, then filters
using exclude patterns.

If `include_globs` is missing from the configuration:
- If `default_includes_if_missing` is provided, uses those patterns and logs a warning.
- Otherwise, logs an error and returns an empty list.

Exclusions from `config.exclude_globs` are always applied. Explicitly
provided paths are also excluded.

Warns if files within common VCS directories (.git, .hg, .svn) are found
and not covered by exclude_globs.

maxwell/src/maxwell/discovery.py
"""

import fnmatch
import logging
import os
import time
from collections.abc import Iterator
from pathlib import Path

from maxwell.config import MaxwellConfig
from maxwell.filesystem import get_relative_path

__all__ = ["discover_files", "discover_files_from_paths"]
logger = logging.getLogger(__name__)

_VCS_DIRS = {".git", ".hg", ".svn"}

# Default exclude patterns to avoid __pycache__, .git, etc. when using custom paths
_DEFAULT_EXCLUDE_PATTERNS = [
    "__pycache__/**",
    "*.pyc",
    "*.pyo",
    ".git/**",
    ".hg/**",
    ".svn/**",
    ".pytest_cache/**",
    ".coverage",
    ".mypy_cache/**",
    ".tox/**",
    "venv/**",
    ".venv/**",
    "env/**",
    ".env/**",
    "node_modules/**",
    ".DS_Store",
    "*.egg-info/**",
]


def _is_excluded(
    path_abs: Path,
    project_root: Path,
    exclude_globs: list[str],
    explicit_exclude_paths: set[Path],
    is_checking_directory_for_prune: bool = False,
) -> bool:
    """Checks if a discovered path (file or directory) should be excluded.

    For files: checks explicit paths first, then exclude globs.
    For directories (for pruning): checks if the directory itself matches an exclude glob.

    Args:
    path_abs: The absolute path of the file or directory to check.
    project_root: The absolute path of the project root.
    exclude_globs: List of glob patterns for exclusion from config.
    explicit_exclude_paths: Set of absolute paths to exclude explicitly (applies to files).
    is_checking_directory_for_prune: True if checking a directory for os.walk pruning.

    Returns:
    True if the path should be excluded/pruned, False otherwise.

    maxwell/src/maxwell/discovery.py

    """
    if not is_checking_directory_for_prune and path_abs in explicit_exclude_paths:
        logger.debug(f"Excluding explicitly provided path: {path_abs}")
        return True

    try:
        # Use resolve() for consistent comparison base
        rel_path = path_abs.resolve().relative_to(project_root.resolve())
        # Normalize for fnmatch and consistent comparisons
        rel_path_str = str(rel_path).replace("\\", "/")
    except ValueError:
        # Path is outside project root, consider it excluded for safety
        logger.warning(f"Path {path_abs} is outside project root {project_root}. Excluding.")
        return True
    except (OSError, TypeError) as e:
        logger.error(f"Error getting relative path for exclusion check on {path_abs}: {e}")
        return True  # Exclude if relative path fails

    for pattern in exclude_globs:
        normalized_pattern = pattern.replace("\\", "/")

        if is_checking_directory_for_prune:
            # Logic for pruning directories:
            # 1. Exact match: pattern "foo", rel_path_str "foo" (dir name)
            if fnmatch.fnmatch(rel_path_str, normalized_pattern):
                logger.debug(
                    f"Pruning dir '{rel_path_str}' due to direct match with exclude pattern '{pattern}'"
                )
                return True
            # 2. Dir pattern like "foo/" or "foo/**":
            #    pattern "build/", rel_path_str "build" -> match
            #    pattern "build/**", rel_path_str "build" -> match
            if normalized_pattern.endswith("/"):
                if rel_path_str == normalized_pattern[:-1]:  # pattern "build/", rel_path "build"
                    logger.debug(
                        f"Pruning dir '{rel_path_str}' due to match with dir pattern '{pattern}'"
                    )
                    return True
            elif normalized_pattern.endswith("/**"):
                if (
                    rel_path_str == normalized_pattern[:-3]
                ):  # e.g. pattern 'dir/**', rel_path_str 'dir'
                    logger.debug(
                        f"Pruning dir '{rel_path_str}' due to match with dir/** pattern '{pattern}'"
                    )
                    return True
        else:
            # Logic for excluding files:
            # Rule 1: File path matches the glob pattern directly
            # This handles patterns like "*.pyc", "temp/*", "specific_file.txt"
            if fnmatch.fnmatch(rel_path_str, normalized_pattern):
                logger.debug(f"Excluding file '{rel_path_str}' due to exclude pattern '{pattern}'")
                return True

            # Rule 2: File is within a directory excluded by a pattern ending with '/' or '/**'
            # e.g., exclude_glob is "build/", file is "build/lib/module.py"
            # e.g., exclude_glob is "output/**", file is "output/data/log.txt"
            if normalized_pattern.endswith("/"):  # Pattern "build/"
                if rel_path_str.startswith(normalized_pattern):
                    logger.debug(
                        f"Excluding file '{rel_path_str}' because it's in excluded dir prefix '{normalized_pattern}'"
                    )
                    return True
            elif normalized_pattern.endswith("/**"):  # Pattern "build/**"
                # For "build/**", we want to match files starting with "build/"
                base_dir_pattern = normalized_pattern[:-2]  # Results in "build/"
                if rel_path_str.startswith(base_dir_pattern):
                    logger.debug(
                        f"Excluding file '{rel_path_str}' because it's in excluded dir prefix '{normalized_pattern}'"
                    )
                    return True
            # Note: A simple exclude pattern like "build" (without / or **) for files
            # will only match a file *named* "build" via the fnmatch rule above.
            # To exclude all contents of a directory "build", the pattern should be
            # "build/" or "build/**". The pruning logic for directories handles these
            # patterns effectively for `os.walk`.

    return False


def _recursive_glob_with_pruning(
    search_root_abs: Path,
    glob_suffix_pattern: str,  # e.g., "*.py" or "data/*.json"
    project_root: Path,
    config_exclude_globs: list[str],
    explicit_exclude_paths: set[Path],
) -> Iterator[Path]:
    """Recursively walks a directory, prunes excluded subdirectories, and yields files
    matching the glob_suffix_pattern that are not otherwise excluded.

    Args:
        search_root_abs: Absolute path to the directory to start the search from.
        glob_suffix_pattern: The glob pattern to match files against (relative to directories in the walk).
        project_root: Absolute path of the project root.
        config_exclude_globs: List of exclude glob patterns from config.
        explicit_exclude_paths: Set of absolute file paths to explicitly exclude.

    Yields:
        Absolute Path objects for matching files.

    """
    logger.debug(
        f"Recursive walk starting at '{search_root_abs}' for pattern '.../{glob_suffix_pattern}'"
    )
    for root_str, dir_names, file_names in os.walk(str(search_root_abs), topdown=True):
        current_dir_abs = Path(root_str)

        # Prune directories
        original_dir_count = len(dir_names)
        dir_names[:] = [
            d_name
            for d_name in dir_names
            if not _is_excluded(
                current_dir_abs / d_name,
                project_root,
                config_exclude_globs,
                explicit_exclude_paths,  # Not used for dir pruning but passed for func signature
                is_checking_directory_for_prune=True,
            )
        ]
        if len(dir_names) < original_dir_count:
            logger.debug(
                f"Pruned {original_dir_count - len(dir_names)} subdirectories under {current_dir_abs}"
            )

        # Match files in the current (potentially non-pruned) directory
        for f_name in file_names:
            file_abs = current_dir_abs / f_name

            # Path of file relative to where the glob_suffix_pattern matching should start (search_root_abs)
            try:
                rel_to_search_root = file_abs.relative_to(search_root_abs)
            except ValueError:
                # Should not happen if os.walk starts at search_root_abs and yields descendants
                logger.warning(
                    f"File {file_abs} unexpectedly not relative to search root {search_root_abs}. Skipping."
                )
                continue

            normalized_rel_to_search_root_str = str(rel_to_search_root).replace("\\", "/")

            if fnmatch.fnmatch(normalized_rel_to_search_root_str, glob_suffix_pattern):
                # File matches the include pattern's suffix.
                # Now, perform a final check against global exclude rules for this specific file.
                if not _is_excluded(
                    file_abs,
                    project_root,
                    config_exclude_globs,
                    explicit_exclude_paths,
                    is_checking_directory_for_prune=False,
                ):
                    yield file_abs.resolve()  # Yield resolved path


def discover_files(
    paths: list[Path],
    config: MaxwellConfig,
    default_includes_if_missing: list[str] | None = None,
    explicit_exclude_paths: set[Path] | None = None,
) -> list[Path]:
    """Discovers files based on include/exclude patterns from configuration.
    Uses a custom walker for recursive globs (**) to enable directory pruning.

    Args:
    paths: Initial paths (largely ignored, globs operate from project root).
    config: The maxwell configuration object (must have project_root set).
    default_includes_if_missing: Fallback include patterns if 'include_globs' is not in config.
    explicit_exclude_paths: A set of absolute file paths to explicitly exclude.

    Returns:
    A sorted list of unique absolute Path objects for the discovered files.

    Raises:
    ValueError: If config.project_root is None.

    """
    # Note: MaxwellConfig doesn't have project_root - this function needs to be called with a separate project_root parameter
    # For now, use current directory as fallback
    project_root = Path.cwd().resolve()
    candidate_files: set[Path] = set()
    _explicit_excludes = {p.resolve() for p in (explicit_exclude_paths or set())}

    # Validate and process include_globs configuration
    include_globs_config = config.file_patterns.include_globs
    include_globs_effective = []

    if include_globs_config is None:
        if default_includes_if_missing is not None:
            logger.warning(
                "Configuration key 'include_globs' missing in [tool.maxwell] section "
                f"of pyproject.toml. Using default patterns: {default_includes_if_missing}"
            )
            include_globs_effective = default_includes_if_missing
        else:
            logger.error(
                "Configuration key 'include_globs' missing. No include patterns specified."
            )
    elif not isinstance(include_globs_config, list):
        logger.error(
            f"Config error: 'include_globs' must be a list. Found {type(include_globs_config)}."
        )
    elif not include_globs_config:
        logger.warning("Config: 'include_globs' is empty. No files will be included.")
    else:
        include_globs_effective = include_globs_config

    # Early return if no valid include patterns
    if not include_globs_effective:
        return []

    normalized_includes = [p.replace("\\", "/") for p in include_globs_effective]

    exclude_globs_config = config.file_patterns.exclude_globs
    if not isinstance(exclude_globs_config, list):
        logger.error(
            f"Config error: 'exclude_globs' must be a list. Found {type(exclude_globs_config)}. Ignoring."
        )
        exclude_globs_effective = []
    else:
        exclude_globs_effective = exclude_globs_config
    normalized_exclude_globs = [p.replace("\\", "/") for p in exclude_globs_effective]

    logger.debug(f"Starting file discovery from project root: {project_root}")
    logger.debug(f"Effective Include globs: {normalized_includes}")
    logger.debug(f"Exclude globs: {normalized_exclude_globs}")
    logger.debug(f"Explicit excludes: {_explicit_excludes}")

    start_time = time.time()

    for pattern in normalized_includes:
        pattern_start_time = time.time()
        logger.debug(f"Processing include pattern: '{pattern}'")

        if "**" in pattern:
            parts = pattern.split("**", 1)
            base_dir_glob_part = parts[0].rstrip("/")  # "src" or ""
            # glob_suffix is the part after '**/', e.g., "*.py" or "some_dir/*.txt"
            glob_suffix = parts[1].lstrip("/")

            current_search_root_abs = project_root
            if base_dir_glob_part:
                # Handle potential multiple directory components in base_dir_glob_part
                # e.g. pattern "src/app/**/... -> base_dir_glob_part = "src/app"
                current_search_root_abs = (project_root / base_dir_glob_part).resolve()

            if not current_search_root_abs.is_dir():
                logger.debug(
                    f"Skipping include pattern '{pattern}': base '{current_search_root_abs}' not a directory."
                )
                continue

            logger.debug(
                f"Using recursive walker for pattern '{pattern}' starting at '{current_search_root_abs}', suffix '{glob_suffix}'"
            )
            for p_found in _recursive_glob_with_pruning(
                current_search_root_abs,
                glob_suffix,
                project_root,
                normalized_exclude_globs,
                _explicit_excludes,
            ):
                # _recursive_glob_with_pruning already yields resolved, filtered paths
                if p_found.is_file():  # Final check, though walker should only yield files
                    candidate_files.add(p_found)  # p_found is already resolved
        else:
            # Non-recursive glob (no "**")
            logger.debug(f"Using Path.glob for non-recursive pattern: '{pattern}'")
            try:
                for p in project_root.glob(pattern):
                    abs_p = p.resolve()
                    if p.is_symlink():
                        logger.debug(f"    -> Skipping discovered symlink: {p}")
                        continue
                    if p.is_file():
                        if not _is_excluded(
                            abs_p,
                            project_root,
                            normalized_exclude_globs,
                            _explicit_excludes,
                            False,
                        ):
                            candidate_files.add(abs_p)
            except PermissionError as e:
                logger.warning(
                    f"Permission denied for non-recursive glob '{pattern}': {e}. Skipping."
                )
            except (OSError, ValueError) as e:
                logger.error(f"Error during non-recursive glob '{pattern}': {e}", exc_info=True)

        pattern_time = time.time() - pattern_start_time
        logger.debug(f"Pattern '{pattern}' processing took {pattern_time:.4f} seconds.")

    discovery_time = time.time() - start_time
    logger.debug(
        f"Globbing and initial filtering finished in {discovery_time:.4f} seconds. Total candidates: {len(candidate_files)}"
    )

    final_files_set = candidate_files

    # VCS Warning Logic
    vcs_warnings: set[Path] = set()
    if final_files_set:
        for file_path in final_files_set:
            try:
                if any(part in _VCS_DIRS for part in file_path.relative_to(project_root).parts):
                    is_actually_excluded_by_vcs_pattern = False
                    for vcs_dir_name in _VCS_DIRS:
                        if _is_excluded(
                            file_path,
                            project_root,
                            [f"{vcs_dir_name}/", f"{vcs_dir_name}/**"],
                            set(),
                            False,
                        ):
                            is_actually_excluded_by_vcs_pattern = True
                            break
                    if not is_actually_excluded_by_vcs_pattern:
                        vcs_warnings.add(file_path)
            except ValueError:
                pass
            except (OSError, TypeError) as e_vcs:
                logger.debug(f"Error during VCS check for {file_path}: {e_vcs}")

    if vcs_warnings:
        logger.warning(
            f"Found {len(vcs_warnings)} included files within potential VCS directories "
            f"({', '.join(_VCS_DIRS)}). Consider adding patterns like '.git/**' to 'exclude_globs' "
            "in your [tool.maxwell] section if this was unintended."
        )
        try:
            paths_to_log = [
                get_relative_path(p, project_root) for p in sorted(list(vcs_warnings), key=str)[:5]
            ]
            for rel_path_warn in paths_to_log:
                logger.warning(f"  - {rel_path_warn}")
            if len(vcs_warnings) > 5:
                logger.warning(f"  - ... and {len(vcs_warnings) - 5} more.")
        except Exception as e_log:
            logger.warning(f"  (Error logging VCS warning example paths: {e_log})")

    final_count = len(final_files_set)
    if final_count == 0 and include_globs_effective:
        logger.warning("No files found matching include_globs patterns or all were excluded.")

    logger.debug(f"Discovery complete. Returning {final_count} files.")
    return sorted(list(final_files_set))


def discover_files_from_paths(
    custom_paths: list[Path],
    config: MaxwellConfig,
    explicit_exclude_paths: set[Path] | None = None,
) -> list[Path]:
    """Discover files from explicitly provided paths (include_globs override).

    This function handles user-provided paths as an override to the configured
    include_globs, while still respecting exclude_globs and sensible defaults
    to avoid processing __pycache__, .git, etc.

    Args:
        custom_paths: List of file or directory paths (include_globs override)
        config: The maxwell configuration object
        explicit_exclude_paths: Additional paths to explicitly exclude

    Returns:
        A sorted list of unique absolute Path objects for Python files

    """
    # Note: MaxwellConfig doesn't have project_root - this function needs to be called with a separate project_root parameter
    # For now, use current directory as fallback
    project_root = Path.cwd().resolve()
    candidate_files: set[Path] = set()
    _explicit_excludes = {p.resolve() for p in (explicit_exclude_paths or set())}

    # Combine config exclude patterns with defaults
    config_exclude_globs = config.file_patterns.exclude_globs
    if not isinstance(config_exclude_globs, list):
        config_exclude_globs = []

    # Always apply default exclude patterns to avoid __pycache__, .git, etc.
    all_exclude_patterns = _DEFAULT_EXCLUDE_PATTERNS + config_exclude_globs

    logger.info(f"Include globs override: processing {len(custom_paths)} custom path(s)")
    logger.debug(f"Using exclude patterns: {all_exclude_patterns}")

    for path in custom_paths:
        abs_path = path.resolve()

        if abs_path.is_file():
            # Single file - check if it's a Python file and not excluded
            if abs_path.suffix == ".py":
                if not _is_excluded(
                    abs_path,
                    project_root,
                    all_exclude_patterns,
                    _explicit_excludes,
                    is_checking_directory_for_prune=False,
                ):
                    candidate_files.add(abs_path)
                else:
                    logger.debug(f"Excluding file {abs_path} due to exclude patterns")

        elif abs_path.is_dir():
            # Directory - recursively find Python files while respecting exclusions
            logger.debug(f"Scanning directory: {abs_path}")

            # Use the existing recursive walker with Python file pattern
            for py_file in _recursive_glob_with_pruning(
                abs_path,
                "*.py",  # Only Python files
                project_root,
                all_exclude_patterns,
                _explicit_excludes,
            ):
                candidate_files.add(py_file)
        else:
            logger.warning(f"Path does not exist or is not a file/directory: {abs_path}")

    sorted_files = sorted(candidate_files)
    logger.info(f"Include globs override result: discovered {len(sorted_files)} Python files")
    return sorted_files
```

---
### File: src/maxwell/extractors.py

```python
"""Multi-format content extractors for Maxwell.

Extracts text from various file formats for semantic indexing:
- PDFs (via marker-pdf)
- Office docs (via markitdown: DOCX, PPTX, XLSX)
- Images (via markitdown: OCR)
- Audio (via markitdown: speech-to-text)
- And more

Content-addressable extraction cache:
- Extractions cached in ~/.maxwell/cache/extracted/{sha256}/
- Reuses existing parsed versions when available
- Global deduplication (same file = same hash = same extraction)
"""

import hashlib
import json
import logging
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.types import (
    ChatExtractionResult,
    DocumentExtractionResult,
    FileMetadata,
    PDFExtractionResult,
)

logger = logging.getLogger(__name__)


@dataclass
class ExtractedContent:
    """Content extracted from a file."""

    text: str
    metadata: Dict[str, Any]  # TODO: Make more specific with dataclass types
    images: List[Any]  # For PDFs with images


class ContentExtractor:
    """Extract text content from various file formats with content-addressable caching."""

    def __init__(self, cache_dir: Optional[Path] = None):
        """Initialize extractors.

        Args:
            cache_dir: Cache directory for extractions (default: ~/.maxwell/cache/extracted)

        """
        self._marker_pdf = None
        self._markitdown = None
        self.cache_dir = cache_dir or Path.home() / ".maxwell" / "cache" / "extracted"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_marker_pdf(self):
        """Lazy load marker-pdf."""
        if self._marker_pdf is None:
            try:
                from marker.converters.pdf import PdfConverter
                from marker.models import create_model_dict

                self._marker_models = create_model_dict()
                self._marker_pdf = PdfConverter(artifact_dict=self._marker_models)
                logger.info("Loaded marker-pdf")
            except ImportError as e:
                logger.warning(f"marker-pdf not available: {e}")
        return self._marker_pdf

    def _get_markitdown(self):
        """Lazy load markitdown."""
        if self._markitdown is None:
            try:
                from markitdown import MarkItDown

                self._markitdown = MarkItDown()
                logger.info("Loaded markitdown")
            except ImportError as e:
                logger.warning(f"markitdown not available: {e}")
        return self._markitdown

    def _hash_file(self, path: Path) -> str:
        """Compute SHA256 hash of file."""
        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(8192):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _get_cache_path(self, path: Path) -> Path:
        """Get cache directory for this file's hash."""
        file_hash = self._hash_file(path)
        return self.cache_dir / file_hash

    def _load_pdf_parse_map(self) -> dict:
        """Load PDF parse mapping from ~/.maxwell/pdf_parse_map.json.

        Format:
        {
            "/absolute/path/to/paper.pdf": "/absolute/path/to/parsed/paper.md",
            "~/Documents/arxiv/*.pdf": "~/Documents/arxiv/parsed_papers/originals/*/paper.md"
        }

        Supports:
        - Absolute paths
        - ~ expansion
        - Glob patterns (for bulk mappings)
        """
        map_file = Path.home() / ".maxwell" / "pdf_parse_map.json"
        if not map_file.exists():
            return {}

        try:
            with open(map_file) as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load PDF parse map: {e}")
            return {}

    def _check_existing_parse(self, path: Path) -> Optional[Path]:
        """Check if this PDF was already parsed.

        Checks in order:
        1. Explicit mapping in ~/.maxwell/pdf_parse_map.json
        2. Sibling 'parsed/' directory (convention-based)

        Examples:
        - praxis/paper.pdf → praxis/parsed/paper.md
        - praxis/paper.pdf → praxis/parsed/paper_name/paper.md
        - Mapped: /any/path/paper.pdf → /any/other/path/parsed.md

        """
        if path.suffix.lower() != ".pdf":
            return None

        # Strategy 1: Check explicit mapping
        parse_map = self._load_pdf_parse_map()
        path_str = str(path.resolve())

        # Try exact match first
        if path_str in parse_map:
            mapped_path = Path(parse_map[path_str]).expanduser()
            if mapped_path.exists():
                logger.info(f"Found mapped parse: {mapped_path}")
                return mapped_path

        # Try glob patterns (e.g., "~/Documents/arxiv/*.pdf")
        from glob import glob as glob_match

        for pattern, target_pattern in parse_map.items():
            if "*" in pattern:
                pattern_expanded = Path(pattern).expanduser()
                matches = glob_match(str(pattern_expanded))
                if path_str in matches:
                    # Resolve target (may also be a pattern)
                    target = Path(target_pattern).expanduser()
                    if target.exists():
                        logger.info(f"Found mapped parse (glob): {target}")
                        return target

        # Strategy 2: Check sibling parsed/ directory
        sibling_parsed = path.parent / "parsed"
        if not sibling_parsed.exists():
            return None

        # Direct match (paper.pdf -> parsed/paper.md)
        md_file = sibling_parsed / f"{path.stem}.md"
        if md_file.exists():
            logger.info(f"Found sibling parse: {md_file.relative_to(path.parent.parent)}")
            return md_file

        # Subdirectory match (paper.pdf -> parsed/paper_*/paper.md)
        for subdir in sibling_parsed.iterdir():
            if subdir.is_dir() and path.stem.lower() in subdir.name.lower():
                md_files = list(subdir.glob("*.md"))
                if md_files:
                    logger.info(
                        f"Found sibling parse: {md_files[0].relative_to(path.parent.parent)}"
                    )
                    return md_files[0]

        return None

    def _load_cached_extraction(self, cache_path: Path) -> Optional[ExtractedContent]:
        """Load extraction from cache."""
        metadata_file = cache_path / "metadata.json"
        text_file = cache_path / "extracted.md"

        if not (metadata_file.exists() and text_file.exists()):
            return None

        try:
            with open(metadata_file) as f:
                metadata = json.load(f)
            text = text_file.read_text()

            # Load images if they exist
            images = []
            image_dir = cache_path / "images"
            if image_dir.exists():
                images = [str(img) for img in image_dir.glob("*")]

            logger.debug(f"Loaded cached extraction from {cache_path}")
            return ExtractedContent(text=text, metadata=metadata, images=images)
        except Exception as e:
            logger.warning(f"Failed to load cache from {cache_path}: {e}")
            return None

    def _save_to_cache(self, cache_path: Path, content: ExtractedContent):
        """Save extraction to cache."""
        try:
            cache_path.mkdir(parents=True, exist_ok=True)

            # Save metadata
            with open(cache_path / "metadata.json", "w") as f:
                json.dump(content.metadata, f, indent=2)

            # Save text
            (cache_path / "extracted.md").write_text(content.text)

            # Save images if any
            if content.images:
                image_dir = cache_path / "images"
                image_dir.mkdir(exist_ok=True)
                # Images are already saved by marker-pdf, just note their existence
                # in metadata

            logger.debug(f"Cached extraction to {cache_path}")
        except Exception as e:
            logger.warning(f"Failed to save to cache {cache_path}: {e}")

    def can_extract(self, path: Path) -> bool:
        """Check if we can extract content from this file."""
        suffix = path.suffix.lower()

        # Claude chat logs (JSONL format)
        if suffix == ".jsonl":
            # Check if it's in .claude/projects directory
            if ".claude/projects/" in str(path):
                return True

        # Marker-pdf for high-quality PDF extraction (LaTeX, tables, figures)
        if suffix == ".pdf":
            return self._get_marker_pdf() is not None

        # Markitdown for Office docs, images, audio, etc.
        markitdown_formats = {
            ".docx",
            ".doc",  # Word
            ".pptx",
            ".ppt",  # PowerPoint
            ".xlsx",
            ".xls",  # Excel
            ".png",
            ".jpg",
            ".jpeg",  # Images (OCR)
            ".mp3",
            ".wav",  # Audio (speech-to-text)
            ".html",
            ".htm",  # HTML
            ".csv",
            ".json",
            ".xml",  # Structured
        }
        if suffix in markitdown_formats:
            return self._get_markitdown() is not None

        return False

    def extract(self, path: Path, max_chars: int = 10000) -> Optional[ExtractedContent]:
        """Extract content from file with content-addressable caching.

        Args:
            path: File to extract from
            max_chars: Maximum characters to extract

        Returns:
            Extracted content or None if extraction failed

        """
        # Check cache first (content-addressable deduplication)
        cache_path = self._get_cache_path(path)
        cached = self._load_cached_extraction(cache_path)
        if cached:
            logger.debug(f"Cache hit for {path.name}")
            return cached

        # For PDFs, check if there's an existing parse
        if path.suffix.lower() == ".pdf":
            existing_parse = self._check_existing_parse(path)
            if existing_parse:
                # Load existing parse and save to cache
                text = existing_parse.read_text()
                result = ExtractedContent(
                    text=text[:max_chars] if len(text) > max_chars else text,
                    metadata=asdict(
                        DocumentExtractionResult(
                            format="pdf",
                            source="existing_arxiv_parse",
                            path=str(existing_parse),
                        )
                    ),
                    images=[],  # Could enumerate images from directory if needed
                )
                self._save_to_cache(cache_path, result)
                return result

        # Extract fresh
        suffix = path.suffix.lower()
        try:
            if suffix == ".jsonl" and ".claude/projects/" in str(path):
                result = self._extract_claude_chat(path, max_chars)
            elif suffix == ".pdf":
                result = self._extract_pdf(path, max_chars)
            elif suffix in {
                ".docx",
                ".pptx",
                ".xlsx",
                ".png",
                ".jpg",
                ".jpeg",
                ".mp3",
                ".wav",
                ".html",
                ".csv",
                ".json",
                ".xml",
            }:
                result = self._extract_markitdown(path, max_chars)
            else:
                return None

            # Cache the result
            if result:
                self._save_to_cache(cache_path, result)

            return result
        except Exception as e:
            logger.error(f"Failed to extract {path}: {e}")
            return None

    def _extract_claude_chat(self, path: Path, max_chars: int) -> Optional[ExtractedContent]:
        """Extract conversational content from Claude Code chat logs (.jsonl).

        Format: One JSON object per line with message data.
        Extract user/assistant exchanges for searchable content.
        """
        try:
            chunks = []
            message_count = 0
            user_msgs = 0
            assistant_msgs = 0

            with open(path) as f:
                for line in f:
                    try:
                        entry = json.loads(line)
                        entry_type = entry.get("type")

                        # Extract user messages
                        if entry_type == "user":
                            msg = entry.get("message", {})
                            content = msg.get("content", [])
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "text":
                                    text = block.get("text", "")
                                    if text and len(text) > 50:  # Skip very short messages
                                        chunks.append(f"[USER]: {text[:2000]}")  # Limit per message
                                        user_msgs += 1

                        # Extract assistant messages
                        elif entry_type == "assistant":
                            msg = entry.get("message", {})
                            content = msg.get("content", [])
                            for block in content:
                                if isinstance(block, dict):
                                    if block.get("type") == "text":
                                        text = block.get("text", "")
                                        if text and len(text) > 50:
                                            chunks.append(f"[ASSISTANT]: {text[:2000]}")
                                            assistant_msgs += 1

                        message_count += 1

                        # Stop if we've extracted enough
                        if sum(len(c) for c in chunks) > max_chars:
                            break

                    except json.JSONDecodeError:
                        continue

            # Combine chunks
            text = "\n\n".join(chunks)
            if len(text) > max_chars:
                text = text[:max_chars] + f"\n\n[Truncated from {len(text)} chars]"

            return ExtractedContent(
                text=text,
                metadata=asdict(
                    ChatExtractionResult(
                        format="claude_chat_jsonl",
                        total_lines=message_count,
                        user_messages=user_msgs,
                        assistant_messages=assistant_msgs,
                        session_id=path.stem,
                    )
                ),
                images=[],
            )

        except Exception as e:
            logger.error(f"Failed to extract Claude chat from {path}: {e}")
            return None

    def _extract_pdf(self, path: Path, max_chars: int) -> Optional[ExtractedContent]:
        """Extract PDF using marker-pdf."""
        converter = self._get_marker_pdf()
        if not converter:
            return None

        try:
            # Convert PDF to markdown (use str, not Path)
            result = converter(str(path))
            full_text = result.markdown

            # Truncate if too long
            if len(full_text) > max_chars:
                full_text = full_text[:max_chars] + f"\n\n[Truncated from {len(full_text)} chars]"

            return ExtractedContent(
                text=full_text,
                metadata=asdict(
                    PDFExtractionResult(
                        format="pdf",
                        pages=getattr(result, "pages", 0),
                        images=len(getattr(result, "images", [])),
                    )
                ),
                images=getattr(result, "images", []),
            )
        except Exception as e:
            logger.error(f"marker-pdf failed on {path}: {e}")
            return None

    def _extract_markitdown(self, path: Path, max_chars: int) -> Optional[ExtractedContent]:
        """Extract content using markitdown."""
        markitdown = self._get_markitdown()
        if not markitdown:
            return None

        try:
            # Convert to markdown
            result = markitdown.convert(str(path))
            text = result.text_content

            # Truncate if too long
            if len(text) > max_chars:
                text = text[:max_chars] + f"\n\n[Truncated from {len(text)} chars]"

            return ExtractedContent(
                text=text,
                metadata=asdict(
                    FileMetadata(
                        format=path.suffix[1:],  # Remove dot
                        size_bytes=path.stat().st_size,
                    )
                ),
                images=[],
            )
        except Exception as e:
            logger.error(f"markitdown failed on {path}: {e}")
            return None


# Global singleton
_extractor = None


def get_content_extractor() -> ContentExtractor:
    """Get or create the global content extractor."""
    global _extractor
    if _extractor is None:
        _extractor = ContentExtractor()
    return _extractor
```

---
### File: src/maxwell/filesystem.py

```python
"""Filesystem and path utility functions for maxwell.

maxwell/src/maxwell/fs.py
"""

from __future__ import annotations

import fnmatch
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

__all__ = [
    "ensure_directory",
    "find_files_by_extension",
    "find_package_root",
    "find_project_root",
    "get_import_path",
    "get_module_name",
    "get_relative_path",
    "is_binary",
    "is_python_file",
    "read_file_safe",
    "walk_up_for_config",
    "walk_up_for_project_root",
    "write_file_safe",
]


def walk_up_for_project_root(start_path: Path) -> Path | None:
    """Walk up directory tree to find project root markers.

    Project root markers (in order of precedence):
    1. .git directory (definitive project boundary)
    2. pyproject.toml file (Python project config)
    3. dev.pyproject.toml file (development/parent project config)

    Args:
        start_path: Path to start walking up from

    Returns:
        Path to project root, or None if not found

    maxwell/src/maxwell/fs.py

    """
    current_path = start_path.resolve()
    while True:
        # Check for git repo (strongest indicator of project root)
        if (current_path / ".git").is_dir():
            return current_path
        # Check for standard Python project config
        if (current_path / "pyproject.toml").is_file():
            return current_path
        # Check for development/parent project config (e.g., kaia's dev.pyproject.toml)
        if (current_path / "dev.pyproject.toml").is_file():
            return current_path
        # Stop at filesystem root
        if current_path.parent == current_path:
            return None
        current_path = current_path.parent


def walk_up_for_config(start_path: Path) -> Path | None:
    """Walk up directory tree to find maxwell configuration.

    Searches for configuration files in this order:
    1. pyproject.toml with [tool.maxwell] section
    2. dev.pyproject.toml with [tool.maxwell] section
    3. .git directory (fallback to git repo root)

    Args:
        start_path: Path to start walking up from

    Returns:
        Path containing viable configuration, or None if not found

    maxwell/src/maxwell/fs.py

    """
    current_path = start_path.resolve()
    if current_path.is_file():
        current_path = current_path.parent

    while True:
        # Check for standard pyproject.toml with maxwell config
        pyproject_path = current_path / "pyproject.toml"
        if pyproject_path.is_file():
            if _has_maxwell_config(pyproject_path):
                return current_path

        # Check for dev.pyproject.toml with maxwell config (kaia pattern)
        dev_pyproject_path = current_path / "dev.pyproject.toml"
        if dev_pyproject_path.is_file():
            if _has_maxwell_config(dev_pyproject_path):
                return current_path

        # Fallback to git repo root
        if (current_path / ".git").is_dir():
            return current_path

        # Stop at filesystem root
        if current_path.parent == current_path:
            return None
        current_path = current_path.parent


def _has_maxwell_config(toml_path: Path) -> bool:
    """Check if a TOML file contains maxwell configuration."""
    try:
        import sys

        if sys.version_info >= (3, 11):
            import tomllib
        else:
            import tomli as tomllib

        with open(toml_path, "rb") as f:
            data = tomllib.load(f)
            return "tool" in data and "maxwell" in data.get("tool", {})
    except Exception:
        return False


# Backward compatibility alias
find_project_root = walk_up_for_project_root


def find_package_root(start_path: Path) -> Path | None:
    """Find the root directory of a Python package containing the given path.

    A package root is identified by containing either:
    1. A pyproject.toml file
    2. A setup.py file
    3. An __init__.py file at the top level with no parent

    Args:
        start_path: Path to start the search from

    Returns:
        Path to package root, or None if not found

    maxwell/src/maxwell/fs.py

    """
    current_path = start_path.resolve()
    if current_path.is_file():
        current_path = current_path.parent

    while True:
        if (current_path / "__init__.py").is_file():
            project_root_marker = walk_up_for_project_root(current_path)
            if project_root_marker and current_path.is_relative_to(project_root_marker):
                pass

        if (current_path / "pyproject.toml").is_file() or (current_path / ".git").is_dir():
            src_dir = current_path / "src"
            if src_dir.is_dir():
                if start_path.resolve().is_relative_to(src_dir):
                    for item in src_dir.iterdir():
                        if item.is_dir() and (item / "__init__.py").is_file():
                            return item
                    return src_dir
                else:
                    if (current_path / "__init__.py").is_file():
                        return current_path

            if (current_path / "__init__.py").is_file():
                return current_path
            return current_path

        if current_path.parent == current_path:
            return start_path.parent if start_path.is_file() else start_path

        current_path = current_path.parent


def is_python_file(path: Path) -> bool:
    """Check if a path represents a Python file.

    Args:
        path: Path to check

    Returns:
        True if the path is a Python file, False otherwise

    maxwell/src/maxwell/fs.py

    """
    return path.is_file() and path.suffix == ".py"


def get_relative_path(path: Path, base: Path) -> Path:
    """Safely compute a relative path, falling back to the original path.

    maxwell/src/maxwell/fs.py
    """
    try:
        return path.resolve().relative_to(base.resolve())
    except ValueError as e:
        logger.debug(f"Path {path} is not relative to {base}: {e}")
        return path.resolve()


def get_import_path(file_path: Path, package_root: Path | None = None) -> str:
    """Get the import path for a Python file.

    Args:
        file_path: Path to the Python file
        package_root: Optional path to the package root

    Returns:
        Import path (e.g., "maxwell.utils")

    maxwell/src/maxwell/fs.py

    """
    if package_root is None:
        package_root = find_package_root(file_path)

    if package_root is None:
        return file_path.stem

    try:
        rel_path = file_path.relative_to(package_root)
        import_path = str(rel_path).replace(os.sep, ".").replace("/", ".")
        if import_path.endswith(".py"):
            import_path = import_path[:-3]
        return import_path
    except ValueError as e:
        logger.debug(f"Could not determine import path for {file_path}: {e}")
        return file_path.stem


def get_module_name(file_path: Path) -> str:
    """Extract module name from a Python file path.

    Args:
        file_path: Path to a Python file

    Returns:
        Module name

    maxwell/src/maxwell/fs.py

    """
    return file_path.stem


def find_files_by_extension(
    root_path: Path,
    extension: str = ".py",
    exclude_globs: list[str] = [],
    include_vcs_hooks: bool = False,
) -> list[Path]:
    """Find all files with a specific extension in a directory and its subdirectories.

    Args:
        root_path: Root path to search in
        extension: File extension to look for (including the dot)
        exclude_globs: Glob patterns to exclude
        include_vcs_hooks: Whether to include version control directories

    Returns:
        List of paths to files with the specified extension

    maxwell/src/maxwell/fs.py

    """
    if exclude_globs is None:
        exclude_globs = []

    result = []

    for file_path in root_path.glob(f"**/*{extension}"):
        if not include_vcs_hooks:
            if any(
                part.startswith(".") and part in {".git", ".hg", ".svn"} for part in file_path.parts
            ):
                continue

        if any(fnmatch.fnmatch(str(file_path), pattern) for pattern in exclude_globs):
            continue

        result.append(file_path)

    return result


def ensure_directory(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary.

    Args:
        path: Path to directory

    Returns:
        Path to the directory

    maxwell/src/maxwell/fs.py

    """
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_file_safe(file_path: Path, encoding: str = "utf-8") -> str | None:
    """Safely read a file, returning None if any errors occur.

    Args:
        file_path: Path to file
        encoding: File encoding

    Returns:
        File contents or None if error

    maxwell/src/maxwell/fs.py

    """
    try:
        return file_path.read_text(encoding=encoding)
    except (OSError, UnicodeDecodeError) as e:
        logger.debug(f"Could not read file {file_path}: {e}")
        return None


def write_file_safe(file_path: Path, content: str, encoding: str = "utf-8") -> bool:
    """Safely write content to a file, returning success status.

    Args:
        file_path: Path to file
        content: Content to write
        encoding: File encoding

    Returns:
        True if successful, False otherwise

    maxwell/src/maxwell/fs.py

    """
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding=encoding)
        return True
    except (OSError, UnicodeEncodeError) as e:
        logger.debug(f"Could not write file {file_path}: {e}")
        return False


def is_binary(file_path: Path, chunk_size: int = 1024) -> bool:
    """Check if a file appears to be binary by looking for null bytes
    or a high proportion of non-text bytes in the first chunk.

    Args:
        file_path: The path to the file.
        chunk_size: The number of bytes to read from the beginning.

    Returns:
        True if the file seems binary, False otherwise.

    maxwell/src/maxwell/fs.py

    """
    try:
        with open(file_path, "rb") as f:
            chunk = f.read(chunk_size)
        if not chunk:
            return False

        if b"\x00" in chunk:
            return True

        text_characters = bytes(range(32, 127)) + b"\n\r\t\f\b"
        non_text_count = sum(1 for byte in chunk if bytes([byte]) not in text_characters)

        if len(chunk) > 0 and (non_text_count / len(chunk)) > 0.3:
            return True

        return False
    except OSError:
        return True
    except (TypeError, AttributeError) as e:
        logger.debug(f"Error checking if {file_path} is binary: {e}")
        return True
```

---
### File: src/maxwell/lm_pool.py

```python
"""LLM and Embedding Pool Manager.

Flexible resource registry that allows users to declare all their LLMs and embeddings,
then intelligently selects the best one for each task based on capabilities.

Usage:
    pool = LLMPool.from_registry()

    # Select by name
    llm = pool.get_lm("qwen-coder-30b")

    # Select by capability
    fast_llm = pool.select_llm(min_speed=50, reasoning=True)
    vision_llm = pool.select_llm(vision=True)

    # Get default embedding
    embed = pool.get_embedding("default")
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class LLMSpec(BaseModel):
    """Specification for an LLM (OpenAI-compatible client)."""

    name: str
    api_base: str = Field(..., description="Base URL (e.g., http://host:port)")
    model: str
    backend: str  # vllm | llamacpp | openai
    capabilities: Dict[str, Any]
    default_temperature: float
    tags: List[str] = Field(default_factory=list)

    # Cost and scheduling metadata
    cost_per_1k_tokens: float = Field(default=0.0, description="Cost per 1K tokens (0 = free)")
    tier: str = Field(default="standard", description="Service tier: free | standard | premium")
    daily_budget_tokens: Optional[int] = Field(default=None, description="Max tokens/day (None = unlimited)")

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LLMSpec":
        """Create from dictionary with Pydantic validation."""
        return cls(**data)  # Pydantic handles validation automatically

    def matches(
        self,
        min_speed: Optional[float] = None,
        min_context: Optional[int] = None,
        reasoning: Optional[bool] = None,
        vision: Optional[bool] = None,
        code_specialized: Optional[bool] = None,
        tags: Optional[List[str]] = None,
    ) -> bool:
        """Check if this LLM matches the given requirements."""
        caps = self.capabilities

        if min_speed is not None and caps.get("speed_tokens_per_sec", 0) < min_speed:
            return False

        if min_context is not None and caps.get("max_context", 0) < min_context:
            return False

        if reasoning is not None and caps.get("reasoning", False) != reasoning:
            return False

        if vision is not None and caps.get("vision", False) != vision:
            return False

        if code_specialized is not None and caps.get("code_specialized", False) != code_specialized:
            return False

        if tags is not None:
            if not all(tag in self.tags for tag in tags):
                return False

        return True


class EmbeddingSpec(BaseModel):
    """Specification for an embedding model (OpenAI-compatible client)."""

    name: str
    api_base: str = Field(..., description="Base URL (e.g., http://host:port)")
    model: str
    dimension: int
    max_context: int = Field(..., description="Maximum context length in tokens")
    specialized_for: List[str]
    tags: List[str]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EmbeddingSpec":
        """Create from dictionary with Pydantic validation."""
        return cls(**data)  # Pydantic handles validation automatically

    def embed(self, text: str) -> List[float]:
        """Embed text using this embedding model.

        Args:
            text: Text to embed (will be truncated to max_context)

        Returns:
            Embedding vector as list of floats

        """
        import requests

        # Truncate to fit within token limit (rough estimate: 4 chars per token)
        max_chars = self.max_context * 4
        if len(text) > max_chars:
            text = text[:max_chars]
            logger.debug(f"Truncated text to {max_chars} chars for embedding")

        # Construct full endpoint URL (OpenAI-compatible)
        endpoint_url = f"{self.api_base.rstrip('/')}/v1/embeddings"
        response = requests.post(
            endpoint_url,
            json={"input": text, "model": self.model},
            timeout=30,
        )
        response.raise_for_status()
        embedding = response.json()["data"][0]["embedding"]

        # JSONL logging for embeddings (same as LLM generation)
        import datetime
        import json as json_module
        import os
        from pathlib import Path

        # Skip if JSONL logging disabled
        if os.getenv("NO_JSONL_LOGGING"):
            return embedding

        # Use same logging logic as LLM generation
        base_dir = Path.cwd() / ".maxwell"
        log_dir = base_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Use session ID or infer from calling script
        import sys

        session_id = os.getenv("LLM_SESSION_ID")
        if not session_id:
            calling_script = "unknown"
            if len(sys.argv) > 0:
                script_path = Path(sys.argv[0])
                calling_script = script_path.stem
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            session_id = f"{calling_script}_{timestamp}"

        jsonl_file = log_dir / f"{session_id}.jsonl"

        # Create embedding log entry
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "model": self.model,
            "type": "embedding",
            "request": {"input": text, "model": self.model},
            "response": {
                "embedding": embedding,
                "dimensions": len(embedding),
                "min_value": min(embedding),
                "max_value": max(embedding),
                "mean_value": sum(embedding) / len(embedding),
                "first_10": embedding[:10],
                "last_10": embedding[-10:],
                "range": [min(embedding), max(embedding)],
            },
            "response_raw": {"data": [{"embedding": embedding}]},
            "grammar_used": False,
        }

        with open(jsonl_file, "a", encoding="utf-8") as f:
            f.write(json_module.dumps(log_entry) + "\n")

        return embedding


class LLMPool:
    """Pool manager for LLMs and embeddings with health checking."""

    def __init__(self, llms: List[LLMSpec], embeddings: List[EmbeddingSpec]):
        self.llms = {llm.name: llm for llm in llms}
        self.embeddings = {emb.name: emb for emb in embeddings}

        # Sort LLMs by speed for default selection
        self._llms_by_speed = sorted(
            llms, key=lambda x: x.capabilities.get("speed_tokens_per_sec", 0), reverse=True
        )

        # Health check cache: {service_name: (is_healthy, timestamp)}
        self._health_cache: Dict[str, tuple[bool, float]] = {}
        self._health_check_ttl = 30.0  # Cache health status for 30 seconds

        # Usage tracking for budget enforcement
        self._usage_tracker: Dict[str, Dict[str, int]] = {}  # {llm_name: {date: tokens_used}}
        self._load_usage_tracker()

    def _load_usage_tracker(self):
        """Load usage tracking data from cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_usage.json"
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    self._usage_tracker = json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load usage tracker: {e}")
                self._usage_tracker = {}
        else:
            self._usage_tracker = {}

    def _save_usage_tracker(self):
        """Save usage tracking data to cache file."""
        cache_file = Path.home() / ".maxwell" / "llm_usage.json"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(cache_file, "w") as f:
            json.dump(self._usage_tracker, f, indent=2)

    def _track_usage(self, llm_name: str, tokens: int):
        """Track token usage for budget enforcement."""
        import datetime

        today = datetime.date.today().isoformat()

        if llm_name not in self._usage_tracker:
            self._usage_tracker[llm_name] = {}

        self._usage_tracker[llm_name][today] = (
            self._usage_tracker[llm_name].get(today, 0) + tokens
        )
        self._save_usage_tracker()

    def _check_budget(self, llm: LLMSpec, estimated_tokens: int) -> bool:
        """Check if LLM has budget remaining for this request."""
        if llm.daily_budget_tokens is None:
            return True  # Unlimited

        import datetime

        today = datetime.date.today().isoformat()
        used_today = self._usage_tracker.get(llm.name, {}).get(today, 0)

        return (used_today + estimated_tokens) <= llm.daily_budget_tokens

    @staticmethod
    def estimate_tokens(text: str, max_completion: int = 0) -> tuple[int, int]:
        """Estimate (prompt_tokens, total_tokens) from text.

        Uses tiktoken-like heuristic: ~4 chars per token.

        Args:
            text: Input text
            max_completion: Expected completion tokens

        Returns:
            (prompt_tokens, total_tokens)
        """
        # Rough heuristic: 4 chars/token (works reasonably for English + code)
        prompt_tokens = max(1, len(text) // 4)
        total_tokens = prompt_tokens + max_completion
        return prompt_tokens, total_tokens

    def score_llm(
        self,
        llm: LLMSpec,
        estimated_tokens: int,
        time_cost_weight: float = 1.0,
    ) -> float:
        """Score an LLM for a given request (higher = better).

        Scoring considers:
        - Monetary cost (static from API pricing)
        - Time cost (dynamic from speed)
        - Context utilization (prefer ~70% utilization)
        - Budget availability

        Args:
            llm: LLM to score
            estimated_tokens: Total tokens (prompt + completion)
            time_cost_weight: Weight for time vs money (0-10, default 1.0)

        Returns:
            Score (higher = better fit), or -1 if impossible
        """
        # Check hard constraints
        max_context = llm.capabilities.get("max_context", 4096)
        if estimated_tokens > max_context:
            return -1.0  # Impossible - doesn't fit

        if not self._check_budget(llm, estimated_tokens):
            logger.debug(f"{llm.name} over budget, skipping")
            return -1.0  # Over budget

        # Calculate monetary cost (negative because lower is better)
        monetary_cost = -llm.cost_per_1k_tokens * (estimated_tokens / 1000)

        # Calculate time cost (negative because slower is worse)
        speed = llm.capabilities.get("speed_tokens_per_sec", 25)
        time_seconds = estimated_tokens / speed
        time_cost = -time_cost_weight * time_seconds

        # Calculate utilization score (prefer ~70% utilization)
        utilization = estimated_tokens / max_context
        utilization_bonus = 1.0 - abs(utilization - 0.7)  # 0-1, peaks at 70%

        # Combined score
        total_score = monetary_cost + time_cost + utilization_bonus

        logger.debug(
            f"{llm.name}: score={total_score:.2f} "
            f"(money={monetary_cost:.2f}, time={time_cost:.2f}, "
            f"util={utilization_bonus:.2f}, {utilization*100:.0f}% full)"
        )

        return total_score

    def select_optimal_llm(
        self,
        prompt: str,
        max_completion: int = 512,
        time_cost_weight: float = 1.0,
        **capability_filters,
    ) -> LLMSpec:
        """Select optimal LLM using intelligent scoring.

        Args:
            prompt: Input prompt text
            max_completion: Expected completion tokens
            time_cost_weight: How much to value speed (0-10)
                - 0.0 = only minimize monetary cost
                - 1.0 = balanced (default)
                - 10.0 = maximize speed regardless of cost
            **capability_filters: Additional filters (reasoning, vision, etc.)

        Returns:
            Best LLM spec for this request

        Example:
            # For cheap batch processing (prefer free internal LLMs)
            llm = pool.select_optimal_llm(prompt, time_cost_weight=0.1)

            # For interactive user-facing (prefer speed)
            llm = pool.select_optimal_llm(prompt, time_cost_weight=10.0)

            # For balanced workloads
            llm = pool.select_optimal_llm(prompt, time_cost_weight=1.0)
        """
        # Estimate request size
        prompt_tokens, total_tokens = self.estimate_tokens(prompt, max_completion)

        logger.debug(
            f"Request size: ~{total_tokens} tokens ({prompt_tokens} prompt + {max_completion} completion)"
        )

        # Get healthy candidates matching capability filters
        healthy = self.get_healthy_llms()
        candidates = [llm for llm in healthy if llm.matches(**capability_filters)]

        if not candidates:
            raise ValueError(f"No healthy LLMs matching filters: {capability_filters}")

        # Score each candidate
        scored = [
            (self.score_llm(llm, total_tokens, time_cost_weight), llm) for llm in candidates
        ]
        scored = [(score, llm) for score, llm in scored if score != -1.0]  # Filter impossible (keep negative scores, they're valid costs)

        if not scored:
            raise ValueError(
                f"No LLMs can handle {total_tokens} tokens "
                f"(max available: {max([llm.capabilities.get('max_context', 0) for llm in candidates])})"
            )

        # Sort by score (best first)
        scored.sort(reverse=True, key=lambda x: x[0])
        best_score, best_llm = scored[0]

        logger.info(
            f"Selected {best_llm.name} (score={best_score:.2f}, "
            f"cost=${best_llm.cost_per_1k_tokens * total_tokens / 1000:.4f}, "
            f"tier={best_llm.tier})"
        )

        return best_llm

    @classmethod
    def from_registry(cls, registry_path: Optional[Path] = None) -> "LLMPool":
        """Load pool from registry JSON file.

        Search order:
        1. Provided registry_path
        2. .maxwell/lm_registry.json in current directory
        3. ~/.maxwell/lm_registry.json (global default)
        """
        if registry_path is None:
            # Try local first
            local_registry = Path.cwd() / ".maxwell" / "lm_registry.json"
            if local_registry.exists():
                registry_path = local_registry
            else:
                # Fall back to global
                global_registry = Path.home() / ".maxwell" / "lm_registry.json"
                if global_registry.exists():
                    registry_path = global_registry
                else:
                    raise FileNotFoundError(
                        "No LLM registry found. Create .maxwell/llm_registry.json or ~/.maxwell/llm_registry.json"
                    )

        with open(registry_path) as f:
            data = json.load(f)

        llms = [LLMSpec.from_dict(llm_data) for llm_data in data.get("llms", [])]
        embeddings = [EmbeddingSpec.from_dict(emb_data) for emb_data in data.get("embeddings", [])]

        logger.info(
            f"Loaded LLM pool from {registry_path}: {len(llms)} LLMs, {len(embeddings)} embeddings"
        )

        return cls(llms, embeddings)

    def _check_service_health(self, api_base: str) -> bool:
        """Check if a service is healthy by making a test request.

        Args:
            api_base: Base API URL (e.g., http://localhost:8000)

        Returns:
            True if service is healthy and responsive

        """
        import time
        import requests

        try:
            # Try /health endpoint first (common pattern)
            health_url = f"{api_base.rstrip('/')}/health"
            response = requests.get(health_url, timeout=2)
            if response.status_code == 200:
                return True
        except Exception:
            pass

        try:
            # Fallback: try /v1/models endpoint (OpenAI-compatible)
            models_url = f"{api_base.rstrip('/')}/v1/models"
            response = requests.get(models_url, timeout=2)
            if response.status_code == 200:
                return True
        except Exception:
            pass

        # Service is unreachable
        return False

    def is_service_healthy(self, name: str, llm_spec: Optional[LLMSpec] = None) -> bool:
        """Check if a service is healthy (with caching).

        Args:
            name: Service name
            llm_spec: LLM spec (optional, will look up if not provided)

        Returns:
            True if service is healthy

        """
        import time

        # Check cache first
        if name in self._health_cache:
            is_healthy, timestamp = self._health_cache[name]
            if time.time() - timestamp < self._health_check_ttl:
                return is_healthy

        # Get spec if not provided
        if llm_spec is None:
            if name in self.llms:
                llm_spec = self.llms[name]
            elif name in self.embeddings:
                # For embeddings, just check the API base
                emb_spec = self.embeddings[name]
                is_healthy = self._check_service_health(emb_spec.api_base)
                self._health_cache[name] = (is_healthy, time.time())
                return is_healthy
            else:
                # Unknown service
                return False

        # Check health using api_base (no need to extract!)
        is_healthy = self._check_service_health(llm_spec.api_base)

        # Update cache
        self._health_cache[name] = (is_healthy, time.time())

        if not is_healthy:
            logger.warning(f"Service {name} ({llm_spec.api_base}) is unhealthy or unreachable")

        return is_healthy

    def get_healthy_llms(self) -> List[LLMSpec]:
        """Get list of all healthy LLMs.

        Returns:
            List of LLM specs for services that are currently healthy

        """
        healthy = []
        for name, spec in self.llms.items():
            if self.is_service_healthy(name, spec):
                healthy.append(spec)
        return healthy

    def get_lm(self, name: str) -> LLMSpec:
        """Get LLM by name."""
        if name not in self.llms:
            raise KeyError(
                f"LLM '{name}' not found in registry. Available: {list(self.llms.keys())}"
            )
        return self.llms[name]

    def select_llm(
        self,
        min_speed: Optional[float] = None,
        min_context: Optional[int] = None,
        reasoning: Optional[bool] = None,
        vision: Optional[bool] = None,
        tags: Optional[List[str]] = None,
        prefer_fastest: bool = True,
        check_health: bool = True,
    ) -> LLMSpec:
        """Select best LLM matching the given criteria (only healthy services).

        Args:
            min_speed: Minimum tokens/sec speed requirement
            min_context: Minimum context length requirement
            reasoning: Must have reasoning capability
            vision: Must have vision capability
            tags: Must have all these tags
            prefer_fastest: If True, return fastest match; otherwise return first match
            check_health: If True, only return healthy services (default)

        Returns:
            LLMSpec matching the criteria

        Raises:
            ValueError: If no LLM matches the criteria

        """
        # Filter by criteria
        candidates = [
            llm
            for llm in self._llms_by_speed
            if llm.matches(
                min_speed, min_context, reasoning, vision, None, tags
            )  # code_specialized=None
        ]

        # Filter by health if requested
        if check_health:
            healthy_candidates = [
                llm for llm in candidates if self.is_service_healthy(llm.name, llm)
            ]

            if healthy_candidates:
                candidates = healthy_candidates
            else:
                logger.warning(
                    f"No healthy LLMs found matching criteria. "
                    f"Falling back to all candidates (unhealthy services may fail)."
                )

        if not candidates:
            raise ValueError(
                f"No LLM found matching criteria: min_speed={min_speed}, min_context={min_context}, "
                f"reasoning={reasoning}, vision={vision}, tags={tags}"
            )

        if prefer_fastest:
            selected = candidates[0]  # Already sorted by speed
        else:
            selected = candidates[0]

        logger.info(
            f"Selected LLM: {selected.name} (healthy={self.is_service_healthy(selected.name, selected)})"
        )
        return selected

    def get_fastest_llm(self, check_health: bool = True) -> LLMSpec:
        """Get the fastest available LLM (only healthy by default).

        Args:
            check_health: If True, only return healthy services (default)

        Returns:
            Fastest LLM spec

        Raises:
            ValueError: If no healthy LLMs available

        """
        if check_health:
            healthy = self.get_healthy_llms()
            if healthy:
                # Sort by speed
                fastest = sorted(
                    healthy, key=lambda x: x.capabilities.get("speed_tokens_per_sec", 0), reverse=True
                )[0]
                logger.info(f"Fastest healthy LLM: {fastest.name}")
                return fastest
            else:
                logger.warning("No healthy LLMs found. Falling back to fastest registered LLM.")

        return self._llms_by_speed[0]

    def get_embedding(self, name_or_tag: str = "default") -> EmbeddingSpec:
        """Get embedding by name or tag."""
        # Try exact name match first
        if name_or_tag in self.embeddings:
            return self.embeddings[name_or_tag]

        # Try tag match
        for emb in self.embeddings.values():
            if name_or_tag in emb.tags:
                return emb

        raise KeyError(
            f"Embedding '{name_or_tag}' not found. Available: {list(self.embeddings.keys())}"
        )

    def list_llms(self) -> List[str]:
        """List all available LLM names."""
        return list(self.llms.keys())

    def list_embeddings(self) -> List[str]:
        """List all available embedding names."""
        return list(self.embeddings.keys())


class LLMClient:
    """LLM client with GBNF grammar support for structured output."""

    def __init__(self, llm_spec: LLMSpec):
        """Initialize with an LLM spec from the pool."""
        self.spec = llm_spec

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        pydantic_model: Optional[Any] = None,
        grammar: Optional[str] = None,
    ) -> str:
        """Generate text from a prompt with optional GBNF grammar constraints.

        Args:
            prompt: User prompt
            temperature: Sampling temperature (default: from spec)
            max_tokens: Max tokens to generate (default: from spec)
            system_prompt: Optional system prompt
            pydantic_model: Pydantic model to auto-generate GBNF grammar (mutually exclusive with grammar)
            grammar: Pre-generated GBNF grammar string (mutually exclusive with pydantic_model)

        Returns:
            Generated text constrained by grammar if provided

        """
        import requests

        temp = temperature if temperature is not None else self.spec.default_temperature
        max_tok = (
            max_tokens if max_tokens is not None else self.spec.capabilities.get("max_tokens", 2000)
        )

        # Auto-generate grammar from Pydantic model if provided
        if pydantic_model is not None and grammar is None:
            from maxwell.pydantic_gbnf import generate_gbnf_grammar_and_documentation

            grammar, _ = generate_gbnf_grammar_and_documentation([pydantic_model])
            logger.debug(f"Auto-generated GBNF grammar from {pydantic_model.__name__}")
        elif pydantic_model is not None and grammar is not None:
            raise ValueError("Cannot specify both pydantic_model and grammar - choose one")

        # Build messages
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        # Build request payload
        payload = {
            "model": self.spec.model,
            "messages": messages,
            "temperature": temp,
            "max_tokens": max_tok,
        }

        # Add grammar if provided (llama.cpp specific)
        if grammar and self.spec.backend == "llamacpp":
            payload["grammar"] = grammar

        # Make request (OpenAI-compatible)
        endpoint_url = f"{self.spec.api_base.rstrip('/')}/v1/chat/completions"
        response = requests.post(endpoint_url, json=payload, timeout=120)
        response.raise_for_status()

        data = response.json()

        # JSONL logging for debugging
        import json as json_module
        import os
        from pathlib import Path

        # Create logs directory relative to current working directory (can be disabled with NO_JSONL_LOGGING env var)
        if os.getenv("NO_JSONL_LOGGING"):
            return data["choices"][0]["message"]["content"]

        # Use execution directory for logs (current working directory)
        base_dir = Path.cwd() / ".maxwell"
        log_dir = base_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Create JSONL log file - use session ID from environment or generate workflow-specific name
        import datetime
        import sys

        # Try to get session ID from environment or infer from calling script
        session_id = os.getenv("LLM_SESSION_ID")
        if not session_id:
            # Infer from calling script name
            calling_script = "unknown"
            if len(sys.argv) > 0:
                script_path = Path(sys.argv[0])
                calling_script = script_path.stem

            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            session_id = f"{calling_script}_{timestamp}"

        jsonl_file = log_dir / f"{session_id}.jsonl"

        logger.info(f"JSONL logging enabled: {jsonl_file}")

        # Log request/response pair
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "model": self.spec.model,
            "request": messages,
            "response": data,
            "response_raw": data,
            "grammar_used": grammar is not None,
        }

        with open(jsonl_file, "a", encoding="utf-8") as f:
            f.write(json_module.dumps(log_entry) + "\n")

        return data["choices"][0]["message"]["content"]


def get_lm(
    name: Optional[str] = None,
    prompt: Optional[str] = None,
    max_completion: int = 512,
    time_cost_weight: float = 1.0,
    **selection_kwargs,
) -> LLMClient:
    """Get a language model (LM) client from the pool.

    Args:
        name: Specific LM name, or None to select by capabilities
        prompt: Optional prompt for intelligent routing (enables scheduler)
        max_completion: Expected completion tokens (used with prompt)
        time_cost_weight: How much to value speed vs cost (0-10, used with prompt)
        **selection_kwargs: Capability filters (min_speed, reasoning, vision, etc.)

    Returns:
        LLMClient ready to use

    Examples:
        # Get default (fastest) LM
        lm = get_lm()

        # Get specific LM by name
        lm = get_lm("qwen-coder-30b")

        # Intelligent routing based on prompt size
        lm = get_lm(prompt="Write a function...", time_cost_weight=1.0)

        # Select by capabilities
        lm = get_lm(reasoning=True, min_speed=50)
        lm = get_lm(vision=True)

    """
    pool = LLMPool.from_registry()

    if name:
        spec = pool.get_lm(name)
    elif prompt:
        # Use intelligent routing when prompt is provided
        spec = pool.select_optimal_llm(
            prompt, max_completion=max_completion, time_cost_weight=time_cost_weight, **selection_kwargs
        )
    elif selection_kwargs:
        spec = pool.select_llm(**selection_kwargs)
    else:
        spec = pool.get_fastest_llm()

    if not spec:
        raise ValueError(f"No LM found matching criteria: name={name}, {selection_kwargs}")

    return LLMClient(spec)


def get_embedding(name: str = "default") -> EmbeddingSpec:
    """Get an embedding model from the pool.

    Args:
        name: Embedding name or tag (default: "default")

    Returns:
        EmbeddingSpec with embed() method

    Examples:
        # Get default embedding
        emb = get_embedding()
        vector = emb.embed("some text")

        # Get specific embedding by name
        emb = get_embedding("qwen-embed-4b")

    """
    pool = LLMPool.from_registry()
    spec = pool.get_embedding(name)

    if not spec:
        raise ValueError(f"Embedding '{name}' not found. Available: {pool.list_embeddings()}")

    return spec


if __name__ == "__main__":
    # Test loading
    pool = LLMPool.from_registry()

    # Test selection
    fast_llm = pool.get_fastest_llm()

    vision_llm = pool.select_llm(vision=True)

    # Test client
    client = LLMClient(fast_llm)
    result = client.generate("Write a haiku about refactoring code.")
```

---
### File: src/maxwell/mcp_server.py

```python
"""MCP server for Maxwell workflows.

Exposes all registered Maxwell workflows as MCP tools with auto-generated schemas
from workflow metadata and docstrings.

Usage:
    # Stdio mode (for Claude Desktop):
    python -m maxwell.mcp_server

    # Or as module:
    from maxwell.mcp_server import create_server
    server = create_server()
"""

import asyncio
import logging
from pathlib import Path
from typing import Any

# MCP SDK imports
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from maxwell.api import execute_workflow, list_workflows, workflow_result_to_dict

logger = logging.getLogger(__name__)

__all__ = ["create_server", "main"]


def create_server() -> Server:
    """Create and configure MCP server with all Maxwell workflows as tools.

    Returns:
        Configured MCP Server instance

    """
    server = Server("maxwell")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List all available Maxwell workflows as MCP tools."""
        tools = []

        for workflow_meta in list_workflows():
            # Build parameter schema from workflow CLI parameters
            properties = {}
            required = []

            # Add project_root parameter (optional for all workflows)
            properties["project_root"] = {
                "type": "string",
                "description": "Project root directory (defaults to current directory)",
            }

            # Add workflow-specific parameters
            for param in workflow_meta.parameters:
                param_name = param["name"]
                param_type = param.get("type", str).__name__

                # Map Python types to JSON schema types
                json_type = {
                    "str": "string",
                    "int": "number",
                    "float": "number",
                    "bool": "boolean",
                }.get(param_type, "string")

                properties[param_name] = {
                    "type": json_type,
                    "description": param.get("help", f"Parameter: {param_name}"),
                }

                # Add default if specified
                if "default" in param:
                    properties[param_name]["default"] = param["default"]

                # Mark as required if specified
                if param.get("required", False):
                    required.append(param_name)

            # Create tool schema
            tool = Tool(
                name=f"maxwell_{workflow_meta.workflow_id.replace('-', '_')}",
                description=(
                    f"{workflow_meta.name}: {workflow_meta.description}\n\n"
                    f"Category: {workflow_meta.category}\n"
                    f"Tags: {', '.join(workflow_meta.tags)}\n"
                    f"Version: {workflow_meta.version}"
                ),
                inputSchema={
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            )

            tools.append(tool)

        logger.info(f"Registered {len(tools)} Maxwell workflows as MCP tools")
        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: Any) -> list[TextContent]:
        """Execute a Maxwell workflow tool.

        Args:
            name: Tool name (maxwell_{workflow_id})
            arguments: Tool arguments including project_root and workflow parameters

        Returns:
            List of TextContent with workflow results

        """
        # Extract workflow ID from tool name
        if not name.startswith("maxwell_"):
            return [
                TextContent(
                    type="text",
                    text=f"Error: Unknown tool '{name}'. All Maxwell tools start with 'maxwell_'",
                )
            ]

        workflow_id = name[8:].replace("_", "-")  # Remove 'maxwell_' prefix and convert underscores

        # Extract parameters
        project_root_str = arguments.get("project_root")
        project_root = Path(project_root_str) if project_root_str else Path.cwd()

        # Build context from remaining arguments
        context = {k: v for k, v in arguments.items() if k != "project_root"}

        logger.info(f"Executing workflow {workflow_id} with context: {context}")

        try:
            # Execute workflow
            result = execute_workflow(workflow_id, project_root, context)

            # Convert result to dict
            result_dict = workflow_result_to_dict(result)

            # Format response based on status
            if result.status.value == "completed":
                # Success - return formatted results
                response_parts = [
                    f"[OK] {workflow_id} completed successfully\n",
                    "\n**Metrics:**",
                    f"- Files processed: {result.metrics.files_processed}",
                    (
                        f"- Execution time: {result.metrics.execution_time_seconds:.2f}s"
                        if result.metrics.execution_time_seconds
                        else ""
                    ),
                ]

                # Add custom metrics if present
                if result.metrics.custom_metrics:
                    response_parts.append("\n**Details:**")
                    for key, value in result.metrics.custom_metrics.items():
                        response_parts.append(f"- {key}: {value}")

                # Add artifacts summary if present
                if result.artifacts:
                    response_parts.append(f"\n**Artifacts:** {', '.join(result.artifacts.keys())}")

                # Add formatted output if present (for validate workflow, etc.)
                if "formatted_output" in result.artifacts:
                    response_parts.append(f"\n\n{result.artifacts['formatted_output']}")

                response_text = "\n".join(filter(None, response_parts))

            elif result.status.value == "failed":
                # Failure - return error
                response_text = (
                    f"[FAILED] {workflow_id} failed\n\n"
                    f"**Error:** {result.error_message}\n\n"
                    f"Check logs for more details."
                )

            else:
                # Other status - return generic info
                response_text = (
                    f"Workflow {workflow_id} finished with status: {result.status.value}\n"
                    f"See full result for details."
                )

            # Return both formatted text and full JSON result
            return [
                TextContent(type="text", text=response_text),
                TextContent(
                    type="text", text=f"\n\n**Full Result (JSON):**\n```json\n{result_dict}\n```"
                ),
            ]

        except Exception as e:
            logger.error(f"Error executing workflow {workflow_id}: {e}", exc_info=True)
            return [
                TextContent(
                    type="text", text=f"[ERROR] Error executing workflow {workflow_id}: {str(e)}"
                )
            ]

    return server


async def main():
    """Run MCP server in stdio mode."""
    # Configure logging
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    logger.info("Starting Maxwell MCP server...")

    # Create and run server
    server = create_server()

    # Run stdio server
    async with stdio_server() as (read_stream, write_stream):
        logger.info("Maxwell MCP server running on stdio")
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
```

---
### File: src/maxwell/pydantic_gbnf.py

```python
"""Generic Pydantic to GBNF Grammar Converter.

This module provides utilities to convert Pydantic models to GBNF (Generalized Backus-Naur Form)
grammar for structured LLM output parsing with llama.cpp.

Key Features:
- Automatic grammar generation from Pydantic models
- Support for nested models, lists, unions, enums
- Markdown code block and triple-quoted string handling
- Compatible with llama.cpp grammar constraints

Usage:
    from pydantic import BaseModel
    from maxwell.pydantic_gbnf import generate_gbnf_grammar_and_documentation

    class MyModel(BaseModel):
        name: str
        count: int
        tags: List[str]

    grammar, docs = generate_gbnf_grammar_and_documentation([MyModel])

    # Use grammar with llama.cpp
    llm.generate(prompt, grammar=grammar)
"""

from __future__ import annotations

import inspect
import re
from enum import Enum
from inspect import isclass
from typing import TYPE_CHECKING, Any, Optional, Union, get_args, get_origin

from pydantic import BaseModel

if TYPE_CHECKING:
    from types import GenericAlias
else:
    # python 3.8 compat
    from typing import _GenericAlias as GenericAlias


class PydanticDataType(Enum):
    """Defines the data types supported by the grammar_generator."""

    STRING = "string"
    TRIPLE_QUOTED_STRING = "triple_quoted_string"
    MARKDOWN_CODE_BLOCK = "markdown_code_block"
    BOOLEAN = "boolean"
    INTEGER = "integer"
    FLOAT = "float"
    OBJECT = "object"
    ARRAY = "array"
    ENUM = "enum"
    ANY = "any"
    NULL = "null"
    CUSTOM_CLASS = "custom-class"
    CUSTOM_DICT = "custom-dict"
    SET = "set"


def map_pydantic_type_to_gbnf(pydantic_type: type[Any]) -> str:
    """Map a Pydantic type to its GBNF grammar rule name."""
    if isclass(pydantic_type) and issubclass(pydantic_type, str):
        return PydanticDataType.STRING.value
    elif isclass(pydantic_type) and issubclass(pydantic_type, bool):
        return PydanticDataType.BOOLEAN.value
    elif isclass(pydantic_type) and issubclass(pydantic_type, int):
        return PydanticDataType.INTEGER.value
    elif isclass(pydantic_type) and issubclass(pydantic_type, float):
        return PydanticDataType.FLOAT.value
    elif isclass(pydantic_type) and issubclass(pydantic_type, Enum):
        return PydanticDataType.ENUM.value
    elif isclass(pydantic_type) and issubclass(pydantic_type, BaseModel):
        return format_model_and_field_name(pydantic_type.__name__)
    elif get_origin(pydantic_type) is list:
        element_type = get_args(pydantic_type)[0]
        return f"{map_pydantic_type_to_gbnf(element_type)}-list"
    elif get_origin(pydantic_type) is set:
        element_type = get_args(pydantic_type)[0]
        return f"{map_pydantic_type_to_gbnf(element_type)}-set"
    elif get_origin(pydantic_type) is Union:
        union_types = get_args(pydantic_type)
        union_rules = [map_pydantic_type_to_gbnf(ut) for ut in union_types]
        return f"union-{'-or-'.join(union_rules)}"
    elif get_origin(pydantic_type) is Optional:
        element_type = get_args(pydantic_type)[0]
        return f"optional-{map_pydantic_type_to_gbnf(element_type)}"
    elif isclass(pydantic_type):
        return f"{PydanticDataType.CUSTOM_CLASS.value}-{format_model_and_field_name(pydantic_type.__name__)}"
    elif get_origin(pydantic_type) is dict:
        key_type, value_type = get_args(pydantic_type)
        return f"custom-dict-key-type-{format_model_and_field_name(map_pydantic_type_to_gbnf(key_type))}-value-type-{format_model_and_field_name(map_pydantic_type_to_gbnf(value_type))}"
    else:
        return "unknown"


def format_model_and_field_name(model_name: str) -> str:
    """Format model/field names for GBNF rules (CamelCase -> kebab-case)."""
    parts = re.findall("[A-Z][^A-Z]*", model_name)
    if not parts:
        return model_name.lower().replace("_", "-")
    return "-".join(part.lower().replace("_", "-") for part in parts)


def generate_list_rule(element_type):
    """Generate a GBNF rule for a list of a given element type."""
    rule_name = f"{map_pydantic_type_to_gbnf(element_type)}-list"
    element_rule = map_pydantic_type_to_gbnf(element_type)
    list_rule = rf'{rule_name} ::= "["  {element_rule} (","  {element_rule})* "]"'
    return list_rule


def generate_gbnf_rule_for_type(
    model_name,
    field_name,
    field_type,
    is_optional,
    processed_models,
    created_rules,
    field_info=None,
) -> tuple[str, list[str]]:
    """Generate GBNF rule for a given field type."""
    rules = []
    field_name = format_model_and_field_name(field_name)
    gbnf_type = map_pydantic_type_to_gbnf(field_type)

    if isclass(field_type) and issubclass(field_type, BaseModel):
        nested_model_name = format_model_and_field_name(field_type.__name__)
        nested_model_rules, _ = generate_gbnf_grammar(field_type, processed_models, created_rules)
        rules.extend(nested_model_rules)
        gbnf_type, rules = nested_model_name, rules
    elif isclass(field_type) and issubclass(field_type, Enum):
        enum_values = [f'"\\"{e.value}\\""' for e in field_type]
        enum_rule = f"{model_name}-{field_name} ::= {' | '.join(enum_values)}"
        rules.append(enum_rule)
        gbnf_type, rules = model_name + "-" + field_name, rules
    elif get_origin(field_type) is list:
        element_type = get_args(field_type)[0]
        element_rule_name, additional_rules = generate_gbnf_rule_for_type(
            model_name,
            f"{field_name}-element",
            element_type,
            is_optional,
            processed_models,
            created_rules,
        )
        rules.extend(additional_rules)
        array_rule = f"""{model_name}-{field_name} ::= "[" ws {element_rule_name} ("," ws {element_rule_name})*  "]" """
        rules.append(array_rule)
        gbnf_type, rules = model_name + "-" + field_name, rules
    elif get_origin(field_type) is set:
        element_type = get_args(field_type)[0]
        element_rule_name, additional_rules = generate_gbnf_rule_for_type(
            model_name,
            f"{field_name}-element",
            element_type,
            is_optional,
            processed_models,
            created_rules,
        )
        rules.extend(additional_rules)
        array_rule = f"""{model_name}-{field_name} ::= "[" ws {element_rule_name} ("," ws {element_rule_name})*  "]" """
        rules.append(array_rule)
        gbnf_type, rules = model_name + "-" + field_name, rules
    elif gbnf_type.startswith("union-"):
        union_types = get_args(field_type)
        union_rules = []

        for union_type in union_types:
            if isinstance(union_type, GenericAlias):
                union_gbnf_type, union_rules_list = generate_gbnf_rule_for_type(
                    model_name, field_name, union_type, False, processed_models, created_rules
                )
                union_rules.append(union_gbnf_type)
                rules.extend(union_rules_list)
            elif not issubclass(union_type, type(None)):
                union_gbnf_type, union_rules_list = generate_gbnf_rule_for_type(
                    model_name, field_name, union_type, False, processed_models, created_rules
                )
                union_rules.append(union_gbnf_type)
                rules.extend(union_rules_list)

        if len(union_rules) == 1:
            union_grammar_rule = (
                f"{model_name}-{field_name}-optional ::= {' | '.join(union_rules)} | null"
            )
        else:
            union_grammar_rule = f"{model_name}-{field_name}-union ::= {' | '.join(union_rules)}"
        rules.append(union_grammar_rule)
        gbnf_type = (
            f"{model_name}-{field_name}-optional"
            if len(union_rules) == 1
            else f"{model_name}-{field_name}-union"
        )
    else:
        gbnf_type, rules = gbnf_type, []

    return gbnf_type, rules


def generate_gbnf_grammar(
    model: type[BaseModel],
    processed_models: set[type[BaseModel]],
    created_rules: dict[str, list[str]],
) -> tuple[list[str], bool]:
    """Generate GBNF grammar for a given Pydantic model."""
    if model in processed_models:
        return [], False

    processed_models.add(model)
    model_name = format_model_and_field_name(model.__name__)

    if not issubclass(model, BaseModel):
        if hasattr(model, "__annotations__") and model.__annotations__:
            model_fields = {name: (typ, ...) for name, typ in model.__annotations__.items()}
        else:
            init_signature = inspect.signature(model.__init__)
            parameters = init_signature.parameters
            model_fields = {
                name: (param.annotation, param.default)
                for name, param in parameters.items()
                if name != "self"
            }
    else:
        model_fields = model.__annotations__

    model_rule_parts = []
    nested_rules = []

    for field_name, field_info in model_fields.items():
        if not issubclass(model, BaseModel):
            field_type, default_value = field_info
            is_optional = (default_value is not inspect.Parameter.empty) and (
                default_value is not Ellipsis
            )
        else:
            field_type = field_info
            field_info = model.model_fields[field_name]
            is_optional = field_info.is_required is False and get_origin(field_type) is Optional

        rule_name, additional_rules = generate_gbnf_rule_for_type(
            model_name,
            format_model_and_field_name(field_name),
            field_type,
            is_optional,
            processed_models,
            created_rules,
            field_info,
        )

        if rule_name not in created_rules:
            created_rules[rule_name] = additional_rules
        model_rule_parts.append(f' ws "\\"{field_name}\\"" ":" ws {rule_name}')
        nested_rules.extend(additional_rules)

    fields_joined = r' "," "\n" '.join(model_rule_parts)
    model_rule = rf'{model_name} ::= "{{" "\n" {fields_joined} "\n" ws "}}"'

    all_rules = [model_rule] + nested_rules
    return all_rules, False


def generate_gbnf_grammar_from_pydantic_models(
    models: list[type[BaseModel]],
    outer_object_name: str | None = None,
    outer_object_content: str | None = None,
    list_of_outputs: bool = False,
) -> str:
    """Generate GBNF Grammar from Pydantic Models."""
    processed_models: set[type[BaseModel]] = set()
    all_rules = []
    created_rules: dict[str, list[str]] = {}

    if outer_object_name is None:
        for model in models:
            model_rules, _ = generate_gbnf_grammar(model, processed_models, created_rules)
            all_rules.extend(model_rules)

        if list_of_outputs:
            root_rule = (
                r'root ::= (" "| "\n") "[" ws grammar-models ("," ws grammar-models)* ws "]"' + "\n"
            )
        else:
            root_rule = r'root ::= (" "| "\n") grammar-models' + "\n"
        root_rule += "grammar-models ::= " + " | ".join(
            [format_model_and_field_name(model.__name__) for model in models]
        )
        all_rules.insert(0, root_rule)
        return "\n".join(all_rules)
    elif outer_object_name is not None:
        if list_of_outputs:
            root_rule = (
                rf'root ::= (" "| "\n") "[" ws {format_model_and_field_name(outer_object_name)} ("," ws {format_model_and_field_name(outer_object_name)})* ws "]"'
                + "\n"
            )
        else:
            root_rule = f"root ::= {format_model_and_field_name(outer_object_name)}\n"

        model_rule = rf'{format_model_and_field_name(outer_object_name)} ::= (" "| "\n") "{{" ws "\"{outer_object_name}\""  ":" ws grammar-models'

        fields_joined = " | ".join(
            [rf"{format_model_and_field_name(model.__name__)}-grammar-model" for model in models]
        )

        grammar_model_rules = f"\ngrammar-models ::= {fields_joined}"
        mod_rules = []
        for model in models:
            mod_rule = rf"{format_model_and_field_name(model.__name__)}-grammar-model ::= "
            mod_rule += (
                rf'"\"{model.__name__}\"" "," ws "\"{outer_object_content}\"" ":" ws {format_model_and_field_name(model.__name__)}'
                + "\n"
            )
            mod_rules.append(mod_rule)
        grammar_model_rules += "\n" + "\n".join(mod_rules)

        for model in models:
            model_rules, has_special_string = generate_gbnf_grammar(
                model, processed_models, created_rules
            )

            if not has_special_string:
                model_rules[0] += r'"\n" ws "}"'

            all_rules.extend(model_rules)

        all_rules.insert(0, root_rule + model_rule + grammar_model_rules)
        return "\n".join(all_rules)


def get_primitive_grammar(grammar):
    """Returns the needed GBNF primitive grammar for a given GBNF grammar string."""
    type_list: list[type[object]] = []
    if "string-list" in grammar:
        type_list.append(str)
    if "boolean-list" in grammar:
        type_list.append(bool)
    if "integer-list" in grammar:
        type_list.append(int)
    if "float-list" in grammar:
        type_list.append(float)
    additional_grammar = [generate_list_rule(t) for t in type_list]
    primitive_grammar = r"""
boolean ::= "true" | "false"
null ::= "null"
string ::= "\"" (
        [^"\\] |
        "\\" (["\\/bfnrt] | "u" [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F])
      )* "\"" ws
ws ::= ([ \t\n] ws)?
float ::= ("-"? ([0-9] | [1-9] [0-9]*)) ("." [0-9]+)? ([eE] [-+]? [0-9]+)? ws

integer ::= [0-9]+"""

    return "\n" + "\n".join(additional_grammar) + primitive_grammar


def remove_empty_lines(string):
    """Remove empty lines from a string."""
    lines = string.splitlines()
    non_empty_lines = [line for line in lines if line.strip() != ""]
    string_no_empty_lines = "\n".join(non_empty_lines)
    return string_no_empty_lines


def generate_gbnf_grammar_and_documentation(
    pydantic_model_list,
    outer_object_name: str | None = None,
    outer_object_content: str | None = None,
    model_prefix: str = "Output Model",
    fields_prefix: str = "Output Fields",
    list_of_outputs: bool = False,
    documentation_with_field_description=True,
):
    """Generate GBNF grammar and documentation for a list of Pydantic models.

    Args:
        pydantic_model_list: List of Pydantic model classes.
        outer_object_name: Outer object name for the GBNF grammar.
        outer_object_content: Content for the outer rule in the GBNF grammar.
        model_prefix: Prefix for the model section in the documentation.
        fields_prefix: Prefix for the fields section in the documentation.
        list_of_outputs: Whether the output is a list of items.
        documentation_with_field_description: Include field descriptions in the documentation.

    Returns:
        tuple: GBNF grammar string, documentation string.

    """
    grammar = generate_gbnf_grammar_from_pydantic_models(
        pydantic_model_list, outer_object_name, outer_object_content, list_of_outputs
    )
    grammar = remove_empty_lines(grammar + get_primitive_grammar(grammar))

    # Generate simple documentation
    documentation = f"# {model_prefix}\n\n"
    for model in pydantic_model_list:
        documentation += f"## {model.__name__}\n\n"
        documentation += f"{fields_prefix}:\n"
        for field_name, field_type in model.__annotations__.items():
            documentation += f"- {field_name}: {field_type}\n"
        documentation += "\n"

    return grammar, documentation
```

---
### File: src/maxwell/registry.py

```python
"""Workflow registry for managing available workflows.

Simple registration system for BaseWorkflow subclasses.
Workflows must properly inherit from BaseWorkflow and implement required methods.

Supports plugin loading from:
- ~/.maxwell/plugins/ (global plugins)
- <project>/.maxwell/plugins/ (project-specific plugins)

Plugin Types:
- Python plugins: .py files with BaseWorkflow subclasses
- Script plugins: Executable scripts with .json metadata files

maxwell/src/maxwell/registry.py
"""

import importlib.util
import json
import logging
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

from .workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)

__all__ = ["WorkflowRegistry", "register_workflow"]


@dataclass(frozen=True)
class ScriptWorkflowInputs(WorkflowInputs):
    """Generic inputs for script-based workflows."""

    pass


@dataclass(frozen=True)
class ScriptWorkflowOutputs(WorkflowOutputs):
    """Generic outputs for script-based workflows."""

    stdout: str
    stderr: str
    exit_code: int


class ScriptWorkflow(BaseWorkflow):
    """Adapter for executing external scripts as workflows."""

    InputSchema = ScriptWorkflowInputs
    OutputSchema = ScriptWorkflowOutputs

    def __init__(self, script_path: Path, metadata: Dict[str, Any]):
        """Initialize script workflow from metadata.

        Args:
            script_path: Path to executable script
            metadata: Workflow metadata (workflow_id, name, description, etc.)
        """
        self.script_path = script_path
        self.workflow_id = metadata["workflow_id"]
        self.name = metadata.get("name", self.workflow_id)
        self.description = metadata.get("description", "External script workflow")
        self.version = metadata.get("version", "1.0")
        self.category = metadata.get("category", "external")
        self.tags = set(metadata.get("tags", ["external", "script"]))
        self._parameters = metadata.get("parameters", [])
        super().__init__()

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Return CLI parameters from metadata."""
        return self._parameters

    def get_required_inputs(self) -> List[str]:
        """Return required inputs from parameters."""
        return [
            p["name"] for p in self._parameters if p.get("required", False)
        ]

    def get_produced_outputs(self) -> List[str]:
        """Script workflows always produce stdout/stderr/exit_code."""
        return ["stdout", "stderr", "exit_code"]

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Return default config for script workflows."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=300,
            parameters={"root_dir": str(root_dir)},
        )

    def execute(
        self, project_root: Path, context: Dict[str, Any]
    ) -> WorkflowResult:
        """Execute the external script."""
        try:
            # Build command with arguments
            cmd = [str(self.script_path)]

            # Add arguments from context
            for param in self._parameters:
                param_name = param["name"]
                if param_name in context:
                    value = context[param_name]
                    cmd.extend([f"--{param_name}", str(value)])

            # Execute script
            logger.info(f"Executing script workflow: {' '.join(cmd)}")
            result = subprocess.run(
                cmd,
                cwd=str(project_root),
                capture_output=True,
                text=True,
                timeout=300,
            )

            outputs = ScriptWorkflowOutputs(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.returncode,
            )

            # Determine status based on exit code
            status = (
                WorkflowStatus.COMPLETED
                if result.returncode == 0
                else WorkflowStatus.FAILED
            )

            return self.create_result(
                outputs=outputs,
                status=status,
                error_message=result.stderr if result.returncode != 0 else None,
            )

        except subprocess.TimeoutExpired:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message="Script execution timed out",
            )
        except Exception as e:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Script execution failed: {str(e)}",
            )


class WorkflowRegistry:
    """Registry for managing available workflows."""

    def __init__(self):
        self._workflows: Dict[str, Type[BaseWorkflow]] = {}
        self._loaded = False

    def register(self, workflow_class: Type[BaseWorkflow]) -> None:
        """Register a workflow class that inherits from BaseWorkflow."""
        if not issubclass(workflow_class, BaseWorkflow):
            raise TypeError(
                f"{workflow_class.__name__} must inherit from BaseWorkflow"
            )

        # Create temporary instance to get workflow_id
        temp_instance = workflow_class()
        workflow_id = temp_instance.workflow_id

        if not workflow_id:
            raise ValueError(
                f"Workflow {workflow_class.__name__} must define workflow_id"
            )

        if workflow_id in self._workflows:
            logger.warning(f"Overwriting existing workflow: {workflow_id}")

        self._workflows[workflow_id] = workflow_class
        logger.debug(f"Registered workflow: {workflow_id}")

    def get_workflow(self, workflow_id: str) -> Optional[Type[BaseWorkflow]]:
        """Get workflow class by ID."""
        self._ensure_loaded()
        return self._workflows.get(workflow_id)

    def get_all_workflows(self) -> Dict[str, Type[BaseWorkflow]]:
        """Get all registered workflows."""
        self._ensure_loaded()
        return self._workflows.copy()

    def list_workflow_ids(self) -> List[str]:
        """List all workflow IDs."""
        self._ensure_loaded()
        return list(self._workflows.keys())

    def unregister(self, workflow_id: str) -> bool:
        """Unregister a workflow."""
        if workflow_id in self._workflows:
            del self._workflows[workflow_id]
            logger.debug(f"Unregistered workflow: {workflow_id}")
            return True
        return False

    def clear(self) -> None:
        """Clear all registered workflows."""
        self._workflows.clear()
        self._loaded = False
        logger.debug("Cleared all workflows from registry")

    def load_plugins(self, plugin_dirs: Optional[List[Path]] = None) -> None:
        """Load plugins from directories.

        Args:
            plugin_dirs: List of directories to search for plugins.
                        Defaults to ~/.maxwell/plugins/ and .maxwell/plugins/
        """
        if plugin_dirs is None:
            plugin_dirs = []
            # Global plugins
            global_plugins = Path.home() / ".maxwell" / "plugins"
            if global_plugins.exists():
                plugin_dirs.append(global_plugins)

            # Project-specific plugins
            project_plugins = Path.cwd() / ".maxwell" / "plugins"
            if project_plugins.exists():
                plugin_dirs.append(project_plugins)

        for plugin_dir in plugin_dirs:
            if not plugin_dir.exists():
                continue

            logger.debug(f"Loading plugins from {plugin_dir}")

            # Load Python plugins (.py files)
            for py_file in plugin_dir.glob("*.py"):
                if py_file.name.startswith("_"):
                    continue  # Skip private modules
                self._load_python_plugin(py_file)

            # Load script plugins (executable + .json metadata)
            for json_file in plugin_dir.glob("*.json"):
                script_path = json_file.with_suffix("")  # Remove .json extension
                if script_path.exists() and script_path.stat().st_mode & 0o111:
                    self._load_script_plugin(script_path, json_file)

    def _load_python_plugin(self, py_file: Path) -> None:
        """Load a Python plugin module."""
        try:
            module_name = f"maxwell_plugin_{py_file.stem}"
            spec = importlib.util.spec_from_file_location(
                module_name, str(py_file)
            )
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)

                # Find BaseWorkflow subclasses in the module
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if (
                        isinstance(attr, type)
                        and issubclass(attr, BaseWorkflow)
                        and attr is not BaseWorkflow
                    ):
                        self.register(attr)
                        logger.info(
                            f"Loaded Python plugin: {attr_name} from {py_file.name}"
                        )
        except Exception as e:
            logger.error(f"Failed to load Python plugin {py_file}: {e}")

    def _load_script_plugin(self, script_path: Path, metadata_path: Path) -> None:
        """Load an external script plugin with metadata."""
        try:
            with open(metadata_path) as f:
                metadata = json.load(f)

            if "workflow_id" not in metadata:
                logger.error(
                    f"Script plugin {script_path.name} missing 'workflow_id' in metadata"
                )
                return

            # Create a ScriptWorkflow wrapper class
            workflow_class = type(
                f"ScriptWorkflow_{metadata['workflow_id']}",
                (ScriptWorkflow,),
                {
                    "__init__": lambda self: ScriptWorkflow.__init__(
                        self, script_path, metadata
                    )
                },
            )

            self.register(workflow_class)
            logger.info(
                f"Loaded script plugin: {metadata['workflow_id']} from {script_path.name}"
            )

        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse metadata for {script_path.name}: {e}"
            )
        except Exception as e:
            logger.error(f"Failed to load script plugin {script_path}: {e}")

    def _ensure_loaded(self) -> None:
        """Ensure workflows are loaded (triggers plugin loading on first access)."""
        if not self._loaded:
            self.load_plugins()
            self._loaded = True


# Initialize single module-level registry instance
_workflow_registry = WorkflowRegistry()

# Export as workflow_registry for backward compatibility
workflow_registry = _workflow_registry


def get_workflow_registry() -> WorkflowRegistry:
    return _workflow_registry


def register_workflow(
    workflow_class: Type[BaseWorkflow],
) -> Type[BaseWorkflow]:
    """Decorator for registering workflows."""
    _workflow_registry.register(workflow_class)
    return workflow_class
```

---
### File: src/maxwell/reporting.py

```python
"""Comprehensive reporting system for maxwell analysis results.

Provides structured report generation with granular verbosity levels,
artifact management, hyperlinked reports, and multiple output formatters
for different consumers (humans, CI/CD, GitHub, LLMs).

maxwell/src/maxwell/reporting.py
"""

import json
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.workflows.validate.validators import BaseFormatter, Finding, Severity

__all__ = [
    "ReportGenerator",
    "ReportConfig",
    "VerbosityLevel",
    "NaturalLanguageFormatter",
    "JsonFormatter",
    "SarifFormatter",
    "LLMFormatter",
    "HumanFormatter",
    "BUILTIN_FORMATTERS",
    "FORMAT_CHOICES",
    "DEFAULT_FORMAT",
    "ExecutiveSummary",
    "PriorityAction",
    "TreeViolation",
    "Synthesis",
    "AnalysisResults",
    "FileAnalysisEntry",
    "ContentAnalysis",
    "TreeAnalysis",
]


class VerbosityLevel(Enum):
    """Report verbosity levels for different use cases."""

    EXECUTIVE = "executive"  # High-level summary for planning
    TACTICAL = "tactical"  # Actionable items for development
    DETAILED = "detailed"  # Comprehensive analysis with context
    FORENSIC = "forensic"  # Complete diagnostic information


@dataclass
class ExecutiveSummary:
    """High-level summary of analysis results."""

    overall_health: str
    critical_issues: int
    improvement_opportunities: int
    estimated_effort: str


@dataclass
class PriorityAction:
    """Priority action item from analysis."""

    title: str
    priority: str
    description: str
    effort_hours: str
    risk_if_ignored: str


@dataclass
class TreeViolation:
    """Organizational/tree structure violation."""

    violation_type: str
    message: str


@dataclass
class Synthesis:
    """Synthesis of all analysis results."""

    executive_summary: ExecutiveSummary
    priority_actions: List[PriorityAction]
    quick_wins: List[str] = field(default_factory=list)


@dataclass
class TreeAnalysis:
    """Tree/organizational analysis results."""

    quick_violations: List[TreeViolation] = field(default_factory=list)


@dataclass
class FileAnalysisEntry:
    """Single file analysis entry with findings."""

    file_path: str
    findings: List[Finding] = field(default_factory=list)


@dataclass
class ContentAnalysis:
    """Content/structural analysis results."""

    file_analyses: List[FileAnalysisEntry] = field(default_factory=list)


@dataclass
class AnalysisResults:
    """Complete analysis results container."""

    synthesis: Synthesis
    tree_analysis: Optional[TreeAnalysis] = None
    content_analysis: Optional[ContentAnalysis] = None
    deep_analysis: Optional[Dict[str, Any]] = None  # Keep as dict for flexibility


@dataclass
class ReportConfig:
    """Configuration for report generation."""

    # Output settings
    output_directory: Path
    report_name: str = "maxwell_analysis"
    verbosity_level: VerbosityLevel = VerbosityLevel.TACTICAL

    # Format settings
    formats: Optional[List[str]] = None  # ["markdown", "json", "html"]
    include_artifacts: bool = True
    create_index: bool = True

    # Content settings
    max_findings_per_category: int = 20
    include_raw_llm_responses: bool = False
    include_performance_metrics: bool = True

    # Navigation settings
    generate_hyperlinks: bool = True
    create_quick_nav: bool = True

    def __post_init__(self):
        if self.formats is None:
            self.formats = ["markdown", "html"]


class ReportGenerator:
    """Generates structured analysis reports with granular verbosity control."""

    def __init__(self, config: ReportConfig):
        self.config = config

    def generate_comprehensive_report(
        self, analysis_results: AnalysisResults, timestamp: Optional[str] = None
    ) -> Dict[str, Path]:
        """Generate comprehensive report with all artifacts."""
        if timestamp is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")

        # Create report directory structure
        report_dir = self.config.output_directory / f"{self.config.report_name}_{timestamp}"
        report_dir.mkdir(parents=True, exist_ok=True)

        generated_files = {}

        # Generate main report
        main_report_path = self._generate_main_report(analysis_results, report_dir, timestamp)
        generated_files["main_report"] = main_report_path

        # Generate artifacts if enabled
        if self.config.include_artifacts:
            artifact_paths = self._generate_artifacts(analysis_results, report_dir, timestamp)
            generated_files.update(artifact_paths)

        # Generate index/navigation if enabled
        if self.config.create_index:
            index_path = self._generate_index(report_dir, generated_files, timestamp)
            generated_files["index"] = index_path

        # Generate quick action plan
        quick_plan_path = self._generate_quick_action_plan(analysis_results, report_dir, timestamp)
        generated_files["quick_plan"] = quick_plan_path

        return generated_files

    def _generate_main_report(
        self, analysis_results: AnalysisResults, report_dir: Path, timestamp: str
    ) -> Path:
        """Generate main analysis report."""
        # Filter content based on verbosity level
        filtered_results = self._filter_by_verbosity(analysis_results)

        # Generate markdown content
        content = self._format_main_report_markdown(filtered_results, timestamp)

        # Save to file
        report_path = report_dir / "main_report.md"
        report_path.write_text(content, encoding="utf-8")

        return report_path

    def _format_main_report_markdown(
        self, analysis_results: AnalysisResults, timestamp: str
    ) -> str:
        """Format main report as markdown."""
        executive = analysis_results.synthesis.executive_summary
        priority_actions = analysis_results.synthesis.priority_actions

        content = f"""# Maxwell Analysis Report

Generated: {timestamp}
Verbosity Level: {self.config.verbosity_level.value}

## Executive Summary

- **Overall Health**: {executive.overall_health}
- **Critical Issues**: {executive.critical_issues}
- **Improvement Opportunities**: {executive.improvement_opportunities}
- **Estimated Effort**: {executive.estimated_effort}

## Priority Actions

"""

        for i, action in enumerate(priority_actions[:5], 1):
            content += f"""### {i}. {action.title} ({action.priority})

{action.description}

**Effort**: {action.effort_hours} hours
**Risk if ignored**: {action.risk_if_ignored}

"""

        # Add findings summary based on verbosity
        if self.config.verbosity_level != VerbosityLevel.EXECUTIVE:
            content += self._add_findings_section(analysis_results)

        return content

    def _add_findings_section(self, analysis_results: AnalysisResults) -> str:
        """Add findings section based on verbosity level."""
        content = "\n## Findings Summary\n\n"

        # Tree violations
        if analysis_results.tree_analysis:
            tree_violations = analysis_results.tree_analysis.quick_violations
            if tree_violations:
                content += f"### Organizational Issues ({len(tree_violations)})\n\n"
                for violation in tree_violations[: self.config.max_findings_per_category]:
                    content += f"- **{violation.violation_type}**: {violation.message}\n"
                content += "\n"

        # Content findings
        if analysis_results.content_analysis:
            content_findings = []
            for file_analysis in analysis_results.content_analysis.file_analyses:
                content_findings.extend(file_analysis.findings)

            if content_findings:
                content += f"### Structural Issues ({len(content_findings)})\n\n"
                for finding in content_findings[: self.config.max_findings_per_category]:
                    content += f"- **{finding.rule_id}**: {finding.message}\n"
                content += "\n"

        return content

    def _generate_artifacts(
        self, analysis_results: AnalysisResults, report_dir: Path, timestamp: str
    ) -> Dict[str, Path]:
        """Generate detailed artifacts for different analysis aspects."""
        artifacts_dir = report_dir / "artifacts"
        artifacts_dir.mkdir(exist_ok=True)

        artifact_paths = {}

        # Generate JSON artifacts for each analysis level
        if analysis_results.tree_analysis:
            tree_path = artifacts_dir / "organizational_analysis.json"
            # Convert dataclass to dict for JSON serialization using asdict()
            tree_data = {
                "quick_violations": [
                    asdict(v) for v in analysis_results.tree_analysis.quick_violations
                ]
            }
            tree_path.write_text(
                json.dumps(tree_data, indent=2, default=str),
                encoding="utf-8",
            )
            artifact_paths["organizational"] = tree_path

        if analysis_results.content_analysis:
            content_path = artifacts_dir / "structural_analysis.json"
            # Convert dataclass to dict for JSON serialization using asdict()
            content_data = {
                "file_analyses": [
                    {
                        "file_path": fa.file_path,
                        "findings": [asdict(f) for f in fa.findings],
                    }
                    for fa in analysis_results.content_analysis.file_analyses
                ]
            }
            content_path.write_text(
                json.dumps(content_data, indent=2, default=str),
                encoding="utf-8",
            )
            artifact_paths["structural"] = content_path

        if analysis_results.deep_analysis:
            arch_path = artifacts_dir / "architectural_analysis.json"
            arch_path.write_text(
                json.dumps(analysis_results.deep_analysis, indent=2, default=str),
                encoding="utf-8",
            )
            artifact_paths["architectural"] = arch_path

        return artifact_paths

    def _generate_quick_action_plan(
        self, analysis_results: AnalysisResults, report_dir: Path, timestamp: str
    ) -> Path:
        """Generate quick action plan for immediate development focus."""
        synthesis = analysis_results.synthesis

        quick_plan = f"""# Quick Action Plan
Generated: {timestamp}

## Immediate Actions (< 1 hour each)

"""

        # Add quick wins
        quick_wins = synthesis.quick_wins
        for i, win in enumerate(quick_wins[:5], 1):
            quick_plan += f"{i}. {win}\n"

        quick_plan += "\n## Priority Issues (requires planning)\n\n"

        # Add priority actions
        priority_actions = synthesis.priority_actions
        for action in priority_actions[:3]:
            quick_plan += f"### {action.title} ({action.priority})\n"
            quick_plan += f"**Effort**: {action.effort_hours} hours\n"
            quick_plan += f"**Description**: {action.description}\n\n"

        quick_plan_path = report_dir / "QUICK_ACTION_PLAN.md"
        quick_plan_path.write_text(quick_plan, encoding="utf-8")

        return quick_plan_path

    def _generate_index(
        self, report_dir: Path, generated_files: Dict[str, Path], timestamp: str
    ) -> Path:
        """Generate navigation index for the report."""
        index_content = f"""# Maxwell Analysis Report Index
Generated: {timestamp}

## Main Reports

- [[REPORT] Main Analysis Report](main_report.md)
- [[ROCKET] Quick Action Plan](QUICK_ACTION_PLAN.md)

## Detailed Artifacts

"""

        # Add artifact links
        artifact_types = {
            "organizational": "[BUILD] Organizational Analysis",
            "structural": "[TOOL] Structural Analysis",
            "architectural": "[ARCH] Architectural Analysis",
        }

        for artifact_key, description in artifact_types.items():
            if artifact_key in generated_files:
                artifact_path = generated_files[artifact_key]
                relative_path = f"artifacts/{artifact_path.name}"
                index_content += f"- [{description}]({relative_path})\n"

        index_content += f"\n---\n\nReport generated by maxwell at {timestamp}\n"

        index_path = report_dir / "index.md"
        index_path.write_text(index_content, encoding="utf-8")

        return index_path

    def _filter_by_verbosity(self, analysis_results: AnalysisResults) -> AnalysisResults:
        """Filter analysis results based on configured verbosity level."""
        if self.config.verbosity_level == VerbosityLevel.EXECUTIVE:
            # Only high-level summary and critical issues
            critical_actions = self._extract_critical_issues(analysis_results)
            return AnalysisResults(
                synthesis=Synthesis(
                    executive_summary=analysis_results.synthesis.executive_summary,
                    priority_actions=critical_actions,
                    quick_wins=[],
                )
            )

        elif self.config.verbosity_level == VerbosityLevel.TACTICAL:
            # Actionable items and priority information
            # Limit findings per category
            limited_content = None
            if analysis_results.content_analysis:
                limited_content = self._limit_content_findings(analysis_results.content_analysis)

            return AnalysisResults(
                synthesis=analysis_results.synthesis,
                tree_analysis=analysis_results.tree_analysis,
                content_analysis=limited_content,
                deep_analysis=analysis_results.deep_analysis,
            )

        else:  # DETAILED or FORENSIC
            # Most or all information
            return analysis_results

    def _extract_critical_issues(self, analysis_results: AnalysisResults) -> List[PriorityAction]:
        """Extract only critical/blocking issues for executive summary."""
        critical_issues = []

        # Check synthesis for critical items
        for action in analysis_results.synthesis.priority_actions:
            if action.priority in ["P0", "P1"]:
                critical_issues.append(action)

        return critical_issues

    def _limit_content_findings(self, content_analysis: ContentAnalysis) -> ContentAnalysis:
        """Limit content findings for tactical verbosity."""
        limited_file_analyses = []

        for file_analysis in content_analysis.file_analyses:
            # Keep only high-severity findings for tactical view
            high_severity = [
                f for f in file_analysis.findings if f.severity in [Severity.BLOCK, Severity.WARN]
            ]
            limited_file_analyses.append(
                FileAnalysisEntry(
                    file_path=file_analysis.file_path, findings=high_severity[:5]  # Limit to 5
                )
            )

        return ContentAnalysis(file_analyses=limited_file_analyses)


# ===== FORMATTERS =====
# Consolidated from formatters.py


class NaturalLanguageFormatter(BaseFormatter):
    """Natural language output formatter for humans and AI agents."""

    name = "natural"
    description = "Natural language output format optimized for human and AI agent consumption"

    def format_results(
        self, findings: List[Finding], summary: Dict[str, int], config: Optional[Any] = None
    ) -> str:
        """Format results for human reading."""
        if not findings:
            return "All checks passed!"

        # Get max display limit from config
        max_displayed = 50  # Default to 50 issues for readability (0 means no limit)
        # Config can be a dict (external API data) - .get() is acceptable here
        if config and isinstance(config, dict):
            max_displayed = config.get("max_displayed_issues", 50)

        # Group findings by severity
        by_severity = {Severity.BLOCK: [], Severity.WARN: [], Severity.INFO: []}

        for finding in findings:
            if finding.severity in by_severity:
                by_severity[finding.severity].append(finding)

        lines = []
        displayed_count = 0
        total_count = len(findings)

        # Add findings by severity (highest first)
        for severity in [Severity.BLOCK, Severity.WARN, Severity.INFO]:
            if by_severity[severity]:
                lines.append(f"\n{severity.value}:")

                severity_findings = by_severity[severity]
                for _, finding in enumerate(severity_findings):
                    if max_displayed > 0 and displayed_count >= max_displayed:
                        remaining_total = total_count - displayed_count
                        lines.append("")
                        lines.append(
                            f"  WARNING: Showing first {max_displayed} issues. {remaining_total} more found."
                        )
                        lines.append(
                            "  TIP: Set max_displayed_issues = 0 in pyproject.toml to show all issues."
                        )
                        break

                    location = (
                        f"{finding.file_path}:{finding.line}"
                        if finding.line > 0
                        else str(finding.file_path)
                    )
                    lines.append(f"  {finding.rule_id}: {finding.message} ({location})")
                    if finding.suggestion:
                        lines.append(f"    → {finding.suggestion}")

                    displayed_count += 1

                if max_displayed > 0 and displayed_count >= max_displayed:
                    break

        # Add summary with full counts
        total_errors = sum(1 for f in findings if f.severity == Severity.BLOCK)
        total_warnings = sum(1 for f in findings if f.severity == Severity.WARN)
        total_info = sum(1 for f in findings if f.severity == Severity.INFO)

        summary_line = (
            f"\nSummary: {total_errors} errors, {total_warnings} warnings, {total_info} info"
        )
        if max_displayed > 0 and total_count > max_displayed:
            summary_line += f" (showing first {min(max_displayed, total_count)} of {total_count})"

        lines.append(summary_line)

        return "\n".join(lines)


class JsonFormatter(BaseFormatter):
    """JSON output formatter for machine processing."""

    name = "json"
    description = "JSON output format for CI/tooling integration"

    def format_results(
        self, findings: List[Finding], summary: Dict[str, int], config: Optional[Any] = None
    ) -> str:
        """Format results as JSON."""
        result = {"summary": summary, "findings": [finding.to_dict() for finding in findings]}
        return json.dumps(result, indent=2, default=str)


class SarifFormatter(BaseFormatter):
    """SARIF output formatter for GitHub integration."""

    name = "sarif"
    description = "SARIF format for GitHub code scanning"

    def format_results(
        self, findings: List[Finding], summary: Dict[str, int], config: Optional[Any] = None
    ) -> str:
        """Format results as SARIF JSON."""
        rules = {}
        results = []

        for finding in findings:
            # Collect unique rules
            if finding.rule_id not in rules:
                rules[finding.rule_id] = {
                    "id": finding.rule_id,
                    "name": finding.rule_id,
                    "shortDescription": {"text": finding.message},
                    "defaultConfiguration": {
                        "level": self._severity_to_sarif_level(finding.severity)
                    },
                }

            # Add result
            result = {
                "ruleId": finding.rule_id,
                "level": self._severity_to_sarif_level(finding.severity),
                "message": {"text": finding.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": str(finding.file_path)},
                            "region": {
                                "startLine": max(1, finding.line),
                                "startColumn": max(1, finding.column),
                            },
                        }
                    }
                ],
            }

            if finding.suggestion:
                result["fixes"] = [{"description": {"text": finding.suggestion}}]

            results.append(result)

        sarif_output = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "maxwell",
                            "version": "0.1.2",
                            "informationUri": "https://github.com/mithranm/maxwell",
                            "rules": list(rules.values()),
                        }
                    },
                    "results": results,
                }
            ],
        }

        return json.dumps(sarif_output, separators=(",", ":"))

    def _severity_to_sarif_level(self, severity: Severity) -> str:
        """Convert maxwell severity to SARIF level."""
        # Mapping dict - .get() is legitimate for safe enum->string conversion
        mapping = {
            Severity.BLOCK: "error",
            Severity.WARN: "warning",
            Severity.INFO: "note",
            Severity.OFF: "none",
        }
        return mapping.get(severity, "warning")


class LLMFormatter(BaseFormatter):
    """LLM-optimized formatter for AI analysis."""

    name = "llm"
    description = "LLM-optimized format for AI analysis"

    def format_results(
        self, findings: List[Finding], summary: Dict[str, int], config: Optional[Any] = None
    ) -> str:
        """Format results for LLM analysis."""
        if not findings:
            return "No issues found."

        output = []
        for finding in findings:
            output.append(
                f"{finding.rule_id}: {finding.message} " f"({finding.file_path}:{finding.line})"
            )

        return "\n".join(output)


class HumanFormatter(NaturalLanguageFormatter):
    """Human-readable formatter (alias for NaturalLanguageFormatter)."""

    name = "human"
    description = "Human-readable format with colors and styling"


# Built-in report formatters
BUILTIN_FORMATTERS = {
    "natural": NaturalLanguageFormatter,
    "human": HumanFormatter,  # Separate class for plugin system compatibility
    "json": JsonFormatter,
    "sarif": SarifFormatter,
    "llm": LLMFormatter,
}

# Format choices for CLI - single source of truth
FORMAT_CHOICES = list(BUILTIN_FORMATTERS.keys())
DEFAULT_FORMAT = "natural"
```

---
### File: src/maxwell/rules.py

```python
"""Rule management system for maxwell.

Handles rule configuration, severity overrides, and policy management.

maxwell/src/maxwell/rules.py
"""

import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from maxwell.config import MaxwellConfig
from maxwell.workflows.validate.validators import BaseValidator, Severity, plugin_manager

logger = logging.getLogger(__name__)


class DefaultSeverity(Enum):
    """Predefined severity levels for consistency."""

    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"


__all__ = ["RuleEngine", "create_default_rule_config", "DefaultSeverity"]


class RuleEngine:
    """Manages rule configuration and policy decisions."""

    def __init__(self, config: MaxwellConfig):
        """Initialize rule engine with configuration.

        Args:
            config: Configuration object from pyproject.toml

        """
        self.config = config
        self._rule_overrides: dict[str, Severity] = {}
        self._enabled_plugins: Set[str] = set()
        self._load_rule_config()

    def _load_rule_config(self):
        """Load rule configuration from config."""
        # Load rule severity overrides
        rules_config = {}  # TODO: Update MaxwellConfig to include rules field
        if isinstance(rules_config, dict):
            for rule_id, setting in rules_config.items():
                if isinstance(setting, str):
                    try:
                        self._rule_overrides[rule_id] = Severity(setting.upper())
                    except ValueError as e:
                        logger.debug(
                            f"Invalid severity setting for rule {rule_id}: {setting} - {e}"
                        )
                        pass
                elif isinstance(setting, bool):
                    # Boolean: True=default severity, False=OFF
                    if not setting:
                        self._rule_overrides[rule_id] = Severity.OFF

        # Load disabled validators from ignore list
        ignore_codes = []  # TODO: Update MaxwellConfig to include ignore field
        if isinstance(ignore_codes, list):
            for rule_id in ignore_codes:
                if isinstance(rule_id, str):
                    self._rule_overrides[rule_id] = Severity.OFF

        # Load enabled plugins
        plugins_config = {}  # TODO: Update MaxwellConfig to include plugins field
        if isinstance(plugins_config, dict):
            enabled = plugins_config.get("enabled", ["maxwell.core"])
            if isinstance(enabled, list):
                self._enabled_plugins.update(enabled)
            elif isinstance(enabled, str):
                self._enabled_plugins.add(enabled)

    def is_rule_enabled(self, rule_id: str) -> bool:
        """Check if a rule is enabled (not set to OFF)."""
        severity = self._rule_overrides.get(rule_id)
        return severity != Severity.OFF if severity else True

    def get_rule_severity(self, rule_id: str, default: Severity = Severity.WARN) -> Severity:
        """Get effective severity for a rule."""
        # Primary: semantic rule IDs
        severity = self._rule_overrides.get(rule_id)
        if severity is not None:
            return severity

        return default

    def create_validator_instance(
        self, validator_class: type[BaseValidator]
    ) -> Optional[BaseValidator]:
        """Create validator instance with configured severity.

        Args:
            validator_class: Validator class to instantiate

        Returns:
            Validator instance or None if rule is disabled

        """
        if not self.is_rule_enabled(validator_class.rule_id):
            return None

        severity = self.get_rule_severity(validator_class.rule_id, validator_class.default_severity)

        return validator_class(severity=severity, config=self.config)

    def get_enabled_validators(self) -> List[BaseValidator]:
        """Get all enabled validator instances."""
        validators = []
        all_validators = plugin_manager.get_all_validators()

        for _, validator_class in all_validators.items():
            instance = self.create_validator_instance(validator_class)
            if instance:
                validators.append(instance)

        return validators

    def filter_enabled_validators(
        self, validator_classes: List[type[BaseValidator]]
    ) -> List[BaseValidator]:
        """Filter and instantiate only enabled validators from a list."""
        validators = []
        for validator_class in validator_classes:
            instance = self.create_validator_instance(validator_class)
            if instance:
                validators.append(instance)
        return validators

    def get_rule_summary(self) -> Dict[str, Any]:
        """Get summary of rule configuration."""
        all_validators = plugin_manager.get_all_validators()
        enabled_count = sum(1 for rule_id in all_validators.keys() if self.is_rule_enabled(rule_id))

        return {
            "total_rules": len(all_validators),
            "enabled_rules": enabled_count,
            "disabled_rules": len(all_validators) - enabled_count,
            "overrides": len(self._rule_overrides),
            "plugins": list(self._enabled_plugins),
        }


def create_default_rule_config() -> Dict[str, Any]:
    """Create default rule configuration for new projects."""
    return {
        "rules": {
            # Semantic rule IDs (primary system)
            "DOCSTRING-MISSING": DefaultSeverity.INFO.value,  # Missing docstring is just info
            "EXPORTS-MISSING-ALL": DefaultSeverity.WARN.value,  # Missing __all__ is warning
            "PRINT-STATEMENT": DefaultSeverity.WARN.value,  # Print statements are warnings
            "EMOJI-IN-STRING": DefaultSeverity.WARN.value,  # Emojis can cause encoding issues
            "TODO-FOUND": DefaultSeverity.INFO.value,  # TODOs are informational
            "PARAMETERS-KEYWORD-ONLY": DefaultSeverity.INFO.value,  # Parameter suggestions are info
        },
        "plugins": {"enabled": ["maxwell.core"]},
    }
```

---
### File: src/maxwell/storage.py

```python
"""Content-addressable storage for Maxwell.

Architecture:
1. Content hashing (SHA256) - deduplication
2. SQLite cache (~/.maxwell/cache.db) - hash → embedding
3. Distributed maps (.maxwell/map.json) - hash → locations
"""

import hashlib
import json
import logging
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ChunkLocation:
    """Location of a content chunk."""

    file_path: str  # Relative to project root
    line_start: int
    line_end: int
    size_bytes: int
    last_modified: int


@dataclass
class ChunkMetadata:
    """Metadata for a content chunk."""

    chunk_hash: str
    locations: List[ChunkLocation]
    content_preview: str  # First 500 chars


class EmbeddingCache:
    """Global embedding cache using SQLite."""

    def __init__(self, cache_dir: Optional[Path] = None):
        """Initialize cache.

        Args:
            cache_dir: Cache directory (defaults to ~/.maxwell/)

        """
        if cache_dir is None:
            cache_dir = Path.home() / ".maxwell"

        cache_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = cache_dir / "cache.db"

        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS embeddings (
                    chunk_hash TEXT PRIMARY KEY,
                    embedding BLOB NOT NULL,
                    created_at INTEGER NOT NULL,
                    last_accessed INTEGER NOT NULL,
                    access_count INTEGER DEFAULT 1
                )
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_last_accessed
                ON embeddings(last_accessed)
            """
            )

    def get(self, chunk_hash: str) -> Optional[np.ndarray]:
        """Get embedding from cache.

        Args:
            chunk_hash: SHA256 hash of content

        Returns:
            Embedding vector or None if not cached

        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT embedding FROM embeddings WHERE chunk_hash = ?", (chunk_hash,)
            )
            row = cursor.fetchone()

            if row is None:
                return None

            # Update access stats
            import time

            conn.execute(
                """UPDATE embeddings
                   SET last_accessed = ?, access_count = access_count + 1
                   WHERE chunk_hash = ?""",
                (int(time.time()), chunk_hash),
            )

            # Deserialize numpy array
            return np.frombuffer(row[0], dtype=np.float32)

    def put(self, chunk_hash: str, embedding: np.ndarray):
        """Store embedding in cache.

        Args:
            chunk_hash: SHA256 hash of content
            embedding: Embedding vector

        """
        import time

        now = int(time.time())

        # Serialize numpy array to bytes
        embedding_bytes = embedding.astype(np.float32).tobytes()

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO embeddings
                   (chunk_hash, embedding, created_at, last_accessed)
                   VALUES (?, ?, ?, ?)""",
                (chunk_hash, embedding_bytes, now, now),
            )

    def stats(self) -> Dict:
        """Get cache statistics."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """SELECT
                    COUNT(*) as total,
                    SUM(access_count) as total_accesses,
                    AVG(access_count) as avg_accesses
                   FROM embeddings"""
            )
            row = cursor.fetchone()

            return {
                "total_embeddings": row[0],
                "total_accesses": row[1] or 0,
                "avg_accesses": row[2] or 0,
                "db_size_mb": self.db_path.stat().st_size / 1024 / 1024,
            }


class ContentHasher:
    """Content hashing utilities."""

    @staticmethod
    def hash_content(content: str) -> str:
        """Hash content using SHA256.

        Args:
            content: Text content

        Returns:
            Hex digest of SHA256 hash

        """
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @staticmethod
    def hash_file(path: Path) -> str:
        """Hash file content.

        Args:
            path: File path

        Returns:
            Hex digest of SHA256 hash

        """
        content = path.read_text(errors="ignore")
        return ContentHasher.hash_content(content)


class LocalMap:
    """Distributed map tracking chunks in a directory."""

    def __init__(self, directory: Path):
        """Initialize map.

        Args:
            directory: Directory containing .maxwell/

        """
        self.directory = directory
        self.map_dir = directory / ".maxwell"
        self.map_path = self.map_dir / "map.json"

        self.chunks: Dict[str, ChunkLocation] = {}

        # Load existing map
        if self.map_path.exists():
            self.load()

    def load(self):
        """Load map from disk."""
        try:
            with open(self.map_path, "r") as f:
                data = json.load(f)

            self.chunks = {
                chunk_hash: ChunkLocation(**loc)
                for chunk_hash, loc in data.get("chunks", {}).items()
            }

            logger.debug(f"Loaded map with {len(self.chunks)} chunks")
        except Exception as e:
            logger.warning(f"Failed to load map from {self.map_path}: {e}")
            self.chunks = {}

    def save(self):
        """Save map to disk."""
        self.map_dir.mkdir(parents=True, exist_ok=True)

        data = {
            "version": "1.0",
            "chunks": {
                chunk_hash: {
                    "file_path": loc.file_path,
                    "line_start": loc.line_start,
                    "line_end": loc.line_end,
                    "size_bytes": loc.size_bytes,
                    "last_modified": loc.last_modified,
                }
                for chunk_hash, loc in self.chunks.items()
            },
        }

        with open(self.map_path, "w") as f:
            json.dump(data, f, indent=2)

        logger.debug(f"Saved map with {len(self.chunks)} chunks")

    def add_chunk(self, chunk_hash: str, location: ChunkLocation):
        """Add chunk to map."""
        self.chunks[chunk_hash] = location

    def get_location(self, chunk_hash: str) -> Optional[ChunkLocation]:
        """Get location of chunk."""
        return self.chunks.get(chunk_hash)

    def remove_chunk(self, chunk_hash: str):
        """Remove chunk from map."""
        self.chunks.pop(chunk_hash, None)


class ContentStore:
    """Content-addressable storage combining cache + maps."""

    def __init__(self, root: Path, cache_dir: Optional[Path] = None):
        """Initialize storage.

        Args:
            root: Project root directory
            cache_dir: Global cache directory

        """
        self.root = root
        # Cache removed - embeddings stored directly in Qdrant
        # self.cache = None  # Embeddings stored directly in Qdrant
        self.hasher = ContentHasher()

        # Track all maps in the project
        self.maps: Dict[Path, LocalMap] = {}

        # Initialize .maxwell directory structure
        self._init_maxwell_dir()

    def _init_maxwell_dir(self):
        """Initialize .maxwell directory with proper structure and gitignore.

        Storage tiers:
        - data/: JSONL files (committed to git)
        - indexes/: SQLite query layer (gitignored, rebuildable)
        - extracted/: Cached PDF extractions (gitignored, can be remote)
        - index/: Hierarchy JSON (gitignored, rebuildable)
        """
        maxwell_dir = self.root / ".maxwell"
        maxwell_dir.mkdir(parents=True, exist_ok=True)

        # Create subdirectories
        (maxwell_dir / "data").mkdir(exist_ok=True)
        (maxwell_dir / "indexes").mkdir(exist_ok=True)
        (maxwell_dir / "extracted").mkdir(exist_ok=True)
        (maxwell_dir / "index").mkdir(exist_ok=True)

        # Create .gitignore
        gitignore_path = maxwell_dir / ".gitignore"
        gitignore_content = """# Maxwell ephemeral indexes (rebuildable from data/)
indexes/
index/

# Content-addressable cache (local extractions, can be rebuilt or fetched from remote)
extracted/

# SQLite databases
*.db
*.db-shm
*.db-wal

# Keep the immutable data (JSONL graph files)
!data/
!data/*.jsonl
"""

        # Only write if doesn't exist or is different
        if not gitignore_path.exists() or gitignore_path.read_text() != gitignore_content:
            gitignore_path.write_text(gitignore_content)
            logger.info(f"Created {gitignore_path}")

    def get_map(self, directory: Path) -> LocalMap:
        """Get or create map for directory."""
        if directory not in self.maps:
            self.maps[directory] = LocalMap(directory)
        return self.maps[directory]

    def save_all_maps(self):
        """Save all maps to disk."""
        for map_obj in self.maps.values():
            map_obj.save()

    def add_file(self, file_path: Path, embedding: np.ndarray, content: str) -> str:
        """Add file to content store.

        Args:
            file_path: Absolute file path
            embedding: Pre-computed embedding
            content: File content

        Returns:
            Content hash

        """
        # Hash content
        chunk_hash = self.hasher.hash_content(content)

        # Cache embedding (idempotent) - DEPRECATED: embeddings stored in Qdrant
        # self.cache.put(chunk_hash, embedding)

        # Add to local map
        directory = file_path.parent
        local_map = self.get_map(directory)

        location = ChunkLocation(
            file_path=str(file_path.relative_to(self.root)),
            line_start=1,
            line_end=len(content.splitlines()),
            size_bytes=len(content.encode("utf-8")),
            last_modified=int(file_path.stat().st_mtime),
        )

        local_map.add_chunk(chunk_hash, location)

        return chunk_hash

    def get_embedding(self, chunk_hash: str) -> Optional[np.ndarray]:
        """Get embedding for chunk hash.

        DEPRECATED: Embeddings now stored directly in Qdrant.
        """
        # return self.cache.get(chunk_hash)
        return None  # Embeddings stored in Qdrant, not in local cache

    def find_locations(self, chunk_hash: str) -> List[ChunkLocation]:
        """Find all locations of a chunk across project."""
        locations = []

        for local_map in self.maps.values():
            loc = local_map.get_location(chunk_hash)
            if loc:
                locations.append(loc)

        return locations
```

---
### File: src/maxwell/types.py

```python
"""Type definitions for Maxwell domain objects.

Contains dataclass definitions for non-workflow types:
- LLM specifications
- Extraction results
- File metadata

Workflow-related types (WorkflowInputs, WorkflowOutputs) are in workflows/base.py.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class ChatExtractionResult:
    """Result from extracting chat content."""

    format: str
    total_lines: int
    user_messages: int
    assistant_messages: int
    session_id: str


@dataclass
class DocumentExtractionResult:
    """Result from extracting document content."""

    format: str
    source: str
    path: str


@dataclass
class PDFExtractionResult:
    """Result from extracting PDF content."""

    format: str
    pages: int
    images: int


@dataclass
class FileMetadata:
    """Metadata about extracted files."""

    format: str
    size_bytes: int


@dataclass
class LLMSpec:
    """Specification for an LLM model."""

    model: str
    api_base: Optional[str] = None
    api_key: Optional[str] = None
    temperature: float = 0.7
    max_tokens: Optional[int] = None


@dataclass
class LLMRequest:
    """Request to an LLM."""

    input: str
    model: str
    temperature: float = 0.7
    max_tokens: Optional[int] = None


@dataclass
class LLMResponse:
    """Response from an LLM."""

    content: str
    usage: Optional[Dict[str, Any]] = None
    finish_reason: Optional[str] = None
    model: str = ""


@dataclass
class Message:
    """Chat message with role and content."""

    role: str
    content: str


@dataclass
class LLMUsage:
    """Usage statistics from LLM API."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
```

---
### File: src/maxwell/utils.py

```python
"""Utility functions for maxwell workflows and tools.

Provides common utilities that workflows and scripts can use:
- Session identification (current directory as session ID)
- Timestamp generation (ISO 8601 format)
- Path normalization

maxwell/src/maxwell/utils.py
"""

import os
from datetime import datetime
from pathlib import Path


def get_session_id(path: Path | str | None = None) -> str:
    """Get session ID based on absolute path of directory.

    Args:
        path: Directory path to use. If None, uses current working directory.

    Returns:
        Absolute path as session identifier

    Examples:
        >>> get_session_id()
        '/home/user/Documents/project'
        >>> get_session_id('/tmp/work')
        '/tmp/work'

    """
    if path is None:
        return os.path.realpath(os.getcwd())

    return str(Path(path).resolve())


def get_timestamp(format: str = "iso") -> str:
    """Get current timestamp in specified format.

    Args:
        format: Output format. Options:
            - "iso": ISO 8601 format (default) - "2025-10-11T08:15:00.123456"
            - "iso_seconds": ISO 8601 with second precision - "2025-10-11T08:15:00"
            - "date": Date only - "2025-10-11"
            - "filename": Safe for filenames - "2025-10-11_08-15-00"
            - "unix": Unix timestamp (float)

    Returns:
        Formatted timestamp string

    Examples:
        >>> get_timestamp()
        '2025-10-11T08:15:00.123456'
        >>> get_timestamp("iso_seconds")
        '2025-10-11T08:15:00'
        >>> get_timestamp("filename")
        '2025-10-11_08-15-00'

    """
    now = datetime.now()

    if format == "iso":
        return now.isoformat()
    elif format == "iso_seconds":
        return now.strftime("%Y-%m-%dT%H:%M:%S")
    elif format == "date":
        return now.strftime("%Y-%m-%d")
    elif format == "filename":
        return now.strftime("%Y-%m-%d_%H-%M-%S")
    elif format == "unix":
        return str(now.timestamp())
    else:
        raise ValueError(f"Unknown timestamp format: {format}")


def normalize_path(path: Path | str) -> Path:
    """Normalize a path to absolute Path object.

    Args:
        path: Path to normalize (can be relative, absolute, or string)

    Returns:
        Absolute Path object with symlinks resolved

    """
    return Path(path).resolve()


__all__ = [
    "get_session_id",
    "get_timestamp",
    "normalize_path",
]
```

---
### File: src/maxwell/workflows/__init__.py

```python
"""Workflow implementations package.

Contains all concrete workflow implementations organized by functionality.

Responsibility: Workflow implementation organization only.
Individual workflow logic belongs in specific implementation modules.

maxwell/src/maxwell/workflow/implementations/__init__.py
"""

# Import all workflows to trigger @register_workflow decorators
from . import chat  # This will import all chat workflows and register them
from . import justification, snapshot, tag_refactor, utilities, validate  # Import other workflows

# Import available implementations - avoid circular imports by importing lazily
__all__ = [
    # Helper functions for lazy imports
    "get_justification_engine",
    "get_tag_refactor_workflow",
    "run_tag_refactor",
]


# Lazy imports to avoid circular dependencies
def get_justification_engine():
    """Get JustificationEngine class."""
    from .justification import JustificationEngine

    return JustificationEngine


def get_tag_refactor_workflow():
    """Get TagRefactorWorkflow class."""
    from .tag_refactor import TagRefactorWorkflow

    return TagRefactorWorkflow


def run_tag_refactor(*args, **kwargs):
    """Run tag refactoring workflow (convenience function)."""
    from .tag_refactor import run_tag_refactor as _run

    return _run(*args, **kwargs)
```

---
### File: src/maxwell/workflows/base.py

```python
"""Base workflow system for extensible analysis tasks.

Provides framework for creating modular, composable workflows with
built-in evaluation, metrics collection, and plugin integration.

maxwell/src/maxwell/workflows/base.py
"""

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field, fields
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Set, Type, TypeVar

logger = logging.getLogger(__name__)

__all__ = [
    "WorkflowStatus",
    "WorkflowPriority",
    "WorkflowConfig",
    "WorkflowMetrics",
    "WorkflowResult",
    "BaseWorkflow",
    "WorkflowInputs",
    "WorkflowOutputs",
]


# Workflow Schema System
# ----------------------
# Base classes for typed workflow inputs and outputs
# Each workflow defines its own schemas in the same file


@dataclass(frozen=True)
class WorkflowInputs:
    """Base class for all workflow input schemas.

    All workflow inputs should inherit from this class.
    Using frozen=True ensures immutability.
    """

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorkflowInputs":
        """Create schema instance from dictionary with validation.

        Args:
            data: Dictionary of input parameters

        Returns:
            Validated schema instance

        Raises:
            TypeError: If required fields are missing or wrong type
            ValueError: If validation fails

        """
        # Get all field names and types
        field_names = {f.name for f in fields(cls)}

        # Filter dict to only include valid fields
        filtered_data = {k: v for k, v in data.items() if k in field_names}

        # Create instance (will raise TypeError if required fields missing)
        return cls(**filtered_data)

    def to_dict(self) -> Dict[str, Any]:
        """Convert schema to dictionary."""
        return asdict(self)


@dataclass(frozen=True)
class WorkflowOutputs:
    """Base class for all workflow output schemas.

    All workflow outputs should inherit from this class.
    Using frozen=True ensures immutability.
    """

    def to_dict(self) -> Dict[str, Any]:
        """Convert schema to dictionary."""
        return asdict(self)


# Type variables for generic workflow schemas
InputSchemaT = TypeVar("InputSchemaT", bound=WorkflowInputs)
OutputSchemaT = TypeVar("OutputSchemaT", bound=WorkflowOutputs)


class WorkflowStatus(Enum):
    """Workflow execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class WorkflowPriority(Enum):
    """Workflow execution priority."""

    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class WorkflowConfig:
    """Configuration for workflow execution."""

    # Basic settings
    enabled: bool = True
    priority: WorkflowPriority = WorkflowPriority.MEDIUM
    timeout_seconds: Optional[int] = None

    # Dependencies and requirements
    required_tools: Set[str] = field(default_factory=set)
    required_data: Set[str] = field(default_factory=set)
    dependencies: List[str] = field(default_factory=list)  # Other workflow IDs

    # Execution settings
    parallel_execution: bool = False
    max_retries: int = 0
    cache_results: bool = True

    # Input/output settings
    input_filters: Dict[str, Any] = field(default_factory=dict)
    output_format: str = "json"

    # Custom parameters
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowMetrics:
    """Metrics collected during workflow execution."""

    # Timing metrics
    start_time: float
    end_time: Optional[float] = None
    execution_time_seconds: Optional[float] = None

    # Resource metrics
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None

    # Analysis metrics
    files_processed: int = 0
    findings_generated: int = 0
    errors_encountered: int = 0

    # Quality metrics
    confidence_score: float = 0.0
    accuracy_score: Optional[float] = None
    coverage_percentage: Optional[float] = None

    # Custom metrics
    custom_metrics: Dict[str, Any] = field(default_factory=dict)

    def finalize(self):
        """Finalize metrics calculation."""
        if self.end_time and self.start_time:
            self.execution_time_seconds = self.end_time - self.start_time


@dataclass
class WorkflowResult:
    """Result of workflow execution."""

    # Execution info
    workflow_id: str
    status: WorkflowStatus
    metrics: WorkflowMetrics

    # Results
    findings: List[Dict[str, Any]] = field(default_factory=list)
    artifacts: Dict[str, Any] = field(default_factory=dict)
    recommendations: List[str] = field(default_factory=list)

    # Error handling
    error_message: Optional[str] = None
    warnings: List[str] = field(default_factory=list)

    # Metadata
    timestamp: str = ""
    version: str = "1.0"

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.strftime("%Y-%m-%d %H:%M:%S")


class BaseWorkflow(ABC):
    """Abstract base class for maxwell workflows.

    Workflows can use typed schemas for type-safe inputs/outputs:

    Example:
        @dataclass(frozen=True)
        class MyInputs(WorkflowInputs):
            query: str
            limit: int = 10

        @dataclass(frozen=True)
        class MyOutputs(WorkflowOutputs):
            results: List[str]
            count: int

        class MyWorkflow(BaseWorkflow):
            InputSchema = MyInputs
            OutputSchema = MyOutputs

            def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
                # Automatic schema conversion
                inputs = self.InputSchema.from_dict(context)
                # Now you have typed access: inputs.query, inputs.limit

                # Do work...
                results = ["result1", "result2"]

                # Return with typed outputs
                outputs = MyOutputs(results=results, count=len(results))
                return self.create_result(outputs)

    """

    # Workflow identification
    workflow_id: str = ""
    name: str = ""
    description: str = ""
    version: str = "1.0"

    # Workflow categorization
    category: str = "analysis"  # analysis, validation, reporting, maintenance
    tags: Set[str] = set()

    # Typed schema support (optional - workflows can define these)
    InputSchema: ClassVar[Optional[Type[WorkflowInputs]]] = None
    OutputSchema: ClassVar[Optional[Type[WorkflowOutputs]]] = None

    def __init__(self, config: Optional[WorkflowConfig] = None):
        """Initialize workflow with configuration."""
        self.config = config or WorkflowConfig()
        self.metrics = WorkflowMetrics(start_time=time.time())
        self._status = WorkflowStatus.PENDING

        # Validate workflow setup
        self._validate_configuration()

    @abstractmethod
    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute the workflow with given context.

        Args:
            project_root: Root directory of the project
            context: Execution context with shared data

        Returns:
            WorkflowResult with findings and artifacts

        """
        pass

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Get CLI parameter definitions for this workflow.

        Returns list of parameter definitions, each with:
        - name: Parameter name (str)
        - type: click type (str, int, Path, etc.)
        - required: Whether required (bool)
        - help: Help text (str)
        - default: Default value (optional)

        Example:
            return [
                {"name": "source", "type": str, "required": True, "help": "Source type"},
                {"name": "user", "type": str, "required": True, "help": "Username"},
                {"name": "machine", "type": str, "required": False, "help": "Machine name"},
            ]

        """
        return []  # Default: no additional parameters

    # Schema-based workflow helpers
    # -----------------------------

    def uses_schemas(self) -> bool:
        """Check if this workflow uses typed schemas."""
        return self.InputSchema is not None and self.OutputSchema is not None

    def parse_inputs(self, context: Dict[str, Any]) -> InputSchemaT:  # type: ignore[type-var]
        """Parse context dict into typed inputs schema.

        Args:
            context: Raw input dictionary

        Returns:
            Validated input schema instance

        Raises:
            ValueError: If InputSchema not defined or validation fails

        """
        if self.InputSchema is None:
            raise ValueError(f"Workflow {self.workflow_id} does not define InputSchema")

        return self.InputSchema.from_dict(context)  # type: ignore[return-value]

    def create_result(
        self,
        outputs: Optional[WorkflowOutputs] = None,
        status: WorkflowStatus = WorkflowStatus.COMPLETED,
        error_message: Optional[str] = None,
    ) -> WorkflowResult:
        """Create WorkflowResult from typed outputs.

        Args:
            outputs: Typed output schema (if None, creates minimal result)
            status: Workflow execution status
            error_message: Error message if failed

        Returns:
            WorkflowResult with typed outputs converted to artifacts

        """
        self.metrics.finalize()

        # Convert outputs to artifacts dict
        artifacts = outputs.to_dict() if outputs is not None else {}

        return WorkflowResult(
            workflow_id=self.workflow_id,
            status=status,
            metrics=self.metrics,
            artifacts=artifacts,
            error_message=error_message,
        )

    def can_execute(self, context: Dict[str, Any]) -> bool:
        """Check if workflow can execute with given context."""
        # Check if enabled
        if not self.config.enabled:
            return False

        # Note: Input validation now happens in parse_inputs() via InputSchema dataclass
        # Required fields without defaults will raise an error during instantiation

        # Check required tools
        if self.config.required_tools:
            # This would check for tool availability
            pass

        return True

    def estimate_execution_time(self, context: Dict[str, Any]) -> float:
        """Estimate execution time in seconds based on context."""
        # Default implementation - workflows can override
        base_time = 10.0  # 10 seconds base

        # Scale by number of files if available
        if "file_count" in context:
            file_count = context["file_count"]
            base_time += file_count * 0.1  # 0.1 seconds per file

        return base_time

    def get_dependencies(self) -> List[str]:
        """Get list of workflow IDs this workflow depends on."""
        return self.config.dependencies

    def get_priority(self) -> WorkflowPriority:
        """Get workflow execution priority."""
        return self.config.priority

    def supports_parallel_execution(self) -> bool:
        """Check if workflow supports parallel execution."""
        return self.config.parallel_execution

    def _validate_configuration(self):
        """Validate workflow configuration."""
        if not self.workflow_id:
            raise ValueError(f"Workflow {self.__class__.__name__} must define workflow_id")

        if not self.name:
            raise ValueError(f"Workflow {self.workflow_id} must define name")

    def _update_status(self, status: WorkflowStatus):
        """Update workflow execution status."""
        self._status = status

        if status == WorkflowStatus.COMPLETED:
            self.metrics.end_time = time.time()
            self.metrics.finalize()

    def _create_result(
        self,
        status: WorkflowStatus,
        findings: Optional[List[Dict[str, Any]]] = None,
        artifacts: Optional[Dict[str, Any]] = None,
        error_message: Optional[str] = None,
    ) -> WorkflowResult:
        """Create workflow result."""
        self._update_status(status)

        return WorkflowResult(
            workflow_id=self.workflow_id,
            status=status,
            metrics=self.metrics,
            findings=findings or [],
            artifacts=artifacts or {},
            error_message=error_message,
        )

    async def _execute_with_error_handling(
        self, project_root: Path, context: Dict[str, Any]
    ) -> WorkflowResult:
        """Execute workflow with comprehensive error handling."""
        try:
            self._update_status(WorkflowStatus.RUNNING)

            # Check timeout
            if self.config.timeout_seconds:
                # Implementation would use asyncio.wait_for
                pass

            # Execute the workflow
            result = self.execute(project_root, context)

            # Validate result
            if result.status == WorkflowStatus.PENDING:
                result.status = WorkflowStatus.COMPLETED

            return result

        except Exception as e:
            logger.error(f"Workflow {self.workflow_id} failed: {e}", exc_info=True)
            self.metrics.errors_encountered += 1

            return self._create_result(WorkflowStatus.FAILED, error_message=str(e))

    def get_evaluation_criteria(self) -> Dict[str, Any]:
        """Get criteria for evaluating workflow effectiveness."""
        return {
            "performance": {
                "max_execution_time": 60.0,  # seconds
                "max_memory_usage": 500.0,  # MB
            },
            "quality": {
                "min_confidence_score": 0.7,
                "min_coverage_percentage": 80.0,
            },
            "reliability": {
                "max_error_rate": 0.05,  # 5%
                "max_timeout_rate": 0.01,  # 1%
            },
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.workflow_id}, status={self._status.value})"
```

---
### File: src/maxwell/workflows/chat/README.md

```markdown
# Chat Workflows - Unified ChatGPT & Claude Analysis

Organized workflow module for parsing, indexing, and analyzing both ChatGPT and Claude conversations.

## Structure

```
chat/
├── __init__.py          # Module exports
├── parsers.py           # ChatGPT and Claude conversation parsers
├── indexer.py           # MongoDB indexing for both sources
├── insights.py          # Deep analysis and insights extraction
└── README.md            # This file
```

## Modules

### parsers.py

Unified message parsers for both ChatGPT and Claude conversations.

**ChatGPTParser**: Handles `conversations.json` export format
- Parses nested message mappings
- Walks conversation graph to get chronological order
- Source: `/home/mithranmohanraj/Documents/chatgpt/conversations.json`

**ClaudeParser**: Handles `.jsonl` conversation files
- Parses JSONL format from `~/.claude/projects/`
- Extracts user/assistant messages
- Source: `~/.claude/projects/*.jsonl`

**Message**: Unified dataclass representing a message from either source
```python
@dataclass
class Message:
    message_id: str
    conversation_id: str
    conversation_title: str
    role: str  # user, assistant, system, tool
    text: str
    timestamp: Optional[float]
    message_index: int
    parent_id: Optional[str]
    source: str  # "chatgpt" or "claude"
    token_count: int
    char_count: int
```

### indexer.py

MongoDB indexer for chat messages from both sources.

**ChatIndexer**: Loads messages into MongoDB `chat_analytics` database
- Creates indexes for fast querying
- Handles deduplication
- Generates conversation summaries
- Adds temporal fields for analytics (year, month, day_of_week, hour_of_day)

**Collections**:
- `messages`: Individual messages with full metadata
- `conversations`: Aggregated conversation summaries

**Usage**:
```python
from maxwell.workflows.implementations.chat.indexer import ChatIndexer

indexer = ChatIndexer()
indexer.setup_collections()

# Index ChatGPT
indexer.index_chatgpt(Path("/home/mithranmohanraj/Documents/chatgpt/conversations.json"))

# Index Claude
indexer.index_claude(Path("~/.claude/projects").expanduser())

# Create summaries
indexer.create_conversation_summaries()

# Get stats
stats = indexer.get_stats()
```

**CLI**:
```bash
# Index ChatGPT
python -m maxwell.workflows.implementations.chat.indexer chatgpt /path/to/conversations.json

# Index Claude
python -m maxwell.workflows.implementations.chat.indexer claude ~/.claude/projects

# View stats
python -m maxwell.workflows.implementations.chat.indexer stats
```

### insights.py

Deep analysis workflow for extracting insights from indexed conversations.

**ChatInsightsWorkflow**: Maxwell workflow for analyzing conversations
- Clustering conversations by semantic similarity
- Extracting key topics per cluster
- Generating insights using LLM
- Supports "organic" mode (no predefined topic count)
- Handles both ChatGPT global memory and Claude long conversations

**Features**:
- Embedding-based clustering (HDBSCAN)
- LLM-powered insight generation with GBNF structured output
- Temporal awareness (analyzes recent conversations)
- Source awareness (ChatGPT vs Claude)

**Usage**:
```python
from pathlib import Path
from maxwell.workflows.implementations.chat.insights import ChatInsightsWorkflow

workflow = ChatInsightsWorkflow()
result = workflow.execute(
    Path.cwd(),
    {
        'method': 'deep',
        'days': 7,
        'limit': 200,
        'max_topics': 50,
        'organic': True
    }
)
```

## Data Flow

### Indexing Pipeline

1. **Parse** conversations using `ChatGPTParser` or `ClaudeParser`
2. **Index** messages to MongoDB using `ChatIndexer`
3. **Summarize** conversations (aggregate stats)

### Insights Pipeline

1. **Query** MongoDB for recent conversations
2. **Embed** conversation summaries using Qwen3-4B-Embed
3. **Cluster** conversations using HDBSCAN
4. **Generate** insights per cluster using LLM with GBNF
5. **Aggregate** global themes across all clusters

## Database Schema

### messages Collection

```javascript
{
  message_id: "unique-id",
  conversation_id: "conv-id",
  conversation_title: "Title",
  role: "user" | "assistant" | "system" | "tool",
  text: "Message content",
  timestamp: 1234567890.123,
  message_index: 0,
  parent_id: "parent-msg-id",
  source: "chatgpt" | "claude",
  token_count: 100,
  char_count: 400,

  // Derived temporal fields
  year: 2025,
  month: "2025-10",
  day_of_week: "Monday",
  hour_of_day: 14
}
```

### conversations Collection

```javascript
{
  conversation_id: "conv-id",
  title: "Conversation Title",
  source: "chatgpt" | "claude",
  message_count: 42,
  first_message: 1234567890.123,
  last_message: 1234567999.456,
  roles: ["user", "assistant"],
  total_tokens: 4200,
  total_chars: 16800
}
```

## Current Status

**Indexed Data** (as of 2025-10-21):
- Total conversations: 686
- Total messages: 90,117
- ChatGPT: 548 conversations (80%), 7,374 messages (8.2%)
- Claude: 138 conversations (20%), 82,743 messages (91.8%)

**Database**: MongoDB `chat_analytics` on localhost:27017

## Integration Points

### Backward Compatibility

The old `chat_insights.py` location is maintained as a shim:
```python
# Old import (still works)
from maxwell.workflows.implementations.chat_insights import ChatInsightsWorkflow

# New import (preferred)
from maxwell.workflows.implementations.chat.insights import ChatInsightsWorkflow
```

### Future Work

1. **Merge with Maxwell document indexer**: Currently `extractors.py` is at maxwell root and only handles Claude. Should integrate both parsers.

2. **LSTM-style summarization for ChatGPT**: Treat ChatGPT conversations as one continuous thread with global memory, using backward summarization from cluster entry points.

3. **Unified language model pool**: Merge `embedding_client.py` and `llm_pool.py` into single `language_model_pool.py`.

## Dependencies

- **MongoDB**: For message storage and analytics
- **pymongo**: MongoDB client
- **LLMPool**: For embeddings and LLM inference
- **scikit-learn**: For clustering (HDBSCAN)
- **Maxwell workflows**: Base workflow infrastructure
```

---
### File: src/maxwell/workflows/chat/__init__.py

```python
"""Chat workflow package for Maxwell.

Provides workflows for chat processing:
- chat_incremental: Incremental processing with deduplication
- chat_backup: Backup and restore functionality
- chat_semantic_search: Semantic search with Qdrant
- chat_bm25_search: BM25 keyword search
- metadata_extractor: Metadata extraction and quality control

Usage:
    from maxwell.workflows.chat import (
        RegisteredIncrementalChatWorkflow,
        RegisteredChatBackupWorkflow,
        ChatSemanticSearchWorkflow,
        ChatBM25SearchWorkflow,
        MetadataExtractor
    )
"""

# Legacy exports for backward compatibility
from .bm25_search import BM25Searcher, ChatBM25SearchWorkflow

# Import only the 3 main workflows to register
from .incremental_processor import RegisteredIncrementalChatWorkflow
from .metadata_extractor import MetadataExtractor, TurnMetadata
from .parsers import ChatGPTParser, ClaudeParser, Message
from .semantic_search import ChatSemanticSearchWorkflow

# Export available workflows for external access
__all__ = [
    "RegisteredIncrementalChatWorkflow",
    "ChatSemanticSearchWorkflow",
    "ChatBM25SearchWorkflow",
]
```

---
### File: src/maxwell/workflows/chat/backup_strategy.py

```python
"""Backup workflow for MongoDB and Qdrant chat data.

Registers as "chat_backup" workflow in Maxwell's registry.
Provides automated backup and recovery for chat analytics data:
- MongoDB metadata and turn collections
- Qdrant vector collections
- Configurable retention policies
- Incremental backup support

Usage:
    from maxwell.workflows.chat.backup_strategy import ChatBackupWorkflow

    workflow = ChatBackupWorkflow()
    result = workflow.run(backup_type="full", include_qdrant=True, include_mongodb=True)
"""

import json
import logging
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import pymongo
from qdrant_client import QdrantClient

from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


class ChatBackupManager:
    """Backup and recovery manager for chat analytics data."""

    def __init__(
        self,
        mongodb_uri: str = "mongodb://localhost:27017",
        mongodb_db: str = "chat_analytics",
        qdrant_host: str = "localhost",
        qdrant_port: int = 6333,
        backup_root: Optional[Path] = None,
    ):
        """Initialize backup manager.

        Args:
            mongodb_uri: MongoDB connection URI
            mongodb_db: MongoDB database name
            qdrant_host: Qdrant host
            qdrant_port: Qdrant port
            backup_root: Root directory for backups (defaults to ~/.maxwell/backups)

        """
        self.mongodb_uri = mongodb_uri
        self.mongodb_db = mongodb_db
        self.qdrant_host = qdrant_host
        self.qdrant_port = qdrant_port

        # Backup storage
        if backup_root:
            self.backup_root = Path(backup_root)
        else:
            # Use ~/.maxwell/backups by default
            self.backup_root = Path.home() / ".maxwell" / "backups"

        self.backup_root.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.backup_root / "backup_metadata.json"

        # Database connections
        self.mongo_client = None
        self.qdrant_client = None

        logger.info("Initialized backup manager")
        logger.info(f"Backup root: {self.backup_root}")

    def _connect_mongodb(self):
        """Connect to MongoDB."""
        if self.mongo_client is None:
            self.mongo_client = pymongo.MongoClient(self.mongodb_uri)
        return self.mongo_client

    def _connect_qdrant(self):
        """Connect to Qdrant."""
        if self.qdrant_client is None:
            self.qdrant_client = QdrantClient(host=self.qdrant_host, port=self.qdrant_port)
        return self.qdrant_client

    def _create_backup_dir(self, backup_type: str = "full") -> Path:
        """Create backup directory with timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = self.backup_root / f"{backup_type}_backup_{timestamp}"
        backup_dir.mkdir(parents=True, exist_ok=True)
        return backup_dir

    def _get_backup_info(self) -> Dict:
        """Load backup metadata."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, "r") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load backup metadata: {e}")
        return {"backups": []}

    def _save_backup_info(self, backup_info: Dict):
        """Save backup metadata."""
        try:
            with open(self.metadata_file, "w") as f:
                json.dump(backup_info, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save backup metadata: {e}")

    def backup_mongodb_collection(self, collection_name: str, backup_dir: Path) -> Dict:
        """Backup a single MongoDB collection to JSON."""
        try:
            client = self._connect_mongodb()
            db = client[self.mongodb_db]
            collection = db[collection_name]

            # Get all documents
            documents = list(collection.find({}))

            # Save to JSON file
            backup_file = backup_dir / f"{collection_name}.json"
            with open(backup_file, "w", encoding="utf-8") as f:
                json.dump(documents, f, indent=2, default=str)

            stats = {
                "collection": collection_name,
                "document_count": len(documents),
                "file_size_mb": backup_file.stat().st_size / (1024 * 1024),
                "backup_file": str(backup_file),
            }

            logger.info(
                f"Backed up {collection_name}: {stats['document_count']} documents ({stats['file_size_mb']:.1f}MB)"
            )
            return stats

        except Exception as e:
            logger.error(f"Failed to backup MongoDB collection {collection_name}: {e}")
            return {"collection": collection_name, "error": str(e)}

    def backup_qdrant_collection(self, collection_name: str, backup_dir: Path) -> Dict:
        """Backup a Qdrant collection to JSON."""
        try:
            client = self._connect_qdrant()

            # Get collection info
            collection_info = client.get_collection(collection_name)
            points_count = collection_info.points_count

            if points_count == 0:
                logger.info(f"Qdrant collection {collection_name} is empty, skipping backup")
                return {
                    "collection": collection_name,
                    "points_count": 0,
                    "file_size_mb": 0,
                    "skipped": True,
                }

            # Scroll through all points (with batch size to handle large collections)
            all_points = []
            scroll_result = client.scroll(collection_name=collection_name, limit=1000)

            points = scroll_result[0]  # points
            all_points.extend(points)

            # Continue scrolling if there are more points
            while len(points) == 1000:
                scroll_result = client.scroll(
                    collection_name=collection_name, limit=1000, offset=len(all_points)
                )
                points = scroll_result[0]
                all_points.extend(points)

            # Convert points to serializable format
            serializable_points = []
            for point in all_points:
                serializable_points.append(
                    {
                        "id": point.id,
                        "vector": (
                            point.vector.tolist()
                            if hasattr(point.vector, "tolist")
                            else point.vector
                        ),
                        "payload": point.payload,
                    }
                )

            # Save to JSON file
            backup_file = backup_dir / f"{collection_name}.json"
            with open(backup_file, "w", encoding="utf-8") as f:
                json.dump(serializable_points, f, indent=2)

            stats = {
                "collection": collection_name,
                "points_count": len(all_points),
                "file_size_mb": backup_file.stat().st_size / (1024 * 1024),
                "backup_file": str(backup_file),
            }

            logger.info(
                f"Backed up Qdrant {collection_name}: {stats['points_count']} points ({stats['file_size_mb']:.1f}MB)"
            )
            return stats

        except Exception as e:
            logger.error(f"Failed to backup Qdrant collection {collection_name}: {e}")
            return {"collection": collection_name, "error": str(e)}

    def create_full_backup(self, include_qdrant: bool = True, include_mongodb: bool = True) -> Dict:
        """Create a full backup of all chat data.

        Args:
            include_qdrant: Include Qdrant vector collections
            include_mongodb: Include MongoDB collections

        Returns:
            Backup result statistics

        """
        logger.info("Starting full backup...")
        backup_dir = self._create_backup_dir("full")

        backup_result = {
            "backup_type": "full",
            "timestamp": datetime.now().isoformat(),
            "backup_dir": str(backup_dir),
            "mongodb": {},
            "qdrant": {},
            "total_size_mb": 0,
            "success": False,
        }

        # Backup MongoDB collections
        if include_mongodb:
            mongodb_collections = ["turns", "turn_metadata"]
            backup_result["mongodb"]["collections"] = []

            for collection_name in mongodb_collections:
                stats = self.backup_mongodb_collection(collection_name, backup_dir)
                backup_result["mongodb"]["collections"].append(stats)
                if "error" not in stats:
                    backup_result["total_size_mb"] += stats["file_size_mb"]

        # Backup Qdrant collections
        if include_qdrant:
            try:
                client = self._connect_qdrant()
                collections = client.get_collections().collections
                qdrant_collection_names = [col.name for col in collections]
                backup_result["qdrant"]["collections"] = []

                for collection_name in qdrant_collection_names:
                    stats = self.backup_qdrant_collection(collection_name, backup_dir)
                    backup_result["qdrant"]["collections"].append(stats)
                    if "error" not in stats:
                        backup_result["total_size_mb"] += stats["file_size_mb"]

            except Exception as e:
                logger.error(f"Failed to get Qdrant collections list: {e}")

        # Check if backup was successful
        # Check for errors in collections
        all_collections = (
            backup_result["mongodb"]["collections"] + backup_result["qdrant"]["collections"]
        )
        has_errors = any(
            "error" in collection for collection in all_collections if isinstance(collection, dict)
        )

        backup_result["success"] = not has_errors

        # Save backup manifest
        manifest_file = backup_dir / "backup_manifest.json"
        with open(manifest_file, "w") as f:
            json.dump(backup_result, f, indent=2, default=str)

        # Update backup registry
        backup_info = self._get_backup_info()
        backup_info["backups"].append(
            {
                "type": "full",
                "timestamp": backup_result["timestamp"],
                "backup_dir": str(backup_dir.relative_to(self.backup_root)),
                "total_size_mb": backup_result["total_size_mb"],
                "success": backup_result["success"],
            }
        )
        self._save_backup_info(backup_info)

        if backup_result["success"]:
            logger.info(
                f"✅ Full backup completed successfully ({backup_result['total_size_mb']:.1f}MB)"
            )
        else:
            logger.error("❌ Full backup completed with errors")

        return backup_result

    def list_backups(self) -> List[Dict]:
        """List all available backups."""
        backup_info = self._get_backup_info()
        return backup_info.get("backups", [])

    def restore_backup(self, backup_path: Path, dry_run: bool = False) -> Dict:
        """Restore from a backup directory.

        Args:
            backup_path: Path to backup directory
            dry_run: If True, only show what would be restored

        Returns:
            Restore statistics

        """
        backup_path = Path(backup_path)
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup directory not found: {backup_path}")

        # Load backup manifest
        manifest_file = backup_path / "backup_manifest.json"
        if not manifest_file.exists():
            raise FileNotFoundError(f"Backup manifest not found: {manifest_file}")

        with open(manifest_file, "r") as f:
            backup_manifest = json.load(f)

        logger.info(f"Restoring backup from {backup_path.name} (dry_run={dry_run})")

        restore_result = {
            "backup_timestamp": backup_manifest.get("timestamp"),
            "mongodb": {"restored": 0, "errors": 0},
            "qdrant": {"restored": 0, "errors": 0},
            "dry_run": dry_run,
            "success": False,
        }

        if not dry_run:
            # Restore MongoDB collections
            if "mongodb" in backup_manifest and "collections" in backup_manifest["mongodb"]:
                client = self._connect_mongodb()
                db = client[self.mongodb_db]

                for collection_info in backup_manifest["mongodb"]["collections"]:
                    if "error" in collection_info:
                        logger.warning(
                            f"Skipping collection with backup error: {collection_info.get('collection')}"
                        )
                        continue

                    collection_name = collection_info["collection"]
                    backup_file = backup_path / f"{collection_name}.json"

                    if backup_file.exists():
                        try:
                            with open(backup_file, "r") as f:
                                documents = json.load(f)

                            # Drop existing collection
                            db.drop_collection(collection_name)
                            # Insert documents
                            if documents:
                                db[collection_name].insert_many(documents)

                            restore_result["mongodb"]["restored"] += 1
                            logger.info(
                                f"Restored MongoDB {collection_name}: {len(documents)} documents"
                            )

                        except Exception as e:
                            logger.error(f"Failed to restore MongoDB {collection_name}: {e}")
                            restore_result["mongodb"]["errors"] += 1
                    else:
                        logger.warning(f"Backup file not found for {collection_name}")

            # Restore Qdrant collections
            if "qdrant" in backup_manifest and "collections" in backup_manifest["qdrant"]:
                client = self._connect_qdrant()

                for collection_info in backup_manifest["qdrant"]["collections"]:
                    if "error" in collection_info or collection_info.get("skipped"):
                        logger.warning(f"Skipping collection: {collection_info.get('collection')}")
                        continue

                    collection_name = collection_info["collection"]
                    backup_file = backup_path / f"{collection_name}.json"

                    if backup_file.exists():
                        try:
                            with open(backup_file, "r") as f:
                                points_data = json.load(f)

                            if points_data and len(points_data) > 0:
                                # Delete existing collection
                                try:
                                    client.delete_collection(collection_name)
                                except:
                                    pass  # Collection might not exist

                                # Recreate collection
                                from qdrant_client.models import Distance, VectorParams

                                client.create_collection(
                                    collection_name=collection_name,
                                    vectors_config=VectorParams(
                                        size=len(points_data[0]["vector"]), distance=Distance.COSINE
                                    ),
                                )

                                # Convert back to PointStruct and upload
                                from qdrant_client.models import PointStruct

                                points = []
                                for point_data in points_data:
                                    points.append(
                                        PointStruct(
                                            id=point_data["id"],
                                            vector=point_data["vector"],
                                            payload=point_data["payload"],
                                        )
                                    )

                                client.upsert(collection_name, points)

                                restore_result["qdrant"]["restored"] += 1
                                logger.info(
                                    f"Restored Qdrant {collection_name}: {len(points)} points"
                                )

                        except Exception as e:
                            logger.error(f"Failed to restore Qdrant {collection_name}: {e}")
                            restore_result["qdrant"]["errors"] += 1
                    else:
                        logger.warning(f"Backup file not found for {collection_name}")

        restore_result["success"] = (
            restore_result["mongodb"]["errors"] == 0 and restore_result["qdrant"]["errors"] == 0
        )

        if restore_result["success"]:
            action = "Would restore" if dry_run else "✅ Successfully restored"
            logger.info(f"{action} backup from {backup_path.name}")
        else:
            logger.error("❌ Restore completed with errors")

        return restore_result

    def cleanup_old_backups(self, keep_days: int = 30, keep_count: int = 5):
        """Clean up old backups, keeping the most recent ones.

        Args:
            keep_days: Delete backups older than this many days
            keep_count: Always keep at least this many recent backups

        """
        backup_info = self._get_backup_info()
        backups = backup_info.get("backups", [])

        if len(backups) <= keep_count:
            logger.info(f"Only {len(backups)} backups exist, keeping all (minimum: {keep_count})")
            return

        # Sort by timestamp (newest first)
        backups.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

        # Keep the most recent `keep_count` backups
        keep_backups = backups[:keep_count]

        # For additional backups, check age
        cutoff_date = datetime.now() - timedelta(days=keep_days)

        for backup in backups[keep_count:]:
            try:
                backup_date = datetime.fromisoformat(backup.get("timestamp", ""))
                backup_dir = self.backup_root / backup.get("backup_dir", "")

                if backup_date < cutoff_date and backup_dir.exists():
                    # Remove backup directory
                    shutil.rmtree(backup_dir)
                    logger.info(f"Deleted old backup: {backup_dir.name}")

                    # Remove from registry
                    backup_info["backups"].remove(backup)

            except Exception as e:
                logger.error(f"Failed to cleanup backup {backup.get('backup_dir', 'unknown')}: {e}")

        self._save_backup_info(backup_info)

    def get_backup_summary(self) -> Dict:
        """Get summary of all backups."""
        backup_info = self._get_backup_info()
        backups = backup_info.get("backups", [])

        if not backups:
            return {"total_count": 0, "total_size_mb": 0, "latest_backup": None}

        total_size = sum(b.get("total_size_mb", 0) for b in backups)
        latest_backup = max(backups, key=lambda x: x.get("timestamp", "")) if backups else None

        return {
            "total_count": len(backups),
            "total_size_mb": total_size,
            "latest_backup": latest_backup.get("timestamp") if latest_backup else None,
            "backup_root": str(self.backup_root),
        }


def print_backup_summary(backup_result: Dict):
    """Print formatted backup summary."""
    print("\n" + "=" * 60)
    print("BACKUP SUMMARY")
    print("=" * 60)
    print(f"Backup type: {backup_result['backup_type']}")
    print(f"Timestamp: {backup_result['timestamp']}")
    print(f"Directory: {backup_result['backup_dir']}")
    print(f"Total size: {backup_result['total_size_mb']:.1f}MB")
    print(f"Success: {'✅' if backup_result['success'] else '❌'}")

    if backup_result.get("mongodb", {}).get("collections"):
        print("\nMongoDB Collections:")
        for col in backup_result["mongodb"]["collections"]:
            if "error" in col:
                print(f"  ❌ {col['collection']}: {col['error']}")
            else:
                print(
                    f"  ✅ {col['collection']}: {col['document_count']} docs ({col['file_size_mb']:.1f}MB)"
                )

    if backup_result.get("qdrant", {}).get("collections"):
        print("\nQdrant Collections:")
        for col in backup_result["qdrant"]["collections"]:
            if col.get("skipped"):
                print(f"  ⏭️ {col['collection']}: empty, skipped")
            elif "error" in col:
                print(f"  ❌ {col['collection']}: {col['error']}")
            else:
                print(
                    f"  ✅ {col['collection']}: {col['points_count']} points ({col['file_size_mb']:.1f}MB)"
                )

    print("=" * 60)


class ChatBackupWorkflow(BaseWorkflow):
    """Backup workflow that integrates with Maxwell's registry."""

    def __init__(self):
        self.workflow_id = "chat_backup"
        self.name = "Chat Data Backup"
        self.description = "Creates automated backups of MongoDB and Qdrant chat data"
        self.version = "1.0"
        super().__init__()

    def get_required_inputs(self) -> Set[str]:
        """Get required input data keys."""
        return set()  # No required inputs

    def get_produced_outputs(self) -> Set[str]:
        """Get output data keys this workflow produces."""
        return {"backup_result", "backup_dir", "collections_backed_up"}

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.HIGH,
            timeout_seconds=7200,  # 2 hours
            cache_results=False,  # Backups shouldn't be cached
            parameters={
                "backup_root": str(root_dir / ".maxwell" / "backups"),
                "mongodb_uri": "mongodb://localhost:27017",
                "mongodb_db": "chat_analytics",
                "qdrant_host": "localhost",
                "qdrant_port": 6333,
                "include_mongodb": True,
                "include_qdrant": True,
            },
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute backup workflow."""
        # Initialize backup manager
        backup = ChatBackupManager(
            mongodb_uri=context.get("mongodb_uri", "mongodb://localhost:27017"),
            mongodb_db=context.get("mongodb_db", "chat_analytics"),
            qdrant_host=context.get("qdrant_host", "localhost"),
            qdrant_port=context.get("qdrant_port", 6333),
            backup_root=Path(context.get("backup_root", "~/.maxwell/backups")),
        )

        # Run backup
        include_mongodb = context.get("include_mongodb", True)
        include_qdrant = context.get("include_qdrant", True)

        backup_result = backup.create_full_backup(
            include_mongodb=include_mongodb, include_qdrant=include_qdrant
        )

        # Create result
        status = WorkflowStatus.COMPLETED if backup_result["success"] else WorkflowStatus.FAILED
        result = WorkflowResult(
            workflow_id=self.workflow_id,
            status=status,
            metrics=self.metrics,
            artifacts={
                "backup_result": backup_result,
                "backup_dir": backup_result["backup_dir"],
                "backup_type": backup_result["backup_type"],
                "collections_backed_up": len(
                    backup_result.get("mongodb", {}).get("collections", [])
                )
                + len(backup_result.get("qdrant", {}).get("collections", [])),
            },
        )

        return result


# Register workflow in Maxwell's registry
@register_workflow
class RegisteredChatBackupWorkflow(ChatBackupWorkflow):
    """Registered version of ChatBackupWorkflow."""

    def __init__(self):
        # Call parent __init__ to set workflow_id
        super().__init__()
```

---
### File: src/maxwell/workflows/chat/batch_extract.py

```python
"""Batch metadata extraction for all chat turns.

Processes all 5,812 turns to extract metadata and embeddings.
Stores metadata in MongoDB and embeddings in Qdrant.

Usage:
    python -m maxwell.workflows.implementations.chat.batch_extract

Progress tracking:
    - Shows progress every 100 turns
    - Saves intermediate results
    - Handles failures gracefully
"""

import logging
import time
from pathlib import Path
from typing import Optional

from pymongo import MongoClient

from .metadata_extractor import MetadataExtractor

logger = logging.getLogger(__name__)


def batch_extract_all(
    mongodb_uri: str = "mongodb://localhost:27017",
    mongodb_db: str = "chat_analytics",
    limit: Optional[int] = None,
    skip_existing: bool = True,
):
    """Extract metadata and embeddings for all turns.

    Args:
        mongodb_uri: MongoDB connection URI
        mongodb_db: MongoDB database name
        limit: Optional limit on number of turns to process (for testing)
        skip_existing: Skip turns that already have metadata cached

    """
    # Set session ID for logging
    import datetime
    import os

    if not os.getenv("LLM_SESSION_ID"):
        session_id = f"batch_extract_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        os.environ["LLM_SESSION_ID"] = session_id
        logger.info(f"Set LLM session ID: {session_id}")

        # Prepend legacy logs if they exist
        log_dir = Path.cwd() / ".maxwell" / "logs"
        legacy_file = log_dir / "legacy_batch_extract_20251021.jsonl"
        current_file = log_dir / f"{session_id}.jsonl"

        if legacy_file.exists():
            logger.info(f"Prepending legacy logs from {legacy_file}")
            # Copy legacy content to new session file
            import shutil

            shutil.copy2(legacy_file, current_file)
            logger.info(f"Copied {legacy_file.stat().st_size:,} bytes to {current_file}")
        else:
            # Create empty file to start logging
            current_file.touch()
    else:
        logger.info(f"Using existing LLM session ID: {os.getenv('LLM_SESSION_ID')}")

    # Setup
    mongo_client = MongoClient(mongodb_uri)
    mongo_db = mongo_client[mongodb_db]
    turns_collection = mongo_db["turns"]
    metadata_collection = mongo_db["turn_metadata"]

    extractor = MetadataExtractor(mongodb_uri=mongodb_uri, mongodb_db=mongodb_db)

    # Get all turn IDs
    logger.info("Fetching turn IDs from MongoDB...")
    if skip_existing:
        # Get turns without metadata
        existing_turn_ids = set(
            doc["turn_id"] for doc in metadata_collection.find({}, {"turn_id": 1})
        )
        all_turns = list(turns_collection.find({}, {"turn_id": 1}))
        turn_ids = [t["turn_id"] for t in all_turns if t["turn_id"] not in existing_turn_ids]
        logger.info(
            f"Found {len(all_turns)} total turns, {len(existing_turn_ids)} already processed"
        )
        logger.info(f"Processing {len(turn_ids)} remaining turns")
    else:
        turn_ids = [t["turn_id"] for t in turns_collection.find({}, {"turn_id": 1})]
        logger.info(f"Processing all {len(turn_ids)} turns")

    if limit:
        turn_ids = turn_ids[:limit]
        logger.info(f"Limited to first {limit} turns")

    if not turn_ids:
        logger.info("No turns to process!")
        return

    # Process turns with load balancing across multiple LLMs
    success_count = 0
    fail_count = 0
    start_time = time.time()

    # Get all available LLMs for parallel processing
    from maxwell.lm_pool import LLMClient, LLMPool

    pool = LLMPool.from_registry()
    available_llms = list(pool.llms.values())
    logger.info(
        f"Load balancing across {len(available_llms)} LLMs: {[llm.name for llm in available_llms]}"
    )

    # Create multiple extractors, one per LLM
    extractors = []
    for llm_spec in available_llms:
        extractor = MetadataExtractor(mongodb_uri=mongodb_uri, mongodb_db=mongodb_db)
        extractor.llm = LLMClient(llm_spec)  # Override with specific LLM
        extractors.append(extractor)
        logger.info(
            f"Created extractor for {llm_spec.name} ({llm_spec.capabilities['speed_tokens_per_sec']} tok/s)"
        )

    # Use round-robin assignment of turns to extractors
    from itertools import cycle

    extractor_cycle = cycle(extractors)

    # Process turns in parallel using threading
    from concurrent.futures import ThreadPoolExecutor, as_completed

    def extract_turn(turn_id, extractor_instance):
        """Extract metadata for a single turn using the specified extractor."""
        try:
            metadata = extractor_instance.extract(turn_id, force_refresh=not skip_existing)
            return turn_id, metadata, None
        except Exception as e:
            return turn_id, None, str(e)

    # Submit all turns for parallel processing
    with ThreadPoolExecutor(max_workers=len(extractors)) as executor:
        # Create future tasks
        future_to_turn = {}
        for turn_id in turn_ids:
            extractor = next(extractor_cycle)
            future = executor.submit(extract_turn, turn_id, extractor)
            future_to_turn[future] = turn_id

        # Process completed tasks
        for future in as_completed(future_to_turn):
            turn_id, metadata, error = future.result()
            if metadata:
                success_count += 1
            else:
                fail_count += 1
                if error:
                    logger.warning(f"Failed to extract {turn_id}: {error}")

    # Final stats
    elapsed = time.time() - start_time
    logger.info("=" * 60)
    logger.info("BATCH EXTRACTION COMPLETE")
    logger.info("=" * 60)
    logger.info(f"Total processed: {len(turn_ids)}")
    logger.info(f"Success: {success_count}")
    logger.info(f"Failed: {fail_count}")
    logger.info(f"Time: {elapsed/60:.1f} minutes")
    logger.info(f"Rate: {len(turn_ids)/elapsed:.1f} turns/sec")

    # Show collection stats
    total_metadata = metadata_collection.count_documents({})
    logger.info(f"\nTotal metadata in MongoDB: {total_metadata:,}")

    # Show Qdrant stats
    try:
        from qdrant_client import QdrantClient

        qdrant = QdrantClient(host="localhost", port=6333)
        info = qdrant.get_collection("chat_turns")
        logger.info(f"Total embeddings in Qdrant: {info.points_count:,}")
    except Exception as e:
        logger.warning(f"Could not get Qdrant stats: {e}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Batch extract metadata for all chat turns")
    parser.add_argument("--limit", type=int, help="Limit number of turns to process (for testing)")
    parser.add_argument("--force", action="store_true", help="Re-extract even if metadata exists")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    batch_extract_all(limit=args.limit, skip_existing=not args.force)
```

---
### File: src/maxwell/workflows/chat/bm25_search.py

```python
"""BM25 search workflow for chat turns - fast keyword-based retrieval.

Architecture:
- BM25Okapi algorithm for keyword scoring
- Simple tokenization (lowercase + split)
- Index built on-demand from MongoDB turns collection
- Fast search: ~5ms for 5,812 turns
- Maxwell workflow interface for MCP access

Usage:
    # Direct usage
    from maxwell.workflows.chat.bm25_search import BM25Searcher

    searcher = BM25Searcher()
    results = searcher.search("maxwell architecture deduplication", top_k=10)

    # Via Maxwell workflow
    from maxwell.registry import get_workflow

    workflow = get_workflow("chat-bm25-search")
    result = workflow.execute(Path.cwd(), {"query": "maxwell architecture", "limit": 10})
"""

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from pymongo import MongoClient
from rank_bm25 import BM25Okapi

from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowMetrics,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


def tokenize(text: str) -> List[str]:
    """Simple tokenizer: lowercase + split on whitespace/punctuation.

    Args:
        text: Text to tokenize

    Returns:
        List of tokens

    """
    # Lowercase and split on whitespace/punctuation
    text = text.lower()
    # Keep alphanumeric and some technical chars (-, _, .)
    tokens = re.findall(r"\b[\w\-_.]+\b", text)
    return tokens


class BM25Searcher:
    """BM25 search over chat turns."""

    def __init__(
        self, mongodb_uri: str = "mongodb://localhost:27017", mongodb_db: str = "chat_analytics"
    ):
        """Initialize BM25 searcher.

        Args:
            mongodb_uri: MongoDB connection URI
            mongodb_db: MongoDB database name

        """
        self.mongo_client = MongoClient(mongodb_uri)
        self.mongo_db = self.mongo_client[mongodb_db]
        self.turns_collection = self.mongo_db["turns"]

        # BM25 index (built on-demand)
        self.bm25 = None
        self.corpus = None  # List of turn documents
        self.tokenized_corpus = None  # Tokenized documents

        logger.info("BM25Searcher initialized")

    def build_index(self, rebuild: bool = False):
        """Build BM25 index from turns collection.

        Args:
            rebuild: Force rebuild even if index exists

        """
        if self.bm25 is not None and not rebuild:
            logger.info("BM25 index already built")
            return

        logger.info("Building BM25 index from turns collection...")

        # Load all turns
        self.corpus = list(self.turns_collection.find({}))
        logger.info(f"Loaded {len(self.corpus)} turns")

        if not self.corpus:
            logger.warning("No turns found in collection")
            return

        # Tokenize all combined_text fields
        self.tokenized_corpus = [tokenize(turn.get("combined_text", "")) for turn in self.corpus]

        # Build BM25 index
        self.bm25 = BM25Okapi(self.tokenized_corpus)
        logger.info("✓ BM25 index built")

    def search(
        self, query: str, top_k: int = 10, filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Search turns using BM25.

        Args:
            query: Search query
            top_k: Number of results to return
            filters: Optional MongoDB filters (e.g., {"source": "chatgpt"})

        Returns:
            List of turn documents with scores

        """
        # Build index if needed
        if self.bm25 is None:
            self.build_index()

        if not self.corpus or self.bm25 is None:
            return []

        # Tokenize query
        query_tokens = tokenize(query)

        # Get BM25 scores
        scores = self.bm25.get_scores(query_tokens)

        # Apply filters if provided
        if filters:
            valid_indices = []
            for i, turn in enumerate(self.corpus):
                match = all(turn.get(key) == value for key, value in filters.items())
                if match:
                    valid_indices.append(i)

            # Filter scores
            filtered_results = [(i, scores[i]) for i in valid_indices]
        else:
            filtered_results = list(enumerate(scores))

        # Sort by score descending
        filtered_results.sort(key=lambda x: x[1], reverse=True)

        # Take top-k
        top_results = filtered_results[:top_k]

        # Build result documents
        results = []
        for idx, score in top_results:
            turn = self.corpus[idx].copy()
            turn["bm25_score"] = float(score)
            results.append(turn)

        return results

    def search_by_source(self, query: str, source: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """Search within a specific source (chatgpt or claude).

        Args:
            query: Search query
            source: "chatgpt" or "claude"
            top_k: Number of results to return

        Returns:
            List of turn documents with scores

        """
        return self.search(query, top_k=top_k, filters={"source": source})

    def search_by_machine(self, query: str, machine: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """Search Claude turns from a specific machine.

        Args:
            query: Search query
            machine: Machine name (e.g., "vanguard", "backup-mac")
            top_k: Number of results to return

        Returns:
            List of turn documents with scores

        """
        return self.search(query, top_k=top_k, filters={"machine": machine})

    def get_stats(self) -> Dict[str, Any]:
        """Get index statistics.

        Returns:
            Dictionary with index stats

        """
        if self.bm25 is None:
            self.build_index()

        if not self.corpus:
            return {
                "total_turns": 0,
                "chatgpt_turns": 0,
                "claude_turns": 0,
                "machines": {},
                "index_built": self.bm25 is not None,
            }

        total_turns = len(self.corpus)

        # Count by source
        chatgpt_count = sum(1 for t in self.corpus if t.get("source") == "chatgpt")
        claude_count = sum(1 for t in self.corpus if t.get("source") == "claude")

        # Count by machine (Claude only)
        machines = {}
        for turn in self.corpus:
            if turn.get("source") == "claude":
                machine = turn.get("machine", "unknown")
                machines[machine] = machines.get(machine, 0) + 1

        return {
            "total_turns": total_turns,
            "chatgpt_turns": chatgpt_count,
            "claude_turns": claude_count,
            "machines": machines,
            "index_built": self.bm25 is not None,
        }


@register_workflow
class ChatBM25SearchWorkflow(BaseWorkflow):
    """Chat BM25 search workflow - Maxwell workflow interface for BM25Searcher."""

    # Workflow metadata
    workflow_id: str = "chat-bm25-search"
    name: str = "Chat BM25 Search"
    description: str = "Search chat conversations using BM25 keyword matching"
    version: str = "1.0"
    category: str = "chat-search"
    tags: set = {"bm25", "search", "chat", "keyword"}

    def __init__(self):
        self.workflow_id = "chat-bm25-search"
        self.name = "Chat BM25 Search"
        self.description = "Search chat conversations using BM25 keyword matching"
        self.version = "1.0"
        super().__init__()

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=300,  # 5 minutes
            parameters={
                "root_dir": str(root_dir),
            },
        )

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters for maxwell chat-bm25-search command.

        CLI Usage:
            maxwell chat-bm25-search --query "your search query" [--limit 10] [--source chatgpt|claude]

        Examples:
            # Search all chat conversations
            maxwell chat-bm25-search --query "maxwell architecture"

            # Search only ChatGPT conversations
            maxwell chat-bm25-search --query "python programming" --source chatgpt --limit 5

            # Search only Claude conversations
            maxwell chat-bm25-search --query "file system" --source claude

        """
        return [
            {
                "name": "query",
                "type": str,
                "required": True,
                "help": "Search query for BM25 keyword search",
            },
            {
                "name": "limit",
                "type": int,
                "required": False,
                "default": 10,
                "help": "Number of results to return (default: 10)",
            },
            {
                "name": "source",
                "type": str,
                "required": False,
                "help": "Filter by source: chatgpt or claude",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        """Get required inputs."""
        return ["query"]

    def get_produced_outputs(self) -> List[str]:
        """Get produced outputs."""
        return ["results", "report"]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute BM25 search using BM25Searcher.

        Args:
            project_root: Root directory (not used for chat search)
            context: Dictionary containing:
                - query (str): Search query
                - limit (int, optional): Number of results (default: 10)
                - source (str, optional): Filter by source

        Returns:
            WorkflowResult with BM25 search results and formatted report

        """
        try:
            query = context.get("query")
            limit = context.get("limit", 10)
            source = context.get("source")

            if not query:
                raise ValueError("Query is required for BM25 search")

            # Use BM25Searcher directly
            searcher = BM25Searcher()

            # Apply source filter if provided
            filters = {"source": source} if source else None
            results = searcher.search(query, top_k=limit, filters=filters)

            # Format results
            report = self._format_results(results, query, source)

            # Get search stats
            stats = searcher.get_stats()

            # Return success
            metrics = WorkflowMetrics(
                start_time=0.0,
                end_time=0.0,
                files_processed=len(results),
                custom_metrics={
                    "results_count": len(results),
                    "search_type": "BM25",
                    "query": query,
                    "source_filter": source,
                    "total_turns_indexed": stats.get("total_turns", 0),
                },
            )
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.COMPLETED,
                metrics=metrics,
                artifacts={
                    "results": results,
                    "results_count": len(results),
                    "search_type": "BM25",
                    "query": query,
                    "source_filter": source,
                    "stats": stats,
                    "report": report,
                },
            )

        except Exception as e:
            logger.error(f"BM25 search failed: {e}", exc_info=True)
            metrics = WorkflowMetrics(
                start_time=0.0, end_time=0.0, files_processed=0, errors_encountered=1
            )
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.FAILED,
                metrics=metrics,
                error_message=f"BM25 search failed: {str(e)}",
            )

    def _format_results(
        self, results: List[Dict[str, Any]], query: str, source_filter: Optional[str] = None
    ) -> str:
        """Format BM25 results for display.

        Args:
            results: List of BM25 search results
            query: Original search query
            source_filter: Optional source filter applied

        Returns:
            Formatted string for display

        """
        lines = []
        lines.append(f"🔍 BM25 search for: {query}")
        if source_filter:
            lines.append(f"🎯 Source filter: {source_filter}")
        lines.append(f"📊 Found {len(results)} results:\n")

        for i, result in enumerate(results, 1):
            turn_id = result.get("turn_id", "Unknown")
            score = result.get("bm25_score", 0.0)
            source = result.get("source", "unknown")
            machine = result.get("machine", "")
            project_path = result.get("project_path", "")
            combined_text = result.get("combined_text", "")

            lines.append(f"Result {i}/{len(results)}")
            lines.append(f"🎯 Score: {score:.3f} | ID: {turn_id} | Source: {source}")

            if machine:
                lines.append(f"🖥️  Machine: {machine}")
            if project_path:
                lines.append(f"📁 Project: {project_path}")

            if combined_text:
                snippet = combined_text[:150] + "..." if len(combined_text) > 150 else combined_text
                lines.append(f"📄 Content: {snippet}")

            lines.append("-" * 80)

        lines.append(f"\n✨ Search complete! Found {len(results)} results.")
        return "\n".join(lines)


def search_cli(query: str, top_k: int = 10, source: Optional[str] = None):
    """CLI interface for BM25 search.

    Args:
        query: Search query
        top_k: Number of results to return
        source: Optional source filter ("chatgpt" or "claude")

    """
    searcher = BM25Searcher()

    # Search
    if source:
        results = searcher.search_by_source(query, source, top_k=top_k)
    else:
        results = searcher.search(query, top_k=top_k)

    # Display results
    if not results:
        print(f"No results found for query: {query}")
        return

    print(f"Found {len(results)} results for query: {query}")
    if source:
        print(f"Source: {source}")
    print("-" * 80)

    for i, result in enumerate(results, 1):
        print(f"\n{i}. Score: {result.get('bm25_score', 0.0):.3f}")
        print(f"   ID: {result.get('turn_id', 'Unknown')}")
        print(f"   Source: {result.get('source', 'unknown')}")

        if result.get("machine"):
            print(f"   Machine: {result['machine']}")
        if result.get("project_path"):
            print(f"   Project: {result['project_path']}")

        # Show preview
        combined = result.get("combined_text", "")
        preview = combined[:300].replace("\n", " ")
        print(f"   Preview: {preview}...")

    # Show stats
    stats = searcher.get_stats()
    print("\n📊 Index Stats:")
    print(f"   Total turns: {stats['total_turns']}")
    print(f"   ChatGPT turns: {stats['chatgpt_turns']}")
    print(f"   Claude turns: {stats['claude_turns']}")

    if stats["machines"]:
        print(f"   Machines: {stats['machines']}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="BM25 search for chat turns")
    parser.add_argument("query", type=str, help="Search query")
    parser.add_argument("--top-k", type=int, default=10, help="Number of results (default: 10)")
    parser.add_argument(
        "--source", type=str, choices=["chatgpt", "claude"], help="Filter by source"
    )

    args = parser.parse_args()

    search_cli(args.query, top_k=args.top_k, source=args.source)
```

---
### File: src/maxwell/workflows/chat/data_quality.py

```python
#!/usr/bin/env python3
"""Chat data quality and cleanup workflow.

This workflow provides:
1. Chat data validation and cleaning
2. MongoDB collection maintenance
3. Qdrant integration monitoring
"""

import time
from pathlib import Path
from typing import Any, Dict, List, Set

from pymongo import MongoClient
from pymongo.database import Database

from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)


class ChatDataQualityWorkflow(BaseWorkflow):
    """Chat data quality and cleanup workflow."""

    # Workflow metadata
    workflow_id: str = "chat-data-quality"
    name: str = "Chat Data Quality & Cleanup"
    description: str = "Validates, cleans, and maintains MongoDB chat collections"
    version: str = "1.0"
    category: str = "chat"
    tags: Set[str] = {"chat", "quality", "etl", "mongodb"}

    def __init__(self):
        self.workflow_id = "chat-data-quality"
        self.name = "Chat Data Quality & Cleanup"
        self.description = "Validates, cleans, and maintains MongoDB chat collections"
        self.version = "1.0"
        super().__init__()

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=1800,  # 30 minutes
            cache_results=True,
            parameters={
                "root_dir": str(root_dir),
                "mongodb_uri": "mongodb://localhost:27017",
                "qdrant_url": "http://localhost:6333",
                "collection_name": "chat_turns",
                "embedding_service": {"url": "http://localhost:8001", "model": "qwen2-embedder"},
            },
        )

    def get_required_inputs(self) -> List[str]:
        """Get required input data keys."""
        return ["root_dir"]

    def get_produced_outputs(self) -> List[str]:
        """Get output data keys this workflow produces."""
        return ["quality_report", "collection_stats", "embeddings_report"]

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Get CLI parameters for maxwell chat-data-quality command."""
        return [
            {
                "name": "operation",
                "type": str,
                "required": False,
                "help": "Operation to perform: validate, clean, backup, rebuild-index",
                "choices": ["validate", "clean", "backup", "rebuild-index", "quality-report"],
            },
            {
                "name": "limit",
                "type": int,
                "required": False,
                "help": "Limit number of turns to process (default: 1000)",
                "default": 1000,
            },
            {
                "name": "dry-run",
                "type": bool,
                "required": False,
                "help": "Only analyze what would be done without making changes (default: False)",
            },
            {
                "name": "force-rebuild",
                "type": bool,
                "required": False,
                "help": "Force rebuild of all indexes (default: False)",
            },
        ]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute chat data quality workflow."""
        try:
            mongodb_uri = context.get("mongodb_uri", "mongodb://localhost:27017")
            collection_name = context.get("collection_name", "chat_turns")
            limit = context.get("limit", 1000)

            # Connect to MongoDB
            client = MongoClient(mongodb_uri)
            db = client[collection_name.rsplit("/", 1)[0]]  # Get database from URI

            # Report initial collection stats
            start_time = time.time()
            initial_stats = {
                "total_turns": db[collection_name].count_documents({}),
                "chatgpt_turns": db[collection_name].count_documents({"source": "chatgpt"}),
                "claude_turns": db[collection_name].count_documents({"source": "claude"}),
            }

            print(f"🔍 Initial collection stats: {initial_stats}")

            # Define quality checks
            quality_issues = {
                "corrupted_content": 0,
                "empty_turns": 0,
                "short_turns": 0,
                "duplicate_turns": 0,
                "format_errors": 0,
                "missing_metadata": 0,
            }

            # Process turns in batches
            processed_count = 0
            batch_size = 100
            cursor = db[collection_name].find({})

            for batch_num, batch in enumerate(self._create_batches(cursor, batch_size)):
                if len(batch) == 0:
                    continue

                print(f"🔄 Processing batch {batch_num + 1}: {len(batch)} turns...")

                # Validate each turn and collect validation results
                validation_results = []
                for turn in batch:
                    validation_result = self._validate_turn(turn, db, collection_name)
                    validation_results.append(validation_result)
                    for issue_type, issues in validation_result.items():
                        if issues:
                            quality_issues[issue_type] += len(issues)

                # Apply fixes if any validation issues found
                has_issues = any(any(vr.values()) for vr in validation_results)
                if has_issues:
                    print(f"🔧 Applying fixes to batch {batch_num + 1}...")
                    success = self._apply_fixes(batch, validation_results, db, collection_name)
                    if success:
                        print(f"✅ Fixed {len(batch)} turns")
                    else:
                        print(f"❌ Failed to fix batch {batch_num + 1}")

                processed_count += len(batch)

                # Progress reports
                if batch_num % 10 == 0:
                    elapsed = time.time() - start_time
                    print(
                        f"📊 Batch {batch_num + 1}: {processed_count} turns processed in {elapsed:.1f}s"
                    )
                    print(f"🔍 Total: {processed_count} turns processed so far")

            # Final report
            end_time = time.time()
            elapsed = end_time - start_time
            final_stats = {
                "total_turns_processed": processed_count,
                "quality_issues_found": quality_issues,
                "duration_seconds": elapsed,
                "turns_per_second": processed_count / elapsed if elapsed > 0 else 0,
            }

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.COMPLETED,
                metrics=self.metrics,
                artifacts={
                    "quality_report": final_stats,
                    "collection_stats": final_stats,
                    "operation": context.get("operation", "validate"),
                    "turns_processed": processed_count,
                    "batch_size": batch_size,
                    "limit": limit,
                },
            )

        except Exception as e:
            print(f"❌ Workflow failed: {e}")
            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.FAILED,
                metrics=self.metrics,
                error_message=str(e),
            )

    def _validate_turn(
        self, turn: Dict, db: Database, collection_name: str
    ) -> Dict[str, List[str]]:
        """Validate a single chat turn for quality issues."""
        issues: Dict[str, List[str]] = {}

        # Check for empty or very short content
        content = turn.get("content", "")
        if not content or len(content.strip()) < 10:
            issues["empty_turns"] = [f"Empty turn: {turn.get('turn_id', 'unknown')}"]

        # Check for unprintable characters
        try:
            content.encode("ascii")
            # If it contains unprintable chars, likely corrupted
            issues["corrupted_content"] = [
                f"Corrupted content in turn {turn.get('turn_id', 'unknown')}"
            ]
        except UnicodeEncodeError:
            issues["encoding_issues"] = [f"Encoding error in turn {turn.get('turn_id', 'unknown')}"]

        # Check for JSON structure
        if turn.get("source") and not isinstance(turn.get("conversation_id"), (str, dict)):
            issues["format_errors"] = [
                f"Invalid conversation structure in turn {turn.get('turn_id', 'unknown')}"
            ]

        # Check for duplicate content using content hash
        content_length = turn.get("content_length")
        if turn.get("content_hash") and content_length is not None and content_length > 0:
            # Check for other turns with same hash in same conversation
            duplicate = db[collection_name].find_one(
                {
                    "conversation_id": turn.get("conversation_id"),
                    "content_hash": turn.get("content_hash"),
                    "turn_id": {"$ne": turn.get("turn_id")},
                }
            )
            if duplicate:
                issues["duplicate_turns"] = [f"Duplicate turn: {turn.get('turn_id', 'unknown')}"]

        # Check for missing required fields
        required_fields = ["turn_id", "role", "content", "conversation_id", "source"]
        for field in required_fields:
            if not turn.get(field):
                issues["missing_metadata"] = [
                    f"Missing field: {field} in turn {turn.get('turn_id', 'unknown')}"
                ]

        return issues

    def _apply_fixes(
        self,
        batch: List[Dict],
        validation_results: List[Dict[str, List[str]]],
        db: Database,
        collection_name: str,
    ) -> bool:
        """Apply fixes to a batch of turns."""
        try:
            for turn, validation_result in zip(batch, validation_results):
                issues = validation_result
                if not issues:
                    continue

                print(f"🔧 Applying {len(issues)} fixes to turn...")

                for issue_type, issue_list in issues.items():
                    for issue in issue_list:
                        if issue_type == "corrupted_content":
                            # Remove corrupted turn
                            db[collection_name].delete_one({"turn_id": turn["turn_id"]})
                            print(f"🗑️  Removed corrupted turn: {turn['turn_id']}")

                        elif issue_type == "encoding_issues":
                            # Could try to re-encode, but removal is safer
                            db[collection_name].delete_one({"turn_id": turn["turn_id"]})
                            print(f"🗑️  Removed encoding error turn: {turn['turn_id']}")

                        elif issue_type == "format_errors":
                            # Could try to fix JSON, but removal is safer
                            db[collection_name].delete_one({"turn_id": turn["turn_id"]})
                            print(f"🗑️  Removed format error turn: {turn['turn_id']}")

                        elif issue_type == "missing_metadata":
                            # Could try to reconstruct, but removal is safer
                            db[collection_name].delete_one({"turn_id": turn["turn_id"]})
                            print(f"🗑️  Removed malformed turn: {turn['turn_id']}")

                        elif issue_type == "empty_turns":
                            # Remove empty turn
                            db[collection_name].delete_one({"turn_id": turn["turn_id"]})
                            print(f"🗑️  Removed empty turn: {turn['turn_id']}")

                        elif issue_type == "duplicate_turns":
                            # Keep the first occurrence, remove duplicates
                            # This is complex - would need tracking and deduplication logic
                            pass  # Simplify for now

            return True

        except Exception as e:
            print(f"❌ Error applying fixes to batch: {e}")
            return False

    def _create_batches(self, cursor, batch_size: int) -> List[List[Dict]]:
        """Create batches from cursor."""
        batches = []
        batch = []
        for turn in cursor:
            batch.append(turn)
            if len(batch) >= batch_size:
                batches.append(batch)
                batch = []

        return batches


def main():
    """Main execution method."""
    import argparse

    parser = argparse.ArgumentParser(description="Chat data quality and cleanup workflow")
    parser.add_argument(
        "operation",
        choices=["validate", "clean", "backup", "rebuild-index", "quality-report"],
        help="Operation to perform",
    )
    parser.add_argument("--limit", type=int, default=1000, help="Limit number of turns to process")
    parser.add_argument(
        "--dry-run", action="store_true", help="Only analyze without making changes"
    )
    parser.add_argument("--force-rebuild", action="store_true", help="Force rebuild of all indexes")
    parser.add_argument("--root-dir", type=str, default=".", help="Root directory")

    args = parser.parse_args()

    # Create workflow and run
    workflow = ChatDataQualityWorkflow()

    # Get config for defaults
    config = workflow.get_config(Path(args.root_dir))

    # Build context dict from config + args
    context = {
        **config.parameters,
        "operation": args.operation,
        "limit": args.limit,
        "dry_run": args.dry_run,
        "force_rebuild": args.force_rebuild,
    }

    # Execute workflow
    print("🚀 Starting chat data quality workflow...")
    result = workflow.execute(Path(args.root_dir), context)

    if result.status == WorkflowStatus.COMPLETED:
        print("✅ Chat data quality workflow completed successfully!")
        if result.artifacts and "quality_report" in result.artifacts:
            report = result.artifacts["quality_report"]
            print("\n📊 QUALITY REPORT")
            print("=" * 50)
            for key, value in report.items():
                if isinstance(value, dict) and value:
                    print(f"  {key}: {value}")
                elif isinstance(value, (list, tuple)):
                    for item in value:
                        print(f"  {key}: {item}")
                else:
                    print(f"  {key}: {value}")
        else:
            print("\n🎉 No quality issues found!")

    elif result.status == WorkflowStatus.FAILED:
        error_msg = result.error_message if result.error_message else "Unknown error"
        print(f"❌ Chat data quality workflow failed: {error_msg}")
    else:
        print("⚠️ Chat data quality workflow completed with warnings")

    return 0
```

---
### File: src/maxwell/workflows/chat/incremental_processor.py

```python
"""Incremental processing workflow for chat files.

Registers as "chat_incremental" workflow in Maxwell's registry.
Leverages Maxwell's content-addressable storage for deduplication:
- Tracks processed files in .maxwell/chat_registry.json
- Uses file content hashes (SHA256) to detect changes
- Only processes new/modified chat files
- Integrates with existing BaseWorkflow system

Usage:
    from maxwell.workflows.chat.incremental_processor import IncrementalChatWorkflow

    workflow = IncrementalChatWorkflow()
    result = workflow.run(chat_root=Path("~/.claude/projects"))
"""

import hashlib
import json
import logging
import os
import socket
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pymongo import MongoClient

from maxwell.registry import register_workflow
from maxwell.storage import ContentHasher
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowMetrics,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)
from maxwell.workflows.chat.parsers import ChatGPTParser, ClaudeParser


@dataclass
class ChatProcessingInputs:
    """Typed inputs for chat processing workflow."""

    chatgpt_path: Optional[str] = None
    claude_backup_path: Optional[str] = None
    claude_projects_path: Optional[str] = None
    dry_run: bool = False


@dataclass
class ChatProcessingOutputs:
    """Typed outputs for chat processing workflow."""

    processing_stats: Dict[str, Any]
    turns_processed: int
    sources_processed: int


logger = logging.getLogger(__name__)


class IncrementalChatProcessor:
    """Incremental processor for chat logs with deduplication."""

    def __init__(
        self,
        chat_root: Path,
        maxwell_root: Optional[Path] = None,
        source_type: str = "claude",
        mongodb_uri: str = "mongodb://localhost:27017",
    ):
        """Initialize incremental processor.

        Args:
            chat_root: Root directory containing chat files
            maxwell_root: Maxwell project root (defaults to current working directory)
            source_type: Type of source ("claude", "chatgpt", "claude-backup")
            mongodb_uri: MongoDB connection URI

        """
        self.chat_root = Path(chat_root).resolve()
        self.maxwell_root = Path(maxwell_root).resolve() if maxwell_root else Path.cwd().resolve()
        self.source_type = source_type
        self.machine_hostname = socket.gethostname()

        # Maxwell storage paths
        self.maxwell_dir = self.maxwell_root / ".maxwell"
        self.registry_file = self.maxwell_dir / f"chat_registry_{source_type}.json"

        # Use Maxwell's content hasher for consistency
        self.hasher = ContentHasher()

        # MongoDB connection
        self.mongo_client = MongoClient(mongodb_uri)
        self.mongo_db = self.mongo_client["chat_analytics"]
        self.turns_collection = self.mongo_db["turns"]

        # Create indexes for deduplication
        self.turns_collection.create_index("turn_id", unique=True)
        self.turns_collection.create_index("source")
        self.turns_collection.create_index("conversation_id")

        # Ensure .maxwell directory exists
        self.maxwell_dir.mkdir(parents=True, exist_ok=True)

        # Load processed file registry
        self.registry = self._load_registry()

        logger.info("Initialized incremental chat processor")
        logger.info(f"Source type: {self.source_type}")
        logger.info(f"Chat root: {self.chat_root}")
        logger.info(f"Maxwell root: {self.maxwell_root}")
        logger.info(f"Machine: {self.machine_hostname}")
        logger.info(f"Previously processed files: {len(self.registry)}")

    def _load_registry(self) -> Dict[str, Dict]:
        """Load registry of processed files."""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, "r") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load registry: {e}")
        return {}

    def _save_registry(self):
        """Save registry of processed files."""
        try:
            with open(self.registry_file, "w") as f:
                json.dump(self.registry, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save registry: {e}")

    def _get_file_hash(self, file_path: Path) -> str:
        """Calculate content hash using Maxwell's hasher."""
        try:
            # Use Maxwell's content hasher for consistency
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            return self.hasher.hash_content(content)
        except Exception as e:
            logger.error(f"Failed to hash {file_path}: {e}")
            return ""

    def _should_process_file(self, file_path: Path) -> tuple[bool, str]:
        """Check if file should be processed based on registry and hash.

        Returns:
            (should_process, reason)

        """
        if not file_path.exists():
            return False, "File does not exist"

        if not file_path.suffix == ".jsonl":
            return False, "Not a JSONL file"

        # Get current file hash using Maxwell's hasher
        current_hash = self._get_file_hash(file_path)
        if not current_hash:
            return False, "Failed to calculate hash"

        # Check registry
        file_key = str(file_path.relative_to(self.chat_root))
        if file_key in self.registry:
            processed_info = self.registry[file_key]
            if processed_info.get("content_hash") == current_hash:
                # Check if processing was complete
                if processed_info.get("status") == "completed":
                    return False, f"Already processed (hash: {current_hash[:8]}...)"
                else:
                    return True, f"Previously incomplete (hash: {current_hash[:8]}...)"

        return True, f"New or modified (hash: {current_hash[:8]}...)"

    def _register_file(self, file_path: Path, status: str, metadata: Optional[Dict] = None):
        """Register file as processed with its hash and metadata."""
        file_key = str(file_path.relative_to(self.chat_root))
        content_hash = self._get_file_hash(file_path)

        self.registry[file_key] = {
            "content_hash": content_hash,
            "status": status,
            "processed_at": datetime.now().isoformat(),
            "file_size": file_path.stat().st_size if file_path.exists() else 0,
            "metadata": metadata or {},
        }

        self._save_registry()

    def discover_chat_files(self) -> Set[Path]:
        """Discover all chat files in directory tree."""
        chat_files = set()

        if not self.chat_root.exists():
            logger.error(f"Chat root does not exist: {self.chat_root}")
            return chat_files

        # Different discovery patterns based on source type
        if self.source_type == "chatgpt":
            # ChatGPT uses conversations.json
            for json_file in self.chat_root.rglob("conversations.json"):
                chat_files.add(json_file)
            logger.info(f"Discovered {len(chat_files)} ChatGPT conversation files")
        else:
            # Claude uses JSONL files
            for jsonl_file in self.chat_root.rglob("*.jsonl"):
                chat_files.add(jsonl_file)
            logger.info(f"Discovered {len(chat_files)} JSONL files")

        return chat_files

    def get_file_stats(self, file_path: Path) -> Dict:
        """Get basic statistics about a chat file."""
        try:
            line_count = sum(1 for _ in open(file_path, "r", encoding="utf-8"))
            file_size = file_path.stat().st_size

            return {
                "line_count": line_count,
                "file_size_bytes": file_size,
                "file_size_mb": file_size / (1024 * 1024),
            }
        except Exception as e:
            logger.error(f"Error getting stats for {file_path}: {e}")
            return {"line_count": 0, "file_size_bytes": 0, "file_size_mb": 0}

    def _create_turn_id(self, source: str, file_path: str, message_index: int) -> str:
        """Create unique turn ID."""
        id_string = f"{source}:{file_path}:{message_index}"
        return hashlib.sha256(id_string.encode()).hexdigest()[:16]

    def _process_claude_file(self, file_path: Path) -> int:
        """Process Claude JSONL file and load into MongoDB."""
        try:
            parser = ClaudeParser(file_path)
            messages = list(parser.parse())

            if not messages:
                logger.warning(f"No messages found in {file_path}")
                return 0

            # Extract project info from path
            relative_path = file_path.relative_to(self.chat_root)
            project_path = str(relative_path.parent)
            conversation_title = file_path.stem

            # Process each message as a turn
            turns_inserted = 0
            for i, message in enumerate(messages):
                if message.role not in ["user", "assistant"]:
                    continue

                # Create turn document
                turn_id = self._create_turn_id(self.source_type, str(file_path), i)

                turn_doc = {
                    "turn_id": turn_id,
                    "source": self.source_type,
                    "conversation_id": conversation_title,
                    "title": conversation_title,
                    "file_path": str(file_path),
                    "project_path": project_path,
                    "role": message.role,
                    "content": message.text,
                    "timestamp": message.timestamp,
                    "message_index": message.message_index,
                    "total_messages": len(messages),
                    "machine": self.machine_hostname,
                    "account": self._extract_account_from_path(file_path),
                    "loaded_at": datetime.utcnow().isoformat(),
                    "combined_text": f"[{message.role.upper()}]: {message.text}",
                    "char_count": message.char_count,
                    "token_count": message.token_count,
                }

                # Upsert to avoid duplicates
                self.turns_collection.update_one(
                    {"turn_id": turn_id}, {"$set": turn_doc}, upsert=True
                )
                turns_inserted += 1

            logger.info(f"✅ Processed {file_path.name}: {turns_inserted} turns")
            return turns_inserted

        except Exception as e:
            logger.error(f"Failed to process Claude file {file_path}: {e}")
            return 0

    def _process_chatgpt_file(self, file_path: Path) -> int:
        """Process ChatGPT conversations.json file and load into MongoDB."""
        try:
            parser = ChatGPTParser(file_path)
            messages = list(parser.parse())

            if not messages:
                logger.warning(f"No messages found in {file_path}")
                return 0

            # Group messages by conversation
            conversations = {}
            for msg in messages:
                conv_id = msg.conversation_id
                if conv_id not in conversations:
                    conversations[conv_id] = []
                conversations[conv_id].append(msg)

            # Process each conversation
            turns_inserted = 0
            for conv_id, conv_messages in conversations.items():
                # Get conversation metadata
                first_msg = conv_messages[0] if conv_messages else None
                if not first_msg:
                    continue

                for i, message in enumerate(conv_messages):
                    if message.role not in ["user", "assistant"]:
                        continue

                    # Create turn document
                    turn_id = self._create_turn_id(
                        "chatgpt", str(file_path), len(conversations[conv_id]) + i
                    )

                    turn_doc = {
                        "turn_id": turn_id,
                        "source": "chatgpt",
                        "conversation_id": message.conversation_id,
                        "title": message.conversation_title,
                        "file_path": str(file_path),
                        "role": message.role,
                        "content": message.text,
                        "timestamp": message.timestamp,
                        "message_index": i,
                        "total_messages": len(conv_messages),
                        "machine": self.machine_hostname,
                        "account": self._extract_account_from_path(file_path),
                        "loaded_at": datetime.utcnow().isoformat(),
                        "combined_text": f"[{message.role.upper()}]: {message.text}",
                        "char_count": message.char_count,
                        "token_count": message.token_count,
                    }

                    # Upsert to avoid duplicates
                    self.turns_collection.update_one(
                        {"turn_id": turn_id}, {"$set": turn_doc}, upsert=True
                    )
                    turns_inserted += 1

            logger.info(f"✅ Processed {file_path.name}: {turns_inserted} turns")
            return turns_inserted

        except Exception as e:
            logger.error(f"Failed to process ChatGPT file {file_path}: {e}")
            return 0

    def _extract_account_from_path(self, file_path: Path) -> str:
        """Extract account name from file path."""
        path_str = str(file_path)

        # Look for common account patterns
        if "users/" in path_str:
            users_idx = path_str.find("users/")
            after_users = path_str[users_idx + 6 :]
            account = after_users.split("/")[0]
            return account

        # Look for home directory pattern
        if "/home/" in path_str:
            home_idx = path_str.find("/home/")
            after_home = path_str[home_idx + 6 :]
            account = after_home.split("/")[0]
            return account

        # Default to current user
        return os.getenv("USER", "unknown")

    def run_incremental(self, dry_run: bool = False) -> Dict:
        """Run incremental analysis.

        Args:
            dry_run: If True, only analyze what would be processed

        Returns:
            Analysis statistics

        """
        discovered_files = self.discover_chat_files()

        stats = {
            "total_files": len(discovered_files),
            "new_files": 0,
            "modified_files": 0,
            "unchanged_files": 0,
            "processing_errors": 0,
            "files_to_process": [],
            "total_size_mb": 0,
        }

        logger.info("Analyzing files for incremental processing...")

        for file_path in sorted(discovered_files):
            should_process, reason = self._should_process_file(file_path)

            if should_process:
                file_stats = self.get_file_stats(file_path)
                relative_path = str(file_path.relative_to(self.chat_root))

                file_info = {
                    "path": relative_path,
                    "reason": reason,
                    "size_mb": file_stats["file_size_mb"],
                    "line_count": file_stats["line_count"],
                }

                stats["files_to_process"].append(file_info)
                stats["total_size_mb"] += file_stats["file_size_mb"]

                # Determine if new or modified
                if relative_path in self.registry:
                    stats["modified_files"] += 1
                else:
                    stats["new_files"] += 1

                if not dry_run:
                    logger.info(f"Processing {file_path.name}: {reason}")
                    try:
                        # Mark as processing
                        self._register_file(file_path, "processing", file_stats)

                        # Process the file based on source type
                        if self.source_type in ["claude", "claude-backup"]:
                            turns_processed = self._process_claude_file(file_path)
                        elif self.source_type == "chatgpt":
                            turns_processed = self._process_chatgpt_file(file_path)
                        else:
                            logger.warning(f"Unknown source type: {self.source_type}")
                            turns_processed = 0

                        # Mark as completed
                        self._register_file(
                            file_path,
                            "completed",
                            {**file_stats, "turns_processed": turns_processed},
                        )
                        logger.info(
                            f"✅ Completed processing {file_path.name}: {turns_processed} turns"
                        )

                    except Exception as e:
                        logger.error(f"Failed to process {file_path}: {e}")
                        self._register_file(file_path, "error", {"error": str(e)})
                        stats["processing_errors"] += 1
            else:
                stats["unchanged_files"] += 1
                logger.debug(f"Skipping {file_path.name}: {reason}")

        if dry_run:
            logger.info("DRY RUN - No files were actually processed")

        return stats

    def get_registry_status(self) -> Dict:
        """Get current registry status."""
        total_files = len(self.registry)
        completed_files = sum(
            1 for info in self.registry.values() if info.get("status") == "completed"
        )
        processing_files = sum(
            1 for info in self.registry.values() if info.get("status") == "processing"
        )
        error_files = sum(1 for info in self.registry.values() if info.get("status") == "error")

        return {
            "total_files": total_files,
            "completed": completed_files,
            "processing": processing_files,
            "errors": error_files,
            "completion_rate": completed_files / total_files if total_files > 0 else 0,
        }


def print_analysis_summary(stats: Dict):
    """Print formatted analysis summary."""
    print("\n" + "=" * 60)
    print("INCREMENTAL CHAT PROCESSING ANALYSIS")
    print("=" * 60)
    print(f"Total JSONL files discovered: {stats['total_files']}")
    print(f"Files to process: {stats['new_files'] + stats['modified_files']}")
    print(f"  New files: {stats['new_files']}")
    print(f"  Modified files: {stats['modified_files']}")
    print(f"Unchanged files: {stats['unchanged_files']}")
    print(f"Total size to process: {stats['total_size_mb']:.1f}MB")
    print(f"Processing errors: {stats['processing_errors']}")

    if stats["files_to_process"]:
        print("\nFiles that would be processed:")
        for file_info in stats["files_to_process"][:10]:  # Show first 10
            print(
                f"  {file_info['path']} ({file_info['size_mb']:.1f}MB, {file_info['line_count']} lines) - {file_info['reason']}"
            )

        if len(stats["files_to_process"]) > 10:
            print(f"  ... and {len(stats['files_to_process']) - 10} more files")
    else:
        print("\n✅ All files are up to date!")

    print("=" * 60)


class IncrementalChatWorkflow(BaseWorkflow):
    """Incremental chat processing workflow that integrates with Maxwell's registry."""

    def __init__(self):
        self.workflow_id = "chat_upsert"
        self.name = "Chat Upsert Processor"
        self.description = "Upserts chat files into MongoDB with deduplication"
        self.version = "1.0"
        super().__init__()

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=3600,  # 1 hour
            cache_results=True,
            parameters={
                "chat_root": str(root_dir),
                "maxwell_root": str(root_dir),
            },
        )

    def get_required_inputs(self) -> List[str]:
        """Get required input field names."""
        return []  # No required inputs - all sources are optional

    def get_produced_outputs(self) -> List[str]:
        """Get output field names this workflow produces."""
        return ["processing_stats", "turns_processed", "sources_processed"]

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters for maxwell chat-incremental command.

        CLI Usage:
            maxwell chat-incremental --source-path /path/to/chats --type claude [--dry-run]
            maxwell chat-incremental --source-path /path/to/chatgpt --type chatgpt [--dry-run]

        Examples:
            # Process Claude projects (default)
            maxwell chat-incremental

            # Process specific source with type
            maxwell chat-incremental --source-path ~/Documents/chatgpt --type chatgpt
            maxwell chat-incremental --source-path ~/Documents/claude-backup --type claude

            # Dry run to see what would be processed
            maxwell chat-incremental --dry-run

        """
        return [
            {
                "name": "source_path",
                "type": str,
                "required": False,
                "help": "Path to chat source directory (default: ~/.claude/projects)",
                "default": "~/.claude/projects",
            },
            {
                "name": "type",
                "type": str,
                "required": False,
                "help": "Source type: claude or chatgpt (auto-detect if not specified)",
                "choices": ["claude", "chatgpt"],
            },
            {
                "name": "dry_run",
                "type": bool,
                "required": False,
                "help": "Only analyze what would be processed without making changes",
                "default": False,
            },
            {
                "name": "limit",
                "type": int,
                "required": False,
                "help": "Limit number of turns to process (for smoke testing)",
                "default": None,
            },
        ]

    def execute(self, project_root: Path, context: Dict) -> WorkflowResult:
        """Execute incremental chat processing for all sources."""
        start_time = time.time()

        # Parse CLI parameters from context
        source_path = context.get("source_path", "~/.claude/projects")
        source_type = context.get("type")  # claude, chatgpt, or None for auto-detect

        # Build sources list from CLI parameters
        sources = []
        source_path = Path(source_path).expanduser()

        if source_type:
            # Use specified type
            sources.append(
                {
                    "name": f"{source_type}-specified",
                    "path": source_path,
                    "source_type": source_type,
                }
            )
        else:
            # Auto-detect: if conversations.json exists, assume ChatGPT, else Claude
            if (source_path / "conversations.json").exists():
                sources.append(
                    {"name": "chatgpt-detected", "path": source_path, "source_type": "chatgpt"}
                )
            else:
                sources.append(
                    {"name": "claude-detected", "path": source_path, "source_type": "claude"}
                )

        inputs = ChatProcessingInputs(
            chatgpt_path=str(source_path) if source_type == "chatgpt" else None,
            claude_backup_path=str(source_path) if source_type == "claude" else None,
            claude_projects_path=str(source_path) if not source_type else None,
            dry_run=context.get("dry_run", False),
        )

        maxwell_root = project_root
        total_stats = {
            "total_sources": len(sources),
            "sources_processed": 0,
            "total_files": 0,
            "total_turns_processed": 0,
            "total_errors": 0,
            "source_details": [],
        }

        logger.info(f"🚀 Starting incremental chat processing for {len(sources)} sources...")

        # Process each source
        for source in sources:
            source_name = source["name"]
            source_path = source["path"]

            if not source_path.exists():
                logger.warning(f"Source path does not exist: {source_path}")
                continue

            logger.info(f"Processing source: {source_name} from {source_path}")

            try:
                # Initialize processor for this source type
                processor = IncrementalChatProcessor(
                    chat_root=source_path,
                    maxwell_root=maxwell_root,
                    source_type=source["source_type"],
                )

                # Run incremental processing
                stats = processor.run_incremental(dry_run=inputs.dry_run)

                # Count total turns processed (need to check registry for this)
                turns_processed = sum(
                    info.get("metadata", {}).get("turns_processed", 0)
                    for info in processor.registry.values()
                    if info.get("status") == "completed"
                )

                source_detail = {
                    "source": source_name,
                    "path": str(source_path),
                    "total_files": stats["total_files"],
                    "new_files": stats["new_files"],
                    "modified_files": stats["modified_files"],
                    "turns_processed": turns_processed,
                    "processing_errors": stats["processing_errors"],
                }

                total_stats["source_details"].append(source_detail)
                total_stats["total_files"] += stats["total_files"]
                total_stats["total_turns_processed"] += turns_processed
                total_stats["total_errors"] += stats["processing_errors"]
                total_stats["sources_processed"] += 1

                logger.info(
                    f"✅ {source_name}: {stats['new_files'] + stats['modified_files']} files, {turns_processed} turns"
                )

            except Exception as e:
                logger.error(f"Failed to process source {source_name}: {e}")
                total_stats["total_errors"] += 1

        # Create result
        end_time = time.time()
        status = (
            WorkflowStatus.COMPLETED if total_stats["total_errors"] == 0 else WorkflowStatus.FAILED
        )

        # Create metrics
        metrics = WorkflowMetrics(
            start_time=start_time,
            end_time=end_time,
            files_processed=total_stats["total_files"],
            errors_encountered=total_stats["total_errors"],
        )
        metrics.finalize()

        # Run batch extract if not dry run
        limit = context.get("limit")
        if not inputs.dry_run and status == WorkflowStatus.COMPLETED:

            logger.info("🚀 Running batch extract for embeddings...")
            try:
                # Simple batch extract for embeddings directly here
                from pymongo import MongoClient
                from qdrant_client import QdrantClient
                from qdrant_client.http.models import Distance, PointStruct, VectorParams

                from maxwell.lm_pool import get_embedding

                client = MongoClient("mongodb://localhost:27017")
                db = client.chat_turns
                collection = db.turns

                # Build query filter
                query = {}
                if limit:
                    query = {"$or": [{"role": "user"}, {"role": "assistant"}]}

                # Get turns to process
                cursor = collection.find(query).sort("timestamp", -1)
                if limit:
                    cursor = cursor.limit(limit)

                turns_to_process = list(cursor)
                logger.info(f"Creating embeddings for {len(turns_to_process)} turns...")

                # Create embeddings
                embedding_client = get_embedding()
                qdrant = QdrantClient(url="http://localhost:6333")

                # Ensure collection exists
                collection_name = "chat_turns"
                try:
                    qdrant.get_collection(collection_name)
                except:
                    qdrant.create_collection(
                        collection_name=collection_name,
                        vectors_config=VectorParams(size=2560, distance=Distance.COSINE),
                    )

                points = []
                for turn in turns_to_process:
                    text = turn.get("content", "")
                    if text and len(text.strip()) > 10:
                        # Create embedding
                        embedding = embedding_client.create_embedding(text)  # type: ignore

                        points.append(
                            PointStruct(
                                id=turn["turn_id"],
                                vector=embedding,
                                payload={
                                    "turn_id": turn["turn_id"],
                                    "content": text[:500],  # First 500 chars for preview
                                    "role": turn.get("role"),
                                    "source": turn.get("source"),
                                    "timestamp": turn.get("timestamp"),
                                    "conversation_id": turn.get("conversation_id"),
                                    "content_length": len(text),
                                },
                            )
                        )

                # Batch upsert to Qdrant
                if points:
                    qdrant.upsert(collection_name=collection_name, points=points)
                    logger.info(f"✅ Created {len(points)} embeddings in Qdrant")
                    total_stats["embeddings_created"] = len(points)
                else:
                    logger.warning("⚠️ No valid content found for embeddings")

            except Exception as e:
                logger.error(f"❌ Batch extract failed: {e}")
                import traceback

                traceback.print_exc()

        # Create result using BaseWorkflow method
        result = WorkflowResult(
            workflow_id=self.workflow_id,
            status=status,
            metrics=metrics,
            artifacts={
                "processing_summary": total_stats,
                "sources_processed": total_stats["sources_processed"],
                "total_files_processed": total_stats["total_files"],
                "total_turns_processed": total_stats["total_turns_processed"],
                "total_errors": total_stats["total_errors"],
                "dry_run": context.get("dry_run", False),
                "limit": limit,
                "data_quality_completed": "data_quality_issues" in total_stats,
                "embeddings_created": total_stats.get("embeddings_created", 0),
            },
            error_message=(
                None
                if status == WorkflowStatus.COMPLETED
                else f"Processing completed with {total_stats['total_errors']} errors"
            ),
        )

        return result


# Register the workflow in Maxwell's registry
@register_workflow
class RegisteredIncrementalChatWorkflow(IncrementalChatWorkflow):
    """Registered version of IncrementalChatWorkflow."""

    def __init__(self):
        # Call parent __init__ to set workflow_id
        super().__init__()
```

---
### File: src/maxwell/workflows/chat/metadata_extractor.py

```python
"""Tier 2 metadata extraction for chat turns using LLM.

Extracts structured metadata:
- Topics (organic tags like "maxwell-architecture", "bm25-search")
- Intent (question, explanation, debugging, implementation, planning)
- Technologies (python, mongodb, elasticsearch, etc.)
- Entities (files, functions, projects)

Caching:
- Results cached in MongoDB turn_metadata collection
- Only re-extract if turn content changes
- Extraction is on-demand, not batch

Usage:
    from metadata_extractor import MetadataExtractor

    extractor = MetadataExtractor()
    metadata = extractor.extract("turn_id_123")
    print(metadata.topics)  # ["maxwell", "bm25-search"]
"""

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from pymongo import MongoClient
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

from maxwell.lm_pool import get_embedding, get_lm

logger = logging.getLogger(__name__)


# ===== Pydantic Schema for Structured Metadata =====


class TurnEntities(BaseModel):
    """Entities extracted from a turn."""

    files: List[str] = Field(
        default_factory=list, description="Files mentioned (e.g., bm25_search.py)"
    )
    functions: List[str] = Field(
        default_factory=list, description="Functions/classes mentioned (e.g., BM25Searcher)"
    )
    projects: List[str] = Field(
        default_factory=list, description="Projects mentioned (e.g., maxwell)"
    )
    tools: List[str] = Field(
        default_factory=list, description="Tools/libraries mentioned (e.g., rank-bm25)"
    )


class TurnMetadata(BaseModel):
    """Tier 2 metadata for a conversation turn."""

    # Core metadata
    topics: List[str] = Field(
        default_factory=list,
        description="Organic topic tags (e.g., maxwell-architecture, bm25-search, chat-indexing)",
        max_length=10,
    )

    intent: str = Field(
        default="discussion",
        description="Primary intent: question, explanation, debugging, implementation, planning, discussion",
    )

    technologies: List[str] = Field(
        default_factory=list,
        description="Technologies mentioned (e.g., python, mongodb, elasticsearch)",
        max_length=15,
    )

    entities: TurnEntities = Field(
        default_factory=TurnEntities,
        description="Structured entities (files, functions, projects, tools)",
    )

    # Optional high-level summary
    summary: Optional[str] = Field(
        None, description="One-sentence summary of the turn (optional)", max_length=500
    )

    # Extraction metadata
    extracted_at: str = Field(
        default_factory=lambda: datetime.now().isoformat(),
        description="When this metadata was extracted",
    )

    extractor_model: str = Field(default="unknown", description="Model used for extraction")


# ===== Metadata Extractor =====


class MetadataExtractor:
    """Extract structured metadata from chat turns using LLM."""

    def __init__(
        self,
        mongodb_uri: str = "mongodb://localhost:27017",
        mongodb_db: str = "chat_analytics",
        qdrant_host: str = "localhost",
        qdrant_port: int = 6333,
    ):
        """Initialize metadata extractor.

        Args:
            mongodb_uri: MongoDB connection URI
            mongodb_db: MongoDB database name
            qdrant_host: Qdrant host
            qdrant_port: Qdrant port

        """
        # MongoDB setup
        self.mongo_client = MongoClient(mongodb_uri)
        self.mongo_db = self.mongo_client[mongodb_db]
        self.turns_collection = self.mongo_db["turns"]
        self.metadata_collection = self.mongo_db["turn_metadata"]

        # Create indexes
        self.metadata_collection.create_index("turn_id", unique=True)
        self.metadata_collection.create_index("topics")
        self.metadata_collection.create_index("intent")
        self.metadata_collection.create_index("technologies")

        # Qdrant setup
        self.qdrant_client = QdrantClient(host=qdrant_host, port=qdrant_port)
        self.collection_name = "chat_turns"

        # Get embedding client
        self.embedding_client = get_embedding()
        embedding_dim = self.embedding_client.dimension

        # Create Qdrant collection if it doesn't exist
        try:
            self.qdrant_client.get_collection(self.collection_name)
            logger.info(f"Using existing Qdrant collection: {self.collection_name}")
        except Exception:
            self.qdrant_client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=embedding_dim, distance=Distance.COSINE),
            )
            logger.info(f"Created Qdrant collection: {self.collection_name} (dim={embedding_dim})")

        # Get LLM for extraction - use load balancing for optimal throughput
        # Prefer fastest LLM with sufficient context for metadata extraction
        self.llm = get_lm(min_context=8000, prefer_fastest=True)
        logger.info(
            f"MetadataExtractor initialized with LLM: {self.llm.spec.name} ({self.llm.spec.capabilities['speed_tokens_per_sec']} tok/s), Embedding: {self.embedding_client.name}"
        )

    def build_extraction_prompt(self, turn: Dict[str, Any]) -> str:
        """Build prompt for metadata extraction.

        Args:
            turn: Turn document from MongoDB

        Returns:
            Extraction prompt

        """
        user_text = turn.get("user", {}).get("text", "")
        assistant_text = turn.get("assistant", {}).get("text", "")

        # Smart truncation - dynamically derive from LLM spec instead of hardcoding
        # Get effective limits from LLM spec, fallback to safe defaults
        max_tokens = self.llm.spec.max_tokens  # type: ignore
        max_context = getattr(self.llm.spec, "max_context", max_tokens // 2)
        max_sequence_length = getattr(self.llm.spec, "max_sequence_length", max_tokens // 4)

        # Calculate reasonable token limits with safety margin
        # Use 90% of max_tokens for generation, 95% of max_context for safety
        generation_limit = int(max_tokens * 0.9)
        context_limit = int(max_context * 0.95)

        # Conservative character limit: 4 chars per token (adjustable)
        max_chars_per_message = max(generation_limit * 4, 8000)

        print(
            f"Using dynamic limits: max_tokens={max_tokens}, context_limit={context_limit}, generation_limit={generation_limit}, max_chars={max_chars_per_message}"
        )

        # Override for config loading
        self.max_tokens = max_tokens
        self.max_context = context_limit
        self.max_chars_per_message = max_chars_per_message

        if len(user_text) > max_chars_per_message:
            user_text = user_text[:max_chars_per_message] + "... [truncated]"
        if len(assistant_text) > max_chars_per_message:
            assistant_text = assistant_text[:max_chars_per_message] + "... [truncated]"

        prompt = f"""Extract structured metadata from this conversation turn.

USER MESSAGE:
{user_text}

ASSISTANT MESSAGE:
{assistant_text}

Extract the following metadata:

1. **topics**: List of 3-10 organic topic tags (lowercase, hyphen-separated)
   - Examples: "maxwell-architecture", "bm25-search", "chat-indexing", "debugging-import-errors"
   - Be specific and technical
   - Capture key themes and concepts discussed

2. **intent**: Primary intent of the conversation (choose ONE):
   - "question": User asking for help/clarification
   - "explanation": Assistant explaining a concept
   - "debugging": Troubleshooting errors or issues
   - "implementation": Building/coding something
   - "planning": Architectural or design decisions
   - "discussion": General discussion or brainstorming

3. **technologies**: List of technologies/tools mentioned
   - Examples: "python", "mongodb", "elasticsearch", "bm25", "docker"
   - Include programming languages, databases, libraries, frameworks
   - Lowercase

4. **entities**:
   - files: File names mentioned (e.g., "bm25_search.py", "turn_indexer.py")
   - functions: Functions/classes mentioned (e.g., "BM25Searcher", "search()")
   - projects: Project names (e.g., "maxwell", "professional-log")
   - tools: Specific tools/libraries (e.g., "rank-bm25", "pymongo")

5. **summary**: One-sentence summary of what happened in this turn (optional, max 200 chars)

Return ONLY a valid JSON object matching this schema:
{{
  "topics": ["topic1", "topic2", ...],
  "intent": "question|explanation|debugging|implementation|planning|discussion",
  "technologies": ["tech1", "tech2", ...],
  "entities": {{
    "files": ["file1.py", ...],
    "functions": ["Function1", ...],
    "projects": ["project1", ...],
    "tools": ["tool1", ...]
  }},
  "summary": "One sentence summary"
}}

Return ONLY the JSON, no other text."""

        return prompt

    def extract(self, turn_id: str, force_refresh: bool = False) -> Optional[TurnMetadata]:
        """Extract metadata for a turn.

        Args:
            turn_id: Turn ID to extract metadata for
            force_refresh: Force re-extraction even if cached

        Returns:
            TurnMetadata object, or None if extraction failed

        """
        # Check cache first
        if not force_refresh:
            cached = self.metadata_collection.find_one({"turn_id": turn_id})
            if cached:
                logger.debug(f"Using cached metadata for {turn_id}")
                # Convert MongoDB doc to TurnMetadata
                try:
                    return TurnMetadata(**cached["metadata"])
                except Exception as e:
                    logger.warning(f"Failed to parse cached metadata: {e}")

        # Get turn from database
        turn = self.turns_collection.find_one({"turn_id": turn_id})
        if not turn:
            logger.error(f"Turn not found: {turn_id}")
            return None

        # Build extraction prompt
        prompt = self.build_extraction_prompt(turn)

        # Extract with LLM
        try:
            logger.info(f"Extracting metadata for {turn_id} with {self.llm.spec.name}")
            # Use model's full max tokens capability
            response = self.llm.generate(
                prompt, max_tokens=self.llm.spec.max_tokens, temperature=0.1  # type: ignore
            )

            # Parse JSON response
            response_text = response.strip()
            # Remove markdown code blocks if present
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()

            metadata_dict = json.loads(response_text)

            # Add extraction metadata
            metadata_dict["extractor_model"] = self.llm.spec.name
            metadata_dict["extracted_at"] = datetime.now().isoformat()

            # Validate with Pydantic
            metadata = TurnMetadata(**metadata_dict)

            # Cache metadata in MongoDB
            self.metadata_collection.update_one(
                {"turn_id": turn_id},
                {
                    "$set": {
                        "turn_id": turn_id,
                        "metadata": metadata.model_dump(),
                        "updated_at": datetime.now(),
                    }
                },
                upsert=True,
            )

            # Create embedding from topics + summary
            topics_str = " ".join(metadata.topics)
            summary_str = metadata.summary or ""
            embedding_text = f"{topics_str}. {summary_str}".strip()

            embedding = self.embedding_client.embed(embedding_text)
            if not isinstance(embedding, list):
                embedding = embedding.tolist()

            # Embedding is now logged in LLM pool, no need for separate logging

            # Store embedding in Qdrant
            point = PointStruct(
                id=hash(turn_id) & 0x7FFFFFFFFFFFFFFF,  # Convert to positive int
                vector=embedding,
                payload={
                    "turn_id": turn_id,
                    "topics": metadata.topics,
                    "summary": summary_str,
                    "intent": metadata.intent,
                    "source": turn.get("source", "unknown"),
                    "conversation_title": turn.get("conversation_title", ""),
                    "technologies": metadata.technologies,
                },
            )
            self.qdrant_client.upsert(collection_name=self.collection_name, points=[point])

            logger.info(f"✓ Extracted metadata and embedded for {turn_id}")
            return metadata

        except Exception as e:
            logger.error(f"Failed to extract metadata for {turn_id}: {e}", exc_info=True)
            return None

    def extract_batch(
        self, turn_ids: List[str], force_refresh: bool = False
    ) -> Dict[str, Optional[TurnMetadata]]:
        """Extract metadata for multiple turns.

        Args:
            turn_ids: List of turn IDs
            force_refresh: Force re-extraction even if cached

        Returns:
            Dictionary mapping turn_id -> TurnMetadata

        """
        results = {}
        for turn_id in turn_ids:
            results[turn_id] = self.extract(turn_id, force_refresh=force_refresh)
        return results

    def get_stats(self) -> Dict[str, Any]:
        """Get metadata extraction statistics.

        Returns:
            Dictionary with stats

        """
        total_turns = self.turns_collection.count_documents({})
        extracted_count = self.metadata_collection.count_documents({})

        # Count by intent
        intents = list(
            self.metadata_collection.aggregate(
                [{"$group": {"_id": "$metadata.intent", "count": {"$sum": 1}}}]
            )
        )

        # Most common topics
        topics = list(
            self.metadata_collection.aggregate(
                [
                    {"$unwind": "$metadata.topics"},
                    {"$group": {"_id": "$metadata.topics", "count": {"$sum": 1}}},
                    {"$sort": {"count": -1}},
                    {"$limit": 20},
                ]
            )
        )

        # Most common technologies
        technologies = list(
            self.metadata_collection.aggregate(
                [
                    {"$unwind": "$metadata.technologies"},
                    {"$group": {"_id": "$metadata.technologies", "count": {"$sum": 1}}},
                    {"$sort": {"count": -1}},
                    {"$limit": 20},
                ]
            )
        )

        return {
            "total_turns": total_turns,
            "extracted_count": extracted_count,
            "coverage": extracted_count / total_turns if total_turns > 0 else 0,
            "intents": {item["_id"]: item["count"] for item in intents},
            "top_topics": [(item["_id"], item["count"]) for item in topics],
            "top_technologies": [(item["_id"], item["count"]) for item in technologies],
        }


# ===== CLI Interface =====


def extract_cli(turn_id: str, force_refresh: bool = False):
    """CLI interface for metadata extraction.

    Args:
        turn_id: Turn ID to extract metadata for
        force_refresh: Force re-extraction even if cached

    """
    extractor = MetadataExtractor()
    metadata = extractor.extract(turn_id, force_refresh=force_refresh)

    if metadata:
        if metadata.summary:
            pass
    else:
        pass


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Extract metadata from chat turns")
    parser.add_argument("turn_id", type=str, help="Turn ID to extract metadata for")
    parser.add_argument("--force", action="store_true", help="Force re-extraction even if cached")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)
    extract_cli(args.turn_id, force_refresh=args.force)
```

---
### File: src/maxwell/workflows/chat/parsers.py

```python
"""Chat conversation parsers for ChatGPT and Claude.

Unified parser system that handles both ChatGPT export (conversations.json)
and Claude projects (.jsonl files).
"""

import hashlib
import json
import logging
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterator, Optional

logger = logging.getLogger(__name__)


@dataclass
class Message:
    """Unified message representation for ChatGPT and Claude conversations."""

    message_id: str
    conversation_id: str
    conversation_title: str
    role: str  # user, assistant, system, tool
    text: str
    timestamp: Optional[float]
    message_index: int  # Position in conversation
    parent_id: Optional[str]
    source: str  # "chatgpt" or "claude"

    # Metadata
    token_count: int
    char_count: int

    def to_dict(self) -> dict:
        """Convert to dictionary for MongoDB."""
        return asdict(self)

    def get_hash(self) -> str:
        """Generate hash for deduplication."""
        content = f"{self.conversation_id}:{self.message_index}:{self.text}"
        return hashlib.sha256(content.encode()).hexdigest()


class ChatGPTParser:
    """Parser for ChatGPT export JSON files.

    Handles conversations.json export format with nested message mappings.

    Usage:
        parser = ChatGPTParser(Path("/path/to/conversations.json"))
        for message in parser.parse():
            print(message.text)
    """

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

    def parse(self) -> Iterator[Message]:
        """Parse ChatGPT export and yield individual messages."""
        logger.info(f"Parsing ChatGPT export: {self.file_path}")

        with open(self.file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Check if this is a single conversation or array of conversations
        if isinstance(data, list):
            total_convs = len(data)
            logger.info(f"Found {total_convs} ChatGPT conversations")
            for i, conversation in enumerate(data, 1):
                yield from self._parse_conversation(conversation)
        elif isinstance(data, dict) and "mapping" in data:
            # Single conversation
            yield from self._parse_conversation(data)
        else:
            logger.error("Unknown ChatGPT export format")
            return

    def _parse_conversation(self, conversation: dict) -> Iterator[Message]:
        """Parse a single conversation and yield messages in chronological order."""
        conv_id = conversation.get("id", self._generate_conv_id(conversation))
        conv_title = conversation.get("title", "Untitled Conversation")
        mapping = conversation.get("mapping", {})

        if not mapping:
            logger.warning(f"Empty conversation: {conv_title}")
            return

        # Build ordered message list by walking the graph
        messages = self._walk_graph(mapping)

        # Yield messages with metadata
        for idx, msg_data in enumerate(messages):
            msg_obj = msg_data.get("message")
            if not msg_obj:
                continue

            author = msg_obj.get("author", {})
            role = author.get("role", "unknown")
            content = msg_obj.get("content", {})

            # Extract text from content
            text = self._extract_text(content)
            if not text or len(text.strip()) < 10:
                continue  # Skip very short messages

            message = Message(
                message_id=msg_obj.get("id", f"{conv_id}-{idx}"),
                conversation_id=conv_id,
                conversation_title=conv_title,
                role=role,
                text=text.strip(),
                timestamp=msg_obj.get("create_time"),
                message_index=idx,
                parent_id=msg_data.get("parent"),
                source="chatgpt",
                token_count=self._estimate_tokens(text),
                char_count=len(text),
            )

            yield message

    def _walk_graph(self, mapping: dict) -> list:
        """Walk the conversation graph to get messages in chronological order.

        ChatGPT stores conversations as a directed graph with parent/children.
        We need to find the root and follow the main path.
        """
        # Find root node (no parent)
        root_id = None
        for node_id, node in mapping.items():
            if node.get("parent") is None:
                root_id = node_id
                break

        if not root_id:
            logger.warning("No root node found, using first node")
            root_id = next(iter(mapping.keys()))

        # Walk from root following children (depth-first, first child)
        messages = []
        visited = set()
        stack = [root_id]

        while stack:
            current_id = stack.pop(0)

            if current_id in visited or current_id not in mapping:
                continue

            visited.add(current_id)
            node = mapping[current_id]

            # Add message if it exists
            if node.get("message"):
                messages.append(node)

            # Add first child to stack (main conversation path)
            children = node.get("children", [])
            if children:
                # Follow first child (main path)
                stack.insert(0, children[0])

        return messages

    def _extract_text(self, content: dict) -> str:
        """Extract text from content object."""
        if not content:
            return ""

        content_type = content.get("content_type", "")

        # Handle text content
        if content_type == "text":
            parts = content.get("parts", [])
            return "".join(str(p) for p in parts if p)

        # Handle code content
        elif content_type == "code":
            return content.get("text", "")

        # Handle other types
        else:
            # Try to extract any text field
            return content.get("text", "") or str(content.get("parts", ""))

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimation (4 chars ≈ 1 token)."""
        return len(text) // 4

    def _generate_conv_id(self, conversation: dict) -> str:
        """Generate conversation ID from metadata."""
        title = conversation.get("title", "")
        create_time = conversation.get("create_time", 0)
        content = f"{title}:{create_time}"
        return hashlib.md5(content.encode()).hexdigest()[:16]


class ClaudeParser:
    """Parser for Claude Code chat logs (.jsonl files).

    Handles the JSONL format from ~/.claude/projects/

    Usage:
        parser = ClaudeParser(Path("~/.claude/projects/some-project/conversation.jsonl"))
        for message in parser.parse():
            print(message.text)
    """

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

    def parse(self) -> Iterator[Message]:
        """Parse Claude JSONL and yield individual messages."""
        logger.info(f"Parsing Claude conversation: {self.file_path}")

        conversation_id = self.file_path.stem
        # Try to extract a title from parent directory or filename
        conversation_title = self.file_path.parent.name or self.file_path.stem

        message_index = 0

        with open(self.file_path, encoding="utf-8") as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    entry_type = entry.get("type")

                    # Only process user and assistant messages
                    if entry_type not in ("user", "assistant"):
                        continue

                    # Extract message object
                    message_obj = entry.get("message", {})
                    content = message_obj.get("content", [])

                    # Extract text from content blocks
                    text_parts = []
                    for block in content:
                        # Handle both dict and string content blocks
                        if isinstance(block, str):
                            text_parts.append(block)
                        elif isinstance(block, dict) and block.get("type") == "text":
                            text_parts.append(block.get("text", ""))

                    if not text_parts:
                        continue

                    text = "\n".join(text_parts)
                    if len(text.strip()) < 10:
                        continue  # Skip very short messages

                    timestamp_str = entry.get("timestamp", "")
                    timestamp = self._parse_timestamp(timestamp_str)

                    message_id = entry.get("id", f"{conversation_id}-{message_index}")

                    message = Message(
                        message_id=message_id,
                        conversation_id=conversation_id,
                        conversation_title=conversation_title,
                        role=message_obj.get("role", entry_type),
                        text=text.strip(),
                        timestamp=timestamp,
                        message_index=message_index,
                        parent_id=None,  # Claude JSONL doesn't have parent references
                        source="claude",
                        token_count=self._estimate_tokens(text),
                        char_count=len(text),
                    )

                    yield message
                    message_index += 1

                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse line in {self.file_path}: {e}")
                    continue
                except Exception as e:
                    logger.error(f"Error processing message in {self.file_path}: {e}")
                    continue

    def _parse_timestamp(self, timestamp_str: str) -> Optional[float]:
        """Parse ISO timestamp to Unix epoch."""
        if not timestamp_str:
            return None

        try:
            from datetime import datetime

            dt = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
            return dt.timestamp()
        except Exception as e:
            logger.warning(f"Failed to parse timestamp '{timestamp_str}': {e}")
            return None

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimation (4 chars ≈ 1 token)."""
        return len(text) // 4
```

---
### File: src/maxwell/workflows/chat/semantic_search.py

```python
"""Chat search workflow for searching indexed chat logs.

Uses MongoDB + Qdrant to search chat conversations with semantic embeddings,
metadata filters, and text search.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from pymongo import MongoClient
from qdrant_client import QdrantClient

from maxwell.lm_pool import get_embedding
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowMetrics,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


@dataclass
class ChatSearchResult:
    """Result from chat search."""

    turn_id: str
    score: float
    user_text: str
    assistant_text: str
    topics: List[str]
    intent: str
    technologies: List[str]
    summary: str
    source: str
    embedding: Optional[List[float]] = None

    @property
    def metadata(self) -> Dict[str, Any]:
        """Get metadata dict for compatibility with topic analysis."""
        return {
            "turn_id": self.turn_id,
            "topics": self.topics,
            "intent": self.intent,
            "technologies": self.technologies,
            "summary": self.summary,
            "user_text": self.user_text,
            "assistant_text": self.assistant_text,
        }


@register_workflow
class ChatSemanticSearchWorkflow(BaseWorkflow):
    """Search chat logs using MongoDB + Qdrant embeddings."""

    # Workflow metadata for registry
    workflow_id: str = "chat-semantic-search"
    name: str = "Chat Semantic Search"
    description: str = (
        "Search indexed chat conversations using semantic search and metadata filters"
    )
    version: str = "1.0"
    category: str = "search"
    tags: set = {"chat", "search", "mongodb", "qdrant", "semantic"}

    def __init__(self):
        self.workflow_id = "chat-semantic-search"
        self.name = "Chat Semantic Search"
        self.description = (
            "Search indexed chat conversations using semantic search and metadata filters"
        )
        self.version = "1.0"
        super().__init__()

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=300,  # 5 minutes
            parameters={
                "root_dir": str(root_dir),
            },
        )

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters for chat search."""
        return [
            {
                "name": "query",
                "type": str,
                "required": False,
                "help": "Search query for semantic search",
            },
            {
                "name": "text",
                "type": str,
                "required": False,
                "help": "Text regex search instead of semantic",
            },
            {
                "name": "limit",
                "type": int,
                "required": False,
                "default": 10,
                "help": "Number of results to return",
            },
            {
                "name": "format",
                "type": str,
                "required": False,
                "default": "detailed",
                "help": "Output format: detailed, topics-only, compact",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        """Get list of required input keys."""
        return []  # No required inputs for search

    def get_produced_outputs(self) -> List[str]:
        """Get list of produced output keys."""
        return ["results", "report"]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute chat search workflow."""
        try:
            # Initialize connections
            qdrant = QdrantClient(host="localhost", port=6333)
            mongo_client = MongoClient("mongodb://localhost:27017")
            mongo_db = mongo_client["chat_analytics"]
            turns_collection = mongo_db["turns"]
            metadata_collection = mongo_db["turn_metadata"]
            embedding_client = get_embedding()

            # Extract parameters
            query = context.get("query")
            text_search = context.get("text") or context.get("company")
            topics = context.get("topic")
            intent = context.get("intent")
            technologies = context.get("technology")
            limit = context.get("limit", 10)
            format_type = context.get("format", "detailed")

            # Parse comma-separated lists
            topics_list = topics.split(",") if topics else None
            technologies_list = technologies.split(",") if technologies else None

            results = []

            # Determine search type and execute
            if text_search:
                # Text search
                pattern = text_search
                results = self._search_text(pattern, turns_collection, limit)
                search_type = f"Text search for: {pattern}"

            elif topics_list or intent or technologies_list:
                # Metadata search
                results = self._search_metadata(
                    metadata_collection,
                    turns_collection,
                    topics_list,
                    intent,
                    technologies_list,
                    limit,
                )
                search_type = "Metadata filtering"

            elif query:
                # Semantic search
                results = self._search_semantic(
                    query, embedding_client, qdrant, turns_collection, limit
                )
                search_type = f"Semantic search for: {query}"

            else:
                # No search parameters provided - return all results (for topic analysis)
                results = self._get_all_results(turns_collection, qdrant, limit)
                search_type = "All results (no filter)"

            # Format results
            report = self._format_results(results, format_type, search_type)

            # Create metrics
            metrics = WorkflowMetrics(
                start_time=0.0,
                end_time=0.0,
                files_processed=len(results),
                custom_metrics={"results_count": len(results), "search_type": search_type},
            )
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.COMPLETED,
                metrics=metrics,
                artifacts={
                    "results": results,
                    "results_count": len(results),
                    "search_type": search_type,
                    "report": report,
                },
            )

        except Exception as e:
            # Create metrics for failed case
            metrics = WorkflowMetrics(
                start_time=0.0, end_time=0.0, files_processed=0, errors_encountered=1
            )
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.FAILED,
                metrics=metrics,
                error_message=f"Semantic search failed: {str(e)}",
            )

    def _search_semantic(
        self, query: str, embedding_client, qdrant, turns_collection, limit: int
    ) -> List[ChatSearchResult]:
        """Search using semantic embeddings."""
        query_vector = embedding_client.embed(query)

        search_results = qdrant.query_points(
            collection_name="chat_turns", query=query_vector, limit=limit, with_payload=True
        )

        results = []
        for point in search_results.points:
            payload = point.payload
            turn_id = payload.get("turn_id", "Unknown")
            score = point.score

            # Get full conversation
            turn = turns_collection.find_one({"turn_id": turn_id})
            if turn:
                results.append(
                    ChatSearchResult(
                        turn_id=turn_id,
                        score=score,
                        user_text=turn.get("user", {}).get("text", ""),
                        assistant_text=turn.get("assistant", {}).get("text", ""),
                        topics=payload.get("topics", []),
                        intent=payload.get("intent", "N/A"),
                        technologies=payload.get("technologies", []),
                        summary=payload.get("summary", ""),
                        source=turn.get("source", "unknown"),
                    )
                )

        return results

    def _search_metadata(
        self,
        metadata_collection,
        turns_collection,
        topics: Optional[List[str]],
        intent: Optional[str],
        technologies: Optional[List[str]],
        limit: int,
    ) -> List[ChatSearchResult]:
        """Search using extracted metadata filters."""
        query = {}

        if topics:
            query["metadata.topics"] = {"$in": topics}
        if intent:
            query["metadata.intent"] = intent
        if technologies:
            query["metadata.technologies"] = {"$in": technologies}

        cursor = metadata_collection.find(query).limit(limit)
        results = []

        for doc in cursor:
            turn_id = doc["turn_id"]
            metadata = doc["metadata"]

            # Get full conversation
            turn = turns_collection.find_one({"turn_id": turn_id})
            if turn:
                results.append(
                    ChatSearchResult(
                        turn_id=turn_id,
                        score=1.0,  # Exact metadata match
                        user_text=turn.get("user", {}).get("text", ""),
                        assistant_text=turn.get("assistant", {}).get("text", ""),
                        topics=metadata.get("topics", []),
                        intent=metadata.get("intent", "N/A"),
                        technologies=metadata.get("technologies", []),
                        summary=metadata.get("summary", ""),
                        source=turn.get("source", "unknown"),
                    )
                )

        return results

    def _search_text(self, pattern: str, turns_collection, limit: int) -> List[ChatSearchResult]:
        """Search using regex text matching."""
        cursor = turns_collection.find(
            {
                "$or": [
                    {"user.text": {"$regex": pattern, "$options": "i"}},
                    {"assistant.text": {"$regex": pattern, "$options": "i"}},
                ]
            }
        ).limit(limit)

        results = []
        for turn in cursor:
            user_text = turn.get("user", {}).get("text", "")
            assistant_text = turn.get("assistant", {}).get("text", "")

            results.append(
                ChatSearchResult(
                    turn_id=turn["turn_id"],
                    score=1.0,
                    user_text=user_text,
                    assistant_text=assistant_text,
                    source=turn.get("source", "unknown"),
                    topics=[],
                    intent="N/A",
                    technologies=[],
                    summary="",
                )
            )

        return results

    def _format_results(
        self, results: List[ChatSearchResult], format_type: str, search_type: str
    ) -> str:
        """Format search results for display."""
        lines = []

        # Header
        lines.append(f"🔍 {search_type}")
        lines.append(f"📊 Found {len(results)} results:\n")

        for i, result in enumerate(results, 1):
            if format_type == "topics-only":
                # Topics-only display
                lines.append(f"Result {i}/{len(results)}")
                lines.append(f"🎯 Score: {result.score:.3f} | {result.turn_id}")
                if result.topics:
                    lines.append(f"📌 Topics: {', '.join(result.topics)}")
                if result.intent != "N/A":
                    lines.append(f"🎭 Intent: {result.intent}")
                if result.technologies:
                    lines.append(f"🔧 Technologies: {', '.join(result.technologies)}")
                lines.append("-" * 80)

            elif format_type == "compact":
                # Compact display
                user_snippet = (
                    result.user_text[:80] + "..."
                    if len(result.user_text) > 80
                    else result.user_text
                )
                lines.append(f"{i}. {result.turn_id} ({result.score:.3f})")
                lines.append(f"   {user_snippet}")
                lines.append("")

            else:  # detailed (default)
                # Full display
                lines.append(f"Result {i}/{len(results)}")
                lines.append(f"🎯 Score: {result.score:.3f} | {result.turn_id}")

                # Metadata
                if result.topics:
                    lines.append(f"📌 Topics: {', '.join(result.topics)}")
                if result.intent != "N/A":
                    lines.append(f"🎭 Intent: {result.intent}")
                if result.technologies:
                    lines.append(f"🔧 Technologies: {', '.join(result.technologies)}")
                if result.summary:
                    lines.append(f"📝 Summary: {result.summary}")

                # Conversation snippet
                if result.user_text:
                    snippet = (
                        result.user_text[:150] + "..."
                        if len(result.user_text) > 150
                        else result.user_text
                    )
                    lines.append(f"👤 User: {snippet}")

                if result.assistant_text:
                    snippet = (
                        result.assistant_text[:150] + "..."
                        if len(result.assistant_text) > 150
                        else result.assistant_text
                    )
                    lines.append(f"🤖 Assistant: {snippet}")

                    lines.append("-" * 80)

        lines.append(f"\n✨ Search complete! Found {len(results)} results.")
        return "\n".join(lines)

    def _get_all_results(
        self, turns_collection, qdrant, limit: int = 100
    ) -> List[ChatSearchResult]:
        """Get all conversation results (for topic analysis)."""
        results = []

        # Query Qdrant directly to get points with embeddings
        try:
            # Scroll through Qdrant collection to get points
            scroll_result = qdrant.scroll(
                collection_name="chat_turns", limit=limit, with_vectors=True, with_payload=True
            )

            points = scroll_result[0]  # Get points from scroll result

            for point in points:
                turn_id = point.id
                embedding = point.vector
                payload = point.payload

                # Create result with existing embedding
                result = ChatSearchResult(
                    turn_id=str(turn_id),
                    score=1.0,  # No relevance score when getting all
                    user_text=payload.get("user_text", ""),
                    assistant_text=payload.get("assistant_text", ""),
                    topics=payload.get("topics", []),
                    intent=payload.get("intent", ""),
                    technologies=payload.get("technologies", []),
                    summary=payload.get("summary", ""),
                    source=payload.get("source", "unknown"),
                    embedding=(
                        embedding.tolist() if hasattr(embedding, "tolist") else list(embedding)
                    ),
                )
                results.append(result)

        except Exception as e:
            logger.error(f"Failed to retrieve embeddings from Qdrant: {e}")
            # Fallback: return empty results rather than crash
            pass

        return results
```

---
### File: src/maxwell/workflows/deep_research.py

```python
"""Deep research workflow - comprehensive search across multiple data sources.

Simple implementation that uses existing Maxwell workflows via MCP interface.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from maxwell.api import execute_workflow
from maxwell.lm_pool import get_lm
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)


# Workflow-specific schemas (defined in same file as workflow)
# -------------------------------------------------------------


@dataclass(frozen=True)
class DeepResearchInputs(WorkflowInputs):
    """Input schema for deep research workflow."""

    research_question: str
    data_sources: str = "chat,filesystem"
    max_iterations: int = 3
    queries_per_iteration: int = 5


@dataclass(frozen=True)
class DeepResearchOutputs(WorkflowOutputs):
    """Output schema for deep research workflow."""

    report: str
    findings_summary: str
    findings: List[Dict[str, str]]
    data_sources: List[str]
    queries_executed: int
    iterations_completed: int


class DeepResearchWorkflow(BaseWorkflow):
    """Deep research workflow using existing Maxwell workflows."""

    workflow_id: str = "deep-research"
    name: str = "Deep Research"
    description: str = "Comprehensive research across chat and filesystem data"
    version: str = "1.0"
    category: str = "research"
    tags: set = {"research", "search", "synthesis"}

    # Typed schemas
    InputSchema = DeepResearchInputs
    OutputSchema = DeepResearchOutputs

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters."""
        return [
            {
                "name": "research_question",
                "type": str,
                "required": True,
                "help": "Research question to investigate",
            },
            {
                "name": "data_sources",
                "type": str,
                "required": False,
                "default": "chat,filesystem",
                "help": "Data sources: chat, filesystem, or both (comma-separated)",
            },
            {
                "name": "max_iterations",
                "type": int,
                "required": False,
                "default": 3,
                "help": "Maximum research iterations",
            },
            {
                "name": "queries_per_iteration",
                "type": int,
                "required": False,
                "default": 5,
                "help": "Queries to generate per iteration",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        """Get required inputs."""
        return ["research_question"]

    def get_produced_outputs(self) -> List[str]:
        """Get produced outputs."""
        return [
            "report",
            "findings_summary",
            "findings",
            "data_sources",
            "queries_executed",
            "iterations_completed",
        ]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute deep research with typed schemas."""
        try:
            # Parse inputs with type safety
            inputs: DeepResearchInputs = self.parse_inputs(context)  # type: ignore[assignment]

            # Now we have typed access!
            research_question = inputs.research_question
            data_sources = [ds.strip() for ds in inputs.data_sources.lower().split(",")]
            max_iterations = inputs.max_iterations
            queries_per_iteration = inputs.queries_per_iteration

            logger.info(f"Starting research: {research_question}")
            logger.info(f"Data sources: {data_sources}")

            # Research state
            all_findings = []
            used_queries = set()

            # Get LLM client
            llm_client = get_lm()

            # Initial queries
            current_queries = self._generate_queries(
                research_question, data_sources, llm_client, queries_per_iteration
            )

            iteration = 0
            for iteration in range(max_iterations):
                logger.info(f"Research iteration {iteration + 1}/{max_iterations}")

                if not current_queries:
                    break

                # Execute searches
                iteration_findings = []
                for query in current_queries:
                    if query in used_queries:
                        continue

                    used_queries.add(query)
                    findings = self._search_and_extract(query, data_sources, project_root)
                    iteration_findings.extend(findings)

                all_findings.extend(iteration_findings)

                # Generate follow-up queries if not last iteration
                if iteration < max_iterations - 1 and iteration_findings:
                    current_queries = self._generate_followup_queries(
                        research_question, iteration_findings, llm_client, queries_per_iteration
                    )
                else:
                    break

            # Generate final report
            report = self._synthesize_report(research_question, all_findings, llm_client)
            findings_summary = self._summarize_findings(all_findings)

            # Create typed outputs
            outputs = DeepResearchOutputs(
                report=report,
                findings_summary=findings_summary,
                findings=all_findings,
                data_sources=data_sources,
                queries_executed=len(used_queries),
                iterations_completed=iteration + 1,
            )

            # Use helper to create result with metrics
            self.metrics.files_processed = len(all_findings)
            self.metrics.custom_metrics = {
                "queries_executed": len(used_queries),
                "findings_found": len(all_findings),
            }

            return self.create_result(outputs, WorkflowStatus.COMPLETED)

        except Exception as e:
            logger.error(f"Deep research failed: {e}", exc_info=True)
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Deep research failed: {str(e)}",
            )

    def _generate_queries(
        self, research_question: str, data_sources: List[str], llm_client, limit: int
    ) -> List[str]:
        """Generate initial search queries."""
        source_text = ", ".join(data_sources)
        prompt = f"""Generate {limit} diverse search queries to research this question:

Question: {research_question}
Data sources: {source_text}

Generate search queries that cover different aspects. Return as a JSON list:
["query 1", "query 2", "query 3", ...]
"""

        try:
            response = llm_client.complete(prompt)
            import json

            queries = json.loads(response.text)
            return queries[:limit] if isinstance(queries, list) else [research_question]
        except Exception as e:
            logger.error(f"Query generation failed: {e}")
            return [research_question]

    def _generate_followup_queries(
        self, research_question: str, findings: List[Dict[str, str]], llm_client, limit: int
    ) -> List[str]:
        """Generate follow-up queries based on findings."""
        findings_text = "\n".join([f.get("content", "")[:200] for f in findings[:3]])

        prompt = f"""Based on these findings, generate {limit} follow-up search queries:

Original question: {research_question}

Current findings:
{findings_text}

Generate follow-up queries to explore gaps or interesting leads. Return as JSON list:
["query 1", "query 2", ...]
"""

        try:
            response = llm_client.complete(prompt)
            import json

            queries = json.loads(response.text)
            return queries[:limit] if isinstance(queries, list) else []
        except Exception as e:
            logger.error(f"Follow-up query generation failed: {e}")
            return []

    def _search_and_extract(
        self, query: str, data_sources: List[str], project_root: Path
    ) -> List[Dict[str, str]]:
        """Execute search across data sources and extract findings."""
        all_results = []

        # Search each data source
        for source in data_sources:
            try:
                if source == "chat":
                    # Try semantic search first
                    result = execute_workflow(
                        "chat-semantic-search", project_root, {"query": query}
                    )
                    if result.status == WorkflowStatus.COMPLETED and result.artifacts:
                        chat_results = result.artifacts.get("results", [])
                        for chat_result in chat_results[:3]:
                            content = ""
                            if isinstance(chat_result, dict):
                                if "user_text" in chat_result and "assistant_text" in chat_result:
                                    content = f"User: {chat_result.get('user_text', '')}\nAssistant: {chat_result.get('assistant_text', '')}"
                                else:
                                    content = chat_result.get("content", str(chat_result))

                            if content:
                                all_results.append(
                                    {
                                        "content": content,
                                        "source": f"chat:{chat_result.get('turn_id', 'unknown')}",
                                        "query": query,
                                        "data_source": "chat",
                                    }
                                )

                elif source == "filesystem":
                    result = execute_workflow("fs-search", project_root, {"query": query})
                    if result.status == WorkflowStatus.COMPLETED and result.artifacts:
                        fs_results = result.artifacts.get("results", [])
                        for fs_result in fs_results[:3]:
                            content = ""
                            if isinstance(fs_result, dict):
                                content = fs_result.get("content", str(fs_result))

                            if content:
                                all_results.append(
                                    {
                                        "content": content,
                                        "source": f"filesystem:{fs_result.get('path', 'unknown')}",
                                        "query": query,
                                        "data_source": "filesystem",
                                    }
                                )

            except Exception as e:
                logger.error(f"Search failed for {source}: {e}")
                continue

        return all_results

    def _synthesize_report(
        self, research_question: str, findings: List[Dict[str, str]], llm_client
    ) -> str:
        """Generate final research report."""
        findings_text = "\n\n".join(
            [
                f"Source: {f['source']}\nContent: {f['content'][:500]}..."
                for f in findings[:10]  # Limit for LLM context
            ]
        )

        prompt = f"""Synthesize a research report answering this question:

Question: {research_question}

Research Findings:
{findings_text}

Create a structured report with:
1. Executive Summary (2-3 sentences)
2. Key Findings (bulleted list)
3. Detailed Analysis
4. Conclusion

Focus on directly answering the research question.
"""

        try:
            response = llm_client.complete(prompt)
            return response.text
        except Exception as e:
            logger.error(f"Report synthesis failed: {e}")
            return f"Research completed with {len(findings)} findings. Report synthesis failed."

    def _summarize_findings(self, findings: List[Dict[str, str]]) -> str:
        """Create summary of findings."""
        if not findings:
            return "No findings found."

        source_counts = {}
        for f in findings:
            source = f["data_source"]
            source_counts[source] = source_counts.get(source, 0) + 1

        summary = (
            f"Found {len(findings)} total findings across {len(source_counts)} data sources:\n"
        )
        for source, count in source_counts.items():
            summary += f"- {source}: {count} findings\n"

        return summary
```

---
### File: src/maxwell/workflows/justification.py

```python
"""Clean, focused justification engine.

Core workflow:
1. Discover files and build filesystem tree
2. Summarize each file's purpose with fast LLM (cached by hash)
3. Generate XML context with structure + summaries
4. Orchestrator LLM analyzes for misplaced/useless/redundant files
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from maxwell.workflows.base import WorkflowResult

from maxwell.registry import register_workflow
from maxwell.workflows.base import BaseWorkflow, WorkflowConfig, WorkflowPriority

logger = logging.getLogger(__name__)


@register_workflow
class JustificationEngine(BaseWorkflow):
    """Clean justification engine focused on the essential workflow."""

    # Workflow metadata for registry
    workflow_id: str = "justification"
    name: str = "Code Justification Analysis"
    description: str = "Analyze code architecture for misplaced/useless/redundant files using LLM"
    version: str = "3.0"
    category: str = "analysis"
    tags: set = {"code-quality", "llm-analysis", "architecture"}

    def __init__(self, config: Optional[WorkflowConfig] = None):
        self.workflow_id = "justification"
        self.name = "Code Justification Analysis"
        self.description = (
            "Analyze code architecture for misplaced/useless/redundant files using LLM"
        )
        self.version = "1.0"
        super().__init__(config)
        self.config = config or WorkflowConfig()
        self.llm_client = None
        self.cache_file = Path(".maxwell/cache/file_summaries.json")

        # Initialize LLM manager
        self._init_llm()

        # Don't set up logging during __init__ - only when actually run
        self.timestamp = None
        self.xml_output = None
        self.jsonl_log_file = None
        self.master_log_file = None
        self.xml_file = None
        self._logging_setup = False

        # Load summary cache
        self.summary_cache = self._load_cache()

    def _init_llm(self):
        """Initialize LLM client using pool system."""
        try:
            from maxwell.lm_pool import get_lm

            # Get fast LM (for file summaries) - needs decent context for large files
            self.fast_llm = get_lm(min_context=16000)  # Ensure we can handle large files
            # Get LM for orchestrator-level analysis (large context)
            self.orchestrator_llm = get_lm(min_context=32000)

            # Use spec for token limits
            self.fast_max_tokens = self.fast_llm.spec.capabilities.get("max_tokens", 2048)
            self.fast_max_context_tokens = self.fast_llm.spec.capabilities.get("max_context", 8192)
            self.orchestrator_max_tokens = self.orchestrator_llm.spec.capabilities.get(
                "max_tokens", 8192
            )
            self.orchestrator_max_context_tokens = self.orchestrator_llm.spec.capabilities.get(
                "max_context", 131072
            )

            logger.info(
                f"LM pool initialized (fast: {self.fast_llm.spec.name}, "
                f"orchestrator: {self.orchestrator_llm.spec.name})"
            )
        except Exception as e:
            logger.warning(f"LM not available: {e}")
            self.fast_llm = None
            self.orchestrator_llm = None
            # Fallback defaults if LLM not available
            self.fast_max_tokens = 2048
            self.fast_max_context_tokens = 8192
            self.orchestrator_max_tokens = 8192
            self.orchestrator_max_context_tokens = 131072

    def _setup_logging(self):
        """Set up both JSONL (LLM calls) and master log (process) files."""
        if self._logging_setup:
            return  # Already set up

        # Initialize timestamp only when actually running
        self.timestamp = time.strftime("%Y%m%d_%H%M%S")
        self.xml_output = Path(f".maxwell/reports/project_analysis_{self.timestamp}.xml")

        logs_dir = Path(".maxwell/logs")
        logs_dir.mkdir(parents=True, exist_ok=True)

        # Auto-create .gitignore in .maxwell/ so outputs don't get tracked
        maxwell_gitignore = Path(".maxwell/.gitignore")
        if not maxwell_gitignore.exists():
            maxwell_gitignore.write_text("*\n")

        # Use the same timestamp as the report files for consistency
        # Master log file for human-readable process logging
        self.master_log_file = logs_dir / f"justification_{self.timestamp}.log"

        # JSONL log file for LLM prompt-response pairs (new pool system doesn't have callbacks yet)
        if self.fast_llm:
            self.jsonl_log_file = logs_dir / f"justification_{self.timestamp}.jsonl"
            self.jsonl_log_file.touch()
            self._log(f"JSONL logging: {self.jsonl_log_file} (manual logging)")

        self._logging_setup = True

        self._log(f"Master log file: {self.master_log_file}")

    def _log(self, message: str):
        """Write to master log file with timestamp."""
        if self.master_log_file:
            try:
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(self.master_log_file, "a") as f:
                    f.write(f"[{timestamp}] {message}\n")
            except Exception as e:
                logger.debug(f"Failed to write master log: {e}")
        # Also log to Python logger
        logger.info(message)

    def _load_cache(self) -> Dict[str, str]:
        """Load file summary cache."""
        if self.cache_file.exists():
            try:
                return json.loads(self.cache_file.read_text())
            except Exception as e:
                logger.warning(f"Failed to load cache: {e}")
        return {}

    def _save_cache(self):
        """Save file summary cache."""
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)
        self.cache_file.write_text(json.dumps(self.summary_cache, indent=2))

    def _get_file_hash(self, file_path: Path) -> str:
        """Get file content hash for caching."""
        try:
            content = file_path.read_text(encoding="utf-8")
            return hashlib.sha256(content.encode()).hexdigest()[:16]
        except Exception:
            return hashlib.sha256(str(file_path).encode()).hexdigest()[:16]

    def _discover_files(self, root: Path) -> List[Path]:
        """Discover all relevant files using maxwell's discovery system."""
        from maxwell.config import load_hierarchical_config
        from maxwell.discovery import discover_files

        # Load config for the project
        config = load_hierarchical_config(root)

        # Use maxwell's discover_files with the project root
        files = discover_files(paths=[root], config=config, explicit_exclude_paths=set())

        # Filter out very large files
        return sorted([f for f in files if f.stat().st_size < 2 * 1024 * 1024])

    def _build_tree_xml(self, root: Path, files: List[Path]) -> ET.Element:
        """Build XML tree structure."""
        project_elem = ET.Element("project", name=root.name, path=str(root))

        # Group files by directory
        dir_structure = {}
        for file_path in files:
            relative = file_path.relative_to(root)
            parts = relative.parts

            current = dir_structure
            for part in parts[:-1]:  # All but the filename
                if part not in current:
                    current[part] = {}
                current = current[part]

            # Add the file
            filename = parts[-1]
            current[filename] = file_path

        def add_to_xml(parent_elem, structure, base_path=""):
            for name, content in sorted(structure.items()):
                if isinstance(content, dict):
                    # It's a directory
                    dir_elem = ET.SubElement(
                        parent_elem, "directory", name=name, path=f"{base_path}/{name}".strip("/")
                    )
                    add_to_xml(dir_elem, content, f"{base_path}/{name}".strip("/"))
                else:
                    # It's a file
                    file_path = content
                    file_elem = ET.SubElement(
                        parent_elem,
                        "file",
                        name=name,
                        path=str(file_path.relative_to(root)),
                        size=str(file_path.stat().st_size),
                    )

                    # Add file summary if available
                    file_hash = self._get_file_hash(file_path)
                    summary = self.summary_cache.get(file_hash, "")
                    if summary:
                        summary_elem = ET.SubElement(file_elem, "summary")
                        summary_elem.text = summary

        add_to_xml(project_elem, dir_structure)
        return project_elem

    def _chunk_content(self, content: str, max_chars: int) -> List[str]:
        """Chunk content to fit in LLM context window."""
        if len(content) <= max_chars:
            return [content]

        chunks = []
        lines = content.split("\n")
        current_chunk = []
        current_size = 0

        for line in lines:
            line_size = len(line) + 1  # +1 for newline
            if current_size + line_size > max_chars and current_chunk:
                chunks.append("\n".join(current_chunk))
                current_chunk = [line]
                current_size = line_size
            else:
                current_chunk.append(line)
                current_size += line_size

        if current_chunk:
            chunks.append("\n".join(current_chunk))

        return chunks

    def _summarize_file(self, file_path: Path) -> str:
        """Summarize file purpose using fast LLM with proper chunking."""
        from maxwell.filesystem import is_binary

        if not self.fast_llm:
            raise RuntimeError("LLM client not initialized")

        # Check if file is binary
        if is_binary(file_path):
            return "[Binary file - cannot summarize content]"

        try:
            content = file_path.read_text(encoding="utf-8")
            if not content.strip():
                return "[Empty file]"

            # Calculate max content size for fast LLM context window
            # Use 3 chars/token estimation, reserve space for prompt overhead (~100 tokens)
            prompt_overhead_tokens = 100
            max_content_tokens = self.fast_max_context_tokens - prompt_overhead_tokens
            max_content_chars = max_content_tokens * 3

            chunks = self._chunk_content(content, max_content_chars)

            # Analyze each chunk and concatenate summaries (no synthesis step for speed)
            chunk_summaries = []
            for i, chunk in enumerate(chunks):
                if len(chunks) == 1:
                    chunk_prompt = f"""File: {file_path.name}

```
{chunk}
```

Output a 1-2 sentence summary of what this file does. No preamble, just the summary:"""
                else:
                    chunk_prompt = f"""File: {file_path.name} (part {i+1}/{len(chunks)})

```
{chunk}
```

One sentence describing what this code does:"""

                response = self.fast_llm.generate(
                    chunk_prompt, max_tokens=self.fast_max_tokens, temperature=0.1
                )

                if not response:
                    raise RuntimeError(
                        f"LLM failed to generate summary for chunk {i+1}/{len(chunks)} of {file_path.name}"
                    )

                chunk_summaries.append(response.strip())

            # Concatenate all chunk summaries
            return " ".join(chunk_summaries)

        except Exception as e:
            logger.warning(f"Failed to summarize {file_path}: {e}")
            raise  # Re-raise to prevent caching failed summaries

    def _chunk_xml_semantically(self, xml_content: str) -> List[str]:
        """Chunk XML content by directory structure to fit in orchestrator context."""
        # Parse XML to extract file entries
        root = ET.fromstring(xml_content)

        # Group files by their top-level directory
        dir_groups = {}
        for file_elem in root.findall(".//file"):
            file_path = file_elem.get("path", "")
            parts = file_path.split("/")
            top_dir = parts[0] if len(parts) > 1 else "root"

            if top_dir not in dir_groups:
                dir_groups[top_dir] = []

            # Serialize this file element
            file_xml = ET.tostring(file_elem, encoding="unicode")
            dir_groups[top_dir].append(file_xml)

        # Calculate max chunk size (90% of orchestrator context for prompt overhead)
        max_chunk_tokens = int(self.orchestrator_max_context_tokens * 0.9)
        max_chunk_chars = max_chunk_tokens * 3

        # Build chunks from directory groups
        chunks = []
        current_chunk = []
        current_size = 0

        project_header = f'<project name="{root.get("name")}" path="{root.get("path")}">\n'
        project_footer = "</project>"
        header_size = len(project_header) + len(project_footer)

        for _, files in sorted(dir_groups.items()):
            dir_content = "\n".join(files)
            dir_size = len(dir_content)

            # If adding this directory would exceed limit, start new chunk
            if current_size + dir_size + header_size > max_chunk_chars and current_chunk:
                chunk_xml = project_header + "\n".join(current_chunk) + "\n" + project_footer
                chunks.append(chunk_xml)
                current_chunk = [dir_content]
                current_size = dir_size
            else:
                current_chunk.append(dir_content)
                current_size += dir_size

        # Add final chunk
        if current_chunk:
            chunk_xml = project_header + "\n".join(current_chunk) + "\n" + project_footer
            chunks.append(chunk_xml)

        return chunks

    def _analyze_xml_chunk(
        self, chunk_xml: str, chunk_num: int, total_chunks: int, root: Path
    ) -> str:
        """Analyze a single XML chunk with orchestrator LLM."""
        if not self.orchestrator_llm:
            return "LLM not available for chunk analysis"

        chunk_context = (
            f" (analyzing part {chunk_num} of {total_chunks})" if total_chunks > 1 else ""
        )

        prompt = f"""Analyze this project structure{chunk_context} to identify issues:

**PROJECT ROOT PRINCIPLE**: A well-organized Python project keeps its root directory minimal and purposeful.

**Root directory should ONLY contain**:
- Project metadata: setup.py, pyproject.toml, MANIFEST.in, tox.ini, LICENSE
- Documentation: README.md (single entry point)
- Configuration: .gitignore, .env.example
- Package entry points: __init__.py, __main__.py, conftest.py (for testing)

**Everything else belongs in subdirectories**:
- Source code → src/ or package_name/
- Scripts and utilities → scripts/ or tools/
- Documentation → docs/
- Tests → tests/
- Examples → examples/

1. **Misplaced files**: Files in wrong directories based on their purpose
   - **Scan file paths**: Files at root level have NO `/` in their path attribute
   - **Evaluate purpose from summary**: Does this file's functionality belong at project root?
   - Common misplacements:
     * Scripts that transform/convert/modify files → should be in scripts/ or tools/
     * Utility code that's imported by the project → should be in src/
     * Additional documentation → should be in docs/
     * Test helpers or fixtures → should be in tests/

2. **Useless files**: Dead code, unused files, or files with no clear purpose
   - One-time migration scripts that have completed their purpose
   - Backup files (*.bak, *_old.py, *_backup.py)
   - Duplicate files with similar names
   - Files that are never imported or executed

3. **Redundant files**: Files with duplicate or overlapping functionality
   - Multiple files with similar summaries or purposes
   - Duplicate utility functions across modules
   - Multiple documentation files covering the same topic

4. **Overly large files**: Files >25000 bytes indicate poor modularity (check size attribute)
   - Files that could be split into logical components
   - Orchestrators or workflows that should be decomposed

5. **Consolidation opportunities**: Files that could be merged or deduplicated
   - Similar validators or workflows
   - Related documentation that should be combined

**ANALYSIS APPROACH**:
1. First, scan all files with path containing no `/` → these are at root level
2. For each root-level file, evaluate: "Should this be at root based on the principles above?"
3. If NO, flag it as misplaced with its actual purpose and recommended location
4. Then analyze the rest of the structure for other categories

Project: {root.name}

{chunk_xml}

Provide specific findings for each category with file paths and consolidation recommendations:"""

        try:
            response = self.orchestrator_llm.generate(
                prompt, max_tokens=self.orchestrator_max_tokens, temperature=0.2
            )
            if response:
                return response.strip()
            else:
                return f"Chunk {chunk_num} analysis failed"

        except Exception as e:
            logger.error(f"Chunk {chunk_num} analysis failed: {e}")
            return f"Chunk {chunk_num} error: {e}"

    def _build_tree_structure(self, files: List[Path], project_root: Path) -> str:
        """Build a tree-style representation of the file structure (paths only)."""
        tree_lines = []

        for file_path in sorted(files):
            rel_path = file_path.resolve().relative_to(project_root)
            tree_lines.append(str(rel_path))

        return "\n".join(tree_lines)

    def _load_project_rules(self, project_root: Path) -> str:
        """Load project-specific justification rules from AGENTS.instructions.md."""
        agents_file = project_root / "AGENTS.instructions.md"

        if not agents_file.exists():
            return ""

        try:
            content = agents_file.read_text()

            # Extract the "File Organization & Project Structure Rules" section
            if "## File Organization & Project Structure Rules" in content:
                # Find the section
                start = content.find("## File Organization & Project Structure Rules")
                # Find the next ## heading or end of file
                next_section = content.find("\n## ", start + 1)

                if next_section == -1:
                    rules_section = content[start:]
                else:
                    rules_section = content[start:next_section]

                return rules_section.strip()

            return ""
        except Exception as e:
            logger.warning(f"Failed to load project rules from AGENTS.instructions.md: {e}")
            return ""

    def _analyze_structure(self, files: List[Path], project_root: Path) -> str:
        """Phase 1: Analyze project structure based on file paths alone."""
        if not self.orchestrator_llm:
            return "LLM not available for structural analysis"

        tree = self._build_tree_structure(files, project_root)
        project_rules = self._load_project_rules(project_root)

        if project_rules:
            self._log("Loaded project-specific rules from AGENTS.instructions.md")

        # Build base prompt
        base_prompt = """Analyze this project's file structure for organizational issues.

**PROJECT ROOT PRINCIPLE**: A well-organized Python project keeps its root directory minimal.

**Root directory should ONLY contain**:
- Project metadata: setup.py, pyproject.toml, MANIFEST.in, tox.ini, LICENSE
- Single documentation entry point: README.md
- Configuration: .gitignore, .env.example
- Package entry points: __init__.py, __main__.py, conftest.py
- AI/Agent instructions: CLAUDE.md, AGENTS.instructions.md, *.instructions.md

**Everything else belongs in subdirectories**:
- Source code → src/ or package_name/
- Documentation → docs/
- Tests → tests/
- Examples → examples/"""

        # Add project-specific rules if found
        if project_rules:
            prompt = f"""{base_prompt}

**PROJECT-SPECIFIC RULES** (from AGENTS.instructions.md):
{project_rules}

**File Structure** ({len(files)} files):
```
{tree}
```

**Task**: Identify files that are misplaced based on BOTH the general principles above AND the project-specific rules. For each misplaced file:
1. State the file path
2. Explain why it's misplaced (what principle or project rule it violates)
3. Suggest where it should be moved OR if it should be deleted

Focus on:
- Root-level files that don't belong there
- Files in wrong subdirectories
- Forbidden directories (per project rules)
- One-off scripts that should be deleted or integrated

Be specific and direct. List misplaced files clearly."""
        else:
            prompt = f"""{base_prompt}

**File Structure** ({len(files)} files):
```
{tree}
```

**Task**: Identify files that are misplaced based ONLY on their location. For each misplaced file:
1. State the file path
2. Explain why it's misplaced (what principle it violates)
3. Suggest where it should be moved

Focus on:
- Root-level files that don't belong there
- Files in wrong subdirectories
- Missing organizational structure

Be specific and direct. List misplaced files clearly."""

        try:
            self._log("Running structural analysis (file paths only)...")
            response = self.orchestrator_llm.generate(
                prompt, max_tokens=self.orchestrator_max_tokens, temperature=0.2
            )
            if response:
                return response.strip()
            else:
                return "Structural analysis failed"

        except Exception as e:
            logger.error(f"Structural analysis failed: {e}")
            return f"Structural analysis error: {e}"

    def _synthesize_chunk_analyses(
        self, structural_analysis: str, chunk_analyses: List[str], root: Path
    ) -> str:
        """Synthesize structural + semantic analyses into final report."""
        if not self.orchestrator_llm:
            return f"## Structural Analysis\n\n{structural_analysis}\n\n" + "\n\n---\n\n".join(
                chunk_analyses
            )

        combined_semantic = "\n\n---\n\n".join(
            [
                f"**Semantic Analysis Part {i+1}:**\n{analysis}"
                for i, analysis in enumerate(chunk_analyses)
            ]
        )

        prompt = f"""Synthesize this multi-phase project analysis into a comprehensive report:

**PHASE 1: Structural Analysis (file organization)**
{structural_analysis}

**PHASE 2: Semantic Analysis (file content and purpose)**
{combined_semantic}

Create a unified report that:
1. Combines structural and semantic findings (avoid duplication)
2. Cross-references findings from both phases
3. Provides prioritized, actionable recommendations
4. Groups related issues together

**CRITICAL**: Do NOT include time estimates, timelines, or effort predictions (e.g., "1 week", "4-6 weeks", "15-30 minutes"). Focus on WHAT should be done and WHY, not HOW LONG it will take. The developer will determine timing based on their context.

Project: {root.name}"""

        try:
            response = self.orchestrator_llm.generate(
                prompt, max_tokens=self.orchestrator_max_tokens, temperature=0.2
            )
            if response:
                return response.strip()
            else:
                # Fallback to simple concatenation
                return (
                    f"## Structural Analysis\n\n{structural_analysis}\n\n"
                    + f"## Semantic Analysis\n\n{combined_semantic}"
                )

        except Exception as e:
            logger.error(f"Synthesis failed: {e}")
            return (
                f"## Structural Analysis\n\n{structural_analysis}\n\n"
                + f"## Semantic Analysis\n\n{combined_semantic}"
            )

    def run_justification(self, project_root: Path) -> Dict:
        """Run the complete justification workflow."""
        try:
            start_time = time.time()
            # Ensure logging is set up
            self._setup_logging()

            # Ensure project_root is absolute
            project_root = project_root.resolve()
            self._log(f"Starting justification analysis for: {project_root}")

            # Step 1: Discover files
            files = self._discover_files(project_root)
            self._log(f"Discovered {len(files)} files")

            # Step 2: Initialize XML file for streaming
            if self.xml_output is None:
                raise ValueError("XML output path not initialized")

            self.xml_output.parent.mkdir(parents=True, exist_ok=True)
            with open(self.xml_output, "w") as xml_file:
                xml_file.write(f'<project name="{project_root.name}" path="{project_root}">\n')

                # Step 3: Summarize files and write to XML incrementally
                cache_hits = 0
                cache_misses = 0

                for idx, file_path in enumerate(files, 1):
                    file_hash = self._get_file_hash(file_path)
                    # Ensure file_path is absolute before making relative
                    rel_path = file_path.resolve().relative_to(project_root)

                    # Get or generate summary
                    if file_hash in self.summary_cache:
                        summary = self.summary_cache[file_hash]
                        cache_hits += 1
                    else:
                        self._log(f"Summarizing: {rel_path}")

                        try:
                            summary = self._summarize_file(file_path)
                            # Cache successful summary
                            self.summary_cache[file_hash] = summary
                            self._save_cache()
                            cache_misses += 1
                        except Exception as e:
                            # Don't cache failures - use placeholder for this run only
                            summary = f"[Failed to summarize: {e}]"
                            logger.error(f"Failed to summarize {rel_path}: {e}")
                            cache_misses += 1

                    # Write file entry to XML immediately with CDATA wrapping
                    xml_file.write(
                        f'  <file path="{rel_path}" size="{file_path.stat().st_size}">\n'
                    )
                    xml_file.write(f"    <summary><![CDATA[{summary}]]></summary>\n")
                    xml_file.write("  </file>\n")
                    xml_file.flush()  # Force write to disk

                # Close project tag
                xml_file.write("</project>\n")

            self._log(f"File summaries: {cache_hits} cached, {cache_misses} new")
            self._log(f"XML written to: {self.xml_output}")

            # Step 4: PHASE 1 - Structural analysis (file paths only)
            self._log("=" * 60)
            self._log("PHASE 1: Structural Analysis (file organization)")
            self._log("=" * 60)
            structural_analysis = self._analyze_structure(files, project_root)

            # Step 5: PHASE 2 - Semantic analysis (file content/purpose)
            self._log("=" * 60)
            self._log("PHASE 2: Semantic Analysis (file content)")
            self._log("=" * 60)

            assert self.xml_output is not None  # Already checked above
            xml_content = self.xml_output.read_text()
            xml_size_chars = len(xml_content)
            xml_size_tokens = xml_size_chars // 3

            self._log(f"XML size: {xml_size_chars:,} chars (~{xml_size_tokens:,} tokens)")

            # Chunk XML semantically by directory structure
            xml_chunks = self._chunk_xml_semantically(xml_content)
            self._log(f"XML chunked into {len(xml_chunks)} parts for semantic analysis")

            # Analyze each chunk
            chunk_analyses = []
            for i, chunk in enumerate(xml_chunks):
                self._log(f"Analyzing semantic chunk {i+1}/{len(xml_chunks)}...")
                chunk_analysis = self._analyze_xml_chunk(
                    chunk, i + 1, len(xml_chunks), project_root
                )
                chunk_analyses.append(chunk_analysis)

            # Step 6: Synthesize both phases into final report
            self._log("=" * 60)
            self._log("SYNTHESIS: Combining structural + semantic findings")
            self._log("=" * 60)
            analysis = self._synthesize_chunk_analyses(
                structural_analysis, chunk_analyses, project_root
            )

            # Step 5: Generate final report
            duration = time.time() - start_time
            report = f"""# Project Justification Analysis

**Project:** {project_root.name}
**Files Analyzed:** {len(files)}
**Cache Performance:** {cache_hits} hits, {cache_misses} misses
**Analysis Time:** {duration:.1f}s

## Orchestrator Analysis

{analysis}

## Project Structure

See: {self.xml_output}
"""

            # Step 7: Run validation and generate checklist
            self._log("=" * 60)
            self._log("VALIDATION: Running code quality checks")
            self._log("=" * 60)

            validation_checklist = self._run_validation_and_generate_checklist(
                project_root, analysis
            )

            # Append checklist to report
            full_report = report + "\n\n" + validation_checklist

            # Save report with timestamp
            report_file = Path(f".maxwell/reports/justification_analysis_{self.timestamp}.md")
            report_file.parent.mkdir(parents=True, exist_ok=True)
            report_file.write_text(full_report)

            logger.info(f"Analysis complete in {duration:.1f}s")

            return {
                "success": True,
                "exit_code": 0,
                "report": full_report,
                "files_analyzed": len(files),
                "cache_hits": cache_hits,
                "cache_misses": cache_misses,
                "duration": duration,
            }

        except Exception as e:
            logger.error(f"Justification analysis failed: {e}")
            return {
                "success": False,
                "exit_code": 1,
                "error": str(e),
                "report": f"Analysis failed: {e}",
            }

    def _run_validation_and_generate_checklist(
        self, project_root: Path, justification_analysis: str
    ) -> str:
        """Run all quality checks (validate, ruff, pyright) and generate combined checklist.

        Args:
            project_root: Project root directory
            justification_analysis: Justification analysis text from orchestrator

        Returns:
            Markdown formatted checklist combining all findings

        """
        import subprocess
        from maxwell.api import execute_workflow

        # 1. Run validate workflow
        self._log("Running validate workflow...")
        validate_findings = []
        try:
            validate_result = execute_workflow("validate", project_root)
            for finding in validate_result.findings:
                if isinstance(finding, dict):
                    validate_findings.append(finding)
                else:
                    # It's a FindingModel dataclass
                    validate_findings.append(
                        {
                            "rule_id": finding.rule_id,
                            "message": finding.message,
                            "file_path": finding.file_path,
                            "line": finding.line,
                            "severity": finding.severity,
                            "suggestion": finding.suggestion,
                            "source": "validate",
                        }
                    )
            self._log(f"Validate complete: {len(validate_findings)} findings")
        except Exception as e:
            logger.error(f"Failed to run validate: {e}")
            validate_findings = []

        # 2. Run ruff check
        self._log("Running ruff check...")
        ruff_findings = self._run_ruff_check(project_root)
        self._log(f"Ruff check complete: {len(ruff_findings)} findings")

        # 3. Run pyright
        self._log("Running pyright...")
        pyright_findings = self._run_pyright(project_root)
        self._log(f"Pyright complete: {len(pyright_findings)} findings")

        # Parse justification analysis for actionable issues
        justification_issues = self._extract_justification_issues(justification_analysis)

        # Generate comprehensive checklist
        checklist = self._generate_comprehensive_checklist(
            justification_issues=justification_issues,
            validate_findings=validate_findings,
            ruff_findings=ruff_findings,
            pyright_findings=pyright_findings,
        )

        return checklist

    def _run_ruff_check(self, project_root: Path) -> List[Dict[str, Any]]:
        """Run ruff check and parse output.

        Args:
            project_root: Project root directory

        Returns:
            List of findings from ruff

        """
        import subprocess

        findings = []
        try:
            # Run ruff with JSON output
            result = subprocess.run(
                ["ruff", "check", "src/", "tests/", "--output-format=json"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=120,
            )

            # Ruff returns exit code 1 if there are violations, which is expected
            if result.stdout:
                import json

                ruff_output = json.loads(result.stdout)
                for item in ruff_output:
                    findings.append(
                        {
                            "rule_id": item.get("code", "RUFF-UNKNOWN"),
                            "message": item.get("message", ""),
                            "file_path": str(item.get("filename", "")),
                            "line": item.get("location", {}).get("row", 0),
                            "column": item.get("location", {}).get("column", 0),
                            "severity": "WARN",  # Ruff violations are warnings
                            "suggestion": item.get("fix", {}).get("message") if item.get("fix") else None,
                            "source": "ruff",
                        }
                    )
        except subprocess.TimeoutExpired:
            logger.error("Ruff check timed out")
        except FileNotFoundError:
            logger.warning("Ruff not found in PATH")
        except Exception as e:
            logger.error(f"Failed to run ruff: {e}")

        return findings

    def _run_pyright(self, project_root: Path) -> List[Dict[str, Any]]:
        """Run pyright and parse output.

        Args:
            project_root: Project root directory

        Returns:
            List of findings from pyright

        """
        import subprocess

        findings = []
        try:
            # Run pyright with JSON output
            result = subprocess.run(
                ["pyright", "src/", "--outputjson"],
                cwd=project_root,
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.stdout:
                import json

                pyright_output = json.loads(result.stdout)
                for diagnostic in pyright_output.get("generalDiagnostics", []):
                    # Map pyright severity to our severity levels
                    severity_map = {
                        "error": "BLOCK",
                        "warning": "WARN",
                        "information": "INFO",
                    }
                    severity = severity_map.get(diagnostic.get("severity", "warning"), "WARN")

                    findings.append(
                        {
                            "rule_id": f"PYRIGHT-{diagnostic.get('rule', 'UNKNOWN')}",
                            "message": diagnostic.get("message", ""),
                            "file_path": str(diagnostic.get("file", "")),
                            "line": diagnostic.get("range", {}).get("start", {}).get("line", 0) + 1,
                            "column": diagnostic.get("range", {}).get("start", {}).get("character", 0),
                            "severity": severity,
                            "suggestion": None,
                            "source": "pyright",
                        }
                    )
        except subprocess.TimeoutExpired:
            logger.error("Pyright check timed out")
        except FileNotFoundError:
            logger.warning("Pyright not found in PATH")
        except Exception as e:
            logger.error(f"Failed to run pyright: {e}")

        return findings

    def _extract_justification_issues(self, analysis: str) -> List[Dict[str, str]]:
        """Extract actionable issues from justification analysis.

        Args:
            analysis: Raw justification analysis text

        Returns:
            List of issues with title, description, and priority

        """
        issues = []

        # Parse for common patterns in justification reports
        # Look for sections with recommendations

        # Pattern 1: Files to move (table format)
        if "Misplaced Files" in analysis or "File Path" in analysis:
            issues.append(
                {
                    "title": "Reorganize misplaced files",
                    "description": "Files are located in incorrect directories per project structure conventions",
                    "priority": "HIGH",
                    "category": "Structure",
                }
            )

        # Pattern 2: Useless/redundant files
        if "Useless" in analysis or "Redundant" in analysis or "Remove" in analysis.lower():
            issues.append(
                {
                    "title": "Remove useless or redundant files",
                    "description": "Files that serve no purpose or duplicate functionality",
                    "priority": "MEDIUM",
                    "category": "Cleanup",
                }
            )

        # Pattern 3: Large files needing decomposition
        if "Large" in analysis or "Split" in analysis or "Decompose" in analysis:
            issues.append(
                {
                    "title": "Refactor large monolithic files",
                    "description": "Files that are too large and should be split into smaller modules",
                    "priority": "MEDIUM",
                    "category": "Modularity",
                }
            )

        # Pattern 4: Documentation consolidation
        if "Documentation" in analysis or "README" in analysis or "docs/" in analysis:
            issues.append(
                {
                    "title": "Consolidate documentation",
                    "description": "Documentation files should be organized under docs/ directory",
                    "priority": "MEDIUM",
                    "category": "Documentation",
                }
            )

        # Pattern 5: Configuration organization
        if "config" in analysis.lower() and ("move" in analysis.lower() or "organize" in analysis.lower()):
            issues.append(
                {
                    "title": "Organize configuration files",
                    "description": "Configuration files should follow project structure conventions",
                    "priority": "LOW",
                    "category": "Structure",
                }
            )

        return issues

    def _generate_comprehensive_checklist(
        self,
        justification_issues: List[Dict[str, str]],
        validate_findings: List[Dict[str, Any]],
        ruff_findings: List[Dict[str, Any]],
        pyright_findings: List[Dict[str, Any]],
    ) -> str:
        """Generate comprehensive action checklist from all quality checks.

        Args:
            justification_issues: High-level architectural issues
            validate_findings: Findings from validate workflow
            ruff_findings: Findings from ruff check
            pyright_findings: Findings from pyright

        Returns:
            Markdown formatted comprehensive checklist

        """
        # Combine all findings and organize by severity
        all_findings = validate_findings + ruff_findings + pyright_findings
        findings_by_severity = {"BLOCK": [], "WARN": [], "INFO": []}
        findings_by_source = {
            "validate": [],
            "ruff": [],
            "pyright": [],
        }

        for finding in all_findings:
            severity = finding.get("severity", "INFO")
            source = finding.get("source", "unknown")

            if severity in findings_by_severity:
                findings_by_severity[severity].append(finding)

            if source in findings_by_source:
                findings_by_source[source].append(finding)

        total_findings = len(all_findings)
        total_blocking = len(findings_by_severity.get("BLOCK", []))
        total_warnings = len(findings_by_severity.get("WARN", []))
        total_info = len(findings_by_severity.get("INFO", []))

        # Build checklist
        checklist = "\n---\n\n# 🎯 Comprehensive Quality Checklist\n\n"
        checklist += (
            "*This checklist combines architectural analysis, custom validators, "
            "ruff linting, and pyright type checking.*\n\n"
        )

        # Summary
        checklist += "## 📊 Summary\n\n"
        checklist += f"- **Justification Issues:** {len(justification_issues)} (architectural)\n"
        checklist += f"- **Total Quality Findings:** {total_findings}\n"
        checklist += f"  - 🔴 BLOCKING: {total_blocking}\n"
        checklist += f"  - ⚠️  WARNINGS: {total_warnings}\n"
        checklist += f"  - ℹ️  INFO: {total_info}\n\n"

        checklist += "**By Source:**\n"
        checklist += f"- Validate (custom): {len(findings_by_source['validate'])}\n"
        checklist += f"- Ruff (linting): {len(findings_by_source['ruff'])}\n"
        checklist += f"- Pyright (types): {len(findings_by_source['pyright'])}\n\n"

        # High-level justification issues
        if justification_issues:
            checklist += "## 📋 Architectural Issues\n\n"
            checklist += "*From LLM-based justification analysis*\n\n"
            for idx, issue in enumerate(justification_issues, 1):
                priority_emoji = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(
                    issue["priority"], "⚪"
                )
                checklist += f"{idx}. {priority_emoji} **{issue['title']}** "
                checklist += f"[{issue['category']}] [Priority: {issue['priority']}]\n"
                checklist += f"   - {issue['description']}\n"
                checklist += "   - [ ] Reviewed\n"
                checklist += "   - [ ] Fixed\n\n"

        # Blocking issues (all sources)
        if findings_by_severity.get("BLOCK"):
            checklist += "## ❌ BLOCKING Issues\n\n"
            checklist += "*Must be fixed before merging*\n\n"

            # Group by source
            blocking_by_source = {}
            for finding in findings_by_severity["BLOCK"]:
                source = finding.get("source", "unknown")
                if source not in blocking_by_source:
                    blocking_by_source[source] = []
                blocking_by_source[source].append(finding)

            for source in ["pyright", "validate", "ruff"]:
                if source not in blocking_by_source:
                    continue

                source_display = {
                    "pyright": "Type Errors (Pyright)",
                    "validate": "Custom Validators",
                    "ruff": "Linting (Ruff)",
                }.get(source, source)

                checklist += f"### {source_display}\n\n"
                for finding in blocking_by_source[source][:20]:  # Limit to first 20
                    checklist += (
                        f"- [ ] **{finding['rule_id']}** - "
                        f"`{finding['file_path']}:{finding['line']}`\n"
                    )
                    checklist += f"  - {finding['message']}\n"
                    if finding.get("suggestion"):
                        checklist += f"  - 💡 *{finding['suggestion']}*\n"

                if len(blocking_by_source[source]) > 20:
                    checklist += f"\n*...and {len(blocking_by_source[source]) - 20} more*\n"
                checklist += "\n"

        # Warnings by source
        if findings_by_severity.get("WARN"):
            checklist += "## ⚠️  Warnings\n\n"
            checklist += "*Recommended fixes (grouped by type)*\n\n"

            # Group warnings by rule_id within each source
            for source in ["validate", "ruff", "pyright"]:
                source_warnings = [f for f in findings_by_severity["WARN"] if f.get("source") == source]
                if not source_warnings:
                    continue

                source_display = {
                    "validate": "Custom Validators",
                    "ruff": "Ruff Linting",
                    "pyright": "Pyright Type Hints",
                }.get(source, source)

                checklist += f"### {source_display} ({len(source_warnings)} warnings)\n\n"

                # Group by rule_id
                warnings_by_rule = {}
                for finding in source_warnings:
                    rule = finding["rule_id"]
                    if rule not in warnings_by_rule:
                        warnings_by_rule[rule] = []
                    warnings_by_rule[rule].append(finding)

                # Show top 10 most common warnings for this source
                for rule_id, rule_findings in sorted(
                    warnings_by_rule.items(), key=lambda x: len(x[1]), reverse=True
                )[:10]:
                    checklist += f"#### {rule_id} ({len(rule_findings)} occurrences)\n\n"
                    checklist += "- [ ] Review and address\n"
                    # Show first 3 examples
                    for finding in rule_findings[:3]:
                        checklist += f"  - `{finding['file_path']}:{finding['line']}` - {finding['message']}\n"
                    if len(rule_findings) > 3:
                        checklist += f"  - *...and {len(rule_findings) - 3} more*\n"
                    checklist += "\n"

                if len(warnings_by_rule) > 10:
                    checklist += f"*...and {len(warnings_by_rule) - 10} more rule types*\n\n"

        # Info items
        if findings_by_severity.get("INFO"):
            checklist += f"## ℹ️  Informational ({total_info} items)\n\n"
            checklist += "*Optional improvements and suggestions*\n\n"
            checklist += "- [ ] Reviewed (optional)\n\n"

        # Instructions
        checklist += "## 📝 Instructions\n\n"
        checklist += "**Priority:**\n"
        checklist += "1. ❌ Fix ALL BLOCKING issues first (especially type errors)\n"
        checklist += "2. 📋 Address architectural issues (may require discussion)\n"
        checklist += "3. ⚠️  Review and fix warnings (grouped by frequency)\n"
        checklist += "4. ℹ️  Consider informational suggestions\n\n"

        checklist += "**Process:**\n"
        checklist += "1. Mark items with `[x]` as you complete them\n"
        checklist += "2. Run `pyright src/` frequently to verify type fixes\n"
        checklist += "3. Run `ruff check --fix src/ tests/` to auto-fix style issues\n"
        checklist += "4. Re-run justification to see updated progress\n\n"

        checklist += "---\n\n"
        checklist += "*Generated by Maxwell Justification Workflow*\n"

        return checklist

    # BaseWorkflow abstract method implementations
    def execute(self, project_root: Path, context: dict) -> "WorkflowResult":
        """Execute justification analysis workflow."""
        from maxwell.workflows.base import WorkflowMetrics, WorkflowResult, WorkflowStatus

        start_time = time.time()

        try:
            result = self.run_justification(project_root)
            end_time = time.time()

            metrics = WorkflowMetrics(
                start_time=start_time,
                end_time=end_time,
                files_processed=result.get("files_analyzed", 0),
                custom_metrics={
                    "cache_hits": result.get("cache_hits", 0),
                    "cache_misses": result.get("cache_misses", 0),
                },
            )
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.COMPLETED if result.get("success") else WorkflowStatus.FAILED,
                metrics=metrics,
                artifacts={"report": result.get("report", "")},
                error_message=result.get("error"),
            )
        except Exception as e:
            end_time = time.time()
            metrics = WorkflowMetrics(start_time=start_time, end_time=end_time)
            metrics.finalize()

            return WorkflowResult(
                workflow_id=self.workflow_id,
                status=WorkflowStatus.FAILED,
                metrics=metrics,
                error_message=str(e),
            )

    def get_required_inputs(self) -> set:
        """No required inputs."""
        return set()

    def get_produced_outputs(self) -> set:
        """Produces justification analysis outputs."""
        return {"justification_report", "xml_structure"}

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=1800,  # 30 minutes
            parameters={
                "root_dir": str(root_dir),
            },
        )
```

---
### File: src/maxwell/workflows/snapshot.py

```python
"""Codebase snapshot generation workflow.

Creates a single markdown file containing the filesystem tree and file contents.
"""

import fnmatch
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.config import MaxwellConfig
from maxwell.discovery import discover_files
from maxwell.filesystem import get_relative_path, is_binary
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)

FILES_KEY = "__FILES__"


@dataclass(frozen=True)
class SnapshotInputs(WorkflowInputs):
    """Input schema for snapshot workflow."""

    output: str = "SNAPSHOT.md"  # Output markdown file path
    target: Optional[str] = None  # Optional target directory (default: project root)


@dataclass(frozen=True)
class SnapshotOutputs(WorkflowOutputs):
    """Output schema for snapshot workflow."""

    snapshot_path: str
    files_included: int
    binary_files: int


@register_workflow
class SnapshotWorkflow(BaseWorkflow):
    """Generate a markdown snapshot of the codebase."""

    workflow_id: str = "snapshot"
    name: str = "Codebase Snapshot"
    description: str = "Generate a markdown file with filesystem tree and file contents"
    version: str = "2.0"
    category: str = "documentation"
    tags: set = {"snapshot", "documentation", "markdown"}

    InputSchema = SnapshotInputs
    OutputSchema = SnapshotOutputs

    def __init__(self):
        self.workflow_id = "snapshot"
        self.name = "Codebase Snapshot"
        self.description = "Generate a markdown file with filesystem tree and file contents"
        self.version = "2.0"
        super().__init__()

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "output",
                "type": str,
                "required": False,
                "default": "SNAPSHOT.md",
                "help": "Output markdown file path",
            },
            {
                "name": "target",
                "type": str,
                "required": False,
                "default": None,
                "help": "Target directory to snapshot (default: project root)",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        return []

    def get_produced_outputs(self) -> List[str]:
        return ["snapshot_path"]

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=300,
            parameters={"root_dir": str(root_dir)},
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute snapshot generation."""
        try:
            inputs: SnapshotInputs = self.parse_inputs(context)  # type: ignore[assignment]

            # Load Maxwell config
            from maxwell.config import load_hierarchical_config

            config = load_hierarchical_config(project_root)

            # Determine output path
            output_path = Path(inputs.output)
            if not output_path.is_absolute():
                output_path = project_root / output_path
            absolute_output_path = output_path.resolve()

            # Determine target paths
            if inputs.target:
                target_path = Path(inputs.target)
                if not target_path.is_absolute():
                    target_path = project_root / target_path
                target_paths = [target_path]
            else:
                target_paths = [project_root]

            logger.info(f"Creating snapshot: output={output_path}, target={target_paths}")

            # Discover files
            discovered_files = discover_files(
                paths=target_paths,
                config=config,
                explicit_exclude_paths={absolute_output_path},
            )

            logger.info(f"Discovered {len(discovered_files)} files")

            # Categorize files (FULL or BINARY)
            file_infos: List[tuple[Path, str]] = []

            for abs_file_path in discovered_files:
                try:
                    rel_path_obj = get_relative_path(abs_file_path, project_root)
                except ValueError:
                    logger.warning(f"Skipping file outside project root: {abs_file_path}")
                    continue

                if is_binary(abs_file_path):
                    cat = "BINARY"
                else:
                    cat = "FULL"
                file_infos.append((abs_file_path, cat))

            file_infos.sort(key=lambda x: x[0])

            # Count categories
            binary_count = sum(1 for _, cat in file_infos if cat == "BINARY")

            # Build tree structure
            tree: dict = {}
            for f_path, f_cat in file_infos:
                try:
                    relative_path_obj = get_relative_path(f_path, project_root)
                    relative_parts = relative_path_obj.parts
                except ValueError:
                    continue

                node = tree
                for i, part in enumerate(relative_parts):
                    if not part:
                        continue

                    is_last_part = i == len(relative_parts) - 1

                    if is_last_part:
                        if FILES_KEY not in node:
                            node[FILES_KEY] = []
                        node[FILES_KEY].append((f_path, f_cat))
                    else:
                        if part not in node:
                            node[part] = {}
                        node = node[part]

            # Write snapshot markdown file
            logger.info(f"Writing snapshot to {output_path}")
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(absolute_output_path, "w", encoding="utf-8") as outfile:
                outfile.write("# Snapshot\n\n")

                # Write Filesystem Tree
                outfile.write("## Filesystem Tree\n\n```\n")
                tree_root_name = project_root.name if project_root.name else str(project_root)
                outfile.write(f"{tree_root_name}/\n")
                self._write_tree(outfile, tree, "")
                outfile.write("```\n\n")

                # Write File Contents
                outfile.write("## File Contents\n\n")
                outfile.write("Files are ordered alphabetically by path.\n\n")

                for f, cat in file_infos:
                    try:
                        relpath_header = get_relative_path(f, project_root)
                        outfile.write(f"### File: {relpath_header}\n\n")

                        if cat == "BINARY":
                            outfile.write("```\n[Binary File - Content not displayed]\n```\n\n---\n")
                        else:  # FULL
                            lang = self._get_language(f)
                            outfile.write(f"```{lang}\n")
                            try:
                                with open(f, encoding="utf-8", errors="ignore") as infile:
                                    content = infile.read()
                                    if not content.endswith("\n"):
                                        content += "\n"
                                    outfile.write(content)
                            except (OSError, UnicodeDecodeError) as e:
                                outfile.write(f"[Error reading file: {e}]\n")
                            outfile.write("```\n\n---\n")

                    except (OSError, ValueError, TypeError) as e:
                        logger.error(f"Error processing file {f}: {e}")
                        outfile.write(f"### File: {f} (Error)\n\n[Error: {e}]\n\n---\n")

                outfile.write("\n")

            outputs = SnapshotOutputs(
                snapshot_path=str(output_path),
                files_included=len(file_infos),
                binary_files=binary_count,
            )

            logger.info(
                f"Snapshot created: {len(file_infos)} files ({binary_count} binary)"
            )

            return self.create_result(outputs)

        except Exception as e:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None, status=WorkflowStatus.FAILED, error_message=f"Snapshot failed: {str(e)}"
            )

    def _write_tree(self, outfile, node: dict, prefix=""):
        """Recursively write directory tree structure."""
        dirs = sorted([k for k in node if k != FILES_KEY])
        files_data: List[tuple[Path, str]] = sorted(
            node.get(FILES_KEY, []), key=lambda x: x[0].name
        )

        entries = dirs + [f_info[0].name for f_info in files_data]

        for i, name in enumerate(entries):
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            outfile.write(f"{prefix}{connector}")

            if name in dirs:
                outfile.write(f"{name}/\n")
                new_prefix = prefix + ("    " if is_last else "│   ")
                self._write_tree(outfile, node[name], new_prefix)
            else:
                file_info_tuple = next((info for info in files_data if info[0].name == name), None)
                file_cat = "FULL"
                if file_info_tuple:
                    file_cat = file_info_tuple[1]

                binary_indicator = " (BINARY)" if file_cat == "BINARY" else ""
                outfile.write(f"{name}{binary_indicator}\n")

    def _get_language(self, file_path: Path) -> str:
        """Guess language for syntax highlighting based on extension."""
        ext = file_path.suffix.lower()
        mapping = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".java": "java",
            ".c": "c",
            ".cpp": "cpp",
            ".cs": "csharp",
            ".go": "go",
            ".rs": "rust",
            ".rb": "ruby",
            ".php": "php",
            ".swift": "swift",
            ".kt": "kotlin",
            ".scala": "scala",
            ".html": "html",
            ".css": "css",
            ".scss": "scss",
            ".less": "less",
            ".json": "json",
            ".xml": "xml",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".md": "markdown",
            ".sh": "bash",
            ".ps1": "powershell",
            ".bat": "batch",
            ".sql": "sql",
            ".dockerfile": "dockerfile",
            ".toml": "toml",
            ".ini": "ini",
            ".cfg": "ini",
            ".gitignore": "gitignore",
            ".env": "bash",
            ".tf": "terraform",
            ".hcl": "terraform",
            ".lua": "lua",
            ".perl": "perl",
            ".pl": "perl",
            ".r": "r",
            ".ex": "elixir",
            ".exs": "elixir",
            ".dart": "dart",
            ".groovy": "groovy",
            ".gradle": "groovy",
            ".vb": "vbnet",
            ".fs": "fsharp",
            ".fsi": "fsharp",
            ".fsx": "fsharp",
            ".fsscript": "fsharp",
        }
        return mapping.get(ext, "")
```

---
### File: src/maxwell/workflows/tag_refactor.py

```python
"""Tag refactoring workflow for markdown documentation.

Formats semantic HTML tags (like <mithranm>, <claude>) in markdown files
to be on separate lines for improved readability and consistency.

This is a linting/formatting operation that ensures documentation tags
follow a consistent style across projects.

maxwell/src/maxwell/workflows/implementations/tag_refactor.py
"""

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Set

from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

logger = logging.getLogger(__name__)

__all__ = ["TagRefactorWorkflow", "refactor_tags_in_file", "refactor_tags_in_content"]


def refactor_tags_in_content(content: str) -> str:
    r"""Format semantic HTML tags to be on separate lines for readability.

    Only modifies custom tags (like <mithranm>, <claude>), leaves standard
    markdown/HTML tags alone.

    Args:
        content: Markdown content to process

    Returns:
        Reformatted content with tags on separate lines

    Examples:
        >>> content = '<mithranm topic="test">Question here</mithranm>'
        >>> refactor_tags_in_content(content)
        '\\n<mithranm topic="test">\\nQuestion here\\n</mithranm>\\n'

    """
    # Pattern to match opening tags like <mithranm ...> or <claude ...>
    # Captures: tag name and attributes
    opening_pattern = r"<(\w+)([^>]*)>"

    # Pattern to match closing tags like </mithranm> or </claude>
    closing_pattern = r"</(\w+)>"

    # Standard HTML/markdown tags to skip
    standard_tags = {
        "sup",
        "span",
        "a",
        "img",
        "div",
        "p",
        "br",
        "hr",
        "em",
        "strong",
        "code",
        "pre",
    }

    def format_opening_tag(match):
        tag_name = match.group(1)
        attributes = match.group(2)

        # Only format custom tags, skip standard HTML
        if tag_name.lower() in standard_tags:
            return match.group(0)

        # Put tag on its own line with newline after
        return f"\n<{tag_name}{attributes}>\n"

    def format_closing_tag(match):
        tag_name = match.group(1)

        # Only format custom tags
        if tag_name.lower() in standard_tags:
            return match.group(0)

        # Put closing tag on its own line with newline after
        return f"\n</{tag_name}>\n"

    # Apply formatting
    result = re.sub(opening_pattern, format_opening_tag, content)
    result = re.sub(closing_pattern, format_closing_tag, result)

    # Clean up excessive newlines (more than 2 in a row)
    result = re.sub(r"\n{3,}", "\n\n", result)

    return result


def refactor_tags_in_file(file_path: Path, dry_run: bool = False) -> Dict[str, Any]:
    """Refactor tags in a single markdown file.

    Args:
        file_path: Path to markdown file
        dry_run: If True, don't write changes, just report what would change

    Returns:
        Dict with keys:
            - success: bool
            - modified: bool (whether content changed)
            - error: Optional[str]
            - original_size: int
            - new_size: int

    """
    try:
        # Read file
        with open(file_path, "r", encoding="utf-8") as f:
            original_content = f.read()

        # Refactor
        refactored_content = refactor_tags_in_content(original_content)

        # Check if modified
        modified = refactored_content != original_content

        # Write back if not dry run and content changed
        if modified and not dry_run:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(refactored_content)

        return {
            "success": True,
            "modified": modified,
            "error": None,
            "original_size": len(original_content),
            "new_size": len(refactored_content),
        }

    except Exception as e:
        logger.error(f"Failed to refactor {file_path}: {e}")
        return {
            "success": False,
            "modified": False,
            "error": str(e),
            "original_size": 0,
            "new_size": 0,
        }


@register_workflow
class TagRefactorWorkflow(BaseWorkflow):
    """Workflow for refactoring semantic tags in markdown files.

    This workflow scans markdown files for custom semantic HTML tags
    (like <mithranm>, <claude>) and reformats them to be on separate
    lines for improved readability.

    Configuration parameters:
        - dry_run: bool - If True, report changes without modifying files
        - include_patterns: List[str] - Glob patterns for files to include
        - exclude_patterns: List[str] - Glob patterns for files to exclude
    """

    workflow_id = "tag_refactor"
    name = "Tag Refactoring"
    description = "Format semantic HTML tags in markdown files"
    version = "1.0"
    category = "formatting"
    tags = {"markdown", "formatting", "linting", "documentation"}

    def __init__(self):
        self.workflow_id = "tag_refactor"
        self.name = "Tag Refactoring"
        self.description = "Format semantic HTML tags in markdown files"
        self.version = "1.0"
        super().__init__()

    def get_required_inputs(self) -> Set[str]:
        """No required inputs - operates on filesystem."""
        return set()

    def get_produced_outputs(self) -> Set[str]:
        """Produces list of modified files."""
        return {"modified_files", "tag_refactor_stats"}

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=600,  # 10 minutes
            parameters={
                "root_dir": str(root_dir),
            },
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute tag refactoring on markdown files.

        Args:
            project_root: Root directory of the project
            context: Execution context with parameters

        Returns:
            WorkflowResult with findings and statistics

        """
        dry_run = self.config.parameters.get("dry_run", False)
        include_patterns = self.config.parameters.get("include_patterns", ["**/*.md"])
        exclude_patterns = self.config.parameters.get("exclude_patterns", [])

        # Find markdown files
        markdown_files = []
        for pattern in include_patterns:
            markdown_files.extend(project_root.glob(pattern))

        # Filter out exclusions
        excluded = set()
        for pattern in exclude_patterns:
            excluded.update(project_root.glob(pattern))

        markdown_files = [f for f in markdown_files if f not in excluded and f.is_file()]

        logger.info(f"Found {len(markdown_files)} markdown files to process")

        # Process each file
        modified_files = []
        stats = {
            "total_files": len(markdown_files),
            "modified_files": 0,
            "failed_files": 0,
            "total_size_before": 0,
            "total_size_after": 0,
        }

        findings = []

        for file_path in markdown_files:
            result = refactor_tags_in_file(file_path, dry_run=dry_run)

            stats["total_size_before"] += result["original_size"]
            stats["total_size_after"] += result["new_size"]

            if not result["success"]:
                stats["failed_files"] += 1
                findings.append(
                    {
                        "type": "error",
                        "file": str(file_path.relative_to(project_root)),
                        "message": result["error"],
                    }
                )
                continue

            if result["modified"]:
                stats["modified_files"] += 1
                modified_files.append(str(file_path.relative_to(project_root)))
                findings.append(
                    {
                        "type": "modified" if not dry_run else "would_modify",
                        "file": str(file_path.relative_to(project_root)),
                        "size_change": result["new_size"] - result["original_size"],
                    }
                )

            self.metrics.files_processed += 1

        # Update metrics
        self.metrics.findings_generated = len(findings)

        # Create result
        return self._create_result(
            status=WorkflowStatus.COMPLETED,
            findings=findings,
            artifacts={
                "modified_files": modified_files,
                "tag_refactor_stats": stats,
                "dry_run": dry_run,
            },
        )


def run_tag_refactor(
    project_root: Path,
    dry_run: bool = False,
    include_patterns: List[str] | None = None,
    exclude_patterns: List[str] | None = None,
) -> WorkflowResult:
    """Convenience function to run tag refactoring workflow.

    Args:
        project_root: Root directory to process
        dry_run: If True, report changes without modifying files
        include_patterns: Glob patterns for files to include (default: ["**/*.md"])
        exclude_patterns: Glob patterns for files to exclude

    Returns:
        WorkflowResult with findings and statistics

    Examples:
        >>> from pathlib import Path
        >>> result = run_tag_refactor(Path.cwd(), dry_run=True)
        >>> print(f"Would modify {result.artifacts['tag_refactor_stats']['modified_files']} files")

    """
    config = WorkflowConfig(
        parameters={
            "dry_run": dry_run,
            "include_patterns": include_patterns or ["**/*.md"],
            "exclude_patterns": exclude_patterns or [],
        }
    )

    workflow = TagRefactorWorkflow(config)
    return workflow.execute(project_root, {})
```

---
### File: src/maxwell/workflows/utilities.py

```python
"""Utility workflows for common Maxwell operations.

Simple utility workflows for timestamps, session IDs, and file operations.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.registry import register_workflow
from maxwell.utils import get_session_id, get_timestamp
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowConfig,
    WorkflowInputs,
    WorkflowOutputs,
    WorkflowPriority,
    WorkflowResult,
    WorkflowStatus,
)

# Workflow Schemas
# ----------------


@dataclass(frozen=True)
class GetTimeInputs(WorkflowInputs):
    """Input schema for timestamp workflow."""

    format: str = "iso"  # iso, iso_seconds, date, filename, unix


@dataclass(frozen=True)
class GetTimeOutputs(WorkflowOutputs):
    """Output schema for timestamp workflow."""

    timestamp: str
    format: str


@dataclass(frozen=True)
class GetSessionInputs(WorkflowInputs):
    """Input schema for session ID workflow."""

    path: Optional[str] = None


@dataclass(frozen=True)
class GetSessionOutputs(WorkflowOutputs):
    """Output schema for session ID workflow."""

    session_id: str


@dataclass(frozen=True)
class FindChatFilesInputs(WorkflowInputs):
    """Input schema for find chat files workflow."""

    directory: str = "."
    recursive: bool = True


@dataclass(frozen=True)
class FindChatFilesOutputs(WorkflowOutputs):
    """Output schema for find chat files workflow."""

    chat_files: List[str]
    count: int
    search_directory: str


@register_workflow
class GetTimeWorkflow(BaseWorkflow):
    """Get current timestamp in various formats."""

    workflow_id: str = "get-time"
    name: str = "Get Timestamp"
    description: str = "Get current timestamp in various formats (iso, date, filename, unix)"
    version: str = "1.0"
    category: str = "utility"
    tags: set = {"timestamp", "time", "utility"}

    # Typed schemas
    InputSchema = GetTimeInputs
    OutputSchema = GetTimeOutputs

    def __init__(self):
        self.workflow_id = "get-time"
        self.name = "Get Timestamp"
        self.description = "Get current timestamp in various formats (iso, date, filename, unix)"
        self.version = "1.0"
        super().__init__()

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "format",
                "type": str,
                "required": False,
                "default": "iso",
                "help": "Timestamp format: iso, iso_seconds, date, filename, unix",
            }
        ]

    def get_required_inputs(self) -> List[str]:
        return []

    def get_produced_outputs(self) -> List[str]:
        return ["timestamp"]

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.LOW,
            timeout_seconds=30,  # 30 seconds
            parameters={
                "root_dir": str(root_dir),
            },
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute timestamp generation with typed schemas."""
        try:
            inputs: GetTimeInputs = self.parse_inputs(context)  # type: ignore[assignment]
            timestamp = get_timestamp(inputs.format)

            outputs = GetTimeOutputs(timestamp=timestamp, format=inputs.format)
            return self.create_result(outputs)

        except Exception as e:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Failed to get timestamp: {str(e)}",
            )


@register_workflow
class GetSessionWorkflow(BaseWorkflow):
    """Get current session ID (absolute path)."""

    workflow_id: str = "get-session"
    name: str = "Get Session ID"
    description: str = "Get current session ID (absolute path of current directory)"
    version: str = "1.0"
    category: str = "utility"
    tags: set = {"session", "path", "utility"}

    # Typed schemas
    InputSchema = GetSessionInputs
    OutputSchema = GetSessionOutputs

    def __init__(self):
        self.workflow_id = "get-session"
        self.name = "Get Session ID"
        self.description = "Get current session ID (absolute path of current directory)"
        self.version = "1.0"
        super().__init__()

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "path",
                "type": str,
                "required": False,
                "help": "Path to get session ID for (default: current directory)",
            }
        ]

    def get_required_inputs(self) -> List[str]:
        return []

    def get_produced_outputs(self) -> List[str]:
        return ["session_id"]

    def get_config(self, root_dir: Path) -> WorkflowConfig:
        """Get workflow configuration."""
        return WorkflowConfig(
            enabled=True,
            priority=WorkflowPriority.LOW,
            timeout_seconds=30,  # 30 seconds
            parameters={
                "root_dir": str(root_dir),
            },
        )

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute session ID generation with typed schemas."""
        try:
            inputs: GetSessionInputs = self.parse_inputs(context)  # type: ignore[assignment]
            session_id = get_session_id(inputs.path)

            outputs = GetSessionOutputs(session_id=session_id)
            return self.create_result(outputs)

        except Exception as e:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Failed to get session ID: {str(e)}",
            )


class FindChatFilesWorkflow(BaseWorkflow):
    """Find Claude chat log files in a directory."""

    workflow_id: str = "find-chatfiles"
    name: str = "Find Chat Files"
    description: str = "Find Claude chat log files (.jsonl) in directory tree"
    version: str = "1.0"
    category: str = "utility"
    tags: set = {"chat", "files", "claude", "jsonl"}

    # Typed schemas
    InputSchema = FindChatFilesInputs
    OutputSchema = FindChatFilesOutputs

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "directory",
                "type": str,
                "required": False,
                "help": "Directory to search (default: current directory)",
            },
            {
                "name": "recursive",
                "type": bool,
                "required": False,
                "default": True,
                "help": "Search recursively in subdirectories",
            },
        ]

    def get_required_inputs(self) -> List[str]:
        return []

    def get_produced_outputs(self) -> List[str]:
        return ["chat_files"]

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute chat file search with typed schemas."""
        try:
            inputs: FindChatFilesInputs = self.parse_inputs(context)  # type: ignore[assignment]

            search_path = Path(inputs.directory)
            if not search_path.is_absolute():
                search_path = project_root / search_path

            if inputs.recursive:
                chat_files = list(search_path.rglob("*.jsonl"))
            else:
                chat_files = list(search_path.glob("*.jsonl"))

            # Filter for Claude-style chat files (those that look like they're from .claude/projects/)
            claude_chat_files = []
            for file_path in chat_files:
                # Check if file looks like a Claude chat file
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        first_line = f.readline().strip()
                        if first_line.startswith("{") and "role" in first_line.lower():
                            claude_chat_files.append(str(file_path))
                except Exception:
                    pass  # Skip files that can't be read

            # Update metrics
            self.metrics.files_processed = len(claude_chat_files)

            outputs = FindChatFilesOutputs(
                chat_files=claude_chat_files,
                count=len(claude_chat_files),
                search_directory=str(search_path),
            )
            return self.create_result(outputs)

        except Exception as e:
            self.metrics.errors_encountered = 1
            return self.create_result(
                outputs=None,
                status=WorkflowStatus.FAILED,
                error_message=f"Failed to find chat files: {str(e)}",
            )
```

---
### File: src/maxwell/workflows/validate/__init__.py

```python
"""Validation workflow - runs validators and reports findings.

Wraps the existing validation_engine into a proper workflow that integrates
with the Maxwell workflow system.
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from maxwell.config import load_config
from maxwell.registry import register_workflow
from maxwell.workflows.base import (
    BaseWorkflow,
    WorkflowInputs,
    WorkflowMetrics,
    WorkflowOutputs,
    WorkflowResult,
    WorkflowStatus,
)
from maxwell.workflows.validate.validation_engine import run_plugin_validation
from maxwell.workflows.validate.validators import Finding

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FindingModel:
    """Model for a validation finding."""

    rule_id: str
    message: str
    file_path: str
    severity: str
    line: int = 0
    column: int = 0
    context: str = ""
    suggestion: Optional[str] = None

    @classmethod
    def from_finding(cls, finding: Finding) -> "FindingModel":
        """Convert from validators.Finding to dataclass."""
        return cls(
            rule_id=finding.rule_id,
            message=finding.message,
            file_path=str(finding.file_path),
            line=finding.line,
            column=finding.column,
            severity=finding.severity.value,
            context=finding.context,
            suggestion=finding.suggestion,
        )


@dataclass(frozen=True)
class ValidationSummary:
    """Summary of validation results by severity."""

    info: int = 0
    warn: int = 0
    block: int = 0
    total: int = 0


@dataclass(frozen=True)
class ValidateInputs(WorkflowInputs):
    """Validate workflow inputs."""

    paths: Optional[str] = None
    format: str = "human"
    fix: bool = False


@dataclass(frozen=True)
class ValidateOutputs(WorkflowOutputs):
    """Validate workflow outputs."""

    findings: List[FindingModel] = field(default_factory=list)
    summary: ValidationSummary = field(default_factory=ValidationSummary)
    has_blocking_issues: bool = False
    formatted_output: str = ""
    fixes_applied: Optional[Dict[str, int]] = None


@register_workflow
class ValidateWorkflow(BaseWorkflow):
    """Validation workflow for running code quality checks."""

    workflow_id: str = "validate"
    name: str = "Code Validation"
    description: str = "Run validators to check code quality, consistency, and style"
    version: str = "1.0"
    category: str = "quality"
    tags: set = {"validation", "linting", "quality", "code-review"}

    InputSchema = ValidateInputs
    OutputSchema = ValidateOutputs

    def get_cli_parameters(self) -> List[Dict[str, Any]]:
        """Define CLI parameters for validation."""
        return [
            {
                "name": "paths",
                "type": str,
                "required": False,
                "help": "Specific file paths to validate (comma-separated). If not provided, uses include_globs from config.",
            },
            {
                "name": "format",
                "type": str,
                "required": False,
                "default": "human",
                "help": "Output format: human, json, sarif, github",
            },
            {
                "name": "fix",
                "type": bool,
                "required": False,
                "default": False,
                "help": "Automatically fix issues where validators support auto-fixing (like emoji removal)",
            },
        ]

    def _apply_autofixes(self, runner, project_root: Path) -> Dict[str, int]:
        """Apply auto-fixes to files with fixable findings.

        Args:
            runner: PluginValidationRunner with findings
            project_root: Project root directory

        Returns:
            Dictionary mapping file paths to number of fixes applied

        """
        from collections import defaultdict

        from maxwell.workflows.validate.validators.types import get_validator

        fixes_applied = defaultdict(int)

        # Group findings by file
        findings_by_file = defaultdict(list)
        for finding in runner.findings:
            findings_by_file[str(finding.file_path)].append(finding)

        # Process each file
        for file_path_str, findings in findings_by_file.items():
            file_path = Path(file_path_str)

            # Check if file exists and is writable
            if not file_path.exists() or not file_path.is_file():
                logger.warning(f"Skipping fixes for {file_path}: file not found")
                continue

            # Get fixable findings for this file
            fixable_findings = []
            for finding in findings:
                validator_class = get_validator(finding.rule_id)
                if validator_class:
                    validator = validator_class()  # Instantiate the validator
                    if hasattr(validator, "can_fix") and validator.can_fix(finding):  # type: ignore
                        fixable_findings.append((finding, validator))

            if not fixable_findings:
                continue

            # Sort by line number (descending) to avoid offset issues
            fixable_findings.sort(key=lambda x: x[0].line, reverse=True)

            # Read file content
            try:
                content = file_path.read_text()
            except Exception as e:
                logger.error(f"Failed to read {file_path}: {e}")
                continue

            # Apply fixes
            for finding, validator in fixable_findings:
                try:
                    content = validator.apply_fix(content, finding)
                    fixes_applied[file_path_str] += 1
                    logger.info(f"Applied fix for {finding.rule_id} at {file_path}:{finding.line}")
                except Exception as e:
                    logger.error(
                        f"Failed to apply fix for {finding.rule_id} at {file_path}:{finding.line}: {e}"
                    )

            # Write fixed content back
            if fixes_applied[file_path_str] > 0:
                try:
                    file_path.write_text(content)
                    logger.info(f"Wrote {fixes_applied[file_path_str]} fixes to {file_path}")
                except Exception as e:
                    logger.error(f"Failed to write fixes to {file_path}: {e}")
                    fixes_applied[file_path_str] = 0

        return dict(fixes_applied)

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        """Execute validation workflow."""
        try:
            # Parse inputs
            inputs: ValidateInputs = self.parse_inputs(context)

            # Load config
            config = load_config(project_root)

            # Get optional path override
            include_globs_override = None
            if inputs.paths:
                path_list = [Path(p.strip()) for p in inputs.paths.split(",")]
                include_globs_override = path_list

            # Run validation
            logger.info("Running validation...")
            runner = run_plugin_validation(
                config=config,
                project_root=project_root,
                include_globs_override=include_globs_override,
            )

            # Apply auto-fixes if requested
            fixes_applied = {}
            if inputs.fix:
                fixes_applied = self._apply_autofixes(runner, project_root)

            # Convert findings to dataclass models
            finding_models = [FindingModel.from_finding(f) for f in runner.findings]

            # Build summary
            raw_summary = runner.get_summary()
            summary = ValidationSummary(
                info=raw_summary.get("INFO", 0),
                warn=raw_summary.get("WARN", 0),
                block=raw_summary.get("BLOCK", 0),
                total=len(runner.findings),
            )

            # Format output
            formatted_output = runner.format_output(inputs.format)

            # Add fix summary to formatted output if fixes were applied
            if fixes_applied:
                fix_summary = f"\n\n[AUTO-FIX] Applied {sum(fixes_applied.values())} fixes across {len(fixes_applied)} files:\n"
                for file_path, count in sorted(fixes_applied.items()):
                    fix_summary += f"  - {file_path}: {count} fixes\n"
                formatted_output += fix_summary

            # Create typed outputs
            outputs = ValidateOutputs(
                findings=finding_models,
                summary=summary,
                has_blocking_issues=runner.has_blocking_issues(),
                formatted_output=formatted_output,
                fixes_applied=fixes_applied if fixes_applied else None,
            )

            # Determine status based on blocking issues
            status = (
                WorkflowStatus.FAILED if runner.has_blocking_issues() else WorkflowStatus.COMPLETED
            )

            return self.create_result(outputs=outputs, status=status)

        except Exception as e:
            logger.error(f"Validation workflow failed: {str(e)}")
            return self.create_result(
                status=WorkflowStatus.FAILED, error_message=f"Validation workflow failed: {str(e)}"
            )
```

---
### File: src/maxwell/workflows/validate/ast_utils.py

```python
"""AST parsing utilities for maxwell validators.

Provides common AST parsing functionality with consistent error handling,
reducing code duplication across validators.

maxwell/src/maxwell/ast_utils.py
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

__all__ = [
    "safe_parse",
    "parse_or_none",
]


def safe_parse(content: str, filename: str | Path = "<unknown>") -> ast.AST:
    """Parse Python source code into an AST.

    Args:
        content: Python source code as string
        filename: Optional filename for error messages

    Returns:
        Parsed AST

    Raises:
        SyntaxError: If the code has syntax errors

    """
    return ast.parse(content, filename=str(filename))


def parse_or_none(content: str, filename: str | Path = "<unknown>") -> Optional[ast.AST]:
    """Parse Python source code into an AST, returning None on syntax errors.

    This is the recommended function for validators to use - it handles
    syntax errors gracefully and logs them appropriately.

    Args:
        content: Python source code as string
        filename: Optional filename for error messages

    Returns:
        Parsed AST or None if parsing failed

    Example:
        >>> tree = parse_or_none(file_content, file_path)
        >>> if tree is None:
        >>>     return  # Skip validation for files with syntax errors

    """
    try:
        return ast.parse(content, filename=str(filename))
    except SyntaxError as e:
        logger.debug(f"Syntax error in {filename}: {e}")
        return None
    except Exception as e:
        logger.warning(f"Unexpected error parsing {filename}: {e}")
        return None


def get_docstring(node: ast.AST) -> Optional[str]:
    """Extract docstring from an AST node (module, function, or class).

    Args:
        node: AST node (Module, FunctionDef, ClassDef, or AsyncFunctionDef)

    Returns:
        Docstring text or None if no docstring found

    """
    if not isinstance(node, (ast.Module, ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
        return None

    body = node.body if hasattr(node, "body") else []
    if not body:
        return None

    first_stmt = body[0]
    if isinstance(first_stmt, ast.Expr) and isinstance(first_stmt.value, ast.Constant):
        value = first_stmt.value.value
        if isinstance(value, str):
            return value

    return None


def get_function_args(node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    """Get argument names from a function definition.

    Args:
        node: Function definition node

    Returns:
        List of argument names

    """
    args = []

    # Regular arguments
    for arg in node.args.args:
        args.append(arg.arg)

    # *args
    if node.args.vararg:
        args.append(f"*{node.args.vararg.arg}")

    # **kwargs
    if node.args.kwarg:
        args.append(f"**{node.args.kwarg.arg}")

    return args


def is_private_name(name: str) -> bool:
    """Check if a name is private (starts with underscore).

    Args:
        name: Name to check

    Returns:
        True if name is private (starts with _ but not __)

    """
    return name.startswith("_") and not name.startswith("__")


def is_dunder_name(name: str) -> bool:
    """Check if a name is a dunder/magic method (starts and ends with __).

    Args:
        name: Name to check

    Returns:
        True if name is a dunder method

    """
    return name.startswith("__") and name.endswith("__") and len(name) > 4
```

---
### File: src/maxwell/workflows/validate/validation_engine.py

```python
"""Plugin-aware validation runner for maxwell.

This module provides the PluginValidationRunner that uses the new plugin system
to run validators and format output according to user configuration.

maxwell/src/maxwell/plugin_runner.py
"""

import logging
from collections import defaultdict
from pathlib import Path
from typing import List

from maxwell.config import MaxwellConfig
from maxwell.discovery import discover_files, discover_files_from_paths
from maxwell.reporting import BUILTIN_FORMATTERS
from maxwell.rules import RuleEngine
from maxwell.workflows.validate.validators import Finding, Severity, plugin_manager

# Note: No longer importing BUILTIN_VALIDATORS - using plugin discovery instead

__all__ = ["PluginValidationRunner", "run_plugin_validation"]


class PluginValidationRunner:
    """Runs validation using the plugin system."""

    def __init__(self, config: MaxwellConfig, project_root: Path):
        """Initialize the plugin validation runner."""
        self.project_root = project_root
        self.config = config
        self.rule_engine = RuleEngine(config)
        self.findings: List[Finding] = []

        # Register built-in validators with plugin manager
        self._register_builtin_validators()

    def _register_builtin_validators(self):
        """Register built-in validators with the plugin manager via entry point discovery."""
        # Built-in validators are now discovered automatically via entry points
        plugin_manager.load_plugins()

    def run_validation(self, file_paths: List[Path]) -> List[Finding]:
        """Run validation on the specified files."""
        self.findings = []

        # Get enabled validators
        validators = self.rule_engine.get_enabled_validators()

        for file_path in file_paths:
            if not file_path.exists() or not file_path.is_file():
                continue

            if file_path.suffix != ".py":
                continue

            try:
                content = file_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError) as e:
                logging.getLogger(__name__).debug(f"Could not read file {file_path}: {e}")
                continue

            # Run all validators on this file
            for validator in validators:
                try:
                    for finding in validator.validate(file_path, content, self.config):
                        # Make path relative to project root
                        relative_path = file_path.relative_to(self.project_root)
                        finding.file_path = relative_path
                        self.findings.append(finding)
                except (ImportError, AttributeError, ValueError, SyntaxError) as e:
                    logging.getLogger(__name__).debug(
                        f"Validator {validator.__class__.__name__} failed on {file_path}: {e}"
                    )
                    continue

        return self.findings

    def get_summary(self) -> dict[str, int]:
        """Get summary counts by severity level."""
        summary = defaultdict(int)
        for finding in self.findings:
            summary[finding.severity.value] += 1
        return dict(summary)

    def format_output(self, output_format: str = "human") -> str:
        """Format the validation results."""
        # Get formatter
        if output_format in BUILTIN_FORMATTERS:
            formatter_class = BUILTIN_FORMATTERS[output_format]
            formatter = formatter_class()
        else:
            # Try plugin formatters
            formatter_class = plugin_manager.get_formatter(output_format)
            if formatter_class:
                formatter = formatter_class()
            else:
                # Fallback to human format
                formatter = BUILTIN_FORMATTERS["human"]()

        summary = self.get_summary()
        return formatter.format_results(self.findings, summary, self.config)

    def has_blocking_issues(self) -> bool:
        """Check if any findings are blocking (BLOCK severity)."""
        return any(finding.severity == Severity.BLOCK for finding in self.findings)

    def get_exit_code(self) -> int:
        """Get appropriate exit code based on findings."""
        if self.has_blocking_issues():
            return 1
        return 0


def run_plugin_validation(
    config: MaxwellConfig,
    project_root: Path,
    include_globs_override: List[Path] | None = None,
) -> PluginValidationRunner:
    """Run validation using the plugin system.

    Args:
        config: Configuration object from pyproject.toml
        project_root: Project root path
        include_globs_override: Optional list of paths to override include_globs.
                               If provided, only these paths are analyzed instead of
                               using the configured include_globs patterns.

    Returns:
        PluginValidationRunner with results

    """
    runner = PluginValidationRunner(config, project_root)

    # Choose discovery method based on whether include_globs are overridden
    if include_globs_override:
        # Use custom path discovery (include_globs override)
        files = discover_files_from_paths(
            custom_paths=include_globs_override, config=config, explicit_exclude_paths=set()
        )
    else:
        # Use original discovery method with configured include_globs
        files = discover_files(paths=[project_root], config=config, explicit_exclude_paths=set())

    # Run validation
    runner.run_validation(files)

    return runner
```

---
### File: src/maxwell/workflows/validate/validators/__init__.py

```python
"""maxwell validators sub-package.

Modular validator system with centralized registry and discovery.

Responsibility: Validator module organization and re-exports only.
Individual validation logic belongs in specific validator modules.

maxwell/src/maxwell/validators/__init__.py
"""

# Import validator categories for direct access (LAST to avoid circular imports)
from . import project_wide, single_file

# Import core types FIRST (before subdirectories to avoid circular imports)
from .types import (
    BaseFormatter,
    BaseValidator,
    Finding,
    Formatter,
    Severity,
    Validator,
    get_all_formatters,
    get_all_validators,
    get_formatter,
    get_validator,
    plugin_manager,
    register_validator,
)

# Note: Individual validators should be imported from their specific modules
# to prevent duplicate import paths and keep the module hierarchy clear.

__all__ = [
    # Core types
    "Severity",
    "Finding",
    "BaseValidator",
    "BaseFormatter",
    "Validator",
    "Formatter",
    "get_formatter",
    "get_all_formatters",
    "plugin_manager",
    # Registry system
    "register_validator",
    "get_validator",
    "get_all_validators",
    # Category modules
    "single_file",
    "project_wide",
]
```

---
### File: src/maxwell/workflows/validate/validators/project_wide/__init__.py

```python
"""Project-wide validators for maxwell.

These validators analyze entire projects and require knowledge
of multiple files to identify issues like:
- Dead code across modules
- API consistency violations
- Architecture pattern violations
- Semantic similarity between modules

maxwell/src/maxwell/validators/project_wide/__init__.py
"""

from pathlib import Path
from typing import Dict, Iterator, List

from maxwell.workflows.validate.validators.types import BaseValidator, Finding


class ProjectWideValidator(BaseValidator):
    """Base class for validators that analyze entire projects."""

    def validate_project(self, project_files: Dict[Path, str], config=None) -> Iterator[Finding]:
        """Validate entire project with knowledge of all files.

        Args:
            project_files: Dictionary mapping file paths to their content
            config: Configuration object

        Yields:
            Finding objects for any issues found

        """
        # Default implementation - subclasses should override
        raise NotImplementedError("Project-wide validators must implement validate_project")

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Single-file validate method for project-wide validators.

        Project-wide validators should not be called on individual files.
        This method raises an error to prevent misuse.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} is a project-wide validator. "
            "Use validate_project() instead of validate()."
        )

    def requires_project_context(self) -> bool:
        """Project-wide validators require full project context."""
        return True


def get_project_wide_validators() -> List[str]:
    """Get list of project-wide validator names."""
    return [
        "DEAD-CODE-FOUND",
        "ARCHITECTURE-INCONSISTENT",
        "ARCHITECTURE-LLM",
        "SEMANTIC-SIMILARITY",
        "FALLBACK-SILENT-FAILURE",
        "API-CONSISTENCY",
        "CODE-SMELLS",
        "MODULE-COHESION",
    ]
```

---
### File: src/maxwell/workflows/validate/validators/single_file/__init__.py

```python
"""Single-file validators for maxwell.

These validators analyze individual Python files in isolation.
They should not require knowledge of other files in the project.

maxwell/src/maxwell/validators/single_file/__init__.py
"""

from pathlib import Path
from typing import Iterator, List

from maxwell.workflows.validate.validators.types import BaseValidator, Finding


class SingleFileValidator(BaseValidator):
    """Base class for validators that analyze individual files."""

    def validate_file(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Validate a single file in isolation.

        Args:
            file_path: Path to the file being validated
            content: File content as string
            config: Configuration object

        Yields:
            Finding objects for any issues found

        """
        # Default implementation delegates to validate method
        yield from self.validate(file_path, content, config)

    def requires_project_context(self) -> bool:
        """Single-file validators do not require project context."""
        return False


def get_single_file_validators() -> List[str]:
    """Get list of single-file validator names."""
    return [
        "DOCSTRING-MISSING",
        "DOCSTRING-PATH-REFERENCE",
        "PRINT-STATEMENT",
        "EMOJI-IN-STRING",
        "TYPING-POOR-PRACTICE",
        "EXPORTS-MISSING-ALL",
        "EXPORTS-MISSING-ALL-INIT",
    ]
```

---
### File: src/maxwell/workflows/validate/validators/single_file/dict_get_fallback.py

```python
"""Validator for detecting .get() with fallback values on typed dictionaries.

In strictly-typed code, .get() with defaults hides missing keys. This is appropriate
for ETL/JSON parsing, but not for internal typed structures which should fail fast.
"""

import ast
import logging
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.validators import BaseValidator, Finding, Severity
from maxwell.workflows.validate.validators.types import Optional

logger = logging.getLogger(__name__)


class DictGetFallbackValidator(BaseValidator):
    """Detects .get() with fallback on typed dictionaries that should use direct access."""

    rule_id = "DICT-GET-FALLBACK"
    description = "Detect .get() with fallback that should use direct key access"

    def __init__(self, config=None, severity=None):
        super().__init__(config)
        self.config = config or {}
        self.severity = severity or Severity.WARN

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Validate Python file for .get() antipatterns.

        Args:
            file_path: Path to the Python file
            content: File content as string
            config: Optional configuration

        Yields:
            Finding objects for .get() antipatterns found

        """
        try:
            tree = ast.parse(content, filename=str(file_path))
        except SyntaxError as e:
            logger.debug(f"Syntax error in {file_path}: {e}")
            return

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if self._is_dict_get_with_fallback(node):
                    yield from self._check_get_pattern(node, file_path)

    def _is_dict_get_with_fallback(self, node: ast.Call) -> bool:
        """Check if this is a .get() call with a fallback value."""
        # Must be a method call
        if not isinstance(node.func, ast.Attribute):
            return False

        # Method name must be 'get'
        if node.func.attr != "get":
            return False

        # Must have 2 arguments (key, default) or 1 with keywords
        if len(node.args) == 2:
            return True
        if len(node.args) == 1 and any(kw.arg == "default" for kw in node.keywords):
            return True

        return False

    def _check_get_pattern(self, node: ast.Call, file_path: Path) -> Iterator[Finding]:
        """Check if this .get() call is an antipattern."""
        # Get the key being accessed
        key = self._extract_key(node)
        fallback = self._extract_fallback(node)

        message = (
            "Using .get() with fallback hides missing keys - use direct access for typed structures"
        )

        if key:
            message = f"dict.get('{key}', {fallback}) hides missing keys - use direct access dict['{key}'] for typed structures"

        suggestion = self._suggest_direct_access(key, fallback)

        yield Finding(
            rule_id=self.rule_id,
            message=message,
            file_path=file_path,
            line=node.lineno,
            column=node.col_offset,
            severity=self.severity,
            suggestion=suggestion,
        )

    def _extract_key(self, node: ast.Call) -> Optional[str]:
        """Extract the key from .get() call."""
        if not node.args:
            return None

        key_node = node.args[0]
        if isinstance(key_node, ast.Constant):
            return str(key_node.value)
        return None

    def _extract_fallback(self, node: ast.Call) -> str:
        """Extract the fallback value as a string."""
        # Check args
        if len(node.args) >= 2:
            fallback = node.args[1]
            return ast.unparse(fallback) if hasattr(ast, "unparse") else "..."

        # Check keywords
        for kw in node.keywords:
            if kw.arg == "default":
                return ast.unparse(kw.value) if hasattr(ast, "unparse") else "..."

        return "None"

    def _suggest_direct_access(self, key: Optional[str], fallback: str) -> str:
        """Suggest direct access replacement."""
        if not key:
            return "Consider: Use direct key access if dictionary is typed/validated"

        suggestion = f"""Consider replacing with direct access:

# If the key is required (fail fast):
value = data["{key}"]

# If the key is truly optional, use explicit check:
value = data.get("{key}")  # Returns None if missing
if "{key}" not in data:
    value = {fallback}

# Best: Use typed structures (dataclass/NamedTuple) instead of dict"""

        return suggestion

    def can_fix(self, finding: Finding) -> bool:
        """Returns True if this validator can automatically fix issues."""
        return False  # Requires context to determine if key is required
```

---
### File: src/maxwell/workflows/validate/validators/single_file/emoji.py

```python
"""Emoji usage validator using BaseValidator plugin system.

Detects emoji usage that can cause encoding issues, reduce readability,
and create compatibility problems across different terminals and systems.

maxwell/src/maxwell/validators/emoji.py
"""

import re
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.validators.types import BaseValidator, Finding, Severity

__all__ = ["EmojiUsageValidator"]


class EmojiUsageValidator(BaseValidator):
    """Detects emoji usage that can cause encoding issues."""

    rule_id = "EMOJI-IN-STRING"
    name = "Emoji Usage Detector"
    description = "Detects emojis that can cause MCP and Windows shell issues"
    default_severity = Severity.WARN

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Check for emoji usage in code."""
        # Comprehensive emoji regex pattern - matches ALL possible emojis
        emoji_pattern = re.compile(
            r"[\U0001F600-\U0001F64F"  # Emoticons
            r"\U0001F300-\U0001F5FF"  # Misc Symbols and Pictographs
            r"\U0001F680-\U0001F6FF"  # Transport and Map Symbols
            r"\U0001F1E0-\U0001F1FF"  # Regional Indicator Symbols
            r"\U0001F700-\U0001F77F"  # Alchemical Symbols
            r"\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
            r"\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
            r"\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
            r"\U0001FA00-\U0001FA6F"  # Chess Symbols
            r"\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
            r"\U00002600-\U000026FF"  # Miscellaneous Symbols
            r"\U00002700-\U000027BF"  # Dingbats
            r"\U0000FE00-\U0000FE0F"  # Variation Selectors
            r"\U0001F018-\U0001F270"  # Various Asian characters
            r"\U0000238C-\U00002454"  # Misc technical (fixed with leading zeros)
            r"\U000020D0-\U000020FF"  # Combining Diacritical Marks for Symbols (fixed)
            r"]+"
        )

        lines = content.splitlines()
        for line_num, line in enumerate(lines, 1):
            emoji_matches = emoji_pattern.findall(line)
            if emoji_matches:
                emojis_found = "".join(emoji_matches)

                # Check if emoji is in code vs strings/comments
                if self._is_emoji_in_code_context(line):
                    # More severe for emojis in actual code
                    yield self.create_finding(
                        message=f"Emoji in code: {emojis_found}",
                        file_path=file_path,
                        line=line_num,
                        suggestion="Replace emoji in code with ASCII alternatives immediately",
                    )
                else:
                    # Less severe for emojis in strings/comments
                    yield self.create_finding(
                        message=f"Emoji usage detected: {emojis_found}",
                        file_path=file_path,
                        line=line_num,
                        suggestion="Replace emojis with text descriptions to avoid encoding issues in MCP and Windows shells",
                    )

    def can_fix(self, finding: "Finding") -> bool:
        """Check if this finding can be automatically fixed."""
        return finding.rule_id == self.rule_id

    def apply_fix(self, content: str, finding: "Finding") -> str:
        """Automatically remove emojis from content."""
        lines = content.splitlines(True)  # Keep line endings
        if finding.line <= len(lines):
            line = lines[finding.line - 1]

            # Comprehensive emoji pattern for removal
            emoji_pattern = re.compile(
                r"[\U0001F600-\U0001F64F"  # Emoticons
                r"\U0001F300-\U0001F5FF"  # Misc Symbols and Pictographs
                r"\U0001F680-\U0001F6FF"  # Transport and Map Symbols
                r"\U0001F1E0-\U0001F1FF"  # Regional Indicator Symbols
                r"\U0001F700-\U0001F77F"  # Alchemical Symbols
                r"\U0001F780-\U0001F7FF"  # Geometric Shapes Extended
                r"\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
                r"\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
                r"\U0001FA00-\U0001FA6F"  # Chess Symbols
                r"\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
                r"\U00002600-\U000026FF"  # Miscellaneous Symbols
                r"\U00002700-\U000027BF"  # Dingbats
                r"\U0000FE00-\U0000FE0F"  # Variation Selectors
                r"\U0001F018-\U0001F270"  # Various Asian characters
                r"\U0000238C-\U00002454"  # Misc technical (fixed with leading zeros)
                r"\U000020D0-\U000020FF"  # Combining Diacritical Marks for Symbols (fixed)
                r"]+"
            )

            # Replace emojis with a single space to preserve structure
            fixed_line = emoji_pattern.sub(" ", line)

            # Clean up any double spaces that might result, but preserve indentation and newlines
            # Extract leading whitespace (indentation)
            leading_whitespace = ""
            content_start = 0
            for char in fixed_line:
                if char in [" ", "\t"]:
                    leading_whitespace += char
                    content_start += 1
                else:
                    break

            # Split into content and line ending
            if fixed_line.endswith("\n"):
                content = fixed_line[content_start:-1]  # Remove leading whitespace and newline
                line_ending = "\n"
            elif fixed_line.endswith("\r\n"):
                content = fixed_line[content_start:-2]  # Remove leading whitespace and CRLF
                line_ending = "\r\n"
            else:
                content = fixed_line[content_start:]  # Remove leading whitespace
                line_ending = ""

            # Clean up only multiple consecutive spaces in content
            content = re.sub(r" {2,}", " ", content)  # Multiple spaces to single space
            content = content.rstrip()  # Remove trailing spaces only

            # Reconstruct the line with original indentation
            fixed_line = leading_whitespace + content + line_ending

            lines[finding.line - 1] = fixed_line

        return "".join(lines)

    def _is_emoji_in_code_context(self, line: str) -> bool:
        """Check if emoji appears to be in code rather than in strings or comments.

        This is a heuristic - emojis in strings/comments are less problematic
        than emojis used as identifiers or in code structure.
        """
        # Remove string literals and comments to see if emoji remains
        line_without_strings = re.sub(r'["\'].*?["\']', "", line)
        line_without_comments = re.sub(r"#.*$", "", line_without_strings)

        # If emoji still exists after removing strings/comments, it's likely in code
        emoji_pattern = re.compile(
            r"[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF\U00002600-\U000026FF\U00002700-\U000027BF]"
        )
        return bool(emoji_pattern.search(line_without_comments))
```

---
### File: src/maxwell/workflows/validate/validators/single_file/exports.py

```python
"""__all__ exports validator using BaseValidator plugin system.

Checks for presence and correct format of __all__ definitions in Python modules.

maxwell/src/maxwell/validators/exports.py
"""

import ast
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.validators.types import BaseValidator, Finding, Severity

__all__ = ["MissingAllValidator"]


class MissingAllValidator(BaseValidator):
    """Validator for missing __all__ definitions."""

    rule_id = "EXPORTS-MISSING-ALL"
    name = "Missing __all__ Checker"
    description = "Checks for missing __all__ definitions in modules"
    default_severity = Severity.INFO

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Check for missing __all__ definition."""
        # Skip if it's __init__.py or private module
        if file_path.name.startswith("_"):
            return

        try:
            tree = ast.parse(content)
        except SyntaxError:
            yield self.create_finding(
                message="SyntaxError parsing file during __all__ validation",
                file_path=file_path,
                line=1,
                suggestion="Fix Python syntax errors in the file",
            )
            return

        # Look for __all__ definition
        has_all = False
        has_exports = False

        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__":
                        has_all = True
                        # Check if __all__ is properly formatted
                        if not self._is_valid_all_format(node.value):
                            yield self.create_finding(
                                message="__all__ is not assigned a list or tuple value",
                                file_path=file_path,
                                line=node.lineno,
                                suggestion='Ensure __all__ = ["item1", "item2"] or __all__ = ("item1", "item2")',
                            )
                        break
            elif isinstance(node, (ast.FunctionDef, ast.ClassDef)) and not node.name.startswith(
                "_"
            ):
                has_exports = True

        if has_exports and not has_all:
            yield self.create_finding(
                message="Module has public functions/classes but no __all__ definition",
                file_path=file_path,
                line=1,
                suggestion="Add __all__ = [...] to explicitly define public API",
            )

    def _is_valid_all_format(self, node: ast.AST) -> bool:
        """Check if __all__ assignment value is a valid list or tuple."""
        if isinstance(node, (ast.List, ast.Tuple)):
            # Check that all elements are strings
            return all(
                isinstance(elt, ast.Constant) and isinstance(elt.value, str) for elt in node.elts
            )
        return False


class InitAllValidator(BaseValidator):
    """Validator for missing __all__ in __init__.py files."""

    rule_id = "EXPORTS-MISSING-ALL-INIT"
    name = "Missing __all__ in __init__.py"
    description = "__init__.py file is missing __all__ definition (optional based on config)"
    default_severity = Severity.INFO

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Check for missing __all__ in __init__.py files."""
        # Only check __init__.py files
        if file_path.name != "__init__.py":
            return

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return

        # Look for __all__ definition
        has_all = False
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__":
                        has_all = True
                        break

        if not has_all:
            yield self.create_finding(
                message="__init__.py file is missing __all__ definition",
                file_path=file_path,
                line=1,
                suggestion="Add __all__ = [...] to control package imports",
            )
```

---
### File: src/maxwell/workflows/validate/validators/single_file/logger_names.py

```python
"""Logger name validator using BaseValidator plugin system.

Detects hardcoded logger names that should use __name__ instead
for proper module hierarchy and maintainability.

maxwell/src/maxwell/validators/logger_names.py
"""

import ast
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.validators.types import BaseValidator, Finding, Severity

__all__ = ["LoggerNameValidator"]


class LoggerNameValidator(BaseValidator):
    """Validator for detecting hardcoded logger names."""

    rule_id = "LOGGER-NAME"
    name = "Logger Name Checker"
    description = "Detects get_logger() calls with hardcoded strings instead of __name__"
    default_severity = Severity.BLOCK

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Validate a single file for hardcoded logger names."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return

        class LoggerNameVisitor(ast.NodeVisitor):
            """Visitor class that traverses an AST to collect all logger names used in the code."""

            def __init__(self, validator):
                """Initialize logger name visitor."""
                self.validator = validator
                self.logger_names = []
                self.findings = []

            def visit_Call(self, node: ast.Call):
                # Check for get_logger() calls
                if (
                    isinstance(node.func, ast.Name)
                    and node.func.id == "get_logger"
                    and len(node.args) == 1
                ):

                    arg = node.args[0]

                    # If argument is a string literal (not __name__)
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        self.findings.append(
                            Finding(
                                rule_id=self.validator.rule_id,
                                severity=self.validator.severity,
                                message=f"Use __name__ instead of hardcoded string '{arg.value}' for logger name",
                                file_path=file_path,
                                line=node.lineno,
                                suggestion="get_logger(__name__)",
                            )
                        )

                # Also check for attribute access like logging.getLogger()
                elif (
                    isinstance(node.func, ast.Attribute)
                    and node.func.attr in ["getLogger", "get_logger"]
                    and len(node.args) == 1
                ):

                    arg = node.args[0]

                    # If argument is a string literal (not __name__)
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        # Skip if this is in logging infrastructure getting specific loggers
                        if "logging.py" in str(file_path) and "kaia." in arg.value:
                            pass  # This is logging infrastructure, skip
                        else:
                            self.findings.append(
                                Finding(
                                    rule_id=self.validator.rule_id,
                                    severity=Severity.WARN,  # Less severe for standard logging
                                    message=f"Consider using __name__ instead of hardcoded string '{arg.value}' for logger name",
                                    file_path=file_path,
                                    line=node.lineno,
                                    suggestion="Use __name__ for consistent logger hierarchy",
                                )
                            )

                self.generic_visit(node)

        visitor = LoggerNameVisitor(self)
        visitor.visit(tree)
        yield from visitor.findings
```

---
### File: src/maxwell/workflows/validate/validators/single_file/typing_quality.py

```python
"""Type quality validator using BaseValidator plugin system.

Detects poor typing practices that reduce code clarity and type safety:
- Raw tuples instead of dataclasses/NamedTuples
- Untyped dictionaries instead of dataclasses
- Excessive use of Any
- Missing type annotations on public functions
- String literals that should be Enums

maxwell/src/maxwell/validators/typing_quality.py
"""

import ast
from pathlib import Path
from typing import Iterator

from maxwell.workflows.validate.ast_utils import parse_or_none
from maxwell.workflows.validate.validators.types import BaseValidator, Finding, Severity

__all__ = ["TypingQualityValidator"]


class TypingQualityValidator(BaseValidator):
    """Validator for detecting poor typing practices."""

    rule_id = "TYPING-POOR-PRACTICE"
    name = "Type Quality Checker"
    description = "Detects poor typing practices that reduce code clarity and type safety"
    default_severity = Severity.WARN

    def validate(self, file_path: Path, content: str, config=None) -> Iterator[Finding]:
        """Validate typing practices in a Python file."""
        tree = parse_or_none(content, file_path)
        if tree is None:
            return

        # Check for tuple type annotations that should be dataclasses
        visitor = _TypingVisitor()
        visitor.visit(tree)

        # Check for dictionary anti-patterns (should be dataclasses)
        yield from self._check_dict_antipatterns(tree, file_path)

        # Report tuple type aliases
        for line_num, name, tuple_info in visitor.tuple_type_aliases:
            if self._looks_like_data_structure(name, tuple_info):
                yield self.create_finding(
                    message=f"Type alias '{name}' uses raw Tuple{tuple_info} - consider using a dataclass or NamedTuple for better clarity",
                    file_path=file_path,
                    line=line_num,
                    suggestion="Replace with: @dataclass class {name}: ...",
                )

        # Report untyped dictionaries
        for line_num, context in visitor.untyped_dicts:
            yield self.create_finding(
                message=f"Using untyped Dict{context} - consider using dataclass for better type safety",
                file_path=file_path,
                line=line_num,
                suggestion="Define a dataclass with explicit field types",
            )

        # Report excessive Any usage
        for line_num, context in visitor.any_usage:
            if not self._is_acceptable_any_usage(context):
                yield self.create_finding(
                    message=f"Using Any type{context} - specify a more precise type",
                    file_path=file_path,
                    line=line_num,
                    suggestion="Replace Any with a specific type or Union of types",
                )

        # Report missing type annotations on public functions
        for line_num, func_name in visitor.untyped_public_functions:
            yield self.create_finding(
                message=f"Public function '{func_name}' is missing type annotations",
                file_path=file_path,
                line=line_num,
                suggestion=f"Add type hints: def {func_name}(...) -> ReturnType:",
            )

        # Report string literals that look like enums
        enum_candidates = self._find_enum_candidates(visitor.string_constants)
        for pattern, locations in enum_candidates.items():
            if len(locations) >= 3:  # Same string pattern used 3+ times
                first_line = locations[0]
                yield self.create_finding(
                    message=f"String literal '{pattern}' used {len(locations)} times - consider using an Enum",
                    file_path=file_path,
                    line=first_line,
                    suggestion="Create an Enum for these related string constants",
                )

    def _looks_like_data_structure(self, name: str, tuple_info: str) -> bool:
        """Check if a tuple type alias looks like it should be a data structure."""
        # Skip if it's a simple pair like (bool, str) for return values
        if tuple_info.count(",") == 1 and "bool" in tuple_info.lower():
            return False

        # If the name suggests it's data (Issue, Result, Info, etc.)
        data_suffixes = ["Issue", "Result", "Info", "Data", "Record", "Entry", "Item"]
        return any(name.endswith(suffix) for suffix in data_suffixes)

    def _is_acceptable_any_usage(self, context: str) -> bool:
        """Check if Any usage is acceptable in this context."""
        # Any is acceptable for **kwargs, *args, or when interfacing with external libs
        acceptable_patterns = ["**kwargs", "*args", "json", "yaml", "config"]
        return any(pattern in context.lower() for pattern in acceptable_patterns)

    def _find_enum_candidates(self, string_constants: list) -> dict:
        """Find string literals that are used repeatedly and could be enums."""
        from collections import defaultdict

        # Group by string pattern (uppercase, prefix, etc.)
        patterns = defaultdict(list)

        for line_num, value in string_constants:
            # Skip short strings and file paths
            if len(value) < 3 or "/" in value or "\\" in value:
                continue

            # Look for patterns like "ERROR", "WARNING", "INFO"
            if value.isupper() and "_" in value:
                patterns[value].append(line_num)
            # Or prefixed patterns like "RULE101", "ERR102"
            elif any(value.startswith(prefix) for prefix in ["RULE", "ERR", "WARN"]):
                prefix = value[:3]
                patterns[f"{prefix}*"].append(line_num)

        return patterns

    def _check_dict_antipatterns(self, tree: ast.AST, file_path: Path) -> Iterator[Finding]:
        """Check for dictionaries that should be dataclasses (merged from dict_antipattern.py)."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                # Analyze dictionary literal
                if not node.keys or len(node.keys) < 2:
                    continue

                # Extract string keys
                string_keys = []
                for key in node.keys:
                    if key is None:  # **kwargs expansion
                        break
                    if isinstance(key, ast.Constant) and isinstance(key.value, str):
                        string_keys.append(key.value)
                    else:
                        break  # Non-string keys, not a candidate

                if len(string_keys) >= 3:
                    yield self.create_finding(
                        message=f"Dictionary with {len(string_keys)} fixed keys should use dataclass/NamedTuple",
                        file_path=file_path,
                        line=node.lineno,
                        suggestion=self._suggest_dataclass_for_dict(string_keys),
                    )
                elif len(string_keys) == 2 and self._dict_keys_look_structured(string_keys):
                    yield self.create_finding(
                        message=f"Dictionary with structured keys '{', '.join(string_keys)}' might benefit from dataclass",
                        file_path=file_path,
                        line=node.lineno,
                        suggestion=self._suggest_dataclass_for_dict(string_keys),
                    )

            elif (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "dict"
            ):
                # Analyze dict() constructor call
                keys = [kw.arg for kw in node.keywords if kw.arg]
                if len(keys) >= 3:
                    yield self.create_finding(
                        message=f"dict() call with {len(keys)} fixed keys should use dataclass/NamedTuple",
                        file_path=file_path,
                        line=node.lineno,
                        suggestion=self._suggest_dataclass_for_dict(keys),
                    )

    def _dict_keys_look_structured(self, keys: list) -> bool:
        """Check if dict keys look like structured data rather than dynamic mapping."""
        structured_indicators = 0
        for key in keys:
            if len(key) > 3:  # Not single letters
                structured_indicators += 1
            if "_" in key:  # Snake case
                structured_indicators += 1
            if key in [
                "id",
                "name",
                "type",
                "value",
                "data",
                "config",
                "status",
                "created",
                "updated",
                "url",
                "path",
                "file",
                "directory",
            ]:
                structured_indicators += 1
        return structured_indicators >= len(keys)

    def _suggest_dataclass_for_dict(self, keys: list) -> str:
        """Generate a dataclass suggestion for dictionary keys."""
        fields = []
        for key in keys:
            if key in ["id", "count", "size", "length"]:
                fields.append(f"{key}: int")
            elif key in ["name", "path", "url", "type", "status"]:
                fields.append(f"{key}: str")
            elif key in ["active", "enabled", "valid", "success"]:
                fields.append(f"{key}: bool")
            else:
                fields.append(f"{key}: Any  # TODO: specify type")

        return "Consider dataclass:\n@dataclass\nclass Data:\n    " + "\n    ".join(fields)


class _TypingVisitor(ast.NodeVisitor):
    """AST visitor to detect typing issues."""

    def __init__(self):
        self.tuple_type_aliases = []  # (line, name, tuple_info)
        self.untyped_dicts = []  # (line, context)
        self.any_usage = []  # (line, context)
        self.untyped_public_functions = []  # (line, func_name)
        self.string_constants = []  # (line, value)

    def visit_AnnAssign(self, node):
        """Visit annotated assignments to find type aliases."""
        if isinstance(node.target, ast.Name):
            name = node.target.id

            # Check for Tuple type annotations
            if self._is_tuple_annotation(node.annotation):
                tuple_info = (
                    ast.unparse(node.annotation)
                    if hasattr(ast, "unparse")
                    else str(node.annotation)
                )
                self.tuple_type_aliases.append((node.lineno, name, tuple_info))

        self.generic_visit(node)

    def visit_Assign(self, node):
        """Visit assignments to find type aliases using old syntax."""
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id.endswith(("Issue", "Result", "Info")):
                # Check if it's a type alias assignment like: ValidationIssue = Tuple[str, str]
                if self._is_tuple_annotation(node.value):
                    tuple_info = (
                        ast.unparse(node.value) if hasattr(ast, "unparse") else str(node.value)
                    )
                    self.tuple_type_aliases.append((node.lineno, target.id, tuple_info))

        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        """Visit function definitions to check for type annotations."""
        # Check if public function (doesn't start with _)
        if not node.name.startswith("_"):
            # Check if it has return type annotation
            if node.returns is None:
                self.untyped_public_functions.append((node.lineno, node.name))
            else:
                # Check for Any in return type
                if self._contains_any(node.returns):
                    context = f" in return type of {node.name}"
                    self.any_usage.append((node.lineno, context))

            # Check parameters
            for arg in node.args.args:
                if arg.annotation is None and arg.arg != "self":
                    self.untyped_public_functions.append((node.lineno, f"{node.name}({arg.arg})"))
                elif arg.annotation and self._contains_any(arg.annotation):
                    context = f" in parameter '{arg.arg}' of {node.name}"
                    self.any_usage.append((node.lineno, context))

        self.generic_visit(node)

    def visit_Constant(self, node):
        """Visit string constants to find potential enums."""
        if isinstance(node.value, str):
            self.string_constants.append((node.lineno, node.value))
        self.generic_visit(node)

    def _is_tuple_annotation(self, node) -> bool:
        """Check if a node is a Tuple type annotation."""
        if isinstance(node, ast.Subscript):
            if isinstance(node.value, ast.Name) and node.value.id == "Tuple":
                return True
            # Check for typing.Tuple
            if isinstance(node.value, ast.Attribute):
                if node.value.attr == "Tuple":
                    return True
        return False

    def _contains_any(self, node) -> bool:
        """Check if a type annotation contains Any."""
        if isinstance(node, ast.Name) and node.id == "Any":
            return True
        if isinstance(node, ast.Attribute) and node.attr == "Any":
            return True
        # Recursively check in subscripts (like Optional[Any], List[Any])
        if isinstance(node, ast.Subscript):
            return self._contains_any(node.value) or any(
                self._contains_any(arg)
                for arg in (node.slice.elts if isinstance(node.slice, ast.Tuple) else [node.slice])
            )
        return False
```

---
### File: src/maxwell/workflows/validate/validators/types.py

```python
"""Core validation types for maxwell.

Defines fundamental types used throughout the validation system:
- Severity: Severity levels for findings (INFO, WARN, BLOCK)
- Finding: Dataclass representing a validation finding
- BaseValidator: Abstract base class for validators
- BaseFormatter: Abstract base class for formatters
- Validator/Formatter: Protocol types for duck typing

Also provides simple registration and discovery functions.

maxwell/src/maxwell/validators/types.py
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Optional, Protocol, Type

if TYPE_CHECKING:
    from maxwell.config import MaxwellConfig

logger = logging.getLogger(__name__)

__all__ = [
    "Severity",
    "Finding",
    "Validator",
    "Formatter",
    "BaseValidator",
    "BaseFormatter",
    "get_all_validators",
    "get_all_formatters",
    "get_validator",
    "get_formatter",
]


class Severity(Enum):
    """Severity levels for validation findings."""

    OFF = "OFF"
    INFO = "INFO"
    WARN = "WARN"
    BLOCK = "BLOCK"

    def __lt__(self, other):
        """Enable sorting by severity."""
        order = {"OFF": 0, "INFO": 1, "WARN": 2, "BLOCK": 3}
        return order[self.value] < order[other.value]


@dataclass
class Finding:
    """A validation finding from a validator."""

    rule_id: str
    message: str
    file_path: Path
    line: int = 0
    column: int = 0
    severity: Severity = Severity.WARN
    context: str = ""
    suggestion: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert finding to dictionary for JSON output."""
        return {
            "rule": self.rule_id,
            "level": self.severity.value,
            "path": str(self.file_path),
            "line": self.line,
            "column": self.column,
            "msg": self.message,
            "context": self.context,
            "suggestion": self.suggestion,
        }


class Validator(Protocol):
    """Protocol for validator classes - simpler than abstract base class."""

    rule_id: str
    default_severity: Severity

    def __init__(
        self, severity: Optional[Severity] = None, config: Optional["MaxwellConfig"] = None
    ) -> None: ...

    def validate(
        self, file_path: Path, content: str, config: Optional["MaxwellConfig"] = None
    ) -> Iterator[Finding]:
        """Validate a file and yield findings."""
        ...

    def create_finding(
        self,
        message: str,
        file_path: Path,
        line: int = 0,
        column: int = 0,
        context: str = "",
        suggestion: Optional[str] = None,
    ) -> Finding:
        """Create a Finding object with this validator's rule_id and severity."""
        ...


class Formatter(Protocol):
    """Protocol for formatter classes - simpler than abstract base class."""

    name: str

    def format_results(
        self,
        findings: List[Finding],
        summary: Dict[str, int],
        config: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Format validation results for output."""
        ...


# Simple registry - no complex plugin discovery needed
_VALIDATORS: Dict[str, Type[Validator]] = {}
_FORMATTERS: Dict[str, Type[Formatter]] = {}


def register_validator(validator_class: Type[Validator]) -> None:
    """Register a validator class."""
    _VALIDATORS[validator_class.rule_id] = validator_class


def register_formatter(formatter_class: Type[Formatter]) -> None:
    """Register a formatter class."""
    _FORMATTERS[formatter_class.name] = formatter_class


def get_validator(rule_id: str) -> Optional[Type[Validator]]:
    """Get validator class by rule ID."""
    return _VALIDATORS.get(rule_id)


def get_all_validators() -> Dict[str, Type[Validator]]:
    """Get all registered validator classes."""
    # Lazy load validators from entry points on first access
    if not _VALIDATORS:
        _load_builtin_validators()
    return _VALIDATORS.copy()


def get_formatter(name: str) -> Optional[Type[Formatter]]:
    """Get formatter class by name."""
    return _FORMATTERS.get(name)


def get_all_formatters() -> Dict[str, Type[Formatter]]:
    """Get all registered formatter classes."""
    # Lazy load formatters from entry points on first access
    if not _FORMATTERS:
        _load_builtin_formatters()
    return _FORMATTERS.copy()


def _load_builtin_validators() -> None:
    """Load built-in validators via filesystem auto-discovery.

    Scans maxwell.validators.* packages and auto-discovers BaseValidator subclasses.
    Third-party validators can still use entry points.
    """
    import importlib

    # Auto-discover built-in validators from filesystem
    try:
        import maxwell.workflows.validate.validators

        validators_path = Path(maxwell.workflows.validate.validators.__file__).parent

        # Scan all subdirectories: single_file, project_wide, architecture
        for subdir in ["single_file", "project_wide", "architecture"]:
            subdir_path = validators_path / subdir
            if not subdir_path.is_dir():
                continue

            # Import all Python modules in this subdirectory
            for module_file in subdir_path.glob("*.py"):
                if module_file.name.startswith("_"):
                    continue

                module_name = f"maxwell.workflows.validate.validators.{subdir}.{module_file.stem}"
                try:
                    module = importlib.import_module(module_name)

                    # Find all BaseValidator subclasses in the module
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (
                            isinstance(attr, type)
                            and issubclass(attr, BaseValidator)
                            and attr is not BaseValidator
                            and hasattr(attr, "rule_id")
                            and attr.rule_id  # Must have non-empty rule_id
                        ):
                            _VALIDATORS[attr.rule_id] = attr
                            logger.debug(
                                f"Auto-discovered validator: {attr.rule_id} from {module_name}"
                            )

                except (ImportError, AttributeError) as e:
                    logger.debug(f"Failed to load validator module {module_name}: {e}")

    except Exception as e:
        logger.warning(f"Failed to auto-discover built-in validators: {e}")

    # Also load third-party validators from entry points
    try:
        import importlib.metadata

        for entry_point in importlib.metadata.entry_points(group="maxwell.validators"):
            try:
                validator_class = entry_point.load()
                if hasattr(validator_class, "rule_id") and validator_class.rule_id:
                    _VALIDATORS[validator_class.rule_id] = validator_class
                    logger.debug(
                        f"Loaded third-party validator from entry point: {validator_class.rule_id}"
                    )
            except (ImportError, AttributeError, TypeError) as e:
                logger.debug(f"Failed to load validator from entry point {entry_point.name}: {e}")
    except Exception as e:
        logger.debug(f"Entry point discovery failed: {e}")


def _load_builtin_formatters() -> None:
    """Load built-in formatters from entry points."""
    import importlib.metadata

    for entry_point in importlib.metadata.entry_points(group="maxwell.formatters"):
        try:
            formatter_class = entry_point.load()
            if hasattr(formatter_class, "name"):
                _FORMATTERS[formatter_class.name] = formatter_class
        except (ImportError, AttributeError, TypeError) as e:
            logger.debug(f"Failed to load formatter from entry point {entry_point.name}: {e}")
            pass


# Concrete base classes
class BaseValidator:
    """Base class for validators."""

    rule_id: str = ""
    default_severity: Severity = Severity.WARN

    def __init__(
        self, severity: Optional[Severity] = None, config: Optional["MaxwellConfig"] = None
    ) -> None:
        self.severity = severity or self.default_severity
        self.config = config

    def validate(
        self, file_path: Path, content: str, config: Optional["MaxwellConfig"] = None
    ) -> Iterator[Finding]:
        """Validate a file and yield findings."""
        raise NotImplementedError

    def create_finding(
        self,
        message: str,
        file_path: Path,
        line: int = 0,
        column: int = 0,
        context: str = "",
        suggestion: Optional[str] = None,
    ) -> Finding:
        """Create a Finding object with this validator's rule_id and severity."""
        return Finding(
            rule_id=self.rule_id,
            message=message,
            file_path=file_path,
            line=line,
            column=column,
            severity=self.severity,
            context=context,
            suggestion=suggestion,
        )

    def can_fix(self, finding: Finding) -> bool:
        """Check if this validator can automatically fix the finding.

        Override this method in subclasses that support auto-fixing.
        """
        return False

    def apply_fix(self, content: str, finding: Finding) -> str:
        """Apply automatic fix to the content for the given finding.

        Override this method in subclasses that support auto-fixing.
        Returns the fixed content.
        """
        return content


class BaseFormatter(ABC):
    """Base class for formatters."""

    name: str = ""
    description: str = ""

    @abstractmethod
    def format_results(
        self,
        findings: List[Finding],
        summary: dict[str, int],
        config: Optional["MaxwellConfig"] = None,
    ) -> str:
        """Format validation results for output."""
        pass


# Legacy global manager for backward compatibility
class _LegacyPluginManager:
    """Legacy compatibility wrapper."""

    def load_plugins(self) -> None:
        """Load plugins - delegated to new system."""
        get_all_validators()
        get_all_formatters()

    def get_validator(self, rule_id: str) -> Optional[Any]:
        """Get validator by rule ID."""
        return get_validator(rule_id)

    def get_all_validators(self) -> Dict[str, type]:
        """Get all validators."""
        return get_all_validators()

    def get_formatter(self, name: str) -> Optional[Any]:
        """Get formatter by name."""
        return get_formatter(name)

    def get_all_formatters(self) -> Dict[str, type]:
        """Get all formatters."""
        return get_all_formatters()


plugin_manager = _LegacyPluginManager()
```

---
### File: src/maxwell.egg-info/PKG-INFO

```
Metadata-Version: 2.4
Name: maxwell
Version: 0.1.2
Summary: Suite of tools to enhance the vibe coding process.
Author-email: Mithran Mohanraj <mithran.mohanraj@gmail.com>
License: MIT
Project-URL: Homepage, https://github.com/mithranm/vibelint
Project-URL: Bug Tracker, https://github.com/mithranm/vibelint/issues
Classifier: Development Status :: 3 - Alpha
Classifier: Environment :: Console
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved :: MIT License
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.11
Classifier: Programming Language :: Python :: 3.12
Classifier: Topic :: Software Development :: Quality Assurance
Requires-Python: >=3.11
Description-Content-Type: text/markdown
License-File: LICENSE
Requires-Dist: click>=8.1.0
Requires-Dist: tomli-w
Requires-Dist: colorama>=0.4.0
Requires-Dist: rich>=12.0.0
Requires-Dist: libcst
Requires-Dist: requests>=2.25.0
Requires-Dist: python-dotenv>=1.0.0
Provides-Extra: embedding
Requires-Dist: sentence-transformers>=2.2.0; extra == "embedding"
Requires-Dist: torch>=1.9.0; extra == "embedding"
Requires-Dist: numpy>=1.21.0; extra == "embedding"
Provides-Extra: dev
Requires-Dist: pytest>=7.0.0; extra == "dev"
Requires-Dist: pytest-cov>=4.0.0; extra == "dev"
Requires-Dist: pytest-asyncio>=0.21.0; extra == "dev"
Requires-Dist: ruff>=0.1.0; extra == "dev"
Requires-Dist: black>=23.0.0; extra == "dev"
Requires-Dist: vulture>=2.0; extra == "dev"
Dynamic: license-file

# Maxwell

**Entropy reducing and consolidation tool for projects** - Content-addressable semantic indexing for documents, code, and conversations.

Maxwell organizes your filesystem's chaos using embeddings and content-addressable storage, making everything searchable by meaning, not just filename.

## Features

- **Content-addressable storage** - Files identified by SHA256 hash, global deduplication
- **Semantic search** - Find documents by meaning using embeddings (not keywords)
- **Multi-format extraction** - PDFs (marker-pdf), Office docs (markitdown), Claude chat logs (.jsonl)
- **Hierarchical indexing** - Folders = mean of children's embeddings
- **Distributed architecture** - Each directory has `.maxwell/` (like `.git/`)
- **Python-first** - Code validation and semantic analysis (more languages coming)

## Installation

```bash
pip install -e .
```

## Quick Start

### Index a Directory

```python
from pathlib import Path
from maxwell.workflows.implementations.index import HierarchicalIndexer

indexer = HierarchicalIndexer(Path.cwd())
indexer.build_index()
indexer.save()
```

### Search Your Documents

```python
from pathlib import Path
from maxwell.workflows.implementations.search import run_search_workflow

# Search for conversations about a topic
results = run_search_workflow(Path.cwd(), 'PDF parsing marker-pdf markitdown', top_k=5)
for result in results:
    print(f'{result.score:.3f} - {result.path}')
```

### Legacy: Code Validation (Python only)

```bash
# Run validators on Python code
maxwell check .

# Run with automatic fixing
maxwell check --fix .
```

## What Gets Indexed

Maxwell indexes:
- **Markdown files** (`.md`)
- **PDFs** (`.pdf`) - reuses existing parsed versions when available
- **Claude chat logs** (`.jsonl` in `.claude/projects/`) - 28MB+ of conversations now searchable
- **Office documents** (`.docx`, `.pptx`, `.xlsx`)
- **Python code** (`.py`) - semantic code search

## Architecture

```
project/
├── .maxwell/                      # Like .git/, per-directory
│   ├── data/                      # JSONL (committed to git)
│   │   ├── messages.jsonl
│   │   ├── tool_calls.jsonl
│   │   └── edges.jsonl
│   ├── indexes/                   # SQLite (gitignored, rebuildable)
│   ├── extracted/                 # Cached extractions (gitignored)
│   └── .gitignore                 # Auto-created
└── documents/

~/.maxwell/                        # Global cache
└── cache.db                       # Shared embedding cache (deduplication)
```

## Configuration

Add to `pyproject.toml`:

```toml
[tool.maxwell]
include_globs = [
    "*.md", "**/*.md",
    "*.pdf", "**/*.pdf",
    "**/.claude/projects/*.jsonl"    # Include chat logs
]
exclude_globs = [
    ".maxwell/**",
    ".git/**",
    "__pycache__/**"
]

# Legacy: Python code validation
[tool.maxwell.validation]
rules = { EMOJI-USAGE = "BLOCK", DICT-GET-FALLBACK = "WARN" }
```

## Development

See [AGENTS.instructions.md](./AGENTS.instructions.md) for development guidelines.

### Testing

```bash
# Run tests
tox -e py311

# Run formatters and linters
isort src/ tests/
black src/ tests/
ruff check --fix src/ tests/
pyright src/
```

## Documentation

- [Development Instructions](./AGENTS.instructions.md)
- [Claude Code Config](./.claude/settings.json)

## License

See LICENSE file.
```

---
### File: src/maxwell.egg-info/SOURCES.txt

```
.env.example
.gitignore
AGENTS.instructions.md
CLAUDE.md
LICENSE
MANIFEST.in
README.md
pyproject.toml
tox.ini
.github/workflows/ci.yml
.github/workflows/publish.yml
docs/EmbeddingGemma.md
docs/GPT-OSS.md
docs/JUSTIFICATION_WORKFLOW.md
docs/extending-vibelint.md
docs/print_suppression.md
src/maxwell/__init__.py
src/maxwell/__main__.py
src/maxwell/api.py
src/maxwell/cli.py
src/maxwell/config.py
src/maxwell/discovery.py
src/maxwell/extractors.py
src/maxwell/filesystem.py
src/maxwell/mcp_server.py
src/maxwell/pydantic_gbnf.py
src/maxwell/reporting.py
src/maxwell/rules.py
src/maxwell/storage.py
src/maxwell/types.py
src/maxwell/utils.py
src/maxwell.egg-info/PKG-INFO
src/maxwell.egg-info/SOURCES.txt
src/maxwell.egg-info/dependency_links.txt
src/maxwell.egg-info/entry_points.txt
src/maxwell.egg-info/requires.txt
src/maxwell.egg-info/top_level.txt
src/maxwell/workflows/__init__.py
src/maxwell/workflows/base.py
src/maxwell/workflows/justification.py
src/maxwell/workflows/tag_refactor.py
src/maxwell/workflows/utilities.py
src/maxwell/workflows/chat/README.md
src/maxwell/workflows/chat/__init__.py
src/maxwell/workflows/chat/batch_extract.py
src/maxwell/workflows/chat/bm25_search.py
src/maxwell/workflows/chat/metadata_extractor.py
src/maxwell/workflows/chat/parsers.py
src/maxwell/workflows/validate/__init__.py
src/maxwell/workflows/validate/ast_utils.py
src/maxwell/workflows/validate/validation_engine.py
src/maxwell/workflows/validate/validators/__init__.py
src/maxwell/workflows/validate/validators/types.py
src/maxwell/workflows/validate/validators/project_wide/__init__.py
src/maxwell/workflows/validate/validators/single_file/__init__.py
src/maxwell/workflows/validate/validators/single_file/dict_get_fallback.py
src/maxwell/workflows/validate/validators/single_file/emoji.py
src/maxwell/workflows/validate/validators/single_file/exports.py
src/maxwell/workflows/validate/validators/single_file/logger_names.py
src/maxwell/workflows/validate/validators/single_file/typing_quality.py
systemd/maxwell-mcp.service
tests/__init__.py
tests/conftest.py
tests/test_cli.py
tests/test_config.py
tests/test_filesystem.py
tests/test_llm_client.py
tests/test_rules.py
tests/test_validation_engine.py
tests/test_validators.py
tests/live/README.md
tests/live/__init__.py
tests/live/test_structured_output.py
```

---
### File: src/maxwell.egg-info/dependency_links.txt

```

```

---
### File: src/maxwell.egg-info/entry_points.txt

```
[console_scripts]
maxwell = maxwell.cli:main

[maxwell.formatters]
human = maxwell.reporting:HumanFormatter
json = maxwell.reporting:JsonFormatter
llm = maxwell.reporting:LLMFormatter
natural = maxwell.reporting:NaturalLanguageFormatter
sarif = maxwell.reporting:SarifFormatter
```

---
### File: src/maxwell.egg-info/requires.txt

```
click>=8.1.0
tomli-w
colorama>=0.4.0
rich>=12.0.0
libcst
requests>=2.25.0
python-dotenv>=1.0.0

[dev]
pytest>=7.0.0
pytest-cov>=4.0.0
pytest-asyncio>=0.21.0
ruff>=0.1.0
black>=23.0.0
vulture>=2.0

[embedding]
sentence-transformers>=2.2.0
torch>=1.9.0
numpy>=1.21.0
```

---
### File: src/maxwell.egg-info/top_level.txt

```

```

---
### File: systemd/maxwell-mcp.service

```
[Unit]
Description=Maxwell MCP Server
After=network.target

[Service]
Type=simple
User=mithranmohanraj
WorkingDirectory=/home/mithranmohanraj/Documents/maxwell-file-demon
Environment="PYTHONPATH=/home/mithranmohanraj/Documents/maxwell-file-demon/src"
ExecStart=/home/mithranmohanraj/miniconda3/envs/mcp-unified/bin/python -m maxwell.mcp_server
Restart=on-failure
RestartSec=5s
StandardOutput=journal
StandardError=journal

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=/home/mithranmohanraj/Documents

[Install]
WantedBy=multi-user.target
```

---
### File: tox.ini

```ini
[tox]
envlist = py311, py312, ruff, black
isolated_build = True

[gh-actions]
python =
    3.11: py311, ruff, black
    3.12: py312

[testenv]
deps =
    pytest>=7.0.0
    pytest-cov>=4.0.0
    pytest-asyncio>=0.21.0
commands =
    pytest {posargs:tests} --cov=vibelint --cov-report=xml

[testenv:py311]
basepython = python3.11

[testenv:py312]
basepython = python3.12

[testenv:ruff]
basepython = python3.11
deps = ruff>=0.1.0
commands = ruff check src tests

[testenv:black]
basepython = python3.11
deps = black>=23.0.0
commands = black --check src tests

# ruff configuration is now in pyproject.toml
```

---

