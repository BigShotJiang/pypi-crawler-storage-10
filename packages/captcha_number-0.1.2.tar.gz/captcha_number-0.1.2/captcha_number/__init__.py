from .solver import captcha_number

__all__ = ["captcha_number"]
