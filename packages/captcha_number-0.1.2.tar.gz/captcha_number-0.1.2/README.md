# captcha-number

A Python package for solving number captchas using pytesseract.

demo:

tesseract_path = r"D:\tesseract\tesseract.exe"

# transform PIL Image
img = Image.open(BytesIO(response.content))

#  captcha_number test
captcha_text = captcha_number(img, tesseract_path=tesseract_path, save_debug=True)
captcha_text = captcha_text.strip()