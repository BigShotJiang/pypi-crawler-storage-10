# flake8: noqa

# import apis into api package
from wink_sdk_extranet_property_register.api.leads_api import LeadsApi
from wink_sdk_extranet_property_register.api.registration_api import RegistrationApi

