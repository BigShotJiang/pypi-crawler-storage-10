# 🧭 DistanceConvert

A simple and lightweight Python package to **convert distances** between multiple units — such as kilometers, miles, meters, feet, centimeters, inches, and nautical miles.

---

## 🚀 Features

✅ Convert between common distance units  
✅ Easy-to-use function: `convert(value, from_unit, to_unit)`  
✅ Accurate conversion factors  
✅ Lightweight (no dependencies)  
✅ Includes tests and examples  

---

## 📦 Installation

```bash

pip install pyconverter_metric
