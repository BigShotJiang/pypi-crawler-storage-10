

conversion_factors = {
    ("km", "miles"): 0.621371,
    ("miles", "km"): 1.60934,
    ("m", "km"): 0.001,
    ("km", "m"): 1000,
    ("cm", "inches"): 0.393701,
    ("inches", "cm"): 2.54,
    ("feet", "m"): 0.3048,
    ("m", "feet"): 3.28084,
    ("nautical_miles", "km"): 1.852,
    ("km", "nautical_miles"): 1 / 1.852,
}

def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert distance from one unit to another."""
    key = (from_unit.lower(), to_unit.lower())
    if key in conversion_factors:
        return value * conversion_factors[key]
    else:
        raise ValueError(f"Conversion from {from_unit} to {to_unit} not supported.")
