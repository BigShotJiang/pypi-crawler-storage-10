# example.py

from pyconverter_metric import convert

def main():
    print("🚀 Distance Conversion Examples\n")

    # Basic conversions
    print(f"10 kilometers = {convert(10, 'km', 'miles'):.4f} miles")
    print(f"5 miles = {convert(5, 'miles', 'km'):.4f} kilometers")
    print(f"1200 meters = {convert(1200, 'm', 'km'):.4f} kilometers")
    print(f"100 centimeters = {convert(100, 'cm', 'inches'):.4f} inches")
    print(f"10 feet = {convert(10, 'feet', 'm'):.4f} meters")
    print(f"2 nautical miles = {convert(2, 'nautical_miles', 'km'):.4f} kilometers")

    # Try an unsupported conversion
    try:
        print(convert(10, 'lightyears', 'miles'))
    except ValueError as e:
        print(f"\n⚠️ Error: {e}")

if __name__ == "__main__":
    main()
