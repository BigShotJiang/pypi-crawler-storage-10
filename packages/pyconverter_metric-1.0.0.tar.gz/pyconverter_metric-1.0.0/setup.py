
from setuptools import setup, find_packages

setup(
    name="pyconverter_metric",
    version="1.0.0",
    author="Vigneshwar S" ,
    description="A simple package to convert distances between various units",
    packages=find_packages(),
    python_requires=">=3.7",
)
