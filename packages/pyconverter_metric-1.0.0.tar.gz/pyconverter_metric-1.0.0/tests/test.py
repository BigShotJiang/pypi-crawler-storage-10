
# test.py

import unittest
from pyconverter_metric.operation import convert

class TestDistanceConvert(unittest.TestCase):

    def test_km_to_miles(self):
        self.assertAlmostEqual(convert(1, 'km', 'miles'), 0.621371, places=6)

    def test_miles_to_km(self):
        self.assertAlmostEqual(convert(1, 'miles', 'km'), 1.60934, places=5)

    def test_m_to_km(self):
        self.assertEqual(convert(1000, 'm', 'km'), 1.0)

    def test_cm_to_inches(self):
        self.assertAlmostEqual(convert(10, 'cm', 'inches'), 3.93701, places=5)

    def test_unsupported_conversion(self):
        with self.assertRaises(ValueError):
            convert(10, 'lightyear', 'miles')

if __name__ == '__main__':
    unittest.main()
