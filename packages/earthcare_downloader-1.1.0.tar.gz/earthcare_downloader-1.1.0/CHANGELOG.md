# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.1.0 – 2025-10-30

- Change disable_progress option to quiet
- Update LICENSE
- Update README
- Update project status

## 1.0.1 – 2025-10-29

- Fix returned paths with unzip

## 1.0.0 – 2025-10-29

- Add Python API

## 0.0.5 – 2025-10-28

- Adjust arguments

## 0.0.4 – 2025-10-28

- Maybe fix auth issues

## 0.0.3 – 2025-10-27

- Add support for L2 products
- Add prompt before downloading
- Improve search parameters

## 0.0.2 – 2025-05-22

- Initial release

## 0.0.1 – 2025-05-22

- Initial release
