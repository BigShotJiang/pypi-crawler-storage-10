from beekeeper.embeddings.watsonx.base import WatsonxEmbedding

__all__ = ["WatsonxEmbedding"]
