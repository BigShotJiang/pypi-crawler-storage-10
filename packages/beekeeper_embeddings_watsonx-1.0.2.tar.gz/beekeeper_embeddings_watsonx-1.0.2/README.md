# Beekeeper embeddings extension - watsonx

## Installation 

```bash
pip install beekeeper-embeddings-watsonx
```
