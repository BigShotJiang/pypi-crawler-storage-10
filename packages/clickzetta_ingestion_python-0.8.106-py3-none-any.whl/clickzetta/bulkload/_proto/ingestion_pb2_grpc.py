"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings
from . import ingestion_pb2 as ingestion__pb2
GRPC_GENERATED_VERSION = '1.68.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(f'The grpc package installed is at version {GRPC_VERSION},' + f' but the generated code in ingestion_pb2_grpc.py depends on' + f' grpcio>={GRPC_GENERATED_VERSION}.' + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}' + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.')

class IngestionControllerServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.GatewayRpcCall = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/GatewayRpcCall', request_serializer=ingestion__pb2.GatewayRequest.SerializeToString, response_deserializer=ingestion__pb2.GatewayResponse.FromString, _registered_method=True)
        self.CreateOrGetStream = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/CreateOrGetStream', request_serializer=ingestion__pb2.CreateOrGetStreamRequest.SerializeToString, response_deserializer=ingestion__pb2.CreateOrGetStreamResponse.FromString, _registered_method=True)
        self.CloseStream = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/CloseStream', request_serializer=ingestion__pb2.CloseStreamRequest.SerializeToString, response_deserializer=ingestion__pb2.CloseStreamResponse.FromString, _registered_method=True)
        self.GetRouteWorkers = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/GetRouteWorkers', request_serializer=ingestion__pb2.GetRouteWorkersRequest.SerializeToString, response_deserializer=ingestion__pb2.GetRouteWorkersResponse.FromString, _registered_method=True)
        self.CreateBulkLoadStream = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/CreateBulkLoadStream', request_serializer=ingestion__pb2.CreateBulkLoadStreamRequest.SerializeToString, response_deserializer=ingestion__pb2.CreateBulkLoadStreamResponse.FromString, _registered_method=True)
        self.GetBulkLoadStream = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/GetBulkLoadStream', request_serializer=ingestion__pb2.GetBulkLoadStreamRequest.SerializeToString, response_deserializer=ingestion__pb2.GetBulkLoadStreamResponse.FromString, _registered_method=True)
        self.CommitBulkLoadStream = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/CommitBulkLoadStream', request_serializer=ingestion__pb2.CommitBulkLoadStreamRequest.SerializeToString, response_deserializer=ingestion__pb2.CommitBulkLoadStreamResponse.FromString, _registered_method=True)
        self.OpenBulkLoadStreamWriter = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/OpenBulkLoadStreamWriter', request_serializer=ingestion__pb2.OpenBulkLoadStreamWriterRequest.SerializeToString, response_deserializer=ingestion__pb2.OpenBulkLoadStreamWriterResponse.FromString, _registered_method=True)
        self.FinishBulkLoadStreamWriter = channel.unary_unary('/cz.proto.ingestion.IngestionControllerService/FinishBulkLoadStreamWriter', request_serializer=ingestion__pb2.FinishBulkLoadStreamWriterRequest.SerializeToString, response_deserializer=ingestion__pb2.FinishBulkLoadStreamWriterResponse.FromString, _registered_method=True)

class IngestionControllerServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def GatewayRpcCall(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CreateOrGetStream(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CloseStream(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetRouteWorkers(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CreateBulkLoadStream(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetBulkLoadStream(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CommitBulkLoadStream(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def OpenBulkLoadStreamWriter(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def FinishBulkLoadStreamWriter(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_IngestionControllerServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'GatewayRpcCall': grpc.unary_unary_rpc_method_handler(servicer.GatewayRpcCall, request_deserializer=ingestion__pb2.GatewayRequest.FromString, response_serializer=ingestion__pb2.GatewayResponse.SerializeToString), 'CreateOrGetStream': grpc.unary_unary_rpc_method_handler(servicer.CreateOrGetStream, request_deserializer=ingestion__pb2.CreateOrGetStreamRequest.FromString, response_serializer=ingestion__pb2.CreateOrGetStreamResponse.SerializeToString), 'CloseStream': grpc.unary_unary_rpc_method_handler(servicer.CloseStream, request_deserializer=ingestion__pb2.CloseStreamRequest.FromString, response_serializer=ingestion__pb2.CloseStreamResponse.SerializeToString), 'GetRouteWorkers': grpc.unary_unary_rpc_method_handler(servicer.GetRouteWorkers, request_deserializer=ingestion__pb2.GetRouteWorkersRequest.FromString, response_serializer=ingestion__pb2.GetRouteWorkersResponse.SerializeToString), 'CreateBulkLoadStream': grpc.unary_unary_rpc_method_handler(servicer.CreateBulkLoadStream, request_deserializer=ingestion__pb2.CreateBulkLoadStreamRequest.FromString, response_serializer=ingestion__pb2.CreateBulkLoadStreamResponse.SerializeToString), 'GetBulkLoadStream': grpc.unary_unary_rpc_method_handler(servicer.GetBulkLoadStream, request_deserializer=ingestion__pb2.GetBulkLoadStreamRequest.FromString, response_serializer=ingestion__pb2.GetBulkLoadStreamResponse.SerializeToString), 'CommitBulkLoadStream': grpc.unary_unary_rpc_method_handler(servicer.CommitBulkLoadStream, request_deserializer=ingestion__pb2.CommitBulkLoadStreamRequest.FromString, response_serializer=ingestion__pb2.CommitBulkLoadStreamResponse.SerializeToString), 'OpenBulkLoadStreamWriter': grpc.unary_unary_rpc_method_handler(servicer.OpenBulkLoadStreamWriter, request_deserializer=ingestion__pb2.OpenBulkLoadStreamWriterRequest.FromString, response_serializer=ingestion__pb2.OpenBulkLoadStreamWriterResponse.SerializeToString), 'FinishBulkLoadStreamWriter': grpc.unary_unary_rpc_method_handler(servicer.FinishBulkLoadStreamWriter, request_deserializer=ingestion__pb2.FinishBulkLoadStreamWriterRequest.FromString, response_serializer=ingestion__pb2.FinishBulkLoadStreamWriterResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('cz.proto.ingestion.IngestionControllerService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('cz.proto.ingestion.IngestionControllerService', rpc_method_handlers)

class IngestionControllerService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def GatewayRpcCall(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/GatewayRpcCall', ingestion__pb2.GatewayRequest.SerializeToString, ingestion__pb2.GatewayResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def CreateOrGetStream(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/CreateOrGetStream', ingestion__pb2.CreateOrGetStreamRequest.SerializeToString, ingestion__pb2.CreateOrGetStreamResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def CloseStream(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/CloseStream', ingestion__pb2.CloseStreamRequest.SerializeToString, ingestion__pb2.CloseStreamResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetRouteWorkers(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/GetRouteWorkers', ingestion__pb2.GetRouteWorkersRequest.SerializeToString, ingestion__pb2.GetRouteWorkersResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def CreateBulkLoadStream(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/CreateBulkLoadStream', ingestion__pb2.CreateBulkLoadStreamRequest.SerializeToString, ingestion__pb2.CreateBulkLoadStreamResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetBulkLoadStream(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/GetBulkLoadStream', ingestion__pb2.GetBulkLoadStreamRequest.SerializeToString, ingestion__pb2.GetBulkLoadStreamResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def CommitBulkLoadStream(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/CommitBulkLoadStream', ingestion__pb2.CommitBulkLoadStreamRequest.SerializeToString, ingestion__pb2.CommitBulkLoadStreamResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def OpenBulkLoadStreamWriter(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/OpenBulkLoadStreamWriter', ingestion__pb2.OpenBulkLoadStreamWriterRequest.SerializeToString, ingestion__pb2.OpenBulkLoadStreamWriterResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def FinishBulkLoadStreamWriter(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cz.proto.ingestion.IngestionControllerService/FinishBulkLoadStreamWriter', ingestion__pb2.FinishBulkLoadStreamWriterRequest.SerializeToString, ingestion__pb2.FinishBulkLoadStreamWriterResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

class IngestionWorkerServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Mutate = channel.stream_stream('/cz.proto.ingestion.IngestionWorkerService/Mutate', request_serializer=ingestion__pb2.MutateRequest.SerializeToString, response_deserializer=ingestion__pb2.MutateResponse.FromString, _registered_method=True)
        self.MutateInternal = channel.stream_stream('/cz.proto.ingestion.IngestionWorkerService/MutateInternal', request_serializer=ingestion__pb2.MutateRequest.SerializeToString, response_deserializer=ingestion__pb2.MutateResponse.FromString, _registered_method=True)

class IngestionWorkerServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def Mutate(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def MutateInternal(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_IngestionWorkerServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'Mutate': grpc.stream_stream_rpc_method_handler(servicer.Mutate, request_deserializer=ingestion__pb2.MutateRequest.FromString, response_serializer=ingestion__pb2.MutateResponse.SerializeToString), 'MutateInternal': grpc.stream_stream_rpc_method_handler(servicer.MutateInternal, request_deserializer=ingestion__pb2.MutateRequest.FromString, response_serializer=ingestion__pb2.MutateResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('cz.proto.ingestion.IngestionWorkerService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('cz.proto.ingestion.IngestionWorkerService', rpc_method_handlers)

class IngestionWorkerService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Mutate(request_iterator, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.stream_stream(request_iterator, target, '/cz.proto.ingestion.IngestionWorkerService/Mutate', ingestion__pb2.MutateRequest.SerializeToString, ingestion__pb2.MutateResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def MutateInternal(request_iterator, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.stream_stream(request_iterator, target, '/cz.proto.ingestion.IngestionWorkerService/MutateInternal', ingestion__pb2.MutateRequest.SerializeToString, ingestion__pb2.MutateResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)