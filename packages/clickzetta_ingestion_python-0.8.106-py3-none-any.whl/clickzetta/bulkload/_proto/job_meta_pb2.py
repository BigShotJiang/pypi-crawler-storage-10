"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 28, 1, '', 'job_meta.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0ejob_meta.proto\x12\x08cz.proto"&\n\x07JobCost\x12\x0b\n\x03cpu\x18\x01 \x01(\r\x12\x0e\n\x06memory\x18\x02 \x01(\r"s\n\nJobHistory\x12\x18\n\x10coordinator_host\x18\x01 \x01(\t\x12\x1b\n\x13coordinator_version\x18\x02 \x01(\x04\x12\x15\n\rstart_time_ms\x18\x03 \x01(\x04\x12\x17\n\x0frelease_version\x18\x04 \x01(\t"\xaf\x01\n\x0cSQLJobConfig\x12\x0f\n\x07timeout\x18\x01 \x01(\x05\x12\x18\n\x10adhoc_size_limit\x18\x02 \x01(\x03\x12\x17\n\x0fadhoc_row_limit\x18\x03 \x01(\x03\x12.\n\x04hint\x18\x04 \x03(\x0b2 .cz.proto.SQLJobConfig.HintEntry\x1a+\n\tHintEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01"{\n\x06SQLJob\x12\r\n\x05query\x18\x01 \x03(\t\x12\x19\n\x11default_namespace\x18\x02 \x03(\t\x12*\n\nsql_config\x18\x03 \x01(\x0b2\x16.cz.proto.SQLJobConfig\x12\x1b\n\x13default_instance_id\x18\x04 \x01(\x03"x\n\x12JobSummaryLocation\x12\x18\n\x10summary_location\x18\x01 \x01(\t\x12\x15\n\rplan_location\x18\x02 \x01(\t\x12\x16\n\x0estats_location\x18\x03 \x01(\t\x12\x19\n\x11progress_location\x18\x04 \x01(\t"\x8b\x08\n\x07JobMeta\x12\x10\n\x08job_name\x18\x02 \x01(\t\x12\x17\n\x0fvirtual_cluster\x18\x03 \x01(\x03\x12#\n\x06status\x18\x04 \x01(\x0e2\x13.cz.proto.JobStatus\x12\x1f\n\x04type\x18\x05 \x01(\x0e2\x11.cz.proto.JobType\x12\x12\n\nstart_time\x18\x06 \x01(\x04\x12\x10\n\x08end_time\x18\x07 \x01(\x04\x12\x10\n\x08priority\x18\t \x01(\r\x12\x11\n\tsignature\x18\n \x01(\t\x12\x1f\n\x04cost\x18\x0b \x01(\x0b2\x11.cz.proto.JobCost\x120\n\thistories\x18\x0c \x01(\x0b2\x1d.cz.proto.JobMeta.HistoryList\x12\x0e\n\x06result\x18\r \x01(\t\x121\n\x0bjob_summary\x18\x0e \x01(\x0b2\x1c.cz.proto.JobSummaryLocation\x121\n\x0cinput_tables\x18\x0f \x01(\x0b2\x1b.cz.proto.JobMeta.TableList\x122\n\routput_tables\x18\x10 \x01(\x0b2\x1b.cz.proto.JobMeta.TableList\x12*\n\x07content\x18\x11 \x01(\x0b2\x19.cz.proto.JobMeta.Content\x1a4\n\x0bHistoryList\x12%\n\x07history\x18\x01 \x03(\x0b2\x14.cz.proto.JobHistory\x1a,\n\tPartition\x12\x10\n\x08field_id\x18\x01 \x03(\r\x12\r\n\x05value\x18\x02 \x03(\t\x1a\xa5\x01\n\x05Table\x12\x11\n\tnamespace\x18\x01 \x03(\t\x12\x11\n\ttableName\x18\x02 \x01(\t\x12\x0c\n\x04size\x18\x03 \x01(\x04\x12\x0e\n\x06record\x18\x04 \x01(\x04\x12\x12\n\ncache_size\x18\x05 \x01(\x04\x12/\n\npartitions\x18\x06 \x03(\x0b2\x1b.cz.proto.JobMeta.Partition\x12\x13\n\x0binstance_id\x18\x07 \x01(\x03\x1a3\n\tTableList\x12&\n\x05table\x18\x01 \x03(\x0b2\x17.cz.proto.JobMeta.Table\x1a\xd9\x01\n\x07Content\x12<\n\njob_config\x18\x01 \x03(\x0b2(.cz.proto.JobMeta.Content.JobConfigEntry\x12#\n\x07sql_job\x18\x02 \x01(\x0b2\x10.cz.proto.SQLJobH\x00\x12\x17\n\x0frelease_version\x18\x03 \x01(\t\x12\x19\n\x11job_desc_location\x18\x14 \x01(\t\x1a0\n\x0eJobConfigEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01B\x05\n\x03job*i\n\tJobStatus\x12\t\n\x05SETUP\x10\x00\x12\x0c\n\x08QUEUEING\x10\x01\x12\x0b\n\x07RUNNING\x10\x02\x12\x0b\n\x07SUCCEED\x10\x03\x12\x0e\n\nCANCELLING\x10\x04\x12\r\n\tCANCELLED\x10\x05\x12\n\n\x06FAILED\x10\x06**\n\x07JobType\x12\x0b\n\x07SQL_JOB\x10\x00\x12\x12\n\x0eCOMPACTION_JOB\x10\x01B\x02P\x01b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'job_meta_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'P\x01'
    _globals['_SQLJOBCONFIG_HINTENTRY']._loaded_options = None
    _globals['_SQLJOBCONFIG_HINTENTRY']._serialized_options = b'8\x01'
    _globals['_JOBMETA_CONTENT_JOBCONFIGENTRY']._loaded_options = None
    _globals['_JOBMETA_CONTENT_JOBCONFIGENTRY']._serialized_options = b'8\x01'
    _globals['_JOBSTATUS']._serialized_start = 1648
    _globals['_JOBSTATUS']._serialized_end = 1753
    _globals['_JOBTYPE']._serialized_start = 1755
    _globals['_JOBTYPE']._serialized_end = 1797
    _globals['_JOBCOST']._serialized_start = 28
    _globals['_JOBCOST']._serialized_end = 66
    _globals['_JOBHISTORY']._serialized_start = 68
    _globals['_JOBHISTORY']._serialized_end = 183
    _globals['_SQLJOBCONFIG']._serialized_start = 186
    _globals['_SQLJOBCONFIG']._serialized_end = 361
    _globals['_SQLJOBCONFIG_HINTENTRY']._serialized_start = 318
    _globals['_SQLJOBCONFIG_HINTENTRY']._serialized_end = 361
    _globals['_SQLJOB']._serialized_start = 363
    _globals['_SQLJOB']._serialized_end = 486
    _globals['_JOBSUMMARYLOCATION']._serialized_start = 488
    _globals['_JOBSUMMARYLOCATION']._serialized_end = 608
    _globals['_JOBMETA']._serialized_start = 611
    _globals['_JOBMETA']._serialized_end = 1646
    _globals['_JOBMETA_HISTORYLIST']._serialized_start = 1107
    _globals['_JOBMETA_HISTORYLIST']._serialized_end = 1159
    _globals['_JOBMETA_PARTITION']._serialized_start = 1161
    _globals['_JOBMETA_PARTITION']._serialized_end = 1205
    _globals['_JOBMETA_TABLE']._serialized_start = 1208
    _globals['_JOBMETA_TABLE']._serialized_end = 1373
    _globals['_JOBMETA_TABLELIST']._serialized_start = 1375
    _globals['_JOBMETA_TABLELIST']._serialized_end = 1426
    _globals['_JOBMETA_CONTENT']._serialized_start = 1429
    _globals['_JOBMETA_CONTENT']._serialized_end = 1646
    _globals['_JOBMETA_CONTENT_JOBCONFIGENTRY']._serialized_start = 1591
    _globals['_JOBMETA_CONTENT_JOBCONFIGENTRY']._serialized_end = 1639