"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 28, 1, '', 'function_meta.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x13function_meta.proto\x12\x08cz.proto"-\n\x10FunctionResource\x12\x0c\n\x04type\x18\x01 \x01(\t\x12\x0b\n\x03uri\x18\x02 \x01(\t"E\n\x14FunctionResourceList\x12-\n\tresources\x18\x01 \x03(\x0b2\x1a.cz.proto.FunctionResource"\xd2\x01\n\x10RemoteEntrypoint\x12\x14\n\x0cinternal_url\x18\x01 \x01(\t\x12\x14\n\x0cexternal_url\x18\x02 \x01(\t\x12\x10\n\x08protocol\x18\x03 \x01(\t\x12\x13\n\x0bvendor_type\x18\x04 \x01(\t\x12:\n\x0bvendor_info\x18\x05 \x01(\x0b2%.cz.proto.RemoteEntrypoint.VendorInfo\x1a/\n\nVendorInfo\x12\x0f\n\x07service\x18\x01 \x01(\t\x12\x10\n\x08function\x18\x02 \x01(\t"\xd4\x01\n\x08Function\x12\x10\n\x08category\x18\x01 \x01(\t\x12\x11\n\texec_type\x18\x02 \x01(\t\x12\x11\n\tsignature\x18\x03 \x01(\t\x12\x0f\n\x07handler\x18\x04 \x01(\t\x12\x15\n\rconnection_id\x18\x05 \x01(\x03\x121\n\tresources\x18\x06 \x01(\x0b2\x1e.cz.proto.FunctionResourceList\x125\n\x11remote_entrypoint\x18\x07 \x01(\x0b2\x1a.cz.proto.RemoteEntrypointb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'function_meta_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_FUNCTIONRESOURCE']._serialized_start = 33
    _globals['_FUNCTIONRESOURCE']._serialized_end = 78
    _globals['_FUNCTIONRESOURCELIST']._serialized_start = 80
    _globals['_FUNCTIONRESOURCELIST']._serialized_end = 149
    _globals['_REMOTEENTRYPOINT']._serialized_start = 152
    _globals['_REMOTEENTRYPOINT']._serialized_end = 362
    _globals['_REMOTEENTRYPOINT_VENDORINFO']._serialized_start = 315
    _globals['_REMOTEENTRYPOINT_VENDORINFO']._serialized_end = 362
    _globals['_FUNCTION']._serialized_start = 365
    _globals['_FUNCTION']._serialized_end = 577