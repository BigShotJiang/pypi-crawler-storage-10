"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 28, 1, '', 'connection_meta.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x15connection_meta.proto\x12\x08cz.proto"\x8b\x01\n\nConnection\x121\n\x0fconnection_type\x18\x01 \x01(\x0e2\x18.cz.proto.ConnectionType\x129\n\x13connection_category\x18\x02 \x01(\x0e2\x1c.cz.proto.ConnectionCategory\x12\x0f\n\x07enabled\x18\x03 \x01(\x08*\x93\x01\n\x0eConnectionType\x12\x12\n\x0eCLOUD_FUNCTION\x10\x00\x12\r\n\tLAKEHOUSE\x10\x01\x12\t\n\x05KAFKA\x10\x02\x12\x08\n\x04HIVE\x10\x03\x12\x0e\n\nCLICKHOUSE\x10\x04\x12\t\n\x05MYSQL\x10\x05\x12\x0b\n\x07POSTGRE\x10\x06\x12\r\n\tSQLSERVER\x10\x07\x12\x12\n\x0eOSS_CONNECTION\x10\x08*=\n\x12ConnectionCategory\x12\x13\n\x0fDATA_CONNECTION\x10\x00\x12\x12\n\x0eAPI_CONNECTION\x10\x01b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connection_meta_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_CONNECTIONTYPE']._serialized_start = 178
    _globals['_CONNECTIONTYPE']._serialized_end = 325
    _globals['_CONNECTIONCATEGORY']._serialized_start = 327
    _globals['_CONNECTIONCATEGORY']._serialized_end = 388
    _globals['_CONNECTION']._serialized_start = 36
    _globals['_CONNECTION']._serialized_end = 175