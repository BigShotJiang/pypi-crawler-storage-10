"""
Query engine for pathql: threaded producer-consumer file search and filtering.

This module defines the Query class, which uses a producer thread to walk the filesystem
and a consumer (main thread) to filter files using pathql filters.
"""

import datetime as dt
import pathlib
import queue
import threading
from typing import Iterator

from .filters.alias import (
    DatetimeOrNone,
    StatProxyOrNone,
    StrOrPath,
    StrPathOrListOfStrPath,
)
from .filters.base import AllowAll, Filter
from .filters.stat_proxy import StatProxy
from .result_set import ResultSet


class Query(Filter):
    """
    Query engine for pathql.

    Uses a threaded producer-consumer model to walk the filesystem and filter files.

    Args:
        filter_expr (Filter): The filter expression to apply to files.
    """

    def __init__(
        self,
        *,
        where_expr: Filter | None = None,
        from_paths: StrPathOrListOfStrPath = ".",
        recursive: bool = True,
        now: DatetimeOrNone = None,
        files_only: bool = True,
        threaded: bool = False,
    ) -> None:
        """
        Initialize Query.

        If you don't provide a where_expr a MatchAll filter is used
        and all files in the folder will be match.
        Optionally, set from_path to provide a default path or list/tuple of paths
        to use for files/select if not specified at call time.

        Args:
            where_expr (Filter): The filter expression to apply to each file found in from_path
            from_path (str | Path | list | tuple): Default path(s) for files/select.
        """
        self.where_expr: Filter = where_expr or AllowAll()


        # These serve as default values for files/select if not provided at call time
        self.from_paths: StrPathOrListOfStrPath = from_paths
        self.results: list[pathlib.Path] = []
        self.recursive: bool = recursive
        self.files_only: bool = files_only
        self.now: DatetimeOrNone = now
        self.threaded: bool = threaded

    def match(
        self,
        path: pathlib.Path,
        stat_proxy: StatProxyOrNone = None,
        now: DatetimeOrNone = None,
    ) -> bool:
        """
        Check if a single path matches the filter expression.
        """
        if now is None:
            now = dt.datetime.now()

        return self.where_expr.match(path, stat_proxy, now=now)

    def _unthreaded_files(
        self,
        path: StrOrPath,
        recursive: bool = True,
        files: bool = True,
        now: DatetimeOrNone = None,
    ) -> Iterator[pathlib.Path]:
        """
        Yield files matching filter expression using a single-threaded approach (no queue/thread).
        """
        if isinstance(path, str):
            path = pathlib.Path(path)

        if now is None:
            now = dt.datetime.now()
        iterator = path.rglob("*") if recursive else path.glob("*")
        for p in iterator:
            if files and not p.is_file():
                continue
            stat_proxy = StatProxy(p)
            if self.where_expr.match(p, stat_proxy, now=now):
                yield p

    def _threaded_files(
        self,
        path: StrOrPath,
        recursive: bool = True,
        files: bool = True,
        now: DatetimeOrNone = None,
    ) -> Iterator[pathlib.Path]:
        """
        Yield files matching the filter expression using a threaded producer-consumer model.
        """
        if isinstance(path, str):
            path = pathlib.Path(path)

        if now is None:
            now = dt.datetime.now()
        q: queue.Queue[pathlib.Path | None] = queue.Queue(maxsize=10)

        def producer():
            iterator = path.rglob("*") if recursive else path.glob("*")
            for p in iterator:
                if files and not p.is_file():
                    continue
                q.put(p)
            q.put(None)  # Sentinel to signal completion

        t = threading.Thread(target=producer, daemon=True)
        t.start()
        while True:
            p = q.get()
            if p is None:
                break
            stat_proxy = StatProxy(p)
            if self.where_expr.match(p, stat_proxy, now=now):
                yield p
        t.join()

    def files(
        self,
        from_paths: StrPathOrListOfStrPath | None = None,
        recursive: bool | None = None,
        files_only: bool | None = None,
        now: DatetimeOrNone = None,
        threaded: bool = False,
    ) -> Iterator[pathlib.Path]:
        """
        Yield files matching the filter expression for a single path or a list of paths.
        Handles both threaded and non-threaded modes. Uses default from_path if paths not given.
        """
        if from_paths is None:
            from_paths = self.from_paths

        if recursive is None:
            recursive = self.recursive

        if files_only is None:
            files_only = self.files_only

        if now is None:
            now = dt.datetime.now()

        if isinstance(from_paths, (str, pathlib.Path)):
            path_list = [from_paths]
        else:
            path_list = list(from_paths)
        path_list = [pathlib.Path(p) for p in path_list]
        for path in path_list:
            if threaded:
                yield from self._threaded_files(
                    path, recursive=recursive, files=files_only, now=now
                )
            else:
                yield from self._unthreaded_files(
                    path, recursive=recursive, files=files_only, now=now
                )

    def select(
        self,
        from_paths: StrPathOrListOfStrPath | None = None,
        recursive: bool | None = None,
        files_only: bool | None = None,
        now: DatetimeOrNone = None,
        threaded: bool = False,
    ) -> ResultSet:
        """
        Return a ResultSet of files matching the filter expr for a path or a list of paths.
        Uses default from_path if paths not given.
        """
        return ResultSet(self.files(from_paths, recursive, files_only, now, threaded))
