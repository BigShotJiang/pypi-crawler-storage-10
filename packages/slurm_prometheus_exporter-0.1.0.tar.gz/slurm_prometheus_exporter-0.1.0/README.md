# slurm-prometheus-exporter

基于 PySlurm 的 Prometheus Exporter SDK，可快速暴露 Slurm 作业、节点、分区等核心指标。

## 安装

```bash
pip install slurm-prometheus-exporter-0.1.0-py3-none-any.whl
```

（或使用 `python -m build slurm_prometheus_exporter` 生成 wheel 后再安装。）

## 快速开始

```bash
slurm-exporter --port 9808 --addr 0.0.0.0
```

访问 `http://<host>:9808/metrics` 获取指标；若需单节点维度可追加 `--node-detail`。

若希望以库的方式集成，可在代码中调用：

```python
from slurm_prometheus_exporter import SlurmCollector, start_http_exporter

collector = SlurmCollector(include_node_detail=False)
start_http_exporter(port=9808, collector=collector)
```

更多示例与说明可参考仓库根目录 `docs/prometheus_exporter.md` 与 `examples/prometheus_exporter.py`。
