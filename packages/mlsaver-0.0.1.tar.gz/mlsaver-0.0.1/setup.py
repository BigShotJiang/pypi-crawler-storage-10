from setuptools import setup, find_packages

setup(
    name="mlsaver", 
    version="0.0.1",  
    author="raad",
    description="A simple ML model versioning tool",
    url="https://github.com/oRaqzz/MLSaver",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "joblib>=1.5.2",
    ]
)