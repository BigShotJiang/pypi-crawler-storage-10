from datasets import load_dataset, DatasetDict


if __name__ == "__main__":
    dataset = load_dataset(
        "OALL/ALRAGE",
        revision="4827b2ed2436aea578e84d9bd4150b66ab8bbe0e",
        split="train",
    )

    import xdev
    xdev.embed()
