import json
from typing import List

import dacite
from helm.benchmark.scenarios.scenario import (
    Scenario,
    Instance,
)

class LocalDatasetScenario(Scenario):
    def __init__(self, instances_path):
        self.instances_path = instances_path

    def get_instances(self, output_path: str) -> List[Instance]:
        # data_path: str = os.path.join(output_path, "data")
        # ensure_directory_exists(data_path)
        # ^ Don't need the above for now; maybe make a symlink to `self.instances_path`

        with open(self.instances_path) as f:
            instances_data = json.load(f)

        return dacite.from_dict(List[Instance], instances_data)
