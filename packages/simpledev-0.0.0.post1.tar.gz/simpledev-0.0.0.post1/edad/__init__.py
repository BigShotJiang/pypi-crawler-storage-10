from ftext import *
import timer

__all__ = ["i_color", "b_color", "color", "font"]
__all__ += [timer]
