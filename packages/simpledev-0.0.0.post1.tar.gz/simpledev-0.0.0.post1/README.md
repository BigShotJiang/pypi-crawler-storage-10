# Easy Develop And Debugging

>This library is useful for development and debugging.

Content:
 - Timer
 - Format Text

## Timer

	@delay(is_res: bool)
	...

## Format Text

	_test_print_format(text: str) -> None
	
	Answer:
	name-foramt: {text} {reset_format}\n 
