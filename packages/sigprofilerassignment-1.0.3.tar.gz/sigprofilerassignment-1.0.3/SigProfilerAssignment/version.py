
# THIS FILE IS GENERATED FROM SigProfilerAssignment SETUP.PY
short_version = '1.0.3'
version = '1.0.3'
Update = 'v1.0.3: Add parameter to toggle automatic background signature addition'

    