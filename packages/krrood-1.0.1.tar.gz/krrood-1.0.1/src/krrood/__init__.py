import importlib.metadata
import logging

__version__ = "1.0.1"


logger = logging.Logger("krrood")
logger.setLevel(logging.INFO)
