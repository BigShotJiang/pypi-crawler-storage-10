# Packmon

Packmon (Package Monitoring) is a cli tool to monitor aging python packages in order to
see if some become outdated.


## Philosophy

As a simple monitoring tool, packmon is pure-python in order to simplify its use.


## Usage

1. Install packmon globally on your system
2. Use it to detect obsolescence and vulnerabilities in any of your project (virtual
    environment or not)


### Example

Local installation for now:

    pip install packmon

Then use it:

    packmon myproject/requirements.txt

or

    pip freeze |packmon

event through pipes:

    curl -s https://raw.githubusercontent.com/AFPy/Potodo/master/requirements.txt |packmon

Result :

![sample](https://framagit.org/tool-caddy/packmon/-/raw/main/media/sample.png)


### Options

#### Cache management

Those options help you managing packages informations from packmon's cache. Cache file
is stored into **HOME_USER/.packmon/packmon.json**.

##### clear-cache

Empty cache file before any update.

##### update-cache

Forces updating of each package from cache.

##### no-cache

Does not use cache when using packmon. With this option set, each package will call pypi
to retrieve its informations. Cache won't be modified.

##### no-update

Does not try to refresh a package information, even if it's too old.

#### Output management

##### quiet

With this option set, packmon will write nothing on the standard output (errors will
still be displayed using error output though).

##### only-problems

This option will limit the results only to problematic packages.

#### CI compatibility

##### ci

With this option set, packmon will return a value corresponding to the number of
packages outdated (max 127).
