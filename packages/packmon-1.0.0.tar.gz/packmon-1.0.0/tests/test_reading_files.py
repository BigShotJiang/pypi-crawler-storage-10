from packmon import parse_files, parse_requirements


def test_basic_requirements():
    lines = parse_files(["tests/files/basic_requirements.txt"])
    assert len(lines) == 8
    assert lines[0] == "certifi==2020.12.5"
    requirements = parse_requirements(lines)
    assert len(requirements) == 8
    assert requirements[0].name == "certifi"


def test_complex_requirements():
    lines = parse_files(["tests/files/complex_requirements.txt"])
    assert len(lines) == 22
    assert lines[0] == "-e git+http://git.entrouvert.org/debian/django-ckeditor.git#egg=django_ckeditor"
    assert lines[1] == "django-ratelimit"
    requirements = parse_requirements(lines)
    assert len(requirements) == 21
    assert requirements[0].name == "django-ratelimit"
    assert requirements[-1].name == "xstatic_roboto-fontface"


def test_basic_setup_cfg():
    requirements = parse_requirements(parse_files(["tests/files/basic_setup.cfg"]))
    assert len(requirements) == 2
    assert requirements[0].name == "importlib-metadata; python_version"
    assert requirements[1].name == "requests"


def test_empty_setup_cfg():
    requirements = parse_requirements(parse_files(["tests/files/empty_setup.cfg"]))
    assert requirements == []


def test_basic_pyproject_toml():
    requirements = parse_requirements(parse_files(["tests/files/basic_pyproject.toml"]))
    assert len(requirements) == 4
    assert requirements[0].name == "django"
    assert requirements[1].name == "django"
    assert requirements[2].name == "gidgethub[httpx]"
    assert len(requirements[2].constraints) == 1
    assert requirements[2].constraints[0].version == "4.0.0"
    assert requirements[2].constraints[0].constraint == ">"


def test_complex_pyproject_toml():
    requirements = parse_requirements(parse_files(["tests/files/complex_pyproject.toml"]))
    assert len(requirements) == 8
    assert requirements[0].name == "black"
    assert requirements[1].name == "django"
    assert requirements[2].name == "django"
    assert requirements[3].name == "gidgethub[httpx]"
    assert len(requirements[3].constraints) == 1
    assert requirements[3].constraints[0].version == "4.0.0"
    assert requirements[3].constraints[0].constraint == ">"


def test_empty_pyproject_toml():
    requirements = parse_requirements(parse_files(["tests/files/empty_pyproject.toml"]))
    assert requirements == []
