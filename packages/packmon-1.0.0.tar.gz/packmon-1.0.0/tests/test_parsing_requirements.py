from packmon import parse_requirements


def test_parsing_simple_requirement():
    requirements = parse_requirements(["certifi"])
    assert len(requirements) == 1
    assert requirements[0].name == "certifi"
    assert requirements[0].constraints == []


def test_parsing_specific_version():
    requirements = parse_requirements(["certifi==2.3"])
    assert len(requirements) == 1
    assert requirements[0].name == "certifi"
    assert len(requirements[0].constraints) == 1
    assert requirements[0].constraints[0].constraint == "=="
    assert requirements[0].constraints[0].version == "2.3"


def test_parsing_lesser_version():
    requirements = parse_requirements(["certifi<2.3"])
    assert len(requirements) == 1
    assert requirements[0].name == "certifi"
    assert len(requirements[0].constraints) == 1
    assert requirements[0].constraints[0].constraint == "<"
    assert requirements[0].constraints[0].version == "2.3"


def test_parsing_multiple_constraints():
    requirements = parse_requirements(["Django>=3.2, <3.3"])
    assert len(requirements) == 1
    assert requirements[0].name == "django"
    assert len(requirements[0].constraints) == 2
    assert requirements[0].constraints[0].constraint == ">="
    assert requirements[0].constraints[0].version == "3.2"
    assert requirements[0].constraints[1].constraint == "<"
    assert requirements[0].constraints[1].version == "3.3"
