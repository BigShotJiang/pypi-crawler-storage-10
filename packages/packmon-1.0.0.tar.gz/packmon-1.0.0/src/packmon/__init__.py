"""
Packmon : Monitoring packages to increase quality and kill obsolescence.
Author  : Mindiell
License : GPLv3+
Package : https://framagit.org/tool-caddy/packmon
Version : 1.0.0
"""

import argparse
import configparser
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
import re
import sys
import tomllib
from urllib.request import Request, urlopen

from packmon.panversion import Version


VERSION = "1.0.0"
BOT_URL = "https://framagit.org/tool-caddy/packmon/-/blob/main/bot.md"
USER_AGENT = f"packmon/{VERSION} ({BOT_URL})"
PATTERN_REQUIREMENT = r"(?P<name>[^>~=<]+)(?P<constraints>.+)?$"
PATTERN_CONSTRAINT = r"(?P<constraint>[^\w]+)(?P<version>.+)?$"
RELEASE_LIMIT = 360


@dataclass
class Constraint:
    constraint: str = None
    version: str = "last"


@dataclass
class Requirement:
    name: str
    constraints: list = field(default_factory=list)


@dataclass
class Package:
    name: str
    status: str = "Unknown"
    license: str = "Unknown"
    vulnerabilities: int = 0
    releases: list = field(default_factory=list)
    last_update: datetime = datetime.now()

    @property
    def last_version(self) -> Version:
        try:
            return self.releases[-1]
        except IndexError:
            return {
                "version": "Unknown",
                "release_date": f"{datetime.now():%Y-%m-%d}",
            }

    def actual_version(self, constraints: list) -> Version:
        if len(constraints) == 0:
            return self.last_version

        version_found = False
        version = None
        for release in self.releases:
            if not version_found:
                if all(
                    [
                        test_constraint(release["version"], constraint)
                        for constraint in constraints
                    ]
                ):
                    version_found = True
                    version = release
            if version_found:
                if all(
                    [
                        test_constraint(release["version"], constraint)
                        for constraint in constraints
                    ]
                ):
                    version = release
                else:
                    return version

        return self.last_version

    def next_version(self, actual_version) -> Version:
        if actual_version == "last":
            return self.last_version
        for version in self.releases:
            if version["version"] > actual_version["version"]:
                return version
        return self.last_version

    def to_json(self) -> dict:
        return {
            "name": self.name,
            "status": self.status,
            "license": self.license,
            "vulnerabilities": self.vulnerabilities,
            "releases": [
                {
                    "version": str(release["version"]),
                    "release_date": release["release_date"],
                }
                for release in self.releases
            ],
            "last_update": f"{self.last_update:%Y-%m-%d %H:%M:%S}",
        }


class Dependency:
    def __init__(self, name, package, constraints):
        self.name = name
        self.status = package.status
        self.license = package.license
        self.vulnerabilities = str(package.vulnerabilities)
        actual_version = package.actual_version(constraints)
        self.version = str(actual_version["version"])
        self.version_date = actual_version["release_date"][:10]
        next_version = package.next_version(actual_version)
        self.next_version = str(next_version["version"])
        self.next_date = next_version["release_date"][:10]
        last_version = package.last_version
        self.last_version = str(last_version["version"])
        self.last_date = last_version["release_date"][:10]

    @property
    def status_level(self) -> str:
        if self.status.lower() in ("planning", "pre-alpha", "alpha", "inactive"):
            return "\033[1m\033[31m"
        elif self.status.lower() in ("", "unknown", "beta"):
            return "\033[1m\033[33m"
        return ""

    @property
    def version_level(self) -> str:
        if self.version in ("", "unknown"):
            return "\033[1m\033[31m"
        version = Version(self.version)
        last_version = Version(self.last_version)
        if version != last_version:
            if version.major != last_version.major:
                return "\033[1m\033[31m"
            return "\033[1m\033[33m"
        return ""

    @property
    def release_level(self) -> str:
        last_date = datetime.strptime(self.last_date, "%Y-%m-%d")
        release_limit = datetime.today() - timedelta(days=RELEASE_LIMIT)
        if last_date < release_limit:
            return "\033[1m\033[33m"
        return ""

    @property
    def vulnerabilities_level(self) -> str:
        if self.vulnerabilities == "0":
            return "\033[92m"
        return "\033[1m\033[31m"

    @property
    def is_problematic(self) -> bool:
        return (
            self.status_level != ""
            or self.version_level != ""
            or self.release_level != ""
            or self.vulnerabilities != "0"
        )


@dataclass
class Header:
    slug: str
    name: str
    size: int
    min_size: int
    index: int
    reduced: bool


def test_constraint(version: Version, constraint: Constraint):
    if constraint.constraint == "==":
        return version == constraint.version
    if constraint.constraint == "<=":
        return version <= constraint.version
    if constraint.constraint == "<":
        return version < constraint.version
    if constraint.constraint == ">=":
        return version >= constraint.version
    if constraint.constraint == ">=":
        return version >= constraint.version
    if constraint.constraint == "!=":
        return version != constraint.version

    return False


def parse_requirements(lines):
    requirements = []
    for line in lines:
        try:
            if len(line.strip()) == 0 or line.strip()[0] == "#":
                continue
            if line.strip().startswith("-e"):
                # TODO: manage repos
                continue
            result = re.match(PATTERN_REQUIREMENT, line.strip())
            name = result.group("name").lower()
            constraints = []
            raw_constraints = result.group("constraints")
            try:
                for raw_contraint in raw_constraints.split(","):
                    result = re.match(PATTERN_CONSTRAINT, raw_contraint.strip())
                    constraint = result.group("constraint")
                    version = Version(result.group("version")) or "last"
                    constraints.append(Constraint(constraint, version))
            except AttributeError:
                # No constraint specified
                pass
            requirements.append(Requirement(name=name, constraints=constraints))
        except Exception as e:
            print(
                f"Error while trying to find informations on {line}",
                file=sys.stderr,
            )
            print(e, file=sys.stderr)
            continue

    return requirements


def parse_file(lines: list) -> list:
    requirements = []

    # Is file a setup.cfg file ?
    try:
        config = configparser.ConfigParser()
        config.read_string("\n".join(lines))
        try:
            for line in config["options"].get("install_requires", "").splitlines():
                if line.strip() != "":
                    requirements.append(line.strip())
        except KeyError:
            # No "option" section, so no dependencies ?
            pass

        return requirements
    except (configparser.MissingSectionHeaderError, configparser.ParsingError):
        # Not a setup.cfg file
        pass

    # Is file a pyproject.toml file ?
    try:
        config = tomllib.loads("\n".join(lines))
        for line in config.get("project", {}).get("dependencies", []):
            requirements.append(line)
        for line in config["project"].get("optional-dependencies", {}).values():
            requirements.extend(line)

        return requirements
    except tomllib.TOMLDecodeError:
        # Not a pyproject.toml file
        pass

    # Last solution, a simple requirements.txt file
    for line in lines:
        if len(line.strip()) != 0 and line.strip()[0] != "#":
            requirements.extend([line])

    return requirements


def parse_files(files: list) -> list:
    if len(files) == 0:
        lines = []
        line = input()
        try:
            while line != "":
                lines.append(line)
                line = input()
        except EOFError:
            pass
        return parse_file(lines)
    else:
        requirements = []
        for filename in files:
            with open(filename) as file_handler:
                requirements.extend(parse_file(file_handler.read().splitlines()))
        return sorted(requirements, key=lambda x: x.lower())

    return []


def get_cache_path():
    home_path = Path.home().joinpath(".packmon")
    os.makedirs(home_path, exist_ok=True)
    return os.path.join(home_path, "packages.json")


def clear_cache():
    try:
        os.remove(get_cache_path())
    except FileNotFoundError:
        pass


def load_cache():
    try:
        with open(get_cache_path()) as file_handler:
            packages = {}
            for package in json.load(file_handler):
                new_package = Package(
                    name=package["name"],
                    status=package["status"],
                    license=package["license"],
                    vulnerabilities=package["vulnerabilities"],
                    last_update=datetime.strptime(
                        package["last_update"], "%Y-%m-%d %H:%M:%S"
                    ),
                )
                for release in package.get("releases", []):
                    new_package.releases.append(
                        {
                            "version": Version(release["version"]),
                            "release_date": release["release_date"],
                        }
                    )
                packages[package["name"]] = new_package
            return packages
    except FileNotFoundError:
        return {}


def save_cache(packages: dict) -> None:
    with open(get_cache_path(), "wt") as file_handler:
        json.dump([package.to_json() for _, package in packages.items()], file_handler)


def get_datas_from_pypi(package_name: str) -> Package:
    datas = None
    request = Request(
        f"https://pypi.org/pypi/{package_name}/json",
        headers={"User-Agent": USER_AGENT},
    )
    result = urlopen(request)
    if result.status == 200:
        datas = json.loads(result.read())
        name = datas["info"]["name"]
        status = "unknown"
        if datas["info"].get("license", "") != "":
            license = datas["info"]["license"] or "unknown"
        else:
            license = "unknown"
        for classifier in datas["info"]["classifiers"]:
            if classifier.startswith("Development Status"):
                status = classifier.split()[-1].strip()
            elif classifier.startswith("License"):
                license = classifier.split(" ::")[-1].strip()
        vulnerabilities = len(datas.get("vulnerabilities", []))
        releases = sorted(
            [
                {
                    "version": Version(version),
                    "release_date": datas["releases"][version][0]["upload_time"],
                }
                for version in datas["releases"]
                if len(datas["releases"][version]) > 0
            ],
            key=lambda x: x["version"],
        )

        return Package(
            name=name,
            status=status,
            license=license,
            vulnerabilities=vulnerabilities,
            releases=releases,
        )

    return None


def update_package(packages, package, force=False):
    if force:
        packages[package] = get_datas_from_pypi(package)
    else:
        # TODO: Manage cache timeout
        if package not in packages:
            packages[package] = get_datas_from_pypi(package)


def display_dependencies(dependencies):
    HEADER = "\033[96m"
    NORMAL = "\033[0m"

    # Computing columns sizes
    terminal_width = os.get_terminal_size().columns
    headers = [
        Header("name", "name", 5, 5, 0, False),
        Header("status", "status", 7, 7, 1, False),
        Header("license", "license", 8, 8, 2, False),
        Header("version", "version", 8, 8, 3, False),
        Header("next_version", "next version", 13, 13, 4, False),
        Header("last_version", "last version", 13, 13, 5, False),
        Header("last_date", "last release", 13, 13, 6, False),
        Header("vulnerabilities", "vulnerabilities", 15, 15, 7, False),
    ]
    for header in headers:
        for dependency in dependencies:
            if len(getattr(dependency, header.slug)) >= header.size:
                header.size = len(getattr(dependency, header.slug)) + 1
    if sum([h.min_size for h in headers]) < terminal_width:
        while sum([h.size for h in headers]) > terminal_width:
            largest = sorted(
                filter(lambda h: not h.reduced, headers),
                key=lambda h: h.size,
                reverse=True,
            )[0].index
            # Reduce largest column
            headers[largest].size -= min(
                sum([h.size for h in headers]) - terminal_width,
                headers[largest].size - headers[largest].min_size,
            )
            headers[largest].reduced = True

    # Printing values
    def display_value(value: str, header: Header, level: str = "") -> str:
        if header.reduced and len(value) > header.size - 1:
            result = value[: (header.size - 2)] + "\u2026"
        else:
            result = value
        return f"{level}{result: <{header.size}}{NORMAL}"

    # Specific for windows in order to enable coloration by escape sequences
    os.system("")

    line = HEADER
    for header in headers:
        line += f"{header.name: <{header.size}}"
    print(f"{line}{NORMAL}")
    for dependency in dependencies:
        line = display_value(dependency.name, headers[0])
        line += display_value(
            dependency.status,
            headers[1],
            dependency.status_level,
        )
        line += display_value(dependency.license, headers[2])
        line += display_value(
            dependency.version,
            headers[3],
            dependency.version_level,
        )
        line += display_value(dependency.next_version, headers[4])
        line += display_value(dependency.last_version, headers[5])
        line += display_value(
            dependency.last_date,
            headers[6],
            dependency.release_level,
        )
        line += display_value(
            dependency.vulnerabilities,
            headers[7],
            dependency.vulnerabilities_level,
        )
        print(line)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Package Monitoring to increase quality and kill obsolescence."
    )
    # version
    parser.add_argument(
        "--version",
        action="store_const",
        const=True,
        default=False,
        help="output version information and exit",
    )
    # requirement file(s)
    parser.add_argument(
        "FILE",
        nargs="*",
        help="file(s) to analyse; if no file given, read standard input",
    )
    # clear cache
    parser.add_argument(
        "--clear-cache",
        action="store_const",
        const=True,
        default=False,
        help="delete cache file before analyse",
    )
    # update cache
    parser.add_argument(
        "--update-cache",
        action="store_const",
        const=True,
        default=False,
        help="update information of each package in cache and exit",
    )
    # no cache
    parser.add_argument(
        "--no-cache",
        action="store_const",
        const=True,
        default=False,
        help=(
            "does not use cache (each package needs a request to pypi to retrieve its "
            "informations)"
        ),
    )
    # no update
    parser.add_argument(
        "--no-update",
        action="store_const",
        const=True,
        default=False,
        help=(
            "does not try to update package informations from pypi, even if it's old"
        ),
    )
    # delay (in days)
    parser.add_argument(
        "--delay",
        default=360,
        type=int,
        help=(
            "delay, in days, after which last release is considered obsolete "
            "(default to 360)"
        ),
    )
    # Quiet output
    parser.add_argument(
        "--quiet",
        action="store_const",
        const=True,
        default=False,
        help="no output (doesn't work with version option)",
    )
    # CI output : exit with -1
    parser.add_argument(
        "--ci",
        action="store_const",
        const=True,
        default=False,
        help="if any package has a problem exit with -1 error code",
    )
    args = parser.parse_args()
    if args.version:
        print(f"Version {VERSION}")
    elif args.update_cache:
        packages = load_cache()
        size = len(packages)
        for idx, package in enumerate(packages):
            if not args.quiet:
                print(f"\r{idx+1}/{size}", end="", file=sys.stderr, flush=True)
            update_package(packages, package, True)
        if not args.quiet:
            print()
        save_cache(packages)
    else:
        if args.clear_cache:
            clear_cache()

        global RELEASE_LIMIT
        RELEASE_LIMIT = args.delay

        # Search for requirements
        requirements = parse_requirements(parse_files(args.FILE))

        # For each package, update its versions if necessary
        if not args.no_cache:
            packages = load_cache()
        else:
            packages = {}
        size = len(requirements)
        if not args.no_update:
            for idx, requirement in enumerate(requirements):
                if not args.quiet:
                    print(f"\r{idx+1}/{size}", end="", file=sys.stderr, flush=True)
                update_package(packages, requirement.name)
            if not args.quiet:
                print()
            if not args.no_cache:
                save_cache(packages)

        # Set dependencies
        dependencies = []
        for requirement in requirements:
            dependencies.append(
                Dependency(
                    requirement.name,
                    packages.get(requirement.name, Package(requirement.name)),
                    requirement.constraints,
                )
            )

        if not args.quiet:
            display_dependencies(dependencies)

        if args.ci:
            sys.exit(
                max(
                    len(
                        [1 for dependency in dependencies if dependency.is_problematic]
                    ),
                    127,
                )
            )
