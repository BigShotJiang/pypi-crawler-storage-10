import os, shutil, random, json, numpy as np
from sklearn.cluster import MiniBatchKMeans, DBSCAN
from sklearn.metrics.pairwise import cosine_similarity
from .core import console, device_select, progress_bar
from .models import EmbeddingExtractor
from PIL import Image
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import faiss
import torch

# ================================================================
# CleanFrame (Scalable Version)
# ================================================================

class CleanFrame:
    def __init__(self, path, model="clip", cluster="kmeans", n_clusters=5,
                 device="auto", batch_size=64, eps=0.5, min_samples=5,
                 threshold=0.95, cache=True):

        self.path = path
        self.model = model.lower()
        self.cluster_method = cluster.lower()
        self.n_clusters = n_clusters
        self.eps = eps
        self.min_samples = min_samples
        self.batch_size = batch_size
        self.threshold = threshold
        self.cache = cache

        # Device
        self.device = device_select(device)
        console.print(f"Device: {self.device}")
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True

        # Paths
        self.dataset_name = os.path.basename(os.path.normpath(path))
        base_dir = os.path.dirname(os.path.normpath(path))
        self.cleaned_dir = os.path.join(base_dir, f"{self.dataset_name}_cleaned")
        self.removed_dir = os.path.join(base_dir, f"{self.dataset_name}_removed")
        self.emb_cache_path = os.path.join(base_dir, f"{self.dataset_name}_embeddings.dat")
        self.paths_cache_path = os.path.join(base_dir, f"{self.dataset_name}_paths.json")
        self.report_path = os.path.join(base_dir, f"{self.dataset_name}_report.txt")

        os.makedirs(self.cleaned_dir, exist_ok=True)
        os.makedirs(self.removed_dir, exist_ok=True)

        # Embedding extractor
        self.extractor = EmbeddingExtractor(self.device, self.batch_size)

        # Placeholders
        self.embeddings = None
        self.paths = None
        self.labels = None
        self.cleaned_paths = []
        self.removed_paths = []

    # ================================================================
    # Embedding Management (streamed + cached)
    # ================================================================

    def _get_or_load_embeddings(self):
        """Load cached embeddings or compute + cache incrementally."""
        if self.cache and os.path.exists(self.emb_cache_path) and os.path.exists(self.paths_cache_path):
            console.print(f"Loading cached embeddings from {self.emb_cache_path}")
            mmap = np.memmap(self.emb_cache_path, dtype="float32", mode="r")
            self.embeddings = mmap.reshape(-1, self.extractor.get_dim(self.model))
            with open(self.paths_cache_path, "r") as f:
                self.paths = json.load(f)
            return self.embeddings, self.paths

        console.print("Computing embeddings (streamed)...")
        images_gen = self.extractor.iter_images(self.path)
        n_images = self.extractor.count_images(self.path)
        dim = self.extractor.get_dim(self.model)
        mmap = np.memmap(self.emb_cache_path, dtype="float32", mode="w+", shape=(n_images, dim))

        all_paths, idx = [], 0
        with torch.inference_mode(), progress_bar(f"Embedding ({self.model})", n_images) as p:
            task = p.add_task("Embedding", total=n_images)
            for imgs, batch_paths in images_gen:
                batch_emb = self.extractor.get_embeddings(imgs, self.model)
                mmap[idx:idx + len(batch_emb)] = batch_emb
                idx += len(batch_emb)
                all_paths.extend(batch_paths)
                p.update(task, advance=len(batch_emb))
        mmap.flush()

        with open(self.paths_cache_path, "w") as f:
            json.dump(all_paths, f)
        self.embeddings = np.array(mmap)
        self.paths = all_paths
        console.print(f"Embeddings cached → {self.emb_cache_path}")
        return self.embeddings, self.paths

    # ================================================================
    # Clustering
    # ================================================================

    def _cluster(self, embeddings):
        console.print(f"Clustering using {self.cluster_method.upper()}...")
        if self.cluster_method == "kmeans":
            labels = MiniBatchKMeans(
                n_clusters=self.n_clusters, batch_size=2048,
                random_state=42, n_init="auto"
            ).fit_predict(embeddings)
        elif self.cluster_method == "dbscan":
            labels = DBSCAN(eps=self.eps, min_samples=self.min_samples, n_jobs=-1).fit_predict(embeddings)
        else:
            raise ValueError("Cluster method must be kmeans or dbscan.")
        return labels

    # ================================================================
    # Cleaning (FAISS cosine-based)
    # ================================================================

    def _clean(self, embeddings, paths, labels):
        unique_clusters = [c for c in np.unique(labels) if c != -1]
        kept, removed = [], []

        with progress_bar("Cleaning frames", len(unique_clusters)) as p:
            task = p.add_task("Clean", total=len(unique_clusters))
            for cid in unique_clusters:
                idx = np.where(labels == cid)[0]
                cluster_paths = [paths[i] for i in idx]
                cluster_embs = embeddings[idx]

                if len(cluster_embs) <= 1:
                    kept.extend(cluster_paths)
                    p.update(task, advance=1)
                    continue

                # Normalize and index with FAISS
                cluster_embs = cluster_embs / np.linalg.norm(cluster_embs, axis=1, keepdims=True)
                index = faiss.IndexFlatIP(cluster_embs.shape[1])
                index.add(cluster_embs.astype("float32"))
                sim, _ = index.search(cluster_embs.astype("float32"), 2)
                remove_mask = sim[:, 1] > self.threshold

                for i, path in enumerate(cluster_paths):
                    dest = self.removed_dir if remove_mask[i] else self.cleaned_dir
                    shutil.copy(path, os.path.join(dest, os.path.basename(path)))
                    (removed if remove_mask[i] else kept).append(path)

                p.update(task, advance=1)

        self.cleaned_paths, self.removed_paths = kept, removed
        console.print(f"Kept: {len(kept)}   Removed: {len(removed)}")
        console.print(f"Cleaned output → {self.cleaned_dir}")
        console.print(f"Removed output → {self.removed_dir}")

    # ================================================================
    # Summary and Report
    # ================================================================

    def _summary(self):
        total = len(self.paths)
        kept = len(self.cleaned_paths)
        removed = len(self.removed_paths)
        lines = [
            "CleanFrames Summary",
            "-" * 40,
            f"Model: {self.model}",
            f"Clustering: {self.cluster_method}",
            f"Device: {self.device}",
            f"Threshold: {self.threshold}",
            "-" * 40,
            f"Total frames: {total}",
            f"Kept: {kept} ({(kept/total)*100:.1f}%)",
            f"Removed: {removed} ({(removed/total)*100:.1f}%)",
            "-" * 40,
            f"Cleaned Output: {self.cleaned_dir}",
            f"Removed Output: {self.removed_dir}",
            f"Report: {self.report_path}"
        ]
        console.print("\n".join(lines))
        with open(self.report_path, "w") as f:
            f.write("\n".join(lines))

    # ================================================================
    # Main pipeline
    # ================================================================

    def run(self):
        console.rule(f"[bold green]Running CleanFrame — {self.dataset_name}")
        self.embeddings, self.paths = self._get_or_load_embeddings()
        self.labels = self._cluster(self.embeddings)
        self._clean(self.embeddings, self.paths, self.labels)
        self._summary()
        console.rule("[bold green]Done[/bold green]")

    # ================================================================
    # Visualization
    # ================================================================

    def visualize_clusters(self, method="pca", sample_size=2000, save=False):
        if self.embeddings is None or self.labels is None:
            raise ValueError("Run the pipeline first (cf.run()) before visualizing clusters.")
        
        n = min(sample_size, len(self.embeddings))
        idx = np.random.choice(len(self.embeddings), n, replace=False)
        emb = self.embeddings[idx]
        labels = self.labels[idx]

        reducer = PCA(n_components=2) if method == "pca" else TSNE(n_components=2, random_state=42, perplexity=30)
        reduced = reducer.fit_transform(emb)

        plt.figure(figsize=(8, 6))
        plt.scatter(reduced[:, 0], reduced[:, 1], c=labels, cmap='tab10', s=10)
        plt.title(f"Embedding Visualization ({method.upper()})")
        plt.xlabel("Component 1")
        plt.ylabel("Component 2")

        if save:
            out_path = os.path.join(os.path.dirname(self.report_path), f"{self.dataset_name}_{method}_clusters.png")
            plt.savefig(out_path, dpi=300)
            console.print(f"Visualization saved → {out_path}")
        plt.show()

    # ================================================================
    # Report (Simple Visual Comparison)
    # ================================================================

    def report(self):
        console.print("\nVisual Report (CleanFrames)")
        console.print("-" * 40)
        pairs = []
        if len(self.cleaned_paths) >= 6:
            sample_idx = random.sample(range(len(self.cleaned_paths)), 6)
            for i in range(0, 6, 2):
                pairs.append((self.cleaned_paths[sample_idx[i]], self.cleaned_paths[sample_idx[i+1]]))
        else:
            for i in range(0, len(self.cleaned_paths)-1, 2):
                pairs.append((self.cleaned_paths[i], self.cleaned_paths[i+1]))

        for i, (p1, p2) in enumerate(pairs[:3]):
            idx1, idx2 = self.paths.index(p1), self.paths.index(p2)
            sim = cosine_similarity(self.embeddings[idx1].reshape(1, -1),
                                    self.embeddings[idx2].reshape(1, -1))[0][0]
            img1, img2 = Image.open(p1), Image.open(p2)
            fig, axes = plt.subplots(1, 2, figsize=(6, 3))
            axes[0].imshow(img1); axes[1].imshow(img2)
            for ax in axes: ax.axis("off")
            fig.suptitle(f"Set {i+1} — Similarity: {sim*100:.1f}%", fontsize=12)
            plt.show()