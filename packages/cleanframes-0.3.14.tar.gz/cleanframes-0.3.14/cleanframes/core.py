import os, shutil, random
import numpy as np
import torch
import torch.nn as nn
from torchvision import models, transforms
from timm import create_model
import open_clip
from sklearn.cluster import MiniBatchKMeans, DBSCAN
from sklearn.metrics.pairwise import cosine_similarity
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageFile
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
import faiss
import matplotlib.pyplot as plt

ImageFile.LOAD_TRUNCATED_IMAGES = True
console = Console()

# ============================================================
# Utilities
# ============================================================

def progress_bar(task_name, total):
    return Progress(
        SpinnerColumn(),
        TextColumn(f"{task_name}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    )

def device_select(device="auto"):
    if device == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        elif torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            return torch.device("cpu")
    return torch.device(device)

def iter_images(folder, batch_size=64):
    """Yield batches of (images, paths) from a folder."""
    exts = (".jpg", ".jpeg", ".png")
    files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(exts)]

    def open_image(p):
        try:
            return Image.open(p).convert("RGB"), p
        except:
            return None, None

    for i in range(0, len(files), batch_size):
        batch_paths = files[i:i + batch_size]
        with ThreadPoolExecutor() as ex:
            imgs_paths = list(ex.map(open_image, batch_paths))
        images = [im for im, p in imgs_paths if im is not None]
        paths = [p for im, p in imgs_paths if im is not None]
        yield images, paths

# ============================================================
# CleanFrame (optimized for large datasets)
# ============================================================

class CleanFrame:
    """
    CleanFrame: Large-scale frame deduplication pipeline.
    Features:
      - Streaming image loading (no RAM overload)
      - np.memmap disk caching for embeddings
      - MiniBatchKMeans / DBSCAN clustering
      - FAISS-based fast cosine deduplication
      - Rich console + progress bars
    """

    def __init__(self, path, model="swin", cluster="kmeans", n_clusters=5,
                 device="auto", batch_size=64, eps=0.5, min_samples=5,
                 threshold=0.95, cache=True):

        self.path = path
        self.model_name = model.lower()
        self.cluster_method = cluster.lower()
        self.n_clusters = n_clusters
        self.batch_size = batch_size
        self.eps = eps
        self.min_samples = min_samples
        self.threshold = threshold
        self.cache = cache
        self.device = device_select(device)
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True

        name = os.path.basename(os.path.normpath(path))
        base_dir = os.path.dirname(os.path.normpath(path))
        self.cleaned_dir = os.path.join(base_dir, f"{name}_cleaned")
        self.removed_dir = os.path.join(base_dir, f"{name}_removed")
        self.emb_cache_path = os.path.join(base_dir, f"{name}_{self.model_name}_embeddings.dat")
        self.report_path = os.path.join(base_dir, f"{name}_report.txt")
        self.paths_cache_path = os.path.join(base_dir, f"{name}_paths.npy")

        os.makedirs(self.cleaned_dir, exist_ok=True)
        os.makedirs(self.removed_dir, exist_ok=True)

        self.embeddings = None
        self.paths = None
        self.labels = None
        self.cleaned_paths = []
        self.removed_paths = []

        console.print(f"[bold cyan]Device:[/bold cyan] {self.device}")

    # ============================================================
    # Embedding Extraction (streamed + cached)
    # ============================================================

    def embed_frames(self):
        if self.cache and os.path.exists(self.emb_cache_path) and os.path.exists(self.paths_cache_path):
            console.print(f"Loading cached embeddings from {self.emb_cache_path}")
            mmap = np.memmap(self.emb_cache_path, dtype="float32", mode="r")
            self.embeddings = mmap.reshape(-1, self._embedding_dim())
            self.paths = np.load(self.paths_cache_path, allow_pickle=True).tolist()
            return self.embeddings, self.paths

        # Choose model
        if self.model_name == "resnet":
            model = models.resnet50(pretrained=True)
            model = nn.Sequential(*list(model.children())[:-1]).to(self.device).eval()
            tf = transforms.Compose([
                transforms.Resize((224, 224)), transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
            ])
            def forward(x): return model(x).squeeze().view(x.size(0), -1)
            dim = 2048
        elif self.model_name == "swin":
            model = create_model("swin_tiny_patch4_window7_224", pretrained=True, num_classes=0).to(self.device).eval()
            tf = transforms.Compose([
                transforms.Resize((224, 224)), transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
            ])
            def forward(x): return model(x)
            dim = 768
        elif self.model_name == "clip":
            model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="openai")
            model.to(self.device).eval()
            tf = preprocess
            def forward(x): return model.encode_image(x)
            dim = 512
        else:
            raise ValueError("Model must be one of ['resnet', 'swin', 'clip'].")

        mmap = np.memmap(self.emb_cache_path, dtype="float32", mode="w+", shape=(self._count_images(), dim))
        all_paths, idx = [], 0

        with torch.inference_mode(), progress_bar(f"Embedding ({self.model_name})", self._count_images()) as p:
            task = p.add_task("Embedding", total=self._count_images())
            for imgs, paths in iter_images(self.path, self.batch_size):
                batch = torch.stack([tf(im) for im in imgs]).to(self.device, non_blocking=True)
                out = forward(batch)
                out = out / out.norm(dim=-1, keepdim=True)
                out_np = out.cpu().numpy()
                mmap[idx:idx+len(out_np)] = out_np
                idx += len(out_np)
                all_paths.extend(paths)
                p.update(task, advance=len(out_np))
                torch.cuda.empty_cache()
        mmap.flush()

        np.save(self.paths_cache_path, np.array(all_paths, dtype=object))
        self.embeddings, self.paths = np.array(mmap), all_paths
        console.print(f"Embeddings cached → {self.emb_cache_path}")
        return self.embeddings, self.paths

    def _embedding_dim(self):
        if self.model_name == "resnet": return 2048
        elif self.model_name == "swin": return 768
        elif self.model_name == "clip": return 512
        return 1024

    def _count_images(self):
        return len([f for f in os.listdir(self.path) if f.lower().endswith((".jpg", ".jpeg", ".png"))])

    # ============================================================
    # Clustering (MiniBatchKMeans / DBSCAN)
    # ============================================================

    def cluster_frames(self):
        emb = self.embeddings
        console.print(f"[cyan]Clustering using {self.cluster_method.upper()}...[/cyan]")
        if self.cluster_method == "kmeans":
            self.labels = MiniBatchKMeans(
                n_clusters=self.n_clusters, batch_size=2048, random_state=42, n_init="auto"
            ).fit_predict(emb)
        elif self.cluster_method == "dbscan":
            self.labels = DBSCAN(eps=self.eps, min_samples=self.min_samples, n_jobs=-1).fit_predict(emb)
        else:
            raise ValueError("Cluster method must be 'kmeans' or 'dbscan'.")
        return self.labels

    # ============================================================
    # Cleaning (FAISS cosine deduplication)
    # ============================================================

    def clean_frames(self):
        emb, paths, labels = self.embeddings, self.paths, self.labels
        unique_clusters = [c for c in np.unique(labels) if c != -1]
        kept, removed = [], []

        with progress_bar("Cleaning", len(unique_clusters)) as p:
            task = p.add_task("Clean", total=len(unique_clusters))
            for cid in unique_clusters:
                idx = np.where(labels == cid)[0]
                cluster_paths = [paths[i] for i in idx]
                cluster_embs = emb[idx]
                if len(cluster_embs) <= 1:
                    kept.extend(cluster_paths)
                    p.update(task, advance=1)
                    continue

                # Normalize for cosine
                cluster_embs = cluster_embs / np.linalg.norm(cluster_embs, axis=1, keepdims=True)
                index = faiss.IndexFlatIP(cluster_embs.shape[1])
                index.add(cluster_embs.astype("float32"))
                sim, nbrs = index.search(cluster_embs.astype("float32"), 2)
                to_remove = sim[:, 1] > self.threshold
                for i, path in enumerate(cluster_paths):
                    if to_remove[i]:
                        removed.append(path)
                        shutil.copy(path, os.path.join(self.removed_dir, os.path.basename(path)))
                    else:
                        kept.append(path)
                        shutil.copy(path, os.path.join(self.cleaned_dir, os.path.basename(path)))
                p.update(task, advance=1)

        self.cleaned_paths, self.removed_paths = kept, removed
        console.print(f"[bold cyan]Kept:[/bold cyan] {len(kept)}   [bold red]Removed:[/bold red] {len(removed)}")
        console.print(f"[yellow]Cleaned output → {self.cleaned_dir}")
        console.print(f"[yellow]Removed output → {self.removed_dir}")

    # ============================================================
    # Summary and Reporting
    # ============================================================

    def _summary(self):
        total = len(self.paths)
        kept = len(self.cleaned_paths)
        removed = len(self.removed_paths)
        lines = [
            "CleanFrames Summary", "-" * 40,
            f"Model: {self.model_name}",
            f"Clustering: {self.cluster_method}",
            f"Device: {self.device}",
            f"Threshold: {self.threshold}",
            "-" * 40,
            f"Total frames: {total}",
            f"Kept: {kept} ({(kept/total)*100:.1f}%)",
            f"Removed: {removed} ({(removed/total)*100:.1f}%)",
            "-" * 40,
            f"Cleaned Output: {self.cleaned_dir}",
            f"Removed Output: {self.removed_dir}",
            f"Report: {self.report_path}"
        ]
        console.print("\n".join(lines))
        with open(self.report_path, "w") as f:
            f.write("\n".join(lines))

    # ============================================================
    # Main Pipeline
    # ============================================================

    def run(self):
        console.rule(f"[bold green]Running CleanFrame — {os.path.basename(self.path)}")
        self.embed_frames()
        self.cluster_frames()
        self.clean_frames()
        self._summary()
        console.rule("[bold green]Done[/bold green]")

    # ============================================================
    # Visual Report
    # ============================================================

    def report(self):
        console.print("\nVisual Report")
        console.print("-" * 40)
        pairs = []
        if len(self.cleaned_paths) >= 6:
            sample_idx = random.sample(range(len(self.cleaned_paths)), 6)
            for i in range(0, 6, 2):
                pairs.append((self.cleaned_paths[sample_idx[i]], self.cleaned_paths[sample_idx[i+1]]))
        else:
            for i in range(0, len(self.cleaned_paths)-1, 2):
                pairs.append((self.cleaned_paths[i], self.cleaned_paths[i+1]))

        for i, (p1, p2) in enumerate(pairs[:3]):
            idx1, idx2 = self.paths.index(p1), self.paths.index(p2)
            sim = cosine_similarity(self.embeddings[idx1].reshape(1, -1),
                                    self.embeddings[idx2].reshape(1, -1))[0][0]
            img1, img2 = Image.open(p1), Image.open(p2)
            fig, axes = plt.subplots(1, 2, figsize=(6, 3))
            axes[0].imshow(img1); axes[1].imshow(img2)
            for ax in axes:
                ax.axis("off")
            fig.suptitle(f"Set {i+1} — Similarity: {sim*100:.1f}%", fontsize=12)
            plt.show()

        total = len(self.paths)
        kept = len(self.cleaned_paths)
        removed = len(self.removed_paths)
        console.print(f"\nSummary: {kept} kept ({(kept/total)*100:.1f}%), {removed} removed.")
        console.print(f"Report saved to {self.report_path}")