import os, torch, numpy as np
from torchvision import models, transforms
from timm import create_model
import open_clip
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageFile
from .core import console, progress_bar

ImageFile.LOAD_TRUNCATED_IMAGES = True

class EmbeddingExtractor:
    """
    EmbeddingExtractor
    -------------------
    Streamed, batched feature extraction using:
      • ResNet-50
      • Swin Transformer Tiny
      • CLIP ViT-B/32
    Designed for large datasets (90k+ images).
    """

    def __init__(self, device, batch_size=64):
        self.device = device
        self.batch_size = batch_size
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True

    # ============================================================
    # Public API
    # ============================================================

    def get_embeddings(self, images, model_name):
        """Extract embeddings for a batch of loaded images."""
        model_name = model_name.lower()
        if model_name == "resnet":
            return self._resnet(images)
        elif model_name == "swin":
            return self._swin(images)
        elif model_name == "clip":
            return self._clip(images)
        else:
            raise ValueError("model must be one of ['clip','resnet','swin'].")

    def get_dim(self, model_name):
        """Return the embedding dimension for a given model."""
        if model_name == "resnet": return 2048
        if model_name == "swin": return 768
        if model_name == "clip": return 512
        raise ValueError("Unknown model name.")

    # ============================================================
    # Image streaming utilities
    # ============================================================

    def count_images(self, folder):
        """Count total image files in a folder."""
        return len([f for f in os.listdir(folder)
                    if f.lower().endswith(('.jpg', '.jpeg', '.png'))])

    def iter_images(self, folder):
        """Yield batches of images and paths efficiently."""
        exts = ('.jpg', '.jpeg', '.png')
        files = [os.path.join(folder, f) for f in os.listdir(folder)
                 if f.lower().endswith(exts)]

        def open_image(p):
            try:
                return Image.open(p).convert("RGB"), p
            except:
                return None, None

        for i in range(0, len(files), self.batch_size):
            batch_paths = files[i:i + self.batch_size]
            with ThreadPoolExecutor() as ex:
                imgs_paths = list(ex.map(open_image, batch_paths))
            images = [im for im, p in imgs_paths if im is not None]
            paths = [p for im, p in imgs_paths if im is not None]
            yield images, paths

    # ============================================================
    # ResNet-50
    # ============================================================

    def _resnet(self, images):
        console.print("[cyan]Loading ResNet-50...[/cyan]")
        model = models.resnet50(pretrained=True)
        model = torch.nn.Sequential(*list(model.children())[:-1]).to(self.device).eval()

        tf = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

        feats = []
        with torch.inference_mode(), progress_bar("Embedding (ResNet-50)", len(images)) as p:
            task = p.add_task("Embedding", total=len(images))
            for i in range(0, len(images), self.batch_size):
                batch = torch.stack([tf(im) for im in images[i:i+self.batch_size]]).to(self.device, non_blocking=True)
                out = model(batch).squeeze()
                if out.ndim == 1:
                    out = out.unsqueeze(0)
                out = out.view(out.size(0), -1)
                out = out / out.norm(dim=-1, keepdim=True)
                feats.append(out.cpu().numpy())
                p.update(task, advance=len(batch))
                torch.cuda.empty_cache()
        feats = np.concatenate(feats, axis=0)
        return feats

    # ============================================================
    # Swin Transformer Tiny
    # ============================================================

    def _swin(self, images):
        console.print("[cyan]Loading Swin Transformer Tiny...[/cyan]")
        model = create_model("swin_tiny_patch4_window7_224",
                             pretrained=True, num_classes=0).to(self.device).eval()

        tf = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

        feats = []
        with torch.inference_mode(), progress_bar("Embedding (Swin Tiny)", len(images)) as p:
            task = p.add_task("Embedding", total=len(images))
            for i in range(0, len(images), self.batch_size):
                batch_imgs = [tf(im) for im in images[i:i + self.batch_size]]
                batch = torch.stack(batch_imgs).to(self.device, non_blocking=True)
                out = model(batch)
                out = out / out.norm(dim=-1, keepdim=True)
                feats.append(out.cpu().numpy())
                torch.cuda.empty_cache()
                p.update(task, advance=len(batch_imgs))
        feats = np.concatenate(feats, axis=0)
        return feats

    # ============================================================
    # CLIP ViT-B/32
    # ============================================================

    def _clip(self, images):
        console.print("[cyan]Loading CLIP ViT-B/32...[/cyan]")
        model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="openai")
        model.to(self.device).eval()

        feats = []
        with torch.inference_mode(), progress_bar("Embedding (CLIP ViT-B/32)", len(images)) as p:
            task = p.add_task("Embedding", total=len(images))
            for i in range(0, len(images), self.batch_size):
                batch_imgs = [preprocess(im) for im in images[i:i + self.batch_size]]
                batch = torch.stack(batch_imgs).to(self.device, non_blocking=True)
                out = model.encode_image(batch)
                out = out / out.norm(dim=-1, keepdim=True)
                feats.append(out.cpu().numpy())
                torch.cuda.empty_cache()
                p.update(task, advance=len(batch_imgs))
        feats = np.concatenate(feats, axis=0)
        return feats