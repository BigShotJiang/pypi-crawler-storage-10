# Users - Profile Sharing
- [Definitions](#definitions)
- [Manage user's profile sharing](#manage-users-profile-sharing)
- [Display user's profile sharing](#display-users-profile-sharing)

## Definitions
* [`<UserTypeEntity>`](Collections-of-Users)

## Manage user's profile sharing
```
gam <UserTypeEntity> profile share|shared|unshare|unshared
```
## Display user's profile sharing
```
gam <UserTypeEntity> show profile
```
