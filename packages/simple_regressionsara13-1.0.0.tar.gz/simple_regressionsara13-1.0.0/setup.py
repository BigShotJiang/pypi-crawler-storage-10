from setuptools import setup, find_packages

setup(
    name="simple_regressionsara13",
    version="1.0.0",
    author="sara",
    author_email="your_email@example.com",
    description="A simple linear regression model built from scratch using Python and NumPy.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    packages=find_packages(),
    install_requires=["numpy"],
    python_requires=">=3.7",
)
