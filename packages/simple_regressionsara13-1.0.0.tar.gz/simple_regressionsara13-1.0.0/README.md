# 📈 Simple Regression Package

A minimal linear regression model implemented from scratch using Python and NumPy.

## Installation

```bash
pip install simple_regressionsara13
```
