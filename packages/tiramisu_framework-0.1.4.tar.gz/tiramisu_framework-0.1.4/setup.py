from setuptools import setup, find_packages

setup(
    name="tiramisu-framework",
    version="0.1.4",
    packages=find_packages(),
    install_requires=[
        "openai>=1.12.0",
        "faiss-cpu>=1.7.4",
        "numpy>=1.26.0",
        "fastapi>=0.119.0",
        "uvicorn>=0.27.0",
        "pydantic>=2.6.0",
        "langchain>=0.1.0",
        "python-dotenv>=1.0.0"
    ]
)
