"""
FastAPI Application - Tiramisu API
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import router
from api.routers.conversations import router as conversations_router

# Create FastAPI app
app = FastAPI(
    title="🍰 Tiramisu API",
    description="AI-powered Marketing Consultancy API - Strategic Analysis Framework",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS for Next.js
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],  # Next.js ports
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(conversations_router, tags=["Conversations"])

# Include routes
app.include_router(router, prefix="/api", tags=["Tiramisu"])

@app.get("/")
async def root():
    return {
        "message": "Tiramisu API - Marketing Analysis Framework",
        "docs": "/docs",
        "version": "1.0.0"
    }
