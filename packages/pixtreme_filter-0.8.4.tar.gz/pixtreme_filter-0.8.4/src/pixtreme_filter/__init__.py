"""pixtreme-filter: GPU-accelerated image filtering operations"""

__version__ = "0.8.4"

from .gaussian import GaussianBlur, gaussian_blur, get_gaussian_kernel
from .morphology import (
    create_dilate_kernel,
    create_erode_kernel,
    dilate,
    erode,
    morphology_close,
    morphology_gradient,
    morphology_open,
)

__all__ = [
    "GaussianBlur",
    "gaussian_blur",
    "get_gaussian_kernel",
    "erode",
    "create_erode_kernel",
    "dilate",
    "create_dilate_kernel",
    "morphology_open",
    "morphology_close",
    "morphology_gradient",
]
