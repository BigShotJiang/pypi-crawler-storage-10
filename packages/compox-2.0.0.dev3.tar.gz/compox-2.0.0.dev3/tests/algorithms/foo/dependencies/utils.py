"""
Copyright 2024 TESCAN 3DIM, s.r.o.
All rights reserved
"""


def my_function():
    return "This is Foo!"
