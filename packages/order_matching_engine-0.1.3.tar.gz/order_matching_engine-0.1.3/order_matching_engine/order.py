from enum import Enum
from time import time


class Side(Enum):
    BUY = 0
    SELL = 1


class TimeInForce(Enum):
    GTC = "GTC"  # Good Till Canceled
    IOC = "IOC"  # Immediate Or Cancel
    FOK = "FOK"  # Fill Or Kill


class PegType(Enum):
    NONE = "NONE"
    MIDPOINT = "MIDPOINT"


class Order(object):
    def __init__(
        self,
        order_id: int,
        timestamp: int | None = None,
    ):
        self.order_id = order_id
        self.timestamp = timestamp or int(1e6 * time())

    def __getType__(self):
        return self.__class__


class CancelOrder(Order):
    def __init__(self, order_id: int, timestamp: int | None = None):
        super().__init__(order_id, timestamp)

    def __repr__(self):
        return "Cancel Order: {}.".format(self.order_id)


class MarketOrder(Order):
    def __init__(
        self,
        order_id: int,
        side: Side,
        size: int,
        timestamp: int | None = None,
    ):
        super().__init__(order_id, timestamp)
        self.side = side
        self.size = self.remaining = size

    def __repr__(self):
        return "Market Order: {0} {1} units.".format(
            "BUY" if self.side == Side.BUY else "SELL", self.remaining
        )


class LimitOrder(MarketOrder):
    def __init__(
        self,
        order_id: int,
        side: Side,
        size: int,
        limit_price: int,
        tif_type: TimeInForce = TimeInForce.GTC,
        timestamp: int | None = None,
        peg_type: PegType = PegType.NONE,
    ):
        super().__init__(
            order_id,
            side,
            size,
            timestamp,
        )
        self.limit_price = limit_price
        self.tif_type = tif_type
        self.peg_type = peg_type
        self.price = limit_price  # effective price

    def __lt__(self, other):
        if self.price != other.price:
            if self.side == Side.BUY:
                return self.price > other.price
            else:
                return self.price < other.price

        elif self.remaining != other.remaining:
            return self.remaining > other.remaining
        
        elif self.timestamp != other.timestamp:
            return self.timestamp < other.timestamp
        
        elif self.order_id != other.order_id:
            return self.order_id < other.order_id

    def __repr__(self):
        return "Limit Order: {0} {1} units at {2} ({3}).".format(
            "BUY" if self.side == Side.BUY else "SELL",
            self.remaining,
            self.price,
            self.tif_type.value,
        )

    def set_effective_price(self, new_price: float | None) -> float:
        if new_price is None:
            return self.price
        if self.peg_type == PegType.MIDPOINT:
            if self.side == Side.BUY:
                self.price = min(new_price, self.limit_price)
            else:
                self.price = max(new_price, self.limit_price)
        return self.price
