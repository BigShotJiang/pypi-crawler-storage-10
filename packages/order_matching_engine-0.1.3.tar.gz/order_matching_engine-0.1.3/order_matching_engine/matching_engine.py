from __future__ import annotations

from sortedcontainers import SortedList

from order_matching_engine.order import (
    CancelOrder,
    LimitOrder,
    MarketOrder,
    Order,
    PegType,
    Side,
    TimeInForce,
)
from order_matching_engine.orderbook import Orderbook
from order_matching_engine.quote import Quote
from order_matching_engine.trade import Trade


class MatchingEngine:
    """
    Consumes incoming orders and updates the provided orderbook.
    """

    def __init__(self, orderbook: Orderbook | None = None):
        self.orderbook = orderbook or Orderbook()
        self.trades: list[Trade] = []
        self.midpoint_price: float | None = None

    def process_quote(self, quote: Quote) -> list[Trade]:
        self.midpoint_price = quote.midpoint()
        if self.midpoint_price is None:
            return []

        for order in self.orderbook.bids:
            if order.peg_type == PegType.MIDPOINT:
                order.set_effective_price(self.midpoint_price)

        for order in self.orderbook.asks:
            if order.peg_type == PegType.MIDPOINT:
                order.set_effective_price(self.midpoint_price)

        self.orderbook.bids = SortedList(self.orderbook.bids)
        self.orderbook.asks = SortedList(self.orderbook.asks)
        return self._match_orders()

    def process_order(self, incoming_order: Order) -> list[Trade]:
        if isinstance(incoming_order, CancelOrder):
            self._cancel_order(incoming_order.order_id)
            return []

        if not isinstance(incoming_order, (LimitOrder, MarketOrder)):
            raise TypeError(
                "Unsupported order type: {}".format(type(incoming_order).__name__)
            )

        executed_trades: list[Trade] = []

        if isinstance(incoming_order, LimitOrder):
            if incoming_order.peg_type == PegType.MIDPOINT:
                if self.midpoint_price is not None:
                    incoming_order.set_effective_price(self.midpoint_price)
                else:
                    return []

        if (
            isinstance(incoming_order, LimitOrder)
            and incoming_order.tif_type == TimeInForce.FOK
        ):
            if not self._can_fulfill_limit_order(incoming_order):
                return []

        def should_continue() -> bool:
            if incoming_order.side == Side.BUY:
                if isinstance(incoming_order, LimitOrder):
                    return (
                        len(self.orderbook.asks) > 0
                        and incoming_order.price >= self.orderbook.asks[0].price
                    )
                return len(self.orderbook.asks) > 0
            else:
                if isinstance(incoming_order, LimitOrder):
                    return (
                        len(self.orderbook.bids) > 0
                        and incoming_order.price <= self.orderbook.bids[0].price
                    )
                return len(self.orderbook.bids) > 0

        while should_continue():
            book_order = self._pop_best_opposite(incoming_order.side)

            volume = min(incoming_order.remaining, book_order.remaining)
            incoming_order.remaining -= volume
            book_order.remaining -= volume

            trade = Trade(
                incoming_order.side,
                book_order.price,
                volume,
                incoming_order.order_id,
                book_order.order_id,
                timestamp=incoming_order.timestamp,
            )
            executed_trades.append(trade)
            self.trades.append(trade)

            if book_order.remaining > 0:
                self._requeue_order(book_order)
                break

            if incoming_order.remaining == 0:
                break

        if isinstance(incoming_order, LimitOrder) and incoming_order.remaining > 0:
            if incoming_order.tif_type == TimeInForce.GTC:
                self._add_limit_order(incoming_order)

        return executed_trades

    def _match_orders(self) -> list[Trade]:
        trades: list[Trade] = []
        bids = self.orderbook.bids
        asks = self.orderbook.asks

        while bids and asks:
            best_bid = bids[0]
            best_ask = asks[0]

            if best_bid.price < best_ask.price:
                break

            if best_bid.peg_type == PegType.NONE and best_ask.peg_type == PegType.NONE:
                break

            if (
                best_bid.peg_type == PegType.MIDPOINT
                and best_ask.peg_type != PegType.MIDPOINT
            ):
                aggressor_side = Side.BUY
                incoming_order = best_bid
                book_order = best_ask
                trade_price = best_ask.price
            elif (
                best_ask.peg_type == PegType.MIDPOINT
                and best_bid.peg_type != PegType.MIDPOINT
            ):
                aggressor_side = Side.SELL
                incoming_order = best_ask
                book_order = best_bid
                trade_price = best_bid.price
            else:
                if best_bid.timestamp >= best_ask.timestamp:
                    aggressor_side = Side.BUY
                    incoming_order = best_bid
                    book_order = best_ask
                    trade_price = best_ask.price
                else:
                    aggressor_side = Side.SELL
                    incoming_order = best_ask
                    book_order = best_bid
                    trade_price = best_bid.price

            volume = min(best_bid.remaining, best_ask.remaining)

            best_bid.remaining -= volume
            best_ask.remaining -= volume

            trade = Trade(
                aggressor_side,
                trade_price,
                volume,
                incoming_order.order_id,
                book_order.order_id,
            )
            trades.append(trade)
            self.trades.append(trade)

            if best_bid.remaining == 0:
                bids.pop(0)
            if best_ask.remaining == 0:
                asks.pop(0)

        return trades

    def _cancel_order(self, order_id: int) -> None:
        for container in (self.orderbook.bids, self.orderbook.asks):
            index = self._find_order_index(container, order_id)
            if index is not None:
                del container[index]
                return

    def _pop_best_opposite(self, side: Side) -> LimitOrder:
        if side == Side.BUY:
            return self.orderbook.asks.pop(0)
        return self.orderbook.bids.pop(0)

    def _requeue_order(self, order: LimitOrder) -> None:
        self._place_order_in_book(order)

    def _add_limit_order(self, order: LimitOrder) -> None:
        self._place_order_in_book(order)

    def _find_order_index(self, container: SortedList, order_id: int) -> int | None:
        for idx, order in enumerate(container):
            if order.order_id == order_id:
                return idx
        return None

    def _place_order_in_book(self, order: LimitOrder) -> None:
        if order.side == Side.BUY:
            self.orderbook.bids.add(order)
        else:
            self.orderbook.asks.add(order)

    def _can_fulfill_limit_order(self, order: LimitOrder) -> bool:
        remaining = order.remaining
        if order.side == Side.BUY:
            for book_order in self.orderbook.asks:
                if order.price < book_order.price:
                    break
                remaining -= book_order.remaining
                if remaining <= 0:
                    return True
        else:
            for book_order in self.orderbook.bids:
                if order.price > book_order.price:
                    break
                remaining -= book_order.remaining
                if remaining <= 0:
                    return True
        return False

    def __len__(self) -> int:
        return len(self.orderbook)
