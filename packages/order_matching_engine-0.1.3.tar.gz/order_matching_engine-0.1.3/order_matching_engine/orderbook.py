from __future__ import annotations

from typing import TYPE_CHECKING

from sortedcontainers import SortedList

if TYPE_CHECKING:
    from order_matching_engine.order import Order


class Orderbook(object):
    """
    Represents the orderbook with bids and asks.
    """

    def __init__(self):
        self.bids: SortedList["Order"] = SortedList()
        self.asks: SortedList["Order"] = SortedList()

    def get_bid(self) -> int | None:
        return self.bids[0].price if len(self.bids) > 0 else None

    def get_ask(self) -> int | None:
        return self.asks[0].price if len(self.asks) > 0 else None

    def __repr__(self):
        lines = []
        lines.append("-" * 5 + "OrderBook" + "-" * 5)

        lines.append("\nAsks:")
        asks = self.asks.copy()
        while len(asks) > 0:
            lines.append(str(asks.pop()))

        lines.append("\t" * 3 + "Bids:")
        bids = list(reversed(self.bids.copy()))
        while len(bids) > 0:
            lines.append("\t" * 3 + str(bids.pop()))

        lines.append("-" * 20)
        return "\n".join(lines)

    def __len__(self):
        return len(self.asks) + len(self.bids)
