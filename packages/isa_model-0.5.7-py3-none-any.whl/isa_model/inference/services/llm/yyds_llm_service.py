import logging
from typing import Dict, Any, List, Union, AsyncGenerator, Optional

# (�� OpenAI �
from openai import AsyncOpenAI

from isa_model.inference.services.llm.base_llm_service import BaseLLMService

logger = logging.getLogger(__name__)

class YydsLLMService(BaseLLMService):
    """YYDS LLM service implementation with unified invoke interface and DeepSeek-R1 reasoning support"""
    
    def __init__(self, provider_name: str, model_name: str = "claude-sonnet-4-20250514", **kwargs):
        super().__init__(provider_name, model_name, **kwargs)
        
        # 🧠 检测是否为 reasoning 模型（DeepSeek-R1）
        self.is_reasoning_model = model_name.startswith("deepseek-r1") or "r1" in model_name.lower()
        
        # Get configuration from centralized config manager
        provider_config = self.get_provider_config()
        
        # Initialize AsyncOpenAI client with provider configuration
        try:
            if not provider_config.get("api_key"):
                raise ValueError("YYDS API key not found in provider configuration")
            
            self.client = AsyncOpenAI(
                api_key=provider_config["api_key"],
                base_url=provider_config.get("base_url") or provider_config.get("api_base_url", "https://api.yyds.com/v1"),
                organization=provider_config.get("organization")
            )
            
            logger.info(f"Initialized YydsLLMService with model {self.model_name} (reasoning={self.is_reasoning_model}) at {self.client.base_url}")
            
        except Exception as e:
            logger.error(f"Failed to initialize YYDS client: {e}")
            raise ValueError(f"Failed to initialize YYDS client. Check your API key configuration: {e}") from e
            
        # 🧠 Token usage 添加 reasoning_tokens 支持
        self.last_token_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "reasoning_tokens": 0}
        self.total_token_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "reasoning_tokens": 0, "requests_count": 0}
        
    
    def _create_bound_copy(self) -> 'YydsLLMService':
        """Create a copy of this service for tool binding"""
        bound_service = YydsLLMService(self.provider_name, self.model_name)
        bound_service._bound_tools = self._bound_tools.copy()
        return bound_service
    
    def bind_tools(self, tools: List[Any], **kwargs) -> 'YydsLLMService':
        """
        Bind tools to this LLM service for function calling
        
        Args:
            tools: List of tools (functions, dicts, or LangChain tools)
            **kwargs: Additional arguments for tool binding
            
        Returns:
            New LLM service instance with tools bound
        """
        # Create a copy of this service
        bound_service = self._create_bound_copy()
        
        # Use base class method to bind tools
        bound_service._bound_tools = tools
        
        return bound_service
    
    async def astream(self, input_data: Union[str, List[Dict[str, str]], Any], **kwargs) -> AsyncGenerator[str, None]:
        """
        True streaming method - yields tokens one by one as they arrive
        🧠 支持 DeepSeek-R1 reasoning content streaming

        Args:
            input_data: Same as ainvoke
            **kwargs: Additional parameters (show_reasoning for reasoning models, user_id, etc.)

        Yields:
            Individual tokens as they arrive from the API
            For reasoning models with show_reasoning=True: [思考: ...] + content
        """
        # Extract parameters
        user_id = kwargs.pop('user_id', None)
        show_reasoning = kwargs.pop('show_reasoning', False)

        try:
            # Use adapter manager to prepare messages
            messages = self._prepare_messages(input_data)

            # Prepare request kwargs
            provider_config = self.get_provider_config()
            request_kwargs = {
                "model": self.model_name,
                "messages": messages,
                "stream": True
            }

            # 🧠 Reasoning 模型不支持 temperature 参数
            if not self.is_reasoning_model:
                request_kwargs["temperature"] = provider_config.get("temperature", 0.7)

            # 🧠 Reasoning 模型需要更多 max_tokens
            max_tokens = provider_config.get("max_tokens", 4096 if self.is_reasoning_model else 1024)
            request_kwargs["max_tokens"] = max_tokens

            # Add tools if bound using adapter manager
            tool_schemas = await self._prepare_tools_for_request()
            if tool_schemas:
                request_kwargs["tools"] = tool_schemas
                request_kwargs["tool_choice"] = "auto"

            # Add tools if provided in kwargs (overrides bound tools)
            if 'tools' in kwargs and kwargs['tools']:
                request_kwargs['tools'] = kwargs.pop('tools')
                request_kwargs['tool_choice'] = kwargs.pop('tool_choice', 'auto')
                logger.debug(f"Using tools from kwargs in streaming: {len(request_kwargs['tools'])} tools")
            
            # Stream tokens one by one
            content_chunks = []
            reasoning_chunks = []
            
            try:
                stream = await self.client.chat.completions.create(**request_kwargs)
                async for chunk in stream:
                    # ✅ 修复: 检查 choices 是否为空（流式输出最后可能有空 chunk）
                    if not chunk.choices:
                        continue
                    
                    delta = chunk.choices[0].delta
                    
                    # 🧠 处理 reasoning content（思考过程）
                    # ✅ 修复: reasoning_content 存储在 model_extra 中
                    if show_reasoning and hasattr(delta, 'model_extra') and delta.model_extra:
                        reasoning_content = delta.model_extra.get('reasoning_content')
                        if reasoning_content:
                            reasoning_chunks.append(reasoning_content)
                            yield f"[思考: {reasoning_content}]"
                    
                    # 处理常规 content
                    if delta.content:
                        content_chunks.append(delta.content)
                        yield delta.content
                
                # Track usage after streaming is complete
                full_content = "".join(content_chunks)
                full_reasoning = "".join(reasoning_chunks) if reasoning_chunks else None
                await self._track_streaming_usage(messages, full_content, full_reasoning, user_id=user_id)
                
            except Exception as e:
                logger.error(f"Error in streaming: {e}")
                raise
            
        except Exception as e:
            logger.error(f"Error in astream: {e}")
            raise
    
    async def ainvoke(self, input_data: Union[str, List[Dict[str, str]], Any], **kwargs) -> Union[str, Any]:
        """
        Unified invoke method for all input types
        🧠 支持 DeepSeek-R1 reasoning models with show_reasoning parameter
        """
        # Extract parameters
        user_id = kwargs.pop('user_id', None)
        show_reasoning = kwargs.pop('show_reasoning', False)
        kwargs.pop('task', None)  # Handled internally

        try:
            # Use adapter manager to prepare messages
            messages = self._prepare_messages(input_data)

            # Prepare request kwargs
            provider_config = self.get_provider_config()
            request_kwargs = {
                "model": self.model_name,
                "messages": messages,
            }

            # 🧠 Reasoning 模型不支持 temperature 参数
            if not self.is_reasoning_model:
                request_kwargs["temperature"] = provider_config.get("temperature", 0.7)

            # 🧠 Reasoning 模型需要更多 max_tokens
            max_tokens = provider_config.get("max_tokens", 4096 if self.is_reasoning_model else 1024)
            request_kwargs["max_tokens"] = max_tokens

            # Add tools if bound using adapter manager
            tool_schemas = await self._prepare_tools_for_request()
            if tool_schemas:
                request_kwargs["tools"] = tool_schemas
                request_kwargs["tool_choice"] = "auto"

            # Add tools if provided in kwargs (overrides bound tools)
            if 'tools' in kwargs and kwargs['tools']:
                request_kwargs['tools'] = kwargs.pop('tools')
                request_kwargs['tool_choice'] = kwargs.pop('tool_choice', 'auto')
                logger.debug(f"Using tools from kwargs: {len(request_kwargs['tools'])} tools")
            
            # Handle streaming vs non-streaming
            if self.streaming:
                # TRUE STREAMING MODE - collect all chunks from the stream
                content_chunks = []
                async for token in self.astream(input_data, show_reasoning=show_reasoning, user_id=user_id):
                    content_chunks.append(token)
                content = "".join(content_chunks)
                
                return self._format_response(content, input_data)
            else:
                # Non-streaming mode
                response = await self.client.chat.completions.create(**request_kwargs)
                message = response.choices[0].message
                
                # Update usage tracking (包含 reasoning_tokens)
                if response.usage:
                    self._update_token_usage(response.usage)
                    await self._track_billing(response.usage, user_id=user_id)
                
                # Handle tool calls if present - let adapter process the complete message
                if message.tool_calls:
                    # Pass the complete message object to adapter for proper tool_calls handling
                    return self._format_response(message, input_data)
                
                # 🧠 For reasoning models, handle reasoning_content if show_reasoning=True
                if self.is_reasoning_model and show_reasoning:
                    # ✅ 修复: reasoning_content 存储在 model_extra 中
                    reasoning_content = None
                    if hasattr(message, 'model_extra') and message.model_extra:
                        reasoning_content = message.model_extra.get('reasoning_content')
                    
                    if reasoning_content:
                        # Combine reasoning and content
                        combined_content = f"[思考过程]\n{reasoning_content}\n\n[最终答案]\n{message.content or ''}"
                        return self._format_response(combined_content, input_data)
                
                # Return appropriate format based on input type
                return self._format_response(message.content or "", input_data)
            
        except Exception as e:
            logger.error(f"Error in ainvoke: {e}")
            raise
    
    async def _track_streaming_usage(self, messages: List[Dict[str, str]], content: str, reasoning_content: Optional[str] = None, user_id: Optional[str] = None):
        """Track usage for streaming requests (estimated) - 🧠 支持 reasoning_tokens"""
        # Create a mock usage object for tracking
        class MockUsage:
            def __init__(self, has_reasoning: bool = False):
                self.prompt_tokens = len(str(messages)) // 4  # Rough estimate
                self.completion_tokens = len(content) // 4   # Rough estimate
                self.reasoning_tokens = len(reasoning_content) // 4 if reasoning_content else 0
                self.total_tokens = self.prompt_tokens + self.completion_tokens + self.reasoning_tokens

        usage = MockUsage(has_reasoning=reasoning_content is not None)
        self._update_token_usage(usage)
        await self._track_billing(usage, user_id=user_id)
    
    async def _stream_response(self, kwargs: Dict[str, Any]) -> AsyncGenerator[str, None]:
        """Handle streaming responses - DEPRECATED: Use astream() instead"""
        kwargs["stream"] = True
        
        async def stream_generator():
            try:
                stream = await self.client.chat.completions.create(**kwargs)
                async for chunk in stream:
                    content = chunk.choices[0].delta.content
                    if content:
                        yield content
            except Exception as e:
                logger.error(f"Error in streaming: {e}")
                raise
        
        return stream_generator()
    
    
    def _update_token_usage(self, usage):
        """Update token usage statistics - 🧠 支持 reasoning_tokens"""
        # Extract reasoning_tokens if available (for reasoning models like DeepSeek-R1)
        # ✅ 修复: 确保 reasoning_tokens 始终是整数，即使 API 不返回
        reasoning_tokens = getattr(usage, 'reasoning_tokens', None)
        if reasoning_tokens is None:
            reasoning_tokens = 0
        
        self.last_token_usage = {
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
            "reasoning_tokens": reasoning_tokens,  # ✅ 始终为整数
            "total_tokens": usage.total_tokens
        }
        
        # Update total usage
        self.total_token_usage["prompt_tokens"] += self.last_token_usage["prompt_tokens"]
        self.total_token_usage["completion_tokens"] += self.last_token_usage["completion_tokens"]
        self.total_token_usage["reasoning_tokens"] += reasoning_tokens
        self.total_token_usage["total_tokens"] += self.last_token_usage["total_tokens"]
        self.total_token_usage["requests_count"] += 1
    
    async def _track_billing(self, usage, user_id: Optional[str] = None):
        """Track billing information using unified billing system"""
        provider_config = self.get_provider_config()
        await self._track_llm_usage(
            user_id=user_id or "anonymous",
            operation="chat",
            input_tokens=usage.prompt_tokens,
            output_tokens=usage.completion_tokens,
            metadata={
                "temperature": provider_config.get("temperature", 0.7),
                "max_tokens": provider_config.get("max_tokens", 1024)
            }
        )
    
    def get_token_usage(self) -> Dict[str, Any]:
        """Get total token usage statistics"""
        return self.total_token_usage
    
    def get_last_token_usage(self) -> Dict[str, int]:
        """Get token usage from last request"""
        return self.last_token_usage
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the current model - 🧠 包含 reasoning 模型信息"""
        provider_config = self.get_provider_config()
        
        # Base info
        info = {
            "name": self.model_name,
            "max_tokens": provider_config.get("max_tokens", 4096 if self.is_reasoning_model else 1024),
            "supports_streaming": True,
            "supports_functions": True,
            "is_reasoning_model": self.is_reasoning_model,
            "provider": "yyds"
        }
        
        # 🧠 Add reasoning-specific info if applicable
        if self.is_reasoning_model:
            info["supports_reasoning"] = True
            info["reasoning_capabilities"] = ["step-by-step", "chain-of-thought", "deep-thinking"]
            info["pricing"] = {
                "input_tokens_per_1k": 0.55,  # DeepSeek-R1 pricing
                "output_tokens_per_1k": 2.19,
                "reasoning_tokens_per_1k": 0.55,  # Reasoning tokens charged at input rate
                "currency": "USD"
            }
        else:
            info["pricing"] = {
                "input_tokens_per_1k": 0.0045,
                "output_tokens_per_1k": 0.0225,
                "currency": "USD"
            }
        
        return info
    
    async def chat(
        self,
        input_data: Union[str, List[Dict[str, str]], Any],
        max_tokens: Optional[int] = None,
        show_reasoning: bool = False
    ) -> Dict[str, Any]:
        """
        Chat method that wraps ainvoke for compatibility with base class
        🧠 支持 DeepSeek-R1 reasoning models with show_reasoning parameter
        
        Args:
            input_data: Input messages
            max_tokens: Maximum tokens to generate
            show_reasoning: Whether to show reasoning process (for reasoning models)
            
        Returns:
            Dict containing chat response with properly formatted message object
        """
        try:
            # Call ainvoke and get the response (already processed by adapter)
            response = await self.ainvoke(input_data, show_reasoning=show_reasoning)
            
            # Return the response as-is (adapter already formatted it correctly)
            # For LangChain inputs, this will be an AIMessage object
            # For standard inputs, this will be a string
            return {
                "message": response,  # Use "message" to preserve object type
                "success": True,
                "metadata": {
                    "model": self.model_name,
                    "provider": self.provider_name,
                    "is_reasoning_model": self.is_reasoning_model,
                    "show_reasoning": show_reasoning if self.is_reasoning_model else None,
                    "max_tokens": max_tokens or self.max_tokens,
                    "token_usage": self.get_last_token_usage()
                }
            }
        except Exception as e:
            logger.error(f"Chat method failed: {e}")
            return {
                "message": None,
                "success": False,
                "error": str(e),
                "metadata": {
                    "model": self.model_name,
                    "provider": self.provider_name
                }
            }
        
    async def close(self):
        """Close the backend client"""
        await self.client.close()