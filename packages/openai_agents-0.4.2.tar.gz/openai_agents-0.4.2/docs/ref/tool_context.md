# `Tool Context`

::: agents.tool_context
