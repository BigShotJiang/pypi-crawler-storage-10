# `Streaming events`

::: agents.stream_events
