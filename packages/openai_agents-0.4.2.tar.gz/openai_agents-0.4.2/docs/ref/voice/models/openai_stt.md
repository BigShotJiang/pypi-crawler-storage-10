# `OpenAI STT`

::: agents.voice.models.openai_stt
