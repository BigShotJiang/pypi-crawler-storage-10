# DoList TUI Redesign Plan

## Overview
Complete redesign of the TUI with vim-like navigation, search, command mode, and improved UX.

## Design Principles
- **Keyboard-first**: All actions accessible via keyboard
- **Vim-like**: Familiar `/` for search, `:` for commands
- **Focused**: Task table is primary focus, filters are overlay-based
- **Live**: Auto-refresh, live search filtering
- **Stateful**: Preserve filters, sorting, selection across refreshes

---

## Deliverable Tasks

### Task 1: Basic Layout Restructure ✅ Foundation
**Goal**: Reorganize TUI to focus on task table, remove visible filter inputs

**Changes**:
- Remove current filter input widgets (search, tag, status selects)
- Make DataTable the primary, auto-focused widget on mount
- Move action buttons to bottom bar (horizontal layout)
- Add placeholder for status toggle buttons at top (empty for now)
- Ensure DataTable receives focus by default

**Files**: `dolist/tui.py`
**Lines affected**: ~50 lines
**Testing**: TUI opens with table focused, arrow keys navigate tasks

---

### Task 2: Status Filter Toggle Buttons
**Goal**: Add clickable status filter buttons at top of TUI

**Changes**:
- Create horizontal container at top with status buttons
- Buttons: `[New]` `[In Progress]` `[Done]` `[Cancel]` `[Post]`
- Implement multi-select toggle behavior (independent on/off)
- Visual indicator when active (variant change: primary/default)
- Store active statuses in app state
- Update task query when status filters change
- Refresh table when filters change

**Files**: `dolist/tui.py`
**Lines affected**: ~80 lines
**State variables**: `self.active_status_filters = set()`
**Testing**: Click status buttons, verify filtering works, multiple selections allowed

---

### Task 3: Search Overlay with `/` Key
**Goal**: Implement vim-like search overlay triggered by `/`

**Changes**:
- Create `SearchOverlay` modal screen component
- Bind `/` key to open search overlay
- Overlay appears at bottom of screen (vim-like)
- Input field with live filtering as user types
- Parse search syntax:
  - `/text` → filter by task name containing "text"
  - `/tag=work,personal` → filter by tags (OR logic)
  - `/status=new,done` → filter by status (updates toggle buttons too)
  - Combined: `/tag=work test` → tag=work AND name contains "test"
- ESC closes overlay and clears search
- Enter closes overlay and keeps search active
- Store search filter in app state
- Refresh table with filtered results

**Files**: `dolist/tui.py`
**Lines affected**: ~120 lines
**State variables**: `self.search_filter = {}` (dict with tag, status, text keys)
**Testing**: Press `/`, type search, verify live filtering, test all syntax patterns

---

### Task 4: Command Mode Overlay with `:`
**Goal**: Implement command mode overlay, integrate with command palette

**Changes**:
- Use existing Textual command palette (triggered by `Ctrl+P`)
- Also bind `:` key to open command palette
- Add custom commands to palette:
  - `sort-name-asc` → Sort by name ascending
  - `sort-name-desc` → Sort by name descending
  - `sort-created-asc` → Sort by created date ascending
  - `sort-created-desc` → Sort by created date descending
  - `sort-status-asc` → Sort by status ascending
  - `sort-status-desc` → Sort by status descending
  - `refresh` → Manual refresh
  - `quit` → Exit TUI
- Alternatively, create custom `CommandOverlay` if palette doesn't fit
- Store current sort in app state
- Apply sort to table data
- Refresh table with sorted results

**Files**: `dolist/tui.py`
**Lines affected**: ~100 lines
**State variables**: `self.sort_column = None`, `self.sort_direction = None`
**Testing**: Press `:`, type commands, verify sorting works, test all sort options

---

### Task 5: Column Header Sorting
**Goal**: Make table column headers clickable for sorting

**Changes**:
- Update DataTable column definitions to be clickable
- Implement `on_data_table_header_selected` event handler
- Click header once → sort ascending
- Click header again → sort descending
- Add visual indicator (▲ ▼) to sorted column header
- Store sort state (column, direction)
- Update table data with sorted results
- Coordinate with command mode sorting (use same state)

**Files**: `dolist/tui.py`
**Lines affected**: ~60 lines
**State variables**: Reuse `self.sort_column` and `self.sort_direction`
**Testing**: Click headers, verify sort toggles, check visual indicators

---

### Task 6: Auto-Refresh with Toggle
**Goal**: Implement auto-refresh timer with on/off toggle

**Changes**:
- Add "Auto-Refresh" toggle button to bottom bar
- Read `autorefresh_interval` from CONFIG
- Use Textual's `set_interval()` to create timer
- When enabled, refresh every N seconds
- Show visual indicator when auto-refresh is ON (button variant)
- Allow user to toggle on/off
- Store toggle state in app instance
- On refresh, preserve all state (filters, sorting, scroll position)

**Files**: `dolist/tui.py`
**Lines affected**: ~80 lines
**State variables**: `self.autorefresh_enabled = False`, `self.autorefresh_timer = None`
**Testing**: Enable auto-refresh, verify timer works, toggle off/on, check state preservation

---

### Task 7: State Preservation on Refresh
**Goal**: Ensure all filters and sorting persist across refreshes

**Changes**:
- Refactor `refresh_tasks()` method to:
  1. Store current scroll position
  2. Store currently selected task ID
  3. Rebuild query with active filters (status, search)
  4. Apply current sort to results
  5. Clear and rebuild table
  6. Restore scroll position
  7. Restore selection (if task still visible)
- Handle case where selected task is filtered out
- Ensure all refresh triggers use this method:
  - Manual refresh button
  - Auto-refresh timer
  - After add/edit/delete operations
  - Status button toggles
  - Search filter changes

**Files**: `dolist/tui.py`
**Lines affected**: ~100 lines
**Refactored method**: `refresh_tasks()` becomes more sophisticated
**Testing**: Set filters, scroll, refresh, verify state preserved

---

### Task 8: Search Button and Key Bindings Update
**Goal**: Add search button, update key bindings documentation

**Changes**:
- Add "Search (/)" button to bottom bar
- Clicking button opens search overlay (same as pressing `/`)
- Update BINDINGS list with all new bindings:
  - `/` → Search
  - `:` → Command mode
  - `Ctrl+Q` → Quit
  - `a` → Add task
  - `r` → Refresh
  - `Enter` → Edit selected task
- Update bottom bar button labels to show shortcuts
- Add footer hints for key bindings

**Files**: `dolist/tui.py`
**Lines affected**: ~40 lines
**Testing**: Click search button, verify all keyboard shortcuts work

---

### Task 9: Integration Testing and Bug Fixes
**Goal**: Test all features together, fix integration issues

**Changes**:
- Test workflow: Start TUI → filter by status → search → sort → auto-refresh → edit task
- Verify state preservation works in all scenarios
- Fix any race conditions with auto-refresh
- Ensure search syntax edge cases work
- Test with empty database
- Test with large dataset (100+ tasks)
- Verify no memory leaks from timers
- Check that all modals close properly (ESC key)
- Ensure focus returns to table after closing overlays

**Files**: `dolist/tui.py`, possibly others
**Lines affected**: Bug-fix specific
**Testing**: Comprehensive integration testing, edge cases

---

### Task 10: Documentation and Polish
**Goal**: Document new TUI features, add inline help

**Changes**:
- Update README.md with new TUI features:
  - Key bindings table
  - Search syntax examples
  - Command mode commands
  - Auto-refresh configuration
- Add inline help in TUI:
  - Help modal (triggered by `?` key)
  - Shows all key bindings and search syntax
- Add docstrings to new methods
- Update CLAUDE.md with TUI architecture notes
- Add comments to complex state management code

**Files**: `README.md`, `CLAUDE.md`, `dolist/tui.py`
**Lines affected**: ~150 lines across files
**Testing**: Verify documentation accuracy, test help modal

---

## Technical Architecture

### State Management
```python
class DoListApp(App):
    # Filter state
    active_status_filters: set[str] = set()  # e.g., {'new', 'done'}
    search_filter: dict = {}  # e.g., {'tag': ['work'], 'text': 'test'}

    # Sort state
    sort_column: str | None = None  # e.g., 'name', 'created', 'status'
    sort_direction: str = 'asc'  # 'asc' or 'desc'

    # UI state
    autorefresh_enabled: bool = False
    autorefresh_timer: Timer | None = None

    # Scroll state (for preservation)
    last_scroll_y: int = 0
    last_selected_task_id: int | None = None
```

### Query Building Pattern
```python
def build_query(self):
    """Build database query from current filter state."""
    query = self.tasks_table.deleted != True

    # Apply status filters
    if self.active_status_filters:
        query &= self.tasks_table.status.belongs(list(self.active_status_filters))

    # Apply search filters
    if 'text' in self.search_filter:
        query &= self.tasks_table.name.like(f"%{self.search_filter['text']}%")

    if 'tag' in self.search_filter:
        # OR logic for multiple tags
        tag_conditions = [
            self.tasks_table.tag == tag
            for tag in self.search_filter['tag']
        ]
        query &= reduce(lambda a, b: a | b, tag_conditions)

    return query
```

### Sort Application Pattern
```python
def apply_sort(self, rows):
    """Apply current sort to rows."""
    if not self.sort_column:
        return rows

    reverse = self.sort_direction == 'desc'

    if self.sort_column == 'name':
        return sorted(rows, key=lambda r: r.name.lower(), reverse=reverse)
    elif self.sort_column == 'created':
        return sorted(rows, key=lambda r: r.created_on, reverse=reverse)
    elif self.sort_column == 'status':
        return sorted(rows, key=lambda r: r.status, reverse=reverse)

    return rows
```

---

## Search Syntax Parser

### Grammar
```
search_query := term (space term)*
term := text_search | tag_filter | status_filter
text_search := [^=]+ (any text without '=')
tag_filter := "tag=" tag_list
status_filter := "status=" status_list
tag_list := tag ("," tag)*
status_list := status ("," status)*
```

### Examples
- `/test` → `{'text': 'test'}`
- `/tag=work` → `{'tag': ['work']}`
- `/tag=work,personal` → `{'tag': ['work', 'personal']}`
- `/status=new,done` → `{'status': ['new', 'done']}`
- `/tag=work test` → `{'tag': ['work'], 'text': 'test'}`
- `/status=new tag=urgent bug` → `{'status': ['new'], 'tag': ['urgent'], 'text': 'bug'}`

### Parser Implementation
```python
def parse_search(search_text: str) -> dict:
    """Parse search syntax into filter dict."""
    filters = {}
    remaining_text = []

    parts = search_text.strip().split()

    for part in parts:
        if '=' in part:
            key, value = part.split('=', 1)
            if key == 'tag':
                filters['tag'] = value.split(',')
            elif key == 'status':
                filters['status'] = value.split(',')
        else:
            remaining_text.append(part)

    if remaining_text:
        filters['text'] = ' '.join(remaining_text)

    return filters
```

---

## Testing Checklist

### Per-Task Testing
- [ ] Task 1: Table focused, navigation works
- [ ] Task 2: Status buttons toggle, filtering works
- [ ] Task 3: Search overlay opens, all syntax works
- [ ] Task 4: Command mode works, all commands execute
- [ ] Task 5: Column headers sort, indicators show
- [ ] Task 6: Auto-refresh toggles, timer works
- [ ] Task 7: State preserved on all refresh types
- [ ] Task 8: All key bindings work, buttons functional
- [ ] Task 9: Integration scenarios pass
- [ ] Task 10: Documentation complete and accurate

### Integration Testing Scenarios
1. **Filter + Sort + Refresh**: Set status filter → sort by name → auto-refresh → verify preserved
2. **Search + Edit**: Search for task → edit task → verify filter still active
3. **Multi-Status + Search**: Toggle multiple statuses → search text → verify AND logic
4. **Sort + Add Task**: Sort by created → add new task → verify sort reapplied
5. **Auto-refresh + Scroll**: Scroll down → let auto-refresh trigger → verify position preserved

---

## Implementation Order (Priority)

1. **Task 1** (Foundation) - Must be first
2. **Task 2** (Status buttons) - Quick win, immediate value
3. **Task 3** (Search overlay) - Core feature
4. **Task 7** (State preservation) - Critical infrastructure for next tasks
5. **Task 5** (Column sorting) - Quick win
6. **Task 6** (Auto-refresh) - Depends on Task 7
7. **Task 4** (Command mode) - Can use existing palette
8. **Task 8** (Polish buttons/bindings) - Cleanup
9. **Task 9** (Integration testing) - Before release
10. **Task 10** (Documentation) - Final step

---

## Configuration

### Config File Updates
Already added to `config.toml`:
```toml
[tui]
autorefresh_interval = 30  # seconds, 0 to disable
```

---

## Compatibility

### Backward Compatibility
- All existing functionality preserved
- Old keyboard shortcuts still work
- CLI remains unchanged
- Database schema unchanged

### Textual Version
- Requires Textual >= 0.47.0 for command palette
- Check version compatibility in requirements

---

## Success Criteria

✅ TUI launches with table focused
✅ Status toggle buttons filter correctly
✅ `/` opens search, all syntax works
✅ `:` opens command palette
✅ Column headers sort on click
✅ Auto-refresh works and preserves state
✅ All keyboard shortcuts functional
✅ State preserved across all refresh types
✅ Documentation complete
✅ All existing tests pass

---

## Estimated Lines of Code

| Task | LoC | Complexity |
|------|-----|------------|
| Task 1 | ~50 | Low |
| Task 2 | ~80 | Medium |
| Task 3 | ~120 | High |
| Task 4 | ~100 | Medium |
| Task 5 | ~60 | Low |
| Task 6 | ~80 | Medium |
| Task 7 | ~100 | High |
| Task 8 | ~40 | Low |
| Task 9 | Variable | High |
| Task 10 | ~150 | Low |

**Total**: ~780 lines of code changes

---

## Notes

- Use Textual's built-in components where possible (DataTable, Input, Button)
- Leverage reactive properties for state management
- Test on both Linux and macOS (notify-send availability)
- Consider performance with large datasets (1000+ tasks)
- Document any Textual-specific patterns for future maintainers
