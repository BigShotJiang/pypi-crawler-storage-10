"""MCP URL Downloader - A Model Context Protocol server for downloading files from URLs."""

__version__ = "0.1.0"

from mcp_url_downloader.server import main

__all__ = ["main"]
