"""Parrot service helpers."""
