import os
import shutil
import hashlib
import random
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from PIL import Image
import imagehash
import torch
import torch.nn as nn
from torchvision import models, transforms
from transformers import AutoImageProcessor, AutoModel
from timm import create_model
import open_clip
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
from IPython import get_ipython

class CleanFrame:
    """
    =============================================================
    CleanFrame: Professional Image Deduplication and Cleaning Tool
    =============================================================
    Performs progressive frame cleaning in three distinct stages:
        1. MD5 exact duplicates (byte-level identical)
        2. Perceptual hash near-duplicates (visual similarity)
        3. Deep embedding cosine similarity (semantic redundancy)

    Features:
    ----------
    - Real-time progress reporting in terminal
    - Tabular summary report (printed only)
    - Example duplicate sets shown as images (popup or inline)
    - Organized cleaned/removed dataset folder structure

    Folder Structure Created:
    --------------------------
    cleand_dataset/
      ├── cleaned_<embedding_name>_<threshold>/
      ├── cleaned_phash/
      └── removed_set/
          ├── removed_MD5/
          ├── removed_phash/
          └── removed_<embedding_name>_<threshold>/
    """

    def __init__(self, device: str = 'cpu'):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self._ipython_env = get_ipython()

    # --------------------------------------------------------------
    # 1. Embedding Extractors
    # --------------------------------------------------------------

    def ResNetEmbedding(self, image_folder: str):
        """Extract normalized ResNet50 embeddings for all images."""
        model = models.resnet50(pretrained=True)
        model = nn.Sequential(*list(model.children())[:-1]).to(self.device).eval()
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
        embeddings, paths = [], []
        with torch.no_grad():
            for fname in tqdm(os.listdir(image_folder), desc="[ResNet50] Extracting embeddings"):
                if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                    path = os.path.join(image_folder, fname)
                    img = Image.open(path).convert('RGB')
                    x = transform(img).unsqueeze(0).to(self.device)
                    feat = model(x).squeeze().cpu().numpy()
                    feat = feat / np.linalg.norm(feat)
                    embeddings.append(feat)
                    paths.append(path)
        return np.array(embeddings), paths

    def DINOEmbedding(self, image_folder: str):
        """
        Extract normalized DINOv2 (facebook/dinov2-base) embeddings for all images.
        Compatible with CleanFrame's self.device.
        """        
        model_id = "facebook/dinov2-base"
        processor = AutoImageProcessor.from_pretrained(model_id)
        model = AutoModel.from_pretrained(model_id).to(self.device)
        model.eval()

        embeddings, paths = [], []

        with torch.no_grad():
            for fname in tqdm(os.listdir(image_folder), desc="[DINOv2] Extracting embeddings"):
                if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                    path = os.path.join(image_folder, fname)
                    img = Image.open(path).convert("RGB")
                    inputs = processor(images=img, return_tensors="pt").to(self.device)

                    feat = model(**inputs).last_hidden_state.mean(dim=1)
                    feat = feat / feat.norm(dim=-1, keepdim=True)

                    embeddings.append(feat.cpu().numpy().flatten())
                    paths.append(path)

        return np.array(embeddings), paths


    def CLIPEmbedding(self, image_folder: str):
        """
        Extract normalized CLIP (ViT-B/32) embeddings for all images in a folder.
        Compatible with CleanFrame's self.device.
        """
       
        # Load pretrained OpenCLIP model and transform
        model, _, preprocess = open_clip.create_model_and_transforms(
            model_name="ViT-B-32",
            pretrained="openai"
        )
        model.to(self.device).eval()

        embeddings, paths = [], []

        with torch.no_grad():
            for fname in tqdm(os.listdir(image_folder), desc="[CLIP] Extracting embeddings"):
                if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                    path = os.path.join(image_folder, fname)
                    img = Image.open(path).convert("RGB")
                    x = preprocess(img).unsqueeze(0).to(self.device)

                    feat = model.encode_image(x)
                    feat /= feat.norm(dim=-1, keepdim=True)

                    embeddings.append(feat.cpu().numpy().flatten())
                    paths.append(path)

        return np.array(embeddings), paths
    

    def SwinEmbedding(self, image_folder: str):
        """Extract normalized Swin Transformer embeddings."""
        model = create_model('swin_tiny_patch4_window7_224', pretrained=True, num_classes=0)
        model.to(self.device).eval()
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
        embeddings, paths = [], []
        with torch.no_grad():
            for fname in tqdm(os.listdir(image_folder), desc="[Swin] Extracting embeddings"):
                if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                    path = os.path.join(image_folder, fname)
                    img = Image.open(path).convert('RGB')
                    x = transform(img).unsqueeze(0).to(self.device)
                    feat = model(x).squeeze().cpu().numpy()
                    feat = feat / np.linalg.norm(feat)
                    embeddings.append(feat)
                    paths.append(path)
        return np.array(embeddings), paths

    # --------------------------------------------------------------
    # 2. Visualization Helpers
    # --------------------------------------------------------------

    def _show_pair_inline(self, img1, img2, title):
        """Display two images side-by-side inline (for notebooks)."""
        plt.figure(figsize=(6, 3))
        fig, axes = plt.subplots(1, 2, figsize=(6, 3))
        for ax, img, label in zip(axes, [img1, img2], ["A", "B"]):
            ax.imshow(Image.open(img))
            ax.set_title(label)
            ax.axis("off")
        plt.suptitle(title, fontsize=10)
        plt.show()

    def _show_pair_popup(self, img1, img2):
        """Open images in system viewer (for .py scripts)."""
        Image.open(img1).show()
        Image.open(img2).show()

    # --------------------------------------------------------------
    # 3. Cleaning Logic
    # --------------------------------------------------------------

    def cleanframes(
        self,
        path=None,
        paths=None,
        embeddings_list=None,
        threshold=0.95,
        output_root="cleand_dataset",
        embeddings=False,
    ):
        """
        Perform 3-stage frame cleaning and print summary to terminal.

        Usage:
          1. cleaner.cleanframes("/path")
             - Runs hash-only cleaning (MD5 + pHash), no embeddings.
          2. cleaner.cleanframes(path="/path", embeddings=True)
             - Runs full cleaning including CLIP embedding cleaning.
          3. cleaner.cleanframes(paths=..., embeddings_list=[("swin", embeddings)])
             - Runs custom embedding cleaning with user-provided embeddings.

        Parameters:
          path: str (optional). Folder containing images.
          paths: list of str (optional). List of image file paths.
          embeddings_list: list of (str, np.ndarray) tuples (optional). Custom embeddings.
          threshold: float. Embedding similarity threshold.
          output_root: str. Output directory.
          embeddings: bool. If True and embeddings_list is None, compute CLIP embeddings automatically.
        """
        # Gather image paths if only path is provided
        if path is not None and paths is None:
            paths = [os.path.join(path, f) for f in os.listdir(path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

        # Embedding stage logic
        if embeddings_list is not None:
            # Validate user-provided embeddings_list
            if not (isinstance(embeddings_list, list) and len(embeddings_list) > 0 and isinstance(embeddings_list[0], tuple)):
                raise ValueError("embeddings_list must be a list of tuples (name, embeddings).")
        elif embeddings and path is not None:
            # Compute CLIP embeddings automatically
            swin_embeddings, _ = self.SwinEmbedding(path)
            embeddings_list = [("swin", swin_embeddings)]
        else:
            embeddings_list = None

        print("\n===================================================")
        print("     CLEANFRAMES: HASH & EMBEDDING BASED CLEANING")
        print("===================================================\n")

        # Folder structure
        removed_root = os.path.join(output_root, "removed_set")
        os.makedirs(os.path.join(removed_root, "removed_MD5"), exist_ok=True)
        os.makedirs(os.path.join(removed_root, "removed_phash"), exist_ok=True)
        os.makedirs(os.path.join(output_root, "cleaned_phash"), exist_ok=True)

        stats = []

        # --------------------------------------------------
        # STEP 1 — MD5 (Exact Duplicates)
        # --------------------------------------------------
        print("[Step 1] Checking MD5 exact duplicates...")
        md5_set, md5_unique, md5_removed = set(), [], []
        for p in tqdm(paths):
            try:
                h = hashlib.md5(open(p, "rb").read()).hexdigest()
            except Exception as e:
                print(f"Error reading {p}: {e}")
                continue
            if h not in md5_set:
                md5_set.add(h)
                md5_unique.append(p)
            else:
                md5_removed.append(p)
                shutil.copy(p, os.path.join(removed_root, "removed_MD5", os.path.basename(p)))

        print(f"  MD5 filter complete → {len(paths)} → {len(md5_unique)} (removed {len(md5_removed)})")
        stats.append(["MD5", len(paths), len(md5_unique), len(md5_removed)])

        # --------------------------------------------------
        # STEP 2 — pHash (Near Duplicates)
        # --------------------------------------------------
        print("\n[Step 2] Checking perceptual hash near-duplicates...")
        phash_dict, phash_unique, phash_removed, example_pairs = {}, [], [], []
        for p in tqdm(md5_unique):
            try:
                h = imagehash.phash(Image.open(p))
            except Exception:
                continue

            match = None
            for k, hh in phash_dict.items():
                if h - hh < 5:
                    match = k
                    break

            if match:
                phash_removed.append(p)
                example_pairs.append((match, p))
                shutil.copy(p, os.path.join(removed_root, "removed_phash", os.path.basename(p)))
            else:
                phash_dict[p] = h
                phash_unique.append(p)
                shutil.copy(p, os.path.join(output_root, "cleaned_phash", os.path.basename(p)))

        print(f"  pHash filter complete → {len(md5_unique)} → {len(phash_unique)} (removed {len(phash_removed)})")
        stats.append(["pHash", len(md5_unique), len(phash_unique), len(phash_removed)])

        # Show example pairs
        if example_pairs:
            print("\n[Example Near-Duplicate Sets]")
            for a, b in random.sample(example_pairs, min(3, len(example_pairs))):
                title = f"{os.path.basename(a)} ≈ {os.path.basename(b)}"
                print(f"  • {title}")
                if self._ipython_env:
                    self._show_pair_inline(a, b, "Near-Duplicate Example")
                else:
                    self._show_pair_popup(a, b)

        # --------------------------------------------------
        # STEP 3 — Embedding Similarity
        # --------------------------------------------------
        if embeddings_list is not None and isinstance(embeddings_list, list) and len(embeddings_list) > 0 and isinstance(embeddings_list[0], tuple):
            for name, embeddings in embeddings_list:
                print(f"\n[Step 3] Checking embedding similarity ({name})...")

                removed_path = os.path.join(removed_root, f"removed_{name}_{threshold}")
                cleaned_path = os.path.join(output_root, f"cleaned_{name}_{threshold}")
                os.makedirs(removed_path, exist_ok=True)
                os.makedirs(cleaned_path, exist_ok=True)

                kept = [phash_unique[0]]
                kept_idx = [paths.index(phash_unique[0])]
                semantic_removed, semantic_pairs = [], []

                for p in tqdm(phash_unique[1:]):
                    idx = paths.index(p)
                    sims = cosine_similarity(
                        embeddings[idx].reshape(1, -1),
                        np.array(embeddings)[kept_idx]
                    )[0]
                    if np.max(sims) < threshold:
                        kept.append(p)
                        kept_idx.append(idx)
                        shutil.copy(p, os.path.join(cleaned_path, os.path.basename(p)))
                    else:
                        semantic_removed.append(p)
                        semantic_pairs.append((p, kept[np.argmax(sims)]))
                        shutil.copy(p, os.path.join(removed_path, os.path.basename(p)))

                if semantic_pairs:
                    print("\n  [Example Semantic Duplicates]")
                    for a, b in random.sample(semantic_pairs, min(3, len(semantic_pairs))):
                        title = f"{os.path.basename(a)} ≈ {os.path.basename(b)}"
                        print(f"   - {title}")
                        if self._ipython_env:
                            self._show_pair_inline(a, b, "Semantic Duplicate Example")
                        else:
                            self._show_pair_popup(a, b)

                print(f"  {name}: {len(phash_unique)} → {len(kept)} (removed {len(semantic_removed)})")
                stats.append([f"Embedding ({name})", len(phash_unique), len(kept), len(semantic_removed)])

        # --------------------------------------------------
        # Final Report
        # --------------------------------------------------
        print("\n===================================================")
        print("                   CLEANING SUMMARY")
        print("===================================================")
        report = pd.DataFrame(stats, columns=["Stage", "Before", "After", "Removed"])
        report["% Removed"] = ((report["Removed"] / report["Before"]) * 100).round(2)
        print(report.to_string(index=False))
        print("===================================================")
        print(f"Cleaned and removed datasets saved under: {output_root}\n")



        