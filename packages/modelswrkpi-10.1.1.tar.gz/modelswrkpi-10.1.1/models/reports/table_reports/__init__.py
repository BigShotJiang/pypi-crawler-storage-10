from models.reports.table_reports.approval_report import approval_report, approval_report_2
from models.reports.table_reports.bin_report import bin_report
from models.reports.table_reports.affid_report import affid_report
from models.reports.table_reports.mtd_report import mtd_report
from models.reports.table_reports.continuity_report import continuity_report
from models.reports.table_reports.inactive_report import inactive_report
from models.reports.table_reports.impact_reports import impact_report, initials_report
