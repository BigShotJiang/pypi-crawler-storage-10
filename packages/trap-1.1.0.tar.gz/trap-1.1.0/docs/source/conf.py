# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------

project = "TraP"
author = "Timo Millenaar"

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import os
import shutil
import sys
import warnings

sys.path.insert(0, os.path.abspath("."))
import generate_api_rst
import generate_input_reference_rst

sys.path.insert(0, os.path.abspath("../../trap"))
sys.path.insert(0, os.path.abspath("../source"))

import trap

# The full version, including alpha/beta/rc tags
release = version = trap.__version__

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.todo",
    "sphinx.ext.autodoc",
    "sphinx.ext.autosummary",
    "sphinx.ext.intersphinx",
    "sphinx.ext.mathjax",
    "sphinx.ext.viewcode",
    "sphinx.ext.napoleon",
    "sphinx_gallery.gen_gallery",
]


warnings.filterwarnings(
    "ignore", category=RuntimeWarning
)  # Do not report warnings in gallery
sphinx_gallery_conf = {
    "examples_dirs": ["../../examples"],  # path to your example scripts
    "gallery_dirs": "example_gallery",  # path to where to save gallery generated output
    "filename_pattern": "^((?!sgskip).)*$",
    "remove_config_comments": True,  # remove comments like: # sphinx_gallery_thumbnail_number = -1
    "nested_sections": False,
    "matplotlib_animations": True,
}

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = "sphinx_rtd_theme"

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = []


# -- Generate api doc stubs -----------------------------------------------

if os.path.exists("api"):
    shutil.rmtree("api")
os.mkdir("api")
generate_api_rst.gen_api_reference("../../trap", "api")
generate_input_reference_rst.write_argument_rst("input_parameters.rst")

# Warn about broken references.
nitpicky = True

# Populate nitpick_ignore form separate file https://stackoverflow.com/a/30624034
nitpick_ignore = []
for line in open("nitpick-exceptions.txt"):
    if line.strip() == "" or line.startswith("#"):
        continue
    dtype, target = line.split(None, 1)
    target = target.strip()
    nitpick_ignore.append((dtype, target))

autodoc_default_options = {
    "member-order": "bysource",  # Options: alphabetical, groupwise, bysource
    "private-members": False,  # Display private objects (eg. _foo)
    "special-members": False,  # Display special objects (eg. __foo__)
}


# need to assign the names here, otherwise autodoc won't document these classes,
# and will instead just say 'alias of ...'
# after https://github.com/slundberg/shap/blob/6af9e1008702fb0fab939bf2154bbf93dfe84a16/docs/conf.py#L380-L394

# from trap import mymodule
# mymodule.MyClass.__name__ = "MyClass"
