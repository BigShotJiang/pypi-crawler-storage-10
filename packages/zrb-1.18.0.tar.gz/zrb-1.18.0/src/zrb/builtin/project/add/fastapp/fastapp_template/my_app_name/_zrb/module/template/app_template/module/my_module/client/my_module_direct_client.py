from my_app_name.module.my_module.client.my_module_client import MyModuleClient


class MyModuleDirectClient(MyModuleClient):
    pass
