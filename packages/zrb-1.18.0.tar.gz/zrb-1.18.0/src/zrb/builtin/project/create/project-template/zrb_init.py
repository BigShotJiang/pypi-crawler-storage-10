import os

_DIR = os.path.dirname(__file__)
