class HostsResponse(object):
    def __init__(self, address, used):
        self.address = address
        self.used = used
