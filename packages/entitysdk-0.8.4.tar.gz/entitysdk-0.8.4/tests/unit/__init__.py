"""entitysdk unit tests."""
