from enum import Enum
from typing import Literal
from pydantic import BaseModel, Field

from typing_extensions import Annotated, TypeAlias
from typing import Union

class AgentPersonaType(str, Enum):
    FOCUSED_SUBAGENTS = "focused_subagents"

    
class BaseAgentPersona(BaseModel):
    type: AgentPersonaType

# ------------------------------------------------------------
# Focused Subagents Persona
# ------------------------------------------------------------

class FocusedSubagentsPersona(BaseAgentPersona):
    type: Literal[AgentPersonaType.FOCUSED_SUBAGENTS] = AgentPersonaType.FOCUSED_SUBAGENTS
    main_agent_system_prompt: str
    
    class SubagentDefinition(BaseModel):
        name: str
        instructions: str
    
    subagents: list[SubagentDefinition]
    

# ------------------------------------------------------------
# Persona Definition
# ------------------------------------------------------------

PersonaDefinition: TypeAlias = Annotated[
    Union[
        FocusedSubagentsPersona,
    ],
   Field(discriminator="type"),
]