from pydantic import BaseModel

from typing import Literal

from cua_protocol.schemas import BaseAgentCommRequest

# ------------------------------------------------------------
# New Subagents
# ------------------------------------------------------------
class NewSubagent(BaseModel):
    name: str
    persona: str
    initial_message: str

class LaunchSubagentsRequest(BaseAgentCommRequest):
    new_subagents: list[NewSubagent]
    

# ------------------------------------------------------------
# Post Message
# ------------------------------------------------------------

class PostMessageRequest(BaseAgentCommRequest):
    name: str
    message: str

# ------------------------------------------------------------
# Get Subagent
# ------------------------------------------------------------

class GetSubagentsRequest(BaseAgentCommRequest):
    pass

class Message(BaseModel):
    role: Literal["input", "output"]
    text: str

class SubagentRead(BaseModel):
    name: str
    status: Literal["running", "end_turn", "error"]
    messages: list[Message]