import logging
logger = logging.getLogger(__name__)

from sqlalchemy import select

from cua.state import state
from cua.db.database import get_session
from cua.db.models import DB_Step, DB_AgentLoop
from cua.ai.loop import load_steps, checkin, llm_call, get_next_tool_call, run_tool_call, refresh_latest_step, clean_up_context


MAIN_LOOP_ID = 0 # default for main loop

async def run_loop():
    # check if main loop and initial step exists, if not, create them
    await _ensure_main_loop_exists()
    
    # load all steps from main loop
    steps = await load_steps(MAIN_LOOP_ID)
        
    while True:
        # refresh and tidy context
        await refresh_latest_step(steps) # need to refresh latest step since tool calls may have modified it
        await clean_up_context(steps, n_images_to_keep=10)
        
        # get new messages and update persona
        await checkin(steps)
        
        # build and make request
        persona = state.data.last_checkin_response.persona
        request_builder = get_request_builder(persona)
        request, tool_box = await request_builder.build_request(persona, steps)
        steps = await llm_call(steps, request)

        # run tool calls
        async for tool in get_next_tool_call(steps):
            await checkin(steps)
            await run_tool_call(tool, tool_box)
        
       
async def _ensure_main_loop_exists():
    async with get_session() as session:
        # check if loop exists, if not, create it
        result = await session.execute(
            select(DB_AgentLoop)
            .where(DB_AgentLoop.id == MAIN_LOOP_ID))
        loop = result.scalar_one_or_none()
        if loop is None:
            loop = DB_AgentLoop(id=MAIN_LOOP_ID, name="MainLoop")
            session.add(loop)
            await session.commit()
    
        # count steps
        from sqlalchemy import func
        result = await session.execute(
            select(func.count())
            .select_from(DB_Step)
            .where(DB_Step.agent_loop_id == MAIN_LOOP_ID))
        step_count = result.scalar()
        
        # if no steps, create initial step
        if step_count == 0:
            initial_step = DB_Step(agent_loop_id=MAIN_LOOP_ID, sequence=1)
            session.add(initial_step)
            await session.commit()
            
# ------------------------------------------------------------
# Get request builder
# ------------------------------------------------------------

from cua_protocol.persona import AgentPersonaType, PersonaDefinition
from cua.ai.llm_request_builder.base_request_builder import BaseRequestBuilder


from cua.ai.llm_request_builder.focused_subagents_request_builder import FocusedSubagentsRequestBuilder

REQUEST_BUILDERS: dict[AgentPersonaType, BaseRequestBuilder] = {
    AgentPersonaType.FOCUSED_SUBAGENTS: FocusedSubagentsRequestBuilder(),
}

def get_request_builder(persona: PersonaDefinition) -> BaseRequestBuilder:
    return REQUEST_BUILDERS[persona.type]