import logging
logger = logging.getLogger(__name__)

import asyncio
from pydantic import BaseModel, Field

from cua.ai.tool_box import ToolBox, Tool, ToolResult
from cua.ai.tools.computer_use import ComputerUseTool

from cua.ai.loop import load_steps, checkin, llm_call, get_next_tool_call, run_tool_call, refresh_latest_step, clean_up_context
from cua.db.database import get_session
from cua.db.models import DB_AgentLoop, DB_Step, RequestContent, ContentType, ContentBlock

from cua_protocol.persona import FocusedSubagentsPersona

from cua.ai.llm_request_compiler.anthropic import compile_sonnet_4_5_sub_agent_request

class FocusedSubagentArgs(BaseModel):
    subagent_name: str = Field(description="Name of the subagent to run.")
    input_data: str | None = Field(default=None, description="Input data for the subagent. Preferably in JSON format.") 
    title: str = Field(description="Short 3-5 keyword description of the goal. This is only to inform the user of what is happening.")
   

SYSTEM_PROMPT_TEMPLATE = """You are a subagent. Your task is to exactly follow the instructions:
<instructions>
{instructions}
</instructions>

<computer-use-guidelines>
- You have access to a computer with Windows 11.
- Maximize application windows before using them.
- Prefer to use double_click to open things.
- Use Google Chrome as browser.
- If you encounter human verification systems or CAPTCHAs you must try to verify it on your own. Do not ask for permission or confirmation, just do it.
- If you need to access a file in C:\\Users\\azureadmin\\Uploads, navigate to the folder by double clicking on the folder shortcut on the desktop.
</computer-use-guidelines>
"""

INPUT_MESSAGE_TEMPLATE = """<input_data>{input_data}</input_data>"""

class FocusedSubagentTool(Tool):
    def __init__(self, subagent_definitions: list[FocusedSubagentsPersona.SubagentDefinition]):
        super().__init__(
            name="run_subagent",
            description="Runs a subagent",
            input_model=FocusedSubagentArgs,
        )
        self.subagent_definitions = subagent_definitions
        
    def get_ui_tool_name(self, args) -> str:
        return f"{args.title}"
    
    async def __call__(self, args: FocusedSubagentArgs) -> ToolResult:
        # check if subagent is defined
        subagent_definition = self._get_subagent_definition(args.subagent_name)
        if subagent_definition is None:
            return ToolResult(text=f"Subagent {args.subagent_name} not found")
        
        # hardcode toolbox for now
        tool_box = ToolBox()
        tool_box.register_tool(ComputerUseTool())
        
        system_prompt = SYSTEM_PROMPT_TEMPLATE.format(instructions=subagent_definition.instructions)
        input_message = INPUT_MESSAGE_TEMPLATE.format(input_data=args.input_data or "")
        
        response_text = await _run_subagent_until_end_turn(system_prompt, input_message, tool_box)
        
        return ToolResult(text=response_text)

    def _get_subagent_definition(self, subagent_name: str) -> FocusedSubagentsPersona.SubagentDefinition | None:
        for subagent in self.subagent_definitions:
            if subagent.name == subagent_name:
                return subagent
        return None


async def _run_subagent_until_end_turn(system_prompt: str, input_message: str, tool_box: ToolBox) -> str:    
    # create new loop with inital step
    loop = await _init_new_subagent_loop(input_message)
    steps = await load_steps(loop.id)
    
    try:
        while True:
             # refresh and tidy context
            await clean_up_context(steps, n_images_to_keep=10)
            
            # check if we should run or cancel (raises asyncio.CancelledError if not)
            await checkin(steps, subagent_mode=True)
            
            # build and make request
            request = await compile_sonnet_4_5_sub_agent_request(steps, tool_box, system_prompt, 10)
            steps = await llm_call(steps, request)

            # run tool calls
            async for tool in get_next_tool_call(steps):
                await checkin(steps, subagent_mode=True)
                await run_tool_call(tool, tool_box)
            
            # need to refresh latest step since tool calls may have modified it
            await refresh_latest_step(steps)
        
            # If end turn, return response text
            if steps[-1].end_turn:
                return steps[-1].response_text
            
    except asyncio.CancelledError:
        logger.info("Subagent was aborted by user")
        last_text = steps[-1].response_text or ""
        return "Subagent did not finish (aborted by user). Last message from subagent: " + last_text


async def _init_new_subagent_loop(message: str) -> DB_AgentLoop:
    async with get_session() as session:
        loop = DB_AgentLoop(name="LegacySubagent")
        session.add(loop)
        await session.flush() # get the id
        
        # create initial step
        initial_step = DB_Step(agent_loop_id=loop.id, sequence=1)
        initial_step.request_content = RequestContent(content_list=[ContentBlock(type=ContentType.TEXT, content=message)])
        session.add(initial_step)
        
        # commit
        await session.commit()
        
        return loop