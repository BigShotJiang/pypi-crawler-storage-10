import logging
logger = logging.getLogger(__name__)


from typing import Literal
from pydantic import BaseModel, Field

from cua.ai.tool_box import Tool, ToolResult

class Message(BaseModel):
    name: str
    text: str

class NewSubagent(BaseModel):
    name: str
    persona: str
    instructions: str

class SubagentsArgs(BaseModel):
    command: Literal["launch_new_subagents", "send_message", "await_next_response"] = Field(description="The command to execute")
    
    new_subagents: list[NewSubagent] | None = Field(default=None, description="If command=='launch_new_subagents', provide a list of new subagents to launch")
    message: Message | None = Field(default=None, description="If command=='send_message', provide a message to be sent to a subagent")
    

class SubagentRead(BaseModel):
    name: str
    status: Literal["running", "end_turn", "error"]
    last_inbound_message: str | None = None
    last_outbound_message: str | None = None

class WorkerAgentTool(Tool):
    def __init__(self):
        super().__init__(
            name="subagents",
            description="Tool to launch and manage subagents.",
            input_model=SubagentsArgs,
        )
        
        self.subagents: dict[str, SubagentRead] = {}

    def get_ui_tool_name(self, args) -> str:
        return f"Subagents - {args.command}"

    async def __call__(self, args: SubagentsArgs) -> ToolResult:
        match args.command:
            case "launch_new_subagents":
                return self._launch_new_subagents(args)
            case "send_message":
                return self._send_message(args)
            case "await_next_response":
                return self._await_next_response(args)
            case _:
                raise ValueError(f"Invalid command: {args.command}")
    
    def _launch_new_subagents(self, args: SubagentsArgs) -> ToolResult:
        # validate input
        if not args.new_subagents:
            raise ValueError("Error: Argument 'new_subagents' must be provided")
        if args.message:
            raise ValueError("Error: Argument 'message' must be empty when launching new subagents")
        
        for new_subagent in args.new_subagents:
            # create new subagent
            subagent = SubagentRead(name=new_subagent.name, persona=new_subagent.persona, instructions=new_subagent.instructions)
            # launch new subagent
            subagent.launch()
        
        return ToolResult(text="New subagents launched successfully")
    
    def _send_message(self, args: SubagentsArgs) -> ToolResult:
        pass
    
    def _await_next_response(self, args: SubagentsArgs) -> ToolResult:
        # poll server every 30s -> return status of all subagents (simple db query)
        # sync with local state
        # detect delta, and return the delta
        
        
        return ToolResult(text="Next response detected")