from abc import ABC, abstractmethod

from cua_protocol.schemas import LLMRequest, PersonaDefinition

from cua.db.models import DB_Step
from cua.ai.tool_box import ToolBox


class BaseRequestBuilder(ABC): 
    
    @abstractmethod
    async def build_request(
        self, 
        persona: PersonaDefinition,
        steps: list[DB_Step], 
    ) -> tuple[LLMRequest, ToolBox]:
        raise NotImplementedError