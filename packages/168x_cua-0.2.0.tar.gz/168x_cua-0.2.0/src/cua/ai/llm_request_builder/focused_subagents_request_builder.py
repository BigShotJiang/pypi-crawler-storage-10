from cua_protocol.persona import FocusedSubagentsPersona
from cua_protocol.schemas import LLMRequest

from cua.ai.llm_request_builder.base_request_builder import BaseRequestBuilder
from cua.db.models import DB_Step
from cua.ai.tool_box import ToolBox

from cua.ai.tools.computer_use import ComputerUseTool
from cua.ai.tools.focused_subagent import FocusedSubagentTool

from cua.ai.llm_request_compiler.anthropic import compile_sonnet_4_5_main_agent_request

class FocusedSubagentsRequestBuilder(BaseRequestBuilder):
    async def build_request(self, persona: FocusedSubagentsPersona, steps: list[DB_Step]) -> tuple[LLMRequest, ToolBox]:
        # Hardcode toolbox for now
        tool_box = ToolBox()
        tool_box.register_tool(FocusedSubagentTool(persona.subagents))
        tool_box.register_tool(ComputerUseTool())
        
        request = await compile_sonnet_4_5_main_agent_request(steps, tool_box, persona.main_agent_system_prompt, 20)
        
        return request, tool_box