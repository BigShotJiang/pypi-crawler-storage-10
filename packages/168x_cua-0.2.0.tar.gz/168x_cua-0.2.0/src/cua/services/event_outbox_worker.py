import logging
logger = logging.getLogger(__name__)

import asyncio
import httpx
from sqlalchemy import select, delete

from cua_protocol import PostEventsRequest

from cua.config import get_config
from cua.db.database import get_session
from cua.db.models import DB_Event


async def event_outbox_worker():
    """
    Background worker that continuously posts events from the database to the backend.
    
    This worker runs in a polling loop with 0.1s intervals, fetching all pending events,
    posting them to the backend, and deleting successfully sent events.
    
    The worker is robust and handles all exceptions gracefully to ensure it keeps running.
    """
    logger.info("Starting event outbox worker")
    
    while True:
        try:
            await _post_events_cycle()
        except Exception as e:
            logger.warning(f"Error in event outbox worker cycle: {e}", exc_info=True)
        
        try:
            await asyncio.sleep(0.1)
        except Exception as e:
            logger.warning(f"Error sleeping in event outbox worker: {e}", exc_info=True)


async def _post_events_cycle():
    """
    Single cycle of posting events to the backend.
    
    Fetches all pending events, posts them, and deletes successfully sent events.
    """
    config = get_config()
    
    # Get all events from database
    async with get_session() as session:
        result = await session.execute(select(DB_Event))
        db_events = result.scalars().all()
        events = [db_event.event for db_event in db_events]
        event_ids = [db_event.id for db_event in db_events]
    
    # If no events, nothing to do
    if not events:
        return
    
    # Prepare and post request
    request = PostEventsRequest(
        agent_instance_id=config.agent_instance_id,
        secret_key=config.secret_key,
        events=events
    )
    
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(
            url=f"{config.backend_api_base_url}/agent-comm/post-events",
            json=request.model_dump(mode="json")
        )
        response.raise_for_status()
    
    # Delete successfully sent events
    if event_ids:
        async with get_session() as session:
            await session.execute(delete(DB_Event).where(DB_Event.id.in_(event_ids)))
            await session.commit()
        logger.debug(f"Successfully posted and deleted {len(event_ids)} events")

