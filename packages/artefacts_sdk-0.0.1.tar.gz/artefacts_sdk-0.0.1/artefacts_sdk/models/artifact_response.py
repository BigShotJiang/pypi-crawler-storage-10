from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ArtifactResponse")



@_attrs_define
class ArtifactResponse:
    """ 
        Attributes:
            filename (str):
            size (int):
            download_url (str):
     """

    filename: str
    size: int
    download_url: str





    def to_dict(self) -> dict[str, Any]:
        filename = self.filename

        size = self.size

        download_url = self.download_url


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "filename": filename,
            "size": size,
            "download_url": download_url,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        filename = d.pop("filename")

        size = d.pop("size")

        download_url = d.pop("download_url")

        artifact_response = cls(
            filename=filename,
            size=size,
            download_url=download_url,
        )

        return artifact_response

