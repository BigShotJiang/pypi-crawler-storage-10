from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.upload_source_response_upload_urls import UploadSourceResponseUploadUrls





T = TypeVar("T", bound="UploadSourceResponse")



@_attrs_define
class UploadSourceResponse:
    """ 
        Attributes:
            upload_urls (UploadSourceResponseUploadUrls):
            job_id (str):
     """

    upload_urls: UploadSourceResponseUploadUrls
    job_id: str





    def to_dict(self) -> dict[str, Any]:
        from ..models.upload_source_response_upload_urls import UploadSourceResponseUploadUrls
        upload_urls = self.upload_urls.to_dict()

        job_id = self.job_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "upload_urls": upload_urls,
            "job_id": job_id,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.upload_source_response_upload_urls import UploadSourceResponseUploadUrls
        d = dict(src_dict)
        upload_urls = UploadSourceResponseUploadUrls.from_dict(d.pop("upload_urls"))




        job_id = d.pop("job_id")

        upload_source_response = cls(
            upload_urls=upload_urls,
            job_id=job_id,
        )

        return upload_source_response

