"""MCP tools implementation."""
