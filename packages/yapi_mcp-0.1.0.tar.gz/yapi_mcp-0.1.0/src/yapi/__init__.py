"""YApi API client module."""
