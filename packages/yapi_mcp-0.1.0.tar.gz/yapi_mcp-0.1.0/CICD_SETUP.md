# CI/CD 配置说明

本文档说明项目的持续集成和持续部署配置。

## 已添加的文件

### GitHub Actions 工作流

```
.github/workflows/
├── ci.yml           # 主 CI 工作流
├── release.yml      # 发布工作流
└── README.md        # 工作流说明文档
```

### Issue 和 PR 模板

```
.github/
├── ISSUE_TEMPLATE/
│   ├── bug_report.yml          # Bug 报告模板
│   ├── feature_request.yml     # 功能请求模板
│   └── config.yml              # Issue 模板配置
├── PULL_REQUEST_TEMPLATE.md    # PR 模板
├── CODE_OF_CONDUCT.md          # 行为准则
└── dependabot.yml              # Dependabot 配置
```

### 其他文件

```
├── LICENSE                # MIT 许可证
├── CONTRIBUTING.md        # 贡献指南
└── CICD_SETUP.md         # 本文件
```

## 功能特性

### 1. 自动化测试 ✅

- **多 Python 版本**: 3.11, 3.12, 3.13
- **多操作系统**: Ubuntu, Windows, macOS
- **测试覆盖率**: 自动生成并可上传到 Codecov

### 2. 代码质量检查 ✅

- **格式检查**: 使用 ruff format
- **代码检查**: 使用 ruff check
- **服务器验证**: 确保 MCP 工具正确注册

### 3. 依赖管理 ✅

- **Dependabot**: 自动检查依赖更新
- **Python 依赖**: 每周检查
- **GitHub Actions**: 每周检查

### 4. 发布自动化 ✅

- **构建**: 自动构建分发包
- **PyPI 发布**: 配置后可自动发布（当前已注释）

### 5. 社区支持 ✅

- **Issue 模板**: Bug 报告和功能请求
- **PR 模板**: 标准化的 PR 流程
- **贡献指南**: 完整的贡献文档
- **行为准则**: 友好的社区环境

## 快速开始

### 1. 启用 GitHub Actions

推送代码到 GitHub 后，Actions 将自动运行。无需额外配置。

### 2. 更新仓库信息

替换以下文件中的占位符：

**README.md**:
```markdown
- YOUR_USERNAME → 你的 GitHub 用户名
```

**CONTRIBUTING.md**:
```markdown
- YOUR_USERNAME → 你的 GitHub 用户名
```

**.github/ISSUE_TEMPLATE/config.yml**:
```yaml
- YOUR_USERNAME → 你的 GitHub 用户名
```

### 3. 配置 Codecov (可选)

1. 访问 https://codecov.io
2. 使用 GitHub 账号登录
3. 添加你的仓库
4. 复制 token
5. 在 GitHub 仓库设置中添加 Secret: `CODECOV_TOKEN`

### 4. 启用 PyPI 发布 (可选)

编辑 `.github/workflows/release.yml`:

1. 取消注释 `publish-pypi` 作业
2. 在 PyPI 配置 Trusted Publisher:
   - 访问 https://pypi.org/manage/account/publishing/
   - 添加 GitHub Actions 作为 publisher
   - Owner: `YOUR_USERNAME`
   - Repository: `yapi-mcp`
   - Workflow: `release.yml`
   - Environment: `pypi`

## 本地开发工作流

### 提交前检查

```bash
# 1. 运行测试
pytest tests/ -v

# 2. 格式化代码
ruff format src/ tests/

# 3. 检查代码质量
ruff check src/ tests/

# 4. 验证服务器
python validate_server.py
```

### 创建 PR

1. Fork 仓库
2. 创建功能分支
3. 提交更改（遵循 Conventional Commits）
4. 推送并创建 PR
5. 等待 CI 检查通过
6. 请求代码审查

## CI/CD 工作流详情

### CI 触发条件

- 推送到 `main`, `master`, `develop` 分支
- 针对这些分支的 Pull Request

### CI 执行内容

1. **测试矩阵** (9 个组合):
   - Python 3.11 on Ubuntu/Windows/macOS
   - Python 3.12 on Ubuntu/Windows/macOS
   - Python 3.13 on Ubuntu/Windows/macOS

2. **代码质量**:
   - ruff format 检查
   - ruff check 检查

3. **服务器验证**:
   - 导入检查
   - 工具注册验证

### Release 触发条件

- 创建 GitHub Release

### Release 执行内容

1. 构建 Python wheel 和 sdist
2. 上传构建产物
3. (可选) 发布到 PyPI

## 徽章状态

在 README.md 中已添加以下徽章：

- **CI 状态**: 显示最新 CI 运行状态
- **Python 版本**: 显示支持的 Python 版本
- **许可证**: MIT 许可证
- **代码风格**: Ruff

更新仓库 URL 后，徽章将自动显示正确的状态。

## 故障排除

### CI 失败

**测试失败**:
```bash
# 本地复现
pytest tests/ -v --tb=short
```

**格式检查失败**:
```bash
# 自动修复
ruff format src/ tests/
```

**代码检查失败**:
```bash
# 查看具体问题
ruff check src/ tests/

# 自动修复
ruff check --fix src/ tests/
```

### Actions 权限问题

如果 Actions 无法创建 PR 或评论：

1. 进入仓库 Settings
2. 选择 Actions → General
3. 在 "Workflow permissions" 选择 "Read and write permissions"
4. 保存更改

## 最佳实践

1. **频繁提交**: 小步快跑，每个提交专注于单一更改
2. **运行本地检查**: 提交前运行所有检查
3. **及时修复**: CI 失败后立即修复
4. **更新依赖**: 定期查看 Dependabot PR
5. **代码审查**: 所有 PR 都应经过审查

## 维护

### 每月检查

- [ ] 查看 Dependabot PR 并合并安全更新
- [ ] 检查 CI 运行时间，考虑优化
- [ ] 更新文档反映最新变化

### 每季度检查

- [ ] 审查 GitHub Actions 版本
- [ ] 考虑添加新的测试矩阵
- [ ] 评估 CI/CD 效果，收集反馈

## 相关资源

- [GitHub Actions 文档](https://docs.github.com/en/actions)
- [Dependabot 文档](https://docs.github.com/en/code-security/dependabot)
- [Ruff 文档](https://docs.astral.sh/ruff/)
- [pytest 文档](https://docs.pytest.org/)
- [Conventional Commits](https://www.conventionalcommits.org/)

## 支持

如有 CI/CD 相关问题：

1. 查看 `.github/workflows/README.md`
2. 在 GitHub Issues 中搜索
3. 创建新 Issue 并标记为 `ci/cd`

---

**注意**: 首次推送到 GitHub 后，记得更新所有文件中的 `YOUR_USERNAME` 占位符。
