from opm._common import SummaryState
