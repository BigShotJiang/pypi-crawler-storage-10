from opm._common import SummaryConfig
