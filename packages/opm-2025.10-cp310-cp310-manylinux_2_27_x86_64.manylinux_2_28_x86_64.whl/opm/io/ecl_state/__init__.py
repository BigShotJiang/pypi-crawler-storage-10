from opm._common import EclipseState
