from opm._common import OpmLog
