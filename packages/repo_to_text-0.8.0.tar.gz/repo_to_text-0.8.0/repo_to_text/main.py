"""This is the main entry point for the repo_to_text package."""

from repo_to_text.cli.cli import main

if __name__ == '__main__':
    main()
