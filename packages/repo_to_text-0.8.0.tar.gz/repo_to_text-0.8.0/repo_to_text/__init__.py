"""This is the main package for the repo_to_text package."""

__author__ = 'Kirill Markin'
__email__ = 'markinkirill@gmail.com'
