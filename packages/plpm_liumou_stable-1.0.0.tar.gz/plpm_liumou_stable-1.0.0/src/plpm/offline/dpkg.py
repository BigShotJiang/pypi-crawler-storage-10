"""
DPKG包管理器实现，用于Debian-based系统。
"""

import os
import subprocess

from ..core import OfflinePackageManager


class DpkgManager(OfflinePackageManager):
    """DPKG包管理器，用于Debian-based系统。"""
    
    def __init__(self, sudo=False):
        """
        初始化DPKG包管理器。
        
        参数:
            sudo (bool): 是否使用sudo执行特权操作，默认为False
            示例: sudo=True
        """
        super().__init__(sudo)
        self.name = "dpkg"
    
    def is_available(self):
        """
        检查DPKG是否在系统上可用。
        
        返回:
            bool: 如果DPKG可用返回True，否则返回False
        """
        try:
            result = subprocess.run(
                ['which', 'dpkg'], 
                capture_output=True, 
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def install(self, packages):
        """
        使用dpkg安装软件包。
        
        注意: DPKG需要文件路径，而不是包名。此方法主要用于兼容性，
        实际安装应使用install_from_file方法。
        
        参数:
            packages (str|list): 要安装的软件包文件路径或列表
            示例: packages="/tmp/package.deb" 或 packages=["/tmp/pkg1.deb", "/tmp/pkg2.deb"]
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        # DPKG需要文件路径，而不是包名
        # 此方法主要用于兼容性
        # 实际安装应使用install_from_file
        command = ['dpkg', '-i'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def remove(self, packages):
        """
        使用dpkg移除软件包。
        
        参数:
            packages (str|list): 要移除的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 移除成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['dpkg', '-r'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def update(self):
        """
        DPKG没有更新功能。
        
        返回:
            bool: 总是返回True
        """
        return True
    
    def upgrade(self, packages=None):
        """
        DPKG没有升级功能。
        
        参数:
            packages (str|list|None): 此参数被忽略
        
        返回:
            bool: 总是返回True
        """
        return True
    
    def search(self, pattern):
        """
        搜索已安装的软件包。
        
        参数:
            pattern (str): 搜索模式
            示例: pattern="python"
        
        返回:
            list: 包含匹配软件包信息的字典列表
        """
        command = ['dpkg', '-l', pattern]
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.startswith('ii'):
                    parts = line.split()
                    if len(parts) >= 3:
                        packages.append({
                            'name': parts[1],
                            'version': parts[2],
                            'description': ' '.join(parts[3:]) if len(parts) > 3 else ''
                        })
        
        return packages
    
    def info(self, package):
        """
        获取软件包信息。
        
        参数:
            package (str): 软件包名称
            示例: package="python3"
        
        返回:
            dict|None: 软件包信息字典，如果包不存在返回None
        """
        command = ['dpkg', '-s', package]
        result = self._run_command(command)
        
        if result.returncode != 0:
            return None
        
        info = {}
        for line in result.stdout.strip().split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                info[key.strip()] = value.strip()
        
        return info
    
    def list_installed(self):
        """
        列出已安装的软件包。
        
        返回:
            list: 包含已安装软件包信息的字典列表
        """
        command = ['dpkg', '-l']
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.startswith('ii'):
                    parts = line.split()
                    if len(parts) >= 3:
                        packages.append({
                            'name': parts[1],
                            'version': parts[2],
                            'architecture': parts[3] if len(parts) > 3 else '',
                            'description': ' '.join(parts[4:]) if len(parts) > 4 else ''
                        })
        
        return packages
    
    def verify(self, package):
        """
        验证软件包完整性。
        
        参数:
            package (str): 要验证的软件包名称
            示例: package="python3"
        
        返回:
            bool: 验证成功返回True，失败返回False
        """
        command = ['dpkg', '--verify', package]
        result = self._run_command(command)
        # DPKG验证返回0表示包正常，非零表示发现问题
        return result.returncode == 0
    
    def install_from_file(self, file_path):
        """
        从本地文件安装软件包。
        
        参数:
            file_path (str): 软件包文件路径
            示例: file_path="/tmp/python3.deb"
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if not os.path.exists(file_path):
            return False
        
        command = ['dpkg', '-i', file_path]
        result = self._run_command(command)
        return result.returncode == 0