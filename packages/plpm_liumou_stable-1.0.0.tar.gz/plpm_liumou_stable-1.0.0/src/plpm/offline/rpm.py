"""
RPM包管理器实现，用于Red Hat-based系统。
"""

import os
import subprocess

from ..core import OfflinePackageManager


class RpmManager(OfflinePackageManager):
    """RPM包管理器，用于Red Hat-based系统。"""
    
    def __init__(self, sudo=False):
        """
        初始化RPM包管理器。
        
        参数:
            sudo (bool): 是否使用sudo执行特权操作，默认为False
            示例: sudo=True
        """
        super().__init__(sudo)
        self.name = "rpm"
    
    def is_available(self):
        """
        检查RPM是否在系统上可用。
        
        返回:
            bool: 如果RPM可用返回True，否则返回False
        """
        try:
            result = subprocess.run(
                ['which', 'rpm'], 
                capture_output=True, 
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def install(self, packages):
        """
        使用rpm安装软件包。
        
        注意: RPM需要文件路径，而不是包名。此方法主要用于兼容性，
        实际安装应使用install_from_file方法。
        
        参数:
            packages (str|list): 要安装的软件包文件路径或列表
            示例: packages="/tmp/package.rpm" 或 packages=["/tmp/pkg1.rpm", "/tmp/pkg2.rpm"]
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        # RPM需要文件路径，而不是包名
        # 此方法主要用于兼容性
        # 实际安装应使用install_from_file
        command = ['rpm', '-i'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def remove(self, packages):
        """
        使用rpm移除软件包。
        
        参数:
            packages (str|list): 要移除的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 移除成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['rpm', '-e'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def update(self):
        """
        RPM没有更新功能。
        
        返回:
            bool: 总是返回True
        """
        return True
    
    def upgrade(self, packages=None):
        """
        RPM没有升级功能。
        
        参数:
            packages (str|list|None): 此参数被忽略
        
        返回:
            bool: 总是返回True
        """
        return True
    
    def search(self, pattern):
        """
        搜索已安装的软件包。
        
        参数:
            pattern (str): 搜索模式
            示例: pattern="python"
        
        返回:
            list: 包含匹配软件包信息的字典列表
        """
        command = ['rpm', '-qa', pattern]
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            for package_name in result.stdout.strip().split('\n'):
                if package_name:
                    # 获取每个包的详细信息
                    info_cmd = ['rpm', '-qi', package_name]
                    info_result = self._run_command(info_cmd)
                    
                    if info_result.returncode == 0:
                        info = {}
                        for line in info_result.stdout.strip().split('\n'):
                            if ':' in line:
                                key, value = line.split(':', 1)
                                info[key.strip()] = value.strip()
                        
                        packages.append({
                            'name': package_name,
                            'version': info.get('Version', ''),
                            'description': info.get('Summary', '')
                        })
        
        return packages
    
    def info(self, package):
        """
        获取软件包信息。
        
        参数:
            package (str): 软件包名称
            示例: package="python3"
        
        返回:
            dict|None: 软件包信息字典，如果包不存在返回None
        """
        command = ['rpm', '-qi', package]
        result = self._run_command(command)
        
        if result.returncode != 0:
            return None
        
        info = {}
        for line in result.stdout.strip().split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                info[key.strip()] = value.strip()
        
        return info
    
    def list_installed(self):
        """
        列出已安装的软件包。
        
        返回:
            list: 包含已安装软件包信息的字典列表
        """
        command = ['rpm', '-qa', '--queryformat', '%{NAME}\t%{VERSION}\t%{ARCH}\t%{SUMMARY}\n']
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 3:
                        packages.append({
                            'name': parts[0],
                            'version': parts[1],
                            'architecture': parts[2],
                            'description': parts[3] if len(parts) > 3 else ''
                        })
        
        return packages
    
    def verify(self, package):
        """
        验证软件包完整性。
        
        参数:
            package (str): 要验证的软件包名称
            示例: package="python3"
        
        返回:
            bool: 验证成功返回True，失败返回False
        """
        command = ['rpm', '-V', package]
        result = self._run_command(command)
        # RPM验证返回0表示包正常，非零表示发现问题
        return result.returncode == 0
    
    def install_from_file(self, file_path):
        """
        从本地文件安装软件包。
        
        参数:
            file_path (str): 软件包文件路径
            示例: file_path="/tmp/python3.rpm"
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if not os.path.exists(file_path):
            return False
        
        command = ['rpm', '-i', file_path]
        result = self._run_command(command)
        return result.returncode == 0