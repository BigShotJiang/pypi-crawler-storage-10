"""
在线包管理器模块。
"""

from .apt import AptManager
from .yum import YumManager
from .dnf import DnfManager
from .apk import ApkManager

__all__ = ["AptManager", "YumManager", "DnfManager", "ApkManager"]