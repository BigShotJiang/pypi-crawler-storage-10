# plpm_liumou_Stable

<div align="center">

![Python Version](https://img.shields.io/badge/python-3.5+-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Platform](https://img.shields.io/badge/platform-linux-lightgrey.svg)

**plpm_liumou_Stable** - 分离的Linux包管理接口

一个为Linux系统提供分离包管理接口的Python库，分别支持在线和离线包管理器。

[English](#english) | [中文](#中文)

</div>

## 🌟 特性

- 🚀 **分离架构**: 提供独立的在线和离线包管理器接口
- 🔍 **自动检测**: 自动识别当前系统的在线和离线包管理器
- 💻 **Python 3.5+ 兼容**: 支持Python 3.5及更高版本
- 📦 **在线包管理**: 支持apt、yum、dnf、apk等在线包管理器，支持更新和升级操作
- 📁 **离线包管理**: 支持dpkg、rpm等离线包管理器，专注于本地包管理
- 🛡️ **错误处理**: 完善的错误处理和异常管理
- 🧪 **完整测试**: 全面的单元测试覆盖

## 📦 安装

### 从PyPI安装

```bash
pip install plpm_liumou_Stable
```

## 🚀 快速开始

### 基本使用

#### 使用在线包管理器

```python
from plpm import OnlinePackageManager

# 创建在线包管理器实例（自动检测系统在线包管理器）
manager = OnlinePackageManager()

# 检查是否有可用的在线包管理器
if manager.is_manager_available():
    print(f"检测到在线包管理器: {manager.get_manager_name()}")
    
    # 更新包列表
    manager.update()
    
    # 搜索包
    packages = manager.search("python")
    print(f"找到 {len(packages)} 个相关包")
    
    # 列出已安装的包
    installed = manager.list_installed()
    print(f"已安装 {len(installed)} 个包")
    
    # 检查特定包是否已安装
    if manager.installed("python3"):
        print("python3 已安装")
    else:
        print("python3 未安装")
    
    # 系统升级
    manager.upgrade()
else:
    print("未检测到可用的在线包管理器")
```

#### 使用离线包管理器

```python
from plpm import OfflinePackageManager

# 创建离线包管理器实例（自动检测系统离线包管理器）
manager = OfflinePackageManager()

# 检查是否有可用的离线包管理器
if manager.is_manager_available():
    print(f"检测到离线包管理器: {manager.get_manager_name()}")
    
    # 搜索包
    packages = manager.search("python")
    print(f"找到 {len(packages)} 个相关包")
    
    # 列出已安装的包
    installed = manager.list_installed()
    print(f"已安装 {len(installed)} 个包")
    
    # 检查特定包是否已安装
    if manager.installed("python3"):
        print("python3 已安装")
    else:
        print("python3 未安装")
    
    # 注意：离线包管理器不支持update和upgrade操作
    print("离线包管理器不支持系统更新和升级操作")
else:
    print("未检测到可用的离线包管理器")
```

### 使用特定包管理器

```python
from plpm import get_package_manager

# 获取特定的包管理器
apt_manager = get_package_manager(manager_name='apt')

if apt_manager and apt_manager.is_available():
    # 安装包
    apt_manager.install(['curl', 'wget'])
    
    # 获取包信息
    info = apt_manager.info('python3')
    print(info)
```

### 列出可用的包管理器

```python
from plpm import list_available_managers

# 列出系统中可用的包管理器
available = list_available_managers()
print(f"可用的包管理器: {available}")
```

## 📚 API 参考

### OnlinePackageManager 类

专门管理在线包管理器（apt、yum、dnf、apk），支持软件安装、更新、升级等操作。

#### 构造函数

```python
OnlinePackageManager(sudo=False, preferred_manager=None)
```

- `sudo`: 是否使用sudo执行特权操作（默认False）
- `preferred_manager`: 优先使用的在线包管理器名称（'apt', 'yum', 'dnf', 'apk'）

#### 主要方法

| 方法 | 描述 | 返回值 |
|------|------|--------|
| `install(packages)` | 安装包 | bool |
| `remove(packages)` | 移除包 | bool |
| `update()` | 更新包列表 | bool |
| `upgrade(packages=None)` | 升级包 | bool |
| `search(pattern)` | 搜索包 | list |
| `info(package)` | 获取包信息 | dict |
| `list_installed()` | 列出已安装的包 | list |
| `installed(package)` | 检查指定包是否已安装 | bool |
| `clean_cache()` | 清理包缓存 | bool |
| `autoremove()` | 自动移除不需要的包 | bool |

### OfflinePackageManager 类

专门管理离线包管理器（dpkg、rpm），支持软件安装、移除、查询等操作。

#### 构造函数

```python
OfflinePackageManager(sudo=False, preferred_manager=None)
```

- `sudo`: 是否使用sudo执行特权操作（默认False）
- `preferred_manager`: 优先使用的离线包管理器名称（'dpkg', 'rpm'）

#### 主要方法

| 方法 | 描述 | 返回值 |
|------|------|--------|
| `install(packages)` | 安装包 | bool |
| `remove(packages)` | 移除包 | bool |
| `search(pattern)` | 搜索包 | list |
| `info(package)` | 获取包信息 | dict |
| `list_installed()` | 列出已安装的包 | list |
| `installed(package)` | 检查指定包是否已安装 | bool |
| `verify(package)` | 验证包完整性 | bool |
| `install_from_file(file_path)` | 从本地文件安装包 | bool |

**注意**: 离线包管理器不支持 `update()` 和 `upgrade()` 方法，因为这些操作需要网络连接。

### 工具函数

- `get_package_manager(sudo=False, manager_name=None)`: 获取特定包管理器实例
- `list_available_managers()`: 列出可用的包管理器
- `detect_online_package_manager()`: 自动检测在线包管理器
- `detect_offline_package_manager()`: 自动检测离线包管理器

## 🛠️ 支持的包管理器

### 在线包管理器

| 管理器 | 系统 | 命令 |
|--------|------|------|
| **AptManager** | Debian/Ubuntu | apt-get, apt-cache |
| **YumManager** | CentOS/RHEL | yum |
| **DnfManager** | Fedora | dnf |
| **ApkManager** | Alpine Linux | apk |

### 离线包管理器

| 管理器 | 系统 | 命令 |
|--------|------|------|
| **DpkgManager** | Debian/Ubuntu | dpkg |
| **RpmManager** | Red Hat | rpm |

## 💡 示例

### 批量安装软件包

```python
from plpm import UnifiedPackageManager

manager = UnifiedPackageManager()

if manager.is_manager_available():
    # 批量安装开发工具
    packages = ['git', 'vim', 'curl', 'wget']
    if manager.install(packages):
        print("软件包安装成功")
    else:
        print("软件包安装失败")
```

### 系统维护任务

```python
from plpm import UnifiedPackageManager

manager = UnifiedPackageManager(sudo=True)

if manager.is_manager_available():
    # 更新系统
    manager.update()
    manager.upgrade()
    
    # 清理缓存
    manager.clean_cache()
    
    print("系统维护完成")
```

### 包信息查询

```python
from plpm import UnifiedPackageManager

manager = UnifiedPackageManager()

if manager.is_manager_available():
    # 搜索Python相关包
    python_packages = manager.search("python")
    
    for pkg in python_packages[:5]:  # 显示前5个结果
        info = manager.info(pkg['name'])
        print(f"包名: {pkg['name']}")
        print(f"版本: {pkg.get('version', 'N/A')}")
        print(f"描述: {pkg.get('description', 'N/A')}")
        print("-" * 50)
```

## 🏗️ 项目结构

```
plpm_liumou_Stable/
├── src/plpm/
│   ├── __init__.py          # 包入口和主要接口
│   ├── core.py              # 核心抽象类和基础功能
│   ├── online/               # 在线包管理器实现
│   │   ├── __init__.py
│   │   ├── apt.py           # apt包管理器
│   │   ├── yum.py           # yum包管理器
│   │   ├── dnf.py           # dnf包管理器
│   │   └── apk.py           # apk包管理器
│   ├── offline/             # 离线包管理器实现
│   │   ├── __init__.py
│   │   ├── dpkg.py          # dpkg包管理器
│   │   └── rpm.py           # rpm包管理器
│   └── unified.py           # 在线和离线包管理器接口
├── tests/                    # 测试文件
│   ├── __init__.py
│   ├── test_core.py         # 核心功能测试
│   └── test_unified.py      # 在线和离线接口测试
├── pyproject.toml            # 项目配置
└── README.md                # 项目文档
```

## 🧪 测试

### 运行测试

```bash
python3 -m unittest discover tests/ -v
```

### 测试覆盖率

项目包含完整的单元测试，确保代码质量和功能稳定性。

## 🔧 开发

### 代码规范

项目使用以下工具进行代码质量检查：

```bash
# 代码格式化
python3 -m black src/
python3 -m isort src/

# 类型检查
python3 -m mypy src/

# 代码检查
python3 -m flake8 src/
```

### 贡献指南

1. Fork 本仓库
2. 新建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 📊 兼容性

| 组件 | 版本/支持 |
|------|-----------|
| **Python** | 3.5+ |
| **操作系统** | Linux（主流发行版） |
| **包管理器** | apt, yum, dnf, dpkg, rpm |

## 📄 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 👥 作者

**liumou**

- 邮箱: [联系作者](mailto:your-email@example.com)
- Gitee: [@liumou](https://gitee.com/liumou)

## 🙏 致谢

感谢所有为这个项目做出贡献的开发者！

## 📈 版本历史

- **v1.0.0** (当前版本)
  - 初始版本发布
  - 支持在线包管理器 (apt, yum, dnf)
  - 支持离线包管理器 (dpkg, rpm)
  - 自动检测和统一接口
  - 完整的测试覆盖

---

<div align="center">

**如果这个项目对你有帮助，请给它一个 ⭐️！**

</div>