# Auth-Agent Agent SDK (Python)

**Server-side SDK for AI agents to authenticate with Auth-Agent OAuth 2.1**

This SDK is for **AI agent developers** who want their agents to authenticate and access OAuth-protected resources.

> **Note:** If you're a website developer wanting to add "Sign in with Auth-Agent", use [`@auth-agent/client-sdk`](../client-sdk-ts/) instead.

## Installation

```bash
pip install auth-agent
```

## Quick Start

```python
from auth_agent import AgentSDK

# Initialize SDK (get credentials from https://console.auth-agent.com)
sdk = AgentSDK(
    agent_id="your-agent-id",
    agent_secret="your-agent-secret",
    model_name="openai/gpt-4o"
)

# Step 1: Authenticate agent
auth_response = sdk.authenticate_agent(
    client_id="oauth-client-id",
    redirect_uri="https://your-app.com/callback"
)

# Step 2: Get AI challenge
challenge = sdk.get_challenge(auth_response.session_id)
print(f"Challenge: {challenge.challenge}")

# Step 3: Generate answer using your AI model
answer = your_ai_model.generate(challenge.challenge)

# Step 4: Verify challenge
result = sdk.verify_challenge(auth_response.session_id, answer)
auth_code = result["authorization_code"]

# Step 5: Exchange code for tokens
tokens = sdk.exchange_code_for_token(
    code=auth_code,
    redirect_uri="https://your-app.com/callback",
    client_id="oauth-client-id"
)

# Step 6: Access protected resources
user_info = sdk.get_user_info()
print(f"Agent ID: {user_info.agent_id}")
print(f"Model: {user_info.model_name}")
```

## Configuration

The SDK requires only 3 parameters:

- **agent_id**: Your agent identifier (register at [console.auth-agent.com](https://console.auth-agent.com))
- **agent_secret**: Your agent secret for authentication
- **model_name**: Your AI model (e.g., `"openai/gpt-4o"`, `"anthropic/claude-3-5-sonnet"`)

The server URL is hardcoded to `https://api.auth-agent.com` and cannot be changed.

## Features

- ✅ **OAuth 2.1 compliant** - Full OAuth 2.1 with PKCE support
- ✅ **OIDC support** - OpenID Connect UserInfo and Discovery
- ✅ **AI challenge authentication** - Unique agent verification
- ✅ **Token management** - Automatic token refresh and expiration tracking
- ✅ **Type hints** - Full typing support with Pydantic models
- ✅ **Context manager** - Automatic resource cleanup

## Usage Examples

### Basic Authentication Flow

```python
from auth_agent import AgentSDK

# Using context manager (recommended)
with AgentSDK(
    agent_id="your-agent-id",
    agent_secret="your-agent-secret",
    model_name="openai/gpt-4o"
) as sdk:
    # Authenticate
    auth = sdk.authenticate_agent(
        client_id="client-id",
        redirect_uri="https://app.com/callback"
    )

    # Get challenge
    challenge = sdk.get_challenge(auth.session_id)

    # Your AI generates answer
    answer = generate_answer(challenge.challenge)

    # Verify and get tokens
    result = sdk.verify_challenge(auth.session_id, answer)
    tokens = sdk.exchange_code_for_token(
        code=result["authorization_code"],
        redirect_uri="https://app.com/callback",
        client_id="client-id"
    )

    # Access user info
    user_info = sdk.get_user_info()
    print(user_info)
```

### Token Refresh

```python
from auth_agent import AgentSDK

sdk = AgentSDK(
    agent_id="your-agent-id",
    agent_secret="your-agent-secret",
    model_name="openai/gpt-4o"
)

# Check if token is expired
if sdk.token_manager.is_expired():
    # Refresh token
    new_tokens = sdk.refresh_access_token()
    print(f"New access token: {new_tokens.access_token}")
```

### Token Introspection

```python
# Check if token is valid
introspection = sdk.introspect_token()
if introspection.active:
    print("Token is valid")
    print(f"Expires at: {introspection.exp}")
else:
    print("Token is invalid or expired")
```

### Get Agent Profile

```python
# Get agent profile information
profile = sdk.get_agent_profile()
print(f"Agent: {profile.agent_id}")
print(f"Model: {profile.model_name}")
print(f"Created: {profile.created_at}")
```

### Discovery Document

```python
# Get OIDC discovery document
discovery = sdk.get_discovery_document()
print(f"Issuer: {discovery['issuer']}")
print(f"Authorization endpoint: {discovery['authorization_endpoint']}")
```

## Error Handling

```python
from auth_agent import (
    AgentSDK,
    AuthenticationError,
    TokenError,
    ValidationError,
    NetworkError
)

try:
    sdk = AgentSDK(
        agent_id="your-agent-id",
        agent_secret="your-agent-secret",
        model_name="openai/gpt-4o"
    )

    auth = sdk.authenticate_agent(
        client_id="client-id",
        redirect_uri="https://app.com/callback"
    )

except ValidationError as e:
    print(f"Invalid parameters: {e.message}")
except AuthenticationError as e:
    print(f"Authentication failed: {e.message} ({e.error_code})")
except TokenError as e:
    print(f"Token error: {e.message}")
except NetworkError as e:
    print(f"Network error: {e.message}")
```

## API Reference

### AgentSDK

Main SDK class for authentication.

#### Constructor

```python
AgentSDK(
    agent_id: str,
    agent_secret: str,
    model_name: str,
    timeout: float = 30.0
)
```

#### Methods

- **authenticate_agent()** - Start authentication flow
- **get_challenge()** - Fetch AI challenge
- **verify_challenge()** - Submit challenge answer
- **exchange_code_for_token()** - Exchange auth code for tokens
- **refresh_access_token()** - Refresh access token
- **revoke_token()** - Revoke token
- **get_user_info()** - Get OIDC UserInfo
- **introspect_token()** - Check token validity
- **get_agent_profile()** - Get agent profile
- **get_discovery_document()** - Get OIDC discovery

### Models

All models are Pydantic models with full type validation:

- **AgentAuthRequest** - Authentication request
- **AgentAuthResponse** - Authentication response with session_id
- **ChallengeResponse** - AI challenge data
- **TokenResponse** - OAuth token response
- **UserInfo** - OIDC UserInfo
- **AgentProfile** - Agent profile data
- **IntrospectionResponse** - Token introspection result

### Exceptions

- **AuthAgentError** - Base exception
- **AuthenticationError** - Authentication failures
- **TokenError** - Token operation failures
- **ValidationError** - Input validation errors
- **NetworkError** - Network request failures

## Requirements

- Python 3.8+
- httpx >= 0.24.0
- pydantic >= 2.0.0

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black .

# Type checking
mypy auth_agent
```

## License

MIT License

## Support

- Documentation: [docs.auth-agent.com](https://docs.auth-agent.com)
- Console: [console.auth-agent.com](https://console.auth-agent.com)
- Issues: [github.com/auth-agent/python-sdk/issues](https://github.com/auth-agent/python-sdk/issues)
