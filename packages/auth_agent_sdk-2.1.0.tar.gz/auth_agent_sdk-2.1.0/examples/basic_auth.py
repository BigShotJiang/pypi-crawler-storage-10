"""
Basic authentication example using Auth-Agent SDK

This example demonstrates the complete authentication flow:
1. Agent authentication
2. Challenge retrieval
3. AI answer generation
4. Challenge verification
5. Token exchange
6. UserInfo access
"""

import os
from auth_agent import AgentSDK, AuthenticationError, TokenError


def simulate_ai_answer(challenge: str) -> str:
    """
    Simulate AI answering the challenge

    In a real implementation, you would use your actual AI model:
    - OpenAI GPT-4: openai.ChatCompletion.create()
    - Anthropic Claude: anthropic.messages.create()
    - etc.
    """
    # This is just a placeholder - real AI would process the challenge
    return f"AI-generated answer to: {challenge}"


def main():
    """Run basic authentication flow"""

    # Get credentials from environment variables
    agent_id = os.getenv("AUTH_AGENT_ID", "your-agent-id")
    agent_secret = os.getenv("AUTH_AGENT_SECRET", "your-agent-secret")
    model_name = os.getenv("AUTH_AGENT_MODEL", "openai/gpt-4o")

    # OAuth client configuration
    client_id = os.getenv("OAUTH_CLIENT_ID", "oauth-client-id")
    redirect_uri = os.getenv("OAUTH_REDIRECT_URI", "https://your-app.com/callback")

    print("🤖 Auth-Agent SDK - Basic Authentication Example\n")

    try:
        # Initialize SDK
        with AgentSDK(
            agent_id=agent_id,
            agent_secret=agent_secret,
            model_name=model_name,
            timeout=30.0
        ) as sdk:

            # Step 1: Authenticate agent
            print("📝 Step 1: Authenticating agent...")
            auth_response = sdk.authenticate_agent(
                client_id=client_id,
                redirect_uri=redirect_uri,
                scope="openid profile email",
                use_pkce=True
            )
            print(f"✅ Session created: {auth_response.session_id}")
            print(f"   Expires at: {auth_response.expires_at}\n")

            # Step 2: Get AI challenge
            print("🧩 Step 2: Fetching AI challenge...")
            challenge = sdk.get_challenge(auth_response.session_id)
            print(f"✅ Challenge received:")
            print(f"   {challenge.challenge}\n")

            # Step 3: Generate answer using AI
            print("🤔 Step 3: Generating AI answer...")
            answer = simulate_ai_answer(challenge.challenge)
            print(f"✅ Answer generated:")
            print(f"   {answer}\n")

            # Step 4: Verify challenge
            print("🔐 Step 4: Verifying challenge...")
            verification = sdk.verify_challenge(
                session_id=auth_response.session_id,
                answer=answer
            )

            if verification.get("success"):
                auth_code = verification.get("authorization_code")
                print(f"✅ Challenge verified!")
                print(f"   Authorization code: {auth_code[:20]}...\n")

                # Step 5: Exchange code for tokens
                print("🎫 Step 5: Exchanging code for tokens...")
                tokens = sdk.exchange_code_for_token(
                    code=auth_code,
                    redirect_uri=redirect_uri,
                    client_id=client_id
                )
                print(f"✅ Tokens received:")
                print(f"   Access token: {tokens.access_token[:20]}...")
                print(f"   Token type: {tokens.token_type}")
                print(f"   Expires in: {tokens.expires_in} seconds")
                if tokens.refresh_token:
                    print(f"   Refresh token: {tokens.refresh_token[:20]}...\n")

                # Step 6: Get user info
                print("👤 Step 6: Fetching user info...")
                user_info = sdk.get_user_info()
                print(f"✅ User info received:")
                print(f"   Agent ID: {user_info.agent_id}")
                print(f"   Model: {user_info.model_name}")
                if user_info.email:
                    print(f"   Email: {user_info.email}")
                print()

                # Bonus: Get agent profile
                print("📋 Bonus: Fetching agent profile...")
                profile = sdk.get_agent_profile()
                print(f"✅ Profile received:")
                print(f"   Agent ID: {profile.agent_id}")
                print(f"   Model: {profile.model_name}")
                print(f"   Status: {profile.status}")
                print(f"   Created: {profile.created_at}")
                print()

                print("🎉 Authentication flow completed successfully!")

            else:
                print(f"❌ Challenge verification failed:")
                print(f"   {verification.get('error_description', 'Unknown error')}")

    except AuthenticationError as e:
        print(f"❌ Authentication error: {e.message}")
        if e.error_code:
            print(f"   Error code: {e.error_code}")
        if e.status_code:
            print(f"   Status code: {e.status_code}")

    except TokenError as e:
        print(f"❌ Token error: {e.message}")

    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")


if __name__ == "__main__":
    main()
