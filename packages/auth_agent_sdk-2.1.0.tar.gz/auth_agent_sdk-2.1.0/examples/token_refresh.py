"""
Token refresh example using Auth-Agent SDK

Demonstrates automatic token refresh when access token expires.
"""

import os
import time
from auth_agent import AgentSDK, TokenError


def main():
    """Demonstrate token refresh"""

    agent_id = os.getenv("AUTH_AGENT_ID", "your-agent-id")
    agent_secret = os.getenv("AUTH_AGENT_SECRET", "your-agent-secret")
    model_name = os.getenv("AUTH_AGENT_MODEL", "openai/gpt-4o")

    print("🔄 Auth-Agent SDK - Token Refresh Example\n")

    with AgentSDK(
        agent_id=agent_id,
        agent_secret=agent_secret,
        model_name=model_name
    ) as sdk:

        # Assume you already have tokens from authentication
        # (In real usage, you would load these from storage)

        print("📊 Checking token status...")
        token_info = sdk.token_manager.get_token_info()
        print(f"Has access token: {token_info['has_access_token']}")
        print(f"Has refresh token: {token_info['has_refresh_token']}")
        print(f"Is expired: {token_info['is_expired']}")
        if token_info['expires_at']:
            print(f"Expires at: {token_info['expires_at']}")
        print()

        # Check if token needs refresh
        if sdk.token_manager.is_expired(buffer_seconds=300):
            print("⏰ Token is expired or will expire soon")

            try:
                print("🔄 Refreshing token...")
                new_tokens = sdk.refresh_access_token()

                print("✅ Token refreshed successfully!")
                print(f"   New access token: {new_tokens.access_token[:20]}...")
                print(f"   Expires in: {new_tokens.expires_in} seconds")
                print()

                # Use new token
                user_info = sdk.get_user_info()
                print(f"✅ Accessed user info with new token")
                print(f"   Agent: {user_info.agent_id}")
                print()

            except TokenError as e:
                print(f"❌ Token refresh failed: {e.message}")
                print("   Please re-authenticate")

        else:
            print("✅ Token is still valid")

            # You can also introspect the token
            print("\n🔍 Introspecting token...")
            introspection = sdk.introspect_token()
            print(f"Token active: {introspection.active}")
            if introspection.active:
                print(f"Scope: {introspection.scope}")
                print(f"Client ID: {introspection.client_id}")
                if introspection.exp:
                    print(f"Expires: {introspection.exp}")


if __name__ == "__main__":
    main()
