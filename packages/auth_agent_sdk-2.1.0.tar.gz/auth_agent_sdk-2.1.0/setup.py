"""
Auth-Agent Python SDK
Agent SDK for AI agent developers to authenticate with OAuth 2.1
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="auth-agent-sdk",
    version="2.1.0",
    author="Auth-Agent Team",
    author_email="support@auth-agent.com",
    description="Agent SDK for AI agent developers - Authenticate AI agents with Auth-Agent OAuth 2.1, solve AI challenges, and access OAuth-protected resources",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/auth-agent/agent-sdk-python",
    project_urls={
        "Homepage": "https://auth-agent.com",
        "Documentation": "https://docs.auth-agent.com",
        "Source": "https://github.com/auth-agent/agent-sdk-python",
        "Bug Reports": "https://github.com/auth-agent/agent-sdk-python/issues",
    },
    packages=find_packages(exclude=["tests", "examples"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
        "pydantic>=2.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "ruff>=0.1.0",
        ],
    },
    package_data={
        "auth_agent": ["py.typed"],
    },
)
