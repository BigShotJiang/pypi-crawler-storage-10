"""
Exception classes for Auth-Agent SDK
"""

from typing import Optional


class AuthAgentError(Exception):
    """Base exception for all Auth-Agent SDK errors"""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        status_code: Optional[int] = None,
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.status_code = status_code

    def __str__(self) -> str:
        if self.error_code:
            return f"{self.error_code}: {self.message}"
        return self.message


class AuthenticationError(AuthAgentError):
    """Raised when authentication fails"""

    pass


class TokenError(AuthAgentError):
    """Raised when token operations fail"""

    pass


class ValidationError(AuthAgentError):
    """Raised when input validation fails"""

    pass


class NetworkError(AuthAgentError):
    """Raised when network requests fail"""

    pass
