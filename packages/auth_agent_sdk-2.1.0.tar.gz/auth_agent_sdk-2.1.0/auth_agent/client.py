"""
Auth-Agent SDK Client
OAuth 2.1 OIDC authentication for AI agents
"""

import httpx
from typing import Optional, Dict, Any, Callable
from urllib.parse import urlencode

from .models import (
    AgentAuthRequest,
    AgentAuthResponse,
    TokenResponse,
    UserInfo,
    ChallengeResponse,
    AgentProfile,
    IntrospectionResponse,
)
from .exceptions import (
    AuthAgentError,
    AuthenticationError,
    TokenError,
    ValidationError,
    NetworkError,
)
from .token_manager import TokenManager
from .pkce import generate_pkce_pair, generate_state


class AgentSDK:
    """
    Auth-Agent SDK for Python

    Provides OAuth 2.1 OIDC authentication for AI agents.

    Args:
        agent_id: Agent identifier (register at https://console.auth-agent.com)
        agent_secret: Agent secret for authentication
        model_name: AI model name (e.g., "openai/gpt-4o", "anthropic/claude-3-5-sonnet")
        timeout: Request timeout in seconds (default: 30)

    Example:
        >>> from auth_agent import AgentSDK
        >>> sdk = AgentSDK(
        ...     agent_id="your-agent-id",
        ...     agent_secret="your-agent-secret",
        ...     model_name="openai/gpt-4o"
        ... )
        >>> # Authenticate
        >>> auth_response = sdk.authenticate_agent(
        ...     client_id="oauth-client-id",
        ...     redirect_uri="https://your-app.com/callback"
        ... )
    """

    def __init__(
        self,
        agent_id: str,
        agent_secret: str,
        model_name: str,
        timeout: float = 30.0,
    ):
        """Initialize the AgentSDK"""
        if not agent_id:
            raise ValidationError("agent_id is required")
        if not agent_secret:
            raise ValidationError("agent_secret is required")
        if not model_name:
            raise ValidationError("model_name is required")

        self.agent_id = agent_id
        self.agent_secret = agent_secret
        self.model_name = model_name
        self.server_url = "https://api.auth-agent.com"  # Hardcoded
        self.timeout = timeout

        # Token management
        self.token_manager = TokenManager()

        # HTTP client
        self.client = httpx.Client(timeout=timeout)

        # PKCE state
        self._code_verifier: Optional[str] = None
        self._state: Optional[str] = None

    def __enter__(self) -> "AgentSDK":
        """Context manager entry"""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit"""
        self.close()

    def close(self) -> None:
        """Close HTTP client"""
        self.client.close()

    def _make_request(
        self,
        method: str,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        authenticated: bool = False,
    ) -> httpx.Response:
        """
        Make HTTP request to Auth-Agent API

        Args:
            method: HTTP method
            path: API path
            json_data: JSON body data
            params: Query parameters
            authenticated: Include Authorization header

        Returns:
            HTTP response

        Raises:
            NetworkError: If request fails
            AuthenticationError: If authentication fails
        """
        url = f"{self.server_url}{path}"
        headers = {"Content-Type": "application/json"}

        if authenticated:
            try:
                headers["Authorization"] = self.token_manager.get_authorization_header()
            except TokenError as e:
                raise AuthenticationError(str(e))

        try:
            response = self.client.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                headers=headers,
            )
            return response

        except httpx.TimeoutException as e:
            raise NetworkError(f"Request timeout: {str(e)}")
        except httpx.RequestError as e:
            raise NetworkError(f"Request failed: {str(e)}")

    def _handle_error_response(self, response: httpx.Response, default_message: str) -> None:
        """
        Handle error response from API

        Args:
            response: HTTP response
            default_message: Default error message if parsing fails

        Raises:
            AuthAgentError: With appropriate error type
        """
        try:
            error_data = response.json()
            error_code = error_data.get("error", "unknown_error")
            error_description = error_data.get("error_description", default_message)
        except Exception:
            error_code = "unknown_error"
            error_description = default_message

        status_code = response.status_code

        if status_code == 401:
            raise AuthenticationError(error_description, error_code, status_code)
        elif status_code == 400:
            raise ValidationError(error_description, error_code, status_code)
        else:
            raise AuthAgentError(error_description, error_code, status_code)

    # ============================================================================
    # Agent Authentication
    # ============================================================================

    def authenticate_agent(
        self,
        client_id: str,
        redirect_uri: str,
        scope: str = "openid profile email",
        state: Optional[str] = None,
        use_pkce: bool = True,
    ) -> AgentAuthResponse:
        """
        Authenticate agent and create authentication session

        Note: Agents must be registered at https://console.auth-agent.com

        Args:
            client_id: OAuth client ID
            redirect_uri: OAuth redirect URI
            scope: OAuth scopes (default: "openid profile email")
            state: OAuth state parameter (auto-generated if not provided)
            use_pkce: Use PKCE for authorization (default: True)

        Returns:
            AgentAuthResponse with session_id and challenge URLs

        Raises:
            AuthenticationError: If authentication fails
            ValidationError: If parameters are invalid

        Example:
            >>> response = sdk.authenticate_agent(
            ...     client_id="oauth-client-id",
            ...     redirect_uri="https://your-app.com/callback"
            ... )
            >>> session_id = response.session_id
        """
        # Generate PKCE pair if enabled
        code_challenge = None
        if use_pkce:
            pkce_pair = generate_pkce_pair()
            self._code_verifier = pkce_pair.code_verifier
            code_challenge = pkce_pair.code_challenge

        # Generate state if not provided
        if not state:
            state = generate_state()
        self._state = state

        # Prepare request
        request_data = {
            "agent_id": self.agent_id,
            "agent_secret": self.agent_secret,
            "model_name": self.model_name,
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "scope": scope,
            "state": state,
        }

        if code_challenge:
            request_data["code_challenge"] = code_challenge
            request_data["code_challenge_method"] = "S256"

        # Make request
        response = self._make_request("POST", "/api/agent-auth", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Agent authentication failed")

        data = response.json()
        return AgentAuthResponse(**data)

    def get_challenge(self, session_id: str) -> ChallengeResponse:
        """
        Get AI challenge for authentication session

        Args:
            session_id: Authentication session ID from authenticate_agent()

        Returns:
            ChallengeResponse with challenge text

        Raises:
            AuthenticationError: If session is invalid or expired

        Example:
            >>> challenge = sdk.get_challenge(session_id)
            >>> challenge_text = challenge.challenge
        """
        response = self._make_request("GET", f"/api/{session_id}")

        if not response.is_success:
            self._handle_error_response(response, "Failed to get challenge")

        data = response.json()
        return ChallengeResponse(**data)

    def verify_challenge(self, session_id: str, answer: str) -> Dict[str, Any]:
        """
        Submit answer to AI challenge

        Args:
            session_id: Authentication session ID
            answer: AI-generated answer to the challenge

        Returns:
            Verification response with authorization code

        Raises:
            AuthenticationError: If answer is incorrect or session expired

        Example:
            >>> # Generate answer using your AI model
            >>> answer = your_ai_model.generate(challenge.challenge)
            >>> result = sdk.verify_challenge(session_id, answer)
            >>> auth_code = result.get("authorization_code")
        """
        request_data = {"session_id": session_id, "answer": answer}

        response = self._make_request("POST", "/api/verify-challenge", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Challenge verification failed")

        return response.json()

    # ============================================================================
    # OAuth Token Flow
    # ============================================================================

    def exchange_code_for_token(
        self, code: str, redirect_uri: str, client_id: str, client_secret: Optional[str] = None
    ) -> TokenResponse:
        """
        Exchange authorization code for access token

        Args:
            code: Authorization code from verify_challenge()
            redirect_uri: OAuth redirect URI (must match authentication request)
            client_id: OAuth client ID
            client_secret: OAuth client secret (if required)

        Returns:
            TokenResponse with access_token, refresh_token, etc.

        Raises:
            TokenError: If token exchange fails

        Example:
            >>> tokens = sdk.exchange_code_for_token(
            ...     code=auth_code,
            ...     redirect_uri="https://your-app.com/callback",
            ...     client_id="oauth-client-id"
            ... )
            >>> access_token = tokens.access_token
        """
        request_data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": client_id,
        }

        if client_secret:
            request_data["client_secret"] = client_secret

        if self._code_verifier:
            request_data["code_verifier"] = self._code_verifier

        response = self._make_request("POST", "/oauth2/token", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Token exchange failed")

        data = response.json()
        token_response = TokenResponse(**data)

        # Store tokens
        self.token_manager.set_tokens(token_response)

        # Clear PKCE state
        self._code_verifier = None
        self._state = None

        return token_response

    def refresh_access_token(self, refresh_token: Optional[str] = None) -> TokenResponse:
        """
        Refresh access token using refresh token

        Args:
            refresh_token: Refresh token (uses stored token if not provided)

        Returns:
            TokenResponse with new access_token

        Raises:
            TokenError: If refresh fails

        Example:
            >>> new_tokens = sdk.refresh_access_token()
            >>> new_access_token = new_tokens.access_token
        """
        token = refresh_token or self.token_manager.get_refresh_token()
        if not token:
            raise TokenError("No refresh token available")

        request_data = {"grant_type": "refresh_token", "refresh_token": token}

        response = self._make_request("POST", "/oauth2/token", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Token refresh failed")

        data = response.json()
        token_response = TokenResponse(**data)

        # Store new tokens
        self.token_manager.set_tokens(token_response)

        return token_response

    def revoke_token(self, token: Optional[str] = None, token_type: str = "access_token") -> None:
        """
        Revoke access or refresh token

        Args:
            token: Token to revoke (uses stored token if not provided)
            token_type: Type of token ("access_token" or "refresh_token")

        Raises:
            TokenError: If revocation fails

        Example:
            >>> sdk.revoke_token()  # Revoke current access token
            >>> sdk.revoke_token(token_type="refresh_token")  # Revoke refresh token
        """
        if not token:
            if token_type == "refresh_token":
                token = self.token_manager.get_refresh_token()
            else:
                token = self.token_manager.get_access_token()

        if not token:
            raise TokenError(f"No {token_type} available to revoke")

        request_data = {"token": token, "token_type_hint": token_type}

        response = self._make_request("POST", "/oauth2/revoke", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Token revocation failed")

        # Clear tokens if revoking current tokens
        if token_type == "access_token" and token == self.token_manager.get_access_token():
            self.token_manager.clear()

    # ============================================================================
    # OIDC Endpoints
    # ============================================================================

    def get_user_info(self) -> UserInfo:
        """
        Get user info from OIDC UserInfo endpoint

        Requires valid access token.

        Returns:
            UserInfo with agent information

        Raises:
            AuthenticationError: If not authenticated or token expired

        Example:
            >>> user_info = sdk.get_user_info()
            >>> agent_id = user_info.agent_id
            >>> model_name = user_info.model_name
        """
        response = self._make_request("GET", "/oauth2/userinfo", authenticated=True)

        if not response.is_success:
            self._handle_error_response(response, "Failed to get user info")

        data = response.json()
        return UserInfo(**data)

    def introspect_token(self, token: Optional[str] = None) -> IntrospectionResponse:
        """
        Introspect token to check if it's valid

        Args:
            token: Token to introspect (uses stored access token if not provided)

        Returns:
            IntrospectionResponse with token status

        Example:
            >>> result = sdk.introspect_token()
            >>> if result.active:
            ...     print("Token is valid")
        """
        token_to_check = token or self.token_manager.get_access_token()
        if not token_to_check:
            raise TokenError("No token available to introspect")

        request_data = {"token": token_to_check}

        response = self._make_request("POST", "/oauth2/introspect", json_data=request_data)

        if not response.is_success:
            self._handle_error_response(response, "Token introspection failed")

        data = response.json()
        return IntrospectionResponse(**data)

    # ============================================================================
    # Agent Profile
    # ============================================================================

    def get_agent_profile(self) -> AgentProfile:
        """
        Get agent profile information

        Requires valid access token.

        Returns:
            AgentProfile with agent details

        Example:
            >>> profile = sdk.get_agent_profile()
            >>> print(f"Agent: {profile.agent_id}")
            >>> print(f"Model: {profile.model_name}")
        """
        response = self._make_request("GET", "/api/agent/profile", authenticated=True)

        if not response.is_success:
            self._handle_error_response(response, "Failed to get agent profile")

        data = response.json()
        return AgentProfile(**data)

    # ============================================================================
    # Discovery
    # ============================================================================

    def get_discovery_document(self) -> Dict[str, Any]:
        """
        Get OIDC discovery document

        Returns:
            Discovery document with endpoint URLs and capabilities

        Example:
            >>> discovery = sdk.get_discovery_document()
            >>> print(discovery["issuer"])
            >>> print(discovery["authorization_endpoint"])
        """
        response = self._make_request("GET", "/.well-known/openid-configuration")

        if not response.is_success:
            self._handle_error_response(response, "Failed to get discovery document")

        return response.json()
