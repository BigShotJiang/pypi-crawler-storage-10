"""
Auth-Agent Python SDK
Agent SDK for AI agent developers to authenticate with OAuth 2.1
"""

from .client import AgentSDK
from .exceptions import (
    AuthAgentError,
    AuthenticationError,
    TokenError,
    ValidationError,
    NetworkError,
)
from .models import (
    AgentAuthRequest,
    AgentAuthResponse,
    TokenResponse,
    UserInfo,
    ChallengeResponse,
    AgentProfile,
)

__version__ = "2.1.0"
__all__ = [
    "AgentSDK",
    "AuthAgentError",
    "AuthenticationError",
    "TokenError",
    "ValidationError",
    "NetworkError",
    "AgentAuthRequest",
    "AgentAuthResponse",
    "TokenResponse",
    "UserInfo",
    "ChallengeResponse",
    "AgentProfile",
]
