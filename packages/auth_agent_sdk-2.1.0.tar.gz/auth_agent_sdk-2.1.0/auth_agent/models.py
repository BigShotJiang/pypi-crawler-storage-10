"""
Data models for Auth-Agent SDK
"""

from datetime import datetime
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


class AgentAuthRequest(BaseModel):
    """Request model for agent authentication"""

    client_id: str = Field(..., description="OAuth client ID")
    redirect_uri: str = Field(..., description="OAuth redirect URI")
    scope: str = Field(default="openid profile email", description="OAuth scopes")
    state: Optional[str] = Field(None, description="OAuth state parameter")
    code_challenge: Optional[str] = Field(None, description="PKCE code challenge")
    code_challenge_method: Optional[str] = Field(
        default="S256", description="PKCE challenge method"
    )


class AgentAuthResponse(BaseModel):
    """Response model for agent authentication"""

    session_id: str = Field(..., description="Authentication session ID")
    challenge_url: str = Field(..., description="URL to fetch the AI challenge")
    verification_url: str = Field(..., description="URL to submit challenge answer")
    expires_at: str = Field(..., description="Session expiration timestamp")


class ChallengeResponse(BaseModel):
    """Response model for challenge fetch"""

    challenge: str = Field(..., description="The AI challenge text")
    session_id: str = Field(..., description="Session ID")
    expires_at: str = Field(..., description="Challenge expiration timestamp")


class VerificationRequest(BaseModel):
    """Request model for challenge verification"""

    session_id: str = Field(..., description="Authentication session ID")
    answer: str = Field(..., description="AI-generated answer to the challenge")


class TokenResponse(BaseModel):
    """OAuth token response"""

    access_token: str = Field(..., description="Access token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration in seconds")
    refresh_token: Optional[str] = Field(None, description="Refresh token")
    id_token: Optional[str] = Field(None, description="OIDC ID token")
    scope: Optional[str] = Field(None, description="Granted scopes")


class UserInfo(BaseModel):
    """OIDC UserInfo response"""

    sub: str = Field(..., description="Subject identifier (agent ID)")
    agent_id: str = Field(..., description="Agent ID")
    model_name: str = Field(..., description="AI model name")
    email: Optional[str] = Field(None, description="Agent owner email")
    name: Optional[str] = Field(None, description="Agent name")
    created_at: Optional[str] = Field(None, description="Agent creation timestamp")
    updated_at: Optional[str] = Field(None, description="Agent update timestamp")


class AgentProfile(BaseModel):
    """Agent profile information"""

    agent_id: str = Field(..., description="Agent ID")
    model_name: str = Field(..., description="AI model name")
    owner_name: Optional[str] = Field(None, description="Owner name")
    owner_email: Optional[str] = Field(None, description="Owner email")
    created_at: str = Field(..., description="Creation timestamp")
    updated_at: str = Field(..., description="Last update timestamp")
    status: str = Field(default="active", description="Agent status")


class IntrospectionResponse(BaseModel):
    """Token introspection response"""

    active: bool = Field(..., description="Whether token is active")
    scope: Optional[str] = Field(None, description="Token scopes")
    client_id: Optional[str] = Field(None, description="Client ID")
    username: Optional[str] = Field(None, description="Username (agent_id)")
    token_type: Optional[str] = Field(None, description="Token type")
    exp: Optional[int] = Field(None, description="Expiration timestamp")
    iat: Optional[int] = Field(None, description="Issued at timestamp")
    sub: Optional[str] = Field(None, description="Subject")


class PKCEPair(BaseModel):
    """PKCE code verifier and challenge pair"""

    code_verifier: str = Field(..., description="PKCE code verifier")
    code_challenge: str = Field(..., description="PKCE code challenge (SHA-256)")
