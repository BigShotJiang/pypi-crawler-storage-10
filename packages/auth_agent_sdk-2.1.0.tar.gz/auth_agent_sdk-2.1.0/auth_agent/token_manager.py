"""
Token management for Auth-Agent SDK
"""

import json
import base64
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from .models import TokenResponse
from .exceptions import TokenError


class TokenManager:
    """Manages OAuth tokens with automatic expiration tracking"""

    def __init__(self) -> None:
        self._access_token: Optional[str] = None
        self._refresh_token: Optional[str] = None
        self._id_token: Optional[str] = None
        self._token_type: str = "Bearer"
        self._expires_at: Optional[datetime] = None
        self._scope: Optional[str] = None

    def set_tokens(self, token_response: TokenResponse) -> None:
        """
        Store tokens from OAuth response

        Args:
            token_response: Token response from OAuth server
        """
        self._access_token = token_response.access_token
        self._refresh_token = token_response.refresh_token
        self._id_token = token_response.id_token
        self._token_type = token_response.token_type
        self._scope = token_response.scope

        # Calculate expiration time
        if token_response.expires_in:
            self._expires_at = datetime.utcnow() + timedelta(seconds=token_response.expires_in)

    def get_access_token(self) -> Optional[str]:
        """
        Get current access token

        Returns:
            Access token or None if not set
        """
        return self._access_token

    def get_refresh_token(self) -> Optional[str]:
        """
        Get current refresh token

        Returns:
            Refresh token or None if not set
        """
        return self._refresh_token

    def get_id_token(self) -> Optional[str]:
        """
        Get current ID token

        Returns:
            ID token or None if not set
        """
        return self._id_token

    def is_expired(self, buffer_seconds: int = 60) -> bool:
        """
        Check if access token is expired

        Args:
            buffer_seconds: Consider token expired N seconds before actual expiration

        Returns:
            True if token is expired or will expire within buffer time
        """
        if not self._expires_at:
            return True

        return datetime.utcnow() >= (self._expires_at - timedelta(seconds=buffer_seconds))

    def get_authorization_header(self) -> str:
        """
        Get formatted Authorization header value

        Returns:
            Authorization header value (e.g., "Bearer abc123")

        Raises:
            TokenError: If no access token is available
        """
        if not self._access_token:
            raise TokenError("No access token available")

        return f"{self._token_type} {self._access_token}"

    def clear(self) -> None:
        """Clear all stored tokens"""
        self._access_token = None
        self._refresh_token = None
        self._id_token = None
        self._expires_at = None
        self._scope = None

    def parse_jwt(self, token: Optional[str] = None) -> Dict[str, Any]:
        """
        Parse JWT token payload (without verification)

        IMPORTANT: This does NOT verify the token signature.
        Only use for reading claims, not for security validation.

        Args:
            token: JWT token to parse (uses access_token if not provided)

        Returns:
            Decoded JWT payload

        Raises:
            TokenError: If token is invalid or cannot be parsed
        """
        jwt_token = token or self._access_token
        if not jwt_token:
            raise TokenError("No token available to parse")

        try:
            # JWT format: header.payload.signature
            parts = jwt_token.split(".")
            if len(parts) != 3:
                raise TokenError("Invalid JWT format")

            # Decode payload (add padding if needed)
            payload_encoded = parts[1]
            padding = "=" * (4 - len(payload_encoded) % 4)
            payload_bytes = base64.urlsafe_b64decode(payload_encoded + padding)
            payload = json.loads(payload_bytes)

            return payload

        except Exception as e:
            raise TokenError(f"Failed to parse JWT: {str(e)}")

    def get_token_info(self) -> Dict[str, Any]:
        """
        Get information about current tokens

        Returns:
            Dictionary with token information
        """
        return {
            "has_access_token": self._access_token is not None,
            "has_refresh_token": self._refresh_token is not None,
            "has_id_token": self._id_token is not None,
            "token_type": self._token_type,
            "scope": self._scope,
            "is_expired": self.is_expired(),
            "expires_at": self._expires_at.isoformat() if self._expires_at else None,
        }
