"""
PKCE (Proof Key for Code Exchange) utilities for OAuth 2.1
"""

import secrets
import hashlib
import base64
from .models import PKCEPair


def base64_url_encode(data: bytes) -> str:
    """
    Base64 URL encode without padding

    Args:
        data: Bytes to encode

    Returns:
        URL-safe base64 encoded string
    """
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("utf-8")


def generate_pkce_pair() -> PKCEPair:
    """
    Generate PKCE code verifier and challenge pair

    OAuth 2.1 compliant with S256 (SHA-256) challenge method

    Returns:
        PKCEPair with code_verifier and code_challenge

    Example:
        >>> pkce = generate_pkce_pair()
        >>> pkce.code_verifier  # Random 43-character string
        >>> pkce.code_challenge  # SHA-256 hash of verifier
    """
    # Generate code verifier (random 32 bytes = 43 characters in base64url)
    code_verifier_bytes = secrets.token_bytes(32)
    code_verifier = base64_url_encode(code_verifier_bytes)

    # Generate code challenge (SHA-256 hash of verifier)
    challenge_bytes = hashlib.sha256(code_verifier.encode("utf-8")).digest()
    code_challenge = base64_url_encode(challenge_bytes)

    return PKCEPair(code_verifier=code_verifier, code_challenge=code_challenge)


def generate_state() -> str:
    """
    Generate random state parameter for CSRF protection

    Returns:
        Random URL-safe string (22 characters)

    Example:
        >>> state = generate_state()
        >>> len(state)
        22
    """
    return base64_url_encode(secrets.token_bytes(16))
