"""
cachekit - Name reservation

This is a placeholder release to reserve the package name on PyPI.
The actual package is under development.

See: https://github.com/27b-io/cachekit
"""

__version__ = "0.0.1"

# Placeholder - do not use
raise NotImplementedError(
    "This is a placeholder package for name reservation only. "
    "The actual cachekit package is under development. "
    "Follow https://github.com/27b-io/cachekit for updates."
)
