# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION

import numpy as np

cimport cython
cimport numpy as np


@cython.boundscheck(False)
@cython.wraparound(False)
def encode_seq(seq: str) -> np.ndarray:
    seq = seq.upper() # faster than checking lowercase in for loop, ~.3ms overhead

    cdef:
        int seq_len = len(seq)
        np.ndarray[np.uint8_t, ndim = 2] encoded = np.zeros((4, seq_len), dtype = np.uint8)
        int i
        char base

    for i, base in enumerate(seq):                                                    
        if base == 'A':                                                         
            encoded[0, i] = 1                                                      
        elif base == 'C':                                                        
            encoded[1, i] = 1                                                      
        elif base == 'G':                                                        
            encoded[2, i] = 1                                                      
        elif base == 'T':                                                        
            encoded[3, i] = 1

    return encoded