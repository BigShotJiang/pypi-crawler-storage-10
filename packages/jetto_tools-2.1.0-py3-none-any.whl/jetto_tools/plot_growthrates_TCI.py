#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, re, argparse
import numpy as np
import matplotlib.pyplot as plt
from jintrac import jintrac

def plot_growthrates_TCI(jsp, time, xrhos, kygrid_range, output):
    """
    Parameters
    ----------
    jsp : dyct
        Python dictionary containing JSP output
    xrhos : list of float
        Desired rho_tor_norm values (e.g., [0.9, 0.6, 0.3]).
    time : float
        Single time (e.g., 54.5) at which to extract spectra.
    kygrid_range : list of float
        Range for plotting (e.g. [0, 1]).
    output : str
        Output directory where to save the figure.
    """

    # --- Time and radial grids ---
    tvec = jsp["TIME"]
    xvec = jsp["XVEC2"]  # Use the XVEC2 vector to have the correct number of x_points as GA, FK, FR
    if time == -1:
        t_idx = -1
    else:
        t_idx = np.argmin(np.abs(tvec - time))
    t_selected = float(tvec[t_idx])
    print(f" Closest time index: {t_selected:.3f} s (requested {time})")

    # --- Identify GA/FR/FK fields ---
    jsp_fields = list(jsp.keys())
    ga_fields = sorted([f for f in jsp_fields if re.match(r"^GA\d+$", f)])
    fr_fields = sorted([f for f in jsp_fields if re.match(r"^FR\d+$", f)])
    fk_fields = sorted([f for f in jsp_fields if re.match(r"^FK\d+$", f)])

    # --- Check that at least GA02, FR02, FK02 exist ---
    required_fields = ["GA02", "FR02", "FK02"]
    missing_fields = [f for f in required_fields if f not in jsp.keys()]

    if missing_fields:
        raise KeyError(f"❌ Missing required fields in JETTO output: {', '.join(missing_fields)}")

    # === Initialize output matrices ===
    n_rhos = len(xrhos)
    n_ky = len(fk_fields)

    GA_mat = np.zeros((n_rhos, n_ky))
    FR_mat = np.zeros((n_rhos, n_ky))
    FK_mat = np.zeros((n_rhos, n_ky))

    # === Loop over rho values ===
    for irho, xrho in enumerate(xrhos):
        print(f"\n Processing rho = {xrho}")
        x_idx = np.argmin(np.abs(xvec - xrho))

        for ikys, (ga_name, fr_name, fk_name) in enumerate(zip(ga_fields, fr_fields, fk_fields)):
            ga = jsp[ga_name]
            fr = jsp[fr_name]
            fk = jsp[fk_name]

            # Fill matrices
            GA_mat[irho, ikys] = ga[t_idx, x_idx]
            FR_mat[irho, ikys] = fr[t_idx, x_idx]
            FK_mat[irho, ikys] = fk[t_idx, x_idx]

    print("\n Data matrices constructed successfully.")
    print(f"GA_mat shape: {GA_mat.shape}")
    print(f"FR_mat shape: {FR_mat.shape}")
    print(f"FK_mat shape: {FK_mat.shape}")

        # === Plotting ===
    fig = plt.figure(figsize=(10, 4 * n_rhos))
    fig.suptitle(f"@ t={t_selected:.3f} s", fontsize=14)

    for irho, xrho in enumerate(xrhos):
        # Extract corresponding row for this rho
        fk_vals = FK_mat[irho, :]
        ga_vals = GA_mat[irho, :]
        fr_vals = FR_mat[irho, :]

        # --- Plot growth rate ---
        ax_gamma = plt.subplot(n_rhos, 2, 2 * irho + 1)
        ax_gamma.set_xscale("log")
        ax_gamma.set_yscale("log")
        ax_gamma.set_xlim(kygrid_range)
        ax_gamma.set_ylabel(r"$\gamma_{GB}$")

        #  Only show x-axis label for bottom row
        if irho == n_rhos - 1:
            ax_gamma.set_xlabel(r"$k_\theta \rho_s$")

        #  Plot unconnected points
        ax_gamma.plot(fk_vals, ga_vals, "o", color="red")

        #  Internal box label for rho=xrho
        ax_gamma.text(
            0.95, 0.9, rf"$\rho = {xrho}$",
            transform=ax_gamma.transAxes,
            fontsize=10,
            ha="right", va="top",
            bbox=dict(facecolor="white", alpha=0.6, edgecolor="none")
        )

        # --- Plot frequency ---
        ax_freq = plt.subplot(n_rhos, 2, 2 * irho + 2)
        ax_freq.set_xscale("log")
        ax_freq.set_xlim(kygrid_range)
        ax_freq.axhline(0, color="k", linestyle="--", linewidth=0.8)
        ax_freq.set_ylabel(r"$\omega_{GB}$")

        #  Only show x-axis label for bottom row
        if irho == n_rhos - 1:
            ax_freq.set_xlabel(r"$k_\theta \rho_s$")

        #  Plot unconnected points
        ax_freq.plot(fk_vals, fr_vals, "s", color="blue")

        #  Internal box label for rho
        ax_freq.text(
            0.95, 0.9, rf"$\rho = {xrho}$",
            transform=ax_freq.transAxes,
            fontsize=10,
            ha="right", va="top",
            bbox=dict(facecolor="white", alpha=0.6, edgecolor="none")
        )

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    # save figure if output path directory is given
    if output:
        os.makedirs(output, exist_ok=True)
        out_path = os.path.join(output, f"tci_plot_t{t_selected:.3f}.png")
        plt.savefig(out_path, dpi=300, bbox_inches="tight")
        print(f"\n💾 Figure saved to: {out_path}")

    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot TCI growth rates and frequencies for a single JETTO run.")
    parser.add_argument("--jetto_path", default="./", help="Path to the JETTO run directory. Default: current directory.")
    parser.add_argument("-t", "--time", type=float, default=-1, help="Time to plot. Default: take the last time available.")
    parser.add_argument("--xrhos", type=str, default="0.2,0.4,0.6,0.8", help="Comma-separated list of rho values. Default: 0.2,0.4,0.6,0.8.")
    parser.add_argument("--kygrid_range", type=str, default="0.1,50", help="Min,max range of k_theta*rho_s to plot. Default: 0.1,50")
    parser.add_argument("-o", "--output", type=str, default=None, help="Optional output directory to save the figure.")
    args = parser.parse_args()

    xrhos = [float(x.strip()) for x in args.xrhos.split(",")]
    kygrid_range = [float(x.strip()) for x in args.kygrid_range.split(",")]

    # --- Load JETTO run ---
    print(f"📂 Loading JINTRAC run from: {args.jetto_path}")
    jet = jintrac(
        database="jet",
        nshot=0,
        run=0,
        jetto_path=args.jetto_path,
        data_version="3.39.0",
        backend="std",
        out_memory=True)
    data = jet.jet

    plot_growthrates_TCI(jsp=data,
        xrhos=xrhos,
        time=args.time,
        kygrid_range=kygrid_range,
        output=args.output)
