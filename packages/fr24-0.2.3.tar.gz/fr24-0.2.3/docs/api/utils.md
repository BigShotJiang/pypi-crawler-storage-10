Mostly used in the [service](service.md).

::: fr24.utils
    options:
        show_if_no_docstring: true