::: fr24.types
    options:
        show_if_no_docstring: true