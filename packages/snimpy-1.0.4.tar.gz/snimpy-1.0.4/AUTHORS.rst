Development Lead
----------------

* Vincent Bernat <bernat@luffy.cx>

Contributors
------------

* Jakub Wroniecki
* Julian Taylor
