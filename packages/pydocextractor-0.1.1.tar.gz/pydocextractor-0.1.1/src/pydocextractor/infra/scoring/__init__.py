"""Quality scoring adapters."""
