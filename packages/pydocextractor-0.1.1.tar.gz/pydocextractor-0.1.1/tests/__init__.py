"""Tests for pyDocExtractor."""
