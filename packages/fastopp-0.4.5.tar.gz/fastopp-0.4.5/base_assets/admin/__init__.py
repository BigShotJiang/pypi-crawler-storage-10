# Base admin module for minimal FastAPI application
