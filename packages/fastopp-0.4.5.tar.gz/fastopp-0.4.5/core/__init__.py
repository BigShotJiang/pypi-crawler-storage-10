"""
Core services and utilities for FastOpp
Shared across base_assets and demo_assets
"""
