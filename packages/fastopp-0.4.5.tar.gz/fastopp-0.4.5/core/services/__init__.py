"""
Core services module
Contains shared services used across the application
"""
