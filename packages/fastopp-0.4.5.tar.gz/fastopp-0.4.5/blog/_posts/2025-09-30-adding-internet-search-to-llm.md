---
layout: post
title: "Using Tavily to add internet search to chat"
date: 2025-09-30
author: Shotoku
author_bio: "Shotoku Taishi was the originator of a Japanese constitution in the 8th century"
image: /assets/images/search-icon.png
excerpt: "This chat_with_history example has an a way to connect LLM to internet search"
---

### [https://github.com/codetricity/chat-with-history](https://github.com/codetricity/chat-with-history)