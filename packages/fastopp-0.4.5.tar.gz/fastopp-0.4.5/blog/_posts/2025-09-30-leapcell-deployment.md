---
layout: post
title: "FastOpp Deployment to Leapcell - Free Hosting Tier"
date: 2025-09-30
author: Oppkey Tutor
author_bio: "Friendly tutor for students using FastOpp in their learning of AI web applications"
image: /assets/images/leapcell_logo.png
excerpt: "Free deployment to Leapcell.  No credit card required."
---

These tutorials will take you through free deployment on
Leapcell with both FastAPI and FastOpp.

[FastAPI Deploy to Leapcell - free hosting tier](https://youtu.be/xhOALd640tA)

[Free  Deploy to Leapcell with FastAPI, PostgreSQL and Object Storage](https://youtu.be/GoKpQTHE-1A)
