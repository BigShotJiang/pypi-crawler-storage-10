"""
Demo scripts package.

This package contains scripts that are only used for demo functionality
and can be safely removed when creating new projects from this template.

These scripts are separate from the core scripts/ directory to make it
easy to delete all demo functionality for production projects.
"""