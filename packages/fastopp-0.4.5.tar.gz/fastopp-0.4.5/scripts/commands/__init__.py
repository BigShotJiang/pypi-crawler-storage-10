# Commands module for oppman.py
