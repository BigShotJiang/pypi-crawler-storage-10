# Help module for oppman.py
from .text import show_help

__all__ = ['show_help']
