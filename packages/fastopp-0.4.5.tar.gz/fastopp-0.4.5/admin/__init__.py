# Demo admin module for full FastAPI application with all features
