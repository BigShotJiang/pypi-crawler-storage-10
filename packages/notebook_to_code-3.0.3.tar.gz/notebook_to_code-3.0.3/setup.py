from pathlib import Path
from setuptools import setup, find_packages

# Fallback setup.py for legacy installers; primary config lives in pyproject.toml
base_dir = Path(__file__).parent
req_file = base_dir / "notebook_converter" / "requirements.txt"
requirements = []
if req_file.exists():
    requirements = [
        ln.strip() for ln in req_file.read_text(encoding="utf-8").splitlines()
        if ln.strip() and not ln.strip().startswith("#")
    ]

setup(
    name="notebook-to-code",
    version="3.0.0",
    description="Advanced Jupyter Notebook to Python script converter with round-trip support",
    packages=find_packages(where="notebook_converter/src"),
    package_dir={"": "notebook_converter/src"},
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "notebook-to-code=notebook_converter.cli:main",
            "nb2py=notebook_converter.cli:main",
        ],
        "notebook_converter.plugins": [
            "default_theme=notebook_converter.plugins.themes.default:DefaultTheme",
            "minimal_theme=notebook_converter.plugins.themes.minimal:MinimalTheme",
        ],
    },
)
