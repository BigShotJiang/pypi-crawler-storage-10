"""
Minimal conversion theme.
"""

from typing import Dict, Any
from ..base import ConversionTheme


class MinimalTheme(ConversionTheme):
    """Minimal theme with clean, simple formatting."""
    
    @property
    def name(self) -> str:
        return "minimal"
    
    @property
    def description(self) -> str:
        return "Minimal theme with clean formatting and reduced metadata"
    
    def format_code_cell(self, code: str, metadata: Dict[str, Any]) -> str:
        """Format code cell minimally."""
        if not code.strip():
            return ""
        
        return code
    
    def format_markdown_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format markdown cell minimally."""
        if not content.strip():
            return ""
        
        return content
    
    def format_raw_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format raw cell minimally."""
        if not content.strip():
            return ""
        
        lines = []
        for line in content.split('\n'):
            lines.append(f"# {line}")
        
        return "\n".join(lines)
