"""
Default conversion theme.
"""

from typing import Dict, Any
from ..base import ConversionTheme


class DefaultTheme(ConversionTheme):
    """Default theme with comprehensive formatting."""
    
    @property
    def name(self) -> str:
        return "default"
    
    @property
    def description(self) -> str:
        return "Default theme with comprehensive cell formatting and metadata preservation"
    
    def format_code_cell(self, code: str, metadata: Dict[str, Any]) -> str:
        """Format code cell with execution info."""
        if not code.strip():
            return ""
        
        lines = [f"# Code Cell {metadata.get('index', 0)}"]
        
        # Add execution count if available
        exec_count = metadata.get('execution_count')
        if exec_count is not None:
            lines.append(f"# Execution count: {exec_count}")
        
        lines.append("")
        lines.append(code)
        
        return "\n".join(lines)
    
    def format_markdown_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format markdown cell with clear separation."""
        if not content.strip():
            return ""
        
        lines = [f"# Markdown Cell {metadata.get('index', 0)}"]
        lines.append("")
        lines.append(content)
        
        return "\n".join(lines)
    
    def format_raw_cell(self, content: str, metadata: Dict[str, Any]) -> str:
        """Format raw cell with prefix."""
        if not content.strip():
            return ""
        
        lines = [f"# Raw Cell {metadata.get('index', 0)}"]
        lines.append("# Raw content:")
        
        for line in content.split('\n'):
            lines.append(f"# {line}")
        
        return "\n".join(lines)
