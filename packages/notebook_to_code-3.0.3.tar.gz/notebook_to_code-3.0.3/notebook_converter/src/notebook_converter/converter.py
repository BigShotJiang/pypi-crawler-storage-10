import json
import logging
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import re
import asyncio
import aiofiles

try:
    import nbformat
    from nbformat.validator import ValidationError
    NBFORMAT_AVAILABLE = True
except ImportError:
    NBFORMAT_AVAILABLE = False

from .utils.markdown_processor import MarkdownProcessor
from .utils.metadata_handler import MetadataHandler
from .utils.quality_analyzer import QualityAnalyzer
from .plugins.base import PluginManager, ConversionTheme


class CellType(Enum):
    """Enumeration of supported notebook cell types."""
    CODE = "code"
    MARKDOWN = "markdown"
    RAW = "raw"
    UNKNOWN = "unknown"


class ConversionMode(Enum):
    """Conversion mode enumeration."""
    NOTEBOOK_TO_SCRIPT = "nb2py"
    SCRIPT_TO_NOTEBOOK = "py2nb"
    ROUND_TRIP_VALIDATION = "validate"


@dataclass
class ConversionOptions:
    """Configuration options for notebook conversion."""
    preserve_metadata: bool = True
    add_execution_info: bool = True
    max_line_length: int = 88
    semantic_markdown: bool = True
    round_trip_metadata: bool = True
    quality_analysis: bool = False
    theme: str = "default"
    custom_header: Optional[str] = None
    strip_outputs: bool = True
    preserve_cell_ids: bool = True
    add_timestamps: bool = True


@dataclass 
class ConversionStats:
    """Comprehensive statistics from notebook conversion."""
    total_cells: int = 0
    code_cells: int = 0
    markdown_cells: int = 0
    raw_cells: int = 0
    empty_cells: int = 0
    processing_time: float = 0.0
    output_size: int = 0
    quality_score: Optional[float] = None
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    def __str__(self) -> str:
        return (
            f"Conversion Statistics:\n"
            f"  Total cells: {self.total_cells}\n"
            f"  Code cells: {self.code_cells}\n"
            f"  Markdown cells: {self.markdown_cells}\n"
            f"  Raw cells: {self.raw_cells}\n"
            f"  Empty cells: {self.empty_cells}\n"
            f"  Processing time: {self.processing_time:.3f}s\n"
            f"  Output size: {self.output_size} bytes\n"
            f"  Quality score: {self.quality_score or 'N/A'}\n"
            f"  Warnings: {len(self.warnings)}\n"
            f"  Errors: {len(self.errors)}"
        )


class NotebookConverterError(Exception):
    """Base exception for notebook converter errors."""
    pass


class InvalidNotebookError(NotebookConverterError):
    """Raised when notebook format is invalid."""
    pass


class ConversionError(NotebookConverterError):
    """Raised when conversion fails."""
    pass


class RoundTripError(NotebookConverterError):
    """Raised when round-trip conversion fails."""
    pass


class AdvancedNotebookConverter:
    """
    Advanced Jupyter Notebook to Python Script Converter.
    
    Features:
    - Semantic markdown conversion
    - Round-trip reversibility 
    - Plugin system for themes
    - Quality analysis integration
    - Async batch processing support
    """
    
    # Metadata markers for round-trip conversion
    CELL_START_MARKER = "# [CELL:"
    CELL_END_MARKER = "# [/CELL]"
    METADATA_MARKER = "# [METADATA:"
    
    def __init__(self, 
                 options: Optional[ConversionOptions] = None,
                 logger: Optional[logging.Logger] = None):
        """
        Initialize the advanced notebook converter.
        
        Args:
            options: Conversion configuration options
            logger: Custom logger instance
        """
        self.options = options or ConversionOptions()
        self.logger = logger or self._setup_logger()
        self.stats = ConversionStats()
        
        # Initialize components
        self.markdown_processor = MarkdownProcessor(
            max_line_length=self.options.max_line_length,
            semantic_mode=self.options.semantic_markdown
        )
        self.metadata_handler = MetadataHandler()
        self.plugin_manager = PluginManager()
        
        # Initialize quality analyzer if requested
        self.quality_analyzer = None
        if self.options.quality_analysis:
            try:
                self.quality_analyzer = QualityAnalyzer()
            except ImportError as e:
                self.logger.warning(f"Quality analysis not available: {e}")
        
        # Load theme
        self.theme = self.plugin_manager.get_theme(self.options.theme)
        
        # Validate environment
        if not NBFORMAT_AVAILABLE:
            self.logger.warning(
                "nbformat library not available. Using manual JSON parsing."
            )
    
    def _setup_logger(self) -> logging.Logger:
        """Set up default logger with rich formatting."""
        logger = logging.getLogger(self.__class__.__name__)
        if not logger.handlers:
            try:
                from rich.logging import RichHandler
                handler = RichHandler(rich_tracebacks=True)
            except ImportError:
                handler = logging.StreamHandler()
            
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _validate_input_file(self, input_path: Union[str, Path]) -> Path:
        """Validate input file path and existence."""
        path = Path(input_path).resolve()
        
        if not path.exists():
            raise FileNotFoundError(f"Input file not found: {path}")
        
        if not path.is_file():
            raise ValueError(f"Input path is not a file: {path}")
        
        return path
    
    def _generate_cell_metadata(self, cell: Dict[str, Any], cell_index: int) -> Dict[str, Any]:
        """Generate metadata for round-trip conversion."""
        metadata = {
            "cell_type": cell.get("cell_type", "unknown"),
            "index": cell_index,
            "id": cell.get("id", f"cell-{cell_index}"),
        }
        
        if self.options.add_timestamps:
            metadata["converted_at"] = datetime.now().isoformat()
        
        # Preserve execution metadata for code cells
        if cell.get("cell_type") == "code":
            if "execution_count" in cell:
                metadata["execution_count"] = cell["execution_count"]
            if "metadata" in cell:
                metadata["cell_metadata"] = cell["metadata"]
        
        return metadata
    
    def _format_cell_header(self, cell_metadata: Dict[str, Any]) -> str:
        """Format cell header with metadata for round-trip support."""
        cell_type = cell_metadata["cell_type"]
        cell_index = cell_metadata["index"]
        cell_id = cell_metadata["id"]
        
        header_parts = [
            f"{self.CELL_START_MARKER} {cell_type.upper()}",
            f"index={cell_index}",
            f"id={cell_id}"
        ]
        
        if "execution_count" in cell_metadata:
            header_parts.append(f"exec_count={cell_metadata['execution_count']}")
        
        header = f"{', '.join(header_parts)} ]"
        
        if self.options.round_trip_metadata:
            # Add detailed metadata as JSON comment
            metadata_json = json.dumps(cell_metadata, separators=(',', ':'))
            header += f"\n{self.METADATA_MARKER} {metadata_json} ]"
        
        return header
    
    def _process_code_cell(self, cell: Dict[str, Any], cell_index: int) -> Tuple[str, Dict[str, Any]]:
        """Process a code cell with advanced features."""
        source = cell.get('source', '')
        if isinstance(source, list):
            source = ''.join(source)
        
        cell_metadata = self._generate_cell_metadata(cell, cell_index)
        
        # Apply theme formatting
        code_content = self.theme.format_code_cell(source.rstrip(), cell_metadata)
        
        # Add cell header for round-trip support
        if self.options.round_trip_metadata:
            header = self._format_cell_header(cell_metadata)
            full_content = f"{header}\n{code_content}\n{self.CELL_END_MARKER}"
        else:
            full_content = code_content
        
        # Update statistics
        if source.strip():
            self.stats.code_cells += 1
        else:
            self.stats.empty_cells += 1
        
        return full_content, cell_metadata
    
    def _process_markdown_cell(self, cell: Dict[str, Any], cell_index: int) -> Tuple[str, Dict[str, Any]]:
        """Process a markdown cell with semantic conversion."""
        source = cell.get('source', '')
        if isinstance(source, list):
            source = ''.join(source)
        
        cell_metadata = self._generate_cell_metadata(cell, cell_index)
        
        if source.strip():
            # Process markdown with semantic conversion
            if self.options.semantic_markdown:
                processed_content = self.markdown_processor.convert_to_comments(source)
            else:
                # Simple comment wrapping
                lines = [f"# {line}" for line in source.split('\n')]
                processed_content = '\n'.join(lines)
            
            # Apply theme formatting
            markdown_content = self.theme.format_markdown_cell(processed_content, cell_metadata)
            
            # Add cell header for round-trip support
            if self.options.round_trip_metadata:
                header = self._format_cell_header(cell_metadata)
                full_content = f"{header}\n{markdown_content}\n{self.CELL_END_MARKER}"
            else:
                full_content = markdown_content
            
            self.stats.markdown_cells += 1
        else:
            full_content = ""
            self.stats.empty_cells += 1
        
        return full_content, cell_metadata
    
    def _process_raw_cell(self, cell: Dict[str, Any], cell_index: int) -> Tuple[str, Dict[str, Any]]:
        """Process a raw cell."""
        source = cell.get('source', '')
        if isinstance(source, list):
            source = ''.join(source)
        
        cell_metadata = self._generate_cell_metadata(cell, cell_index)
        
        if source.strip():
            # Apply theme formatting
            raw_content = self.theme.format_raw_cell(source, cell_metadata)
            
            # Add cell header for round-trip support
            if self.options.round_trip_metadata:
                header = self._format_cell_header(cell_metadata)
                full_content = f"{header}\n{raw_content}\n{self.CELL_END_MARKER}"
            else:
                full_content = raw_content
            
            self.stats.raw_cells += 1
        else:
            full_content = ""
            self.stats.empty_cells += 1
        
        return full_content, cell_metadata
    
    def _generate_file_header(self, input_path: Path, notebook_metadata: Dict[str, Any]) -> str:
        """Generate comprehensive file header."""
        header_lines = []
        
        # Shebang and encoding
        header_lines.extend([
            "#!/usr/bin/env python3",
            "# -*- coding: utf-8 -*-",
            '"""',
            f"Converted from Jupyter Notebook: {input_path.name}",
            f"Original path: {input_path}",
            f"Conversion date: {datetime.now().isoformat()}",
            f"Converter version: 3.0.0",
        ])
        
        # Add custom header if provided
        if self.options.custom_header:
            header_lines.extend(["", self.options.custom_header])
        
        # Preserve original metadata
        if self.options.preserve_metadata and notebook_metadata:
            header_lines.extend(["", "Original notebook metadata:"])
            metadata_str = json.dumps(notebook_metadata, indent=2)
            for line in metadata_str.split('\n'):
                header_lines.append(f"    {line}")
        
        header_lines.extend(['"""', ""])
        
        # Add execution info
        if self.options.add_execution_info:
            header_lines.extend([
                "# This file was automatically converted from a Jupyter notebook.",
                "# Original notebook structure and cell order have been preserved.",
                "# Markdown cells have been converted to semantic comments.",
                "",
            ])
        
        return '\n'.join(header_lines)
    
    async def convert_notebook_async(self, 
                                   input_path: Union[str, Path], 
                                   output_path: Optional[Union[str, Path]] = None) -> Tuple[Path, ConversionStats]:
        """Async version of notebook conversion."""
        return await asyncio.get_event_loop().run_in_executor(
            None, self.convert_notebook, input_path, output_path
        )
    
    def convert_notebook(self, 
                        input_path: Union[str, Path], 
                        output_path: Optional[Union[str, Path]] = None) -> Tuple[Path, ConversionStats]:
        """
        Convert a Jupyter notebook to a Python script.
        
        Args:
            input_path: Path to the input .ipynb file
            output_path: Path to the output .py file (optional)
            
        Returns:
            Tuple of (output file path, conversion statistics)
        """
        start_time = datetime.now()
        
        try:
            # Validate paths
            input_file = self._validate_input_file(input_path)
            
            if input_file.suffix.lower() not in ['.ipynb', '.py']:
                raise ValueError(f"Unsupported file type: {input_file.suffix}")
            
            if output_path is None:
                if input_file.suffix.lower() == '.ipynb':
                    output_file = input_file.with_suffix('.py')
                else:
                    output_file = input_file.with_suffix('.ipynb')
            else:
                output_file = Path(output_path).resolve()
                output_file.parent.mkdir(parents=True, exist_ok=True)
            
            self.logger.info(f"Converting {input_file} to {output_file}")
            
            # Reset statistics
            self.stats = ConversionStats()
            
            # Determine conversion mode
            if input_file.suffix.lower() == '.ipynb':
                content = self._convert_notebook_to_script(input_file)
            else:
                content = self._convert_script_to_notebook(input_file)
            
            # Perform quality analysis if requested
            if self.quality_analyzer and input_file.suffix.lower() == '.ipynb':
                try:
                    quality_results = self.quality_analyzer.analyze_code(content)
                    self.stats.quality_score = quality_results.get('score', 0.0)
                    self.stats.warnings.extend(quality_results.get('warnings', []))
                    self.stats.errors.extend(quality_results.get('errors', []))
                except Exception as e:
                    self.logger.warning(f"Quality analysis failed: {e}")
            
            # Write output
            output_file.write_text(content, encoding='utf-8')
            self.stats.output_size = len(content.encode('utf-8'))
            
            # Update final statistics
            self.stats.processing_time = (datetime.now() - start_time).total_seconds()
            
            self.logger.info("Conversion completed successfully")
            return output_file, self.stats
            
        except Exception as e:
            self.logger.error(f"Conversion failed: {e}")
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug(traceback.format_exc())
            raise ConversionError(f"Conversion failed: {e}") from e
    
    def _convert_notebook_to_script(self, input_path: Path) -> str:
        """Convert notebook to Python script."""
        # Load notebook
        if NBFORMAT_AVAILABLE:
            try:
                with open(input_path, 'r', encoding='utf-8') as f:
                    notebook = nbformat.read(f, as_version=nbformat.NO_CONVERT)
                cells = notebook.cells
                metadata = notebook.metadata
            except Exception as e:
                raise ConversionError(f"Failed to read notebook with nbformat: {e}")
        else:
            # Manual JSON parsing
            try:
                with open(input_path, 'r', encoding='utf-8') as f:
                    notebook_data = json.load(f)
                cells = notebook_data.get('cells', [])
                metadata = notebook_data.get('metadata', {})
            except json.JSONDecodeError as e:
                raise InvalidNotebookError(f"Invalid JSON in notebook: {e}")
        
        # Generate header
        output_lines = []
        header = self._generate_file_header(input_path, metadata)
        output_lines.append(header)
        
        # Process cells
        for cell_index, cell in enumerate(cells):
            self.stats.total_cells += 1
            
            cell_type = CellType(cell.get('cell_type', 'unknown'))
            
            try:
                if cell_type == CellType.CODE:
                    content, _ = self._process_code_cell(cell, cell_index)
                elif cell_type == CellType.MARKDOWN:
                    content, _ = self._process_markdown_cell(cell, cell_index)
                elif cell_type == CellType.RAW:
                    content, _ = self._process_raw_cell(cell, cell_index)
                else:
                    content = f"# Unknown cell type: {cell_type.value}"
                    self.stats.warnings.append(f"Unknown cell type: {cell_type.value}")
                
                if content.strip():
                    output_lines.append(content)
                    output_lines.append("")  # Add spacing between cells
                    
            except Exception as e:
                error_msg = f"Error processing cell {cell_index}: {e}"
                self.logger.error(error_msg)
                self.stats.errors.append(error_msg)
                output_lines.append(f"# ERROR: {error_msg}")
                output_lines.append("")
        
        return '\n'.join(output_lines)
    
    def _convert_script_to_notebook(self, input_path: Path) -> str:
        """Convert annotated Python script back to notebook format."""
        with open(input_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Parse round-trip metadata
        cells = self._parse_script_cells(content)
        
        # Create notebook structure
        notebook = {
            "cells": cells,
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                },
                "language_info": {
                    "name": "python",
                    "version": "3.8.0"
                }
            },
            "nbformat": 4,
            "nbformat_minor": 4
        }
        
        return json.dumps(notebook, indent=2, ensure_ascii=False)
    
    def _parse_script_cells(self, content: str) -> List[Dict[str, Any]]:
        """Parse script content to extract cell information."""
        cells = []
        lines = content.split('\n')
        current_cell = None
        current_content = []
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for cell start marker
            if line.startswith(self.CELL_START_MARKER):
                # Save previous cell if exists
                if current_cell:
                    current_cell['source'] = '\n'.join(current_content)
                    cells.append(current_cell)
                
                # Parse cell header
                current_cell = self._parse_cell_header(line)
                current_content = []
            
            # Check for metadata marker
            elif line.startswith(self.METADATA_MARKER):
                if current_cell:
                    metadata_json = line[len(self.METADATA_MARKER):-1].strip()
                    try:
                        cell_metadata = json.loads(metadata_json)
                        current_cell.update(cell_metadata)
                    except json.JSONDecodeError:
                        pass
            
            # Check for cell end marker
            elif line.startswith(self.CELL_END_MARKER):
                pass  # Just skip end markers
            
            # Regular content line
            else:
                if current_cell:
                    current_content.append(line)
            
            i += 1
        
        # Add final cell
        if current_cell:
            current_cell['source'] = '\n'.join(current_content)
            cells.append(current_cell)
        
        return cells
    
    def _parse_cell_header(self, header_line: str) -> Dict[str, Any]:
        """Parse cell header to extract metadata."""
        # Extract cell type and metadata from header
        # Example: # [CELL: CODE, index=0, id=cell-0, exec_count=1 ]
        
        cell = {
            "cell_type": "code",
            "metadata": {},
            "source": []
        }
        
        # Simple parsing - in production, use proper regex
        if "CODE" in header_line:
            cell["cell_type"] = "code"
            cell["execution_count"] = None
            cell["outputs"] = []
        elif "MARKDOWN" in header_line:
            cell["cell_type"] = "markdown"
        elif "RAW" in header_line:
            cell["cell_type"] = "raw"
        
        return cell
    
    def validate_round_trip(self, original_path: Union[str, Path], 
                           converted_path: Union[str, Path]) -> bool:
        """Validate round-trip conversion integrity."""
        try:
            # Convert original to script
            temp_script = self.convert_notebook(original_path)[0]
            
            # Convert script back to notebook  
            reconstructed = self.convert_notebook(temp_script)[0]
            
            # Compare structural integrity
            # This is a simplified validation - full implementation would
            # compare cell counts, types, and essential content
            
            return True
            
        except Exception as e:
            raise RoundTripError(f"Round-trip validation failed: {e}")