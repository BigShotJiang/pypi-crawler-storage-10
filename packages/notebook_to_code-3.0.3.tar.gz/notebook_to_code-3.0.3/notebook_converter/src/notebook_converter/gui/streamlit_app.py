"""
Streamlit GUI for notebook conversion.
"""

import streamlit as st
import tempfile
import zipfile
from pathlib import Path
from typing import Optional, List
import io
import sys
import os

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from ..converter import AdvancedNotebookConverter, ConversionOptions
    from ..utils.batch_processor import BatchProcessor
    from ..plugins.base import PluginManager
except ImportError:
    from notebook_converter.converter import AdvancedNotebookConverter, ConversionOptions
    from notebook_converter.utils.batch_processor import BatchProcessor
    from notebook_converter.plugins.base import PluginManager


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="Notebook Converter",
        page_icon="📓",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.title("🚀 Advanced Notebook Converter")
    st.markdown("Convert Jupyter notebooks to Python scripts with semantic markdown processing and round-trip support.")
    
    # Sidebar configuration
    st.sidebar.header("⚙️ Configuration")
    
    # Get available themes
    plugin_manager = PluginManager()
    themes = plugin_manager.list_themes()
    
    # Conversion options
    theme = st.sidebar.selectbox("Theme", themes, index=themes.index("default") if "default" in themes else 0)
    preserve_metadata = st.sidebar.checkbox("Preserve Metadata", value=True)
    round_trip_metadata = st.sidebar.checkbox("Round-trip Metadata", value=True)
    semantic_markdown = st.sidebar.checkbox("Semantic Markdown", value=True)
    quality_analysis = st.sidebar.checkbox("Quality Analysis", value=False)
    max_line_length = st.sidebar.slider("Max Line Length", 60, 120, 88)
    
    # Custom header
    custom_header = st.sidebar.text_area("Custom Header (optional)", height=100)
    
    # Main content tabs
    tab1, tab2, tab3 = st.tabs(["📄 Single File", "📁 Batch Processing", "🔄 Round-trip"])
    
    with tab1:
        single_file_conversion(
            theme, preserve_metadata, round_trip_metadata, semantic_markdown,
            quality_analysis, max_line_length, custom_header
        )
    
    with tab2:
        batch_conversion(
            theme, preserve_metadata, round_trip_metadata, semantic_markdown,
            quality_analysis, max_line_length, custom_header
        )
    
    with tab3:
        round_trip_conversion()


def single_file_conversion(theme: str, preserve_metadata: bool, round_trip_metadata: bool,
                          semantic_markdown: bool, quality_analysis: bool, max_line_length: int,
                          custom_header: str):
    """Handle single file conversion."""
    st.header("Single File Conversion")
    
    uploaded_file = st.file_uploader(
        "Choose a file",
        type=['ipynb', 'py'],
        help="Upload a Jupyter notebook (.ipynb) or Python script (.py)"
    )
    
    if uploaded_file is not None:
        # Display file info
        st.info(f"📁 File: {uploaded_file.name} ({uploaded_file.size} bytes)")
        
        # Convert button
        if st.button("🔄 Convert", type="primary"):
            try:
                with st.spinner("Converting..."):
                    # Create temporary file
                    with tempfile.NamedTemporaryFile(mode='wb', delete=False,
                                                   suffix=Path(uploaded_file.name).suffix) as tmp_file:
                        tmp_file.write(uploaded_file.getvalue())
                        tmp_path = Path(tmp_file.name)
                    
                    # Create conversion options
                    options = ConversionOptions(
                        preserve_metadata=preserve_metadata,
                        round_trip_metadata=round_trip_metadata,
                        semantic_markdown=semantic_markdown,
                        quality_analysis=quality_analysis,
                        theme=theme,
                        max_line_length=max_line_length,
                        custom_header=custom_header if custom_header.strip() else None
                    )
                    
                    # Perform conversion
                    converter = AdvancedNotebookConverter(options=options)
                    output_path, stats = converter.convert_notebook(tmp_path)
                    
                    # Read converted content
                    converted_content = output_path.read_text(encoding='utf-8')
                    
                    # Display results
                    st.success("✅ Conversion successful!")
                    
                    # Show statistics
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Total Cells", stats.total_cells)
                    with col2:
                        st.metric("Code Cells", stats.code_cells)
                    with col3:
                        st.metric("Markdown Cells", stats.markdown_cells)
                    with col4:
                        st.metric("Processing Time", f"{stats.processing_time:.2f}s")
                    
                    # Quality score if available
                    if stats.quality_score is not None:
                        st.metric("Quality Score", f"{stats.quality_score:.1f}/100")
                    
                    # Download button
                    output_filename = output_path.name
                    st.download_button(
                        label="📥 Download Converted File",
                        data=converted_content,
                        file_name=output_filename,
                        mime="text/plain"
                    )
                    
                    # Preview
                    with st.expander("👀 Preview", expanded=False):
                        st.code(converted_content[:2000] + ("..." if len(converted_content) > 2000 else ""), 
                               language="python")
                    
                    # Warnings and errors
                    if stats.warnings:
                        with st.expander(f"⚠️ Warnings ({len(stats.warnings)})", expanded=False):
                            for warning in stats.warnings:
                                st.warning(warning)
                    
                    if stats.errors:
                        with st.expander(f"❌ Errors ({len(stats.errors)})", expanded=False):
                            for error in stats.errors:
                                st.error(error)
                    
                    # Cleanup
                    tmp_path.unlink(missing_ok=True)
                    output_path.unlink(missing_ok=True)
                    
            except Exception as e:
                st.error(f"❌ Conversion failed: {e}")


def batch_conversion(theme: str, preserve_metadata: bool, round_trip_metadata: bool,
                    semantic_markdown: bool, quality_analysis: bool, max_line_length: int,
                    custom_header: str):
    """Handle batch file conversion."""
    st.header("Batch Processing")
    
    uploaded_files = st.file_uploader(
        "Choose multiple files",
        type=['ipynb'],
        accept_multiple_files=True,
        help="Upload multiple Jupyter notebooks for batch conversion"
    )
    
    if uploaded_files:
        st.info(f"📁 {len(uploaded_files)} files selected")
        
        # Show file list
        with st.expander("📋 File List", expanded=True):
            for file in uploaded_files:
                st.write(f"• {file.name} ({file.size} bytes)")
        
        # Batch convert button
        if st.button("🔄 Convert All", type="primary"):
            try:
                with st.spinner("Converting files..."):
                    # Create progress bar
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    # Create temporary directory
                    with tempfile.TemporaryDirectory() as tmp_dir:
                        tmp_path = Path(tmp_dir)
                        
                        # Save uploaded files
                        input_files = []
                        for i, file in enumerate(uploaded_files):
                            file_path = tmp_path / file.name
                            file_path.write_bytes(file.getvalue())
                            input_files.append(file_path)
                        
                        # Create conversion options
                        options = ConversionOptions(
                            preserve_metadata=preserve_metadata,
                            round_trip_metadata=round_trip_metadata,
                            semantic_markdown=semantic_markdown,
                            quality_analysis=quality_analysis,
                            theme=theme,
                            max_line_length=max_line_length,
                            custom_header=custom_header if custom_header.strip() else None
                        )
                        
                        # Process batch
                        processor = BatchProcessor()
                        
                        def progress_callback(completed: int, total: int):
                            progress = completed / total
                            progress_bar.progress(progress)
                            status_text.text(f"Processing {completed}/{total} files...")
                        
                        results = processor.process_batch(
                            [{"input_path": f, "options": options} for f in input_files],
                            parallel=False,  # Disable parallel for Streamlit
                            progress_callback=progress_callback
                        )
                        
                        # Display results
                        st.success(f"✅ Batch conversion completed!")
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Successful", len(results.successful))
                        with col2:
                            st.metric("Failed", len(results.failed))
                        with col3:
                            st.metric("Total Time", f"{results.total_time:.2f}s")
                        
                        # Create zip file for download
                        zip_buffer = io.BytesIO()
                        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                            for output_path in results.successful:
                                if output_path.exists():
                                    zip_file.write(output_path, output_path.name)
                        
                        zip_buffer.seek(0)
                        
                        # Download button
                        st.download_button(
                            label="📥 Download All Converted Files",
                            data=zip_buffer.getvalue(),
                            file_name="converted_notebooks.zip",
                            mime="application/zip"
                        )
                        
                        # Show failed files
                        if results.failed:
                            with st.expander(f"❌ Failed Files ({len(results.failed)})", expanded=False):
                                for file_path, error in results.failed:
                                    st.error(f"{file_path.name}: {error}")
                
            except Exception as e:
                st.error(f"❌ Batch conversion failed: {e}")


def round_trip_conversion():
    """Handle round-trip conversion testing."""
    st.header("Round-trip Conversion Testing")
    st.markdown("Test the integrity of notebook ↔ script ↔ notebook conversion.")
    
    uploaded_file = st.file_uploader(
        "Choose a notebook file",
        type=['ipynb'],
        key="roundtrip",
        help="Upload a Jupyter notebook to test round-trip conversion"
    )
    
    if uploaded_file is not None:
        st.info(f"📁 File: {uploaded_file.name}")
        
        if st.button("🔄 Test Round-trip", type="primary"):
            try:
                with st.spinner("Testing round-trip conversion..."):
                    # Create temporary files
                    with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.ipynb') as tmp_nb:
                        tmp_nb.write(uploaded_file.getvalue())
                        original_path = Path(tmp_nb.name)
                    
                    # Step 1: Convert to script
                    options = ConversionOptions(round_trip_metadata=True)
                    converter = AdvancedNotebookConverter(options=options)
                    
                    st.info("Step 1: Converting notebook to script...")
                    script_path, stats1 = converter.convert_notebook(original_path)
                    
                    # Step 2: Convert back to notebook
                    st.info("Step 2: Converting script back to notebook...")
                    recreated_path, stats2 = converter.convert_notebook(script_path)
                    
                    # Step 3: Validate
                    st.info("Step 3: Validating integrity...")
                    is_valid = converter.validate_round_trip(original_path, recreated_path)
                    
                    if is_valid:
                        st.success("✅ Round-trip conversion successful!")
                        
                        # Show comparison metrics
                        col1, col2 = st.columns(2)
                        with col1:
                            st.subheader("Original → Script")
                            st.metric("Cells Processed", stats1.total_cells)
                            st.metric("Processing Time", f"{stats1.processing_time:.2f}s")
                        
                        with col2:
                            st.subheader("Script → Notebook")  
                            st.metric("Cells Recreated", stats2.total_cells)
                            st.metric("Processing Time", f"{stats2.processing_time:.2f}s")
                        
                        # Download options
                        col1, col2 = st.columns(2)
                        with col1:
                            script_content = script_path.read_text(encoding='utf-8')
                            st.download_button(
                                "📥 Download Script",
                                data=script_content,
                                file_name=script_path.name,
                                mime="text/plain"
                            )
                        
                        with col2:
                            notebook_content = recreated_path.read_text(encoding='utf-8')
                            st.download_button(
                                "📥 Download Recreated Notebook",
                                data=notebook_content,
                                file_name=recreated_path.name,
                                mime="application/json"
                            )
                    
                    else:
                        st.error("❌ Round-trip validation failed!")
                        st.warning("The recreated notebook may not be identical to the original.")
                    
                    # Cleanup
                    for path in [original_path, script_path, recreated_path]:
                        path.unlink(missing_ok=True)
                        
            except Exception as e:
                st.error(f"❌ Round-trip test failed: {e}")


if __name__ == "__main__":
    main()