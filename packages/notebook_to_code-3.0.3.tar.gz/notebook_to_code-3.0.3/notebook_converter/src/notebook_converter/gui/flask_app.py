"""
Flask GUI for notebook conversion.
"""

from flask import Flask, render_template, request, jsonify, send_file
from flask_cors import CORS
import tempfile
import zipfile
from pathlib import Path
import json
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from ..converter import AdvancedNotebookConverter, ConversionOptions
    from ..utils.batch_processor import BatchProcessor
    from ..plugins.base import PluginManager
except ImportError:
    from notebook_converter.converter import AdvancedNotebookConverter, ConversionOptions
    from notebook_converter.utils.batch_processor import BatchProcessor
    from notebook_converter.plugins.base import PluginManager


app = Flask(__name__)
CORS(app)

# Configure upload folder
UPLOAD_FOLDER = tempfile.gettempdir()
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size


@app.route('/')
def index():
    """Main page."""
    plugin_manager = PluginManager()
    themes = plugin_manager.list_themes()
    return render_template('index.html', themes=themes)


@app.route('/api/convert', methods=['POST'])
def convert_file():
    """Convert a single file."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get conversion options
        options_data = request.form.get('options', '{}')
        options_dict = json.loads(options_data)
        
        options = ConversionOptions(
            preserve_metadata=options_dict.get('preserve_metadata', True),
            round_trip_metadata=options_dict.get('round_trip_metadata', True),
            semantic_markdown=options_dict.get('semantic_markdown', True),
            quality_analysis=options_dict.get('quality_analysis', False),
            theme=options_dict.get('theme', 'default'),
            max_line_length=options_dict.get('max_line_length', 88),
            custom_header=options_dict.get('custom_header')
        )
        
        # Save uploaded file
        filename = file.filename
        input_path = Path(app.config['UPLOAD_FOLDER']) / filename
        file.save(input_path)
        
        # Perform conversion
        converter = AdvancedNotebookConverter(options=options)
        output_path, stats = converter.convert_notebook(input_path)
        
        # Read converted content
        converted_content = output_path.read_text(encoding='utf-8')
        
        # Prepare response
        response_data = {
            'success': True,
            'filename': output_path.name,
            'content': converted_content,
            'stats': {
                'total_cells': stats.total_cells,
                'code_cells': stats.code_cells,
                'markdown_cells': stats.markdown_cells,
                'raw_cells': stats.raw_cells,
                'empty_cells': stats.empty_cells,
                'processing_time': stats.processing_time,
                'output_size': stats.output_size,
                'quality_score': stats.quality_score,
                'warnings': stats.warnings,
                'errors': stats.errors
            }
        }
        
        # Cleanup
        input_path.unlink(missing_ok=True)
        output_path.unlink(missing_ok=True)
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/batch-convert', methods=['POST'])
def batch_convert():
    """Convert multiple files."""
    try:
        files = request.files.getlist('files')
        if not files:
            return jsonify({'error': 'No files provided'}), 400
        
        # Get conversion options
        options_data = request.form.get('options', '{}')
        options_dict = json.loads(options_data)
        
        options = ConversionOptions(
            preserve_metadata=options_dict.get('preserve_metadata', True),
            round_trip_metadata=options_dict.get('round_trip_metadata', True),
            semantic_markdown=options_dict.get('semantic_markdown', True),
            quality_analysis=options_dict.get('quality_analysis', False),
            theme=options_dict.get('theme', 'default'),
            max_line_length=options_dict.get('max_line_length', 88),
            custom_header=options_dict.get('custom_header')
        )
        
        # Create temporary directory
        temp_dir = Path(tempfile.mkdtemp())
        
        # Save uploaded files
        input_files = []
        for file in files:
            if file.filename:
                file_path = temp_dir / file.filename
                file.save(file_path)
                input_files.append(file_path)
        
        # Process batch
        processor = BatchProcessor()
        from notebook_converter.utils.batch_processor import BatchJob
        
        jobs = [BatchJob(input_path=f, options=options) for f in input_files]
        results = processor.process_batch(jobs, parallel=False)
        
        # Create zip file
        zip_path = temp_dir / 'converted_files.zip'
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for output_path in results.successful:
                if output_path.exists():
                    zip_file.write(output_path, output_path.name)
        
        # Prepare response
        response_data = {
            'success': True,
            'results': {
                'successful_count': len(results.successful),
                'failed_count': len(results.failed),
                'total_time': results.total_time,
                'failed_files': [(str(path), error) for path, error in results.failed]
            },
            'download_url': f'/api/download/{zip_path.name}'
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/download/<filename>')
def download_file(filename):
    """Download converted file."""
    try:
        file_path = Path(app.config['UPLOAD_FOLDER']) / filename
        if file_path.exists():
            return send_file(file_path, as_attachment=True)
        else:
            return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/themes')
def get_themes():
    """Get available themes."""
    try:
        plugin_manager = PluginManager()
        themes_data = []
        
        for theme_name in plugin_manager.list_themes():
            theme = plugin_manager.get_theme(theme_name)
            themes_data.append({
                'name': theme.name,
                'description': theme.description
            })
        
        return jsonify({'themes': themes_data})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)