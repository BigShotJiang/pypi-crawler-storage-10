
from dataclasses import dataclass
from typing import Optional, List, Dict, Any

@dataclass
class ConversionOptions:
    preserve_metadata: bool = True
    add_execution_info: bool = True
    max_line_length: int = 88
    semantic_markdown: bool = True
    round_trip_metadata: bool = True
    quality_analysis: bool = False
    theme: str = "default"
    custom_header: Optional[str] = None
    strip_outputs: bool = True
    preserve_cell_ids: bool = True
    add_timestamps: bool = True

@dataclass 
class ConversionStats:
    total_cells: int = 0
    code_cells: int = 0
    markdown_cells: int = 0
    raw_cells: int = 0
    empty_cells: int = 0
    processing_time: float = 0.0
    output_size: int = 0
    quality_score: Optional[float] = None
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)