"""
Batch processing utilities for converting multiple notebooks.
"""

import asyncio
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable
import logging
from dataclasses import dataclass

from ..converter import AdvancedNotebookConverter, ConversionOptions, ConversionStats



@dataclass
class BatchJob:
    """Represents a single conversion job in a batch."""
    input_path: Path
    output_path: Optional[Path] = None
    options: Optional[ConversionOptions] = None


@dataclass
class BatchResults:
    """Results from batch processing."""
    successful: List[Path]
    failed: List[Tuple[Path, str]]
    stats: List[ConversionStats]
    total_time: float
    
    def __str__(self) -> str:
        return (
            f"Batch Processing Results:\n"
            f"  Successful: {len(self.successful)}\n"
            f"  Failed: {len(self.failed)}\n"
            f"  Total time: {self.total_time:.2f}s\n"
            f"  Average time per file: {self.total_time / max(1, len(self.successful)):.2f}s"
        )


class BatchProcessor:
    """Handles batch processing of multiple notebooks."""
    
    def __init__(self, 
                 max_workers: Optional[int] = None,
                 logger: Optional[logging.Logger] = None):
        """
        Initialize batch processor.
        
        Args:
            max_workers: Maximum number of worker processes
            logger: Custom logger instance
        """
        self.max_workers = max_workers or mp.cpu_count()
        self.logger = logger or logging.getLogger(self.__class__.__name__)
    
    def process_directory(self, 
                         input_dir: Path, 
                         output_dir: Optional[Path] = None,
                         pattern: str = "*.ipynb",
                         options: Optional[ConversionOptions] = None,
                         parallel: bool = True) -> BatchResults:
        """
        Process all notebooks in a directory.
        
        Args:
            input_dir: Directory containing notebooks
            output_dir: Output directory (optional)
            pattern: File pattern to match
            options: Conversion options
            parallel: Whether to use parallel processing
            
        Returns:
            Batch processing results
        """
        input_path = Path(input_dir)
        if not input_path.exists() or not input_path.is_dir():
            raise ValueError(f"Input directory does not exist: {input_path}")
        
        # Find all matching files
        notebook_files = list(input_path.glob(pattern))
        if not notebook_files:
            self.logger.warning(f"No files matching '{pattern}' found in {input_path}")
            return BatchResults([], [], [], 0.0)
        
        # Create batch jobs
        jobs = []
        for nb_file in notebook_files:
            output_file = None
            if output_dir:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                output_file = output_path / nb_file.with_suffix('.py').name
            
            jobs.append(BatchJob(
                input_path=nb_file,
                output_path=output_file,
                options=options
            ))
        
        return self.process_batch(jobs, parallel=parallel)
    
    def process_batch(self, 
                     jobs: List[BatchJob], 
                     parallel: bool = True,
                     progress_callback: Optional[Callable[[int, int], None]] = None) -> BatchResults:
        """
        Process a batch of conversion jobs.
        
        Args:
            jobs: List of conversion jobs
            parallel: Whether to use parallel processing
            progress_callback: Optional progress callback function
            
        Returns:
            Batch processing results
        """
        import time
        start_time = time.time()
        
        successful = []
        failed = []
        stats = []
        
        if parallel and len(jobs) > 1:
            results = self._process_parallel(jobs, progress_callback)
        else:
            results = self._process_sequential(jobs, progress_callback)
        
        # Process results
        for job, result in results:
            if isinstance(result, Exception):
                failed.append((job.input_path, str(result)))
                self.logger.error(f"Failed to convert {job.input_path}: {result}")
            else:
                output_path, job_stats = result
                successful.append(output_path)
                stats.append(job_stats)
                self.logger.info(f"Successfully converted {job.input_path} -> {output_path}")
        
        total_time = time.time() - start_time
        
        return BatchResults(
            successful=successful,
            failed=failed,
            stats=stats,
            total_time=total_time
        )
    
    def _process_parallel(self, 
                         jobs: List[BatchJob],
                         progress_callback: Optional[Callable[[int, int], None]] = None) -> List[Tuple[BatchJob, Any]]:
        """Process jobs in parallel using multiprocessing."""
        results = []
        
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all jobs
            future_to_job = {
                executor.submit(_convert_single_job, job): job 
                for job in jobs
            }
            
            # Collect results as they complete
            completed = 0
            for future in as_completed(future_to_job):
                job = future_to_job[future]
                try:
                    result = future.result()
                    results.append((job, result))
                except Exception as e:
                    results.append((job, e))
                
                completed += 1
                if progress_callback:
                    progress_callback(completed, len(jobs))
        
        return results
    
    def _process_sequential(self, 
                           jobs: List[BatchJob],
                           progress_callback: Optional[Callable[[int, int], None]] = None) -> List[Tuple[BatchJob, Any]]:
        """Process jobs sequentially."""
        results = []
        
        for i, job in enumerate(jobs):
            try:
                result = _convert_single_job(job)
                results.append((job, result))
            except Exception as e:
                results.append((job, e))
            
            if progress_callback:
                progress_callback(i + 1, len(jobs))
        
        return results


def _convert_single_job(job: BatchJob) -> Tuple[Path, ConversionStats]:
    """
    Convert a single notebook job (used for multiprocessing).
    
    Args:
        job: Batch job to process
        
    Returns:
        Tuple of output path and conversion stats
    """
    converter = AdvancedNotebookConverter(options=job.options)
    return converter.convert_notebook(job.input_path, job.output_path)