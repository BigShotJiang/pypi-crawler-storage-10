"""
Semantic Markdown Processing for Notebook Conversion.

Converts Markdown cells to clean, readable Python comments while preserving
structure, lists, tables, and links in a comment-friendly format.
"""

import re
from typing import List, Tuple, Dict, Any
from dataclasses import dataclass, field


@dataclass
class MarkdownElement:
    """Represents a parsed markdown element."""
    element_type: str
    content: str
    level: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


class MarkdownProcessor:
    """Advanced markdown to comment processor with semantic understanding."""
    
    def __init__(self, max_line_length: int = 88, semantic_mode: bool = True):
        """
        Initialize markdown processor.
        
        Args:
            max_line_length: Maximum line length for wrapped comments
            semantic_mode: Enable semantic processing of markdown elements
        """
        self.max_line_length = max_line_length
        self.semantic_mode = semantic_mode
        self.comment_prefix = "# "
        
        # Regex patterns for markdown elements
        self.patterns = {
            'header': re.compile(r'^(#{1,6})\s+(.+), re.MULTILINE'),
            'bold': re.compile(r'\*\*(.*?)\*\*'),
            'italic': re.compile(r'\*(.*?)\*'),
            'code_inline': re.compile(r'`([^`]+)`'),
            'code_block': re.compile(r'```(\w+)?\n(.*?)\n```', re.DOTALL),
            'link': re.compile(r'\[([^\]]+)\]\(([^)]+)\)'),
            'image': re.compile(r'!\[([^\]]*)\]\(([^)]+)\)'),
            'list_item': re.compile(r'^(\s*)([-*+]|\d+\.)\s+(.+), re.MULTILINE'),
            'table_row': re.compile(r'\|(.+)\|'),
            'horizontal_rule': re.compile(r'^(-{3,}|\*{3,}|_{3,}), re.MULTILINE'),
            'blockquote': re.compile(r'^>\s+(.+), re.MULTILINE'),
        }
    
    def convert_to_comments(self, markdown_text: str) -> str:
        """
        Convert markdown text to semantically meaningful Python comments.
        
        Args:
            markdown_text: Raw markdown content
            
        Returns:
            Processed markdown as Python comments
        """
        if not markdown_text.strip():
            return ""
        
        if not self.semantic_mode:
            return self._simple_comment_conversion(markdown_text)
        
        # Parse markdown into semantic elements
        elements = self._parse_markdown(markdown_text)
        
        # Convert elements to comments
        comment_lines = []
        for element in elements:
            converted = self._convert_element_to_comment(element)
            if converted:
                comment_lines.extend(converted)
        
        return '\n'.join(comment_lines)
    
    def _simple_comment_conversion(self, text: str) -> str:
        """Simple line-by-line comment conversion."""
        lines = text.split('\n')
        comment_lines = []
        
        for line in lines:
            if line.strip():
                wrapped = self._wrap_text(line, self.comment_prefix)
                comment_lines.extend(wrapped)
            else:
                comment_lines.append(self.comment_prefix.rstrip())
        
        return '\n'.join(comment_lines)
    
    def _parse_markdown(self, text: str) -> List[MarkdownElement]:
        """Parse markdown text into semantic elements."""
        elements = []
        lines = text.split('\n')
        current_element = None
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for headers
            header_match = self.patterns['header'].match(line)
            if header_match:
                level = len(header_match.group(1))
                content = header_match.group(2).strip()
                elements.append(MarkdownElement(
                    element_type='header',
                    content=content,
                    level=level
                ))
                i += 1
                continue
            
            # Check for code blocks
            remaining_text = '\n'.join(lines[i:])
            code_match = self.patterns['code_block'].match(remaining_text)
            if code_match:
                language = code_match.group(1) or ''
                code_content = code_match.group(2)
                elements.append(MarkdownElement(
                    element_type='code_block',
                    content=code_content,
                    metadata={'language': language}
                ))
                # Skip processed lines
                i += len(code_match.group(0).split('\n')) - 1
                continue
            
            # Check for list items
            list_match = self.patterns['list_item'].match(line)
            if list_match:
                indent = len(list_match.group(1))
                marker = list_match.group(2)
                content = list_match.group(3)
                elements.append(MarkdownElement(
                    element_type='list_item',
                    content=content,
                    level=indent // 2,  # Approximate nesting level
                    metadata={'marker': marker}
                ))
                i += 1
                continue
            
            # Check for table rows
            table_match = self.patterns['table_row'].match(line)
            if table_match:
                cells = [cell.strip() for cell in table_match.group(1).split('|')]
                elements.append(MarkdownElement(
                    element_type='table_row',
                    content='',
                    metadata={'cells': cells}
                ))
                i += 1
                continue
            
            # Check for blockquotes
            quote_match = self.patterns['blockquote'].match(line)
            if quote_match:
                content = quote_match.group(1)
                elements.append(MarkdownElement(
                    element_type='blockquote',
                    content=content
                ))
                i += 1
                continue
            
            # Check for horizontal rules
            hr_match = self.patterns['horizontal_rule'].match(line)
            if hr_match:
                elements.append(MarkdownElement(
                    element_type='horizontal_rule',
                    content=''
                ))
                i += 1
                continue
            
            # Regular paragraph text
            if line.strip():
                # Process inline formatting
                processed_line = self._process_inline_formatting(line)
                elements.append(MarkdownElement(
                    element_type='paragraph',
                    content=processed_line
                ))
            else:
                elements.append(MarkdownElement(
                    element_type='empty_line',
                    content=''
                ))
            
            i += 1
        
        return elements
    
    def _process_inline_formatting(self, text: str) -> str:
        """Process inline markdown formatting."""
        # Handle links
        text = self.patterns['link'].sub(r'\1 (\2)', text)
        
        # Handle images
        text = self.patterns['image'].sub(r'[Image: \1] (\2)', text)
        
        # Handle inline code
        text = self.patterns['code_inline'].sub(r'`\1`', text)
        
        # Handle bold (keep minimal formatting)
        text = self.patterns['bold'].sub(r'\1', text)
        
        # Handle italic (keep minimal formatting)
        text = self.patterns['italic'].sub(r'\1', text)
        
        return text
    
    def _convert_element_to_comment(self, element: MarkdownElement) -> List[str]:
        """Convert a markdown element to comment lines."""
        if element.element_type == 'header':
            return self._format_header(element)
        elif element.element_type == 'paragraph':
            return self._format_paragraph(element)
        elif element.element_type == 'list_item':
            return self._format_list_item(element)
        elif element.element_type == 'code_block':
            return self._format_code_block(element)
        elif element.element_type == 'table_row':
            return self._format_table_row(element)
        elif element.element_type == 'blockquote':
            return self._format_blockquote(element)
        elif element.element_type == 'horizontal_rule':
            return self._format_horizontal_rule(element)
        elif element.element_type == 'empty_line':
            return [self.comment_prefix.rstrip()]
        else:
            return self._wrap_text(element.content, self.comment_prefix)
    
    def _format_header(self, element: MarkdownElement) -> List[str]:
        """Format header elements."""
        level_prefix = "=" * element.level
        header_text = f"{level_prefix} {element.content} {level_prefix}"
        
        # Add visual separation
        lines = [self.comment_prefix.rstrip()]  # Empty comment line
        lines.extend(self._wrap_text(header_text, self.comment_prefix))
        lines.append(self.comment_prefix.rstrip())  # Empty comment line
        
        return lines
    
    def _format_paragraph(self, element: MarkdownElement) -> List[str]:
        """Format paragraph elements."""
        return self._wrap_text(element.content, self.comment_prefix)
    
    def _format_list_item(self, element: MarkdownElement) -> List[str]:
        """Format list item elements."""
        indent = "  " * element.level
        marker = element.metadata.get('marker', '-')
        
        # Convert numbered lists to simple bullets for comments
        if marker.endswith('.'):
            marker = '-'
        
        list_prefix = f"{self.comment_prefix}{indent}{marker} "
        continuation_prefix = f"{self.comment_prefix}{indent}  "
        
        lines = self._wrap_text(element.content, list_prefix)
        
        # Use continuation prefix for wrapped lines
        if len(lines) > 1:
            wrapped_lines = [lines[0]]
            for line in lines[1:]:
                wrapped_lines.append(continuation_prefix + line[len(self.comment_prefix):])
            return wrapped_lines
        
        return lines
    
    def _format_code_block(self, element: MarkdownElement) -> List[str]:
        """Format code block elements."""
        language = element.metadata.get('language', '')
        lines = [f"{self.comment_prefix}Code block ({language}):"]
        
        for code_line in element.content.split('\n'):
            lines.append(f"{self.comment_prefix}  {code_line}")
        
        return lines
    
    def _format_table_row(self, element: MarkdownElement) -> List[str]:
        """Format table row elements."""
        cells = element.metadata.get('cells', [])
        if not cells:
            return []
        
        # Create simple table representation
        table_line = " | ".join(cells)
        return self._wrap_text(f"Table: {table_line}", self.comment_prefix)
    
    def _format_blockquote(self, element: MarkdownElement) -> List[str]:
        """Format blockquote elements."""
        quote_prefix = f"{self.comment_prefix}> "
        return self._wrap_text(element.content, quote_prefix)
    
    def _format_horizontal_rule(self, element: MarkdownElement) -> List[str]:
        """Format horizontal rule elements."""
        rule = "-" * (self.max_line_length - len(self.comment_prefix))
        return [f"{self.comment_prefix}{rule}"]
    
    def _wrap_text(self, text: str, prefix: str) -> List[str]:
        """Wrap text to specified width with prefix."""
        if not text.strip():
            return [prefix.rstrip()]
        
        max_content_length = self.max_line_length - len(prefix)
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            test_line = current_line + (" " if current_line else "") + word
            if len(test_line) <= max_content_length:
                current_line = test_line
            else:
                if current_line:
                    lines.append(prefix + current_line)
                current_line = word
        
        if current_line:
            lines.append(prefix + current_line)
        
        return lines if lines else [prefix.rstrip()]