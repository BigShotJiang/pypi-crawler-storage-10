"""
Code quality analysis for converted notebooks.
"""

import ast
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging


class QualityAnalyzer:
    """Analyzes code quality of converted notebooks."""
    
    def __init__(self, enable_external_tools: bool = True):
        """
        Initialize quality analyzer.
        
        Args:
            enable_external_tools: Whether to use external tools like pylint, flake8
        """
        self.enable_external_tools = enable_external_tools
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Check availability of external tools
        self.available_tools = self._check_tool_availability()
    
    def _check_tool_availability(self) -> Dict[str, bool]:
        """Check which external tools are available."""
        tools = {}
        for tool in ['pylint', 'flake8', 'bandit']:
            try:
                subprocess.run([tool, '--version'], 
                             capture_output=True, check=True)
                tools[tool] = True
            except (subprocess.CalledProcessError, FileNotFoundError):
                tools[tool] = False
        
        return tools
    
    def analyze_code(self, code_content: str) -> Dict[str, Any]:
        """
        Perform comprehensive code quality analysis.
        
        Args:
            code_content: Python code to analyze
            
        Returns:
            Analysis results with scores, warnings, and errors
        """
        results = {
            'score': 0.0,
            'warnings': [],
            'errors': [],
            'metrics': {},
            'suggestions': []
        }
        
        try:
            # Parse code with AST for basic analysis
            ast_results = self._analyze_with_ast(code_content)
            results['metrics'].update(ast_results)
            
            # Run external tools if available and enabled
            if self.enable_external_tools:
                external_results = self._analyze_with_external_tools(code_content)
                results['warnings'].extend(external_results.get('warnings', []))
                results['errors'].extend(external_results.get('errors', []))
                
                # Calculate composite score
                results['score'] = self._calculate_quality_score(
                    ast_results, external_results
                )
            else:
                results['score'] = self._calculate_basic_score(ast_results)
            
            # Generate suggestions
            results['suggestions'] = self._generate_suggestions(results)
            
        except Exception as e:
            self.logger.error(f"Quality analysis failed: {e}")
            results['errors'].append(f"Analysis failed: {e}")
        
        return results
    
    def _analyze_with_ast(self, code: str) -> Dict[str, Any]:
        """Analyze code using Python AST."""
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return {
                'syntax_errors': [f"Syntax error at line {e.lineno}: {e.msg}"],
                'lines_of_code': len(code.split('\n')),
                'complexity': 0
            }
        
        # Count various code elements
        visitor = CodeMetricsVisitor()
        visitor.visit(tree)
        
        return {
            'lines_of_code': len(code.split('\n')),
            'functions': visitor.function_count,
            'classes': visitor.class_count,
            'imports': visitor.import_count,
            'complexity': visitor.complexity,
            'syntax_errors': []
        }
    
    def _analyze_with_external_tools(self, code: str) -> Dict[str, Any]:
        """Run external code analysis tools."""
        results = {'warnings': [], 'errors': []}
        
        # Create temporary file for analysis
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_file = Path(f.name)
        
        try:
            # Run pylint
            if self.available_tools.get('pylint'):
                pylint_results = self._run_pylint(temp_file)
                results['warnings'].extend(pylint_results)
            
            # Run flake8
            if self.available_tools.get('flake8'):
                flake8_results = self._run_flake8(temp_file)
                results['warnings'].extend(flake8_results)
            
            # Run bandit for security analysis
            if self.available_tools.get('bandit'):
                bandit_results = self._run_bandit(temp_file)
                results['warnings'].extend(bandit_results)
        
        finally:
            # Clean up temporary file
            temp_file.unlink(missing_ok=True)
        
        return results
    
    def _run_pylint(self, file_path: Path) -> List[str]:
        """Run pylint analysis."""
        try:
            result = subprocess.run(
                ['pylint', '--output-format=json', str(file_path)],
                capture_output=True, text=True
            )
            
            if result.stdout:
                import json
                issues = json.loads(result.stdout)
                return [f"Line {issue['line']}: {issue['message']}" for issue in issues]
        
        except Exception as e:
            self.logger.debug(f"Pylint analysis failed: {e}")
        
        return []
    
    def _run_flake8(self, file_path: Path) -> List[str]:
        """Run flake8 analysis."""
        try:
            result = subprocess.run(
                ['flake8', '--format=json', str(file_path)],
                capture_output=True, text=True
            )
            
            warnings = []
            for line in result.stdout.split('\n'):
                if line.strip():
                    warnings.append(line.strip())
            
            return warnings
        
        except Exception as e:
            self.logger.debug(f"Flake8 analysis failed: {e}")
        
        return []
    
    def _run_bandit(self, file_path: Path) -> List[str]:
        """Run bandit security analysis."""
        try:
            result = subprocess.run(
                ['bandit', '-f', 'json', str(file_path)],
                capture_output=True, text=True
            )
            
            if result.stdout:
                import json
                data = json.loads(result.stdout)
                return [
                    f"Security issue at line {issue['line_number']}: {issue['issue_text']}"
                    for issue in data.get('results', [])
                ]
        
        except Exception as e:
            self.logger.debug(f"Bandit analysis failed: {e}")
        
        return []
    
    def _calculate_quality_score(self, ast_results: Dict[str, Any], 
                               external_results: Dict[str, Any]) -> float:
        """Calculate composite quality score."""
        base_score = 100.0
        
        # Deduct for syntax errors
        base_score -= len(ast_results.get('syntax_errors', [])) * 20
        
        # Deduct for external tool warnings
        base_score -= len(external_results.get('warnings', [])) * 2
        base_score -= len(external_results.get('errors', [])) * 10
        
        # Complexity penalty
        complexity = ast_results.get('complexity', 0)
        if complexity > 10:
            base_score -= (complexity - 10) * 3
        
        return max(0.0, min(100.0, base_score))
    
    def _calculate_basic_score(self, ast_results: Dict[str, Any]) -> float:
        """Calculate basic quality score without external tools."""
        base_score = 100.0
        
        # Deduct for syntax errors
        base_score -= len(ast_results.get('syntax_errors', [])) * 30
        
        # Complexity penalty
        complexity = ast_results.get('complexity', 0)
        if complexity > 15:
            base_score -= (complexity - 15) * 5
        
        return max(0.0, min(100.0, base_score))
    
    def _generate_suggestions(self, results: Dict[str, Any]) -> List[str]:
        """Generate improvement suggestions based on analysis."""
        suggestions = []
        
        if results['score'] < 70:
            suggestions.append("Consider refactoring code to improve quality score")
        
        if len(results['errors']) > 0:
            suggestions.append("Fix syntax errors before proceeding")
        
        if results['metrics'].get('complexity', 0) > 10:
            suggestions.append("Consider breaking down complex functions")
        
        return suggestions


class CodeMetricsVisitor(ast.NodeVisitor):
    """AST visitor for collecting code metrics."""
    
    def __init__(self):
        self.function_count = 0
        self.class_count = 0
        self.import_count = 0
        self.complexity = 0
    
    def visit_FunctionDef(self, node):
        self.function_count += 1
        self.complexity += self._calculate_complexity(node)
        self.generic_visit(node)
    
    def visit_AsyncFunctionDef(self, node):
        self.function_count += 1
        self.complexity += self._calculate_complexity(node)
        self.generic_visit(node)
    
    def visit_ClassDef(self, node):
        self.class_count += 1
        self.generic_visit(node)
    
    def visit_Import(self, node):
        self.import_count += len(node.names)
        self.generic_visit(node)
    
    def visit_ImportFrom(self, node):
        self.import_count += len(node.names) if node.names else 1
        self.generic_visit(node)
    
    def _calculate_complexity(self, node) -> int:
        """Calculate cyclomatic complexity for a function."""
        complexity = 1  # Base complexity
        
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.AsyncFor)):
                complexity += 1
            elif isinstance(child, ast.ExceptHandler):
                complexity += 1
        
        return complexity