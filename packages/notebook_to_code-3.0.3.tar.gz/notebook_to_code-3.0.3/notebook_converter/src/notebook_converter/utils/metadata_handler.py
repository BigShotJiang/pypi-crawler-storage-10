"""
Metadata handling for round-trip notebook conversion.
"""

import json
from typing import Dict, Any, Optional
from datetime import datetime


class MetadataHandler:
    """Handles notebook metadata for round-trip conversion."""
    
    def __init__(self):
        """Initialize metadata handler."""
        self.preserved_keys = {
            'kernelspec', 'language_info', 'widgets', 'colab', 
            'accelerator', 'instance_type', 'orig_nbformat'
        }
    
    def extract_notebook_metadata(self, notebook: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and clean notebook metadata."""
        metadata = notebook.get('metadata', {})
        
        # Filter and preserve important metadata
        filtered_metadata = {}
        for key in self.preserved_keys:
            if key in metadata:
                filtered_metadata[key] = metadata[key]
        
        # Add conversion tracking
        filtered_metadata['conversion_info'] = {
            'converted_at': datetime.now().isoformat(),
            'converter_version': '3.0.0',
            'original_format': 'ipynb'
        }
        
        return filtered_metadata
    
    def extract_cell_metadata(self, cell: Dict[str, Any]) -> Dict[str, Any]:
        """Extract important cell metadata."""
        cell_meta = {
            'cell_type': cell.get('cell_type', 'unknown'),
            'id': cell.get('id', ''),
        }
        
        # For code cells, preserve execution info
        if cell.get('cell_type') == 'code':
            cell_meta['execution_count'] = cell.get('execution_count')
            if 'metadata' in cell and cell['metadata']:
                cell_meta['cell_metadata'] = cell['metadata']
        
        return cell_meta
    
    def serialize_metadata(self, metadata: Dict[str, Any]) -> str:
        """Serialize metadata for embedding in comments."""
        try:
            return json.dumps(metadata, separators=(',', ':'), ensure_ascii=False)
        except (TypeError, ValueError):
            return json.dumps({'error': 'Failed to serialize metadata'})
    
    def deserialize_metadata(self, metadata_str: str) -> Dict[str, Any]:
        """Deserialize metadata from comment strings."""
        try:
            return json.loads(metadata_str)
        except (json.JSONDecodeError, TypeError):
            return {}
