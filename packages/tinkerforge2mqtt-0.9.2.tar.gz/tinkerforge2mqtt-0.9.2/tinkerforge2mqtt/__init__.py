"""
    tinkerforge2mqtt
    Emit MQTT events from tinkerforge
"""

__version__ = '0.9.2'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
