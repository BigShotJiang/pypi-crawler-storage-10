def main() -> None:
    print("Hello from lilizong-tomato-price!")
