# Copyright (C) 2025 <UTN FRA>
#
# Author: Facundo Falcone <f.falcone@sistemas-utnfra.com.ar>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

def clear_console() -> None: ...
def saludo() -> None: ...
def show_matrix_as_table(matrix: list[list], headers: list[str], tablefmt: str = 'rounded_grid') -> None: ...
def show_dict_list_to_table(dict_list: list[dict], headers: list[str], tablefmt: str = 'rounded_grid') -> None: ...
def load_csv_as_list(file_path: str) -> list[str]: ...
def load_csv_as_matrix(file_path: str) -> list[list]: ...
def load_csv_as_dict_list(file_path: str) -> list[dict]: ...
