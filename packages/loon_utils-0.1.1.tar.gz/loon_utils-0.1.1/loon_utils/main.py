# Dummy function printing a message
def hello():
    print("Hello from loon-utils main!")