"""
ml-experiment-utils: Opinionated utilities for quick ML and deep learning experiments.

This package provides reusable components for common ML tasks including:
- Pre-configured data loaders for popular datasets
- Training loops with built-in experiment tracking
- Helper utilities for metrics and evaluation
"""

__version__ = "0.1.0"
