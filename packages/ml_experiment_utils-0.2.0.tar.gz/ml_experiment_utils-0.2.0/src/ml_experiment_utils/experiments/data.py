import torch
from torchvision import transforms, datasets
from torch.utils.data import DataLoader

def CIFAR_for_torch(batch_size: int = 128, root="./data") -> tuple[DataLoader, DataLoader]:
    """
    Prepares the CIFAR-10 dataset for training and testing in PyTorch.

    This function applies data augmentation and normalization to the training dataset
    and normalization to the test dataset. It then creates PyTorch DataLoader objects
    for both the training and test datasets.

    :return: A tuple containing the training DataLoader and the test DataLoader.
    """
    data_transforms = transforms.Compose([
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.RandomHorizontalFlip(p=0.5),  # Randomly flip images horizontally
        transforms.RandomRotation(degrees=10),   # Randomly rotate images
        transforms.ToTensor(),                   # Convert PIL image to tensor
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))  # Normalize with CIFAR-10 mean/std

    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))
    ])

    train_dataset = datasets.CIFAR10(
        root=root,
        train=True,
        download=True,
        transform=data_transforms
    )

    test_dataset = datasets.CIFAR10(
        root=root,
        train=False,
        download=True,
        transform=transform_test
    )

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader= DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    return train_loader, test_loader