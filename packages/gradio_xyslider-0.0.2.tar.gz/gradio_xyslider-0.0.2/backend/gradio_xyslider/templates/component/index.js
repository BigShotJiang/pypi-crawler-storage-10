import { I as f } from "./Index-DmbbsQLU.js";
export {
  f as default
};
