var nr = Object.defineProperty;
var Hn = (i) => {
  throw TypeError(i);
};
var ir = (i, e, t) => e in i ? nr(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var V = (i, e, t) => ir(i, typeof e != "symbol" ? e + "" : e, t), ar = (i, e, t) => e.has(i) || Hn("Cannot " + t);
var Gn = (i, e, t) => e.has(i) ? Hn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var gt = (i, e, t) => (ar(i, e, "access private method"), t);
const {
  SvelteComponent: rr,
  append_hydration: un,
  assign: or,
  attr: oe,
  binding_callbacks: lr,
  children: ct,
  claim_element: ji,
  claim_space: Yi,
  claim_svg_element: Yt,
  create_slot: sr,
  detach: Ne,
  element: Xi,
  empty: Vn,
  get_all_dirty_from_scope: ur,
  get_slot_changes: cr,
  get_spread_update: _r,
  init: dr,
  insert_hydration: pt,
  listen: fr,
  noop: pr,
  safe_not_equal: hr,
  set_dynamic_element_data: Zn,
  set_style: z,
  space: Wi,
  svg_element: Xt,
  toggle_class: te,
  transition_in: Ki,
  transition_out: Qi,
  update_slot_base: mr
} = window.__gradio__svelte__internal;
function jn(i) {
  let e, t, n, a, o;
  return {
    c() {
      e = Xt("svg"), t = Xt("line"), n = Xt("line"), this.h();
    },
    l(r) {
      e = Yt(r, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var l = ct(e);
      t = Yt(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ct(t).forEach(Ne), n = Yt(l, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ct(n).forEach(Ne), l.forEach(Ne), this.h();
    },
    h() {
      oe(t, "x1", "1"), oe(t, "y1", "9"), oe(t, "x2", "9"), oe(t, "y2", "1"), oe(t, "stroke", "gray"), oe(t, "stroke-width", "0.5"), oe(n, "x1", "5"), oe(n, "y1", "9"), oe(n, "x2", "9"), oe(n, "y2", "5"), oe(n, "stroke", "gray"), oe(n, "stroke-width", "0.5"), oe(e, "class", "resize-handle svelte-239wnu"), oe(e, "xmlns", "http://www.w3.org/2000/svg"), oe(e, "viewBox", "0 0 10 10");
    },
    m(r, l) {
      pt(r, e, l), un(e, t), un(e, n), a || (o = fr(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: pr,
    d(r) {
      r && Ne(e), a = !1, o();
    }
  };
}
function gr(i) {
  var p;
  let e, t, n, a, o;
  const r = (
    /*#slots*/
    i[31].default
  ), l = sr(
    r,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && jn(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((p = i[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = or(c, u[d]);
  return {
    c() {
      e = Xi(
        /*tag*/
        i[25]
      ), l && l.c(), t = Wi(), s && s.c(), this.h();
    },
    l(d) {
      e = ji(
        d,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = ct(e);
      l && l.l(h), t = Yi(h), s && s.l(h), h.forEach(Ne), this.h();
    },
    h() {
      Zn(
        /*tag*/
        i[25]
      )(e, c), te(
        e,
        "hidden",
        /*visible*/
        i[14] === !1 || /*visible*/
        i[14] === "hidden"
      ), te(
        e,
        "padded",
        /*padding*/
        i[10]
      ), te(
        e,
        "flex",
        /*flex*/
        i[1]
      ), te(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), te(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), te(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), te(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), te(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), te(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), z(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), z(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), z(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), z(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), z(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), z(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), z(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), z(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), z(e, "border-width", "var(--block-border-width)");
    },
    m(d, h) {
      pt(d, e, h), l && l.m(e, null), un(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(d, h) {
      var b;
      l && l.p && (!o || h[0] & /*$$scope*/
      1073741824) && mr(
        l,
        r,
        d,
        /*$$scope*/
        d[30],
        o ? cr(
          r,
          /*$$scope*/
          d[30],
          h,
          null
        ) : ur(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, h) : (s = jn(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Zn(
        /*tag*/
        d[25]
      )(e, c = _r(u, [
        (!o || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!o || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!o || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((b = d[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || h[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: a }
      ])), te(
        e,
        "hidden",
        /*visible*/
        d[14] === !1 || /*visible*/
        d[14] === "hidden"
      ), te(
        e,
        "padded",
        /*padding*/
        d[10]
      ), te(
        e,
        "flex",
        /*flex*/
        d[1]
      ), te(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), te(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), te(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), te(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), te(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), te(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && z(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && z(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && z(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && z(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), h[0] & /*variant*/
      256 && z(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && z(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && z(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), h[0] & /*min_width*/
      262144 && z(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      o || (Ki(l, d), o = !0);
    },
    o(d) {
      Qi(l, d), o = !1;
    },
    d(d) {
      d && Ne(e), l && l.d(d), s && s.d(), i[32](null);
    }
  };
}
function Yn(i) {
  let e;
  return {
    c() {
      e = Xi("div"), this.h();
    },
    l(t) {
      e = ji(t, "DIV", { class: !0 }), ct(e).forEach(Ne), this.h();
    },
    h() {
      oe(e, "class", "placeholder svelte-239wnu"), z(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), z(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      pt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && z(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && z(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ne(e);
    }
  };
}
function br(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && gr(i)
  ), o = (
    /*fullscreen*/
    i[0] && Yn(i)
  );
  return {
    c() {
      a && a.c(), e = Wi(), o && o.c(), t = Vn();
    },
    l(r) {
      a && a.l(r), e = Yi(r), o && o.l(r), t = Vn();
    },
    m(r, l) {
      a && a.m(r, l), pt(r, e, l), o && o.m(r, l), pt(r, t, l), n = !0;
    },
    p(r, l) {
      /*tag*/
      r[25] && a.p(r, l), /*fullscreen*/
      r[0] ? o ? o.p(r, l) : (o = Yn(r), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(r) {
      n || (Ki(a, r), n = !0);
    },
    o(r) {
      Qi(a, r), n = !1;
    },
    d(r) {
      r && (Ne(e), Ne(t)), a && a.d(r), o && o.d(r);
    }
  };
}
function vr(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: o = void 0 } = e, { min_height: r = void 0 } = e, { max_height: l = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: p = "solid" } = e, { border_mode: d = "base" } = e, { padding: h = !0 } = e, { type: b = "normal" } = e, { test_id: y = void 0 } = e, { explicit_call: w = !1 } = e, { container: F = !0 } = e, { visible: f = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: m = "auto" } = e, { scale: D = null } = e, { min_width: v = 0 } = e, { flex: E = !1 } = e, { resizable: C = !1 } = e, { rtl: k = !1 } = e, { fullscreen: S = !1 } = e, B = S, L, K = b === "fieldset" ? "fieldset" : "div", X = 0, le = 0, H = null;
  function Q($) {
    S && $.key === "Escape" && t(0, S = !1);
  }
  const q = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, ee = ($) => {
    let A = $.clientY;
    const Y = (ie) => {
      const N = ie.clientY - A;
      A = ie.clientY, t(21, L.style.height = `${L.offsetHeight + N}px`, L);
    }, M = () => {
      window.removeEventListener("mousemove", Y), window.removeEventListener("mouseup", M);
    };
    window.addEventListener("mousemove", Y), window.addEventListener("mouseup", M);
  };
  function me($) {
    lr[$ ? "unshift" : "push"](() => {
      L = $, t(21, L);
    });
  }
  return i.$$set = ($) => {
    "height" in $ && t(2, o = $.height), "min_height" in $ && t(3, r = $.min_height), "max_height" in $ && t(4, l = $.max_height), "width" in $ && t(5, s = $.width), "elem_id" in $ && t(6, u = $.elem_id), "elem_classes" in $ && t(7, c = $.elem_classes), "variant" in $ && t(8, p = $.variant), "border_mode" in $ && t(9, d = $.border_mode), "padding" in $ && t(10, h = $.padding), "type" in $ && t(28, b = $.type), "test_id" in $ && t(11, y = $.test_id), "explicit_call" in $ && t(12, w = $.explicit_call), "container" in $ && t(13, F = $.container), "visible" in $ && t(14, f = $.visible), "allow_overflow" in $ && t(15, _ = $.allow_overflow), "overflow_behavior" in $ && t(16, m = $.overflow_behavior), "scale" in $ && t(17, D = $.scale), "min_width" in $ && t(18, v = $.min_width), "flex" in $ && t(1, E = $.flex), "resizable" in $ && t(19, C = $.resizable), "rtl" in $ && t(20, k = $.rtl), "fullscreen" in $ && t(0, S = $.fullscreen), "$$scope" in $ && t(30, a = $.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && S !== B && (t(29, B = S), S ? (t(24, H = L.getBoundingClientRect()), t(22, X = L.offsetHeight), t(23, le = L.offsetWidth), window.addEventListener("keydown", Q)) : (t(24, H = null), window.removeEventListener("keydown", Q))), i.$$.dirty[0] & /*visible*/
    16384 && (f || t(1, E = !1));
  }, [
    S,
    E,
    o,
    r,
    l,
    s,
    u,
    c,
    p,
    d,
    h,
    y,
    w,
    F,
    f,
    _,
    m,
    D,
    v,
    C,
    k,
    L,
    X,
    le,
    H,
    K,
    q,
    ee,
    b,
    B,
    a,
    n,
    me
  ];
}
class yr extends rr {
  constructor(e) {
    super(), dr(
      this,
      e,
      vr,
      br,
      hr,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function kn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Qe = kn();
function Ji(i) {
  Qe = i;
}
const ea = /[&<>"']/, wr = new RegExp(ea.source, "g"), ta = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Dr = new RegExp(ta.source, "g"), Er = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Xn = (i) => Er[i];
function fe(i, e) {
  if (e) {
    if (ea.test(i))
      return i.replace(wr, Xn);
  } else if (ta.test(i))
    return i.replace(Dr, Xn);
  return i;
}
const kr = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Fr(i) {
  return i.replace(kr, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const $r = /(^|[^\[])\^/g;
function U(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let r = typeof o == "string" ? o : o.source;
      return r = r.replace($r, "$1"), t = t.replace(a, r), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Wn(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const _t = { exec: () => null };
function Kn(i, e) {
  const t = i.replace(/\|/g, (o, r, l) => {
    let s = !1, u = r;
    for (; --u >= 0 && l[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function bt(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function Ar(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Qn(i, e, t, n) {
  const a = e.href, o = e.title ? fe(e.title) : null, r = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const l = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: r,
      tokens: n.inlineTokens(r)
    };
    return n.state.inLink = !1, l;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: fe(r)
  };
}
function Cr(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [r] = o;
    return r.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class Lt {
  // set by the lexer
  constructor(e) {
    V(this, "options");
    V(this, "rules");
    // set by the lexer
    V(this, "lexer");
    this.options = e || Qe;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : bt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Cr(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = bt(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = bt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const r = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let l = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = r.exec(e)) || this.rules.block.hr.test(e))
          break;
        l = t[0], e = e.substring(l.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (F) => " ".repeat(3 * F.length)), d = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, s = p.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, s = p.slice(h), h += t[1].length);
        let b = !1;
        if (!p && /^ *$/.test(d) && (l += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const F = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), f = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), m = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (d = D, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || m.test(d) || F.test(d) || f.test(e))
              break;
            if (d.search(/[^ ]/) >= h || !d.trim())
              s += `
` + d.slice(h);
            else {
              if (b || p.search(/[^ ]/) >= 4 || _.test(p) || m.test(p) || f.test(p))
                break;
              s += `
` + d;
            }
            !b && !d.trim() && (b = !0), l += D + `
`, e = e.substring(D.length + 1), p = d.slice(h);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(l) && (u = !0));
        let y = null, w;
        this.options.gfm && (y = /^\[[ xX]\] /.exec(s), y && (w = y[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: l,
          task: !!y,
          checked: w,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += l;
      }
      o.items[o.items.length - 1].raw = l.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const p = o.items[c].tokens.filter((h) => h.type === "space"), d = p.length > 0 && p.some((h) => /\n.*\n/.test(h.raw));
          o.loose = d;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Kn(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], r = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const l of a)
        /^ *-+: *$/.test(l) ? r.align.push("right") : /^ *:-+: *$/.test(l) ? r.align.push("center") : /^ *:-+ *$/.test(l) ? r.align.push("left") : r.align.push(null);
      for (const l of n)
        r.header.push({
          text: l,
          tokens: this.lexer.inline(l)
        });
      for (const l of o)
        r.rows.push(Kn(l, r.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return r;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: fe(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const r = bt(n.slice(0, -1), "\\");
        if ((n.length - r.length) % 2 === 0)
          return;
      } else {
        const r = Ar(t[2], "()");
        if (r > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + r;
          t[2] = t[2].substring(0, r), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const r = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        r && (a = r[1], o = r[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Qn(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const r = n[0].charAt(0);
        return {
          type: "text",
          raw: r,
          text: r
        };
      }
      return Qn(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const r = [...a[0]].length - 1;
      let l, s, u = r, c = 0;
      const p = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + r); (a = p.exec(t)) != null; ) {
        if (l = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !l)
          continue;
        if (s = [...l].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && r % 3 && !((r + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...a[0]][0].length, h = e.slice(0, r + a.index + d + s);
        if (Math.min(r, s) % 2) {
          const y = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: y,
            tokens: this.lexer.inlineTokens(y)
          };
        }
        const b = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = fe(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = fe(t[1]), a = "mailto:" + n) : (n = fe(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = fe(t[0]), o = "mailto:" + a;
      else {
        let r;
        do
          r = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (r !== t[0]);
        a = fe(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = fe(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Sr = /^(?: *(?:\n|$))+/, xr = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Tr = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, ht = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Br = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, na = /(?:[*+-]|\d{1,9}[.)])/, ia = U(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, na).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Fn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ir = /^[^\n]+/, $n = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Rr = U(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", $n).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Lr = U(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, na).getRegex(), Ut = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", An = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Nr = U("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", An).replace("tag", Ut).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), aa = U(Fn).replace("hr", ht).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex(), qr = U(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", aa).getRegex(), Cn = {
  blockquote: qr,
  code: xr,
  def: Rr,
  fences: Tr,
  heading: Br,
  hr: ht,
  html: Nr,
  lheading: ia,
  list: Lr,
  newline: Sr,
  paragraph: aa,
  table: _t,
  text: Ir
}, Jn = U("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", ht).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex(), Or = {
  ...Cn,
  table: Jn,
  paragraph: U(Fn).replace("hr", ht).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Jn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex()
}, zr = {
  ...Cn,
  html: U(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", An).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: _t,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: U(Fn).replace("hr", ht).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ia).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, ra = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Mr = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, oa = /^( {2,}|\\)\n(?!\s*$)/, Pr = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, mt = "\\p{P}\\p{S}", Ur = U(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, mt).getRegex(), Hr = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Gr = U(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, mt).getRegex(), Vr = U("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, mt).getRegex(), Zr = U("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, mt).getRegex(), jr = U(/\\([punct])/, "gu").replace(/punct/g, mt).getRegex(), Yr = U(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Xr = U(An).replace("(?:-->|$)", "-->").getRegex(), Wr = U("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Xr).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Nt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Kr = U(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Nt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), la = U(/^!?\[(label)\]\[(ref)\]/).replace("label", Nt).replace("ref", $n).getRegex(), sa = U(/^!?\[(ref)\](?:\[\])?/).replace("ref", $n).getRegex(), Qr = U("reflink|nolink(?!\\()", "g").replace("reflink", la).replace("nolink", sa).getRegex(), Sn = {
  _backpedal: _t,
  // only used for GFM url
  anyPunctuation: jr,
  autolink: Yr,
  blockSkip: Hr,
  br: oa,
  code: Mr,
  del: _t,
  emStrongLDelim: Gr,
  emStrongRDelimAst: Vr,
  emStrongRDelimUnd: Zr,
  escape: ra,
  link: Kr,
  nolink: sa,
  punctuation: Ur,
  reflink: la,
  reflinkSearch: Qr,
  tag: Wr,
  text: Pr,
  url: _t
}, Jr = {
  ...Sn,
  link: U(/^!?\[(label)\]\((.*?)\)/).replace("label", Nt).getRegex(),
  reflink: U(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Nt).getRegex()
}, cn = {
  ...Sn,
  escape: U(ra).replace("])", "~|])").getRegex(),
  url: U(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, eo = {
  ...cn,
  br: U(oa).replace("{2,}", "*").getRegex(),
  text: U(cn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, vt = {
  normal: Cn,
  gfm: Or,
  pedantic: zr
}, lt = {
  normal: Sn,
  gfm: cn,
  breaks: eo,
  pedantic: Jr
};
class qe {
  constructor(e) {
    V(this, "tokens");
    V(this, "options");
    V(this, "state");
    V(this, "tokenizer");
    V(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Qe, this.options.tokenizer = this.options.tokenizer || new Lt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: vt.normal,
      inline: lt.normal
    };
    this.options.pedantic ? (t.block = vt.pedantic, t.inline = lt.pedantic) : this.options.gfm && (t.block = vt.gfm, this.options.breaks ? t.inline = lt.breaks : t.inline = lt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: vt,
      inline: lt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new qe(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new qe(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (l, s, u) => s + "    ".repeat(u.length));
    let n, a, o, r;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((l) => (n = l.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let l = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
          }), l < 1 / 0 && l >= 0 && (o = e.substring(0, l + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], r && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), r = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const l = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(l);
            break;
          } else
            throw new Error(l);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, r = e, l, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (l = this.tokenizer.rules.inline.reflinkSearch.exec(r)) != null; )
          c.includes(l[0].slice(l[0].lastIndexOf("[") + 1, -1)) && (r = r.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + r.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (l = this.tokenizer.rules.inline.blockSkip.exec(r)) != null; )
      r = r.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + r.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (l = this.tokenizer.rules.inline.anyPunctuation.exec(r)) != null; )
      r = r.slice(0, l.index) + "++" + r.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, r, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const p = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((h) => {
            d = h.call({ lexer: this }, p), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class qt {
  constructor(e) {
    V(this, "options");
    this.options = e || Qe;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + fe(a) + '">' + (n ? e : fe(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : fe(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = Wn(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = Wn(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class xn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Oe {
  constructor(e) {
    V(this, "options");
    V(this, "renderer");
    V(this, "textRenderer");
    this.options = e || Qe, this.options.renderer = this.options.renderer || new qt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new xn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Oe(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Oe(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const r = o, l = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(r.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const r = o;
          n += this.renderer.heading(this.parseInline(r.tokens), r.depth, Fr(this.parseInline(r.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const r = o;
          n += this.renderer.code(r.text, r.lang, !!r.escaped);
          continue;
        }
        case "table": {
          const r = o;
          let l = "", s = "";
          for (let c = 0; c < r.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(r.header[c].tokens), { header: !0, align: r.align[c] });
          l += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < r.rows.length; c++) {
            const p = r.rows[c];
            s = "";
            for (let d = 0; d < p.length; d++)
              s += this.renderer.tablecell(this.parseInline(p[d].tokens), { header: !1, align: r.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(l, u);
          continue;
        }
        case "blockquote": {
          const r = o, l = this.parse(r.tokens);
          n += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          const r = o, l = r.ordered, s = r.start, u = r.loose;
          let c = "";
          for (let p = 0; p < r.items.length; p++) {
            const d = r.items[p], h = d.checked, b = d.task;
            let y = "";
            if (d.task) {
              const w = this.renderer.checkbox(!!h);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = w + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = w + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: w + " "
              }) : y += w + " ";
            }
            y += this.parse(d.tokens, u), c += this.renderer.listitem(y, b, !!h);
          }
          n += this.renderer.list(c, l, s);
          continue;
        }
        case "html": {
          const r = o;
          n += this.renderer.html(r.text, r.block);
          continue;
        }
        case "paragraph": {
          const r = o;
          n += this.renderer.paragraph(this.parseInline(r.tokens));
          continue;
        }
        case "text": {
          let r = o, l = r.tokens ? this.parseInline(r.tokens) : r.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            r = e[++a], l += `
` + (r.tokens ? this.parseInline(r.tokens) : r.text);
          n += t ? this.renderer.paragraph(l) : l;
          continue;
        }
        default: {
          const r = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(r), "";
          throw new Error(r);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const r = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (r !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const r = o;
          n += t.text(r.text);
          break;
        }
        case "html": {
          const r = o;
          n += t.html(r.text);
          break;
        }
        case "link": {
          const r = o;
          n += t.link(r.href, r.title, this.parseInline(r.tokens, t));
          break;
        }
        case "image": {
          const r = o;
          n += t.image(r.href, r.title, r.text);
          break;
        }
        case "strong": {
          const r = o;
          n += t.strong(this.parseInline(r.tokens, t));
          break;
        }
        case "em": {
          const r = o;
          n += t.em(this.parseInline(r.tokens, t));
          break;
        }
        case "codespan": {
          const r = o;
          n += t.codespan(r.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const r = o;
          n += t.del(this.parseInline(r.tokens, t));
          break;
        }
        case "text": {
          const r = o;
          n += t.text(r.text);
          break;
        }
        default: {
          const r = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(r), "";
          throw new Error(r);
        }
      }
    }
    return n;
  }
}
class dt {
  constructor(e) {
    V(this, "options");
    this.options = e || Qe;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
V(dt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Ke, _n, ca;
class ua {
  constructor(...e) {
    Gn(this, Ke);
    V(this, "defaults", kn());
    V(this, "options", this.setOptions);
    V(this, "parse", gt(this, Ke, _n).call(this, qe.lex, Oe.parse));
    V(this, "parseInline", gt(this, Ke, _n).call(this, qe.lexInline, Oe.parseInline));
    V(this, "Parser", Oe);
    V(this, "Renderer", qt);
    V(this, "TextRenderer", xn);
    V(this, "Lexer", qe);
    V(this, "Tokenizer", Lt);
    V(this, "Hooks", dt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const r of e)
      switch (n = n.concat(t.call(this, r)), r.type) {
        case "table": {
          const l = r;
          for (const s of l.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of l.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const l = r;
          n = n.concat(this.walkTokens(l.items, t));
          break;
        }
        default: {
          const l = r;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[l.type] ? this.defaults.extensions.childTokens[l.type].forEach((s) => {
            const u = l[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : l.tokens && (n = n.concat(this.walkTokens(l.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const r = t.renderers[o.name];
          r ? t.renderers[o.name] = function(...l) {
            let s = o.renderer.apply(this, l);
            return s === !1 && (s = r.apply(this, l)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const r = t[o.level];
          r ? r.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new qt(this.defaults);
        for (const r in n.renderer) {
          if (!(r in o))
            throw new Error(`renderer '${r}' does not exist`);
          if (r === "options")
            continue;
          const l = r, s = n.renderer[l], u = o[l];
          o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Lt(this.defaults);
        for (const r in n.tokenizer) {
          if (!(r in o))
            throw new Error(`tokenizer '${r}' does not exist`);
          if (["options", "rules", "lexer"].includes(r))
            continue;
          const l = r, s = n.tokenizer[l], u = o[l];
          o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new dt();
        for (const r in n.hooks) {
          if (!(r in o))
            throw new Error(`hook '${r}' does not exist`);
          if (r === "options")
            continue;
          const l = r, s = n.hooks[l], u = o[l];
          dt.passThroughHooks.has(r) ? o[l] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((d) => u.call(o, d));
            const p = s.call(o, c);
            return u.call(o, p);
          } : o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, r = n.walkTokens;
        a.walkTokens = function(l) {
          let s = [];
          return s.push(r.call(this, l)), o && (s = s.concat(o.call(this, l))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return qe.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Oe.parse(e, t ?? this.defaults);
  }
}
Ke = new WeakSet(), _n = function(e, t) {
  return (n, a) => {
    const o = { ...a }, r = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (r.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), r.async = !0);
    const l = gt(this, Ke, ca).call(this, !!r.silent, !!r.async);
    if (typeof n > "u" || n === null)
      return l(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return l(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (r.hooks && (r.hooks.options = r), r.async)
      return Promise.resolve(r.hooks ? r.hooks.preprocess(n) : n).then((s) => e(s, r)).then((s) => r.hooks ? r.hooks.processAllTokens(s) : s).then((s) => r.walkTokens ? Promise.all(this.walkTokens(s, r.walkTokens)).then(() => s) : s).then((s) => t(s, r)).then((s) => r.hooks ? r.hooks.postprocess(s) : s).catch(l);
    try {
      r.hooks && (n = r.hooks.preprocess(n));
      let s = e(n, r);
      r.hooks && (s = r.hooks.processAllTokens(s)), r.walkTokens && this.walkTokens(s, r.walkTokens);
      let u = t(s, r);
      return r.hooks && (u = r.hooks.postprocess(u)), u;
    } catch (s) {
      return l(s);
    }
  };
}, ca = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + fe(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const We = new ua();
function P(i, e) {
  return We.parse(i, e);
}
P.options = P.setOptions = function(i) {
  return We.setOptions(i), P.defaults = We.defaults, Ji(P.defaults), P;
};
P.getDefaults = kn;
P.defaults = Qe;
P.use = function(...i) {
  return We.use(...i), P.defaults = We.defaults, Ji(P.defaults), P;
};
P.walkTokens = function(i, e) {
  return We.walkTokens(i, e);
};
P.parseInline = We.parseInline;
P.Parser = Oe;
P.parser = Oe.parse;
P.Renderer = qt;
P.TextRenderer = xn;
P.Lexer = qe;
P.lexer = qe.lex;
P.Tokenizer = Lt;
P.Hooks = dt;
P.parse = P;
P.options;
P.setOptions;
P.use;
P.walkTokens;
P.parseInline;
Oe.parse;
qe.lex;
function to(i) {
  if (typeof i == "function" && (i = {
    highlight: i
  }), !i || typeof i.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof i.langPrefix != "string" && (i.langPrefix = "language-"), typeof i.emptyLangClass != "string" && (i.emptyLangClass = ""), {
    async: !!i.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = ei(e.lang);
      if (i.async)
        return Promise.resolve(i.highlight(e.text, t, e.lang || "")).then(ti(e));
      const n = i.highlight(e.text, t, e.lang || "");
      if (n instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      ti(e)(n);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, n) {
        typeof e == "object" && (n = e.escaped, t = e.lang, e = e.text);
        const a = ei(t), o = a ? i.langPrefix + ii(a) : i.emptyLangClass, r = o ? ` class="${o}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${r}>${n ? e : ii(e, !0)}
</code></pre>`;
      }
    }
  };
}
function ei(i) {
  return (i || "").match(/\S*/)[0];
}
function ti(i) {
  return (e) => {
    typeof e == "string" && e !== i.text && (i.escaped = !0, i.text = e);
  };
}
const _a = /[&<>"']/, no = new RegExp(_a.source, "g"), da = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, io = new RegExp(da.source, "g"), ao = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ni = (i) => ao[i];
function ii(i, e) {
  if (e) {
    if (_a.test(i))
      return i.replace(no, ni);
  } else if (da.test(i))
    return i.replace(io, ni);
  return i;
}
const ro = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, oo = Object.hasOwnProperty;
class Tn {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = lo(e, t === !0);
    const o = a;
    for (; oo.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function lo(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(ro, "").replace(/ /g, "-"));
}
let fa = new Tn(), pa = [];
function so({ prefix: i = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || uo(), t;
      }
    },
    renderer: {
      heading(t, n, a) {
        a = a.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const o = `${i}${fa.slug(a)}`, r = { level: n, text: t, id: o };
        return pa.push(r), `<h${n} id="${o}">${t}</h${n}>
`;
      }
    }
  };
}
function uo() {
  pa = [], fa = new Tn();
}
var ai = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function vu(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var ha = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, r = {}, l = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function f(_) {
          return _ instanceof s ? new s(_.type, f(_.content), _.alias) : Array.isArray(_) ? _.map(f) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(f) {
          return Object.prototype.toString.call(f).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(f) {
          return f.__id || Object.defineProperty(f, "__id", { value: ++o }), f.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function f(_, m) {
          m = m || {};
          var D, v;
          switch (l.util.type(_)) {
            case "Object":
              if (v = l.util.objId(_), m[v])
                return m[v];
              D = /** @type {Record<string, any>} */
              {}, m[v] = D;
              for (var E in _)
                _.hasOwnProperty(E) && (D[E] = f(_[E], m));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return v = l.util.objId(_), m[v] ? m[v] : (D = [], m[v] = D, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(C, k) {
                D[k] = f(C, m);
              }), /** @type {any} */
              D);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(f) {
          for (; f; ) {
            var _ = a.exec(f.className);
            if (_)
              return _[1].toLowerCase();
            f = f.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(f, _) {
          f.className = f.className.replace(RegExp(a, "gi"), ""), f.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var f = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (f) {
              var _ = document.getElementsByTagName("script");
              for (var m in _)
                if (_[m].src == f)
                  return _[m];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(f, _, m) {
          for (var D = "no-" + _; f; ) {
            var v = f.classList;
            if (v.contains(_))
              return !0;
            if (v.contains(D))
              return !1;
            f = f.parentElement;
          }
          return !!m;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: r,
        plaintext: r,
        text: r,
        txt: r,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(f, _) {
          var m = l.util.clone(l.languages[f]);
          for (var D in _)
            m[D] = _[D];
          return m;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(f, _, m, D) {
          D = D || /** @type {any} */
          l.languages;
          var v = D[f], E = {};
          for (var C in v)
            if (v.hasOwnProperty(C)) {
              if (C == _)
                for (var k in m)
                  m.hasOwnProperty(k) && (E[k] = m[k]);
              m.hasOwnProperty(C) || (E[C] = v[C]);
            }
          var S = D[f];
          return D[f] = E, l.languages.DFS(l.languages, function(B, L) {
            L === S && B != f && (this[B] = E);
          }), E;
        },
        // Traverse a language definition with Depth First Search
        DFS: function f(_, m, D, v) {
          v = v || {};
          var E = l.util.objId;
          for (var C in _)
            if (_.hasOwnProperty(C)) {
              m.call(_, C, _[C], D || C);
              var k = _[C], S = l.util.type(k);
              S === "Object" && !v[E(k)] ? (v[E(k)] = !0, f(k, m, null, v)) : S === "Array" && !v[E(k)] && (v[E(k)] = !0, f(k, m, C, v));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(f, _) {
        l.highlightAllUnder(document, f, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(f, _, m) {
        var D = {
          callback: m,
          container: f,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        l.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), l.hooks.run("before-all-elements-highlight", D);
        for (var v = 0, E; E = D.elements[v++]; )
          l.highlightElement(E, _ === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(f, _, m) {
        var D = l.util.getLanguage(f), v = l.languages[D];
        l.util.setLanguage(f, D);
        var E = f.parentElement;
        E && E.nodeName.toLowerCase() === "pre" && l.util.setLanguage(E, D);
        var C = f.textContent, k = {
          element: f,
          language: D,
          grammar: v,
          code: C
        };
        function S(L) {
          k.highlightedCode = L, l.hooks.run("before-insert", k), k.element.innerHTML = k.highlightedCode, l.hooks.run("after-highlight", k), l.hooks.run("complete", k), m && m.call(k.element);
        }
        if (l.hooks.run("before-sanity-check", k), E = k.element.parentElement, E && E.nodeName.toLowerCase() === "pre" && !E.hasAttribute("tabindex") && E.setAttribute("tabindex", "0"), !k.code) {
          l.hooks.run("complete", k), m && m.call(k.element);
          return;
        }
        if (l.hooks.run("before-highlight", k), !k.grammar) {
          S(l.util.encode(k.code));
          return;
        }
        if (_ && n.Worker) {
          var B = new Worker(l.filename);
          B.onmessage = function(L) {
            S(L.data);
          }, B.postMessage(JSON.stringify({
            language: k.language,
            code: k.code,
            immediateClose: !0
          }));
        } else
          S(l.highlight(k.code, k.grammar, k.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(f, _, m) {
        var D = {
          code: f,
          grammar: _,
          language: m
        };
        if (l.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = l.tokenize(D.code, D.grammar), l.hooks.run("after-tokenize", D), s.stringify(l.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(f, _) {
        var m = _.rest;
        if (m) {
          for (var D in m)
            _[D] = m[D];
          delete _.rest;
        }
        var v = new p();
        return d(v, v.head, f), c(f, v, _, v.head, 0), b(v);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(f, _) {
          var m = l.hooks.all;
          m[f] = m[f] || [], m[f].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(f, _) {
          var m = l.hooks.all[f];
          if (!(!m || !m.length))
            for (var D = 0, v; v = m[D++]; )
              v(_);
        }
      },
      Token: s
    };
    n.Prism = l;
    function s(f, _, m, D) {
      this.type = f, this.content = _, this.alias = m, this.length = (D || "").length | 0;
    }
    s.stringify = function f(_, m) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var D = "";
        return _.forEach(function(S) {
          D += f(S, m);
        }), D;
      }
      var v = {
        type: _.type,
        content: f(_.content, m),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: m
      }, E = _.alias;
      E && (Array.isArray(E) ? Array.prototype.push.apply(v.classes, E) : v.classes.push(E)), l.hooks.run("wrap", v);
      var C = "";
      for (var k in v.attributes)
        C += " " + k + '="' + (v.attributes[k] || "").replace(/"/g, "&quot;") + '"';
      return "<" + v.tag + ' class="' + v.classes.join(" ") + '"' + C + ">" + v.content + "</" + v.tag + ">";
    };
    function u(f, _, m, D) {
      f.lastIndex = _;
      var v = f.exec(m);
      if (v && D && v[1]) {
        var E = v[1].length;
        v.index += E, v[0] = v[0].slice(E);
      }
      return v;
    }
    function c(f, _, m, D, v, E) {
      for (var C in m)
        if (!(!m.hasOwnProperty(C) || !m[C])) {
          var k = m[C];
          k = Array.isArray(k) ? k : [k];
          for (var S = 0; S < k.length; ++S) {
            if (E && E.cause == C + "," + S)
              return;
            var B = k[S], L = B.inside, K = !!B.lookbehind, X = !!B.greedy, le = B.alias;
            if (X && !B.pattern.global) {
              var H = B.pattern.toString().match(/[imsuy]*$/)[0];
              B.pattern = RegExp(B.pattern.source, H + "g");
            }
            for (var Q = B.pattern || B, q = D.next, ee = v; q !== _.tail && !(E && ee >= E.reach); ee += q.value.length, q = q.next) {
              var me = q.value;
              if (_.length > f.length)
                return;
              if (!(me instanceof s)) {
                var $ = 1, A;
                if (X) {
                  if (A = u(Q, ee, f, K), !A || A.index >= f.length)
                    break;
                  var N = A.index, Y = A.index + A[0].length, M = ee;
                  for (M += q.value.length; N >= M; )
                    q = q.next, M += q.value.length;
                  if (M -= q.value.length, ee = M, q.value instanceof s)
                    continue;
                  for (var ie = q; ie !== _.tail && (M < Y || typeof ie.value == "string"); ie = ie.next)
                    $++, M += ie.value.length;
                  $--, me = f.slice(ee, M), A.index -= ee;
                } else if (A = u(Q, 0, me, K), !A)
                  continue;
                var N = A.index, ge = A[0], x = me.slice(0, N), Ie = me.slice(N + ge.length), Ge = ee + me.length;
                E && Ge > E.reach && (E.reach = Ge);
                var Je = q.prev;
                x && (Je = d(_, Je, x), ee += x.length), h(_, Je, $);
                var Ht = new s(C, L ? l.tokenize(ge, L) : ge, le, ge);
                if (q = d(_, Je, Ht), Ie && d(_, q, Ie), $ > 1) {
                  var ot = {
                    cause: C + "," + S,
                    reach: Ge
                  };
                  c(f, _, m, q.prev, ee, ot), E && ot.reach > E.reach && (E.reach = ot.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var f = { value: null, prev: null, next: null }, _ = { value: null, prev: f, next: null };
      f.next = _, this.head = f, this.tail = _, this.length = 0;
    }
    function d(f, _, m) {
      var D = _.next, v = { value: m, prev: _, next: D };
      return _.next = v, D.prev = v, f.length++, v;
    }
    function h(f, _, m) {
      for (var D = _.next, v = 0; v < m && D !== f.tail; v++)
        D = D.next;
      _.next = D, D.prev = _, f.length -= v;
    }
    function b(f) {
      for (var _ = [], m = f.head.next; m !== f.tail; )
        _.push(m.value), m = m.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (l.disableWorkerMessageHandler || n.addEventListener("message", function(f) {
        var _ = JSON.parse(f.data), m = _.language, D = _.code, v = _.immediateClose;
        n.postMessage(l.highlight(D, l.languages[m], m)), v && n.close();
      }, !1)), l;
    var y = l.util.currentScript();
    y && (l.filename = y.src, y.hasAttribute("data-manual") && (l.manual = !0));
    function w() {
      l.manual || l.highlightAll();
    }
    if (!l.manual) {
      var F = document.readyState;
      F === "loading" || F === "interactive" && y && y.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return l;
  }(e);
  i.exports && (i.exports = t), typeof ai < "u" && (ai.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var r = {};
      r["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, r.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: r
        }
      };
      l["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(y, w) {
      return "✖ Error " + y + " while fetching file: " + w;
    }, o = "✖ Error: File does not exist or is empty", r = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, l = "data-src-status", s = "loading", u = "loaded", c = "failed", p = "pre[data-src]:not([" + l + '="' + u + '"]):not([' + l + '="' + s + '"])';
    function d(y, w, F) {
      var f = new XMLHttpRequest();
      f.open("GET", y, !0), f.onreadystatechange = function() {
        f.readyState == 4 && (f.status < 400 && f.responseText ? w(f.responseText) : f.status >= 400 ? F(a(f.status, f.statusText)) : F(o));
      }, f.send(null);
    }
    function h(y) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(y || "");
      if (w) {
        var F = Number(w[1]), f = w[2], _ = w[3];
        return f ? _ ? [F, Number(_)] : [F, void 0] : [F, F];
      }
    }
    t.hooks.add("before-highlightall", function(y) {
      y.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(y) {
      var w = (
        /** @type {HTMLPreElement} */
        y.element
      );
      if (w.matches(p)) {
        y.code = "", w.setAttribute(l, s);
        var F = w.appendChild(document.createElement("CODE"));
        F.textContent = n;
        var f = w.getAttribute("data-src"), _ = y.language;
        if (_ === "none") {
          var m = (/\.(\w+)$/.exec(f) || [, "none"])[1];
          _ = r[m] || m;
        }
        t.util.setLanguage(F, _), t.util.setLanguage(w, _);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(_), d(
          f,
          function(v) {
            w.setAttribute(l, u);
            var E = h(w.getAttribute("data-range"));
            if (E) {
              var C = v.split(/\r\n?|\n/g), k = E[0], S = E[1] == null ? C.length : E[1];
              k < 0 && (k += C.length), k = Math.max(0, Math.min(k - 1, C.length)), S < 0 && (S += C.length), S = Math.max(0, Math.min(S, C.length)), v = C.slice(k, S).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(k + 1));
            }
            F.textContent = v, t.highlightElement(F);
          },
          function(v) {
            w.setAttribute(l, c), F.textContent = v;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var F = (w || document).querySelectorAll(p), f = 0, _; _ = F[f++]; )
          t.highlightElement(_);
      }
    };
    var b = !1;
    t.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ha);
var Wt = ha.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, r = 0; r < a.length; r++)
    o[a[r]] = i.languages.bash[a[r]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(i) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, t = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  i.languages.cpp = i.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), i.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return t;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), i.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: i.languages.cpp
        }
      }
    }
  }), i.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), i.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: i.languages.extend("cpp", {})
    }
  }), i.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, i.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(i) {
  var e = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, t = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, n = {
    pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  i.languages.java = i.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      n,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + t + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: n.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + t + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: n.inside
      }
    ],
    keyword: e,
    function: [
      i.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), i.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), i.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": n,
        keyword: e,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + t + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: n.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + t + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: n.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return e.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(i) {
  for (var e = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, t = 0; t < 2; t++)
    e = e.replace(/<self>/g, function() {
      return e;
    });
  e = e.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), i.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + e),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, i.languages.rust["closure-params"].inside.rest = i.languages.rust, i.languages.rust.attribute.inside.string = i.languages.rust.string;
})(Prism);
(function(i) {
  var e = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, t = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], n = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, a = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, o = /[{}\[\](),:;]/;
  i.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: e,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: t,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: n,
    operator: a,
    punctuation: o
  };
  var r = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: i.languages.php
  }, l = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: r
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: r
      }
    }
  ];
  i.languages.insertBefore("php", "variable", {
    string: l,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: e,
            string: l,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: t,
            number: n,
            operator: a,
            punctuation: o
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), i.hooks.add("before-tokenize", function(s) {
    if (/<\?/.test(s.code)) {
      var u = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      i.languages["markup-templating"].buildPlaceholders(s, "php", u);
    }
  }), i.hooks.add("after-tokenize", function(s) {
    i.languages["markup-templating"].tokenizePlaceholders(s, "php");
  });
})(Prism);
(function(i) {
  var e = /[*&][^\s[\]{},]+/, t = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, n = "(?:" + t.source + "(?:[ 	]+" + e.source + ")?|" + e.source + "(?:[ 	]+" + t.source + ")?)", a = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), o = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function r(l, s) {
    s = (s || "").replace(/m/g, "") + "m";
    var u = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return n;
    }).replace(/<<value>>/g, function() {
      return l;
    });
    return RegExp(u, s);
  }
  i.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return n;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return n;
      }).replace(/<<key>>/g, function() {
        return "(?:" + a + "|" + o + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: r(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: r(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: r(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: r(o),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: r(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: t,
    important: e,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, i.languages.yml = i.languages.yaml;
})(Prism);
(function(i) {
  function e(t, n) {
    return "___" + t.toUpperCase() + n + "___";
  }
  Object.defineProperties(i.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(t, n, a, o) {
        if (t.language === n) {
          var r = t.tokenStack = [];
          t.code = t.code.replace(a, function(l) {
            if (typeof o == "function" && !o(l))
              return l;
            for (var s = r.length, u; t.code.indexOf(u = e(n, s)) !== -1; )
              ++s;
            return r[s] = l, u;
          }), t.grammar = i.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(t, n) {
        if (t.language !== n || !t.tokenStack)
          return;
        t.grammar = i.languages[n];
        var a = 0, o = Object.keys(t.tokenStack);
        function r(l) {
          for (var s = 0; s < l.length && !(a >= o.length); s++) {
            var u = l[s];
            if (typeof u == "string" || u.content && typeof u.content == "string") {
              var c = o[a], p = t.tokenStack[c], d = typeof u == "string" ? u : u.content, h = e(n, c), b = d.indexOf(h);
              if (b > -1) {
                ++a;
                var y = d.substring(0, b), w = new i.Token(n, i.tokenize(p, t.grammar), "language-" + n, p), F = d.substring(b + h.length), f = [];
                y && f.push.apply(f, r([y])), f.push(w), F && f.push.apply(f, r([F])), typeof u == "string" ? l.splice.apply(l, [s, 1].concat(f)) : u.content = f;
              }
            } else u.content && r(u.content);
          }
          return l;
        }
        r(t.tokens);
      }
    }
  });
})(Prism);
const co = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', _o = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, fo = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, ri = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${_o}</span>
  <span class="check">${fo}</span>
</button>`, ma = /[&<>"']/, po = new RegExp(ma.source, "g"), ga = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, ho = new RegExp(ga.source, "g"), mo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, oi = (i) => mo[i] || "";
function Kt(i, e) {
  if (e) {
    if (ma.test(i))
      return i.replace(po, oi);
  } else if (ga.test(i))
    return i.replace(ho, oi);
  return i;
}
function go(i) {
  const e = i.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const n of e) {
        const a = t.match(n.start);
        if (a)
          return a.index;
      }
      return -1;
    },
    tokenizer(t, n) {
      for (const a of e) {
        const o = new RegExp(
          `${a.start.source}([\\s\\S]+?)${a.end.source}`
        ).exec(t);
        if (o)
          return {
            type: "latex",
            raw: o[0],
            text: o[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function bo() {
  return {
    name: "mermaid",
    level: "block",
    start(i) {
      var e;
      return (e = i.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(i) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(i);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(i) {
      return `<div class="mermaid">${i.text}</div>
`;
    }
  };
}
const vo = {
  code(i, e, t) {
    var a;
    const n = ((a = (e ?? "").match(/\S*/)) == null ? void 0 : a[0]) ?? "";
    return i = i.replace(/\n$/, "") + `
`, !n || n === "mermaid" ? '<div class="code_wrap">' + ri + "<pre><code>" + (t ? i : Kt(i, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + ri + '<pre><code class="language-' + Kt(n) + '">' + (t ? i : Kt(i, !0)) + `</code></pre></div>
`;
  }
}, yo = new Tn();
function wo({
  header_links: i,
  line_breaks: e,
  latex_delimiters: t
}) {
  const n = new ua();
  n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    to({
      highlight: (r, l) => {
        var s;
        return (s = Wt.languages) != null && s[l] ? Wt.highlight(r, Wt.languages[l], l) : r;
      }
    }),
    { renderer: vo }
  ), i && (n.use(so()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(r) {
          const l = r.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + yo.slug(l), u = r.depth, c = this.parser.parseInline(r.tokens);
          return `<h${u} id="${s}"><a class="md-header-anchor" href="#${s}">${co}</a>${c}</h${u}>
`;
        }
      }
    ]
  }));
  const a = bo(), o = go(t);
  return n.use({
    extensions: [a, o]
  }), n;
}
const dn = (i) => JSON.parse(JSON.stringify(i)), Do = (i) => i.nodeType === 1, Eo = (i) => Go.has(i.tagName), ko = (i) => "action" in i, Fo = (i) => i.tagName === "IFRAME", $o = (i) => "formAction" in i, Ao = (i) => "protocol" in i, yt = /* @__PURE__ */ (() => {
  const i = /^(?:\w+script|data):/i;
  return (e) => i.test(e);
})(), Co = /* @__PURE__ */ (() => {
  const i = /(?:script|data):/i;
  return (e) => i.test(e);
})(), So = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, ba = (i, e) => {
  let t = i.firstChild;
  for (; t; ) {
    const n = t.nextSibling;
    Do(t) && (e(t, i), t.parentNode && ba(t, e)), t = n;
  }
}, xo = (i, e) => {
  const t = document.createNodeIterator(i, NodeFilter.SHOW_ELEMENT);
  let n;
  for (; n = t.nextNode(); ) {
    const a = n.parentNode;
    a && e(n, a);
  }
}, To = (i, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? xo(i, e) : ba(i, e), va = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Bo = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Io = /* @__PURE__ */ new Set([
  ...va,
  ...Bo
]), ya = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Ro = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], Lo = /* @__PURE__ */ new Set([
  ...ya,
  ...Ro
]), wa = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], No = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], qo = /* @__PURE__ */ new Set([
  ...wa,
  ...No
]), Oo = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], zo = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Mo = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Be = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, Po = {
  [Be.HTML]: Io,
  [Be.SVG]: Lo,
  [Be.MATH]: qo
}, Uo = {
  [Be.HTML]: "html",
  [Be.SVG]: "svg",
  [Be.MATH]: "math"
}, Ho = {
  [Be.HTML]: "",
  [Be.SVG]: "svg:",
  [Be.MATH]: "math:"
}, Go = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), Da = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...va,
    ...ya.map((i) => `svg:${i}`),
    ...wa.map((i) => `math:${i}`)
  ],
  allowAttributes: So([
    Object.fromEntries(Oo.map((i) => [i, ["*"]])),
    Object.fromEntries(zo.map((i) => [i, ["svg:*"]])),
    Object.fromEntries(Mo.map((i) => [i, ["math:*"]]))
  ])
};
var Qt = function(i, e, t, n, a) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !a) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? i !== e || !a : !e.has(i)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? a.call(i, t) : a ? a.value = t : e.set(i, t), t;
}, Ze = function(i, e, t, n) {
  if (t === "a" && !n) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? i !== e || !n : !e.has(i)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? n : t === "a" ? n.call(i) : n ? n.value : e.get(i);
}, Pe, xt, Tt;
class Ea {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    Pe.set(this, void 0), xt.set(this, void 0), Tt.set(this, void 0), this.getConfiguration = () => dn(Ze(this, Pe, "f")), this.sanitize = (c) => {
      const p = Ze(this, xt, "f"), d = Ze(this, Tt, "f");
      return To(c, (h, b) => {
        const y = h.namespaceURI || Be.HTML, w = b.namespaceURI || Be.HTML, F = Po[y], f = Uo[y], _ = Ho[y], m = h.tagName.toLowerCase(), D = `${_}${m}`, E = `${_}*`;
        if (!F.has(m) || !p.has(D) || y !== w && m !== f)
          b.removeChild(h);
        else {
          const C = h.getAttributeNames(), k = C.length;
          if (k) {
            for (let S = 0; S < k; S++) {
              const B = C[S], L = d[B];
              (!L || !L.has(E) && !L.has(D)) && h.removeAttribute(B);
            }
            if (Eo(h))
              if (Ao(h)) {
                const S = h.getAttribute("href");
                S && Co(S) && yt(h.protocol) && h.removeAttribute("href");
              } else ko(h) ? yt(h.action) && h.removeAttribute("action") : $o(h) ? yt(h.formAction) && h.removeAttribute("formaction") : Fo(h) && (yt(h.src) && h.removeAttribute("formaction"), h.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), c;
    }, this.sanitizeFor = (c, p) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: n, allowUnknownMarkup: a, blockElements: o, dropElements: r, dropAttributes: l } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (n)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (a)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (o)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (r)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (l)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    Qt(this, Pe, dn(Da), "f");
    const { allowElements: s, allowAttributes: u } = e;
    s && (Ze(this, Pe, "f").allowElements = e.allowElements), u && (Ze(this, Pe, "f").allowAttributes = e.allowAttributes), Qt(this, xt, new Set(Ze(this, Pe, "f").allowElements), "f"), Qt(this, Tt, Object.fromEntries(Object.entries(Ze(this, Pe, "f").allowAttributes || {}).map(([c, p]) => [c, new Set(p)])), "f");
  }
}
Pe = /* @__PURE__ */ new WeakMap(), xt = /* @__PURE__ */ new WeakMap(), Tt = /* @__PURE__ */ new WeakMap();
Ea.getDefaultConfiguration = () => dn(Da);
const Vo = (i, e = location.href) => {
  try {
    return !!i && new URL(i).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function li(i) {
  const e = new Ea(), t = new DOMParser().parseFromString(i, "text/html");
  return ka(t.body, "A", (n) => {
    n instanceof HTMLElement && "target" in n && Vo(n.getAttribute("href"), location.href) && (n.setAttribute("target", "_blank"), n.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function ka(i, e, t) {
  i && (i.nodeName === e || typeof e == "function") && t(i);
  const n = (i == null ? void 0 : i.childNodes) || [];
  for (let a = 0; a < n.length; a++)
    ka(n[a], e, t);
}
const si = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Zo = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], jo = [
  ...si,
  ...Zo.filter((i) => !si.includes(i))
], {
  HtmlTagHydration: Yo,
  SvelteComponent: Xo,
  attr: Wo,
  binding_callbacks: Ko,
  children: Qo,
  claim_element: Jo,
  claim_html_tag: el,
  detach: ui,
  element: tl,
  init: nl,
  insert_hydration: il,
  noop: ci,
  safe_not_equal: al,
  toggle_class: wt
} = window.__gradio__svelte__internal, { afterUpdate: rl, tick: ol, onMount: yu } = window.__gradio__svelte__internal;
function ll(i) {
  let e, t;
  return {
    c() {
      e = tl("span"), t = new Yo(!1), this.h();
    },
    l(n) {
      e = Jo(n, "SPAN", { class: !0 });
      var a = Qo(e);
      t = el(a, !1), a.forEach(ui), this.h();
    },
    h() {
      t.a = null, Wo(e, "class", "md svelte-1m32c2s"), wt(
        e,
        "chatbot",
        /*chatbot*/
        i[0]
      ), wt(
        e,
        "prose",
        /*render_markdown*/
        i[1]
      );
    },
    m(n, a) {
      il(n, e, a), t.m(
        /*html*/
        i[3],
        e
      ), i[11](e);
    },
    p(n, [a]) {
      a & /*html*/
      8 && t.p(
        /*html*/
        n[3]
      ), a & /*chatbot*/
      1 && wt(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), a & /*render_markdown*/
      2 && wt(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    i: ci,
    o: ci,
    d(n) {
      n && ui(e), i[11](null);
    }
  };
}
function _i(i) {
  return i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function sl(i, e, t) {
  var n = this && this.__awaiter || function(v, E, C, k) {
    function S(B) {
      return B instanceof C ? B : new C(function(L) {
        L(B);
      });
    }
    return new (C || (C = Promise))(function(B, L) {
      function K(H) {
        try {
          le(k.next(H));
        } catch (Q) {
          L(Q);
        }
      }
      function X(H) {
        try {
          le(k.throw(H));
        } catch (Q) {
          L(Q);
        }
      }
      function le(H) {
        H.done ? B(H.value) : S(H.value).then(K, X);
      }
      le((k = k.apply(v, E || [])).next());
    });
  };
  let { chatbot: a = !0 } = e, { message: o } = e, { sanitize_html: r = !0 } = e, { latex_delimiters: l = [] } = e, { render_markdown: s = !0 } = e, { line_breaks: u = !0 } = e, { header_links: c = !1 } = e, { allow_tags: p = !1 } = e, { theme_mode: d = "system" } = e, h, b, y = !1;
  const w = wo({
    header_links: c,
    line_breaks: u,
    latex_delimiters: l || []
  });
  function F(v) {
    return !l || l.length === 0 ? !1 : l.some((E) => v.includes(E.left) && v.includes(E.right));
  }
  function f(v, E) {
    if (E === !0) {
      const C = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return v.replace(C, (k, S, B) => jo.includes(S.toLowerCase()) ? k : k.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(E)) {
      const C = E.map((S) => ({
        open: new RegExp(`<(${S})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${S})>`, "gi")
      }));
      let k = v;
      return C.forEach((S) => {
        k = k.replace(S.open, (B) => B.replace(/</g, "&lt;").replace(/>/g, "&gt;")), k = k.replace(S.close, (B) => B.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), k;
    }
    return v;
  }
  function _(v) {
    let E = v;
    if (s) {
      const C = [];
      l.forEach((k, S) => {
        const B = _i(k.left), L = _i(k.right), K = new RegExp(`${B}([\\s\\S]+?)${L}`, "g");
        E = E.replace(K, (X, le) => (C.push(X), `%%%LATEX_BLOCK_${C.length - 1}%%%`));
      }), E = w.parse(E), E = E.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (k, S) => C[parseInt(S, 10)]);
    }
    return p && (E = f(E, p)), r && li && (E = li(E)), E;
  }
  function m(v) {
    return n(this, void 0, void 0, function* () {
      if (l.length > 0 && v && F(v))
        if (!y)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-16_rLRwR.js")
          ]).then(([, { default: E }]) => {
            y = !0, E(h, {
              delimiters: l,
              throwOnError: !1
            });
          });
        else {
          const { default: E } = yield import("./auto-render-16_rLRwR.js");
          E(h, {
            delimiters: l,
            throwOnError: !1
          });
        }
      if (h) {
        const E = h.querySelectorAll(".mermaid");
        if (E.length > 0) {
          yield ol();
          const { default: C } = yield import("./mermaid.core-CSMXsFf-.js").then((k) => k.bC);
          C.initialize({
            startOnLoad: !1,
            theme: d === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield C.run({
            nodes: Array.from(E).map((k) => k)
          });
        }
      }
    });
  }
  rl(() => n(void 0, void 0, void 0, function* () {
    h && document.body.contains(h) ? yield m(o) : console.error("Element is not in the DOM");
  }));
  function D(v) {
    Ko[v ? "unshift" : "push"](() => {
      h = v, t(2, h);
    });
  }
  return i.$$set = (v) => {
    "chatbot" in v && t(0, a = v.chatbot), "message" in v && t(4, o = v.message), "sanitize_html" in v && t(5, r = v.sanitize_html), "latex_delimiters" in v && t(6, l = v.latex_delimiters), "render_markdown" in v && t(1, s = v.render_markdown), "line_breaks" in v && t(7, u = v.line_breaks), "header_links" in v && t(8, c = v.header_links), "allow_tags" in v && t(9, p = v.allow_tags), "theme_mode" in v && t(10, d = v.theme_mode);
  }, i.$$.update = () => {
    i.$$.dirty & /*message*/
    16 && (o && o.trim() ? t(3, b = _(o)) : t(3, b = ""));
  }, [
    a,
    s,
    h,
    b,
    o,
    r,
    l,
    u,
    c,
    p,
    d,
    D
  ];
}
class ul extends Xo {
  constructor(e) {
    super(), nl(this, e, sl, ll, al, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: cl,
  attr: _l,
  children: dl,
  claim_component: fl,
  claim_element: pl,
  create_component: hl,
  destroy_component: ml,
  detach: di,
  element: gl,
  init: bl,
  insert_hydration: vl,
  mount_component: yl,
  safe_not_equal: wl,
  transition_in: Dl,
  transition_out: El
} = window.__gradio__svelte__internal;
function kl(i) {
  let e, t, n;
  return t = new ul({
    props: {
      message: (
        /*info*/
        i[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = gl("div"), hl(t.$$.fragment), this.h();
    },
    l(a) {
      e = pl(a, "DIV", { class: !0 });
      var o = dl(e);
      fl(t.$$.fragment, o), o.forEach(di), this.h();
    },
    h() {
      _l(e, "class", "svelte-17qq50w");
    },
    m(a, o) {
      vl(a, e, o), yl(t, e, null), n = !0;
    },
    p(a, [o]) {
      const r = {};
      o & /*info*/
      1 && (r.message = /*info*/
      a[0]), t.$set(r);
    },
    i(a) {
      n || (Dl(t.$$.fragment, a), n = !0);
    },
    o(a) {
      El(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && di(e), ml(t);
    }
  };
}
function Fl(i, e, t) {
  let { info: n } = e;
  return i.$$set = (a) => {
    "info" in a && t(0, n = a.info);
  }, [n];
}
class $l extends cl {
  constructor(e) {
    super(), bl(this, e, Fl, kl, wl, { info: 0 });
  }
}
const {
  SvelteComponent: Al,
  attr: Dt,
  check_outros: Cl,
  children: Sl,
  claim_component: xl,
  claim_element: Tl,
  claim_space: Bl,
  create_component: Il,
  create_slot: Rl,
  destroy_component: Ll,
  detach: Et,
  element: Nl,
  empty: fi,
  get_all_dirty_from_scope: ql,
  get_slot_changes: Ol,
  group_outros: zl,
  init: Ml,
  insert_hydration: Jt,
  mount_component: Pl,
  safe_not_equal: Ul,
  space: Hl,
  toggle_class: et,
  transition_in: ut,
  transition_out: Bt,
  update_slot_base: Gl
} = window.__gradio__svelte__internal;
function pi(i) {
  let e, t;
  return e = new $l({ props: { info: (
    /*info*/
    i[1]
  ) } }), {
    c() {
      Il(e.$$.fragment);
    },
    l(n) {
      xl(e.$$.fragment, n);
    },
    m(n, a) {
      Pl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a & /*info*/
      2 && (o.info = /*info*/
      n[1]), e.$set(o);
    },
    i(n) {
      t || (ut(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Bt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ll(e, n);
    }
  };
}
function Vl(i) {
  let e, t, n, a, o;
  const r = (
    /*#slots*/
    i[4].default
  ), l = Rl(
    r,
    i,
    /*$$scope*/
    i[3],
    null
  );
  let s = (
    /*info*/
    i[1] && pi(i)
  );
  return {
    c() {
      e = Nl("span"), l && l.c(), n = Hl(), s && s.c(), a = fi(), this.h();
    },
    l(u) {
      e = Tl(u, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = Sl(e);
      l && l.l(c), c.forEach(Et), n = Bl(u), s && s.l(u), a = fi(), this.h();
    },
    h() {
      Dt(e, "data-testid", "block-info"), Dt(e, "dir", t = /*rtl*/
      i[2] ? "rtl" : "ltr"), Dt(e, "class", "svelte-zgrq3"), et(e, "sr-only", !/*show_label*/
      i[0]), et(e, "hide", !/*show_label*/
      i[0]), et(
        e,
        "has-info",
        /*info*/
        i[1] != null
      );
    },
    m(u, c) {
      Jt(u, e, c), l && l.m(e, null), Jt(u, n, c), s && s.m(u, c), Jt(u, a, c), o = !0;
    },
    p(u, [c]) {
      l && l.p && (!o || c & /*$$scope*/
      8) && Gl(
        l,
        r,
        u,
        /*$$scope*/
        u[3],
        o ? Ol(
          r,
          /*$$scope*/
          u[3],
          c,
          null
        ) : ql(
          /*$$scope*/
          u[3]
        ),
        null
      ), (!o || c & /*rtl*/
      4 && t !== (t = /*rtl*/
      u[2] ? "rtl" : "ltr")) && Dt(e, "dir", t), (!o || c & /*show_label*/
      1) && et(e, "sr-only", !/*show_label*/
      u[0]), (!o || c & /*show_label*/
      1) && et(e, "hide", !/*show_label*/
      u[0]), (!o || c & /*info*/
      2) && et(
        e,
        "has-info",
        /*info*/
        u[1] != null
      ), /*info*/
      u[1] ? s ? (s.p(u, c), c & /*info*/
      2 && ut(s, 1)) : (s = pi(u), s.c(), ut(s, 1), s.m(a.parentNode, a)) : s && (zl(), Bt(s, 1, 1, () => {
        s = null;
      }), Cl());
    },
    i(u) {
      o || (ut(l, u), ut(s), o = !0);
    },
    o(u) {
      Bt(l, u), Bt(s), o = !1;
    },
    d(u) {
      u && (Et(e), Et(n), Et(a)), l && l.d(u), s && s.d(u);
    }
  };
}
function Zl(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { show_label: o = !0 } = e, { info: r = void 0 } = e, { rtl: l = !1 } = e;
  return i.$$set = (s) => {
    "show_label" in s && t(0, o = s.show_label), "info" in s && t(1, r = s.info), "rtl" in s && t(2, l = s.rtl), "$$scope" in s && t(3, a = s.$$scope);
  }, [o, r, l, a, n];
}
class jl extends Al {
  constructor(e) {
    super(), Ml(this, e, Zl, Vl, Ul, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: wu,
  append_hydration: Du,
  attr: Eu,
  children: ku,
  claim_component: Fu,
  claim_element: $u,
  claim_space: Au,
  claim_text: Cu,
  create_component: Su,
  destroy_component: xu,
  detach: Tu,
  element: Bu,
  init: Iu,
  insert_hydration: Ru,
  mount_component: Lu,
  safe_not_equal: Nu,
  set_data: qu,
  space: Ou,
  text: zu,
  toggle_class: Mu,
  transition_in: Pu,
  transition_out: Uu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hu,
  assign: Gu,
  children: Vu,
  claim_element: Zu,
  compute_rest_props: ju,
  create_slot: Yu,
  detach: Xu,
  element: Wu,
  exclude_internal_props: Ku,
  get_all_dirty_from_scope: Qu,
  get_slot_changes: Ju,
  get_spread_update: ec,
  init: tc,
  insert_hydration: nc,
  listen: ic,
  safe_not_equal: ac,
  set_attributes: rc,
  set_style: oc,
  toggle_class: lc,
  transition_in: sc,
  transition_out: uc,
  update_slot_base: cc
} = window.__gradio__svelte__internal, { createEventDispatcher: _c } = window.__gradio__svelte__internal, {
  SvelteComponent: Yl,
  append_hydration: It,
  attr: ze,
  bubble: Xl,
  check_outros: Wl,
  children: fn,
  claim_component: Kl,
  claim_element: pn,
  claim_space: hi,
  claim_text: Ql,
  construct_svelte_component: mi,
  create_component: gi,
  create_slot: Jl,
  destroy_component: bi,
  detach: ft,
  element: hn,
  get_all_dirty_from_scope: es,
  get_slot_changes: ts,
  group_outros: ns,
  init: is,
  insert_hydration: Fa,
  listen: as,
  mount_component: vi,
  safe_not_equal: rs,
  set_data: os,
  set_style: tt,
  space: yi,
  text: ls,
  toggle_class: re,
  transition_in: en,
  transition_out: tn,
  update_slot_base: ss
} = window.__gradio__svelte__internal;
function wi(i) {
  let e, t;
  return {
    c() {
      e = hn("span"), t = ls(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = pn(n, "SPAN", { class: !0 });
      var a = fn(e);
      t = Ql(
        a,
        /*label*/
        i[1]
      ), a.forEach(ft), this.h();
    },
    h() {
      ze(e, "class", "svelte-y0enk4");
    },
    m(n, a) {
      Fa(n, e, a), It(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && os(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && ft(e);
    }
  };
}
function us(i) {
  let e, t, n, a, o, r, l, s, u = (
    /*show_label*/
    i[2] && wi(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function p(b, y) {
    return {};
  }
  c && (a = mi(c, p()));
  const d = (
    /*#slots*/
    i[15].default
  ), h = Jl(
    d,
    i,
    /*$$scope*/
    i[14],
    null
  );
  return {
    c() {
      e = hn("button"), u && u.c(), t = yi(), n = hn("div"), a && gi(a.$$.fragment), o = yi(), h && h.c(), this.h();
    },
    l(b) {
      e = pn(b, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0
      });
      var y = fn(e);
      u && u.l(y), t = hi(y), n = pn(y, "DIV", { class: !0 });
      var w = fn(n);
      a && Kl(a.$$.fragment, w), o = hi(w), h && h.l(w), w.forEach(ft), y.forEach(ft), this.h();
    },
    h() {
      ze(n, "class", "svelte-y0enk4"), re(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), re(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), re(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), re(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), ze(e, "class", "icon-button svelte-y0enk4"), e.disabled = /*disabled*/
      i[7], ze(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), ze(
        e,
        "title",
        /*label*/
        i[1]
      ), re(
        e,
        "pending",
        /*pending*/
        i[3]
      ), re(
        e,
        "padded",
        /*padded*/
        i[5]
      ), re(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), re(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), tt(
        e,
        "--border-color",
        /*border*/
        i[11]
      ), tt(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[12] ? (
        /*_color*/
        i[12]
      ) : "var(--block-label-text-color)"), tt(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(b, y) {
      Fa(b, e, y), u && u.m(e, null), It(e, t), It(e, n), a && vi(a, n, null), It(n, o), h && h.m(n, null), r = !0, l || (s = as(
        e,
        "click",
        /*click_handler*/
        i[16]
      ), l = !0);
    },
    p(b, [y]) {
      if (/*show_label*/
      b[2] ? u ? u.p(b, y) : (u = wi(b), u.c(), u.m(e, t)) : u && (u.d(1), u = null), y & /*Icon*/
      1 && c !== (c = /*Icon*/
      b[0])) {
        if (a) {
          ns();
          const w = a;
          tn(w.$$.fragment, 1, 0, () => {
            bi(w, 1);
          }), Wl();
        }
        c ? (a = mi(c, p()), gi(a.$$.fragment), en(a.$$.fragment, 1), vi(a, n, o)) : a = null;
      }
      h && h.p && (!r || y & /*$$scope*/
      16384) && ss(
        h,
        d,
        b,
        /*$$scope*/
        b[14],
        r ? ts(
          d,
          /*$$scope*/
          b[14],
          y,
          null
        ) : es(
          /*$$scope*/
          b[14]
        ),
        null
      ), (!r || y & /*size*/
      16) && re(
        n,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!r || y & /*size*/
      16) && re(
        n,
        "small",
        /*size*/
        b[4] === "small"
      ), (!r || y & /*size*/
      16) && re(
        n,
        "large",
        /*size*/
        b[4] === "large"
      ), (!r || y & /*size*/
      16) && re(
        n,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!r || y & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!r || y & /*label*/
      2) && ze(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!r || y & /*hasPopup*/
      256) && ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!r || y & /*label*/
      2) && ze(
        e,
        "title",
        /*label*/
        b[1]
      ), (!r || y & /*pending*/
      8) && re(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!r || y & /*padded*/
      32) && re(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!r || y & /*highlight*/
      64) && re(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!r || y & /*transparent*/
      512) && re(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), y & /*border*/
      2048 && tt(
        e,
        "--border-color",
        /*border*/
        b[11]
      ), y & /*disabled, _color*/
      4224 && tt(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[12] ? (
        /*_color*/
        b[12]
      ) : "var(--block-label-text-color)"), y & /*disabled, background*/
      1152 && tt(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      r || (a && en(a.$$.fragment, b), en(h, b), r = !0);
    },
    o(b) {
      a && tn(a.$$.fragment, b), tn(h, b), r = !1;
    },
    d(b) {
      b && ft(e), u && u.d(), a && bi(a), h && h.d(b), l = !1, s();
    }
  };
}
function cs(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: r } = e, { label: l = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: p = !0 } = e, { highlight: d = !1 } = e, { disabled: h = !1 } = e, { hasPopup: b = !1 } = e, { color: y = "var(--block-label-text-color)" } = e, { transparent: w = !1 } = e, { background: F = "var(--block-background-fill)" } = e, { border: f = "transparent" } = e;
  function _(m) {
    Xl.call(this, i, m);
  }
  return i.$$set = (m) => {
    "Icon" in m && t(0, r = m.Icon), "label" in m && t(1, l = m.label), "show_label" in m && t(2, s = m.show_label), "pending" in m && t(3, u = m.pending), "size" in m && t(4, c = m.size), "padded" in m && t(5, p = m.padded), "highlight" in m && t(6, d = m.highlight), "disabled" in m && t(7, h = m.disabled), "hasPopup" in m && t(8, b = m.hasPopup), "color" in m && t(13, y = m.color), "transparent" in m && t(9, w = m.transparent), "background" in m && t(10, F = m.background), "border" in m && t(11, f = m.border), "$$scope" in m && t(14, o = m.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    8256 && t(12, n = d ? "var(--color-accent)" : y);
  }, [
    r,
    l,
    s,
    u,
    c,
    p,
    d,
    h,
    b,
    w,
    F,
    f,
    n,
    y,
    o,
    a,
    _
  ];
}
class $a extends Yl {
  constructor(e) {
    super(), is(this, e, cs, us, rs, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: dc,
  append_hydration: fc,
  attr: pc,
  binding_callbacks: hc,
  children: mc,
  claim_element: gc,
  create_slot: bc,
  detach: vc,
  element: yc,
  get_all_dirty_from_scope: wc,
  get_slot_changes: Dc,
  init: Ec,
  insert_hydration: kc,
  safe_not_equal: Fc,
  toggle_class: $c,
  transition_in: Ac,
  transition_out: Cc,
  update_slot_base: Sc
} = window.__gradio__svelte__internal, {
  SvelteComponent: xc,
  append_hydration: Tc,
  attr: Bc,
  children: Ic,
  claim_svg_element: Rc,
  detach: Lc,
  init: Nc,
  insert_hydration: qc,
  noop: Oc,
  safe_not_equal: zc,
  svg_element: Mc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pc,
  append_hydration: Uc,
  attr: Hc,
  children: Gc,
  claim_svg_element: Vc,
  detach: Zc,
  init: jc,
  insert_hydration: Yc,
  noop: Xc,
  safe_not_equal: Wc,
  svg_element: Kc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qc,
  append_hydration: Jc,
  attr: e_,
  children: t_,
  claim_svg_element: n_,
  detach: i_,
  init: a_,
  insert_hydration: r_,
  noop: o_,
  safe_not_equal: l_,
  svg_element: s_
} = window.__gradio__svelte__internal, {
  SvelteComponent: u_,
  append_hydration: c_,
  attr: __,
  children: d_,
  claim_svg_element: f_,
  detach: p_,
  init: h_,
  insert_hydration: m_,
  noop: g_,
  safe_not_equal: b_,
  svg_element: v_
} = window.__gradio__svelte__internal, {
  SvelteComponent: y_,
  append_hydration: w_,
  attr: D_,
  children: E_,
  claim_svg_element: k_,
  detach: F_,
  init: $_,
  insert_hydration: A_,
  noop: C_,
  safe_not_equal: S_,
  svg_element: x_
} = window.__gradio__svelte__internal, {
  SvelteComponent: T_,
  append_hydration: B_,
  attr: I_,
  children: R_,
  claim_svg_element: L_,
  detach: N_,
  init: q_,
  insert_hydration: O_,
  noop: z_,
  safe_not_equal: M_,
  svg_element: P_
} = window.__gradio__svelte__internal, {
  SvelteComponent: U_,
  append_hydration: H_,
  attr: G_,
  children: V_,
  claim_svg_element: Z_,
  detach: j_,
  init: Y_,
  insert_hydration: X_,
  noop: W_,
  safe_not_equal: K_,
  svg_element: Q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: J_,
  append_hydration: ed,
  attr: td,
  children: nd,
  claim_svg_element: id,
  detach: ad,
  init: rd,
  insert_hydration: od,
  noop: ld,
  safe_not_equal: sd,
  svg_element: ud
} = window.__gradio__svelte__internal, {
  SvelteComponent: cd,
  append_hydration: _d,
  attr: dd,
  children: fd,
  claim_svg_element: pd,
  detach: hd,
  init: md,
  insert_hydration: gd,
  noop: bd,
  safe_not_equal: vd,
  svg_element: yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: wd,
  append_hydration: Dd,
  attr: Ed,
  children: kd,
  claim_svg_element: Fd,
  detach: $d,
  init: Ad,
  insert_hydration: Cd,
  noop: Sd,
  safe_not_equal: xd,
  svg_element: Td
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bd,
  append_hydration: Id,
  attr: Rd,
  children: Ld,
  claim_svg_element: Nd,
  detach: qd,
  init: Od,
  insert_hydration: zd,
  noop: Md,
  safe_not_equal: Pd,
  svg_element: Ud
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append_hydration: Gd,
  attr: Vd,
  children: Zd,
  claim_svg_element: jd,
  detach: Yd,
  init: Xd,
  insert_hydration: Wd,
  noop: Kd,
  safe_not_equal: Qd,
  svg_element: Jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: _s,
  append_hydration: nn,
  attr: $e,
  children: kt,
  claim_svg_element: Ft,
  detach: st,
  init: ds,
  insert_hydration: fs,
  noop: an,
  safe_not_equal: ps,
  set_style: Re,
  svg_element: $t
} = window.__gradio__svelte__internal;
function hs(i) {
  let e, t, n, a;
  return {
    c() {
      e = $t("svg"), t = $t("g"), n = $t("path"), a = $t("path"), this.h();
    },
    l(o) {
      e = Ft(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var r = kt(e);
      t = Ft(r, "g", { transform: !0 });
      var l = kt(t);
      n = Ft(l, "path", { d: !0, style: !0 }), kt(n).forEach(st), l.forEach(st), a = Ft(r, "path", { d: !0, style: !0 }), kt(a).forEach(st), r.forEach(st), this.h();
    },
    h() {
      $e(n, "d", "M18,6L6.087,17.913"), Re(n, "fill", "none"), Re(n, "fill-rule", "nonzero"), Re(n, "stroke-width", "2px"), $e(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), $e(a, "d", "M4.364,4.364L19.636,19.636"), Re(a, "fill", "none"), Re(a, "fill-rule", "nonzero"), Re(a, "stroke-width", "2px"), $e(e, "width", "100%"), $e(e, "height", "100%"), $e(e, "viewBox", "0 0 24 24"), $e(e, "version", "1.1"), $e(e, "xmlns", "http://www.w3.org/2000/svg"), $e(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), $e(e, "xml:space", "preserve"), $e(e, "stroke", "currentColor"), Re(e, "fill-rule", "evenodd"), Re(e, "clip-rule", "evenodd"), Re(e, "stroke-linecap", "round"), Re(e, "stroke-linejoin", "round");
    },
    m(o, r) {
      fs(o, e, r), nn(e, t), nn(t, n), nn(e, a);
    },
    p: an,
    i: an,
    o: an,
    d(o) {
      o && st(e);
    }
  };
}
class Aa extends _s {
  constructor(e) {
    super(), ds(this, e, null, hs, ps, {});
  }
}
const {
  SvelteComponent: ef,
  append_hydration: tf,
  attr: nf,
  children: af,
  claim_svg_element: rf,
  claim_text: of,
  detach: lf,
  init: sf,
  insert_hydration: uf,
  noop: cf,
  safe_not_equal: _f,
  svg_element: df,
  text: ff
} = window.__gradio__svelte__internal, {
  SvelteComponent: pf,
  append_hydration: hf,
  attr: mf,
  children: gf,
  claim_svg_element: bf,
  detach: vf,
  init: yf,
  insert_hydration: wf,
  noop: Df,
  safe_not_equal: Ef,
  svg_element: kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ff,
  append_hydration: $f,
  attr: Af,
  children: Cf,
  claim_svg_element: Sf,
  detach: xf,
  init: Tf,
  insert_hydration: Bf,
  noop: If,
  safe_not_equal: Rf,
  svg_element: Lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nf,
  append_hydration: qf,
  attr: Of,
  children: zf,
  claim_svg_element: Mf,
  detach: Pf,
  init: Uf,
  insert_hydration: Hf,
  noop: Gf,
  safe_not_equal: Vf,
  svg_element: Zf
} = window.__gradio__svelte__internal, {
  SvelteComponent: jf,
  append_hydration: Yf,
  attr: Xf,
  children: Wf,
  claim_svg_element: Kf,
  detach: Qf,
  init: Jf,
  insert_hydration: ep,
  noop: tp,
  safe_not_equal: np,
  svg_element: ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: ap,
  append_hydration: rp,
  attr: op,
  children: lp,
  claim_svg_element: sp,
  detach: up,
  init: cp,
  insert_hydration: _p,
  noop: dp,
  safe_not_equal: fp,
  svg_element: pp
} = window.__gradio__svelte__internal, {
  SvelteComponent: hp,
  append_hydration: mp,
  attr: gp,
  children: bp,
  claim_svg_element: vp,
  detach: yp,
  init: wp,
  insert_hydration: Dp,
  noop: Ep,
  safe_not_equal: kp,
  svg_element: Fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: $p,
  append_hydration: Ap,
  attr: Cp,
  children: Sp,
  claim_svg_element: xp,
  detach: Tp,
  init: Bp,
  insert_hydration: Ip,
  noop: Rp,
  safe_not_equal: Lp,
  svg_element: Np
} = window.__gradio__svelte__internal, {
  SvelteComponent: qp,
  append_hydration: Op,
  attr: zp,
  children: Mp,
  claim_svg_element: Pp,
  detach: Up,
  init: Hp,
  insert_hydration: Gp,
  noop: Vp,
  safe_not_equal: Zp,
  svg_element: jp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yp,
  append_hydration: Xp,
  attr: Wp,
  children: Kp,
  claim_svg_element: Qp,
  detach: Jp,
  init: eh,
  insert_hydration: th,
  noop: nh,
  safe_not_equal: ih,
  svg_element: ah
} = window.__gradio__svelte__internal, {
  SvelteComponent: rh,
  append_hydration: oh,
  attr: lh,
  children: sh,
  claim_svg_element: uh,
  detach: ch,
  init: _h,
  insert_hydration: dh,
  noop: fh,
  safe_not_equal: ph,
  svg_element: hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: mh,
  append_hydration: gh,
  attr: bh,
  children: vh,
  claim_svg_element: yh,
  detach: wh,
  init: Dh,
  insert_hydration: Eh,
  noop: kh,
  safe_not_equal: Fh,
  svg_element: $h
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ah,
  append_hydration: Ch,
  attr: Sh,
  children: xh,
  claim_svg_element: Th,
  detach: Bh,
  init: Ih,
  insert_hydration: Rh,
  noop: Lh,
  safe_not_equal: Nh,
  svg_element: qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oh,
  append_hydration: zh,
  attr: Mh,
  children: Ph,
  claim_svg_element: Uh,
  detach: Hh,
  init: Gh,
  insert_hydration: Vh,
  noop: Zh,
  safe_not_equal: jh,
  svg_element: Yh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xh,
  append_hydration: Wh,
  attr: Kh,
  children: Qh,
  claim_svg_element: Jh,
  detach: em,
  init: tm,
  insert_hydration: nm,
  noop: im,
  safe_not_equal: am,
  svg_element: rm
} = window.__gradio__svelte__internal, {
  SvelteComponent: om,
  append_hydration: lm,
  attr: sm,
  children: um,
  claim_svg_element: cm,
  detach: _m,
  init: dm,
  insert_hydration: fm,
  noop: pm,
  safe_not_equal: hm,
  svg_element: mm
} = window.__gradio__svelte__internal, {
  SvelteComponent: gm,
  append_hydration: bm,
  attr: vm,
  children: ym,
  claim_svg_element: wm,
  detach: Dm,
  init: Em,
  insert_hydration: km,
  noop: Fm,
  safe_not_equal: $m,
  svg_element: Am
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cm,
  append_hydration: Sm,
  attr: xm,
  children: Tm,
  claim_svg_element: Bm,
  detach: Im,
  init: Rm,
  insert_hydration: Lm,
  noop: Nm,
  safe_not_equal: qm,
  svg_element: Om
} = window.__gradio__svelte__internal, {
  SvelteComponent: zm,
  append_hydration: Mm,
  attr: Pm,
  children: Um,
  claim_svg_element: Hm,
  detach: Gm,
  init: Vm,
  insert_hydration: Zm,
  noop: jm,
  safe_not_equal: Ym,
  svg_element: Xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wm,
  append_hydration: Km,
  attr: Qm,
  children: Jm,
  claim_svg_element: eg,
  detach: tg,
  init: ng,
  insert_hydration: ig,
  noop: ag,
  safe_not_equal: rg,
  svg_element: og
} = window.__gradio__svelte__internal, {
  SvelteComponent: lg,
  append_hydration: sg,
  attr: ug,
  children: cg,
  claim_svg_element: _g,
  detach: dg,
  init: fg,
  insert_hydration: pg,
  noop: hg,
  safe_not_equal: mg,
  svg_element: gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: bg,
  append_hydration: vg,
  attr: yg,
  children: wg,
  claim_svg_element: Dg,
  detach: Eg,
  init: kg,
  insert_hydration: Fg,
  noop: $g,
  safe_not_equal: Ag,
  svg_element: Cg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sg,
  append_hydration: xg,
  attr: Tg,
  children: Bg,
  claim_svg_element: Ig,
  detach: Rg,
  init: Lg,
  insert_hydration: Ng,
  noop: qg,
  safe_not_equal: Og,
  svg_element: zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Pg,
  attr: Ug,
  children: Hg,
  claim_svg_element: Gg,
  detach: Vg,
  init: Zg,
  insert_hydration: jg,
  noop: Yg,
  safe_not_equal: Xg,
  svg_element: Wg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kg,
  append_hydration: Qg,
  attr: Jg,
  children: e0,
  claim_svg_element: t0,
  detach: n0,
  init: i0,
  insert_hydration: a0,
  noop: r0,
  safe_not_equal: o0,
  svg_element: l0
} = window.__gradio__svelte__internal, {
  SvelteComponent: s0,
  append_hydration: u0,
  attr: c0,
  children: _0,
  claim_svg_element: d0,
  detach: f0,
  init: p0,
  insert_hydration: h0,
  noop: m0,
  safe_not_equal: g0,
  svg_element: b0
} = window.__gradio__svelte__internal, {
  SvelteComponent: v0,
  append_hydration: y0,
  attr: w0,
  children: D0,
  claim_svg_element: E0,
  detach: k0,
  init: F0,
  insert_hydration: $0,
  noop: A0,
  safe_not_equal: C0,
  svg_element: S0
} = window.__gradio__svelte__internal, {
  SvelteComponent: x0,
  append_hydration: T0,
  attr: B0,
  children: I0,
  claim_svg_element: R0,
  detach: L0,
  init: N0,
  insert_hydration: q0,
  noop: O0,
  safe_not_equal: z0,
  svg_element: M0
} = window.__gradio__svelte__internal, {
  SvelteComponent: P0,
  append_hydration: U0,
  attr: H0,
  children: G0,
  claim_svg_element: V0,
  detach: Z0,
  init: j0,
  insert_hydration: Y0,
  noop: X0,
  safe_not_equal: W0,
  svg_element: K0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q0,
  append_hydration: J0,
  attr: e1,
  children: t1,
  claim_svg_element: n1,
  detach: i1,
  init: a1,
  insert_hydration: r1,
  noop: o1,
  safe_not_equal: l1,
  svg_element: s1
} = window.__gradio__svelte__internal, {
  SvelteComponent: u1,
  append_hydration: c1,
  attr: _1,
  children: d1,
  claim_svg_element: f1,
  detach: p1,
  init: h1,
  insert_hydration: m1,
  noop: g1,
  safe_not_equal: b1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: y1,
  append_hydration: w1,
  attr: D1,
  children: E1,
  claim_svg_element: k1,
  detach: F1,
  init: $1,
  insert_hydration: A1,
  noop: C1,
  safe_not_equal: S1,
  svg_element: x1
} = window.__gradio__svelte__internal, {
  SvelteComponent: T1,
  append_hydration: B1,
  attr: I1,
  children: R1,
  claim_svg_element: L1,
  detach: N1,
  init: q1,
  insert_hydration: O1,
  noop: z1,
  safe_not_equal: M1,
  svg_element: P1
} = window.__gradio__svelte__internal, {
  SvelteComponent: U1,
  append_hydration: H1,
  attr: G1,
  children: V1,
  claim_svg_element: Z1,
  detach: j1,
  init: Y1,
  insert_hydration: X1,
  noop: W1,
  safe_not_equal: K1,
  svg_element: Q1
} = window.__gradio__svelte__internal, {
  SvelteComponent: J1,
  append_hydration: eb,
  attr: tb,
  children: nb,
  claim_svg_element: ib,
  detach: ab,
  init: rb,
  insert_hydration: ob,
  noop: lb,
  safe_not_equal: sb,
  set_style: ub,
  svg_element: cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: _b,
  append_hydration: db,
  attr: fb,
  children: pb,
  claim_svg_element: hb,
  detach: mb,
  init: gb,
  insert_hydration: bb,
  noop: vb,
  safe_not_equal: yb,
  svg_element: wb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Db,
  append_hydration: Eb,
  attr: kb,
  children: Fb,
  claim_svg_element: $b,
  detach: Ab,
  init: Cb,
  insert_hydration: Sb,
  noop: xb,
  safe_not_equal: Tb,
  svg_element: Bb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ib,
  append_hydration: Rb,
  attr: Lb,
  children: Nb,
  claim_svg_element: qb,
  detach: Ob,
  init: zb,
  insert_hydration: Mb,
  noop: Pb,
  safe_not_equal: Ub,
  svg_element: Hb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gb,
  append_hydration: Vb,
  attr: Zb,
  children: jb,
  claim_svg_element: Yb,
  detach: Xb,
  init: Wb,
  insert_hydration: Kb,
  noop: Qb,
  safe_not_equal: Jb,
  svg_element: ev
} = window.__gradio__svelte__internal, {
  SvelteComponent: tv,
  append_hydration: nv,
  attr: iv,
  children: av,
  claim_svg_element: rv,
  detach: ov,
  init: lv,
  insert_hydration: sv,
  noop: uv,
  safe_not_equal: cv,
  svg_element: _v
} = window.__gradio__svelte__internal, {
  SvelteComponent: dv,
  append_hydration: fv,
  attr: pv,
  children: hv,
  claim_svg_element: mv,
  detach: gv,
  init: bv,
  insert_hydration: vv,
  noop: yv,
  safe_not_equal: wv,
  svg_element: Dv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ev,
  append_hydration: kv,
  attr: Fv,
  children: $v,
  claim_svg_element: Av,
  detach: Cv,
  init: Sv,
  insert_hydration: xv,
  noop: Tv,
  safe_not_equal: Bv,
  svg_element: Iv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rv,
  append_hydration: Lv,
  attr: Nv,
  children: qv,
  claim_svg_element: Ov,
  detach: zv,
  init: Mv,
  insert_hydration: Pv,
  noop: Uv,
  safe_not_equal: Hv,
  svg_element: Gv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vv,
  append_hydration: Zv,
  attr: jv,
  children: Yv,
  claim_svg_element: Xv,
  claim_text: Wv,
  detach: Kv,
  init: Qv,
  insert_hydration: Jv,
  noop: ey,
  safe_not_equal: ty,
  svg_element: ny,
  text: iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ay,
  append_hydration: ry,
  attr: oy,
  children: ly,
  claim_svg_element: sy,
  detach: uy,
  init: cy,
  insert_hydration: _y,
  noop: dy,
  safe_not_equal: fy,
  svg_element: py
} = window.__gradio__svelte__internal, {
  SvelteComponent: hy,
  append_hydration: my,
  attr: gy,
  children: by,
  claim_svg_element: vy,
  detach: yy,
  init: wy,
  insert_hydration: Dy,
  noop: Ey,
  safe_not_equal: ky,
  svg_element: Fy
} = window.__gradio__svelte__internal, {
  SvelteComponent: $y,
  append_hydration: Ay,
  attr: Cy,
  children: Sy,
  claim_svg_element: xy,
  detach: Ty,
  init: By,
  insert_hydration: Iy,
  noop: Ry,
  safe_not_equal: Ly,
  svg_element: Ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: qy,
  append_hydration: Oy,
  attr: zy,
  children: My,
  claim_svg_element: Py,
  detach: Uy,
  init: Hy,
  insert_hydration: Gy,
  noop: Vy,
  safe_not_equal: Zy,
  svg_element: jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yy,
  append_hydration: Xy,
  attr: Wy,
  children: Ky,
  claim_svg_element: Qy,
  detach: Jy,
  init: ew,
  insert_hydration: tw,
  noop: nw,
  safe_not_equal: iw,
  svg_element: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: rw,
  append_hydration: ow,
  attr: lw,
  children: sw,
  claim_svg_element: uw,
  detach: cw,
  init: _w,
  insert_hydration: dw,
  noop: fw,
  safe_not_equal: pw,
  svg_element: hw
} = window.__gradio__svelte__internal, {
  SvelteComponent: mw,
  append_hydration: gw,
  attr: bw,
  children: vw,
  claim_svg_element: yw,
  detach: ww,
  init: Dw,
  insert_hydration: Ew,
  noop: kw,
  safe_not_equal: Fw,
  svg_element: $w
} = window.__gradio__svelte__internal, {
  SvelteComponent: Aw,
  append_hydration: Cw,
  attr: Sw,
  children: xw,
  claim_svg_element: Tw,
  claim_text: Bw,
  detach: Iw,
  init: Rw,
  insert_hydration: Lw,
  noop: Nw,
  safe_not_equal: qw,
  svg_element: Ow,
  text: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mw,
  append_hydration: Pw,
  attr: Uw,
  children: Hw,
  claim_svg_element: Gw,
  claim_text: Vw,
  detach: Zw,
  init: jw,
  insert_hydration: Yw,
  noop: Xw,
  safe_not_equal: Ww,
  svg_element: Kw,
  text: Qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jw,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: iD,
  claim_text: aD,
  detach: rD,
  init: oD,
  insert_hydration: lD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: cD,
  text: _D
} = window.__gradio__svelte__internal, {
  SvelteComponent: dD,
  append_hydration: fD,
  attr: pD,
  children: hD,
  claim_svg_element: mD,
  detach: gD,
  init: bD,
  insert_hydration: vD,
  noop: yD,
  safe_not_equal: wD,
  svg_element: DD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ED,
  append_hydration: kD,
  attr: FD,
  children: $D,
  claim_svg_element: AD,
  detach: CD,
  init: SD,
  insert_hydration: xD,
  noop: TD,
  safe_not_equal: BD,
  svg_element: ID
} = window.__gradio__svelte__internal, {
  SvelteComponent: RD,
  append_hydration: LD,
  attr: ND,
  children: qD,
  claim_svg_element: OD,
  detach: zD,
  init: MD,
  insert_hydration: PD,
  noop: UD,
  safe_not_equal: HD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: VD,
  append_hydration: ZD,
  attr: jD,
  children: YD,
  claim_svg_element: XD,
  detach: WD,
  init: KD,
  insert_hydration: QD,
  noop: JD,
  safe_not_equal: eE,
  svg_element: tE
} = window.__gradio__svelte__internal, {
  SvelteComponent: nE,
  append_hydration: iE,
  attr: aE,
  children: rE,
  claim_svg_element: oE,
  detach: lE,
  init: sE,
  insert_hydration: uE,
  noop: cE,
  safe_not_equal: _E,
  svg_element: dE
} = window.__gradio__svelte__internal, {
  SvelteComponent: fE,
  append_hydration: pE,
  attr: hE,
  children: mE,
  claim_svg_element: gE,
  detach: bE,
  init: vE,
  insert_hydration: yE,
  noop: wE,
  safe_not_equal: DE,
  svg_element: EE
} = window.__gradio__svelte__internal, {
  SvelteComponent: kE,
  append_hydration: FE,
  attr: $E,
  children: AE,
  claim_svg_element: CE,
  detach: SE,
  init: xE,
  insert_hydration: TE,
  noop: BE,
  safe_not_equal: IE,
  svg_element: RE
} = window.__gradio__svelte__internal, {
  SvelteComponent: LE,
  append_hydration: NE,
  attr: qE,
  children: OE,
  claim_svg_element: zE,
  detach: ME,
  init: PE,
  insert_hydration: UE,
  noop: HE,
  safe_not_equal: GE,
  svg_element: VE
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZE,
  append_hydration: jE,
  attr: YE,
  children: XE,
  claim_svg_element: WE,
  detach: KE,
  init: QE,
  insert_hydration: JE,
  noop: ek,
  safe_not_equal: tk,
  svg_element: nk
} = window.__gradio__svelte__internal, {
  SvelteComponent: ik,
  append_hydration: ak,
  attr: rk,
  children: ok,
  claim_svg_element: lk,
  detach: sk,
  init: uk,
  insert_hydration: ck,
  noop: _k,
  safe_not_equal: dk,
  svg_element: fk
} = window.__gradio__svelte__internal, {
  SvelteComponent: pk,
  append_hydration: hk,
  attr: mk,
  children: gk,
  claim_svg_element: bk,
  detach: vk,
  init: yk,
  insert_hydration: wk,
  noop: Dk,
  safe_not_equal: Ek,
  svg_element: kk
} = window.__gradio__svelte__internal, ms = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Di = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
ms.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Di[e][t],
      secondary: Di[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Fk,
  claim_component: $k,
  create_component: Ak,
  destroy_component: Ck,
  init: Sk,
  mount_component: xk,
  safe_not_equal: Tk,
  transition_in: Bk,
  transition_out: Ik
} = window.__gradio__svelte__internal, { createEventDispatcher: Rk } = window.__gradio__svelte__internal, {
  SvelteComponent: Lk,
  append_hydration: Nk,
  attr: qk,
  check_outros: Ok,
  children: zk,
  claim_component: Mk,
  claim_element: Pk,
  claim_space: Uk,
  claim_text: Hk,
  create_component: Gk,
  destroy_component: Vk,
  detach: Zk,
  element: jk,
  empty: Yk,
  group_outros: Xk,
  init: Wk,
  insert_hydration: Kk,
  mount_component: Qk,
  safe_not_equal: Jk,
  set_data: eF,
  space: tF,
  text: nF,
  toggle_class: iF,
  transition_in: aF,
  transition_out: rF
} = window.__gradio__svelte__internal, {
  SvelteComponent: oF,
  attr: lF,
  children: sF,
  claim_element: uF,
  create_slot: cF,
  detach: _F,
  element: dF,
  get_all_dirty_from_scope: fF,
  get_slot_changes: pF,
  init: hF,
  insert_hydration: mF,
  safe_not_equal: gF,
  toggle_class: bF,
  transition_in: vF,
  transition_out: yF,
  update_slot_base: wF
} = window.__gradio__svelte__internal, {
  SvelteComponent: DF,
  append_hydration: EF,
  attr: kF,
  check_outros: FF,
  children: $F,
  claim_component: AF,
  claim_element: CF,
  claim_space: SF,
  create_component: xF,
  destroy_component: TF,
  detach: BF,
  element: IF,
  empty: RF,
  group_outros: LF,
  init: NF,
  insert_hydration: qF,
  listen: OF,
  mount_component: zF,
  safe_not_equal: MF,
  space: PF,
  toggle_class: UF,
  transition_in: HF,
  transition_out: GF
} = window.__gradio__svelte__internal, {
  SvelteComponent: VF,
  attr: ZF,
  children: jF,
  claim_element: YF,
  create_slot: XF,
  detach: WF,
  element: KF,
  get_all_dirty_from_scope: QF,
  get_slot_changes: JF,
  init: e2,
  insert_hydration: t2,
  null_to_empty: n2,
  safe_not_equal: i2,
  transition_in: a2,
  transition_out: r2,
  update_slot_base: o2
} = window.__gradio__svelte__internal, {
  SvelteComponent: l2,
  check_outros: s2,
  claim_component: u2,
  create_component: c2,
  destroy_component: _2,
  detach: d2,
  empty: f2,
  group_outros: p2,
  init: h2,
  insert_hydration: m2,
  mount_component: g2,
  noop: b2,
  safe_not_equal: v2,
  transition_in: y2,
  transition_out: w2
} = window.__gradio__svelte__internal, { createEventDispatcher: D2 } = window.__gradio__svelte__internal;
function it(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function Rt() {
}
const Ca = typeof window < "u";
let Ei = Ca ? () => window.performance.now() : () => Date.now(), Sa = Ca ? (i) => requestAnimationFrame(i) : Rt;
const rt = /* @__PURE__ */ new Set();
function xa(i) {
  rt.forEach((e) => {
    e.c(i) || (rt.delete(e), e.f());
  }), rt.size !== 0 && Sa(xa);
}
function gs(i) {
  let e;
  return rt.size === 0 && Sa(xa), { promise: new Promise((t) => {
    rt.add(e = { c: i, f: t });
  }), abort() {
    rt.delete(e);
  } };
}
const nt = [];
function bs(i, e = Rt) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(r) {
    if (s = r, ((l = i) != l ? s == s : l !== s || l && typeof l == "object" || typeof l == "function") && (i = r, t)) {
      const u = !nt.length;
      for (const c of n) c[1](), nt.push(c, i);
      if (u) {
        for (let c = 0; c < nt.length; c += 2) nt[c][0](nt[c + 1]);
        nt.length = 0;
      }
    }
    var l, s;
  }
  function o(r) {
    a(r(i));
  }
  return { set: a, update: o, subscribe: function(r, l = Rt) {
    const s = [r, l];
    return n.add(s), n.size === 1 && (t = e(a, o) || Rt), r(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function ki(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function mn(i, e, t, n) {
  if (typeof t == "number" || ki(t)) {
    const a = n - t, o = (t - e) / (i.dt || 1 / 60), r = (o + (i.opts.stiffness * a - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(r) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, ki(t) ? new Date(t.getTime() + r) : t + r);
  }
  if (Array.isArray(t)) return t.map((a, o) => mn(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = mn(i, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Fi(i, e = {}) {
  const t = bs(i), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let r, l, s, u = i, c = i, p = 1, d = 0, h = !1;
  function b(w, F = {}) {
    c = w;
    const f = s = {};
    return i == null || F.hard || y.stiffness >= 1 && y.damping >= 1 ? (h = !0, r = Ei(), u = w, t.set(i = c), Promise.resolve()) : (F.soft && (d = 1 / (60 * (F.soft === !0 ? 0.5 : +F.soft)), p = 0), l || (r = Ei(), h = !1, l = gs((_) => {
      if (h) return h = !1, l = null, !1;
      p = Math.min(p + d, 1);
      const m = { inv_mass: p, opts: y, settled: !0, dt: 60 * (_ - r) / 1e3 }, D = mn(m, u, i, c);
      return r = _, u = i, t.set(i = D), m.settled && (l = null), !m.settled;
    })), new Promise((_) => {
      l.promise.then(() => {
        f === s && _();
      });
    }));
  }
  const y = { set: b, update: (w, F) => b(w(c, i), F), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return y;
}
const {
  SvelteComponent: vs,
  append_hydration: Ae,
  attr: O,
  children: ve,
  claim_element: ys,
  claim_svg_element: Ce,
  component_subscribe: $i,
  detach: de,
  element: ws,
  init: Ds,
  insert_hydration: Es,
  noop: Ai,
  safe_not_equal: ks,
  set_style: At,
  svg_element: Se,
  toggle_class: Ci
} = window.__gradio__svelte__internal, { onMount: Fs } = window.__gradio__svelte__internal;
function $s(i) {
  let e, t, n, a, o, r, l, s, u, c, p, d;
  return {
    c() {
      e = ws("div"), t = Se("svg"), n = Se("g"), a = Se("path"), o = Se("path"), r = Se("path"), l = Se("path"), s = Se("g"), u = Se("path"), c = Se("path"), p = Se("path"), d = Se("path"), this.h();
    },
    l(h) {
      e = ys(h, "DIV", { class: !0 });
      var b = ve(e);
      t = Ce(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var y = ve(t);
      n = Ce(y, "g", { style: !0 });
      var w = ve(n);
      a = Ce(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(a).forEach(de), o = Ce(w, "path", { d: !0, fill: !0, class: !0 }), ve(o).forEach(de), r = Ce(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(r).forEach(de), l = Ce(w, "path", { d: !0, fill: !0, class: !0 }), ve(l).forEach(de), w.forEach(de), s = Ce(y, "g", { style: !0 });
      var F = ve(s);
      u = Ce(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(u).forEach(de), c = Ce(F, "path", { d: !0, fill: !0, class: !0 }), ve(c).forEach(de), p = Ce(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(p).forEach(de), d = Ce(F, "path", { d: !0, fill: !0, class: !0 }), ve(d).forEach(de), F.forEach(de), y.forEach(de), b.forEach(de), this.h();
    },
    h() {
      O(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), O(a, "fill", "#FF7C00"), O(a, "fill-opacity", "0.4"), O(a, "class", "svelte-43sxxs"), O(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), O(o, "fill", "#FF7C00"), O(o, "class", "svelte-43sxxs"), O(r, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), O(r, "fill", "#FF7C00"), O(r, "fill-opacity", "0.4"), O(r, "class", "svelte-43sxxs"), O(l, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), O(l, "fill", "#FF7C00"), O(l, "class", "svelte-43sxxs"), At(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), O(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), O(u, "fill", "#FF7C00"), O(u, "fill-opacity", "0.4"), O(u, "class", "svelte-43sxxs"), O(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), O(c, "fill", "#FF7C00"), O(c, "class", "svelte-43sxxs"), O(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), O(p, "fill", "#FF7C00"), O(p, "fill-opacity", "0.4"), O(p, "class", "svelte-43sxxs"), O(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), O(d, "fill", "#FF7C00"), O(d, "class", "svelte-43sxxs"), At(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), O(t, "viewBox", "-1200 -1200 3000 3000"), O(t, "fill", "none"), O(t, "xmlns", "http://www.w3.org/2000/svg"), O(t, "class", "svelte-43sxxs"), O(e, "class", "svelte-43sxxs"), Ci(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(h, b) {
      Es(h, e, b), Ae(e, t), Ae(t, n), Ae(n, a), Ae(n, o), Ae(n, r), Ae(n, l), Ae(t, s), Ae(s, u), Ae(s, c), Ae(s, p), Ae(s, d);
    },
    p(h, [b]) {
      b & /*$top*/
      2 && At(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), b & /*$bottom*/
      4 && At(s, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), b & /*margin*/
      1 && Ci(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: Ai,
    o: Ai,
    d(h) {
      h && de(e);
    }
  };
}
function As(i, e, t) {
  let n, a;
  var o = this && this.__awaiter || function(h, b, y, w) {
    function F(f) {
      return f instanceof y ? f : new y(function(_) {
        _(f);
      });
    }
    return new (y || (y = Promise))(function(f, _) {
      function m(E) {
        try {
          v(w.next(E));
        } catch (C) {
          _(C);
        }
      }
      function D(E) {
        try {
          v(w.throw(E));
        } catch (C) {
          _(C);
        }
      }
      function v(E) {
        E.done ? f(E.value) : F(E.value).then(m, D);
      }
      v((w = w.apply(h, b || [])).next());
    });
  };
  let { margin: r = !0 } = e;
  const l = Fi([0, 0]);
  $i(i, l, (h) => t(1, n = h));
  const s = Fi([0, 0]);
  $i(i, s, (h) => t(2, a = h));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 140]), s.set([-125, -140])]), yield Promise.all([l.set([-125, 140]), s.set([125, -140])]), yield Promise.all([l.set([-125, 0]), s.set([125, -0])]), yield Promise.all([l.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function p() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || p();
    });
  }
  function d() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 0]), s.set([-125, 0])]), p();
    });
  }
  return Fs(() => (d(), () => u = !0)), i.$$set = (h) => {
    "margin" in h && t(0, r = h.margin);
  }, [r, n, a, l, s];
}
class Cs extends vs {
  constructor(e) {
    super(), Ds(this, e, As, $s, ks, { margin: 0 });
  }
}
const {
  SvelteComponent: Ss,
  append_hydration: Te,
  attr: we,
  binding_callbacks: Si,
  check_outros: Ot,
  children: De,
  claim_component: Bn,
  claim_element: Ee,
  claim_space: ce,
  claim_text: Z,
  create_component: In,
  create_slot: Ta,
  destroy_component: Rn,
  destroy_each: Ba,
  detach: T,
  element: ke,
  empty: Fe,
  ensure_array_like: zt,
  get_all_dirty_from_scope: Ia,
  get_slot_changes: Ra,
  group_outros: Mt,
  init: xs,
  insert_hydration: I,
  mount_component: Ln,
  noop: gn,
  safe_not_equal: Ts,
  set_data: he,
  set_style: He,
  space: _e,
  text: j,
  toggle_class: ye,
  transition_in: ue,
  transition_out: pe,
  update_slot_base: La
} = window.__gradio__svelte__internal, { tick: Bs } = window.__gradio__svelte__internal, { onDestroy: Is } = window.__gradio__svelte__internal, { createEventDispatcher: Rs } = window.__gradio__svelte__internal, Ls = (i) => ({}), xi = (i) => ({}), Ns = (i) => ({}), Ti = (i) => ({});
function Bi(i, e, t) {
  const n = i.slice();
  return n[43] = e[t], n[45] = t, n;
}
function Ii(i, e, t) {
  const n = i.slice();
  return n[43] = e[t], n;
}
function Ri(i) {
  let e, t, n, a, o, r;
  return o = new $a({
    props: {
      Icon: Aa,
      label: (
        /*i18n*/
        i[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), o.$on(
    "click",
    /*click_handler*/
    i[33]
  ), {
    c() {
      e = ke("div"), t = j(
        /*validation_error*/
        i[1]
      ), n = _e(), a = ke("button"), In(o.$$.fragment), this.h();
    },
    l(l) {
      e = Ee(l, "DIV", { class: !0 });
      var s = De(e);
      t = Z(
        s,
        /*validation_error*/
        i[1]
      ), n = ce(s), a = Ee(s, "BUTTON", {});
      var u = De(a);
      Bn(o.$$.fragment, u), u.forEach(T), s.forEach(T), this.h();
    },
    h() {
      we(e, "class", "validation-error svelte-vusapu");
    },
    m(l, s) {
      I(l, e, s), Te(e, t), Te(e, n), Te(e, a), Ln(o, a, null), r = !0;
    },
    p(l, s) {
      (!r || s[0] & /*validation_error*/
      2) && he(
        t,
        /*validation_error*/
        l[1]
      );
      const u = {};
      s[0] & /*i18n*/
      4 && (u.label = /*i18n*/
      l[2]("common.clear")), o.$set(u);
    },
    i(l) {
      r || (ue(o.$$.fragment, l), r = !0);
    },
    o(l) {
      pe(o.$$.fragment, l), r = !1;
    },
    d(l) {
      l && T(e), Rn(o);
    }
  };
}
function qs(i) {
  let e, t, n, a, o = (
    /*i18n*/
    i[2]("common.error") + ""
  ), r, l, s;
  t = new $a({
    props: {
      Icon: Aa,
      label: (
        /*i18n*/
        i[2]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    i[35]
  );
  const u = (
    /*#slots*/
    i[32].error
  ), c = Ta(
    u,
    i,
    /*$$scope*/
    i[31],
    xi
  );
  return {
    c() {
      e = ke("div"), In(t.$$.fragment), n = _e(), a = ke("span"), r = j(o), l = _e(), c && c.c(), this.h();
    },
    l(p) {
      e = Ee(p, "DIV", { class: !0 });
      var d = De(e);
      Bn(t.$$.fragment, d), d.forEach(T), n = ce(p), a = Ee(p, "SPAN", { class: !0 });
      var h = De(a);
      r = Z(h, o), h.forEach(T), l = ce(p), c && c.l(p), this.h();
    },
    h() {
      we(e, "class", "clear-status svelte-vusapu"), we(a, "class", "error svelte-vusapu");
    },
    m(p, d) {
      I(p, e, d), Ln(t, e, null), I(p, n, d), I(p, a, d), Te(a, r), I(p, l, d), c && c.m(p, d), s = !0;
    },
    p(p, d) {
      const h = {};
      d[0] & /*i18n*/
      4 && (h.label = /*i18n*/
      p[2]("common.clear")), t.$set(h), (!s || d[0] & /*i18n*/
      4) && o !== (o = /*i18n*/
      p[2]("common.error") + "") && he(r, o), c && c.p && (!s || d[1] & /*$$scope*/
      1) && La(
        c,
        u,
        p,
        /*$$scope*/
        p[31],
        s ? Ra(
          u,
          /*$$scope*/
          p[31],
          d,
          Ls
        ) : Ia(
          /*$$scope*/
          p[31]
        ),
        xi
      );
    },
    i(p) {
      s || (ue(t.$$.fragment, p), ue(c, p), s = !0);
    },
    o(p) {
      pe(t.$$.fragment, p), pe(c, p), s = !1;
    },
    d(p) {
      p && (T(e), T(n), T(a), T(l)), Rn(t), c && c.d(p);
    }
  };
}
function Os(i) {
  let e, t, n, a, o, r, l, s, u, c = (
    /*variant*/
    i[9] === "default" && /*show_eta_bar*/
    i[20] && /*show_progress*/
    i[7] === "full" && Li(i)
  );
  function p(_, m) {
    if (
      /*progress*/
      _[8]
    ) return Ps;
    if (
      /*queue_position*/
      _[3] !== null && /*queue_size*/
      _[4] !== void 0 && /*queue_position*/
      _[3] >= 0
    ) return Ms;
    if (
      /*queue_position*/
      _[3] === 0
    ) return zs;
  }
  let d = p(i), h = d && d(i), b = (
    /*timer*/
    i[6] && Oi(i)
  );
  const y = [Vs, Gs], w = [];
  function F(_, m) {
    return (
      /*last_progress_level*/
      _[17] != null ? 0 : (
        /*show_progress*/
        _[7] === "full" ? 1 : -1
      )
    );
  }
  ~(o = F(i)) && (r = w[o] = y[o](i));
  let f = !/*timer*/
  i[6] && Vi(i);
  return {
    c() {
      c && c.c(), e = _e(), t = ke("div"), h && h.c(), n = _e(), b && b.c(), a = _e(), r && r.c(), l = _e(), f && f.c(), s = Fe(), this.h();
    },
    l(_) {
      c && c.l(_), e = ce(_), t = Ee(_, "DIV", { class: !0 });
      var m = De(t);
      h && h.l(m), n = ce(m), b && b.l(m), m.forEach(T), a = ce(_), r && r.l(_), l = ce(_), f && f.l(_), s = Fe(), this.h();
    },
    h() {
      we(t, "class", "progress-text svelte-vusapu"), ye(
        t,
        "meta-text-center",
        /*variant*/
        i[9] === "center"
      ), ye(
        t,
        "meta-text",
        /*variant*/
        i[9] === "default"
      );
    },
    m(_, m) {
      c && c.m(_, m), I(_, e, m), I(_, t, m), h && h.m(t, null), Te(t, n), b && b.m(t, null), I(_, a, m), ~o && w[o].m(_, m), I(_, l, m), f && f.m(_, m), I(_, s, m), u = !0;
    },
    p(_, m) {
      /*variant*/
      _[9] === "default" && /*show_eta_bar*/
      _[20] && /*show_progress*/
      _[7] === "full" ? c ? c.p(_, m) : (c = Li(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = p(_)) && h ? h.p(_, m) : (h && h.d(1), h = d && d(_), h && (h.c(), h.m(t, n))), /*timer*/
      _[6] ? b ? b.p(_, m) : (b = Oi(_), b.c(), b.m(t, null)) : b && (b.d(1), b = null), (!u || m[0] & /*variant*/
      512) && ye(
        t,
        "meta-text-center",
        /*variant*/
        _[9] === "center"
      ), (!u || m[0] & /*variant*/
      512) && ye(
        t,
        "meta-text",
        /*variant*/
        _[9] === "default"
      );
      let D = o;
      o = F(_), o === D ? ~o && w[o].p(_, m) : (r && (Mt(), pe(w[D], 1, 1, () => {
        w[D] = null;
      }), Ot()), ~o ? (r = w[o], r ? r.p(_, m) : (r = w[o] = y[o](_), r.c()), ue(r, 1), r.m(l.parentNode, l)) : r = null), /*timer*/
      _[6] ? f && (Mt(), pe(f, 1, 1, () => {
        f = null;
      }), Ot()) : f ? (f.p(_, m), m[0] & /*timer*/
      64 && ue(f, 1)) : (f = Vi(_), f.c(), ue(f, 1), f.m(s.parentNode, s));
    },
    i(_) {
      u || (ue(r), ue(f), u = !0);
    },
    o(_) {
      pe(r), pe(f), u = !1;
    },
    d(_) {
      _ && (T(e), T(t), T(a), T(l), T(s)), c && c.d(_), h && h.d(), b && b.d(), ~o && w[o].d(_), f && f.d(_);
    }
  };
}
function Li(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = ke("div"), this.h();
    },
    l(n) {
      e = Ee(n, "DIV", { class: !0 }), De(e).forEach(T), this.h();
    },
    h() {
      we(e, "class", "eta-bar svelte-vusapu"), He(e, "transform", t);
    },
    m(n, a) {
      I(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      524288 && t !== (t = `translateX(${/*eta_level*/
      (n[19] || 0) * 100 - 100}%)`) && He(e, "transform", t);
    },
    d(n) {
      n && T(e);
    }
  };
}
function zs(i) {
  let e;
  return {
    c() {
      e = j("processing |");
    },
    l(t) {
      e = Z(t, "processing |");
    },
    m(t, n) {
      I(t, e, n);
    },
    p: gn,
    d(t) {
      t && T(e);
    }
  };
}
function Ms(i) {
  let e, t = (
    /*queue_position*/
    i[3] + 1 + ""
  ), n, a, o, r;
  return {
    c() {
      e = j("queue: "), n = j(t), a = j("/"), o = j(
        /*queue_size*/
        i[4]
      ), r = j(" |");
    },
    l(l) {
      e = Z(l, "queue: "), n = Z(l, t), a = Z(l, "/"), o = Z(
        l,
        /*queue_size*/
        i[4]
      ), r = Z(l, " |");
    },
    m(l, s) {
      I(l, e, s), I(l, n, s), I(l, a, s), I(l, o, s), I(l, r, s);
    },
    p(l, s) {
      s[0] & /*queue_position*/
      8 && t !== (t = /*queue_position*/
      l[3] + 1 + "") && he(n, t), s[0] & /*queue_size*/
      16 && he(
        o,
        /*queue_size*/
        l[4]
      );
    },
    d(l) {
      l && (T(e), T(n), T(a), T(o), T(r));
    }
  };
}
function Ps(i) {
  let e, t = zt(
    /*progress*/
    i[8]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = qi(Ii(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = Fe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = Fe();
    },
    m(a, o) {
      for (let r = 0; r < n.length; r += 1)
        n[r] && n[r].m(a, o);
      I(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      256) {
        t = zt(
          /*progress*/
          a[8]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const l = Ii(a, t, r);
          n[r] ? n[r].p(l, o) : (n[r] = qi(l), n[r].c(), n[r].m(e.parentNode, e));
        }
        for (; r < n.length; r += 1)
          n[r].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && T(e), Ba(n, a);
    }
  };
}
function Ni(i) {
  let e, t = (
    /*p*/
    i[43].unit + ""
  ), n, a, o = " ", r;
  function l(c, p) {
    return (
      /*p*/
      c[43].length != null ? Hs : Us
    );
  }
  let s = l(i), u = s(i);
  return {
    c() {
      u.c(), e = _e(), n = j(t), a = j(" | "), r = j(o);
    },
    l(c) {
      u.l(c), e = ce(c), n = Z(c, t), a = Z(c, " | "), r = Z(c, o);
    },
    m(c, p) {
      u.m(c, p), I(c, e, p), I(c, n, p), I(c, a, p), I(c, r, p);
    },
    p(c, p) {
      s === (s = l(c)) && u ? u.p(c, p) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), p[0] & /*progress*/
      256 && t !== (t = /*p*/
      c[43].unit + "") && he(n, t);
    },
    d(c) {
      c && (T(e), T(n), T(a), T(r)), u.d(c);
    }
  };
}
function Us(i) {
  let e = it(
    /*p*/
    i[43].index || 0
  ) + "", t;
  return {
    c() {
      t = j(e);
    },
    l(n) {
      t = Z(n, e);
    },
    m(n, a) {
      I(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      256 && e !== (e = it(
        /*p*/
        n[43].index || 0
      ) + "") && he(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function Hs(i) {
  let e = it(
    /*p*/
    i[43].index || 0
  ) + "", t, n, a = it(
    /*p*/
    i[43].length
  ) + "", o;
  return {
    c() {
      t = j(e), n = j("/"), o = j(a);
    },
    l(r) {
      t = Z(r, e), n = Z(r, "/"), o = Z(r, a);
    },
    m(r, l) {
      I(r, t, l), I(r, n, l), I(r, o, l);
    },
    p(r, l) {
      l[0] & /*progress*/
      256 && e !== (e = it(
        /*p*/
        r[43].index || 0
      ) + "") && he(t, e), l[0] & /*progress*/
      256 && a !== (a = it(
        /*p*/
        r[43].length
      ) + "") && he(o, a);
    },
    d(r) {
      r && (T(t), T(n), T(o));
    }
  };
}
function qi(i) {
  let e, t = (
    /*p*/
    i[43].index != null && Ni(i)
  );
  return {
    c() {
      t && t.c(), e = Fe();
    },
    l(n) {
      t && t.l(n), e = Fe();
    },
    m(n, a) {
      t && t.m(n, a), I(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[43].index != null ? t ? t.p(n, a) : (t = Ni(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function Oi(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[21]}` : ""
  ), n, a;
  return {
    c() {
      e = j(
        /*formatted_timer*/
        i[22]
      ), n = j(t), a = j("s");
    },
    l(o) {
      e = Z(
        o,
        /*formatted_timer*/
        i[22]
      ), n = Z(o, t), a = Z(o, "s");
    },
    m(o, r) {
      I(o, e, r), I(o, n, r), I(o, a, r);
    },
    p(o, r) {
      r[0] & /*formatted_timer*/
      4194304 && he(
        e,
        /*formatted_timer*/
        o[22]
      ), r[0] & /*eta, formatted_eta*/
      2097153 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[21]}` : "") && he(n, t);
    },
    d(o) {
      o && (T(e), T(n), T(a));
    }
  };
}
function Gs(i) {
  let e, t;
  return e = new Cs({
    props: { margin: (
      /*variant*/
      i[9] === "default"
    ) }
  }), {
    c() {
      In(e.$$.fragment);
    },
    l(n) {
      Bn(e.$$.fragment, n);
    },
    m(n, a) {
      Ln(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      512 && (o.margin = /*variant*/
      n[9] === "default"), e.$set(o);
    },
    i(n) {
      t || (ue(e.$$.fragment, n), t = !0);
    },
    o(n) {
      pe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Rn(e, n);
    }
  };
}
function Vs(i) {
  let e, t, n, a, o, r = `${/*last_progress_level*/
  i[17] * 100}%`, l = (
    /*progress*/
    i[8] != null && zi(i)
  );
  return {
    c() {
      e = ke("div"), t = ke("div"), l && l.c(), n = _e(), a = ke("div"), o = ke("div"), this.h();
    },
    l(s) {
      e = Ee(s, "DIV", { class: !0 });
      var u = De(e);
      t = Ee(u, "DIV", { class: !0 });
      var c = De(t);
      l && l.l(c), c.forEach(T), n = ce(u), a = Ee(u, "DIV", { class: !0 });
      var p = De(a);
      o = Ee(p, "DIV", { class: !0 }), De(o).forEach(T), p.forEach(T), u.forEach(T), this.h();
    },
    h() {
      we(t, "class", "progress-level-inner svelte-vusapu"), we(o, "class", "progress-bar svelte-vusapu"), He(o, "width", r), we(a, "class", "progress-bar-wrap svelte-vusapu"), we(e, "class", "progress-level svelte-vusapu");
    },
    m(s, u) {
      I(s, e, u), Te(e, t), l && l.m(t, null), Te(e, n), Te(e, a), Te(a, o), i[34](o);
    },
    p(s, u) {
      /*progress*/
      s[8] != null ? l ? l.p(s, u) : (l = zi(s), l.c(), l.m(t, null)) : l && (l.d(1), l = null), u[0] & /*last_progress_level*/
      131072 && r !== (r = `${/*last_progress_level*/
      s[17] * 100}%`) && He(o, "width", r);
    },
    i: gn,
    o: gn,
    d(s) {
      s && T(e), l && l.d(), i[34](null);
    }
  };
}
function zi(i) {
  let e, t = zt(
    /*progress*/
    i[8]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Gi(Bi(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = Fe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = Fe();
    },
    m(a, o) {
      for (let r = 0; r < n.length; r += 1)
        n[r] && n[r].m(a, o);
      I(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      65792) {
        t = zt(
          /*progress*/
          a[8]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const l = Bi(a, t, r);
          n[r] ? n[r].p(l, o) : (n[r] = Gi(l), n[r].c(), n[r].m(e.parentNode, e));
        }
        for (; r < n.length; r += 1)
          n[r].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && T(e), Ba(n, a);
    }
  };
}
function Mi(i) {
  let e, t, n, a, o = (
    /*i*/
    i[45] !== 0 && Zs()
  ), r = (
    /*p*/
    i[43].desc != null && Pi(i)
  ), l = (
    /*p*/
    i[43].desc != null && /*progress_level*/
    i[16] && /*progress_level*/
    i[16][
      /*i*/
      i[45]
    ] != null && Ui()
  ), s = (
    /*progress_level*/
    i[16] != null && Hi(i)
  );
  return {
    c() {
      o && o.c(), e = _e(), r && r.c(), t = _e(), l && l.c(), n = _e(), s && s.c(), a = Fe();
    },
    l(u) {
      o && o.l(u), e = ce(u), r && r.l(u), t = ce(u), l && l.l(u), n = ce(u), s && s.l(u), a = Fe();
    },
    m(u, c) {
      o && o.m(u, c), I(u, e, c), r && r.m(u, c), I(u, t, c), l && l.m(u, c), I(u, n, c), s && s.m(u, c), I(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[43].desc != null ? r ? r.p(u, c) : (r = Pi(u), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null), /*p*/
      u[43].desc != null && /*progress_level*/
      u[16] && /*progress_level*/
      u[16][
        /*i*/
        u[45]
      ] != null ? l || (l = Ui(), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null), /*progress_level*/
      u[16] != null ? s ? s.p(u, c) : (s = Hi(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (T(e), T(t), T(n), T(a)), o && o.d(u), r && r.d(u), l && l.d(u), s && s.d(u);
    }
  };
}
function Zs(i) {
  let e;
  return {
    c() {
      e = j(" /");
    },
    l(t) {
      e = Z(t, " /");
    },
    m(t, n) {
      I(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function Pi(i) {
  let e = (
    /*p*/
    i[43].desc + ""
  ), t;
  return {
    c() {
      t = j(e);
    },
    l(n) {
      t = Z(n, e);
    },
    m(n, a) {
      I(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      256 && e !== (e = /*p*/
      n[43].desc + "") && he(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function Ui(i) {
  let e;
  return {
    c() {
      e = j("-");
    },
    l(t) {
      e = Z(t, "-");
    },
    m(t, n) {
      I(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function Hi(i) {
  let e = (100 * /*progress_level*/
  (i[16][
    /*i*/
    i[45]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = j(e), n = j("%");
    },
    l(a) {
      t = Z(a, e), n = Z(a, "%");
    },
    m(a, o) {
      I(a, t, o), I(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      65536 && e !== (e = (100 * /*progress_level*/
      (a[16][
        /*i*/
        a[45]
      ] || 0)).toFixed(1) + "") && he(t, e);
    },
    d(a) {
      a && (T(t), T(n));
    }
  };
}
function Gi(i) {
  let e, t = (
    /*p*/
    (i[43].desc != null || /*progress_level*/
    i[16] && /*progress_level*/
    i[16][
      /*i*/
      i[45]
    ] != null) && Mi(i)
  );
  return {
    c() {
      t && t.c(), e = Fe();
    },
    l(n) {
      t && t.l(n), e = Fe();
    },
    m(n, a) {
      t && t.m(n, a), I(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[43].desc != null || /*progress_level*/
      n[16] && /*progress_level*/
      n[16][
        /*i*/
        n[45]
      ] != null ? t ? t.p(n, a) : (t = Mi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function Vi(i) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    i[32]["additional-loading-text"]
  ), r = Ta(
    o,
    i,
    /*$$scope*/
    i[31],
    Ti
  );
  return {
    c() {
      e = ke("p"), t = j(
        /*loading_text*/
        i[10]
      ), n = _e(), r && r.c(), this.h();
    },
    l(l) {
      e = Ee(l, "P", { class: !0 });
      var s = De(e);
      t = Z(
        s,
        /*loading_text*/
        i[10]
      ), s.forEach(T), n = ce(l), r && r.l(l), this.h();
    },
    h() {
      we(e, "class", "loading svelte-vusapu");
    },
    m(l, s) {
      I(l, e, s), Te(e, t), I(l, n, s), r && r.m(l, s), a = !0;
    },
    p(l, s) {
      (!a || s[0] & /*loading_text*/
      1024) && he(
        t,
        /*loading_text*/
        l[10]
      ), r && r.p && (!a || s[1] & /*$$scope*/
      1) && La(
        r,
        o,
        l,
        /*$$scope*/
        l[31],
        a ? Ra(
          o,
          /*$$scope*/
          l[31],
          s,
          Ns
        ) : Ia(
          /*$$scope*/
          l[31]
        ),
        Ti
      );
    },
    i(l) {
      a || (ue(r, l), a = !0);
    },
    o(l) {
      pe(r, l), a = !1;
    },
    d(l) {
      l && (T(e), T(n)), r && r.d(l);
    }
  };
}
function js(i) {
  let e, t, n, a, o, r, l = (
    /*validation_error*/
    i[1] && /*show_validation_error*/
    i[14] && Ri(i)
  );
  const s = [Os, qs], u = [];
  function c(p, d) {
    return (
      /*status*/
      p[5] === "pending" ? 0 : (
        /*status*/
        p[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = c(i)) && (a = u[n] = s[n](i)), {
    c() {
      e = ke("div"), l && l.c(), t = _e(), a && a.c(), this.h();
    },
    l(p) {
      e = Ee(p, "DIV", { class: !0 });
      var d = De(e);
      l && l.l(d), t = ce(d), a && a.l(d), d.forEach(T), this.h();
    },
    h() {
      we(e, "class", o = "wrap " + /*variant*/
      i[9] + " " + /*show_progress*/
      i[7] + " svelte-vusapu"), ye(e, "hide", (!/*status*/
      i[5] || /*status*/
      i[5] === "complete" || /*show_progress*/
      i[7] === "hidden" || /*status*/
      i[5] == "streaming") && !/*validation_error*/
      i[1]), ye(
        e,
        "translucent",
        /*variant*/
        i[9] === "center" && /*status*/
        (i[5] === "pending" || /*status*/
        i[5] === "error") || /*translucent*/
        i[12] || /*show_progress*/
        i[7] === "minimal" || /*validation_error*/
        i[1]
      ), ye(
        e,
        "generating",
        /*status*/
        i[5] === "generating" && /*show_progress*/
        i[7] === "full"
      ), ye(
        e,
        "border",
        /*border*/
        i[13]
      ), He(
        e,
        "position",
        /*absolute*/
        i[11] ? "absolute" : "static"
      ), He(
        e,
        "padding",
        /*absolute*/
        i[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(p, d) {
      I(p, e, d), l && l.m(e, null), Te(e, t), ~n && u[n].m(e, null), i[36](e), r = !0;
    },
    p(p, d) {
      /*validation_error*/
      p[1] && /*show_validation_error*/
      p[14] ? l ? (l.p(p, d), d[0] & /*validation_error, show_validation_error*/
      16386 && ue(l, 1)) : (l = Ri(p), l.c(), ue(l, 1), l.m(e, t)) : l && (Mt(), pe(l, 1, 1, () => {
        l = null;
      }), Ot());
      let h = n;
      n = c(p), n === h ? ~n && u[n].p(p, d) : (a && (Mt(), pe(u[h], 1, 1, () => {
        u[h] = null;
      }), Ot()), ~n ? (a = u[n], a ? a.p(p, d) : (a = u[n] = s[n](p), a.c()), ue(a, 1), a.m(e, null)) : a = null), (!r || d[0] & /*variant, show_progress*/
      640 && o !== (o = "wrap " + /*variant*/
      p[9] + " " + /*show_progress*/
      p[7] + " svelte-vusapu")) && we(e, "class", o), (!r || d[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && ye(e, "hide", (!/*status*/
      p[5] || /*status*/
      p[5] === "complete" || /*show_progress*/
      p[7] === "hidden" || /*status*/
      p[5] == "streaming") && !/*validation_error*/
      p[1]), (!r || d[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && ye(
        e,
        "translucent",
        /*variant*/
        p[9] === "center" && /*status*/
        (p[5] === "pending" || /*status*/
        p[5] === "error") || /*translucent*/
        p[12] || /*show_progress*/
        p[7] === "minimal" || /*validation_error*/
        p[1]
      ), (!r || d[0] & /*variant, show_progress, status, show_progress*/
      672) && ye(
        e,
        "generating",
        /*status*/
        p[5] === "generating" && /*show_progress*/
        p[7] === "full"
      ), (!r || d[0] & /*variant, show_progress, border*/
      8832) && ye(
        e,
        "border",
        /*border*/
        p[13]
      ), d[0] & /*absolute*/
      2048 && He(
        e,
        "position",
        /*absolute*/
        p[11] ? "absolute" : "static"
      ), d[0] & /*absolute*/
      2048 && He(
        e,
        "padding",
        /*absolute*/
        p[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(p) {
      r || (ue(l), ue(a), r = !0);
    },
    o(p) {
      pe(l), pe(a), r = !1;
    },
    d(p) {
      p && T(e), l && l.d(), ~n && u[n].d(), i[36](null);
    }
  };
}
var Ys = function(i, e, t, n) {
  function a(o) {
    return o instanceof t ? o : new t(function(r) {
      r(o);
    });
  }
  return new (t || (t = Promise))(function(o, r) {
    function l(c) {
      try {
        u(n.next(c));
      } catch (p) {
        r(p);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (p) {
        r(p);
      }
    }
    function u(c) {
      c.done ? o(c.value) : a(c.value).then(l, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let Ct = [], rn = !1;
const Xs = typeof window < "u", Na = Xs ? window.requestAnimationFrame : (i) => {
};
function Ws(i) {
  return Ys(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Ct.push(e), !rn) rn = !0;
      else return;
      yield Bs(), Na(() => {
        let n = [0, 0];
        for (let a = 0; a < Ct.length; a++) {
          const r = Ct[a].getBoundingClientRect();
          (a === 0 || r.top + window.scrollY <= n[0]) && (n[0] = r.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), rn = !1, Ct = [];
      });
    }
  });
}
function Ks(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const r = Rs();
  let { i18n: l } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: p } = e, { scroll_to_output: d = !1 } = e, { timer: h = !0 } = e, { show_progress: b = "full" } = e, { message: y = null } = e, { progress: w = null } = e, { variant: F = "default" } = e, { loading_text: f = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: m = !1 } = e, { border: D = !1 } = e, { autoscroll: v } = e, { validation_error: E = null } = e, { show_validation_error: C = !0 } = e, k, S = !1, B = 0, L = 0, K = null, X = null, le = 0, H = null, Q, q = null, ee = !0;
  const me = () => {
    t(0, s = t(29, K = t(21, Y = null))), t(27, B = performance.now()), t(28, L = 0), S = !0, $();
  };
  function $() {
    Na(() => {
      t(28, L = (performance.now() - B) / 1e3), S && $();
    });
  }
  function A() {
    t(28, L = 0), t(0, s = t(29, K = t(21, Y = null))), S && (S = !1);
  }
  Is(() => {
    S && A();
  });
  let Y = null;
  const M = () => t(1, E = null);
  function ie(x) {
    Si[x ? "unshift" : "push"](() => {
      q = x, t(18, q), t(8, w), t(16, H), t(17, Q);
    });
  }
  const N = () => {
    r("clear_status");
  };
  function ge(x) {
    Si[x ? "unshift" : "push"](() => {
      k = x, t(15, k);
    });
  }
  return i.$$set = (x) => {
    "i18n" in x && t(2, l = x.i18n), "eta" in x && t(0, s = x.eta), "queue_position" in x && t(3, u = x.queue_position), "queue_size" in x && t(4, c = x.queue_size), "status" in x && t(5, p = x.status), "scroll_to_output" in x && t(24, d = x.scroll_to_output), "timer" in x && t(6, h = x.timer), "show_progress" in x && t(7, b = x.show_progress), "message" in x && t(25, y = x.message), "progress" in x && t(8, w = x.progress), "variant" in x && t(9, F = x.variant), "loading_text" in x && t(10, f = x.loading_text), "absolute" in x && t(11, _ = x.absolute), "translucent" in x && t(12, m = x.translucent), "border" in x && t(13, D = x.border), "autoscroll" in x && t(26, v = x.autoscroll), "validation_error" in x && t(1, E = x.validation_error), "show_validation_error" in x && t(14, C = x.show_validation_error), "$$scope" in x && t(31, o = x.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (s === null && t(0, s = K), s != null && K !== s && (t(30, X = (performance.now() - B) / 1e3 + s), t(21, Y = X.toFixed(1)), t(29, K = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && t(19, le = X === null || X <= 0 || !L ? null : Math.min(L / X, 1)), i.$$.dirty[0] & /*progress*/
    256 && w != null && t(20, ee = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (w != null ? t(16, H = w.map((x) => {
      if (x.index != null && x.length != null)
        return x.index / x.length;
      if (x.progress != null)
        return x.progress;
    })) : t(16, H = null), H ? (t(17, Q = H[H.length - 1]), q && (Q === 0 ? t(18, q.style.transition = "0", q) : t(18, q.style.transition = "150ms", q))) : t(17, Q = void 0)), i.$$.dirty[0] & /*status*/
    32 && (p === "pending" ? me() : A()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && k && d && (p === "pending" || p === "complete") && Ws(k, v), i.$$.dirty[0] & /*status, message*/
    33554464, i.$$.dirty[0] & /*timer_diff*/
    268435456 && t(22, n = L.toFixed(1));
  }, [
    s,
    E,
    l,
    u,
    c,
    p,
    h,
    b,
    w,
    F,
    f,
    _,
    m,
    D,
    C,
    k,
    H,
    Q,
    q,
    le,
    ee,
    Y,
    n,
    r,
    d,
    y,
    v,
    B,
    L,
    K,
    X,
    o,
    a,
    M,
    ie,
    N,
    ge
  ];
}
class Qs extends Ss {
  constructor(e) {
    super(), xs(
      this,
      e,
      Ks,
      js,
      Ts,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: E2,
  SvelteComponent: k2,
  add_render_callback: F2,
  append_hydration: $2,
  attr: A2,
  bubble: C2,
  check_outros: S2,
  children: x2,
  claim_component: T2,
  claim_element: B2,
  claim_html_tag: I2,
  claim_space: R2,
  claim_text: L2,
  create_component: N2,
  create_in_transition: q2,
  create_out_transition: O2,
  destroy_component: z2,
  detach: M2,
  element: P2,
  get_svelte_dataset: U2,
  group_outros: H2,
  init: G2,
  insert_hydration: V2,
  listen: Z2,
  mount_component: j2,
  run_all: Y2,
  safe_not_equal: X2,
  set_data: W2,
  space: K2,
  stop_propagation: Q2,
  text: J2,
  toggle_class: e$,
  transition_in: t$,
  transition_out: n$
} = window.__gradio__svelte__internal, { createEventDispatcher: i$, onMount: a$ } = window.__gradio__svelte__internal, {
  SvelteComponent: r$,
  append_hydration: o$,
  attr: l$,
  bubble: s$,
  check_outros: u$,
  children: c$,
  claim_component: _$,
  claim_element: d$,
  claim_space: f$,
  component_subscribe: p$,
  create_animation: h$,
  create_component: m$,
  destroy_component: g$,
  detach: b$,
  element: v$,
  ensure_array_like: y$,
  fix_and_outro_and_destroy_block: w$,
  fix_position: D$,
  group_outros: E$,
  init: k$,
  insert_hydration: F$,
  mount_component: $$,
  noop: A$,
  safe_not_equal: C$,
  set_style: S$,
  space: x$,
  transition_in: T$,
  transition_out: B$,
  update_keyed_each: I$
} = window.__gradio__svelte__internal, {
  SvelteComponent: R$,
  attr: L$,
  children: N$,
  claim_element: q$,
  detach: O$,
  element: z$,
  empty: M$,
  init: P$,
  insert_hydration: U$,
  noop: H$,
  safe_not_equal: G$,
  set_style: V$
} = window.__gradio__svelte__internal, {
  SvelteComponent: Js,
  append_hydration: Ue,
  assign: eu,
  attr: Le,
  binding_callbacks: tu,
  children: je,
  claim_component: bn,
  claim_element: Ye,
  claim_space: on,
  claim_text: qa,
  create_component: vn,
  destroy_component: yn,
  detach: xe,
  element: Xe,
  get_spread_object: nu,
  get_spread_update: iu,
  globals: au,
  init: ru,
  insert_hydration: Pt,
  listen: at,
  mount_component: wn,
  run_all: ou,
  safe_not_equal: lu,
  set_data: su,
  space: ln,
  text: Oa,
  transition_in: Dn,
  transition_out: En
} = window.__gradio__svelte__internal, { window: uu } = au, { afterUpdate: cu, onMount: _u } = window.__gradio__svelte__internal;
function du(i) {
  let e;
  return {
    c() {
      e = Oa(
        /*label*/
        i[4]
      );
    },
    l(t) {
      e = qa(
        t,
        /*label*/
        i[4]
      );
    },
    m(t, n) {
      Pt(t, e, n);
    },
    p(t, n) {
      n[0] & /*label*/
      16 && su(
        e,
        /*label*/
        t[4]
      );
    },
    d(t) {
      t && xe(e);
    }
  };
}
function Zi(i) {
  let e, t, n, a;
  return {
    c() {
      e = Xe("button"), t = Oa("↺"), this.h();
    },
    l(o) {
      e = Ye(o, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "data-testid": !0
      });
      var r = je(e);
      t = qa(r, "↺"), r.forEach(xe), this.h();
    },
    h() {
      Le(e, "class", "reset-button svelte-3kau6o"), e.disabled = /*disabled*/
      i[15], Le(e, "aria-label", "Reset to default value"), Le(e, "data-testid", "reset-button");
    },
    m(o, r) {
      Pt(o, e, r), Ue(e, t), n || (a = at(
        e,
        "click",
        /*reset_value*/
        i[18]
      ), n = !0);
    },
    p(o, r) {
      r[0] & /*disabled*/
      32768 && (e.disabled = /*disabled*/
      o[15]);
    },
    d(o) {
      o && xe(e), n = !1, a();
    }
  };
}
function fu(i) {
  let e, t, n, a, o, r, l, s, u, c, p, d, h, b;
  const y = [
    { autoscroll: (
      /*gradio*/
      i[0].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      i[0].i18n
    ) },
    /*loading_status*/
    i[10]
  ];
  let w = {};
  for (let f = 0; f < y.length; f += 1)
    w = eu(w, y[f]);
  e = new Qs({ props: w }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[36]
  ), r = new jl({
    props: {
      show_label: (
        /*show_label*/
        i[9]
      ),
      info: (
        /*info*/
        i[5]
      ),
      $$slots: { default: [du] },
      $$scope: { ctx: i }
    }
  });
  let F = (
    /*show_reset_button*/
    i[11] && Zi(i)
  );
  return {
    c() {
      vn(e.$$.fragment), t = ln(), n = Xe("div"), a = Xe("div"), o = Xe("label"), vn(r.$$.fragment), l = ln(), s = Xe("div"), F && F.c(), u = ln(), c = Xe("div"), p = Xe("canvas"), this.h();
    },
    l(f) {
      bn(e.$$.fragment, f), t = on(f), n = Ye(f, "DIV", { class: !0 });
      var _ = je(n);
      a = Ye(_, "DIV", { class: !0 });
      var m = je(a);
      o = Ye(m, "LABEL", { for: !0, class: !0 });
      var D = je(o);
      bn(r.$$.fragment, D), D.forEach(xe), l = on(m), s = Ye(m, "DIV", { class: !0 });
      var v = je(s);
      F && F.l(v), v.forEach(xe), m.forEach(xe), u = on(_), c = Ye(_, "DIV", { class: !0 });
      var E = je(c);
      p = Ye(E, "CANVAS", { class: !0 }), je(p).forEach(xe), E.forEach(xe), _.forEach(xe), this.h();
    },
    h() {
      Le(
        o,
        "for",
        /*id*/
        i[16]
      ), Le(o, "class", "svelte-3kau6o"), Le(s, "class", "tab-like-container svelte-3kau6o"), Le(a, "class", "head svelte-3kau6o"), Le(p, "class", "lane svelte-3kau6o"), Le(c, "class", "lane_container svelte-3kau6o"), Le(n, "class", "wrap svelte-3kau6o");
    },
    m(f, _) {
      wn(e, f, _), Pt(f, t, _), Pt(f, n, _), Ue(n, a), Ue(a, o), wn(r, o, null), Ue(a, l), Ue(a, s), F && F.m(s, null), Ue(n, u), Ue(n, c), Ue(c, p), i[37](p), d = !0, h || (b = [
        at(
          p,
          "pointerdown",
          /*onPointerDown*/
          i[20]
        ),
        at(
          p,
          "pointermove",
          /*onPointerMove*/
          i[21]
        ),
        at(
          p,
          "pointerup",
          /*onPointerUp*/
          i[22]
        ),
        at(
          p,
          "mouseleave",
          /*mouseleave_handler*/
          i[38]
        )
      ], h = !0);
    },
    p(f, _) {
      const m = _[0] & /*gradio, loading_status*/
      1025 ? iu(y, [
        _[0] & /*gradio*/
        1 && { autoscroll: (
          /*gradio*/
          f[0].autoscroll
        ) },
        _[0] & /*gradio*/
        1 && { i18n: (
          /*gradio*/
          f[0].i18n
        ) },
        _[0] & /*loading_status*/
        1024 && nu(
          /*loading_status*/
          f[10]
        )
      ]) : {};
      e.$set(m);
      const D = {};
      _[0] & /*show_label*/
      512 && (D.show_label = /*show_label*/
      f[9]), _[0] & /*info*/
      32 && (D.info = /*info*/
      f[5]), _[0] & /*label*/
      16 | _[2] & /*$$scope*/
      32768 && (D.$$scope = { dirty: _, ctx: f }), r.$set(D), /*show_reset_button*/
      f[11] ? F ? F.p(f, _) : (F = Zi(f), F.c(), F.m(s, null)) : F && (F.d(1), F = null);
    },
    i(f) {
      d || (Dn(e.$$.fragment, f), Dn(r.$$.fragment, f), d = !0);
    },
    o(f) {
      En(e.$$.fragment, f), En(r.$$.fragment, f), d = !1;
    },
    d(f) {
      f && (xe(t), xe(n)), yn(e, f), yn(r), F && F.d(), i[37](null), h = !1, ou(b);
    }
  };
}
function pu(i) {
  let e, t, n, a;
  return e = new yr({
    props: {
      visible: (
        /*visible*/
        i[3]
      ),
      elem_id: (
        /*elem_id*/
        i[1]
      ),
      elem_classes: (
        /*elem_classes*/
        i[2]
      ),
      container: (
        /*container*/
        i[6]
      ),
      scale: (
        /*scale*/
        i[7]
      ),
      min_width: (
        /*min_width*/
        i[8]
      ),
      $$slots: { default: [fu] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      vn(e.$$.fragment);
    },
    l(o) {
      bn(e.$$.fragment, o);
    },
    m(o, r) {
      wn(e, o, r), t = !0, n || (a = at(
        uu,
        "resize",
        /*handle_resize*/
        i[17]
      ), n = !0);
    },
    p(o, r) {
      const l = {};
      r[0] & /*visible*/
      8 && (l.visible = /*visible*/
      o[3]), r[0] & /*elem_id*/
      2 && (l.elem_id = /*elem_id*/
      o[1]), r[0] & /*elem_classes*/
      4 && (l.elem_classes = /*elem_classes*/
      o[2]), r[0] & /*container*/
      64 && (l.container = /*container*/
      o[6]), r[0] & /*scale*/
      128 && (l.scale = /*scale*/
      o[7]), r[0] & /*min_width*/
      256 && (l.min_width = /*min_width*/
      o[8]), r[0] & /*canvas, isDraggingPoint, hoveredIndex, disabled, show_reset_button, show_label, info, label, gradio, loading_status*/
      65073 | r[2] & /*$$scope*/
      32768 && (l.$$scope = { dirty: r, ctx: o }), e.$set(l);
    },
    i(o) {
      t || (Dn(e.$$.fragment, o), t = !0);
    },
    o(o) {
      En(e.$$.fragment, o), t = !1;
    },
    d(o) {
      yn(e, o), n = !1, a();
    }
  };
}
let hu = 0;
const mu = 6;
function sn(i, e, t) {
  return [
    Math.round(i[0] + (e[0] - i[0]) * t),
    Math.round(i[1] + (e[1] - i[1]) * t),
    Math.round(i[2] + (e[2] - i[2]) * t)
  ];
}
function St(i) {
  const e = i.match(/rgba?\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
  return e ? [parseInt(e[1]), parseInt(e[2]), parseInt(e[3])] : [200, 200, 200];
}
function gu(i, e, t) {
  let n, { gradio: a } = e, { elem_id: o = "" } = e, { elem_classes: r = [] } = e, { visible: l = !0 } = e, { value: s = [] } = e, { label: u = "XYSlider" } = e, { info: c = void 0 } = e, { container: p = !0 } = e, { scale: d = null } = e, { min_width: h = void 0 } = e, { x_min: b = 0 } = e, { x_max: y = 1 } = e, { y_min: w = 0 } = e, { y_max: F = 1 } = e, { shade_enabled: f = !0 } = e, { shade_above_color: _ = "rgba(250, 204, 21, 0.25)" } = e, { shade_below_color: m = "rgba(34, 197, 94, 0.25)" } = e, { top_label: D = null } = e, { bottom_label: v = null } = e, E = null, C = null, k = null, S = null, B = "rgba(239, 68, 68, 0.9)", L = "rgba(59, 130, 246, 0.9)", K = "rgba(16, 185, 129, 0.9)", X = "rgba(234, 179, 8, 0.9)", { show_label: le } = e, { interactive: H } = e, { loading_status: Q } = e, { value_is_output: q = !1 } = e, { show_reset_button: ee } = e;
  const me = `xyslider_${hu++}`;
  let $, A = null, Y = 0, M = 0, ie = 1, N = [], ge = null, x = null, Ie = !1, Ge = null;
  function Je() {
    w >= F && t(27, F = w + 1e-6);
  }
  function Ht() {
    t(35, N = N.map(([g, R]) => [g, Math.max(w, Math.min(F, R))]));
  }
  function ot() {
    if (s && typeof s == "object" && !Array.isArray(s)) {
      if (typeof s.x == "number" && typeof s.y == "number")
        t(35, N = [[s.x, s.y]]);
      else if (Array.isArray(s.points) && s.points.length > 0) {
        const g = s.points[0];
        Array.isArray(g) && g.length === 2 && t(35, N = [[g[0], g[1]]]);
      }
      typeof s.x_min == "number" && t(24, b = s.x_min), typeof s.x_max == "number" && t(25, y = s.x_max), typeof s.y_min == "number" && t(26, w = s.y_min), typeof s.y_max == "number" && t(27, F = s.y_max), typeof s.shade_enabled == "boolean" && t(28, f = s.shade_enabled), typeof s.shade_above_color == "string" && t(29, _ = s.shade_above_color), typeof s.shade_below_color == "string" && t(30, m = s.shade_below_color), typeof s.top_label == "string" && t(31, D = s.top_label), typeof s.bottom_label == "string" && t(32, v = s.bottom_label), typeof s.upper_left_label == "string" && (E = s.upper_left_label), typeof s.upper_right_label == "string" && (C = s.upper_right_label), typeof s.lower_right_label == "string" && (k = s.lower_right_label), typeof s.lower_left_label == "string" && (S = s.lower_left_label), typeof s.color_upper_left == "string" && (B = s.color_upper_left), typeof s.color_upper_right == "string" && (L = s.color_upper_right), typeof s.color_lower_right == "string" && (K = s.color_lower_right), typeof s.color_lower_left == "string" && (X = s.color_lower_left);
    } else if (Array.isArray(s) && s.length === 2) {
      const [g, R] = s;
      t(35, N = [[g, R]]);
    }
    Zt(), N.map((g) => [g[0], g[1]]);
  }
  function za(g) {
    if (!(!g || typeof g != "object" || Array.isArray(g))) {
      if (typeof g.upper_left_label == "string" && (E = g.upper_left_label), typeof g.upper_right_label == "string" && (C = g.upper_right_label), typeof g.lower_right_label == "string" && (k = g.lower_right_label), typeof g.lower_left_label == "string" && (S = g.lower_left_label), typeof g.color_upper_left == "string" && (B = g.color_upper_left), typeof g.color_upper_right == "string" && (L = g.color_upper_right), typeof g.color_lower_right == "string" && (K = g.color_lower_right), typeof g.color_lower_left == "string" && (X = g.color_lower_left), !Ie && typeof g.x == "number" && typeof g.y == "number") {
        const R = Math.max(b, Math.min(y, g.x)), G = Math.max(w, Math.min(F, g.y));
        (N.length === 0 || N[0][0] !== R || N[0][1] !== G) && t(35, N = [[R, G]]);
      }
      be();
    }
  }
  function Ma() {
    a.dispatch("change"), q || a.dispatch("input");
  }
  function Nn() {
    t(33, q = !0);
    const g = Ua();
    t(23, s = g), a.dispatch("release", g);
  }
  function Gt() {
    Vt(), be();
  }
  function Pa() {
    t(35, N = []), Zt(), be(), a.dispatch("change"), Nn();
  }
  function Vt() {
    if (!$) return;
    const g = $.getBoundingClientRect();
    ie = window.devicePixelRatio || 1, Y = Math.max(1, Math.floor(g.width)), M = Math.max(120, Math.floor(g.height)), t(12, $.width = Math.floor(Y * ie), $), t(12, $.height = Math.floor(M * ie), $), A || (A = $.getContext("2d")), A && A.setTransform(ie, 0, 0, ie, 0, 0);
  }
  function qn(g) {
    const R = y - b || 1;
    return (g - b) / R * Y;
  }
  function On(g) {
    const R = F - w || 1;
    return M - (g - w) / R * M;
  }
  function zn(g) {
    const R = y - b || 1;
    return b + g / Y * R;
  }
  function Mn(g) {
    const R = F - w || 1;
    return w + (M - g) / M * R;
  }
  function Pn(g, R) {
    const G = y - b || 1, J = F - w || 1, W = (g - b) / G, ae = (R - w) / J, Ve = (1 - W) * ae, Me = W * ae, ne = (1 - W) * (1 - ae), se = W * (1 - ae);
    return {
      top_left: Ve,
      top_right: Me,
      bottom_left: ne,
      bottom_right: se
    };
  }
  function Ua() {
    if (N.length === 0) {
      const G = b + (y - b) * 0.5, J = w + (F - w) * 0.5;
      return {
        x: G,
        y: J,
        bilinear: Pn(G, J)
      };
    }
    const [g, R] = N[0];
    return { x: g, y: R, bilinear: Pn(g, R) };
  }
  function Ha() {
    if (!A) return;
    A.clearRect(0, 0, Y, M), Ga(), A.strokeStyle = "#e5e7eb", A.lineWidth = 1;
    const g = 8;
    for (let R = 1; R < g; R++) {
      const G = R / g * M;
      A.beginPath(), A.moveTo(0, G), A.lineTo(Y, G), A.stroke();
    }
    if (A.fillStyle = "#111827", A.font = "12px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial", A.textBaseline = "top", E && A.fillText(E, 8, 6), C) {
      const R = A.measureText(C).width;
      A.fillText(C, Y - R - 8, 6);
    }
    if (S && (A.textBaseline = "bottom", A.fillText(S, 8, M - 6)), k) {
      const R = A.measureText(k).width;
      A.textBaseline = "bottom", A.fillText(k, Y - R - 8, M - 6);
    }
  }
  function Ga() {
    if (!A) return;
    const g = St(B), R = St(L), G = St(K), J = St(X), W = 32, ae = Y / W, Ve = M / W;
    for (let ne = 0; ne < W; ne++)
      for (let se = 0; se < W; se++) {
        const Un = se / (W - 1), Ja = 1 - ne / (W - 1), er = sn(g, R, Un), tr = sn(J, G, Un), jt = sn(tr, er, Ja);
        A.fillStyle = `rgb(${jt[0]}, ${jt[1]}, ${jt[2]})`, A.fillRect(se * ae, ne * Ve, Math.ceil(ae) + 1, Math.ceil(Ve) + 1);
      }
    A.strokeStyle = "#e5e7eb", A.lineWidth = 1;
    const Me = 8;
    for (let ne = 1; ne < Me; ne++) {
      const se = ne / Me * M;
      A.beginPath(), A.moveTo(0, se), A.lineTo(Y, se), A.stroke();
    }
    for (let ne = 1; ne < Me; ne++) {
      const se = ne / Me * Y;
      A.beginPath(), A.moveTo(se, 0), A.lineTo(se, M), A.stroke();
    }
  }
  function Va() {
    if (!A || N.length === 0) return;
    const [g, R] = N[0], G = qn(g), J = On(R);
    A.strokeStyle = "#111827", A.lineWidth = 1, A.setLineDash([4, 3]), A.beginPath(), A.moveTo(G, 0), A.lineTo(G, M), A.moveTo(0, J), A.lineTo(Y, J), A.stroke(), A.setLineDash([]), A.fillStyle = "#111827", A.beginPath(), A.arc(G, J, 5, 0, Math.PI * 2), A.fill(), (x === 0 || ge === 0) && (A.beginPath(), A.arc(G, J, 9, 0, Math.PI * 2), A.lineWidth = 2, A.strokeStyle = x === 0 ? "#ffffff" : "#9ca3af", A.stroke()), A.font = "11px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial", A.fillStyle = "#111827", A.textBaseline = "bottom";
    const W = `${g.toFixed(2)}, ${R.toFixed(2)}`;
    A.fillText(W, G + 8, Math.max(0, J - 8));
  }
  function be() {
    $ && (Ha(), Va());
  }
  function Zt() {
    if (!Array.isArray(N) || N.length === 0) {
      const g = w + (F - w) * 0.5, R = b + (y - b) * 0.5;
      t(35, N = [[R, g]]);
    } else N.length > 1 && t(35, N = [[N[0][0], N[0][1]]]);
  }
  function Za(g) {
    if (H === !1) return;
    const R = $.getBoundingClientRect(), G = g.clientX - R.left, J = g.clientY - R.top, W = Math.max(b, Math.min(y, zn(G))), ae = Math.max(w, Math.min(F, Mn(J)));
    t(35, N = [[W, ae]]), x = 0, t(13, ge = 0), t(14, Ie = !0), Ge = 0;
    try {
      $.setPointerCapture(g.pointerId);
    } catch {
    }
    be();
  }
  function ja(g) {
    if (H === !1) return;
    const R = $.getBoundingClientRect(), G = g.clientX - R.left, J = g.clientY - R.top;
    if (Ie && Ge !== null && x !== null) {
      const W = Math.max(b, Math.min(y, zn(G))), ae = Math.max(w, Math.min(F, Mn(J)));
      t(35, N[x] = [W, ae], N), be();
      return;
    }
    t(13, ge = Xa(G, J, mu)), be();
  }
  function Ya(g) {
    Ie && (t(14, Ie = !1), Ge = null), Nn();
    try {
      $.releasePointerCapture(g.pointerId);
    } catch {
    }
  }
  function Xa(g, R, G) {
    const J = G * G;
    let W = null;
    for (let ae = 0; ae < N.length; ae++) {
      const [Ve, Me] = N[ae], ne = qn(Ve) - g, se = On(Me) - R;
      if (ne * ne + se * se <= J) {
        W = ae;
        break;
      }
    }
    return W;
  }
  _u(() => {
    ot(), Vt(), be();
    const g = new ResizeObserver(() => {
      Vt(), be();
    });
    return g.observe($), window.addEventListener("resize", Gt), () => {
      g.disconnect(), window.removeEventListener("resize", Gt);
    };
  }), cu(() => {
    t(33, q = !1), be();
  });
  const Wa = () => a.dispatch("clear_status", Q);
  function Ka(g) {
    tu[g ? "unshift" : "push"](() => {
      $ = g, t(12, $);
    });
  }
  const Qa = () => {
    Ie || (t(13, ge = null), be());
  };
  return i.$$set = (g) => {
    "gradio" in g && t(0, a = g.gradio), "elem_id" in g && t(1, o = g.elem_id), "elem_classes" in g && t(2, r = g.elem_classes), "visible" in g && t(3, l = g.visible), "value" in g && t(23, s = g.value), "label" in g && t(4, u = g.label), "info" in g && t(5, c = g.info), "container" in g && t(6, p = g.container), "scale" in g && t(7, d = g.scale), "min_width" in g && t(8, h = g.min_width), "x_min" in g && t(24, b = g.x_min), "x_max" in g && t(25, y = g.x_max), "y_min" in g && t(26, w = g.y_min), "y_max" in g && t(27, F = g.y_max), "shade_enabled" in g && t(28, f = g.shade_enabled), "shade_above_color" in g && t(29, _ = g.shade_above_color), "shade_below_color" in g && t(30, m = g.shade_below_color), "top_label" in g && t(31, D = g.top_label), "bottom_label" in g && t(32, v = g.bottom_label), "show_label" in g && t(9, le = g.show_label), "interactive" in g && t(34, H = g.interactive), "loading_status" in g && t(10, Q = g.loading_status), "value_is_output" in g && t(33, q = g.value_is_output), "show_reset_button" in g && t(11, ee = g.show_reset_button);
  }, i.$$.update = () => {
    i.$$.dirty[1] & /*interactive*/
    8 && t(15, n = H === !1), i.$$.dirty[0] & /*value*/
    8388608 && za(s), i.$$.dirty[1] & /*points*/
    16 && Ma();
  }, Je(), Ht(), Zt(), be(), [
    a,
    o,
    r,
    l,
    u,
    c,
    p,
    d,
    h,
    le,
    Q,
    ee,
    $,
    ge,
    Ie,
    n,
    me,
    Gt,
    Pa,
    be,
    Za,
    ja,
    Ya,
    s,
    b,
    y,
    w,
    F,
    f,
    _,
    m,
    D,
    v,
    q,
    H,
    N,
    Wa,
    Ka,
    Qa
  ];
}
class Z$ extends Js {
  constructor(e) {
    super(), ru(
      this,
      e,
      gu,
      pu,
      lu,
      {
        gradio: 0,
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 23,
        label: 4,
        info: 5,
        container: 6,
        scale: 7,
        min_width: 8,
        x_min: 24,
        x_max: 25,
        y_min: 26,
        y_max: 27,
        shade_enabled: 28,
        shade_above_color: 29,
        shade_below_color: 30,
        top_label: 31,
        bottom_label: 32,
        show_label: 9,
        interactive: 34,
        loading_status: 10,
        value_is_output: 33,
        show_reset_button: 11
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  Z$ as I,
  ai as c,
  vu as g
};
