
from .xyslider import XYSlider

__all__ = ['XYSlider']
