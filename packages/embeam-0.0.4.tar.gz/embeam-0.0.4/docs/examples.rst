.. _examples_sec:

Examples
========

You can find examples of using the ``embeam`` library in a series of notebooks
found in the directory ``<root>/examples`` of the repository, where ``<root>``
is the root of the ``embeam`` repository. You can find the repository `here
<https://github.com/mrfitzpa/embeam>`_.
