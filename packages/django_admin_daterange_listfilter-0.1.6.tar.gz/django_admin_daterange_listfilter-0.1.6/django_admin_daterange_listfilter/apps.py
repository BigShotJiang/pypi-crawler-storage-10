from django.apps import AppConfig


class DjangoAdminDaterangeListfilterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_admin_daterange_listfilter'
