default_app_config = (
    "django_admin_daterange_listfilter.apps.DjangoAdminDaterangeListfilterConfig"
)
app_requires = [
    "django_static_jquery_ui",
    "django_middleware_global_request",
    "django_listfilter_media_extension",
]
