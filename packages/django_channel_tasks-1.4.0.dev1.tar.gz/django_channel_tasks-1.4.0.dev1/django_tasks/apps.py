from django import apps


class TasksConfig(apps.AppConfig):
    name = 'django_tasks'
    verbose_name = 'Doc-Tasks'
