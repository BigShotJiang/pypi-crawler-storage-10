# gemato: __main__ wrapper
# (c) 2023 Michał Górny
# SPDX-License-Identifier: GPL-2.0-or-later

from gemato.cli import setuptools_main


if __name__ == '__main__':
    setuptools_main()
