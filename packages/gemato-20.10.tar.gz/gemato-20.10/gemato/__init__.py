"""Gentoo Manifest Tool -- a utility to verify and update Manifest files"""

__version__ = "20.10"
