# NiimPrint 精臣打印机Python库

## 🚀 功能特性

* 自动连接 NIIMBOT 打印机（指定 COM 端口）
* 获取设备信息：型号、固件版本、序列号
* 实时检测纸张状态（有纸/无纸）
* 读取 RFID 智能标签信息（UUID、条码、序列号、容量等）
* 打印任意图像（自动转换为 1-bit 黑白图）
* 支持自定义标签尺寸（单位：毫米）

## 📦 安装

* Install from source (Recommend)

```bash
cd niimprint
pip install -e .
```
* Install from PyPI
```bash
pip install niimprint
```

## 🚀 快速开始

### 🖨️ 使用示例

```python
from niimprint import PrinterClient, SerialTransport
from niimprint import InfoEnum

# 1. 连接打印机
transport = SerialTransport(port="COM9")
printer = PrinterClient(transport)

# 2. 获取设备信息
print("设备类型:", printer.get_info(InfoEnum.DEVICETYPE))
print("固件版本:", printer.get_info(InfoEnum.SOFTVERSION))

# 3. 检查耗材状态
status = printer.heartbeat()
if status.get('paperstate') == 0:
    print("✅ 有纸，可打印")

# 4. 打印图像
img = Image.open("test.jpg").resize((384, 160))
printer.print_image(img, density=3)  # density: 1~5
```

### 📐 标签尺寸设置

修改以下参数以匹配你的标签纸：

```python
width_mm = 30   # 标签宽度（毫米）
height_mm = 30  # 标签高度（毫米）
```

程序会自动按 203 dpi 转换为像素尺寸。

#### ⚠️ 注意事项

* 确保打印机已通过 USB 连接并识别为 COM 端口（如 COM9）
* 首次使用建议先运行设备信息查询，确认通信正常
* 图像将被转换为 黑白 1-bit 模式，彩色/灰度图会自动处理
* 打印浓度 density 范围：1（最浅）~ 5（最深），推荐值：3



## 🙏 特别声明

本项目基于niimbot的开源项目，核心协议实现参考自 niimprint 。

🔹 本项目仅为个人学习与便捷使用而开发

🔹 所有协议解析与通信逻辑均源自社区贡献

🔹 如官方需要，本人愿意将相关代码与改进交还给官方或原作者 

我们尊重 NIIMBOT 官方知识产权，本项目不用于商业分发，仅作为技术探索与自动化打印的实践示例。



## 📬 反馈与支持

如遇问题，请提供：

* 打印机具体型号（如 B1、B21 Pro）
* 标签纸类型（普通/RFID）
* 错误日志或现象描述
* 欢迎提交 Issue 或 PR

> **保持热爱，奔赴星海！**
> *这个世界上唯有两样东西能让我们的心灵感到深深的震撼：一是我们头上灿烂的星空，一是我们内心崇高的道德法则*

