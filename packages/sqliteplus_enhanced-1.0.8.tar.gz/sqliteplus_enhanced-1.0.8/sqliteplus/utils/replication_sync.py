from __future__ import annotations

if __name__ == "__main__" and __package__ in {None, ""}:
    import sys
    from pathlib import Path
    from runpy import run_module

    package_root = Path(__file__).resolve().parents[2]
    if str(package_root) not in sys.path:
        sys.path.insert(0, str(package_root))
    run_module("sqliteplus.utils.replication_sync", run_name="__main__")
    raise SystemExit()

import csv
import os
import shutil
import sqlite3
from pathlib import Path

from sqliteplus.utils.constants import DEFAULT_DB_PATH, resolve_default_db_path
from sqliteplus.utils.sqliteplus_sync import apply_cipher_key, SQLitePlusCipherError


class SQLiteReplication:
    """
    Módulo para exportación y replicación de bases de datos SQLitePlus.
    """

    def __init__(
        self,
        db_path: str | os.PathLike[str] | None = None,
        backup_dir="backups",
        cipher_key: str | None = None,
    ):
        if db_path is None:
            resolved_path = resolve_default_db_path()
        else:
            raw_path = Path(db_path).expanduser()
            if raw_path == Path(DEFAULT_DB_PATH):
                resolved_path = resolve_default_db_path(prefer_package=False)
            else:
                resolved_path = raw_path

        normalized_db_path = Path(resolved_path).expanduser().resolve()
        self.db_path = str(normalized_db_path)

        backup_base = Path(backup_dir).expanduser().resolve()
        self.backup_dir = backup_base
        self.cipher_key = cipher_key if cipher_key is not None else os.getenv("SQLITE_DB_KEY")
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def export_to_csv(self, table_name: str, output_file: str):
        """
        Exporta los datos de una tabla a un archivo CSV.
        """
        if not self._is_valid_table_name(table_name):
            raise ValueError(f"Nombre de tabla inválido: {table_name}")

        query = f"SELECT * FROM {self._escape_identifier(table_name)}"

        output_path = Path(output_file).expanduser().resolve()

        try:
            with sqlite3.connect(self.db_path) as conn:
                apply_cipher_key(conn, self.cipher_key)
                cursor = conn.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
                column_names = [desc[0] for desc in cursor.description]

            output_path.parent.mkdir(parents=True, exist_ok=True)

            with output_path.open("w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(column_names)
                writer.writerows(rows)

            print(f"Datos exportados correctamente a {output_path}")
        except SQLitePlusCipherError as exc:
            raise RuntimeError(str(exc)) from exc
        except sqlite3.Error as e:
            raise sqlite3.Error(f"Error al exportar datos: {e}") from e

    def backup_database(self):
        """
        Crea una copia de seguridad de la base de datos.
        """
        backup_file = self.backup_dir / f"backup_{self._get_timestamp()}.db"
        try:
            if not os.path.exists(self.db_path):
                raise FileNotFoundError(
                    f"No se encontró la base de datos origen: {self.db_path}"
                )

            with sqlite3.connect(self.db_path) as source_conn:
                apply_cipher_key(source_conn, self.cipher_key)
                with sqlite3.connect(str(backup_file)) as backup_conn:
                    apply_cipher_key(backup_conn, self.cipher_key)
                    source_conn.backup(backup_conn)

            self._copy_wal_and_shm(self.db_path, backup_file)

            print(f"Copia de seguridad creada en {backup_file}")
            return str(backup_file)
        except SQLitePlusCipherError as exc:
            raise RuntimeError(str(exc)) from exc
        except Exception as e:
            raise RuntimeError(
                f"Error al realizar la copia de seguridad: {e}"
            ) from e

    def replicate_database(self, target_db_path: str):
        """
        Replica la base de datos en otra ubicación.
        """
        try:
            if not os.path.exists(self.db_path):
                raise FileNotFoundError(
                    f"No se encontró la base de datos origen: {self.db_path}"
                )

            target_path = Path(target_db_path).expanduser().resolve()
            target_dir = target_path.parent
            if target_dir:
                target_dir.mkdir(parents=True, exist_ok=True)

            with sqlite3.connect(self.db_path) as source_conn:
                apply_cipher_key(source_conn, self.cipher_key)
                with sqlite3.connect(str(target_path)) as target_conn:
                    apply_cipher_key(target_conn, self.cipher_key)
                    source_conn.backup(target_conn)

            self._copy_wal_and_shm(self.db_path, target_path)

            print(f"Base de datos replicada en {target_path}")
            return str(target_path)
        except SQLitePlusCipherError as exc:
            raise RuntimeError(str(exc)) from exc
        except Exception as e:
            raise RuntimeError(f"Error en la replicación: {e}") from e

    def _get_timestamp(self):
        """
        Genera un timestamp para los nombres de archivo.
        """
        import datetime
        return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    @staticmethod
    def _is_valid_table_name(table_name: str) -> bool:
        return bool(table_name) and table_name.isidentifier()

    @staticmethod
    def _escape_identifier(identifier: str) -> str:
        escaped_identifier = identifier.replace('"', '""')
        return f'"{escaped_identifier}"'

    @staticmethod
    def _copy_wal_and_shm(
        source_path: str | os.PathLike[str],
        target_path: str | os.PathLike[str],
    ) -> list[str]:
        """Replica los archivos WAL y SHM asociados cuando existen."""

        base_source = Path(source_path)
        base_target = Path(target_path)
        copied_files: list[str] = []

        for suffix in ("-wal", "-shm"):
            src_file = base_source.with_name(base_source.name + suffix)
            if src_file.exists():
                dest_file = base_target.with_name(base_target.name + suffix)
                if dest_file.exists():
                    dest_file.unlink()
                dest_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, dest_file)
                copied_files.append(str(dest_file))

        return copied_files


if __name__ == "__main__":
    # Crear la base de datos por defecto si aún no existe antes de iniciar las
    # tareas de replicación.  Cuando el script se ejecuta fuera del árbol del
    # proyecto (por ejemplo, desde un directorio temporal) el archivo de base
    # de datos aún no ha sido creado y las operaciones de copia fallan con un
    # FileNotFoundError.  Inicializamos SQLitePlus para generar la estructura
    # necesaria y así garantizar que los comandos posteriores funcionen.
    from sqliteplus.utils.sqliteplus_sync import SQLitePlus

    database = SQLitePlus()
    database.log_action("Inicialización de replicación desde script")

    replicator = SQLiteReplication(db_path=database.db_path)
    replicator.backup_database()
    replicator.export_to_csv("logs", "logs_export.csv")
