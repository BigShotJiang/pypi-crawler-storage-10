import re
import math
import random
from . import data_arcturus

# -------------------------
# NLP Pipeline
# -------------------------
class arcturusNLP:
    def __init__(self):
        self.LEMMATIZER = data_arcturus.LEMMATIZER
        self.STOPWORDS = {"a", "an", "the", "is", "am", "are", "was", "were", "to", "of", "and", "in", "on", "for", "it"}

    def tokenize(self, text):
        text = text.lower()
        pattern = r'\w+'
        tokens = re.findall(pattern, text)
        return [t for t in tokens if t not in self.STOPWORDS]

    def lemmatizer(self, token):
        for lemma, forms in self.LEMMATIZER.items():
            if token in forms:
                return {token: (token, lemma)}
        return {token: (token, token)}

    def sentence_to_vector(self, sentence, idf=None):
        tokens = self.tokenize(sentence)
        lemmas = [self.lemmatizer(t).get(t, (t, t))[1] for t in tokens]
        vec = {}
        for t in lemmas:
            vec[t] = vec.get(t, 0) + 1

        # Apply TF-IDF weighting if IDF data exists
        if idf:
            for t in vec:
                vec[t] *= idf.get(t, 1.0)
        return vec

    def cosine_similarity(self, vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        dot = sum(vec1[t] * vec2[t] for t in intersection)
        mag1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
        mag2 = math.sqrt(sum(v ** 2 for v in vec2.values()))
        if mag1 == 0 or mag2 == 0:
            return 0
        return dot / (mag1 * mag2)


# -------------------------
# Supervised Intent-Based Bot
# -------------------------
class arcturusSUPERVISED_INTENT:
    def __init__(self, nlp_pipeline, intent_responses):
        self.nlp = nlp_pipeline
        self.intent_responses = intent_responses
        self.inputs = []
        self.intents = []
        self.vectors = []
        self.idf = {}

    def compute_idf(self, dataset):
        doc_count = {}
        total_docs = len(dataset)
        for sent, _ in dataset:
            tokens = set(self.nlp.tokenize(sent))
            for t in tokens:
                doc_count[t] = doc_count.get(t, 0) + 1
        for t, c in doc_count.items():
            self.idf[t] = math.log((1 + total_docs) / (1 + c)) + 1

    def train(self, data):
        self.inputs = [inp for inp, intent in data]
        self.intents = [intent for inp, intent in data]
        self.compute_idf(data)
        self.vectors = [self.nlp.sentence_to_vector(inp, self.idf) for inp in self.inputs]

    def predict_intent(self, sentence, show_scores=False):
        vec = self.nlp.sentence_to_vector(sentence, self.idf)
        scores = []
        for i, v in enumerate(self.vectors):
            sim = self.nlp.cosine_similarity(vec, v)
            scores.append((self.intents[i], sim))
        scores.sort(key=lambda x: x[1], reverse=True)
        if show_scores:
            print("Intent similarity scores:", scores)
        return scores[0][0] if scores else "unknown"

    def get_response(self, sentence):
        intent = self.predict_intent(sentence)
        responses = self.intent_responses.get(intent, ["I don't understand."])
        return random.choice(responses)


# -------------------------
# Keyword-Based Search Engine
# -------------------------
# -------------------------
# Cosine-Similarity-Based Search Engine
# -------------------------
import math

class arcturusSEARCH_ENGINE:
    def __init__(self, nlp_pipeline, search_data):
        """
        search_data: list of strings (documents to search in)
        """
        self.nlp = nlp_pipeline
        self.search_data = search_data or []
        self.idf = self.compute_idf(self.search_data)

        # Precompute TF-IDF vectors for all documents
        self.vectors = [
            self.nlp.sentence_to_vector(doc, self.idf)
            for doc in self.search_data
        ]

    def compute_idf(self, documents):
        """Compute simple IDF values for all tokens in the search data."""
        doc_count = {}
        total_docs = len(documents)
        for doc in documents:
            tokens = set(self.nlp.tokenize(doc))
            for t in tokens:
                doc_count[t] = doc_count.get(t, 0) + 1
        idf = {t: math.log((1 + total_docs) / (1 + c)) + 1 for t, c in doc_count.items()}
        return idf

    def search_response(self, sentence, show_scores=False):
        """Find the best-matching document using cosine similarity."""
        query_vec = self.nlp.sentence_to_vector(sentence, self.idf)

        best_doc = None
        best_score = 0
        scores = []

        for doc, vec in zip(self.search_data, self.vectors):
            score = self.nlp.cosine_similarity(query_vec, vec)
            scores.append((doc, score))
            if score > best_score:
                best_score = score
                best_doc = doc

        if show_scores:
            print("🔍 Similarity Scores:")
            for doc, s in sorted(scores, key=lambda x: x[1], reverse=True):
                print(f"  {doc} -> {s:.3f}")

        return best_doc

