class SimpleLinearRegression:
    """
    Simple Linear Regression model built from scratch.
    y = b0 + b1 * x
    """

    def __init__(self):
        self.b0 = 0  # intercept
        self.b1 = 0  # slope
        self.fitted = False

    def fit(self, X, y):
        """Train the model using least squares formula."""
        if len(X) != len(y):
            raise ValueError("X and y must be the same length")

        x_mean = sum(X) / len(X)
        y_mean = sum(y) / len(y)

        num = sum((X[i] - x_mean) * (y[i] - y_mean) for i in range(len(X)))
        den = sum((X[i] - x_mean)**2 for i in range(len(X)))

        self.b1 = num / den
        self.b0 = y_mean - self.b1 * x_mean
        self.fitted = True

    def predict(self, X):
        """Predict y for a given list of X values."""
        if not self.fitted:
            raise RuntimeError("Model must be fitted before prediction.")
        return [self.b0 + self.b1 * x for x in X]

    def score(self, X, y):
        """Compute R² score."""
        y_pred = self.predict(X)
        y_mean = sum(y) / len(y)
        ss_tot = sum((yi - y_mean)**2 for yi in y)
        ss_res = sum((y[i] - y_pred[i])**2 for i in range(len(y)))
        return 1 - (ss_res / ss_tot)

    def __str__(self):
        return f"SimpleLinearRegression(b0={self.b0:.3f}, b1={self.b1:.3f})"
