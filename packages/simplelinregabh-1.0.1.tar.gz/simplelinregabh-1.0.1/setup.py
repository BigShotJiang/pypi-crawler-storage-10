from setuptools import setup, find_packages

setup(
    name='simplelinregabh',
    version='1.0.1',
    author='Yacine Abderrahmane Belkaid',
    author_email='yacine.abh@gmail.com',
    description='A simple linear regression model built from scratch in Python.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    license='MIT',
    packages=find_packages(),
    python_requires='>=3.7',
)
