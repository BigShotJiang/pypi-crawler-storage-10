# simpleLinRegAbh

A simple linear regression model built from scratch using pure Python.

## Usage

```python
from simpleLinRegAbh import SimpleLinearRegression

X = [1, 2, 3, 4, 5]
y = [2, 4, 5, 4, 5]

model = SimpleLinearRegression()
model.fit(X, y)

print("Slope:", model.b1)
print("Intercept:", model.b0)
print("Predictions:", model.predict([6, 7]))
print("R² score:", model.score(X, y))
