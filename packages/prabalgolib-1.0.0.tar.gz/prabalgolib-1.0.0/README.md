# Algolib

Custom Python library with common search and sorting algorithms.

## Installation
```bash
pip install palgolib




