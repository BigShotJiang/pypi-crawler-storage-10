from setuptools import setup, find_packages

setup(
    name="prabalgolib",
    version="1.0.0",
    author="PRABANJAN M",
    author_email="prabanjanm22@gamil.com",
    description="Custom search and sorting algorithms library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/algolib",
    packages=find_packages(),
    python_requires='>=3.6',
)



