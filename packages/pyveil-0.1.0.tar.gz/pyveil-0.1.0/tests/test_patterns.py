"""Tests for the patterns module."""
