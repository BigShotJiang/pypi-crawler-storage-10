"""Test suite for ppget."""
