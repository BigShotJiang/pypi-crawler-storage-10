# 测试与演示手册

本文列出若干命令行或脚本示例，便于快速验证 `solidity_fcg_tool` 的功能，涵盖函数源码提取、调用图查看以及 Python API 演示。所有命令默认在项目根目录执行。

## 1. 函数源码查询

```bash
python -m solidity_fcg_tool \
  --project samples/SimpleToken.sol \
  query \
  --contract SimpleToken \
  --function "transfer(address,uint256)"
```

输出示例（缩略）：
```json
{
  "contract": "SimpleToken",
  "function": "transfer(address,uint256)",
  "source": "...",
  "location": {
    "file": "/absolute/path/to/solidity-fcg-tool/samples/SimpleToken.sol",
    "start_line": 17,
    "end_line": 20
  },
  "parameter": [
    { "name": "to", "type": "address" },
    { "name": "amount", "type": "uint256" }
  ],
  "calls": [
    {
      "file": "/Audit/solidity-fcg-tool/samples/SimpleToken.sol",
      "module": "SimpleToken",
      "function": "_performTransfer(address,address,uint256)"
    }
  ]
}
```

## 2. 调用图导出

```bash
python -m solidity_fcg_tool \
  --project samples/SimpleToken.sol \
  call-graph \
  --contract SimpleToken
```

若希望只查看特定函数的出边：

```bash
python -m solidity_fcg_tool \
  --project samples/SimpleToken.sol \
  call-graph \
  --contract SimpleToken \
  --function "transfer(address,uint256)"
```

## 3. 指定 `solc` 版本运行

```bash
python -m solidity_fcg_tool \
  --project samples/SimpleToken.sol \
  --solc-version 0.8.20 \
  query \
  --contract SimpleToken \
  --function "balanceOf(address)"
```

## 4. Python API 快速脚本

```bash
python - <<'PY'
from pprint import pprint
from solidity_fcg_tool.services.query import create_service

service = create_service("samples/SimpleToken.sol")

function_info = service.get_function_source("SimpleToken", "transfer(address,uint256)")
print("函数源码片段:")
print(function_info["source"])

print("\n调用图出边:")
pprint(service.get_call_graph(caller_contract="SimpleToken"))
PY
```

## 5. 演示引擎不可用时的容错

```bash
python - <<'PY'
from solidity_fcg_tool.services.query import QueryService, QueryError

service = QueryService("samples/SimpleToken.sol", engine_name="non-existent")
try:
    print(service.list_contracts())
except QueryError as exc:
    print("预期失败:", exc)
PY
```

## 6. 将结果重定向保存

```bash
python -m solidity_fcg_tool \
  --project samples/SimpleToken.sol \
  query \
  --contract SimpleToken \
  --function "transfer(address,uint256)" \
  > output.json
cat output.json
```

以上命令覆盖 README 中列举的主要使用场景，可直接作为日常验证或演示脚本。***
