# solidity-fcg-tool 需求说明

## 1. 背景与目标
- 目标：构建一个 Solidity 静态分析工具，对合约源代码进行模块（合约/库）与函数级别的解析，为后续 AI 框架提供精准的源代码与关系数据。
- 方法：以现有成熟工具为基础（PoC 选用 Slither），对外提供统一的查询接口，确保未来可无缝切换或并存 Tree-sitter、Solar 等其他解析引擎。
- 预期产出：一个可在命令行与 Python API 中调用的小型模块，输入模块名 + 函数名/签名，返回对应源代码及关联信息。

## 2. 术语说明
- 模块（Module）：指 Solidity 合约、库或接口。
- 函数（Function）：Solidity 中的函数、构造函数、事件函数（当需要）等可被调用的代码块。
- 解析引擎（Engine）：承担源码解析与静态信息计算的实现，可由 Slither、Tree-sitter 等工具驱动。

## 3. 功能需求
### F1 合约解析
- 支持对单个文件或基于 `crytic-compile` 的多文件项目进行编译与解析。
- 解析结果需包含模块列表、继承结构、函数声明及其签名。

### F2 函数源码检索
- 输入：`模块名` + `函数名`（需支持同名不同签名的情况，优先使用完整签名）。
- 输出：函数完整源码文本、在原文件中的位置信息（文件路径、起始/结束行列）、所属模块及可见性等元数据。

### F3 调用关系与上下文
- 提供函数级调用图数据，至少包含被调函数列表与调用方向。
- 对库函数、内部函数、继承导致的函数解析需正确归位，避免漏报或重复。

### F4 对 AI 的友好数据接口
- 返回结构化数据（Python 对象和可 JSON 序列化结果），为上层 AI 应用直接消费。
- 需要包含最小上下文（如模块级注释、继承链）以便 AI 推理。

### F5 CLI 与 API
- CLI 示例：`python -m tool query --contract Foo --function "bar(uint256)"` 返回 JSON。
- Python API：`tool.query.get_function_source(contract="Foo", function="bar(uint256)")`。

## 4. 解析引擎抽象需求
- 定义统一的引擎接口，例如：
  - `parse(project_path) -> ProjectModel`
  - `get_function(contract_name, function_signature)`
  - `get_call_graph(contract_name)`
- 引擎应通过依赖注入或注册机制接入，避免在业务逻辑中写死特定实现。
- 需提供引擎能力描述（例如支持/不支持调用图、事件解析等）以便业务层降级处理。

## 5. PoC 范围（v0）
- 默认引擎：Slither。
- 依赖：`slither-analyzer`、`crytic-compile`、`py-solc-x`。
- 生成的模型需覆盖功能需求 F1-F4 的基本场景。
- 需要简单的 CLI 命令与最小测试样例。

## 6. 系统架构与主要模块
- `core/engine_base.py`：抽象引擎接口定义。
- `core/models.py`：数据模型（ContractInfo、FunctionInfo、CallGraphEdge 等）。
- `engines/slither_engine.py`：Slither 适配器，实现引擎接口。
- `services/query.py`：对外查询服务，负责参数校验、缓存、结果格式化。
- `cli.py` / `__main__.py`：命令行入口，解析参数并调用 `services.query`。
- `samples/`：存放示例合约用于测试与演示。
- `tests/`：针对模型转换与查询接口的单元测试。

## 7. 输入输出规范
- 支持输入：
  - 单个 Solidity 文件路径。
  - 包含 `solc` 配置或 `crytic.json` 的项目目录。
- 输出统一结构：
  ```json
  {
    "contract": "Foo",
    "function": "bar(uint256)",
    "visibility": "public",
    "source": "function bar(uint256 x) ...",
    "location": {
      "file": "contracts/Foo.sol",
      "start_line": 12,
      "start_column": 1,
      "end_line": 20,
      "end_column": 2
    },
    "calls": ["Foo._internal(uint256)", "Lib.doThing(address)"],
    "metadata": { "engine": "slither", "timestamp": "..." }
  }
  ```
- 需保证输出可被 JSON 序列化。

## 8. 扩展性与未来路线
- 提供引擎注册表，例如 `register_engine("slither", SlitherEngine)`。
- 未来可接入：
  - Tree-sitter：提供更快的语法解析，适合轻量需求。
  - Solar、Mythril 等：用于更深入的静态分析或安全检测。
- 为多个引擎并存预留策略（优先级、能力标记、回退逻辑）。

## 9. 性能与依赖约束
- 需缓存编译结果和解析模型，减少重复运行成本。
- PoC 阶段可接受 1-2s 的解析延迟，后续需评估增量分析能力。
- 明确 `solc` 版本需求，并在 README 中提供安装说明。

## 10. 测试与验收标准
- 至少包含：
  - 函数检索单元测试（包含继承、库、函数重载场景）。
  - 调用图解析测试（基础调用、跨合约调用）。
- 验收条件：
  - 对样例合约，CLI 与 API 均可返回预期函数源码及调用信息。
  - 切换解析引擎时（即使未实现），主流程保持稳定，可给出明确错误或降级提示。

## 11. 文档与可维护性
- README 需要覆盖安装依赖、运行示例、支持的功能列表。
- 为引擎抽象、数据模型补充内联注释或开发文档，便于后续扩展。
- 代码需保持模块化、低耦合，遵循 Python 通用编码规范。
