"""API module for Cradle Data Load Config UI."""

from .routes import router

__all__ = ["router"]
