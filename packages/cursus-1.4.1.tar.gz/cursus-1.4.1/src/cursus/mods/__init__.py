"""
Cursus modules package.

This package contains modular components that extend the core cursus functionality.
"""
