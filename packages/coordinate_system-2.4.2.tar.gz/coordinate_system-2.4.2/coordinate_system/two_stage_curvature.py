#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Two-Stage Adaptive Curvature Computation
基于两级自适应修正的曲率计算

理论基础：
1. 离散化误差与真实曲率成正比：ε ∝ K_true
2. 投影协变破坏在李括号中被线性放大
3. 通过快速估算打破曲率嵌套的自指循环
"""

from typing import Optional
import numpy as np

# ========== Stage 1: Fast Curvature Scale Estimation ==========

def estimate_curvature_scale(
    surface,
    u: float,
    v: float,
    h: float = 1e-3
) -> float:
    """
    第1级：快速曲率标量估计

    基于法向量变化的几何直觉：
    曲率越大，法向量变化越快

    Args:
        surface: 曲面对象
        u, v: 参数坐标
        h: 步长

    Returns:
        粗估的曲率标量 K_rough
    """
    # 计算中心点和邻域点的法向量
    n_center = surface.normal(u, v)
    n_u_plus = surface.normal(u + h, v)
    n_v_plus = surface.normal(u, v + h)

    # 法向量变化的平均值（几何直觉）
    dn_u = (n_u_plus - n_center).len()
    dn_v = (n_v_plus - n_center).len()

    # 粗估曲率：法向量变化率的平均
    K_rough = (dn_u + dn_v) / (2.0 * h)

    return K_rough


def estimate_curvature_from_metric(
    surface,
    u: float,
    v: float,
    h: float = 1e-3
) -> float:
    """
    基于度量张量变化的曲率估计（备用方法）

    通过度量张量的二阶导数粗估曲率
    """
    from coordinate_system.differential_geometry import compute_metric

    # 计算度量张量
    g = compute_metric(surface, u, v)

    # 简化估计：基于 Gauss 方程的离散近似
    # K ≈ -Δ log(√det(g)) / 2

    g_u_plus = compute_metric(surface, u + h, v)
    g_u_minus = compute_metric(surface, u - h, v)
    g_v_plus = compute_metric(surface, u, v + h)
    g_v_minus = compute_metric(surface, u, v - h)

    # 二阶差分
    d2_det_u = (g_u_plus.det - 2.0 * g.det + g_u_minus.det) / (h * h)
    d2_det_v = (g_v_plus.det - 2.0 * g.det + g_v_minus.det) / (h * h)

    if abs(g.det) > 1e-10:
        K_rough = -(d2_det_u + d2_det_v) / (2.0 * g.det)
    else:
        K_rough = 0.0

    return K_rough


# ========== Stage 2: Adaptive Correction Factor ==========

def compute_adaptive_beta(
    K_estimate: float,
    beta_0: float = 0.75,
    alpha: float = 0.1,
    gamma: float = 2.0
) -> float:
    """
    第2级：计算自适应修正因子

    基于曲率估计的修正因子：
    β(K) = β_0 × (1 + α × tanh(γ × K_estimate))

    物理意义：
    - β_0 = 0.75: 基准修正因子，补偿投影协变破坏
    - α: 曲率依赖的调节参数
    - γ: 曲率响应的敏感度

    Args:
        K_estimate: 第1级估算的曲率标量
        beta_0: 基准修正因子（默认 0.75）
        alpha: 调节参数
        gamma: 敏感度参数

    Returns:
        自适应修正因子 β
    """
    # 使用 tanh 函数实现平滑的非线性响应
    beta = beta_0 * (1.0 + alpha * np.tanh(gamma * abs(K_estimate)))

    return beta


def compute_simple_beta(K_estimate: float) -> float:
    """
    简化版修正因子（固定值）

    基于经验观察：投影协变破坏导致~33%的系统性放大
    因此修正因子 β ≈ 3/4 = 0.75
    """
    return 0.75


# ========== Two-Stage Curvature Computation ==========

def compute_gaussian_curvature_two_stage(
    surface,
    u: float,
    v: float,
    step_size: float = 1e-3,
    use_adaptive_beta: bool = True,
    beta_0: float = 0.75
) -> float:
    """
    两级自适应曲率计算

    算法流程：
    1. Stage 1: 快速估算曲率标量 K_rough
    2. Stage 2: 计算自适应修正因子 β(K_rough)
    3. 应用修正因子到精确曲率计算

    Args:
        surface: 曲面对象
        u, v: 参数坐标
        step_size: 数值微分步长
        use_adaptive_beta: 是否使用自适应修正因子
        beta_0: 基准修正因子

    Returns:
        修正后的高斯曲率 K

    Example:
        >>> sphere = Sphere(radius=1.0)
        >>> K = compute_gaussian_curvature_two_stage(sphere, np.pi/2, np.pi/4)
        >>> print(f"K = {K:.6f}")  # 应接近 1.0
    """
    # === Stage 1: 快速曲率标量估计 ===
    K_rough = estimate_curvature_scale(surface, u, v, step_size)

    # === Stage 2: 自适应修正因子 ===
    if use_adaptive_beta:
        beta = compute_adaptive_beta(K_rough, beta_0=beta_0)
    else:
        beta = beta_0

    # === 精确曲率张量计算 ===
    # 导入避免循环依赖
    from coordinate_system.differential_geometry import compute_curvature_tensor, compute_metric

    R_uv = compute_curvature_tensor(
        surface, u, v,
        scale_factor=1.0,  # 不在这里应用 scale_factor
        use_metric_correction=True,
        use_lie_derivative=False,  # 简化版不使用李导数项
        step_size=step_size
    )

    g = compute_metric(surface, u, v)

    # 提取反对称部分
    R_01 = R_uv.ux.y
    R_10 = R_uv.uy.x
    R_12_antisym = (R_01 - R_10) / 2.0

    # 原始曲率（未修正）
    if abs(g.det) > 1e-10:
        K_raw = R_12_antisym / g.det
    else:
        K_raw = 0.0

    # === 应用修正因子 ===
    K_corrected = beta * K_raw

    return K_corrected


# ========== Enhanced Version with Iterative Refinement ==========

def compute_gaussian_curvature_iterative(
    surface,
    u: float,
    v: float,
    step_size: float = 1e-3,
    max_iterations: int = 3,
    tolerance: float = 1e-4
) -> float:
    """
    迭代精化版本的两级曲率计算

    通过迭代更新修正因子，进一步提高精度：
    1. 初始估计 K^(0)
    2. 计算 β^(1) = f(K^(0))
    3. 更新 K^(1) = β^(1) × K_raw
    4. 重复直到收敛

    Args:
        surface: 曲面对象
        u, v: 参数坐标
        step_size: 数值微分步长
        max_iterations: 最大迭代次数
        tolerance: 收敛判据

    Returns:
        迭代收敛后的高斯曲率 K
    """
    # 初始估计
    K_prev = estimate_curvature_scale(surface, u, v, step_size)

    # 计算原始曲率（只计算一次）
    from coordinate_system.differential_geometry import compute_curvature_tensor, compute_metric

    R_uv = compute_curvature_tensor(
        surface, u, v,
        scale_factor=1.0,
        use_metric_correction=True,
        use_lie_derivative=False,
        step_size=step_size
    )

    g = compute_metric(surface, u, v)
    R_01 = R_uv.ux.y
    R_10 = R_uv.uy.x
    R_12_antisym = (R_01 - R_10) / 2.0

    if abs(g.det) > 1e-10:
        K_raw = R_12_antisym / g.det
    else:
        return 0.0

    # 迭代精化
    for iteration in range(max_iterations):
        # 基于上一次估计计算修正因子
        beta = compute_adaptive_beta(K_prev)

        # 更新曲率估计
        K_new = beta * K_raw

        # 检查收敛
        if abs(K_new - K_prev) < tolerance:
            return K_new

        K_prev = K_new

    return K_prev


__all__ = [
    'estimate_curvature_scale',
    'estimate_curvature_from_metric',
    'compute_adaptive_beta',
    'compute_simple_beta',
    'compute_gaussian_curvature_two_stage',
    'compute_gaussian_curvature_iterative',
]
