"""The Eheim Digital package."""

__version__ = "1.4.0"
