"""
Minimal health checker demo script.
This script demonstrates the core health checking functionality.
"""

import json
import time
from openHealth import HealthChecker, load_config



def demo_direct_config_initialization():
    """Demo using direct config parameter for continuous monitoring (new approach)."""
    print("=== Demo: Continuous Monitoring with Direct Config ===")
    print("NOTE: This runs continuous monitoring that checks services at configured intervals.")
    
    # Load config using standalone function
    print("Loading configuration using load_config() function...")
    config = load_config(config_path="debug_config.json")
    print(f"Config loaded successfully, contains {len(config['services'])} service(s)")

    # Create simple status callback
    def status_callback(result):
        status_icon = "[OK]" if result.is_healthy() else "[ERROR]"
        error_info = f" - Error: {result.error_message}" if result.error_message else ""
        print(f"{status_icon} {result.service_name}: {result.status} ({result.response_time * 1000:.1f}ms){error_info}")

    # Initialize health checker using direct config
    print("\nInitializing health checker with direct config...")
    checker = HealthChecker(
        config=config,
        log_level="INFO"
    )

    # Add status callback
    checker.add_status_callback(status_callback)
    
    try:
        print("Starting continuous monitoring...")
        checker.start()
        
        print("✅ Continuous monitoring started successfully!")
        print("📊 Services will be checked at configured intervals")
        print("🌐 Web dashboard available at http://localhost:8080")
        print("⏹️  Press Ctrl+C to stop monitoring")
        print("=" * 60)
        
        # Keep the script running for continuous monitoring
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n⏹️  Stopping monitoring by user request...")
        
    finally:
        print("🛑 Stopping health checker...")
        checker.stop()
        print("✅ Health checker stopped successfully.")


def main():
    demo_direct_config_initialization()



if __name__ == "__main__":
    main()

