"""
Test suite for openHealth package.
"""