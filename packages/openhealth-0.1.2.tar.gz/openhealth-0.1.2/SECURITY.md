# Security Policy

## Supported Versions

| Version | Supported Until |
|---------|-----------------|
| 0.1.x   | Current         |
| 0.0.x   | Unsupported     |

Only the latest version of openHealth receives security updates and patches. Users are strongly encouraged to upgrade to the latest version.

## Reporting a Vulnerability

### How to Report

If you discover a security vulnerability in openHealth, please report it privately before disclosing it publicly.

**Email:** kdhruv.fsd@gmail.com
**Subject:** Security Vulnerability Report - openHealth

### What to Include

Please include as much information as possible in your report:

- **Type of vulnerability** (e.g., XSS, SQL injection, authentication bypass)
- **Affected versions** of openHealth
- **Steps to reproduce** the vulnerability
- **Proof of concept** or exploit code (if available)
- **Potential impact** of the vulnerability
- **Any suggested mitigations** (if known)

### Response Timeline

- **Initial response**: Within 48 hours
- **Detailed assessment**: Within 7 days
- **Patch release**: Within 14 days (depending on severity)
- **Public disclosure**: After patch is released and users have time to update

### Security Contact Information

- **Primary Contact**: Dhruv Karnwal (kdhruv.fsd@gmail.com)
- **Repository Security**: Use GitHub's private vulnerability reporting feature when available

## Security Model

### Threat Model

openHealth is designed to monitor the health of web services and applications. The primary security considerations are:

1. **Network Communications**: HTTP/HTTPS requests to monitored services
2. **Configuration Security**: Handling of credentials and sensitive data
3. **Notification Systems**: Email, Slack, and webhook outputs
4. **Web Dashboard**: Authentication and access control
5. **Data Storage**: Logs, configuration files, and historical data

### Security Features

#### Network Security
- HTTPS certificate validation by default
- Configurable request timeouts
- Support for custom headers and authentication
- SSL/TLS verification options

#### Configuration Security
- Environment variable support for sensitive data
- Configuration file permissions recommendations
- No hardcoded credentials
- Optional credential encryption

#### Access Control
- Web dashboard basic authentication
- API key support for webhooks
- Configurable notification endpoints
- Audit logging for security events

## Best Practices

### For Users

1. **Use HTTPS**: Always monitor services over HTTPS when possible
2. **Secure Configuration**: Store sensitive data in environment variables
3. **Regular Updates**: Keep openHealth updated to the latest version
4. **Network Isolation**: Run monitoring in isolated network segments
5. **Access Control**: Implement proper authentication for web dashboard
6. **Log Management**: Securely store and rotate logs

### Configuration Security Examples

```bash
# Use environment variables for sensitive data
export SMTP_PASSWORD="your-smtp-password"
export SLACK_WEBHOOK="https://hooks.slack.com/your-webhook"
export DASHBOARD_SECRET="your-secret-key"

# Secure file permissions
chmod 600 config.json
chmod 700 logs/
```

### Example Secure Configuration

```json
{
  "services": [
    {
      "name": "api-service",
      "url": "https://api.example.com/health",
      "headers": {
        "Authorization": "Bearer ${API_TOKEN}"
      },
      "verify_ssl": true
    }
  ],
  "notifications": {
    "email": {
      "smtp_password": "${SMTP_PASSWORD}"
    },
    "slack": {
      "webhook_url": "${SLACK_WEBHOOK}"
    }
  },
  "dashboard": {
    "secret_key": "${DASHBOARD_SECRET}",
    "auth_required": true
  }
}
```

## Known Security Considerations

### Current Limitations

1. **Web Authentication**: Currently only supports basic authentication
2. **Credential Storage**: Credentials stored in plaintext in configuration files
3. **Log Sensitivity**: Logs may contain sensitive URLs or headers
4. **Network Exposure**: Web dashboard runs on configured ports

### Mitigation Recommendations

1. **Use Reverse Proxy**: Place dashboard behind authenticated reverse proxy
2. **Environment Variables**: Store sensitive data in environment variables
3. **Network Security**: Use firewalls and network segmentation
4. **Log Sanitization**: Configure log levels appropriately
5. **Regular Audits**: Review configurations and access logs

## Security Updates

### How to Apply Updates

1. **Monitor Releases**: Watch for security announcements
2. **Update Dependencies**: Update openHealth using pip:
   ```bash
   pip install --upgrade openHealth
   ```
3. **Review Configuration**: Check for new security settings
4. **Test Thoroughly**: Validate in non-production environment first
5. **Update Documentation**: Review and update security procedures

### Security Announcements

Security announcements will be made through:
- GitHub Security Advisories
- Release notes in CHANGELOG.md
- Email notifications (for critical issues)

## Third-Party Dependencies

### Security of Dependencies

openHealth uses the following dependencies that have security implications:

- `requests`: HTTP client library
- `flask`: Web framework for dashboard
- `schedule`: Task scheduling
- `jsonschema`: JSON validation

### Dependency Management

- Dependencies are pinned to secure versions
- Regular security audits are performed
- Vulnerability scanning is part of CI/CD process
- Updates are tested before release

## Incident Response

### Incident Classification

- **Critical**: Immediate threat to system security or data
- **High**: Significant security impact, requires prompt attention
- **Medium**: Moderate security issue
- **Low**: Minor security concern

### Response Process

1. **Detection**: Vulnerability reported or discovered
2. **Assessment**: Evaluate impact and severity
3. **Development**: Create and test patch
4. **Release**: Deploy security update
5. **Notification**: Inform users and provide guidance
6. **Documentation**: Update security documentation

## Security Audits

### Regular Security Reviews

- Code security reviews before major releases
- Dependency vulnerability scanning
- Configuration security validation
- Access control verification

### Tools Used

- **Bandit**: Python security linter
- **Safety**: Dependency vulnerability checker
- **Snyk**: Open source security scanning
- **Semgrep**: Static analysis security testing

## Security Resources

### Useful Links

- [OWASP Python Security](https://cheatsheetseries.owasp.org/cheatsheets/Python_Security_Cheat_Sheet.html)
- [Python Security Best Practices](https://docs.python.org/3/library/security.html)
- [HTTPS Certificate Validation](https://requests.readthedocs.io/en/latest/user/advanced/#ssl-cert-verification)
- [Flask Security Best Practices](https://flask.palletsprojects.com/en/2.3.x/security/)

### Recommended reading

- Secure Coding Guidelines
- Web Application Security
- Network Security Fundamentals
- Cryptography Best Practices

## Security Questions

If you have any security-related questions or concerns that don't require a full vulnerability report, feel free to contact us:

- **Email**: kdhruv.fsd@gmail.com
- **GitHub Issues**: Use the "security" label for security discussions

---

## Security Policy Updates

This security policy may be updated periodically to reflect:
- New security features
- Updated threat models
- Changed best practices
- Feedback from the community

Last updated: October 27, 2025

Thank you for helping keep openHealth secure! 🔒