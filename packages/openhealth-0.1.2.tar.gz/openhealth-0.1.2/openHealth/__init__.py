"""
openHealth Package

A comprehensive health monitoring tool for backend and frontend services.
Supports multiple endpoints with configurable intervals, retries, timeouts,
and notification systems including email and Slack integration.
"""

from ._version import __version__
from .client import HealthChecker
from .core.config import ConfigValidator, load_config, validate_config

__author__ = "Dhruv Karnwal"
__email__ = "kdhruv.fsd@gmail.com"

__all__ = ["HealthChecker", "ConfigValidator", "load_config", "validate_config", "__version__"]