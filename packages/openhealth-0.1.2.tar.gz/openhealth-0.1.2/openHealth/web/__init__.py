"""
Web dashboard module for health checker.
"""

from .dashboard import WebDashboard

__all__ = ["WebDashboard"]