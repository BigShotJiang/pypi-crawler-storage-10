"""
Setup script for openHealth package.
"""

from setuptools import setup, find_packages
import os

# Read README file
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "A comprehensive health monitoring tool for backend and frontend services."

# Read requirements
def read_requirements():
    requirements_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    if os.path.exists(requirements_path):
        with open(requirements_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

setup(
    name="openHealth",
    version="0.1.2",
    author="Dhruv Karnwal",
    author_email="kdhruv.fsd@gmail.com",
    description="A comprehensive health monitoring tool for backend and frontend services",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/Dhruv1969Karnwal/openHealth",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP :: Site Management",
        "Topic :: System :: Monitoring",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.0.0",
            "pytest-mock>=3.0.0",
            "black>=21.0.0",
            "flake8>=3.8.0",
            "mypy>=0.800",
            "pre-commit>=2.0.0",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=0.5.0",
            "myst-parser>=0.15.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "openhealth=openHealth.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords="health monitoring check status alert notification webhook email slack dashboard",
    project_urls={
        "Bug Reports": "https://github.com/Dhruv1969Karnwal/openHealth/issues",
        "Source": "https://github.com/Dhruv1969Karnwal/openHealth",
        "Documentation": "https://openhealth.readthedocs.io/",
    },
)