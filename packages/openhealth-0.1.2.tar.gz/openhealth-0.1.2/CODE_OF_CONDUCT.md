# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

## Our Standards

### Expected Behavior

**✅ DO:**

- **Be Respectful and Considerate**: Treat others with respect, kindness, and empathy
- **Be Welcoming**: Welcome newcomers and help them learn and contribute
- **Be Collaborative**: Work together to solve problems and build great software
- **Be Constructive**: Provide constructive feedback and focus on what is best for the community
- **Be Inclusive**: Use inclusive language and be mindful of different perspectives and experiences
- **Be Professional**: Maintain professional conduct in all interactions
- **Be Helpful**: Help others learn and grow, share knowledge freely
- **Be Patient**: Remember that people have different skill levels and learning curves
- **Be Accountable**: Take responsibility for your actions and their impact
- **Be Positive**: Maintain a positive attitude and focus on solutions

**Examples of Positive Behavior:**

```python
# Good example: Providing helpful feedback
"I notice this approach might have a performance issue for large datasets. 
Have you considered using a generator or implementing pagination? 
Here's a reference that might help: [link]"

# Good example: Welcoming newcomers
"Welcome to openHealth! That's a great first contribution. 
Let me know if you need help with the development setup or have any questions."
```

### Prohibited Behavior

**🚫 DON'T:**

- **Harassment**: Any form of harassment, bullying, or intimidation
- **Discrimination**: Discrimination based on any personal characteristic
- **Personal Attacks**: Insults, personal criticism, or attacks on character
- **Unwelcome Content**: Posting sexually explicit, violent, or offensive content
- **Privacy Violations**: Sharing private information about others without consent
- **Spam**: Posting irrelevant, off-topic, or repetitive content
- **Trolling**: Deliberately provoking or disrupting discussions
- **Threats**: Any form of threat or incitement to violence
- **Vandalism**: Intentionally damaging or disrupting the project
- **Doxxing**: Sharing private or identifying information about others

**Examples of Unacceptable Behavior:**

```
# Bad example: Personal attack
"That's a stupid way to implement it. Anyone with basic coding skills would know better."

# Bad example: Unwelcoming behavior
"You clearly don't know what you're doing. Maybe you should contribute to a different project."
```

## Enforcement Guidelines

### Reporting Guidelines

**How to Report:**

If you experience or witness unacceptable behavior, please report it:

- **Email**: kdhruv.fsd@gmail.com
- **GitHub Issues**: Create a private issue if available, or contact maintainers directly
- **Slack/Discord**: Private message to project maintainers (if available)

**What to Include:**

- Description of the incident
- People involved (if comfortable sharing)
- When and where it occurred
- Any relevant screenshots or links
- Whether you want to remain anonymous

### Response Process

1. **Initial Response**: We'll acknowledge your report within 48 hours
2. **Investigation**: We'll investigate the incident thoroughly and privately
3. **Action**: We'll take appropriate action based on the severity
4. **Follow-up**: We'll follow up with you about the resolution

### Enforcement Actions

Depending on the severity and circumstances, we may:

- **Warning**: Private warning about inappropriate behavior
- **Temporary Suspension**: Temporary removal from community spaces
- **Permanent Ban**: Permanent removal from all community spaces
- **Content Removal**: Removal of inappropriate content
- **Official Apology**: Request for public or private apology
- **Restorative Justice**: Facilitated conversation to resolve conflicts

### Appeals

If you believe an enforcement action was made in error:

1. Send a detailed appeal to kdhruv.fsd@gmail.com
2. Include the original action and why you believe it was incorrect
3. We will review within 7 days and respond accordingly

## Community Guidelines

### Communication Guidelines

**In Issues and Pull Requests:**

- Use clear, descriptive titles
- Provide context and relevant details
- Be patient with maintainers and contributors
- Search existing issues before creating new ones
- Use appropriate labels and templates

**In Discussions and Forums:**

- Stay on topic
- Use appropriate channels for different types of discussions
- Avoid cross-posting the same question in multiple places
- Follow the community's norms and etiquette

**Code and Documentation:**

- Write clear, maintainable code
- Include helpful comments and documentation
- Follow the project's coding standards
- Review others' contributions constructively

### Conflict Resolution

**When Disagreements Arise:**

1. **Assume Good Intent**: Assume others are acting with good intentions
2. **Stay Calm**: Avoid emotional responses in discussions
3. **Focus on Issues**: Discuss technical issues, not personal opinions
4. **Seek Mediation**: Ask maintainers to help mediate if needed
5. **Take Breaks**: Step away from heated discussions if needed

**Constructive Disagreement Example:**

```
Good: "I have a different perspective on this approach. 
I'm concerned about X and Y. Could we explore alternative Z instead?"

Bad: "Your approach is completely wrong and will never work."
```

## Specific Scenarios

### Code Reviews

**As a Reviewer:**

- Be constructive and specific in your feedback
- Explain the "why" behind your suggestions
- acknowledge good work and improvements
- Be patient and helpful with questions

**As an Author:**

- Be open to feedback and suggestions
- Ask for clarification if feedback is unclear
- Thank reviewers for their time and input
- Respond professionally, even to critical feedback

### New Contributors

**Welcoming Newcomers:**

- Greet them and thank them for their interest
- Help them with setup and initial contributions
- Point them to relevant documentation
- Be patient as they learn the project

**As a New Contributor:**

- Don't hesitate to ask for help
- Read the documentation and existing issues
- Start with small, well-defined tasks
- Join community discussions and introduce yourself

### Handling Mistakes

**When You Make a Mistake:**

- Acknowledge it honestly and quickly
- Focus on fixing the issue
- Learn from the experience
- Share what you learned with others

**When Others Make Mistakes:**

- Be understanding and supportive
- Focus on solutions, not blame
- Help them fix the issue
- Turn it into a learning opportunity

## Diversity and Inclusion

### Our Commitment to Diversity

We are committed to creating a diverse and inclusive community where:

- Everyone feels welcome and valued
- Different perspectives are respected and considered
- People from all backgrounds can participate fully
- Leadership reflects our community's diversity

### Inclusive Language Guidelines

**Use Inclusive Language:**

- Use gender-neutral language (e.g., "they" instead of "he/she")
- Avoid idioms that might not translate well
- Be mindful of cultural differences
- Avoid assumptions about background or experience

**Examples:**

```
Instead of: "Hey guys!"
Use: "Hello everyone!" or "Hello team!"

Instead of: "Man up and fix it"
Use: "Let's tackle this problem" or "We need to resolve this"
```

## Consequences of Unacceptable Behavior

### Temporary Consequences

- **Warning**: Official warning about behavior
- **Moderation**: Content may require review before posting
- **Temporary Suspension**: Limited access for a specified period

### Permanent Consequences

- **Community Ban**: Permanent removal from all community spaces
- **Project Ban**: Permanent removal from project involvement
- **Legal Action**: Involvement of law enforcement if required

## Community Resources

### Help and Support

- **Documentation**: Project README and guides
- **Maintainers**: Contact information in project files
- **Community Forums**: GitHub Discussions (if available)
- **Resources**: Links to relevant learning materials

### Mental Health Resources

- **Crisis Support**: Local mental health hotlines
- **Professional Help**: Encourage seeking professional help when needed
- ** breaks**: Take breaks from online communities when overwhelmed

## Acknowledgments

### Inspiration

This Code of Conduct is adapted from:

- [Contributor Covenant](https://www.contributor-covenant.org/)
- [Python Code of Conduct](https://www.python.org/psf/conduct/)
- [GitHub Community Guidelines](https://docs.github.com/en/github/site-policy/github-community-guidelines)

### Contact

**Code of Conduct Maintainer:**
- **Dhruv Karnwal**: kdhruv.fsd@gmail.com

This Code of Conduct is licensed under the [Creative Commons Attribution 4.0 International License](https://creativecommons.org/licenses/by/4.0/).

---

## Enforcement Statistics

To maintain transparency, we'll occasionally publish (anonymized) statistics about:

- Number of reports received
- Types of issues reported
- Actions taken
- Resolution times

Last updated: October 27, 2025

Thank you for helping us maintain a welcoming and inclusive community! 🌈