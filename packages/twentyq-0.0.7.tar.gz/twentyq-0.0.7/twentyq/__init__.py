# import the play_game function from the play module
from .play import play_game
