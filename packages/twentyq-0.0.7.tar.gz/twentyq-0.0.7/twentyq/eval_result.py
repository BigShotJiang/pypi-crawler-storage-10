import re

# translations for "yes" in various languages
yes_translations = {
    "english": "yes",
    "hindi": "हां",
    "mandarin": "是",
    "spanish": "sí",
    "japanese": "はい",
    "turkish": "evet",
    "french": "oui",
}

# Function to compute evaluation metrics from a text file
def compute_metrics(file_path, max_turns, language):

    """
    Computes the evaluation metrics from the given txt file.
    Args:
        file_path (str): Path to the evaluation txt file.
        max_turns (int): Maximum number of turns allowed.
        language (str): Language for the "yes" response.
    Returns:
        dict: A dictionary containing the evaluation metrics.
    """
    
    # Open the file and read lines
    with open(file_path, "r") as txt_file:
        lines = txt_file.readlines()

    # Remove the first two lines
    lines = lines[2:]

    lines = [line.strip() for line in lines if line.strip()]

    num_yes = 0
    success = False
    has_given_up = False
    turn_at_which_given_up = "N/A"
    num_turns_to_answer = "N/A"
    turn_count = 0

    # Check if the last line contains "bingo" to determine success
    if "bingo" in lines[min(2 * max_turns, len(lines)) - 1].lower():
        success = True

    # Iterate through the lines to count "yes" responses and check for giving up
    for i in range(0, min(2 * max_turns, len(lines)), 2):
        match = re.search(r"Turn (\d+)", lines[i])
        if match:
            turn_count = int(match.group(1))

        if "User:" in lines[i + 1]:
            if yes_translations[language].lower() in lines[i + 1].lower():
                num_yes += 1
            if "you have given up" in lines[i + 1].lower():
                has_given_up = True
                turn_at_which_given_up = turn_count

    # If the game was successful, record the number of turns to answer
    if success:
        num_turns_to_answer = turn_count

    result = {
        "Success": success,
        "Has_Given_Up": has_given_up,
        "Turn_At_Which_Given_Up": turn_at_which_given_up,
        "Num_Turns_To_Answer": num_turns_to_answer,
        "Num_Yes": num_yes
    }

    return result