"""Reachy Part module.

Handles all specific methods commmon to all Reachy parts (Arm, Head, Hand or MobileBase).
"""

import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Dict

import grpc
from reachy2_sdk_api.arm_pb2 import Arm as Arm_proto
from reachy2_sdk_api.arm_pb2 import ArmState, ArmStatus
from reachy2_sdk_api.arm_pb2_grpc import ArmServiceStub
from reachy2_sdk_api.hand_pb2 import Hand as Hand_proto
from reachy2_sdk_api.hand_pb2 import HandState, HandStatus
from reachy2_sdk_api.hand_pb2_grpc import HandServiceStub
from reachy2_sdk_api.head_pb2 import Head as Head_proto
from reachy2_sdk_api.head_pb2 import HeadState, HeadStatus
from reachy2_sdk_api.head_pb2_grpc import HeadServiceStub
from reachy2_sdk_api.mobile_base_utility_pb2 import MobileBase as MobileBase_proto
from reachy2_sdk_api.mobile_base_utility_pb2 import MobileBaseState, MobileBaseStatus
from reachy2_sdk_api.mobile_base_utility_pb2_grpc import MobileBaseUtilityServiceStub
from reachy2_sdk_api.part_pb2 import PartId


class Part(ABC):
    """The Part class serves as an abstract base class representing parts of a robot, such as Arm, Hand, Head, or MobileBase.

    This class provides a common interface for managing robot components, including turning them on or off, checking their
    status, and updating their states. The class is intended to be subclassed to implement specific behaviors for different
    types of robot parts.
    """

    def __init__(
        self,
        proto_msg: Arm_proto | Head_proto | Hand_proto | MobileBase_proto,
        grpc_channel: grpc.Channel,
        stub: ArmServiceStub | HeadServiceStub | HandServiceStub | MobileBaseUtilityServiceStub,
    ) -> None:
        """Initialize the Part with common attributes for gRPC communication.

        This sets up the communication channel and service stubs for the specified part,
        configures the part's unique identifier. It provides the foundation for specific parts of the robot
        (Arm, Head, Hand, MobileBase) to be derived from this class.

        Args:
            proto_msg: The protobuf message containing configuration details for the part
                (Arm, Head, Hand, or MobileBase).
            grpc_channel: The gRPC channel used to communicate with the service.
            stub: The service stub for the gRPC communication, which could be for Arm, Head,
                Hand, or MobileBase.
        """
        self._grpc_channel = grpc_channel
        self._stub = stub
        self._part_id = PartId(id=proto_msg.part_id.id, name=proto_msg.part_id.name)
        self._logger = logging.getLogger(__name__)

        self._actuators: Dict[str, Any] = {}

    def turn_on(self) -> bool:
        """Turn on the part.

        This method sets the speed limits to a low value, turns on all motors of the part, and then restores the speed limits
        to maximum. It waits for a brief period to ensure the operation is complete.

        Returns:
            'True' if all motors are on, 'False' otherwise.
        """
        self._set_speed_limits(1)
        time.sleep(0.05)
        turned_on = self._turn_on()
        time.sleep(0.05)
        self._set_speed_limits(100)
        time.sleep(0.4)
        return turned_on

    def turn_off(self) -> bool:
        """Turn off the part.

        This method turns off all motors of the part and waits for a brief period to ensure the operation is complete.

        Returns:
            'True' if all motors are off, 'False' otherwise.
        """
        return self._turn_off()

    def _turn_on(self) -> bool:
        """Send a command to turn on immediately the part.

        It retries the operation a maximum number of times if the part does not turn on immediately.

        Returns:
            'True' if all motors are on, 'False' otherwise.
        """
        max_iter = 10
        ite = 0
        while not self.is_on() and ite < max_iter:
            self._stub.TurnOn(self._part_id)
            ite += 1
            time.sleep(0.05)

        if ite == max_iter:
            self._logger.warning(f"Failed to turn on {self._part_id.name}")
            return False
        return True

    def _turn_off(self) -> bool:
        """Send a command to turn off immediately the part.

        It retries the operation a maximum number of times if the part does not turn off immediately.

        Returns:
            'True' if all motors are off, 'False' otherwise.
        """
        max_iter = 10
        ite = 0
        while not self.is_off() and ite < max_iter:
            self._stub.TurnOff(self._part_id)
            ite += 1
            time.sleep(0.05)

        if ite == max_iter:
            self._logger.warning(f"Failed to turn off {self._part_id.name}")
            return False
        return True

    def is_on(self) -> bool:
        """Check if all actuators of the part are currently on.

        Returns:
            True if all actuators are on, otherwise False.
        """
        for actuator in self._actuators.values():
            if not actuator.is_on():
                return False
        return True

    def is_off(self) -> bool:
        """Check if all actuators of the part are currently off.

        Returns:
            True if all actuators are off, otherwise False.
        """
        for actuator in self._actuators.values():
            if actuator.is_on():
                return False
        return True

    @abstractmethod
    def _update_with(self, state: ArmState | HeadState | HandState | MobileBaseState) -> None:
        """Update the part's state with newly received data.

        This method must be implemented by subclasses to update the state of the part based on
        specific state data types such as ArmState, HeadState, HandState, or MobileBaseState.

        Args:
            state: The state data used to update the part, which can be an ArmState, HeadState,
                HandState, or MobileBaseState.
        """
        pass  # pragma: no cover

    @abstractmethod
    def _update_audit_status(self, state: ArmStatus | HeadStatus | HandStatus | MobileBaseStatus) -> None:
        """Update the audit status of the part.

        This method must be implemented by subclasses to update the audit status of the part based on
        specific status data types such as ArmStatus, HeadStatus, HandStatus, or MobileBaseStatus.

        Args:
            state: The status data used to update the audit status, which can be an ArmStatus,
                HeadStatus, HandStatus, or MobileBaseStatus.
        """
        pass  # pragma: no cover

    @abstractmethod
    def _set_speed_limits(self, value: int) -> None:
        """Set the speed limits for the part.

        This method must be implemented by subclasses to set speed limits.

        Args:
            value: The speed limit value to be set, as a percentage of the maximum speed allowed (0-100).
        """
        pass  # pragma: no cover

    @property
    def audit(self) -> Dict[str, str]:
        """Get the audit status of all actuators of the part.

        Returns:
            A dictionary where each key is the name of an actuator and the value is its audit status.
            If an error is detected in any actuator, a warning is logged. Otherwise, an informational
            message indicating no errors is logged.
        """
        error_dict: Dict[str, str] = {}
        error_detected = False
        for act_name, actuator in self._actuators.items():
            error_dict[act_name] = actuator.status
            if actuator.status is not None and actuator.status != "Ok":
                self._logger.warning(f'Error detected on {self._part_id.name}_{act_name}: "{actuator.status}"')
                error_detected = True
        if not error_detected:
            self._logger.info(f"No error detected on {self._part_id.name}")
        return error_dict
