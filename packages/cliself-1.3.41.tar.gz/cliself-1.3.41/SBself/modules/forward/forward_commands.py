# -*- coding: utf-8 -*-
# File: CliSelf/SBself/moudels/forward/forward_commands.py
#
# رجیستر دستورات فوروارد:
#   - saveall <SRC> to <DEST>
#   - add_fmsg / clear_fmsgs
#   - add_ftarget / clear_ftargets
#   - set_fdelay / start_forward / stop_forward / forward_status
#   - (اختیاری) set_fcycle
#
# استفاده در main.py:
#   from SBself.moudels.forward.forward_commands import register as register_forward_commands
#   register_forward_commands(app)

from __future__ import annotations

from pyrogram import Client, filters
from pyrogram.types import Message
from SBself.filters.SBfilters import admin_filter

# ماژول تک‌فوروارد (saveall) — طبق ساختار زیپ شما زیر modules/forward/
from SBself.modules.forward.forward_cmds import init_forward_tools, forward_all

# ماژول مولتی‌فوروارد (صف پیام‌ها و چند مقصد) — طبق زیپ
from SBself.modules.forward.multi_forward_cmds import (
    add_fmsg, clear_fmsgs,
    add_ftarget, clear_ftargets,
    set_fdelay, set_fcycle,  # set_fcycle اختیاری است؛ اگر در پروژه‌ات نیست حذفش کن
    start_forward, stop_forward, forward_status,
)

# -*- coding: utf-8 -*-
# File: SBself/modules/forward/forward_commands.py
#
# دستورات:
#   saveall <SRC> to <DEST>
#
# مثال‌ها:
#   saveall @Rrabt to me
#   saveall 777000 to me
#   saveall @my_channel to @backup_channel
#   saveall -1001234567890 to @somewhere

from __future__ import annotations

import asyncio
from typing import Optional, List, Union

from pyrogram import Client, filters
from pyrogram.types import Message

from SBself.filters.SBfilters import admin_filter


# --- کمک‌تابع‌ها -------------------------------------------------------------

async def _resolve_ref(app: Client, ref: str) -> Union[str, int]:
    """
    رشته‌ی ورودی کاربر رو به چیزی که Pyrogram قبول داره تبدیل می‌کنه:
    - "me" همون "me" می‌مونه
    - اگر قابل تبدیل به int باشه، int برمی‌گردونیم (برای آیدی‌های عددی مثل 777000 یا -100...)
    - در غیر این صورت خود رشته (یوزرنیم/لینک) برمی‌گرده
    در نهایت یک get_chat می‌زنیم تا سریع ارورِ نا‌معتبر بودن منبع/مقصد مشخص شه.
    """
    norm = ref.strip()
    if norm.lower() == "me":
        target = "me"
    else:
        try:
            target = int(norm)
        except Exception:
            target = norm

    # اعتبارسنجی سبک: اگر چت وجود نداشته باشد همین‌جا ارور می‌خوریم
    await app.get_chat(target)
    return target


async def _paged_history(app: Client, src: Union[str, int], page_size: int = 200):
    """
    تاریخچه‌ی پیام‌ها را صفحه‌به‌صفحه برمی‌گرداند (از جدید به قدیم)،
    ولی ما هر صفحه را reverse می‌کنیم تا فوروارد نهایی به ترتیب قدیم→جدید باشد.
    Yield می‌کند لیست‌های کوچکِ پیام (برای مصرف کمِ RAM).
    """
    # نکته: get_chat_history در Pyrogram از جدید به قدیم برمی‌گرداند.
    # با offset_id صفحه‌بندی می‌کنیم.
    last_id = 0
    while True:
        batch: List[Message] = await app.get_chat_history(
            chat_id=src,
            offset_id=last_id,
            limit=page_size
        )
        if not batch:
            break
        # صفحه را از قدیمی به جدید می‌کنیم:
        batch.reverse()
        yield batch
        # برای صفحه‌ی بعدی، قدیمی‌ترین مورد این صفحه را به‌عنوان offset می‌گیریم:
        last_id = batch[0].id


async def _forward_messages_ordered(
    app: Client,
    src: Union[str, int],
    dest: Union[str, int],
    delay_sec: float = 0.0
) -> int:
    """
    همه‌ی پیام‌های src را به ترتیب زمانی به dest فوروارد می‌کند.
    اگر محتوای چت protected باشد، Pyrogram اجازه‌ی forward نمی‌دهد و آن پیام را رد می‌کنیم.
    خروجی: تعداد پیام‌های موفق.
    """
    forwarded = 0
    async for page in _paged_history(app, src, page_size=200):
        for msg in page:
            try:
                # فقط فوروارد (نه کپی) طبق خواسته‌ی شما
                await app.forward_messages(
                    chat_id=dest,
                    from_chat_id=src,
                    message_ids=msg.id
                )
                forwarded += 1
                if delay_sec > 0:
                    await asyncio.sleep(delay_sec)
            except Exception:
                # پیام‌هایی که فورواردشان مجاز نیست/پاک شده‌اند/… را رد می‌کنیم
                continue
    return forwarded


# --- فرمان اصلی: saveall ----------------------------------------------------
def register(app: Client) -> None:
    # آماده‌سازی ابزارهای فوروارد تک‌مقصدی (در صورت نیاز)
    try:
        init_forward_tools(app)
    except Exception:
        # اگر برای اولین بار مسیرها/پوشه‌ها ساخته نشده بود، اجازه بده هندلرها بعداً آن را راه بیندازند
        pass

    @app.on_message(admin_filter & filters.command("saveall", prefixes=["/", ""]))
    async def _saveall_handler(client: Client, m: Message):
        """
        استفاده:
            saveall <SRC> to <DEST>

        مثال:
            saveall @Rrabt to me
        """
        text = (m.text or "").strip()
        parts = text.split()
        # انتظار داریم شکل دستور این باشد: saveall <SRC> to <DEST>
        if len(parts) < 4 or parts[2].lower() != "to":
            return await m.reply(
                "Usage:\n"
                "saveall <SRC> to <DEST>\n"
                "مثال: saveall @Rrabt to me"
            )
        src_ref = parts[1]
        dest_ref = parts[3]

        try:
            src = await _resolve_ref(client, src_ref)
            dest = await _resolve_ref(client, dest_ref)
        except Exception as e:
            return await m.reply(f"❌ منبع/مقصد نامعتبر است: {e}")

        try:
            count = await _forward_messages_ordered(client, src, dest, delay_sec=0.0)
        except Exception as e:
            return await m.reply(f"⚠️ خطا در saveall: {e}")

        if count == 0:
            return await m.reply("هیچ پیامی فوروارد نشد (شاید چت خالی/محافظت‌شده باشد).")
        return await m.reply(f"✅ {count} پیام با موفقیت به مقصد فوروارد شد.")

    # ---- Multi Forwarder ----
    @app.on_message(admin_filter & filters.command("add_fmsg", prefixes=["/", ""]))
    async def _add_fmsg(client: Client, m: Message):
        msg_id = None
        if m.text and len(m.command) > 1:
            try:
                msg_id = int(m.command[1])
            except Exception:
                return await m.reply("❌ msg_id نامعتبر است.")
        await m.reply(await add_fmsg(m, msg_id))

    @app.on_message(admin_filter & filters.command("clear_fmsgs", prefixes=["/", ""]))
    async def _clear_fmsgs(client: Client, m: Message):
        await m.reply(await clear_fmsgs())

    @app.on_message(admin_filter & filters.command("add_ftarget", prefixes=["/", ""]))
    async def _add_ftarget(client: Client, m: Message):
        if not (m.text and len(m.command) > 1):
            return await m.reply("Usage: add_ftarget <chat_id|@username>")
        try:
            chat_id = int(m.command[1])
        except Exception:
            chat_id = m.command[1]  # مثلا @channel
        await m.reply(await add_ftarget(chat_id))

    @app.on_message(admin_filter & filters.command("clear_ftargets", prefixes=["/", ""]))
    async def _clear_ftargets(client: Client, m: Message):
        await m.reply(await clear_ftargets())

    @app.on_message(admin_filter & filters.command("set_fdelay", prefixes=["/", ""]))
    async def _set_fdelay(client: Client, m: Message):
        if not (m.text and len(m.command) > 1):
            return await m.reply("Usage: set_fdelay <seconds>")
        try:
            seconds = int(m.command[1])
        except Exception:
            return await m.reply("❌ عدد معتبر وارد کن.")
        await m.reply(await set_fdelay(seconds))

    @app.on_message(admin_filter & filters.command("start_forward", prefixes=["/", ""]))
    async def _start_forward(client: Client, m: Message):
        await m.reply(await start_forward(client))

    @app.on_message(admin_filter & filters.command("stop_forward", prefixes=["/", ""]))
    async def _stop_forward(client: Client, m: Message):
        await m.reply(await stop_forward())

    @app.on_message(admin_filter & filters.command("forward_status", prefixes=["/", ""]))
    async def _forward_status(client: Client, m: Message):
        await m.reply(await forward_status())

    # اختیاری: فاصله‌ی بین چرخه‌ها (اگر در پروژه/ماژولت تعریف نشده، این بلوک را حذف کن)
    @app.on_message(admin_filter & filters.command("set_fcycle", prefixes=["/", ""]))
    async def _set_fcycle(client: Client, m: Message):
        if not (m.text and len(m.command) > 1):
            return await m.reply("Usage: set_fcycle <seconds>")
        try:
            seconds = int(m.command[1])
        except Exception:
            return await m.reply("❌ عدد معتبر وارد کن.")
        await m.reply(await set_fcycle(seconds))
