from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class RunStatus(ZosEnumBase):
    COMPLETED = 0
    FAILED_TO_START = 1
    TIMED_OUT = 2
    INVALID_TIMEOUT = 3

# attach config AFTER class creation (safe from Enum)
RunStatus._NATIVE_PATH = "ZOSAPI.Tools.RunStatus"
RunStatus._ALIASES_EXTRA = {
    "COMPLETED": ("Completed",),
    "FAILED_TO_START": ("FailedToStart",),
    "TIMED_OUT": ("TimedOut",),
    "INVALID_TIMEOUT": ("InvalidTimeout",),
}

__all__ = ["RunStatus"]
