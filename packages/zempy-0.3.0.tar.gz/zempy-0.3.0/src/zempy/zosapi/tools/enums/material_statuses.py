from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class MaterialStatuses(ZosEnumBase):
    STANDARD = 0
    PREFERRED = 1
    OBSOLETE = 2
    SPECIAL = 3
    MELT = 4

# attach config AFTER class creation (safe from Enum)
MaterialStatuses._NATIVE_PATH = "ZOSAPI.Tools.MaterialStatuses"
MaterialStatuses._ALIASES_EXTRA = {
    "STANDARD": ("Standard",),
    "PREFERRED": ("Preferred",),
    "OBSOLETE": ("Obsolete",),
    "SPECIAL": ("Special",),
    "MELT": ("Melt",),
}

__all__ = ["MaterialStatuses"]
