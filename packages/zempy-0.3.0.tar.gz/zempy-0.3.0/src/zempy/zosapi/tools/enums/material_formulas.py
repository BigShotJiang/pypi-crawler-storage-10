from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class MaterialFormulas(ZosEnumBase):
    SCHOTT = 0
    SELLMEIER1 = 1
    HERZBERGER = 2
    SELLMEIER2 = 3
    CONRADY = 4
    SELLMEIER3 = 5
    HANDBOOK1 = 6
    HANDBOOK2 = 7
    SELLMEIER4 = 8
    EXTENDED = 9
    SELLMEIER5 = 10
    EXTENDED2 = 11
    EXTENDED3 = 12

# attach config AFTER class creation (safe from Enum)
MaterialFormulas._NATIVE_PATH = "ZOSAPI.Tools.MaterialFormulas"
MaterialFormulas._ALIASES_EXTRA = {
    "SCHOTT": ("Schott",),
    "SELLMEIER1": ("Sellmeier1",),
    "HERZBERGER": ("Herzberger",),
    "SELLMEIER2": ("Sellmeier2",),
    "CONRADY": ("Conrady",),
    "SELLMEIER3": ("Sellmeier3",),
    "HANDBOOK1": ("Handbook1",),
    "HANDBOOK2": ("Handbook2",),
    "SELLMEIER4": ("Sellmeier4",),
    "EXTENDED": ("Extended",),
    "SELLMEIER5": ("Sellmeier5",),
    "EXTENDED2": ("Extended2",),
    "EXTENDED3": ("Extended3",),
}

__all__ = ["MaterialFormulas"]
