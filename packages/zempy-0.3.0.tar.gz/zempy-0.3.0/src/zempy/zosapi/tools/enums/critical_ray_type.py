from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class CriticalRayType(ZosEnumBase):
    CHIEF = 0
    MARGINAL = 1
    GRID = 2
    RING = 3
    Y_FAN = 4
    X_FAN = 5
    XY_FAN = 6
    LIST = 7

# attach config AFTER class creation (safe from Enum)
CriticalRayType._NATIVE_PATH = "ZOSAPI.Tools.CriticalRayType"
CriticalRayType._ALIASES_EXTRA = {
    "CHIEF": ("Chief",),
    "MARGINAL": ("Marginal",),
    "GRID": ("Grid",),
    "RING": ("Ring",),
    "Y_FAN": ("YFan",),
    "X_FAN": ("XFan",),
    "XY_FAN": ("XYFan",),
    "LIST": ("List",),
}

__all__ = ["CriticalRayType"]
