from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class HPCEnvironments(ZosEnumBase):
    ON_PREMISE = 0
    AWS_KUBERNETES = 1
    AZURE_KUBERNETES = 2

# attach config AFTER class creation (safe from Enum)
HPCEnvironments._NATIVE_PATH = "ZOSAPI.Tools.HPCEnvironments"
HPCEnvironments._ALIASES_EXTRA = {
    "ON_PREMISE": ("OnPremise",),
    "AWS_KUBERNETES": ("AWSKubernetes",),
    "AZURE_KUBERNETES": ("AzureKubernetes",),
}

__all__ = ["HPCEnvironments"]
