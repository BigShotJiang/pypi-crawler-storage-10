from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class HPCRunState(ZosEnumBase):
    NOT_RUNNING = 0
    INITIALIZING = 1
    CLUSTER_ALLOCATING = 2
    UPLOADING_DATA = 3
    QUEUED = 4
    RUN_STARTING = 5
    WAITING_FOR_RESULTS = 6
    COMPLETE = 7

# attach config AFTER class creation (safe from Enum)
HPCRunState._NATIVE_PATH = "ZOSAPI.Tools.HPCRunState"
HPCRunState._ALIASES_EXTRA = {
    "NOT_RUNNING": ("NotRunning",),
    "INITIALIZING": ("Initializing",),
    "CLUSTER_ALLOCATING": ("ClusterAllocating",),
    "UPLOADING_DATA": ("UploadingData",),
    "QUEUED": ("Queued",),
    "RUN_STARTING": ("RunStarting",),
    "WAITING_FOR_RESULTS": ("WaitingForResults",),
    "COMPLETE": ("Complete",),
}

__all__ = ["HPCRunState"]
