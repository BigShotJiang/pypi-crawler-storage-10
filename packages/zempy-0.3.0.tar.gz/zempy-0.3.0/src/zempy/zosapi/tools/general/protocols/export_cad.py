from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable, Optional
from zempy.zosapi.tools.protocols.system_tool import ISystemTool
from zempy.zosapi.tools.general.enums.cad_file_type import CADFileType
from zempy.zosapi.tools.general.enums.cad_tolerance_type import CADToleranceType
from zempy.zosapi.tools.general.enums.cad_angular_tolerance_type import CADAngularToleranceType
from zempy.zosapi.tools.general.enums.acis_export_version import ACISExportVersion
from zempy.zosapi.tools.general.enums.scale_to_units import ScaleToUnits



@dataclass(frozen=True)
class ExportCADOptions:
    file_path: str
    file_type: CADFileType
    tolerance_type: CADToleranceType | None = None
    angular_tolerance_type: CADAngularToleranceType | None = None
    acis_version: ACISExportVersion | None = None
    chordal_tolerance: float | None = None
    angular_tolerance_deg: float | None = None
    export_surfaces_only: bool | None = None
    scale_to_units: ScaleToUnits | None = None

@dataclass(frozen=True)
class ExportCADResult:
    success: bool
    message: Optional[str] = None

@runtime_checkable
class ExportCADTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.IExportCAD minimal surface."""
    # common property surface
    @property
    def file_type(self) -> CADFileType: ...
    @file_type.setter
    def file_type(self, v: CADFileType) -> None: ...

    @property
    def tolerance_type(self) -> CADToleranceType: ...
    @tolerance_type.setter
    def tolerance_type(self, v: CADToleranceType) -> None: ...

    @property
    def angular_tolerance_type(self) -> CADAngularToleranceType: ...
    @angular_tolerance_type.setter
    def angular_tolerance_type(self, v: CADAngularToleranceType) -> None: ...

    @property
    def acis_version(self) -> ACISExportVersion: ...
    @acis_version.setter
    def acis_version(self, v: ACISExportVersion) -> None: ...

    @property
    def chordal_tolerance(self) -> float: ...
    @chordal_tolerance.setter
    def chordal_tolerance(self, v: float) -> None: ...

    @property
    def angular_tolerance_deg(self) -> float: ...
    @angular_tolerance_deg.setter
    def angular_tolerance_deg(self, v: float) -> None: ...

    @property
    def scale_to_units(self) -> ScaleToUnits: ...
    @scale_to_units.setter
    def scale_to_units(self, v: ScaleToUnits) -> None: ...

    def set_output_path(self, path: str) -> None: ...
