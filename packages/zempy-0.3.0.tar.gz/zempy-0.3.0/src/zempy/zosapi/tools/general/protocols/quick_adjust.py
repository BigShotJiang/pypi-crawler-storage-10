from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable
from zempy.zosapi.tools.protocols.system_tool import ISystemTool
from zempy.zosapi.tools.general.enums.quick_adjust_type import QuickAdjustType
from zempy.zosapi.tools.general.enums.quick_adjust_criterion import QuickAdjustCriterion

@dataclass(frozen=True)
class QuickAdjustSettings:
    adjust_type: QuickAdjustType
    criterion: QuickAdjustCriterion

@runtime_checkable
class QuickAdjustTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.IQuickAdjust."""
    @property
    def type(self) -> QuickAdjustType: ...
    @type.setter
    def type(self, value: QuickAdjustType) -> None: ...

    @property
    def criterion(self) -> QuickAdjustCriterion: ...
    @criterion.setter
    def criterion(self, value: QuickAdjustCriterion) -> None: ...
