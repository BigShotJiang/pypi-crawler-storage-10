from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class SplineSegmentsType(ZosEnumBase):
    N_016 = 0
    N_032 = 1
    N_064 = 2
    N_128 = 3
    N_256 = 4
    N_512 = 5

# attach config AFTER class creation (safe from Enum)
SplineSegmentsType._NATIVE_PATH = "ZOSAPI.Tools.General.SplineSegmentsType"
SplineSegmentsType._ALIASES_EXTRA = {
    "N_016": ("N016",),
    "N_032": ("N032",),
    "N_064": ("N064",),
    "N_128": ("N128",),
    "N_256": ("N256",),
    "N_512": ("N512",),
}

__all__ = ["SplineSegmentsType"]