from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class ACISExportVersion(ZosEnumBase):
    CURRENT = 0
    V25 = 1
    V26 = 2
    V27 = 3
    V28 = 4
    V29 = 5
    V30 = 6

# attach config AFTER class creation (safe from Enum)
ACISExportVersion._NATIVE_PATH = "ZOSAPI.Tools.General.ACISExportVersion"
ACISExportVersion._ALIASES_EXTRA = {
    "CURRENT": ("Current",),
    "V25": ("V25",),
    "V26": ("V26",),
    "V27": ("V27",),
    "V28": ("V28",),
    "V29": ("V29",),
    "V30": ("V30",),
}

__all__ = ["ACISExportVersion"]