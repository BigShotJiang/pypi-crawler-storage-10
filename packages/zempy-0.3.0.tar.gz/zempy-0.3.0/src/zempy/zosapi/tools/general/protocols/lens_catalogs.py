from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

@dataclass(frozen=True)
class LensCatalogQuery:
    vendor: str | None = None
    model: str | None = None
    focal_length_mm: float | None = None

@dataclass(frozen=True)
class LensCatalogEntry:
    vendor: str
    model: str
    focal_length_mm: float | None = None
    file_path: str | None = None

@dataclass(frozen=True)
class LensCatalogResult:
    items: tuple[LensCatalogEntry, ...]

@runtime_checkable
class LensCatalogsTool(Protocol):
    """Wraps ZOSAPI.Tools.General.ILensCatalogs."""
    def search(self, q: LensCatalogQuery) -> LensCatalogResult: ...
