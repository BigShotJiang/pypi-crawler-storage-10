from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class RayPatternType(ZosEnumBase):
    XY_FAN = 0
    X_FAN = 1
    Y_FAN = 2
    RING = 3
    LIST = 4
    RANDOM = 5
    GRID = 6
    SOLID_RING = 7

# attach config AFTER class creation (safe from Enum)
RayPatternType._NATIVE_PATH = "ZOSAPI.Tools.General.RayPatternType"
RayPatternType._ALIASES_EXTRA = {
    "XY_FAN": ("XyFan",),
    "X_FAN": ("XFan",),
    "Y_FAN": ("YFan",),
    "RING": ("Ring",),
    "LIST": ("List",),
    "RANDOM": ("Random",),
    "GRID": ("Grid",),
    "SOLID_RING": ("SolidRing",),
}

__all__ = ["RayPatternType"]