from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class LensType(ZosEnumBase):
    OTHER = 0
    SPHERICAL = 1
    GRIN = 2
    ASPHERIC = 3
    TOROIDAL = 4

# attach config AFTER class creation (safe from Enum)
LensType._NATIVE_PATH = "ZOSAPI.Tools.General.LensType"
LensType._ALIASES_EXTRA = {
    "OTHER": ("Other",),
    "SPHERICAL": ("Spherical",),
    "GRIN": ("Grin",),
    "ASPHERIC": ("Aspheric",),
    "TOROIDAL": ("Toroidal",),
}

__all__ = ["LensType"]