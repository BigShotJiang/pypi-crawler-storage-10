from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class DataTypes(ZosEnumBase):
    NOT_SET = 0
    BOOLEAN = 1
    INTEGER = 2
    INTEGER_ARRAY = 3
    INTEGER_MATRIX = 4
    FLOAT = 5
    FLOAT_ARRAY = 6
    FLOAT_MATRIX = 7
    DOUBLE = 8
    DOUBLE_ARRAY = 9
    DOUBLE_MATRIX = 10
    STRING = 11
    STRING_ARRAY = 12
    STRING_MATRIX = 13
    BYTE_ARRAY = 14
    DICTIONARY = 15
    SERIALIZABLE = 16
    FILE = 17

# attach config AFTER class creation (safe from Enum)
DataTypes._NATIVE_PATH = "ZOSAPI.Tools.General.DataTypes"
DataTypes._ALIASES_EXTRA = {
    "NOT_SET": ("NotSet",),
    "BOOLEAN": ("Boolean",),
    "INTEGER": ("Integer",),
    "INTEGER_ARRAY": ("IntegerArray",),
    "INTEGER_MATRIX": ("IntegerMatrix",),
    "FLOAT": ("Float",),
    "FLOAT_ARRAY": ("FloatArray",),
    "FLOAT_MATRIX": ("FloatMatrix",),
    "DOUBLE": ("Double",),
    "DOUBLE_ARRAY": ("DoubleArray",),
    "DOUBLE_MATRIX": ("DoubleMatrix",),
    "STRING": ("String",),
    "STRING_ARRAY": ("StringArray",),
    "STRING_MATRIX": ("StringMatrix",),
    "BYTE_ARRAY": ("ByteArray",),
    "DICTIONARY": ("Dictionary",),
    "SERIALIZABLE": ("Serializable",),
    "FILE": ("File",),
}

__all__ = ["DataTypes"]