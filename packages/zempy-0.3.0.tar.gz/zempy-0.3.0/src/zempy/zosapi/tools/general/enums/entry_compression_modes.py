from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class EntryCompressionModes(ZosEnumBase):
    AUTO = 0
    ON = 1
    OFF = 2

# attach config AFTER class creation (safe from Enum)
EntryCompressionModes._NATIVE_PATH = "ZOSAPI.Tools.General.EntryCompressionModes"
EntryCompressionModes._ALIASES_EXTRA = {
    "AUTO": ("Auto",),
    "ON": ("On",),
    "OFF": ("Off",),
}

__all__ = ["EntryCompressionModes"]