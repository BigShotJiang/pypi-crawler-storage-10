from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class QuickAdjustType(ZosEnumBase):
    RADIUS = 0
    THICKNESS = 1

# attach config AFTER class creation (safe from Enum)
QuickAdjustType._NATIVE_PATH = "ZOSAPI.Tools.General.QuickAdjustType"
QuickAdjustType._ALIASES_EXTRA = {
    "RADIUS": ("Radius",),
    "THICKNESS": ("Thickness",),
}

__all__ = ["QuickAdjustType"]