from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class QuickAdjustCriterion(ZosEnumBase):
    SPOT_SIZE_RADIAL = 0
    SPOT_SIZE_X_ONLY = 1
    SPOT_SIZE_Y_ONLY = 2
    ANGULAR_RADIAL = 3
    ANGULAR_X_ONLY = 4
    ANGULAR_Y_ONLY = 5

# attach config AFTER class creation (safe from Enum)
QuickAdjustCriterion._NATIVE_PATH = "ZOSAPI.Tools.General.QuickAdjustCriterion"
QuickAdjustCriterion._ALIASES_EXTRA = {
    "SPOT_SIZE_RADIAL": ("SpotSizeRadial",),
    "SPOT_SIZE_X_ONLY": ("SpotSizeXOnly",),
    "SPOT_SIZE_Y_ONLY": ("SpotSizeYOnly",),
    "ANGULAR_RADIAL": ("AngularRadial",),
    "ANGULAR_X_ONLY": ("AngularXOnly",),
    "ANGULAR_Y_ONLY": ("AngularYOnly",),
}

__all__ = ["QuickAdjustCriterion"]