from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class LensShape(ZosEnumBase):
    UNKNOWN = 0
    EQUI = 1
    BI = 2
    PLANO = 3
    MENISCUS = 4

# attach config AFTER class creation (safe from Enum)
LensShape._NATIVE_PATH = "ZOSAPI.Tools.General.LensShape"
LensShape._ALIASES_EXTRA = {
    "UNKNOWN": ("Unknown",),
    "EQUI": ("Equi",),
    "BI": ("Bi",),
    "PLANO": ("Plano",),
    "MENISCUS": ("Meniscus",),
}

__all__ = ["LensShape"]