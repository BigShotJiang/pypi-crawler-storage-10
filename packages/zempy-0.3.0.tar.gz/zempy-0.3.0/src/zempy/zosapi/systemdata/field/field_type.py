from zempy.zosapi.core import ZosEnumBase

class FieldType(ZosEnumBase):
    ANGLE = 0
    OBJECT_HEIGHT = 1
    PARAXIAL_IMAGE_HEIGHT = 2
    REAL_IMAGE_HEIGHT = 3
    THEODOLITE_ANGLE = 4

# attach config AFTER class creation (safe from Enum)
FieldType._NATIVE_PATH = "ZOSAPI.SystemData.FieldType"
FieldType._ALIASES_EXTRA = {
    "ANGLE": ("Angle",),
    "OBJECT_HEIGHT": ("ObjectHeight",),
    "PARAXIAL_IMAGE_HEIGHT": ("ParaxialImageHeight",),
    "REAL_IMAGE_HEIGHT": ("RealImageHeight",),
    "THEODOLITE_ANGLE": ("TheodoliteAngle",),
}

__all__ = ["FieldType"]
