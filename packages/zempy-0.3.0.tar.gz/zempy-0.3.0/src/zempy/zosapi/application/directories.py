from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Directories:
    program: str
    lens: str
    objects: str
    glass: str
    zpl: str
    coating: str
    pop: str
    images: str
    solidworks: str
    inventor: str
    creo: str
    matlab: str
    scatter: str
    undo: str
    samples: str
    data: str
