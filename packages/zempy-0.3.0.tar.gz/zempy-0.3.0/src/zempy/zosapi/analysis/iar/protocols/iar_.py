from __future__ import annotations
from typing import Protocol, runtime_checkable, TYPE_CHECKING, Sequence

if TYPE_CHECKING:
    from zempy.zosapi.analysis.iar.protocols.iar_datagrid import IAR_DataGrid
    from zempy.zosapi.analysis.iar.protocols.iar_datagridRgb import IAR_DataGridRgb
    from zempy.zosapi.analysis.data.protocols.iar_data_series import IAR_DataSeries
    from zempy.zosapi.analysis.data.protocols.iar_data_series_rgb import IAR_DataSeriesRgb
    from zempy.zosapi.analysis.data.protocols.iar_data_scatter_points import IAR_DataScatterPoints
    from zempy.zosapi.analysis.data.protocols.iar_data_scatter_points_rgb import IAR_DataScatterPointsRgb
    from zempy.zosapi.analysis.data.protocols.iar_ray_data import IAR_RayData
    from zempy.zosapi.analysis.data.protocols.iar_critical_ray_data import IAR_CriticalRayData
    from zempy.zosapi.analysis.data.protocols.iar_path_analysis_data import IAR_PathAnalysisData
    from zempy.zosapi.analysis.data.protocols.iar_spot_data_result_matrix import IAR_SpotDataResultMatrix
    from zempy.zosapi.analysis.data.protocols.iar_nsc_single_ray_trace_data import IAR_NSCSingleRayTraceData
    from zempy.zosapi.analysis.protocols.IMessage import  IMessage
    from zempy.zosapi.analysis.data.protocols.iar_metadata import IAR_MetaData
    from zempy.zosapi.analysis.data.protocols.iar_header_data import IAR_HeaderData


@runtime_checkable
class IAR_(Protocol):
    """
    ZOSAPI.Analysis.Data.IAR_ – analysis results interface.
    Provides typed access to result payloads (grids, series, spot data, ray data, messages, etc.).
    """

    # ----------------------------
    # Methods
    # ----------------------------
    def GetDataGrid(self, index: int) -> "IAR_DataGrid": ...

    def GetDataGridRgb(self, index: int) -> "IAR_DataGridRgb": ...

    def GetDataSeries(self, index: int) -> "IAR_DataSeries": ...

    def GetDataSeriesRgb(self, index: int) -> "IAR_DataSeriesRgb": ...

    def GetDataScatterPoint(self, index: int) -> "IAR_DataScatterPoints": ...

    def GetDataScatterPointRgb(self, index: int) -> "IAR_DataScatterPointsRgb": ...

    def GetRayData(self, index: int) -> "IAR_RayData": ...

    def GetMessageAt(self, index: int) -> "IMessage": ...

    def GetTextFile(self, Filename: str) -> bool: ...

    # ----------------------------
    # Properties
    # ----------------------------
    @property
    def MetaData(self) -> "IAR_MetaData": ...

    @property
    def HeaderData(self) -> "IAR_HeaderData": ...

    @property
    def NumberOfDataGrids(self) -> int: ...

    @property
    def DataGrids(self) -> "Sequence[IAR_DataGrid]": ...

    @property
    def NumberOfDataGridsRgb(self) -> int: ...

    @property
    def DataGridsRgb(self) -> "Sequence[IAR_DataGridRgb]": ...

    @property
    def NumberOfDataSeries(self) -> int: ...

    @property
    def DataSeries(self) -> "Sequence[IAR_DataSeries]": ...

    @property
    def NumberOfDataSeriesRgb(self) -> int: ...

    @property
    def DataSeriesRgb(self) -> "Sequence[IAR_DataSeriesRgb]": ...

    @property
    def NumberOfDataScatterPoints(self) -> int: ...

    @property
    def DataScatterPoints(self) -> "Sequence[IAR_DataScatterPoints]": ...

    @property
    def NumberOfDataScatterPointsRgb(self) -> int: ...

    @property
    def DataScatterPointsRgb(self) -> "Sequence[IAR_DataScatterPointsRgb]": ...

    @property
    def NumberOfRayData(self) -> int: ...

    @property
    def RayData(self) -> "Sequence[IAR_RayData]": ...

    @property
    def CriticalRayData(self) -> "IAR_CriticalRayData": ...

    @property
    def PathAnalysisData(self) -> "IAR_PathAnalysisData": ...

    @property
    def SpotData(self) -> "IAR_SpotDataResultMatrix": ...

    @property
    def NSCSingleRayTraceData(self) -> "IAR_NSCSingleRayTraceData": ...

    @property
    def NumberOfMessages(self) -> int: ...

    @property
    def Messages(self) -> "Sequence[IMessage]": ...
    # If you have an IMessages aggregate interface, expose it as well:
    # @property
    # def StatusMessages(self) -> "IMessages": ...


__all__ = ["IAR_"]
