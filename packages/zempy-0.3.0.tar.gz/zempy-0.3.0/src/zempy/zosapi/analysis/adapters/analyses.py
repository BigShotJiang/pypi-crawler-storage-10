from __future__ import annotations
from typing import Optional
from zempy.zosapi.analysis.protocols.IA_ import IA_
from zempy.zosapi.system.protocols.IOpticalSystem import IOpticalSystem
from zempy.zosapi.analysis.enums.analysisIDM import AnalysisIDM
from zempy.zosapi.analysis.adapters.analysis_window import AnalysisWindow


class Analyses:
    def __init__(self, system: IOpticalSystem):
        self.system = system
        self.zosapi = system.zosapi
        self.native = system.raw.Analyses  # ZOSAPI.Analysis.I_Analyses


    @property
    def NumberOfAnalyses(self) -> int:
        return int(self.native.NumberOfAnalyses)

    def CloseAnalysis(self, arg) -> bool:
        if isinstance(arg, int):
            return bool(self.native.CloseAnalysis(int(arg)))
        # assume arg is IAnalysis adapter with .analysis pointing to native window
        return bool(self.native.CloseAnalysis(arg.analysis))

    def Get_AnalysisAtIndex(self, index: int) -> Optional[IA_]:
        win = self.native.Get_AnalysisAtIndex(int(index))
        return None if win is None else AnalysisWindow(self.system, win)  # your IAnalysis adapter

    def New_Analysis(self, analysis_type: AnalysisIDM) -> Optional[IA_]:
        win = self.native.New_Analysis(analysis_type)
        return None if win is None else AnalysisWindow(self.system, win)

    def New_Analysis_SettingsFirst(self, analysis_type: AnalysisIDM) -> Optional[IA_]:
        win = self.native.New_Analysis_SettingsFirst(analysis_type)
        return None if win is None else AnalysisWindow(self.system, win)


    def New_FftPsf(self) -> Optional[IA_]:
        win = self.native.New_FftPsf()
        return None if win is None else AnalysisWindow(system=self.system, native=win)




