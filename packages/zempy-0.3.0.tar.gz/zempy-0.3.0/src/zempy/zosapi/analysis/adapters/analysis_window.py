from __future__ import annotations
from typing import Any, TYPE_CHECKING

from zempy.zosapi.analysis.iar.adapters.iar import IAR
from zempy.zosapi.system.protocols.IOpticalSystem import IOpticalSystem

if TYPE_CHECKING:
    from zempy.zosapi.analysis.ias.protocols.ias_ import IAS_
    from zempy.zosapi.analysis.iar.protocols.iar_ import IAR_

class AnalysisWindow:
    def __init__(self, system: IOpticalSystem, native: Any):
        self.system = system
        self.ZOSAPI = system.zosapi
        self.analysis = native

    def GetSettings(self) -> IAS_:
        return self.analysis.GetSettings()

    def ApplyAndWaitForCompletion(self) -> None:
        self.analysis.ApplyAndWaitForCompletion()

    def WaitForCompletion(self) -> None:
        self.analysis.WaitForCompletion()

    def Terminate(self) -> None:
        self.analysis.Terminate()

    @property
    def HasAnalysisSpecificSettings(self) -> bool:
        return bool(self.analysis.HasAnalysisSpecificSettings)

    # Optional convenience
    def run(self) -> IAR_:
        self.ApplyAndWaitForCompletion()
        return IAR(self.analysis)
