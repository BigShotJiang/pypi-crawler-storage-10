from __future__ import annotations
from typing import Protocol, runtime_checkable, Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from zempy.zosapi.core.IZosapi import IZosapi
    from zempy.zosapi.analysis.ias.protocols.ias_ import IAS_
    from zempy.zosapi.analysis.iar.protocols.iar_ import IAR_
    from zempy.zosapi.system.protocols.IOpticalSystem import IOpticalSystem

@runtime_checkable
class IA_(Protocol):
    """
    Structural interface for a single analysis window (docs' IA_):
    - Owns a native analysis window handle
    - Exposes settings (IAS)
    - Runs synchronously and returns results (IAR)
    - Supports context-manager cleanup
    """
    # Typically a ZOSAPI analysis window instance
    analysis: Any
    # Optional links back to system / ZOSAPI (implementations may set these)
    system: Optional[IOpticalSystem]
    ZOSAPI: Optional[IZosapi]

    def GetSettings(self) -> IAS_: ...
    def ApplyAndWaitForCompletion(self) -> None: ...
    def WaitForCompletion(self) -> None: ...
    def Terminate(self) -> None: ...
    @property
    def HasAnalysisSpecificSettings(self) -> bool: ...

    def run(self) -> IAR_: ...
    def close(self) -> None: ...

    def __enter__(self) -> IA_: ...
    def __exit__(self, exc_type, exc, tb) -> None: ...

