from __future__ import annotations
from zemax.zos.analysis.fftpsf.psf_settings import PSFSettings
from zemax.zos.analysis.adapters.analysis_base import AnalysisBase
from zemax.zos.analysis.enums.analysisIDM import AnalysisIDM
from zemax.zos.system.adapters.optical_system import OpticalSystem

class FFTPSF(AnalysisBase):
    def __init__(self, system : OpticalSystem):
        super().__init__(system, AnalysisIDM.FftPsf)

    def _init_settings(self) -> PSFSettings:
        return PSFSettings.from_analysis(self.analysis)

    def __str__(self) -> str:
        return f"FFT PSF settings={self.analysis}"


