from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from zempy.zosapi.analysis.adapters.message import Message
from zempy.zosapi.analysis.ias.base_selector import _BaseIASSelector

@dataclass(frozen=True, slots=True)
class IASSurface(_BaseIASSelector):
    _ias_surface: Any

    _iface_attr = "_ias_surface"
    _GET_NAME   = "GetSurfaceNumber"
    _SET_NAME   = "SetSurfaceNumber"
    _LABEL      = "IAS_Surface"
    _USE_IMAGE_NAME     = "UseImageSurface"
    _USE_OBJECTIVE_NAME = "UseObjectiveSurface"

    def use_image(self) -> Message:
        return self._call_msg(self.__class__._USE_IMAGE_NAME)  # type: ignore[arg-type]

    def use_objective(self) -> Message:
        return self._call_msg(self.__class__._USE_OBJECTIVE_NAME)  # type: ignore[arg-type]
