from __future__ import annotations
from typing import TYPE_CHECKING

__all__ = ("FFTPSF",)

def __getattr__(name: str):
    if name == "FFTPSF":
        from .fftpsf.fftpsf import FFTPSF
        return FFTPSF
    raise AttributeError(name)

if TYPE_CHECKING:
    from .fftpsf.fftpsf import FFTPSF  # re-export for typing only