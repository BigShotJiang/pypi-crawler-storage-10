core-apis
===============================================================================

This project/library contains useful elements related to APIs and provides
basic structures to speed up the implementation of an API service using
the FastApi framework as base...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-apis.svg
    :target: https://pypi.org/project/core-apis/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-apis/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-apis/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-apis/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-apis/badge/?version=latest
    :target: https://readthedocs.org/projects/core-apis/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-apis
    uv pip install core-apis  # Or using UV...


Features
===============================================================================

**FastAPI Server Management**

* Quick server setup with uvicorn ASGI server
* Environment-based configuration (HOST, PORT, DEBUG, LOG_LEVEL)
* Secure defaults (localhost-only binding)

**Application Factory**

* Create pre-configured FastAPI applications
* Customizable name, version, description, and base path
* Built-in CORS middleware support
* Debug mode configuration

**Router Management**

* Dynamic router registration system
* Add custom routers before application creation
* Automatic router inclusion with configurable base path
* Built-in health check endpoint (``/api/ping``)

**Response Standardization**

* ``@wrap_response`` decorator for consistent API responses
* Standardized response format with code, status, and result/error fields
* Automatic exception handling for ServiceException and InternalServerError
* HTTP status code mapping (2XX success, 4XX error, 5XX failure)

**Testing Utilities**

* ``BaseApiTestCases`` class for FastAPI testing
* Pre-configured TestClient setup
* Automatic test application initialization
* CORS configuration for test environments


How to use it
===============================================================================

The simple way to spin up the FastAPI server and running it
locally using `uvicorn`...

.. code-block:: python

    # -*- coding: utf-8 -*-
    from core_apis.api import server
    server.run()
..

Adding custom routers...

.. code-block:: python

    # -*- coding: utf-8 -*-

    from fastapi import APIRouter

    from core_apis.api import server
    from core_apis.api.routers import add_router

    router = APIRouter()
    add_router(router)

    @router.get(path="/server_status")
    def new_router():
        return {"status": "OK"}

    server.run()
..

For an example of the structure of a production-ready project
check: https://gitlab.com/bytecode-solutions/examples/fastapi-project


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-apis
    uv pip install core-apis  # Or using UV...
    pip install -e ".[dev]"    # For development...


Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: bash

    python manager.py run-tests
    python manager.py run-coverage


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_apis``
6. Run security checks: ``bandit -r core_apis``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-apis.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-apis
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-apis/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-apis/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-apis/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
