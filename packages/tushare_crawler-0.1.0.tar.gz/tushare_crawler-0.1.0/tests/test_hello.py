from tushare_crawler import hello

def test_hello():
    assert hello()=="Hello Python!"