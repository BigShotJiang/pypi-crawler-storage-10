# lichess-api

A simple Python wrapper for Lichess API
