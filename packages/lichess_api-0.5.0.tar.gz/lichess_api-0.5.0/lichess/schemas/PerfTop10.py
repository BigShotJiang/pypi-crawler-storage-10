from .TopUser import TopUser


PerfTop10 = tuple[
    TopUser, TopUser, TopUser, TopUser, TopUser, TopUser, TopUser, TopUser, TopUser, TopUser
]

"""
PerfTop10

See https://github.com/lichess-org/api/blob/master/doc/specs/schemas/PerfTop10.yaml
"""
