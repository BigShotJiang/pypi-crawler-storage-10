GamePgn = str

"""
GamePgn

See https://github.com/lichess-org/api/blob/master/doc/specs/schemas/GamePgn.yaml
"""
