def noop[T](arg: T) -> T:
    return arg
