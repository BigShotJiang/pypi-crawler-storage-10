"""
Passkey authentication API endpoints for WebAuthn.
"""
from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional
import secrets
import base64
import sys
import json
from pathlib import Path

from webauthn import (
    generate_authentication_options,
    verify_authentication_response,
    options_to_json,
)
from webauthn.helpers.structs import (
    PublicKeyCredentialDescriptor,
    UserVerificationRequirement,
)

# Add the auth-app api directory to path for imports
_api_dir = Path(__file__).parent
if str(_api_dir) not in sys.path:
    sys.path.insert(0, str(_api_dir))

# Now import passkey_store as a module
import passkey_store as ps_module
passkey_store = ps_module.passkey_store

# Import JWT utilities
from jwt_utils import jwt_manager, is_auth_server

# Import session manager from auth middleware
try:
    from src.auth_middleware import session_manager
except ImportError:
    # Fallback for development
    sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "src"))
    from auth_middleware import session_manager


router = APIRouter()

# Temporary storage for authentication challenges
authentication_challenges: dict = {}


def get_rp_id_and_origin(request: Request) -> tuple[str, str]:
    """Extract RP_ID and ORIGIN from the request headers."""
    host = request.headers.get("host", "")
    # Remove port if present (e.g., localhost:8000 -> localhost)
    rp_id = host.split(":")[0] if host else "localhost"
    
    # Determine protocol (check if request is secure)
    protocol = "https" if request.url.scheme == "https" else "http"
    origin = f"{protocol}://{host}"
    
    return rp_id, origin


class AuthenticationStartRequest(BaseModel):
    """Request to start passkey authentication."""
    username: Optional[str] = None  # Optional for discoverable credentials


class AuthenticationStartResponse(BaseModel):
    """Response with authentication options."""
    options: dict
    session_id: str


class AuthenticationVerifyRequest(BaseModel):
    """Request to verify authentication response."""
    session_id: str
    credential: dict


class AuthenticationVerifyResponse(BaseModel):
    """Response after verifying authentication."""
    success: bool
    message: str
    username: str
    user_id: str
    token: str


@router.post("/start", response_model=AuthenticationStartResponse, summary="Start passkey authentication", tags=["auth", "passkey"])
async def start_authentication(auth_request: AuthenticationStartRequest, request: Request):
    """
    Start the passkey authentication process.
    
    IMPORTANT: Authentication can ONLY happen on the centralized auth server.
    API execution providers should redirect users to the auth server.
    
    This generates authentication options that the client will use to
    authenticate with an existing passkey.
    
    Args:
        auth_request: Optional username for authentication
        request: FastAPI request object
        
    Returns:
        Authentication options to be passed to the WebAuthn API
    """
    # Get dynamic RP_ID and ORIGIN from request
    rp_id, origin = get_rp_id_and_origin(request)
    
    allow_credentials: List[PublicKeyCredentialDescriptor] = []
    
    # If username is provided, get their credentials
    if auth_request.username:
        user = passkey_store.get_user_by_username(auth_request.username)
        if user and user.credentials:
            allow_credentials = [
                PublicKeyCredentialDescriptor(
                    id=cred.credential_id,
                    transports=cred.transports,
                )
                for cred in user.credentials
            ]
    
    # Generate authentication options
    options = generate_authentication_options(
        rp_id=rp_id,
        allow_credentials=allow_credentials,
        user_verification=UserVerificationRequirement.REQUIRED,
    )
    
    # Create a session ID
    session_id = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8').rstrip('=')
    
    # Store the challenge for verification
    authentication_challenges[session_id] = {
        "challenge": options.challenge,
        "username": auth_request.username,
        "rp_id": rp_id,
        "origin": origin,
    }
    
    # Convert options to dict (options_to_json returns a JSON string)
    options_dict = json.loads(options_to_json(options))
    
    return AuthenticationStartResponse(
        options=options_dict,
        session_id=session_id
    )


@router.post("/verify", response_model=AuthenticationVerifyResponse, summary="Verify passkey authentication", tags=["auth", "passkey"])
async def verify_authentication(verify_request: AuthenticationVerifyRequest, response: Response):
    """
    Verify the passkey authentication response from the client.
    
    IMPORTANT: Authentication can ONLY happen on the centralized auth server.
    This endpoint generates JWT tokens which should only be done on the auth server.
    
    This validates the authentication assertion and logs the user in.
    
    Args:
        verify_request: Authentication response from the client
        response: FastAPI response object for setting cookies
        
    Returns:
        Success confirmation with user info and session token
    """
    # Get the stored challenge
    challenge_data = authentication_challenges.get(verify_request.session_id)
    if not challenge_data:
        raise HTTPException(status_code=400, detail="Invalid or expired authentication session")
    
    # Get the stored RP_ID and ORIGIN from the challenge
    rp_id = challenge_data["rp_id"]
    origin = challenge_data["origin"]
    
    try:
        # Get the credential ID from the response
        credential_id_b64 = verify_request.credential.get("id")
        if not credential_id_b64:
            raise HTTPException(status_code=400, detail="Missing credential ID")
        
        # Decode the credential ID (add padding if needed)
        # Base64 strings must be a multiple of 4 characters
        padding = (4 - len(credential_id_b64) % 4) % 4
        credential_id = base64.urlsafe_b64decode(credential_id_b64 + '=' * padding)
        
        # Debug logging
        print(f"\n=== Authentication Verify Debug ===")
        print(f"Credential ID (base64): {credential_id_b64[:20]}...")
        print(f"Credential ID (bytes length): {len(credential_id)}")
        
        # Check all users and their credentials
        all_users = passkey_store.get_all_users()
        print(f"Total users in store: {len(all_users)}")
        for u in all_users:
            print(f"  User: {u.username}, Credentials: {len(u.credentials)}")
            for i, c in enumerate(u.credentials):
                cred_id_b64 = base64.urlsafe_b64encode(c.credential_id).decode('utf-8').rstrip('=')
                match = c.credential_id == credential_id
                print(f"    Cred {i}: {cred_id_b64[:20]}... Match: {match}")
        
        # Find the user by credential ID
        user = passkey_store.get_user_by_credential_id(credential_id)
        if not user:
            print(f"ERROR: User not found for credential ID")
            print(f"Available usernames: {[u.username for u in all_users]}")
            raise HTTPException(
                status_code=404, 
                detail="User not found for this credential. The passkey may not be registered on this device."
            )
        
        print(f"Found user: {user.username}")
        
        # Get the credential
        credential = passkey_store.get_credential(user.user_id, credential_id)
        if not credential:
            raise HTTPException(status_code=404, detail="Credential not found")
        
        # Verify the authentication response
        verification = verify_authentication_response(
            credential=verify_request.credential,
            expected_challenge=challenge_data["challenge"],
            expected_origin=origin,
            expected_rp_id=rp_id,
            credential_public_key=credential.public_key,
            credential_current_sign_count=credential.sign_count,
        )
        
        # Update the sign count
        passkey_store.update_credential_sign_count(
            user.user_id,
            credential_id,
            verification.new_sign_count
        )
        
        # Create a JWT token for cross-domain authentication
        jwt_token = jwt_manager.create_token(
            user_id=user.user_id,
            username=user.username,
            role=user.role,
            metadata={
                'login_time': str(verification.new_sign_count),
                'device_type': credential.device_type if hasattr(credential, 'device_type') else 'unknown'
            }
        )
        
        # Also create a session using the session manager for backward compatibility
        # Use the JWT token as the session key so lookups work
        session_token = session_manager.create_session(
            user_id=user.user_id,
            username=user.username,
            metadata={
                'login_time': str(verification.new_sign_count),
                'role': user.role
            },
            token=jwt_token  # Use JWT token as session key
        )
        
        # Set the authentication cookie with JWT token
        response.set_cookie(
            key="auth_token",
            value=jwt_token,  # Use JWT token instead of session token
            httponly=True,
            secure=False,  # Set to True in production with HTTPS
            samesite="lax",
            max_age=60 * 60 * 24 * 7  # 7 days
        )
        
        # Clean up the challenge
        del authentication_challenges[verify_request.session_id]
        
        return AuthenticationVerifyResponse(
            success=True,
            message="Authentication successful",
            username=user.username,
            user_id=user.user_id,
            token=jwt_token  # Return JWT token to client
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Authentication verification failed: {str(e)}")


@router.get("/info", summary="Get authentication endpoint info", tags=["auth", "passkey"])
async def get_authentication_info(request: Request):
    """Get information about the authentication endpoints."""
    rp_id, _ = get_rp_id_and_origin(request)
    return {
        "endpoints": {
            "/start": "Start passkey authentication",
            "/verify": "Verify passkey authentication",
            "/logout": "Logout and invalidate session",
            "/current-user": "Get current authenticated user"
        },
        "rp_id": rp_id,
        "supports_discoverable_credentials": True
    }


@router.post("/logout", summary="Logout user", tags=["auth"])
async def logout(request: Request, response: Response):
    """
    Logout the current user by invalidating their session.
    
    Args:
        request: FastAPI request object
        response: FastAPI response object for clearing cookies
        
    Returns:
        Success confirmation
    """
    # Get token from request
    token = request.cookies.get('auth_token')
    if not token:
        # Also check Authorization header
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.replace('Bearer ', '')
    
    if token:
        # Invalidate the session
        session_manager.invalidate_session(token)
    
    # Clear the cookie
    response.delete_cookie(key="auth_token")
    
    return {
        "success": True,
        "message": "Logged out successfully"
    }


@router.get("/current-user", summary="Get current user", tags=["auth"])
async def get_current_user_info(request: Request):
    """
    Get information about the currently authenticated user.
    
    Args:
        request: FastAPI request object
        
    Returns:
        User information or error if not authenticated
    """
    # Get token from request
    token = request.cookies.get('auth_token')
    if not token:
        # Also check Authorization header
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.replace('Bearer ', '')
    
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    # Get session
    session = session_manager.get_session(token)
    
    if not session:
        # Try to verify JWT token directly
        try:
            import jwt
            from jwt_utils import jwt_manager
            
            # Verify the token
            claims = jwt_manager.verify_token(token)
            if claims:
                # Token is valid - extract user info
                return {
                    "authenticated": True,
                    "user_id": claims.get('sub'),
                    "username": claims.get('username'),
                    "role": claims.get('role', 'user'),
                    "token": token,
                }
        except Exception as e:
            print(f"⚠️  JWT verification failed in /current-user: {e}")
            pass
        
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    # Get role from session metadata
    role = session.get('metadata', {}).get('role', 'user')
    
    return {
        "authenticated": True,
        "user_id": session['user_id'],
        "username": session['username'],
        "role": role,
        "token": token,  # Return the JWT token for redirect flow
        "session_created": session['created_at'].isoformat(),
        "last_accessed": session['last_accessed'].isoformat()
    }
