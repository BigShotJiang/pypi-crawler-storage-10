def hello():
    return "Hello from DeepfenceAI!"
