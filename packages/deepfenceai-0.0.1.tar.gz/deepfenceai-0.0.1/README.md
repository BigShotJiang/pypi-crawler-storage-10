# DeepfenceAI

DeepfenceAI is a cybersec utility to empower professionals and enterprises to secure their infrastructure  

## Usage
```python
import deepfenceai
print(deepfenceai.hello())
