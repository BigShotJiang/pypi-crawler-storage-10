"""
Microservice HTTP Clients

마이크로서비스 간 HTTP 통신을 위한 공통 클라이언트 베이스 클래스
"""

from .base_client import BaseServiceClient

__all__ = ["BaseServiceClient"]
