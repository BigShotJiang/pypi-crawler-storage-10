class CommandAlreadyReg(Exception): pass
class UnknownCommand(Exception): pass
class ConvertArg(Exception): pass
class ArgumentOverflow(Exception): pass