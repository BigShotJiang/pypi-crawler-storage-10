from typing import TypedDict, Literal


class CachePointBlock(TypedDict):
    type: Literal["default"]
