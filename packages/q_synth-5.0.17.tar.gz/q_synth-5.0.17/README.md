# Quantum-Circuit Synthesis - Q-Synth v5.1

A state-of-the-art open-source optimal quantum circuit synthesis tool.
This tool provides three main synthesis options Layout Synthesis, CNOT (Re)Synthesis, and Clifford (Re)Synthesis.

## Key Features
- Layout Synthesis with Classical Planning and SAT for optimizing CNOT-count/-depth (v1.0, v2.0, v4.0).
- Layout aware CNOT (Re)Synthesis with Planning, SAT and QBF optimizing CNOT-count/-depth (v3.0).
- Layout aware CNOT-Optimal Clifford Synthesis as SAT (v5.0).
- Scalable layout synthesis for large platforms via maximal subarchitectures (v4.0).
- All efficient synthesis features based on SAT are available via API (with easy PyPi installation, v5.1).
- Additional features with planning and QBF are available via command line interface.

## Getting started

Q-Synth can be installed via pypi (url):

    python3 -m pip install Q-Synth

> **Recommended:** Please use a fresh python virtual environment.

### Layout Synthesis

For layout synthesis simply call `layout_synthesis` with your circuit (as a qiskit QuantumCircuit) and a coupling graph as input. For example:

    from qsynth import get_coupling_graph, layout_synthesis
    from qiskit import QuantumCircuit

    # An example bidirectional coupling graph
    coupling_graph = get_coupling_graph(coupling_graph=[[0,1],[1,2]], bidirectional=1)

    qc = QuantumCircuit(3)
    qc.cx(0,1)
    qc.s(0)
    qc.cx(0,2)
    qc.cx(1,2)

    mapped_result = layout_synthesis(circuit=qc, coupling_graph=coupling_graph, metric="cx-count", verbose=-1) # silent mode
    print(mapped_result.circuit)
    print(mapped_result.final_mapping)

`mapped_result.circuit` contains the mapped circuit with provably optimal swap count, and `mapped_result.final_mapping` stores the output qubit permutation.

### Peephole Synthesis with CNOT and Clifford (Re)Synthesis

Q-Synth can resynthesize CNOT/Clifford sub-circuits in a peephole manner to further optimize the CNOT count or depth, while still respecting the layout constraints.

For example, we can easily resynthesize our mapped result circuit using peephole synthesis with CNOT slicing using:

    from qsynth import peephole_synthesis
    opt_result = peephole_synthesis(circuit=mapped_result.circuit, coupling_graph=coupling_graph, slicing="cnot", metric="cx-count")

`opt_result.circuit` contains the resynthesized circuit with 5 CNOTs instead of 6 without any extra single qubit gates.

Using Clifford slicing allows resynthesis of larger sub-circuits with possible further reductions. Simply using `slicing="clifford"` in the `peephole_synthesis` call enables this.

    opt_result = peephole_synthesis(circuit=mapped_result.circuit, coupling_graph=coupling_graph, slicing="clifford", metric="cx-count")

`opt_result.circuit` now only has 4 CNOTs, but with extra single qubit gates.

Q-Synth also supports several other features such as optimizing for CNOT depth, using subarchitectures, qubit permutations, and more.
Please refer to tutorials in (Jupyter Notebook) for more examples.

<sub>For optional features via command line with classical planning and QBF solvers, please see the [Installation Instructions](INSTALL.md).
Detail descriptions are available in [README_layout.md](README_layout.md), [README_cnot.md](README_cnot.md), [README_clifford.md](README_clifford.md) pages.</sub>

## Publications

Please refer to this publication for Layout-Synthesis based on classical-planning (v1.0):

I. Shaik, J. van de Pol, _Optimal Layout Synthesis for Quantum Circuits as Classical Planning_. 
In: Proc. IEEE/ACM IC on Computer-Aided Design, (ICCAD'23), San Francisco, California, USA, 2023.

    @inproceedings{ShaikvdP2023,
      author       = {Irfansha Shaik and Jaco van de Pol},
      title        = {Optimal Layout Synthesis for Quantum Circuits as Classical Planning},
      booktitle    = {{ICCAD'23}},
      address      = {{San Diego, California, USA}},
      organization = {{IEEE/ACM}},
      year         = {2023}
    }

Please refer to this publication for Layout-Synthesis based on SAT encoding (v2.0):

I. Shaik, J. van de Pol, _Optimal layout synthesis for deep quantum circuits on NISQ processors with 100+ qubits_.

    @article{shaikvdP2024layoutsynthesis,
      author       = {Irfansha Shaik and Jaco van de Pol},
      title        = {Optimal Layout Synthesis for Deep Quantum Circuits on {NISQ} Processors with 100+ Qubits}, 
      booktitle    = {27th International Conference on Theory and Applications of Satisfiability
                      Testing, {SAT} 2024, August 21-24, 2024, Pune, India},
      series       = {LIPIcs},
      publisher    = {Schloss Dagstuhl - Leibniz-Zentrum f{\"{u}}r Informatik},
      year         = {2024}
    }

Please refer to this publication for CNOT synthesis (based on Planning, SAT and QBF) (v3.0):

I. Shaik, J. van de Pol, _Optimal Layout-Aware CNOT Circuit Synthesis with Qubit Permutation_.
In: Proc. 27th European Conference on Artificial Intelligence, (ECAI'24), Santiago de Compostela, Spain, 2024.

    @inproceedings{ShaikvdP2024cnotsynthesis,
      author       = {Irfansha Shaik and Jaco van de Pol},
      title        = {Optimal Layout-Aware CNOT Circuit Synthesis with Qubit Permutation},
      booktitle    = {{ECAI'24}},
      address      = {{Santiago de Compostela, Spain}},
      publisher    = {IOS Press},
      year         = {2024}
    }


Please refer to this publication for Depth-Optimal Synthesis (v4.0):
A. B. Clausen, A. B. Jakobsen, J. van de Pol, I. Shaik, _Depth-Optimal Quantum Layout Synthesis as SAT_.

    @article{Jakobsen2025depthoptimal,
      author       = {Anna Blume Jakobsen, Anders Benjamin Clausen, Jaco van de Pol and Irfansha Shaik},
      title        = {Depth-Optimal Quantum Layout Synthesis as SAT},
      booktitle    = {28th International Conference on Theory and Applications of Satisfiability
                      Testing, {SAT} 2025, August 12-15, 2025, Glasgow, Scotland},
      series       = {LIPIcs},
      publisher    = {Schloss Dagstuhl - Leibniz-Zentrum f{\"{u}}r Informatik},
      year         = {2025}
    }

Depth-Optimal Synthesis was ported from [GitHub repository](https://github.com/anbclausen/quills).

Please refer to this publication for Sub-Architectures (v4.0):
K. Milkevych, J. van de Pol, I. Shaik, _Practical Subarchitectures for Optimal Quantum Layout Synthesis_.
    
    @mastersthesis{Milkevych2025subarchitectures,
      title         = {Practical Subarchitectures for Optimal Quantum Layout Synthesis},
      school        = {Aarhus University},
      author        = {Kostiantyn V. Milkevych and Jaco van de Pol and Irfansha Shaik},
      eprint        = {2507.12976},
      archivePrefix = {arXiv},
      primaryClass  = {quant-ph},
      year          = {2025}
    }


Please refer to this publication for CNOT-Optimal Clifford synthesis (v5.0):

I. Shaik, J. van de Pol, _CNOT-Optimal Clifford Synthesis as SAT_.

    @article{shaikvdP2025cliffordsynthesis,
      author       = {Irfansha Shaik and Jaco van de Pol},
      title        = {CNOT-Optimal Clifford Synthesis as SAT},
      booktitle    = {28th International Conference on Theory and Applications of Satisfiability
                      Testing, {SAT} 2025, August 12-15, 2025, Glasgow, Scotland},
      series       = {LIPIcs},
      publisher    = {Schloss Dagstuhl - Leibniz-Zentrum f{\"{u}}r Informatik},
      year         = {2025}
    }

## Limitations

The input should only contain unary gates and binary CNOT gates.
We currently do not handle multiple quantum registers in the input circuit.

The scripts are tested on Linux and macOS.

## Copyright

(C) CC-BY Irfansha Shaik, Jaco van de Pol, Aarhus University, 2023, 2024, 2025

## Contributors

- Irfansha Shaik (Aarhus University, Kvantify)
- Jaco van de Pol (Aarhus University)
- Anna Blume Jakobsen (depth-optimal layout mapping)
- Anders B. Clausen (depth-optimal layout mapping)
- Kostiantyn Milkevych (subarchitectures, testing)
