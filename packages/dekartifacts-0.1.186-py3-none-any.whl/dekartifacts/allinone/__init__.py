from .docker import DockerAllInOne
from .helm import HelmCommonAllInOne, HelmGitAllInOne, HelmCodingAllInOne
from .staticfiles import StaticfilesAllInOne
