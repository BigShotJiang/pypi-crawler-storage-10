# b402

Gasless crypto payments on BSC.

## Install

```bash
pip install b402
```

## Usage

```bash
export PRIVATE_KEY="0x..."
```

```python
from b402 import pay

result = pay(amount="0.01", token="USD1", recipient="0x...")

if result.success:
    print(f"TX: {result.tx_hash}")
else:
    print(f"Error: {result.error}")
```

First payment auto-approves $10,000 worth (one-time, costs gas). Future payments use existing allowance.

Defaults to BSC mainnet.

### Manual Control

```python
from b402 import B402

b402 = B402()

# Check approval
approved, allowance = b402.check_approval("USD1")

# Setup
if not approved:
    b402.setup("USD1")

# Pay
result = b402.pay(amount="0.01", token="USD1", recipient="0x...")
```

## How It Works

**First Payment:**
1. Checks token allowance
2. Approves up to $10,000 if needed (costs gas once)
3. Sends payment (gasless)

**Subsequent Payments:**
1. Uses existing allowance
2. Sends immediately (gasless)
3. Re-approves automatically when low

### Security

Capped approvals prevent unlimited token exposure.

**Most SDKs:**
```python
approve(relayer, 2^256-1)  # Infinite
```

**B402:**
```python
approve(relayer, 10_000 * 10^18)  # $10k cap
```

## API

### `pay()`

```python
from b402 import pay

result = pay(
    amount="0.01",
    token="USD1",
    recipient="0x...",
    network="mainnet",  # Optional
    auto_approve=True,  # Optional
    debug=False         # Optional
)
```

### `B402()`

```python
from b402 import B402

b402 = B402()  # mainnet
```

**Methods:**
- `b402.setup(token)` - One-time approval
- `b402.check_approval(token)` - Check approval status
- `b402.pay(amount, token, recipient)` - Send payment

## Supported Tokens

**Mainnet:** USD1, USDT, USDC
**Testnet:** USDT

## Network Details

**BSC Mainnet** (Chain ID: 56)
- Relayer: `0xE1C2830d5DDd6B49E9c46EbE03a98Cb44CD8eA5a`
- USD1: `0x8d0d000ee44948fc98c9b98a4fa4921476f08b0d`
- USDT: `0x55d398326f99059fF775485246999027B3197955`
- USDC: `0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d`

**BSC Testnet** (Chain ID: 97)
- Relayer: `0x62150F2c3A29fDA8bCf22c0F22Eb17270FCBb78A`
- USDT: `0x337610d27c682E347C9cD60BD4b3b107C9d34dDd`

## License

MIT
