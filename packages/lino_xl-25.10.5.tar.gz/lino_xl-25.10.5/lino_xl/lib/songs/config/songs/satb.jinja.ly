\version "2.25.24"
\paper{
    indent=0\mm
    line-width={{sng.scores_line_width}}
    oddFooterMarkup=##f
    oddHeaderMarkup=##f
    bookTitleMarkup = ##f
    scoreTitleMarkup = ##f
    }
\score {
\new GrandStaff <<
  \new Staff = "SA" <<
    \new Voice = "soprano" {
    {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
    {% if sng.scores_alto %} \voiceOne {% endif %} <<
      {{sng.scores_preamble}} \relative g' {
      {{sng.scores_soprano}}
      } >> }
  {% if sng.scores_alto %}
   \new Voice = "alto" { \voiceTwo <<
     {{sng.scores_preamble}} \relative g' {
     {{sng.scores_alto}} }
   >> }
  {% endif %}
 >>

{#############
{% for lyrics in sng.get_lyrics() %}
\new Lyrics
\lyricsto "soprano" { \lyricmode {
  {% if loop.first %}
  \override LyricText.font-shape = #'italic
  {% endif %}
  {{lyrics}}
} }
{% endfor %}
##############}

{% for lyrics in sng.get_lyrics() %}
\new Lyrics
\lyricsto "soprano" {
  {% if not loop.first %}
  \override LyricText . font-family = #'sans
  \override LyricText . font-shape = #'italic
  \override LyricText . font-size = #-1
  {% else %}
  \override LyricText . font-family = #'sans
  {% endif %}
  {{lyrics}}
}
{% endfor %}


{% if sng.scores_tenor or sng.scores_bass %}
 \new Staff = "TB" <<
  \clef bass
  {% if sng.scores_tenor %}
  \new Voice = "tenor" {
    {% if sng.scores_bass %} \voiceOne {% endif %}
  << {{sng.scores_preamble}} \relative f {
    {{sng.scores_tenor}}
  } >> }
  {% endif %}
  {% if sng.scores_bass %}
  \new Voice = "bass" {
    \voiceTwo
    << {{sng.scores_preamble}} \relative f {
    {{sng.scores_bass}}
  } >> }
  {% endif %}
 >>
{% endif %}

>>
   \layout{
   {# setting font-name here causes italic above to not work
   \context { \Lyrics \override LyricText.font-name = #"DejaVu Sans" }
   #}
   \context { \Score \omit BarNumber }
}
}
