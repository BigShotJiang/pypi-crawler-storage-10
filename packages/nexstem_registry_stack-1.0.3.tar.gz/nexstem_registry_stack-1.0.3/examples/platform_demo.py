#!/usr/bin/env python3
"""
Platform-agnostic Python SDK demonstration.

This script demonstrates how the Python SDK automatically detects
platform-specific paths and library extensions.
"""

import sys
import os
from pathlib import Path

# Add the src directory to the path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from utils.platform import (
    get_platform_info,
    get_library_extension,
    get_executable_extension,
    resolve_library_paths,
    resolve_library_path,
    get_possible_library_paths
)

def main():
    """Demonstrate platform detection and path resolution."""
    print("=== SW Registry Stack Python SDK - Platform Demo ===\n")
    
    # Show platform information
    platform_info = get_platform_info()
    print(f"Platform: {platform_info.os.value}")
    print(f"Architecture: {platform_info.arch.value}")
    print(f"Library Extension: {platform_info.lib_ext}")
    print(f"Executable Extension: {platform_info.exe_ext}")
    print(f"Path Separator: {platform_info.path_sep}")
    print()
    
    # Show resolved library paths
    print("=== Resolved Library Paths ===")
    paths = resolve_library_paths()
    for key, value in paths.items():
        print(f"{key}: {value}")
    print()
    
    # Show library extension detection
    print("=== Library Extension Detection ===")
    lib_ext = get_library_extension()
    exe_ext = get_executable_extension()
    print(f"Library extension: {lib_ext}")
    print(f"Executable extension: {exe_ext}")
    print()
    
    # Show possible library paths for different libraries
    libraries = ['executor_bridge', 'operator_registry_bridge', 'pipeline_registry_bridge', 'recorder_bridge']
    
    for lib_name in libraries:
        print(f"=== {lib_name} ===")
        possible_paths = get_possible_library_paths(lib_name)
        print(f"Possible paths ({len(possible_paths)}):")
        for i, path in enumerate(possible_paths[:5], 1):  # Show first 5 paths
            print(f"  {i}. {path}")
        if len(possible_paths) > 5:
            print(f"  ... and {len(possible_paths) - 5} more")
        
        # Try to resolve the actual path
        resolved_path = resolve_library_path(lib_name)
        if resolved_path:
            print(f"✓ Resolved: {resolved_path}")
        else:
            print("✗ Not found")
        print()
    
    # Show environment variables
    print("=== Environment Variables ===")
    env_vars = [
        'SW_REGISTRY_BASE_PATH',
        'SW_REGISTRY_LOG_DIR',
        'EXECUTOR_PATH',
        'OPERATOR_REGISTRY_PATH',
        'PIPELINE_REGISTRY_PATH',
        'RECORDER_PATH',
        'BRIDGE_LIB_PATH',
        'SW_REGISTRY_ROOT'
    ]
    
    for var in env_vars:
        value = os.environ.get(var, "Not set")
        print(f"{var}: {value}")
    print()
    
    print("=== SDK Configuration Demo ===")
    print("The Python SDK will automatically use these platform-specific paths")
    print("when creating configuration objects. No manual path configuration needed!")
    print()
    print("Example usage:")
    print("  from modules.executor.dto.config import ExecutorConfig")
    print("  config = ExecutorConfig()  # Automatically uses platform-specific paths")
    print("  print(config.bridge_lib_path)  # Shows resolved library path")

if __name__ == "__main__":
    main()
