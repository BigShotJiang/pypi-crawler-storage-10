#!/usr/bin/env python3
"""
Executor Example - Demonstrates how to use the Executor from nexstem-registry-stack
This example shows the basic workflow of creating, starting, and managing pipelines
"""

import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "src"))

from modules.executor import Executor

print("🚀 Executor Example - nexstem-registry-stack")
print("=" * 50)

async def executor_example():
    """Test Executor methods like in Node.js SDK"""
    print("🧪 Testing Executor Methods - nexstem-registry-stack")
    print("=" * 60)
    
    try:
        # Initialize Executor (like Node.js SDK)
        print("\n1️⃣ Initializing Executor...")
        executor = Executor({})
        print("✅ Executor created successfully")
        
        # Initialize bridge
        print("\n2️⃣ Initializing native bridge...")
        await executor.initialize()
        print("✅ Executor initialized successfully")
        
        # Test version method
        print("\n3️⃣ Testing version() method...")
        version_result = await executor.version()
        print(f"✅ Version: {version_result}")
        
        # Test list method
        print("\n4️⃣ Testing list() method...")
        list_result = await executor.list()
        print(f"✅ List result: {list_result}")
        
        # Test info method (with runId like Node.js)
        print("\n5️⃣ Testing info() method...")
        try:
            info_result = await executor.info({"runId": "test-run-123"})
            print(f"✅ Info result: {info_result}")
        except Exception as e:
            print(f"⚠️  Info method test (expected to fail without real run): {e}")
        
        # Test create method (will fail without native libraries, but we can test the call)
        print("\n6️⃣ Testing create() method...")
        try:
            create_result = await executor.create(
                json_file="/path/to/example-pipeline.json",
                device_id="example-device-001",
                background=True,
                enable_logging=True
            )
            print(f"✅ Create result: {create_result}")
        except Exception as e:
            print(f"⚠️  Create method test (expected to fail without native libraries): {e}")
        
        print("\n🎉 Executor methods are working correctly!")
        
    except Exception as error:
        print(f"❌ Executor example failed: {error}")
        print("   This is expected if native bridge libraries are not available")
        print("   In a real environment, ensure the bridge libraries are properly installed")

# Run the example
if __name__ == "__main__":
    asyncio.run(executor_example())
    print("\n🎉 Executor example completed!")
    print("\n📚 Next steps:")
    print("   1. Install the actual bridge libraries")
    print("   2. Provide correct paths to bridge libraries")
    print("   3. Create a real pipeline configuration file")
    print("   4. Run with actual hardware/device")
