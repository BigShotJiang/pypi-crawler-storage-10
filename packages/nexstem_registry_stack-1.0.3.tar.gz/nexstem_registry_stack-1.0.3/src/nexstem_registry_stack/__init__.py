"""
Public package entrypoint for nexstem-registry-stack.

This shim exposes a clean top-level import path while keeping the existing
internal repository layout intact. It re-exports the SDK's public API from
the underlying modules.
"""

from ..modules.operator_registry import OperatorRegistry  # noqa: F401
from ..modules.pipeline_registry import PipelineRegistry  # noqa: F401
from ..modules.executor import Executor  # noqa: F401
from ..modules.recorder import Recorder  # noqa: F401

from ..exceptions import (  # noqa: F401
    SdkError,
    ValidationError,
    FfiBridgeError,
    ConfigurationError,
    CliExecutionError,
)

from ..shared.dto.common import (  # noqa: F401
    BaseConfig,
    CliResponse,
    ErrorDetails,
    PaginationOptions,
    OperationOptions,
)

# Often-used typed DTOs (optional to re-export; add as needed)
# from ..modules.operator_registry.dto.options import (  # noqa: F401
#     OperatorListOptions,
#     OperatorInstallOptions,
#     OperatorUninstallOptions,
#     OperatorInfoOptions,
# )

__all__ = [
    # Core services
    "OperatorRegistry",
    "PipelineRegistry",
    "Executor",
    "Recorder",
    # Exceptions
    "SdkError",
    "ValidationError",
    "FfiBridgeError",
    "ConfigurationError",
    "CliExecutionError",
    # Common types
    "BaseConfig",
    "CliResponse",
    "ErrorDetails",
    "PaginationOptions",
    "OperationOptions",
]


